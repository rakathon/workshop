# DineFind

A US restaurant discovery and delivery web app. Find the right restaurant by cuisine, menu, photos, and reviews — then order delivery without switching apps.

## Screenshots

| Home | Search results |
|---|---|
| ![Home](docs/screenshots/01-home.png) | ![Search](docs/screenshots/02-search.png) |

| Restaurant listing | Cart & cashback |
|---|---|
| ![Listing](docs/screenshots/03-listing.png) | ![Cart](docs/screenshots/04-cart.png) |

| Live delivery tracking |
|---|
| ![Tracking](docs/screenshots/05-tracking.png) |

## Features

- **Restaurant discovery** — search by city, filter by cuisine, price range, dietary options, and meal period
- **Rich listings** — photos, full menus, hours, star ratings, and user reviews on every restaurant
- **Order delivery** — add items to cart, enter a delivery address, pay with a mock card, and track your order live
- **Cashback discounts** — each restaurant offers 3–10% cashback applied automatically at checkout
- **Order history** — view past orders and re-order in one tap
- **Live delivery tracking** — 4-step status stepper with automatic mock progression

## Tech stack

| Layer | Technology |
|---|---|
| Framework | React 19 + TypeScript |
| Routing | React Router v7 |
| Styling | Tailwind CSS v4 + inline design tokens |
| Build | Vite 8 |
| Unit tests | Vitest + Testing Library |
| E2E tests | Playwright (Chromium + mobile Chrome) |
| Persistence | Browser `localStorage` (MVP) |

## Getting started

```bash
npm install
npm run dev        # start dev server at http://localhost:3000
```

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Start dev server at localhost:3000 |
| `npm run build` | Production build |
| `npm run unit` | Run unit tests (Vitest) |
| `npm run unit:watch` | Watch mode for unit tests |
| `npm test` | Run Playwright E2E tests (requires dev server) |
| `npm run test:ui` | Playwright UI mode |
| `npm run lint` | ESLint |
| `npm run validate-data` | Validate mock JSON data files |

## Project structure

```
src/
├── components/
│   ├── cart/           # CartPanel
│   ├── checkout/       # CheckoutProgress, AddressStep, OrderSummary, PaymentStep
│   ├── home/           # CityAutocomplete, CuisinePills
│   ├── listing/        # MenuDisplay, PhotoGallery, ReviewSection
│   ├── order/          # OrderConfirmation, OrderHistory, TrackingScreen
│   ├── search/         # FilterSidebar, RestaurantCard
│   └── ui/             # AddToCartButton, CashbackBadge, OpenBadge, StarRating, …
├── context/
│   ├── CartContext.tsx  # Cart state shared across the app
│   └── FilterContext.tsx
├── data/
│   ├── cities.json      # 5 US cities
│   ├── cuisines.json
│   └── restaurants.json # 21 mock restaurants
├── lib/
│   ├── cartService.ts
│   ├── orderService.ts
│   └── storage/         # LocalStorageService, mockSeed, userService, types
├── pages/
│   ├── HomePage.tsx
│   ├── SearchPage.tsx
│   ├── ListingPage.tsx
│   ├── CheckoutPage.tsx
│   ├── ConfirmationPage.tsx
│   ├── TrackingPage.tsx
│   └── OrderHistoryPage.tsx
└── types/index.ts
tests/
├── order-e2e.spec.ts    # 12 system E2E scenarios (SC-1–SC-12)
└── order-ui.spec.ts     # 15 UI E2E scenarios (SC-1–SC-15)
```

## Data and storage

All data is stored in `localStorage` under `dinefind:*` keys. Mock restaurant and menu data is seeded on first app load from `src/lib/storage/mockSeed.ts`. No backend is required.

Key localStorage schema:

| Key | Contents |
|---|---|
| `dinefind:user` | Local user identity (UUID, generated on first visit) |
| `dinefind:cart:<restaurant_id>` | Active cart for a restaurant |
| `dinefind:orders` | All placed orders, most recent first |
| `dinefind:restaurants` | Mock restaurant catalogue (5 restaurants, 3–10% cashback) |
| `dinefind:menu:<restaurant_id>` | Menu items per restaurant |

## Routes

| Route | Page |
|---|---|
| `/` | Home — city + cuisine search |
| `/search` | Search results with filters |
| `/restaurant/:id` | Restaurant listing — menu, photos, reviews, order |
| `/checkout/:restaurantId` | 3-step checkout (address → summary → payment) |
| `/confirmation/:orderId` | Order confirmation |
| `/tracking/:orderId` | Live delivery tracking |
| `/orders` | Order history |

## Testing

117 unit tests and 54 Playwright E2E tests (27 scenarios × Chromium + mobile Chrome).

```bash
# Unit tests
npm run unit

# E2E (starts dev server automatically)
npm test

# E2E on a specific browser
npx playwright test --project=chromium
```
