import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'
import { cartService } from '../lib/cartService'
import { getOrCreateUser } from '../lib/storage'
import type { StoredCart } from '../lib/storage/types'

interface CartContextValue {
  cart: StoredCart | null
  restaurantId: string | null
  isOpen: boolean
  openCart: (restaurantId: string) => void
  closeCart: () => void
  addItem: (restaurantId: string, item: { id: string; name: string; price: number }) => void
  changeQuantity: (menuItemId: string, qty: number) => void
  loadCart: (restaurantId: string) => void
  totalItems: number
}

const CartContext = createContext<CartContextValue | null>(null)

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<StoredCart | null>(null)
  const [restaurantId, setRestaurantId] = useState<string | null>(null)
  const [isOpen, setIsOpen] = useState(false)

  const openCart = useCallback((rid: string) => {
    const existing = cartService.getCart(rid)
    setCart(existing)
    setRestaurantId(rid)
    setIsOpen(true)
  }, [])

  const closeCart = useCallback(() => setIsOpen(false), [])

  // Hydrate context from localStorage — call on listing page mount
  const loadCart = useCallback((rid: string) => {
    const existing = cartService.getCart(rid)
    if (existing && existing.status === 'active') {
      setCart(existing)
      setRestaurantId(rid)
    }
  }, [])

  const addItem = useCallback((
    rid: string,
    item: { id: string; name: string; price: number },
  ) => {
    const user = getOrCreateUser()
    const updated = cartService.addItem(rid, { ...item, restaurant_id: rid }, user.id)
    setCart(updated)
    setRestaurantId(rid)
  }, [])

  const changeQuantity = useCallback((menuItemId: string, qty: number) => {
    if (!restaurantId) return
    const updated = cartService.updateQuantity(restaurantId, menuItemId, qty)
    setCart(updated)
  }, [restaurantId])

  const totalItems = cart?.items.reduce((s, i) => s + i.quantity, 0) ?? 0

  return (
    <CartContext.Provider value={{ cart, restaurantId, isOpen, openCart, closeCart, addItem, changeQuantity, loadCart, totalItems }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
