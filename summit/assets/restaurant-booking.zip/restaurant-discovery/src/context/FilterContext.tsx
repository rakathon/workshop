import { createContext, useContext, useState, useEffect, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import type { FilterState } from '../types'

const defaultFilters: FilterState = {
  city: '',
  cuisine: [],
  price: [],
  dietary: [],
  mealPeriod: '',
  openNow: false,
}

interface FilterContextValue {
  filters: FilterState
  setFilters: (filters: FilterState) => void
  updateFilter: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void
  clearFilters: () => void
}

const FilterContext = createContext<FilterContextValue | null>(null)

function parseSearchParams(params: URLSearchParams): Partial<FilterState> {
  return {
    city: params.get('city') ?? '',
    cuisine: params.get('cuisine') ? params.get('cuisine')!.split(',') : [],
    price: params.get('price') ? params.get('price')!.split(',') : [],
    dietary: params.get('dietary') ? params.get('dietary')!.split(',') : [],
    mealPeriod: params.get('mealPeriod') ?? '',
    openNow: params.get('openNow') === 'true',
  }
}

function filtersToSearchParams(filters: FilterState): URLSearchParams {
  const params = new URLSearchParams()
  if (filters.city) params.set('city', filters.city)
  if (filters.cuisine.length) params.set('cuisine', filters.cuisine.join(','))
  if (filters.price.length) params.set('price', filters.price.join(','))
  if (filters.dietary.length) params.set('dietary', filters.dietary.join(','))
  if (filters.mealPeriod) params.set('mealPeriod', filters.mealPeriod)
  if (filters.openNow) params.set('openNow', 'true')
  return params
}

export function FilterProvider({ children }: { children: ReactNode }) {
  const [searchParams, setSearchParams] = useSearchParams()
  const [filters, setFiltersState] = useState<FilterState>(() => ({
    ...defaultFilters,
    ...parseSearchParams(searchParams),
  }))

  // Restore from URL on mount / URL changes
  useEffect(() => {
    setFiltersState(prev => ({ ...prev, ...parseSearchParams(searchParams) }))
  }, [searchParams])

  function setFilters(newFilters: FilterState) {
    setFiltersState(newFilters)
    setSearchParams(filtersToSearchParams(newFilters), { replace: true })
  }

  function updateFilter<K extends keyof FilterState>(key: K, value: FilterState[K]) {
    const updated = { ...filters, [key]: value }
    setFilters(updated)
  }

  function clearFilters() {
    setFilters(defaultFilters)
  }

  return (
    <FilterContext.Provider value={{ filters, setFilters, updateFilter, clearFilters }}>
      {children}
    </FilterContext.Provider>
  )
}

export function useFilters() {
  const ctx = useContext(FilterContext)
  if (!ctx) throw new Error('useFilters must be used within FilterProvider')
  return ctx
}

export { filtersToSearchParams, parseSearchParams }
