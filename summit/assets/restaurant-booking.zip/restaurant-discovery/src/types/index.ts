export interface City {
  id: string
  name: string
  state: string
  displayName: string
  timezone: string
  zip: string
}

export interface Cuisine {
  id: string
  name: string
  slug: string
}

export interface User {
  id: string
  displayName: string
}

export interface Address {
  street: string
  neighbourhood: string
  city: string
  state: string
  zip: string
  lat: number
  lng: number
  timezone: string
}

export type DayOfWeek = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday'

export interface DayHours {
  open: string
  close: string
}

export type WeeklyHours = Record<DayOfWeek, DayHours | null>

export interface Photo {
  id: string
  url: string
  alt: string
  sortOrder: number
}

export interface MenuItem {
  id: string
  name: string
  description: string
  price: number
}

export interface MenuSection {
  id: string
  name: string
  position: number
  items: MenuItem[]
}

export interface Menu {
  lastUpdated: string
  sections: MenuSection[]
}

export interface Review {
  id: string
  userId: string
  userName: string
  rating: number
  text: string
  reviewedAt: string
  photoUrl: string | null
}

export interface Restaurant {
  id: string
  slug: string
  name: string
  cityId: string
  address: Address
  cuisineIds: string[]
  cuisineNames: string[]
  priceRange: '$' | '$$' | '$$$' | '$$$$'
  dietaryOptions: string[]
  mealPeriods: string[]
  coverPhoto: string
  isComplete: boolean
  averageRating: number
  recentAverageRating: number
  reviewCount: number
  recentReviewCount: number
  hours: WeeklyHours
  photos: Photo[]
  menu: Menu
  reviews: Review[]
}

export interface FilterState {
  city: string
  cuisine: string[]
  price: string[]
  dietary: string[]
  mealPeriod: string
  openNow: boolean
}
