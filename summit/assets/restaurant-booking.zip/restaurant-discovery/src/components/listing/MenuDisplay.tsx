import { useState } from 'react'
import type { Menu } from '../../types'

interface Props {
  menu: Menu
}

function daysSince(dateStr: string): number {
  return Math.floor((Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24))
}

export function MenuDisplay({ menu }: Props) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>(
    Object.fromEntries(menu.sections.map(s => [s.id, true]))
  )

  if (!menu.sections.length) {
    return (
      <div style={{
        textAlign: 'center', padding: '32px 24px',
        background: '#FAFAF8', borderRadius: '12px',
        border: '1px dashed var(--color-border)',
      }}>
        <div style={{ fontSize: '32px', marginBottom: '8px' }}>📋</div>
        <p style={{ fontSize: '14px', color: 'var(--color-text-muted)' }}>Menu not yet available</p>
      </div>
    )
  }

  const days = daysSince(menu.lastUpdated)
  const freshLabel = days === 0 ? 'Updated today' : `Updated ${days} day${days !== 1 ? 's' : ''} ago`
  const isRecent = days <= 30

  return (
    <div>
      {/* Freshness banner */}
      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: '6px',
        padding: '5px 12px', borderRadius: '8px', marginBottom: '20px',
        background: isRecent ? '#e8f5e9' : '#FFF3E0',
        border: `1px solid ${isRecent ? '#a5d6a7' : '#ffcc80'}`,
        fontSize: '12px', fontWeight: 600,
        color: isRecent ? '#2e7d32' : '#e65100',
      }}>
        <span>{isRecent ? '✓' : '⚠'}</span>
        {freshLabel}
      </div>

      {/* Sections */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {menu.sections.sort((a, b) => a.position - b.position).map(section => {
          const isOpen = expanded[section.id]
          return (
            <div key={section.id} style={{
              borderRadius: '14px', overflow: 'hidden',
              border: '1px solid var(--color-border)',
              boxShadow: isOpen ? 'var(--shadow-sm)' : 'none',
              transition: 'box-shadow 140ms',
            }}>
              {/* Section header */}
              <button
                onClick={() => setExpanded(e => ({ ...e, [section.id]: !e[section.id] }))}
                aria-expanded={isOpen}
                style={{
                  width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '14px 20px', cursor: 'pointer', border: 'none',
                  background: isOpen
                    ? 'linear-gradient(135deg, var(--color-brand-light) 0%, #ede9ff 100%)'
                    : '#FAFAF8',
                  textAlign: 'left',
                  transition: 'background 140ms',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style={{ fontSize: '18px' }}>
                    {section.name.toLowerCase().includes('start') || section.name.toLowerCase().includes('appetiz') || section.name.toLowerCase().includes('snack') || section.name.toLowerCase().includes('small') ? '🥗'
                      : section.name.toLowerCase().includes('main') || section.name.toLowerCase().includes('second') || section.name.toLowerCase().includes('meat') ? '🍽️'
                      : section.name.toLowerCase().includes('dessert') ? '🍮'
                      : section.name.toLowerCase().includes('drink') || section.name.toLowerCase().includes('beverage') || section.name.toLowerCase().includes('cocktail') || section.name.toLowerCase().includes('beer') || section.name.toLowerCase().includes('sake') ? '🥂'
                      : section.name.toLowerCase().includes('pasta') || section.name.toLowerCase().includes('noodle') ? '🍝'
                      : section.name.toLowerCase().includes('soup') ? '🍜'
                      : section.name.toLowerCase().includes('bread') || section.name.toLowerCase().includes('rice') ? '🍚'
                      : '🍴'}
                  </span>
                  <span style={{ fontSize: '16px', fontWeight: 700, color: isOpen ? 'var(--color-brand)' : 'var(--color-text)' }}>
                    {section.name}
                  </span>
                  <span style={{
                    fontSize: '11px', fontWeight: 600, padding: '2px 8px', borderRadius: '10px',
                    background: isOpen ? 'rgba(133,41,205,0.12)' : 'var(--color-border)',
                    color: isOpen ? 'var(--color-brand)' : 'var(--color-text-muted)',
                  }}>
                    {section.items.length} items
                  </span>
                </div>
                <svg
                  width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"
                  style={{
                    color: isOpen ? 'var(--color-brand)' : 'var(--color-text-muted)',
                    transform: isOpen ? 'rotate(180deg)' : 'none',
                    transition: 'transform 200ms ease',
                    flexShrink: 0,
                  }}
                  aria-hidden="true"
                >
                  <path d="m6 9 6 6 6-6"/>
                </svg>
              </button>

              {/* Items */}
              {isOpen && (
                <div>
                  {section.items.map((item, idx) => (
                    <div key={item.id} style={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
                      gap: '16px', padding: '14px 20px',
                      borderTop: '1px solid var(--color-border)',
                      background: idx % 2 === 0 ? '#fff' : '#FDFCFF',
                      transition: 'background 80ms',
                    }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-brand-light)')}
                      onMouseLeave={e => (e.currentTarget.style.background = idx % 2 === 0 ? '#fff' : '#FDFCFF')}
                    >
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: '15px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '3px' }}>
                          {item.name}
                        </div>
                        {item.description && (
                          <div style={{ fontSize: '13px', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                            {item.description}
                          </div>
                        )}
                      </div>
                      {item.price > 0 && (
                        <div style={{
                          fontSize: '15px', fontWeight: 700, flexShrink: 0,
                          color: 'var(--color-brand)',
                          background: 'var(--color-brand-light)',
                          padding: '4px 10px', borderRadius: '8px',
                          minWidth: '52px', textAlign: 'center',
                        }}>
                          ${item.price}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
