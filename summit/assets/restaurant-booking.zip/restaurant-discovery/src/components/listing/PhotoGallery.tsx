import { useState, useEffect, useCallback } from 'react'
import type { Photo } from '../../types'

interface Props {
  photos: Photo[]
}

export function PhotoGallery({ photos }: Props) {
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null)

  const closeLightbox = useCallback(() => setLightboxIdx(null), [])

  const prev = useCallback(() => {
    setLightboxIdx(i => i !== null ? (i - 1 + photos.length) % photos.length : null)
  }, [photos.length])

  const next = useCallback(() => {
    setLightboxIdx(i => i !== null ? (i + 1) % photos.length : null)
  }, [photos.length])

  useEffect(() => {
    if (lightboxIdx === null) return
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') closeLightbox()
      else if (e.key === 'ArrowLeft') prev()
      else if (e.key === 'ArrowRight') next()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [lightboxIdx, closeLightbox, prev, next])

  return (
    <>
      {/* Horizontal scroll gallery */}
      <div
        className="flex gap-3 overflow-x-auto pb-2 rounded-lg"
        style={{ scrollSnapType: 'x mandatory', scrollPaddingLeft: '0px' }}
        role="list"
        aria-label="Restaurant photos"
      >
        {photos.map((photo, idx) => (
          <button
            key={photo.id}
            className="flex-shrink-0 rounded-lg overflow-hidden focus:outline-none"
            style={{
              width: '260px',
              height: '185px',
              scrollSnapAlign: 'start',
              backgroundImage: `url(${photo.url})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundColor: 'var(--color-surface-raised)',
              transition: 'opacity 120ms ease',
            }}
            onClick={() => setLightboxIdx(idx)}
            role="listitem"
            aria-label={photo.alt}
            onMouseEnter={e => (e.currentTarget.style.opacity = '0.85')}
            onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
          />
        ))}
      </div>

      {/* Lightbox */}
      {lightboxIdx !== null && (
        <div
          className="fixed inset-0 z-50 flex flex-col items-center justify-center"
          style={{ background: 'rgba(0,0,0,0.92)' }}
          role="dialog"
          aria-modal="true"
          aria-label="Photo viewer"
        >
          <button
            className="absolute top-5 right-6 flex items-center justify-center rounded-full text-white text-2xl"
            style={{ width: '44px', height: '44px', background: 'rgba(255,255,255,0.15)' }}
            onClick={closeLightbox}
            aria-label="Close photo viewer"
          >
            ✕
          </button>

          <div
            style={{
              width: 'min(700px, 90vw)',
              height: 'min(500px, 80vh)',
              backgroundImage: `url(${photos[lightboxIdx].url})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              borderRadius: '8px',
              backgroundColor: 'var(--color-dark-indigo)',
            }}
            role="img"
            aria-label={photos[lightboxIdx].alt}
          />

          <div className="flex items-center gap-6 mt-4">
            <button
              onClick={prev}
              className="text-white text-2xl px-4 py-2"
              aria-label="Previous photo"
            >
              ←
            </button>
            <span className="text-sm" style={{ color: 'rgba(255,255,255,0.7)' }}>
              {lightboxIdx + 1} / {photos.length}
            </span>
            <button
              onClick={next}
              className="text-white text-2xl px-4 py-2"
              aria-label="Next photo"
            >
              →
            </button>
          </div>
        </div>
      )}
    </>
  )
}
