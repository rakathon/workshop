import { useState } from 'react'
import { filterRecentReviews, computeRecentAverageRating, sortReviewsByDate } from '../../lib/reviewUtils'
import type { Review } from '../../types'

interface Props {
  reviews: Review[]
  restaurantId: string
}

function timeAgo(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime()
  const days = Math.floor(ms / (1000 * 60 * 60 * 24))
  if (days === 0) return 'Today'
  if (days < 30) return `${days}d ago`
  const months = Math.floor(days / 30)
  if (months < 12) return `${months}mo ago`
  return `${Math.floor(months / 12)}y ago`
}

function StarDisplay({ rating, size = 16 }: { rating: number; size?: number }) {
  return (
    <span aria-label={`${rating} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map(n => (
        <span key={n} style={{ fontSize: `${size}px`, color: n <= rating ? '#EE6B00' : '#e0d6f5' }}>★</span>
      ))}
    </span>
  )
}

function RatingBar({ label, value, max = 5 }: { label: string; value: number; max?: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
      <span style={{ fontSize: '12px', color: 'var(--color-text-muted)', width: '48px', flexShrink: 0 }}>{label}</span>
      <div style={{ flex: 1, height: '6px', borderRadius: '3px', background: '#e8e3f5', overflow: 'hidden' }}>
        <div style={{
          height: '100%', borderRadius: '3px',
          background: 'linear-gradient(90deg, var(--color-brand), #a855f7)',
          width: `${(value / max) * 100}%`,
          transition: 'width 600ms ease',
        }} />
      </div>
      <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--color-text)', width: '24px', flexShrink: 0 }}>{value.toFixed(1)}</span>
    </div>
  )
}

const AVATAR_COLORS = [
  ['#ede9fd', 'var(--color-brand)'],
  ['#e8f5e9', '#2e7d32'],
  ['#fff3e0', '#e65100'],
  ['#fce4ec', '#c62828'],
  ['#e3f2fd', '#1565c0'],
]

export function ReviewSection({ reviews, restaurantId }: Props) {
  const [showOlder, setShowOlder] = useState(false)
  const [formOpen, setFormOpen] = useState(false)
  const [selectedRating, setSelectedRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [reviewText, setReviewText] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const recentReviews = sortReviewsByDate(filterRecentReviews(reviews))
  const olderReviews = reviews.filter(r => !recentReviews.find(rr => rr.id === r.id))
  const displayReviews = showOlder ? sortReviewsByDate(reviews) : recentReviews
  const avg = computeRecentAverageRating(reviews)

  function handleSubmit() {
    if (!selectedRating || !reviewText.trim()) return
    setSubmitted(true)
    setFormOpen(false)
  }

  return (
    <div>
      {/* ── Rating summary ─────────────────────────────────── */}
      <div style={{
        display: 'grid', gridTemplateColumns: '140px 1fr',
        gap: '24px', padding: '24px',
        background: 'linear-gradient(135deg, #faf9ff 0%, var(--color-brand-light) 100%)',
        borderRadius: '16px', marginBottom: '24px',
        border: '1px solid rgba(133,41,205,0.12)',
      }}>
        {/* Big number */}
        <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{
            fontSize: '64px', fontWeight: 800, lineHeight: 1,
            color: 'var(--color-brand)', letterSpacing: '-0.04em',
            marginBottom: '6px',
          }}>
            {avg.toFixed(1)}
          </div>
          <StarDisplay rating={Math.round(avg)} size={20} />
          <div style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginTop: '6px' }}>
            {recentReviews.length} recent review{recentReviews.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Breakdown bars */}
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          {[5, 4, 3, 2, 1].map(star => {
            const count = recentReviews.filter(r => Math.round(r.rating) === star).length
            const pct = recentReviews.length ? (count / recentReviews.length) * 5 : 0
            return <RatingBar key={star} label={`${star} ★`} value={pct} />
          })}
        </div>
      </div>

      {/* ── Review cards ───────────────────────────────────── */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginBottom: '20px' }}>
        {displayReviews.map((r, idx) => {
          const [bg, color] = AVATAR_COLORS[idx % AVATAR_COLORS.length]
          return (
            <div key={r.id} style={{
              background: '#fff', borderRadius: '16px',
              border: '1px solid var(--color-border)',
              padding: '20px',
              boxShadow: '0 1px 4px rgba(133,41,205,0.05)',
              transition: 'box-shadow 140ms',
            }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 4px 16px rgba(133,41,205,0.10)')}
              onMouseLeave={e => (e.currentTarget.style.boxShadow = '0 1px 4px rgba(133,41,205,0.05)')}
            >
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  {/* Avatar */}
                  <div style={{
                    width: '42px', height: '42px', borderRadius: '50%',
                    background: bg, color, fontWeight: 700, fontSize: '16px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0, border: `2px solid ${color}20`,
                  }} aria-hidden="true">
                    {r.userName.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--color-text)' }}>{r.userName}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '2px' }}>
                      <StarDisplay rating={r.rating} size={13} />
                    </div>
                  </div>
                </div>
                <span style={{
                  fontSize: '11px', color: 'var(--color-text-muted)',
                  background: '#F4F3FE', padding: '3px 10px', borderRadius: '8px', fontWeight: 500,
                }}>
                  {timeAgo(r.reviewedAt)}
                </span>
              </div>

              {/* Review text */}
              <p style={{
                fontSize: '14px', color: 'var(--color-text-secondary)',
                lineHeight: 1.7, margin: 0,
              }}>
                "{r.text}"
              </p>
            </div>
          )
        })}
      </div>

      {/* Show older */}
      {!showOlder && olderReviews.length > 0 && (
        <button onClick={() => setShowOlder(true)} style={{
          width: '100%', padding: '12px', borderRadius: '12px',
          border: '1.5px dashed var(--color-border)',
          background: 'transparent', cursor: 'pointer',
          fontSize: '13px', fontWeight: 600, color: 'var(--color-text-muted)',
          marginBottom: '24px', transition: 'all 120ms',
        }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--color-brand)'; e.currentTarget.style.color = 'var(--color-brand)' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--color-border)'; e.currentTarget.style.color = 'var(--color-text-muted)' }}
        >
          Show {olderReviews.length} older review{olderReviews.length !== 1 ? 's' : ''} ↓
        </button>
      )}

      {/* ── Write a review ─────────────────────────────────── */}
      {!submitted ? (
        <div style={{
          borderRadius: '16px', overflow: 'hidden',
          border: '1.5px solid var(--color-border)',
          boxShadow: 'var(--shadow-sm)',
        }}>
          <button
            onClick={() => setFormOpen(o => !o)}
            aria-expanded={formOpen}
            style={{
              width: '100%', padding: '16px 20px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              background: formOpen ? 'var(--color-brand-light)' : '#fff',
              border: 'none', cursor: 'pointer',
              borderBottom: formOpen ? '1px solid rgba(133,41,205,0.15)' : 'none',
              transition: 'background 140ms',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ fontSize: '20px' }}>✏️</span>
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--color-brand)' }}>Write a review</div>
                <div style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>Share your experience</div>
              </div>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--color-brand)" strokeWidth="2.5"
              style={{ transform: formOpen ? 'rotate(180deg)' : 'none', transition: 'transform 200ms' }} aria-hidden="true">
              <path d="m6 9 6 6 6-6"/>
            </svg>
          </button>

          {formOpen && (
            <div style={{ padding: '24px', background: '#fff' }}>
              {/* Star selector */}
              <div style={{ marginBottom: '20px' }}>
                <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-text-muted)', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Your rating
                </div>
                <div role="group" aria-label="Rate this restaurant" style={{ display: 'flex', gap: '4px' }}>
                  {[1, 2, 3, 4, 5].map(n => (
                    <button
                      key={n}
                      onClick={() => setSelectedRating(n)}
                      onMouseEnter={() => setHoveredRating(n)}
                      onMouseLeave={() => setHoveredRating(0)}
                      aria-label={`${n} star${n !== 1 ? 's' : ''}`}
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        fontSize: '36px', lineHeight: 1, padding: '0 2px',
                        color: n <= (hoveredRating || selectedRating) ? '#EE6B00' : '#e0d6f5',
                        transform: n <= (hoveredRating || selectedRating) ? 'scale(1.15)' : 'scale(1)',
                        transition: 'all 80ms',
                      }}
                    >
                      ★
                    </button>
                  ))}
                </div>
                {selectedRating > 0 && (
                  <div style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginTop: '6px' }}>
                    {['', 'Poor', 'Fair', 'Good', 'Very good', 'Excellent'][selectedRating]}
                  </div>
                )}
              </div>

              {/* Text input */}
              <div style={{ marginBottom: '20px' }}>
                <label htmlFor={`review-text-${restaurantId}`} style={{
                  display: 'block', fontSize: '13px', fontWeight: 600,
                  color: 'var(--color-text-muted)', marginBottom: '8px',
                  textTransform: 'uppercase', letterSpacing: '0.06em',
                }}>
                  Your experience
                </label>
                <textarea
                  id={`review-text-${restaurantId}`}
                  value={reviewText}
                  onChange={e => setReviewText(e.target.value)}
                  placeholder="What did you love? What could be better? Would you recommend it?"
                  aria-required="true"
                  style={{
                    width: '100%', minHeight: '100px', padding: '14px 16px',
                    borderRadius: '12px', border: '1.5px solid var(--color-border)',
                    fontSize: '14px', lineHeight: 1.6, resize: 'vertical',
                    color: 'var(--color-text)', fontFamily: 'var(--font-body)',
                    outline: 'none', transition: 'border-color 120ms',
                    boxSizing: 'border-box',
                  }}
                  onFocus={e => (e.target.style.borderColor = 'var(--color-brand)')}
                  onBlur={e => (e.target.style.borderColor = 'var(--color-border)')}
                />
              </div>

              <button
                onClick={handleSubmit}
                disabled={!selectedRating || !reviewText.trim()}
                style={{
                  padding: '13px 28px', borderRadius: '12px',
                  background: selectedRating && reviewText.trim()
                    ? 'linear-gradient(135deg, var(--color-brand) 0%, #6b15b0 100%)'
                    : 'var(--color-border)',
                  color: selectedRating && reviewText.trim() ? '#fff' : 'var(--color-text-muted)',
                  border: 'none', cursor: selectedRating && reviewText.trim() ? 'pointer' : 'not-allowed',
                  fontSize: '15px', fontWeight: 700,
                  transition: 'all 120ms',
                }}
              >
                Submit review
              </button>
            </div>
          )}
        </div>
      ) : (
        <div style={{
          padding: '20px 24px', borderRadius: '16px',
          background: 'linear-gradient(135deg, #e8f5e9 0%, #f1f8e9 100%)',
          border: '1px solid #a5d6a7',
          display: 'flex', alignItems: 'center', gap: '12px',
        }} role="alert" aria-live="polite">
          <span style={{ fontSize: '28px' }}>🎉</span>
          <div>
            <div style={{ fontSize: '15px', fontWeight: 700, color: '#2e7d32' }}>Review submitted!</div>
            <div style={{ fontSize: '13px', color: '#388e3c', marginTop: '2px' }}>Thank you for sharing your experience.</div>
          </div>
        </div>
      )}
    </div>
  )
}
