import { AddToCartButton } from '../ui/AddToCartButton'
import type { StoredCart } from '../../lib/storage/types'

interface Props {
  cart: StoredCart | null
  restaurantName: string
  cashbackRate: number
  onClose: () => void
  onCheckout: () => void
  onQuantityChange: (menuItemId: string, newQty: number) => void
  onBrowse?: () => void
}

function fmt(n: number) {
  return n.toFixed(2)
}

export function CartPanel({ cart, restaurantName, cashbackRate, onClose, onCheckout, onQuantityChange, onBrowse }: Props) {
  const items = cart?.items ?? []
  const subtotal = items.reduce((s, i) => s + i.unit_price * i.quantity, 0)
  const cashbackAmount = Math.round(subtotal * cashbackRate) / 100
  const isEmpty = items.length === 0

  return (
    <div
      role="dialog"
      aria-label="Your cart"
      aria-modal="true"
      style={{
        position: 'fixed', top: 0, right: 0, bottom: 0,
        width: '360px', maxWidth: '100vw',
        background: '#fff',
        boxShadow: '-4px 0 32px rgba(0,0,0,0.14)',
        zIndex: 300,
        display: 'flex', flexDirection: 'column',
        borderLeft: '1px solid var(--color-border)',
      }}
    >
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 20px',
        borderBottom: '1px solid var(--color-border)',
        flexShrink: 0,
      }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: '17px', color: 'var(--color-text)' }}>Your Cart</div>
          {restaurantName && (
            <div style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginTop: '2px' }}>{restaurantName}</div>
          )}
        </div>
        <button
          onClick={onClose}
          aria-label="Close cart"
          style={{
            width: '32px', height: '32px',
            border: '1px solid var(--color-border)',
            borderRadius: '50%',
            background: '#fff',
            cursor: 'pointer',
            fontSize: '18px', color: 'var(--color-text-secondary)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'border-color 120ms',
          }}
        >
          ✕
        </button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>
        {isEmpty ? (
          <div style={{ textAlign: 'center', padding: '48px 16px' }}>
            <div style={{ fontSize: '40px', marginBottom: '12px' }}>🛒</div>
            <div style={{ fontWeight: 700, fontSize: '16px', marginBottom: '6px' }}>Your cart is empty</div>
            <div style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginBottom: '20px' }}>
              Head back to find something delicious.
            </div>
            <button
              onClick={() => { onClose(); onBrowse?.() }}
              style={{
                padding: '10px 20px',
                background: 'var(--color-brand-light)',
                color: 'var(--color-brand)',
                border: '1px solid var(--color-brand)',
                borderRadius: '10px',
                fontSize: '14px', fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Browse restaurants
            </button>
          </div>
        ) : (
          <>
            {/* Items */}
            {items.map(item => (
              <div
                key={item.menu_item_id}
                style={{
                  display: 'flex', alignItems: 'center', gap: '12px',
                  padding: '12px 0',
                  borderBottom: '1px solid var(--color-border)',
                }}
              >
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--color-text)' }}>
                    {item.name}
                  </div>
                  <div style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
                    ${fmt(item.unit_price)} each
                  </div>
                </div>
                <AddToCartButton
                  quantity={item.quantity}
                  onAdd={() => onQuantityChange(item.menu_item_id, item.quantity + 1)}
                  onChange={(q) => onQuantityChange(item.menu_item_id, q)}
                  itemName={item.name}
                />
                <div style={{ minWidth: '52px', textAlign: 'right', fontWeight: 700, fontSize: '14px' }}>
                  ${fmt(item.unit_price * item.quantity)}
                </div>
              </div>
            ))}

            {/* Subtotal */}
            <div style={{
              display: 'flex', justifyContent: 'space-between',
              padding: '12px 0 0',
              fontSize: '15px',
            }}>
              <span style={{ color: 'var(--color-text-secondary)' }}>Subtotal</span>
              <span style={{ fontWeight: 700 }}>${fmt(subtotal)}</span>
            </div>

            {/* Cashback preview */}
            {cashbackRate > 0 && subtotal > 0 && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: '10px',
                background: 'var(--color-cashback-bg)',
                border: '1px solid var(--color-cashback-border)',
                borderRadius: '10px',
                padding: '10px 14px',
                marginTop: '12px',
              }}>
                <span style={{ fontSize: '18px' }}>🎁</span>
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--color-cashback)' }}>
                    You'll save ${fmt(cashbackAmount)} with {cashbackRate}% cashback
                  </div>
                  <div style={{ fontSize: '11px', color: 'var(--color-cashback)', opacity: 0.8 }}>
                    Applied automatically at checkout
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Footer */}
      <div style={{
        padding: '16px 20px',
        borderTop: '1px solid var(--color-border)',
        flexShrink: 0,
        display: 'flex', flexDirection: 'column', gap: '8px',
      }}>
        <button
          onClick={isEmpty ? undefined : onCheckout}
          aria-disabled={isEmpty ? 'true' : 'false'}
          role="button"
          aria-label="Go to checkout"
          style={{
            width: '100%',
            padding: '14px',
            background: isEmpty ? 'var(--color-border)' : 'var(--color-brand)',
            color: isEmpty ? 'var(--color-text-muted)' : '#fff',
            border: 'none',
            borderRadius: '12px',
            fontSize: '15px', fontWeight: 700,
            cursor: isEmpty ? 'not-allowed' : 'pointer',
            transition: 'background 120ms',
          }}
          onMouseEnter={e => { if (!isEmpty) e.currentTarget.style.background = 'var(--color-brand-hover)' }}
          onMouseLeave={e => { if (!isEmpty) e.currentTarget.style.background = 'var(--color-brand)' }}
        >
          {isEmpty ? 'Go to Checkout' : `Go to Checkout · $${fmt(subtotal)}`}
        </button>
        <button
          onClick={onClose}
          style={{
            background: 'none', border: 'none',
            fontSize: '13px', color: 'var(--color-text-muted)',
            cursor: 'pointer', textAlign: 'center',
          }}
        >
          ← Continue browsing
        </button>
      </div>
    </div>
  )
}
