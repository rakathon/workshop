import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import type { StoredOrder, OrderStatus } from '../../lib/storage/types'

const STEPS: { status: OrderStatus; label: string; emoji: string }[] = [
  { status: 'received',         label: 'Order Received',   emoji: '📋' },
  { status: 'preparing',        label: 'Preparing',         emoji: '👨‍🍳' },
  { status: 'out_for_delivery', label: 'Out for Delivery',  emoji: '🛵' },
  { status: 'delivered',        label: 'Delivered',         emoji: '✓' },
]

const STATUS_ORDER: OrderStatus[] = ['received', 'preparing', 'out_for_delivery', 'delivered']

interface Props {
  order: StoredOrder
  /** Interval between status advances in ms. Default 90000 (90s). Use small values in tests. */
  tickMs?: number
  /** Called each time the status advances — caller is responsible for persisting to localStorage. */
  onStatusChange?: (status: OrderStatus) => void
}

export function TrackingScreen({ order, tickMs = 90_000, onStatusChange }: Props) {
  const [currentStatus, setCurrentStatus] = useState<OrderStatus>(order.status)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const cancelledRef = useRef(false)

  useEffect(() => {
    cancelledRef.current = false
    if (timerRef.current) clearTimeout(timerRef.current)
    if (currentStatus === 'delivered') return

    timerRef.current = setTimeout(() => {
      if (cancelledRef.current) return
      const idx = STATUS_ORDER.indexOf(currentStatus)
      if (idx < STATUS_ORDER.length - 1) {
        const next = STATUS_ORDER[idx + 1]
        setCurrentStatus(next)
        onStatusChange?.(next)
      }
    }, tickMs)

    return () => {
      cancelledRef.current = true
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [currentStatus, tickMs, onStatusChange])

  const currentIdx = STATUS_ORDER.indexOf(currentStatus)
  const isDelivered = currentStatus === 'delivered'

  const statusLabels: Record<OrderStatus, string> = {
    received: 'Order received',
    preparing: 'Preparing your order',
    out_for_delivery: 'Out for delivery!',
    delivered: 'Your order has arrived!',
  }

  return (
    <div style={{ padding: '24px', maxWidth: '480px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginBottom: '6px' }}>
          {order.restaurant_name}
        </p>
        <h1 style={{
          fontSize: '24px', fontWeight: 800, letterSpacing: '-0.03em',
          color: isDelivered ? 'var(--color-success)' : 'var(--color-text)',
          marginBottom: '6px',
        }}>
          {statusLabels[currentStatus]}
        </h1>
        {!isDelivered && (
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)' }}>
            Estimated arrival: <strong>~{order.estimated_delivery_minutes} min</strong>
          </p>
        )}
      </div>

      {/* Stepper */}
      <div
        role="list"
        aria-label="Order status steps"
        style={{ marginBottom: '28px' }}
      >
        {STEPS.map((step, i) => {
          const done = i < currentIdx
          const active = i === currentIdx
          const future = i > currentIdx

          return (
            <div key={step.status} role="listitem">
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '14px' }}>
                {/* Dot + line column */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                  <div
                    aria-current={active ? 'step' : undefined}
                    style={{
                      width: '32px', height: '32px',
                      borderRadius: '9999px',
                      background: done ? 'var(--color-success)' : active ? 'var(--color-brand)' : '#fff',
                      border: `2px solid ${done ? 'var(--color-success)' : active ? 'var(--color-brand)' : 'var(--color-border)'}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: done ? '14px' : '16px',
                      color: done || active ? '#fff' : 'var(--color-text-muted)',
                      flexShrink: 0,
                      animation: active ? 'dot-pulse 1.5s ease-in-out infinite' : 'none',
                    }}
                  >
                    {done ? '✓' : step.emoji}
                  </div>
                  {i < STEPS.length - 1 && (
                    <div style={{
                      width: '2px', height: '32px',
                      background: done ? 'var(--color-success)' : 'var(--color-border)',
                      margin: '2px 0',
                      transition: 'background 400ms',
                    }} />
                  )}
                </div>

                {/* Label */}
                <div style={{ paddingTop: '4px', paddingBottom: i < STEPS.length - 1 ? '28px' : '0' }}>
                  <div style={{
                    fontSize: '15px',
                    fontWeight: active ? 700 : done ? 600 : 400,
                    color: future ? 'var(--color-text-muted)' : 'var(--color-text)',
                  }}>
                    {step.label}
                  </div>
                  {active && !isDelivered && (
                    <div style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
                      In progress…
                    </div>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Delivered celebration */}
      {isDelivered && (
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{ fontSize: '48px', marginBottom: '8px' }}>🎉</div>
          <p style={{ fontSize: '16px', fontWeight: 700, color: 'var(--color-success)', marginBottom: '4px' }}>
            Your order has arrived!
          </p>
          <p style={{ fontSize: '14px', color: 'var(--color-text-muted)' }}>Enjoy your meal 😊</p>
        </div>
      )}

      {/* Divider */}
      <div style={{ height: '1px', background: 'var(--color-border)', marginBottom: '16px' }} />

      {/* Order detail toggle */}
      <details style={{ marginBottom: '24px' }}>
        <summary style={{
          fontSize: '14px', fontWeight: 600, cursor: 'pointer',
          color: 'var(--color-brand)', padding: '8px 0', listStyle: 'none',
        }}>
          View order details ▾
        </summary>
        <div style={{ paddingTop: '12px' }}>
          {order.items.map(item => (
            <div key={item.menu_item_id} style={{
              display: 'flex', justifyContent: 'space-between',
              fontSize: '14px', padding: '4px 0', color: 'var(--color-text-secondary)',
            }}>
              <span>{item.name} × {item.quantity}</span>
              <span>${item.line_total.toFixed(2)}</span>
            </div>
          ))}
          <div style={{ height: '1px', background: 'var(--color-border)', margin: '8px 0' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: 700 }}>
            <span>Total</span>
            <span>${order.total_charged.toFixed(2)}</span>
          </div>
        </div>
      </details>

      {/* CTAs */}
      {isDelivered && (
        <Link
          to={`/restaurant/${order.restaurant_id}`}
          style={{
            display: 'block', textAlign: 'center',
            padding: '14px', borderRadius: '12px',
            background: 'var(--color-brand)', color: '#fff',
            textDecoration: 'none', fontSize: '15px', fontWeight: 700,
            marginBottom: '10px',
          }}
        >
          Order again
        </Link>
      )}
      <Link
        to="/"
        style={{
          display: 'block', textAlign: 'center',
          fontSize: '13px', color: 'var(--color-text-muted)',
          textDecoration: 'none', padding: '8px',
        }}
      >
        Back to home
      </Link>

      <style>{`
        @keyframes dot-pulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(133,41,205,0.4); }
          50%       { box-shadow: 0 0 0 6px rgba(133,41,205,0); }
        }
        @media (prefers-reduced-motion: reduce) {
          * { animation: none !important; transition: none !important; }
        }
      `}</style>
    </div>
  )
}
