import { Link } from 'react-router-dom'
import type { StoredOrder } from '../../lib/storage/types'

interface Props {
  orders: StoredOrder[]
  onReorder: (order: StoredOrder) => void
}

function fmt(n: number) { return n.toFixed(2) }

function formatDate(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const diffDays = Math.floor((now.getTime() - d.getTime()) / 86_400_000)
  if (diffDays === 0) return 'Today'
  if (diffDays === 1) return 'Yesterday'
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

export function OrderHistory({ orders, onReorder }: Props) {
  if (orders.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '64px 24px' }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>📋</div>
        <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '8px' }}>No orders yet.</h2>
        <p style={{ fontSize: '14px', color: 'var(--color-text-muted)', marginBottom: '24px' }}>
          Start browsing restaurants and place your first order.
        </p>
        <Link
          to="/"
          style={{
            display: 'inline-block', padding: '12px 28px',
            background: 'var(--color-brand)', color: '#fff',
            borderRadius: '12px', textDecoration: 'none',
            fontSize: '15px', fontWeight: 700,
          }}
        >
          Browse restaurants
        </Link>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {orders.map(order => (
        <div
          key={order.id}
          style={{
            background: '#fff',
            border: '1px solid var(--color-border)',
            borderRadius: '14px',
            padding: '16px',
            boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
          }}
        >
          {/* Header row */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--color-text)', margin: 0 }}>
              {order.restaurant_name}
            </h3>
            <span style={{ fontSize: '12px', color: 'var(--color-text-muted)', flexShrink: 0, marginLeft: '8px' }}>
              {formatDate(order.created_at)}
            </span>
          </div>

          {/* Items */}
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', marginBottom: '10px', lineHeight: 1.5 }}>
            {order.items.map(i => `${i.name} × ${i.quantity}`).join(', ')}
          </p>

          {/* Footer row */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <span style={{ fontSize: '15px', fontWeight: 700, color: 'var(--color-text)' }}>
                ${fmt(order.total_charged)}
              </span>
              {order.cashback_amount > 0 && (
                <span
                  data-testid="order-cashback"
                  style={{
                    fontSize: '13px', fontWeight: 600,
                    color: 'var(--color-cashback)',
                    marginLeft: '10px',
                  }}
                >
                  🎁 saved ${fmt(order.cashback_amount)}
                </span>
              )}
            </div>

            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <Link
                to={`/tracking/${order.id}`}
                style={{
                  fontSize: '12px', color: 'var(--color-text-muted)',
                  textDecoration: 'underline',
                }}
              >
                Track
              </Link>
              <button
                onClick={() => onReorder(order)}
                aria-label="Re-order"
                style={{
                  padding: '8px 16px',
                  background: 'var(--color-brand)', color: '#fff',
                  border: 'none', borderRadius: '8px',
                  fontSize: '13px', fontWeight: 700, cursor: 'pointer',
                  transition: 'background 120ms',
                  minHeight: '36px',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-brand-hover)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'var(--color-brand)')}
              >
                Re-order
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
