import { Link } from 'react-router-dom'
import type { StoredOrder } from '../../lib/storage/types'

interface Props {
  order: StoredOrder
}

function fmt(n: number) { return n.toFixed(2) }

export function OrderConfirmation({ order }: Props) {
  return (
    <div style={{ padding: '32px 24px', textAlign: 'center' }}>
      {/* Success icon */}
      <div style={{
        width: '72px', height: '72px',
        background: 'var(--color-success-light)',
        borderRadius: '9999px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: '32px', margin: '0 auto 16px',
      }} role="img" aria-label="Order confirmed">
        ✓
      </div>

      <h1 style={{ fontSize: '26px', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: '6px' }}>
        Order placed!
      </h1>
      <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginBottom: '28px' }}>
        Order #{order.id}
      </p>

      {/* Order items */}
      <div style={{
        background: 'var(--color-surface-raised)', borderRadius: '14px',
        padding: '16px', marginBottom: '16px', textAlign: 'left',
      }}>
        <div style={{ fontSize: '12px', fontWeight: 700, textTransform: 'uppercase',
          letterSpacing: '0.06em', color: 'var(--color-text-secondary)', marginBottom: '12px' }}>
          {order.restaurant_name}
        </div>
        {order.items.map(item => (
          <div key={item.menu_item_id} style={{
            display: 'flex', justifyContent: 'space-between',
            fontSize: '14px', padding: '4px 0',
          }}>
            <span style={{ color: 'var(--color-text)' }}>{item.name} × {item.quantity}</span>
            <span style={{ fontWeight: 600 }}>${fmt(item.line_total)}</span>
          </div>
        ))}

        <div style={{ height: '1px', background: 'var(--color-border)', margin: '12px 0' }} />

        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '15px', fontWeight: 700 }}>
          <span>Total paid</span>
          <span>${fmt(order.total_charged)}</span>
        </div>

        {order.cashback_amount > 0 && (
          <div
            data-testid="cashback-saved"
            style={{
              display: 'flex', justifyContent: 'space-between',
              fontSize: '14px', fontWeight: 600, marginTop: '6px',
              color: 'var(--color-cashback)',
            }}
          >
            <span>🎁 Cashback saved</span>
            <span>${fmt(order.cashback_amount)}</span>
          </div>
        )}
      </div>

      {/* Delivery info */}
      <div style={{
        background: 'var(--color-surface-raised)', borderRadius: '14px',
        padding: '14px 16px', marginBottom: '28px', textAlign: 'left',
      }}>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '8px', fontSize: '14px' }}>
          <span>📍</span>
          <span style={{ color: 'var(--color-text-secondary)' }}>{order.delivery_address}</span>
        </div>
        <div style={{ display: 'flex', gap: '10px', fontSize: '14px' }}>
          <span>⏱</span>
          <span style={{ color: 'var(--color-text-secondary)' }}>
            Estimated arrival: <strong style={{ color: 'var(--color-text)' }}>~{order.estimated_delivery_minutes} min</strong>
          </span>
        </div>
      </div>

      {/* Track CTA */}
      <Link
        to={`/tracking/${order.id}`}
        aria-label="Track my order"
        style={{
          display: 'block', width: '100%', padding: '14px',
          background: 'var(--color-brand)', color: '#fff',
          borderRadius: '12px', textDecoration: 'none',
          fontSize: '15px', fontWeight: 700, marginBottom: '10px',
          transition: 'background 120ms',
        }}
      >
        Track my order →
      </Link>

      <Link
        to="/"
        style={{
          display: 'block', textAlign: 'center',
          fontSize: '13px', color: 'var(--color-text-muted)',
          textDecoration: 'none', padding: '8px',
        }}
      >
        Back to home
      </Link>
    </div>
  )
}
