import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { PaymentStep } from '../checkout/PaymentStep'

describe('PaymentStep', () => {
  it('disablesPlaceOrder_whenFieldsEmpty', () => {
    render(<PaymentStep total={42.52} onPlace={vi.fn()} onBack={vi.fn()} />)
    const btn = screen.getByRole('button', { name: /place order/i })
    expect(btn.getAttribute('aria-disabled')).toBe('true')
  })

  it('enablesPlaceOrder_whenAllFieldsFilled', () => {
    render(<PaymentStep total={42.52} onPlace={vi.fn()} onBack={vi.fn()} />)
    fireEvent.change(screen.getByLabelText(/card number/i), { target: { value: '4242424242424242' } })
    fireEvent.change(screen.getByLabelText(/expiry/i), { target: { value: '06/28' } })
    fireEvent.change(screen.getByLabelText(/cvv/i), { target: { value: '123' } })
    expect(screen.getByRole('button', { name: /place order/i }).getAttribute('aria-disabled')).toBe('false')
  })

  it('remainsDisabled_whenOnlyPartiallyFilled', () => {
    render(<PaymentStep total={42.52} onPlace={vi.fn()} onBack={vi.fn()} />)
    fireEvent.change(screen.getByLabelText(/card number/i), { target: { value: '4242424242424242' } })
    // expiry and CVV still empty
    expect(screen.getByRole('button', { name: /place order/i }).getAttribute('aria-disabled')).toBe('true')
  })

  it('storesOnlyLastFour_notFullNumber', () => {
    const onPlace = vi.fn()
    render(<PaymentStep total={42.52} onPlace={onPlace} onBack={vi.fn()} />)
    fireEvent.change(screen.getByLabelText(/card number/i), { target: { value: '4242424242424242' } })
    fireEvent.change(screen.getByLabelText(/expiry/i), { target: { value: '06/28' } })
    fireEvent.change(screen.getByLabelText(/cvv/i), { target: { value: '123' } })
    fireEvent.click(screen.getByRole('button', { name: /place order/i }))
    expect(onPlace).toHaveBeenCalledWith('4242')
    // Full PAN must NOT be in the call args
    const callArg = onPlace.mock.calls[0][0] as string
    expect(callArg).not.toBe('4242424242424242')
    expect(callArg.length).toBe(4)
  })

  it('navigatesToConfirmation_onSuccess — calls onPlace with last four', () => {
    const onPlace = vi.fn()
    render(<PaymentStep total={42.52} onPlace={onPlace} onBack={vi.fn()} />)
    fireEvent.change(screen.getByLabelText(/card number/i), { target: { value: '5555555555554444' } })
    fireEvent.change(screen.getByLabelText(/expiry/i), { target: { value: '12/29' } })
    fireEvent.change(screen.getByLabelText(/cvv/i), { target: { value: '321' } })
    fireEvent.click(screen.getByRole('button', { name: /place order/i }))
    expect(onPlace).toHaveBeenCalledWith('4444')
  })

  it('shows total amount prominently', () => {
    render(<PaymentStep total={42.52} onPlace={vi.fn()} onBack={vi.fn()} />)
    expect(screen.getByText(/42\.52/)).toBeTruthy()
  })

  it('shows trust badge', () => {
    render(<PaymentStep total={42.52} onPlace={vi.fn()} onBack={vi.fn()} />)
    expect(screen.getByText(/secure/i)).toBeTruthy()
  })

  it('calls onBack when back button clicked', () => {
    const onBack = vi.fn()
    render(<PaymentStep total={42.52} onPlace={vi.fn()} onBack={onBack} />)
    fireEvent.click(screen.getByRole('button', { name: /back/i }))
    expect(onBack).toHaveBeenCalledTimes(1)
  })
})
