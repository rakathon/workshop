import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, act } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { TrackingScreen } from '../order/TrackingScreen'
import type { StoredOrder } from '../../lib/storage/types'

const BASE_ORDER: StoredOrder = {
  id: 'ORD-001',
  user_id: 'usr-1',
  restaurant_id: 'rest-001',
  restaurant_name: 'Osteria Morini',
  delivery_address: '123 Main St, New York, NY 10001',
  status: 'received',
  status_updated_at: '2026-06-05T18:10:00Z',
  estimated_delivery_minutes: 35,
  items: [
    { menu_item_id: 'mi-001', name: 'Margherita Pizza', unit_price: 14.99, quantity: 2, line_total: 29.98 },
  ],
  subtotal: 29.98,
  delivery_fee: 2.99,
  cashback_rate_pct: 8,
  cashback_amount: 2.40,
  total_charged: 30.57,
  payment: { id: 'pay-1', card_last_four: '4242', status: 'mock_success', paid_at: '2026-06-05T18:10:00Z' },
  created_at: '2026-06-05T18:10:00Z',
}

const onStatusChange = vi.fn()

function Wrap({ children }: { children: React.ReactNode }) {
  return <MemoryRouter>{children}</MemoryRouter>
}

beforeEach(() => {
  vi.useFakeTimers()
  vi.clearAllMocks()
})

afterEach(() => {
  vi.useRealTimers()
})

describe('TrackingScreen', () => {
  it('showsCorrectActiveStep — received is active on mount', () => {
    render(<Wrap><TrackingScreen order={BASE_ORDER} tickMs={500} onStatusChange={onStatusChange} /></Wrap>)
    expect(screen.getAllByText(/order received/i).length).toBeGreaterThan(0)
    // Active step has aria-current="step"
    const activeDot = document.querySelector('[aria-current="step"]')
    expect(activeDot).toBeTruthy()
  })

  it('advancesStatus_onTimer — progresses to preparing after one tick', () => {
    render(<Wrap><TrackingScreen order={BASE_ORDER} tickMs={500} onStatusChange={onStatusChange} /></Wrap>)
    act(() => { vi.advanceTimersByTime(500) })
    expect(onStatusChange).toHaveBeenCalledWith('preparing')
  })

  it('progresses through all four steps', () => {
    render(<Wrap><TrackingScreen order={BASE_ORDER} tickMs={100} onStatusChange={onStatusChange} /></Wrap>)
    act(() => { vi.advanceTimersByTime(100) })
    act(() => { vi.advanceTimersByTime(100) })
    act(() => { vi.advanceTimersByTime(100) })
    expect(onStatusChange).toHaveBeenCalledTimes(3)
    expect(onStatusChange).toHaveBeenNthCalledWith(1, 'preparing')
    expect(onStatusChange).toHaveBeenNthCalledWith(2, 'out_for_delivery')
    expect(onStatusChange).toHaveBeenNthCalledWith(3, 'delivered')
  })

  it('showsDeliveredCelebration_onFinalStep', () => {
    const deliveredOrder = { ...BASE_ORDER, status: 'delivered' as const }
    render(<Wrap><TrackingScreen order={deliveredOrder} tickMs={100} onStatusChange={onStatusChange} /></Wrap>)
    expect(screen.getAllByText(/arrived/i).length).toBeGreaterThan(0)
  })

  it('stopsTimer_whenDelivered — exactly 3 transitions total', () => {
    render(<Wrap><TrackingScreen order={BASE_ORDER} tickMs={100} onStatusChange={onStatusChange} /></Wrap>)
    // Advance one tick at a time to flush React state between each
    act(() => { vi.advanceTimersByTime(100) }) // → preparing
    act(() => { vi.advanceTimersByTime(100) }) // → out_for_delivery
    act(() => { vi.advanceTimersByTime(100) }) // → delivered
    act(() => { vi.advanceTimersByTime(100) }) // no more — should be stopped
    act(() => { vi.advanceTimersByTime(100) }) // still stopped
    // Only 3 transitions
    expect(onStatusChange.mock.calls.length).toBe(3)
    const statuses = onStatusChange.mock.calls.map((c: unknown[]) => c[0])
    expect(statuses[statuses.length - 1]).toBe('delivered')
  })

  it('writesStatusToStorage — calls onStatusChange with each new status', () => {
    render(<Wrap><TrackingScreen order={BASE_ORDER} tickMs={50} onStatusChange={onStatusChange} /></Wrap>)
    act(() => { vi.advanceTimersByTime(50) })
    expect(onStatusChange).toHaveBeenCalledWith('preparing')
  })

  it('shows restaurant name', () => {
    render(<Wrap><TrackingScreen order={BASE_ORDER} tickMs={500} onStatusChange={onStatusChange} /></Wrap>)
    expect(screen.getByText(/Osteria Morini/)).toBeTruthy()
  })

  it('shows all four step labels', () => {
    render(<Wrap><TrackingScreen order={BASE_ORDER} tickMs={500} onStatusChange={onStatusChange} /></Wrap>)
    expect(screen.getByText(/Order Received/)).toBeTruthy()
    expect(screen.getByText(/Preparing/)).toBeTruthy()
    expect(screen.getByText(/Out for Delivery/)).toBeTruthy()
    expect(screen.getByText(/Delivered/)).toBeTruthy()
  })

  it('starts at provided status — not always received', () => {
    const preparingOrder = { ...BASE_ORDER, status: 'preparing' as const }
    render(<Wrap><TrackingScreen order={preparingOrder} tickMs={500} onStatusChange={onStatusChange} /></Wrap>)
    // Should show preparing as current, not advance from received
    act(() => { vi.advanceTimersByTime(500) })
    expect(onStatusChange).toHaveBeenCalledWith('out_for_delivery')
  })
})
