import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { OrderHistory } from '../order/OrderHistory'
import type { StoredOrder } from '../../lib/storage/types'

function makeOrder(overrides: Partial<StoredOrder> = {}): StoredOrder {
  return {
    id: 'ORD-001',
    user_id: 'usr-1',
    restaurant_id: 'rest-001',
    restaurant_name: 'Osteria Morini',
    delivery_address: '123 Main St',
    status: 'delivered',
    status_updated_at: '2026-06-05T18:48:00Z',
    estimated_delivery_minutes: 35,
    items: [
      { menu_item_id: 'mi-001', name: 'Margherita Pizza', unit_price: 14.99, quantity: 2, line_total: 29.98 },
    ],
    subtotal: 29.98,
    delivery_fee: 2.99,
    cashback_rate_pct: 8,
    cashback_amount: 2.40,
    total_charged: 30.57,
    payment: { id: 'pay-1', card_last_four: '4242', status: 'mock_success', paid_at: '2026-06-05T18:10:00Z' },
    created_at: '2026-06-05T18:10:00Z',
    ...overrides,
  }
}

function Wrap({ children }: { children: React.ReactNode }) {
  return <MemoryRouter>{children}</MemoryRouter>
}

describe('OrderHistory', () => {
  it('rendersOrders_mostRecentFirst', () => {
    const orders = [
      makeOrder({ id: 'ORD-001', restaurant_name: 'First Restaurant', created_at: '2026-06-05T18:00:00Z' }),
      makeOrder({ id: 'ORD-002', restaurant_name: 'Second Restaurant', created_at: '2026-06-04T12:00:00Z' }),
    ]
    render(<Wrap><OrderHistory orders={orders} onReorder={vi.fn()} /></Wrap>)
    const names = screen.getAllByRole('heading', { level: 3 })
    expect(names[0].textContent).toContain('First Restaurant')
    expect(names[1].textContent).toContain('Second Restaurant')
  })

  it('showsCashbackSaved_perOrder', () => {
    render(<Wrap><OrderHistory orders={[makeOrder()]} onReorder={vi.fn()} /></Wrap>)
    const cashbackEl = document.querySelector('[data-testid="order-cashback"]')
    expect(cashbackEl).toBeTruthy()
    expect((cashbackEl as HTMLElement).style.color).toBe('var(--color-cashback)')
    expect(cashbackEl?.textContent).toContain('2.40')
  })

  it('showsEmptyState_whenNoOrders', () => {
    render(<Wrap><OrderHistory orders={[]} onReorder={vi.fn()} /></Wrap>)
    expect(screen.getByText(/no orders yet/i)).toBeTruthy()
    expect(screen.getByText(/browse restaurants/i)).toBeTruthy()
  })

  it('isAccessible_fromNavigation — re-order button present per order', () => {
    render(<Wrap><OrderHistory orders={[makeOrder()]} onReorder={vi.fn()} /></Wrap>)
    expect(screen.getByRole('button', { name: /re-order/i })).toBeTruthy()
  })

  it('calls onReorder with the order when re-order clicked', () => {
    const onReorder = vi.fn()
    const order = makeOrder()
    render(<Wrap><OrderHistory orders={[order]} onReorder={onReorder} /></Wrap>)
    fireEvent.click(screen.getByRole('button', { name: /re-order/i }))
    expect(onReorder).toHaveBeenCalledWith(order)
  })

  it('shows restaurant name, date, total and items per entry', () => {
    render(<Wrap><OrderHistory orders={[makeOrder()]} onReorder={vi.fn()} /></Wrap>)
    expect(screen.getByText(/Osteria Morini/)).toBeTruthy()
    expect(screen.getByText(/Margherita Pizza/)).toBeTruthy()
    expect(screen.getByText(/30\.57/)).toBeTruthy()
  })
})
