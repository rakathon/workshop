import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { AddressStep } from '../checkout/AddressStep'

describe('AddressStep', () => {
  it('preventsAdvance_whenFieldsEmpty', () => {
    const onContinue = vi.fn()
    render(<AddressStep onContinue={onContinue} onBack={vi.fn()} />)
    fireEvent.click(screen.getByRole('button', { name: /continue/i }))
    expect(onContinue).not.toHaveBeenCalled()
  })

  it('showsInlineErrors_perField', () => {
    render(<AddressStep onContinue={vi.fn()} onBack={vi.fn()} />)
    fireEvent.click(screen.getByRole('button', { name: /continue/i }))
    expect(screen.getByText(/enter a street address/i)).toBeTruthy()
    expect(screen.getByText(/enter a city/i)).toBeTruthy()
    expect(screen.getByText(/enter a state/i)).toBeTruthy()
    expect(screen.getByText(/enter a zip/i)).toBeTruthy()
  })

  it('advances_whenAllFieldsValid', () => {
    const onContinue = vi.fn()
    render(<AddressStep onContinue={onContinue} onBack={vi.fn()} />)
    fireEvent.change(screen.getByLabelText(/street address/i), { target: { value: '123 Main St' } })
    fireEvent.change(screen.getByLabelText(/city/i), { target: { value: 'New York' } })
    fireEvent.change(screen.getByLabelText(/state/i), { target: { value: 'NY' } })
    fireEvent.change(screen.getByLabelText(/zip/i), { target: { value: '10001' } })
    fireEvent.click(screen.getByRole('button', { name: /continue/i }))
    expect(onContinue).toHaveBeenCalledWith('123 Main St, New York, NY 10001')
  })

  it('clears error when field is filled', () => {
    render(<AddressStep onContinue={vi.fn()} onBack={vi.fn()} />)
    fireEvent.click(screen.getByRole('button', { name: /continue/i }))
    expect(screen.getByText(/enter a street address/i)).toBeTruthy()
    fireEvent.change(screen.getByLabelText(/street address/i), { target: { value: '123 Main St' } })
    expect(screen.queryByText(/enter a street address/i)).toBeNull()
  })

  it('calls onBack when back button clicked', () => {
    const onBack = vi.fn()
    render(<AddressStep onContinue={vi.fn()} onBack={onBack} />)
    fireEvent.click(screen.getByRole('button', { name: /back/i }))
    expect(onBack).toHaveBeenCalledTimes(1)
  })
})
