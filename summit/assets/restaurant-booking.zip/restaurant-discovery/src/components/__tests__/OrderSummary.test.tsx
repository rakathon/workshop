import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { OrderSummary } from '../checkout/OrderSummary'

const BASE_PROPS = {
  items: [
    { menu_item_id: 'mi-001', name: 'Margherita Pizza', unit_price: 14.99, quantity: 2, line_total: 29.98 },
    { menu_item_id: 'mi-002', name: 'Penne Arrabbiata', unit_price: 12.99, quantity: 1, line_total: 12.99 },
  ],
  deliveryFee: 2.99,
  cashbackRatePct: 8,
  deliveryAddress: '123 Main St, New York, NY 10001',
  estimatedMinutes: 35,
  onContinue: () => {},
  onBack: () => {},
}

describe('OrderSummary', () => {
  it('calculatesCashback_correctly', () => {
    render(<OrderSummary {...BASE_PROPS} />)
    // subtotal = 42.97, cashback = 42.97 * 0.08 = 3.4376 → $3.44
    expect(screen.getByText(/3\.44/)).toBeTruthy()
  })

  it('displaysAllLineItems', () => {
    render(<OrderSummary {...BASE_PROPS} />)
    expect(screen.getAllByText(/42\.97/).length).toBeGreaterThan(0) // subtotal
    expect(screen.getAllByText(/2\.99/).length).toBeGreaterThan(0)  // delivery fee
    expect(screen.getAllByText(/3\.44/).length).toBeGreaterThan(0)  // cashback
    expect(screen.getAllByText(/42\.52/).length).toBeGreaterThan(0) // total
  })

  it('cashbackLineUsesGreenToken', () => {
    const { container } = render(<OrderSummary {...BASE_PROPS} />)
    // Find the cashback row and check it uses the cashback color
    const cashbackRow = container.querySelector('[data-testid="cashback-line"]')
    expect(cashbackRow).toBeTruthy()
    expect((cashbackRow as HTMLElement).style.color).toBe('var(--color-cashback)')
  })

  it('shows estimated delivery time', () => {
    render(<OrderSummary {...BASE_PROPS} />)
    expect(screen.getByText(/35/)).toBeTruthy()
  })

  it('shows delivery address', () => {
    render(<OrderSummary {...BASE_PROPS} />)
    expect(screen.getByText(/123 Main St/)).toBeTruthy()
  })

  it('handles zero cashback rate', () => {
    render(<OrderSummary {...BASE_PROPS} cashbackRatePct={0} />)
    // total = subtotal + delivery fee only
    expect(screen.getByText(/45\.96/)).toBeTruthy() // 42.97 + 2.99
  })

  it('rounds cashback to 2 decimal places', () => {
    // subtotal = 33.33, rate = 3 → 0.9999 → rounds to $1.00
    render(
      <OrderSummary
        {...BASE_PROPS}
        items={[{ menu_item_id: 'mi-001', name: 'Item', unit_price: 33.33, quantity: 1, line_total: 33.33 }]}
        cashbackRatePct={3}
      />
    )
    expect(screen.getByText(/1\.00/)).toBeTruthy()
  })
})
