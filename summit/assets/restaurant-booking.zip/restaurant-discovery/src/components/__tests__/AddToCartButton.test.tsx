import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { AddToCartButton } from '../ui/AddToCartButton'

describe('AddToCartButton', () => {
  it('showsStepperAfterFirstTap', () => {
    const onAdd = vi.fn()
    render(<AddToCartButton quantity={0} onAdd={onAdd} onChange={vi.fn()} />)
    const addBtn = screen.getByRole('button', { name: /add/i })
    fireEvent.click(addBtn)
    expect(onAdd).toHaveBeenCalledTimes(1)
  })

  it('renders qty stepper when quantity > 0', () => {
    render(<AddToCartButton quantity={2} onAdd={vi.fn()} onChange={vi.fn()} />)
    expect(screen.getByText('2')).toBeTruthy()
    expect(screen.getByRole('button', { name: /decrease/i })).toBeTruthy()
    expect(screen.getByRole('button', { name: /increase/i })).toBeTruthy()
  })

  it('stepperCollapsesAtZero — calls onChange(0) when decreased from 1', () => {
    const onChange = vi.fn()
    render(<AddToCartButton quantity={1} onAdd={vi.fn()} onChange={onChange} />)
    fireEvent.click(screen.getByRole('button', { name: /decrease/i }))
    expect(onChange).toHaveBeenCalledWith(0)
  })

  it('calls onChange with incremented value', () => {
    const onChange = vi.fn()
    render(<AddToCartButton quantity={2} onAdd={vi.fn()} onChange={onChange} />)
    fireEvent.click(screen.getByRole('button', { name: /increase/i }))
    expect(onChange).toHaveBeenCalledWith(3)
  })

  it('shows Add button not stepper when quantity is 0', () => {
    render(<AddToCartButton quantity={0} onAdd={vi.fn()} onChange={vi.fn()} />)
    expect(screen.getByRole('button', { name: /add/i })).toBeTruthy()
    expect(screen.queryByRole('button', { name: /decrease/i })).toBeNull()
  })
})
