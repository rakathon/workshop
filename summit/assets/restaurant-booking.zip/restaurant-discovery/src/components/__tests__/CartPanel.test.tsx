import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { CartPanel } from '../cart/CartPanel'
import type { StoredCart } from '../../lib/storage/types'

function Wrap({ children }: { children: React.ReactNode }) {
  return <MemoryRouter>{children}</MemoryRouter>
}

const makeCart = (overrides: Partial<StoredCart> = {}): StoredCart => ({
  id: 'cart-1',
  user_id: 'usr-1',
  restaurant_id: 'rest-001',
  status: 'active',
  items: [
    { id: 'ci-1', menu_item_id: 'mi-001', name: 'Margherita Pizza', unit_price: 14.99, quantity: 2 },
    { id: 'ci-2', menu_item_id: 'mi-002', name: 'Penne Arrabbiata', unit_price: 12.99, quantity: 1 },
  ],
  updated_at: '2026-06-05T10:00:00Z',
  ...overrides,
})

describe('CartPanel', () => {
  it('showsEmptyState_whenCartEmpty', () => {
    render(
      <Wrap><CartPanel
        cart={null}
        restaurantName="Pizza Palace"
        cashbackRate={8}
        onClose={vi.fn()}
        onCheckout={vi.fn()}
        onQuantityChange={vi.fn()}
      /></Wrap>
    )
    expect(screen.getByText(/your cart is empty/i)).toBeTruthy()
    expect(screen.getByText(/browse restaurants/i)).toBeTruthy()
  })

  it('showsItems_withSubtotal', () => {
    render(
      <Wrap><CartPanel
        cart={makeCart()}
        restaurantName="Pizza Palace"
        cashbackRate={8}
        onClose={vi.fn()}
        onCheckout={vi.fn()}
        onQuantityChange={vi.fn()}
      /></Wrap>
    )
    expect(screen.getByText('Margherita Pizza')).toBeTruthy()
    expect(screen.getByText('Penne Arrabbiata')).toBeTruthy()
    // Subtotal: 14.99 * 2 + 12.99 * 1 = 42.97
    expect(screen.getAllByText(/42\.97/).length).toBeGreaterThan(0)
  })

  it('showsCashbackBanner', () => {
    render(
      <Wrap><CartPanel
        cart={makeCart()}
        restaurantName="Pizza Palace"
        cashbackRate={8}
        onClose={vi.fn()}
        onCheckout={vi.fn()}
        onQuantityChange={vi.fn()}
      /></Wrap>
    )
    expect(screen.getAllByText(/8%/).length).toBeGreaterThan(0)
    expect(screen.getByText(/cashback/i)).toBeTruthy()
  })

  it('disablesCheckoutCTA_whenEmpty', () => {
    render(
      <Wrap><CartPanel
        cart={null}
        restaurantName="Pizza Palace"
        cashbackRate={8}
        onClose={vi.fn()}
        onCheckout={vi.fn()}
        onQuantityChange={vi.fn()}
      /></Wrap>
    )
    const btn = screen.getByRole('button', { name: /checkout/i })
    expect(btn.getAttribute('aria-disabled')).toBe('true')
  })

  it('calls onCheckout when cart has items and CTA clicked', () => {
    const onCheckout = vi.fn()
    render(
      <Wrap><CartPanel
        cart={makeCart()}
        restaurantName="Pizza Palace"
        cashbackRate={8}
        onClose={vi.fn()}
        onCheckout={onCheckout}
        onQuantityChange={vi.fn()}
      /></Wrap>
    )
    fireEvent.click(screen.getByRole('button', { name: /checkout/i }))
    expect(onCheckout).toHaveBeenCalledTimes(1)
  })

  it('calls onClose when close button clicked', () => {
    const onClose = vi.fn()
    render(
      <Wrap><CartPanel
        cart={makeCart()}
        restaurantName="Pizza Palace"
        cashbackRate={8}
        onClose={onClose}
        onCheckout={vi.fn()}
        onQuantityChange={vi.fn()}
      /></Wrap>
    )
    fireEvent.click(screen.getByRole('button', { name: /close cart/i }))
    expect(onClose).toHaveBeenCalledTimes(1)
  })
})
