import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { OrderConfirmation } from '../order/OrderConfirmation'
import type { StoredOrder } from '../../lib/storage/types'

const ORDER: StoredOrder = {
  id: 'ORD-001',
  user_id: 'usr-1',
  restaurant_id: 'rest-001',
  restaurant_name: 'Osteria Morini',
  delivery_address: '123 Main St, New York, NY 10001',
  status: 'received',
  status_updated_at: '2026-06-05T18:10:00Z',
  estimated_delivery_minutes: 35,
  items: [
    { menu_item_id: 'mi-001', name: 'Margherita Pizza', unit_price: 14.99, quantity: 2, line_total: 29.98 },
  ],
  subtotal: 29.98,
  delivery_fee: 2.99,
  cashback_rate_pct: 8,
  cashback_amount: 2.40,
  total_charged: 30.57,
  payment: { id: 'pay-1', card_last_four: '4242', status: 'mock_success', paid_at: '2026-06-05T18:10:00Z' },
  created_at: '2026-06-05T18:10:00Z',
}

function Wrap({ children }: { children: React.ReactNode }) {
  return <MemoryRouter>{children}</MemoryRouter>
}

describe('OrderConfirmation', () => {
  it('displaysAllRequiredFields', () => {
    render(<Wrap><OrderConfirmation order={ORDER} /></Wrap>)
    expect(screen.getByText(/ORD-001/)).toBeTruthy()
    expect(screen.getByText(/Osteria Morini/)).toBeTruthy()
    expect(screen.getByText(/Margherita Pizza/)).toBeTruthy()
    expect(screen.getByText(/30\.57/)).toBeTruthy()
    expect(screen.getByText(/35/)).toBeTruthy()
  })

  it('cashbackSavedUsesGreenToken', () => {
    const { container } = render(<Wrap><OrderConfirmation order={ORDER} /></Wrap>)
    const cashbackEl = container.querySelector('[data-testid="cashback-saved"]')
    expect(cashbackEl).toBeTruthy()
    expect((cashbackEl as HTMLElement).style.color).toBe('var(--color-cashback)')
  })

  it('trackOrderCTA_navigatesToTracking', () => {
    render(<Wrap><OrderConfirmation order={ORDER} /></Wrap>)
    const cta = screen.getByRole('link', { name: /track/i })
    expect(cta.getAttribute('href')).toContain('ORD-001')
  })

  it('shows success icon', () => {
    render(<Wrap><OrderConfirmation order={ORDER} /></Wrap>)
    expect(screen.getByText(/order placed/i)).toBeTruthy()
  })

  it('shows cashback amount', () => {
    render(<Wrap><OrderConfirmation order={ORDER} /></Wrap>)
    expect(screen.getByText(/2\.40/)).toBeTruthy()
  })
})
