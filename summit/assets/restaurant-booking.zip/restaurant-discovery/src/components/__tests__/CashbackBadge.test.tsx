import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { CashbackBadge } from '../ui/CashbackBadge'

describe('CashbackBadge', () => {
  it('renders_withCorrectRate', () => {
    render(<CashbackBadge rate={8} />)
    expect(screen.getByText(/8%/)).toBeTruthy()
    expect(screen.getByText(/back/i)).toBeTruthy()
  })

  it('renders rate 3', () => {
    render(<CashbackBadge rate={3} />)
    expect(screen.getByText(/3%/)).toBeTruthy()
  })

  it('renders rate 10', () => {
    render(<CashbackBadge rate={10} />)
    expect(screen.getByText(/10%/)).toBeTruthy()
  })

  it('usesCorrectToken — applies cashback color via style', () => {
    const { container } = render(<CashbackBadge rate={8} />)
    const el = container.firstChild as HTMLElement
    // Badge must use the cashback green color token, not arbitrary color
    expect(el.style.color).toBe('var(--color-cashback)')
  })

  it('has accessible label', () => {
    render(<CashbackBadge rate={8} />)
    expect(screen.getByRole('status')).toBeTruthy()
  })
})
