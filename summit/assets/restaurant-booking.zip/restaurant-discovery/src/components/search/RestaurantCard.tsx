import { useNavigate } from 'react-router-dom'
import { StarRating } from '../ui/StarRating'
import { OpenBadge } from '../ui/OpenBadge'
import { CashbackBadge } from '../ui/CashbackBadge'
import type { Restaurant } from '../../types'

interface Props {
  restaurant: Restaurant
  cashbackRate?: number
}

export function RestaurantCard({ restaurant: r, cashbackRate }: Props) {
  const navigate = useNavigate()

  return (
    <article
      onClick={() => navigate(`/restaurant/${r.id}`)}
      onKeyDown={e => e.key === 'Enter' && navigate(`/restaurant/${r.id}`)}
      tabIndex={0}
      role="button"
      aria-label={`View ${r.name}`}
      style={{
        background: '#fff',
        borderRadius: '16px',
        overflow: 'hidden',
        cursor: 'pointer',
        border: '1px solid var(--color-border)',
        boxShadow: '0 1px 4px rgba(37,37,37,0.07)',
        transition: 'box-shadow 200ms ease, transform 200ms ease',
        display: 'flex',
        flexDirection: 'column',
      }}
      onMouseEnter={e => {
        const el = e.currentTarget as HTMLElement
        el.style.boxShadow = '0 12px 32px rgba(37,37,37,0.14)'
        el.style.transform = 'translateY(-4px)'
      }}
      onMouseLeave={e => {
        const el = e.currentTarget as HTMLElement
        el.style.boxShadow = '0 1px 4px rgba(37,37,37,0.07)'
        el.style.transform = 'translateY(0)'
      }}
    >
      {/* Photo */}
      <div
        role="img"
        aria-label={`${r.name} cover photo`}
        style={{
          width: '100%',
          height: '200px',
          backgroundImage: `url(${r.coverPhoto})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundColor: 'var(--color-surface-raised)',
          position: 'relative',
          flexShrink: 0,
        }}
      >
        {/* Price badge overlay */}
        <span style={{
          position: 'absolute', top: '12px', right: '12px',
          background: 'rgba(255,255,255,0.92)',
          backdropFilter: 'blur(4px)',
          padding: '3px 10px', borderRadius: '8px',
          fontSize: '13px', fontWeight: 700,
          color: 'var(--color-text)',
          boxShadow: '0 1px 4px rgba(0,0,0,0.12)',
        }}>{r.priceRange}</span>
      </div>

      {/* Body */}
      <div style={{ padding: '16px', flex: 1, display: 'flex', flexDirection: 'column', gap: '6px' }}>
        {/* Name */}
        <h3 style={{
          fontSize: '17px', fontWeight: 700,
          color: 'var(--color-text)', lineHeight: 1.25,
          letterSpacing: '-0.01em',
          margin: 0,
        }}>
          {r.name}
        </h3>

        {/* Cuisine + location */}
        <div style={{
          fontSize: '13px', color: 'var(--color-text-secondary)',
          display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap',
        }}>
          <span>{r.cuisineNames.join(', ')}</span>
          <span style={{ color: 'var(--color-border-strong)' }}>·</span>
          <span>{r.address.neighbourhood || r.address.city}, {r.address.state}</span>
        </div>

        {/* Rating */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <StarRating rating={r.recentAverageRating} count={r.recentReviewCount} size="sm" />
        </div>

        {/* Open badge */}
        <div style={{ marginTop: '4px' }}>
          <OpenBadge hours={r.hours} timezone={r.address.timezone} />
        </div>

        {/* Cashback badge */}
        {cashbackRate != null && (
          <div style={{ marginTop: '4px' }}>
            <CashbackBadge rate={cashbackRate} />
          </div>
        )}
      </div>
    </article>
  )
}
