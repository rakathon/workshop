import type { Cuisine, FilterState } from '../../types'

interface Props {
  cuisines: Cuisine[]
  filters: FilterState
  onUpdate: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void
  onClear: () => void
}

const PRICE_OPTIONS = ['$', '$$', '$$$', '$$$$']
const DIETARY_OPTIONS = [
  { value: 'vegetarian', label: 'Vegetarian' },
  { value: 'vegan', label: 'Vegan' },
  { value: 'gluten-free', label: 'Gluten-free' },
]
const MEAL_PERIODS = [
  { value: 'breakfast', label: 'Breakfast' },
  { value: 'brunch', label: 'Brunch' },
  { value: 'lunch', label: 'Lunch' },
  { value: 'dinner', label: 'Dinner' },
]

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: '11px', fontWeight: 700, letterSpacing: '0.08em',
      textTransform: 'uppercase', color: 'var(--color-text-muted)',
      marginBottom: '10px',
    }}>{children}</div>
  )
}

function FilterPill({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      style={{
        padding: '6px 14px',
        borderRadius: '10px',
        fontSize: '13px',
        fontWeight: 500,
        cursor: 'pointer',
        border: `1.5px solid ${active ? 'var(--color-brand)' : 'var(--color-border)'}`,
        background: active ? 'var(--color-brand)' : '#fff',
        color: active ? '#fff' : 'var(--color-text-secondary)',
        transition: 'all 120ms ease',
      }}
      onMouseEnter={e => {
        if (!active) {
          e.currentTarget.style.borderColor = 'var(--color-brand)'
          e.currentTarget.style.color = 'var(--color-brand)'
        }
      }}
      onMouseLeave={e => {
        if (!active) {
          e.currentTarget.style.borderColor = 'var(--color-border)'
          e.currentTarget.style.color = 'var(--color-text-secondary)'
        }
      }}
    >
      {label}
    </button>
  )
}

function Divider() {
  return <div style={{ height: '1px', background: 'var(--color-border)', margin: '20px 0' }} />
}

export function FilterSidebar({ cuisines, filters, onUpdate, onClear }: Props) {
  function toggleCuisine(id: string) {
    const cur = filters.cuisine
    onUpdate('cuisine', cur.includes(id) ? cur.filter(c => c !== id) : [...cur, id])
  }
  function togglePrice(p: string) {
    const cur = filters.price
    onUpdate('price', cur.includes(p) ? cur.filter(x => x !== p) : [...cur, p])
  }
  function toggleDietary(d: string) {
    const cur = filters.dietary
    onUpdate('dietary', cur.includes(d) ? cur.filter(x => x !== d) : [...cur, d])
  }

  const hasActive = filters.cuisine.length > 0 || filters.price.length > 0
    || filters.dietary.length > 0 || !!filters.mealPeriod || filters.openNow

  return (
    <aside aria-label="Search filters" style={{
      width: '256px',
      flexShrink: 0,
      background: '#fff',
      borderRight: '1px solid var(--color-border)',
      padding: '24px 20px',
      overflowY: 'auto',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <span style={{ fontSize: '16px', fontWeight: 700, color: 'var(--color-text)' }}>Filters</span>
        {hasActive && (
          <button onClick={onClear} style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontSize: '12px', color: 'var(--color-brand)', fontWeight: 600,
          }}>
            Reset all
          </button>
        )}
      </div>

      {/* Open now — prominent toggle at top */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 16px', borderRadius: '12px', marginBottom: '20px',
        background: filters.openNow ? 'var(--color-success-light)' : 'var(--color-surface-raised)',
        border: `1.5px solid ${filters.openNow ? 'var(--color-success)' : 'var(--color-border)'}`,
        cursor: 'pointer',
        transition: 'all 140ms ease',
      }} onClick={() => onUpdate('openNow', !filters.openNow)} role="switch" aria-checked={filters.openNow} tabIndex={0}
        onKeyDown={e => e.key === 'Enter' && onUpdate('openNow', !filters.openNow)}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ fontSize: '18px' }}>🟢</span>
          <div>
            <div style={{ fontSize: '14px', fontWeight: 600, color: filters.openNow ? 'var(--color-success)' : 'var(--color-text)' }}>Open now</div>
            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>Show only open restaurants</div>
          </div>
        </div>
        {/* Toggle */}
        <div style={{
          width: '40px', height: '22px', borderRadius: '11px',
          background: filters.openNow ? 'var(--color-success)' : 'var(--color-border-strong)',
          position: 'relative', transition: 'background 140ms ease', flexShrink: 0,
        }}>
          <div style={{
            position: 'absolute', top: '3px',
            left: filters.openNow ? '21px' : '3px',
            width: '16px', height: '16px', borderRadius: '50%',
            background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
            transition: 'left 140ms ease',
          }} />
        </div>
      </div>

      <Divider />

      {/* Cuisine */}
      <div style={{ marginBottom: '4px' }}>
        <SectionLabel>Cuisine</SectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {cuisines.map(c => (
            <FilterPill key={c.id} label={c.name} active={filters.cuisine.includes(c.id)} onClick={() => toggleCuisine(c.id)} />
          ))}
        </div>
      </div>

      <Divider />

      {/* Price */}
      <div style={{ marginBottom: '4px' }}>
        <SectionLabel>Price range</SectionLabel>
        <div style={{ display: 'flex', gap: '6px' }}>
          {PRICE_OPTIONS.map(p => (
            <FilterPill key={p} label={p} active={filters.price.includes(p)} onClick={() => togglePrice(p)} />
          ))}
        </div>
      </div>

      <Divider />

      {/* Dietary */}
      <div style={{ marginBottom: '4px' }}>
        <SectionLabel>Dietary</SectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {DIETARY_OPTIONS.map(d => (
            <FilterPill key={d.value} label={d.label} active={filters.dietary.includes(d.value)} onClick={() => toggleDietary(d.value)} />
          ))}
        </div>
      </div>

      <Divider />

      {/* Meal period */}
      <div>
        <SectionLabel>Meal period</SectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {MEAL_PERIODS.map(m => (
            <FilterPill
              key={m.value}
              label={m.label}
              active={filters.mealPeriod === m.value}
              onClick={() => onUpdate('mealPeriod', filters.mealPeriod === m.value ? '' : m.value)}
            />
          ))}
        </div>
      </div>
    </aside>
  )
}
