import type { Cuisine } from '../../types'

interface Props {
  cuisines: Cuisine[]
  selected: string
  onSelect: (cuisineId: string, cuisineName: string) => void
}

const EMOJI: Record<string, string> = {
  thai: '🍜', italian: '🍕', mexican: '🌮', japanese: '🍣',
  indian: '🍛', american: '🍔', mediterranean: '🥙', chinese: '🥡',
  french: '🥐', korean: '🍖',
}

export function CuisinePills({ cuisines, selected, onSelect }: Props) {
  function toggle(cuisine: Cuisine) {
    if (selected === cuisine.id) {
      onSelect('', '')
    } else {
      onSelect(cuisine.id, cuisine.name)
    }
  }

  return (
    <div className="flex flex-wrap gap-2 justify-center" role="group" aria-label="Quick cuisine filters">
      {cuisines.map(c => {
        const isSelected = selected === c.id
        return (
          <button
            key={c.id}
            onClick={() => toggle(c)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all duration-fast"
            style={{
              border: `1.5px solid ${isSelected ? 'var(--color-brand)' : 'var(--color-border-strong)'}`,
              background: isSelected ? 'var(--color-brand)' : 'var(--color-surface)',
              color: isSelected ? 'var(--color-brand-contrast)' : 'var(--color-text-secondary)',
            }}
            aria-pressed={isSelected}
          >
            <span aria-hidden="true">{EMOJI[c.slug] ?? '🍽️'}</span>
            {c.name}
          </button>
        )
      })}
    </div>
  )
}
