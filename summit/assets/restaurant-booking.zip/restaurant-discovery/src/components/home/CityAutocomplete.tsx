import { useState, useRef, useEffect, useId } from 'react'
import type { City } from '../../types'

interface Props {
  cities: City[]
  value: string
  onChange: (cityId: string, displayName: string) => void
  placeholder?: string
}

export function CityAutocomplete({ cities, value, onChange, placeholder = 'City or zip code…' }: Props) {
  const [inputVal, setInputVal] = useState(value)
  const [open, setOpen] = useState(false)
  const [focusedIdx, setFocusedIdx] = useState(-1)
  const inputRef = useRef<HTMLInputElement>(null)
  const listId = useId()

  const filtered = inputVal.trim()
    ? cities.filter(c =>
        c.displayName.toLowerCase().includes(inputVal.toLowerCase()) ||
        c.name.toLowerCase().includes(inputVal.toLowerCase()) ||
        c.zip.startsWith(inputVal.trim())
      )
    : cities

  useEffect(() => { setInputVal(value) }, [value])

  function handleInput(val: string) {
    setInputVal(val)
    setOpen(true)
    setFocusedIdx(-1)
    if (!val) onChange('', '')
  }

  function selectCity(city: City) {
    setInputVal(city.displayName)
    setOpen(false)
    setFocusedIdx(-1)
    onChange(city.id, city.displayName)
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (!open) return
    if (e.key === 'ArrowDown') { e.preventDefault(); setFocusedIdx(i => Math.min(i + 1, filtered.length - 1)) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setFocusedIdx(i => Math.max(i - 1, 0)) }
    else if (e.key === 'Enter' && focusedIdx >= 0) { e.preventDefault(); selectCity(filtered[focusedIdx]) }
    else if (e.key === 'Escape') { setOpen(false); setFocusedIdx(-1) }
  }

  return (
    <div style={{ position: 'relative', flex: 1, minWidth: 0 }}>
      <input
        ref={inputRef}
        type="text"
        value={inputVal}
        onChange={e => handleInput(e.target.value)}
        onFocus={() => setOpen(true)}
      onBlur={() => setTimeout(() => setOpen(false), 150)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        aria-label="Search by city"
        aria-autocomplete="list"
        aria-controls={open ? listId : undefined}
        aria-expanded={open}
        role="combobox"
        autoComplete="off"
        style={{
          width: '100%',
          background: 'transparent',
          border: 'none',
          outline: 'none',
          fontSize: '15px',
          fontWeight: 500,
          color: 'var(--color-text)',
          padding: 0,
        }}
      />

      {open && filtered.length > 0 && (
        <ul
          id={listId}
          role="listbox"
          aria-label="City suggestions"
          style={{
            position: 'absolute',
            top: 'calc(100% + 8px)',
            left: '-50px',
            width: '280px',
            background: '#fff',
            border: '1px solid var(--color-border)',
            borderRadius: '14px',
            boxShadow: '0 12px 40px rgba(133,41,205,0.15), 0 2px 8px rgba(0,0,0,0.08)',
            zIndex: 200,
            overflow: 'hidden',
            padding: '4px',
            listStyle: 'none',
            margin: 0,
          }}
        >
          {filtered.map((city, idx) => (
            <li
              key={city.id}
              role="option"
              aria-selected={idx === focusedIdx}
              style={{
                display: 'flex', alignItems: 'center', gap: '10px',
                padding: '10px 14px', borderRadius: '10px',
                cursor: 'pointer', fontSize: '14px', fontWeight: 500,
                background: idx === focusedIdx ? 'var(--color-brand-light)' : 'transparent',
                color: idx === focusedIdx ? 'var(--color-brand)' : 'var(--color-text)',
                transition: 'all 80ms',
              }}
              onMouseDown={e => { e.preventDefault(); selectCity(city) }}
              onMouseEnter={() => setFocusedIdx(idx)}
            >
              <span style={{ fontSize: '16px' }}>📍</span>
              <div>
                <div style={{ fontWeight: 600 }}>{city.name}</div>
                <div style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>{city.state}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
