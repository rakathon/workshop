interface Props {
  rate: number // 3–10
}

export function CashbackBadge({ rate }: Props) {
  return (
    <span
      role="status"
      aria-label={`${rate} percent cashback on this order`}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '4px',
        background: 'var(--color-cashback-bg)',
        color: 'var(--color-cashback)',
        border: '1px solid var(--color-cashback-border)',
        borderRadius: '9999px',
        padding: '2px 10px',
        fontSize: '13px',
        fontWeight: 600,
        whiteSpace: 'nowrap',
      }}
    >
      🎁 {rate}% back
    </span>
  )
}
