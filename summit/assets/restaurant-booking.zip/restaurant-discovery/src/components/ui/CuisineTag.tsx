interface Props {
  name: string
  className?: string
}

export function CuisineTag({ name, className = '' }: Props) {
  return (
    <span
      className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${className}`}
      style={{
        background: 'var(--color-surface-raised)',
        border: '1px solid var(--color-border)',
        color: 'var(--color-text-secondary)',
      }}
    >
      {name}
    </span>
  )
}
