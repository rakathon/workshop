interface Props {
  value: string
  className?: string
}

export function PriceRange({ value, className = '' }: Props) {
  return (
    <span
      className={`text-sm font-medium ${className}`}
      style={{ color: 'var(--color-text-secondary)' }}
      aria-label={`Price range: ${value}`}
    >
      {value}
    </span>
  )
}
