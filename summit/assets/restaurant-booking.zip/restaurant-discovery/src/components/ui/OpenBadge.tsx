import type { WeeklyHours, DayOfWeek } from '../../types'

interface Props {
  hours: WeeklyHours
  timezone: string
}

const DAYS: DayOfWeek[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

function getLocalTime(timezone: string): { day: DayOfWeek; minutes: number } {
  const now = new Date()
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    weekday: 'long',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(now)
  const weekday = parts.find(p => p.type === 'weekday')?.value?.toLowerCase() as DayOfWeek
  const h = parseInt(parts.find(p => p.type === 'hour')?.value ?? '0', 10)
  const m = parseInt(parts.find(p => p.type === 'minute')?.value ?? '0', 10)
  return { day: weekday, minutes: h * 60 + m }
}

function getNextOpenText(hours: WeeklyHours, currentDay: DayOfWeek, timezone: string): string {
  const currentIdx = DAYS.indexOf(currentDay)
  for (let i = 1; i <= 7; i++) {
    const nextDay = DAYS[(currentIdx + i) % 7]
    const h = hours[nextDay]
    if (h) {
      const dayLabel = i === 1 ? 'tomorrow' : nextDay.charAt(0).toUpperCase() + nextDay.slice(1)
      return `Opens ${dayLabel} at ${h.open}`
    }
  }
  return 'Hours unavailable'
}

export function OpenBadge({ hours, timezone }: Props) {
  const { day, minutes } = getLocalTime(timezone)
  const todayHours = hours[day]

  let isOpen = false
  let label = 'Closed'
  let sub = getNextOpenText(hours, day, timezone)

  if (todayHours) {
    const [oh, om] = todayHours.open.split(':').map(Number)
    const [ch, cm] = todayHours.close.split(':').map(Number)
    const openMin = oh * 60 + om
    const closeMin = ch * 60 + cm
    isOpen = minutes >= openMin && minutes < closeMin
    if (isOpen) {
      label = 'Open now'
      sub = `Closes at ${todayHours.close}`
    }
  }

  return (
    <span
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium"
      style={{
        background: isOpen ? 'var(--color-success-light)' : 'var(--color-danger-light)',
        color: isOpen ? 'var(--color-success)' : 'var(--color-danger)',
      }}
      aria-label={`${label}. ${sub}`}
    >
      <span
        className="w-1.5 h-1.5 rounded-full"
        style={{ background: 'currentColor' }}
        aria-hidden="true"
      />
      {label}
      <span className="font-normal opacity-75 hidden sm:inline">· {sub}</span>
    </span>
  )
}
