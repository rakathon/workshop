export function SkeletonCard() {
  return (
    <div
      className="rounded-lg overflow-hidden animate-pulse"
      style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}
      aria-hidden="true"
    >
      <div className="h-40" style={{ background: 'var(--color-surface-raised)' }} />
      <div className="p-4 space-y-2">
        <div className="h-4 rounded" style={{ background: 'var(--color-border)', width: '65%' }} />
        <div className="h-3 rounded" style={{ background: 'var(--color-border)', width: '45%' }} />
        <div className="h-3 rounded" style={{ background: 'var(--color-border)', width: '55%' }} />
        <div className="h-5 rounded-full mt-3" style={{ background: 'var(--color-border)', width: '40%' }} />
      </div>
    </div>
  )
}

export function SkeletonListing() {
  return (
    <div className="animate-pulse" aria-hidden="true">
      <div className="w-full" style={{ height: '360px', background: 'var(--color-surface-raised)' }} />
      <div className="max-w-4xl mx-auto px-6 py-8 space-y-4">
        <div className="h-8 rounded" style={{ background: 'var(--color-border)', width: '50%' }} />
        <div className="h-4 rounded" style={{ background: 'var(--color-border)', width: '35%' }} />
        <div className="h-4 rounded" style={{ background: 'var(--color-border)', width: '25%' }} />
        <div className="space-y-2 mt-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-3 rounded" style={{ background: 'var(--color-border)', width: `${70 - i * 8}%` }} />
          ))}
        </div>
      </div>
    </div>
  )
}
