interface Props {
  quantity: number
  onAdd: () => void
  onChange: (newQty: number) => void
  itemName?: string
}

export function AddToCartButton({ quantity, onAdd, onChange, itemName = 'item' }: Props) {
  if (quantity === 0) {
    return (
      <button
        onClick={onAdd}
        aria-label={`Add ${itemName} to cart`}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: '4px',
          padding: '6px 14px',
          background: 'var(--color-brand)',
          color: '#fff',
          border: 'none',
          borderRadius: '9999px',
          fontSize: '13px', fontWeight: 600,
          cursor: 'pointer',
          transition: 'background 120ms',
          whiteSpace: 'nowrap',
          minHeight: '32px',
        }}
        onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-brand-hover)')}
        onMouseLeave={e => (e.currentTarget.style.background = 'var(--color-brand)')}
      >
        + Add
      </button>
    )
  }

  return (
    <div
      style={{
        display: 'inline-flex', alignItems: 'center', gap: '6px',
        border: '2px solid var(--color-brand)',
        borderRadius: '9999px',
        overflow: 'hidden',
      }}
      role="group"
      aria-label={`${itemName} quantity`}
    >
      <button
        onClick={() => onChange(quantity - 1)}
        aria-label={`Decrease ${itemName} quantity`}
        style={{
          width: '28px', height: '28px',
          background: quantity === 1 ? '#fff' : 'var(--color-brand)',
          color: quantity === 1 ? 'var(--color-brand)' : '#fff',
          border: 'none', cursor: 'pointer',
          fontSize: '16px', fontWeight: 700,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'background 120ms, color 120ms',
          flexShrink: 0,
        }}
      >
        −
      </button>
      <span
        style={{
          minWidth: '20px', textAlign: 'center',
          fontSize: '14px', fontWeight: 700,
          color: 'var(--color-brand)',
          userSelect: 'none',
        }}
        aria-live="polite"
        aria-label={`${quantity} in cart`}
      >
        {quantity}
      </span>
      <button
        onClick={() => onChange(quantity + 1)}
        aria-label={`Increase ${itemName} quantity`}
        style={{
          width: '28px', height: '28px',
          background: 'var(--color-brand)', color: '#fff',
          border: 'none', cursor: 'pointer',
          fontSize: '16px', fontWeight: 700,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'background 120ms',
          flexShrink: 0,
        }}
        onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-brand-hover)')}
        onMouseLeave={e => (e.currentTarget.style.background = 'var(--color-brand)')}
      >
        +
      </button>
    </div>
  )
}
