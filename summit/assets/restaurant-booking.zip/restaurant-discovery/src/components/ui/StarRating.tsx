interface Props {
  rating: number
  count?: number
  size?: 'sm' | 'md' | 'lg'
}

const sizes = { sm: 'text-sm', md: 'text-base', lg: 'text-xl' }

export function StarRating({ rating, count, size = 'md' }: Props) {
  const full = Math.floor(rating)
  const half = rating - full >= 0.5
  const stars = Array.from({ length: 5 }, (_, i) => {
    if (i < full) return '★'
    if (i === full && half) return '★'
    return '☆'
  })

  return (
    <span
      className={`inline-flex items-center gap-1 ${sizes[size]}`}
      aria-label={`${rating} out of 5 stars${count !== undefined ? `, ${count} reviews` : ''}`}
    >
      <span style={{ color: 'var(--color-star)', letterSpacing: '1px' }} aria-hidden="true">
        {stars.join('')}
      </span>
      <span className="font-bold" style={{ color: 'var(--color-text)' }}>{rating.toFixed(1)}</span>
      {count !== undefined && (
        <span style={{ color: 'var(--color-text-muted)', fontSize: '0.875em' }}>
          ({count})
        </span>
      )}
    </span>
  )
}
