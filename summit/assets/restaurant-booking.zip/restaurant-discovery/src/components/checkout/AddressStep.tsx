import { useState } from 'react'

interface Props {
  onContinue: (address: string) => void
  onBack: () => void
  initialAddress?: string
}

interface Errors {
  street?: string
  city?: string
  state?: string
  zip?: string
}

export function AddressStep({ onContinue, onBack, initialAddress = '' }: Props) {
  const [street, setStreet] = useState(() => {
    if (!initialAddress) return ''
    return initialAddress.split(',')[0]?.trim() ?? ''
  })
  const [city, setCity] = useState('')
  const [state, setState] = useState('')
  const [zip, setZip] = useState('')
  const [errors, setErrors] = useState<Errors>({})

  function validate(): boolean {
    const e: Errors = {}
    if (!street.trim()) e.street = 'Please enter a street address'
    if (!city.trim()) e.city = 'Please enter a city'
    if (!state.trim()) e.state = 'Please enter a state'
    if (!zip.trim()) e.zip = 'Please enter a ZIP code'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function handleSubmit(ev: React.FormEvent) {
    ev.preventDefault()
    if (!validate()) return
    onContinue(`${street.trim()}, ${city.trim()}, ${state.trim()} ${zip.trim()}`)
  }

  const fieldStyle: React.CSSProperties = {
    width: '100%',
    padding: '10px 12px',
    border: '2px solid var(--color-border)',
    borderRadius: '10px',
    fontSize: '15px',
    color: 'var(--color-text)',
    background: '#fff',
    outline: 'none',
    transition: 'border-color 120ms',
    minHeight: '44px',
  }
  const errorStyle: React.CSSProperties = {
    fontSize: '12px', color: 'var(--color-danger)',
    marginTop: '4px', display: 'flex', alignItems: 'center', gap: '4px',
  }
  const labelStyle: React.CSSProperties = {
    display: 'block', fontSize: '13px', fontWeight: 600,
    color: 'var(--color-text)', marginBottom: '4px',
  }

  return (
    <form onSubmit={handleSubmit} noValidate style={{ padding: '24px' }}>
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '20px', color: 'var(--color-text)', letterSpacing: '-0.02em' }}>
        Delivery address
      </h2>

      <div style={{ marginBottom: '16px' }}>
        <label htmlFor="addr-street" style={labelStyle}>Street address</label>
        <input
          id="addr-street"
          type="text"
          autoComplete="address-line1"
          placeholder="123 Main St"
          value={street}
          onChange={e => { setStreet(e.target.value); if (errors.street) setErrors(p => ({ ...p, street: undefined })) }}
          style={{ ...fieldStyle, borderColor: errors.street ? 'var(--color-danger)' : 'var(--color-border)' }}
          aria-label="Street address"
          aria-describedby={errors.street ? 'err-street' : undefined}
          aria-invalid={!!errors.street}
        />
        {errors.street && <p id="err-street" style={errorStyle} role="alert">⚠ {errors.street}</p>}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' }}>
        <div>
          <label htmlFor="addr-city" style={labelStyle}>City</label>
          <input
            id="addr-city"
            type="text"
            autoComplete="address-level2"
            placeholder="New York"
            value={city}
            onChange={e => { setCity(e.target.value); if (errors.city) setErrors(p => ({ ...p, city: undefined })) }}
            style={{ ...fieldStyle, borderColor: errors.city ? 'var(--color-danger)' : 'var(--color-border)' }}
            aria-label="City"
            aria-invalid={!!errors.city}
          />
          {errors.city && <p style={errorStyle} role="alert">⚠ {errors.city}</p>}
        </div>
        <div>
          <label htmlFor="addr-state" style={labelStyle}>State</label>
          <input
            id="addr-state"
            type="text"
            autoComplete="address-level1"
            placeholder="NY"
            maxLength={2}
            value={state}
            onChange={e => { setState(e.target.value); if (errors.state) setErrors(p => ({ ...p, state: undefined })) }}
            style={{ ...fieldStyle, borderColor: errors.state ? 'var(--color-danger)' : 'var(--color-border)' }}
            aria-label="State"
            aria-invalid={!!errors.state}
          />
          {errors.state && <p style={errorStyle} role="alert">⚠ {errors.state}</p>}
        </div>
      </div>

      <div style={{ marginBottom: '24px' }}>
        <label htmlFor="addr-zip" style={labelStyle}>ZIP code</label>
        <input
          id="addr-zip"
          type="text"
          inputMode="numeric"
          autoComplete="postal-code"
          placeholder="10001"
          maxLength={5}
          value={zip}
          onChange={e => { setZip(e.target.value); if (errors.zip) setErrors(p => ({ ...p, zip: undefined })) }}
          style={{ ...fieldStyle, maxWidth: '160px', borderColor: errors.zip ? 'var(--color-danger)' : 'var(--color-border)' }}
          aria-label="ZIP code"
          aria-invalid={!!errors.zip}
        />
        {errors.zip && <p style={errorStyle} role="alert">⚠ {errors.zip}</p>}
      </div>

      <button
        type="submit"
        style={{
          width: '100%', padding: '14px',
          background: 'var(--color-brand)', color: '#fff',
          border: 'none', borderRadius: '12px',
          fontSize: '15px', fontWeight: 700, cursor: 'pointer',
          marginBottom: '10px',
          transition: 'background 120ms',
        }}
      >
        Continue to Summary →
      </button>
      <button
        type="button"
        onClick={onBack}
        aria-label="Back to cart"
        style={{
          width: '100%', padding: '10px',
          background: 'none', border: 'none',
          fontSize: '13px', color: 'var(--color-text-muted)',
          cursor: 'pointer',
        }}
      >
        ← Back to cart
      </button>
    </form>
  )
}
