export type CheckoutStep = 1 | 2 | 3
const LABELS: Record<CheckoutStep, string> = { 1: 'Address', 2: 'Summary', 3: 'Payment' }

interface Props {
  step: CheckoutStep
}

export function CheckoutProgress({ step }: Props) {
  return (
    <nav aria-label="Checkout steps" style={{ display: 'flex', alignItems: 'center', padding: '16px 24px 0' }}>
      {([1, 2, 3] as CheckoutStep[]).map((n, i) => {
        const done = n < step
        const active = n === step
        return (
          <div key={n} style={{ display: 'flex', alignItems: 'center', flex: n < 3 ? 1 : undefined }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
              <div
                aria-current={active ? 'step' : undefined}
                aria-label={`Step ${n} of 3: ${LABELS[n]}${done ? ', completed' : active ? ', current' : ''}`}
                style={{
                  width: '28px', height: '28px',
                  borderRadius: '9999px',
                  background: done ? 'var(--color-success)' : active ? 'var(--color-brand)' : '#fff',
                  border: `2px solid ${done ? 'var(--color-success)' : active ? 'var(--color-brand)' : 'var(--color-border-strong)'}`,
                  color: done || active ? '#fff' : 'var(--color-text-muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '12px', fontWeight: 700,
                  flexShrink: 0,
                }}
              >
                {done ? '✓' : n}
              </div>
              <span style={{
                fontSize: '11px',
                fontWeight: active ? 700 : 400,
                color: done ? 'var(--color-success)' : active ? 'var(--color-brand)' : 'var(--color-text-muted)',
                whiteSpace: 'nowrap',
              }}>
                {LABELS[n]}
              </span>
            </div>
            {i < 2 && (
              <div style={{
                flex: 1, height: '2px', margin: '0 4px 18px',
                background: done ? 'var(--color-success)' : 'var(--color-border)',
              }} />
            )}
          </div>
        )
      })}
    </nav>
  )
}
