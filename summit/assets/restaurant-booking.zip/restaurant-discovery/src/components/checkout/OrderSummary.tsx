import type { OrderItem } from '../../lib/storage/types'

interface Props {
  items: OrderItem[]
  deliveryFee: number
  cashbackRatePct: number
  deliveryAddress: string
  estimatedMinutes: number
  onContinue: () => void
  onBack: () => void
}

function fmt(n: number) { return n.toFixed(2) }

export function computeCashback(subtotal: number, ratePct: number): number {
  return Math.round(subtotal * ratePct) / 100
}

export function OrderSummary({
  items, deliveryFee, cashbackRatePct, deliveryAddress, estimatedMinutes, onContinue, onBack,
}: Props) {
  const subtotal = items.reduce((s, i) => s + i.unit_price * i.quantity, 0)
  const cashback = computeCashback(subtotal, cashbackRatePct)
  const total = subtotal + deliveryFee - cashback

  const rowStyle: React.CSSProperties = {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '8px 0', fontSize: '15px',
  }
  const dividerStyle: React.CSSProperties = {
    height: '1px', background: 'var(--color-border)', margin: '4px 0',
  }

  return (
    <div style={{ padding: '24px' }}>
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '20px', color: 'var(--color-text)', letterSpacing: '-0.02em' }}>
        Order summary
      </h2>

      {/* Items */}
      <div style={{ background: 'var(--color-surface-raised)', borderRadius: '12px', padding: '16px', marginBottom: '16px' }}>
        {items.map(item => (
          <div key={item.menu_item_id} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '14px' }}>
            <span style={{ color: 'var(--color-text)' }}>{item.name} × {item.quantity}</span>
            <span style={{ fontWeight: 600 }}>${fmt(item.unit_price * item.quantity)}</span>
          </div>
        ))}
      </div>

      {/* Price breakdown */}
      <div style={{ marginBottom: '16px' }}>
        <div style={rowStyle}>
          <span style={{ color: 'var(--color-text-secondary)' }}>Subtotal</span>
          <span>${fmt(subtotal)}</span>
        </div>
        <div style={dividerStyle} />
        <div style={rowStyle}>
          <span style={{ color: 'var(--color-text-secondary)' }}>Delivery fee</span>
          <span>${fmt(deliveryFee)}</span>
        </div>
        {cashbackRatePct > 0 && (
          <>
            <div style={dividerStyle} />
            <div
              data-testid="cashback-line"
              style={{ ...rowStyle, color: 'var(--color-cashback)', fontWeight: 600 }}
            >
              <span>🎁 Cashback ({cashbackRatePct}%)</span>
              <span>−${fmt(cashback)}</span>
            </div>
          </>
        )}
        <div style={{ height: '2px', background: 'var(--color-text)', margin: '8px 0 4px' }} />
        <div style={{ ...rowStyle, fontWeight: 700, fontSize: '17px' }}>
          <span>Total</span>
          <span style={{ color: 'var(--color-brand)' }}>${fmt(total)}</span>
        </div>
      </div>

      {/* Delivery info */}
      <div style={{ background: 'var(--color-surface-raised)', borderRadius: '12px', padding: '14px 16px', marginBottom: '24px' }}>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '8px', fontSize: '14px' }}>
          <span>📍</span>
          <span style={{ color: 'var(--color-text-secondary)' }}>{deliveryAddress}</span>
        </div>
        <div style={{ display: 'flex', gap: '10px', fontSize: '14px' }}>
          <span>⏱</span>
          <span style={{ color: 'var(--color-text-secondary)' }}>
            Estimated delivery: <strong style={{ color: 'var(--color-text)' }}>~{estimatedMinutes} min</strong>
          </span>
        </div>
      </div>

      <button
        onClick={onContinue}
        style={{
          width: '100%', padding: '14px',
          background: 'var(--color-brand)', color: '#fff',
          border: 'none', borderRadius: '12px',
          fontSize: '15px', fontWeight: 700, cursor: 'pointer',
          marginBottom: '10px', transition: 'background 120ms',
        }}
      >
        Continue to Payment →
      </button>
      <button
        onClick={onBack}
        style={{
          width: '100%', padding: '10px',
          background: 'none', border: 'none',
          fontSize: '13px', color: 'var(--color-text-muted)', cursor: 'pointer',
        }}
      >
        ← Edit address
      </button>
    </div>
  )
}
