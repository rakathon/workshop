import { useState } from 'react'

interface Props {
  total: number
  onPlace: (cardLastFour: string) => void  // full PAN never passed — only last 4
  onBack: () => void
}

export function PaymentStep({ total, onPlace, onBack }: Props) {
  const [cardNumber, setCardNumber] = useState('')
  const [expiry, setExpiry] = useState('')
  const [cvv, setCvv] = useState('')

  const allFilled = cardNumber.trim().length >= 15 && expiry.trim().length >= 4 && cvv.trim().length >= 3
  const isDisabled = !allFilled

  function handlePlace() {
    if (isDisabled) return
    // Strip spaces, extract last 4 — full PAN is never stored or passed further
    const digits = cardNumber.replace(/\s/g, '')
    const lastFour = digits.slice(-4)
    onPlace(lastFour)
  }

  const fieldStyle: React.CSSProperties = {
    width: '100%', padding: '10px 12px',
    border: '2px solid var(--color-border)', borderRadius: '10px',
    fontSize: '15px', color: 'var(--color-text)', background: '#fff',
    outline: 'none', transition: 'border-color 120ms', minHeight: '44px',
  }
  const labelStyle: React.CSSProperties = {
    display: 'block', fontSize: '13px', fontWeight: 600,
    color: 'var(--color-text)', marginBottom: '4px',
  }

  return (
    <div style={{ padding: '24px' }}>
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '20px', color: 'var(--color-text)', letterSpacing: '-0.02em' }}>
        Payment
      </h2>

      {/* Trust badge */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
        background: 'var(--color-surface-raised)', border: '1px solid var(--color-border)',
        borderRadius: '10px', padding: '10px', marginBottom: '20px',
        fontSize: '13px', color: 'var(--color-text-secondary)',
      }}>
        🔒 Secure payment — card details are never stored in full
      </div>

      {/* Card number */}
      <div style={{ marginBottom: '16px' }}>
        <label htmlFor="card-number" style={labelStyle}>Card number</label>
        <input
          id="card-number"
          type="text"
          inputMode="numeric"
          autoComplete="cc-number"
          placeholder="1234 5678 9012 3456"
          maxLength={19}
          value={cardNumber}
          onChange={e => setCardNumber(e.target.value)}
          onFocus={e => (e.target.style.borderColor = 'var(--color-brand)')}
          onBlur={e => (e.target.style.borderColor = 'var(--color-border)')}
          style={fieldStyle}
          aria-label="Card number"
        />
      </div>

      {/* Expiry + CVV */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '24px' }}>
        <div>
          <label htmlFor="card-expiry" style={labelStyle}>Expiry (MM/YY)</label>
          <input
            id="card-expiry"
            type="text"
            inputMode="numeric"
            autoComplete="cc-exp"
            placeholder="06/28"
            maxLength={5}
            value={expiry}
            onChange={e => setExpiry(e.target.value)}
            onFocus={e => (e.target.style.borderColor = 'var(--color-brand)')}
            onBlur={e => (e.target.style.borderColor = 'var(--color-border)')}
            style={fieldStyle}
            aria-label="Expiry date"
          />
        </div>
        <div>
          <label htmlFor="card-cvv" style={labelStyle}>CVV</label>
          <input
            id="card-cvv"
            type="text"
            inputMode="numeric"
            autoComplete="cc-csc"
            placeholder="•••"
            maxLength={3}
            value={cvv}
            onChange={e => setCvv(e.target.value)}
            onFocus={e => (e.target.style.borderColor = 'var(--color-brand)')}
            onBlur={e => (e.target.style.borderColor = 'var(--color-border)')}
            style={fieldStyle}
            aria-label="CVV"
          />
        </div>
      </div>

      {/* Total reminder */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '12px 0', borderTop: '1px solid var(--color-border)', marginBottom: '16px',
      }}>
        <span style={{ color: 'var(--color-text-secondary)', fontSize: '14px' }}>Total to charge</span>
        <span style={{ fontSize: '22px', fontWeight: 800, color: 'var(--color-brand)' }}>
          ${total.toFixed(2)}
        </span>
      </div>

      {/* Place Order */}
      <button
        onClick={handlePlace}
        aria-disabled={isDisabled ? 'true' : 'false'}
        aria-label="Place order"
        style={{
          width: '100%', padding: '16px',
          background: isDisabled ? 'var(--color-border)' : 'var(--color-brand)',
          color: isDisabled ? 'var(--color-text-muted)' : '#fff',
          border: 'none', borderRadius: '12px',
          fontSize: '16px', fontWeight: 700,
          cursor: isDisabled ? 'not-allowed' : 'pointer',
          marginBottom: '10px', transition: 'background 120ms',
        }}
        onMouseEnter={e => { if (!isDisabled) e.currentTarget.style.background = 'var(--color-brand-hover)' }}
        onMouseLeave={e => { if (!isDisabled) e.currentTarget.style.background = 'var(--color-brand)' }}
      >
        Place Order
      </button>

      <button
        onClick={onBack}
        aria-label="Back to summary"
        style={{
          width: '100%', padding: '10px',
          background: 'none', border: 'none',
          fontSize: '13px', color: 'var(--color-text-muted)', cursor: 'pointer',
        }}
      >
        ← Back to summary
      </button>

      <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', textAlign: 'center', marginTop: '12px' }}>
        By placing your order you agree to DineFind's terms. This is a mock payment — no real charge is made.
      </p>
    </div>
  )
}
