import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { OpenBadge } from '../components/ui/OpenBadge'
import { StarRating } from '../components/ui/StarRating'
import { CashbackBadge } from '../components/ui/CashbackBadge'
import { AddToCartButton } from '../components/ui/AddToCartButton'
import { SkeletonListing } from '../components/ui/SkeletonCard'
import { PhotoGallery } from '../components/listing/PhotoGallery'
import { MenuDisplay } from '../components/listing/MenuDisplay'
import { ReviewSection } from '../components/listing/ReviewSection'
import { CartPanel } from '../components/cart/CartPanel'
import { useCart } from '../context/CartContext'
import { LocalStorageService } from '../lib/storage'
import restaurantsData from '../data/restaurants.json'
import type { Restaurant, DayOfWeek } from '../types'

const allRestaurants = restaurantsData as Restaurant[]

const DAYS_ORDER: DayOfWeek[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
const DAY_LABELS: Record<DayOfWeek, string> = {
  monday: 'Monday', tuesday: 'Tuesday', wednesday: 'Wednesday',
  thursday: 'Thursday', friday: 'Friday', saturday: 'Saturday', sunday: 'Sunday',
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2 style={{
      fontSize: '20px', fontWeight: 700, color: 'var(--color-text)',
      letterSpacing: '-0.02em', marginBottom: '16px',
      paddingLeft: '12px',
      borderLeft: '4px solid var(--color-brand)',
    }}>{children}</h2>
  )
}

function HoursSection({ restaurant }: { restaurant: Restaurant }) {
  const [showFull, setShowFull] = useState(false)
  const today = new Intl.DateTimeFormat('en-US', {
    timeZone: restaurant.address.timezone, weekday: 'long',
  }).format(new Date()).toLowerCase() as DayOfWeek

  const todayHours = restaurant.hours[today]
  const todayLabel = todayHours ? `${todayHours.open} – ${todayHours.close}` : 'Closed today'

  return (
    <div>
      <div style={{ fontSize: '15px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '8px' }}>
        {DAY_LABELS[today]}: <span style={{ fontWeight: 400, color: 'var(--color-text-secondary)' }}>{todayLabel}</span>
      </div>
      <button
        id="hours-toggle-btn"
        onClick={() => setShowFull(v => !v)}
        aria-expanded={showFull}
        aria-controls="hours-full-week"
        style={{
          background: 'none', border: 'none', cursor: 'pointer',
          fontSize: '13px', color: 'var(--color-brand)', fontWeight: 600,
          textDecoration: 'underline', padding: 0,
        }}
      >
        {showFull ? 'Hide full week ▲' : 'Show full week ▼'}
      </button>
      {showFull && (
        <div id="hours-full-week" style={{ marginTop: '12px', borderRadius: '10px', overflow: 'hidden', border: '1px solid var(--color-border)' }}
          role="region" aria-label="Full week hours">
          {DAYS_ORDER.map((day, i) => (
            <div key={day} style={{
              display: 'flex', justifyContent: 'space-between', padding: '10px 16px',
              fontSize: '14px',
              background: day === today ? 'var(--color-brand-light)' : i % 2 === 0 ? '#fff' : '#FAFAF8',
              fontWeight: day === today ? 600 : 400,
              color: day === today ? 'var(--color-brand)' : 'var(--color-text-secondary)',
              borderBottom: i < 6 ? '1px solid var(--color-border)' : 'none',
            }}>
              <span>{DAY_LABELS[day]}{day === today ? ' (today)' : ''}</span>
              <span>{restaurant.hours[day] ? `${restaurant.hours[day]!.open} – ${restaurant.hours[day]!.close}` : 'Closed'}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default function ListingPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [shareMsg, setShareMsg] = useState('')
  const { cart, isOpen, openCart, closeCart, addItem, changeQuantity, loadCart, totalItems } = useCart()

  const restaurant = allRestaurants.find(r => r.id === id || r.slug === id)
  const mockRestaurant = restaurant ? LocalStorageService.getRestaurantById(restaurant.id) : null

  // Hydrate cart from localStorage on mount so badge survives navigation
  useEffect(() => {
    if (restaurant) loadCart(restaurant.id)
  }, [restaurant?.id, loadCart])
  const cashbackRate = mockRestaurant?.cashback_rate_pct ?? 0
  const mockMenuItems = restaurant ? LocalStorageService.getMenu(restaurant.id) : []

  function handleShare() {
    const url = window.location.href
    if (navigator.share) {
      navigator.share({ title: restaurant?.name ?? 'DineFind', url }).catch(() => {})
    } else {
      navigator.clipboard?.writeText(url).catch(() => {})
      setShareMsg('Link copied!')
      setTimeout(() => setShareMsg(''), 2500)
    }
  }

  if (!restaurant) return <SkeletonListing />

  return (
    <div style={{ minHeight: '100vh', background: '#FAFAF8' }}>

      {/* ── Header ──────────────────────────────────────────────── */}
      <header style={{
        background: '#fff', borderBottom: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-sm)', height: '64px',
        display: 'flex', alignItems: 'center', padding: '0 24px', gap: '16px',
        position: 'sticky', top: 0, zIndex: 50,
      }}>
        <button onClick={() => navigate('/')} style={{
          fontWeight: 800, fontSize: '20px', color: 'var(--color-brand)',
          background: 'none', border: 'none', cursor: 'pointer', letterSpacing: '-0.03em', flexShrink: 0,
        }}>
          Dine<span style={{ color: 'var(--color-dark-indigo)' }}>Find</span>
        </button>
        <div
          onClick={() => navigate(-1)} role="button" tabIndex={0}
          onKeyDown={e => e.key === 'Enter' && navigate(-1)}
          aria-label="Back to search"
          style={{
            flex: 1, maxWidth: '400px', display: 'flex', alignItems: 'center', gap: '8px',
            padding: '0 16px', borderRadius: '10px', height: '40px',
            background: '#FAFAF8', border: '1px solid var(--color-border)',
            cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-muted)',
          }}
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          Search restaurants
        </div>
        <div style={{ flex: 1 }} />
        {/* Orders link */}
        <button onClick={() => navigate('/orders')} style={{
          background: 'none', border: '1px solid var(--color-border)',
          borderRadius: '10px', padding: '8px 14px',
          fontSize: '13px', fontWeight: 600, color: 'var(--color-text-secondary)',
          cursor: 'pointer', flexShrink: 0, minHeight: '44px',
        }}>
          Orders
        </button>

        {/* Cart button */}
        <button
          onClick={() => restaurant && openCart(restaurant.id)}
          aria-label={`Cart: ${totalItems} item${totalItems !== 1 ? 's' : ''}`}
          style={{
            position: 'relative',
            padding: '10px 14px', borderRadius: '10px',
            background: '#fff', border: '1px solid var(--color-border)',
            cursor: 'pointer', fontSize: '18px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, minWidth: '44px', minHeight: '44px',
          }}
        >
          🛒
          {totalItems > 0 && (
            <span style={{
              position: 'absolute', top: '-4px', right: '-4px',
              background: 'var(--color-brand)', color: '#fff',
              borderRadius: '9999px',
              minWidth: '18px', height: '18px',
              fontSize: '11px', fontWeight: 700,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              padding: '0 4px',
            }} aria-hidden="true">
              {totalItems}
            </span>
          )}
        </button>

        <button onClick={handleShare} style={{
          display: 'flex', alignItems: 'center', gap: '8px',
          padding: '10px 20px', borderRadius: '10px',
          background: 'var(--color-brand)', color: '#fff',
          border: 'none', cursor: 'pointer', fontSize: '14px', fontWeight: 600,
          flexShrink: 0,
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
            <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
            <path d="m8.59 13.51 6.83 3.98M15.41 6.51l-6.82 3.98"/>
          </svg>
          Share
        </button>
      </header>

      {/* ── Hero photo ───────────────────────────────────────────── */}
      <div
        role="img" aria-label={`${restaurant.name} cover photo`}
        style={{
          width: '100%', height: '480px',
          backgroundImage: `url(${restaurant.coverPhoto})`,
          backgroundSize: 'cover', backgroundPosition: 'center',
          backgroundColor: 'var(--color-surface-raised)', position: 'relative',
        }}
      >
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, transparent 30%, rgba(15,10,30,0.7) 100%)' }} />
        {/* Restaurant name overlaid on hero */}
        <div style={{
          position: 'absolute', bottom: '32px', left: '32px', right: '32px',
          display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '8px', flexWrap: 'wrap' }}>
              {restaurant.cuisineNames.map(c => (
                <span key={c} style={{
                  padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 600,
                  background: 'rgba(255,255,255,0.2)', backdropFilter: 'blur(8px)',
                  color: '#fff', border: '1px solid rgba(255,255,255,0.3)',
                }}>{c}</span>
              ))}
              <span style={{
                padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 700,
                background: 'rgba(255,255,255,0.2)', backdropFilter: 'blur(8px)',
                color: '#fff', border: '1px solid rgba(255,255,255,0.3)',
              }}>{restaurant.priceRange}</span>
            </div>
            <h1 style={{
              fontSize: '40px', fontWeight: 800, color: '#fff',
              letterSpacing: '-0.03em', lineHeight: 1.1, margin: 0,
              textShadow: '0 2px 12px rgba(0,0,0,0.4)',
            }}>
              {restaurant.name}
            </h1>
          </div>
        </div>
      </div>

      {/* ── Body ─────────────────────────────────────────────────── */}
      <div style={{
        maxWidth: '1140px', margin: '0 auto',
        padding: '32px 24px',
        display: 'flex', gap: '32px', alignItems: 'flex-start',
      }}>

        {/* ── Main content ── */}
        <main style={{ flex: 1, minWidth: 0 }}>

          {/* Back nav */}
          <button
            onClick={() => navigate(-1)}
            aria-label="Back to results"
            style={{
              display: 'inline-flex', alignItems: 'center', gap: '6px',
              marginBottom: '24px', padding: '8px 16px', borderRadius: '10px',
              background: '#fff', border: '1px solid var(--color-border)',
              fontSize: '13px', fontWeight: 600, color: 'var(--color-text-secondary)',
              cursor: 'pointer', boxShadow: 'var(--shadow-sm)',
              transition: 'all 120ms',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.borderColor = 'var(--color-brand)'
              e.currentTarget.style.color = 'var(--color-brand)'
            }}
            onMouseLeave={e => {
              e.currentTarget.style.borderColor = 'var(--color-border)'
              e.currentTarget.style.color = 'var(--color-text-secondary)'
            }}
          >
            ← Back to results
          </button>

          {/* Identity card */}
          <div style={{
            background: '#fff', borderRadius: '16px',
            border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)',
            padding: '24px', marginBottom: '24px',
          }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '16px', flexWrap: 'wrap' }}>
              <div>
                <h2 style={{
                  fontSize: '28px', fontWeight: 800, color: 'var(--color-text)',
                  letterSpacing: '-0.03em', marginBottom: '8px',
                }}>
                  {restaurant.name}
                </h2>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap', marginBottom: '12px' }}>
                  <StarRating rating={restaurant.recentAverageRating} count={restaurant.recentReviewCount} size="md" />
                  <OpenBadge hours={restaurant.hours} timezone={restaurant.address.timezone} />
                  {cashbackRate > 0 && <CashbackBadge rate={cashbackRate} />}
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {restaurant.cuisineNames.map(c => (
                    <span key={c} style={{
                      padding: '4px 12px', borderRadius: '8px', fontSize: '13px', fontWeight: 500,
                      background: 'var(--color-surface-raised)', border: '1px solid var(--color-border)',
                      color: 'var(--color-text-secondary)',
                    }}>{c}</span>
                  ))}
                  <span style={{
                    padding: '4px 12px', borderRadius: '8px', fontSize: '13px', fontWeight: 600,
                    background: 'var(--color-brand-light)', border: '1px solid rgba(133,41,205,0.2)',
                    color: 'var(--color-brand)',
                  }}>{restaurant.priceRange}</span>
                  {restaurant.mealPeriods.map(m => (
                    <span key={m} style={{
                      padding: '4px 12px', borderRadius: '8px', fontSize: '13px', fontWeight: 500,
                      background: 'var(--color-surface-raised)', border: '1px solid var(--color-border)',
                      color: 'var(--color-text-secondary)', textTransform: 'capitalize',
                    }}>{m}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Address & Hours */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '24px',
          }}>
            {/* Address */}
            <div style={{
              background: '#fff', borderRadius: '16px', padding: '20px',
              border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)',
            }}>
              <SectionHeading>Address</SectionHeading>
              <address style={{ fontStyle: 'normal', fontSize: '15px', color: 'var(--color-text-secondary)', lineHeight: 1.7 }}>
                {restaurant.address.street}<br />
                {restaurant.address.neighbourhood && <>{restaurant.address.neighbourhood}, </>}
                {restaurant.address.city}, {restaurant.address.state} {restaurant.address.zip}
              </address>
            </div>

            {/* Hours */}
            <div style={{
              background: '#fff', borderRadius: '16px', padding: '20px',
              border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)',
            }}>
              <SectionHeading>Hours</SectionHeading>
              <HoursSection restaurant={restaurant} />
            </div>
          </div>

          {/* Photos */}
          <div style={{
            background: '#fff', borderRadius: '16px', padding: '24px',
            border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)', marginBottom: '24px',
          }}>
            <SectionHeading>Photos</SectionHeading>
            {restaurant.photos.length > 0
              ? <PhotoGallery photos={restaurant.photos} />
              : <p style={{ fontSize: '14px', color: 'var(--color-text-muted)' }}>No photos yet — check back soon.</p>
            }
          </div>

          {/* Menu */}
          <div style={{
            background: '#fff', borderRadius: '16px', padding: '24px',
            border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)', marginBottom: '24px',
          }}>
            <SectionHeading>Menu</SectionHeading>
            {/* If mock menu items exist (delivery enabled), show orderable menu */}
            {mockMenuItems.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
                {mockMenuItems.map((item, idx) => {
                  const cartQty = cart?.items.find(i => i.menu_item_id === item.id)?.quantity ?? 0
                  return (
                    <div
                      key={item.id}
                      style={{
                        display: 'flex', alignItems: 'center', gap: '16px',
                        padding: '14px 0',
                        borderBottom: idx < mockMenuItems.length - 1 ? '1px solid var(--color-border)' : 'none',
                      }}
                    >
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '15px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '3px' }}>
                          {item.name}
                        </div>
                        <div style={{ fontSize: '13px', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                          {item.description}
                        </div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexShrink: 0 }}>
                        <span style={{
                          fontSize: '15px', fontWeight: 700, color: 'var(--color-brand)',
                          background: 'var(--color-brand-light)',
                          padding: '4px 10px', borderRadius: '8px',
                          minWidth: '52px', textAlign: 'center',
                        }}>
                          ${item.price.toFixed(2)}
                        </span>
                        {item.available && (
                          <AddToCartButton
                            quantity={cartQty}
                            itemName={item.name}
                            onAdd={() => addItem(restaurant.id, { id: item.id, name: item.name, price: item.price })}
                            onChange={(q) => changeQuantity(item.id, q)}
                          />
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <MenuDisplay menu={restaurant.menu} />
            )}
          </div>

          {/* Reviews */}
          <div style={{
            background: '#fff', borderRadius: '16px', padding: '24px',
            border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)',
          }}>
            <SectionHeading>Reviews</SectionHeading>
            <ReviewSection reviews={restaurant.reviews} restaurantId={restaurant.id} />
          </div>
        </main>

        {/* ── Sticky Sidebar ── */}
        <aside style={{
          width: '300px', flexShrink: 0, position: 'sticky', top: '80px',
        }}>
          <div style={{
            borderRadius: '20px', overflow: 'hidden',
            border: '1px solid var(--color-border)',
            boxShadow: '0 8px 32px rgba(133,41,205,0.12), 0 2px 8px rgba(0,0,0,0.06)',
          }}>
            {/* Sidebar header */}
            <div style={{
              background: 'linear-gradient(135deg, #ede9fd 0%, #d5ceff 100%)',
              padding: '20px 20px 16px',
              borderBottom: '1px solid rgba(133,41,205,0.12)',
            }}>
              <div style={{ fontSize: '17px', fontWeight: 700, color: 'var(--color-text)', marginBottom: '4px', letterSpacing: '-0.01em' }}>
                {restaurant.name}
              </div>
              <div style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                {restaurant.address.neighbourhood ? `${restaurant.address.neighbourhood}, ` : ''}{restaurant.address.city}
              </div>
              <div style={{ marginTop: '10px' }}>
                <OpenBadge hours={restaurant.hours} timezone={restaurant.address.timezone} />
              </div>
            </div>

            {/* Sidebar body */}
            <div style={{ background: '#fff', padding: '20px' }}>
              {/* Order Delivery CTA */}
              {mockMenuItems.length > 0 && (
                <>
                  <button
                    onClick={() => restaurant && openCart(restaurant.id)}
                    style={{
                      width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                      padding: '14px', borderRadius: '12px',
                      background: 'var(--color-brand)', color: '#fff',
                      border: 'none', cursor: 'pointer', fontSize: '15px', fontWeight: 700,
                      marginBottom: '8px', transition: 'background 120ms',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-brand-hover)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'var(--color-brand)')}
                  >
                    🛒 Order Delivery
                    {totalItems > 0 && (
                      <span style={{
                        background: 'rgba(255,255,255,0.25)',
                        borderRadius: '9999px', padding: '2px 8px', fontSize: '13px',
                      }}>
                        {totalItems} item{totalItems !== 1 ? 's' : ''}
                      </span>
                    )}
                  </button>
                  {cashbackRate > 0 && (
                    <div style={{ textAlign: 'center', marginBottom: '16px' }}>
                      <CashbackBadge rate={cashbackRate} />
                    </div>
                  )}
                  <div style={{ height: '1px', background: 'var(--color-border)', marginBottom: '16px' }} />
                </>
              )}

              {/* Share button */}
              <button
                onClick={handleShare}
                style={{
                  width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                  padding: '14px', borderRadius: '12px',
                  background: 'var(--color-brand)', color: '#fff',
                  border: 'none', cursor: 'pointer', fontSize: '15px', fontWeight: 700,
                  marginBottom: '12px', transition: 'background 120ms',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-dark-indigo)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'var(--color-brand)')}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
                  <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                  <path d="m8.59 13.51 6.83 3.98M15.41 6.51l-6.82 3.98"/>
                </svg>
                Share restaurant
              </button>
              <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', textAlign: 'center', marginBottom: '20px' }}>
                Copies link · or native share on mobile
              </p>

              <div style={{ height: '1px', background: 'var(--color-border)', marginBottom: '16px' }} />

              {/* Quick info */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '16px', flexShrink: 0 }}>📍</span>
                  <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>
                    {restaurant.address.street}<br />
                    {restaurant.address.city}, {restaurant.address.state}
                  </span>
                </div>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <span style={{ fontSize: '16px', flexShrink: 0 }}>🍽️</span>
                  <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                    {restaurant.cuisineNames.join(' · ')}
                  </span>
                </div>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <span style={{ fontSize: '16px', flexShrink: 0 }}>💰</span>
                  <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                    {restaurant.priceRange} · {restaurant.mealPeriods.map(m => m.charAt(0).toUpperCase() + m.slice(1)).join(', ')}
                  </span>
                </div>
                {restaurant.dietaryOptions.length > 0 && (
                  <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                    <span style={{ fontSize: '16px', flexShrink: 0 }}>🌿</span>
                    <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                      {restaurant.dietaryOptions.join(', ')}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </aside>
      </div>

      {/* Cart panel + backdrop */}
      {isOpen && restaurant && (
        <>
          <div
            onClick={closeCart}
            aria-hidden="true"
            style={{
              position: 'fixed', inset: 0,
              background: 'rgba(0,0,0,0.4)',
              zIndex: 299,
            }}
          />
          <CartPanel
            cart={cart}
            restaurantName={restaurant.name}
            cashbackRate={cashbackRate}
            onClose={closeCart}
            onCheckout={() => navigate(`/checkout/${restaurant.id}`)}
            onQuantityChange={(menuItemId, qty) => changeQuantity(menuItemId, qty)}
            onBrowse={() => navigate('/')}
          />
        </>
      )}

      {/* Toast */}
      {shareMsg && (
        <div style={{
          position: 'fixed', bottom: '32px', left: '50%', transform: 'translateX(-50%)',
          padding: '12px 24px', borderRadius: '12px',
          background: 'var(--color-dark-indigo)', color: '#fff',
          fontSize: '14px', fontWeight: 600, boxShadow: 'var(--shadow-lg)', zIndex: 200,
        }} role="status" aria-live="polite">
          {shareMsg}
        </div>
      )}
    </div>
  )
}
