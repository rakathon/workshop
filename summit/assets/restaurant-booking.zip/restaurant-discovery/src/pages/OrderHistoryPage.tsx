import { useNavigate } from 'react-router-dom'
import { OrderHistory } from '../components/order/OrderHistory'
import { LocalStorageService } from '../lib/storage'
import { useCart } from '../context/CartContext'
import { getOrCreateUser } from '../lib/storage'
import type { StoredOrder } from '../lib/storage/types'

export default function OrderHistoryPage() {
  const navigate = useNavigate()
  const { addItem } = useCart()
  const orders = LocalStorageService.getOrders()

  function handleReorder(order: StoredOrder) {
    const user = getOrCreateUser()
    // Use useCart's addItem so CartContext state is updated for checkout
    // replaceCart via localStorage first, then add each item via context
    import('../lib/cartService').then(({ cartService }) => {
      cartService.replaceCart(order.restaurant_id, user.id)
      for (const item of order.items) {
        for (let q = 0; q < item.quantity; q++) {
          addItem(order.restaurant_id, { id: item.menu_item_id, name: item.name, price: item.unit_price })
        }
      }
      navigate(`/checkout/${order.restaurant_id}`)
    })
  }

  return (
    <div style={{ minHeight: '100vh', background: '#FAFAF8' }}>
      <header style={{
        background: '#fff', borderBottom: '1px solid var(--color-border)',
        height: '64px', display: 'flex', alignItems: 'center', padding: '0 24px', gap: '16px',
        position: 'sticky', top: 0, zIndex: 50,
      }}>
        <button onClick={() => navigate('/')} style={{
          fontWeight: 800, fontSize: '20px', color: 'var(--color-brand)',
          background: 'none', border: 'none', cursor: 'pointer', letterSpacing: '-0.03em',
        }}>
          Dine<span style={{ color: 'var(--color-dark-indigo)' }}>Find</span>
        </button>
        <span style={{ fontSize: '15px', fontWeight: 600, color: 'var(--color-text-secondary)' }}>
          Order History
        </span>
      </header>

      <div style={{ maxWidth: '600px', margin: '0 auto', padding: '24px 16px' }}>
        <OrderHistory orders={orders} onReorder={handleReorder} />
      </div>
    </div>
  )
}
