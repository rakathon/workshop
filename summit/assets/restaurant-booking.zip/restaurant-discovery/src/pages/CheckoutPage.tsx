import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { CheckoutProgress, type CheckoutStep } from '../components/checkout/CheckoutProgress'
import { AddressStep } from '../components/checkout/AddressStep'
import { OrderSummary } from '../components/checkout/OrderSummary'
import { PaymentStep } from '../components/checkout/PaymentStep'
import { useCart } from '../context/CartContext'
import { LocalStorageService } from '../lib/storage'
import { computeCashback } from '../components/checkout/OrderSummary'
import { orderService } from '../lib/orderService'
import type { OrderItem } from '../lib/storage/types'

export default function CheckoutPage() {
  const { restaurantId } = useParams<{ restaurantId: string }>()
  const navigate = useNavigate()
  const { cart } = useCart()
  const [step, setStep] = useState<CheckoutStep>(1)
  const [deliveryAddress, setDeliveryAddress] = useState('')

  const mockRestaurant = restaurantId ? LocalStorageService.getRestaurantById(restaurantId) : null

  // If no cart or no restaurant, send back
  if (!cart || !mockRestaurant || !restaurantId) {
    navigate(-1)
    return null
  }

  const orderItems: OrderItem[] = cart.items.map(i => ({
    menu_item_id: i.menu_item_id,
    name: i.name,
    unit_price: i.unit_price,
    quantity: i.quantity,
    line_total: i.unit_price * i.quantity,
  }))

  return (
    <div style={{ minHeight: '100vh', background: '#FAFAF8' }}>
      {/* Header */}
      <header style={{
        background: '#fff', borderBottom: '1px solid var(--color-border)',
        height: '64px', display: 'flex', alignItems: 'center', padding: '0 24px', gap: '16px',
        position: 'sticky', top: 0, zIndex: 50, boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
      }}>
        <button onClick={() => navigate('/')} style={{
          fontWeight: 800, fontSize: '20px', color: 'var(--color-brand)',
          background: 'none', border: 'none', cursor: 'pointer', letterSpacing: '-0.03em',
        }}>
          Dine<span style={{ color: 'var(--color-dark-indigo)' }}>Find</span>
        </button>
        <span style={{ fontSize: '15px', fontWeight: 600, color: 'var(--color-text-secondary)' }}>
          Checkout
        </span>
      </header>

      {/* Main */}
      <div style={{ maxWidth: '520px', margin: '0 auto', padding: '24px 16px' }}>
        <div style={{
          background: '#fff', borderRadius: '20px',
          border: '1px solid var(--color-border)',
          boxShadow: '0 4px 24px rgba(0,0,0,0.06)',
          overflow: 'hidden',
        }}>
          <CheckoutProgress step={step} />

          {step === 1 && (
            <AddressStep
              onContinue={(addr) => { setDeliveryAddress(addr); setStep(2) }}
              onBack={() => navigate(-1)}
            />
          )}

          {step === 2 && (
            <OrderSummary
              items={orderItems}
              deliveryFee={mockRestaurant.delivery_fee}
              cashbackRatePct={mockRestaurant.cashback_rate_pct}
              deliveryAddress={deliveryAddress}
              estimatedMinutes={mockRestaurant.estimated_delivery_minutes}
              onContinue={() => setStep(3)}
              onBack={() => setStep(1)}
            />
          )}

          {step === 3 && (() => {
            const subtotal = orderItems.reduce((s, i) => s + i.unit_price * i.quantity, 0)
            const cashback = computeCashback(subtotal, mockRestaurant.cashback_rate_pct)
            const total = subtotal + mockRestaurant.delivery_fee - cashback
            return (
              <PaymentStep
                total={total}
                onPlace={(cardLastFour) => {
                  const order = orderService.createOrder({
                    cartItems: cart!.items,
                    mockRestaurant,
                    deliveryAddress,
                    cardLastFour,
                    userId: LocalStorageService.getUser()?.id ?? 'unknown',
                  })
                  navigate(`/confirmation/${order.id}`)
                }}
                onBack={() => setStep(2)}
              />
            )
          })()}
        </div>
      </div>
    </div>
  )
}
