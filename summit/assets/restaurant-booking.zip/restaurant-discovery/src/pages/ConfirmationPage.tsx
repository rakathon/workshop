import { useParams, useNavigate } from 'react-router-dom'
import { OrderConfirmation } from '../components/order/OrderConfirmation'
import { LocalStorageService } from '../lib/storage'

export default function ConfirmationPage() {
  const { orderId } = useParams<{ orderId: string }>()
  const navigate = useNavigate()
  const order = orderId ? LocalStorageService.getOrderById(orderId) : null

  if (!order) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '48px', marginBottom: '16px' }}>🔍</div>
          <p style={{ color: 'var(--color-text-muted)' }}>Order not found.</p>
          <button onClick={() => navigate('/')} style={{
            marginTop: '16px', padding: '10px 24px',
            background: 'var(--color-brand)', color: '#fff',
            border: 'none', borderRadius: '10px', cursor: 'pointer', fontWeight: 600,
          }}>Back to home</button>
        </div>
      </div>
    )
  }

  return (
    <div style={{ minHeight: '100vh', background: '#FAFAF8' }}>
      <header style={{
        background: '#fff', borderBottom: '1px solid var(--color-border)',
        height: '64px', display: 'flex', alignItems: 'center', padding: '0 24px',
        position: 'sticky', top: 0, zIndex: 50,
      }}>
        <button onClick={() => navigate('/')} style={{
          fontWeight: 800, fontSize: '20px', color: 'var(--color-brand)',
          background: 'none', border: 'none', cursor: 'pointer', letterSpacing: '-0.03em',
        }}>
          Dine<span style={{ color: 'var(--color-dark-indigo)' }}>Find</span>
        </button>
      </header>

      <div style={{ maxWidth: '480px', margin: '0 auto', padding: '24px 16px' }}>
        <div style={{
          background: '#fff', borderRadius: '20px',
          border: '1px solid var(--color-border)',
          boxShadow: '0 4px 24px rgba(0,0,0,0.06)',
          overflow: 'hidden',
        }}>
          <OrderConfirmation order={order} />
        </div>
      </div>
    </div>
  )
}
