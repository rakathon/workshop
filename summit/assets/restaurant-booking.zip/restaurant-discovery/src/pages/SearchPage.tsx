import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useFilters } from '../context/FilterContext'
import { FilterSidebar } from '../components/search/FilterSidebar'
import { RestaurantCard } from '../components/search/RestaurantCard'
import restaurantsData from '../data/restaurants.json'
import cuisinesData from '../data/cuisines.json'
import citiesData from '../data/cities.json'
import { filterRestaurants, sortRestaurants } from '../lib/filterRestaurants'
import { LocalStorageService } from '../lib/storage'
import type { Restaurant, Cuisine, City, FilterState } from '../types'

const allRestaurants = restaurantsData as Restaurant[]
const cuisines = cuisinesData as Cuisine[]
const cities = citiesData as City[]

function ActiveChips({
  filters, cuisines, onRemove, onClearAll,
}: {
  filters: FilterState
  cuisines: Cuisine[]
  onRemove: (key: keyof FilterState, value?: string) => void
  onClearAll: () => void
}) {
  const chips: { label: string; onRemove: () => void }[] = []
  filters.cuisine.forEach(id => {
    const c = cuisines.find(x => x.id === id)
    if (c) chips.push({ label: c.name, onRemove: () => onRemove('cuisine', id) })
  })
  filters.price.forEach(p => chips.push({ label: p, onRemove: () => onRemove('price', p) }))
  filters.dietary.forEach(d => chips.push({ label: d, onRemove: () => onRemove('dietary', d) }))
  if (filters.mealPeriod) chips.push({ label: filters.mealPeriod, onRemove: () => onRemove('mealPeriod') })
  if (filters.openNow) chips.push({ label: 'Open now', onRemove: () => onRemove('openNow') })
  if (!chips.length) return null

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', marginBottom: '20px' }}>
      {chips.map(chip => (
        <span key={chip.label} style={{
          display: 'inline-flex', alignItems: 'center', gap: '4px',
          padding: '5px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 600,
          background: 'var(--color-brand-light)',
          border: '1px solid var(--color-brand)',
          color: 'var(--color-brand)',
        }}>
          {chip.label}
          <button
            onClick={chip.onRemove}
            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', lineHeight: 1, color: 'var(--color-brand)', padding: '0 0 0 2px' }}
            aria-label={`Remove ${chip.label} filter`}
          >×</button>
        </span>
      ))}
      {chips.length >= 2 && (
        <button onClick={onClearAll} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          fontSize: '12px', color: 'var(--color-text-muted)', textDecoration: 'underline',
        }}>Clear all</button>
      )}
    </div>
  )
}

export default function SearchPage() {
  const navigate = useNavigate()
  const { filters, updateFilter, clearFilters } = useFilters()

  const cityName = useMemo(() => cities.find(c => c.id === filters.city)?.displayName ?? '', [filters.city])

  const results = useMemo(() => sortRestaurants(filterRestaurants(allRestaurants, {
    city: filters.city, cuisine: filters.cuisine, price: filters.price,
    dietary: filters.dietary, mealPeriod: filters.mealPeriod, openNow: filters.openNow,
  })), [filters])

  function removeFilter(key: keyof FilterState, value?: string) {
    if (key === 'cuisine' && value) updateFilter('cuisine', filters.cuisine.filter(c => c !== value))
    else if (key === 'price' && value) updateFilter('price', filters.price.filter(p => p !== value))
    else if (key === 'dietary' && value) updateFilter('dietary', filters.dietary.filter(d => d !== value))
    else if (key === 'mealPeriod') updateFilter('mealPeriod', '')
    else if (key === 'openNow') updateFilter('openNow', false)
  }

  return (
    <div style={{ minHeight: '100vh', background: '#FAFAF8', display: 'flex', flexDirection: 'column' }}>

      {/* ── Header ─────────────────────────────────────────────── */}
      <header style={{
        background: '#fff',
        borderBottom: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-sm)',
        height: '64px',
        display: 'flex',
        alignItems: 'center',
        padding: '0 24px',
        gap: '16px',
        position: 'sticky',
        top: 0,
        zIndex: 50,
      }}>
        <button onClick={() => navigate('/')} style={{
          fontWeight: 800, fontSize: '20px',
          color: 'var(--color-brand)', background: 'none', border: 'none', cursor: 'pointer',
          letterSpacing: '-0.03em', flexShrink: 0,
        }}>
          Dine<span style={{ color: 'var(--color-dark-indigo)' }}>Find</span>
        </button>

        {/* Compact search pill */}
        <div
          onClick={() => navigate('/')}
          role="button"
          tabIndex={0}
          onKeyDown={e => e.key === 'Enter' && navigate('/')}
          aria-label="Edit search"
          style={{
            flex: 1, maxWidth: '480px',
            display: 'flex', alignItems: 'center', gap: '8px',
            padding: '0 16px', borderRadius: '12px', height: '42px',
            background: '#FAFAF8', border: '1.5px solid var(--color-border)',
            cursor: 'pointer', fontSize: '14px', color: 'var(--color-text-muted)',
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <span style={{ color: 'var(--color-text)', fontWeight: 500 }}>
            {cityName || 'All cities'}
          </span>
          {filters.cuisine.length > 0 && (
            <>
              <span style={{ color: 'var(--color-border-strong)' }}>·</span>
              <span>{cuisines.find(c => c.id === filters.cuisine[0])?.name ?? ''}</span>
            </>
          )}
          <span style={{ marginLeft: 'auto', fontSize: '11px', color: 'var(--color-brand)', fontWeight: 600 }}>Edit</span>
        </div>
      </header>

      {/* ── Body ───────────────────────────────────────────────── */}
      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>

        {/* Filter sidebar */}
        <FilterSidebar cuisines={cuisines} filters={filters} onUpdate={updateFilter} onClear={clearFilters} />

        {/* Main results */}
        <main style={{ flex: 1, padding: '28px 32px', overflowY: 'auto' }}>

          {/* Results header */}
          <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px', marginBottom: '8px' }}>
            <h1 style={{ fontSize: '24px', fontWeight: 700, color: 'var(--color-text)', letterSpacing: '-0.02em' }}>
              {results.length} restaurant{results.length !== 1 ? 's' : ''}
              {cityName && <span style={{ fontWeight: 400, color: 'var(--color-text-muted)', fontSize: '18px' }}> in {cityName}</span>}
            </h1>
            <span style={{
              fontSize: '11px', fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase',
              padding: '3px 10px', borderRadius: '6px',
              background: 'var(--color-surface-raised)', border: '1px solid var(--color-border)',
              color: 'var(--color-text-secondary)',
            }}>Top rated</span>
          </div>
          <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginBottom: '20px' }}>
            Sorted by recent reviews · {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </p>

          <ActiveChips filters={filters} cuisines={cuisines} onRemove={removeFilter} onClearAll={clearFilters} />

          {/* Grid */}
          {results.length > 0 ? (
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
              gap: '24px',
            }}>
              {results.map(r => (
                <RestaurantCard
                  key={r.id}
                  restaurant={r}
                  cashbackRate={LocalStorageService.getRestaurantById(r.id)?.cashback_rate_pct}
                />
              ))}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '80px 24px', color: 'var(--color-text-secondary)' }}>
              <div style={{ fontSize: '48px', marginBottom: '16px' }}>🍽️</div>
              <h2 style={{ fontSize: '22px', fontWeight: 700, color: 'var(--color-text)', marginBottom: '8px', letterSpacing: '-0.02em' }}>
                No restaurants match your filters
              </h2>
              <p style={{ fontSize: '15px', marginBottom: '24px', color: 'var(--color-text-muted)' }}>
                Try removing a filter to see more results.
              </p>
              <button
                onClick={clearFilters}
                style={{
                  padding: '12px 28px', borderRadius: '12px',
                  background: 'var(--color-brand)', color: '#fff',
                  border: 'none', cursor: 'pointer', fontSize: '15px', fontWeight: 600,
                }}
              >
                Clear all filters
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
