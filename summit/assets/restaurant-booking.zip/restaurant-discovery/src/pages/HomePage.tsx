import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CityAutocomplete } from '../components/home/CityAutocomplete'
import citiesData from '../data/cities.json'
import cuisinesData from '../data/cuisines.json'
import type { City, Cuisine } from '../types'

const cities = citiesData as City[]
const cuisines = cuisinesData as Cuisine[]

const OCCASIONS = [
  { label: '🌅 Brunch spots', mealPeriod: 'brunch' },
  { label: '🍷 Date night', mealPeriod: 'dinner' },
  { label: '👨‍👩‍👧 Family-friendly', mealPeriod: 'lunch' },
  { label: '⚡ Quick lunch', mealPeriod: 'lunch' },
  { label: '🕐 Open late', openNow: true },
  { label: '🌿 Vegetarian', dietary: 'vegetarian' },
]

export default function HomePage() {
  const navigate = useNavigate()
  const [selectedCityId, setSelectedCityId] = useState('')
  const [selectedCityDisplay, setSelectedCityDisplay] = useState('')
  const [selectedCuisineId, setSelectedCuisineId] = useState('')
  const [locating, setLocating] = useState(false)

  function handleSearch() {
    const params = new URLSearchParams()
    if (selectedCityId) params.set('city', selectedCityId)
    if (selectedCuisineId) params.set('cuisine', selectedCuisineId)
    navigate(`/search?${params.toString()}`)
  }

  function handleUseMyLocation() {
    if (!navigator.geolocation) return
    setLocating(true)
    navigator.geolocation.getCurrentPosition(
      position => {
        setLocating(false)
        // Find the nearest city by lat/lng from cities.json (closest by Euclidean distance)
        const { latitude, longitude } = position.coords
        let nearest = cities[0]
        let minDist = Infinity
        for (const city of cities) {
          // Cities don't have lat/lng; use a simple lookup by known approximate coords
          const CITY_COORDS: Record<string, [number, number]> = {
            'city-001': [30.267, -97.743],  // Austin
            'city-002': [40.713, -74.006],  // New York
            'city-003': [41.878, -87.630],  // Chicago
            'city-004': [34.052, -118.244], // Los Angeles
            'city-005': [25.761, -80.192],  // Miami
          }
          const coords = CITY_COORDS[city.id]
          if (!coords) continue
          const dist = Math.hypot(latitude - coords[0], longitude - coords[1])
          if (dist < minDist) { minDist = dist; nearest = city }
        }
        setSelectedCityId(nearest.id)
        setSelectedCityDisplay(nearest.displayName)
      },
      () => setLocating(false),
      { timeout: 8000 }
    )
  }

  function handleOccasion(opts: { mealPeriod?: string; openNow?: boolean; dietary?: string }) {
    const params = new URLSearchParams()
    if (selectedCityId) params.set('city', selectedCityId)
    if (opts.mealPeriod) params.set('mealPeriod', opts.mealPeriod)
    if (opts.openNow) params.set('openNow', 'true')
    if (opts.dietary) params.set('dietary', opts.dietary)
    navigate(`/search?${params.toString()}`)
  }

  return (
    <div style={{ minHeight: '100vh', background: '#FAFAF8' }}>

      {/* ── Nav ───────────────────────────────────────────────── */}
      <header style={{
        background: '#fff',
        borderBottom: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-sm)',
        height: '64px',
        display: 'flex',
        alignItems: 'center',
        padding: '0 32px',
      }}>
        <a href="/" style={{
          fontWeight: 800,
          fontSize: '22px',
          color: 'var(--color-brand)',
          letterSpacing: '-0.03em',
          textDecoration: 'none',
        }}>
          Dine<span style={{ color: 'var(--color-dark-indigo)' }}>Find</span>
        </a>
        <div style={{ flex: 1 }} />
      </header>

      {/* ── Hero ──────────────────────────────────────────────── */}
      <section style={{
        background: 'linear-gradient(160deg, #ede9fd 0%, #d5ceff 60%, #c2b4ff 100%)',
        padding: '72px 24px 64px',
        textAlign: 'center',
        borderBottom: '1px solid var(--color-border)',
      }}>
        <div style={{ maxWidth: '680px', margin: '0 auto' }}>

          {/* Badge */}
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            background: 'rgba(133,41,205,0.12)',
            border: '1px solid rgba(133,41,205,0.3)',
            borderRadius: '20px',
            padding: '5px 14px',
            fontSize: '12px',
            fontWeight: 600,
            color: 'var(--color-brand)',
            marginBottom: '20px',
            letterSpacing: '0.02em',
          }}>
            <span>🍽️</span> 21 restaurants across 5 US cities
          </div>

          {/* Headline */}
          <h1 style={{
            fontSize: '52px',
            fontWeight: 800,
            color: '#1a1020',
            letterSpacing: '-0.04em',
            lineHeight: 1.1,
            marginBottom: '16px',
          }}>
            Find your next<br />
            <span style={{ color: 'var(--color-brand)' }}>favourite restaurant</span>
          </h1>

          <p style={{
            fontSize: '17px',
            color: '#5a4e72',
            marginBottom: '36px',
            lineHeight: 1.6,
          }}>
            Search across US cities — menus, photos, and reviews in one place.
          </p>

          {/* Search bar */}
          <div
            role="search"
            style={{
              display: 'flex',
              background: '#fff',
              borderRadius: '20px',
              boxShadow: '0 8px 40px rgba(133,41,205,0.20), 0 2px 12px rgba(0,0,0,0.07)',
              border: '2px solid rgba(133,41,205,0.18)',
              height: '72px',
              marginBottom: '28px',
            }}
          >
            {/* City input */}
            <div style={{ flex: '0 0 260px', display: 'flex', alignItems: 'center', gap: '10px', padding: '0 20px' }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="var(--color-brand)" strokeWidth="2" style={{ flexShrink: 0 }} aria-hidden="true">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--color-text-muted)', marginBottom: '2px' }}>Location</div>
                <CityAutocomplete
                  cities={cities}
                  value={selectedCityDisplay}
                  onChange={(id, displayName) => { setSelectedCityId(id); setSelectedCityDisplay(displayName) }}
                  placeholder="City or zip code…"
                />
              </div>
            </div>

            {/* Use my location */}
            <button
              type="button"
              onClick={handleUseMyLocation}
              disabled={locating}
              aria-label="Use my current location"
              title="Use my current location"
              style={{
                background: 'none', border: 'none', cursor: locating ? 'wait' : 'pointer',
                padding: '0 8px', flexShrink: 0, color: locating ? 'var(--color-text-muted)' : 'var(--color-brand)',
                opacity: locating ? 0.5 : 1, transition: 'opacity 120ms',
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <circle cx="12" cy="12" r="3"/>
                <path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>
                <path d="M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z" fill="currentColor" fillOpacity="0.2"/>
              </svg>
            </button>

            {/* Divider */}
            <div style={{ width: '1px', background: '#e8e3f5', margin: '16px 0', flexShrink: 0 }} />

            {/* Cuisine */}
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '10px', padding: '0 20px' }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="var(--color-brand)" strokeWidth="2" style={{ flexShrink: 0 }} aria-hidden="true">
                <path d="M3 6h18M7 12h10M11 18h2"/>
              </svg>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '10px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--color-text-muted)', marginBottom: '2px' }}>Cuisine</div>
                <select
                  value={selectedCuisineId}
                  onChange={e => setSelectedCuisineId(e.target.value)}
                  aria-label="Filter by cuisine"
                  style={{
                    background: 'transparent', border: 'none', outline: 'none',
                    fontSize: '15px', fontWeight: 500,
                    color: selectedCuisineId ? 'var(--color-text)' : '#999',
                    appearance: 'none', cursor: 'pointer', width: '100%', padding: 0,
                  }}
                >
                  <option value="">Any cuisine</option>
                  {cuisines.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
            </div>

            {/* Search btn */}
            <button
              onClick={handleSearch}
              aria-label="Search restaurants"
              style={{
                background: 'linear-gradient(135deg, var(--color-brand) 0%, #6b15b0 100%)',
                color: '#fff', border: 'none',
                padding: '0 36px',
                fontSize: '16px', fontWeight: 700,
                cursor: 'pointer', flexShrink: 0,
                letterSpacing: '0.02em',
                transition: 'opacity 120ms',
                display: 'flex', alignItems: 'center', gap: '8px',
                borderRadius: '0 18px 18px 0',
              }}
              onMouseEnter={e => (e.currentTarget.style.opacity = '0.9')}
              onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
              </svg>
              Search
            </button>
          </div>

        </div>
      </section>

      {/* ── Popular Occasions ─────────────────────────────────── */}
      <section style={{ padding: '56px 24px', maxWidth: '900px', margin: '0 auto' }}>
        <h2 style={{
          fontSize: '22px',
          fontWeight: 700,
          color: 'var(--color-text)',
          letterSpacing: '-0.02em',
          marginBottom: '20px',
        }}>
          Browse by occasion
        </h2>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
          {OCCASIONS.map(o => (
            <button
              key={o.label}
              onClick={() => handleOccasion({ mealPeriod: o.mealPeriod, openNow: o.openNow, dietary: o.dietary })}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 20px',
                borderRadius: '12px',
                border: '1.5px solid var(--color-border)',
                background: '#fff',
                color: 'var(--color-text-secondary)',
                fontSize: '14px',
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 140ms ease',
                boxShadow: 'var(--shadow-sm)',
              }}
              onMouseEnter={e => {
                const el = e.currentTarget
                el.style.borderColor = 'var(--color-brand)'
                el.style.color = 'var(--color-brand)'
                el.style.background = 'var(--color-brand-light)'
                el.style.transform = 'translateY(-2px)'
                el.style.boxShadow = 'var(--shadow-md)'
              }}
              onMouseLeave={e => {
                const el = e.currentTarget
                el.style.borderColor = 'var(--color-border)'
                el.style.color = 'var(--color-text-secondary)'
                el.style.background = '#fff'
                el.style.transform = 'translateY(0)'
                el.style.boxShadow = 'var(--shadow-sm)'
              }}
            >
              {o.label}
            </button>
          ))}
        </div>
      </section>

      {/* ── Footer ────────────────────────────────────────────── */}
      <footer style={{
        borderTop: '1px solid var(--color-border)',
        padding: '24px 32px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        background: '#fff',
        fontSize: '13px',
        color: 'var(--color-text-muted)',
      }}>
        <span>© 2026 DineFind</span>
        <div style={{ display: 'flex', gap: '20px' }}>
          <a href="#" style={{ color: 'var(--color-text-muted)', textDecoration: 'none' }}>Privacy</a>
          <a href="#" style={{ color: 'var(--color-text-muted)', textDecoration: 'none' }}>Terms</a>
          <a href="#" style={{ color: 'var(--color-text-muted)', textDecoration: 'none' }}>About</a>
        </div>
      </footer>
    </div>
  )
}
