import { Routes, Route } from 'react-router-dom'
import { FilterProvider } from './context/FilterContext'
import { CartProvider } from './context/CartContext'
import HomePage from './pages/HomePage'
import SearchPage from './pages/SearchPage'
import ListingPage from './pages/ListingPage'
import CheckoutPage from './pages/CheckoutPage'
import ConfirmationPage from './pages/ConfirmationPage'
import TrackingPage from './pages/TrackingPage'
import OrderHistoryPage from './pages/OrderHistoryPage'

export default function App() {
  return (
    <FilterProvider>
      <CartProvider>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/restaurant/:id" element={<ListingPage />} />
          <Route path="/checkout/:restaurantId" element={<CheckoutPage />} />
          <Route path="/confirmation/:orderId" element={<ConfirmationPage />} />
          <Route path="/tracking/:orderId" element={<TrackingPage />} />
          <Route path="/orders" element={<OrderHistoryPage />} />
        </Routes>
      </CartProvider>
    </FilterProvider>
  )
}
