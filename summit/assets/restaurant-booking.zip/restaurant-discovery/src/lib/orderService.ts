import { LocalStorageService } from './storage/LocalStorageService'
import { cartService } from './cartService'
import type { StoredOrder, StoredPayment, OrderItem, CartItem, OrderStatus } from './storage/types'
import type { MockRestaurant } from './storage/types'

function generateId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID()
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

interface CreateOrderParams {
  cartItems: CartItem[]
  mockRestaurant: MockRestaurant
  deliveryAddress: string
  cardLastFour: string   // full PAN never accepted — only last 4
  userId: string
}

export const orderService = {
  createOrder({
    cartItems,
    mockRestaurant,
    deliveryAddress,
    cardLastFour,
    userId,
  }: CreateOrderParams): StoredOrder {
    const now = new Date().toISOString()

    const items: OrderItem[] = cartItems.map(i => ({
      menu_item_id: i.menu_item_id,
      name: i.name,
      unit_price: i.unit_price,
      quantity: i.quantity,
      line_total: Math.round(i.unit_price * i.quantity * 100) / 100,
    }))

    const subtotal = Math.round(items.reduce((s, i) => s + i.line_total, 0) * 100) / 100
    const cashback_amount = Math.round(subtotal * mockRestaurant.cashback_rate_pct) / 100
    const total_charged = Math.round((subtotal + mockRestaurant.delivery_fee - cashback_amount) * 100) / 100

    const payment: StoredPayment = {
      id: generateId(),
      card_last_four: cardLastFour,
      status: 'mock_success',
      paid_at: now,
    }

    const order: StoredOrder = {
      id: `ORD-${Date.now()}`,
      user_id: userId,
      restaurant_id: mockRestaurant.id,
      restaurant_name: mockRestaurant.name,
      delivery_address: deliveryAddress,
      status: 'received',
      status_updated_at: now,
      estimated_delivery_minutes: mockRestaurant.estimated_delivery_minutes,
      items,
      subtotal,
      delivery_fee: mockRestaurant.delivery_fee,
      cashback_rate_pct: mockRestaurant.cashback_rate_pct,
      cashback_amount,
      total_charged,
      payment,
      created_at: now,
    }

    LocalStorageService.prependOrder(order)
    cartService.checkoutCart(mockRestaurant.id)

    return order
  },

  advanceOrderStatus(orderId: string, status: OrderStatus, updatedAt: string): void {
    LocalStorageService.updateOrderStatus(orderId, status, updatedAt)
  },

  getOrderById(orderId: string): StoredOrder | null {
    return LocalStorageService.getOrderById(orderId)
  },

  getAllOrders(): StoredOrder[] {
    return LocalStorageService.getOrders()
  },
}
