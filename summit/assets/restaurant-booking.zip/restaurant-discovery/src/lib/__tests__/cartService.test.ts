import { describe, it, expect, beforeEach, vi } from 'vitest'

// Mock LocalStorageService so cart tests don't touch real localStorage
vi.mock('../storage/LocalStorageService', () => {
  let store: Record<string, unknown> = {}
  return {
    LocalStorageService: {
      getCart: vi.fn((id: string) => store[`cart:${id}`] ?? null),
      setCart: vi.fn((cart: unknown) => { store[`cart:${(cart as { restaurant_id: string }).restaurant_id}`] = cart }),
      getRestaurantById: vi.fn((id: string) => {
        const restaurants: Record<string, unknown> = {
          'rest-001': { id: 'rest-001', name: 'Osteria Morini', cashback_rate_pct: 8, delivery_fee: 2.99, estimated_delivery_minutes: 35 },
        }
        return restaurants[id] ?? null
      }),
      _reset: () => { store = {} },
    },
  }
})

import { cartService } from '../cartService'
import { LocalStorageService } from '../storage/LocalStorageService'

const ls = LocalStorageService as unknown as { _reset: () => void }

beforeEach(() => {
  vi.clearAllMocks()
  ls._reset()
})

const MENU_ITEM = { id: 'mi-001', name: 'Margherita Pizza', price: 14.99, restaurant_id: 'rest-001' }
const MENU_ITEM_2 = { id: 'mi-002', name: 'Penne Arrabbiata', price: 12.99, restaurant_id: 'rest-001' }

describe('cartService', () => {
  describe('getOrCreateCart', () => {
    it('creates a new cart when none exists', () => {
      const cart = cartService.getOrCreateCart('rest-001', 'usr-abc')
      expect(cart.restaurant_id).toBe('rest-001')
      expect(cart.user_id).toBe('usr-abc')
      expect(cart.status).toBe('active')
      expect(cart.items).toEqual([])
      expect(LocalStorageService.setCart).toHaveBeenCalledWith(
        expect.objectContaining({ restaurant_id: 'rest-001', status: 'active' })
      )
    })

    it('returns existing active cart when one exists', () => {
      const first = cartService.getOrCreateCart('rest-001', 'usr-abc')
      const second = cartService.getOrCreateCart('rest-001', 'usr-abc')
      expect(second.id).toBe(first.id)
      expect(LocalStorageService.setCart).toHaveBeenCalledTimes(1)
    })

    it('replaces prior active cart for same restaurant', () => {
      const first = cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      const replaced = cartService.replaceCart('rest-001', 'usr-abc')
      expect(replaced.id).not.toBe(first.id)
      expect(replaced.items).toHaveLength(0)
      expect(replaced.status).toBe('active')
    })
  })

  describe('addItem', () => {
    it('adds a new item and snapshots price and name', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      const cart = cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      expect(cart.items).toHaveLength(1)
      expect(cart.items[0].name).toBe('Margherita Pizza')
      expect(cart.items[0].unit_price).toBe(14.99)
      expect(cart.items[0].quantity).toBe(1)
    })

    it('snapshotted price is independent of source menu item price change', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      // Simulate price change on source — cart item must not change
      const cart = cartService.getOrCreateCart('rest-001', 'usr-abc')
      expect(cart.items[0].unit_price).toBe(14.99)
    })

    it('increments quantity when adding same item twice', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      const cart = cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      expect(cart.items).toHaveLength(1)
      expect(cart.items[0].quantity).toBe(2)
    })
  })

  describe('updateQuantity', () => {
    it('recalculates subtotal correctly after quantity change', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc') // $14.99
      cartService.addItem('rest-001', MENU_ITEM_2, 'usr-abc') // $12.99
      const cart = cartService.updateQuantity('rest-001', 'mi-001', 2)
      // $14.99 × 2 + $12.99 × 1 = $42.97
      expect(cartService.getSubtotal(cart)).toBeCloseTo(42.97, 2)
    })

    it('removes item from cart when quantity set to zero', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      const cart = cartService.updateQuantity('rest-001', 'mi-001', 0)
      expect(cart.items).toHaveLength(0)
    })
  })

  describe('removeItem', () => {
    it('removes specified item and updates subtotal', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM_2, 'usr-abc')
      const cart = cartService.removeItem('rest-001', 'mi-001')
      expect(cart.items).toHaveLength(1)
      expect(cart.items[0].menu_item_id).toBe('mi-002')
    })
  })

  describe('getCart / absent key', () => {
    it('returns null for non-existent cart without throwing', () => {
      expect(() => cartService.getCart('rest-999')).not.toThrow()
      expect(cartService.getCart('rest-999')).toBeNull()
    })
  })

  describe('checkoutCart', () => {
    it('transitions cart status to checked_out', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
      const cart = cartService.checkoutCart('rest-001')
      expect(cart.status).toBe('checked_out')
    })
  })

  describe('getSubtotal', () => {
    it('returns 0 for empty cart', () => {
      const cart = cartService.getOrCreateCart('rest-001', 'usr-abc')
      expect(cartService.getSubtotal(cart)).toBe(0)
    })

    it('sums all item line totals correctly', () => {
      cartService.getOrCreateCart('rest-001', 'usr-abc')
      cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')   // $14.99
      cartService.addItem('rest-001', MENU_ITEM_2, 'usr-abc') // $12.99
      const cart = cartService.getCart('rest-001')!
      expect(cartService.getSubtotal(cart)).toBeCloseTo(27.98, 2)
    })
  })
})
