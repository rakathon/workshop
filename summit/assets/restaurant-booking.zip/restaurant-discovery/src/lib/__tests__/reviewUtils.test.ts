import { describe, it, expect } from 'vitest'
import { filterRecentReviews, computeRecentAverageRating, sortReviewsByDate } from '../reviewUtils'
import type { Review } from '../../types'

const makeReview = (overrides: Partial<Review> = {}): Review => ({
  id: 'rv1',
  userId: 'u1',
  userName: 'Alice',
  rating: 5,
  text: 'Great',
  reviewedAt: new Date().toISOString(),
  photoUrl: null,
  ...overrides,
})

const oneYearAgo = () => {
  const d = new Date()
  d.setFullYear(d.getFullYear() - 1)
  d.setDate(d.getDate() - 1)
  return d.toISOString()
}

const sixMonthsAgo = () => {
  const d = new Date()
  d.setMonth(d.getMonth() - 6)
  return d.toISOString()
}

describe('filterRecentReviews', () => {
  it('excludes reviews older than 12 months', () => {
    const recent = makeReview({ id: 'recent', reviewedAt: sixMonthsAgo() })
    const old = makeReview({ id: 'old', reviewedAt: oneYearAgo() })
    const result = filterRecentReviews([recent, old])
    expect(result).toHaveLength(1)
    expect(result[0].id).toBe('recent')
  })

  it('includes reviews within the past 12 months', () => {
    const r1 = makeReview({ id: 'r1', reviewedAt: sixMonthsAgo() })
    const r2 = makeReview({ id: 'r2', reviewedAt: new Date().toISOString() })
    expect(filterRecentReviews([r1, r2])).toHaveLength(2)
  })

  it('returns empty array when all reviews are old', () => {
    const old = makeReview({ reviewedAt: oneYearAgo() })
    expect(filterRecentReviews([old])).toHaveLength(0)
  })
})

describe('computeRecentAverageRating', () => {
  it('ignores old reviews when computing average', () => {
    const recent5 = makeReview({ id: 'r1', rating: 5, reviewedAt: sixMonthsAgo() })
    const recent4 = makeReview({ id: 'r2', rating: 4, reviewedAt: sixMonthsAgo() })
    const old1   = makeReview({ id: 'r3', rating: 1, reviewedAt: oneYearAgo() })
    const avg = computeRecentAverageRating([recent5, recent4, old1])
    expect(avg).toBeCloseTo(4.5)
  })

  it('returns 0 when no recent reviews', () => {
    const old = makeReview({ reviewedAt: oneYearAgo() })
    expect(computeRecentAverageRating([old])).toBe(0)
  })

  it('returns 0 for empty array', () => {
    expect(computeRecentAverageRating([])).toBe(0)
  })
})

describe('sortReviewsByDate', () => {
  it('sorts most recent first', () => {
    const old  = makeReview({ id: 'old',  reviewedAt: sixMonthsAgo() })
    const newer = makeReview({ id: 'new', reviewedAt: new Date().toISOString() })
    const result = sortReviewsByDate([old, newer])
    expect(result[0].id).toBe('new')
    expect(result[1].id).toBe('old')
  })
})
