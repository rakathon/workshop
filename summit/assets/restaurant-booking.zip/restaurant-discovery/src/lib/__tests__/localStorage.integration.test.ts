/**
 * localStorage integration tests — SC-1 through SC-12
 * Tests run against real LocalStorageService backed by jsdom's localStorage.
 * Each test clears storage in beforeEach for isolation.
 */
import { describe, it, expect, beforeEach } from 'vitest'
import { LocalStorageService } from '../storage/LocalStorageService'
import { cartService } from '../cartService'
import { orderService } from '../orderService'
import { getOrCreateUser } from '../storage'

const RESTAURANT = {
  id: 'rest-001', name: 'Osteria Morini', cuisine: 'Italian',
  cashback_rate_pct: 8, delivery_fee: 2.99, estimated_delivery_minutes: 35,
  address: '218 Lafayette St', rating: 4.6,
}
const MENU_ITEM = { id: 'mi-001', name: 'Margherita Pizza', price: 14.99 }
const MENU_ITEM_2 = { id: 'mi-002', name: 'Penne Arrabbiata', price: 12.99 }

beforeEach(() => {
  localStorage.clear()
})

describe('SC-1: Writing a new cart stores correct key and shape', () => {
  it('writes cart with correct key, user_id, restaurant_id, status=active', () => {
    const cart = cartService.getOrCreateCart('rest-001', 'usr-abc')
    const stored = LocalStorageService.getCart('rest-001')
    expect(stored).not.toBeNull()
    expect(stored!.user_id).toBe('usr-abc')
    expect(stored!.restaurant_id).toBe('rest-001')
    expect(stored!.status).toBe('active')
    expect(stored!.items).toHaveLength(0)
    expect(stored!.updated_at).toBeTruthy()
    expect(cart.id).toBe(stored!.id)
  })
})

describe('SC-2: Item prices and names are snapshotted at add-to-cart time', () => {
  it('snapshot is copied — not a live reference', () => {
    cartService.getOrCreateCart('rest-001', 'usr-abc')
    cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
    const stored = LocalStorageService.getCart('rest-001')!
    expect(stored.items[0].name).toBe('Margherita Pizza')
    expect(stored.items[0].unit_price).toBe(14.99)
  })

  it('price in cart is unaffected by later mock-catalogue changes', () => {
    cartService.getOrCreateCart('rest-001', 'usr-abc')
    cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
    // Simulate a different price in the catalogue — cart item must not change
    cartService.addItem('rest-001', { ...MENU_ITEM, price: 99.99 }, 'usr-abc')
    const stored = LocalStorageService.getCart('rest-001')!
    // quantity 2, both unit_prices should be the first snapshot
    expect(stored.items[0].unit_price).toBe(14.99)
    expect(stored.items[0].quantity).toBe(2)
  })
})

describe('SC-3: Cart status is set to checked_out when order is placed', () => {
  it('transitions status to checked_out via orderService', () => {
    cartService.getOrCreateCart('rest-001', 'usr-abc')
    cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')
    orderService.createOrder({
      cartItems: LocalStorageService.getCart('rest-001')!.items,
      mockRestaurant: RESTAURANT,
      deliveryAddress: '123 Main St',
      cardLastFour: '4242',
      userId: 'usr-abc',
    })
    const cart = LocalStorageService.getCart('rest-001')!
    expect(cart.status).toBe('checked_out')
  })
})

describe('SC-4: Order creation writes all required fields with correct calculations', () => {
  it('subtotal, delivery_fee, cashback_amount, total_charged all correct', () => {
    cartService.getOrCreateCart('rest-001', 'usr-abc')
    cartService.addItem('rest-001', MENU_ITEM, 'usr-abc')    // $14.99
    cartService.addItem('rest-001', MENU_ITEM_2, 'usr-abc')  // $12.99
    const items = LocalStorageService.getCart('rest-001')!.items

    const order = orderService.createOrder({
      cartItems: items,
      mockRestaurant: RESTAURANT,
      deliveryAddress: '123 Main St, New York, NY 10001',
      cardLastFour: '4242',
      userId: 'usr-abc',
    })

    expect(order.subtotal).toBeCloseTo(27.98, 2)
    expect(order.delivery_fee).toBe(2.99)
    expect(order.cashback_rate_pct).toBe(8)
    expect(order.cashback_amount).toBeCloseTo(2.24, 2) // 27.98 * 0.08 = 2.2384 → 2.24
    expect(order.total_charged).toBeCloseTo(28.73, 2)  // 27.98 + 2.99 - 2.24
    expect(order.delivery_address).toBe('123 Main St, New York, NY 10001')
    expect(order.status).toBe('received')
    expect(order.id).toBeTruthy()
    expect(order.created_at).toBeTruthy()
  })
})

describe('SC-5: Cashback amount is calculated correctly', () => {
  it('rate 8% — standard rounding', () => {
    cartService.getOrCreateCart('rest-001', 'u1')
    cartService.addItem('rest-001', MENU_ITEM, 'u1')   // $14.99
    cartService.addItem('rest-001', MENU_ITEM, 'u1')   // ×2 = $29.98
    cartService.addItem('rest-001', MENU_ITEM_2, 'u1') // +$12.99 = $42.97
    const items = LocalStorageService.getCart('rest-001')!.items
    const order = orderService.createOrder({ cartItems: items, mockRestaurant: RESTAURANT, deliveryAddress: 'A', cardLastFour: '1234', userId: 'u1' })
    // 42.97 × 8 / 100 = 3.4376 → Math.round(429.7 * 8) / 100 = Math.round(3437.6) / 100 = 3438/100 = 34.38? No:
    // Math.round(subtotal * ratePct) / 100 = Math.round(42.97 * 8) / 100 = Math.round(343.76) / 100 = 344/100 = 3.44
    expect(order.cashback_amount).toBe(3.44)
  })

  it('rate 3% — rounds correctly at boundary', () => {
    cartService.getOrCreateCart('rest-001', 'u1')
    // subtotal = $33.33
    cartService.addItem('rest-001', { id: 'mi-x', name: 'Item', price: 33.33 }, 'u1')
    const items = LocalStorageService.getCart('rest-001')!.items
    const restaurant3pct = { ...RESTAURANT, cashback_rate_pct: 3 }
    const order = orderService.createOrder({ cartItems: items, mockRestaurant: restaurant3pct, deliveryAddress: 'B', cardLastFour: '5678', userId: 'u1' })
    // Math.round(33.33 * 3) / 100 = Math.round(99.99) / 100 = 100/100 = 1.00
    expect(order.cashback_amount).toBe(1.00)
  })
})

describe('SC-6: Full card number is never written to localStorage', () => {
  it('card_last_four stored, full PAN absent from all storage', () => {
    cartService.getOrCreateCart('rest-001', 'u1')
    cartService.addItem('rest-001', MENU_ITEM, 'u1')
    const items = LocalStorageService.getCart('rest-001')!.items
    orderService.createOrder({ cartItems: items, mockRestaurant: RESTAURANT, deliveryAddress: 'X', cardLastFour: '4242', userId: 'u1' })

    const allStorage = JSON.stringify(Object.entries(localStorage))
    expect(allStorage).not.toContain('4242424242424242')
    const orders = LocalStorageService.getOrders()
    expect(orders[0].payment.card_last_four).toBe('4242')
    expect(orders[0].payment.card_last_four.length).toBe(4)
  })
})

describe('SC-7: Order status update overwrites only status and status_updated_at', () => {
  it('other fields unchanged after status advance', () => {
    cartService.getOrCreateCart('rest-001', 'u1')
    cartService.addItem('rest-001', MENU_ITEM, 'u1')
    const items = LocalStorageService.getCart('rest-001')!.items
    const order = orderService.createOrder({ cartItems: items, mockRestaurant: RESTAURANT, deliveryAddress: 'X', cardLastFour: '4242', userId: 'u1' })

    const before = LocalStorageService.getOrderById(order.id)!
    orderService.advanceOrderStatus(order.id, 'preparing', '2026-06-05T18:12:00Z')
    const after = LocalStorageService.getOrderById(order.id)!

    expect(after.status).toBe('preparing')
    expect(after.status_updated_at).toBe('2026-06-05T18:12:00Z')
    // Everything else must be identical
    expect(after.subtotal).toBe(before.subtotal)
    expect(after.total_charged).toBe(before.total_charged)
    expect(after.items).toEqual(before.items)
    expect(after.payment).toEqual(before.payment)
    expect(after.delivery_address).toBe(before.delivery_address)
  })
})

describe('SC-8: Orders array is prepended on new order (most recent first)', () => {
  it('second order appears at index 0', () => {
    cartService.getOrCreateCart('rest-001', 'u1')
    cartService.addItem('rest-001', MENU_ITEM, 'u1')
    const items = LocalStorageService.getCart('rest-001')!.items

    orderService.createOrder({ cartItems: items, mockRestaurant: RESTAURANT, deliveryAddress: 'A', cardLastFour: '1111', userId: 'u1' })
    cartService.replaceCart('rest-001', 'u1')
    cartService.addItem('rest-001', MENU_ITEM, 'u1')
    const items2 = LocalStorageService.getCart('rest-001')!.items
    orderService.createOrder({ cartItems: items2, mockRestaurant: RESTAURANT, deliveryAddress: 'B', cardLastFour: '2222', userId: 'u1' })

    const orders = LocalStorageService.getOrders()
    expect(orders[0].delivery_address).toBe('B')
    expect(orders[1].delivery_address).toBe('A')
  })
})

describe('SC-9: Reading a non-existent cart key returns null without error', () => {
  it('absent key returns null, no throw', () => {
    expect(() => LocalStorageService.getCart('rest-999')).not.toThrow()
    expect(LocalStorageService.getCart('rest-999')).toBeNull()
  })
})

describe('SC-10: Reading menu items for a restaurant returns correct array', () => {
  it('returns seeded menu items in display_order', () => {
    const items = [
      { id: 'mi-1', restaurant_id: 'rest-001', name: 'Pizza', description: '', price: 14.99, category: 'Mains', display_order: 1, available: true },
      { id: 'mi-2', restaurant_id: 'rest-001', name: 'Pasta', description: '', price: 12.99, category: 'Mains', display_order: 2, available: true },
    ]
    LocalStorageService.setMenu('rest-001', items)
    const result = LocalStorageService.getMenu('rest-001')
    expect(result).toHaveLength(2)
    expect(result[0].id).toBe('mi-1')
    expect(result[1].id).toBe('mi-2')
    result.forEach(item => {
      expect(item).toHaveProperty('id')
      expect(item).toHaveProperty('name')
      expect(item).toHaveProperty('price')
      expect(item).toHaveProperty('category')
      expect(item).toHaveProperty('display_order')
      expect(item).toHaveProperty('available')
    })
  })
})

describe('SC-11: User ID is generated on first visit and persisted', () => {
  it('same ID returned on subsequent reads', () => {
    const user1 = getOrCreateUser()
    const user2 = getOrCreateUser()
    expect(user1.id).toBe(user2.id)
    expect(user1.id).toMatch(/^usr_/)
  })

  it('generates a new ID if storage cleared', () => {
    const user1 = getOrCreateUser()
    localStorage.removeItem('dinefind:user')
    const user2 = getOrCreateUser()
    expect(user2.id).not.toBe(user1.id)
  })
})

describe('SC-12: New cart for same restaurant replaces prior active cart', () => {
  it('prior items not retained in replaced cart', () => {
    cartService.getOrCreateCart('rest-001', 'u1')
    cartService.addItem('rest-001', MENU_ITEM, 'u1')
    expect(LocalStorageService.getCart('rest-001')!.items).toHaveLength(1)

    cartService.replaceCart('rest-001', 'u1')
    const replaced = LocalStorageService.getCart('rest-001')!
    expect(replaced.items).toHaveLength(0)
    expect(replaced.status).toBe('active')
  })

  it('replaced cart has a new id', () => {
    const first = cartService.getOrCreateCart('rest-001', 'u1')
    const replaced = cartService.replaceCart('rest-001', 'u1')
    expect(replaced.id).not.toBe(first.id)
  })
})
