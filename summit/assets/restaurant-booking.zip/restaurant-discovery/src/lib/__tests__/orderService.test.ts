import { describe, it, expect, beforeEach, vi } from 'vitest'

vi.mock('../storage/LocalStorageService', () => {
  let orders: unknown[] = []
  let user: unknown = { id: 'usr-test', created_at: '2026-06-05T00:00:00Z' }
  return {
    LocalStorageService: {
      getOrders: vi.fn(() => [...orders]),
      prependOrder: vi.fn((o: unknown) => { orders = [o, ...orders] }),
      updateOrderStatus: vi.fn((id: string, status: string, updatedAt: string) => {
        orders = orders.map((o: unknown) => {
          const order = o as { id: string }
          return order.id === id ? { ...order, status, status_updated_at: updatedAt } : o
        })
      }),
      getOrderById: vi.fn((id: string) => (orders as { id: string }[]).find(o => o.id === id) ?? null),
      getUser: vi.fn(() => user),
      getCart: vi.fn(() => null),
      setCart: vi.fn(),
      _reset: () => { orders = [] },
    },
  }
})

vi.mock('../cartService', () => ({
  cartService: {
    checkoutCart: vi.fn(),
  },
}))

import { orderService } from '../orderService'
import { LocalStorageService } from '../storage/LocalStorageService'

const ls = LocalStorageService as unknown as { _reset: () => void }

const CART_ITEMS = [
  { id: 'ci-1', menu_item_id: 'mi-001', name: 'Margherita Pizza', unit_price: 14.99, quantity: 2 },
  { id: 'ci-2', menu_item_id: 'mi-002', name: 'Penne Arrabbiata', unit_price: 12.99, quantity: 1 },
]
const MOCK_RESTAURANT = {
  id: 'rest-001',
  name: 'Osteria Morini',
  cuisine: 'Italian',
  cashback_rate_pct: 8,
  delivery_fee: 2.99,
  estimated_delivery_minutes: 35,
  address: '218 Lafayette St',
  rating: 4.6,
}

beforeEach(() => {
  vi.clearAllMocks()
  ls._reset()
})

describe('orderService', () => {
  describe('createOrder', () => {
    it('writesCorrectShape — all required fields present', () => {
      const order = orderService.createOrder({
        cartItems: CART_ITEMS,
        mockRestaurant: MOCK_RESTAURANT,
        deliveryAddress: '123 Main St, New York, NY 10001',
        cardLastFour: '4242',
        userId: 'usr-abc',
      })
      expect(order.id).toBeTruthy()
      expect(order.restaurant_id).toBe('rest-001')
      expect(order.restaurant_name).toBe('Osteria Morini')
      expect(order.delivery_address).toBe('123 Main St, New York, NY 10001')
      expect(order.status).toBe('received')
      expect(order.payment.card_last_four).toBe('4242')
      expect(order.payment.status).toBe('mock_success')
      expect(order.created_at).toBeTruthy()
    })

    it('cashbackCalculation — subtotal × rate / 100, rounded to 2dp', () => {
      const order = orderService.createOrder({
        cartItems: CART_ITEMS, // subtotal = 14.99*2 + 12.99*1 = 42.97
        mockRestaurant: MOCK_RESTAURANT, // rate = 8%
        deliveryAddress: '123 Main St',
        cardLastFour: '4242',
        userId: 'usr-abc',
      })
      expect(order.subtotal).toBeCloseTo(42.97, 2)
      expect(order.cashback_amount).toBe(3.44) // 42.97 * 0.08 = 3.4376 → 3.44
      expect(order.total_charged).toBeCloseTo(42.52, 2) // 42.97 + 2.99 - 3.44
    })

    it('prependsToArray — new order at index 0', () => {
      orderService.createOrder({ cartItems: CART_ITEMS, mockRestaurant: MOCK_RESTAURANT, deliveryAddress: 'A', cardLastFour: '1111', userId: 'u1' })
      orderService.createOrder({ cartItems: CART_ITEMS, mockRestaurant: MOCK_RESTAURANT, deliveryAddress: 'B', cardLastFour: '2222', userId: 'u1' })
      expect(LocalStorageService.prependOrder).toHaveBeenCalledTimes(2)
      // Second call's order should have address 'B'
      const secondCall = (LocalStorageService.prependOrder as ReturnType<typeof vi.fn>).mock.calls[1][0]
      expect(secondCall.delivery_address).toBe('B')
    })

    it('storesOnlyLastFour — payment.card_last_four is 4 chars', () => {
      const order = orderService.createOrder({
        cartItems: CART_ITEMS, mockRestaurant: MOCK_RESTAURANT,
        deliveryAddress: '123 Main St', cardLastFour: '9999', userId: 'u1',
      })
      expect(order.payment.card_last_four).toBe('9999')
      expect(order.payment.card_last_four.length).toBe(4)
    })

    it('transitionsCart — cartService.checkoutCart called with restaurant id', async () => {
      const { cartService } = await import('../cartService')
      orderService.createOrder({
        cartItems: CART_ITEMS, mockRestaurant: MOCK_RESTAURANT,
        deliveryAddress: '123', cardLastFour: '4242', userId: 'u1',
      })
      expect(cartService.checkoutCart).toHaveBeenCalledWith('rest-001')
    })

    it('snapshotsOrderItems — ORDER_ITEM has line_total', () => {
      const order = orderService.createOrder({
        cartItems: CART_ITEMS, mockRestaurant: MOCK_RESTAURANT,
        deliveryAddress: '123', cardLastFour: '4242', userId: 'u1',
      })
      const pizza = order.items.find(i => i.menu_item_id === 'mi-001')!
      expect(pizza.line_total).toBeCloseTo(29.98, 2) // 14.99 * 2
      expect(pizza.name).toBe('Margherita Pizza')
      expect(pizza.unit_price).toBe(14.99)
      expect(pizza.quantity).toBe(2)
    })
  })

  describe('advanceOrderStatus', () => {
    it('mutates only status and status_updated_at', () => {
      const order = orderService.createOrder({
        cartItems: CART_ITEMS, mockRestaurant: MOCK_RESTAURANT,
        deliveryAddress: '123', cardLastFour: '4242', userId: 'u1',
      })
      orderService.advanceOrderStatus(order.id, 'preparing', '2026-06-05T18:12:00Z')
      expect(LocalStorageService.updateOrderStatus).toHaveBeenCalledWith(order.id, 'preparing', '2026-06-05T18:12:00Z')
    })
  })
})
