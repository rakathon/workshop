import { describe, it, expect, beforeEach, vi } from 'vitest'

// Use real localStorage via the InMemoryStorage polyfill from setup.ts
import { LocalStorageService } from '../storage/LocalStorageService'
import { cartService } from '../cartService'
import type { StoredOrder } from '../storage/types'

beforeEach(() => {
  localStorage.clear()
})

const PAST_ORDER: StoredOrder = {
  id: 'ORD-001',
  user_id: 'usr-1',
  restaurant_id: 'rest-001',
  restaurant_name: 'Osteria Morini',
  delivery_address: '123 Main St',
  status: 'delivered',
  status_updated_at: '2026-06-05T18:48:00Z',
  estimated_delivery_minutes: 35,
  items: [
    { menu_item_id: 'mi-001', name: 'Margherita Pizza', unit_price: 14.99, quantity: 2, line_total: 29.98 },
    { menu_item_id: 'mi-002', name: 'Penne Arrabbiata', unit_price: 12.99, quantity: 1, line_total: 12.99 },
  ],
  subtotal: 42.97,
  delivery_fee: 2.99,
  cashback_rate_pct: 8,
  cashback_amount: 3.44,
  total_charged: 42.52,
  payment: { id: 'pay-1', card_last_four: '4242', status: 'mock_success', paid_at: '2026-06-05T18:10:00Z' },
  created_at: '2026-06-05T18:10:00Z',
}

function reorderFromHistory(order: StoredOrder, userId: string) {
  cartService.replaceCart(order.restaurant_id, userId)
  for (const item of order.items) {
    for (let q = 0; q < item.quantity; q++) {
      cartService.addItem(
        order.restaurant_id,
        { id: item.menu_item_id, name: item.name, price: item.unit_price },
        userId,
      )
    }
  }
  return LocalStorageService.getCart(order.restaurant_id)!
}

describe('Re-order from history', () => {
  it('populatesCart_withPriorItems', () => {
    const cart = reorderFromHistory(PAST_ORDER, 'usr-1')
    expect(cart.items).toHaveLength(2)
    const pizza = cart.items.find(i => i.menu_item_id === 'mi-001')!
    expect(pizza.name).toBe('Margherita Pizza')
    expect(pizza.unit_price).toBe(14.99)
    expect(pizza.quantity).toBe(2)
    const pasta = cart.items.find(i => i.menu_item_id === 'mi-002')!
    expect(pasta.quantity).toBe(1)
  })

  it('navigatesToCheckout — cart is active and ready', () => {
    const cart = reorderFromHistory(PAST_ORDER, 'usr-1')
    expect(cart.status).toBe('active')
    expect(cart.restaurant_id).toBe('rest-001')
  })

  it('replacesExistingCart — prior cart items not retained', () => {
    // Pre-populate an existing cart
    cartService.getOrCreateCart('rest-001', 'usr-1')
    cartService.addItem('rest-001', { id: 'mi-999', name: 'Old Item', price: 5.00 }, 'usr-1')
    expect(LocalStorageService.getCart('rest-001')!.items).toHaveLength(1)

    // Re-order replaces it
    const cart = reorderFromHistory(PAST_ORDER, 'usr-1')
    const items = cart.items.map(i => i.menu_item_id)
    expect(items).not.toContain('mi-999')
    expect(items).toContain('mi-001')
    expect(items).toContain('mi-002')
  })

  it('addItem calls increment quantity when same item re-added', () => {
    const cart = reorderFromHistory(PAST_ORDER, 'usr-1')
    // Margherita was qty 2 in the order — after reorder it should be 2
    const pizza = cart.items.find(i => i.menu_item_id === 'mi-001')!
    expect(pizza.quantity).toBe(2)
  })
})
