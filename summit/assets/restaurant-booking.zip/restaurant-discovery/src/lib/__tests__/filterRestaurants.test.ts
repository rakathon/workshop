import { describe, it, expect, beforeEach, vi } from 'vitest'
import { filterRestaurants, sortRestaurants } from '../filterRestaurants'
import type { Restaurant } from '../../types'

const makeRestaurant = (overrides: Partial<Restaurant> = {}): Restaurant => ({
  id: 'r1',
  slug: 'test-restaurant',
  name: 'Test Restaurant',
  cityId: 'city-001',
  address: {
    street: '123 Main St',
    neighbourhood: 'Downtown',
    city: 'Austin',
    state: 'TX',
    zip: '78701',
    lat: 30.27,
    lng: -97.74,
    timezone: 'America/Chicago',
  },
  cuisineIds: ['cu-001'],
  cuisineNames: ['Thai'],
  priceRange: '$$',
  dietaryOptions: ['vegetarian'],
  mealPeriods: ['lunch', 'dinner'],
  coverPhoto: '/img/cover.jpg',
  isComplete: true,
  averageRating: 4.5,
  recentAverageRating: 4.5,
  reviewCount: 3,
  recentReviewCount: 3,
  hours: {
    monday:    { open: '11:00', close: '22:00' },
    tuesday:   { open: '11:00', close: '22:00' },
    wednesday: { open: '11:00', close: '22:00' },
    thursday:  { open: '11:00', close: '22:00' },
    friday:    { open: '11:00', close: '23:00' },
    saturday:  { open: '12:00', close: '23:00' },
    sunday:    { open: '12:00', close: '21:00' },
  },
  photos: [
    { id: 'p1', url: '/img/1.jpg', alt: 'Photo 1', sortOrder: 1 },
    { id: 'p2', url: '/img/2.jpg', alt: 'Photo 2', sortOrder: 2 },
    { id: 'p3', url: '/img/3.jpg', alt: 'Photo 3', sortOrder: 3 },
  ],
  menu: {
    lastUpdated: '2026-05-01',
    sections: [{ id: 's1', name: 'Mains', position: 1, items: [{ id: 'i1', name: 'Pad Thai', description: 'Noodles', price: 18 }] }],
  },
  reviews: [
    { id: 'rv1', userId: 'u1', userName: 'Alice', rating: 5, text: 'Great', reviewedAt: '2026-04-01T12:00:00Z', photoUrl: null },
    { id: 'rv2', userId: 'u2', userName: 'Bob', rating: 4, text: 'Good', reviewedAt: '2026-03-01T12:00:00Z', photoUrl: null },
  ],
  ...overrides,
})

describe('filterRestaurants', () => {
  describe('filterByCity', () => {
    it('returns only restaurants with matching cityId', () => {
      const r1 = makeRestaurant({ id: 'r1', cityId: 'city-001' })
      const r2 = makeRestaurant({ id: 'r2', cityId: 'city-002' })
      const result = filterRestaurants([r1, r2], { city: 'city-001' })
      expect(result).toHaveLength(1)
      expect(result[0].id).toBe('r1')
    })

    it('returns all restaurants when city filter is empty', () => {
      const r1 = makeRestaurant({ id: 'r1', cityId: 'city-001' })
      const r2 = makeRestaurant({ id: 'r2', cityId: 'city-002' })
      const result = filterRestaurants([r1, r2], { city: '' })
      expect(result).toHaveLength(2)
    })
  })

  describe('filterByCuisine', () => {
    it('returns restaurants matching any selected cuisine ID', () => {
      const r1 = makeRestaurant({ id: 'r1', cuisineIds: ['cu-001'] })
      const r2 = makeRestaurant({ id: 'r2', cuisineIds: ['cu-002'] })
      const r3 = makeRestaurant({ id: 'r3', cuisineIds: ['cu-003'] })
      const result = filterRestaurants([r1, r2, r3], { cuisine: ['cu-001', 'cu-002'] })
      expect(result).toHaveLength(2)
      expect(result.map(r => r.id)).toEqual(expect.arrayContaining(['r1', 'r2']))
    })

    it('returns all when no cuisines selected', () => {
      const r1 = makeRestaurant({ id: 'r1' })
      const r2 = makeRestaurant({ id: 'r2' })
      expect(filterRestaurants([r1, r2], { cuisine: [] })).toHaveLength(2)
    })
  })

  describe('filterByPriceRange', () => {
    it('returns only restaurants with exact matching price range', () => {
      const r1 = makeRestaurant({ id: 'r1', priceRange: '$' })
      const r2 = makeRestaurant({ id: 'r2', priceRange: '$$' })
      const r3 = makeRestaurant({ id: 'r3', priceRange: '$$$' })
      const result = filterRestaurants([r1, r2, r3], { price: ['$$'] })
      expect(result).toHaveLength(1)
      expect(result[0].id).toBe('r2')
    })
  })

  describe('filterByDietary', () => {
    it('requires ALL selected dietary options to be present', () => {
      const r1 = makeRestaurant({ id: 'r1', dietaryOptions: ['vegetarian', 'vegan'] })
      const r2 = makeRestaurant({ id: 'r2', dietaryOptions: ['vegetarian'] })
      const result = filterRestaurants([r1, r2], { dietary: ['vegetarian', 'vegan'] })
      expect(result).toHaveLength(1)
      expect(result[0].id).toBe('r1')
    })
  })

  describe('filterByMealPeriod', () => {
    it('returns restaurants containing the selected meal period', () => {
      const r1 = makeRestaurant({ id: 'r1', mealPeriods: ['lunch', 'dinner'] })
      const r2 = makeRestaurant({ id: 'r2', mealPeriods: ['breakfast', 'brunch'] })
      const result = filterRestaurants([r1, r2], { mealPeriod: 'lunch' })
      expect(result).toHaveLength(1)
      expect(result[0].id).toBe('r1')
    })

    it('returns all when no meal period selected', () => {
      const r1 = makeRestaurant({ id: 'r1' })
      const r2 = makeRestaurant({ id: 'r2' })
      expect(filterRestaurants([r1, r2], { mealPeriod: '' })).toHaveLength(2)
    })
  })

  describe('openNowFilter', () => {
    it('uses the restaurant timezone not the browser timezone', () => {
      // Thursday 21:30 UTC = 16:30 US/Eastern = 15:30 US/Central
      // A Chicago restaurant open 11:00-22:00 should still be open at 15:30 CT
      const mockDate = new Date('2026-06-04T21:30:00Z') // Thursday
      vi.setSystemTime(mockDate)

      const r = makeRestaurant({
        hours: { ...makeRestaurant().hours, thursday: { open: '11:00', close: '22:00' } },
        address: { ...makeRestaurant().address, timezone: 'America/Chicago' },
      })
      const result = filterRestaurants([r], { openNow: true })
      expect(result).toHaveLength(1)

      vi.useRealTimers()
    })

    it('excludes restaurants with no hours data for the current day', () => {
      vi.useFakeTimers()
      const mockDate = new Date('2026-06-01T15:00:00Z') // Monday
      vi.setSystemTime(mockDate)

      const r = makeRestaurant({
        hours: {
          monday: null,
          tuesday: { open: '11:00', close: '22:00' },
          wednesday: null,
          thursday: null,
          friday: null,
          saturday: null,
          sunday: null,
        },
      })
      const result = filterRestaurants([r], { openNow: true })
      expect(result).toHaveLength(0)

      vi.useRealTimers()
    })
  })

  describe('multipleFilters', () => {
    it('applies all active filters as AND conditions', () => {
      const r1 = makeRestaurant({ id: 'r1', cityId: 'city-001', cuisineIds: ['cu-001'], priceRange: '$$', dietaryOptions: ['vegetarian'] })
      const r2 = makeRestaurant({ id: 'r2', cityId: 'city-001', cuisineIds: ['cu-001'], priceRange: '$$$', dietaryOptions: ['vegetarian'] })
      const r3 = makeRestaurant({ id: 'r3', cityId: 'city-002', cuisineIds: ['cu-001'], priceRange: '$$', dietaryOptions: ['vegetarian'] })
      const result = filterRestaurants([r1, r2, r3], {
        city: 'city-001',
        cuisine: ['cu-001'],
        price: ['$$'],
        dietary: ['vegetarian'],
      })
      expect(result).toHaveLength(1)
      expect(result[0].id).toBe('r1')
    })
  })
})

describe('sortRestaurants', () => {
  it('sorts by recentAverageRating descending', () => {
    const r1 = makeRestaurant({ id: 'r1', recentAverageRating: 4.2, recentReviewCount: 10 })
    const r2 = makeRestaurant({ id: 'r2', recentAverageRating: 4.8, recentReviewCount: 5 })
    const r3 = makeRestaurant({ id: 'r3', recentAverageRating: 4.5, recentReviewCount: 8 })
    const result = sortRestaurants([r1, r2, r3])
    expect(result.map(r => r.id)).toEqual(['r2', 'r3', 'r1'])
  })

  it('uses recentReviewCount as secondary sort for ties', () => {
    const r1 = makeRestaurant({ id: 'r1', recentAverageRating: 4.5, recentReviewCount: 3 })
    const r2 = makeRestaurant({ id: 'r2', recentAverageRating: 4.5, recentReviewCount: 10 })
    const result = sortRestaurants([r1, r2])
    expect(result.map(r => r.id)).toEqual(['r2', 'r1'])
  })

  it('sorts incomplete listings to the bottom', () => {
    const complete = makeRestaurant({ id: 'r1', isComplete: true, recentAverageRating: 3.0 })
    const incomplete = makeRestaurant({ id: 'r2', isComplete: false, recentAverageRating: 4.9 })
    const result = sortRestaurants([incomplete, complete])
    expect(result[0].id).toBe('r1')
    expect(result[1].id).toBe('r2')
  })
})
