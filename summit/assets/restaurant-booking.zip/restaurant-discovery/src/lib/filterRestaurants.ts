import type { Restaurant, DayOfWeek } from '../types'

export interface FilterOptions {
  city?: string
  neighbourhood?: string
  cuisine?: string[]
  price?: string[]
  dietary?: string[]
  mealPeriod?: string
  openNow?: boolean
  query?: string
}

const DAYS: DayOfWeek[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

function isOpenNow(restaurant: Restaurant): boolean {
  const { timezone } = restaurant.address
  const now = new Date()

  // Get current time in restaurant's timezone
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    weekday: 'long',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  })

  const parts = formatter.formatToParts(now)
  const weekday = parts.find(p => p.type === 'weekday')?.value?.toLowerCase() as DayOfWeek
  const hourPart = parts.find(p => p.type === 'hour')?.value ?? '00'
  const minutePart = parts.find(p => p.type === 'minute')?.value ?? '00'

  const dayIndex = DAYS.indexOf(weekday)
  if (dayIndex === -1) return false

  const dayHours = restaurant.hours[weekday]
  if (!dayHours) return false

  const currentMinutes = parseInt(hourPart, 10) * 60 + parseInt(minutePart, 10)
  const [openH, openM] = dayHours.open.split(':').map(Number)
  const [closeH, closeM] = dayHours.close.split(':').map(Number)
  const openMinutes = openH * 60 + openM
  const closeMinutes = closeH * 60 + closeM

  return currentMinutes >= openMinutes && currentMinutes < closeMinutes
}

export function filterRestaurants(restaurants: Restaurant[], options: FilterOptions): Restaurant[] {
  const { city, neighbourhood, cuisine, price, dietary, mealPeriod, openNow, query } = options

  return restaurants.filter(r => {
    if (city && r.cityId !== city) return false
    if (neighbourhood && r.address.neighbourhood.toLowerCase() !== neighbourhood.toLowerCase()) return false
    if (cuisine && cuisine.length > 0 && !cuisine.some(c => r.cuisineIds.includes(c))) return false
    if (price && price.length > 0 && !price.includes(r.priceRange)) return false
    if (dietary && dietary.length > 0 && !dietary.every(d => r.dietaryOptions.includes(d))) return false
    if (mealPeriod && !r.mealPeriods.includes(mealPeriod)) return false
    if (openNow && !isOpenNow(r)) return false
    if (query && !r.name.toLowerCase().includes(query.toLowerCase())) return false
    return true
  })
}

export function sortRestaurants(restaurants: Restaurant[]): Restaurant[] {
  return [...restaurants].sort((a, b) => {
    // Incomplete listings always go to the bottom
    if (a.isComplete !== b.isComplete) return a.isComplete ? -1 : 1
    // Primary: recentAverageRating descending
    if (b.recentAverageRating !== a.recentAverageRating) return b.recentAverageRating - a.recentAverageRating
    // Secondary: recentReviewCount descending
    return b.recentReviewCount - a.recentReviewCount
  })
}
