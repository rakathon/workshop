import type { Review } from '../types'

const TWELVE_MONTHS_MS = 365 * 24 * 60 * 60 * 1000

export function filterRecentReviews(reviews: Review[]): Review[] {
  const cutoff = Date.now() - TWELVE_MONTHS_MS
  return reviews.filter(r => new Date(r.reviewedAt).getTime() > cutoff)
}

export function computeRecentAverageRating(reviews: Review[]): number {
  const recent = filterRecentReviews(reviews)
  if (recent.length === 0) return 0
  const sum = recent.reduce((acc, r) => acc + r.rating, 0)
  return Math.round((sum / recent.length) * 10) / 10
}

export function sortReviewsByDate(reviews: Review[]): Review[] {
  return [...reviews].sort(
    (a, b) => new Date(b.reviewedAt).getTime() - new Date(a.reviewedAt).getTime()
  )
}
