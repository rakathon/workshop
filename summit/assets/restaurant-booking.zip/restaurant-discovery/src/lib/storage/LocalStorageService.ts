import type {
  StoredUser,
  StoredCart,
  StoredOrder,
  MockRestaurant,
  MockMenuItem,
} from './types'

const NS = 'dinefind'

const keys = {
  user: `${NS}:user`,
  cart: (restaurantId: string) => `${NS}:cart:${restaurantId}`,
  orders: `${NS}:orders`,
  restaurants: `${NS}:restaurants`,
  menu: (restaurantId: string) => `${NS}:menu:${restaurantId}`,
  version: `${NS}:_version`,
} as const

const SCHEMA_VERSION = 1

function read<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch {
    return null
  }
}

function write<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value))
}

export const LocalStorageService = {
  // ── User ──────────────────────────────────────────────────────────────────
  getUser(): StoredUser | null {
    return read<StoredUser>(keys.user)
  },
  setUser(user: StoredUser): void {
    write(keys.user, user)
  },

  // ── Cart ──────────────────────────────────────────────────────────────────
  getCart(restaurantId: string): StoredCart | null {
    return read<StoredCart>(keys.cart(restaurantId))
  },
  setCart(cart: StoredCart): void {
    write(keys.cart(cart.restaurant_id), cart)
  },

  // ── Orders ────────────────────────────────────────────────────────────────
  getOrders(): StoredOrder[] {
    return read<StoredOrder[]>(keys.orders) ?? []
  },
  prependOrder(order: StoredOrder): void {
    const existing = this.getOrders()
    write(keys.orders, [order, ...existing])
  },
  updateOrderStatus(
    orderId: string,
    status: StoredOrder['status'],
    updatedAt: string,
  ): void {
    const orders = this.getOrders()
    const idx = orders.findIndex((o) => o.id === orderId)
    if (idx === -1) return
    orders[idx] = { ...orders[idx], status, status_updated_at: updatedAt }
    write(keys.orders, orders)
  },
  getOrderById(orderId: string): StoredOrder | null {
    return this.getOrders().find((o) => o.id === orderId) ?? null
  },

  // ── Restaurants (mock catalogue) ──────────────────────────────────────────
  getRestaurants(): MockRestaurant[] {
    return read<MockRestaurant[]>(keys.restaurants) ?? []
  },
  setRestaurants(restaurants: MockRestaurant[]): void {
    write(keys.restaurants, restaurants)
  },
  getRestaurantById(id: string): MockRestaurant | null {
    return this.getRestaurants().find((r) => r.id === id) ?? null
  },

  // ── Menu (mock, per restaurant) ───────────────────────────────────────────
  getMenu(restaurantId: string): MockMenuItem[] {
    return read<MockMenuItem[]>(keys.menu(restaurantId)) ?? []
  },
  setMenu(restaurantId: string, items: MockMenuItem[]): void {
    write(keys.menu(restaurantId), items)
  },

  // ── Schema version ────────────────────────────────────────────────────────
  getSchemaVersion(): number {
    return read<number>(keys.version) ?? 0
  },
  setSchemaVersion(v: number): void {
    write(keys.version, v)
  },
  isSeeded(): boolean {
    return this.getSchemaVersion() >= SCHEMA_VERSION
  },
  markSeeded(): void {
    this.setSchemaVersion(SCHEMA_VERSION)
  },
}
