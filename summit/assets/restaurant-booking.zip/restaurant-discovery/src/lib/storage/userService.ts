import { LocalStorageService } from './LocalStorageService'
import type { StoredUser } from './types'

function generateId(): string {
  // crypto.randomUUID() is available in all modern browsers
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return `usr_${crypto.randomUUID()}`
  }
  // Fallback for test environments without crypto.randomUUID
  return `usr_${Date.now()}_${Math.random().toString(36).slice(2)}`
}

export function getOrCreateUser(): StoredUser {
  const existing = LocalStorageService.getUser()
  if (existing) return existing

  const user: StoredUser = {
    id: generateId(),
    created_at: new Date().toISOString(),
  }
  LocalStorageService.setUser(user)
  return user
}
