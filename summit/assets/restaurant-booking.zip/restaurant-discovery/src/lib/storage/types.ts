// localStorage schema types — mirrors spec/storage/localstorage.md

export interface StoredUser {
  id: string
  created_at: string
}

export interface CartItem {
  id: string
  menu_item_id: string
  name: string       // snapshot at add time
  unit_price: number // snapshot at add time
  quantity: number
}

export type CartStatus = 'active' | 'checked_out' | 'abandoned'

export interface StoredCart {
  id: string
  user_id: string
  restaurant_id: string
  status: CartStatus
  items: CartItem[]
  updated_at: string
}

export type OrderStatus = 'received' | 'preparing' | 'out_for_delivery' | 'delivered'

export interface OrderItem {
  menu_item_id: string
  name: string       // snapshot at order time
  unit_price: number // snapshot at order time
  quantity: number
  line_total: number
}

export interface StoredPayment {
  id: string
  card_last_four: string // only last 4 digits — full PAN never stored
  status: 'mock_success'
  paid_at: string
}

export interface StoredOrder {
  id: string
  user_id: string
  restaurant_id: string
  restaurant_name: string  // snapshot
  delivery_address: string
  status: OrderStatus
  status_updated_at: string
  estimated_delivery_minutes: number
  items: OrderItem[]
  subtotal: number
  delivery_fee: number
  cashback_rate_pct: number
  cashback_amount: number
  total_charged: number
  payment: StoredPayment
  created_at: string
}

export interface MockRestaurant {
  id: string
  name: string
  cuisine: string
  cashback_rate_pct: number
  address: string
  rating: number
  delivery_fee: number
  estimated_delivery_minutes: number
}

export interface MockMenuItem {
  id: string
  restaurant_id: string
  name: string
  description: string
  price: number
  category: string
  display_order: number
  available: boolean
}
