import type { MockRestaurant, MockMenuItem } from './types'
import { LocalStorageService } from './LocalStorageService'

const MOCK_RESTAURANTS: MockRestaurant[] = [
  {
    id: 'rest-001',
    name: 'Osteria Morini',
    cuisine: 'Italian',
    cashback_rate_pct: 8,
    address: '218 Lafayette St, New York, NY 10012',
    rating: 4.6,
    delivery_fee: 2.99,
    estimated_delivery_minutes: 35,
  },
  {
    id: 'rest-002',
    name: 'Xi\'an Famous Foods',
    cuisine: 'Chinese',
    cashback_rate_pct: 10,
    address: '81 St. Marks Pl, New York, NY 10003',
    rating: 4.4,
    delivery_fee: 1.99,
    estimated_delivery_minutes: 30,
  },
  {
    id: 'rest-003',
    name: 'Tacos El Bronco',
    cuisine: 'Mexican',
    cashback_rate_pct: 5,
    address: '86 Roosevelt Ave, Jackson Heights, NY 11372',
    rating: 4.7,
    delivery_fee: 2.49,
    estimated_delivery_minutes: 40,
  },
  {
    id: 'rest-004',
    name: 'Nobu New York',
    cuisine: 'Japanese',
    cashback_rate_pct: 3,
    address: '105 Hudson St, New York, NY 10013',
    rating: 4.8,
    delivery_fee: 4.99,
    estimated_delivery_minutes: 45,
  },
  {
    id: 'rest-005',
    name: 'Shake Shack Madison Square Park',
    cuisine: 'American',
    cashback_rate_pct: 7,
    address: 'Madison Ave & E 23rd St, New York, NY 10010',
    rating: 4.3,
    delivery_fee: 1.99,
    estimated_delivery_minutes: 25,
  },
]

const MOCK_MENUS: Record<string, MockMenuItem[]> = {
  'rest-001': [
    { id: 'mi-001-1', restaurant_id: 'rest-001', name: 'Tagliatelle al Ragù', description: 'Hand-rolled pasta, slow-braised Bolognese, Parmigiano', price: 24.00, category: 'Pasta', display_order: 1, available: true },
    { id: 'mi-001-2', restaurant_id: 'rest-001', name: 'Margherita Pizza', description: 'San Marzano tomato, fresh mozzarella, basil', price: 18.00, category: 'Pizza', display_order: 2, available: true },
    { id: 'mi-001-3', restaurant_id: 'rest-001', name: 'Penne Arrabbiata', description: 'Spicy tomato, garlic, chilli, penne pasta', price: 16.00, category: 'Pasta', display_order: 3, available: true },
    { id: 'mi-001-4', restaurant_id: 'rest-001', name: 'Bruschetta al Pomodoro', description: 'Grilled bread, ripe tomatoes, garlic, basil', price: 12.00, category: 'Starters', display_order: 4, available: true },
    { id: 'mi-001-5', restaurant_id: 'rest-001', name: 'Tiramisu', description: 'Mascarpone, espresso-soaked ladyfingers, cocoa', price: 10.00, category: 'Desserts', display_order: 5, available: true },
  ],
  'rest-002': [
    { id: 'mi-002-1', restaurant_id: 'rest-002', name: 'Spicy Cumin Lamb Noodles', description: 'Hand-ripped noodles, cumin-spiced lamb, chilli oil', price: 16.50, category: 'Noodles', display_order: 1, available: true },
    { id: 'mi-002-2', restaurant_id: 'rest-002', name: 'Pork & Chive Dumplings', description: 'Steamed, 6 pieces', price: 9.50, category: 'Dumplings', display_order: 2, available: true },
    { id: 'mi-002-3', restaurant_id: 'rest-002', name: 'Stewed Oxtail Noodles', description: 'Slow-braised oxtail, rich broth, wide noodles', price: 19.00, category: 'Noodles', display_order: 3, available: true },
    { id: 'mi-002-4', restaurant_id: 'rest-002', name: 'Liang Pi Cold Noodles', description: 'Cold wheat noodles, sesame paste, chilli', price: 11.00, category: 'Noodles', display_order: 4, available: true },
  ],
  'rest-003': [
    { id: 'mi-003-1', restaurant_id: 'rest-003', name: 'Al Pastor Taco', description: 'Marinated pork, pineapple, cilantro, onion', price: 4.50, category: 'Tacos', display_order: 1, available: true },
    { id: 'mi-003-2', restaurant_id: 'rest-003', name: 'Carne Asada Taco', description: 'Grilled skirt steak, salsa verde, lime', price: 5.00, category: 'Tacos', display_order: 2, available: true },
    { id: 'mi-003-3', restaurant_id: 'rest-003', name: 'Quesadilla de Rajas', description: 'Roasted poblano, Oaxacan cheese, crema', price: 9.00, category: 'Quesadillas', display_order: 3, available: true },
    { id: 'mi-003-4', restaurant_id: 'rest-003', name: 'Horchata', description: 'Rice milk, cinnamon, vanilla — 16oz', price: 3.50, category: 'Drinks', display_order: 4, available: true },
  ],
  'rest-004': [
    { id: 'mi-004-1', restaurant_id: 'rest-004', name: 'Black Cod with Miso', description: 'Marinated 2 days in sweet white miso', price: 42.00, category: 'Mains', display_order: 1, available: true },
    { id: 'mi-004-2', restaurant_id: 'rest-004', name: 'Yellowtail Sashimi with Jalapeño', description: '6 pieces, yuzu soy, micro cilantro', price: 28.00, category: 'Sashimi', display_order: 2, available: true },
    { id: 'mi-004-3', restaurant_id: 'rest-004', name: 'Edamame', description: 'Salted, steamed', price: 8.00, category: 'Starters', display_order: 3, available: true },
    { id: 'mi-004-4', restaurant_id: 'rest-004', name: 'Rock Shrimp Tempura', description: 'Crispy battered shrimp, creamy spicy sauce', price: 24.00, category: 'Starters', display_order: 4, available: true },
  ],
  'rest-005': [
    { id: 'mi-005-1', restaurant_id: 'rest-005', name: 'ShackBurger', description: 'Cheeseburger with lettuce, tomato, ShackSauce', price: 9.29, category: 'Burgers', display_order: 1, available: true },
    { id: 'mi-005-2', restaurant_id: 'rest-005', name: 'SmokeShack', description: 'Bacon, cherry pepper relish, ShackSauce', price: 10.99, category: 'Burgers', display_order: 2, available: true },
    { id: 'mi-005-3', restaurant_id: 'rest-005', name: 'Cheese Fries', description: 'Crinkle-cut fries, Cheddar sauce', price: 5.29, category: 'Fries', display_order: 3, available: true },
    { id: 'mi-005-4', restaurant_id: 'rest-005', name: 'Vanilla Shake', description: 'Hand-spun vanilla custard milkshake', price: 6.99, category: 'Shakes', display_order: 4, available: true },
  ],
}

export function seedMockData(): void {
  if (LocalStorageService.isSeeded()) return

  LocalStorageService.setRestaurants(MOCK_RESTAURANTS)
  for (const [restaurantId, items] of Object.entries(MOCK_MENUS)) {
    LocalStorageService.setMenu(restaurantId, items)
  }
  LocalStorageService.markSeeded()
}
