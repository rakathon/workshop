import { LocalStorageService } from './storage/LocalStorageService'
import type { StoredCart, CartItem } from './storage/types'

function uuid(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID()
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

function now(): string {
  return new Date().toISOString()
}

interface MenuItemRef {
  id: string
  name: string
  price: number
  restaurant_id?: string
}

function makeCart(restaurantId: string, userId: string): StoredCart {
  return {
    id: uuid(),
    user_id: userId,
    restaurant_id: restaurantId,
    status: 'active',
    items: [],
    updated_at: now(),
  }
}

function save(cart: StoredCart): StoredCart {
  const updated = { ...cart, updated_at: now() }
  LocalStorageService.setCart(updated)
  return updated
}

export const cartService = {
  getCart(restaurantId: string): StoredCart | null {
    return LocalStorageService.getCart(restaurantId)
  },

  getOrCreateCart(restaurantId: string, userId: string): StoredCart {
    const existing = LocalStorageService.getCart(restaurantId)
    if (existing && existing.status === 'active') return existing
    const cart = makeCart(restaurantId, userId)
    LocalStorageService.setCart(cart)
    return cart
  },

  replaceCart(restaurantId: string, userId: string): StoredCart {
    const cart = makeCart(restaurantId, userId)
    LocalStorageService.setCart(cart)
    return cart
  },

  addItem(restaurantId: string, item: MenuItemRef, userId: string): StoredCart {
    const cart = this.getOrCreateCart(restaurantId, userId)
    const idx = cart.items.findIndex((i) => i.menu_item_id === item.id)
    let items: CartItem[]
    if (idx >= 0) {
      items = cart.items.map((i, n) =>
        n === idx ? { ...i, quantity: i.quantity + 1 } : i
      )
    } else {
      const newItem: CartItem = {
        id: uuid(),
        menu_item_id: item.id,
        name: item.name,       // snapshot
        unit_price: item.price, // snapshot
        quantity: 1,
      }
      items = [...cart.items, newItem]
    }
    return save({ ...cart, items })
  },

  updateQuantity(restaurantId: string, menuItemId: string, quantity: number): StoredCart {
    const cart = LocalStorageService.getCart(restaurantId)
    if (!cart) throw new Error(`No cart for restaurant ${restaurantId}`)
    const items =
      quantity <= 0
        ? cart.items.filter((i) => i.menu_item_id !== menuItemId)
        : cart.items.map((i) =>
            i.menu_item_id === menuItemId ? { ...i, quantity } : i
          )
    return save({ ...cart, items })
  },

  removeItem(restaurantId: string, menuItemId: string): StoredCart {
    const cart = LocalStorageService.getCart(restaurantId)
    if (!cart) throw new Error(`No cart for restaurant ${restaurantId}`)
    return save({ ...cart, items: cart.items.filter((i) => i.menu_item_id !== menuItemId) })
  },

  checkoutCart(restaurantId: string): StoredCart {
    const cart = LocalStorageService.getCart(restaurantId)
    if (!cart) throw new Error(`No cart for restaurant ${restaurantId}`)
    return save({ ...cart, status: 'checked_out' })
  },

  getSubtotal(cart: StoredCart): number {
    return cart.items.reduce((sum, i) => sum + i.unit_price * i.quantity, 0)
  },
}
