import cities from '../src/data/cities.json' assert { type: 'json' }
import cuisines from '../src/data/cuisines.json' assert { type: 'json' }
import restaurants from '../src/data/restaurants.json' assert { type: 'json' }
import users from '../src/data/users.json' assert { type: 'json' }

const VALID_PRICE_RANGES = ['$', '$$', '$$$', '$$$$']
const VALID_MEAL_PERIODS = ['breakfast', 'brunch', 'lunch', 'dinner']
const VALID_DIETARY = ['vegetarian', 'vegan', 'gluten-free']
const TWELVE_MONTHS_AGO = new Date()
TWELVE_MONTHS_AGO.setFullYear(TWELVE_MONTHS_AGO.getFullYear() - 1)

const errors: string[] = []

const cityIds = new Set(cities.map((c: any) => c.id))
const cuisineIds = new Set(cuisines.map((c: any) => c.id))
const userIds = new Set(users.map((u: any) => u.id))
const restaurantIds = new Set<string>()
const restaurantSlugs = new Set<string>()

for (const r of restaurants as any[]) {
  // Unique ID
  if (restaurantIds.has(r.id)) errors.push(`Duplicate restaurant ID: ${r.id}`)
  restaurantIds.add(r.id)

  // Unique slug
  if (restaurantSlugs.has(r.slug)) errors.push(`Duplicate slug: ${r.slug} (${r.id})`)
  restaurantSlugs.add(r.slug)

  // FK: cityId
  if (!cityIds.has(r.cityId)) errors.push(`${r.id}: cityId "${r.cityId}" not found in cities.json`)

  // FK: cuisineIds
  for (const cid of r.cuisineIds) {
    if (!cuisineIds.has(cid)) errors.push(`${r.id}: cuisineId "${cid}" not found in cuisines.json`)
  }

  // priceRange
  if (!VALID_PRICE_RANGES.includes(r.priceRange))
    errors.push(`${r.id}: invalid priceRange "${r.priceRange}"`)

  // dietaryOptions
  for (const d of r.dietaryOptions) {
    if (!VALID_DIETARY.includes(d)) errors.push(`${r.id}: invalid dietaryOption "${d}"`)
  }

  // mealPeriods
  for (const m of r.mealPeriods) {
    if (!VALID_MEAL_PERIODS.includes(m)) errors.push(`${r.id}: invalid mealPeriod "${m}"`)
  }

  // IANA timezone
  try {
    new Intl.DateTimeFormat('en', { timeZone: r.address.timezone })
  } catch {
    errors.push(`${r.id}: invalid timezone "${r.address.timezone}"`)
  }

  // Photos: min 3
  if (!r.photos || r.photos.length < 3)
    errors.push(`${r.id}: needs at least 3 photos (has ${r.photos?.length ?? 0})`)

  // Reviews: 2-3
  if (!r.reviews || r.reviews.length < 2)
    errors.push(`${r.id}: needs at least 2 reviews (has ${r.reviews?.length ?? 0})`)

  // Review constraints
  for (const rev of r.reviews ?? []) {
    if (!userIds.has(rev.userId))
      errors.push(`${r.id}/review ${rev.id}: userId "${rev.userId}" not in users.json`)
    if (rev.rating < 1 || rev.rating > 5 || !Number.isInteger(rev.rating))
      errors.push(`${r.id}/review ${rev.id}: rating ${rev.rating} must be integer 1-5`)
    const reviewDate = new Date(rev.reviewedAt)
    if (reviewDate < TWELVE_MONTHS_AGO)
      errors.push(`${r.id}/review ${rev.id}: reviewedAt ${rev.reviewedAt} is older than 12 months`)
  }

  // isComplete check
  const hasMenu = r.menu?.sections?.length > 0
  const hasPhotos = r.photos?.length >= 3
  const hasReviews = r.reviews?.length > 0
  const hasHours = r.hours && Object.values(r.hours).some((h: any) => h !== null)
  const hasAddress = !!r.address?.street
  const shouldBeComplete = hasMenu && hasPhotos && hasReviews && hasHours && hasAddress
  if (r.isComplete !== shouldBeComplete)
    errors.push(`${r.id}: isComplete=${r.isComplete} but computed=${shouldBeComplete}`)

  // recentAverageRating consistency
  const recentReviews = (r.reviews ?? []).filter(
    (rev: any) => new Date(rev.reviewedAt) >= TWELVE_MONTHS_AGO
  )
  if (recentReviews.length > 0) {
    const computedAvg = parseFloat(
      (recentReviews.reduce((sum: number, rev: any) => sum + rev.rating, 0) / recentReviews.length).toFixed(1)
    )
    if (Math.abs(computedAvg - r.recentAverageRating) > 0.15)
      errors.push(`${r.id}: recentAverageRating=${r.recentAverageRating} but computed=${computedAvg}`)
  }
}

if (errors.length > 0) {
  console.error(`\n❌ Data validation failed with ${errors.length} error(s):\n`)
  errors.forEach(e => console.error(`  • ${e}`))
  process.exit(1)
} else {
  console.log(`✓ Data validation passed — ${(restaurants as any[]).length} restaurants, ${(cities as any[]).length} cities, ${(cuisines as any[]).length} cuisines`)
}
