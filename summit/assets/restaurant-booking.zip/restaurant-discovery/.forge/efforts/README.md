# Efforts

Registry of all work efforts in this repository.

| ID | Title | Type | Tier | Risk | Parent | Phase | Status |
|----|-------|------|------|------|--------|-------|--------|
| restaurant-search-and-discovery | Restaurant Search and Discovery | epic | full | R2 |  | qa | graduated |
| order-placement-and-delivery-tracking | Order Placement and Delivery Tracking | epic | full | R2 |  | implementation | in_progress |
