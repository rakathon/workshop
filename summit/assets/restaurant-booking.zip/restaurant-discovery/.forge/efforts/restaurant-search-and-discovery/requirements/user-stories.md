# User Stories: Restaurant Search and Discovery

*Product / Effort: restaurant-search-and-discovery*
*Last updated: 2026-06-05*

---

## The Local Explorer

A frequent diner who lives in a US city and wants to discover new restaurants in neighbourhoods they don't know well.

---

**US-1:** As a Local Explorer, I want to search for restaurants by cuisine type and neighbourhood, so that I can discover options in parts of my city I don't usually go to.

**Acceptance Criteria:**
- [ ] Search returns results filtered by both cuisine and neighbourhood simultaneously
- [ ] Results update without a full page reload when filters are changed

---

**US-2:** As a Local Explorer, I want to filter restaurants by "open now" and meal period, so that I can find somewhere that fits my schedule without checking each place individually.

**Acceptance Criteria:**
- [ ] "Open now" filter uses real-time clock against listed hours
- [ ] Meal period filter (breakfast/brunch/lunch/dinner) is available alongside "open now"

---

**US-3:** As a Local Explorer, I want to browse photos and menus on a restaurant's listing page, so that I can get a feel for the food and atmosphere before committing to a visit.

**Acceptance Criteria:**
- [ ] Photos and menu are visible on the listing page without navigating away
- [ ] Menu shows sections and item names with prices where available

---

**US-4:** As a Local Explorer, I want to share a restaurant listing with a friend, so that we can agree on where to go without switching to a different app.

**Acceptance Criteria:**
- [ ] Share action produces a working deep link to the listing
- [ ] Recipient can view the full listing without requiring app installation

---

## The Visiting Planner

Someone travelling to a US city who researches restaurants before arriving.

---

**US-5:** As a Visiting Planner, I want to search for restaurants in a specific US city before I arrive, so that I have options ready when I land.

**Acceptance Criteria:**
- [ ] City search accepts any US city name or zip code
- [ ] Results are scoped to the selected city and labelled clearly (e.g. "Restaurants in Austin, TX")

---

**US-6:** As a Visiting Planner, I want to filter by cuisine, price range, and dietary restrictions, so that I can narrow down options that match my group's preferences.

**Acceptance Criteria:**
- [ ] Cuisine, price range, and dietary restriction filters can be applied simultaneously
- [ ] Active filters are visible and individually removable

---

**US-7:** As a Visiting Planner, I want to see reviews with recency information, so that I can trust the feedback reflects the restaurant's current quality.

**Acceptance Criteria:**
- [ ] Review recency is displayed on every review (e.g. "3 months ago")
- [ ] Only reviews from the past 12 months are shown by default

---

## The Decisive Diner

Someone who already has a restaurant name in mind and wants to quickly verify hours, menu, and location before going.

---

**US-8:** As a Decisive Diner, I want to search for a restaurant by name, so that I can quickly pull up its listing without browsing.

**Acceptance Criteria:**
- [ ] Name search returns the matching restaurant as the top result
- [ ] Search works across all US cities, not just the user's current location

---

**US-9:** As a Decisive Diner, I want to see cuisine type, menu, photos, hours, location, and reviews on a single page, so that I can confirm everything I need without visiting multiple sources.

**Acceptance Criteria:**
- [ ] All 6 dimensions (cuisine, menu, photos, hours, location map, reviews) are visible on a single listing page
- [ ] No navigation away from the listing page is required to view any dimension

---

**US-10:** As a Decisive Diner, I want to see the restaurant's current open/closed status at a glance, so that I don't show up when it's closed.

**Acceptance Criteria:**
- [ ] Open/closed status is displayed prominently on the listing page and in search results
- [ ] Status reflects the current time against listed hours
