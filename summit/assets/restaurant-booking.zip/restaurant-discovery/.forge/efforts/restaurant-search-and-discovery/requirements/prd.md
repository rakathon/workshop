# PRD: Restaurant Search and Discovery

*Product / Effort: restaurant-search-and-discovery*
*Last updated: 2026-06-05*

---

## Problem Statement

US diners face a fragmented, multi-platform research process every time they decide where to eat. On average, a consumer consults 6 different platforms — Google Maps for location and hours, Yelp for reviews, the restaurant's own website for the menu, Instagram for photos — before making a choice. None of these platforms were designed around the pre-visit decision moment; they serve navigation, social sharing, reservations, or travel planning as their primary job. The result is a scattered, time-consuming experience that leaves diners either under-informed or simply defaulting to wherever they've been before.

The Restaurant Search and Discovery feature is DineFind's direct answer to this problem. It serves US diners in the active decision moment — locals exploring unfamiliar neighbourhoods, visitors researching a city before arrival, and frequent diners looking to discover something new — by putting every piece of information needed to make a confident restaurant choice in one place.

*Evidence:* BrightLocal Local Consumer Review Survey 2026 (consumers average 6 platforms for local business research; 97% read reviews before visiting); competitive research confirms no purpose-built US restaurant discovery product remains in market following Foursquare City Guide shutdown (December 2024).

---

## Goals

1. **Complete restaurant information** — 80% of active listings have all 6 data dimensions (cuisine, menu, photos, hours, location, reviews) populated at launch
2. **Effective discovery** — search-to-listing CTR ≥ 80%
3. **Review trust at launch** — 80% of submitted reviews include at least one photo within 90 days of launch
4. **First-session conversion** — 30% of first sessions result in a save or share; Day-1 retention ≥ 40%
5. **Market presence** — top-3 Google ranking for 80+ cuisine-city keyword combinations within 6 months of launch

---

## Non-Goals

- We are not building table reservations — booking a table is a different job-to-be-done; DineFind helps you decide where to go, not secure a seat
- We are not building food delivery — in-person dining is the target consumption mode; delivery is a separate market with different infrastructure
- We are not building restaurant-side tools — operator dashboards, CRM, and analytics for restaurants are out of scope; DineFind is built for diners
- We are not launching outside the US — depth in US metros before any international expansion
- We are not building social features (followers, friend activity feeds) — discovery is intent-driven, not social-graph-driven; this is a v1 scope exclusion, not a permanent product decision
- We are not building AI sentiment summaries in v1 — deferred to a future iteration once review volume justifies it

---

## Success Metrics

### Leading Indicators (early signal)

- Search-to-listing CTR tracked weekly from day 1 (target ≥ 80%)
- Filter usage rate per session (target ≥ 40% of sessions include ≥ 1 filter interaction)
- First-session save/share rate (target ≥ 30%)
- Listing completeness rate across launch metros (target ≥ 80% of listings fully populated)
- App store conversion rate — page view to install (target ≥ 25%)

### Lagging Indicators (final outcome)

- Day-1 retention ≥ 40% (measured at 60 days post-launch)
- Day-7 retention ≥ 20% (measured at 90 days post-launch)
- 80% listing completeness across all launch metros (at launch)
- Top-3 Google ranking for 80+ cuisine-city keyword combinations (6 months post-launch)
- ≥ 50% of new installs from organic search or word-of-mouth (90 days post-launch)

---

## Open Questions

- Which data sources will power restaurant listings — Google Places API, a menu aggregator (SinglePlatform, Locu), direct restaurant scraping, or a combination? [owner: eng] [due: before implementation starts]
- What AI model/service will power review sentiment summaries (deferred to v2) — first-party LLM (Claude API) or a third-party NLP service? [owner: eng] [due: before v2 implementation starts]
- What are the launch metros — which 5–8 US cities will be at full listing completeness at launch? [owner: eng] [due: before implementation starts]
- Is there a minimum review count threshold before a listing is considered ready to surface to users? [owner: eng] [due: before implementation starts]

---

## Timeline / Dependencies

- **Target:** Before Q3 2026 launch
- **Dependencies:** None identified

---

## Requirements

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See `user-stories.md` for Connextra-format stories grouped by persona.
