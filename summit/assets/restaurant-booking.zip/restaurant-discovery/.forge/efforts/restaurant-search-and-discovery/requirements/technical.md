# Technical Requirements — Restaurant Search and Discovery

*Effort: restaurant-search-and-discovery*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-05*

---

## TR-1: Web-Only Platform — React

*Traces to: BR-1, BR-2, BR-3, BR-4, BR-5, BR-6, BR-7, BR-8, BR-9*

The application must be delivered as a web application built with React. No native iOS or Android app is required at launch. The web app must be fully functional on modern mobile browsers (iOS Safari, Android Chrome) as well as desktop browsers (Chrome, Firefox, Safari, Edge).

---

## TR-2: Mock Data via JSON Files — No Backend Required

*Traces to: BR-1, BR-2, BR-3, BR-4, BR-5, BR-6, BR-7, BR-8, BR-9*

For the MVP, all restaurant data (listings, menus, photos, reviews, hours, location) must be served from static JSON files bundled with the React application. No backend server, database, or external API integration is required at this stage. The mock dataset must cover approximately 30 restaurants. The JSON data structure must be designed to reflect the real data model so that a backend can be substituted later without frontend changes.

---

## TR-3: Client-Side Search and Filtering

*Traces to: BR-1, BR-2, BR-3, BR-9*

All search and filtering (by location, cuisine, dietary restrictions, price range, open status, meal period, and city) must be implemented client-side in React using in-memory operations over the JSON dataset. No search index or server-side query engine is required for the MVP given the 30-restaurant dataset size.

---

## TR-4: Initial Page Load Performance

*Traces to: BR-1, BR-4*

The application must achieve an initial page load time of under 3 seconds on a standard 4G mobile connection. This must be achieved through React code splitting and lazy-loaded images. Listing pages must render within 2 seconds of navigation (client-side routing transition).

---

## TR-5: Restaurant Data Model

*Traces to: BR-4, BR-5, BR-6, BR-7*

Each restaurant record in the JSON dataset must conform to the following structure:

```json
{
  "id": "string",
  "name": "string",
  "cuisine": ["string"],
  "priceRange": "$" | "$$" | "$$$" | "$$$$",
  "address": {
    "street": "string",
    "neighbourhood": "string",
    "city": "string",
    "state": "string",
    "zip": "string",
    "lat": "number",
    "lng": "number",
    "timezone": "string (IANA, e.g. America/Chicago)"
  },
  "hours": {
    "monday": { "open": "HH:MM", "close": "HH:MM" },
    "tuesday": { "open": "HH:MM", "close": "HH:MM" },
    "wednesday": { "open": "HH:MM", "close": "HH:MM" },
    "thursday": { "open": "HH:MM", "close": "HH:MM" },
    "friday": { "open": "HH:MM", "close": "HH:MM" },
    "saturday": { "open": "HH:MM", "close": "HH:MM" },
    "sunday": { "open": "HH:MM", "close": "HH:MM" }
  },
  "mealPeriods": ["breakfast" | "brunch" | "lunch" | "dinner"],
  "dietaryOptions": ["vegetarian" | "vegan" | "gluten-free"],
  "coverPhoto": "url",
  "photos": ["url"],
  "menu": {
    "lastUpdated": "YYYY-MM-DD",
    "sections": [
      {
        "name": "string",
        "items": [{ "name": "string", "description": "string", "price": "number" }]
      }
    ]
  },
  "reviews": [
    {
      "id": "string",
      "rating": "1-5",
      "text": "string",
      "date": "ISO-8601",
      "photoUrl": "string | null"
    }
  ],
  "averageRating": "number",
  "reviewCount": "number"
}
```

This structure must be treated as the canonical data contract. Frontend components must not assume fields beyond this schema. The `neighbourhood` field enables neighbourhood-based filtering (BR-2). The `coverPhoto` field is the hero image on listing pages and search result cards, distinct from the `photos` gallery array. The `timezone` field (IANA format) on the address object is required for open/closed status computation (TR-9).

---

## TR-6: Routing and URL Structure

*Traces to: BR-1, BR-8, BR-9*

The application must use React Router with the following URL structure:

- `/` — home / search landing page
- `/search?city=&cuisine=&price=&dietary=&mealPeriod=&openNow=` — search results page; all active filters must be reflected as query parameters so that search state is shareable via URL
- `/restaurant/:id` — individual restaurant listing page; this URL is also the deep link target for the share feature (BR-8)

Browser back/forward navigation must work correctly across all routes. Filter state must be restored from query parameters on page load.

---

## TR-7: Location Display — Address Only (MVP)

*Traces to: BR-4*

For the MVP, restaurant location must be displayed as a formatted text address (street, neighbourhood, city, state, zip). No map embed or map API integration is required. The address data structure in TR-5 retains lat/lng fields to support a future map integration without a data migration.

---

## TR-8: Share Implementation — Web Share API with Copy Link Fallback

*Traces to: BR-8*

The share feature must use the Web Share API (navigator.share) where supported (primarily mobile browsers). On desktop or unsupported browsers, the share action must fall back to copying the listing URL to the clipboard with a visible confirmation ("Link copied"). The share URL is the canonical `/restaurant/:id` page URL — no URL shortener required for MVP.

---

## TR-9: Open Now Logic — Client-Side Timezone-Aware Computation

*Traces to: BR-3*

The "open now" filter must be computed client-side by comparing the current time against each restaurant's listed hours. The comparison must be performed in the restaurant's local timezone using the IANA `timezone` field from TR-5 (e.g. "America/Chicago"), not the user's browser timezone. Restaurants with no hours data must be excluded from "open now" results — they must not be shown as open.

---

## TR-10: Review Display — Recency Enforcement and Sort Order

*Traces to: BR-7*

Reviews must be filtered client-side to display only those with a date within the past 12 months by default. Older reviews must be accessible via an explicit "Show older reviews" toggle. Reviews must be sorted most-recent-first as the default order. The `averageRating` and `reviewCount` fields in the JSON reflect all reviews regardless of recency, but the displayed star rating on the listing page must be computed only from reviews within the past 12 months.

---

## TR-11: Search Results Sort Order

*Traces to: BR-1, BR-2, BR-3*

Search results must be sorted by average rating (computed from reviews within the past 12 months) descending by default. Review count must be used as a secondary sort to break ties. No manual sort controls are required for MVP.

---

## TR-12: Photo Display — Mock Data URLs, No Upload

*Traces to: BR-6*

Photos must be displayed from URLs stored in the restaurant's `photos` array in the JSON mock data. User photo submission is not required for MVP — the upload UI must not be built. Each restaurant record must include a minimum of 3 photo URLs pointing to publicly accessible images (e.g. Unsplash) representing realistic food/restaurant imagery.

---

## TR-13: Review Submission — Mock Success, No Persistence

*Traces to: BR-7*

The review submission form (star rating + text) must be displayed on every listing page. On submission, the form must display a success message ("Your review has been submitted") without persisting any data. Each restaurant in the mock dataset must include 2–3 pre-populated reviews with realistic content, dates within the past 12 months, and a mix of star ratings.

---

## TR-14: Responsive Design — Desktop-First with Tailwind CSS

*Traces to: TR-1*

The application must be built desktop-first with responsive adaptation for mobile browsers. Tailwind CSS must be used as the styling framework. Two primary breakpoints: desktop (≥ 768px, primary design target) and mobile (< 768px, responsive adaptation). A single React codebase must serve both breakpoints — no separate mobile/desktop builds.

---

## TR-15: State Management — React Built-In Only

*Traces to: TR-1, TR-3, TR-6*

State management must use React built-in primitives only (useState, useContext). No external state management library (Redux, Zustand, Jotai) is required for MVP. A single React context must manage global filter and city selection state. URL query parameters (TR-6) are the source of truth for shareable search state.

---

## TR-16: Local Development Only — No Deployment Required

*Traces to: TR-1*

For the MVP, the application must run locally via Vite's development server (`npm run dev`). No production deployment, hosting, or CI/CD pipeline is required for this effort. Deep links (TR-6) must resolve correctly in the local development environment.

---

## TR-17: Build Tool — Vite with TypeScript

*Traces to: TR-1, TR-16*

The React application must be scaffolded using Vite with the React + TypeScript template. TypeScript strict mode must be enabled. The development server must be started with `npm run dev`.
