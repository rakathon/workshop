# Business Requirements: Restaurant Search and Discovery

*Product / Effort: restaurant-search-and-discovery*
*Last updated: 2026-06-05*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained
-->

---

## BR-1: Location-Based Restaurant Search

**Priority:** P0

The system must allow users to search for restaurants by US city, neighbourhood, zip code, or current device location and return relevant results scoped to that area.

**Acceptance Criteria:**
- [ ] User can enter a US city, neighbourhood, or zip code and receive restaurant results within that area
- [ ] User can use current device location to search nearby restaurants
- [ ] Search results load within 3 seconds for any valid US location

---

## BR-2: Cuisine and Category Filters

**Priority:** P0

The system must provide filters enabling users to narrow restaurant results by cuisine type, dietary restrictions, and price range.

**Acceptance Criteria:**
- [ ] At least 8 cuisine types are available as filters (e.g. Italian, Thai, Mexican, Japanese, Indian, American, Mediterranean, Chinese)
- [ ] Dietary restriction filters are available (vegetarian, vegan, gluten-free)
- [ ] Price range filter ($ / $$ / $$$ / $$$$) is available and functional

---

## BR-3: Timing Filters

**Priority:** P0

The system must allow users to filter restaurants by current open/closed status and meal period so they only see relevant options for the time they intend to dine.

**Acceptance Criteria:**
- [ ] "Open now" toggle filters results to restaurants currently open based on their listed hours
- [ ] Users can filter by meal period (breakfast, brunch, lunch, dinner)
- [ ] Hours of operation are displayed on every listing and kept current

---

## BR-4: Restaurant Listing Page

**Priority:** P0

Every restaurant must have a dedicated listing page displaying all 6 decision dimensions: cuisine, menu, photos, hours, location, and reviews. No dimension may be absent without internal flagging.

**Acceptance Criteria:**
- [ ] Every listing displays all 6 dimensions: cuisine type, menu, photos, hours, location (map pin + address), and reviews
- [ ] A listing with any dimension missing is flagged internally and deprioritised in search results
- [ ] Listing page loads within 2 seconds on mobile and desktop

---

## BR-5: Menu Display

**Priority:** P0

Menus must be displayed directly on the restaurant listing page without redirecting users to an external site.

**Acceptance Criteria:**
- [ ] Menu is displayed directly on the listing page — no redirect to an external site required
- [ ] Menu shows at minimum: sections (starters, mains, desserts) and item names with prices where available
- [ ] Menu data freshness is displayed (e.g. "last updated 14 days ago") so users can assess reliability

---

## BR-6: Photo Gallery

**Priority:** P0

Each restaurant listing must display a browsable photo gallery sourced from users or the restaurant, with the ability for users to submit new photos.

**Acceptance Criteria:**
- [ ] Each listing displays a minimum of 3 photos sourced from the mock data
- [ ] Photos are browsable in a gallery view without leaving the listing page

---

## BR-7: Reviews and Ratings

**Priority:** P0

The system must display user-submitted reviews and aggregated star ratings on each listing, with recency enforcement to surface the most relevant feedback.

**Acceptance Criteria:**
- [ ] Each listing displays a star rating (1–5) aggregated from user reviews, shown prominently on the listing page and in search results
- [ ] Reviews are displayed with recency enforcement — only reviews from the past 12 months are shown by default, with older reviews accessible behind a toggle
- [ ] Users can submit a review (star rating + text) directly from the listing page

---

## BR-8: Share a Restaurant

**Priority:** P0

Users must be able to share any restaurant listing via a deep link that works on both mobile and web, without requiring the recipient to have the app installed.

**Acceptance Criteria:**
- [ ] Every listing has a share action that generates a deep link to that listing
- [ ] The share action triggers the device's native share sheet (iOS/Android) and works on web via copy-link
- [ ] Shared links resolve to the correct listing page without requiring the recipient to have the app installed

---

## BR-9: Cross-City US Browse

**Priority:** P0

Users must be able to search and browse restaurants in any US city regardless of their current physical location, with clear labelling of the selected city context.

**Acceptance Criteria:**
- [ ] Users can search and browse restaurants in any US city without being constrained to their current location
- [ ] City/location selector is accessible from the home screen and from within search results
- [ ] Search results are scoped to the selected city and labelled clearly (e.g. "Restaurants in Austin, TX")
