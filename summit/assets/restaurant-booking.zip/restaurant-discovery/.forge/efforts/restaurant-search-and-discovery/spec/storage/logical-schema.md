# Logical Schema

*Effort: restaurant-search-and-discovery*  *Authored: 2026-06-05*

---

## Entity-Relationship Diagram

```mermaid
erDiagram
    RESTAURANT ||--|{ RESTAURANT_CUISINE : "tagged with"
    CUISINE    ||--|{ RESTAURANT_CUISINE : "applied to"

    RESTAURANT ||--o{ RESTAURANT_HOURS : "open during"
    RESTAURANT ||--o{ REVIEW           : "receives"
    RESTAURANT ||--o{ PHOTO            : "has"
    RESTAURANT ||--|| MENU             : "has"
    RESTAURANT }o--|| CITY             : "located in"

    USER       ||--o{ REVIEW           : "writes"

    MENU       ||--|{ MENU_SECTION     : "contains"
    MENU_SECTION ||--|{ MENU_ITEM     : "contains"
```

## Entities

| Entity | Description |
|--------|-------------|
| `RESTAURANT` | A dining venue with address, cover photo, price range, and discoverable metadata. The central entity in the domain. |
| `CUISINE` | A cuisine type (Thai, Italian, Mexican, Japanese…). Lookup table enabling cuisine-based filtering without code changes. |
| `RESTAURANT_CUISINE` | Many-to-many junction linking restaurants to one or more cuisine types. |
| `CITY` | A US city covered by DineFind. Powers the city search autocomplete and scopes restaurant results. |
| `RESTAURANT_HOURS` | Operating hours per day of week for a restaurant. Stored separately to enable server-side open/closed queries without loading the full restaurant record. |
| `USER` | A registered diner. Exists to associate reviews with the person who wrote them. No auth in MVP but the model is auth-ready. |
| `REVIEW` | A user's review of a restaurant: star rating (1–5) and text. Timestamped for recency enforcement. |
| `PHOTO` | A photo associated with a restaurant. Separate entity to support multiple ordered photos, source attribution, and future moderation. |
| `MENU` | A restaurant's current menu with a freshness date. One menu per restaurant at any time. |
| `MENU_SECTION` | A named section within a menu (e.g. Starters, Mains, Desserts) with an ordering position. |
| `MENU_ITEM` | An individual dish within a menu section: name, description, and price. |
