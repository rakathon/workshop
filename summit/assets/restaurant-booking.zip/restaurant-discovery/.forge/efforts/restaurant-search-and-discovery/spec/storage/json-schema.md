# Physical Schema — JSON Mock Data

*Effort: restaurant-search-and-discovery*  *Authored: 2026-06-05*
*Storage type: Static JSON files (MVP — no backend)*
*Traces to: TR-2, TR-5*

---

## Overview

All application data is served from static JSON files bundled with the React app.
Each file exports an array of records. The frontend imports these files directly;
no HTTP request, no database query. All filtering, sorting, and open/closed
computation happens client-side in React.

This document is the canonical data contract. Frontend components must not assume
fields beyond what is defined here. When a real backend is added, these schemas
become the source-of-truth for the initial database migration — no field may be
renamed or removed without a corresponding migration.

**File layout:**

```
src/data/
  cities.json
  cuisines.json
  restaurants.json   ← includes hours, photos, menu, reviews inline
  users.json
```

---

## File: `cities.json`

Supports: *List cities for autocomplete*

```json
[
  {
    "id": "string",          // UUID, e.g. "c1a2b3c4-..."
    "name": "string",        // Display name, e.g. "Austin"
    "state": "string",       // Two-letter state code, e.g. "TX"
    "displayName": "string", // Full display, e.g. "Austin, TX"
    "timezone": "string"     // IANA timezone, e.g. "America/Chicago"
  }
]
```

**Example:**
```json
[
  {
    "id": "c1a2b3c4-0001-0000-0000-000000000001",
    "name": "Austin",
    "state": "TX",
    "displayName": "Austin, TX",
    "timezone": "America/Chicago"
  },
  {
    "id": "c1a2b3c4-0002-0000-0000-000000000002",
    "name": "New York",
    "state": "NY",
    "displayName": "New York, NY",
    "timezone": "America/New_York"
  }
]
```

---

## File: `cuisines.json`

Supports: *Get cuisine list*, *Filter restaurants by cuisine*

```json
[
  {
    "id": "string",    // UUID
    "name": "string",  // Display name, e.g. "Thai"
    "slug": "string"   // URL-safe key, e.g. "thai"
  }
]
```

**Minimum 8 required at launch (BR-2):** Italian, Thai, Mexican, Japanese, Indian, American, Mediterranean, Chinese.

**Example:**
```json
[
  { "id": "cu-0001", "name": "Thai",       "slug": "thai" },
  { "id": "cu-0002", "name": "Italian",    "slug": "italian" },
  { "id": "cu-0003", "name": "Mexican",    "slug": "mexican" },
  { "id": "cu-0004", "name": "Japanese",   "slug": "japanese" },
  { "id": "cu-0005", "name": "Indian",     "slug": "indian" },
  { "id": "cu-0006", "name": "American",   "slug": "american" },
  { "id": "cu-0007", "name": "Mediterranean", "slug": "mediterranean" },
  { "id": "cu-0008", "name": "Chinese",    "slug": "chinese" }
]
```

---

## File: `restaurants.json`

The primary data file. Supports all restaurant search, filter, and listing patterns.
Hours, photos, menu, and reviews are **embedded inline** (denormalised) — no joins,
no secondary lookups. This is the correct approach for static JSON; normalisation
would add complexity with no benefit.

**~30 records required at launch (TR-2).**

### Top-level restaurant record

```json
{
  "id": "string",             // UUID, used in /restaurant/:id route
  "slug": "string",           // URL-safe name, used for deep links, e.g. "lotus-thai-kitchen"
  "name": "string",           // Display name, e.g. "Lotus Thai Kitchen"

  "cityId": "string",         // FK → cities.json id
  "address": {
    "street": "string",       // e.g. "123 East 6th Street"
    "neighbourhood": "string",// e.g. "East Austin"
    "city": "string",         // Denormalised display name, e.g. "Austin"
    "state": "string",        // e.g. "TX"
    "zip": "string",          // e.g. "78702"
    "lat": "number",          // For future map integration
    "lng": "number",          // For future map integration
    "timezone": "string"      // IANA, e.g. "America/Chicago" — required for open/closed (TR-9)
  },

  "cuisineIds": ["string"],   // FK array → cuisines.json id — supports multi-cuisine restaurants
  "cuisineNames": ["string"], // Denormalised display names, e.g. ["Thai", "Vegetarian"]

  "priceRange": "string",     // One of: "$" | "$$" | "$$$" | "$$$$"
  "dietaryOptions": ["string"],// Subset of: ["vegetarian", "vegan", "gluten-free"]
  "mealPeriods": ["string"],  // Subset of: ["breakfast", "brunch", "lunch", "dinner"]

  "coverPhoto": "string",     // URL — hero image on listing page and search result card
  "isComplete": "boolean",    // true if all 6 dimensions populated; false triggers deprioritisation (BR-4)

  "averageRating": "number",  // Pre-computed across ALL reviews (for display fallback)
  "recentAverageRating": "number", // Pre-computed from reviews in past 12 months (TR-10, TR-11)
  "reviewCount": "number",    // Total review count (all time)
  "recentReviewCount": "number",   // Review count within past 12 months

  "hours": {                  // null values = closed that day
    "monday":    { "open": "HH:MM", "close": "HH:MM" } | null,
    "tuesday":   { "open": "HH:MM", "close": "HH:MM" } | null,
    "wednesday": { "open": "HH:MM", "close": "HH:MM" } | null,
    "thursday":  { "open": "HH:MM", "close": "HH:MM" } | null,
    "friday":    { "open": "HH:MM", "close": "HH:MM" } | null,
    "saturday":  { "open": "HH:MM", "close": "HH:MM" } | null,
    "sunday":    { "open": "HH:MM", "close": "HH:MM" } | null
  },

  "photos": [                 // Minimum 3 required (BR-6)
    {
      "id": "string",
      "url": "string",        // Publicly accessible image URL
      "alt": "string",        // Accessibility alt text (WCAG requirement)
      "sortOrder": "number"   // Display order; lower = earlier
    }
  ],

  "menu": {
    "lastUpdated": "string",  // ISO date, e.g. "2026-05-22" — freshness display (BR-5)
    "sections": [
      {
        "id": "string",
        "name": "string",     // e.g. "Starters"
        "position": "number", // Display order
        "items": [
          {
            "id": "string",
            "name": "string",        // e.g. "Pad Thai"
            "description": "string", // e.g. "Rice noodles, egg, bean sprouts…"
            "price": "number"        // In USD, e.g. 18.00; null if not available
          }
        ]
      }
    ]
  },

  "reviews": [                // 2–3 per restaurant in mock data (TR-13)
    {
      "id": "string",
      "userId": "string",     // FK → users.json id
      "userName": "string",   // Denormalised for display without a user lookup
      "rating": "number",     // Integer 1–5
      "text": "string",
      "reviewedAt": "string", // ISO-8601 datetime, e.g. "2025-11-15T14:30:00Z"
      "photoUrl": "string" | null // Optional review photo URL
    }
  ]
}
```

### Completeness rules

`isComplete` must be `false` if any of the following are true:
- `menu.sections` is empty or absent
- `photos` has fewer than 3 items
- `reviews` is empty
- `hours` is absent or all days are null
- `address.street` is absent

Incomplete restaurants are sorted below complete ones in search results (BR-4).

---

## File: `users.json`

Supports: *Review attribution* (display reviewer name alongside review)

Minimal for MVP — no auth, no PII beyond display name.

```json
[
  {
    "id": "string",          // UUID
    "displayName": "string"  // e.g. "Sarah M." — shown on reviews
  }
]
```

**Note:** When real auth is added, this file becomes the seed for the `users` table. The `id` field must be stable — do not regenerate UUIDs between MVP and production.

---

## Client-Side Filtering Contract

These are the filter operations the React app must implement against `restaurants.json`. Each operation must be composable — all active filters are applied as AND conditions.

| Filter | Operation |
|--------|-----------|
| City | `restaurant.cityId === selectedCityId` |
| Neighbourhood | `restaurant.address.neighbourhood === selectedNeighbourhood` (case-insensitive) |
| Cuisine | `restaurant.cuisineIds.some(id => selectedCuisineIds.includes(id))` |
| Price range | `restaurant.priceRange === selectedPrice` |
| Dietary option | `selectedDietary.every(opt => restaurant.dietaryOptions.includes(opt))` |
| Meal period | `restaurant.mealPeriods.includes(selectedMealPeriod)` |
| Open now | Compute using `restaurant.hours[currentDayOfWeek]` and `restaurant.address.timezone` (TR-9) |
| Name search | `restaurant.name.toLowerCase().includes(query.toLowerCase())` |

**Sort order (TR-11):** Primary — `recentAverageRating DESC`. Secondary — `recentReviewCount DESC`.

**Deprioritisation (BR-4):** Incomplete restaurants (`isComplete === false`) are sorted to the bottom of results regardless of rating.

---

## Data Integrity Constraints

These constraints must hold across all mock records and must be enforced by a data validation script before any data file is committed:

| Constraint | Check |
|------------|-------|
| `restaurant.id` is unique across all records | No duplicate IDs |
| `restaurant.slug` is unique across all records | No duplicate slugs |
| `restaurant.cityId` references a valid city in `cities.json` | FK integrity |
| `restaurant.cuisineIds` all reference valid cuisines in `cuisines.json` | FK integrity |
| `review.userId` references a valid user in `users.json` | FK integrity |
| `restaurant.photos` has ≥ 3 entries | BR-6 minimum |
| `restaurant.reviews` has 2–3 entries | TR-13 requirement |
| `review.rating` is an integer 1–5 | Range constraint |
| `review.reviewedAt` is within the past 12 months | TR-13 recency requirement for mock data |
| `restaurant.priceRange` is one of `$`, `$$`, `$$$`, `$$$$` | Enum constraint |
| `restaurant.address.timezone` is a valid IANA timezone string | TR-9 requirement |
| `restaurant.recentAverageRating` matches computed average of recent reviews | Derived field consistency |
| `restaurant.isComplete` correctly reflects completeness rules above | Completeness flag accuracy |
