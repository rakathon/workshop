# UI E2E Test Suite — Restaurant Search and Discovery

*Capability/Effort:* `.forge/efforts/restaurant-search-and-discovery/spec/test/`
*Authored:* 2026-06-05
*Effort:* restaurant-search-and-discovery

## Why Test This

DineFind is entirely a UI product — there is no API layer to contract-test and no database to integration-test. The browser is the system boundary. These UI E2E scenarios verify every screen, every non-default state, and every interaction documented in the UX spec Screen Inventory. They are the primary regression safety net for this product and must be run before any build is considered releasable. Implemented with Playwright against `localhost:5173` (Vite dev server). Each scenario targets what a real user sees and can interact with — not internal component state or JSON data structure.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: Home page renders hero search and cuisine pills | Screen 1 default state |
| SC-2: City autocomplete dropdown appears on input | Screen 1 city-entered state |
| SC-3: Selecting autocomplete city populates input | Screen 1 city autocomplete interaction |
| SC-4: No-match state shown for unknown city | Screen 1 no-city-match state |
| SC-5: Cuisine pill selection highlights and pre-fills cuisine input | Screen 1 cuisine pill interaction |
| SC-6: Search submission navigates to results page | Home → Results navigation |
| SC-7: Results page renders restaurant cards | Screen 2 default loaded state |
| SC-8: Results page shows loading skeleton before data | Screen 2 loading state |
| SC-9: Empty state shown when no results match filters | Screen 2 empty state |
| SC-10: "No open results" variant when Open now yields zero | Screen 2 filtered-no-open state |
| SC-11: Active filter chips appear and are removable | Screen 2 filter chip interaction |
| SC-12: Clear all removes all active filter chips | Screen 2 clear all interaction |
| SC-13: Filter sidebar pills toggle active state on click | Screen 2 filter toggle interaction |
| SC-14: Open now toggle switches on and off | Screen 2 open now toggle interaction |
| SC-15: Clicking a restaurant card navigates to listing page | Results → Listing navigation |
| SC-16: Listing page renders all 6 information sections | Screen 3 default loaded state |
| SC-17: Listing page shows loading skeleton during transition | Screen 3 loading state |
| SC-18: Incomplete listing shows per-section placeholder messages | Screen 3 incomplete state |
| SC-19: Open now badge shows correct open/closed status | Screen 3 open state |
| SC-20: Closed badge shows next opening time | Screen 3 closed state |
| SC-21: Hours accordion expands to show full week | Screen 3 hours interaction |
| SC-22: Photo gallery is horizontally scrollable | Screen 3 photo gallery interaction |
| SC-23: Clicking a photo opens the lightbox | Screen 3 lightbox open |
| SC-24: Lightbox arrow keys navigate between photos | Screen 3 lightbox keyboard navigation |
| SC-25: Escape key closes the lightbox | Screen 3 lightbox close |
| SC-26: Menu section accordion expands and collapses | Screen 3 menu accordion interaction |
| SC-27: Review form expands on "Write a review" click | Screen 3 review form open |
| SC-28: Star rating selector highlights stars on click | Screen 3 star rating interaction |
| SC-29: Review submission shows success message | Screen 3 review submitted state |
| SC-30: Share button shows "Link copied" toast on desktop | Screen 3 share interaction |
| SC-31: Back button returns to results page | Listing → Results back navigation |
| SC-32: Keyboard navigation reaches all interactive elements | Accessibility — keyboard operability |
| SC-33: Focus ring visible on all interactive elements | Accessibility — visible focus |
| SC-34: Desktop layout renders at ≥768px viewport | TR-14 responsive desktop breakpoint |
| SC-35: Mobile layout adapts at <768px viewport | TR-14 responsive mobile breakpoint |

## Scenarios

### SC-1: Home page renders hero search and cuisine pills

**Type:** e2e (UI)
**Given** the user navigates to `http://localhost:5173/`
**Then** the hero heading is visible on the page
**And** the city search input is visible and empty
**And** at least 8 cuisine pill buttons are visible
**Verifies:** Screen 1 default state — "Hero with search bar and featured cuisine categories"

---

### SC-2: City autocomplete dropdown appears on input

**Type:** e2e (UI)
**Given** the user is on the home page
**When** the user types "Aus" into the city input
**Then** an autocomplete dropdown appears below the city input
**And** at least one city matching "Aus" (e.g. "Austin, TX") is visible in the dropdown
**Verifies:** Screen 1 city-entered state — "Autocomplete dropdown with matching US cities"

---

### SC-3: Selecting autocomplete city populates input

**Type:** e2e (UI)
**Given** the autocomplete dropdown is open showing "Austin, TX"
**When** the user clicks "Austin, TX" in the dropdown
**Then** the city input field contains "Austin, TX"
**And** the autocomplete dropdown is dismissed
**Verifies:** Screen 1 city autocomplete interaction — city selection fills input and closes dropdown

---

### SC-4: No-match state shown for unknown city

**Type:** e2e (UI)
**Given** the user is on the home page
**When** the user types "Xyzburg" (a city not in the dataset) and submits the search
**Then** a message is displayed indicating the city has no results (e.g. "We don't have restaurants in Xyzburg yet")
**And** no restaurant cards are shown
**Verifies:** Screen 1 no-city-match state — "We don't have restaurants in [city] yet — try a nearby city"

---

### SC-5: Cuisine pill selection highlights and pre-fills cuisine input

**Type:** e2e (UI)
**Given** the user is on the home page
**When** the user clicks the "Thai" cuisine pill
**Then** the "Thai" pill is visually highlighted (active state)
**And** the cuisine input field is pre-filled with "Thai"
**Verifies:** Screen 1 cuisine pill interaction — pill click pre-fills cuisine input

---

### SC-6: Search submission navigates to results page

**Type:** e2e (UI)
**Given** the user has entered "Austin, TX" in the city input
**When** the user clicks the Search button
**Then** the browser URL changes to `/search` with at least `city=` as a query parameter
**And** the search results page is rendered showing restaurant cards
**Verifies:** Home → Results navigation — search submission routes to `/search`

---

### SC-7: Results page renders restaurant cards

**Type:** e2e (UI)
**Given** the user has searched for restaurants in "Austin, TX"
**When** the results page is fully loaded
**Then** at least one restaurant card is visible
**And** each card shows: a cover photo, restaurant name, cuisine, price range, star rating, and open/closed badge
**Verifies:** Screen 2 default loaded state — "Grid of restaurant cards with cover photo, name, cuisine, rating, price, open status"

---

### SC-8: Results page shows loading skeleton before data

**Type:** e2e (UI)
**Given** the results page is navigated to with a slow network (throttled to 3G in Playwright)
**When** the page is loading
**Then** skeleton placeholder cards matching the card layout dimensions are visible before the real cards appear
**Verifies:** Screen 2 loading state — "Card skeleton placeholders"

---

### SC-9: Empty state shown when no results match filters

**Type:** e2e (UI)
**Given** the user applies a cuisine filter for which no mock restaurants exist (e.g. "Korean" in a city with no Korean restaurants)
**When** the results page renders
**Then** an empty state message is visible (e.g. "No restaurants match your filters")
**And** at least one suggestion to broaden filters is displayed
**And** zero restaurant cards are shown
**Verifies:** Screen 2 empty state — "No restaurants match your filters + suggestion"

---

### SC-10: "No open results" variant when Open now yields zero

**Type:** e2e (UI)
**Given** the user enables "Open now" during a time when all matching restaurants are closed
**When** the results page renders
**Then** a message is displayed indicating no restaurants are open right now
**And** a toggle or link to remove the "Open now" filter is shown
**Verifies:** Screen 2 filtered-no-open state — "No restaurants are open right now — showing all results"

---

### SC-11: Active filter chips appear and are removable

**Type:** e2e (UI)
**Given** the user has applied the cuisine "Thai" and price "$$" filters
**When** the results page renders
**Then** filter chips labelled "Thai" and "$$" are visible in the filter strip
**When** the user clicks the × on the "Thai" chip
**Then** the "Thai" chip is removed from the strip
**And** the results update to show restaurants not filtered by cuisine
**Verifies:** Screen 2 filter chip interaction — chips appear for active filters and are individually removable

---

### SC-12: Clear all removes all active filter chips

**Type:** e2e (UI)
**Given** at least 2 filter chips are active on the results page
**When** the user clicks "Clear all"
**Then** all active filter chips are removed from the filter strip
**And** the results update to show unfiltered restaurants for the current city
**Verifies:** Screen 2 clear all interaction — "Clear all" link removes all active filters

---

### SC-13: Filter sidebar pills toggle active state on click

**Type:** e2e (UI)
**Given** the user is on the results page with no cuisine filter active
**When** the user clicks the "Italian" pill in the filter sidebar
**Then** the "Italian" pill has a visually distinct active state (background/border change)
**When** the user clicks the "Italian" pill again
**Then** the pill returns to its inactive visual state
**Verifies:** Screen 2 filter toggle interaction — pills toggle active/inactive on click

---

### SC-14: Open now toggle switches on and off

**Type:** e2e (UI)
**Given** the user is on the results page
**When** the user clicks the "Open now" toggle to turn it on
**Then** the toggle visually shows the on state
**When** the user clicks it again
**Then** the toggle visually shows the off state
**Verifies:** Screen 2 open now toggle interaction — toggle switches on and off with visual feedback

---

### SC-15: Clicking a restaurant card navigates to listing page

**Type:** e2e (UI)
**Given** the user is on the search results page showing at least one restaurant card
**When** the user clicks the first restaurant card
**Then** the browser URL changes to `/restaurant/:id` matching that restaurant's ID
**And** the listing page for that restaurant is rendered
**Verifies:** Results → Listing navigation — card click routes to `/restaurant/:id`

---

### SC-16: Listing page renders all 6 information sections

**Type:** e2e (UI)
**Given** the user has navigated to a listing page for a fully-populated restaurant
**When** the page is fully loaded
**Then** the following sections are all visible on the page without navigating away: cuisine tags, formatted address, hours of operation, photo gallery with at least one photo, menu with at least one section and item, and at least one review with star rating
**Verifies:** Screen 3 default loaded state — "Full listing: cover photo hero, name + meta, open/closed badge, address, hours, photo gallery, menu, reviews"

---

### SC-17: Listing page shows loading skeleton during transition

**Type:** e2e (UI)
**Given** the user navigates to a listing page under throttled network conditions
**When** the page is transitioning
**Then** a hero skeleton and content row skeletons are visible before the real content appears
**Verifies:** Screen 3 loading state — "Hero skeleton, content area skeleton rows"

---

### SC-18: Incomplete listing shows per-section placeholder messages

**Type:** e2e (UI)
**Given** a restaurant in the mock dataset has no menu data
**When** the user views that restaurant's listing page
**Then** the menu section displays a placeholder message (e.g. "Menu not yet available")
**And** the remaining 5 sections are still displayed normally
**Verifies:** Screen 3 incomplete state — "Per-section placeholder messages for missing dimensions"

---

### SC-19: Open now badge shows correct open status

**Type:** e2e (UI)
**Given** a restaurant listing page is viewed during the restaurant's open hours
**When** the listing page renders
**Then** a badge with text "Open now" (or equivalent) is prominently visible
**And** the badge has a green or success visual treatment
**And** the closing time is displayed (e.g. "Closes at 10pm")
**Verifies:** Screen 3 open state — "Open now badge + closes at time"

---

### SC-20: Closed badge shows next opening time

**Type:** e2e (UI)
**Given** a restaurant listing page is viewed outside the restaurant's open hours
**When** the listing page renders
**Then** a badge with text "Closed" is prominently visible
**And** the badge has a red or danger visual treatment
**And** the next opening time is displayed (e.g. "Opens Friday at 5pm")
**Verifies:** Screen 3 closed state — "Closed badge + opens [day] at [time]"

---

### SC-21: Hours accordion expands to show full week

**Type:** e2e (UI)
**Given** the user is on a listing page showing today's hours
**When** the user clicks "Show full week"
**Then** a table or list showing hours for all 7 days is visible
**And** the toggle text changes to "Hide full week" (or equivalent)
**When** the user clicks it again
**Then** the full week hours collapse and only today's hours are shown
**Verifies:** Screen 3 hours interaction — "Show full week ▼ / Hide full week ▲ accordion"

---

### SC-22: Photo gallery is horizontally scrollable

**Type:** e2e (UI)
**Given** the user is on a listing page with 3 or more photos
**When** the photo gallery section is visible
**Then** photo thumbnails are laid out horizontally
**And** the gallery can be scrolled horizontally to reveal additional photos
**Verifies:** Screen 3 photo gallery — "Horizontal scroll; min 3 photos"

---

### SC-23: Clicking a photo opens the lightbox

**Type:** e2e (UI)
**Given** the user is on a listing page
**When** the user clicks the first photo thumbnail in the gallery
**Then** a full-screen lightbox overlay appears displaying the photo
**And** the lightbox shows a counter (e.g. "1 / 5")
**And** a close button is visible in the lightbox
**Verifies:** Screen 3 lightbox open — "Click any photo → full-screen lightbox"

---

### SC-24: Lightbox arrow keys navigate between photos

**Type:** e2e (UI)
**Given** the lightbox is open showing photo 1 of 5
**When** the user presses the right arrow key
**Then** photo 2 is displayed in the lightbox and the counter reads "2 / 5"
**When** the user presses the left arrow key
**Then** photo 1 is displayed again and the counter reads "1 / 5"
**Verifies:** Screen 3 lightbox keyboard navigation — "Arrow keys to navigate"

---

### SC-25: Escape key closes the lightbox

**Type:** e2e (UI)
**Given** the lightbox is open
**When** the user presses the Escape key
**Then** the lightbox overlay is dismissed
**And** focus returns to the photo thumbnail that triggered the lightbox
**Verifies:** Screen 3 lightbox close — "Escape to close; focus returns to trigger element"

---

### SC-26: Menu section accordion expands and collapses

**Type:** e2e (UI)
**Given** the user is on a listing page with a menu containing multiple sections
**When** the user clicks the "Desserts" menu section header
**Then** the dessert items expand and are visible
**When** the user clicks the section header again
**Then** the dessert items collapse and are hidden
**Verifies:** Screen 3 menu accordion interaction — "Sections collapsed/expanded on click"

---

### SC-27: Review form expands on "Write a review" click

**Type:** e2e (UI)
**Given** the user is on a listing page and the review form is collapsed
**When** the user clicks "Write a review"
**Then** the review form expands inline showing a star rating selector and a text input field
**And** the form is visible without navigating away from the listing page
**Verifies:** Screen 3 review form open — "Inline form expands below existing reviews"

---

### SC-28: Star rating selector highlights stars on click

**Type:** e2e (UI)
**Given** the review form is open on a listing page
**When** the user clicks the 4th star in the star selector
**Then** stars 1 through 4 are visually highlighted (filled/lit)
**And** the 5th star remains unhighlighted
**When** the user clicks the 2nd star
**Then** only stars 1 and 2 are highlighted and stars 3–5 are not
**Verifies:** Screen 3 star rating interaction — "Click to rate; stars 1–N highlighted"

---

### SC-29: Review submission shows success message

**Type:** e2e (UI)
**Given** the review form is open, the user has selected a star rating, and entered review text
**When** the user clicks the Submit button
**Then** a success message reading "Your review has been submitted" (or equivalent) is visible on the page
**And** the form input fields are no longer shown
**Verifies:** Screen 3 review submitted state — "Success message inline; form dismissed (mock)"

---

### SC-30: Share button shows "Link copied" toast on desktop

**Type:** e2e (UI)
**Given** the user is on a listing page in a desktop browser (Playwright Chromium, viewport ≥768px)
**And** the Web Share API is not available (standard desktop Chromium behaviour)
**When** the user clicks the Share button
**Then** a toast notification containing "Link copied" (or equivalent) appears on screen
**And** the toast is dismissed after approximately 2–3 seconds
**Verifies:** Screen 3 share interaction — "Copy link fallback with 'Link copied!' toast on desktop"; TR-8

---

### SC-31: Back button returns to results page

**Type:** e2e (UI)
**Given** the user navigated to a listing page from a filtered search results page
**When** the user clicks the browser back button (or the in-app "Back to results" link)
**Then** the search results page is displayed
**And** the previously applied filters are still active
**Verifies:** Listing → Results back navigation — "Back navigates to results with filters intact"

---

### SC-32: Keyboard navigation reaches all interactive elements

**Type:** e2e (UI)
**Given** the user is on the search results page
**When** the user repeatedly presses the Tab key from the top of the page
**Then** focus moves sequentially through all interactive elements: header search, filter pills, restaurant cards
**And** no interactive element is skipped or unreachable by keyboard alone
**Verifies:** Accessibility — "All interactive elements keyboard reachable"

---

### SC-33: Focus ring visible on all interactive elements

**Type:** e2e (UI)
**Given** the user navigates through the listing page using the Tab key
**When** focus lands on any interactive element (buttons, links, form inputs)
**Then** a visible focus indicator (outline or ring) is displayed around the focused element
**And** the focus indicator is visible against the element's background (minimum 3:1 contrast)
**Verifies:** Accessibility — "Visible focus styles on all interactive elements"

---

### SC-34: Desktop layout renders at ≥768px viewport

**Type:** e2e (UI)
**Given** the Playwright browser is set to a 1280×800 viewport
**When** the user navigates to the search results page
**Then** the filter sidebar is visible as a persistent side panel
**And** restaurant cards are displayed in a 3-column grid
**And** the listing page sticky sidebar is visible alongside the main content
**Verifies:** TR-14 — "Desktop primary target ≥ 768px; filter sidebar visible; 3-column card grid"

---

### SC-35: Mobile layout adapts at <768px viewport

**Type:** e2e (UI)
**Given** the Playwright browser is set to a 375×812 viewport (iPhone-equivalent)
**When** the user navigates to the search results page
**Then** the filter sidebar is not visible as a side panel
**And** a "Filters" button is visible to open filters
**And** restaurant cards are displayed in a single-column layout
**And** the listing page sticky sidebar is not shown (share button remains in header)
**Verifies:** TR-14 — "Mobile adaptation < 768px; filters collapse to button; single-column cards"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
