# Query Patterns

*Effort: restaurant-search-and-discovery*  *Authored: 2026-06-05*

---

| Pattern | Entity | Filters | Sort | Source | Notes |
|---------|--------|---------|------|--------|-------|
| Search restaurants by city | RESTAURANT | city_id = ? | avg_rating DESC, review_count DESC | BR-1, TR-3 | Primary search entry point |
| Search restaurants by neighbourhood | RESTAURANT | city_id = ?, neighbourhood = ? | avg_rating DESC | BR-1, UX Screen 2 | Neighbourhood filter |
| Filter restaurants by cuisine | RESTAURANT_CUISINE | cuisine_id IN (?) | — | BR-2, UX Screen 2 | Combined with city search |
| Filter restaurants by price range | RESTAURANT | city_id = ?, price_range = ? | avg_rating DESC | BR-2, UX Screen 2 | Price filter |
| Filter restaurants by dietary option | RESTAURANT | dietary_options contains ? | — | BR-2, UX Screen 2 | Dietary restriction filter |
| Filter restaurants by meal period | RESTAURANT | meal_periods contains ? | — | BR-3, UX Screen 2 | Meal period filter |
| Filter restaurants open now | RESTAURANT_HOURS | restaurant_id IN (?), day_of_week = ?, current_time BETWEEN open AND close | — | BR-3, TR-9 | Timezone-aware; expensive at scale — see note below |
| Get restaurant by ID | RESTAURANT | id = ? | — | BR-4, UX Screen 3, TR-6 | Listing page load |
| Get restaurant by slug | RESTAURANT | slug = ? | — | BR-8, TR-6, TR-8 | Deep link / share URL resolution |
| Get restaurant hours by restaurant | RESTAURANT_HOURS | restaurant_id = ? | day_of_week ASC | BR-3, UX Screen 3 | Full week hours display |
| Get photos by restaurant | PHOTO | restaurant_id = ? | sort_order ASC | BR-6, UX Screen 3 | Photo gallery |
| Get menu by restaurant | MENU + MENU_SECTION + MENU_ITEM | menu.restaurant_id = ? | section.position ASC, item.position ASC | BR-5, UX Screen 3 | Full menu load |
| Get reviews by restaurant (recent) | REVIEW | restaurant_id = ?, reviewed_at >= 12 months ago | reviewed_at DESC | BR-7, TR-10 | Default review display |
| Get reviews by restaurant (all) | REVIEW | restaurant_id = ? | reviewed_at DESC | TR-10 | "Show older reviews" toggle |
| Compute average rating (recent) | REVIEW | restaurant_id = ?, reviewed_at >= 12 months ago | — | TR-10, TR-11 | Rating on listing page and search cards |
| Create review | REVIEW | — | — | BR-7, TR-13 | Review submission |
| List cities for autocomplete | CITY | name ILIKE ? | name ASC | BR-1, UX Screen 1 | City search autocomplete |
| Get cuisine list | CUISINE | — | name ASC | BR-2, UX Screen 1 | Populate cuisine filter pills |
| Get cuisines for restaurant | RESTAURANT_CUISINE | restaurant_id = ? | — | UX Screen 3 | Cuisine tags on listing page |
| Create user | USER | — | — | Future auth | Account creation |
| Get user by ID | USER | id = ? | — | Future auth | Session / review attribution |

---

## Scale Note — "Filter restaurants open now"

At MVP scale (30 restaurants, client-side) this is trivial. At production scale, joining
RESTAURANT with RESTAURANT_HOURS and evaluating time ranges across a large dataset is
expensive. Mitigation options (v2):
- Denormalise an `is_open_now` boolean on RESTAURANT, refreshed by a cron job per timezone
- Cache open/closed status in Redis keyed by `restaurant:{id}:open`, with TTL aligned to the next open/close transition
