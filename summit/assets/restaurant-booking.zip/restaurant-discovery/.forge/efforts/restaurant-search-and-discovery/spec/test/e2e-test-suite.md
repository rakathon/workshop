# E2E Test Suite — Restaurant Search and Discovery

*Capability/Effort:* `.forge/efforts/restaurant-search-and-discovery/spec/test/`
*Authored:* 2026-06-05
*Effort:* restaurant-search-and-discovery

## Why Test This

DineFind's core value proposition is a single-session restaurant decision — a diner opens the app, searches, and leaves with enough confidence to go. Every BR in this effort is P0: if search doesn't return results, if filters don't narrow them, if the listing page is missing any of its six information dimensions, or if a shared link fails to resolve, the product fails its fundamental job. These E2E scenarios verify the complete user-observable journeys from search entry through to listing view and share action, using the static JSON mock dataset as the live data layer. They must pass before any release candidate is considered stable.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: Search by city returns scoped results | BR-1: city search returns results within the area |
| SC-2: Search by neighbourhood returns scoped results | BR-1: neighbourhood search returns results |
| SC-3: Search results load within 3 seconds | BR-1: results load within 3 seconds |
| SC-4: Cuisine filter narrows results to matching restaurants | BR-2: cuisine filter is functional |
| SC-5: Multiple filters applied simultaneously narrow results | BR-2, BR-3: filters combine correctly |
| SC-6: Price range filter returns only matching restaurants | BR-2: price range filter functional |
| SC-7: Dietary restriction filter returns matching restaurants | BR-2: dietary filters available and functional |
| SC-8: Open now filter shows only currently open restaurants | BR-3: open now filter uses current time |
| SC-9: Open now excludes restaurants with no hours data | TR-9: no-hours restaurants excluded from open now |
| SC-10: Meal period filter returns restaurants serving that period | BR-3: meal period filter functional |
| SC-11: Timezone-aware open/closed status is correct for non-local city | TR-9: open status computed in restaurant's timezone |
| SC-12: Results sorted by recent rating descending | TR-11: sort by recent average rating, review count secondary |
| SC-13: Listing page displays all 6 dimensions | BR-4: all 6 dimensions present on listing page |
| SC-14: Listing page loads within 2 seconds | BR-4: listing page render time |
| SC-15: Menu displays inline with sections and prices | BR-5: menu shown directly on listing page |
| SC-16: Menu freshness date is displayed | BR-5: menu last-updated date shown |
| SC-17: Photo gallery shows minimum 3 photos | BR-6: minimum 3 photos displayed |
| SC-18: Star rating reflects only past-12-months reviews | TR-10: rating computed from recent reviews only |
| SC-19: Only recent reviews shown by default | TR-10: reviews filtered to past 12 months |
| SC-20: Older reviews visible via toggle | TR-10: older reviews accessible behind toggle |
| SC-21: Review form shown on listing page | BR-7: review submission form present |
| SC-22: Review submission shows success message | TR-13: mock success on submit |
| SC-23: Share generates a deep link to the listing | BR-8: share action generates correct URL |
| SC-24: Shared link resolves to correct listing without app install | BR-8: shared link resolves correctly |
| SC-25: Cross-city search works for city not matching user location | BR-9: any US city searchable |
| SC-26: City label shown on results page | BR-9: results labelled with selected city |
| SC-27: Filter state persists in URL query parameters | TR-6: active filters reflected in URL |
| SC-28: Filter state restored on page load from URL | TR-6: filter state restored from query params |
| SC-29: Back navigation returns to search results with filters intact | TR-6: browser back works correctly |
| SC-30: Empty state shown when no results match filters | UX spec Screen 2: empty state |
| SC-31: Incomplete listing deprioritised in search results | BR-4: incomplete listings ranked lower |

## Scenarios

### SC-1: Search by city returns scoped results

**Type:** e2e
**Given** the user is on the home page at `/`
**When** they enter "Austin, TX" in the city input and submit the search
**Then** the results page at `/search?city=Austin%2C+TX` is displayed
**And** all restaurant cards shown belong to Austin, TX
**And** the results heading reads "Restaurants in Austin, TX"
**Verifies:** BR-1 — "User can enter a US city and receive restaurant results within that area"

---

### SC-2: Search by neighbourhood returns scoped results

**Type:** e2e
**Given** the user is on the home page at `/`
**When** they enter "East Austin" in the city input and submit the search
**Then** the results page displays only restaurants whose `address.neighbourhood` matches "East Austin"
**Verifies:** BR-1 — "User can enter a neighbourhood and receive restaurant results within that area"

---

### SC-3: Search results load within 3 seconds

**Type:** e2e
**Given** a standard 4G network connection (simulated at 20 Mbps / 30ms latency)
**When** the user submits a city search for "New York, NY"
**Then** the search results page is fully rendered within 3 seconds
**Verifies:** BR-1 — "Search results load within 3 seconds for any valid US location"

---

### SC-4: Cuisine filter narrows results to matching restaurants

**Type:** e2e
**Given** the user is on the search results page for "Austin, TX" with no filters applied
**When** they select "Thai" from the cuisine filter
**Then** only restaurants with `cuisine` containing "Thai" are displayed
**And** the active filter chip "Thai" appears in the filter strip
**Verifies:** BR-2 — "At least 8 cuisine types are available as filters and functional"

---

### SC-5: Multiple filters applied simultaneously narrow results

**Type:** e2e
**Given** the user is on the search results page for "Austin, TX"
**When** they select cuisine "Thai" AND price "$$" AND dietary "Vegetarian"
**Then** only restaurants matching all three criteria simultaneously are displayed
**And** the URL reflects all three active filters as query parameters
**Verifies:** BR-2, BR-3 — "Filters combine correctly"; "Filter state reflected in URL"

---

### SC-6: Price range filter returns only matching restaurants

**Type:** e2e
**Given** the user is on the search results page for "Chicago, IL"
**When** they select the "$" price filter
**Then** only restaurants with `priceRange === "$"` are shown
**Verifies:** BR-2 — "Price range filter ($ / $$ / $$$ / $$$$) is available and functional"

---

### SC-7: Dietary restriction filter returns matching restaurants

**Type:** e2e
**Given** the user is on the search results page for "New York, NY"
**When** they select the "Vegan" dietary filter
**Then** only restaurants whose `dietaryOptions` includes "vegan" are displayed
**Verifies:** BR-2 — "Dietary restriction filters are available (vegetarian, vegan, gluten-free)"

---

### SC-8: Open now filter shows only currently open restaurants

**Type:** e2e
**Given** the current time is known (e.g. Thursday 7:00pm local to Austin, TX)
**And** the mock dataset contains at least one Austin restaurant open at that time and at least one closed
**When** the user enables the "Open now" toggle on the results page
**Then** only restaurants whose hours cover the current time in their local timezone are displayed
**And** closed restaurants are hidden from results
**Verifies:** BR-3 — "Open now toggle filters results to restaurants currently open based on their listed hours"

---

### SC-9: Open now filter excludes restaurants with no hours data

**Type:** e2e
**Given** a restaurant in the mock dataset has no `hours` object (all days null or absent)
**When** the user enables the "Open now" toggle
**Then** the restaurant with no hours data is not shown in filtered results
**Verifies:** TR-9 — "Restaurants with no hours data must be excluded from open now results"

---

### SC-10: Meal period filter returns restaurants serving that period

**Type:** e2e
**Given** the user is on the search results page for "Austin, TX"
**When** they select the "Brunch" meal period filter
**Then** only restaurants with `mealPeriods` including "brunch" are displayed
**Verifies:** BR-3 — "Users can filter by meal period (breakfast, brunch, lunch, dinner)"

---

### SC-11: Timezone-aware open/closed status is correct for non-local city

**Type:** e2e
**Given** the user's browser is in the "America/New_York" timezone (UTC-5)
**And** a restaurant in Austin, TX has hours "11:00–22:00" with timezone "America/Chicago" (UTC-6)
**And** the current wall-clock time is 10:30pm Eastern (22:30 ET = 21:30 CT)
**When** the user views the Austin restaurant listing
**Then** the restaurant is shown as **closed** (21:30 CT is after 22:00 closing time)
**And** if the user were viewing at 10:30pm ET on a day where 21:30 CT < closing, it would show as **open**
**Verifies:** TR-9 — "Comparison must be performed in the restaurant's local timezone, not the user's browser timezone"

---

### SC-12: Results sorted by recent rating descending

**Type:** e2e
**Given** the mock dataset contains Austin Thai restaurants with different average ratings based on reviews from the past 12 months
**When** the user views search results for Austin, Thai cuisine
**Then** the restaurant with the highest recent-review average rating appears first
**And** among restaurants with equal ratings, the one with more recent reviews appears higher
**Verifies:** TR-11 — "Search results sorted by average rating (recent reviews) descending; review count as secondary sort"

---

### SC-13: Listing page displays all 6 dimensions

**Type:** e2e
**Given** a restaurant in the mock dataset has all 6 data dimensions populated
**When** the user navigates to `/restaurant/:id` for that restaurant
**Then** the listing page displays: cuisine tags, menu sections with items, photo gallery, hours of operation, formatted address, and at least one review with star rating
**Verifies:** BR-4 — "Every listing displays all 6 dimensions: cuisine, menu, photos, hours, location, reviews"

---

### SC-14: Listing page loads within 2 seconds

**Type:** e2e
**Given** a standard broadband connection
**When** the user navigates from the search results to a restaurant listing page
**Then** the listing page is fully rendered within 2 seconds of the navigation event
**Verifies:** BR-4 — "Listing page loads within 2 seconds on mobile and desktop"

---

### SC-15: Menu displays inline with sections and prices

**Type:** e2e
**Given** a restaurant listing with a fully populated menu
**When** the user views the listing page at `/restaurant/:id`
**Then** the menu is visible on the page without any redirect or external link
**And** menu sections (e.g. Starters, Mains, Desserts) are displayed with item names and prices
**Verifies:** BR-5 — "Menu displayed directly on listing page; shows sections and item names with prices"

---

### SC-16: Menu freshness date is displayed

**Type:** e2e
**Given** a restaurant in the mock dataset has `menu.lastUpdated` set to a date
**When** the user views the listing page
**Then** the menu section displays the last-updated date (e.g. "Last updated 14 days ago")
**Verifies:** BR-5 — "Menu data freshness is displayed so users can assess reliability"

---

### SC-17: Photo gallery shows minimum 3 photos

**Type:** e2e
**Given** a restaurant in the mock dataset has at least 3 entries in its `photos` array
**When** the user views the listing page
**Then** at least 3 photo thumbnails are visible in the gallery
**And** photos are browsable within the gallery view without leaving the page
**Verifies:** BR-6 — "Each listing displays a minimum of 3 photos; photos browsable in gallery view"

---

### SC-18: Star rating reflects only past-12-months reviews

**Type:** e2e
**Given** a restaurant has 3 reviews: two from 6 months ago (ratings 5 and 4) and one from 18 months ago (rating 1)
**When** the user views the listing page
**Then** the displayed average star rating is 4.5 (average of 5 and 4 only)
**And** the rating is not 3.33 (which would include the 18-month-old review)
**Verifies:** TR-10 — "Displayed star rating computed only from reviews within the past 12 months"

---

### SC-19: Only recent reviews shown by default

**Type:** e2e
**Given** a restaurant has 2 reviews from within the past 12 months and 1 review from 18 months ago
**When** the user views the reviews section of the listing page
**Then** only the 2 recent reviews are displayed by default
**And** the 18-month-old review is not visible
**Verifies:** TR-10 — "Only reviews from the past 12 months shown by default"

---

### SC-20: Older reviews visible via toggle

**Type:** e2e
**Given** a restaurant has reviews older than 12 months and the user is on the listing page
**When** the user clicks "Show older reviews"
**Then** the review list expands to include reviews older than 12 months
**And** the older reviews are appended below the recent ones
**Verifies:** TR-10 — "Older reviews accessible behind a toggle"

---

### SC-21: Review form shown on listing page

**Type:** e2e
**Given** the user is on a restaurant listing page
**When** the user clicks "Write a review"
**Then** the review form expands inline showing a star rating selector and a text input
**And** the form is accessible without navigating away from the listing page
**Verifies:** BR-7 — "Users can submit a review (star rating + text) directly from the listing page"

---

### SC-22: Review submission shows success message

**Type:** e2e
**Given** the user has opened the review form on a listing page
**And** the user has selected a star rating and entered review text
**When** the user submits the form
**Then** a success message "Your review has been submitted" is displayed inline
**And** the form fields are cleared or hidden
**Verifies:** TR-13 — "On submission, form displays success message; no persistence required (mock)"

---

### SC-23: Share generates a deep link to the listing

**Type:** e2e
**Given** the user is on a restaurant listing page at `/restaurant/lotus-thai-kitchen`
**When** the user clicks the Share button on a browser that does not support the Web Share API
**Then** the URL `/restaurant/lotus-thai-kitchen` is copied to the clipboard
**And** a confirmation message "Link copied!" is displayed
**Verifies:** BR-8 — "Share action works on web via copy-link"; TR-8 — "Copy-link fallback with visible confirmation"

---

### SC-24: Shared link resolves to correct listing without app install

**Type:** e2e
**Given** a user has a direct URL `/restaurant/lotus-thai-kitchen` (as received via share)
**When** a new browser session navigates directly to that URL
**Then** the listing page for "Lotus Thai Kitchen" is displayed in full
**And** no login, install prompt, or redirect to the home page occurs
**Verifies:** BR-8 — "Shared links resolve to the correct listing page without requiring the recipient to have the app installed"

---

### SC-25: Cross-city search works for city not matching user location

**Type:** e2e
**Given** the user's device location is detected as "San Francisco, CA"
**When** the user searches for "Austin, TX" by typing it in the city input
**Then** the results page shows restaurants in Austin, TX — not San Francisco, CA
**And** the city label on the results page reads "Austin, TX"
**Verifies:** BR-9 — "Users can search restaurants in any US city without being constrained to their current location"

---

### SC-26: City label shown on results page

**Type:** e2e
**Given** the user has searched for restaurants in "Chicago, IL"
**When** the results page is displayed
**Then** a label reading "Restaurants in Chicago, IL" (or equivalent) is visible on the results page
**Verifies:** BR-9 — "Search results scoped to the selected city and labelled clearly"

---

### SC-27: Filter state persists in URL query parameters

**Type:** e2e
**Given** the user is on the search results page
**When** the user applies cuisine "Italian", price "$$", and enables "Open now"
**Then** the browser URL contains `?cuisine=Italian&price=%24%24&openNow=true` (or equivalent encoding)
**And** copying and opening that URL in a new tab shows the same filtered results
**Verifies:** TR-6 — "All active filters must be reflected as query parameters so that search state is shareable via URL"

---

### SC-28: Filter state restored on page load from URL

**Type:** e2e
**Given** a URL `/search?city=Austin%2C+TX&cuisine=Thai&price=%24%24&openNow=true`
**When** a user navigates directly to that URL
**Then** the search results page loads with cuisine "Thai", price "$$", and "Open now" already active
**And** the filter chips for those values are displayed in the filter strip
**Verifies:** TR-6 — "Filter state must be restored from query parameters on page load"

---

### SC-29: Back navigation returns to search results with filters intact

**Type:** e2e
**Given** the user has arrived at a listing page by clicking a card from a filtered results page
**When** the user clicks the browser back button
**Then** the search results page is restored with the same filters and scroll position
**Verifies:** TR-6 — "Browser back/forward navigation must work correctly across all routes"

---

### SC-30: Empty state shown when no results match filters

**Type:** e2e
**Given** the user applies a combination of filters that no restaurant in the mock dataset satisfies (e.g. cuisine "Korean" in a city with no Korean restaurants)
**When** the search results page renders
**Then** an empty state message is displayed (e.g. "No restaurants match your filters")
**And** at least one actionable suggestion is shown (e.g. "Try removing the Open now filter")
**And** no restaurant cards are shown
**Verifies:** UX spec Screen 2 empty state — "No restaurants match your filters + suggestion to broaden"

---

### SC-31: Incomplete listing deprioritised in search results

**Type:** e2e
**Given** the mock dataset contains one restaurant missing a menu AND several restaurants with all 6 dimensions populated
**When** the user views search results for the city containing that restaurant
**Then** the restaurant with the missing menu appears lower in the results list than fully-populated restaurants with comparable ratings
**Verifies:** BR-4 — "A listing with any dimension missing is deprioritised in search results"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
