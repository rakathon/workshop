# UX Strategy & Spec — DineFind Restaurant Search & Discovery

*Effort: restaurant-search-and-discovery*
*Mode: greenfield (Mode B — synthesised token set)*
*Written: 2026-06-05*

---

## Problem Framing

**Problem statement:** How might we help US diners make a confident restaurant choice — given that the information they need is scattered across 6 different platforms — so that they can decide where to eat in a single session without switching apps?

**Users affected:** Any US diner in the pre-visit decision moment: locals exploring their own city, visitors planning ahead, and anyone who just wants to verify a specific restaurant's details before going.

**Current workaround / failure mode:** Open Google Maps for the pin, Yelp for reviews, the restaurant's own website for the menu, Instagram for photos. The research process is slow, fragmented, and often ends with the user giving up and going somewhere familiar. No single product was built around this job.

---

## Users & Jobs-to-be-Done

### Proto-Persona 1: The Local Explorer

**Goal:** Discover restaurants in parts of their city they don't know well — find something new that matches their mood.

**Job story:** When I want to try somewhere new on a Friday night, I want to browse restaurants by cuisine and neighbourhood with enough information to make a decision, so I can stop defaulting to the same three places I always go.

**Context of use:** Desktop or mobile browser, usually at home or on commute. Moderate urgency. Comfortable with technology. Mental model: "it should work like Google Maps but actually tell me about the food."

**Key anxieties:** Arriving somewhere that looks nothing like the photos. Reviews that are too old to trust. Menus that are only available as a PDF on a slow website.

---

### Proto-Persona 2: The Visiting Planner

**Goal:** Build a shortlist of restaurants in a city they're visiting, before they arrive.

**Job story:** When I'm travelling to a new US city next week, I want to research restaurants by cuisine and neighbourhood in advance, so I can spend my trip eating well instead of standing on a street corner debating where to go.

**Context of use:** Desktop, at home, with time to research. Low urgency in the planning phase. High expectations — this person has already done hotel and flight research and expects restaurant research to be equally easy.

**Key anxieties:** Information being out of date. Not knowing which neighbourhood to focus on. Reviews being dominated by tourists rather than locals.

---

### Proto-Persona 3: The Decisive Diner

**Goal:** Verify the details of a specific restaurant before going — are they open, what's on the menu, is it worth it?

**Job story:** When a friend recommends a restaurant and I want to check it out tonight, I want to quickly look up hours, menu, and recent reviews, so I can decide in under two minutes whether to go.

**Context of use:** Mobile browser, often on the go. High urgency. Wants speed over depth. Mental model: "like a business listing but focused on what I actually care about."

**Key anxieties:** Showing up to find the restaurant is closed. Menu being completely different from what was described. Not enough reviews to trust the rating.

---

## Success Signals

| Signal | Metric | Target |
|--------|--------|--------|
| Task success | % of sessions where user views a listing in full (all 6 dimensions) | ≥ 60% |
| Engagement | % of sessions that include at least one filter interaction | ≥ 40% |
| Adoption | % of first sessions resulting in a share action | ≥ 30% |
| Retention | Day-1 return rate | ≥ 40% |
| Happiness | Search-to-listing CTR | ≥ 80% |

**The one thing this must get right:** A diner must be able to open DineFind, find a restaurant that matches their need, and feel confident in that choice — all without leaving the app. If they open a second tab, we failed.

---

## Information Architecture

```
/ (Home — Search)
  └── /search (Results — filtered list)
        └── /restaurant/:id (Listing — single restaurant)
```

**Navigation model:** Minimal persistent header (logo + search bar). No sidebar. No complex nav. The product is three screens deep at most — navigation is primarily back-arrow and in-page. The search bar is always accessible from the header on results and listing pages.

**IA rationale:** The diner's mental model is linear: "I describe what I want → I see options → I pick one." Deep nav trees, category browsing pages, and editorial content would all distract from this job. The IA is deliberately shallow — breadth at the results level (many restaurants), depth at the listing level (all information about one restaurant).

---

## Key User Flows

### Flow 1: Discover by cuisine and city (Local Explorer / Visiting Planner)

**Trigger:** User lands on homepage with a city and cuisine in mind.

**Steps:**
1. User arrives at `/` — sees hero search with city input and cuisine quick-picks
2. User types a city name and selects a cuisine filter
3. User lands on `/search?city=austin&cuisine=thai` — sees restaurant cards sorted by rating
4. User optionally adds more filters (price, dietary, open now, meal period)
5. User clicks a restaurant card → lands on `/restaurant/:id`
6. User browses photos, reads menu, scans reviews, checks hours and address
7. User shares the listing or navigates back to results to compare another option

**Success state:** User has enough information to decide. They either share the link or navigate to the restaurant.

**Failure / edge cases:**
- Zero results for the filter combination → empty state with suggestions to broaden filters
- Restaurant listing has missing data → incomplete listing notice, prompt to check back

---

### Flow 2: Look up a specific restaurant (Decisive Diner)

**Trigger:** User knows a restaurant name and wants to verify details.

**Steps:**
1. User arrives at `/` — types restaurant name in search bar
2. Search returns the matching restaurant as the first result
3. User lands on `/restaurant/:id`
4. User checks open status, scans menu, reads 2–3 reviews, confirms address
5. Done in under 2 minutes

**Success state:** User has confirmed the restaurant is open, the menu looks right, and reviews are recent. They close the tab and go.

**Failure / edge cases:**
- Name search returns no results → clear "no results" state with search suggestions
- Restaurant is closed right now → prominent closed badge, show next opening time

---

### Flow 3: Submit a review (secondary)

**Trigger:** User has visited a restaurant and wants to leave a review from the listing page.

**Steps:**
1. User scrolls to reviews section on `/restaurant/:id`
2. User clicks "Write a review"
3. Review form expands inline — star rating selector + text field
4. User submits → success message "Your review has been submitted" (mock, no persistence)

**Success state:** User sees the success message. (Mock — review not actually saved.)

---

## Screen Inventory

### Screen 1: Home / Search Landing Page (`/`)

**Route:** `/`

**Purpose:** Give the user the fastest possible path to a restaurant search — one clear input, a city, and optionally a cuisine — so they can get to results in one action.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default | Page load | Hero with search bar (city input + cuisine pills), featured cuisine categories below |
| City entered | User types | Autocomplete dropdown with matching US cities |
| No city match | Unknown city string | "We don't have restaurants in [city] yet — try a nearby city" |

**Primary action:** Submit a search (city + optional cuisine/filters)

**Out of scope:** User authentication, saved searches, personalised recommendations, editorial content ("top picks this week")

---

### Screen 2: Search Results (`/search`)

**Route:** `/search?city=&cuisine=&price=&dietary=&mealPeriod=&openNow=`

**Purpose:** Show the matching restaurants for the user's query, filterable and scannable, so they can identify candidates quickly and click through to the one they want.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default (loaded) | Results available | Grid of restaurant cards (cover photo, name, cuisine, rating, price, open status) sorted by rating desc |
| Loading / skeleton | Data fetch | Card skeleton placeholders (grey boxes matching card dimensions) |
| Empty | No restaurants match filters | "No restaurants match your filters" + suggestions to remove the most restrictive filter |
| Filtered — no open results | "Open now" with all closed | "No restaurants are open right now — showing all results" with toggle to remove filter |
| Error | Data load failure | "Something went wrong loading restaurants. Try refreshing." |

**Primary action:** Click a restaurant card to view its listing

**Active filter display:** Applied filters shown as removable chips below the filter bar. "Clear all" link when ≥2 filters active.

**Out of scope:** Map view, list/grid toggle, save to favourites, user reviews from this screen

---

### Screen 3: Restaurant Listing Page (`/restaurant/:id`)

**Route:** `/restaurant/:id`

**Purpose:** Give the diner complete confidence about a single restaurant — every fact they need to decide whether to go — in one scrollable page.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default (loaded) | Restaurant data available | Full listing: cover photo hero, name + meta, open/closed badge, address, hours, photo gallery, menu, reviews |
| Loading / skeleton | Page transition | Hero skeleton, content area skeleton rows |
| Incomplete listing | Missing data dimensions | Per-section: "Menu not yet available" / "No photos yet" placeholder with gentle message |
| Restaurant closed | Current time outside hours | Prominent red "Closed" badge + "Opens [day] at [time]" |
| Restaurant open | Current time within hours | Green "Open now" badge + "Closes at [time]" |
| Review form open | User clicks "Write a review" | Inline form expands below existing reviews |
| Review submitted | User submits form | Success message inline: "Your review has been submitted — thanks!" |
| Share action | User clicks Share | Web Share API sheet (mobile) or "Link copied!" toast (desktop) |

**Primary action:** Share the restaurant listing

**Content priority order (scroll):**
1. Cover photo hero (full-width, ~50vh)
2. Restaurant name, cuisine tags, price range, open/closed status
3. Address (street, neighbourhood, city)
4. Hours of operation (today prominent, full week in accordion)
5. Photo gallery (horizontal scroll, 3+ photos)
6. Menu (sections → items with prices)
7. Reviews (rating summary, recency-filtered list, write-a-review form)

**Out of scope:** Reservations, delivery, map embed (address text only), user accounts, saved lists

---

## Interaction Notes

- **Filter chips:** Applied filters shown as removable pills. Clicking × on a chip removes that filter and updates results immediately (no reload).
- **Open/closed status:** Computed client-side from the restaurant's timezone and current hours. Updates in real time if the user's session spans an open/close boundary (unlikely but correct).
- **Review recency toggle:** "Show older reviews" text button below the 12-month filtered list. Clicking expands older reviews inline.
- **Photo gallery:** Horizontal scroll on desktop and mobile. Clicking a photo opens a full-screen lightbox overlay. Keyboard: arrow keys to navigate, Escape to close.
- **Menu accordion:** Sections collapsed by default on mobile (to avoid overwhelming scroll). Expanded by default on desktop.
- **Share button:** Web Share API on mobile (native sheet). On desktop or unsupported: copies URL to clipboard, shows a "Link copied!" toast for 2 seconds.
- **Search autocomplete:** City name input shows a dropdown of matching US cities from a static list. Keyboard navigable (arrow + Enter). Dismissed on Escape or outside click.
- **Filter bar:** Sticky below the header on the search results page. Filters: City (editable), Cuisine (multi-select pill group), Price (single select), Dietary (multi-select), Meal period (single select), Open now (toggle).

---

## Accessibility Notes

- All interactive elements (`<button>`, `<a>`) are keyboard reachable with visible focus rings (offset, brand-coloured).
- Photo gallery lightbox traps focus while open; returns focus to the triggering photo on close.
- Open/closed status badge communicates via text + colour (not colour alone) — "Open now" / "Closed" labels always present.
- Star rating display uses `aria-label="4.2 out of 5 stars"` on the rating element.
- Review submission form: all fields have associated `<label>`s; success message announced via `aria-live="polite"`.
- Cover photo hero: `alt` text describes the restaurant image content.
- Filter chips: each chip's × button has `aria-label="Remove [filter name] filter"`.
- `prefers-reduced-motion` respected — all transitions/animations disabled when set.
- Heading hierarchy: one `<h1>` per page (restaurant name on listing, "Find your next favourite restaurant" on home), `<h2>` for sections, `<h3>` for sub-sections.

---

## Assumptions & Open Questions

**Assumptions:**
- Users are not authenticated — no login, no saved state between sessions
- 30 mock restaurants cover enough variety (≥5 cuisines, ≥3 cities, mix of price ranges) to make filtering meaningful
- Review dates in mock data are within the past 12 months so recency filter shows results by default
- "Open now" is always computable because every mock restaurant has complete hours + timezone data
- Photo URLs from Unsplash are stable and won't expire during the MVP demo period

**Open questions:**
- Should the home page show a list of featured cities to help the Visiting Planner who doesn't know where to start? (Likely yes — helps discovery entry point, but not designed here yet)
- Should search also accept neighbourhood names as a primary search term, or is neighbourhood filtering only available on the results page?
- How should the app behave when a restaurant has only 1–2 reviews — show the average rating or withhold it until a minimum threshold is met?
