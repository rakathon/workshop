# Implementation Plan: Restaurant Search and Discovery

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

```mermaid
gantt
    title  Restaurant Search and Discovery — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Project Scaffold & Data
    Scaffold Vite + React + TS project           :task1, 1, 2
    Author JSON mock dataset (30 restaurants)    :task2, 1, 2
    Project observable (dev server running)      :milestone, m0, 2, 0

    section Home Screen — Search Entry
    City autocomplete component                  :task3, 2, 3
    Cuisine pill filter component                :task4, 2, 3
    Home page layout + search form               :task5, 2, 3
    Global state context + URL routing           :crit, task6, 2, 3
    Home screen observable                       :milestone, m1, 3, 0

    %% Wave 2: Scaffold completes, Home & Search begins

    section Search Results Screen
    Search + filter engine (client-side)         :crit, task7, 3, 4
    Restaurant card component                    :task8, 3, 4
    Filter sidebar + chips                       :task9, 3, 4
    Search results page                          :task10, 3, 4
    Results screen observable                    :milestone, m2, 4, 0

    section Restaurant Listing Screen
    Listing page layout + all 6 sections         :task11, 4, 5
    Photo gallery + lightbox                     :task12, 4, 5
    Menu accordion component                     :task13, 4, 5
    Review section + review form                 :task14, 4, 5
    Share feature                                :task15, 4, 5
    Listing screen observable                    :milestone, m3, 5, 0

    section Testing
    Playwright e2e test suite                    :task16, 5, 6
    UI e2e test suite                            :task17, 5, 6
    All tests passing                            :milestone, m4, 6, 0
```

---

## Wave 1 — Project Scaffold & Mock Data

### TASK-001 [auto][wave:1]

- [x] Scaffold the Vite + React + TypeScript project with Tailwind CSS, React Router, and Playwright dev dependencies — confirm all tools start cleanly before any feature work begins. (09ad429)

**Satisfies:** TR-1, TR-14, TR-16, TR-17
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-002 [auto][wave:1]

- [x] Author the complete JSON mock dataset: `src/data/cities.json`, `src/data/cuisines.json`, `src/data/restaurants.json` (21 restaurants across 5 US cities, 8+ cuisine types, all 6 data dimensions populated, 2–3 reviews per restaurant within the past 12 months), and `src/data/users.json` — fully conformant to the schema defined in `spec/storage/json-schema.md`. (09ad429)

**Satisfies:** TR-2, TR-5, TR-12, TR-13
**Standards:** none
**Required tests:** none (data authoring task — integrity validated by TASK-003 data validator)

---

### TASK-003 [auto][wave:1]

- [x] Write a TypeScript data validation script (`scripts/validate-data.ts`) that enforces all constraints from `spec/storage/json-schema.md`: unique IDs and slugs, FK integrity, minimum photo/review counts, rating 1–5, valid IANA timezones, `isComplete` flag accuracy, and `recentAverageRating` consistency — run via `npm run validate-data` and exit non-zero on any violation. (09ad429)

**Satisfies:** TR-2, TR-5
**Standards:** none
**Required tests:** none (tooling task — correctness verified by running against the mock dataset)

---

## Wave 2 — Foundation: State, Routing, and Shared Components

### TASK-004 [auto][wave:2]

- [x] Implement the React Router configuration with all three routes (`/`, `/search`, `/restaurant/:id`), URL query parameter serialisation/deserialisation for all filter dimensions (city, cuisine, price, dietary, mealPeriod, openNow), and browser back/forward correctness. (9e87403)

**Satisfies:** TR-6, BR-9
**Standards:** none
**Required tests:** none (routing/config task)

---

### TASK-005 [auto][wave:2]

- [x] Implement the global `FilterContext` (React Context + `useContext`) that manages active city selection and filter state, with URL query params as the source of truth — state is initialised from URL on mount and updated to URL on every filter change. (9e87403)

**Satisfies:** TR-15, TR-6
**Standards:** none
**Required tests:** none (state scaffolding task)

---

### TASK-006 [tdd][wave:2]

- [x] Implement the client-side search and filter engine (`src/lib/filterRestaurants.ts`): composable AND-filters for city, neighbourhood, cuisine, price range, dietary options, meal period, open-now (timezone-aware via IANA timezone field), name search, result sort (recentAverageRating DESC, recentReviewCount DESC), and incomplete-listing deprioritisation. (9e87403)

**Satisfies:** TR-3, TR-9, TR-11, BR-1, BR-2, BR-3, BR-9
**Standards:** none
**Required tests:**
- [x] `filterByCity_returnsOnlyMatchingCity`
- [x] `filterByCuisine_multiSelect_returnsUnion`
- [x] `filterByPriceRange_returnsExactMatch`
- [x] `filterByDietary_allSelectedMustMatch`
- [x] `filterByMealPeriod_returnsContaining`
- [x] `openNowFilter_usesRestaurantTimezone_notBrowserTimezone`
- [x] `openNowFilter_excludesRestaurantsWithNoHours`
- [x] `sortResults_byRecentRatingDesc_thenReviewCountDesc`
- [x] `incompleteListings_sortedToBottom`
- [x] `multipleFilters_combinedAsAnd`

---

### TASK-007 [tdd][wave:2]

- [x] Implement the review recency utilities (`src/lib/reviewUtils.ts`): filter reviews to past 12 months, compute `recentAverageRating` from filtered set, sort by `reviewedAt` descending. (9e87403)

**Satisfies:** TR-10, BR-7
**Standards:** none
**Required tests:**
- [x] `filterRecentReviews_excludesOlderThan12Months`
- [x] `computeRecentAverageRating_ignoresOldReviews`
- [x] `sortReviews_mostRecentFirst`

---

### TASK-008 [auto][wave:2]

- [x] Implement shared UI primitives: `<OpenBadge>`, `<StarRating>`, `<PriceRange>`, cuisine `<Tag>`, `<SkeletonCard>` / `<SkeletonListing>`. (9e87403)

**Satisfies:** BR-4, BR-7, TR-14
**Standards:** none
**Required tests:** none (presentational component task)

---

## Wave 3 — Home Screen: Search Entry

### TASK-009 [tdd][wave:3]

- [x] Implement the `<CityAutocomplete>` input: filters the `cities.json` list as the user types, renders a keyboard-navigable dropdown (↑↓ Enter Escape), selects a city to populate the input, and dismisses on outside click. (684d3d6)

**Satisfies:** BR-1, BR-9
**Standards:** none
**Required tests:**
- [x] `cityAutocomplete_showsDropdownOnInput`
- [x] `cityAutocomplete_filtersResultsByQuery`
- [x] `cityAutocomplete_selectsOnEnter`
- [x] `cityAutocomplete_dismissesOnEscape`

---

### TASK-010 [auto][wave:3]

- [x] Implement the `<CuisinePills>` quick-pick component: toggleable pills, single-selection, pre-fills cuisine input on click. (684d3d6)

**Satisfies:** BR-2
**Standards:** none
**Required tests:** none

---

### TASK-011 [auto][wave:3]

- [x] Implement the Home page (`/`) layout with hero, search bar, cuisine pills, occasion shortcuts, and search navigation to `/search`. (684d3d6)

**Satisfies:** BR-1, BR-9, TR-14
**Standards:** none
**Required tests:** none

---

## Wave 4 — Search Results Screen

### TASK-012 [auto][wave:4]

- [x] Implement the `<RestaurantCard>` component: cover photo, name, cuisine, price, star rating, open badge, hover elevation, click-through to listing. (8e43f35)

**Satisfies:** BR-4, TR-14
**Standards:** none
**Required tests:** none

---

### TASK-013 [auto][wave:4]

- [x] Implement the `<FilterSidebar>` with all filter dimensions: cuisine multi-select, price, dietary, meal period, open-now toggle, clear all. (8e43f35)

**Satisfies:** BR-2, BR-3, TR-14
**Standards:** none
**Required tests:** none

---

### TASK-014 [auto][wave:4]

- [x] Implement the Search Results page (`/search`): client-side filtering, restaurant card grid, active filter chips, result count, empty state. (8e43f35)

**Satisfies:** BR-1, BR-2, BR-3, BR-9, TR-3, TR-11, TR-14
**Standards:** none
**Required tests:** none

---

## Wave 5 — Restaurant Listing Screen

### TASK-015 [auto][wave:5]

- [x] Implement listing page hero: cover photo, name, cuisine tags, price, star rating, open badge, address, hours accordion. (ded7fcd)

**Satisfies:** BR-4, BR-3, TR-7, TR-9, TR-14
**Standards:** none
**Required tests:** none

---

### TASK-016 [auto][wave:5]

- [x] Implement `<PhotoGallery>`: horizontal-scroll thumbnails, lightbox with ←→ keyboard navigation, Escape to close, accessible aria-labels. (ded7fcd)

**Satisfies:** BR-6, TR-12
**Standards:** none
**Required tests:** none

---

### TASK-017 [auto][wave:5]

- [x] Implement `<MenuDisplay>`: section accordions with emoji headers, freshness date, item prices, graceful empty state. (ded7fcd)

**Satisfies:** BR-5, TR-14
**Standards:** none
**Required tests:** none

---

### TASK-018 [auto][wave:5]

- [x] Implement `<ReviewSection>`: rating summary with breakdown bars, recency-filtered reviews, show older toggle, star selector, mock submit success. (ded7fcd)

**Satisfies:** BR-7, TR-10, TR-13
**Standards:** none
**Required tests:** none

---

### TASK-019 [auto][wave:5]

- [x] Implement Share feature: Web Share API on mobile, clipboard copy fallback with "Link copied!" toast on desktop. (ded7fcd)

**Satisfies:** BR-8, TR-8
**Standards:** none
**Required tests:** none

---

### TASK-020 [auto][wave:5]

- [x] Implement Restaurant Listing page (`/restaurant/:id`): full composition, sticky sidebar, back navigation, skeleton loading state, deep link resolution. (ded7fcd)

**Satisfies:** BR-4, BR-5, BR-6, BR-7, BR-8, TR-6, TR-7, TR-16
**Standards:** none
**Required tests:** none

---

## Wave 6 — Testing

### TASK-021 [e2e-test][wave:6]

- [ ] Implement the system E2E test suite from `spec/test/e2e-test-suite.md` using Playwright — 31 scenarios. (deferred — test implementation post-MVP)

**Satisfies:** BR-1 through BR-9, TR-6, TR-8, TR-9, TR-10, TR-11, TR-13
**Standards:** none
**type:** e2e-test
**target:** `.forge/efforts/restaurant-search-and-discovery/spec/test/e2e-test-suite.md`
**language:** TypeScript
**depends_on:** TASK-011, TASK-014, TASK-020

---

### TASK-022 [e2e-test][wave:6]

- [ ] Implement the UI E2E test suite from `spec/test/ui-e2e-test-suite.md` using Playwright — 35 scenarios. (deferred — test implementation post-MVP)

**Satisfies:** BR-1 through BR-9, TR-14
**Standards:** none
**type:** e2e-test
**target:** `.forge/efforts/restaurant-search-and-discovery/spec/test/ui-e2e-test-suite.md`
**language:** TypeScript
**depends_on:** TASK-011, TASK-014, TASK-020
