# Implementation Plan: Order Placement and Delivery Tracking

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

The effort delivers across four feature clusters in this sequence:
1. **Cart & Menu** — user can add items and build an order (BR-2, BR-6 badge)
2. **Checkout & Payment** — user can enter address, review fees, and pay (BR-3, BR-4, BR-5, BR-6)
3. **Order Confirmation & Tracking** — user sees confirmation and live status (BR-1, BR-7, BR-8)
4. **Order History & Re-order** — user can view and repeat past orders (BR-9, BR-10)

```mermaid
gantt
    title  Order Placement & Delivery Tracking — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Foundation
    Mock data seed + localStorage service   :task1, 1, 2
    User identity initialisation            :task2, 1, 2

    section Cart & Menu (Cluster 1)
    Cart service (read/write/update/clear)  :task3, 2, 3
    Cashback badge on listing               :task4, 2, 3
    Add-to-cart UI + qty stepper            :task5, 3, 4
    Cart panel UI                           :task6, 3, 4
    Cart observable                         :milestone, m1, 4, 0

    section Checkout & Payment (Cluster 2)
    Checkout wizard scaffold                :task7, 4, 5
    Address step + validation               :task8, 4, 5
    Order summary + fee/cashback calc       :task9, 4, 5
    Payment step + mock processing          :task10, 5, 6
    Checkout observable                     :milestone, m2, 6, 0

    %% Wave 5: Cart completes, Checkout begins

    section Order Confirmation & Tracking (Cluster 3)
    Order service (create + persist)        :task11, 6, 7
    Order confirmation screen               :task12, 6, 7
    Mock status timer + tracking screen     :task13, 7, 8
    Tracking observable                     :milestone, m3, 8, 0

    section Order History & Re-order (Cluster 4)
    Order history screen                    :task14, 8, 9
    Re-order flow                           :task15, 9, 10
    History observable                      :milestone, m4, 10, 0

    section Tests
    localStorage integration tests          :task16, 8, 9
    E2E test suite                          :task17, 9, 10
    UI E2E test suite                       :task18, 9, 10
```

---

## Wave 1 — Foundation

### TASK-001 [auto][wave:1]

Seed mock data (restaurants with cashback rates + menu items) and implement a typed `LocalStorageService` wrapper that encapsulates all `dinefind:*` key reads and writes, with JSON parse/stringify error handling.

**Satisfies:** BR-2, BR-6, BR-8 (foundational — all features depend on storage access)
**Standards:** none (no applicable standards for browser localStorage)
**Required tests:** none (scaffolding task)

---

### TASK-002 [auto][wave:1]

Implement user identity initialisation — on first app load, generate a UUID user ID and persist it to `dinefind:user`; on subsequent loads, read the existing ID.

**Satisfies:** BR-1 (user association on orders)
**Standards:** none
**Required tests:** none (scaffolding task)

---

## Wave 2 — Cart & Menu (Cluster 1)

### TASK-003 [tdd][wave:2]

Implement the cart service — create cart, add/update/remove items, read active cart by restaurant ID, update subtotal, and transition cart status (`active → checked_out`). All reads and writes go through the `LocalStorageService` from TASK-001.

**Satisfies:** BR-2
**Standards:** none
**Required tests:**
- `cartService_createCart` — new cart written with correct key, user_id, restaurant_id, and status "active"
- `cartService_addItem_snapshotsPrice` — item price and name are copied at add time, not live-referenced
- `cartService_updateQuantity` — subtotal recalculates correctly after quantity change
- `cartService_removeItem` — item removed from items array; subtotal updates
- `cartService_getActiveCart_returnsNullWhenAbsent` — missing key returns null, no error thrown
- `cartService_replaceCart_onSameRestaurant` — new cart for same restaurant replaces prior active cart

---

### TASK-004 [tdd][wave:2]

Add cashback rate badge to restaurant listing and restaurant cards in search results — reads `cashback_rate_pct` from mock restaurant data and renders the "X% back" badge using the `cashback` design token.

**Satisfies:** BR-6 (cashback rate visible on listing page)
**Standards:** `standards/frontend/design-tokens.md`
**Required tests:**
- `CashbackBadge_renders_withCorrectRate` — badge shows correct percentage from restaurant data
- `CashbackBadge_usesCorrectToken` — renders with `text.cashback` / `fill.cashback` token class

---

## Wave 3 — Add-to-Cart UI + Cart Panel

### TASK-005 [tdd][wave:3]

Implement the add-to-cart UI on the restaurant menu listing — "+ Add" button shows an inline quantity stepper after first tap, cart badge in the global header increments and plays the pulse animation, and the badge aria-label updates to "Cart: N items".

**Satisfies:** BR-2
**Standards:** `standards/frontend/design-tokens.md`, `standards/frontend/component-selection.md`
**Required tests:**
- `AddToCart_showsStepperAfterFirstTap` — "+ Add" replaced by stepper on click
- `AddToCart_stepperCollapsesAtZero` — stepper hidden, "+ Add" restored when qty reaches 0
- `AddToCart_cartBadgeIncrements` — badge count increments and aria-label updates

---

### TASK-006 [tdd][wave:3]

Implement the cart panel UI — slide-in panel (desktop) / bottom sheet (mobile) showing cart items with per-item qty steppers, live subtotal, cashback preview banner, and "Go to Checkout" CTA (disabled when cart is empty). Reads cart state from the cart service (TASK-003).

**Satisfies:** BR-2, BR-6
**Standards:** `standards/frontend/design-tokens.md`, `standards/frontend/responsive-layout.md`
**Required tests:**
- `CartPanel_showsEmptyState_whenCartEmpty` — empty state message and disabled CTA rendered
- `CartPanel_showsItems_withSubtotal` — items, quantities, and real-time subtotal rendered
- `CartPanel_showsCashbackBanner` — cashback preview banner shows correct estimated saving
- `CartPanel_disablesCheckoutCTA_whenEmpty` — CTA has aria-disabled="true" when cart empty

---

## Wave 4 — Checkout Wizard Scaffold + Address Step

### TASK-007 [auto][wave:4]

Scaffold the 3-step checkout wizard — router/navigation structure, progress indicator component (3-step pill, current step highlighted, not clickable), and shared checkout layout wrapper. No business logic yet.

**Satisfies:** BR-1, BR-3, BR-4, BR-5
**Standards:** `standards/frontend/design-tokens.md`
**Required tests:** none (scaffolding task)

---

### TASK-008 [tdd][wave:4]

Implement checkout step 1 — delivery address form (street, city, state, zip) with always-visible labels, inline field-level validation on submit (blameless error copy), and "Continue" CTA that advances to step 2 only when all fields are non-empty.

**Satisfies:** BR-3
**Standards:** `standards/frontend/design-tokens.md`, `standards/frontend/component-selection.md`
**Required tests:**
- `AddressStep_preventsAdvance_whenFieldsEmpty` — "Continue" does not navigate on empty submit
- `AddressStep_showsInlineErrors_perField` — each empty field shows its own error message
- `AddressStep_advances_whenAllFieldsValid` — valid address allows navigation to step 2

---

### TASK-009 [tdd][wave:4]

Implement checkout step 2 — order summary screen showing itemised cart contents, subtotal, delivery fee, cashback discount (green, signed negative), and total charged. Cashback amount is calculated as `subtotal × cashback_rate_pct / 100`, rounded to 2 decimal places.

**Satisfies:** BR-4, BR-6
**Standards:** `standards/frontend/design-tokens.md`
**Required tests:**
- `OrderSummary_calculatesCashback_correctly` — cashback_amount = subtotal × rate / 100, rounded to 2dp
- `OrderSummary_displaysAllLineItems` — subtotal, delivery fee, cashback, and total all rendered
- `OrderSummary_cashbackLineUsesGreenToken` — cashback line uses `text.cashback` token

---

## Wave 5 — Payment Step + Mock Processing

### TASK-010 [tdd][wave:5]

Implement checkout step 3 — card entry form (card number, expiry, CVV) with always-visible labels; "Place Order" CTA gated by `aria-disabled` until all three fields are non-empty; mock payment handler that always succeeds and stores only `card_last_four` (never the full card number) in the order; navigates to order confirmation on success.

**Satisfies:** BR-5
**Standards:** `standards/frontend/design-tokens.md`, `standards/frontend/component-selection.md`
**Required tests:**
- `PaymentStep_disablesPlaceOrder_whenFieldsEmpty` — CTA has aria-disabled="true" on mount
- `PaymentStep_enablesPlaceOrder_whenAllFieldsFilled` — CTA becomes active after all fields filled
- `PaymentStep_storesOnlyLastFour_notFullNumber` — payment record in localStorage contains card_last_four only, not full PAN
- `PaymentStep_navigatesToConfirmation_onSuccess` — mock payment transitions to confirmation screen

---

## Wave 6 — Order Service + Order Confirmation

### TASK-011 [tdd][wave:6]

Implement the order service — create order from a checked-out cart (snapshot items, prices, restaurant name, cashback rate), calculate cashback amount and total charged, generate order ID, persist to `dinefind:orders` (prepend, most recent first), and transition the cart to `checked_out` status.

**Satisfies:** BR-1, BR-4, BR-6, BR-7
**Standards:** none
**Required tests:**
- `orderService_createOrder_writesCorrectShape` — all required fields present with correct types
- `orderService_createOrder_cashbackCalculation` — cashback_amount and total_charged computed correctly
- `orderService_createOrder_prependsToArray` — new order at index 0 of dinefind:orders
- `orderService_createOrder_transitionsCart` — cart status set to "checked_out"
- `orderService_createOrder_storesOnlyLastFour` — payment.card_last_four only, no full PAN in storage

---

### TASK-012 [tdd][wave:6]

Implement the order confirmation screen — shows success icon (✓), order ID, itemised order summary, total paid, cashback saved (green), estimated delivery time, and a "Track my order" CTA navigating to the tracking screen. Reads from the just-placed order in localStorage.

**Satisfies:** BR-7
**Standards:** `standards/frontend/design-tokens.md`
**Required tests:**
- `OrderConfirmation_displaysAllRequiredFields` — order ID, restaurant, items, total, cashback, ETA all rendered
- `OrderConfirmation_cashbackSavedUsesGreenToken` — cashback saved uses `text.cashback` token
- `OrderConfirmation_trackOrderCTA_navigatesToTracking` — tapping CTA navigates to tracking screen

---

## Wave 7 — Mock Status Timer + Tracking Screen

### TASK-013 [tdd][wave:7]

Implement the order tracking screen — 4-step vertical stepper (Order Received → Preparing → Out for Delivery → Delivered) with done/active/future visual states; mock status timer advancing every 90 seconds via `setTimeout` writing updated `status` and `status_updated_at` to the order in localStorage; delivered state shows celebratory treatment; timer respects `prefers-reduced-motion` for animations. Timer advances are 90s in production mock; a configurable interval prop enables fast-forward in tests.

**Satisfies:** BR-8
**Standards:** `standards/frontend/design-tokens.md`, `standards/frontend/component-selection.md`
**Required tests:**
- `TrackingScreen_showsCorrectActiveStep` — active step highlighted, prior steps marked done, future steps muted
- `TrackingScreen_advancesStatus_onTimer` — status progresses through all 4 steps with configurable interval
- `TrackingScreen_showsDeliveredCelebration_onFinalStep` — celebratory element shown at "Delivered" status
- `TrackingScreen_writesStatusToStorage` — each advancement updates status and status_updated_at in localStorage

---

## Wave 8 — Order History + Integration Tests

### TASK-014 [tdd][wave:8]

Implement the order history screen — reads `dinefind:orders` array, renders each past order (restaurant name, date, items, total, cashback saved in green), sorted most recent first; empty state with "Browse restaurants" CTA when no orders exist; accessible from the account/navigation menu.

**Satisfies:** BR-9
**Standards:** `standards/frontend/design-tokens.md`
**Required tests:**
- `OrderHistory_rendersOrders_mostRecentFirst` — orders displayed in correct sort order
- `OrderHistory_showsCashbackSaved_perOrder` — cashback saved shown in green per entry
- `OrderHistory_showsEmptyState_whenNoOrders` — empty state message and CTA rendered
- `OrderHistory_isAccessible_fromNavigation` — history link present in account/nav menu

---

### TASK-016 [storage-integration-tests][wave:8]

Implement localStorage integration tests from `spec/test/integration-test-suite.md` — 12 scenarios covering cart lifecycle, order creation, price snapshotting, cashback calculation, PII constraint (no full card number), status mutation, orders array ordering, and user identity persistence.

**type:** storage-integration-tests
**target:** `.forge/efforts/order-placement-and-delivery-tracking/spec/test/integration-test-suite.md`
**language:** typescript
**depends_on:** TASK-011, TASK-003
**Required tests:**
- SC-1: Writing a new cart to localStorage stores correct key and shape
- SC-2: Item prices and names are snapshotted at add-to-cart time
- SC-3: Cart status is set to "checked_out" when an order is placed
- SC-4: Order creation writes all required fields with correct calculations
- SC-5: Cashback amount is calculated correctly and stored in the order
- SC-6: Full card number is never written to localStorage
- SC-7: Order status update overwrites only status and status_updated_at fields
- SC-8: Orders array is prepended on new order (most recent first)
- SC-9: Reading a non-existent cart key returns null without error
- SC-10: Reading menu items for a restaurant returns correct array
- SC-11: User ID is generated on first visit and persisted across reads
- SC-12: Starting a new cart for the same restaurant replaces the prior active cart

---

## Wave 9 — Re-order + E2E Tests

### TASK-015 [tdd][wave:9]

Implement the re-order flow — "Re-order" CTA on each order history entry; tapping it reads the past order's items, populates a new cart in localStorage for that restaurant (replacing any existing active cart), and navigates to checkout step 1 (address).

**Satisfies:** BR-10
**Standards:** `standards/frontend/design-tokens.md`
**Required tests:**
- `ReOrder_populatesCart_withPriorItems` — cart pre-filled with correct items and quantities
- `ReOrder_navigatesToCheckout` — navigates to address step after cart population
- `ReOrder_replacesExistingCart` — prior active cart for the same restaurant is replaced

---

### TASK-017 [e2e-test][wave:9]

Implement E2E tests from `.forge/products/dinefind/test/e2e-test-suite.md` — 12 scenarios covering full order flow (SC-1 smoke), real-time subtotal (SC-2), address blocking (SC-3), fee breakdown accuracy (SC-4), mock payment (SC-5), cashback calculation (SC-6), confirmation fields (SC-7 smoke), tracking progression (SC-8), order history (SC-9), re-order (SC-10), cart persistence (SC-11), payment gating (SC-12).

**type:** e2e-test
**target:** `.forge/products/dinefind/test/e2e-test-suite.md`
**language:** typescript
**depends_on:** TASK-015, TASK-014, TASK-013
**Required tests:**
- SC-1: Complete delivery order flow — discovery to tracking
- SC-2: Cart subtotal updates in real time as items are added and removed
- SC-3: Checkout is blocked without a delivery address
- SC-4: Order summary shows correct fee breakdown before payment
- SC-5: Mock card payment completes and advances to confirmation
- SC-6: Cashback discount is calculated correctly and applied at checkout
- SC-7: Order confirmation screen shows all expected fields after payment
- SC-8: Order status progresses through all four mock delivery steps
- SC-9: Order history lists past orders most-recent-first with cashback shown
- SC-10: Re-order from history pre-populates the cart and navigates to checkout
- SC-11: Cart persists across page navigation within the same session
- SC-12: "Place Order" is disabled until all card fields are non-empty

---

### TASK-018 [e2e-test][wave:9]

Implement UI E2E tests from `.forge/products/dinefind/test/ui-e2e-test-suite.md` — 15 Playwright scenarios covering cashback badge visibility (SC-1), inline qty stepper (SC-2), cart badge animation (SC-3), cart empty state (SC-4), cart with items (SC-5), disabled checkout CTA (SC-6), checkout progress indicator (SC-7), address validation errors (SC-8), cashback green line (SC-9), trust badge + payment gating (SC-10), confirmation fields (SC-11), tracking stepper states (SC-12), delivered celebration (SC-13), history empty state (SC-14), per-order cashback (SC-15).

**type:** e2e-test
**target:** `.forge/products/dinefind/test/ui-e2e-test-suite.md`
**language:** typescript
**depends_on:** TASK-015, TASK-014, TASK-013
**Required tests:**
- SC-1: Cashback badge visible on restaurant listing page
- SC-2: Add-to-cart button shows inline qty stepper after first tap
- SC-3: Cart badge increments with animation when item is added
- SC-4: Cart panel shows empty state with browse CTA when no items
- SC-5: Cart panel shows items, subtotal, and cashback preview
- SC-6: "Go to Checkout" is disabled when cart is empty
- SC-7: Checkout progress indicator shows correct active step
- SC-8: Address form shows inline errors on empty submit
- SC-9: Order summary shows cashback discount in green as a separate line item
- SC-10: Payment step shows trust badge and requires all fields
- SC-11: Order confirmation shows success icon, order ID, and cashback saved
- SC-12: Tracking stepper shows correct active, done, and future visual states
- SC-13: Delivered state shows celebratory treatment
- SC-14: Order history empty state shows invite to browse
- SC-15: Order history shows per-order cashback saved
