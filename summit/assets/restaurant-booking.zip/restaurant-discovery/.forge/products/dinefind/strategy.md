# Product Strategy: DineFind

*Created: 2026-06-05*
*Mode: create*

---

## Diagnosis

**Data:** US consumers consult an average of 6 different platforms when researching
a local business (BrightLocal 2026); 97% read reviews before visiting; Google Maps
dominates at 71% but is declining as consumers increasingly turn to AI tools (surging
from 6% → 45% as a discovery channel); the US food & drink app market is growing at
8% CAGR. No internal metrics — pre-launch product.

**Observations:** Every US restaurant discovery incumbent stacks discovery on top of
a different primary product — maps (Google), reservations (OpenTable), travel
(TripAdvisor), or general local reviews (Yelp). None were designed around the diner's
pre-visit decision moment. Foursquare, the only purpose-built consumer discovery
product, shut its City Guide app in December 2024 — leaving the niche vacant.

**Beliefs:** The fragmentation is structural, not accidental — incumbents cannot solve
it without cannibalising their primary monetisation model. Yelp can't deprioritise ads;
OpenTable can't deprioritise reservations. For a self-serve consumer app, this
fragmentation creates a first-session conversion risk: DineFind must deliver a
confident, complete restaurant decision faster and more completely than the scattered
status quo, or users have no reason to return.

**Bet:** US diners are forced to consult an average of 6 platforms to make a confident
restaurant choice because every major discovery surface was built to serve a different
primary job — not the pre-visit decision itself. No purpose-built restaurant discovery
product exists in the US market today. DineFind must deliver decision completeness in
a single session, or the self-serve growth model fails before it starts.

*Evidence:* BrightLocal Local Consumer Review Survey 2026; competitive research in
`competitive/initial-landscape.md`

---

## Guiding Policy

### Strategic Pillars

| # | Pillar | Where We Play | How We Win | OKR | Success Indicator |
|---|--------|--------------|-----------|-----|-------------------|
| 1 | Information Completeness | US diners in the pre-visit decision moment | All 6 decision dimensions (cuisine, menu, photos, hours, location, reviews) on every listing — no dead ends | OKR-2026-1 | 90%+ of launch metro listings fully populated |
| 2 | Discovery Depth | Users with a cuisine/occasion/location intent but no restaurant name | Filter and search depth no generalist platform matches (≥ 8 dimensions) | OKR-2026-2 | Search-to-listing CTR ≥ 60%; 40% of sessions include a filter interaction |
| 3 | Trust at Lower Review Volume | Quality-conscious diners who rely on reviews | Recency enforcement, photo-encouraged reviews, AI sentiment summaries — fresh beats voluminous | OKR-2026-3 | 70%+ reviews include photo; avg review age ≤ 6 months |
| 4 | First-Session Retention | Self-serve consumer app adopters | First-open experience engineered around a single outcome: save or share a restaurant before closing | OKR-2026-4 | Day-1 retention ≥ 40%; 30% of first sessions result in save or share |

### Strategic Exclusions

| Exclusion | Rationale |
|-----------|-----------|
| Restaurant-side tools (CRM, reservation management, operator analytics) | Different customer, different sales motion, different product — would dilute focus on the diner |
| Food delivery | Different consumption mode; dominated by DoorDash/Uber Eats with supply-side infrastructure we cannot match |
| Travel itinerary planning | TripAdvisor's territory; competing on travel content pulls us away from dining discovery depth |
| International markets | US-first; depth in one market before breadth across geographies |

---

## Coherent Actions

| Initiative | Strategic Pillar | Horizon | Success Metric | Effort ID |
|------------|-----------------|---------|----------------|-----------|
| Restaurant Data Pipeline & Listing Completeness | Information Completeness | Now | 90%+ of launch metro listings have all 6 data dimensions populated | |
| Core Discovery & Search Experience | Discovery Depth | Now | Search-to-listing CTR ≥ 60% in first 90 days | |
| Review Quality & AI Trust Layer | Trust at Lower Review Volume | Now | 70%+ of reviews include a photo; avg listing review age ≤ 6 months | |
| First-Session Onboarding & Retention Loop | First-Session Retention | Now | Day-1 retention ≥ 40%; 30% of first sessions result in save or share | |
| Metro Launch Sequencing & SEO Depth | Cross-cutting | Now / Next | Top-3 Google ranking for 100+ cuisine-city combinations within 6 months | |

---

## OKRs

*See [okrs.md](okrs.md) for full product-level OKRs.*

---

## Roadmap

*See [roadmap.md](roadmap.md) for the outcome-based roadmap.*

---

## History

| Version | Date | Notes |
|---------|------|-------|
| Initial | 2026-06-05 | Create mode. No company OKRs available — alignment risk noted. |
