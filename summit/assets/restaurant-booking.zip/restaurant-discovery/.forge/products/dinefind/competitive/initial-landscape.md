---
product: dinefind
brief: initial-landscape
date: 2026-06-05
competitors: [Yelp, Google Maps, OpenTable, TripAdvisor, Foursquare]
strategic_implication: true
---

# Competitive Brief — Initial Landscape

*Product: DineFind | Date: 2026-06-05*

---

## Executive Summary

The US restaurant discovery market is dominated by four incumbents — Yelp, Google Maps, OpenTable, and TripAdvisor — but none of them are pure-play discovery products. Every incumbent has stacked reservations, food delivery, travel planning, or enterprise data on top of discovery, cluttering the experience for users whose sole intent is to find the right restaurant. DineFind's focused scope (search, reviews, photos, menus, hours, cuisine — no booking, no delivery) is a genuine differentiation, not a feature gap. The most significant competitive event of the past 12 months is Foursquare's shutdown of its City Guide consumer app in December 2024, which has left personalised, taste-profile-driven discovery with no clear US successor — a near-term positioning window. The primary structural threat is Google Maps: it is already installed on every smartphone, and while its restaurant discovery depth is shallow, its distribution advantage is nearly impossible to overcome on convenience alone. DineFind must win on discovery quality and depth, not discoverability.

---

## Feature Matrix

| Feature / Capability | DineFind | Yelp | Google Maps | OpenTable | TripAdvisor |
|---------------------|:---:|:---:|:---:|:---:|:---:|
| **Core Discovery** | | | | | |
| Location-based restaurant search (US-wide) | ✓ | ✓ | ✓ | ✓ | ✓ |
| Cuisine type filter | ✓ | ✓ | ~ | ✓ | ✓ |
| Price range filter | ✓ | ✓ | ✓ | ✓ | ✓ |
| "Open now" / hours filter | ✓ | ✓ | ✓ | ✓ | ✓ |
| Dietary restriction filters | ? | ✓ | ~ | ✓ | ✓ |
| Occasion / atmosphere tags | ? | ~ | ✗ | ~ | ✓ |
| Neighbourhood / area browse | ✓ | ✓ | ✓ | ✓ | ✓ |
| Cross-city US discovery (not just local) | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Content & Information** | | | | | |
| User reviews & ratings | ✓ | ✓ | ✓ | ✓ | ✓ |
| Photos (user-submitted) | ✓ | ✓ | ✓ | ~ | ✓ |
| Menu display | ✓ | ~ | ~ | ✓ | ✓ |
| Hours of operation | ✓ | ✓ | ✓ | ✓ | ✓ |
| AI-powered review insights / summarisation | ? | ✓ | ✗ | ✗ | ✗ |
| Health / hygiene inspection scores | ✗ | ✓ | ✗ | ✗ | ✗ |
| Awards / recognition badges (Michelin etc.) | ✗ | ✗ | ✗ | ~ | ✓ |
| **User Experience** | | | | | |
| Mobile app (iOS / Android) | ✓ | ✓ | ✓ | ✓ | ✓ |
| Personalised recommendations | ✗ | ~ | ~ | ~ | ~ |
| Collections / saved lists | ? | ✓ | ✓ | ~ | ✓ |
| Social features (friends, check-ins, sharing) | ✗ | ~ | ✗ | ✗ | ✗ |
| **Transactions & Actions** | | | | | |
| Table reservations | ✗ | ~ | ~ | ✓ | ~ |
| Food delivery integration | ✗ | ✓ | ✓ | ✗ | ~ |
| Dining loyalty / points | ✗ | ✗ | ✗ | ✓ | ✗ |

*Key: ✓ supported · ~ partial/limited · ✗ absent · ? planned/unconfirmed*

### Where we lead

- **Pure discovery focus** — no reservation flow, no delivery upsell, no travel itinerary; the entire surface area is devoted to finding the right restaurant
- **Menu as a first-class search and browsing surface** — DineFind explicitly positions menu display alongside cuisine, photos, and reviews; incumbents treat menus as secondary (Yelp, Google Maps) or outsource syndication (TripAdvisor via SinglePlatform acquisition)
- **Cross-US intent** — explicitly designed for users searching across US locations, not just hyperlocal; this is a niche most competitors serve incidentally

### Where we lag

- **Review corpus depth** — new entrant problem; Yelp has 308M+ reviews, Google Maps has 1B+; trust takes years to build
- **No reservations** — OpenTable (1B+ diners seated/year) and TripAdvisor have made booking a standard expectation immediately after discovery for many users
- **No AI-powered features at launch** — Yelp has launched Review Insights, Yelp Assistant (AI chatbot), and acquired Hatch AI ($270M); AI-driven discovery summarisation is becoming table stakes
- **No personalised recommendations** — the taste-profile-driven discovery niche (formerly Foursquare's) is open but DineFind doesn't fill it yet
- **No health inspection scores or awards data** — Yelp integrates hygiene data; TripAdvisor shows Michelin stars; these are trust signals that matter to quality-sensitive diners
- **No collections or saved lists confirmed** — competitors provide save/list features that drive re-engagement

---

## Positioning Analysis

### Competitive positioning summaries

**DineFind**
A purpose-built restaurant discovery app for US diners who want to find the right restaurant — by cuisine, location, timing, photos, and menu — before they go. The target user is anyone searching for a restaurant in an unfamiliar city or neighbourhood, or looking for a specific cuisine type across the US. DineFind's entire product surface is devoted to the discovery job-to-be-done; it does not ask users to book a table or order delivery. Tone: practical, clean, traveller- and local-friendly. Brand character is nascent — early-stage product with a clear scope.

**Yelp**
"Yelp connects people with great local businesses." In practice, restaurant discovery is Yelp's core use case (49% of all reviews are restaurant-related), even though the platform spans home services, auto, and health. Leads the market on user-generated review volume (308M+ reviews), audience quality (50%+ earn $100K+ HHI), and now AI — Review Insights launched Dec 2024, Yelp Assistant chatbot April 2024, Hatch AI acquisition Jan 2025 ($270M). Primarily monetises through business advertising and sponsored listings. Tone: community-driven, trust-first, increasingly AI-forward.

**Google Maps**
The default starting point for most US consumers — not because it is the best restaurant discovery tool, but because it is already open. Google Maps serves restaurant search as one use case within a universal local search and navigation product. Cuisine filters are shallow, menu integration is inconsistent, and curated discovery (occasion, atmosphere, awards) is absent. Its advantage is monopoly distribution: 1B+ monthly users, pre-installed on Android, deeply embedded in iOS via Siri. Monetises via advertising and the broader Google ecosystem. Tone: utilitarian, omnipresent, not restaurant-specific.

**OpenTable**
"Find the perfect table" — OpenTable is a reservation platform that has layered discovery features to support booking conversion. Discovery is a funnel, not the product. Strongest on US urban restaurant breadth (55K+ restaurants, 80+ countries), real-time table availability, and dining loyalty (points redeemable for dining discounts). Recently partnered with Visa to give premium cardholders access to sought-after reservation slots. Owned by Booking Holdings. Tone: polished, dining-occasion-oriented, slightly upscale.

**TripAdvisor**
The travel-audience restaurant discovery incumbent: 490M monthly unique visitors, 1B+ reviews, Michelin Guide integration, Travellers' Choice awards. Restaurant discovery depth is strong — cuisine, dietary, occasion, neighbourhood, price, and awards filters all present. But the audience skews tourists and infrequent visitors; locals searching for their next regular lunch spot are not TripAdvisor's core user. Has acquired deep infrastructure: SinglePlatform for menu syndication, TheFork for European reservations. 2024 revenue: $1.83B. Tone: authoritative, travel-adjacent, award-driven.

**Foursquare (City Guide — now shut)**
Foursquare City Guide was the most differentiated restaurant discovery product in the US — personalised recommendations driven by check-in history and taste profiles. It shut down in December 2024. Foursquare has pivoted entirely to enterprise location intelligence. They acquired Superlocal (April 2025) as a thin consumer replacement, but it is brand new and unproven. The social/personalised discovery niche that Foursquare owned for 15 years is currently vacant.

### Positioning map

**Crowded territory:** "Reviews and ratings for restaurants" — Yelp, Google Maps, TripAdvisor, and OpenTable all claim credible review surfaces. Competing on review volume or ratings alone as a new entrant is a losing strategy.

**Crowded territory:** "Find and book" — OpenTable and TripAdvisor both push discovery-to-reservation as a core flow. This is not a space DineFind competes in by design, which is the right call.

**Open territory: pure discovery, no transactional clutter** — No incumbent has positioned as discovery-only. Every player either monetises through reservations, delivery, or advertising that pushes transactional behaviour. A clean, intent-focused discovery experience with no upsell is genuinely unclaimed messaging territory.

**Open territory: local diner, not tourist** — TripAdvisor's travel-audience skew is a structural gap. A product that speaks to the regular local diner — "you live here, find your next favourite spot" — rather than the infrequent visitor has no clear incumbent.

**Open territory: menu-first and cross-city US search** — None of the incumbents prominently position menu browsing as a discovery dimension. For a user thinking "I want somewhere that has this dish" or planning a trip to another US city and wanting to research restaurants before arriving, no product currently owns this clearly.

**Messaging inconsistency risk:** DineFind should be careful not to implicitly position against Yelp on reviews (Yelp wins that fight on volume) or against Google Maps on convenience (Google wins that fight on distribution). The frame must be discovery depth and intent purity, not comparison.

---

## Win / Loss Signals

*Note: DineFind is pre-launch. Win/loss signals below are projections from competitor weakness analysis and category behaviour, not first-party data. Confidence ratings reflect source quality.*

### Where we win

| Customer type / use case | Reason | Confidence |
|--------------------------|--------|-----------|
| Traveller researching restaurants in an unfamiliar US city before arrival | Wants cuisine, menu, photos, hours in one place without being pushed to book; TripAdvisor's tourist skew helps, but its UI is cluttered with travel/hotel content | Medium |
| User searching for a specific cuisine type or dish across a city | Google Maps cuisine filters are shallow; Yelp requires knowing the area; DineFind's cross-US, cuisine-first search serves this intent better | Medium |
| User who wants to browse menus before deciding | Menu display is a first-class DineFind feature; Yelp and Google Maps treat menus as secondary; strong differentiation for indecisive or dietary-conscious diners | Medium |
| User frustrated by reservation/delivery upsells on Yelp or OpenTable | Pure discovery with no transactional pressure is a clean, differentiated experience | Low (no survey data yet) |

### Where we lose

| Competitor | Customer type / use case | Reason | Confidence |
|------------|--------------------------|--------|-----------|
| Google Maps | Any user who starts their restaurant search while already using Maps for navigation | Convenience and distribution; DineFind requires a separate app install | High |
| Yelp | User who wants high-volume, high-trust reviews | 308M+ reviews vs. a new entrant's sparse corpus; trust gap is real and takes years to close | High |
| OpenTable | Urban diner who wants to book a specific table immediately after choosing a restaurant | DineFind has no reservation capability; users with booking intent will pivot to OpenTable after discovery | High |
| TripAdvisor | Tourist seeking award-validated, Michelin-starred, or "best of city" restaurant lists | TripAdvisor's Travellers' Choice and Michelin badges carry authority DineFind cannot match at launch | Medium |

### Where data is thin

- Local repeat-visit behaviour — whether users will return to DineFind regularly (vs. treating it as a one-off trip-planning tool) is unknown; this is the key retention question
- Head-to-head preference vs. Yelp for discovery-only tasks (no reservation intent) — no public data exists
- Appetite for a standalone discovery app vs. a Google Maps plugin/overlay — worth testing in user research
- *Recommended: collect first-party data from user interviews, beta testers, and app store reviews at launch*

---

## Market Trends

### 1. AI is redefining restaurant discovery interfaces

**What is happening:** Yelp launched Review Insights (AI-powered sentiment summaries across food, service, atmosphere) in December 2024, deployed a conversational Yelp Assistant chatbot in April 2024, and acquired AI platform Hatch for $270M in January 2025. TripAdvisor launched a ChatGPT plugin for vacation and restaurant planning in November 2025. Google Maps has AR Lens integration showing restaurant info via camera. Natural language restaurant search ("somewhere quiet with good pasta near downtown") is moving from novelty to expectation.
**Who is moving on it:** Yelp (most aggressively), TripAdvisor, Google Maps.
**Implication for us:** If DineFind launches without any AI-assisted discovery (natural language search, review summaries, personalised suggestions), it will feel dated by 2026 standards. This is a near-term table-stakes requirement, not a differentiator.
**Time horizon:** Near-term (0–12 months)

### 2. Foursquare's consumer exit leaves personalised discovery vacant

**What is happening:** Foursquare shut down its City Guide consumer app in December 2024 after 15 years. The app pioneered taste-profile-driven restaurant recommendations based on check-in history and social graph. Foursquare acquired Superlocal (April 2025) as a replacement, but the product is brand new and unproven. No major incumbent has moved to claim this positioning since the shutdown.
**Who is moving on it:** No one clearly yet — Superlocal is nascent; Yelp and TripAdvisor have not repositioned.
**Implication for us:** A near-term window exists to position DineFind as the spiritual successor to Foursquare's discovery model — personalised, taste-driven, local-first. This would require adding a preference/profile layer (cuisine affinities, past favourites, dietary needs), but the user base is available and currently without a home.
**Time horizon:** Near-term (0–12 months) — the window closes as Superlocal matures or another player moves

### 3. Menu display is becoming a core discovery signal

**What is happening:** TripAdvisor acquired SinglePlatform for $51M in 2019 specifically to syndicate menu data onto restaurant listings. Google has been expanding menu integration via Business Profiles. Users increasingly want to see a menu — not just cuisine type — before committing to a restaurant, particularly dietary-restriction and allergy-aware diners.
**Who is moving on it:** TripAdvisor (via SinglePlatform), Google Maps (incomplete), OpenTable (native menus on listings).
**Implication for us:** DineFind's explicit inclusion of menu display is already aligned with this trend. Investing in complete, structured, searchable menu data (ingredients, allergens, price per dish) would meaningfully differentiate from competitors whose menu coverage is inconsistent.
**Time horizon:** Near-term (0–12 months)

### 4. Reservation consolidation is tightening the discovery-to-booking funnel

**What is happening:** Booking Holdings (OpenTable parent) controls the dominant US reservation infrastructure. TripAdvisor owns TheFork in Europe and has DoorDash integration for delivery. OpenTable partnered with Visa in 2024 to give premium cardholders exclusive reservation access. The discovery-to-booking funnel is consolidating into fewer hands, and the players who own booking have a structural advantage in monetisation.
**Who is moving on it:** OpenTable (Booking Holdings), TripAdvisor (TheFork, DoorDash), Visa.
**Implication for us:** DineFind's explicit decision not to pursue reservations is a scope choice, not a permanent strategy. As this consolidation accelerates, pressure will grow to either integrate with a reservation partner (OpenTable API, Resy) or accept that monetisation must come from an advertising/listing model. The longer DineFind waits to resolve this, the more leverage the reservation incumbents accumulate.
**Time horizon:** Medium-term (1–3 years)

### 5. The local diner segment is underserved by travel-skewed incumbents

**What is happening:** TripAdvisor announced the merger of Viator and TripAdvisor brands in 2025 under an "experience-led" model — doubling down on the travel and tourism audience. This further skews TripAdvisor's restaurant product toward infrequent visitors rather than regular local diners. Google Maps serves locals but through a generalist lens. Yelp is the closest to a local diner product but its review corpus and advertising model create noise.
**Who is moving on it:** No one is explicitly repositioning for the "local regular" diner in 2025.
**Implication for us:** A product that speaks to someone who eats out 2–4 times per week in their own city — helping them discover new neighbourhoods, find cuisines they haven't tried, track what they've visited — addresses a behavioural use case that none of the incumbents are actively optimising for.
**Time horizon:** Medium-term (1–3 years)

---

## Research notes

*Sources consulted:*
- Wikipedia: Yelp, OpenTable, Zomato, Google Maps, TripAdvisor, Foursquare
- review42.com Yelp statistics
- TripAdvisor live restaurant search page (New York City)
- OpenTable homepage (live, via Playwright)
- TripAdvisor investor/about page (live, via WebFetch)

*Data gaps:*
- Yelp app MAU is from 2019 (37M); no verified 2024/2025 figure found
- Google Maps restaurant-specific usage breakdown not publicly available
- Superlocal (Foursquare's new consumer app) has insufficient public data — omitted from feature matrix
- No first-party win/loss data exists for DineFind (pre-launch); all signals are projections
- Zomato confirmed as non-competitor in US market (exited 2021) — excluded

*Last updated: 2026-06-05*
