# Vision — dinefind

*Stable product identity. Update only when the fundamental nature of the product
changes — not when strategy, roadmap, or scope evolves.*

*Time horizon: 3 years (2026–2029)*

---

## Vision Statement

Any diner in the US can make a confident food decision — going out or ordering in —
because everything they need is in one place.

---

## Target Beneficiaries

US diners in any food decision moment: the person choosing where to eat out tonight,
the visitor researching restaurants before a trip, and the person at home deciding
what to order in. The common thread is the decision itself — they know they want to
eat, they don't yet know what or where, and they need reliable, complete information
to choose with confidence.

---

## The Transformation

**Before:** A diner going out stitches together fragments from multiple sources —
hours on Google Maps, reviews on Yelp, a website hunt for the menu. A diner ordering
in switches between a discovery product to find the right restaurant and a separate
delivery app to act on that choice, losing context in the handoff. Either way, the
information and the action live in different places.

**After:** Find the right restaurant and act on that decision — go there or order
from it — without leaving the app. Whether you're a local exploring a new
neighbourhood, a visitor planning a trip, or someone at home who wants dinner
delivered, you make a confident, informed choice and follow through in a single
session.

---

## What This Is Not

- **Not a reservation platform** — DineFind helps you decide where to go; table
  booking is a separate job with different infrastructure and different competitors.
- **Not a restaurant management tool** — DineFind is built for diners, not operators;
  even if restaurants benefit from visibility, they are not the primary user this
  product is designed around.
- **Not a grocery or convenience delivery platform** — DineFind is restaurant-focused;
  expanding to groceries, alcohol, or retail delivery would pull it away from food
  decision-making and toward general commerce logistics.

---

## Durability Note

This vision would need to change if: (1) AI agents begin making food decisions
autonomously on behalf of users, eliminating the human decision moment entirely;
(2) restaurant information becomes so universally structured and accessible through
dominant platforms that the aggregation and decision problem effectively disappears;
or (3) user research reveals the real transformation is narrower or different —
for instance, that DineFind's value is fundamentally about trip planning rather than
daily food decisions, or that discovery and ordering are jobs users consistently want
to keep separate.

Expected stable horizon: 3 years.

---

## Change History

| Date | What changed | Why |
|------|-------------|-----|
| 2026-06-05 | Initial vision | Collaborative session with stakeholders. Established core transformation: fragmented pre-visit uncertainty → confident, informed decision in one place. |
| 2026-06-05 | Expanded scope to include food delivery alongside dine-in discovery | Collaborative session with Rakuten stakeholders. Removed delivery exclusion; updated vision statement, target beneficiaries, transformation, and scope boundaries to reflect find-and-act-in-one-session as the core job. |
