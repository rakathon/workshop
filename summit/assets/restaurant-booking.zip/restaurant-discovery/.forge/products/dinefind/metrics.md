# Metric Hierarchy: DineFind

*Last updated: 2026-06-05*
*Strategy version: 2026-06-05*

---

## North Star

| Metric | Definition | Data source | Cadence | Baseline | Healthy range |
|--------|-----------|------------|---------|---------|---------------|
| Confident Restaurant Decisions per Month | Monthly sessions resulting in a restaurant save, share, or return visit to a listing within 24 hours | App analytics | Weekly | 0 (pre-launch) | Growing MoM; ≥ 30% of MAU sessions |

---

## L1 Inputs

| Metric | Drives | Definition | Data source | Cadence | Baseline | Healthy range |
|--------|--------|-----------|------------|---------|---------|---------------|
| Day-1 Retention Rate | North Star | % of new users who return within 24 hours of first session | App analytics | Weekly | — | ≥ 40% |
| Listing Completeness Rate | North Star | % of active listings with all 6 data dimensions populated | Internal data pipeline | Weekly | 0% | ≥ 90% at launch |
| Search-to-Listing CTR | North Star | % of search queries that result in a listing view | App analytics | Weekly | — | ≥ 60% |
| Review Trust Indicators | North Star | Composite: % reviews with photo AND average review age per metro | App analytics + review DB | Weekly | — | ≥ 70% photo rate; avg age ≤ 6 months |
| Organic Acquisition Rate | North Star | % of new installs attributable to organic search or word-of-mouth | Attribution / App Store analytics | Weekly | — | ≥ 50% |

---

## L2 Diagnostics

| Metric | Explains | Definition | Data source | Cadence | Baseline | Healthy range |
|--------|---------|-----------|------------|---------|---------|---------------|
| First-session save/share rate | Day-1 Retention | % of first sessions ending with a save or share action | App analytics | Weekly | — | ≥ 30% |
| Onboarding drop-off step | Day-1 Retention | The step in the first-open flow with highest abandonment | App analytics funnel | Weekly | — | No single step > 30% drop-off |
| Day-7 retention rate | Day-1 Retention | % of new users active 7 days after install | App analytics | Weekly | — | ≥ 20% |
| % listings missing menu data | Listing Completeness | Share of active listings with no menu data | Data pipeline | Weekly | — | < 10% |
| % listings with ≥ 5 recent reviews | Listing Completeness | Share of listings meeting minimum trust threshold | Review DB | Weekly | — | ≥ 60% in launch metros |
| Data freshness lag (days since last update) | Listing Completeness | Average days since any data dimension was last updated | Data pipeline | Weekly | — | ≤ 30 days |
| Filter usage rate per session | Search-to-Listing CTR | % of sessions where user applies ≥ 1 filter | App analytics | Weekly | — | ≥ 40% |
| Zero-results rate | Search-to-Listing CTR | % of search queries returning no results | App analytics | Weekly | — | < 5% |
| Session depth (listings viewed per session) | Search-to-Listing CTR | Average number of listings viewed per session | App analytics | Weekly | — | ≥ 3 |
| Photo submission rate per new review | Review Trust Indicators | % of new reviews submitted with ≥ 1 photo | Review submission analytics | Weekly | — | ≥ 70% |
| Average review age per metro | Review Trust Indicators | Mean age (in months) of displayed reviews per launch metro | Review DB | Weekly | — | ≤ 6 months |
| AI summary coverage rate | Review Trust Indicators | % of listings with ≥ 5 reviews that have live AI summaries | Feature flag / listing DB | Weekly | — | ≥ 80% |
| App store conversion rate | Organic Acquisition Rate | % of app store page views converting to installs | App Store Connect / Play Console | Weekly | — | ≥ 25% |
| Keyword ranking coverage | Organic Acquisition Rate | Number of cuisine-city combinations ranked top-3 in Google | SEO tooling | Weekly | 0 | ≥ 100 within 6 months |
| Referral share rate | Organic Acquisition Rate | % of installs driven by in-app share actions | Attribution tooling | Weekly | — | ≥ 15% |
