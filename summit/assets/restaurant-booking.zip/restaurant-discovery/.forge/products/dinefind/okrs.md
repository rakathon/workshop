# Product OKRs: DineFind

*Quarter: Q2–Q3 2026 (launch period)*
*Cascaded from: No company OKRs provided — product OKRs derived directly from strategy*
*Linked from: [strategy.md](strategy.md)*

---

## Objective 1: Establish DineFind as the most complete restaurant information source in launch markets

*Cascades from: OKR-2026-1*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| % of launch metro listings with all 6 data dimensions populated | 0% (pre-launch) | 90% | 95% |
| Average menu data freshness for top-100 restaurants per metro | — | ≤ 30 days | ≤ 14 days |
| User-flagged data gap reports as % of total listing views | — | < 5% | < 2% |

---

## Objective 2: Build a discovery experience that converts search intent into confident restaurant choices

*Cascades from: OKR-2026-2*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Search-to-listing click-through rate | — | ≥ 60% within 90 days of launch | ≥ 70% |
| Active filter dimensions available at launch | 0 | ≥ 8 | ≥ 10 |
| % of sessions including a filter interaction | — | 40% | 50% |

---

## Objective 3: Earn user trust despite a smaller review corpus than incumbents

*Cascades from: OKR-2026-3*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| % of submitted reviews including at least one photo | — | 70% | 85% |
| Average review age across top-metro listings | — | ≤ 6 months within 90 days of launch | ≤ 3 months |
| % of listings with ≥ 5 reviews that have AI sentiment summaries live | — | 80% by end of Q1 post-launch | 90% |

---

## Objective 4: Achieve strong first-session retention that validates the self-serve growth model

*Cascades from: OKR-2026-4*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Day-1 retention rate | — | ≥ 40% within 60 days of launch | ≥ 50% |
| % of first sessions resulting in a restaurant save or share | — | 30% | 40% |
| Day-7 retention rate | — | ≥ 20% within 90 days of launch | ≥ 28% |

---

## Objective 5: Establish organic search as DineFind's primary acquisition channel

*Cascades from: OKR-2026-5*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Top-3 Google rankings for cuisine-city keyword combinations | 0 | 100+ within 6 months of launch | 250+ |
| % of new installs from organic search or word-of-mouth | — | ≥ 50% within 90 days of launch | ≥ 65% |
| Launch metros at ≥ 90% listing completeness before expansion | 0 | 5–8 metros | 10 metros |
