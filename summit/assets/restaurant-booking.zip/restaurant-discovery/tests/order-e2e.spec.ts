import { test, expect, type Page } from '@playwright/test'

/**
 * E2E test suite — Order Placement & Delivery Tracking
 * SC-1 through SC-12 from .forge/products/dinefind/test/e2e-test-suite.md
 */

async function goToListing(page: Page, restaurantId = 'rest-001') {
  await page.goto(`/restaurant/${restaurantId}`)
  await page.waitForLoadState('networkidle')
}

async function addItemToCart(page: Page, itemLabel: string) {
  await page.getByRole('button', { name: new RegExp(`Add ${itemLabel}`, 'i') }).click()
}

async function openCartAndCheckout(page: Page) {
  // Use the header cart button (always visible on all viewports)
  await page.locator('button[aria-label*="Cart:"]').first().click()
  // force=true: cart panel footer may be partially obscured on mobile viewports
  await page.getByRole('button', { name: /go to checkout/i }).click({ force: true })
}

async function fillAddress(page: Page) {
  await page.getByRole('textbox', { name: 'Street address' }).fill('123 Main St')
  await page.locator('#addr-city').fill('New York')
  await page.locator('#addr-state').fill('NY')
  await page.getByRole('textbox', { name: 'ZIP code' }).fill('10001')
  await page.getByRole('button', { name: /continue to summary/i }).click()
}

async function fillPayment(page: Page) {
  await page.getByRole('textbox', { name: 'Card number' }).fill('4242424242424242')
  await page.locator('#card-expiry').fill('06/28')
  await page.locator('#card-cvv').fill('123')
  await page.getByRole('button', { name: /place order/i }).click()
}

test.beforeEach(async ({ page }) => {
  await page.goto('/')
  await page.evaluate(() => localStorage.clear())
  await page.reload()
  await page.waitForLoadState('networkidle')
})

/** SC-1: Complete delivery order flow — discovery to tracking @tag smoke */
test('SC-1: complete delivery order flow — discovery to tracking', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  await fillPayment(page)
  await expect(page.getByRole('heading', { name: /order placed/i })).toBeVisible()
  await expect(page.getByText(/ORD-/)).toBeVisible()
  await page.getByRole('link', { name: /track my order/i }).click()
  await expect(page.getByText('Order Received').first()).toBeVisible()
  await expect(page.locator('[aria-current="step"]')).toBeVisible()
})

/** SC-2: Cart subtotal updates in real time */
test('SC-2: cart subtotal updates in real time', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  // Open cart
  await page.locator('button', { hasText: /order delivery/i }).first().click()
  // $24.00 — use context-specific locator inside cart dialog
  await expect(page.getByRole('dialog').getByText('$24.00').first()).toBeVisible()
  // Close, add another item
  await page.getByRole('button', { name: /close cart/i }).click({ force: true })
  await addItemToCart(page, 'Margherita Pizza')
  await page.locator('button[aria-label*="Cart:"]').first().click()
  // Both items visible
  await expect(page.getByRole('dialog').getByText('Tagliatelle')).toBeVisible()
  await expect(page.getByRole('dialog').getByText('Margherita Pizza')).toBeVisible()
})

/** SC-3: Checkout is blocked without a delivery address */
test('SC-3: checkout blocked without delivery address', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await page.getByRole('button', { name: /continue to summary/i }).click()
  await expect(page.getByText(/enter a street address/i)).toBeVisible()
  await expect(page.getByText(/enter a city/i)).toBeVisible()
  await expect(page.getByRole('textbox', { name: 'Street address' })).toBeVisible()
})

/** SC-4: Order summary shows correct fee breakdown */
test('SC-4: order summary shows correct fee breakdown', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle') // $24.00
  await openCartAndCheckout(page)
  await fillAddress(page)
  // Use data-testid for cashback line, then check surrounding price rows
  await expect(page.locator('[data-testid="cashback-line"]')).toBeVisible()
  await expect(page.locator('[data-testid="cashback-line"]')).toContainText('8%')
  await expect(page.locator('[data-testid="cashback-line"]')).toContainText('1.92')
  // Delivery fee row
  await expect(page.getByText('Delivery fee')).toBeVisible()
  // ETA
  await expect(page.getByText(/35/)).toBeVisible()
})

/** SC-5: Mock card payment completes and advances to confirmation */
test('SC-5: mock card payment completes successfully', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  await fillPayment(page)
  await expect(page.getByRole('heading', { name: /order placed/i })).toBeVisible()
  await expect(page.getByText(/ORD-/)).toBeVisible()
})

/** SC-6: Cashback discount calculated correctly */
test('SC-6: cashback calculated correctly at checkout', async ({ page }) => {
  await goToListing(page, 'rest-002') // Xi'an: 10% cashback
  await addItemToCart(page, 'Spicy Cumin Lamb') // $16.50
  await openCartAndCheckout(page)
  await fillAddress(page)
  // Cashback 10% of $16.50 = $1.65
  await expect(page.locator('[data-testid="cashback-line"]')).toContainText('1.65')
  await expect(page.locator('[data-testid="cashback-line"]')).toContainText('10%')
})

/** SC-7: Order confirmation shows all required fields @tag smoke */
test('SC-7: order confirmation shows all required fields', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  await fillPayment(page)
  await expect(page.getByRole('heading', { name: /order placed/i })).toBeVisible()
  await expect(page.getByText(/ORD-/)).toBeVisible()
  await expect(page.getByText(/Osteria Morini/)).toBeVisible()
  await expect(page.getByText(/Tagliatelle/)).toBeVisible()
  await expect(page.getByText(/123 Main St/)).toBeVisible()
  await expect(page.locator('[data-testid="cashback-saved"]')).toBeVisible()
  await expect(page.getByRole('link', { name: /track my order/i })).toBeVisible()
})

/** SC-8: Order status progresses through all four steps */
test('SC-8: order tracking shows all four status steps', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  await fillPayment(page)
  await page.getByRole('link', { name: /track my order/i }).click()
  await expect(page.getByText('Order Received').first()).toBeVisible()
  await expect(page.getByText('Preparing')).toBeVisible()
  await expect(page.getByText('Out for Delivery')).toBeVisible()
  await expect(page.getByText('Delivered')).toBeVisible()
  await expect(page.locator('[aria-current="step"]')).toBeVisible()
})

/** SC-9: Order history lists past orders with cashback */
test('SC-9: order history shows past orders with cashback', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  await fillPayment(page)
  await page.goto('/orders')
  await expect(page.getByText(/Osteria Morini/)).toBeVisible()
  await expect(page.locator('[data-testid="order-cashback"]')).toBeVisible()
  await expect(page.getByRole('button', { name: /re-order/i })).toBeVisible()
})

/** SC-10: Re-order from history pre-populates cart */
test('SC-10: re-order from history navigates to checkout', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  await fillPayment(page)
  await page.goto('/orders')
  await page.getByRole('button', { name: /re-order/i }).click()
  await expect(page).toHaveURL(/\/checkout\//)
  await expect(page.getByRole('heading', { name: /delivery address/i })).toBeVisible()
})

/** SC-11: Cart persists across page navigation */
test('SC-11: cart persists across page navigation', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  // Verify cart badge updated
  await expect(page.locator('button[aria-label*="Cart:"]').first())
    .toHaveAttribute('aria-label', /1 item/)
  // Navigate away then back
  await page.goto('/')
  await page.waitForLoadState('networkidle')
  await goToListing(page)
  // Cart data is in localStorage — the context reloads from storage on mount
  // Verify by opening cart panel
  await page.locator('button', { hasText: /order delivery/i }).first().click()
  await expect(page.getByRole('dialog').getByText('Tagliatelle')).toBeVisible()
})

/** SC-12: "Place Order" disabled until all card fields filled */
test('SC-12: Place Order disabled until all card fields filled', async ({ page }) => {
  await goToListing(page)
  await addItemToCart(page, 'Tagliatelle')
  await openCartAndCheckout(page)
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  const btn = page.getByRole('button', { name: /place order/i })
  // Initially disabled
  await expect(btn).toBeDisabled()
  // Card number only
  await page.getByRole('textbox', { name: 'Card number' }).fill('4242424242424242')
  await expect(btn).toBeDisabled()
  // All fields
  await page.locator('#card-expiry').fill('06/28')
  await page.locator('#card-cvv').fill('123')
  await expect(btn).toBeEnabled()
})
