import { test, expect, type Page } from '@playwright/test'

/**
 * UI E2E test suite — Order Placement & Delivery Tracking
 * SC-1 through SC-15 from .forge/products/dinefind/test/ui-e2e-test-suite.md
 */

async function goToListing(page: Page, restaurantId = 'rest-001') {
  await page.goto(`/restaurant/${restaurantId}`)
  await page.waitForLoadState('networkidle')
}

async function fillAddress(page: Page) {
  await page.getByRole('textbox', { name: 'Street address' }).fill('123 Main St')
  await page.locator('#addr-city').fill('New York')
  await page.locator('#addr-state').fill('NY')
  await page.getByRole('textbox', { name: 'ZIP code' }).fill('10001')
  await page.getByRole('button', { name: /continue to summary/i }).click()
}

async function fillPayment(page: Page) {
  await page.getByRole('textbox', { name: 'Card number' }).fill('4242424242424242')
  await page.locator('#card-expiry').fill('06/28')
  await page.locator('#card-cvv').fill('123')
  await page.getByRole('button', { name: /place order/i }).click()
}

async function placeOrder(page: Page) {
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await page.getByRole('button', { name: /go to checkout/i }).click({ force: true })
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  await fillPayment(page)
}

test.beforeEach(async ({ page }) => {
  await page.goto('/')
  await page.evaluate(() => localStorage.clear())
  await page.reload()
  await page.waitForLoadState('networkidle')
})

/** SC-1: Cashback badge visible on restaurant listing page */
test('SC-1: cashback badge visible on restaurant listing', async ({ page }) => {
  await goToListing(page)
  // The CashbackBadge has role="status"
  const badge = page.getByRole('status').filter({ hasText: /8%/ }).first()
  await expect(badge).toBeVisible()
  await expect(badge).toContainText('back')
})

/** SC-2: Add-to-cart button shows inline qty stepper after first tap */
test('SC-2: add-to-cart shows qty stepper after first tap', async ({ page }) => {
  await goToListing(page)
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  // Stepper appears with decrease/increase buttons
  await expect(page.getByRole('button', { name: /decrease tagliatelle/i })).toBeVisible()
  await expect(page.getByRole('button', { name: /increase tagliatelle/i })).toBeVisible()
  // The "Add" button disappears
  await expect(page.getByRole('button', { name: /^add tagliatelle/i })).not.toBeVisible()
})

/** SC-3: Cart badge increments when item added */
test('SC-3: cart badge increments when item added', async ({ page }) => {
  await goToListing(page)
  const cartBtn = page.locator('button[aria-label*="Cart:"]').first()
  await expect(cartBtn).toHaveAttribute('aria-label', 'Cart: 0 items')
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await expect(cartBtn).toHaveAttribute('aria-label', 'Cart: 1 item')
})

/** SC-4: Cart panel shows empty state with browse CTA when no items */
test('SC-4: cart panel shows empty state', async ({ page }) => {
  await goToListing(page)
  // Open cart via sidebar button — no items added yet
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await expect(page.getByText(/your cart is empty/i)).toBeVisible()
  await expect(page.getByText(/browse restaurants/i)).toBeVisible()
  await expect(page.getByRole('button', { name: /go to checkout/i }))
    .toHaveAttribute('aria-disabled', 'true')
})

/** SC-5: Cart panel shows items, subtotal, and cashback preview */
test('SC-5: cart panel shows items and cashback preview', async ({ page }) => {
  await goToListing(page)
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await expect(page.getByRole('dialog').getByText('Tagliatelle al Ragù')).toBeVisible()
  await expect(page.getByRole('dialog').getByText('$24.00').first()).toBeVisible()
  await expect(page.getByRole('dialog').getByText(/cashback/i)).toBeVisible()
})

/** SC-6: "Go to Checkout" is disabled when cart is empty */
test('SC-6: checkout CTA disabled when cart empty', async ({ page }) => {
  await goToListing(page)
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await expect(page.getByRole('button', { name: /go to checkout/i }))
    .toHaveAttribute('aria-disabled', 'true')
  // Close cart via button (force=true to bypass overlap on mobile)
  await page.getByRole('button', { name: /close cart/i }).click({ force: true })
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await expect(page.getByRole('button', { name: /go to checkout/i }))
    .toHaveAttribute('aria-disabled', 'false')
})

/** SC-7: Checkout progress indicator shows correct active step */
test('SC-7: checkout progress indicator shows correct step', async ({ page }) => {
  await goToListing(page)
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await page.getByRole('button', { name: /go to checkout/i }).click({ force: true })
  // Step 1 active
  await expect(page.locator('[aria-current="step"]')).toBeVisible()
  await expect(page.locator('[aria-current="step"]')).toContainText('1')
  // Complete step 1
  await fillAddress(page)
  // Step 2 now active
  await expect(page.locator('[aria-current="step"]')).toContainText('2')
})

/** SC-8: Address form shows inline errors on empty submit */
test('SC-8: address form shows inline errors on empty submit', async ({ page }) => {
  await goToListing(page)
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await page.getByRole('button', { name: /go to checkout/i }).click({ force: true })
  await page.getByRole('button', { name: /continue to summary/i }).click()
  await expect(page.getByText(/enter a street address/i)).toBeVisible()
  await expect(page.getByText(/enter a city/i)).toBeVisible()
  await expect(page.getByText(/enter a state/i)).toBeVisible()
  await expect(page.getByText(/enter a zip/i)).toBeVisible()
})

/** SC-9: Order summary shows cashback discount in green as separate line */
test('SC-9: order summary shows cashback line', async ({ page }) => {
  await goToListing(page)
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await page.getByRole('button', { name: /go to checkout/i }).click({ force: true })
  await fillAddress(page)
  const cashbackLine = page.locator('[data-testid="cashback-line"]')
  await expect(cashbackLine).toBeVisible()
  await expect(cashbackLine).toContainText('8%')
  await expect(cashbackLine).toContainText('1.92')
})

/** SC-10: Payment step shows trust badge and requires all fields */
test('SC-10: payment step trust badge and field gating', async ({ page }) => {
  await goToListing(page)
  await page.getByRole('button', { name: /add tagliatelle/i }).click()
  await page.locator('button[aria-label*="Cart:"]').first().click()
  await page.getByRole('button', { name: /go to checkout/i }).click({ force: true })
  await fillAddress(page)
  await page.getByRole('button', { name: /continue to payment/i }).click()
  // Trust badge
  await expect(page.getByText(/secure/i)).toBeVisible()
  // Button disabled initially
  await expect(page.getByRole('button', { name: /place order/i })).toBeDisabled()
  // Fill all fields
  await page.getByRole('textbox', { name: 'Card number' }).fill('4242424242424242')
  await page.locator('#card-expiry').fill('06/28')
  await page.locator('#card-cvv').fill('123')
  await expect(page.getByRole('button', { name: /place order/i })).toBeEnabled()
})

/** SC-11: Order confirmation shows success icon, order ID, and cashback saved */
test('SC-11: order confirmation shows all success fields', async ({ page }) => {
  await goToListing(page)
  await placeOrder(page)
  await expect(page.getByRole('heading', { name: /order placed/i })).toBeVisible()
  await expect(page.getByText(/ORD-/)).toBeVisible()
  await expect(page.locator('[data-testid="cashback-saved"]')).toBeVisible()
  await expect(page.getByRole('link', { name: /track my order/i })).toBeVisible()
})

/** SC-12: Tracking stepper shows correct active, done, future states */
test('SC-12: tracking stepper shows correct states', async ({ page }) => {
  await goToListing(page)
  await placeOrder(page)
  await page.getByRole('link', { name: /track my order/i }).click()
  await expect(page.locator('[aria-current="step"]')).toBeVisible()
  await expect(page.getByText('Order Received').first()).toBeVisible()
  await expect(page.getByText('Preparing')).toBeVisible()
  await expect(page.getByText('Out for Delivery')).toBeVisible()
  await expect(page.getByText('Delivered')).toBeVisible()
})

/** SC-13: Delivered state shows celebratory treatment */
test('SC-13: delivered state shows celebration', async ({ page }) => {
  await page.goto('/')
  await page.evaluate(() => {
    const order = {
      id: 'ORD-TEST', user_id: 'usr-1', restaurant_id: 'rest-001',
      restaurant_name: 'Osteria Morini', delivery_address: '123 Main St',
      status: 'delivered', status_updated_at: new Date().toISOString(),
      estimated_delivery_minutes: 35,
      items: [{ menu_item_id: 'mi-1', name: 'Pizza', unit_price: 14.99, quantity: 1, line_total: 14.99 }],
      subtotal: 14.99, delivery_fee: 2.99, cashback_rate_pct: 8,
      cashback_amount: 1.20, total_charged: 16.78,
      payment: { id: 'p1', card_last_four: '4242', status: 'mock_success', paid_at: new Date().toISOString() },
      created_at: new Date().toISOString(),
    }
    localStorage.setItem('dinefind:orders', JSON.stringify([order]))
  })
  await page.goto('/tracking/ORD-TEST')
  await expect(page.getByText(/arrived/i).first()).toBeVisible()
  await expect(page.locator('text=🎉')).toBeVisible()
})

/** SC-14: Order history empty state shows invite to browse */
test('SC-14: order history empty state', async ({ page }) => {
  await page.goto('/orders')
  await expect(page.getByText(/no orders yet/i)).toBeVisible()
  await expect(page.getByText(/browse restaurants/i)).toBeVisible()
})

/** SC-15: Order history shows per-order cashback saved */
test('SC-15: order history shows cashback saved per order', async ({ page }) => {
  await page.goto('/')
  await page.evaluate(() => {
    const order = {
      id: 'ORD-HIST', user_id: 'usr-1', restaurant_id: 'rest-001',
      restaurant_name: 'Osteria Morini', delivery_address: '123 Main St',
      status: 'delivered', status_updated_at: new Date().toISOString(),
      estimated_delivery_minutes: 35,
      items: [{ menu_item_id: 'mi-1', name: 'Tagliatelle', unit_price: 24.00, quantity: 1, line_total: 24.00 }],
      subtotal: 24.00, delivery_fee: 2.99, cashback_rate_pct: 8,
      cashback_amount: 1.92, total_charged: 25.07,
      payment: { id: 'p1', card_last_four: '4242', status: 'mock_success', paid_at: new Date().toISOString() },
      created_at: new Date().toISOString(),
    }
    localStorage.setItem('dinefind:orders', JSON.stringify([order]))
  })
  await page.goto('/orders')
  await expect(page.getByText(/Osteria Morini/)).toBeVisible()
  const cashbackEl = page.locator('[data-testid="order-cashback"]')
  await expect(cashbackEl).toBeVisible()
  await expect(cashbackEl).toContainText('1.92')
})
