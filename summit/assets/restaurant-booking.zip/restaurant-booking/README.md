# GrabATable

> **See availability. Book instantly.**

A curated US restaurant booking app — browse hand-picked restaurants, check real-time availability, and reserve a table in under 2 minutes. No account or login required.

---

## Screenshots

| | |
|---|---|
| ![Home](docs/screenshots/01-home.jpg) | ![Restaurant listing](docs/screenshots/02-listing.jpg) |
| **Hero with search bar** | **Restaurant listing with cuisine filters** |
| ![Restaurant detail](docs/screenshots/03-detail.jpg) | ![Booking form](docs/screenshots/04-booking.jpg) |
| **Restaurant detail page** | **Booking form with time slots** |
| ![Confirmation](docs/screenshots/05-confirmation.jpg) | ![City filter](docs/screenshots/06-city-filter.jpg) |
| **Booking confirmation** | **City selector with All US option** |

| |
|---|
| ![Mobile view](docs/screenshots/07-mobile.jpg) |
| **Mobile view (390px)** |

---

## Features

- **28 curated restaurants** across 9 US cities (New York, San Francisco, Los Angeles, Chicago, Austin, Washington DC, Seattle, New Orleans, Cambridge)
- **Location-aware** — detects your nearest city via the Geolocation API; falls back to San Francisco
- **City + cuisine filters** — switch between cities (or "All US"), filter by cuisine type
- **Search** — find restaurants by name, cuisine, or city
- **Real-time slot availability** — 1-hour slots generated from each restaurant's hours; booked slots are excluded automatically
- **Zero-friction booking** — name and email only; no account, no login, no loyalty programme
- **My Reservations** — look up all bookings by email, separated into upcoming and past
- **Real restaurant photos** — images sourced from OpenTable's CDN
- **Star ratings & social proof** — mock ratings and "Booked N times today" labels on every card
- **Fully responsive** — mobile-first layout at 375px, 768px, and 1280px breakpoints
- **Mock data only** — all state persisted to `localStorage`; no backend or database required

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend framework | React 18 + TypeScript |
| Styling | Tailwind CSS v3 |
| Routing | React Router v6 |
| State & persistence | React Context + localStorage |
| Build tool | Vite |
| Testing | Vitest + Testing Library |
| Data | Local JSON files (`src/data/`) |

---

## Getting Started

### Prerequisites

- Node.js 18+
- npm 9+

### Install

```bash
npm install
```

### Run dev server

```bash
npm run dev
```

Opens at [http://localhost:3000](http://localhost:3000).

### Run tests

```bash
npm test
```

47 tests across 12 test files. All tests run in a jsdom environment — no browser required.

### Build for production

```bash
npm run build
```

Output in `dist/`. Preview the production build locally:

```bash
npm run preview
```

---

## Project Structure

```
src/
├── components/         # Reusable UI components
│   ├── FilterBar.tsx       # Cuisine filter chips
│   ├── MenuSection.tsx     # Accordion menu display
│   ├── PhotoGallery.tsx    # Cover photo + thumbnail strip
│   ├── RestaurantCard.tsx  # Listing page card
│   ├── SlotPicker.tsx      # Time slot selection chips
│   └── StarRating.tsx      # SVG star rating (supports half-stars)
│
├── context/
│   └── ReservationContext.tsx  # Global reservation state + localStorage
│
├── data/
│   ├── restaurants.json    # 28 restaurant records (static)
│   ├── tables.json         # Table capacity data (static)
│   └── reservations.json   # Empty array — runtime state lives in localStorage
│
├── hooks/                  # Custom hooks (extensible)
│
├── pages/
│   ├── RestaurantList.tsx      # /  — landing page with hero, search, filters
│   ├── RestaurantDetail.tsx    # /restaurants/:id
│   ├── BookingForm.tsx         # /restaurants/:id/book
│   ├── BookingConfirmation.tsx # /confirmation/:reservationId
│   └── MyReservations.tsx      # /my-reservations
│
├── types/
│   └── index.ts            # TypeScript interfaces (Restaurant, Table, Reservation…)
│
└── utils/
    ├── location.ts         # Geolocation, nearest-city logic, city filtering
    └── slots.ts            # Slot derivation, date range validation, time formatting

public/
└── images/restaurants/     # 84 cover + gallery photos (3 per restaurant)
```

---

## Data Model

All data is stored in local JSON files and `localStorage` — no server required.

| File | Contents | Mutable? |
|---|---|---|
| `src/data/restaurants.json` | 28 restaurants with menus, hours, photos, ratings | Static |
| `src/data/tables.json` | 3–6 tables per restaurant with capacity | Static |
| `localStorage` key `rba_reservations` | Confirmed bookings (written at runtime) | Runtime |

**Slot availability** is derived at runtime: for a given restaurant + date + party size, the app generates all 1-hour windows within operating hours and excludes any already-reserved slots.

---

## Routes

| Route | Page |
|---|---|
| `/` | Restaurant listing with hero search, city/cuisine filters |
| `/restaurants/:id` | Restaurant detail — photos, info, menu, booking CTA |
| `/restaurants/:id/book` | Booking form — date, time slot, party size, name, email |
| `/confirmation/:reservationId` | Booking confirmation |
| `/my-reservations` | Email-based reservation lookup |

---
