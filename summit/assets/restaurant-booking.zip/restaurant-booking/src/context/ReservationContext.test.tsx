import { describe, it, expect, beforeEach, vi } from 'vitest'
import { render, screen, act } from '@testing-library/react'
import { ReservationProvider, useReservations } from './ReservationContext'
import type { Reservation } from '../types'

const mockReservation: Reservation = {
  id: 'res-test-001',
  restaurant_id: 'rest-001',
  table_id: 'tbl-001',
  date: '2026-07-01',
  slot_start: '19:00',
  slot_end: '20:00',
  people: 2,
  diner_name: 'Test User',
  diner_email: 'test@example.com',
  created_at: '2026-06-04T10:00:00Z',
}

function TestConsumer() {
  const { reservations, addReservation } = useReservations()
  return (
    <div>
      <span data-testid="count">{reservations.length}</span>
      <button onClick={() => addReservation(mockReservation)}>Add</button>
    </div>
  )
}

// Use an in-memory localStorage mock so tests are isolated from the environment's localStorage
function makeLocalStorageMock() {
  let store: Record<string, string> = {}
  return {
    getItem: (key: string) => store[key] ?? null,
    setItem: (key: string, value: string) => { store[key] = value },
    removeItem: (key: string) => { delete store[key] },
    clear: () => { store = {} },
  }
}

describe('ReservationContext', () => {
  beforeEach(() => {
    vi.stubGlobal('localStorage', makeLocalStorageMock())
  })

  it('ReservationContext_loadsFromLocalStorage', () => {
    localStorage.setItem('rba_reservations', JSON.stringify([mockReservation]))
    render(
      <ReservationProvider>
        <TestConsumer />
      </ReservationProvider>
    )
    expect(screen.getByTestId('count').textContent).toBe('1')
  })

  it('ReservationContext_addReservation_persists', () => {
    render(
      <ReservationProvider>
        <TestConsumer />
      </ReservationProvider>
    )
    act(() => {
      screen.getByRole('button').click()
    })
    const stored = JSON.parse(localStorage.getItem('rba_reservations') ?? '[]') as Reservation[]
    expect(stored).toHaveLength(1)
    expect(stored[0].id).toBe('res-test-001')
  })

  it('ReservationContext_fallsBackToEmptyArray', () => {
    render(
      <ReservationProvider>
        <TestConsumer />
      </ReservationProvider>
    )
    expect(screen.getByTestId('count').textContent).toBe('0')
  })
})
