import { createContext, useContext, useState, useEffect, type ReactNode } from 'react'
import type { Reservation } from '../types'

const STORAGE_KEY = 'rba_reservations'

interface ReservationContextValue {
  reservations: Reservation[]
  addReservation: (reservation: Reservation) => void
}

const ReservationContext = createContext<ReservationContextValue | null>(null)

export function ReservationProvider({ children }: { children: ReactNode }) {
  const [reservations, setReservations] = useState<Reservation[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      return stored ? (JSON.parse(stored) as Reservation[]) : []
    } catch {
      return []
    }
  })

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reservations))
  }, [reservations])

  const addReservation = (reservation: Reservation) => {
    setReservations(prev => [...prev, reservation])
  }

  return (
    <ReservationContext.Provider value={{ reservations, addReservation }}>
      {children}
    </ReservationContext.Provider>
  )
}

export function useReservations(): ReservationContextValue {
  const ctx = useContext(ReservationContext)
  if (!ctx) throw new Error('useReservations must be used within ReservationProvider')
  return ctx
}
