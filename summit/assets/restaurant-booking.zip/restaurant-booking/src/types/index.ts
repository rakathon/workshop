export interface Restaurant {
  id: string
  name: string
  cuisine: string
  location: {
    city: string
    state: string
    neighbourhood: string
    address: string
    lat: number
    lng: number
  }
  description: string
  hours: {
    opening_time: string
    closing_time: string
    days_open: string[]
  }
  price_range: string
  rating: number
  review_count: number
  booked_today: number
  photos: {
    cover: string
    gallery: string[]
  }
  menu: {
    categories: MenuCategory[]
  }
}

export interface MenuCategory {
  id: string
  name: string
  items: MenuItem[]
}

export interface MenuItem {
  id: string
  name: string
  description: string
  price: number
}

export interface Table {
  id: string
  restaurant_id: string
  capacity: number
  label?: string
}

export interface Reservation {
  id: string
  restaurant_id: string
  table_id: string
  date: string
  slot_start: string
  slot_end: string
  people: number
  diner_name: string
  diner_email: string
  created_at: string
}
