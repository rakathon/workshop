import { Routes, Route } from 'react-router-dom'
import RestaurantList from './pages/RestaurantList'
import RestaurantDetail from './pages/RestaurantDetail'
import BookingForm from './pages/BookingForm'
import BookingConfirmation from './pages/BookingConfirmation'
import MyReservations from './pages/MyReservations'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<RestaurantList />} />
      <Route path="/restaurants/:id" element={<RestaurantDetail />} />
      <Route path="/restaurants/:id/book" element={<BookingForm />} />
      <Route path="/confirmation/:reservationId" element={<BookingConfirmation />} />
      <Route path="/my-reservations" element={<MyReservations />} />
    </Routes>
  )
}
