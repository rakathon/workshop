import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { ReservationProvider } from './context/ReservationContext'
import App from './App'
import './index.css'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <ReservationProvider>
        <App />
      </ReservationProvider>
    </BrowserRouter>
  </StrictMode>,
)
