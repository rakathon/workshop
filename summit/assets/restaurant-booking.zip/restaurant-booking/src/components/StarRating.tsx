interface StarRatingProps {
  rating: number
  reviewCount: number
  size?: 'sm' | 'md'
}

function Star({ fill, size }: { fill: 'full' | 'half' | 'empty'; size: number }) {
  const id = `half-${Math.random().toString(36).slice(2)}`
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      {fill === 'half' && (
        <defs>
          <linearGradient id={id}>
            <stop offset="50%" stopColor="#f97316" />
            <stop offset="50%" stopColor="#d1d5db" />
          </linearGradient>
        </defs>
      )}
      <path
        d="M10 1.5l2.39 4.84 5.34.78-3.87 3.77.91 5.32L10 13.77l-4.77 2.44.91-5.32L2.27 7.12l5.34-.78z"
        fill={
          fill === 'full' ? '#f97316' :
          fill === 'half' ? `url(#${id})` :
          '#d1d5db'
        }
      />
    </svg>
  )
}

export default function StarRating({ rating, reviewCount, size = 'sm' }: StarRatingProps) {
  const rounded = Math.round(rating * 2) / 2
  const full = Math.floor(rounded)
  const half = rounded % 1 >= 0.5 ? 1 : 0
  const empty = 5 - full - half
  const starSize = size === 'sm' ? 14 : 16
  const countSz = size === 'sm' ? 'text-xs' : 'text-sm'

  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center gap-0.5">
        {Array.from({ length: full }).map((_, i) => <Star key={`f${i}`} fill="full" size={starSize} />)}
        {half === 1 && <Star key="h" fill="half" size={starSize} />}
        {Array.from({ length: empty }).map((_, i) => <Star key={`e${i}`} fill="empty" size={starSize} />)}
      </div>
      <span className="font-semibold text-gray-800 text-sm">{rating.toFixed(1)}</span>
      <span className={`text-gray-400 ${countSz}`}>({reviewCount.toLocaleString()})</span>
    </div>
  )
}
