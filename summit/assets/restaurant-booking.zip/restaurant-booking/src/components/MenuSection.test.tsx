import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import MenuSection from './MenuSection'
import type { MenuCategory } from '../types'

const categories: MenuCategory[] = [
  {
    id: 'cat-1',
    name: 'Starters',
    items: [
      { id: 'item-1', name: 'Bruschetta', description: 'Tomatoes on toast', price: 12 },
      { id: 'item-2', name: 'Calamari', description: 'Fried squid', price: 14 },
    ],
  },
  {
    id: 'cat-2',
    name: 'Mains',
    items: [
      { id: 'item-3', name: 'Pasta', description: 'Fresh pasta', price: 22 },
      { id: 'item-4', name: 'Risotto', description: 'Creamy rice', price: 24 },
    ],
  },
]

describe('MenuSection', () => {
  it('MenuSection_rendersAllCategories', () => {
    render(<MenuSection categories={categories} />)
    expect(screen.getByText('Starters')).toBeInTheDocument()
    expect(screen.getByText('Mains')).toBeInTheDocument()
  })

  it('MenuSection_rendersItemsInCategory', () => {
    render(<MenuSection categories={categories} />)
    // First category is open by default
    expect(screen.getByText('Bruschetta')).toBeInTheDocument()
    expect(screen.getByText('Tomatoes on toast')).toBeInTheDocument()
    expect(screen.getByText('$12.00')).toBeInTheDocument()
  })
})
