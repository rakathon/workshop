import { useState } from 'react'
import type { MenuCategory } from '../types'

interface MenuSectionProps {
  categories: MenuCategory[]
}

export default function MenuSection({ categories }: MenuSectionProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <div className="divide-y divide-gray-100 border border-gray-100 rounded-xl overflow-hidden">
      {categories.map((category, i) => (
        <div key={category.id}>
          <button
            onClick={() => setOpenIndex(openIndex === i ? null : i)}
            className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors text-left font-semibold text-gray-800"
            aria-expanded={openIndex === i}
          >
            <span>{category.name}</span>
            <span className="text-gray-400 text-lg">{openIndex === i ? '−' : '+'}</span>
          </button>
          {openIndex === i && (
            <ul className="divide-y divide-gray-50">
              {category.items.map(item => (
                <li key={item.id} className="flex justify-between items-start px-4 py-3 gap-4">
                  <div>
                    <p className="font-medium text-gray-900">{item.name}</p>
                    <p className="text-sm text-gray-500 mt-0.5">{item.description}</p>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-gray-700">${item.price.toFixed(2)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  )
}
