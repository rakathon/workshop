import { useState } from 'react'

interface PhotoGalleryProps {
  restaurantName: string
  cover: string
  gallery: string[]
}

export default function PhotoGallery({ restaurantName, cover, gallery }: PhotoGalleryProps) {
  const allPhotos = [cover, ...gallery]
  const [activeIndex, setActiveIndex] = useState(0)

  const fallback = (e: React.SyntheticEvent<HTMLImageElement>) => {
    e.currentTarget.src = 'https://placehold.co/1200x600/f3f4f6/9ca3af?text=' + encodeURIComponent(restaurantName)
  }

  return (
    <div>
      <div className="w-full aspect-video overflow-hidden rounded-xl">
        <img
          src={allPhotos[activeIndex] ?? cover}
          alt={restaurantName}
          className="w-full h-full object-cover"
          onError={fallback}
        />
      </div>
      {allPhotos.length > 1 && (
        <div className="flex gap-2 mt-2 overflow-x-auto">
          {allPhotos.map((photo, i) => (
            <button
              key={i}
              onClick={() => setActiveIndex(i)}
              aria-label={`Photo ${i + 1}`}
              className={`shrink-0 w-20 h-14 rounded-md overflow-hidden border-2 transition-colors ${
                activeIndex === i ? 'border-orange-500' : 'border-transparent'
              }`}
            >
              <img
                src={photo}
                alt={`${restaurantName} photo ${i + 1}`}
                className="w-full h-full object-cover"
                onError={fallback}
              />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
