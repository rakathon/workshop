import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import FilterBar from './FilterBar'

const cuisines = ['Italian', 'Mexican', 'Indian']

describe('FilterBar', () => {
  it('FilterBar_rendersAllChip', () => {
    render(<FilterBar cuisines={cuisines} activeCuisine={null} onFilterChange={vi.fn()} />)
    expect(screen.getByRole('button', { name: 'All' })).toBeInTheDocument()
  })

  it('FilterBar_rendersUniqueCuisines', () => {
    render(<FilterBar cuisines={cuisines} activeCuisine={null} onFilterChange={vi.fn()} />)
    cuisines.forEach(c => {
      expect(screen.getByRole('button', { name: c })).toBeInTheDocument()
    })
  })

  it('FilterBar_callsOnFilterChange', async () => {
    const handler = vi.fn()
    render(<FilterBar cuisines={cuisines} activeCuisine={null} onFilterChange={handler} />)
    await userEvent.click(screen.getByRole('button', { name: 'Italian' }))
    expect(handler).toHaveBeenCalledWith('Italian')
  })

  it('FilterBar_allChipClearsFilter', async () => {
    const handler = vi.fn()
    render(<FilterBar cuisines={cuisines} activeCuisine="Italian" onFilterChange={handler} />)
    await userEvent.click(screen.getByRole('button', { name: 'All' }))
    expect(handler).toHaveBeenCalledWith(null)
  })
})
