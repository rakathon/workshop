import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import SlotPicker from './SlotPicker'

describe('SlotPicker', () => {
  it('SlotPicker_rendersSlotChips', () => {
    render(<SlotPicker availableSlots={['12:00', '13:00', '14:00']} selectedSlot={null} onSlotSelect={vi.fn()} />)
    expect(screen.getByRole('button', { name: '12:00 PM' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '1:00 PM' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '2:00 PM' })).toBeInTheDocument()
  })

  it('SlotPicker_callsOnSlotSelect', async () => {
    const handler = vi.fn()
    render(<SlotPicker availableSlots={['19:00', '20:00']} selectedSlot={null} onSlotSelect={handler} />)
    await userEvent.click(screen.getByRole('button', { name: /7:00 PM/i }))
    expect(handler).toHaveBeenCalledWith('19:00')
  })

  it('SlotPicker_emptyStateWhenNoSlots', () => {
    render(<SlotPicker availableSlots={[]} selectedSlot={null} onSlotSelect={vi.fn()} />)
    expect(screen.getByText(/No slots available/i)).toBeInTheDocument()
  })

  it('SlotPicker_selectedChipDistinct', () => {
    render(<SlotPicker availableSlots={['12:00', '13:00']} selectedSlot="12:00" onSlotSelect={vi.fn()} />)
    const selected = screen.getByRole('button', { name: /12:00 PM/i })
    expect(selected).toHaveAttribute('aria-pressed', 'true')
    const unselected = screen.getByRole('button', { name: /1:00 PM/i })
    expect(unselected).toHaveAttribute('aria-pressed', 'false')
  })
})
