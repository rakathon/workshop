import { formatSlotStart } from '../utils/slots'

interface SlotPickerProps {
  availableSlots: string[]
  selectedSlot: string | null
  onSlotSelect: (slot: string) => void
}

export default function SlotPicker({ availableSlots, selectedSlot, onSlotSelect }: SlotPickerProps) {
  if (availableSlots.length === 0) {
    return (
      <p className="text-sm text-gray-500 py-2">
        No slots available for this date and party size.
      </p>
    )
  }

  return (
    <div className="flex flex-wrap gap-2" role="group" aria-label="Available time slots">
      {availableSlots.map(slot => {
        const isSelected = selectedSlot === slot
        return (
          <button
            key={slot}
            onClick={() => onSlotSelect(slot)}
            aria-pressed={isSelected}
            className={`px-4 py-2 rounded-lg text-sm font-medium border transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 ${
              isSelected
                ? 'bg-orange-500 text-white border-orange-500 ring-2 ring-orange-200'
                : 'bg-white text-gray-700 border-gray-300 hover:border-orange-400 hover:text-orange-600'
            }`}
          >
            {formatSlotStart(slot)}
          </button>
        )
      })}
    </div>
  )
}
