import { useNavigate } from 'react-router-dom'
import type { Restaurant } from '../types'
import StarRating from './StarRating'

interface RestaurantCardProps {
  restaurant: Restaurant
}

export default function RestaurantCard({ restaurant }: RestaurantCardProps) {
  const navigate = useNavigate()

  return (
    <article
      onClick={() => navigate(`/restaurants/${restaurant.id}`)}
      className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-md transition-all cursor-pointer group"
    >
      {/* Cover photo */}
      <div className="aspect-video overflow-hidden relative">
        <img
          src={restaurant.photos.cover}
          alt={restaurant.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {/* Cuisine badge overlay */}
        <span className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm text-gray-700 text-xs font-semibold px-2.5 py-1 rounded-full shadow-sm">
          {restaurant.cuisine}
        </span>
      </div>

      <div className="p-4">
        {/* Name */}
        <h3 className="text-base font-bold text-gray-900 truncate mb-0.5">{restaurant.name}</h3>

        {/* Rating */}
        <div className="mb-1.5">
          <StarRating rating={restaurant.rating} reviewCount={restaurant.review_count} />
        </div>

        {/* Location + price */}
        <p className="text-sm text-gray-500 truncate">
          {restaurant.price_range} · {restaurant.location.neighbourhood}, {restaurant.location.city}
        </p>

        {/* Social proof + CTA */}
        <div className="flex items-center justify-between mt-3">
          {restaurant.booked_today > 0 ? (
            <span className="text-xs text-gray-500 flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-orange-400 rounded-full inline-block"></span>
              Booked {restaurant.booked_today} times today
            </span>
          ) : (
            <span />
          )}
          <button
            onClick={e => { e.stopPropagation(); navigate(`/restaurants/${restaurant.id}`) }}
            className="px-3 py-1.5 bg-orange-500 text-white text-xs font-semibold rounded-lg hover:bg-orange-600 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 shrink-0"
          >
            Book a table
          </button>
        </div>
      </div>
    </article>
  )
}
