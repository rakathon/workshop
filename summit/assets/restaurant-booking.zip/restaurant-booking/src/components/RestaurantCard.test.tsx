import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import RestaurantCard from './RestaurantCard'
import type { Restaurant } from '../types'

const mockNavigate = vi.fn()
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom')
  return { ...actual, useNavigate: () => mockNavigate }
})

const restaurant: Restaurant = {
  id: 'rest-001',
  name: 'Osteria Morini',
  cuisine: 'Italian',
  location: { city: 'New York', state: 'NY', neighbourhood: 'SoHo', address: '218 Lafayette St', lat: 40.71, lng: -74.01 },
  description: 'A rustic Italian trattoria.',
  hours: { opening_time: '11:00', closing_time: '22:00', days_open: ['Monday'] },
  price_range: '$$$',
  rating: 4.6,
  review_count: 2847,
  booked_today: 48,
  photos: { cover: '/images/restaurants/rest-001-cover.jpg', gallery: [] },
  menu: { categories: [] },
}

describe('RestaurantCard', () => {
  it('RestaurantCard_rendersRequiredFields', () => {
    render(<MemoryRouter><RestaurantCard restaurant={restaurant} /></MemoryRouter>)
    expect(screen.getByText('Osteria Morini')).toBeInTheDocument()
    expect(screen.getByText('Italian')).toBeInTheDocument()
    expect(screen.getByText(/SoHo/)).toBeInTheDocument()
    expect(screen.getByText(/\$\$\$/)).toBeInTheDocument()
    expect(screen.getByRole('img', { name: 'Osteria Morini' })).toBeInTheDocument()
  })

  it('RestaurantCard_bookButtonNavigatesToDetail', async () => {
    render(<MemoryRouter><RestaurantCard restaurant={restaurant} /></MemoryRouter>)
    await userEvent.click(screen.getByRole('button', { name: /book a table/i }))
    expect(mockNavigate).toHaveBeenCalledWith('/restaurants/rest-001')
  })
})
