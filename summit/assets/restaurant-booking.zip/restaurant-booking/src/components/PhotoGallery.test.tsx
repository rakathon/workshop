import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import PhotoGallery from './PhotoGallery'

describe('PhotoGallery', () => {
  it('PhotoGallery_rendersCoverPhoto', () => {
    render(
      <PhotoGallery
        restaurantName="Test Restaurant"
        cover="/images/cover.jpg"
        gallery={['/images/g1.jpg']}
      />
    )
    const img = screen.getByRole('img', { name: 'Test Restaurant' })
    expect(img).toBeInTheDocument()
    expect(img).toHaveAttribute('src', '/images/cover.jpg')
  })

  it('PhotoGallery_thumbnailClickSwitchesActive', async () => {
    render(
      <PhotoGallery
        restaurantName="Test Restaurant"
        cover="/images/cover.jpg"
        gallery={['/images/g1.jpg']}
      />
    )
    const thumb = screen.getByRole('button', { name: 'Photo 2' })
    await userEvent.click(thumb)
    const mainImg = screen.getByRole('img', { name: 'Test Restaurant' })
    expect(mainImg).toHaveAttribute('src', '/images/g1.jpg')
  })
})
