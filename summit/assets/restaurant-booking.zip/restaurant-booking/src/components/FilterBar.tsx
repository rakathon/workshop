interface FilterBarProps {
  cuisines: string[]
  activeCuisine: string | null
  onFilterChange: (cuisine: string | null) => void
}

export default function FilterBar({ cuisines, activeCuisine, onFilterChange }: FilterBarProps) {
  const allChips = ['All', ...cuisines]

  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide" role="group" aria-label="Filter by cuisine">
      {allChips.map(chip => {
        const isAll = chip === 'All'
        const isActive = isAll ? activeCuisine === null : activeCuisine === chip
        return (
          <button
            key={chip}
            onClick={() => onFilterChange(isAll ? null : chip)}
            aria-pressed={isActive}
            className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 ${
              isActive
                ? 'bg-orange-500 text-white border-orange-500'
                : 'bg-white text-gray-700 border-gray-300 hover:border-orange-400 hover:text-orange-600'
            }`}
          >
            {chip}
          </button>
        )
      })}
    </div>
  )
}
