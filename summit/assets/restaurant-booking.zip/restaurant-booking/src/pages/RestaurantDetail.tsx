import { useParams, Link, useNavigate } from 'react-router-dom'
import restaurantsData from '../data/restaurants.json'
import type { Restaurant } from '../types'
import PhotoGallery from '../components/PhotoGallery'
import MenuSection from '../components/MenuSection'
import StarRating from '../components/StarRating'

const restaurants = restaurantsData as Restaurant[]

const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

function formatTime(t: string): string {
  const [h, m] = t.split(':').map(Number)
  const period = h >= 12 ? 'PM' : 'AM'
  const display = h > 12 ? h - 12 : h === 0 ? 12 : h
  return `${display}:${String(m ?? 0).padStart(2, '0')} ${period}`
}

function formatDays(days: string[]): string {
  if (days.length === 7) return 'Open daily'
  if (days.length === 0) return 'Check availability'
  const shortDays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
  const indices = days.map(d => shortDays.indexOf(d)).filter(i => i >= 0).sort((a, b) => a - b)
  if (indices.length === 0) return days.join(', ')
  // Try to express as ranges
  const parts: string[] = []
  let start = indices[0]!
  let prev = indices[0]!
  for (let i = 1; i <= indices.length; i++) {
    const cur = indices[i]
    if (cur !== prev + 1) {
      if (start === prev) parts.push(DAY_SHORT[start]!)
      else parts.push(`${DAY_SHORT[start]}–${DAY_SHORT[prev]}`)
      if (cur !== undefined) { start = cur; prev = cur }
    } else {
      prev = cur
    }
  }
  return parts.join(', ')
}

export default function RestaurantDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const restaurant = restaurants.find(r => r.id === id)

  if (!restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center px-4">
          <p className="text-5xl mb-4">🍽</p>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Restaurant not found</h1>
          <p className="text-gray-500 mb-4">The restaurant you're looking for doesn't exist or has been removed.</p>
          <Link to="/" className="text-orange-500 hover:underline font-medium">← Back to all restaurants</Link>
        </div>
      </div>
    )
  }

  const isOpenToday = (() => {
    const today = new Date().toLocaleDateString('en-US', { weekday: 'long' })
    return restaurant.hours.days_open.includes(today)
  })()

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl">🍽</span>
            <span className="text-xl font-bold text-gray-900 hidden sm:block">GrabATable</span>
          </Link>
          <nav className="flex items-center gap-4">
            <Link to="/" className="text-sm text-gray-500 hover:text-orange-500 transition-colors hidden sm:block">
              All Restaurants
            </Link>
            <Link to="/my-reservations" className="text-sm font-medium text-gray-600 hover:text-orange-500 transition-colors">
              My Reservations
            </Link>
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6 pb-32 lg:pb-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-gray-500 mb-4" aria-label="Breadcrumb">
          <Link to="/" className="hover:text-orange-500 transition-colors">Restaurants</Link>
          <span>›</span>
          <span className="text-gray-800 font-medium">{restaurant.name}</span>
        </nav>

        <div className="lg:grid lg:grid-cols-3 lg:gap-8">
          {/* Main column */}
          <div className="lg:col-span-2">
            {/* Photo gallery */}
            <PhotoGallery
              restaurantName={restaurant.name}
              cover={restaurant.photos.cover}
              gallery={restaurant.photos.gallery}
            />

            {/* Restaurant header */}
            <div className="mt-6 bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">{restaurant.name}</h1>
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <span className="px-3 py-1 bg-orange-50 text-orange-700 rounded-full text-sm font-semibold">
                      {restaurant.cuisine}
                    </span>
                    <span className="text-gray-400">·</span>
                    <span className="text-gray-600 text-sm font-medium">{restaurant.price_range}</span>
                    <span className="text-gray-400">·</span>
                    <span className={`text-sm font-semibold ${isOpenToday ? 'text-green-600' : 'text-red-500'}`}>
                      {isOpenToday ? 'Open today' : 'Closed today'}
                    </span>
                  </div>
                  <div className="mt-2">
                    <StarRating rating={restaurant.rating} reviewCount={restaurant.review_count} size="md" />
                  </div>
                </div>
                {restaurant.booked_today > 10 && (
                  <div className="bg-orange-50 border border-orange-100 rounded-lg px-3 py-2 text-center">
                    <p className="text-2xl font-bold text-orange-600">{restaurant.booked_today}</p>
                    <p className="text-xs text-orange-500 font-medium">bookings today</p>
                  </div>
                )}
              </div>
            </div>

            {/* Info */}
            <div className="mt-4 bg-white rounded-xl p-5 shadow-sm border border-gray-100 space-y-3">
              <h2 className="text-lg font-bold text-gray-900 mb-3">About</h2>

              <div className="flex gap-3 text-sm">
                <span className="text-gray-400 w-6 mt-0.5">📍</span>
                <div>
                  <p className="text-gray-800 font-medium">{restaurant.location.address}</p>
                  <p className="text-gray-500">{restaurant.location.neighbourhood} · {restaurant.location.city}, {restaurant.location.state}</p>
                </div>
              </div>

              <div className="flex gap-3 text-sm">
                <span className="text-gray-400 w-6">🕐</span>
                <div>
                  <p className="text-gray-800 font-medium">
                    {formatTime(restaurant.hours.opening_time)} – {formatTime(restaurant.hours.closing_time)}
                  </p>
                  <p className="text-gray-500">{formatDays(restaurant.hours.days_open)}</p>
                </div>
              </div>

              <div className="border-t border-gray-50 pt-3">
                <p className="text-gray-600 leading-relaxed text-sm">{restaurant.description}</p>
              </div>
            </div>

            {/* Menu */}
            <div className="mt-4 bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Menu</h2>
              <MenuSection categories={restaurant.menu.categories} />
            </div>
          </div>

          {/* Sidebar — desktop only */}
          <div className="hidden lg:block">
            <div className="sticky top-24">
              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                <p className="font-bold text-gray-900 text-lg mb-1">{restaurant.name}</p>
                <StarRating rating={restaurant.rating} reviewCount={restaurant.review_count} />
                <p className="text-sm text-gray-500 mt-1 mb-5">
                  {restaurant.location.city}, {restaurant.location.state} · {restaurant.price_range}
                </p>
                <button
                  onClick={() => navigate(`/restaurants/${restaurant.id}/book`)}
                  className="w-full py-3 bg-orange-500 text-white font-bold rounded-xl hover:bg-orange-600 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500"
                >
                  Book a Table
                </button>
                <p className="text-xs text-gray-400 text-center mt-2">No account required</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Mobile sticky CTA */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 shadow-xl p-4">
        <div className="flex items-center justify-between gap-4 max-w-lg mx-auto">
          <div>
            <p className="font-semibold text-gray-900 text-sm">{restaurant.name}</p>
            <StarRating rating={restaurant.rating} reviewCount={restaurant.review_count} />
          </div>
          <button
            onClick={() => navigate(`/restaurants/${restaurant.id}/book`)}
            className="shrink-0 py-3 px-6 bg-orange-500 text-white font-bold rounded-xl hover:bg-orange-600 transition-colors"
          >
            Book a Table
          </button>
        </div>
      </div>
    </div>
  )
}
