import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useReservations } from '../context/ReservationContext'
import restaurantsData from '../data/restaurants.json'
import type { Restaurant } from '../types'
import { formatSlot } from '../utils/slots'
import StarRating from '../components/StarRating'

const restaurants = restaurantsData as Restaurant[]

function formatDate(dateStr: string): string {
  const [year, month, day] = dateStr.split('-').map(Number)
  const d = new Date(year!, month! - 1, day!)
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })
}

function isPast(dateStr: string, slotStart: string): boolean {
  const [y, m, d] = dateStr.split('-').map(Number)
  const [h, min] = slotStart.split(':').map(Number)
  const dt = new Date(y!, m! - 1, d!, (h ?? 0) + 1, min ?? 0)
  return dt < new Date()
}

export default function MyReservations() {
  const { reservations } = useReservations()
  const [email, setEmail] = useState('')
  const [searched, setSearched] = useState(false)

  const matched = reservations
    .filter(r => r.diner_email.toLowerCase() === email.trim().toLowerCase())
    .sort((a, b) => a.date.localeCompare(b.date))

  const upcoming = matched.filter(r => !isPast(r.date, r.slot_start))
  const past = matched.filter(r => isPast(r.date, r.slot_start))

  function handleSearch(e: React.FormEvent) {
    e.preventDefault()
    setSearched(true)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl">🍽</span>
            <span className="text-xl font-bold text-gray-900 hidden sm:block">GrabATable</span>
          </Link>
          <Link to="/" className="text-sm font-medium text-gray-600 hover:text-orange-500 transition-colors">
            Browse Restaurants
          </Link>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-1">My Reservations</h1>
          <p className="text-gray-500 text-sm">Enter the email you used when booking to find your reservations.</p>
        </div>

        {/* Email lookup form */}
        <form onSubmit={handleSearch} className="flex gap-2 mb-8">
          <input
            type="email"
            value={email}
            onChange={e => { setEmail(e.target.value); setSearched(false) }}
            placeholder="Enter your email address"
            aria-label="Email address"
            className="flex-1 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white shadow-sm"
          />
          <button
            type="submit"
            disabled={!email.trim()}
            className="px-5 py-3 bg-orange-500 text-white text-sm font-bold rounded-xl hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
          >
            Find
          </button>
        </form>

        {/* Results */}
        {searched && matched.length === 0 && (
          <div className="text-center py-16 bg-white rounded-2xl border border-gray-100 shadow-sm">
            <p className="text-4xl mb-3">📭</p>
            <p className="text-lg font-semibold text-gray-700 mb-1">No reservations found</p>
            <p className="text-gray-500 text-sm mb-5">
              No reservations were found for <strong>{email}</strong>
            </p>
            <Link
              to="/"
              className="inline-block bg-orange-500 text-white font-bold px-6 py-3 rounded-xl hover:bg-orange-600 transition-colors text-sm"
            >
              Book a Table
            </Link>
          </div>
        )}

        {searched && matched.length > 0 && (
          <div className="space-y-6">
            {/* Upcoming */}
            {upcoming.length > 0 && (
              <div>
                <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-3">
                  Upcoming ({upcoming.length})
                </h2>
                <div className="space-y-3">
                  {upcoming.map(r => {
                    const res = restaurants.find(rest => rest.id === r.restaurant_id)
                    return (
                      <div key={r.id} className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                        <div className="flex gap-4 p-4">
                          <img
                            src={res?.photos.cover}
                            alt={res?.name}
                            className="w-20 h-16 rounded-lg object-cover shrink-0"
                          />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <p className="font-bold text-gray-900 truncate">{res?.name ?? r.restaurant_id}</p>
                                {res && <StarRating rating={res.rating} reviewCount={res.review_count} />}
                                <p className="text-xs text-gray-500 mt-0.5">{res?.cuisine} · {res?.location.city}</p>
                              </div>
                              <span className="text-xs bg-green-100 text-green-700 font-semibold px-2 py-1 rounded-full shrink-0">
                                Upcoming
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="bg-orange-50 px-4 py-3 flex flex-wrap gap-4 text-sm border-t border-orange-100">
                          <div>
                            <span className="text-gray-400 text-xs block">Date</span>
                            <span className="font-semibold text-gray-800">{formatDate(r.date)}</span>
                          </div>
                          <div>
                            <span className="text-gray-400 text-xs block">Time</span>
                            <span className="font-semibold text-gray-800">{formatSlot(r.slot_start)}</span>
                          </div>
                          <div>
                            <span className="text-gray-400 text-xs block">Party</span>
                            <span className="font-semibold text-gray-800">{r.people} {r.people === 1 ? 'person' : 'people'}</span>
                          </div>
                        </div>
                        <div className="px-4 py-2 border-t border-gray-50 flex justify-between items-center">
                          <span className="text-xs text-gray-400 font-mono truncate">{r.id}</span>
                          {res && (
                            <Link
                              to={`/restaurants/${res.id}`}
                              className="text-xs text-orange-500 hover:underline font-medium"
                            >
                              View restaurant →
                            </Link>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Past */}
            {past.length > 0 && (
              <div>
                <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-3">
                  Past ({past.length})
                </h2>
                <div className="space-y-3 opacity-70">
                  {past.map(r => {
                    const res = restaurants.find(rest => rest.id === r.restaurant_id)
                    return (
                      <div key={r.id} className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                        <div className="flex gap-4 p-4">
                          <img
                            src={res?.photos.cover}
                            alt={res?.name}
                            className="w-16 h-12 rounded-lg object-cover shrink-0 grayscale"
                          />
                          <div className="min-w-0">
                            <p className="font-semibold text-gray-700 truncate">{res?.name ?? r.restaurant_id}</p>
                            <p className="text-xs text-gray-500">{formatDate(r.date)} · {formatSlot(r.slot_start)} · {r.people} {r.people === 1 ? 'person' : 'people'}</p>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
