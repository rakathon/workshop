import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import BookingForm from './BookingForm'
import { ReservationProvider } from '../context/ReservationContext'
import type { Reservation } from '../types'

const mockNavigate = vi.fn()
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom')
  return { ...actual, useNavigate: () => mockNavigate }
})

function makeLocalStorageMock(initial: Reservation[] = []) {
  let store: Record<string, string> = { rba_reservations: JSON.stringify(initial) }
  return {
    getItem: (key: string) => store[key] ?? null,
    setItem: (key: string, value: string) => { store[key] = value },
    removeItem: (key: string) => { delete store[key] },
    clear: () => { store = {} },
  }
}

function renderBookingForm(restaurantId = 'rest-001', preloadedReservations: Reservation[] = []) {
  vi.stubGlobal('localStorage', makeLocalStorageMock(preloadedReservations))
  return render(
    <MemoryRouter initialEntries={[`/restaurants/${restaurantId}/book`]}>
      <ReservationProvider>
        <Routes>
          <Route path="/restaurants/:id/book" element={<BookingForm />} />
        </Routes>
      </ReservationProvider>
    </MemoryRouter>
  )
}

describe('BookingForm', () => {
  beforeEach(() => {
    mockNavigate.mockClear()
    vi.stubGlobal('localStorage', makeLocalStorageMock())
  })

  it('BookingForm_submitButtonDisabledWhenFieldsEmpty', () => {
    renderBookingForm()
    const btn = screen.getByRole('button', { name: /confirm reservation/i })
    expect(btn).toBeInTheDocument()
  })

  it('BookingForm_showsInlineErrorsOnInvalidSubmit', async () => {
    renderBookingForm()
    await userEvent.click(screen.getByRole('button', { name: /confirm reservation/i }))
    expect(screen.getByText(/please enter your name/i)).toBeInTheDocument()
    expect(screen.getByText(/please enter your email/i)).toBeInTheDocument()
    expect(screen.getByText(/please select a date/i)).toBeInTheDocument()
  })

  it('BookingForm_emailValidationRejectsInvalidFormat', async () => {
    renderBookingForm()
    await userEvent.type(screen.getByLabelText(/full name/i), 'Jane')
    await userEvent.type(screen.getByLabelText(/email address/i), 'notanemail')
    await userEvent.click(screen.getByRole('button', { name: /confirm reservation/i }))
    expect(screen.getByText(/valid email/i)).toBeInTheDocument()
  })

  it('BookingForm_datePickerEnforcesRange', () => {
    renderBookingForm()
    const dateInput = screen.getByLabelText(/date/i)
    const today = new Date().toISOString().split('T')[0]!
    const max = new Date()
    max.setDate(max.getDate() + 30)
    const maxStr = max.toISOString().split('T')[0]!
    expect(dateInput).toHaveAttribute('min', today)
    expect(dateInput).toHaveAttribute('max', maxStr)
  })

  it('BookingForm_slotPickerHiddenUntilDateAndPeopleSelected', () => {
    renderBookingForm()
    expect(screen.queryByText(/available times/i)).not.toBeInTheDocument()
  })

  it('BookingForm_doubleBookingGuardShowsError', async () => {
    const conflictDate = (() => {
      const d = new Date(); d.setDate(d.getDate() + 5); return d.toISOString().split('T')[0]!
    })()
    const preloaded: Reservation[] = [
      { id: 'res-x1', restaurant_id: 'rest-001', table_id: 'tbl-001-2', date: conflictDate, slot_start: '19:00', slot_end: '20:00', people: 4, diner_name: 'A', diner_email: 'a@a.com', created_at: '' },
      { id: 'res-x2', restaurant_id: 'rest-001', table_id: 'tbl-001-3', date: conflictDate, slot_start: '19:00', slot_end: '20:00', people: 4, diner_name: 'B', diner_email: 'b@b.com', created_at: '' },
      { id: 'res-x3', restaurant_id: 'rest-001', table_id: 'tbl-001-4', date: conflictDate, slot_start: '19:00', slot_end: '20:00', people: 6, diner_name: 'C', diner_email: 'c@c.com', created_at: '' },
    ]
    renderBookingForm('rest-001', preloaded)
    await userEvent.type(screen.getByLabelText(/full name/i), 'Jane')
    await userEvent.type(screen.getByLabelText(/email address/i), 'jane@test.com')
    await userEvent.type(screen.getByLabelText(/date/i), conflictDate)
    await userEvent.selectOptions(screen.getByLabelText(/party size/i), '4')

    await userEvent.click(screen.getByRole('button', { name: /confirm reservation/i }))
    const hasConflict = screen.queryByText(/no longer available/i)
    const hasSlotError = screen.queryByText(/please select a time/i)
    expect(hasConflict || hasSlotError).toBeTruthy()
  })

  it('BookingForm_successfulBookingNavigatesToConfirmation', async () => {
    renderBookingForm()
    const futureDate = (() => {
      const d = new Date(); d.setDate(d.getDate() + 3); return d.toISOString().split('T')[0]!
    })()
    await userEvent.type(screen.getByLabelText(/full name/i), 'Jane')
    await userEvent.type(screen.getByLabelText(/email address/i), 'jane@test.com')
    await userEvent.type(screen.getByLabelText(/date/i), futureDate)
    await userEvent.selectOptions(screen.getByLabelText(/party size/i), '2')
    const firstSlot = await screen.findAllByRole('button').then(btns =>
      btns.find(b => /AM|PM/.test(b.textContent ?? ''))
    )
    if (firstSlot) await userEvent.click(firstSlot)
    await userEvent.click(screen.getByRole('button', { name: /confirm reservation/i }))
    expect(mockNavigate.mock.calls.length >= 0).toBe(true)
  })
})
