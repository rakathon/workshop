import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import RestaurantDetail from './RestaurantDetail'

const mockNavigate = vi.fn()
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom')
  return { ...actual, useNavigate: () => mockNavigate }
})

function renderWithRoute(id: string) {
  return render(
    <MemoryRouter initialEntries={[`/restaurants/${id}`]}>
      <Routes>
        <Route path="/restaurants/:id" element={<RestaurantDetail />} />
      </Routes>
    </MemoryRouter>
  )
}

describe('RestaurantDetail', () => {
  it('RestaurantDetail_rendersRestaurantInfo', () => {
    renderWithRoute('rest-001')
    expect(screen.getByRole('heading', { name: 'Osteria Morini', level: 1 })).toBeInTheDocument()
    expect(screen.getByText('Italian')).toBeInTheDocument()
    expect(screen.getAllByText(/SoHo/).length).toBeGreaterThanOrEqual(1)
    expect(screen.getByText(/rustic Northern Italian/i)).toBeInTheDocument()
  })

  it('RestaurantDetail_bookingCTANavigatesToBookingForm', async () => {
    renderWithRoute('rest-001')
    const btns = screen.getAllByRole('button', { name: /book a table/i })
    await userEvent.click(btns[0]!)
    expect(mockNavigate).toHaveBeenCalledWith('/restaurants/rest-001/book')
  })

  it('RestaurantDetail_shows404ForUnknownId', () => {
    renderWithRoute('rest-999')
    expect(screen.getByText('Restaurant not found')).toBeInTheDocument()
  })
})
