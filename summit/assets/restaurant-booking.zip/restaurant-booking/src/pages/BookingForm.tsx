import { useState, useMemo } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import restaurantsData from '../data/restaurants.json'
import tablesData from '../data/tables.json'
import type { Restaurant, Table } from '../types'
import { getAvailableSlots, isDateInAllowedRange } from '../utils/slots'
import { useReservations } from '../context/ReservationContext'
import SlotPicker from '../components/SlotPicker'
import StarRating from '../components/StarRating'

const restaurants = restaurantsData as Restaurant[]
const tables = tablesData as Table[]

function todayStr() {
  return new Date().toISOString().split('T')[0]!
}

function maxDateStr() {
  const d = new Date()
  d.setDate(d.getDate() + 30)
  return d.toISOString().split('T')[0]!
}

function formatTime(t: string): string {
  const [h, m] = t.split(':').map(Number)
  const period = h >= 12 ? 'PM' : 'AM'
  const display = h > 12 ? h - 12 : h === 0 ? 12 : h
  return `${display}:${String(m ?? 0).padStart(2, '0')} ${period}`
}

export default function BookingForm() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { reservations, addReservation } = useReservations()

  const restaurant = restaurants.find(r => r.id === id)

  const [date, setDate] = useState('')
  const [people, setPeople] = useState('')
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [slotConflict, setSlotConflict] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const availableSlots = useMemo(() => {
    if (!restaurant || !date || !people) return []
    return getAvailableSlots(
      restaurant.id, date, parseInt(people),
      restaurant.hours.opening_time, restaurant.hours.closing_time,
      tables, reservations
    )
  }, [restaurant, date, people, reservations])

  if (!restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center px-4">
          <p className="text-5xl mb-4">🍽</p>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Restaurant not found</h1>
          <Link to="/" className="text-orange-500 hover:underline">← Back to all restaurants</Link>
        </div>
      </div>
    )
  }

  function validate(): boolean {
    const e: Record<string, string> = {}
    if (!name.trim()) e.name = 'Please enter your name'
    if (!email.trim()) {
      e.email = 'Please enter your email address'
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      e.email = 'Please enter a valid email address'
    }
    if (!date) {
      e.date = 'Please select a date'
    } else if (!isDateInAllowedRange(date)) {
      e.date = 'Date must be within the next 30 days'
    }
    if (!people) e.people = 'Please select party size'
    if (!selectedSlot) e.slot = 'Please select a time slot'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSlotConflict(false)
    if (!validate()) return
    setSubmitting(true)

    const eligibleTables = tables.filter(
      t => t.restaurant_id === restaurant.id && t.capacity >= parseInt(people)
    )
    const tableForBooking = eligibleTables.find(
      t => !reservations.some(
        r => r.table_id === t.id && r.date === date && r.slot_start === selectedSlot
      )
    )

    if (!tableForBooking) {
      setSlotConflict(true)
      setSubmitting(false)
      return
    }

    const reservationId = `res-${crypto.randomUUID()}`
    const [h, m] = selectedSlot!.split(':').map(Number)
    const endH = ((h ?? 0) + 1) % 24
    const slotEnd = `${String(endH).padStart(2, '0')}:${String(m ?? 0).padStart(2, '0')}`

    addReservation({
      id: reservationId,
      restaurant_id: restaurant.id,
      table_id: tableForBooking.id,
      date,
      slot_start: selectedSlot!,
      slot_end: slotEnd,
      people: parseInt(people),
      diner_name: name.trim(),
      diner_email: email.trim().toLowerCase(),
      created_at: new Date().toISOString(),
    })

    navigate(`/confirmation/${reservationId}`)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl">🍽</span>
            <span className="text-xl font-bold text-gray-900 hidden sm:block">GrabATable</span>
          </Link>
          <Link to="/my-reservations" className="text-sm font-medium text-gray-600 hover:text-orange-500 transition-colors">
            My Reservations
          </Link>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-gray-500 mb-6" aria-label="Breadcrumb">
          <Link to="/" className="hover:text-orange-500 transition-colors">Restaurants</Link>
          <span>›</span>
          <Link to={`/restaurants/${restaurant.id}`} className="hover:text-orange-500 transition-colors">{restaurant.name}</Link>
          <span>›</span>
          <span className="text-gray-800">Book a Table</span>
        </nav>

        {/* Restaurant summary card */}
        <div className="flex gap-4 items-center bg-white rounded-xl p-4 shadow-sm border border-gray-100 mb-6">
          <img
            src={restaurant.photos.cover}
            alt={restaurant.name}
            className="w-20 h-16 rounded-lg object-cover shrink-0"
          />
          <div className="min-w-0">
            <p className="font-bold text-gray-900 truncate">{restaurant.name}</p>
            <StarRating rating={restaurant.rating} reviewCount={restaurant.review_count} />
            <p className="text-xs text-gray-500 mt-0.5">
              {restaurant.cuisine} · {restaurant.location.city}, {restaurant.location.state} · {restaurant.price_range}
            </p>
          </div>
        </div>

        {/* Booking form */}
        <form onSubmit={handleSubmit} noValidate className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-5">
          <h1 className="text-2xl font-bold text-gray-900">Book a Table</h1>
          <p className="text-sm text-gray-500 -mt-3">No account required — just fill in your details below.</p>

          {/* Date + People row */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="date" className="block text-sm font-semibold text-gray-700 mb-1.5">Date</label>
              <input
                id="date"
                type="date"
                value={date}
                min={todayStr()}
                max={maxDateStr()}
                onChange={e => { setDate(e.target.value); setSelectedSlot(null) }}
                className={`w-full border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 ${errors.date ? 'border-red-400 bg-red-50' : 'border-gray-200'}`}
              />
              {errors.date && <p className="text-xs text-red-500 mt-1">{errors.date}</p>}
            </div>
            <div>
              <label htmlFor="people" className="block text-sm font-semibold text-gray-700 mb-1.5">Party size</label>
              <select
                id="people"
                value={people}
                onChange={e => { setPeople(e.target.value); setSelectedSlot(null) }}
                className={`w-full border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 ${errors.people ? 'border-red-400 bg-red-50' : 'border-gray-200'}`}
              >
                <option value="">Select</option>
                {[1, 2, 3, 4, 5, 6].map(n => <option key={n} value={n}>{n} {n === 1 ? 'person' : 'people'}</option>)}
              </select>
              {errors.people && <p className="text-xs text-red-500 mt-1">{errors.people}</p>}
            </div>
          </div>

          {/* Time slots */}
          {date && people && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Available times
                <span className="ml-2 text-xs font-normal text-gray-400">
                  {restaurant.hours.opening_time && `${formatTime(restaurant.hours.opening_time)} – ${formatTime(restaurant.hours.closing_time)}`}
                </span>
              </label>
              {slotConflict && (
                <div className="mb-2 px-3 py-2 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                  ⚠️ This slot is no longer available. Please choose another time.
                </div>
              )}
              <SlotPicker
                availableSlots={availableSlots}
                selectedSlot={selectedSlot}
                onSlotSelect={slot => { setSelectedSlot(slot); setSlotConflict(false) }}
              />
              {errors.slot && <p className="text-xs text-red-500 mt-1">{errors.slot}</p>}
            </div>
          )}

          <div className="border-t border-gray-100 pt-5 space-y-4">
            <p className="text-sm font-semibold text-gray-700">Your details</p>

            {/* Name */}
            <div>
              <label htmlFor="diner-name" className="block text-sm text-gray-600 mb-1.5">Full name</label>
              <input
                id="diner-name"
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Jane Smith"
                className={`w-full border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 ${errors.name ? 'border-red-400 bg-red-50' : 'border-gray-200'}`}
              />
              {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
            </div>

            {/* Email */}
            <div>
              <label htmlFor="diner-email" className="block text-sm text-gray-600 mb-1.5">Email address</label>
              <input
                id="diner-email"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="jane@example.com"
                className={`w-full border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 ${errors.email ? 'border-red-400 bg-red-50' : 'border-gray-200'}`}
              />
              {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
              <p className="text-xs text-gray-400 mt-1">Used to look up your reservations — no account created</p>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 bg-orange-500 text-white font-bold rounded-xl hover:bg-orange-600 disabled:opacity-60 disabled:cursor-not-allowed transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 text-base"
          >
            {submitting ? 'Confirming your reservation…' : 'Confirm Reservation'}
          </button>

          <p className="text-xs text-gray-400 text-center">
            Free cancellation · No credit card required · No account needed
          </p>
        </form>
      </main>
    </div>
  )
}
