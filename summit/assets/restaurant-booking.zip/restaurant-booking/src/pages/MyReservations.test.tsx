import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import MyReservations from './MyReservations'
import { ReservationProvider } from '../context/ReservationContext'
import type { Reservation } from '../types'

function makeLocalStorageMock(initial: Reservation[] = []) {
  let store: Record<string, string> = { rba_reservations: JSON.stringify(initial) }
  return {
    getItem: (key: string) => store[key] ?? null,
    setItem: (key: string, value: string) => { store[key] = value },
    removeItem: (key: string) => { delete store[key] },
    clear: () => { store = {} },
  }
}

// Future dates so reservations show as "upcoming"
const futureDate1 = (() => { const d = new Date(); d.setDate(d.getDate() + 10); return d.toISOString().split('T')[0]! })()
const futureDate2 = (() => { const d = new Date(); d.setDate(d.getDate() + 5); return d.toISOString().split('T')[0]! })()
const futureDate3 = (() => { const d = new Date(); d.setDate(d.getDate() + 12); return d.toISOString().split('T')[0]! })()

const res1: Reservation = { id: 'res-001', restaurant_id: 'rest-001', table_id: 'tbl-001-2', date: futureDate1, slot_start: '19:00', slot_end: '20:00', people: 2, diner_name: 'Jane', diner_email: 'jane@test.com', created_at: '' }
const res2: Reservation = { id: 'res-002', restaurant_id: 'rest-002', table_id: 'tbl-002-2', date: futureDate2, slot_start: '20:00', slot_end: '21:00', people: 4, diner_name: 'Jane', diner_email: 'jane@test.com', created_at: '' }
const res3: Reservation = { id: 'res-003', restaurant_id: 'rest-003', table_id: 'tbl-003-1', date: futureDate3, slot_start: '18:00', slot_end: '19:00', people: 2, diner_name: 'Bob', diner_email: 'bob@test.com', created_at: '' }

function renderMyReservations(reservations: Reservation[] = [res1, res2, res3]) {
  vi.stubGlobal('localStorage', makeLocalStorageMock(reservations))
  return render(
    <MemoryRouter>
      <ReservationProvider>
        <MyReservations />
      </ReservationProvider>
    </MemoryRouter>
  )
}

describe('MyReservations', () => {
  beforeEach(() => vi.stubGlobal('localStorage', makeLocalStorageMock()))

  it('MyReservations_returnsMatchingReservations', async () => {
    renderMyReservations()
    await userEvent.type(screen.getByRole('textbox'), 'jane@test.com')
    await userEvent.click(screen.getByRole('button', { name: /find/i }))
    expect(screen.getByText('Osteria Morini')).toBeInTheDocument()
    expect(screen.getByText('Cosme')).toBeInTheDocument()
    expect(screen.queryByText('Rasika')).not.toBeInTheDocument()
  })

  it('MyReservations_emptyStateWhenNoMatch', async () => {
    renderMyReservations()
    await userEvent.type(screen.getByRole('textbox'), 'nobody@test.com')
    await userEvent.click(screen.getByRole('button', { name: /find/i }))
    expect(screen.getByText(/no reservations found/i)).toBeInTheDocument()
  })

  it('MyReservations_caseInsensitiveEmailMatch', async () => {
    renderMyReservations()
    await userEvent.type(screen.getByRole('textbox'), 'JANE@TEST.COM')
    await userEvent.click(screen.getByRole('button', { name: /find/i }))
    expect(screen.getByText('Osteria Morini')).toBeInTheDocument()
  })

  it('MyReservations_sortsByDateAsc', async () => {
    renderMyReservations()
    await userEvent.type(screen.getByRole('textbox'), 'jane@test.com')
    await userEvent.click(screen.getByRole('button', { name: /find/i }))
    const names = screen.getAllByText(/Osteria Morini|Cosme/)
    // res2 has an earlier future date than res1
    expect(names[0]?.textContent).toContain('Cosme')
    expect(names[1]?.textContent).toContain('Osteria Morini')
  })
})
