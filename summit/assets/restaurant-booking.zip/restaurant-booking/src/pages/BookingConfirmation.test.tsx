import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import BookingConfirmation from './BookingConfirmation'
import { ReservationProvider } from '../context/ReservationContext'
import type { Reservation } from '../types'

function makeLocalStorageMock(initial: Reservation[] = []) {
  let store: Record<string, string> = { rba_reservations: JSON.stringify(initial) }
  return {
    getItem: (key: string) => store[key] ?? null,
    setItem: (key: string, value: string) => { store[key] = value },
    removeItem: (key: string) => { delete store[key] },
    clear: () => { store = {} },
  }
}

const mockReservation: Reservation = {
  id: 'res-test-confirm-001',
  restaurant_id: 'rest-001',
  table_id: 'tbl-001-2',
  date: '2026-07-15',
  slot_start: '19:00',
  slot_end: '20:00',
  people: 2,
  diner_name: 'Jane Smith',
  diner_email: 'jane@test.com',
  created_at: '2026-06-04T10:00:00Z',
}

function renderConfirmation(reservationId: string, reservations: Reservation[] = [mockReservation]) {
  vi.stubGlobal('localStorage', makeLocalStorageMock(reservations))
  return render(
    <MemoryRouter initialEntries={[`/confirmation/${reservationId}`]}>
      <ReservationProvider>
        <Routes>
          <Route path="/confirmation/:reservationId" element={<BookingConfirmation />} />
        </Routes>
      </ReservationProvider>
    </MemoryRouter>
  )
}

describe('BookingConfirmation', () => {
  beforeEach(() => vi.stubGlobal('localStorage', makeLocalStorageMock()))

  it('BookingConfirmation_rendersReservationDetails', () => {
    renderConfirmation('res-test-confirm-001')
    expect(screen.getByText(/confirmed/i)).toBeInTheDocument()
    expect(screen.getByText('Osteria Morini')).toBeInTheDocument()
    expect(screen.getByText('Jane Smith')).toBeInTheDocument()
    expect(screen.getByText('2 people')).toBeInTheDocument()
    expect(screen.getByText(/7:00 PM/)).toBeInTheDocument()
  })

  it('BookingConfirmation_bookAnotherTableNavigatesToRoot', () => {
    renderConfirmation('res-test-confirm-001')
    const link = screen.getByRole('link', { name: /book another table/i })
    expect(link).toHaveAttribute('href', '/')
  })

  it('BookingConfirmation_viewReservationsNavigatesToMyReservations', () => {
    renderConfirmation('res-test-confirm-001')
    const links = screen.getAllByRole('link', { name: /my reservations/i })
    expect(links.some(l => l.getAttribute('href') === '/my-reservations')).toBe(true)
  })

  it('BookingConfirmation_gracefulHandlingOfUnknownId', () => {
    renderConfirmation('res-nonexistent')
    expect(screen.getByText('Reservation not found')).toBeInTheDocument()
  })
})
