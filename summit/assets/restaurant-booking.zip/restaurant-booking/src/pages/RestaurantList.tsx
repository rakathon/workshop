import { useState, useMemo, useEffect } from 'react'
import { Link } from 'react-router-dom'
import restaurantsData from '../data/restaurants.json'
import type { Restaurant } from '../types'
import FilterBar from '../components/FilterBar'
import RestaurantCard from '../components/RestaurantCard'
import { detectCity, getCitiesFromRestaurants, DEFAULT_CITY } from '../utils/location'

const restaurants = restaurantsData as Restaurant[]
const allCities = getCitiesFromRestaurants(restaurants)

const ALL_US = 'All US'

function todayStr() {
  return new Date().toISOString().split('T')[0]!
}

export default function RestaurantList() {
  const [activeCuisine, setActiveCuisine] = useState<string | null>(null)
  const [activeCity, setActiveCity] = useState<string>(DEFAULT_CITY)
  const [locationLoading, setLocationLoading] = useState(true)
  const [showCityMenu, setShowCityMenu] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  // Hero search bar state
  const [searchDate, setSearchDate] = useState(todayStr())
  const [searchTime, setSearchTime] = useState('19:00')
  const [searchPeople, setSearchPeople] = useState('2')

  useEffect(() => {
    detectCity().then(city => {
      setActiveCity(city)
      setLocationLoading(false)
    })
  }, [])

  // Restaurants filtered by city (or all if All US selected)
  const cityRestaurants = useMemo(() => {
    if (activeCity === ALL_US) return restaurants
    return restaurants.filter(r => r.location.city === activeCity)
  }, [activeCity])

  const cuisinesInCity = useMemo(
    () => [...new Set(cityRestaurants.map(r => r.cuisine))].sort(),
    [cityRestaurants]
  )

  // Apply cuisine + search query filters
  const filtered = useMemo(() => {
    let list = cityRestaurants
    if (activeCuisine) list = list.filter(r => r.cuisine === activeCuisine)
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase()
      list = list.filter(r =>
        r.name.toLowerCase().includes(q) ||
        r.cuisine.toLowerCase().includes(q) ||
        r.location.city.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q)
      )
    }
    return list
  }, [cityRestaurants, activeCuisine, searchQuery])

  function formatDisplayTime(t: string) {
    const [h, m] = t.split(':').map(Number)
    const period = h >= 12 ? 'PM' : 'AM'
    const display = h > 12 ? h - 12 : h === 0 ? 12 : h
    return `${display}:${String(m ?? 0).padStart(2, '0')} ${period}`
  }

  const timeSlots: string[] = []
  for (let h = 6; h <= 23; h++) {
    timeSlots.push(`${String(h).padStart(2, '0')}:00`)
    timeSlots.push(`${String(h).padStart(2, '0')}:30`)
  }

  const cityLabel = locationLoading ? 'Detecting…' : activeCity

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sticky Header */}
      <header className="sticky top-0 z-20 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <span className="text-2xl">🍽</span>
            <div className="hidden sm:block">
              <span className="text-xl font-bold text-gray-900 block leading-tight">GrabATable</span>
              <span className="text-xs text-gray-400 font-normal">See availability. Book instantly.</span>
            </div>
          </Link>

          {/* City selector — left-aligned in header */}
          <div className="relative flex-1 flex justify-start">
            <button
              onClick={() => setShowCityMenu(v => !v)}
              className="flex items-center gap-1.5 text-sm font-medium text-gray-700 hover:text-orange-500 transition-colors px-3 py-2 rounded-lg hover:bg-gray-50 border border-gray-200"
            >
              <span>📍</span>
              <span>{cityLabel}</span>
              <span className="text-gray-400 text-xs">▾</span>
            </button>
            {showCityMenu && (
              <div className="absolute top-full left-0 mt-1 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-30 min-w-52">
                {/* All US option */}
                <button
                  onClick={() => { setActiveCity(ALL_US); setActiveCuisine(null); setShowCityMenu(false) }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-orange-50 hover:text-orange-600 transition-colors flex items-center gap-2 ${
                    activeCity === ALL_US ? 'text-orange-600 font-semibold bg-orange-50' : 'text-gray-700'
                  }`}
                >
                  <span>🇺🇸</span>
                  <span>All US</span>
                  <span className="ml-auto text-xs text-gray-400">{restaurants.length}</span>
                </button>
                <div className="border-t border-gray-100 my-1" />
                {allCities.map(city => (
                  <button
                    key={city}
                    onClick={() => { setActiveCity(city); setActiveCuisine(null); setShowCityMenu(false) }}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-orange-50 hover:text-orange-600 transition-colors flex items-center gap-2 ${
                      city === activeCity ? 'text-orange-600 font-semibold bg-orange-50' : 'text-gray-700'
                    }`}
                  >
                    <span>📍</span>
                    <span>{city}</span>
                    <span className="ml-auto text-xs text-gray-400">
                      {restaurants.filter(r => r.location.city === city).length}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <nav className="flex items-center gap-4 shrink-0">
            <Link
              to="/my-reservations"
              className="text-sm font-medium text-gray-600 hover:text-orange-500 transition-colors hidden sm:block"
            >
              My Reservations
            </Link>
            <Link
              to="/my-reservations"
              className="sm:hidden text-gray-600 hover:text-orange-500"
              aria-label="My Reservations"
            >
              🗓
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero section */}
      <section className="relative bg-gray-900 text-white" style={{ minHeight: '300px' }}>
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40"
          style={{ backgroundImage: `url(${restaurants[0]?.photos.cover})` }}
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900/60 to-gray-900/80" aria-hidden="true" />

        <div className="relative z-10 max-w-5xl mx-auto px-4 py-12 text-center">
          <p className="text-orange-300 text-sm font-semibold uppercase tracking-widest mb-2">
            {activeCity === ALL_US ? 'ALL US RESTAURANTS' : `${activeCity.toUpperCase()} RESTAURANTS`}
          </p>
          <h1 className="text-4xl md:text-5xl font-bold mb-8">Make a free reservation</h1>

          {/* Hero search bar */}
          <form
            onSubmit={e => { e.preventDefault(); document.getElementById('restaurant-grid')?.scrollIntoView({ behavior: 'smooth' }) }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 bg-white rounded-xl p-2 shadow-2xl max-w-3xl mx-auto"
          >
            <div className="flex items-center gap-2 flex-1 px-3 py-2 border-b sm:border-b-0 sm:border-r border-gray-100">
              <span className="text-gray-400 text-lg">📅</span>
              <input
                type="date"
                value={searchDate}
                min={todayStr()}
                onChange={e => setSearchDate(e.target.value)}
                className="text-sm text-gray-800 font-medium bg-transparent border-none outline-none w-full cursor-pointer"
              />
            </div>
            <div className="flex items-center gap-2 flex-1 px-3 py-2 border-b sm:border-b-0 sm:border-r border-gray-100">
              <span className="text-gray-400 text-lg">🕐</span>
              <select
                value={searchTime}
                onChange={e => setSearchTime(e.target.value)}
                className="text-sm text-gray-800 font-medium bg-transparent border-none outline-none w-full cursor-pointer"
              >
                {timeSlots.map(t => <option key={t} value={t}>{formatDisplayTime(t)}</option>)}
              </select>
            </div>
            <div className="flex items-center gap-2 flex-1 px-3 py-2 border-b sm:border-b-0 sm:border-r border-gray-100">
              <span className="text-gray-400 text-lg">👥</span>
              <select
                value={searchPeople}
                onChange={e => setSearchPeople(e.target.value)}
                className="text-sm text-gray-800 font-medium bg-transparent border-none outline-none w-full cursor-pointer"
              >
                {[1, 2, 3, 4, 5, 6].map(n => <option key={n} value={n}>{n} {n === 1 ? 'person' : 'people'}</option>)}
              </select>
            </div>
            <button
              type="submit"
              className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-6 py-3 rounded-lg transition-colors text-sm shrink-0"
            >
              Let's go
            </button>
          </form>
        </div>
      </section>

      {/* Main content */}
      <main id="restaurant-grid" className="max-w-7xl mx-auto px-4 py-8">

        {/* Section header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {activeCity === ALL_US ? 'All US Restaurants' : `Restaurants in ${activeCity}`}
            </h2>
            <p className="text-sm text-gray-500 mt-0.5">
              {filtered.length} {filtered.length === 1 ? 'restaurant' : 'restaurants'}
              {searchQuery ? ` matching "${searchQuery}"` : ''}
            </p>
          </div>

          {/* Search input */}
          <div className="relative w-full sm:w-72">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">🔍</span>
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by name or cuisine…"
              className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white shadow-sm"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-lg leading-none"
                aria-label="Clear search"
              >
                ×
              </button>
            )}
          </div>
        </div>

        {/* Cuisine filter chips */}
        <div className="mb-6">
          <FilterBar
            cuisines={cuisinesInCity}
            activeCuisine={activeCuisine}
            onFilterChange={cuisine => setActiveCuisine(cuisine)}
          />
        </div>

        {/* Results */}
        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-5xl mb-4">🍽</p>
            <h2 className="text-xl font-semibold text-gray-700 mb-2">No restaurants found</h2>
            <p className="text-gray-500 mb-5">
              {searchQuery
                ? `No results for "${searchQuery}"${activeCuisine ? ` in ${activeCuisine}` : ''}.`
                : `No ${activeCuisine} restaurants in ${activeCity}.`}
            </p>
            <div className="flex items-center justify-center gap-4">
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="text-orange-500 hover:underline font-medium">
                  Clear search
                </button>
              )}
              {activeCuisine && (
                <button onClick={() => setActiveCuisine(null)} className="text-orange-500 hover:underline font-medium">
                  Clear cuisine filter
                </button>
              )}
              {activeCity !== ALL_US && (
                <button onClick={() => { setActiveCity(ALL_US); setActiveCuisine(null) }} className="text-gray-500 hover:underline text-sm">
                  Show all US restaurants
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(restaurant => (
              <RestaurantCard key={restaurant.id} restaurant={restaurant} />
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 mt-12 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-400">
          <p className="font-semibold text-gray-600 mb-1">GrabATable</p>
          <p>See availability. Book instantly.</p>
        </div>
      </footer>

      {showCityMenu && <div className="fixed inset-0 z-10" onClick={() => setShowCityMenu(false)} />}
    </div>
  )
}
