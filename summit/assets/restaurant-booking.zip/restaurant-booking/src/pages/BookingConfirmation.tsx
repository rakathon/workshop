import { Link, useParams } from 'react-router-dom'
import { useReservations } from '../context/ReservationContext'
import restaurantsData from '../data/restaurants.json'
import type { Restaurant } from '../types'
import { formatSlot } from '../utils/slots'
import StarRating from '../components/StarRating'

const restaurants = restaurantsData as Restaurant[]

function formatDate(dateStr: string): string {
  const [year, month, day] = dateStr.split('-').map(Number)
  const d = new Date(year!, month! - 1, day!)
  return d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
}

export default function BookingConfirmation() {
  const { reservationId } = useParams<{ reservationId: string }>()
  const { reservations } = useReservations()

  const reservation = reservations.find(r => r.id === reservationId)
  const restaurant = reservation ? restaurants.find(r => r.id === reservation.restaurant_id) : undefined

  if (!reservation || !restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center">
          <p className="text-5xl mb-4">❓</p>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Reservation not found</h1>
          <p className="text-gray-500 mb-4">This reservation may have expired or the link is invalid.</p>
          <Link to="/" className="inline-block bg-orange-500 text-white font-bold px-6 py-3 rounded-xl hover:bg-orange-600 transition-colors">
            Book a Table
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl">🍽</span>
            <span className="text-xl font-bold text-gray-900 hidden sm:block">GrabATable</span>
          </Link>
          <Link to="/my-reservations" className="text-sm font-medium text-gray-600 hover:text-orange-500 transition-colors">
            My Reservations
          </Link>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-12">
        {/* Success header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-5 shadow-sm">
            <span className="text-4xl">✓</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">You're confirmed!</h1>
          <p className="text-gray-500 mt-2">Your table is reserved. We'll see you there.</p>
        </div>

        {/* Restaurant card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mb-5">
          <img
            src={restaurant.photos.cover}
            alt={restaurant.name}
            className="w-full h-40 object-cover"
          />
          <div className="p-5">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <h2 className="text-xl font-bold text-gray-900">{restaurant.name}</h2>
                <p className="text-sm text-gray-500">{restaurant.cuisine} · {restaurant.location.city}, {restaurant.location.state}</p>
                <div className="mt-1">
                  <StarRating rating={restaurant.rating} reviewCount={restaurant.review_count} />
                </div>
              </div>
            </div>

            <div className="bg-orange-50 rounded-xl p-4 space-y-2.5 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500 font-medium">Date</span>
                <span className="font-semibold text-gray-800">{formatDate(reservation.date)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 font-medium">Time</span>
                <span className="font-semibold text-gray-800">{formatSlot(reservation.slot_start)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 font-medium">Party size</span>
                <span className="font-semibold text-gray-800">
                  {reservation.people} {reservation.people === 1 ? 'person' : 'people'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 font-medium">Name</span>
                <span className="font-semibold text-gray-800">{reservation.diner_name}</span>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-gray-100">
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-400">Reservation ID</span>
                <span className="text-xs text-gray-400 font-mono truncate max-w-48">{reservation.id}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Address */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-5 flex gap-3 items-start text-sm">
          <span className="text-2xl">📍</span>
          <div>
            <p className="font-semibold text-gray-800">{restaurant.location.address}</p>
            <p className="text-gray-500">{restaurant.location.neighbourhood} · {restaurant.location.city}, {restaurant.location.state}</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-3">
          <Link
            to="/"
            className="w-full py-3.5 bg-orange-500 text-white font-bold rounded-xl text-center hover:bg-orange-600 transition-colors text-base"
          >
            Book Another Table
          </Link>
          <Link
            to="/my-reservations"
            className="w-full py-3.5 bg-white text-gray-700 font-semibold rounded-xl text-center border border-gray-200 hover:bg-gray-50 transition-colors"
          >
            View All My Reservations
          </Link>
          <Link
            to={`/restaurants/${restaurant.id}`}
            className="w-full py-3 text-orange-500 font-medium text-center hover:underline text-sm"
          >
            View {restaurant.name} details
          </Link>
        </div>
      </main>
    </div>
  )
}
