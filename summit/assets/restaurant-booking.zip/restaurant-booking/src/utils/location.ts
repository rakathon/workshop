import type { Restaurant } from '../types'

// US cities available in the data set with their coordinates
export const US_CITIES = [
  { city: 'New York', state: 'NY', lat: 40.7128, lng: -74.006 },
  { city: 'San Francisco', state: 'CA', lat: 37.7749, lng: -122.4194 },
  { city: 'Los Angeles', state: 'CA', lat: 34.0522, lng: -118.2437 },
  { city: 'Chicago', state: 'IL', lat: 41.8781, lng: -87.6298 },
  { city: 'Austin', state: 'TX', lat: 30.2672, lng: -97.7431 },
  { city: 'Washington', state: 'DC', lat: 38.9072, lng: -77.0369 },
  { city: 'Seattle', state: 'WA', lat: 47.6062, lng: -122.3321 },
  { city: 'New Orleans', state: 'LA', lat: 29.9511, lng: -90.0715 },
  { city: 'Cambridge', state: 'MA', lat: 42.3736, lng: -71.1097 },
]

export const DEFAULT_CITY = 'San Francisco'

function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371 // km
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

export function nearestCity(lat: number, lng: number): string {
  let best = DEFAULT_CITY
  let bestDist = Infinity
  for (const c of US_CITIES) {
    const d = haversineDistance(lat, lng, c.lat, c.lng)
    if (d < bestDist) {
      bestDist = d
      best = c.city
    }
  }
  return best
}

// Returns city name derived from geolocation, or DEFAULT_CITY on failure
export function detectCity(): Promise<string> {
  return new Promise(resolve => {
    if (!navigator.geolocation) {
      resolve(DEFAULT_CITY)
      return
    }
    navigator.geolocation.getCurrentPosition(
      pos => resolve(nearestCity(pos.coords.latitude, pos.coords.longitude)),
      () => resolve(DEFAULT_CITY),
      { timeout: 5000, maximumAge: 300_000 }
    )
  })
}

export function getCitiesFromRestaurants(restaurants: Restaurant[]): string[] {
  return [...new Set(restaurants.map(r => r.location.city))].sort()
}

export function filterByCity(restaurants: Restaurant[], city: string): Restaurant[] {
  return restaurants.filter(r => r.location.city === city)
}
