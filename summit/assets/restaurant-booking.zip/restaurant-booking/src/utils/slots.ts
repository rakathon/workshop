import type { Table, Reservation } from '../types'

export function isDateInAllowedRange(date: string): boolean {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const maxDate = new Date(today)
  maxDate.setDate(maxDate.getDate() + 30)

  const d = new Date(date + 'T00:00:00')
  return d >= today && d <= maxDate
}

export function getAvailableSlots(
  restaurantId: string,
  date: string,
  people: number,
  openingTime: string,
  closingTime: string,
  tables: Table[],
  reservations: Reservation[]
): string[] {
  const eligibleTables = tables.filter(
    t => t.restaurant_id === restaurantId && t.capacity >= people
  )

  const [openH, openM] = openingTime.split(':').map(Number)
  const [closeH, closeM] = closingTime.split(':').map(Number)
  const openMinutes = openH * 60 + (openM ?? 0)
  const closeMinutes = closeH * 60 + (closeM ?? 0)

  const availableSlotStarts = new Set<string>()

  for (const table of eligibleTables) {
    for (let m = openMinutes; m < closeMinutes; m += 60) {
      const h = Math.floor(m / 60)
      const min = m % 60
      const slotStart = `${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`

      const isBooked = reservations.some(
        r =>
          r.restaurant_id === restaurantId &&
          r.table_id === table.id &&
          r.date === date &&
          r.slot_start === slotStart
      )

      if (!isBooked) {
        availableSlotStarts.add(slotStart)
      }
    }
  }

  return Array.from(availableSlotStarts).sort()
}

export function formatSlot(slotStart: string): string {
  const [h, m] = slotStart.split(':').map(Number)
  const endH = (h + 1) % 24
  const period = h >= 12 ? 'PM' : 'AM'
  const endPeriod = endH >= 12 ? 'PM' : 'AM'
  const displayH = h > 12 ? h - 12 : h === 0 ? 12 : h
  const displayEndH = endH > 12 ? endH - 12 : endH === 0 ? 12 : endH
  const displayM = String(m ?? 0).padStart(2, '0')
  const displayEndM = '00'
  return `${displayH}:${displayM} ${period} – ${displayEndH}:${displayEndM} ${endPeriod}`
}

export function formatSlotStart(slotStart: string): string {
  const [h, m] = slotStart.split(':').map(Number)
  const period = h >= 12 ? 'PM' : 'AM'
  const displayH = h > 12 ? h - 12 : h === 0 ? 12 : h
  const displayM = String(m ?? 0).padStart(2, '0')
  return `${displayH}:${displayM} ${period}`
}
