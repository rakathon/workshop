import { describe, it, expect } from 'vitest'
import { getAvailableSlots, isDateInAllowedRange } from './slots'
import type { Table, Reservation } from '../types'

const tables: Table[] = [
  { id: 'tbl-a', restaurant_id: 'rest-1', capacity: 4 },
  { id: 'tbl-b', restaurant_id: 'rest-1', capacity: 2 },
]

const baseReservation: Reservation = {
  id: 'res-1',
  restaurant_id: 'rest-1',
  table_id: 'tbl-a',
  date: '2026-07-01',
  slot_start: '12:00',
  slot_end: '13:00',
  people: 2,
  diner_name: 'Test',
  diner_email: 'test@test.com',
  created_at: '2026-06-04T00:00:00Z',
}

describe('getAvailableSlots', () => {
  it('getAvailableSlots_returnsAllSlotsWhenNoneBooked', () => {
    const slots = getAvailableSlots('rest-1', '2026-07-01', 2, '12:00', '15:00', tables, [])
    expect(slots).toEqual(['12:00', '13:00', '14:00'])
  })

  it('getAvailableSlots_excludesBookedSlots', () => {
    const slots = getAvailableSlots('rest-1', '2026-07-01', 4, '12:00', '15:00', tables, [baseReservation])
    // tbl-a is booked at 12:00; tbl-b capacity=2 < 4 so only tbl-a is eligible
    // tbl-a has 13:00 and 14:00 free
    expect(slots).not.toContain('12:00')
    expect(slots).toContain('13:00')
    expect(slots).toContain('14:00')
  })

  it('getAvailableSlots_respectsCapacity', () => {
    // Request 5 people — no table with capacity >= 5
    const slots = getAvailableSlots('rest-1', '2026-07-01', 5, '12:00', '15:00', tables, [])
    expect(slots).toHaveLength(0)
  })

  it('getAvailableSlots_respectsOperatingHours', () => {
    const slots = getAvailableSlots('rest-1', '2026-07-01', 2, '19:00', '22:00', tables, [])
    // Should only have 19:00, 20:00, 21:00
    expect(slots).toEqual(['19:00', '20:00', '21:00'])
    expect(slots).not.toContain('22:00')
    expect(slots).not.toContain('18:00')
  })

  it('getAvailableSlots_deduplicatesBySlotStart', () => {
    // Both tables are eligible, both free — each slot_start should appear only once
    const slots = getAvailableSlots('rest-1', '2026-07-01', 1, '12:00', '14:00', tables, [])
    const unique = new Set(slots)
    expect(slots.length).toBe(unique.size)
  })
})

describe('isDateInAllowedRange', () => {
  it('isDateInAllowedRange_trueForToday', () => {
    const today = new Date()
    const todayStr = today.toISOString().split('T')[0]!
    expect(isDateInAllowedRange(todayStr)).toBe(true)
  })

  it('isDateInAllowedRange_trueForPlus30', () => {
    const d = new Date()
    d.setDate(d.getDate() + 30)
    const str = d.toISOString().split('T')[0]!
    expect(isDateInAllowedRange(str)).toBe(true)
  })

  it('isDateInAllowedRange_falseForPlus31', () => {
    const d = new Date()
    d.setDate(d.getDate() + 31)
    const str = d.toISOString().split('T')[0]!
    expect(isDateInAllowedRange(str)).toBe(false)
  })
})
