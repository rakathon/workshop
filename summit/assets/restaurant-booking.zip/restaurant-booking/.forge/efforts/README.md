# Efforts

Registry of all Forge work efforts in this repository.

| ID | Title | Type | Tier | Risk | Parent | Phase | Status |
|----|-------|------|------|------|--------|-------|--------|
| restaurant-booking-app | Restaurant booking app | epic | full | R3 |  | verification | in_progress |
