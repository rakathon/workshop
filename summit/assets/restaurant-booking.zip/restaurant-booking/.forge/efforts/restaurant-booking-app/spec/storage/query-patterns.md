# Query Patterns

*Effort: restaurant-booking-app*  *Authored: 2026-06-04*

---

| Pattern | Entity | Filters | Sort | Source | Notes |
|---------|--------|---------|------|--------|-------|
| List all restaurants | RESTAURANT | none | none | BR-1, US-6 | Landing page catalog |
| List restaurants by cuisine | RESTAURANT | cuisine = ? | none | BR-2, US-1, US-7 | Cuisine filter |
| Get restaurant by ID | RESTAURANT | id = ? | none | BR-3, US-3 | Detail page |
| List tables by restaurant | TABLE | restaurant_id = ? | none | BR-4 | Availability check |
| List available slots for restaurant + date + party size | TIME_SLOT | restaurant_id = ?, date = ?, table.capacity ≥ party_size, reserved = false | time ASC | BR-4, US-8 | Slot picker — cross-references TABLE → TIME_SLOT → RESERVATION; acceptable for in-memory JSON mock |
| Create reservation | RESERVATION | — | — | BR-5, US-2 | Booking form submit |
| Get reservation by slot | RESERVATION | time_slot_id = ? | — | BR-7 | Double-booking guard |
| List reservations by email | RESERVATION | email = ? | date ASC | BR-11 | My reservations lookup |
| Get reservation by ID | RESERVATION | id = ? | — | BR-6 | Confirmation screen |

## Notes

- All patterns are executed in-memory against JSON files loaded at app startup — no database indexes required for MVP.
- The "List available slots" pattern is the most complex: it filters TIME_SLOTs by restaurant and date, checks TABLE capacity against party size, and excludes slots with an existing RESERVATION. Flag for indexing if a real database is introduced post-MVP.
- RESERVATION is the only entity written at runtime; all other patterns are reads against static JSON.
