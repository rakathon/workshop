# UI Spec — Restaurant Booking App

## Goal

A React + Tailwind SPA that lets US diners browse a curated list of 25–30 restaurants, filter by cuisine, view restaurant details and menus, and book a table for any meal occasion — no account or login required.

## Mode

mode: production

## Scope

scope: feature-area

Full application — all five routes implemented as a single cohesive SPA.

Target locations:
- `/` → `src/pages/RestaurantList.tsx`
- `/restaurants/:id` → `src/pages/RestaurantDetail.tsx`
- `/restaurants/:id/book` → `src/pages/BookingForm.tsx`
- `/confirmation/:reservationId` → `src/pages/BookingConfirmation.tsx`
- `/my-reservations` → `src/pages/MyReservations.tsx`

## Data

All data loaded from local JSON files — no network requests.

**restaurants.json** (static import):
```
{
  id: string,
  name: string,
  cuisine: string,           // Italian | Mexican | Indian | American | Chinese | Japanese | Mediterranean | French | Korean | Soul Food
  location: {
    city: string, state: string, neighbourhood: string, address: string
  },
  description: string,
  hours: {
    opening_time: string,    // HH:MM 24h
    closing_time: string,    // HH:MM 24h
    days_open: string[]
  },
  price_range: string,       // $ | $$ | $$$ | $$$$
  photos: {
    cover: string,           // /images/restaurants/rest-NNN-cover.jpg
    gallery: string[]
  },
  menu: {
    categories: [{
      id: string, name: string,
      items: [{ id: string, name: string, description: string, price: number }]
    }]
  }
}
```

**tables.json** (static import):
```
{ id: string, restaurant_id: string, capacity: number, label?: string }
```

**Reservations** — read/written to localStorage key `rba_reservations`:
```
{
  id: string,              // res-<uuid>
  restaurant_id: string,
  table_id: string,
  date: string,            // YYYY-MM-DD
  slot_start: string,      // HH:MM
  slot_end: string,        // HH:MM (slot_start + 1h)
  people: number,          // 1–6
  diner_name: string,      // PII — localStorage only
  diner_email: string,     // PII — localStorage only
  created_at: string       // ISO-8601 UTC
}
```

**Slot derivation** (runtime, in `src/utils/slots.ts`):
For restaurant R, date D, people P: get tables where capacity ≥ P, generate 1-hour slots within opening/closing hours, exclude slots with existing reservations for same table+date+slot_start.

## Pages and Components

### Page 1: RestaurantList (`/`)

**Layout:** Full-width page with sticky header, filter bar, and responsive restaurant grid.

**Sections (top to bottom):**

1. **AppHeader** — app name/logo, navigation link to "My Reservations"
2. **HeroSection** — brief headline ("Book a table, skip the hassle") and subtext
3. **FilterBar** — horizontal scrollable list of cuisine filter chips: All + one per cuisine in data set. Active chip visually distinct. Client-side filter, <500ms.
4. **RestaurantGrid** — responsive grid of RestaurantCard components
   - Mobile (375px): 1 column
   - Tablet (768px): 2 columns
   - Desktop (1280px): 3 columns
5. **EmptyState** — shown when filter returns no results: illustration + "No restaurants found for [cuisine]. Try a different cuisine."

**RestaurantCard component:**
- Cover photo (aspect ratio 16:9, object-cover)
- Restaurant name (heading)
- Cuisine tag + neighbourhood/city
- Price range indicator
- "Book a table" CTA button → navigates to `/restaurants/:id`

---

### Page 2: RestaurantDetail (`/restaurants/:id`)

**Layout:** Full-width with back navigation, photo gallery, info section, menu section, and booking CTA.

**Sections (top to bottom):**

1. **BackNav** — "← All Restaurants" link to `/`
2. **PhotoGallery** — cover photo full-width + thumbnail strip for gallery images
3. **RestaurantInfo**
   - Name (h1), cuisine badge, price range
   - Location: neighbourhood, city, state, full address
   - Operating hours (formatted: e.g. "Mon–Sun 11:00 AM – 10:00 PM")
   - Description paragraph
4. **MenuSection** — accordion or tabbed layout per menu category
   - Category name as section header
   - Items: name, description, price (right-aligned)
   - Min 3 categories, 2+ items each
5. **BookingCTA** — sticky bottom bar (mobile) or sidebar (desktop)
   - "Book a Table" button → navigates to `/restaurants/:id/book`

---

### Page 3: BookingForm (`/restaurants/:id/book`)

**Layout:** Centered card layout, max-width 640px, restaurant summary at top.

**Sections (top to bottom):**

1. **RestaurantSummary** — mini card: cover photo thumbnail, name, cuisine, location
2. **BookingFormFields** — controlled React form, no external library
   - **Date picker** — native `<input type="date">`, min=today, max=today+30 days
   - **People selector** — dropdown or stepper, values 1–6, label "Number of people"
   - **SlotPicker** — rendered after date + people are selected; shows available 1-hour slots as selectable time chips (e.g. "12:00 PM", "1:00 PM"); unavailable slots not shown; empty state if no slots available
   - **Diner name** — text input, required
   - **Diner email** — email input, required, format-validated
3. **FormActions**
   - "Confirm Booking" submit button (disabled until all fields valid)
   - Inline field-level error messages shown on submit attempt

**States:**
- Default: empty form, date/people selects slot list
- Slot unavailable error: after submit conflict detected — inline error above slot picker: "This slot is no longer available, please choose another time."
- Form validation errors: inline below each invalid field
- Submitting: button shows loading indicator, disabled during write to localStorage

---

### Page 4: BookingConfirmation (`/confirmation/:reservationId`)

**Layout:** Centered, max-width 540px. Celebratory / success state.

**Sections:**

1. **SuccessHeader** — checkmark icon, "Booking Confirmed!" heading
2. **ReservationSummary** card:
   - Restaurant name
   - Date (formatted: e.g. "Saturday, June 15 2026")
   - Time slot (e.g. "7:00 PM – 8:00 PM")
   - People (e.g. "3 people")
   - Diner name
   - Reservation ID (small, muted)
3. **Actions**
   - "Book Another Table" → `/`
   - "View My Reservations" → `/my-reservations`

---

### Page 5: MyReservations (`/my-reservations`) — P2

**Layout:** Centered, max-width 640px.

**Sections:**

1. **EmailLookupForm** — single email input + "Find Reservations" button
2. **ReservationList** — list of matching reservations sorted by date ASC
   - Each item: restaurant name, date, time slot, people, reservation ID
   - Empty state: "No reservations found for [email]."
3. **NoResults** — shown if email not found: muted text, link back to "/"

---

## States Required

- [ ] Default (data loaded, restaurants visible) — RestaurantList
- [ ] Empty state (cuisine filter returns no matches) — FilterBar + RestaurantGrid
- [ ] Slot unavailable error (double-booking conflict on submit) — BookingForm
- [ ] Form validation errors (inline, on submit attempt) — BookingForm
- [ ] No slots available (all slots booked for selected date/people/restaurant) — SlotPicker
- [ ] Booking confirmation (post-booking success) — BookingConfirmation
- [ ] No reservations found (email lookup returns empty) — MyReservations

## Accessibility Notes

None beyond organizational baseline (WCAG 2.1 AA).

Standard requirements apply:
- All interactive elements keyboard-accessible
- Form fields have associated `<label>` elements
- Images have descriptive `alt` text (restaurant cover photos: restaurant name; decorative elements: `alt=""`)
- Color is not the sole indicator of state (filter chips and slot selection must have non-color differentiation)
- Focus visible on all interactive elements

## Design Reference

No Figma handoff — implementation is derived from product requirements and data contracts. Visual design decisions:
- Tailwind CSS utility classes throughout; no custom CSS files
- Neutral base palette with one accent color for CTAs and active states
- Mobile-first responsive layout (375px → 768px → 1280px breakpoints)
- Clean, uncluttered aesthetic — white/light-gray backgrounds, generous padding, readable typography

## Out of Scope

- Authentication, login, or user accounts
- Real email sending (confirmation is on-screen only)
- Native iOS or Android apps (responsive web only)
- Restaurant operator tools (dashboard, CRM, analytics)
- Crowdsourced reviews or ratings
- Analytics instrumentation
- Server-side rendering or backend API
