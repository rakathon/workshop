# Logical Schema

*Effort: restaurant-booking-app*  *Authored: 2026-06-04*

---

## Entity-Relationship Diagram

```mermaid
erDiagram
    RESTAURANT ||--|| MENU : "has"
    RESTAURANT ||--|{ TABLE : "has"
    TABLE ||--|{ TIME_SLOT : "generates"
    TIME_SLOT ||--o| RESERVATION : "fulfilled by"
    MENU ||--|{ MENU_CATEGORY : "contains"
    MENU_CATEGORY ||--|{ MENU_ITEM : "contains"
```

## Entities

| Entity | Description |
|--------|-------------|
| RESTAURANT | A curated restaurant — name, cuisine type, location (city/neighbourhood), description, operating hours, and cover photo |
| TABLE | A physical table within a restaurant with a defined seating capacity |
| TIME_SLOT | A 1-hour bookable window for a specific table on a specific date, within the restaurant's operating hours |
| RESERVATION | A confirmed booking made by a diner — links to a time slot, stores diner name and email |
| MENU | The menu belonging to a restaurant — embedded within the RESTAURANT in JSON |
| MENU_CATEGORY | A grouping of menu items (e.g. Starters, Mains, Desserts) within a menu |
| MENU_ITEM | An individual dish within a category — name, description, and optionally price |

## Notes

- MENU, MENU_CATEGORY, and MENU_ITEM are modelled as nested structures within the RESTAURANT JSON object rather than separate files — no joins required for the mock data layer.
- TIME_SLOTs are derived from a restaurant's operating hours and the 1-hour slot model; they are stored as a generated structure in JSON, not as a separate top-level file.
- RESERVATION is the only entity that is written at runtime (user action); all other entities are static mock data.
