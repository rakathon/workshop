# Physical Schema — JSON

*Effort: restaurant-booking-app*  *Authored: 2026-06-04*

---

## File Structure

```
src/data/
  restaurants.json   — static; all restaurant and menu data
  tables.json        — static; all tables per restaurant
  reservations.json  — runtime; written to localStorage on each booking (initial value: [])
```

> **TIME_SLOT is not a stored file.** Slots are derived at runtime by generating all
> 1-hour windows between a restaurant's `opening_time` and `closing_time`, then
> filtering out windows where a RESERVATION already exists for a table of sufficient
> capacity. This avoids pre-generating thousands of slot records.

---

## restaurants.json

Array of RESTAURANT objects. MENU is embedded within each restaurant (no separate file).

### Shape

```json
[
  {
    "id": "rest-001",
    "name": "Osteria Morini",
    "cuisine": "Italian",
    "location": {
      "city": "New York",
      "state": "NY",
      "neighbourhood": "SoHo",
      "address": "218 Lafayette St, New York, NY 10012"
    },
    "description": "Rustic Northern Italian fare in a warm, convivial space.",
    "hours": {
      "opening_time": "11:00",
      "closing_time": "22:00",
      "days_open": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    },
    "price_range": "$$",
    "photos": {
      "cover": "/images/rest-001-cover.jpg",
      "gallery": ["/images/rest-001-1.jpg", "/images/rest-001-2.jpg"]
    },
    "menu": {
      "categories": [
        {
          "id": "cat-001",
          "name": "Starters",
          "items": [
            {
              "id": "item-001",
              "name": "Bruschetta al Pomodoro",
              "description": "Grilled bread with heirloom tomatoes and basil",
              "price": 12.00
            }
          ]
        }
      ]
    }
  }
]
```

### Field Reference — RESTAURANT

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `id` | string | ✓ | Unique identifier, e.g. `rest-001` |
| `name` | string | ✓ | Display name |
| `cuisine` | string | ✓ | One of: Italian, Mexican, Indian, American, Chinese, Japanese, Mediterranean, French, Korean, Soul Food |
| `location.city` | string | ✓ | US city name |
| `location.state` | string | ✓ | 2-letter state code |
| `location.neighbourhood` | string | ✓ | Neighbourhood or district |
| `location.address` | string | ✓ | Full street address |
| `description` | string | ✓ | 2–4 sentence restaurant description |
| `hours.opening_time` | string | ✓ | `HH:MM` 24-hour format |
| `hours.closing_time` | string | ✓ | `HH:MM` 24-hour format |
| `hours.days_open` | string[] | ✓ | Days the restaurant is open |
| `price_range` | string | ✓ | One of: `$` / `$$` / `$$$` / `$$$$` |
| `photos.cover` | string | ✓ | Path or URL to cover image |
| `photos.gallery` | string[] | ✓ | Min 1 additional photo |
| `menu.categories` | array | ✓ | Min 3 categories per restaurant |
| `menu.categories[].id` | string | ✓ | Unique category identifier |
| `menu.categories[].name` | string | ✓ | Category display name |
| `menu.categories[].items` | array | ✓ | Min 2 items per category |
| `menu.categories[].items[].id` | string | ✓ | Unique item identifier |
| `menu.categories[].items[].name` | string | ✓ | Dish name |
| `menu.categories[].items[].description` | string | ✓ | Short dish description |
| `menu.categories[].items[].price` | number | ✓ | Price in USD |

### Operating Hours Patterns

The data set must include at least 4 distinct operating hour patterns:

| Pattern | opening_time | closing_time | Example meal services |
|---------|-------------|--------------|----------------------|
| Breakfast + Lunch | `07:00` | `15:00` | Breakfast, brunch, lunch |
| Lunch + Dinner | `11:00` | `22:00` | Lunch, dinner |
| Dinner Only | `17:00` | `23:00` | Dinner |
| All Day | `08:00` | `22:00` | Breakfast, lunch, dinner |

---

## tables.json

Array of TABLE objects. Each restaurant has 3–6 tables of varying capacities.

### Shape

```json
[
  {
    "id": "tbl-001",
    "restaurant_id": "rest-001",
    "capacity": 4,
    "label": "Table 1"
  }
]
```

### Field Reference — TABLE

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `id` | string | ✓ | Unique identifier, e.g. `tbl-001` |
| `restaurant_id` | string | ✓ | Foreign key → restaurants.json[].id |
| `capacity` | number | ✓ | Maximum number of people at this table (e.g. 2, 4, 6) |
| `label` | string | ✗ | Optional display name, e.g. "Window Table" |

---

## reservations.json

Array of RESERVATION objects. Initial value: `[]`. Persisted to localStorage at runtime — loaded from localStorage on app initialisation, falling back to `[]`.

### Shape

```json
[
  {
    "id": "res-a1b2c3",
    "restaurant_id": "rest-001",
    "table_id": "tbl-001",
    "date": "2026-06-15",
    "slot_start": "19:00",
    "slot_end": "20:00",
    "people": 3,
    "diner_name": "Jane Smith",
    "diner_email": "jane@example.com",
    "created_at": "2026-06-04T09:15:00Z"
  }
]
```

### Field Reference — RESERVATION

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `id` | string | ✓ | `res-` prefixed short random string, e.g. `res-a1b2c3` |
| `restaurant_id` | string | ✓ | Foreign key → restaurants.json[].id |
| `table_id` | string | ✓ | Foreign key → tables.json[].id |
| `date` | string | ✓ | `YYYY-MM-DD` format |
| `slot_start` | string | ✓ | `HH:MM` 24-hour format — start of 1-hour slot |
| `slot_end` | string | ✓ | `HH:MM` 24-hour format — always slot_start + 1 hour |
| `people` | number | ✓ | Number of people; must be ≤ table capacity |
| `diner_name` | string | ✓ | **PII** — stored in localStorage only; no server-side retention for MVP |
| `diner_email` | string | ✓ | **PII** — stored in localStorage only; no server-side retention for MVP |
| `created_at` | string | ✓ | ISO-8601 UTC timestamp |

---

## Slot Derivation Algorithm (runtime)

```
For restaurant R on date D with people count P:
  1. Load tables: T[] where T.restaurant_id = R.id AND T.capacity >= P
  2. Load reservations: existing[] from localStorage
  3. For each table T in T[]:
       Generate slots from R.hours.opening_time to R.hours.closing_time, step 1 hour
       For each slot S:
         If no reservation exists where
           restaurant_id = R.id AND table_id = T.id AND date = D AND slot_start = S.start
         → slot S is available for table T
  4. Collect all available (slot_start, table_id) pairs
  5. Deduplicate by slot_start — if any table has the slot free, surface it once
  6. Return sorted by slot_start ASC
```

---

## Constraints

- `date` range: today to today + 30 days inclusive (TR-1)
- `people` minimum: 1; maximum: 6 (BR-4)
- No slot may start at or after `closing_time`
- No slot may start before `opening_time`
- A reservation is only valid if the restaurant is open on the day of week for `date`
