# Implementation Plan: Restaurant Booking App

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

```mermaid
gantt
    title  Restaurant Booking App — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Foundation
    Scaffold Vite + React + Tailwind project          :task1, 1, 2
    Create src directory structure                    :task2, 1, 2
    Author restaurants.json + tables.json data        :task3, 1, 2
    Add restaurant image assets                       :task4, 1, 2
    Implement ReservationContext + localStorage       :task5, 1, 2
    Set up React Router v6 routes                     :task6, 1, 2
    Foundation observable                             :milestone, m0, 2, 0

    section Restaurant Browsing
    Build RestaurantCard component                    :task7, 2, 3
    Build FilterBar component                         :task8, 2, 3
    Build RestaurantList page                         :task9, 2, 3
    Browsing observable                               :milestone, m1, 3, 0

    section Restaurant Detail + Menu
    Build PhotoGallery component                      :task10, 3, 4
    Build MenuSection component                       :task11, 3, 4
    Build RestaurantDetail page                       :task12, 3, 4
    Detail + menu observable                          :milestone, m2, 4, 0

    section Booking Flow
    Implement slot derivation utility                 :task13, 2, 3
    Build SlotPicker component                        :task14, 3, 4
    Build BookingForm page                            :crit, task15, 4, 5
    Build BookingConfirmation page                    :task16, 4, 5
    Booking flow observable                           :milestone, m3, 5, 0

    section My Reservations (P2)
    Build MyReservations page                         :task17, 5, 6
    My Reservations observable                        :milestone, m4, 6, 0
```

---

## Wave 1 — Foundation

### TASK-001 [auto][wave:1]

Scaffold a new Vite + React + TypeScript project with Tailwind CSS configured, ESLint, and a working `npm run dev` dev server.

**Satisfies:** TR-3, TR-7
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-002 [auto][wave:1]

Create the full `src/` directory structure: `components/`, `pages/`, `context/`, `data/`, `utils/`, `hooks/`, and `public/images/restaurants/` — with placeholder `.gitkeep` files in empty directories.

**Satisfies:** TR-13
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-003 [auto][wave:1]

Author `src/data/restaurants.json` with 25–30 complete restaurant records across ≥ 5 cuisine categories (Italian, Mexican, Indian, American, Chinese, Japanese, Mediterranean, French, Korean, Soul Food), spanning multiple US cities. Each record must include id, name, cuisine, location, description, hours (using all 4 operating-hour patterns), price_range, photos, and menu (≥ 3 categories, ≥ 2 items each). Author `src/data/tables.json` with 3–6 tables per restaurant of varying capacities (2, 4, 6). Author `src/data/reservations.json` as an empty array `[]`. Image paths must use `/images/restaurants/rest-NNN-cover.jpg` format.

**Satisfies:** BR-1, BR-9, BR-10, TR-2, TR-6, TR-11
**Standards:** none
**Required tests:** none (data authoring task)

---

### TASK-004 [auto][wave:1]

Source and commit cover and gallery image assets for all restaurants under `public/images/restaurants/`. Each restaurant requires at minimum one cover image (`rest-NNN-cover.jpg`) and one gallery image (`rest-NNN-1.jpg`). Images must be stock or AI-generated (no copyrighted material). File names must match the paths in `restaurants.json`.

**Satisfies:** BR-1, BR-3, TR-11
**Standards:** none
**Required tests:** none (asset task)

---

### TASK-005 [tdd][wave:1]

Implement `src/context/ReservationContext.tsx` — a React Context that: loads reservations from localStorage key `rba_reservations` on mount (falling back to `[]`), exposes `reservations`, `addReservation(reservation)`, and persists the updated array to localStorage after each `addReservation` call.

**Satisfies:** BR-5, BR-7, BR-9, BR-11, TR-4, TR-12
**Standards:** none
**Required tests:**
- Unit: `ReservationContext_loadsFromLocalStorage` — verifies context initialises with reservations persisted in localStorage
- Unit: `ReservationContext_addReservation_persists` — verifies addReservation writes updated array to localStorage key `rba_reservations`
- Unit: `ReservationContext_fallsBackToEmptyArray` — verifies context initialises with [] when localStorage key is absent

---

### TASK-006 [auto][wave:1]

Configure React Router v6 in `src/main.tsx` with the five required routes: `/` (RestaurantList), `/restaurants/:id` (RestaurantDetail), `/restaurants/:id/book` (BookingForm), `/confirmation/:reservationId` (BookingConfirmation), `/my-reservations` (MyReservations). Wrap the app in `ReservationContext.Provider`. Stub all page components as empty placeholders so routes resolve without errors.

**Satisfies:** TR-5, TR-8
**Standards:** none
**Required tests:** none (wiring task)

---

## Wave 2 — Restaurant Browsing + Slot Utility

### TASK-007 [tdd][wave:2]

Build `src/components/RestaurantCard.tsx` — displays a single restaurant with: 16:9 cover photo (`object-cover`), restaurant name, cuisine tag, neighbourhood/city, price range indicator, and a "Book a table" CTA button that navigates to `/restaurants/:id`. Must be responsive (full-width on mobile, constrained on larger viewports via parent grid).

**Satisfies:** BR-1, BR-8, TR-3
**Standards:** none
**Required tests:**
- Unit: `RestaurantCard_rendersRequiredFields` — verifies name, cuisine, location, price range, and cover photo all render given a complete restaurant object
- Unit: `RestaurantCard_bookButtonNavigatesToDetail` — verifies clicking "Book a table" navigates to `/restaurants/rest-001`

---

### TASK-008 [tdd][wave:2]

Build `src/components/FilterBar.tsx` — renders a horizontally scrollable row of cuisine filter chips ("All" plus one per unique cuisine in the data set). The active chip is visually distinct (not color-only). Clicking a chip calls an `onFilterChange(cuisine)` callback. Selecting "All" passes `null` or `""`. Filter must complete client-side in < 500ms.

**Satisfies:** BR-2, US-1, US-7, TR-3
**Standards:** none
**Required tests:**
- Unit: `FilterBar_rendersAllChip` — verifies "All" chip is always present
- Unit: `FilterBar_rendersUniqueCuisines` — verifies one chip per unique cuisine from data
- Unit: `FilterBar_callsOnFilterChange` — verifies clicking a chip calls the callback with the cuisine string
- Unit: `FilterBar_allChipClearsFilter` — verifies clicking "All" calls callback with null/empty

---

### TASK-009 [tdd][wave:2]

Build `src/pages/RestaurantList.tsx` — the `/` landing page. Imports `restaurants.json`, renders `AppHeader`, `HeroSection`, `FilterBar`, and a responsive `RestaurantGrid` (1 col mobile / 2 col tablet / 3 col desktop) of `RestaurantCard` components. Manages filter state locally; filtered list passed to grid. Renders `EmptyState` ("No restaurants found for [cuisine]. Try a different cuisine.") when filter returns no matches.

**Satisfies:** BR-1, BR-2, BR-8, BR-9, US-6, US-7, TR-3, TR-6
**Standards:** none
**Required tests:**
- Unit: `RestaurantList_rendersAllRestaurantsByDefault` — verifies all restaurant cards render with no filter applied
- Unit: `RestaurantList_filterByCuisine` — verifies applying a cuisine filter shows only matching restaurants
- Unit: `RestaurantList_emptyStateOnNoMatch` — verifies EmptyState renders when filter produces zero results
- Unit: `RestaurantList_clearFilterRestoresFull` — verifies selecting "All" restores the full list

---

### TASK-010 [tdd][wave:2]

Implement `src/utils/slots.ts` — exports `getAvailableSlots(restaurantId, date, people, tables, reservations)` which: filters tables by `capacity >= people`, generates all 1-hour slots from `opening_time` to `closing_time` for the restaurant, excludes slots with an existing reservation matching `restaurant_id + table_id + date + slot_start`, deduplicates by `slot_start`, and returns slots sorted ASC. Also exports `isDateInAllowedRange(date)` which returns true if date is today ≤ date ≤ today+30.

**Satisfies:** BR-4, BR-7, TR-1, TR-2, TR-9
**Standards:** none
**Required tests:**
- Unit: `getAvailableSlots_returnsAllSlotsWhenNoneBooked` — verifies all hour windows within hours are returned when reservations is empty
- Unit: `getAvailableSlots_excludesBookedSlots` — verifies a slot with matching reservation does not appear
- Unit: `getAvailableSlots_respectsCapacity` — verifies tables with capacity < people are excluded
- Unit: `getAvailableSlots_respectsOperatingHours` — verifies no slot starts before opening_time or at/after closing_time
- Unit: `getAvailableSlots_deduplicatesBySlotStart` — verifies each slot_start appears at most once
- Unit: `isDateInAllowedRange_trueForToday` — verifies today is valid
- Unit: `isDateInAllowedRange_trueForPlus30` — verifies today+30 is valid
- Unit: `isDateInAllowedRange_falseForPlus31` — verifies today+31 is rejected

---

## Wave 3 — Restaurant Detail + SlotPicker

### TASK-011 [tdd][wave:3]

Build `src/components/PhotoGallery.tsx` — renders a full-width cover photo and a thumbnail strip for gallery images. Clicking a thumbnail sets it as the active (large) image. All images have descriptive `alt` text (restaurant name for cover, index for gallery). Uses `object-cover` for consistent aspect ratios.

**Satisfies:** BR-3, BR-8, TR-3
**Standards:** none
**Required tests:**
- Unit: `PhotoGallery_rendersCoverPhoto` — verifies cover image renders with correct src and alt
- Unit: `PhotoGallery_thumbnailClickSwitchesActive` — verifies clicking a thumbnail updates the large image

---

### TASK-012 [tdd][wave:3]

Build `src/components/MenuSection.tsx` — renders a restaurant's menu as an accordion or tabbed layout. Each category is a collapsible/tab section with its name as header. Items render as name + description + right-aligned price. Minimum 3 categories and 2 items each enforced by data (not by component). Keyboard-accessible tab/accordion navigation.

**Satisfies:** BR-3, BR-10, US-4, TR-3
**Standards:** none
**Required tests:**
- Unit: `MenuSection_rendersAllCategories` — verifies all menu categories render
- Unit: `MenuSection_rendersItemsInCategory` — verifies items (name, description, price) render within a category

---

### TASK-013 [tdd][wave:3]

Build `src/pages/RestaurantDetail.tsx` — the `/restaurants/:id` page. Uses `useParams` to load the correct restaurant from `restaurants.json`. Renders: `BackNav` (← All Restaurants), `PhotoGallery`, `RestaurantInfo` (name h1, cuisine badge, price range, location, formatted hours, description), `MenuSection`, and a sticky/sidebar `BookingCTA` button navigating to `/restaurants/:id/book`. Shows 404 message if restaurant ID not found.

**Satisfies:** BR-3, BR-10, US-3, US-4, TR-3, TR-5, TR-8
**Standards:** none
**Required tests:**
- Unit: `RestaurantDetail_rendersRestaurantInfo` — verifies name, cuisine, location, hours, description all render for a given restaurant id
- Unit: `RestaurantDetail_bookingCTANavigatesToBookingForm` — verifies "Book a Table" navigates to `/restaurants/rest-001/book`
- Unit: `RestaurantDetail_shows404ForUnknownId` — verifies graceful not-found state for invalid restaurant ID

---

### TASK-014 [tdd][wave:3]

Build `src/components/SlotPicker.tsx` — receives `availableSlots: string[]` (HH:MM values from `getAvailableSlots`) and `selectedSlot: string | null` plus `onSlotSelect(slot: string)`. Renders available slots as selectable time chips (formatted as 12h AM/PM). Selected chip is visually distinct (not color-only). Renders "No slots available for this date and party size." when `availableSlots` is empty. Only rendered after date and people count are selected.

**Satisfies:** BR-4, US-8, TR-3
**Standards:** none
**Required tests:**
- Unit: `SlotPicker_rendersSlotChips` — verifies one chip per available slot formatted as 12h time
- Unit: `SlotPicker_callsOnSlotSelect` — verifies clicking a chip calls the callback with the HH:MM value
- Unit: `SlotPicker_emptyStateWhenNoSlots` — verifies empty message renders when availableSlots is []
- Unit: `SlotPicker_selectedChipDistinct` — verifies selected chip has distinct visual treatment

---

## Wave 4 — Booking Flow + Confirmation

### TASK-015 [tdd][wave:4]

Build `src/pages/BookingForm.tsx` — the `/restaurants/:id/book` page. Renders `RestaurantSummary` (cover thumbnail, name, cuisine, location) followed by the controlled booking form: date picker (min=today, max=today+30), people selector (1–6), `SlotPicker` (rendered after date+people selected), diner name input, diner email input. "Confirm Booking" submit button is disabled until all fields are valid. On submit: validates all fields (inline errors below each invalid field), runs double-booking guard against localStorage reservations, on conflict shows "This slot is no longer available, please choose another time." inline above slot picker. On success: generates `res-<crypto.randomUUID()>` id, writes reservation to context/localStorage, navigates to `/confirmation/:reservationId`.

**Satisfies:** BR-4, BR-5, BR-6, BR-7, US-2, TR-1, TR-4, TR-9, TR-10, TR-12
**Standards:** none
**Required tests:**
- Unit: `BookingForm_submitButtonDisabledWhenFieldsEmpty` — verifies submit is disabled with empty form
- Unit: `BookingForm_showsInlineErrorsOnInvalidSubmit` — verifies all required field errors appear on submission with blank fields
- Unit: `BookingForm_emailValidationRejectsInvalidFormat` — verifies invalid email format triggers error
- Unit: `BookingForm_datePickerEnforcesRange` — verifies min=today and max=today+30 attributes set correctly
- Unit: `BookingForm_slotPickerHiddenUntilDateAndPeopleSelected` — verifies SlotPicker not rendered before both date and people are set
- Unit: `BookingForm_doubleBookingGuardShowsError` — verifies conflict error shown when slot is already reserved in localStorage
- Unit: `BookingForm_successfulBookingNavigatesToConfirmation` — verifies navigation to /confirmation/:id on valid submission

---

### TASK-016 [tdd][wave:4]

Build `src/pages/BookingConfirmation.tsx` — the `/confirmation/:reservationId` page. Loads the reservation from context by ID. Renders: checkmark icon + "Booking Confirmed!" heading, `ReservationSummary` card (restaurant name, formatted date e.g. "Saturday, June 15 2026", time slot e.g. "7:00 PM – 8:00 PM", people count, diner name, reservation ID in small muted text), "Book Another Table" → `/` and "View My Reservations" → `/my-reservations` action buttons. Shows graceful error if reservationId not found in context.

**Satisfies:** BR-6, US-5, TR-8
**Standards:** none
**Required tests:**
- Unit: `BookingConfirmation_rendersReservationDetails` — verifies all reservation fields render correctly for a given reservationId
- Unit: `BookingConfirmation_bookAnotherTableNavigatesToRoot` — verifies "Book Another Table" navigates to /
- Unit: `BookingConfirmation_viewReservationsNavigatesToMyReservations` — verifies "View My Reservations" navigates to /my-reservations
- Unit: `BookingConfirmation_gracefulHandlingOfUnknownId` — verifies not-found state renders without crash

---

## Wave 5 — My Reservations (P2)

### TASK-017 [tdd][wave:5]

Build `src/pages/MyReservations.tsx` — the `/my-reservations` page (P2). Renders an email input + "Find Reservations" button. On submit: reads all reservations from context, filters by matching `diner_email` (case-insensitive), renders matching reservations sorted by `date` ASC showing restaurant name, formatted date, time slot, people count, and reservation ID. Renders "No reservations found for [email]." empty state when no match. Includes a link back to `/` in the empty state.

**Satisfies:** BR-11, US-MyReservations, TR-4
**Standards:** none
**Required tests:**
- Unit: `MyReservations_returnsMatchingReservations` — verifies reservations matching email are displayed
- Unit: `MyReservations_emptyStateWhenNoMatch` — verifies empty state renders when no reservations match email
- Unit: `MyReservations_caseInsensitiveEmailMatch` — verifies matching is case-insensitive
- Unit: `MyReservations_sortsByDateAsc` — verifies results are ordered by date ascending
