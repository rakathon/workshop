# User Stories: Restaurant Booking App

*Product / Effort: restaurant-booking-app*
*Last updated: 2026-06-04*

---

## The Decisive Diner

*Knows the cuisine, wants to book fast — for any meal occasion (breakfast, lunch, or dinner).*

---

**US-1:** As a decisive diner, I want to filter restaurants by cuisine type, so that I can quickly see only the options that match what I'm in the mood for.

**Acceptance Criteria:**
- [ ] Cuisine filter reduces the restaurant list to matching restaurants within 500ms
- [ ] Selecting "All" restores the full unfiltered restaurant list
- [ ] Filter state persists while I browse the filtered list

---

**US-2:** As a decisive diner, I want to select a date, time slot, and party size and complete a booking in under 2 minutes, so that I can confirm my table reservation without creating an account — whether I'm booking for breakfast, lunch, or dinner.

**Acceptance Criteria:**
- [ ] Booking completes with only name, email, date, slot, and party size — no account required
- [ ] Confirmation screen shows all booking details immediately after submission
- [ ] Total flow from restaurant detail page to confirmation is achievable in ≤5 steps

---

## The Occasion Planner

*Booking for a special event — wants full restaurant details, menu, and a clear confirmation.*

---

**US-3:** As an occasion planner, I want to view a restaurant's photos, description, cuisine, location, and hours on its detail page, so that I can decide if it's the right venue before committing to a booking.

**Acceptance Criteria:**
- [ ] Detail page shows name, cuisine, neighbourhood/city, operating hours, description, and at least one photo
- [ ] All fields are populated — no placeholder content is visible on any restaurant detail page

---

**US-4:** As an occasion planner, I want to view the restaurant's menu before booking, so that I can confirm the food is suitable for my group's preferences and meal occasion.

**Acceptance Criteria:**
- [ ] Menu is visible on the restaurant detail page with at least 3 categories and 2+ items each
- [ ] Menu is accessible without leaving the detail page or initiating a booking
- [ ] Menu content reflects the appropriate meal types for the restaurant's operating hours

---

**US-5:** As an occasion planner, I want to see a clear confirmation screen after booking with all reservation details, so that I have everything I need to plan around the reservation.

**Acceptance Criteria:**
- [ ] Confirmation screen displays restaurant name, date, time slot, party size, and diner name
- [ ] Confirmation is shown immediately after booking completes without requiring additional navigation

---

## The Foodie Explorer

*Wants to discover new cuisines across the curated restaurant list.*

---

**US-6:** As a foodie explorer, I want to browse the full list of restaurants with their cuisine type, location, and meal availability visible, so that I can discover options for any meal occasion.

**Acceptance Criteria:**
- [ ] All restaurants appear on the listing page with name, cuisine, neighbourhood/city, and cover photo
- [ ] List is fully browsable without any filter applied
- [ ] Restaurants cover a variety of meal occasions (not exclusively dinner)

---

**US-7:** As a foodie explorer, I want to filter by multiple cuisine types (Italian, Mexican, Indian, American, Chinese, and others), so that I can narrow down to cuisines I'm curious about.

**Acceptance Criteria:**
- [ ] All defined cuisine categories are available as filter options
- [ ] Filter correctly returns restaurants for each cuisine category
- [ ] At least 2 restaurants exist per cuisine category in the data set

---

**US-8:** As a foodie explorer, I want to check available time slots for a restaurant on a specific date, so that I can find a time that works for my schedule before deciding to book.

**Acceptance Criteria:**
- [ ] Available 1-hour slots display for the selected restaurant, date, and party size
- [ ] Already-booked slots do not appear as available
- [ ] Displayed slots respect each restaurant's operating hours and meal-service schedule
