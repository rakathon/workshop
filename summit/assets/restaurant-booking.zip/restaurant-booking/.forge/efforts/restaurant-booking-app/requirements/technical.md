# Technical Requirements — Restaurant Booking App

*Effort: restaurant-booking-app*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-04*

---

## TR-13: Project Structure

*Traces to: TR-3, TR-4, TR-5*

The application source must follow this directory layout:

```
src/
  components/   — reusable UI components (RestaurantCard, SlotPicker, FilterBar, etc.)
  pages/        — route-level page components (RestaurantList, RestaurantDetail, BookingForm, BookingConfirmation, MyReservations)
  context/      — ReservationContext (global state + localStorage read/write)
  data/         — restaurants.json, tables.json, reservations.json (initial empty array)
  utils/        — slot derivation logic, date helpers, validation helpers
  hooks/        — custom hooks (useReservations, useRestaurant, useAvailability)
public/
  images/
    restaurants/ — cover and gallery image files (TR-11)
```

Key module responsibilities:
- `ReservationContext` — wraps the app; exposes `reservations`, `addReservation`, `getAvailableSlots`
- `SlotPicker` — renders available 1-hour slots for selected restaurant, date, and people count
- `FilterBar` — cuisine filter on the landing page
- `RestaurantCard` — card component used in the listing grid

---

## TR-12: Reservation ID Generation

*Traces to: BR-5, BR-6*

Reservation IDs must be generated client-side using `crypto.randomUUID()` (native browser API — no library required). Each ID must be prefixed with `res-` for readability, e.g. `res-550e8400-e29b-41d4-a716-446655440000`.

---

## TR-11: Image Assets

*Traces to: BR-1, BR-3*

Restaurant cover photos and gallery images must be committed as actual files in the repository under `public/images/restaurants/`. Each restaurant must have at minimum one cover image and one gallery image. Images must be sourced from stock or AI-generated content (no copyrighted material). Image paths in `restaurants.json` must reference these local files (e.g. `/images/restaurants/rest-001-cover.jpg`).

---

## TR-10: Form Validation

*Traces to: BR-5*

Booking form validation must be implemented using React controlled components only — no external form library (Formik, React Hook Form, etc.) for MVP. Validation rules: name is required (non-empty string), email is required and must match a valid email format, date is required and must fall within today to today + 30 days, time slot is required (must be selected), people count is required and must be between 1 and 6 inclusive. Inline error messages must appear below each invalid field on form submission attempt.

---

## TR-9: Double-Booking Guard

*Traces to: BR-7*

Before persisting a new reservation, the app must read the current reservations array from localStorage and check for an existing entry with the same `table_id`, `date`, and `slot_start`. If a conflict is found, the booking must be rejected with a user-visible error: "This slot is no longer available, please choose another time." If no conflict, the reservation is written to localStorage and the user is navigated to the confirmation screen. Last-write-wins behaviour in simultaneous tab scenarios is acceptable for MVP.

---

## TR-8: Route Structure

*Traces to: BR-1, BR-3, BR-5, BR-6, BR-11, TR-5*

The application must implement the following client-side routes:

| Route | Component | Purpose |
|-------|-----------|---------|
| `/` | RestaurantList | Landing page — full catalog with cuisine filter |
| `/restaurants/:id` | RestaurantDetail | Detail page — photos, description, hours, menu |
| `/restaurants/:id/book` | BookingForm | Date picker, slot selector, people count, name + email |
| `/confirmation/:reservationId` | BookingConfirmation | On-screen confirmation after booking |
| `/my-reservations` | MyReservations | Lookup reservations by email (P2) |

Deep-linking to any route by URL must work correctly (TR-5).

---

## TR-7: Build Tooling

*Traces to: TR-3*

The application must be scaffolded and bundled using Vite. No other build tool (Create React App, Webpack, Parcel) is permitted for MVP.

---

## TR-6: No API Layer

*Traces to: BR-9*

The application must not use a backend API, mock API server (json-server, MSW, etc.), or any network requests for data. Restaurant and table data must be loaded via direct ES module imports or static `fetch()` calls against local JSON files bundled with the app. Reservation state is read from and written to localStorage only.

---

## TR-5: Client-Side Routing

*Traces to: BR-1, BR-3, BR-5, BR-6*

The application must use React Router v6 for all client-side navigation. Each distinct view (restaurant list, restaurant detail, booking form, confirmation) must have its own URL route. Deep-linking to a restaurant detail page via URL must work correctly.

---

## TR-4: State Management and Persistence

*Traces to: BR-5, BR-7, BR-9, BR-11*

Reservation state must be managed using React Context. Confirmed bookings must be persisted to localStorage so that availability remains accurate if the user refreshes the page within the same browser session. No external state management library (Redux, Zustand, etc.) is permitted for MVP.

---

## TR-3: Frontend Stack

*Traces to: BR-1, BR-2, BR-3, BR-4, BR-5, BR-6, BR-8*

The frontend must be built using React. Tailwind CSS must be used for all styling — no other CSS framework or component library is permitted for MVP. The app must be a single-page application (SPA) with client-side routing.

---

## TR-2: Per-Restaurant Operating Hours

*Traces to: BR-4, BR-9*

Each restaurant record in the JSON data source must define its own operating hours. A minimum of four distinct hour patterns must be represented across the data set: breakfast+lunch (e.g. 07:00–15:00), lunch+dinner (e.g. 11:00–22:00), dinner-only (e.g. 17:00–23:00), and all-day (e.g. 08:00–22:00). Time slots generated for availability must respect each restaurant's defined hours — no slots may be offered outside the restaurant's open period.

---

## TR-14: Geolocation API Usage

*Traces to: BR-12*

The app must use `navigator.geolocation.getCurrentPosition()` to request location on page load. The result must be matched to the nearest US city available in the restaurant data set using straight-line distance (Haversine or simple Euclidean on lat/long). Geolocation must be non-blocking — if permission is denied or an error occurs, the app falls back to San Francisco immediately without showing an error to the user.

---

## TR-15: Real Image Assets

*Traces to: BR-13*

All restaurant images must be real photographs sourced from freely licensed stock image services (Unsplash, Pexels, or similar). Images must be downloaded and committed under `public/images/restaurants/` as JPEG or WebP files. The filename convention is `rest-NNN-cover.jpg` and `rest-NNN-1.jpg`, `rest-NNN-2.jpg` for gallery images. Each image must be ≤ 300 KB after compression to keep the repository size manageable.

---

## TR-16: Mock Ratings and Social Proof Data

*Traces to: BR-14*

Each restaurant record in `restaurants.json` must include mock rating fields: `rating` (number, 3.5–5.0, one decimal place), `review_count` (integer, 50–20000), and `booked_today` (integer, 0–250 representing bookings in the last 24 hours). These values are static mock data — no calculation logic required.

---

## TR-1: Booking Advance Window

*Traces to: BR-4, BR-5*

The date picker must restrict selection to today through today + 30 calendar days (inclusive). Dates outside this window must not be selectable.

