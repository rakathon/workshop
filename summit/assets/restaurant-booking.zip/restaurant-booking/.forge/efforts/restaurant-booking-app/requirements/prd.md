# PRD: Restaurant Booking App

*Product / Effort: restaurant-booking-app*
*Last updated: 2026-06-04*

---

## Problem Statement

US diners who want to book a table at a quality local restaurant face a frustrating mismatch: the only booking tools available are large marketplaces (OpenTable, Resy) that require account creation, present thousands of undifferentiated options, and bury the actual booking step inside a discovery platform. For a diner who already knows what cuisine they want — whether for breakfast, lunch, or dinner — this overhead is friction, not value.

Competitive research shows pricing and complexity are OpenTable's most-cited weaknesses across 1,320+ verified user reviews. All credible US alternatives (SevenRooms, Resy, Yelp Guest Manager) target restaurant operators, not diners. No current product serves the "I know what I want, just book it" intent without account overhead. The structural opening is a curated, zero-friction booking app that puts the diner's speed and simplicity first.

---

## Goals

1. Complete end-to-end booking flow — measured by ≥70% booking completion rate (browse → confirm) in user testing
2. Fast, frictionless booking — measured by ≤5 steps and <2 minutes from intent to confirmation
3. High-quality curated restaurant set — measured by 25–30 fully complete restaurant records (name, cuisine, location, hours, menu, photos, time slots) with zero placeholder data
4. Informed pre-booking decision — measured by ≥60% of users who view a restaurant detail page proceeding to check availability
5. Zero critical booking bugs — measured by 0 double-bookings or broken confirmation states across all demo/user testing scenarios

---

## Non-Goals

- We are not building user accounts or login — the zero-friction premise requires name+email only; storing credentials adds complexity and contradicts the vision.
- We are not building restaurant operator tools (dashboard, CRM, analytics) — this product serves diners, not operators; operator tooling is a different product entirely.
- We are not building a crowdsourced review or ratings system — community moderation is a platform business; editorial curation replaces it.
- We are not connecting to a real database for MVP — JSON mock data is sufficient to validate the booking flow; backend integration is a post-validation investment.
- We are not building native iOS/Android apps for MVP — responsive web is sufficient; native apps require post-validation investment.

---

## Success Metrics

### Leading Indicators (early signal)

- Booking completion rate ≥70% from restaurant detail page to confirmation screen in user testing
- Restaurant detail page → availability check conversion ≥60% in user testing
- Average booking flow step count ≤5 from first restaurant browse to confirmation
- Zero placeholder fields across all restaurant JSON records at launch

### Lagging Indicators (final outcome)

- 0 critical booking bugs (double-bookings, broken confirmation states) across all demo/testing scenarios
- 25–30 fully complete restaurant records across ≥5 cuisine categories at launch
- Availability correctly reflects booked slots in 100% of test booking scenarios

---

## Open Questions

- How far in advance can a user book? (e.g. today only, up to 30 days?) [owner: eng] [due: before availability logic is built]
- What operating hours should mock restaurants use — fixed standard hours (e.g. 12pm–10pm) or per-restaurant custom hours that vary by meal type? [owner: PM] [due: before data set authoring]

---

## Timeline / Dependencies

- **Target:** Q3 2026 — first working demo by end of July 2026
- **Dependencies:** None identified (JSON mock data; no external systems or team dependencies)

---

## Requirements

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See `user-stories.md` for Connextra-format stories grouped by persona.
