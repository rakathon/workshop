# Business Requirements: Restaurant Booking App

*Product / Effort: restaurant-booking-app*
*Last updated: 2026-06-04*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained
-->

---

## BR-1: Restaurant Catalog

**Priority:** P0

The system must display a browsable list of 25–30 restaurants, each showing name, cuisine type, neighbourhood/city, and a cover photo.

**Acceptance Criteria:**
- [ ] All restaurants appear on the listing page with name, cuisine, location, and cover photo
- [ ] No restaurant record is missing any required fields
- [ ] List loads without errors on desktop and mobile viewports

---

## BR-2: Cuisine Filter

**Priority:** P0

The system must allow diners to filter the restaurant list by cuisine type client-side.

**Acceptance Criteria:**
- [ ] Filter returns only restaurants matching the selected cuisine within 500ms
- [ ] Selecting "All" restores the full unfiltered list
- [ ] Empty state is handled gracefully when no restaurants match the selected cuisine

---

## BR-3: Restaurant Detail Page

**Priority:** P0

The system must provide a detail page per restaurant showing photos, description, cuisine type, location, operating hours, and menu.

**Acceptance Criteria:**
- [ ] Detail page displays all required fields with no placeholder content
- [ ] At least one food or restaurant photo is displayed per restaurant
- [ ] Menu is visible on the detail page with categories and items

---

## BR-4: Available Time Slot Display

**Priority:** P0

The system must display available 1-hour booking slots for a selected restaurant, date, and party size.

**Acceptance Criteria:**
- [ ] Slots reflect restaurant operating hours — no slots appear outside open hours
- [ ] Already-booked slots are not shown as available
- [ ] Party size selector works correctly for at minimum 1–6 people

---

## BR-5: Booking Creation

**Priority:** P0

The system must allow a diner to complete a reservation by providing name, email, date, time slot, and party size — with no account or login required.

**Acceptance Criteria:**
- [ ] Booking completes successfully with valid name, email, date, slot, and party size
- [ ] Form validates all required fields before submission and shows clear errors for missing inputs
- [ ] Booking is persisted in JSON so that availability is updated immediately after confirmation

---

## BR-6: Booking Confirmation Screen

**Priority:** P0

The system must display an on-screen confirmation immediately after a successful booking, showing all reservation details.

**Acceptance Criteria:**
- [ ] Confirmation screen shows restaurant name, date, time slot, party size, and diner name
- [ ] Confirmation screen is shown immediately after booking completes without requiring navigation
- [ ] No real email is sent for MVP

---

## BR-7: Availability Integrity

**Priority:** P0

The system must prevent double-bookings — a slot already reserved must not be bookable again for the same table capacity.

**Acceptance Criteria:**
- [ ] Booking a slot removes it from available slots for that table and time
- [ ] Concurrent booking attempts for the same slot do not both succeed
- [ ] No double-booking is possible across any test scenario

---

## BR-8: Responsive Web Interface

**Priority:** P0

The full booking flow must be usable on both desktop and mobile viewports without layout breakage.

**Acceptance Criteria:**
- [ ] All pages render correctly at 375px (mobile) and 1280px (desktop) viewport widths
- [ ] The complete booking flow is achievable on mobile without horizontal scrolling

---

## BR-9: Mock Data Source

**Priority:** P0

All restaurant, table, time slot, and reservation data must be served from local JSON files — no database or external API required.

**Acceptance Criteria:**
- [ ] The app runs fully with no network calls required for data
- [ ] JSON files contain all 25–30 restaurants with complete records
- [ ] Reservation state persists correctly within a session and availability reflects confirmed bookings

---

## BR-10: Menu Display

**Priority:** P1

Each restaurant detail page must include a menu with at least high-level categories and representative items.

**Acceptance Criteria:**
- [ ] Menu section is visible on all restaurant detail pages
- [ ] At least 3 menu categories per restaurant with 2+ items each
- [ ] Menu content covers a range of meal types appropriate to the restaurant's operating hours (breakfast, lunch, dinner)

---

## BR-11: My Reservations Lookup

**Priority:** P2

A diner should be able to look up their existing bookings by email address without logging in.

**Acceptance Criteria:**
- [ ] Entering a valid email returns all reservations associated with that email
- [ ] A clear empty state is shown when no bookings are found for the email
- [ ] No login or account is required to access the lookup

---

## BR-12: Location-Based Default Filtering

**Priority:** P1

The app must detect the user's geographic location on page load (via the Geolocation API) and pre-filter the restaurant list to the US city nearest to their location. If location permission is denied, the location is outside the US, or detection fails, the app must fall back to a sensible US default city (San Francisco). A city selector in the header must allow the user to manually change their city at any time.

**Acceptance Criteria:**
- [ ] On first load, the app requests location permission and derives the nearest US city from the data set
- [ ] If geolocation is unavailable or outside the US, San Francisco is shown as the default
- [ ] A city selector/badge is visible in the header showing the current city
- [ ] Changing city re-filters the restaurant list to that city's restaurants
- [ ] At least 3 US cities are represented across the restaurant data set

---

## BR-13: Real Restaurant Images

**Priority:** P0

Each restaurant must display actual food/restaurant photographs — not placeholder images. Images must be downloaded, committed to the repository, and served as local files. No external image CDN or placeholder service is permitted for production use.

**Acceptance Criteria:**
- [ ] All 28 restaurants have a real cover image and at least one gallery image committed under `public/images/restaurants/`
- [ ] No placeholder.co, picsum, or other external placeholder service URLs appear in the app
- [ ] Images load correctly in the restaurant listing and detail pages

---

## BR-14: Production-Ready UI Polish

**Priority:** P0

The UI must be visually polished and production-ready, modelled on the quality level of OpenTable's restaurant listing experience. This includes: a hero search bar with date, time, and party size selectors on the landing page; a sticky header with city selector and branding; restaurant cards with ratings display, review counts, and "booked N times today" social proof; detailed restaurant information with clearly formatted hours, address, and cuisine tags; and consistent typography, spacing, and colour usage throughout.

**Acceptance Criteria:**
- [ ] Landing page has a full-width hero section with inline date, time, and party size quick-search that pre-fills the booking form
- [ ] Restaurant cards show name, cuisine, price range, location, a star rating (mock 4.0–5.0), and a review count
- [ ] "Booked N times today" social proof label appears on cards for restaurants with high booking activity
- [ ] Restaurant detail page has a properly formatted address, opening hours per day, and cuisine/price tags
- [ ] All navigation links (back, home, my reservations) work correctly and consistently across all pages
- [ ] Typography is consistent — one font family, clear hierarchy (h1 → h2 → body → caption)
- [ ] Colour palette is consistent — one primary accent colour used for CTAs, active states, and links throughout
