# restaurant-booking — Navigation Guide

This directory is the Forge home for all product management artifacts for **restaurant-booking**.
Read this file before looking for or placing any artifact related to this product.

---

## Root-Level Files

| File | Purpose | Produced by | Lifecycle stage |
|------|---------|-------------|----------------|
| `AGENTS.md` | This file — directory navigation guide | `forge:product` | initialization |
| `vision.md` | Stable product identity: target users, key needs, unique value proposition, business goals | `forge:product-vision` | strategy |
| `strategy.md` | Rumelt diagnosis + Roger Martin guiding policy (pillars + exclusions) + coherent actions table | `forge:product-strategy` | strategy |
| `okrs.md` | Product-level OKRs cascaded from company OKRs; cross-referenced in `strategy.md` | `forge:product-strategy` | strategy |
| `roadmap.md` | Outcome-based now/next/later or quarterly roadmap; each row maps to a coherent action and OKR | `forge:product-strategy` | strategy |
| `deployables.md` | Registry of the deployable units (services, apps, libraries) that collectively implement this product, with cross-repo references | `forge:product` (stub), maintained by team | ongoing |

---

## Subdirectories

---

## deployables.md

`deployables.md` is the registry of technical deployable units (services, apps, libraries)
that collectively implement this product. A PM product is a cross-cutting concern — it spans
multiple deployables, which may live in different repositories. This file is the single place
to find them all (ADR-029).

**Format:**

```markdown
# Deployables — restaurant-booking

| Deployable | Repository | Role | Capability path | Notes |
|------------|------------|------|-----------------|-------|
| rewards-api | github.com/org/rewards-api | primary backend | .forge/deployables/rewards-api/capabilities/... | |
| mobile-app  | github.com/org/mobile      | iOS/Android client | .forge/deployables/mobile-app/capabilities/... | |
| web-app     | (this repo)                | web frontend | .forge/deployables/web-app/capabilities/...    | |
```

**Fields:**
- **Deployable** — the canonical deployable name used in `.forge/deployables/<name>/`
- **Repository** — GitHub/VCS URL; use `(this repo)` for deployables in the current repository
- **Role** — what this deployable contributes to the product (primary backend, client, data pipeline, etc.)
- **Capability path** — path to the relevant capability directory within that deployable's
  `.forge/deployables/<name>/capabilities/` tree (link for same-repo; prose reference for cross-repo)
- **Notes** — any relevant constraints, ownership notes, or deprecation status

`forge:product` writes a stub `deployables.md` at creation time. The team maintains it as
deployables are added or removed from the product's implementation footprint.

---

### `research/`

Discovery artifacts that feed the strategy diagnosis. Written before or during `forge:product-strategy`.
If this directory does not exist yet, run `forge:product-discover` to populate it.

| File | Purpose | Produced by |
|------|---------|-------------|
| `customer-research.md` | Interview synthesis: key themes, opportunity spaces, customer quotes | `forge:product-discover` |
| `opportunity-tree.md` | Teresa Torres Opportunity Solution Tree: desired outcome → opportunity branches → solution experiments | `forge:product-discover` |
| `competitive-analysis.md` | Competitor positioning, pricing, feature gaps, market share signals | `forge:product-discover` |

### `briefs/`

One PM brief per coherent action from `strategy.md`. A brief is the PM-owned handoff
artifact that links a strategic initiative to a Forge effort (`forge:effort`). Lighter
than a PRD; heavier than a roadmap bullet.

File naming: `<initiative-slug>.md`

| Section | Contents |
|---------|---------|
| Problem | The specific customer or business problem this initiative addresses |
| Proposed solution | The approach at PM level (not engineering spec) |
| Success metrics | Measurable outcomes that define done |
| Constraints | Known time, scope, or technical constraints |
| Effort link | The `forge:effort` ID for this initiative (back-filled after effort creation) |

Produced by: `forge:product-brief`

### `gtm/`

Go-to-market plans for initiatives approaching release. Written after planning is
approved and before delivery begins.

File naming: `<initiative-slug>.md`

| Section | Contents |
|---------|---------|
| Target audience | Which customer segment(s) this release targets |
| Messaging | Key benefit statements and positioning |
| Channel strategy | How the release reaches the audience (in-app, email, sales, etc.) |
| Rollout plan | Phased or full rollout, feature flags, early access |
| Success criteria | Metrics that confirm the launch succeeded |

Produced by: `forge:product-gtm` *(planned)*

### `reviews/`

Post-launch reviews written after an initiative ships. Feed back into the next
`forge:product-strategy` refresh cycle.

File naming: `<initiative-slug>.md`

| Section | Contents |
|---------|---------|
| Metric actuals vs. projections | How outcomes compared to the success metrics in the brief |
| What worked | Decisions and approaches worth repeating |
| What did not work | Surprises, failures, false assumptions |
| Next bets | Follow-on opportunities surfaced by this launch |

Produced by: `forge:product-review` *(planned)*

### `experiments/`

Experiment logs for any hypothesis-driven work — A/B tests, feature flags evaluated
for impact, pricing experiments, onboarding variants.

File naming: `<experiment-slug>.md`

| Section | Contents |
|---------|---------|
| Hypothesis | The belief being tested and the expected outcome |
| Design | How the experiment is structured (variants, sample, duration) |
| Results | Observed outcomes with statistical confidence where applicable |
| Decision | What was decided based on the results and why |

Produced by: `forge:product-experiment` *(planned)*

### `references/`

Raw research inputs gathered during strategy sessions: market research, competitor
analysis sheets, data warehouse query results, PM-supplied documents (roadmaps, board
decks, Confluence exports). Written by `forge:product-strategy` during session execution.

Files use date-stamped names: `competitor-analysis-YYYY-MM-DD.md`,
`market-research-YYYY-MM-DD.md`, `data-analysis-<metric>-YYYY-MM-DD.md`.

Do not write output artifacts here — `references/` is inputs only.

### `strategy-archive/`

Archived versions of `strategy.md`, `okrs.md`, and `roadmap.md` from pivot mode.
Written automatically by `forge:product-strategy` when a pivot is initiated.

File naming: `strategy-YYYY-MM-DD.md`, `okrs-YYYY-MM-DD.md`, `roadmap-YYYY-MM-DD.md`.
If multiple pivots occur on the same date, a counter suffix is appended: `strategy-YYYY-MM-DD-2.md`.

Do not write to this directory manually — it is managed exclusively by `forge:product-strategy`.

---

## Lifecycle Order

For a new product, artifacts are typically created in this order:

```
1. forge:product            → AGENTS.md
2. forge:product-discover   → research/customer-research.md
                              research/opportunity-tree.md
                              research/competitive-analysis.md
3. forge:product-strategy   → strategy.md, okrs.md, roadmap.md, references/
4. forge:product-brief      → briefs/<initiative>.md (one per coherent action)
5. forge:effort             → effort created, linked from brief
6. forge:product-gtm        → gtm/<initiative>.md (before launch)
7. forge:product-review     → reviews/<initiative>.md (after launch)
```

Research and strategy may run in either order; discovery context enriches the strategy
diagnosis, but `forge:product-strategy` can run without it.
