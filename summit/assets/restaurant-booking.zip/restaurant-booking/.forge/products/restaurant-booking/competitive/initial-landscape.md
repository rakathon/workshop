---
product: restaurant-booking
brief: Initial landscape
date: 2026-06-04
competitors: [OpenTable]
strategic_implication: true
---

# Competitive Brief — Initial Landscape

*Product: restaurant-booking | Date: 2026-06-04*

---

## Executive Summary

The US restaurant reservation market is dominated by OpenTable (owned by Booking Holdings), a two-sided marketplace with 65,000+ restaurant partners and 1.9 billion diners seated annually. OpenTable's core value proposition to restaurants is demand generation via its diner network, not just booking software — a fundamentally different offering from a curated 25–30 restaurant booking app. The main competitive pressure is not feature parity with OpenTable but rather the contrast in user experience: OpenTable is a large, fee-heavy, account-centric platform, while our product's opportunity lies in being the clean, friction-free, curated alternative for US diners who find the incumbents overwhelming. The single most important strategic finding is that lightweight curated booking — fast, mobile-first, no loyalty lock-in — is an underserved positioning territory that OpenTable structurally cannot occupy without cannibalising its own restaurant-operator revenue model.

---

## Feature Matrix

| Feature / Capability | restaurant-booking | OpenTable |
|---|:---:|:---:|
| **Core Booking** | | |
| Online table reservation | ✓ | ✓ |
| Real-time availability | ~ | ✓ |
| Time-slot selection | ✓ | ✓ |
| Party size selection | ✓ | ✓ |
| Special requests / booking notes | ? | ✓ |
| Group reservations (6+ covers) | ✗ | ~ |
| Reservation modification / cancellation | ? | ✓ |
| **Discovery** | | |
| Restaurant search & filter by cuisine | ✓ | ✓ |
| Location-based search | ~ | ✓ |
| Menu access in-app | ✗ | ✓ |
| Diner reviews & ratings | ✗ | ✓ |
| Curated restaurant selection | ✓ | ✗ |
| **Mobile & Notifications** | | |
| Mobile-optimised booking flow | ? | ✓ |
| Calendar / reminder integration | ✗ | ✓ |
| SMS / email confirmation | ? | ✓ |
| **Diner Account** | | |
| User accounts & reservation history | ? | ✓ |
| Loyalty / rewards programme | ✗ | ✓ |
| Personalised recommendations | ✗ | ✓ |
| **Restaurant Operator Tools** | | |
| Restaurant management dashboard | ✗ | ✓ |
| Guest CRM / guest notes | ✗ | ✓ |
| Table management / floor plan | ✗ | ✓ |
| POS / tech-stack integration | ✗ | ✓ |
| Analytics & reporting | ✗ | ✓ |
| Offline operation mode | ✗ | ✓ |
| **Commercial** | | |
| Free for diners | ✓ | ✓ |
| Network-driven demand generation | ✗ | ✓ |
| No per-cover fees for restaurants | ✓ | ✗ |

*Key: ✓ supported · ~ partial/limited · ✗ absent · ? not yet defined*

### Where we lead
- **Curated selection** — 25–30 hand-picked restaurants vs. OpenTable's undifferentiated 65,000+; curation is itself a positioning advantage with diners experiencing choice overload.
- **No cost to restaurants** — mock/JSON backend means zero per-cover or monthly fees; removes the #1 complaint restaurant operators have about OpenTable.
- **Simplicity** — no account required, no loyalty programme complexity, no management dashboard noise. The entire surface area is booking.

### Where we lag
- **Restaurant operator tooling** — no management dashboard, table management, guest CRM, POS integration, or analytics. OpenTable is a full operating system for restaurants.
- **Diner network scale** — OpenTable's 1.9B-diner network drives organic demand to restaurants; we have zero network effect at launch.
- **Discovery depth** — no reviews, ratings, menus, or personalization. Diners can't research before booking.
- **Mobile app** — OpenTable has native iOS/Android apps with offline support; our mobile story is not yet defined.
- **Notifications** — no calendar integration, SMS, or email reminder system defined yet.

---

## Positioning Analysis

### Competitive positioning summaries

**restaurant-booking (our product)**
A focused, no-frills table booking app for US diners, covering 25–30 restaurants across multiple cuisines. The target user is someone who wants to book a table quickly without navigating a marketplace platform. The competitive claim is simplicity and curation — a small, trusted list rather than an overwhelming directory. Tone should be warm, direct, and local-feeling — the opposite of enterprise software.

**OpenTable**
OpenTable positions itself as the operating system for the restaurant industry — simultaneously a consumer discovery platform and a B2B restaurant management product. It emphasises scale ("65,000+ restaurants", "1.9 billion diners"), revenue maximisation for operators ("the power to book 2,000 reservations in 50 seconds"), and platform reliability. It targets mid-to-large restaurant groups and hospitality enterprises as much as individual restaurants. Brand tone is authoritative and professional. For diners, it emphasises the rewards programme, real-time availability, and the breadth of choice.

### Positioning map

OpenTable occupies the "scale + management + demand generation" quadrant — it is the enterprise-grade, everything-platform for restaurant reservations. This positioning is crowded on the operator side (SevenRooms, Tock, Resy all compete here) but largely uncontested on its own terms because of network-effect moat.

The underserved territory is **lightweight, curated, diner-first booking** — no management overhead, no per-cover fees, a small trusted restaurant list, and a booking flow that takes under 60 seconds. This is where our product has a structurally defensible position. OpenTable cannot move here without undermining its restaurant-operator subscription business.

There is no meaningful messaging inconsistency risk at this stage — our product is pre-launch and undiscovered. The risk runs the other way: if we mimic OpenTable's language ("discover thousands of restaurants", "maximize covers"), we will be perceived as an inferior imitation rather than a distinct alternative.

---

## Win / Loss Signals

### Where we win

| Customer type / use case | Reason | Confidence |
|---|---|---|
| Diner who wants a quick, low-friction booking | Simpler UX, no account required, curated list removes decision fatigue | Medium |
| Diner in a market where our 25–30 restaurants are well-chosen | Curation beats breadth when the list quality is high | Medium |
| Restaurant not wanting to pay $149–$499/mo + per-cover fees | Zero cost model removes OpenTable's primary operator pain point | High |
| Developer / demo context | Mock JSON data makes the app easy to run and extend without backend complexity | High |

### Where we lose

| Competitor | Customer type / use case | Reason | Confidence |
|---|---|---|
| OpenTable | Diner wanting to browse 100s of restaurants | We cover 25–30 only — insufficient breadth for open-ended discovery | High |
| OpenTable | Diner who values loyalty/rewards | We have no rewards programme | High |
| OpenTable | Restaurant operator needing management tools | We provide no dashboard, CRM, analytics, or POS integration | High |
| OpenTable | Diner wanting reviews and menus before booking | We have no review or menu content | High |
| OpenTable | Group booking of 7+ | We have no group booking feature | Medium |

### Where data is thin

- Head-to-head user preference for a curated 25-restaurant app vs. OpenTable's full directory — no public data; this is a product hypothesis requiring user testing.
- Diner willingness to book without reading reviews first — assumption baked into our design that needs validation.
- *Recommended: conduct 5–10 diner interviews asking "when do you use OpenTable vs. other methods to find a restaurant?" to validate the curation hypothesis.*

---

## Market Trends

### 1. Fee backlash is driving restaurant disintermediation

**What is happening:** Restaurant operators increasingly resent OpenTable's per-cover fees on top of monthly subscriptions ($149–$499/mo). G2 and GetApp reviews consistently flag pricing as the platform's biggest weakness. Post-COVID, margin-squeezed restaurants are looking for lower-cost or direct booking alternatives.

**Who is moving on it:** SevenRooms and Tock both market explicitly against OpenTable's fee model. Direct-booking tools (via Google Reserve, Instagram links) are growing.

**Implication for us:** Our zero-cost-to-restaurant model is a genuine differentiator. The narrative "book directly, no cover fees passed to your table" resonates with restaurant operators and cost-conscious diners alike.

**Time horizon:** Near-term (0–12 months)

---

### 2. AI-powered personalization is becoming table stakes

**What is happening:** OpenTable is actively adding AI features (confirmed in G2 enterprise reviews, May 2025). Competitors are integrating AI for personalized recommendations, dynamic availability, and demand prediction. Diners increasingly expect AI to surface the right restaurant at the right time without manual search.

**Who is moving on it:** OpenTable (in-progress), Resy (Amex-backed, strong personalization), Google (AI-powered restaurant suggestions in Search and Maps).

**Implication for us:** Our current scope (mock JSON data) has no AI layer. This is not a blocker for an MVP but becomes a gap at scale. The "AI restaurant assistant" framing (conversational booking) is an option to explore in v2.

**Time horizon:** Near-term (0–12 months)

---

### 3. Mobile-first, zero-friction booking is the new expectation

**What is happening:** Diner behaviour has shifted decisively to mobile. OpenTable reports the majority of reservations come from mobile. Calendar integration, instant SMS confirmations, and one-tap rebooking are now expected, not premium. Apps that require account creation before booking see significant drop-off.

**Who is moving on it:** OpenTable (full iOS/Android, calendar sync), Google Reserve (in-search booking with no app required), Resy (mobile-first by design).

**Implication for us:** Our mobile story needs to be defined early. If we launch web-only without SMS confirmations, we will feel dated relative to incumbents. The no-account-required approach (if pursued) directly addresses mobile drop-off.

**Time horizon:** Near-term (0–12 months)

---

### 4. Platform consolidation is squeezing independent booking apps

**What is happening:** Google Reserve embeds restaurant booking directly into Google Search and Maps results, bypassing standalone apps entirely. As Google surfaces real-time OpenTable/Resy availability inline, the incentive to install a separate booking app decreases for diners.

**Who is moving on it:** Google (Google Reserve, integrated with OpenTable and Resy feeds), Apple Maps (restaurant reservations via Yelp).

**Implication for us:** Distribution via Google/Apple is unavailable to a small independent app without API partnerships. We need a direct-to-diner acquisition channel (QR codes at restaurants, referral from restaurant websites) that doesn't depend on organic search.

**Time horizon:** Medium-term (1–3 years)

---

### 5. Hyper-local curation is an emerging counter-trend

**What is happening:** As large platforms grow to 65,000+ restaurants, decision fatigue among diners is real. Niche, editorially-curated restaurant guides (Eater, Infatuation, Resy's editorial features) attract high engagement. Diners in specific cities or cuisines increasingly trust curated lists over algorithm-ranked results.

**Who is moving on it:** Resy (editorial/cultural positioning, "restaurants worth going to"), The Infatuation (acquired by Zagat/Google), local newsletter-based guides.

**Implication for us:** Curation is a real positioning moat if executed with taste and local knowledge. 25–30 restaurants, if genuinely well-chosen across cuisines, can be a stronger trust signal than a marketplace with tens of thousands. This is a tailwind for our current scope.

**Time horizon:** Structural

---

## Research notes

*Sources consulted:*
- OpenTable restaurant solutions page: https://www.opentable.com/restaurant-solutions/
- OpenTable Wikipedia entry (scale, history, business model)
- G2 OpenTable for Restaurants reviews and pricing: https://www.g2.com/products/opentable-for-restaurants/
- GetApp OpenTable listing (1,320 verified reviews): https://www.getapp.com/all-software/a/opentable-for-restaurants/
- G2 alternatives listing: https://www.g2.com/products/opentable-for-restaurants/competitors/alternatives

*Data gaps:*
- OpenTable's exact per-cover fee (publicly unpublished; commonly cited as $1–2/cover but not confirmed from current pricing pages)
- Per-tier feature breakdown for Basic vs Core vs Pro ($149/$299/$499) — OpenTable's pricing page returned 404
- Internal win/loss data — product is pre-launch, no first-party signals available

*Last updated:* 2026-06-04
