# Product Roadmap: restaurant-booking

*Format: Now / Next / Later*
*Linked from: [strategy.md](strategy.md)*

---

## Now

*Foundation: the data, logic, and core flows that make the product work.*

| Initiative | Success Metric |
|------------|----------------|
| Validate + structure restaurant data set (25–30 restaurants, JSON) | 25–30 complete restaurant records; no placeholder data |
| Define reservation slot model and availability logic | No double-bookings; availability reflects existing reservations |
| Build core booking flow (browse → detail → slot → confirm) | End-to-end booking in <2 min, zero errors |
| Build cuisine filter + search | <500ms filter response; empty state handled gracefully |
| Build "my reservations" view (lookup by email, no login) | Bookings retrievable by email without login |

---

## Next

*Polish: mobile experience and data completeness.*

| Initiative | Success Metric |
|------------|----------------|
| Responsive UI + mobile optimisation | Fully usable on mobile viewport without layout issues |
| Expand to full 30 restaurants across all cuisine categories | ≥2 restaurants per cuisine category; no category empty |

---

## Later

*Post-validation: initiatives unlocked after the core booking loop is proven with real users.*

| Initiative | Success Metric |
|------------|----------------|
| Real backend integration (replace JSON mock with database) | Reservation data persists across sessions; concurrent bookings handled correctly |
| AI-assisted booking (conversational slot selection) | Users can describe a booking need in natural language and receive a slot suggestion |
| Native mobile apps (iOS / Android) | App Store / Play Store presence; booking parity with web |
