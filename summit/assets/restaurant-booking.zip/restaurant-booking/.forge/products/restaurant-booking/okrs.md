# Product OKRs: restaurant-booking

*Quarter: Q3 2026*
*Cascaded from: No company OKRs provided — product-level OKRs derived directly from strategy diagnosis and pillars.*
*Linked from: [strategy.md](strategy.md)*

⚠️ *OKR alignment risk: establish company OKRs and cascade these down from them before this drives engineering investment.*

---

## Objective 1: Deliver a working, zero-friction booking experience

*Addresses: Zero-friction booking pillar + Reliable mock-data operations pillar*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| End-to-end booking completion rate (browse → confirm) in user testing | 0% (pre-launch) | ≥70% | ≥85% |
| Booking flow step count (intent to confirmation) | N/A | ≤5 steps | ≤3 steps |
| Critical booking bugs in demo/user testing scenarios | N/A | 0 | 0 |

---

## Objective 2: Launch a complete, high-quality curated restaurant set

*Addresses: Curation over breadth pillar*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Restaurants with fully complete records (name, cuisine, location, hours, menu, photos, slots) | 0 | 25 | 30 |
| Cuisine categories with ≥2 restaurants represented | 0 | 5 | 7 |
| Placeholder or empty fields in restaurant JSON | N/A | 0 | 0 |

---

## Objective 3: Enable diners to make informed restaurant choices in-app

*Addresses: Rich restaurant context pillar*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Restaurant detail page → availability check conversion in user testing | 0% (pre-launch) | ≥60% | ≥75% |
| Restaurants with menu data present | 0 | 100% of data set | 100% |
| Restaurants with photo assets present | 0 | 100% of data set | 100% |
