# Product Strategy: restaurant-booking

*Created: 2026-06-04*
*Mode: create*

---

## Diagnosis

<!-- Rumelt: one specific, evidence-backed problem statement. Not a goal. Not a list. -->
<!-- DIBB framing: Data → Observations → Beliefs → Bet -->

**Data:** OpenTable charges restaurants $149–$499/mo plus per-cover fees; across 1,320+ verified reviews, pricing and value-for-money are the platform's most-cited weakness. All credible US alternatives (SevenRooms, Resy, Yelp Guest Manager) are full restaurant-management platforms targeting operators, not diners seeking fast, low-friction booking.

**Observations:** The dominant platforms are two-sided marketplaces optimised for restaurant operator tooling and breadth of inventory. The "discover new restaurants" use case is served. The "I know what I want, just book it" use case is not — every current option requires account creation and marketplace navigation before a table can be confirmed.

**Beliefs:** The root cause of this gap is that marketplace economics force incumbents to serve restaurants (who pay fees) as their primary customer, not diners. A product that inverts this — putting the diner's speed and simplicity first, with zero restaurant operator overhead — cannot be built inside the existing platforms without destroying their revenue model.

**Bet:** The structural opening is the underserved "decisive diner" segment: US diners who know their cuisine preference and want a confirmed table in under two minutes, without an account or a marketplace experience. No current product serves this intent without overhead. The primary barrier to capturing it is not technology — it is the assumption that any new entrant must compete on breadth.

*Evidence:* [competitive/initial-landscape.md](competitive/initial-landscape.md)

⚠️ *OKR alignment risk: no company OKRs were provided. This strategy is not currently traceable to company-level goals. Establish company OKRs and back-link before this strategy drives significant engineering investment.*

---

## Guiding Policy

<!-- Roger Martin: where to play and how to win -->

### Strategic Pillars

| # | Pillar | Where We Play | How We Win | Success Indicator |
|---|--------|---------------|-----------|-------------------|
| 1 | Curation over breadth | The "I know what I want" US diner segment | 25–30 hand-picked restaurants across cuisines — quality of selection is the product | >80% of users complete a booking without using search/filter more than once |
| 2 | Zero-friction booking flow | The moment between dining intent and confirmed table | Name + email only, no account, no loyalty programme, booking in under 2 minutes | Booking completion rate >70% from restaurant detail page to confirmation |
| 3 | Rich restaurant context | The pre-booking "is this the right place?" decision | Menus, photos, cuisine, location, hours, and capacity presented clearly in-app | >60% of users who view a restaurant detail page proceed to check availability |
| 4 | Reliable mock-data operations | The MVP technical foundation | Availability checks, reservation creation, and confirmation work correctly on JSON mock data with no broken states | Zero critical booking bugs in demo/user testing; availability correctly reflects existing reservations |

### Strategic Exclusions

| Exclusion | Rationale |
|-----------|-----------|
| Restaurant operator tools (dashboard, CRM, analytics) | Serving operators is a different product and business model; dilutes the diner-first focus |
| User accounts and login | Contradicts the zero-friction premise; name+email at booking is the ceiling |
| Open marketplace / 100+ restaurants | Scale destroys curation value; breadth is OpenTable's territory |
| Crowdsourced reviews and ratings | Community moderation is a platform business; adds complexity with no MVP value |
| Native mobile apps (iOS/Android) for MVP | Responsive web is sufficient for MVP; native apps are a post-validation investment |

---

## Coherent Actions

| Initiative | Strategic Pillar | Horizon | Success Metric | Effort ID |
|------------|-----------------|---------|----------------|-----------|
| Validate + structure restaurant data set (25–30 restaurants, JSON) | Curation over breadth | Now | 25–30 complete restaurant records; no placeholder data | <!-- back-filled by forge:effort --> |
| Define reservation slot model and availability logic | Reliable mock-data operations | Now | No double-bookings; availability reflects existing reservations | <!-- back-filled by forge:effort --> |
| Build core booking flow (browse → detail → slot → confirm) | Zero-friction booking + Rich restaurant context | Now | End-to-end booking in <2 min, zero errors | <!-- back-filled by forge:effort --> |
| Build cuisine filter + search | Curation over breadth | Now | <500ms filter response; empty state handled gracefully | <!-- back-filled by forge:effort --> |
| Build "my reservations" view (lookup by email, no login) | Zero-friction booking | Now | Bookings retrievable by email | <!-- back-filled by forge:effort --> |
| Responsive UI + mobile optimisation | Zero-friction booking | Next | Fully usable on mobile viewport without layout issues | <!-- back-filled by forge:effort --> |
| Expand to full 30 restaurants across all cuisine categories | Curation over breadth | Next | ≥2 restaurants per cuisine category; no category empty | <!-- back-filled by forge:effort --> |

---

## OKRs

*See [okrs.md](okrs.md) for full product-level OKRs.*

---

## Roadmap

*See [roadmap.md](roadmap.md) for the outcome-based roadmap.*
