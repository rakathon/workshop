# Vision — restaurant-booking

*Stable product identity. Update only when the fundamental nature of the product
changes — not when strategy, roadmap, or scope evolves.*

*Time horizon: 3 years (2026–2029)*

---

## Vision Statement

Any US diner can browse a curated shortlist of quality restaurants, explore menus,
and confirm a table booking in minutes — no account, no login, no friction.

---

## Target Beneficiaries

US diners who eat out regularly and want to reserve a table at a quality local
restaurant quickly. The primary user already has a general preference in mind — a
cuisine type, an occasion, a neighbourhood — and needs a fast, low-friction path
from "I want to go out" to "table confirmed." They are not looking to discover an
unknown restaurant from a list of thousands; they want to browse a trusted shortlist,
see the menu and photos, and book without creating an account.

---

## The Transformation

**Before:** Booking a table means opening OpenTable or a similar platform, creating
an account, scrolling through thousands of undifferentiated listings, and decoding
loyalty points — all before confirming a simple dinner reservation. The booking
experience is buried inside a marketplace designed to maximise platform engagement,
not minimise the diner's time.

**After:** A diner opens the app, filters by cuisine, browses a curated set of
25–30 restaurants (with menus, photos, and details), selects an available time slot,
provides only their name and email to complete the booking, and receives a
confirmation — in minutes, with no account or login required. The product does one
thing well: turn a dining intention into a confirmed table.

---

## What This Is Not

- **Not a restaurant management platform** — no operator dashboard, table management,
  guest CRM, or POS integration; the product serves diners, not restaurant operators
- **Not a nationwide open marketplace** — the curated 25–30 restaurant scope is
  intentional; breadth is not the goal and scale is not an MVP success metric
- **Not an account-based platform** — no user registration, no login, no stored
  profiles; a name and email at booking time is the full identity requirement
- **Not a crowdsourced review platform** — no user-generated reviews, ratings, or
  social features; editorial curation replaces community moderation

---

## Durability Note

This vision would need to be reconsidered if:
1. User research demonstrates that diners consistently require open-ended discovery
   (hundreds of restaurants, user reviews) before booking — meaning the curated
   model is a barrier, not a benefit
2. The restaurant set grows to a scale where curation loses meaning and the product
   functionally becomes a marketplace
3. Conversational AI booking (e.g. "book me dinner for two on Saturday near downtown")
   becomes the dominant interaction model, making slot-browsing obsolete

Expected stable horizon: 3 years (2026–2029).

---

## Change History

| Date | What changed | Why |
|------|-------------|-----|
| 2026-06-04 | Initial vision | Solo-authored by PM. Derived from MVP scope definition and competitive analysis. Stakeholder alignment recommended before strategy decisions are made. |
