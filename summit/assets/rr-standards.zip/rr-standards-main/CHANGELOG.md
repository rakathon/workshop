## [0.30.1](https://github.com/rewards-guilds/rr-standards/compare/v0.30.0...v0.30.1) (2026-05-29)

### Bug Fixes

* **ci:** guard grep pipelines with || true under set -eo pipefail ([#400](https://github.com/rewards-guilds/rr-standards/issues/400)) ([d2b2c95](https://github.com/rewards-guilds/rr-standards/commit/d2b2c95de95b603f19a707a438159c0c41d23748)), closes [#397](https://github.com/rewards-guilds/rr-standards/issues/397)

## [0.30.0](https://github.com/rewards-guilds/rr-standards/compare/v0.29.1...v0.30.0) (2026-05-29)

### Bug Fixes

* **skill-creator:** fix mode detection and review mode gate enforcement ([#392](https://github.com/rewards-guilds/rr-standards/issues/392)) ([92d1bb0](https://github.com/rewards-guilds/rr-standards/commit/92d1bb02dc2e423aca3487901db435a43e8073bc))
* **ci:** use annotated tags and curl for GitHub release creation ([#395](https://github.com/rewards-guilds/rr-standards/issues/395)) ([b47bb4a](https://github.com/rewards-guilds/rr-standards/commit/b47bb4ae88e47470f75ae0172eb3797715b2f0df)), closes [#forge-users](https://github.com/rewards-guilds/rr-standards/issues/forge-users)
* **ci:** use marketplace install instructions in secondary plugin Slack notifications ([#396](https://github.com/rewards-guilds/rr-standards/issues/396)) ([de3a148](https://github.com/rewards-guilds/rr-standards/commit/de3a148c15483cb9b391864c183b65e03f28cb81))
* **ci:** use printf to avoid unindented PROMPT lines breaking YAML parse ([#398](https://github.com/rewards-guilds/rr-standards/issues/398)) ([2c205a5](https://github.com/rewards-guilds/rr-standards/commit/2c205a58dbc5565b140d9ce9c83788f02e0a4b69))

### Features

* **ci:** generate release notes via backbone AI ([#397](https://github.com/rewards-guilds/rr-standards/issues/397)) ([d4dfad2](https://github.com/rewards-guilds/rr-standards/commit/d4dfad2f5930ba0af500ce230d2de6839f11773b))

## [0.29.1](https://github.com/rewards-guilds/rr-standards/compare/v0.29.0...v0.29.1) (2026-05-29)

### Bug Fixes

* **ci:** store breaking-change regex in variable to fix bash syntax error ([#393](https://github.com/rewards-guilds/rr-standards/issues/393)) ([e8295e7](https://github.com/rewards-guilds/rr-standards/commit/e8295e75b5272b6d0abd0182f24e142f7fe763a9))

## [0.29.0](https://github.com/rewards-guilds/rr-standards/compare/v0.28.0...v0.29.0) (2026-05-29)

### Features

* **product-management:** forge-product-management plugin — full skill library ([#385](https://github.com/rewards-guilds/rr-standards/issues/385)) ([e3d7a50](https://github.com/rewards-guilds/rr-standards/commit/e3d7a50e4ef44e3189784f0b68a4bf28b9b7739c))

## [0.28.0](https://github.com/rewards-guilds/rr-standards/compare/v0.27.0...v0.28.0) (2026-05-29)

### Features

* **forge-plan:** PPE-1696 - Generate test tasks from spec-tests suite files ([#374](https://github.com/rewards-guilds/rr-standards/issues/374)) ([4f5604a](https://github.com/rewards-guilds/rr-standards/commit/4f5604ad76069b3706dd9974abad5ce6a554432b)), closes [#325](https://github.com/rewards-guilds/rr-standards/issues/325) [#325](https://github.com/rewards-guilds/rr-standards/issues/325)

## [0.27.0](https://github.com/rewards-guilds/rr-standards/compare/v0.26.1...v0.27.0) (2026-05-29)

### Features

* rr-standards review v3 ([#389](https://github.com/rewards-guilds/rr-standards/issues/389)) ([2773ead](https://github.com/rewards-guilds/rr-standards/commit/2773ead427b1f77a6dd17acf838b3be951d144d0))
* rr-standards review v3 ([#390](https://github.com/rewards-guilds/rr-standards/issues/390)) ([e3c0b2c](https://github.com/rewards-guilds/rr-standards/commit/e3c0b2cf6a55fc2d4f00936cab9bb113c02207e3))
* rr-standards review v3 ([#391](https://github.com/rewards-guilds/rr-standards/issues/391)) ([d8c9ab8](https://github.com/rewards-guilds/rr-standards/commit/d8c9ab84245a480108205cb9ffc38461911ac3dc))

### Bug Fixes

* skill review detection and diff check changes to PR ([#387](https://github.com/rewards-guilds/rr-standards/issues/387)) ([f47f803](https://github.com/rewards-guilds/rr-standards/commit/f47f8032c13565b7db2a2cedba1cdbad0c0fbc09))

## [0.26.1](https://github.com/rewards-guilds/rr-standards/compare/v0.26.0...v0.26.1) (2026-05-28)

### Bug Fixes

* **forge:mobile-tests:** update test file paths for structured folder layout ([#353](https://github.com/rewards-guilds/rr-standards/issues/353)) ([2e653b8](https://github.com/rewards-guilds/rr-standards/commit/2e653b815426befe8cf0964fb490fe7cc98f8232))

## [0.26.0](https://github.com/rewards-guilds/rr-standards/compare/v0.25.0...v0.26.0) (2026-05-28)

### Features

* **forge:** add forge-framework product strategy artifacts ([#375](https://github.com/rewards-guilds/rr-standards/issues/375)) ([e5cc12e](https://github.com/rewards-guilds/rr-standards/commit/e5cc12eb30fe874154cc7fe56ac2a2ba820c4dfb))

## [0.25.0](https://github.com/rewards-guilds/rr-standards/compare/v0.24.0...v0.25.0) (2026-05-27)

### Features

* **PPE-1614:** add HTTP request/response logging to E2E test guides (all 4 languages) ([#332](https://github.com/rewards-guilds/rr-standards/issues/332)) ([f1e3668](https://github.com/rewards-guilds/rr-standards/commit/f1e3668331af57bc9ccd3512ce4c27bba5583dea))

## [0.24.0](https://github.com/rewards-guilds/rr-standards/compare/v0.23.0...v0.24.0) (2026-05-27)

### Features

* **skill-creator:** add review mode for existing skills ([#373](https://github.com/rewards-guilds/rr-standards/issues/373)) ([bae0d18](https://github.com/rewards-guilds/rr-standards/commit/bae0d185f4560055ab5b2dd555cf5c3cf6f1b560))

## [0.23.0](https://github.com/rewards-guilds/rr-standards/compare/v0.22.1...v0.23.0) (2026-05-27)

### Features

* **forge:** add forge:product skill and forge-product capability ([#372](https://github.com/rewards-guilds/rr-standards/issues/372)) ([90ae9e9](https://github.com/rewards-guilds/rr-standards/commit/90ae9e9a5d51a61f58784b919cfc928f08477e26))

## [0.22.1](https://github.com/rewards-guilds/rr-standards/compare/v0.22.0...v0.22.1) (2026-05-27)

## [0.22.0](https://github.com/rewards-guilds/rr-standards/compare/v0.21.0...v0.22.0) (2026-05-27)

### Features

* **forge:** add argument-hint and arguments frontmatter to skills ([#346](https://github.com/rewards-guilds/rr-standards/issues/346)) ([9aa5441](https://github.com/rewards-guilds/rr-standards/commit/9aa54417737eefdc61ce6b8c8388423f517eba99))

## [0.21.0](https://github.com/rewards-guilds/rr-standards/compare/v0.20.0...v0.21.0) (2026-05-27)

### Features

* **product-strategy:** implement forge:product-strategy skill ([#367](https://github.com/rewards-guilds/rr-standards/issues/367)) ([563613e](https://github.com/rewards-guilds/rr-standards/commit/563613e8b383dc259c73cfde429253acbe6033c7))

### Bug Fixes

* Semantic Release Slack step by replacing inline bash regex with pattern variables ([#366](https://github.com/rewards-guilds/rr-standards/issues/366)) ([14ffa5d](https://github.com/rewards-guilds/rr-standards/commit/14ffa5d37f92d48ee3d63e3adc62a7ad73e99d59))

## [0.20.0](https://github.com/rewards-guilds/rr-standards/compare/v0.19.3...v0.20.0) (2026-05-26)

### Features

* dynamic plugin release, easy to add and remove from release gen… ([#354](https://github.com/rewards-guilds/rr-standards/issues/354)) ([ba43b7d](https://github.com/rewards-guilds/rr-standards/commit/ba43b7d99dba34ac6cac8c64ad862c0b07cc00d6))
* improve rr-standard review skill ([#362](https://github.com/rewards-guilds/rr-standards/issues/362)) ([e47a17d](https://github.com/rewards-guilds/rr-standards/commit/e47a17d4e731156e16d738b28aea14093d47f875))

## [0.19.3](https://github.com/rewards-guilds/rr-standards/compare/v0.19.2...v0.19.3) (2026-05-26)

## [0.19.2](https://github.com/rewards-guilds/rr-standards/compare/v0.19.1...v0.19.2) (2026-05-26)

### Bug Fixes

* **forge:** pick highest cached plugin version in claude-md snippet ([#357](https://github.com/rewards-guilds/rr-standards/issues/357)) ([a130ea4](https://github.com/rewards-guilds/rr-standards/commit/a130ea42b6a439dc22a35ed4ac7aef1bfe90df8b))

## [0.19.1](https://github.com/rewards-guilds/rr-standards/compare/v0.19.0...v0.19.1) (2026-05-20)

### Bug Fixes

* **forge-skill-creator:** enforce description length limits and trigger-word guidance ([#351](https://github.com/rewards-guilds/rr-standards/issues/351)) ([f4c6409](https://github.com/rewards-guilds/rr-standards/commit/f4c6409562cb08126dabbed06d2b64732a0d5346))

## [0.19.0](https://github.com/rewards-guilds/rr-standards/compare/v0.18.0...v0.19.0) (2026-05-20)

### Features

* **forge-skill-creator:** teach skill-creator to author and validate argument-hint/arguments frontmatter ([#347](https://github.com/rewards-guilds/rr-standards/issues/347)) ([10cbc03](https://github.com/rewards-guilds/rr-standards/commit/10cbc0357e1f6b4c7f93667d70f00115c8c8ef16))

## [0.18.0](https://github.com/rewards-guilds/rr-standards/compare/v0.17.0...v0.18.0) (2026-05-19)

### Features

* **data-discover:** add forge:data-discover lineage skill ([#348](https://github.com/rewards-guilds/rr-standards/issues/348)) ([628efac](https://github.com/rewards-guilds/rr-standards/commit/628efac4bec4fe6dc23f307443029b3b2e2580d4))

## [0.17.0](https://github.com/rewards-guilds/rr-standards/compare/v0.16.0...v0.17.0) (2026-05-19)

### Features

* **forge-plugin:** Transcript Pipeline Simplification ([#339](https://github.com/rewards-guilds/rr-standards/issues/339)) ([4a2b014](https://github.com/rewards-guilds/rr-standards/commit/4a2b014004c9618a16531eccf16fcc1b79747843))

### Bug Fixes

* **release-slack-notify:** msg handling ([#342](https://github.com/rewards-guilds/rr-standards/issues/342)) ([8d02162](https://github.com/rewards-guilds/rr-standards/commit/8d02162a4b1a6c753fdf63facf1da1ac2b168bf2))

## [0.16.0](https://github.com/rewards-guilds/rr-standards/compare/v0.15.0...v0.16.0) (2026-05-19)

### Features

* add slack file upload skill ([d7f6a4b](https://github.com/rewards-guilds/rr-standards/commit/d7f6a4bbfa2c7bf05ab71ebd9f0f1b7f142b593d))

## [0.15.0](https://github.com/rewards-guilds/rr-standards/compare/v0.14.5...v0.15.0) (2026-05-19)

### Features

* **forge:** add forge:about-me skill ([#343](https://github.com/rewards-guilds/rr-standards/issues/343)) ([6fe9ab7](https://github.com/rewards-guilds/rr-standards/commit/6fe9ab74f3be6a10680477ec662809b6ce090da2))

## [0.14.5](https://github.com/rewards-guilds/rr-standards/compare/v0.14.4...v0.14.5) (2026-05-16)

### Bug Fixes

* **forge-skill-creator:** split overloaded description into when_to_use and add effort/argument-hint fields ([#340](https://github.com/rewards-guilds/rr-standards/issues/340)) ([82beef3](https://github.com/rewards-guilds/rr-standards/commit/82beef356c134305a68c73b87c5a9e0028eee033))

### Features

* rr standards pr review v2 ([#324](https://github.com/rewards-guilds/rr-standards/issues/324)) ([9053e59](https://github.com/rewards-guilds/rr-standards/commit/9053e59bc753b2129eb24f23d5d5ce7bc21eab97)), closes [/#diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL22-R32](https://github.com/rewards-guilds///issues/diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL22-R32) [/#diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edR159-R195](https://github.com/rewards-guilds///issues/diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edR159-R195) [/#diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edR222-R230](https://github.com/rewards-guilds///issues/diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edR222-R230) [/#diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL348-R402](https://github.com/rewards-guilds///issues/diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL348-R402) [/#diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL296-R348](https://github.com/rewards-guilds///issues/diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL296-R348) [/#diff-5149e8cc43552d250f03239d3fb2e4eee6c2acf1e41bdc3cdae2e57a981b5473L40-R43](https://github.com/rewards-guilds///issues/diff-5149e8cc43552d250f03239d3fb2e4eee6c2acf1e41bdc3cdae2e57a981b5473L40-R43) [/#diff-5149e8cc43552d250f03239d3fb2e4eee6c2acf1e41bdc3cdae2e57a981b5473L95-R100](https://github.com/rewards-guilds///issues/diff-5149e8cc43552d250f03239d3fb2e4eee6c2acf1e41bdc3cdae2e57a981b5473L95-R100) [/#diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL394-R488](https://github.com/rewards-guilds///issues/diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL394-R488) [/#diff-5149e8cc43552d250f03239d3fb2e4eee6c2acf1e41bdc3cdae2e57a981b5473L191-R201](https://github.com/rewards-guilds///issues/diff-5149e8cc43552d250f03239d3fb2e4eee6c2acf1e41bdc3cdae2e57a981b5473L191-R201) [/#diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL22-R32](https://github.com/rewards-guilds///issues/diff-d1eed94349e67a4a07bd1f38b7411ce03ebad4b382cf50a7aa1bad5c2e5327edL22-R32)

## [0.14.4](https://github.com/rewards-guilds/rr-standards/compare/v0.14.3...v0.14.4) (2026-05-15)

### Bug Fixes

* **forge-skill-creator:** detect inaccessible harness script before committing to CLI path ([#338](https://github.com/rewards-guilds/rr-standards/issues/338)) ([d7ca7ee](https://github.com/rewards-guilds/rr-standards/commit/d7ca7ee248c719121ce60dc7beb10efc933dd43e))

## [0.14.3](https://github.com/rewards-guilds/rr-standards/compare/v0.14.2...v0.14.3) (2026-05-15)

### Bug Fixes

* **forge-skill-creator:** require full interview and explicit confirmation before drafting ([#337](https://github.com/rewards-guilds/rr-standards/issues/337)) ([9de2bcc](https://github.com/rewards-guilds/rr-standards/commit/9de2bcc1f70b70775f960cffc4f806b140c43298))

## [0.14.2](https://github.com/rewards-guilds/rr-standards/compare/v0.14.1...v0.14.2) (2026-05-15)

### Bug Fixes

* **forge-skill-creator:** check frontmatter validity in improve mode before summarising ([#335](https://github.com/rewards-guilds/rr-standards/issues/335)) ([3236430](https://github.com/rewards-guilds/rr-standards/commit/32364301b3589c594a85258b171638d0954310bd))
* **forge-skill-creator:** close all frontmatter validation gaps across create, improve, optimize, and package paths ([#336](https://github.com/rewards-guilds/rr-standards/issues/336)) ([c135bdc](https://github.com/rewards-guilds/rr-standards/commit/c135bdc2a9b46729305af813399f3de57d873d21)), closes [#334](https://github.com/rewards-guilds/rr-standards/issues/334) [#335](https://github.com/rewards-guilds/rr-standards/issues/335)

## [0.14.1](https://github.com/rewards-guilds/rr-standards/compare/v0.14.0...v0.14.1) (2026-05-15)

### Bug Fixes

* **forge-skill-creator:** enforce valid YAML frontmatter rules when drafting skills ([#334](https://github.com/rewards-guilds/rr-standards/issues/334)) ([f6a6f26](https://github.com/rewards-guilds/rr-standards/commit/f6a6f26df5ee7abe122e455ce4ede61e993d0704))

## [0.14.0](https://github.com/rewards-guilds/rr-standards/compare/v0.13.0...v0.14.0) (2026-05-15)

### Features

* **forge-skill-creator:** add zip/package trigger phrases and Package mode phase detection ([#330](https://github.com/rewards-guilds/rr-standards/issues/330)) ([caabe52](https://github.com/rewards-guilds/rr-standards/commit/caabe520b4169e65dfa784d22955457063184788))

### Bug Fixes

* **forge-skill-creator-plugin:** improve skill behavioral test pass rate from 40% to 87% ([#327](https://github.com/rewards-guilds/rr-standards/issues/327)) ([c5c4264](https://github.com/rewards-guilds/rr-standards/commit/c5c4264f6ab2c0dd4343a807864c38a8bcc24579))

## [0.13.0](https://github.com/rewards-guilds/rr-standards/compare/v0.12.0...v0.13.0) (2026-05-12)

### Features

* **build-tests:** add TypeScript/Node.js e2e-test language guide and fixtures ([#313](https://github.com/rewards-guilds/rr-standards/issues/313)) ([70cde64](https://github.com/rewards-guilds/rr-standards/commit/70cde64e5a2081f8f7010326e9c9efbcb3fb6a92))

### Bug Fixes

* **forge:** publish marketplace.json and install script to Nexus ([#318](https://github.com/rewards-guilds/rr-standards/issues/318)) ([d6e68dc](https://github.com/rewards-guilds/rr-standards/commit/d6e68dca8fe575baa325eea11f4d94cb688e61ed))

## [0.12.0](https://github.com/rewards-guilds/rr-standards/compare/v0.11.0...v0.12.0) (2026-05-11)

### Features

* **forge:review:** Phase 2 delta review with carry-forward inline comments ([#248](https://github.com/rewards-guilds/rr-standards/issues/248)) ([fa4a077](https://github.com/rewards-guilds/rr-standards/commit/fa4a0778daba7ece0a1356db05b5463e129cb35e)), closes [#73](https://github.com/rewards-guilds/rr-standards/issues/73) [#74](https://github.com/rewards-guilds/rr-standards/issues/74)

## [0.11.0](https://github.com/rewards-guilds/rr-standards/compare/v0.10.0...v0.11.0) (2026-05-07)

### Features

* **forge:arch-review:** add architecture review skill ([#306](https://github.com/rewards-guilds/rr-standards/issues/306)) ([b6834d9](https://github.com/rewards-guilds/rr-standards/commit/b6834d93b5fc5e8a1362effa79fd08b8f7781ef4)), closes [#246](https://github.com/rewards-guilds/rr-standards/issues/246)
* **forge:build-tests:** add e2e-test type with Go, Java, and Python support ([#305](https://github.com/rewards-guilds/rr-standards/issues/305)) ([5041acd](https://github.com/rewards-guilds/rr-standards/commit/5041acdbea3d7aeea833a06e02ecbfc0a594fe64))
* **forge:build-tests:** Add External API Integration Tests Implementation and Design Guides ([#260](https://github.com/rewards-guilds/rr-standards/issues/260)) ([9ed30ad](https://github.com/rewards-guilds/rr-standards/commit/9ed30adf6ae24b22cc3ccfef7fb8a4d5e6e441a4))
* **forge-clear:** add forge:clear skill to unset active effort pointer ([#294](https://github.com/rewards-guilds/rr-standards/issues/294)) ([9d339bc](https://github.com/rewards-guilds/rr-standards/commit/9d339bc47df423a091f3cf2743d165b23f08f6cd))
* **forge:mobile-tests:** Add skill for mobile test automation  ([#291](https://github.com/rewards-guilds/rr-standards/issues/291)) ([85807db](https://github.com/rewards-guilds/rr-standards/commit/85807db33419ed950b3ead7231a30f7282e3f60f))
* **forge-help-skill:** forge:help Skill ([#296](https://github.com/rewards-guilds/rr-standards/issues/296)) ([70486a8](https://github.com/rewards-guilds/rr-standards/commit/70486a842ef2aee335ba0d3cb7d2d4431c706baf))
* **forge-report:** forge:report skill family ([#246](https://github.com/rewards-guilds/rr-standards/issues/246)) ([bb60b86](https://github.com/rewards-guilds/rr-standards/commit/bb60b862dd8996101b7a4cd504d81bf99f6f37f4))
* **forge-slack:** near-real-time import, lag buffer, and thread lookback ([#288](https://github.com/rewards-guilds/rr-standards/issues/288)) ([7256c55](https://github.com/rewards-guilds/rr-standards/commit/7256c558b4723828e3892168edbb568a9de8c22d))
* **forge:** rename forge:ui-design to forge:spec-ui ([#286](https://github.com/rewards-guilds/rr-standards/issues/286)) ([ae9decf](https://github.com/rewards-guilds/rr-standards/commit/ae9decf3daf23ca58232f2bf1435385931effdb8))
* **forge-plan:** vertical slice wave assignment and delivery diagram ([#293](https://github.com/rewards-guilds/rr-standards/issues/293)) ([8c1621c](https://github.com/rewards-guilds/rr-standards/commit/8c1621c713b3e7d051f490067204e172449c67b2))

### Bug Fixes

* **statusline:** add context-aware color thresholds for 200k and 1M windows ([#308](https://github.com/rewards-guilds/rr-standards/issues/308)) ([a9927a9](https://github.com/rewards-guilds/rr-standards/commit/a9927a9e8d737c92831cec70441dcae2021fb450))
* **forge:** add effort --select mode and fix session-start CTA ([#285](https://github.com/rewards-guilds/rr-standards/issues/285)) ([5a0cc55](https://github.com/rewards-guilds/rr-standards/commit/5a0cc55fb9ae0dcc94a349b6f9f7849607b05537))
* **forge-slack:** convert ISO 8601 bounds to Unix timestamps before Slack MCP calls ([#289](https://github.com/rewards-guilds/rr-standards/issues/289)) ([3a1dc04](https://github.com/rewards-guilds/rr-standards/commit/3a1dc04d8fd8c67bef15476ace6da6558c46edd1))
* **forge/telemetry:** guard git remote get-url against repos with no origin ([#302](https://github.com/rewards-guilds/rr-standards/issues/302)) ([f9919fc](https://github.com/rewards-guilds/rr-standards/commit/f9919fc8b9eddb45e0219757b7ad3e7e62c239cf))
