# rr-standards Specs

This directory exists to host specs created for the spec driven workflow for making modifications to this repository.
It is highly recommended that when making major changes to this repository that you follow the workflow promoted
and maintained from within this repository.

See [SPEC_DRIVEN_DEVELOPMENT.md](../docs/workflows/SPEC_DRIVEN_DEVELOPMENT.md) for instructions on using the flow.
