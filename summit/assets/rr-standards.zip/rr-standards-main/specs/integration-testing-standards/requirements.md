# Requirements: integration-testing-standards

## Overview

This feature defines comprehensive, language-agnostic best practices and standards for integration testing across all services in the Rewards ecosystem. The standard ensures that all interactions between the service under development and external components (databases, web services, message queues, etc.) are properly tested using real components where possible, with contract-based mocking when necessary.

This standard complements the [unit-testing-standards](../unit-testing-standards/requirements.md) and aligns with the overall [Testing Strategy](../../standards/testing/strategy.md).

## Functional Requirements

### FR-1: Test External Component Interactions
**Description:** Integration tests must validate the interaction between external components and the service under development
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard defines what constitutes an external component (databases, web services, message queues, file systems, caches, third-party APIs)
- [ ] Standard requires testing the integration points, not the external components themselves
- [ ] Examples of integration tests for common external components (database, REST API, message queue)
- [ ] Guidance on testing both happy paths and error scenarios (connection failures, timeouts, invalid data)
- [ ] Clear distinction between integration tests and unit tests

### FR-2: Comprehensive Coverage of External Dependencies
**Description:** Every external component that interacts with the service under development must have integration tests. All code lines that interact with external services must be covered by integration tests.
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires integration tests for every database table the service reads from or writes to
- [ ] Standard requires integration tests for every message topic/queue the service consumes from or publishes to
- [ ] Standard requires integration tests for every external API endpoint the service calls
- [ ] Standard requires integration tests for every cache the service uses
- [ ] Standard requires integration tests for any file system or object storage the service accesses
- [ ] Standard requires that all code lines interacting with external services must be covered by integration tests
- [ ] Examples showing comprehensive coverage mapping (service dependencies → integration tests)
- [ ] Guidance on documenting which integration tests cover which external dependencies
- [ ] Guidance on verifying integration test coverage in code reviews and CI/CD

### FR-3: Contract-Based Mocking
**Description:** When mocking is necessary in integration tests, it must be based on formal contracts
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard specifies using database schemas for database mocks
- [ ] Standard specifies using OpenAPI specifications for REST API mocks
- [ ] Standard specifies using JSON schemas or protobuf definitions for message queue contracts
- [ ] Standard prohibits ad-hoc or invented mocks that don't match real contracts
- [ ] Examples of contract-based mocking vs ad-hoc mocking
- [ ] Guidance on keeping mock contracts in sync with real services
- [ ] Rationale for why contract-based mocking is required (prevents contract drift)

### FR-4: Test Atomicity
**Description:** Integration tests must be atomic, independent, and idempotent
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard defines what makes an integration test atomic
- [ ] Tests must not depend on execution order
- [ ] Tests must not share state or side effects
- [ ] Each test must set up its own data and clean up afterward
- [ ] Tests must be repeatable with consistent results
- [ ] Standard requires using isolated databases/queues per test run (not shared infrastructure)
- [ ] Guidance on database cleanup strategies (truncation, transactions, test containers)
- [ ] Examples of atomic vs non-atomic integration tests
- [ ] Rationale for isolated infrastructure (prevents interference, enables parallelization)

### FR-5: Real Component Testing
**Description:** Integration tests should use real components (not mocks) whenever possible
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires using real databases for database integration tests
- [ ] Standard requires using real message queues for messaging integration tests
- [ ] Standard requires using real services when possible (test instances, Podman containers)
- [ ] Guidance on when mocking is acceptable: third-party APIs you don't control, expensive external services
- [ ] Standard explicitly allows mocking third-party APIs if mocks are contract-based (using OpenAPI specs, API documentation)
- [ ] Examples of spinning up real components using Podman
- [ ] Language guides specify specific approaches (Testcontainers, embedded databases, etc.)
- [ ] Guidance on using test containers or embedded instances
- [ ] Performance considerations for real component testing

### FR-6: CI/CD Integration
**Description:** Integration tests must run in CI/CD pipelines and pass before code can be committed or merged
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires integration tests to run in CI/CD pipeline before merge
- [ ] Standard requires 100% passing integration tests before merge to main branch
- [ ] Quality gates must verify that all integration tests pass
- [ ] Quality gates must verify that code interacting with external services has integration test coverage
- [ ] Guidance on running integration tests locally before commit
- [ ] Guidance on setting up test infrastructure in CI/CD (test databases, containers)
- [ ] Performance expectations for integration test execution time (faster than E2E, slower than unit)
- [ ] Handling of external dependencies in CI/CD (test instances, mocked services)

### FR-7: Descriptive Test Names
**Description:** Integration test names must clearly describe what is being tested
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard provides guidelines for descriptive test names
- [ ] Test names should indicate: what external component is being tested, what operation is being performed, what the expected outcome is
- [ ] Examples of good integration test names vs poor names
- [ ] Language-agnostic naming patterns (specific formats defined in language guides)
- [ ] Consistency with unit testing naming conventions

### FR-8: Test Documentation
**Description:** Each integration test must have a comment explaining its purpose and goal
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard requires each integration test to have a comment describing purpose
- [ ] Comments should explain: what external component is being tested, what contract or behavior is being validated, why this test is important
- [ ] Template or example of integration test documentation
- [ ] Guidance on when test name is sufficient vs when detailed comment is needed
- [ ] Examples of well-documented integration tests

### FR-9: Integration Test Scope and Boundaries
**Description:** Define clear boundaries between integration tests and other test types
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard clearly distinguishes integration tests from unit tests (unit tests mock all external dependencies, integration tests use real dependencies)
- [ ] Standard clearly distinguishes integration tests from E2E tests (integration tests focus on specific integrations, E2E tests validate full workflows)
- [ ] Guidance on what should be an integration test vs unit test vs E2E test
- [ ] Examples showing appropriate test boundaries
- [ ] Rationale for why these boundaries matter (test pyramid, performance, maintainability)

### FR-10: Language-Agnostic Approach
**Description:** Standard must be applicable across all programming languages
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard is language-agnostic (no language-specific code in core document)
- [ ] Principles apply to Go, Java, Python, TypeScript, Kotlin, Swift
- [ ] Clear references to language-specific guides for implementation details
- [ ] Language guides provide specific frameworks and tools (Testcontainers, embedded databases, etc.)
- [ ] Consistent terminology across all languages

### FR-11: Test Data Management
**Description:** Define standards for managing test data in integration tests
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard provides guidance on test data setup and teardown
- [ ] Recommendations for test data fixtures and factories
- [ ] Guidance on using realistic test data vs minimal test data
- [ ] Strategies for handling test data in databases (SQL scripts, object mothers, builders)
- [ ] Examples of test data management patterns
- [ ] Guidance on data cleanup to maintain test atomicity

### FR-12: Error Handling and Edge Cases
**Description:** Integration tests must validate error conditions and edge cases
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires testing error scenarios (connection failures, timeouts, invalid responses)
- [ ] Guidance on testing retry logic and circuit breakers
- [ ] Testing of partial failures and degraded modes
- [ ] Examples of error condition testing for common scenarios
- [ ] Balance between happy path and error path testing

### FR-13: Performance Characteristics
**Description:** Define expected performance characteristics for integration tests
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard specifies integration tests should be faster than E2E tests but slower than unit tests
- [ ] Target execution time ranges (individual tests typically < 5 seconds, test suite < 10 minutes)
- [ ] Guidance on optimizing integration test performance
- [ ] When to refactor slow integration tests
- [ ] Strategies for parallelizing integration tests

### FR-14: Test Organization and Directory Structure
**Description:** Integration tests must be organized in a separate directory structure from unit tests
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires integration tests in separate folder from unit tests
- [ ] Parent folder must be named "integration"
- [ ] Clear directory structure guidance (language guides provide specific paths)
- [ ] Examples of proper integration test organization
- [ ] Rationale for separation (different execution in CI/CD, clear identification, different configurations)
- [ ] Guidance on how to run integration tests separately from unit tests

## Non-Functional Requirements

### NFR-1: Clarity and Comprehensiveness
**Requirement:** Documentation must be clear, comprehensive, and actionable
**Target:**
- Developers can understand and apply standards without additional training
- Examples provided for all major concepts
- Standards answer "why" not just "what"
- All functional requirements have clear guidance

### NFR-2: Maintainability
**Requirement:** Standards must be easy to maintain and update
**Target:**
- Single source of truth for language-agnostic standards
- Clear separation between language-agnostic and language-specific guidance
- Versioning and change history tracked
- Updates can be made without breaking language guides

### NFR-3: Adoption and Usability
**Requirement:** Standards should be easily adoptable across existing projects
**Target:**
- Provide migration guidance for existing codebases
- Incremental adoption path available
- Clear, actionable guidance that developers can follow
- Tooling and automation recommendations to support adoption

### NFR-4: Integration with Development Tools
**Requirement:** Standards should integrate with existing development tools
**Target:**
- Works with common CI/CD systems (GitHub Actions, Jenkins, GitLab CI, etc.)
- Compatible with container technologies (Podman)
- Supports test automation frameworks across languages
- Can be enforced via automated quality gates

### NFR-5: Consistency with Testing Strategy
**Requirement:** Standard must align with overall Testing Strategy and testing pyramid
**Target:**
- Integration tests positioned correctly in testing pyramid (middle layer)
- Consistent terminology with testing strategy
- Risk-based approach supported (R1-R4 framework)
- Clear relationship to other testing types

## Constraints

### Technical Constraints
- Must be language-agnostic (no language-specific code in core standard)
- Must reference language-specific guidelines for implementation details
- Must work with existing rr-standards repository structure (standards/ and languages/ directories)
- Must follow rr-standards documentation format and conventions (see CLAUDE.md)
- Must be compatible with existing testing frameworks and container technologies

### Business Constraints
- Should align with Rakuten Rewards existing development practices where possible
- Must not require complete rewrites of existing test suites (incremental adoption supported)
- Should provide ROI through improved integration reliability and reduced production bugs
- Must be maintainable by multiple contributors over time
- Should work with existing infrastructure and CI/CD pipelines

## Dependencies

### External Dependencies
- None - this is a standard definition, not a tool or implementation

### Internal Dependencies
- **Testing Strategy** - standards/testing/strategy.md (defines overall testing approach and integration testing in pyramid)
- **Unit Testing Standard** - standards/testing/unit-testing.md (complementary standard for unit tests)
- **Existing language guides** in rr-standards:
  - languages/go/
  - languages/java/
  - languages/python/
  - languages/typescript/
  - languages/kotlin/
  - languages/swift/
- **Workflow documentation**:
  - docs/workflows/SPEC_DRIVEN_DEVELOPMENT.md
  - docs/workflows/guides/test-design-process.md
  - docs/workflows/guides/risk-assessment-guide.md
- **Related standards** (may need to reference):
  - CI/CD pipeline standards
  - Code review standards
  - Container/infrastructure standards (for Podman usage)

### Dependents
- **Language implementation guides** will reference this standard
- **Development teams** will use this as basis for integration test quality
- **CI/CD pipelines** will enforce these standards
- **Code review processes** will check compliance with these standards
- **Skills/tooling** may be created to help enforce or generate integration tests following these standards

## Resolved Questions

All key questions have been resolved and incorporated into the requirements:

1. **Test container vs embedded vs remote test instances**
   - **Decision:** Standard remains flexible; language guides specify specific approaches
   - **Rationale:** Different languages and frameworks have different tooling available. Language guides can recommend Testcontainers for Java, embedded databases for specific languages, or Podman containers as needed.
   - **Incorporated in:** FR-5, FR-10

2. **Integration test coverage metrics**
   - **Decision:** Code lines that interact with external services must be covered by integration tests. Quality gates in CI/CD must verify integration tests pass.
   - **Rationale:** Unlike unit tests with % coverage, integration testing focuses on ensuring all integration points are tested. Every database table, API endpoint, message queue topic must have integration test coverage.
   - **Incorporated in:** FR-2, FR-6

3. **Handling third-party APIs**
   - **Decision:** Allow mocking for third-party APIs, but mocks must be based on contracts (OpenAPI specs, API documentation)
   - **Rationale:** Test instances/sandboxes for third-party services may not be available or cost-effective. Contract-based mocks ensure we test against accurate API contracts.
   - **Incorporated in:** FR-3, FR-5

4. **Integration test organization**
   - **Decision:** Integration tests must be in a separate folder from unit tests. Parent folder must be named "integration".
   - **Rationale:** Clear separation enables different test execution in CI/CD, makes it easy to identify integration tests, and allows different test runners/configurations.
   - **Incorporated in:** New FR-14

5. **Shared test infrastructure**
   - **Decision:** Teams should use isolated databases/queues per test run
   - **Rationale:** Ensures test atomicity, prevents interference between parallel test runs, enables local development and CI/CD parallelization.
   - **Incorporated in:** FR-4

## Success Criteria

How will we know this feature is successful?

### Documentation Quality
- [ ] All 14 functional requirements have clear, detailed guidance with examples
- [ ] Standard can be read and understood without additional training
- [ ] Each requirement includes rationale (the "why")
- [ ] Language-agnostic throughout with clear references to language guides
- [ ] Examples cover common integration scenarios (database, API, message queue)

### Adoption
- [ ] Standard is referenced in at least 3 language-specific guides within 3 months
- [ ] At least one language guide fully implements all requirements with examples
- [ ] Development teams use standard for integration test design and code reviews
- [ ] CI/CD pipelines enforce key requirements (passing tests, real components)

### Measurable Quality Improvements
- [ ] Integration tests consistently test all external dependencies (FR-2)
- [ ] Reduction in production bugs related to integration failures
- [ ] Integration test execution time meets performance targets (FR-13)
- [ ] Integration tests are stable and deterministic (low flakiness rate)

### Developer Experience
- [ ] Positive feedback from development teams on clarity and usefulness
- [ ] Developers can implement integration tests following the standard without assistance
- [ ] Standard reduces ambiguity in code reviews about integration test quality
- [ ] Onboarding time for new developers reduced due to clear integration testing standards

### Consistency
- [ ] Integration tests across different services follow common patterns
- [ ] Tests across languages demonstrate similar structure and quality
- [ ] Code reviews reference standard for objective quality criteria
- [ ] Integration tests properly positioned in testing pyramid (more than E2E, fewer than unit)

### Completeness
- [ ] All acceptance criteria met for all 14 functional requirements
- [ ] Open questions resolved or documented
- [ ] Standard addresses real-world integration testing scenarios
- [ ] Examples cover common patterns (database transactions, API calls, message queues)
