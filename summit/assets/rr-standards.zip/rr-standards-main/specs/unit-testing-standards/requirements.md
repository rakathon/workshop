# Requirements: unit-testing-standards

## Overview

This feature defines comprehensive, language-agnostic best practices and standards for unit testing across all services in the Rewards ecosystem. The standard ensures consistent quality, maintainability, and reliability of unit tests while delegating language-specific implementation details to language-specific guidelines.

## Functional Requirements

### FR-1: Code Coverage Standards
**Description:** Establish minimum code coverage threshold of >90% for unit tests
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard specifies >90% code coverage requirement
- [ ] Coverage measurement includes branches, not just lines
- [ ] Examples of how to measure coverage (reference language guides for tools)

### FR-2: Requirements Traceability
**Description:** Ensure every functional requirement in the product requirements document has corresponding unit test coverage
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard defines requirement-to-test mapping approach
- [ ] Guidance on documenting traceability between requirements and tests
- [ ] Examples of how to structure tests that validate requirements
- [ ] Recommendation for naming tests to reflect requirements they validate

### FR-3: Dependency Mocking
**Description:** Define standards for mocking all external dependencies in unit tests
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard defines what constitutes an "external dependency" (databases, APIs, message queues, file systems, etc.)
- [ ] Requirement that all external dependencies must be mocked in unit tests
- [ ] Guidelines for when to use mocks vs stubs vs fakes
- [ ] Reference to language-specific mocking frameworks in language guides

### FR-4: Contract-Based Mocking
**Description:** Establish standards for creating mocks based on formal contracts when accessible
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard specifies using database schemas for database mocks
- [ ] Standard specifies using OpenAPI specs for REST API mocks
- [ ] Standard specifies using Kafka message contracts for event mocks
- [ ] Guidance on using similar documentation for other external components
- [ ] Examples of contract-based vs ad-hoc mocking

### FR-5: Language-Specific Implementation References
**Description:** Link to language-specific guidelines for implementation details
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard explicitly states it is language-agnostic
- [ ] Clear references to language guidelines for: folder structure, method naming, technologies/frameworks used
- [ ] Standard avoids language-specific code in core document
- [ ] Navigation from this standard to language guides is clear

### FR-6: CI/CD Integration
**Description:** Define requirements for integrating unit tests into development workflow
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires unit tests to run prior to any commit (pre-commit hooks)
- [ ] Standard requires unit tests to run prior to any merge in CI/CD pipeline
- [ ] Guidance on failing builds when tests fail
- [ ] Performance requirements for test execution time in CI/CD

### FR-7: Static Value Assertions
**Description:** Ensure all tests compare a static value to a value derived from the function being tested
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires comparing expected static values against actual derived values
- [ ] Standard prohibits comparing two derived values
- [ ] Examples of correct assertions (static expected vs derived actual)
- [ ] Examples of incorrect assertions (derived vs derived)
- [ ] Rationale for why static values are required

### FR-8: Passing Tests Requirement
**Description:** Establish policy that all unit tests must be passing prior to any commit
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires 100% passing tests before commit
- [ ] No failing tests allowed in main/master branch
- [ ] Guidance on handling flaky tests
- [ ] Process for temporarily disabling tests (discouraged, with tracking)

### FR-9: Test Determinism
**Description:** Ensure tests are deterministic and produce the same result no matter how many executions or in which order
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard defines what makes a test deterministic
- [ ] Prohibition of dependencies on: external state, execution order, time/date (unless properly mocked), random values (unless seeded), shared mutable state
- [ ] Guidelines for handling time-dependent logic in tests
- [ ] Examples of deterministic vs non-deterministic tests

### FR-10: Test Atomicity
**Description:** Define requirements that tests are atomic and do not rely on each other
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires tests to be completely independent
- [ ] Tests must not rely on execution order
- [ ] Tests must not share state
- [ ] Each test must set up its own context
- [ ] Guidance on avoiding test interdependencies

### FR-11: Descriptive Test Names
**Description:** Establish that test names must be descriptive
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard provides guidelines for descriptive test names
- [ ] Examples of good test names that describe: what is being tested, under what conditions, what the expected outcome is
- [ ] Language-agnostic naming patterns (delegate exact format to language guides)
- [ ] Examples of poor vs good test names

### FR-12: Test Documentation
**Description:** Require that each test should have a comment on the purpose and goal of the test
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard requires each test to have a comment explaining purpose and goal
- [ ] Template or example of what information should be in comments
- [ ] Guidance on when test name is sufficient vs when detailed comment is needed
- [ ] Examples of well-documented tests

### FR-13: Single Responsibility Tests
**Description:** Ensure tests only verify one functionality per test
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard defines "single functionality" in test context
- [ ] Guidance on breaking complex tests into multiple simple tests
- [ ] Examples of tests that do too much vs focused tests
- [ ] Exception handling: when multiple assertions in one test are acceptable

### FR-14: Test Performance
**Description:** Define standards that unit tests must execute quickly
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard specifies that individual unit tests must execute in sub-1-second times
- [ ] Individual tests should complete in milliseconds (typically < 100ms)
- [ ] Test suite execution time scales linearly with number of tests
- [ ] Guidance on what to do with slow tests (refactor or move to integration tests)
- [ ] Performance optimization techniques for tests
- [ ] Note that total suite time depends on number of tests in the test class/file

### FR-15: Arrange-Act-Assert Pattern
**Description:** Standardize that unit tests should follow an Arrange, Act, Assert pattern
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires Arrange-Act-Assert structure
- [ ] Definition of each phase: Arrange (setup test data/mocks), Act (execute code under test), Assert (verify results)
- [ ] Examples showing clear AAA sections
- [ ] Guidance on using comments or whitespace to separate phases

### FR-16: No Magic Strings/Values
**Description:** Require that unit tests do not use magic strings and each variable used should have a clear explanation as to the reason of its use
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard prohibits unexplained "magic" strings and numbers
- [ ] Requirement to use named constants or well-documented variables
- [ ] Each test value should have clear reasoning (via variable name or comment)
- [ ] Examples of magic values vs well-explained values

### FR-17: Helper Methods Over Setup/Teardown
**Description:** Specify that helper methods should be used over Setup and Teardown to support the tests, and test data should follow object mother patterns
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard recommends helper methods for test setup
- [ ] Rationale: explicit is better than implicit, easier to understand test in isolation
- [ ] Guidance on when setup/teardown is acceptable
- [ ] Examples of helper method patterns
- [ ] Test data management should follow object mother patterns
- [ ] Guidance on implementing object mother pattern for test data creation
- [ ] Examples of object mother pattern vs fixtures/factories

### FR-18: Private Method Testing
**Description:** Define that unit tests can validate private methods in the service under test through testing public methods
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard states private methods should be tested through public methods
- [ ] Rationale: tests should verify behavior, not implementation
- [ ] Guidance on when private method is too complex (should be extracted)
- [ ] Language-specific notes on visibility/access (in language guides)

### FR-19: Seams in Testing
**Description:** Define that seams should be used in unit tests when they test a stub with a static reference
**Priority:** Medium
**Acceptance Criteria:**
- [ ] Standard defines what a "seam" is in testing context
- [ ] Guidance on using seams for testing code with static dependencies
- [ ] Examples of seam patterns (delegation, dependency injection)
- [ ] When to refactor code to make it more testable

### FR-20: Single Act Per Test
**Description:** Ensure that tests should only have one Act
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard requires exactly one act (execution) per test
- [ ] Multiple acts indicate multiple tests needed
- [ ] Examples of tests with single act vs multiple acts
- [ ] Relation to single responsibility principle (FR-13)

### FR-21: Legacy Code Coverage
**Description:** Define that legacy code that cannot achieve >90% coverage should have unit tests added when new functionality is added that increase the overall code coverage
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard states code coverage cannot decrease in legacy code when new code is added or changed
- [ ] Guidance on incremental improvement of legacy code coverage
- [ ] Approach for handling existing code below threshold
- [ ] Strategy for gradually improving coverage over time
- [ ] Examples of how to add tests when modifying legacy code

### FR-22: Test Coverage for All Code
**Description:** Establish that test coverage is required for generated and non-generated code
**Priority:** High
**Acceptance Criteria:**
- [ ] Standard specifies coverage requirement applies to all code
- [ ] Includes both manually written and generated code
- [ ] Guidance on how to test generated code
- [ ] No blanket exemptions for generated code
- [ ] Examples of testing code generation outputs

### FR-23: AAA Pattern for All Frameworks
**Description:** Require that frameworks that cannot accomplish AAA should have examples of how to do the same given the limitations
**Priority:** High
**Acceptance Criteria:**
- [ ] Language guides must provide AAA examples even for frameworks that don't natively support it
- [ ] Guidance on achieving AAA structure regardless of framework
- [ ] Examples showing how to work around framework limitations
- [ ] Clear separation of Arrange, Act, Assert even in unconventional frameworks

## Non-Functional Requirements

### NFR-1: Clarity and Comprehensiveness
**Requirement:** Documentation must be clear, comprehensive, and actionable
**Target:**
- Developers can understand and apply standards without additional training
- Examples provided for all major concepts
- Standards answer "why" not just "what"
- All 23 functional requirements have clear guidance

### NFR-2: Maintainability
**Requirement:** Standards must be easy to maintain and update
**Target:**
- Single source of truth for language-agnostic standards
- Clear separation between language-agnostic and language-specific guidance
- Versioning and change history tracked
- Updates can be made without breaking language guides

### NFR-3: Adoption and Usability
**Requirement:** Standards should be easily adoptable across existing projects
**Target:**
- Provide migration guidance for existing codebases
- Incremental adoption path available (via FR-21)
- Clear, actionable guidance that developers can follow
- Tooling and automation recommendations to support adoption

### NFR-4: Integration with Development Tools
**Requirement:** Standards should integrate with existing development tools
**Target:**
- Works with common CI/CD systems (GitHub Actions, Jenkins, GitLab CI, etc.)
- Compatible with code coverage tools across languages
- Supports pre-commit hooks
- Can be enforced via automated quality gates

## Constraints

### Technical Constraints
- Must be language-agnostic (no language-specific code in core standard)
- Must reference language-specific guidelines for implementation details
- Must work with existing rr-standards repository structure (standards/ and languages/ directories)
- Must follow rr-standards documentation format and conventions (see CLAUDE.md)
- Must be compatible with existing testing frameworks across supported languages

### Business Constraints
- Should align with Rakuten Rewards existing development practices where possible
- Must not require complete rewrites of existing test suites (incremental adoption via FR-21)
- Should provide ROI through improved code quality and reduced production bugs
- Must be maintainable by multiple contributors over time

## Dependencies

### External Dependencies
- None - this is a standard definition, not a tool or implementation

### Internal Dependencies
- **Language-specific guidelines** - Each supported language needs:
  - Folder structure conventions
  - Naming conventions
  - Testing frameworks (e.g., JUnit, pytest, Jest, go test)
  - Mocking frameworks (e.g., Mockito, unittest.mock, jest.mock, gomock)
  - Code coverage tools (e.g., JaCoCo, coverage.py, Istanbul, go cover)
  - Examples implementing these 23 standards

- **Existing language guides** in rr-standards:
  - languages/go/
  - languages/java/
  - languages/python/
  - languages/typescript/
  - languages/kotlin/
  - languages/swift/

- **Related standards** (may need to reference):
  - Integration testing standards (complementary to unit testing)
  - CI/CD pipeline standards
  - Code review standards

### Dependents
- **Language implementation guides** will reference this standard
- **Development teams** will use this as basis for test quality
- **CI/CD pipelines** will enforce these standards
- **Code review processes** will check compliance with these standards
- **Skills/tooling** may be created to help enforce or generate tests following these standards

## Resolved Questions

All key questions have been resolved and incorporated into the requirements:

1. **Contract-based mocks detail level** (FR-4)
   - **Decision:** Principle in standard, implementation examples in language guides
   - **Rationale:** Maintains language-agnostic approach while providing concrete guidance

2. **Test organization prescriptiveness** (FR-5)
   - **Decision:** General guidance in standard, specific structure in language guides
   - **Rationale:** Allows flexibility across different languages and frameworks

3. **Test data management** (FR-17)
   - **Decision:** Use object mother patterns for test data
   - **Rationale:** Provides consistent, readable approach to test data creation across tests

4. **Test execution time thresholds** (FR-14)
   - **Decision:** Unit tests must execute in sub-1-second times
   - **Rationale:** Ensures fast feedback loop and encourages proper unit test design

5. **Mutation testing scope**
   - **Decision:** Future enhancement, focus on core 23 requirements first
   - **Rationale:** Core standards must be established before advanced techniques

6. **Parameterized/data-driven tests in AAA** (FR-15, FR-23)
   - **Decision:** Include examples in language guides showing AAA with parameterized tests
   - **Rationale:** Different frameworks handle parameterized tests differently; language guides best suited for specific examples

## Success Criteria

How will we know this feature is successful?

### Documentation Quality
- [ ] All 23 functional requirements have clear, detailed guidance with examples
- [ ] Standard can be read and understood without additional training
- [ ] Each requirement includes rationale (the "why")
- [ ] Language-agnostic throughout with clear references to language guides

### Adoption
- [ ] Standard is referenced in at least 3 language-specific guides within 3 months
- [ ] At least one language guide fully implements all 23 requirements
- [ ] Development teams use standard for code reviews
- [ ] CI/CD pipelines enforce key requirements (coverage, passing tests)

### Measurable Quality Improvements
- [ ] New code consistently meets >90% coverage requirement (FR-1)
- [ ] Code coverage trends upward in legacy codebases (FR-21)
- [ ] Reduction in production bugs that could have been caught by unit tests
- [ ] Test execution time meets performance targets (FR-14)

### Developer Experience
- [ ] Positive feedback from development teams on clarity and usefulness
- [ ] Developers can implement tests following the standard without assistance
- [ ] Standard reduces ambiguity in code reviews about test quality
- [ ] Onboarding time for new developers reduced due to clear testing standards

### Consistency
- [ ] Unit tests across different services follow common patterns
- [ ] Tests across languages demonstrate similar structure and quality
- [ ] Code reviews reference standard for objective quality criteria

### Completeness
- [ ] All acceptance criteria met for all 23 functional requirements
- [ ] Open questions resolved or documented
- [ ] Standard addresses real-world testing scenarios
- [ ] Examples cover common and edge cases
