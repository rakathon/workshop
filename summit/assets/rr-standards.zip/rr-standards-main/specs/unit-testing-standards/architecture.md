# Architecture: Unit Testing Standards

## Overview

This architecture defines a comprehensive, language-agnostic unit testing standard that will be added to the rr-standards repository. The standard establishes 23 core requirements covering code coverage, test structure, mocking, performance, and quality practices that apply across all programming languages in the Rewards ecosystem.

**Architectural Approach:**
- Create a **single source of truth** for unit testing principles at `standards/testing/unit-testing.md`
- Language-agnostic standard defines **WHAT** to test and **WHY**
- Language-specific guides define **HOW** to implement with specific tools/frameworks
- Clear separation follows existing rr-standards pattern (standards/ → languages/)

**Key Design Decisions:**
1. **Language-Agnostic First:** Core standard contains no language-specific code
2. **Reference-Based Architecture:** Language guides explicitly reference the standard
3. **Incremental Adoption:** Legacy code support (FR-21) built into standard
4. **Enforcement Ready:** Designed to integrate with CI/CD pipelines

**Integration with Existing System:**
- Fits into existing `standards/testing/` directory alongside `strategy.md`
- Extends current language guides (Java, Go, Python, TypeScript, Kotlin, Swift)
- Follows established documentation patterns (README.md, AGENTS.md)
- Compatible with existing CI/CD workflows

---

## System Context

### External Dependencies
- **None** - This is a documentation standard, not a tool or service
- Standards reference external tools (JUnit, pytest, Jest) but don't depend on them

### Internal Dependencies

**Existing Repository Structure:**
- `standards/` - Where new unit testing standard lives
- `standards/testing/` - Testing standards directory (currently has empty `strategy.md`)
- `languages/{go,java,python,typescript,kotlin,swift}/` - Language implementation guides
- `templates/standard-template.md` - Template for creating standards

**Existing Documentation:**
- `languages/java/guides/testing/testing.md` - Comprehensive Java testing guide (already implements many requirements)
- `languages/go/guides/testing/` - Go testing guides (to be updated)
- `CLAUDE.md` - Repository contribution guidelines
- `README.md` - Main repository documentation

**Related Standards (to reference):**
- `standards/api/rest.md` - For examples of contract-based mocking (FR-4)
- CI/CD standards (if they exist) - For pipeline integration (FR-6)
- Code review standards (if they exist) - For enforcement

### Dependents

**Direct Dependents:**
- Language implementation guides (Java, Go, Python, TypeScript, Kotlin, Swift)
- Development teams using rr-standards
- CI/CD pipelines enforcing testing requirements
- Code review processes checking compliance

**Indirect Dependents:**
- New services adopting rr-standards
- Skills/tools that generate test code
- Training materials for developers

---

## System Components

### Component 1: Core Unit Testing Standard
**Responsibility:** Define language-agnostic unit testing principles and requirements
**Technology:** Markdown documentation
**Location:** `standards/testing/unit-testing.md`
**Interfaces:** Referenced by language guides via relative links
**Dependencies:** None (pure documentation)

**Content Sections:**
1. **Overview & Core Principles** - What unit testing is and why it matters
2. **Coverage Requirements** (FR-1, FR-21, FR-22) - 90% coverage, legacy code, generated code
3. **Requirements Traceability** (FR-2) - Mapping tests to functional requirements
4. **Dependency Management** (FR-3, FR-4) - Mocking and contract-based testing
5. **Test Structure** (FR-15, FR-20, FR-23) - AAA pattern, single act
6. **Test Quality** (FR-7, FR-9, FR-10, FR-13) - Static assertions, determinism, atomicity, single responsibility
7. **Test Documentation** (FR-11, FR-12) - Naming and comments
8. **Test Performance** (FR-14) - Sub-1-second execution
9. **Test Data Management** (FR-16, FR-17) - Object mother pattern, no magic strings
10. **Advanced Topics** (FR-18, FR-19) - Private method testing, seams
11. **Workflow Integration** (FR-6, FR-8) - CI/CD, pre-commit hooks
12. **Language Guide References** (FR-5) - Links to implementation details

### Component 2: Language Implementation Guides (Updates)
**Responsibility:** Provide language-specific implementation of unit testing standard
**Technology:** Markdown documentation with code examples
**Location:** `languages/{language}/guides/testing/`
**Interfaces:** References `standards/testing/unit-testing.md`
**Dependencies:** Core unit testing standard

**Required Updates for Each Language:**
1. Add reference to `standards/testing/unit-testing.md` at the top
2. Map each FR to language-specific implementation
3. Show framework-specific examples (e.g., JUnit 5, pytest, Jest)
4. Demonstrate AAA pattern in the language (FR-23)
5. Show object mother pattern implementation (FR-17)
6. Provide coverage tool configuration (JaCoCo, coverage.py, Istanbul, etc.)
7. Include CI/CD integration examples

**Languages to Update:**
- Java (`languages/java/guides/testing/testing.md`) - Already comprehensive, needs standard reference
- Go (`languages/go/guides/testing/`) - Needs full guide creation
- Python (`languages/python/guides/testing/`) - Needs full guide creation
- TypeScript (`languages/typescript/guides/testing/`) - Needs full guide creation
- Kotlin (`languages/kotlin/guides/testing/`) - Needs full guide creation
- Swift (`languages/swift/guides/testing/`) - Needs full guide creation

### Component 3: Repository Metadata Updates
**Responsibility:** Ensure new standard is discoverable and navigable
**Technology:** Markdown documentation
**Location:** Multiple files
**Interfaces:** N/A
**Dependencies:** Core standard

**Files to Update:**
1. `standards/README.md` - Add unit testing standard to catalog
2. `standards/testing/README.md` - Create if doesn't exist, list standards
3. `standards/AGENTS.md` - Update AI navigation to include unit testing
4. `languages/README.md` - Note that guides reference unit testing standard
5. Root `README.md` - Mention unit testing standard if applicable

### Component 4: Examples and Templates (Future)
**Responsibility:** Provide concrete examples of tests following the standard
**Technology:** Code examples in multiple languages
**Location:** `languages/{language}/examples/testing/`
**Interfaces:** Referenced by language guides
**Dependencies:** Language guides, core standard

**Scope:** Out of scope for initial architecture implementation, but planned for future enhancement

---

## Data Models

**N/A** - This is a documentation standard. No data models, databases, or APIs.

However, the standard defines **conceptual models**:

### Test Structure Model (FR-15)
```
Test
├── Arrange Phase
│   ├── Test data setup
│   ├── Mock configuration
│   └── Preconditions
├── Act Phase (single action)
│   └── Method/function execution
└── Assert Phase
    ├── Result verification
    └── Mock verification
```

### Test Coverage Model (FR-1, FR-21, FR-22)
```
Code Coverage
├── New Code: Must achieve >90%
├── Legacy Code: Cannot decrease
└── Generated Code: Must be tested (no exemptions)
```

### Test Data Model (FR-17)
```
Object Mother Pattern
└── TestDataBuilder
    ├── Default values
    ├── Fluent builder methods
    └── Build() method returns test object
```

---

## Documentation Structure

### Primary Standard Document: `standards/testing/unit-testing.md`

**Outline:**
```markdown
# Unit Testing Standard

## Overview
- Purpose and scope
- When to use this standard
- Relationship to language guides

## Core Principles
- Why unit testing matters
- Testing pyramid
- Fast feedback
- Test as documentation

## Coverage Requirements

### Minimum Coverage (FR-1)
- >90% code coverage requirement
- Branch vs line coverage
- How to measure

### Requirements Traceability (FR-2)
- Every functional requirement needs tests
- Naming tests to reflect requirements
- Documentation approach

### Legacy Code Strategy (FR-21)
- Incremental improvement
- No coverage decrease allowed
- When adding new features to legacy code

### Generated Code Testing (FR-22)
- Must test generated code
- No blanket exemptions
- Strategies for testing code generators

## Dependency Management

### Mocking External Dependencies (FR-3)
- What constitutes external dependency
- When to mock vs use real implementations
- Mocks vs stubs vs fakes

### Contract-Based Mocking (FR-4)
- Using OpenAPI specs for API mocks
- Using database schemas for DB mocks
- Using Kafka contracts for event mocks
- Benefits and examples

## Test Structure

### Arrange-Act-Assert Pattern (FR-15)
- What is AAA
- Why use AAA
- Structure of each phase
- Visual examples

### Single Act Per Test (FR-20)
- One execution per test
- Why multiple acts indicate multiple tests
- Refactoring multi-act tests

### Framework Limitations (FR-23)
- Achieving AAA in all frameworks
- Workarounds for non-standard frameworks
- Language guide examples

## Test Quality

### Static Value Assertions (FR-7)
- Compare expected (static) vs actual (derived)
- Why avoid comparing two derived values
- Examples of good vs bad assertions

### Deterministic Tests (FR-9)
- What makes a test deterministic
- Avoiding external state
- Handling time/dates
- Dealing with randomness

### Atomic Tests (FR-10)
- Test independence
- No execution order dependencies
- No shared state
- Each test sets up own context

### Single Responsibility (FR-13)
- One functionality per test
- When multiple assertions are acceptable
- Breaking complex tests into focused ones

## Test Documentation

### Descriptive Test Names (FR-11)
- Naming patterns
- What to include in test names
- Good vs poor examples
- Language-agnostic guidance

### Test Comments (FR-12)
- Purpose and goal documentation
- When comments are needed
- What to include
- Examples

## Test Performance

### Execution Time (FR-14)
- Individual tests: sub-1-second (typically <100ms)
- Suite time scales with test count
- Dealing with slow tests
- Performance optimization

## Test Data Management

### No Magic Strings (FR-16)
- Named constants over literals
- Clear variable names
- Explaining test values
- Examples

### Object Mother Pattern (FR-17)
- What is object mother pattern
- Benefits over fixtures/setup
- Implementation approach
- Helper methods over setup/teardown

## Advanced Topics

### Testing Private Methods (FR-18)
- Test through public API
- When to extract private methods
- Behavior vs implementation testing

### Seams for Static Dependencies (FR-19)
- What are seams
- Using seams for testability
- Refactoring for testability
- Examples

## Workflow Integration

### CI/CD Integration (FR-6)
- Pre-commit hooks
- CI/CD pipeline requirements
- Failing builds on test failure
- Performance constraints

### All Tests Must Pass (FR-8)
- No failing tests in codebase
- Handling flaky tests
- Disabling tests (discouraged)

## Language-Specific Implementation (FR-5)

### Reference Links
- Java: [Link to Java testing guide]
- Go: [Link to Go testing guide]
- Python: [Link to Python testing guide]
- TypeScript: [Link to TypeScript testing guide]
- Kotlin: [Link to Kotlin testing guide]
- Swift: [Link to Swift testing guide]

### What Language Guides Provide
- Specific testing frameworks
- Mocking libraries
- Coverage tools
- Folder structure
- Naming conventions
- Complete code examples

## Compliance Checklist

### Before Committing
- [ ] All tests pass (FR-8)
- [ ] Coverage ≥90% (FR-1)
- [ ] Tests follow AAA pattern (FR-15)
- [ ] Test names are descriptive (FR-11)
- [ ] Tests are deterministic (FR-9)
- [ ] Tests are atomic (FR-10)
- [ ] All dependencies mocked (FR-3)
- [ ] Tests execute quickly (FR-14)

### Code Review
- [ ] Requirements have tests (FR-2)
- [ ] Contract-based mocks used (FR-4)
- [ ] No magic strings (FR-16)
- [ ] Object mother pattern used (FR-17)
- [ ] Single responsibility per test (FR-13)
- [ ] Static assertions used (FR-7)
- [ ] Legacy code coverage maintained (FR-21)

## Examples

### Good Test Example (Conceptual)
```
Test: CalculateDiscount_WithValidCoupon_ReturnsDiscountedPrice

// Arrange
order = createOrder(price: 100.00)
coupon = createCoupon(code: "SAVE10", discount: 0.10)
service = new DiscountService()

// Act
result = service.calculateDiscount(order, coupon)

// Assert
expect(result.finalPrice).toEqual(90.00)  // Static value
expect(result.discountApplied).toEqual(10.00)
```

See language guides for language-specific examples.

## References
- Language implementation guides (see FR-5)
- Testing pyramid concept
- Object mother pattern literature
- AAA pattern resources
```

---

## Technology Stack

**Documentation:**
- Format: Markdown (`.md`)
- Style: GitHub Flavored Markdown
- Links: Relative paths for internal references
- Code blocks: Language-tagged for syntax highlighting

**Tools (Referenced, Not Included):**
- Coverage tools: JaCoCo (Java), coverage.py (Python), Istanbul (TypeScript), go cover (Go)
- Testing frameworks: JUnit 5 (Java), pytest (Python), Jest (TypeScript), go test (Go)
- Mocking frameworks: Mockito (Java), unittest.mock (Python), jest.mock (TypeScript), gomock (Go)

**Repository:**
- Git for version control
- GitHub for hosting
- Markdown rendering via GitHub

---

## Standards Compliance

This architecture follows rr-standards repository conventions:

**Documentation Structure (CLAUDE.md):**
- ✅ Language-agnostic standard in `standards/`
- ✅ Language-specific guides in `languages/`
- ✅ Clear separation of WHAT (standard) vs HOW (guides)
- ✅ README.md and AGENTS.md for navigation
- ✅ Relative links for cross-references

**File Naming (CLAUDE.md):**
- ✅ Lowercase with dashes: `unit-testing.md`
- ✅ README.md for catalogs
- ✅ AGENTS.md for AI navigation

**Markdown Style (CLAUDE.md):**
- ✅ Single H1 header per file
- ✅ Code blocks with language tags
- ✅ Relative links to other docs
- ✅ Examples before theory where possible

**Content Quality (CLAUDE.md):**
- ✅ Clear purpose stated upfront
- ✅ Complete examples provided
- ✅ "Why" explained, not just "how"
- ✅ Related content linked
- ✅ No duplication across files

---

## Implementation Phases

### Phase 1: Core Standard Creation
**Goal:** Create the language-agnostic standard document
**Deliverables:**
- `standards/testing/unit-testing.md` (complete standard with all 23 FRs)
- All sections written with clear guidance
- Conceptual examples (language-agnostic)

**Estimated Effort:** 1 epic, 8-12 stories

### Phase 2: Repository Integration
**Goal:** Make standard discoverable and navigable
**Deliverables:**
- `standards/README.md` updated with new standard
- `standards/testing/README.md` created (if needed)
- `standards/AGENTS.md` updated
- Root `README.md` updated (if applicable)

**Estimated Effort:** 1-2 stories

### Phase 3: Language Guide Updates
**Goal:** Update existing guides to reference and implement the standard
**Deliverables:**
- Java guide updated (add reference, fill gaps)
- Go guide created or updated
- Python guide created or updated
- TypeScript guide created or updated
- Kotlin guide created or updated
- Swift guide created or updated

**Estimated Effort:** 2-4 stories per language (12-24 stories total)

### Phase 4: Validation and Examples
**Goal:** Ensure standard is complete, clear, and usable
**Deliverables:**
- Review by development teams
- Add missing examples or clarifications
- Create sample test code (optional)
- Documentation testing

**Estimated Effort:** 2-4 stories

---

## Security Considerations

**N/A** - This is a documentation standard. However, the standard promotes security by:
- Encouraging comprehensive testing (FR-1) which catches bugs before production
- Requiring deterministic tests (FR-9) which prevents security issues from non-deterministic behavior
- Mandating all tests pass before commit (FR-8) which prevents vulnerable code from merging

**Documentation Security:**
- No sensitive information in documentation
- No credentials or API keys in examples
- Public repository appropriate (documentation only)

---

## Performance Considerations

**Documentation Performance:**
- Markdown files are lightweight and fast to render
- Relative links enable fast navigation
- No build process required

**Test Performance (Defined by Standard):**
- FR-14: Individual unit tests must execute in sub-1-second times (typically <100ms)
- Suite time scales linearly with test count
- Fast feedback enables rapid development

**Standard Impact on Development:**
- Faster PR reviews (clear quality criteria)
- Faster debugging (comprehensive test coverage)
- Faster onboarding (documented testing practices)

---

## Error Handling

**N/A** - This is documentation, not executable code.

However, the standard addresses error handling in tests:
- FR-13: Tests should verify error cases (single responsibility extends to error paths)
- Tests must verify expected exceptions
- Error messages should be tested for clarity

---

## Monitoring and Observability

**N/A** - Documentation doesn't require monitoring.

However, adoption can be monitored via:
- Code review feedback (referencing the standard)
- Coverage metrics (trending toward 90%)
- CI/CD metrics (test execution time, pass rates)
- Developer surveys (understanding and adoption)

---

## Trade-offs and Alternatives

### Decision 1: Single Standard File vs Multiple Files
**Decision:** Create single comprehensive `unit-testing.md` file

**Rationale:**
- Easier to navigate (single source of truth)
- Simpler to reference from language guides
- Follows pattern of `standards/api/rest.md` (comprehensive single file)

**Trade-off:**
- Large file (may be 200-300 lines)
- Mitigation: Clear table of contents, good heading structure

**Alternative Considered:** Split into multiple files (`coverage.md`, `mocking.md`, `structure.md`)
- **Rejected because:** Harder to maintain consistency, more complex navigation

### Decision 2: Object Mother vs Other Test Data Patterns
**Decision:** Standardize on object mother pattern (FR-17)

**Rationale:**
- Explicit over implicit (helper methods > setup/teardown)
- Flexible and readable
- Works across languages

**Trade-off:**
- More verbose than fixtures in some cases
- Mitigation: Show clear examples, explain benefits

**Alternative Considered:** Test fixtures, factory patterns, builders
- **Partially accepted:** Object mother IS a builder pattern, can coexist with factories

### Decision 3: >90% Coverage Threshold
**Decision:** Require >90% code coverage (FR-1)

**Rationale:**
- Industry standard for high-quality software
- Balances thoroughness with pragmatism
- Allows exceptions for trivial code

**Trade-off:**
- May feel restrictive for some teams
- Risk of "testing for coverage" rather than value
- Mitigation: FR-21 allows incremental improvement, emphasis on quality over quantity

**Alternative Considered:** 80% threshold (more lenient) or 100% (more strict)
- **Rejected because:** 80% too low for critical systems, 100% unrealistic

### Decision 4: Sub-1-Second Per Test
**Decision:** Individual tests must execute in sub-1-second times, typically <100ms (FR-14)

**Rationale:**
- Fast feedback is crucial for TDD
- Encourages proper unit test design
- Scales to hundreds of tests

**Trade-off:**
- May require refactoring slow tests
- Some setup-heavy tests may struggle
- Mitigation: Move slow tests to integration tests, optimize test data creation

**Alternative Considered:** Allow up to 1 second per test (more lenient)
- **Partially accepted:** Sub-1-second is the target, with typical performance <100ms

### Decision 5: Language-Agnostic Standard First
**Decision:** Create comprehensive language-agnostic standard before language guides

**Rationale:**
- Single source of truth prevents duplication
- Ensures consistency across languages
- Easier to maintain and evolve
- Follows rr-standards architecture pattern

**Trade-off:**
- Abstract concepts without concrete examples
- Mitigation: Link to language guides, provide conceptual examples

**Alternative Considered:** Create language guides first, extract commonality later
- **Rejected because:** Leads to duplication, inconsistency, harder to maintain

### Decision 6: Update Existing Java Guide vs Start Fresh
**Decision:** Update existing `languages/java/guides/testing/testing.md` to reference standard

**Rationale:**
- Java guide already comprehensive and high-quality
- Already implements most requirements
- Just needs to reference standard and fill gaps

**Trade-off:**
- Need to ensure consistency between guide and standard
- Mitigation: Careful mapping of guide sections to FRs

**Alternative Considered:** Rewrite Java guide from scratch
- **Rejected because:** Wasteful, existing guide is good quality

---

## Resolved Questions

All open questions have been resolved:

### Question 1: Strategy.md File Handling ✅
**Decision:** Keep both files
- `strategy.md` will define high-level testing concepts in the future (test pyramid, testing types, strategy overview)
- `unit-testing.md` will contain the detailed 23-requirement standard
**Rationale:** Separation of high-level strategy from detailed unit testing requirements
**Impact:** Clear documentation hierarchy, future-proof structure

### Question 2: AGENTS.md for standards/testing/ ✅
**Decision:** Yes, create AGENTS.md
**Rationale:** Maintains consistency with repository pattern, improves AI agent navigation
**Impact:** Better discoverability, follows rr-standards conventions
**Action:** Add to Phase 2 deliverables

### Question 3: Language Guide Update Priority ✅
**Decision:** By usage
**Priority Order:**
1. **Java** (highest usage, already comprehensive) - Update with standard reference
2. **Go** (based on adoption data)
3. **Python** (based on adoption data)
4. **TypeScript** (based on adoption data)
5. **Kotlin** (based on adoption data)
6. **Swift** (based on adoption data)

**Rationale:** Maximize impact by prioritizing most-used languages
**Impact:** Faster ROI, better resource allocation
**Note:** Actual usage data should determine exact order for languages 2-6

### Question 4: Mutation Testing ✅
**Decision:** Yes, reserve space for mutation testing as future enhancement
**Rationale:** Acknowledge advanced testing technique while keeping initial scope focused
**Impact:** Architecture accommodates future growth
**Implementation:** Add "Future Enhancements" section to standard mentioning mutation testing

### Question 5: Test Design Process Integration ✅
**Decision:** Reference existing test design guide
**Context:** No `templates/test-design-template.md` exists, but `docs/workflows/guides/test-design-process.md` does exist
**Action:**
- Reference `docs/workflows/guides/test-design-process.md` in workflow integration section (FR-6)
- Consider creating template in future if needed
**Impact:** Connects unit testing standard to broader test planning workflow

### Question 6: Code Examples in Standard ✅
**Decision:** Standard can include pseudo-code only
**Guidelines:**
- Use pseudo-code/conceptual examples in standard
- Keep examples language-agnostic and clearly marked as conceptual
- Always include explicit links to language guides for real implementations
- Examples should illustrate concepts, not provide copy-paste code
**Rationale:** Maintains language-agnostic nature while providing clarity
**Impact:** Standard remains maintainable and truly language-agnostic

---

## Success Metrics

### Documentation Quality Metrics
- ✅ All 23 functional requirements addressed in standard
- ✅ Each requirement has clear guidance with rationale
- ✅ Zero broken links in documentation
- ✅ Standard can be read in < 30 minutes
- ✅ Language guides successfully reference standard

### Adoption Metrics
- ✅ Standard referenced by 3+ language guides within 3 months
- ✅ At least 1 language guide fully implements all 23 requirements
- ✅ Development teams use standard in code reviews
- ✅ New projects adopt standard from day 1

### Quality Impact Metrics
- ✅ New code consistently meets >90% coverage
- ✅ Code coverage trends upward in legacy codebases
- ✅ Reduction in production bugs catchable by unit tests
- ✅ Test execution times meet performance targets

### Developer Experience Metrics
- ✅ Positive feedback on clarity and usefulness
- ✅ Reduced ambiguity in code reviews about test quality
- ✅ Faster onboarding for new developers
- ✅ Fewer questions about "how to write good tests"

---

## Next Steps

### Immediate Actions (Architecture Phase Complete)
1. ✅ Review this architecture document
2. ✅ Resolve open questions (ALL RESOLVED)
3. ✅ Ready for plan generation

### Phase 1: Create Core Standard
1. Generate implementation plan with `/generate-plan unit-testing-standards`
2. Break down into specific tasks (epics → stories → tasks)
3. Implement `standards/testing/unit-testing.md` with all 23 requirements
4. Add examples and rationale for each requirement
5. Create comprehensive compliance checklist

### Phase 2: Repository Integration
1. Update `standards/README.md`
2. Create/update `standards/testing/README.md`
3. Update `standards/AGENTS.md`
4. Verify navigation and discoverability

### Phase 3: Language Guide Updates
1. Start with Java (highest priority, already comprehensive)
2. Continue with Go, Python, TypeScript
3. Complete with Kotlin, Swift
4. Each guide references standard and provides concrete examples

### Phase 4: Validation
1. Team reviews and feedback
2. Add missing examples or clarifications
3. Mark architecture and plan as complete
4. Begin implementation

---

## Conclusion

This architecture provides a comprehensive blueprint for creating a language-agnostic unit testing standard that will:
- Establish consistent testing practices across all Rewards services
- Provide clear, actionable guidance for developers
- Support incremental adoption in existing codebases
- Integrate seamlessly with CI/CD workflows
- Scale across 6 programming languages

The standard addresses all 23 functional requirements from the requirements phase while maintaining flexibility for language-specific implementations. The phased approach ensures quality and allows for feedback at each stage.

**Ready for plan generation:** This architecture is complete and ready for the next phase.
