# Spec-Driven Development Workflow: Enhancement Plan

## Executive Summary

This plan enhances our existing spec-driven development workflow by incorporating proven concepts from BMAD-METHOD, focusing on QA integration, risk management, and brownfield support while maintaining our core strengths: simplicity, Claude Code optimization, and team collaboration.

**Timeline:** 3-5 days of implementation
**Effort:** Low to Medium
**Impact:** High (addresses critical QA gap without complexity overhead)

---

## Current State Analysis

### Our Strengths (Preserve These)
- ✅ Simple 4-stage linear workflow (Requirements → Architecture → Plan → Implementation)
- ✅ Claude Code native features (Plan Mode, skills, slash commands, hooks)
- ✅ Team collaboration focus with explicit refinement sessions
- ✅ Progressive context loading (single source of truth)
- ✅ rr-standards git submodule integration
- ✅ Lightweight (no external dependencies)
- ✅ Git-friendly markdown files

### Critical Gaps (Address These)
- ❌ Weak QA integration (no dedicated tooling)
- ❌ No risk assessment framework
- ❌ No test design automation or guidance
- ❌ Tests written DURING development (not designed BEFORE)
- ❌ No brownfield/existing codebase support
- ❌ No NFR (non-functional requirements) validation

---

## Enhancement Strategy

### Philosophy
**"Enhance, Don't Complicate"**

We will add lightweight QA scaffolding that integrates seamlessly into our existing workflow without requiring new skills, additional complexity, or changing the core 4-stage process.

### Approach
1. **Add structure to existing documents** (not new tools)
2. **Provide templates and checklists** (not automation)
3. **Guide humans to make decisions** (not AI agents)
4. **Make QA visible and trackable** (not hidden)

---

## Detailed Enhancement Plan

## Enhancement 1: Risk Assessment in Planning

### Objective
Add risk rating to each story in the plan to prioritize testing efforts and surface high-risk areas early.

### Implementation

#### 1.1 Update Plan Template
**File:** `templates/plan-template.md`

Add risk assessment section to each story:

```markdown
### Story 1.1: [Story Name]

**Risk Rating:** [R1/R2/R3/R4] - [Risk Category]
**Risk Justification:** [1-2 sentence explanation of why this rating]

**As a** [role], **I want** [capability], **So that** [benefit]

**Acceptance Criteria:**
- [ ] Given/When/Then format
- [ ] ...

**Risk Factors:**
- Technical Complexity: [Low/Medium/High] - [Why?]
- Security Impact: [Low/Medium/High] - [Why?]
- Performance Impact: [Low/Medium/High] - [Why?]
- Business Impact: [Low/Medium/High] - [Why?]
- Integration Complexity: [Low/Medium/High] - [Why?]

**Testing Strategy (Based on Risk):**
- [What types of tests are needed?]
- [What edge cases must be covered?]
- [What performance targets exist?]

**Tasks:**
- [ ] EPIC#-### [Task description] [standards: api, security]
```

#### 1.2 Create Risk Assessment Guide
**File:** `docs/workflows/guides/risk-assessment-guide.md`

**Content:**
- Risk rating definitions (R1-R4)
- Risk probability × impact matrix
- Examples of each risk category
- When to escalate high-risk stories
- How to adjust testing based on risk

**Risk Rating Scale:**
- **R1 (Critical):** High probability + High impact = Score 9
  - Examples: Authentication changes, payment processing, data migrations
  - Testing: Comprehensive unit, integration, E2E, performance, security tests

- **R2 (High):** Medium-High probability + Medium-High impact = Score 6-8
  - Examples: Core feature changes, API modifications, database schema updates
  - Testing: Standard unit, integration, E2E tests with edge cases

- **R3 (Moderate):** Medium probability + Medium impact = Score 3-5
  - Examples: UI updates, new non-critical features, refactoring
  - Testing: Unit tests and key integration tests

- **R4 (Low):** Low probability + Low impact = Score 1-2
  - Examples: Logging improvements, minor UI tweaks, documentation
  - Testing: Basic unit tests

#### 1.3 Update plan-generator skill
**File:** `skills/workflow/plan-generator/SKILL.md`

Add instruction to:
- Analyze each story for risk factors
- Assign risk rating with justification
- Recommend testing strategy based on risk
- Flag R1 stories for team discussion

**Estimated Effort:** 4 hours

---

## Enhancement 2: Test Design Before Implementation

### Objective
Require test design to be completed before task implementation begins, preventing rework and ensuring comprehensive coverage.

### Implementation

#### 2.1 Create Test Design Template
**File:** `templates/test-design-template.md`

```markdown
# Test Design: [Feature Name] - [Story Name]

**Story:** [Story ID and description]
**Risk Rating:** [R1/R2/R3/R4]
**Author:** [Name]
**Date:** [Date]

## Test Strategy Summary
[High-level approach based on risk rating]

## Functional Test Scenarios

### Acceptance Criterion 1: [Description]

#### Scenario 1.1: [Happy Path]
- **Given:** [Preconditions]
- **When:** [Action]
- **Then:** [Expected outcome]
- **Test Data:** [What data is needed?]
- **Mocks/Stubs:** [What needs to be mocked?]

#### Scenario 1.2: [Edge Case]
- **Given:** [Preconditions]
- **When:** [Action]
- **Then:** [Expected outcome]

#### Scenario 1.3: [Error Case]
- **Given:** [Preconditions]
- **When:** [Action]
- **Then:** [Expected error handling]

### Acceptance Criterion 2: [Description]
[Repeat for each AC]

## Non-Functional Test Requirements

### Performance
- **Target Latency:** [e.g., < 200ms p95]
- **Target Throughput:** [e.g., 1000 req/s]
- **Load Test Scenario:** [Description]

### Security
- [ ] Authentication required?
- [ ] Authorization checks needed?
- [ ] Input validation requirements?
- [ ] Sensitive data handling?
- [ ] Security test cases: [List]

### Reliability
- [ ] Error handling scenarios
- [ ] Retry logic needed?
- [ ] Fallback behavior?
- [ ] Circuit breaker needed?

### Integration
- [ ] External service dependencies
- [ ] Integration test approach
- [ ] Contract testing needed?
- [ ] E2E test scope

## Test Data Requirements
| Scenario | Data Needed | Setup Method |
|----------|-------------|--------------|
| [Scenario] | [Data] | [How to create] |

## Test Environment Requirements
- [What environments are needed?]
- [What services must be running?]
- [What configuration is required?]

## Coverage Target
- **Unit Test Coverage:** [e.g., 90% for R1/R2, 80% for R3/R4]
- **Integration Test Coverage:** [Key integration points]
- **E2E Test Coverage:** [Critical user paths]

## Open Questions
- [Any unknowns that need clarification?]

## Sign-off
- [ ] Product Owner reviewed scenarios
- [ ] QA reviewed test strategy
- [ ] Developer confirmed feasibility
- [ ] Ready for implementation
```

#### 2.2 Create Test Design Process Guide
**File:** `docs/workflows/guides/test-design-process.md`

**Content:**
- When to create test design (before implementation)
- Who should participate (Dev + QA + PO for R1/R2)
- How to translate ACs into test scenarios
- How to identify edge cases
- How to determine NFR targets
- Test design checklist

#### 2.3 Update workflow stages
**File:** `docs/workflows/SPEC_DRIVEN_DEVELOPMENT.md`

Add new sub-stage between Stage 3 (Plan) and Stage 4 (Implementation):

**Stage 3.5: Test Design (For R1/R2 Stories)**

**Input:** Plan with stories and risk ratings
**Output:** Test design documents for high-risk stories
**Who's Involved:** Developer + QA Lead + Product Owner (for R1)

**Process:**
1. For each R1 and R2 story, create test design using template
2. Conduct test design review meeting (15-30 min per story)
3. Refine based on feedback
4. Get sign-off before implementation begins

**Artifact:** `<feature>/test-design/<story-id>-test-design.md`

#### 2.4 Update task-implementer skill
**File:** `skills/workflow/task-implementer/SKILL.md`

Add check at the beginning:
```markdown
## Pre-Implementation Check

Before starting implementation:

1. **Load test design** (if story is R1 or R2):
   - Check for `<feature>/test-design/<story-id>-test-design.md`
   - If missing for R1/R2 story, prompt: "This is a R1/R2 story. Test design should be completed first. Would you like to create it now or proceed without it?"

2. **Review test scenarios** to understand:
   - What edge cases must be handled
   - What error conditions must be addressed
   - What performance targets exist
   - What security requirements apply

3. **Reference throughout implementation** to ensure all scenarios are covered
```

**Estimated Effort:** 5 hours

---

## Enhancement 3: Quality Checklist and Gates

### Objective
Provide structured checklist for validating story completion, ensuring nothing is missed.

### Implementation

#### 3.1 Create QA Review Checklist
**File:** `templates/qa-review-checklist.md`

```markdown
# QA Review Checklist: [Feature Name] - [Story Name]

**Story:** [Story ID]
**Risk Rating:** [R1/R2/R3/R4]
**Reviewer:** [Name]
**Date:** [Date]

## 1. Requirements Traceability

### Acceptance Criteria Coverage
- [ ] All acceptance criteria implemented
- [ ] Each AC has corresponding tests
- [ ] Tests pass in CI/CD

**Notes:** [Any gaps or concerns?]

## 2. Functional Testing

### Test Execution
- [ ] All planned test scenarios executed
- [ ] Happy paths validated
- [ ] Edge cases validated
- [ ] Error cases validated
- [ ] Manual testing completed (if applicable)

### Test Results
- [ ] All tests passing
- [ ] No flaky tests
- [ ] Test coverage meets target

**Coverage Report:**
- Unit: [X%]
- Integration: [Y%]
- E2E: [Z%]

**Notes:** [Test failures, skipped tests, coverage gaps?]

## 3. Non-Functional Requirements

### Performance (R1/R2 only)
- [ ] Load testing completed
- [ ] Latency targets met: [target] → [actual]
- [ ] Throughput targets met: [target] → [actual]
- [ ] No memory leaks detected
- [ ] Database query performance acceptable

**Notes:** [Performance concerns?]

### Security
- [ ] Authentication implemented correctly
- [ ] Authorization checks in place
- [ ] Input validation present
- [ ] Sensitive data encrypted/protected
- [ ] Security tests passing
- [ ] No new security vulnerabilities (scan results)

**Notes:** [Security concerns?]

### Reliability
- [ ] Error handling comprehensive
- [ ] Retries implemented where needed
- [ ] Fallbacks configured
- [ ] Logging adequate for debugging
- [ ] Monitoring/alerts configured

**Notes:** [Reliability concerns?]

## 4. Code Quality

### Standards Compliance
- [ ] Follows rr-standards for: [list relevant standards]
- [ ] Code style consistent
- [ ] No linter errors
- [ ] No type errors (if applicable)

### Code Review
- [ ] PR approved by [number] reviewers
- [ ] All review comments addressed
- [ ] No unresolved discussions

### Documentation
- [ ] Code comments adequate
- [ ] API documentation updated
- [ ] README updated (if needed)
- [ ] Migration guide provided (if breaking change)

**Notes:** [Code quality concerns?]

## 5. Integration

### Dependencies
- [ ] All dependencies tested
- [ ] External service integrations validated
- [ ] Database migrations tested (up and down)
- [ ] No breaking changes to existing APIs (or properly versioned)

### Backwards Compatibility
- [ ] Existing functionality unaffected
- [ ] Regression tests passing
- [ ] Feature flags used (if needed)

**Notes:** [Integration concerns?]

## 6. Architecture Compliance

### Design Adherence
- [ ] Follows architecture.md design
- [ ] No architectural violations
- [ ] Appropriate design patterns used
- [ ] Separation of concerns maintained

**Notes:** [Architecture concerns?]

## 7. Operational Readiness

### Deployment
- [ ] Deployment plan documented
- [ ] Rollback plan documented
- [ ] Database migrations safe
- [ ] Environment variables documented
- [ ] Configuration changes documented

### Observability
- [ ] Metrics instrumented
- [ ] Logs provide actionable information
- [ ] Alerts configured for failures
- [ ] Dashboards updated

**Notes:** [Operational concerns?]

## 8. Risk-Specific Checks

### For R1 Stories Only
- [ ] Security penetration testing completed
- [ ] Performance testing under peak load
- [ ] Disaster recovery tested
- [ ] Customer impact analysis completed
- [ ] Rollback procedure tested

### For R2 Stories Only
- [ ] Integration testing with dependent services
- [ ] Performance testing under normal load
- [ ] Error scenario testing comprehensive

**Notes:** [Risk-specific concerns?]

## Quality Gate Decision

**Overall Assessment:**
- ✅ **PASS** - Ready for production, all criteria met
- ⚠️ **PASS WITH CONCERNS** - Can deploy but has minor issues (document below)
- ❌ **FAIL** - Not ready, critical issues must be resolved
- 🔄 **WAIVED** - Known issues accepted by Product Owner (document below)

**Decision:** [PASS / PASS WITH CONCERNS / FAIL / WAIVED]

**Justification:** [Explain decision, especially for CONCERNS/FAIL/WAIVED]

## Issues Found

| Severity | Issue | Status | Owner |
|----------|-------|--------|-------|
| [Critical/Major/Minor] | [Description] | [Open/Resolved/Waived] | [Name] |

## Follow-up Actions

- [ ] [Action item 1] - Owner: [Name] - Due: [Date]
- [ ] [Action item 2] - Owner: [Name] - Due: [Date]

## Sign-off

- **QA Lead:** [Name] - [Date]
- **Tech Lead:** [Name] - [Date]
- **Product Owner (R1 only):** [Name] - [Date]
```

#### 3.2 Create QA Process Guide
**File:** `docs/workflows/guides/qa-process-guide.md`

**Content:**
- When to perform QA review (before merging to main)
- Who performs review (QA lead or designated reviewer)
- How to use the checklist
- What each gate decision means
- When to escalate
- How to track issues found

#### 3.3 Update workflow documentation
Add QA review as final step before story completion in Stage 4.

**Estimated Effort:** 4 hours

---

## Enhancement 4: Brownfield Workflow Guide

### Objective
Provide guidance for using spec-driven development with existing codebases.

### Implementation

#### 4.1 Create Brownfield Workflow Guide
**File:** `docs/workflows/guides/brownfield-workflow.md`

```markdown
# Spec-Driven Development for Existing Codebases

## Overview

This guide adapts the spec-driven development workflow for brownfield projects (existing codebases). The core workflow remains the same, but with additional considerations for existing code, technical debt, and regression risk.

## Key Differences from Greenfield

| Aspect | Greenfield | Brownfield |
|--------|------------|------------|
| Stage 1 | Define requirements | **+ Understand current state** |
| Stage 2 | Design architecture | **+ Assess existing architecture** |
| Stage 3 | Create plan | **+ Identify refactoring needs** |
| Stage 4 | Implement | **+ Regression testing strategy** |

## Brownfield-Specific Workflow

### Pre-Stage 1: Codebase Analysis

**Before starting requirements, understand what exists:**

#### 1. Use Claude Code's Plan Mode
```
Enter Plan Mode and analyze:
- What is the current architecture?
- What patterns are used?
- What are the main components?
- What is the test coverage?
- What technical debt exists?
```

#### 2. Create Current State Document
**File:** `<feature>/current-state.md`

```markdown
# Current State Analysis: [Feature Area]

## Existing Functionality
[What does the system do today in this area?]

## Current Architecture
[How is it built?]
- Components involved
- Data flow
- External dependencies
- Database schema

## Current Test Coverage
- Unit tests: [X%]
- Integration tests: [Y%]
- E2E tests: [Z%]
- Key gaps: [What's not tested?]

## Technical Debt
- [Issue 1] - Impact: [High/Medium/Low]
- [Issue 2] - Impact: [High/Medium/Low]

## Constraints
- [Cannot change X because Y]
- [Must maintain backwards compatibility with Z]

## Opportunities for Improvement
- [Opportunity 1]
- [Opportunity 2]
```

#### 3. Flatten the Codebase (Optional)
For large codebases, create a flattened view:

```bash
# Create directory structure overview
find . -type f -name "*.ts" -o -name "*.js" | head -100 > structure.txt

# Create code summary (use Claude)
# "Analyze these files and create a summary of the main components,
# their responsibilities, and how they interact"
```

### Stage 1: Requirements (Brownfield Adapted)

**Standard requirements.md PLUS:**

#### Additional Section: Impact on Existing System

```markdown
## Impact on Existing System

### Affected Components
- [Component 1] - Changes: [Modify/Replace/Deprecate]
- [Component 2] - Changes: [Modify/Replace/Deprecate]

### Breaking Changes
- [Change 1] - Mitigation: [How to handle?]
- [Change 2] - Mitigation: [How to handle?]

### Migration Requirements
- Data migration needed? [Yes/No] - [Details]
- API versioning needed? [Yes/No] - [Details]
- Feature flags needed? [Yes/No] - [Details]

### Backwards Compatibility
- [What must remain compatible?]
- [What can be deprecated?]
- [What is the deprecation timeline?]

### Regression Risk
- **High Risk Areas:** [What could break?]
- **Testing Strategy:** [How to prevent regression?]
- **Rollback Plan:** [How to undo if needed?]
```

### Stage 2: Architecture (Brownfield Adapted)

**Standard architecture.md PLUS:**

#### Additional Sections:

```markdown
## Existing Architecture Assessment

### What to Keep
- [Existing pattern/component 1] - Rationale: [Why?]
- [Existing pattern/component 2] - Rationale: [Why?]

### What to Modify
- [Existing pattern/component 1] - Changes: [What?] - Rationale: [Why?]
- [Existing pattern/component 2] - Changes: [What?] - Rationale: [Why?]

### What to Replace
- [Existing pattern/component 1] - Replacement: [What?] - Rationale: [Why?]
- [Existing pattern/component 2] - Replacement: [What?] - Rationale: [Why?]

### Technical Debt to Address
- [Debt item 1] - Resolution: [How?]
- [Debt item 2] - Resolution: [How?]

### Technical Debt to Defer
- [Debt item 1] - Reason: [Why defer?] - Tracked in: [Issue #]
- [Debt item 2] - Reason: [Why defer?] - Tracked in: [Issue #]

## Migration Strategy

### Phase 1: Foundation
[What groundwork is needed?]

### Phase 2: Incremental Migration
[How to migrate gradually?]

### Phase 3: Cutover
[When/how to complete migration?]

### Rollback Plan
[How to revert if needed?]
```

### Stage 3: Plan (Brownfield Adapted)

**Standard plan.md PLUS:**

#### Risk Assessment Focus Areas

**For Brownfield, always assess:**
- **Regression Risk:** [High/Medium/Low] - What existing functionality could break?
- **Migration Risk:** [High/Medium/Low] - What could go wrong during data/code migration?
- **Integration Risk:** [High/Medium/Low] - What external systems could be affected?

#### Brownfield-Specific Stories

Consider adding stories for:
- **Story X.0:** Setup and preparation
  - Feature flags
  - Monitoring
  - Rollback mechanisms

- **Story X.1-X.N:** Core feature stories (standard)

- **Story X.99:** Cleanup and deprecation
  - Remove old code
  - Update documentation
  - Deprecation notices

### Stage 4: Implementation (Brownfield Adapted)

**Standard implementation PLUS:**

#### Regression Testing Requirements

Before implementing any task:

1. **Identify Existing Tests**
   ```bash
   # Find tests related to area you're modifying
   /explore tests for [component name]
   ```

2. **Run Existing Tests**
   ```bash
   # Establish baseline - all tests should pass before you start
   npm test -- [test pattern]
   ```

3. **Implement Task**
   - Follow standard task-implementer process
   - Write new tests for new functionality

4. **Run All Tests**
   ```bash
   # Ensure no regressions
   npm test
   ```

5. **Document Impact**
   Update task checklist:
   ```markdown
   - [ ] New functionality implemented
   - [ ] New tests written and passing
   - [ ] Existing tests still passing (regression check)
   - [ ] Manual testing of affected areas
   - [ ] No breaking changes (or properly handled)
   ```

#### Refactoring Strategy

When refactoring existing code:

1. **Test First**
   - If no tests exist, write characterization tests
   - Lock down current behavior before changing

2. **Small Steps**
   - One refactoring at a time
   - Commit frequently
   - Tests pass after each commit

3. **No Mixed Commits**
   - Refactoring commits: Only structure changes
   - Feature commits: Only new functionality
   - Never both in same commit

#### Feature Flags (for High-Risk Changes)

For R1/R2 brownfield changes, use feature flags:

```markdown
## Feature Flag Strategy

**Flag Name:** `feature_<feature_name>_enabled`

**States:**
- `false` (default): Old behavior
- `true`: New behavior

**Rollout Plan:**
1. Deploy with flag OFF (0% users)
2. Enable for internal users (test in production)
3. Gradual rollout: 1% → 10% → 50% → 100%
4. Monitor metrics at each stage
5. Remove flag after 2 weeks at 100%

**Rollback Plan:**
- Set flag to `false` if issues detected
- No code deployment needed
```

## Brownfield Best Practices

### 1. Understand Before Changing
- Read the code you're modifying
- Understand why it was written that way
- Look for comments explaining past decisions
- Check git history for context

### 2. Respect Existing Patterns
- Follow established conventions
- Don't rewrite everything in your preferred style
- Consistency > perfection
- Save major refactoring for dedicated stories

### 3. Incremental Improvement
- Leave code better than you found it
- Fix small issues as you go (within reason)
- Don't try to solve all technical debt at once
- "Boy Scout Rule": Clean up your campsite

### 4. Comprehensive Testing
- Brownfield = higher regression risk
- Test more than you would in greenfield
- Focus on integration tests (components interact)
- Manual testing of related features

### 5. Documentation
- Update documentation as you change code
- Document "gotchas" you discover
- Explain non-obvious decisions
- Update architectural diagrams if they exist

### 6. Communication
- Notify team of changes to shared components
- Discuss breaking changes early
- Get extra code reviews for risky changes
- Pair with someone familiar with the area

## Common Brownfield Scenarios

### Scenario 1: Adding Feature to Existing Area

**Approach:**
1. Current state analysis
2. Design feature to fit existing architecture
3. Implement with feature flag (if risky)
4. Comprehensive regression testing

**Risk Level:** Medium
**Testing Strategy:** Standard + extra regression tests

### Scenario 2: Refactoring Existing Code

**Approach:**
1. Write characterization tests for current behavior
2. Refactor in small, safe steps
3. Tests pass after each step
4. Deploy incrementally

**Risk Level:** High
**Testing Strategy:** Extensive unit + integration + manual tests

### Scenario 3: Replacing Existing Component

**Approach:**
1. Build new component alongside old one
2. Feature flag to switch between old/new
3. Gradual rollout with monitoring
4. Remove old component after validation

**Risk Level:** Very High
**Testing Strategy:** Parallel testing, gradual rollout, easy rollback

### Scenario 4: Fixing Technical Debt

**Approach:**
1. Assess impact of technical debt
2. Create dedicated story for debt resolution
3. Ensure changes are backwards compatible
4. Update documentation and standards

**Risk Level:** Medium to High
**Testing Strategy:** Focus on unchanged behavior preservation

## Tools and Techniques

### Codebase Exploration
```bash
# Find all usages of a function/class
/explore usages of [function name]

# Find all files in an area
/glob "src/feature-area/**/*.ts"

# Search for patterns
/grep "pattern" --type ts
```

### Test Coverage Analysis
```bash
# Generate coverage report
npm run test:coverage

# Identify untested areas
# Focus on files you're about to modify
```

### Dependency Analysis
```bash
# Find what depends on component you're changing
# Use IDE tools or grep for imports
```

## Checklist: Brownfield Story Completion

Before marking a brownfield story complete:

- [ ] Current state documented
- [ ] Existing tests identified and passing
- [ ] New functionality implemented
- [ ] New tests written
- [ ] Regression tests passing
- [ ] Manual testing of affected areas
- [ ] No breaking changes (or properly handled with migration)
- [ ] Feature flag implemented (if R1/R2)
- [ ] Rollback plan documented and tested
- [ ] Documentation updated
- [ ] Team notified of changes
- [ ] QA review completed
- [ ] Deployed to staging and validated
- [ ] Ready for production

## When to Escalate

Escalate to Tech Lead or team if:
- Discovering significant technical debt blocking progress
- Finding architectural inconsistencies requiring discussion
- Identifying breaking changes with no clear mitigation
- Regression testing reveals unexpected dependencies
- Existing code quality makes changes risky

## Resources

- **Claude Code Plan Mode:** For codebase analysis
- **rr-standards:** Follow existing standards in codebase
- **Git History:** Use `git blame` and `git log` for context
- **Team Knowledge:** Ask developers familiar with the area
```

**Estimated Effort:** 5 hours

---

## Enhancement 5: Documentation Updates

### Objective
Update all workflow documentation to reflect new QA and risk management features.

### Implementation

#### 5.1 Update SPEC_DRIVEN_DEVELOPMENT.md
**File:** `docs/workflows/SPEC_DRIVEN_DEVELOPMENT.md`

Add/update sections:
- Stage 3: Add "Risk Assessment" step
- Stage 3.5: Add "Test Design (for R1/R2)"
- Stage 4: Add "QA Review" as final step
- Add "Brownfield Considerations" section
- Update examples to include risk ratings

#### 5.2 Update README
**File:** `README.md` (if applicable)

Add references to:
- Risk assessment guide
- Test design process
- QA checklist
- Brownfield workflow

#### 5.3 Create Quick Reference
**File:** `docs/workflows/guides/quick-reference.md`

```markdown
# Spec-Driven Development: Quick Reference

## Risk Ratings
- **R1:** Critical - Comprehensive testing required
- **R2:** High - Standard testing with edge cases
- **R3:** Moderate - Basic testing
- **R4:** Low - Minimal testing

## When to Create Test Design
- **Always:** For R1 stories
- **Recommended:** For R2 stories
- **Optional:** For R3/R4 stories

## QA Review Checklist
Use `templates/qa-review-checklist.md` before merging to main

## Quality Gates
- **PASS:** ✅ Ready for production
- **PASS WITH CONCERNS:** ⚠️ Can deploy with minor issues
- **FAIL:** ❌ Critical issues must be resolved
- **WAIVED:** 🔄 Known issues accepted by PO

## Brownfield Development
See `docs/workflows/guides/brownfield-workflow.md` for working with existing codebases
```

**Estimated Effort:** 3 hours

---

## Summary of Enhancements

| Enhancement | Files Created/Modified | Effort | Impact |
|-------------|----------------------|--------|--------|
| 1. Risk Assessment | 3 files (template, guide, skill) | 4 hrs | High |
| 2. Test Design | 4 files (template, guide, workflow, skill) | 5 hrs | High |
| 3. QA Checklist | 2 files (checklist, guide) | 4 hrs | High |
| 4. Brownfield Guide | 1 file (comprehensive guide) | 5 hrs | Medium |
| 5. Documentation | 4 files (updates) | 3 hrs | Medium |
| **TOTAL** | **14 files** | **21 hrs** | **High** |

---

## Implementation Timeline

### Day 1 (8 hours)
- ✅ Enhancement 1: Risk Assessment (4 hrs)
  - Update plan template
  - Create risk assessment guide
  - Update plan-generator skill
- ✅ Enhancement 2: Test Design - Part 1 (4 hrs)
  - Create test design template
  - Create test design process guide

### Day 2 (8 hours)
- ✅ Enhancement 2: Test Design - Part 2 (1 hr)
  - Update workflow documentation
  - Update task-implementer skill
- ✅ Enhancement 3: QA Checklist (4 hrs)
  - Create QA review checklist
  - Create QA process guide
- ✅ Enhancement 5: Documentation - Part 1 (3 hrs)
  - Update main workflow documentation
  - Create quick reference

### Day 3 (5 hours)
- ✅ Enhancement 4: Brownfield Guide (5 hrs)
  - Create comprehensive brownfield workflow guide

**Total: 21 hours = ~3 days of focused work**

---

## Files to Create/Modify

### New Files (11)
1. `docs/workflows/guides/risk-assessment-guide.md`
2. `docs/workflows/guides/test-design-process.md`
3. `docs/workflows/guides/qa-process-guide.md`
4. `docs/workflows/guides/brownfield-workflow.md`
5. `docs/workflows/guides/quick-reference.md`
6. `templates/test-design-template.md`
7. `templates/qa-review-checklist.md`

### Modified Files (3)
1. `templates/plan-template.md` - Add risk assessment sections
2. `skills/workflow/plan-generator/SKILL.md` - Add risk analysis instructions
3. `skills/workflow/task-implementer/SKILL.md` - Add test design check
4. `docs/workflows/SPEC_DRIVEN_DEVELOPMENT.md` - Add QA stages

---

## Validation Plan

### After Implementation
1. **Test with pilot feature:**
   - Pick a R2 story from a real feature
   - Walk through enhanced workflow
   - Gather feedback

2. **Measure effectiveness:**
   - Did risk assessment surface real risks?
   - Did test design prevent rework?
   - Was QA checklist helpful?
   - Did brownfield guide address real challenges?

3. **Iterate based on feedback:**
   - Simplify if too complex
   - Add clarity where confused
   - Fix templates based on usage

### Success Criteria
- ✅ Team can follow new process without confusion
- ✅ High-risk stories identified and tested more thoroughly
- ✅ Test design catches issues before implementation
- ✅ QA checklist prevents missed items
- ✅ Brownfield projects have clear guidance
- ✅ No significant slowdown in velocity

---

## Benefits of This Approach

### 1. Lightweight
- No new skills or agents to learn
- No external dependencies
- Just templates and guides

### 2. Flexible
- Use risk assessment always, test design for R1/R2
- QA checklist scales with risk
- Brownfield guide is optional reference

### 3. Educational
- Guides teach best practices
- Templates show what "good" looks like
- Checklists prevent forgetting

### 4. Integrated
- Fits seamlessly into 4-stage workflow
- Uses existing tools (Claude Code, git, markdown)
- Enhances without complicating

### 5. Actionable
- Clear deliverables (templates filled out)
- Trackable (checklists with checkboxes)
- Visible (markdown files in git)

---

## Future Enhancements (Out of Scope)

These are good ideas but not included in the 3-5 day plan:

- ❌ Automated risk scoring (requires AI skill)
- ❌ Test generation from acceptance criteria (requires AI skill)
- ❌ NFR validation automation (requires tooling)
- ❌ Quality gate enforcement (requires hooks/automation)
- ❌ Metrics dashboard (requires infrastructure)
- ❌ Codebase flattener tool (complex, BMAD-specific)

---

## Questions for Consideration

1. **Risk Rating Adoption:**
   - Should risk rating be mandatory or optional?
   - Who assigns the risk rating (Claude or human)?

2. **Test Design Threshold:**
   - Is R1/R2 the right threshold for mandatory test design?
   - Or should it be R1 only?

3. **QA Review:**
   - Who performs QA review (QA lead, peer, tech lead)?
   - Is review mandatory for all stories or just R1/R2?

4. **Brownfield:**
   - Is current-state analysis mandatory or optional?
   - Should there be a separate brownfield workflow or just a guide?

---

## Next Steps

1. **Review this plan** with team
2. **Answer questions** above
3. **Assign owner** for implementation
4. **Schedule pilot** with real feature
5. **Begin implementation** following timeline

---

## Appendix: Comparison to BMAD

| Feature | BMAD Method | Our Enhancement |
|---------|-------------|-----------------|
| Risk Assessment | 1-9 scoring, probability × impact | H/M/L per category, R1-R4 rating |
| Test Design | Quinn agent with *design command | Template + human process |
| QA Review | Quinn agent with *review, *gate | Checklist + human review |
| NFR Validation | Quinn agent with *nfr command | Checklist section |
| Brownfield | Flattener tool + dedicated workflows | Guide + Claude Plan Mode |
| Complexity | High (multiple agents, commands) | Low (templates, guides) |
| Automation | Heavy (AI-driven) | Light (AI-assisted) |
| Learning Curve | Steep | Gentle |
| Control | Framework-driven | Human-driven |

**Philosophy Difference:**
- **BMAD:** "AI agents do the QA work"
- **Our Approach:** "Humans do QA work with structured guidance"

Both are valid. Ours fits better with our "simple, lightweight, team-collaboration" philosophy while still borrowing BMAD's excellent QA concepts.
