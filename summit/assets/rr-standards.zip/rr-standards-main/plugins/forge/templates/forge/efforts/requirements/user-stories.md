# User Stories — {{effort_title}}

*Effort: {{effort_id}}*
*Derived from: [requirements/business.md](business.md)*
*Written: {{date}}*

---

## {{theme}}

- As a {{role}}, I want {{capability}} so that {{outcome}}.
