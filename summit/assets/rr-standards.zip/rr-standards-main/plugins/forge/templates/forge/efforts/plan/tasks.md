# Implementation Plan: [Effort Title]

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Foundation

### TASK-001 [auto][wave:1]

[One-sentence description of what this task produces or changes.]

**Satisfies:** [BR-*/TR-* IDs, or n/a]
**Standards:** [plugin-root-relative paths, or none]
**Required tests:** none (scaffolding task)

---

## Wave 2 — Core Implementation

### TASK-002 [tdd][wave:2]

[One-sentence description.]

**Satisfies:** [BR-*/TR-* IDs]
**Standards:** [plugin-root-relative paths]
**Required tests:**
- Unit: `[TestName]` — [what it verifies]
- Integration: `[TestName]` — [what it verifies]

---

## Wave 3 — Integration

### TASK-003 [checkpoint][wave:3]

[One-sentence description] — confirm [specific thing] before proceeding.

**Satisfies:** [BR-*/TR-* IDs]
**Standards:** [plugin-root-relative paths, or none]
**Required tests:** none (checkpoint — no code written until confirmed)
