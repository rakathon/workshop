# Architecture: [Feature Name]

<!-- Omit any section that has no content for this component. Do not leave sections
     populated with placeholder text only — a missing section is better than a
     placeholder that conveys nothing. The only required sections are Overview,
     System Components, and Technology Stack. -->

## Overview
[2-3 paragraphs describing the high-level architectural approach]

## System Context

### How This Fits
[Describe how this feature integrates with the existing system]

### External Dependencies
- **Service/API Name**: [What it provides and how we use it]

### Internal Dependencies
- **Feature/Service Name**: [What we need from it]

## System Components

### Component 1: [Name]
**Responsibility:** [What this component does]
**Technology:** [Language, framework, libraries]
**Location:** [Where code will live, e.g., src/services/auth/]
**Interfaces:** [APIs, events, or interfaces it exposes]
**Dependencies:** [Other components it needs]

## Data Models

<!-- Omit this section if this component owns no persistent data models. -->

### Entity: [EntityName]
```json
{
  "id": "string (UUID)",
  "field1": "type (constraints)",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

**Relationships:**
- Has many: [RelatedEntity]
- Belongs to: [ParentEntity]

**Indexes:**
- Primary: id
- Unique: field1
- Composite: (field1, field2)

## Contracts

<!-- Include only the subsections that apply to this component. Omit any subsection
     for which there are no contracts (e.g. omit gRPC if the component has no proto
     definitions, omit In-Memory Interfaces if this is not a library). -->

### REST / HTTP

<!-- Omit if this component exposes no HTTP endpoints. -->

**[Endpoint Name]:**
```
METHOD /api/path

Request:
{
  "field": "type"
}

Response (200):
{
  "field": "type"
}

Response (400):
{
  "error": "message"
}
```

### gRPC

<!-- Omit if this component has no proto definitions. -->

| RPC | Request message | Response message |
|-----|----------------|-----------------|
| [MethodName] | [RequestType] | [ResponseType] |

### GraphQL

<!-- Omit if this component exposes no GraphQL schema. -->

| Operation | Type | Return type |
|-----------|------|------------|
| [operationName] | Query \| Mutation \| Subscription | [ReturnType] |

### Messages

<!-- Omit if this component neither publishes nor subscribes to any topics or queues. -->

| Direction | Topic / Queue | Event type | Broker |
|-----------|--------------|-----------|--------|
| publishes \| subscribes | [topic-name] | [EventType] | Kafka \| SQS \| SNS \| RabbitMQ |

### In-Memory Interfaces

<!-- Include for libraries and internal modules that expose interfaces to callers.
     Omit for services that are only consumed over the network. -->

| Interface | Methods |
|-----------|---------|
| [InterfaceName] | [method1(args): ReturnType, ...] |

## Flows

<!-- Omit this section if the component has no non-trivial request or event flows
     worth documenting. Include 1–3 representative flows. Each flow must be a
     mermaid sequenceDiagram. -->

### Flow: [Name from dominant route group, entry message, or scheduled job]

```mermaid
sequenceDiagram
    participant Client
    participant Handler
    participant Service
    participant Repository

    Client->>Handler: [HTTP verb + path / event name]
    Handler->>Service: [method call with args]
    Service->>Repository: [read/write operation]
    Repository-->>Service: [result]
    Service-->>Handler: [return value]
    Handler-->>Client: [HTTP status + body / acknowledgement]
```

<!-- Repeat per distinct flow. Use more participants as needed to represent
     external services, message brokers, caches, etc. -->

## Algorithms

<!-- Omit this section if this component contains no non-trivial algorithms or
     business rules. Include only logic that is not self-evident from the code. -->

### [Algorithm Name]
[Description of the algorithm, its inputs, outputs, and any important complexity
or correctness properties.]

## Technology Stack

**Backend:**
- Language: [e.g., Go 1.22]
- Framework: [e.g., net/http]
- Database: [e.g., PostgreSQL 14+]

**Frontend:** *(omit if not applicable)*
- Framework: [e.g., React 18]
- State: [e.g., Redux Toolkit]

## Security Considerations

<!-- Omit if there are no security concerns specific to this component beyond
     the repository-level baseline. -->

[Authentication, authorization, PII handling, known attack surface.]

## Scalability and Performance

<!-- Omit if there are no scalability or performance concerns specific to this
     component. -->

[How this will scale and perform under load.]

## Standards Compliance

<!-- Omit if no standards are explicitly referenced. -->

Referenced standards:
- [Standard name]: `plugins/rr-standards/standards/path/to/standard.md`

## Trade-offs and Alternatives

<!-- Omit if no significant trade-offs were made during design. -->

### Decision: [Decision made]
**Rationale:** [Why]
**Trade-off:** [What we're giving up]
**Mitigation:** [How we address the trade-off]

## Open Questions

<!-- Omit once all questions are resolved. -->

1. **[Question]**
   - **Impact:** [What depends on this]
   - **Decision needed by:** [When]
