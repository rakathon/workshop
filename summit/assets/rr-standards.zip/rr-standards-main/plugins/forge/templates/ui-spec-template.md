# UI Spec — [Title]

<!--
This file is the input artifact for forge:ui. Fill in the sections relevant to
your use case — not all sections are required for every context.

Use case guidance:
  Exploration / demo variants → fill: Goal, Scope, Mode, Variants
  API / data visibility       → fill: Goal, Scope, Mode, Data
  Production from design      → fill: Goal, Scope, Mode, Design Reference, States, Accessibility, Out of Scope
-->

## Goal

<!-- One sentence. What does this UI accomplish? What decision or need does it serve? -->

## Mode

<!--
Pick one. This shapes how forge:ui interprets the spec.

  exploration   — building one or more demo variants to evaluate different approaches;
                  polish is not the goal, breadth of options is
  data-first    — making data from an API or data source visible as quickly as possible;
                  UX detail is secondary for now
  production    — implementing a design already defined by the design team; every
                  state, edge case, and accessibility requirement must be met
-->

mode: exploration | data-first | production

## Scope

<!--
What is being built? Choose the most specific description that applies.

  full-page       — an entire new page/route
  page-section    — one or more sections within an existing page
  component       — a standalone reusable component
  feature-area    — a bounded feature that may span multiple sections or components
-->

scope: full-page | page-section | component | feature-area

Target location in the codebase (file path or route, if known):

## Data

<!--
What data does this UI display? Where does it come from?
Include the shape of the data (field names, types) if it affects component selection.
If this is a production implementation, link to the API spec or data contract.

Examples:
  - Cashback offers from /api/v2/offers — { id, merchantName, rate, logoUrl }
  - Static marketing copy (no dynamic data)
  - User's transaction history from the existing useTransactions() hook
-->

## Variants

<!--
[Exploration mode only] List each approach to be demoed. Each variant should be
distinct enough to evaluate — not just cosmetic differences.

Example:
  - Variant A: Store grid with inline cashback rates
  - Variant B: Store carousel with expandable detail panel
  - Variant C: List view with sorting/filtering controls
-->

## Design Reference

<!--
[Production mode only] Link to the Figma file or frame, or describe the design
handoff artifact.

  Figma: [link]
  Screens: [list of screens / states in the design]
  Design version / date:
-->

## States Required

<!--
[Production mode] List every state the UI must handle. Missing a state here means
it won't be implemented.

  - [ ] Default (data loaded)
  - [ ] Loading / skeleton
  - [ ] Empty (no data returned)
  - [ ] Error (API failure)
  - [ ] [Feature-specific states, e.g. "Item saved", "Offer expired"]
-->

## Accessibility Notes

<!--
[Production mode] Any specific accessibility requirements from the design team
beyond the organizational baseline (WCAG 2.1 AA).

Examples:
  - Hero image is decorative — alt="" is correct
  - Modal must trap focus and restore it on close
  - Cashback amounts must be announced by screen readers as "X percent cash back"
-->

## Out of Scope

<!--
What is intentionally excluded from this implementation? Being explicit here
prevents scope creep and sets clear expectations.

Examples:
  - Authentication / sign-in flow
  - Mobile app (web only)
  - Personalization / A/B variant logic
  - Analytics instrumentation
-->
