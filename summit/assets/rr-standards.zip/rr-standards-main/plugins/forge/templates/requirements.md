# Requirements: [Feature Name]

## Overview
<!-- Brief description of this feature: What is it? Why do we need it? -->

## Functional Requirements

### FR-1: [Requirement Name]
**Description:** [What this requirement does]<br>
**Priority:** High | Medium | Low<br>
**Acceptance Criteria:**<br>
- [ ] Criterion 1 (specific, testable condition)
- [ ] Criterion 2
- [ ] Criterion 3

### FR-2: [Another Requirement]
**Description:** [What this requirement does]<br>
**Priority:** High | Medium | Low<br>
**Acceptance Criteria:**<br>
- [ ] Criterion 1 (specific, testable condition)

## Non-Functional Requirements

### NFR-1: Performance
**Requirement:** [Specific performance requirements]<br>
**Target:** [Measurable target, e.g., "API response time < 200ms p95"]<br>
**Rationale:** [Why this matters]<br>

### NFR-2: Security
**Requirement:** [Security requirements]<br>
**Standards:** [Which security standards apply]<br>
**Rationale:** [Why this matters]<br>

### NFR-3: Scalability
**Requirement:** [Scalability requirements]<br>
**Target:** [E.g., "Support 10,000 concurrent users"]<br>
**Rationale:** [Why this matters]<br>

## Constraints

### Technical Constraints
- [E.g., "The team prefers working in Java"]
- [E.g., "Must use existing PostgreSQL database"]
- [E.g., "Must integrate with existing authentication system"]
- [E.g., "Cannot introduce new runtime dependencies"]

### Business Constraints
- [E.g., "Must launch by Q2 2025"]
- [E.g., "Budget: 40 developer days"]
- [E.g., "Must be compatible with mobile app"]

## Dependencies

### External Dependencies
- [External service/API this feature depends on]
- [Third-party library or tool required]

### Internal Dependencies
- [Other features that must exist first]
- [Shared services this will use]

### Dependents
- [Other features that will depend on this]
- [Future capabilities this enables]

## Business Metrics

How will we measure the business impact and success of this feature? Define the metrics and clearly indicate how they
are calculated.

- **Feature Adoption:** [e.g. "% of members who use the feature"]
  - **Target:** [e.g., "50% adoption within 3 months"]
  - **Calculation:** Members who engaged once with the feature / Members who have seen the feature
  - **Collection:** [Page Viewed Event, Button Clicked Event, Funnel Completed Event etc.]

- **Usage Frequency:** [e.g. "Average uses per members per month"]
  - **Target:** [e.g., "3+ uses per month"]
  - **Calculation:** [Formula]
  - **Collection:** [How measured]

### Instrumentation Plan

What specific instrumentation needs to be implemented?

#### Events to Track
1. **[Event Name]** (e.g., "feature_started")
   - **Key Dimensions:** [e.g. "application, application version"]
   - **Purpose:** [Why we're tracking this]

2. **[Another Event]** (e.g., "feature_completed")
    - **Key Dimensions:** [e.g. "application, application version"]
   - **Purpose:** [Why we're tracking this]


## Notes

[Any additional context, references, or considerations]
