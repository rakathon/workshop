# ADR-NNN: [Title]

**Status:** Accepted
**Effort ID:** [effort-id]
**Date:** [YYYY-MM-DD]

## Context

[Why this decision was needed. What problem was being solved, what constraints
existed, what was learned that made this decision necessary. Written in past or
present tense from the perspective of the moment the decision was made.]

## Decision

[The decision itself, stated clearly and directly. "We will use X." "The system
will Y." Not hedged, not tentative — this is the committed choice.]

## Alternatives Considered

[Each alternative that was meaningfully considered before this decision was made.
For each alternative: what it was, why it was not chosen. If no alternatives were
considered, write "No alternatives were explicitly considered."]

## Consequences

[What this decision means going forward. What is now easier, what is now harder,
what constraints it imposes, what follow-on decisions it enables or forecloses.]
