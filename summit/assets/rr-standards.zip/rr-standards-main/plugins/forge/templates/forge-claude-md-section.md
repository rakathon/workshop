<!-- forge:managed:start -->
## Forge Workflow

This project uses Forge, a structured development workflow system. Forge manages work
artifacts — requirements, specifications, plans, architecture decisions, and validation
reports — in the `.forge/` directory. These artifacts are the source of truth for
what is being built, why, and how far along it is.

### The `.forge/` directory

`.forge/` has three subdirectories, each with a distinct purpose:

- **`efforts/`** — Work-in-progress artifacts. Each effort (a unit of work, from a
  multi-repo initiative down to a single story) has its own subdirectory containing
  requirements, specifications, plans, and decisions produced during that work. Efforts
  are active while the work is in progress and become historical records when closed.

- **`deployables/`** — Canonical, living documentation for each technical deployable
  unit in this repository. Updated when efforts complete (graduate). Reflects the
  current state of the deployable — what it does, what decisions shaped it, what
  constraints it operates under.

  Each deployable contains a `capabilities/` directory. A capability is a user-facing
  feature — it is named after what it delivers to the engineer, not the architectural
  layer it belongs to. `forge-init` is a capability because it delivers the `forge:init`
  experience. "initialization-infrastructure" is not a capability name — that is an
  architectural grouping. When creating or naming a capability, ask: "what does an
  engineer *do* with this?" — the answer is the capability name.

- **`products/`** — PM-facing documentation for business capabilities that span
  multiple deployables. Present only in coordination repositories.

### Recognizing workflow events

When the conversation contains one of these, take the corresponding action in addition
to responding naturally — do not announce it, just do it:

- Technical decision made ("we'll use X", "let's go with Y because Z") → write an ADR
- Requirements described ("it must do X", "users need to be able to Y") → update requirements
- Design discussed ("the API should look like X", "data flows from X to Y") → update spec
- Work completed ("that's done", "task X is finished") → update plan task status
- Concern raised ("I'm worried about X", "this might not work because Y") → record as open decision
- Checkpoint task reached and blocked ("I need to confirm X before I can proceed") → record as open decision, note which task is blocked
- Status asked ("where are we", "what's left") → read state and summarize
- Work declared complete ("we're done", "let's close this out") → initiate graduation

The session context injected at startup contains the full artifact routing table with
exact paths for every artifact type (requirements, spec, plan, ADRs, decisions, etc.).
Engineers and agents should refer to that context for precise file locations rather than
inferring paths from the directory structure above.

### Creating branches

When starting work that does not have an active Forge effort:
1. If an active effort exists: its branch (`effort/<id>`) is already checked out — no action needed
2. Infer type from the request:
   - `fix` → bug, crash, broken, regression, error, not working
   - `hotfix` → urgent, production, critical, emergency
   - `docs` → documentation, README, guide, comments
   - `refactor` → refactor, restructure, clean up, extract
   - `chore` → dependency, maintenance, upgrade, version bump, cleanup
   - `release` → release, version, tag, changelog
   - `feature` → adding, building, implementing new functionality
   - ambiguous → ask: "What type of change is this? (feature/fix/hotfix/chore/docs/refactor/release)"
3. Derive slug: 3-5 descriptive words, lowercase, hyphens, max 40 chars
4. Run: `git checkout -b <type>/<slug>`
5. Confirm: "Created branch: <type>/<slug>"

### Before writing any `.forge/` file

1. Read `.forge/efforts/README.md` to identify active efforts
2. Read the relevant effort's `.state.json` to confirm current phase
3. The session context injected at startup contains the full artifact routing table —
   use it to determine the correct path for the artifact type you are writing
4. If the file already exists, read it before writing

The PostToolUse hook updates `.state.json` automatically after every artifact write.
Commit artifact changes with: `docs(<effort-id>): <description>`
<!-- forge:managed:end -->
