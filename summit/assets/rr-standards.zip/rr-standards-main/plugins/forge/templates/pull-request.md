## Summary

<!-- 3–5 bullets describing what this PR delivers. Synthesized from requirements —
     reviewer-facing prose, not requirement identifiers. -->

- 
- 
- 

## Reviewer focus

<!-- 1–3 bullets highlighting areas that need close attention: validation concerns,
     open decisions, checkpoint tasks. Omit section if nothing to surface. -->

## Related ticket

<!-- Link to the associated Jira ticket or GitHub issue.
     Example: https://your-org.atlassian.net/browse/PROJ-1234 -->

## Type of change

<!-- Mark the relevant option(s) with an 'x' -->

- [ ] New feature
- [ ] Bug fix
- [ ] Breaking change
- [ ] Refactoring (no functional change)
- [ ] Documentation / standards update

## Risk

<!-- Classification: R1–R4 and the review requirement.
     R1/R2: Human review required in addition to AI review.
     R3/R4: AI review sufficient; human review optional.
     Rationale: the primary reason for this tier (from forge:classify riskRationale,
     or a brief note if classify was not run). -->

## Quality gate

<!-- Result of forge:verify (implementation PRs) or forge:validate (discovery PRs).
     PASS / PASS WITH CONCERNS / not run. -->

## Validation / verification report

<!-- Paste key findings from validation/report.md or verification/report.md.
     If PASS with no findings: "No findings."
     If PASS WITH CONCERNS: include the SUGGESTION items so reviewers can assess them.
     If gate was not run: "Not run." -->

## What was implemented

<!-- For implementation PRs: completed tasks grouped by wave with commit SHAs.
     For discovery PRs: list artifacts produced (requirements, spec files, ADRs). -->

## Test plan

<!-- Checklist of what was tested. Derived from completed tasks and verification
     report. Omit for discovery PRs. -->

- [ ] 
- [ ] 

## Breaking changes

<!-- Describe anything that breaks existing behaviour and provide migration
     instructions. Omit section if none. -->

## Deployment notes

<!-- Special deployment considerations: database migrations, new environment
     variables, configuration changes, feature flags. Omit section if none. -->
