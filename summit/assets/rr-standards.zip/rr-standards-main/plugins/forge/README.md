# Forge

Every time you start a new Claude Code session, Claude has forgotten everything —
the decisions you made last week, the requirements you spent an hour explaining,
the half-finished tasks from yesterday. You spend the first 20 minutes of every
session re-establishing context before you can do real work.

Forge fixes this. It gives Claude a structured workspace committed to your
repository, so every session starts with full context and every engineer on your
team is working from the same shared picture.

## What a session looks like with Forge

You open Claude Code. The session hook detects you paused mid-task yesterday:

```
Resuming: add-favorites-api

  Last session: Implemented the repository layer (TASK-003). Wave 2 in progress.
  Active task:  TASK-004 — Add POST /v2/favorites endpoint
  Next action:  Implement the handler in src/api/favorites.go, wire to FavoritesService
```

You say "continue" and Claude picks up exactly where it left off — with the right
language guide injected, the spec open, and the task context loaded. No re-explaining.
No re-reading. Just work.

If you need to context switch, `forge:pause` saves your position on the current effort. 
When you or a teammate picks it back up, `forge:resume` gives you the same context you had
when you paused.

---

## Prerequisites

- [Claude Code](https://claude.ai/code)
- [GitHub CLI](https://cli.github.com) authenticated (`gh auth login`)
- Python 3

## Installation

**1. Add the rr-standards marketplace**

```
/plugin marketplace add github:rewards-guilds/rr-standards --scope project
```

**2. Install the Forge plugin**

```
/plugin install forge@rr-standards --scope project
```

**3. Initialize the repository**

```
forge:init
```

Forge will ask what kind of repository this is (source code, product, or
coordination), then create a `.forge/` workspace, register hooks, and add a
navigation block to `CLAUDE.md`. Commit the result:

```bash
git add .forge/ CLAUDE.md
git commit -m "chore: initialize forge"
```

That's it. Forge is running.

---

## Your first effort

An **effort** is any piece of work — from a single bug fix to a multi-team feature.
Forge tracks its requirements, decisions, tasks, and state in `.forge/efforts/<id>/`.

### 1. Create the effort

```
forge:effort
```

Forge asks for a title, type (story, task, spike, patch, etc.), and risk level.
It creates the effort directory, writes `.state.json`, and checks out a working branch
(`effort/<id>`).

### 2. Write requirements (full-tier efforts)

For anything beyond a quick patch, drop two files in the effort directory:

- `requirements/business.md` — what the user needs and why
- `requirements/technical.md` — constraints, non-functional requirements, acceptance criteria

These become the source of truth Claude uses for planning, implementation, and verification.

### 3. Generate a plan

```
forge:plan <effort-id>
```

Claude reads your requirements and spec artifacts, enumerates tasks, analyzes
dependencies, and writes a wave-ordered plan to `plan/tasks.md`:

```
## Wave 1 — Foundation
- [ ] [auto][wave:1] Add FavoritesRepository interface (TASK-001)
- [ ] [auto][wave:1] Write database migration for favorites table (TASK-002)

## Wave 2 — Core Implementation
- [ ] [tdd][wave:2] Implement FavoritesRepository (TASK-003)
- [ ] [tdd][wave:2] Add POST /v2/favorites handler (TASK-004)
```

Tasks in the same wave are independent — they can run in parallel on separate git
worktrees if you want to go faster.

### 4. Implement

Work through the tasks. The pre-tool-use hook injects the relevant language guide
before Claude generates any code, so output is standards-aligned from the start.

Check progress anytime:

```
forge:status
```

### 5. Verify and graduate

When all tasks are done, `forge:verify` reads your requirements and the implementation
commits, confirms every requirement has real code behind it (no stubs, no missing
wiring), and writes a `verification/report.md`.

Once QA signs off, `forge:graduate` merges the effort's requirements and specs into
your deployable's canonical documentation — so your architecture records stay
accurate without a separate documentation pass.

---

## Key concepts

**Efforts** are the unit of work in Forge. Each effort lives in `.forge/efforts/<id>/`
and has a `.state.json` that tracks its phase, task progress, open decisions, and
pause state.

**Waves** are dependency-ordered groups of tasks. All wave 1 tasks can run in parallel;
wave 2 tasks start only after wave 1 completes. Forge determines waves automatically
from the dependency graph.

**Tiers and risk** control how much process an effort requires. A `patch` (tier:
lightweight) goes straight to implementation — no requirements, no plan, no QA. An
`epic` (tier: full, risk: R1) goes through discovery, arch review, planning,
verification, review, and QA. Pick the right tier and Forge scales the process up
or down accordingly.

| Risk | When to use | Examples |
|------|-------------|---------|
| R1 | Critical paths | Auth, payments, data migrations, PII |
| R2 | High-impact work | Core features, external integrations |
| R3 | Moderate scope | New features, UI updates |
| R4 | Low-risk changes | Logging, config, minor fixes |

**Deployables** are the named units of source code in your repository. When an effort
is graduated, its artifacts are merged into `.forge/deployables/<name>/` — the
single source of truth for that deployable's requirements and design.

---

## Slack Integration

Forge can import Slack conversations into an effort's artifact directory, giving
Claude access to the full decision history that lives in chat — not just in code
and documents. Three skills work together to set this up:

- **`forge:slack-channel`** — Associates one or more Slack channels with an effort
  (or removes an existing association). Resolves channel names to IDs via the
  Slack MCP and writes them to the effort's `.state.json`. Optionally records a
  cron schedule for automated imports.

- **`forge:slack-import`** — Fetches messages from the effort's associated
  channels, writes dated markdown files under
  `.forge/efforts/<id>/messages/slack/`, and advances an import checkpoint.
  Supports `--from`/`--to` date bounds for backfill, `--channel` to scope a run
  to one channel, and `--ci` to sweep all efforts in the repository.

- **`forge:slack-summarize`** — Reads imported message files and generates a
  structured daily or weekly summary. Extracts architectural decisions, planning
  decisions, raised risks, bugs, spec problems, time-off notices, and status
  updates into a summary file committed alongside the raw messages.

### Prerequisites

1. **Slack MCP configured** — The Slack MCP server must be declared in the Forge
   plugin's `.mcp.json`.
2. **OAuth authorization completed** — Complete the OAuth flow for the Slack MCP
   before running any `forge:slack-*` skill. Restart Claude Code after
   authorization.

### Quick-start

```
# 1. Associate a Slack channel with the active effort
forge:slack-channel #eng-payments

# 2. Run the first import (you will be prompted for a start date)
forge:slack-import

# 3. Generate a daily summary for a specific date
forge:slack-summarize --daily 2026-04-21

# — or generate a weekly summary —
forge:slack-summarize --weekly 2026-W17
```

### Scheduled automation

To run imports on a cron schedule without a human in the loop, configure the
GitHub Actions workflow at `.github/workflows/slack-import.yml`. Record the
desired cadence when associating a channel:

```
forge:slack-channel #eng-payments --schedule "0 9 * * *"
```

The printed reminder will tell you which workflow file to update and confirm
that the Slack MCP OAuth authorization has been completed for the GitHub
Actions runner.

---

## Skills reference

| Skill | What it does |
|-------|-------------|
| `forge:effort` | Create a new work item and scaffold its directory |
| `forge:plan <id>` | Generate a wave-ordered task plan from requirements |
| `forge:status [<id>]` | Show phase, artifact inventory, task progress, next action |
| `forge:adr` | Capture an architectural decision record |
| `forge:verify <id>` | Confirm every requirement has implementation evidence |
| `forge:graduate <id>` | Promote effort artifacts into canonical deployable docs |
| `forge:pause` | Save session state for handoff |
| `forge:resume` | Restore context at the start of a new session |
| `forge:update` | Migrate repo config after a plugin update |
| `forge:init` | Initialize a repository (run once) |
| `forge:pin` | Pin the team to a specific Forge version (optional) |
| `forge:slack-channel` | Associate (or remove) a Slack channel from an effort |
| `forge:slack-import` | Import Slack messages into effort artifact files |
| `forge:slack-summarize` | Generate a daily or weekly summary from imported messages |

---

## Going deeper

### The .forge/ directory

```
.forge/
├── README.md               # Active work item registry
├── version                 # Forge version metadata
├── spec/
│   └── arch-decisions/     # Repository-level ADRs
├── efforts/
│   └── <effort-id>/
│       ├── .state.json     # Phase and task state (machine-readable)
│       ├── requirements/   # business.md, technical.md
│       ├── spec/           # api/, storage/, messaging/, arch-decisions/
│       ├── plan/           # tasks.md — wave-ordered implementation plan
│       ├── validation/     # Standards compliance review
│       ├── verification/   # Requirement coverage report
│       └── meetings/       # YYYY-MM/ subdirs; transcript + summary per meeting
├── deployables/
│   └── <name>/             # Canonical docs per deployable (source repos)
└── products/
    └── <name>/             # Canonical docs per product (product repos)
```

### Pinning to a specific version

By default, each engineer loads whatever version of Forge they have globally
installed. Most teams don't need to pin — Forge follows semantic versioning and
MINOR/PATCH releases are backwards-compatible.

Pin when you want the whole team locked to the same version — for example, to
hold off on an upgrade while a critical effort is in flight:

```
forge:pin [--version <semver>]
```

Commit the resulting `.claude-plugin/marketplace.json` so all engineers get the
pinned version. Then run `forge:update` to migrate the repo config to match.

### Opting out of standards enforcement

Deprecated or exempt repositories can suppress coding standards injection by
creating `.forge/compliance`:

```
coding_standards=exempt
reason=Repository deprecated — scheduled for decommission Q3 2026
```

All other review checks (security, privacy, error handling) continue to run.
Repositories initialized as legacy repositories with `forge:init` get this file
created automatically.
