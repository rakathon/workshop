# Scenario: Lightweight Tier — Patch, Extension, and PoC Efforts

Three independent scenarios covering each lightweight effort subtype. Each scenario
can be run on its own. All scenarios use the Favorite Stores domain established in the
full-tier lifecycle test.

---

## Scenario A: Patch Effort — Bug Fix (insertion order)

**Context:** The Favorite Stores feature has shipped. Engineers report that
`GET /v1/members/{id}/favorites` returns stores in random order instead of the
order in which the member added them.

---

### Step A-1: Engineer Reports the Bug

**Input prompt:**
> "We have a bug — the favorites endpoint is returning stores in random order
> instead of insertion order."

**Expected outcomes:**

1. Claude recognizes a narrow, well-scoped bug report → classifies as `patch`
2. forge:effort scaffolds `.forge/efforts/favorites-insertion-order-fix/`:

```bash
ls .forge/efforts/favorites-insertion-order-fix/
# Expected: .state.json only — no subdirectories
```

3. `.state.json` has correct lightweight patch fields:

```bash
jq '{tier, subtype, currentPhase, productionBound, risk}' \
  .forge/efforts/favorites-insertion-order-fix/.state.json
# Expected:
# {
#   "tier": "lightweight",
#   "subtype": "patch",
#   "currentPhase": "implementation",
#   "productionBound": true,
#   "risk": "R4"
# }
```

4. No `requirements/`, `spec/`, `plan/`, or `validation/` directories exist:

```bash
[ ! -d ".forge/efforts/favorites-insertion-order-fix/requirements" ] && echo "PASS" || echo "FAIL"
[ ! -d ".forge/efforts/favorites-insertion-order-fix/spec" ] && echo "PASS" || echo "FAIL"
[ ! -d ".forge/efforts/favorites-insertion-order-fix/plan" ] && echo "PASS" || echo "FAIL"
[ ! -d ".forge/efforts/favorites-insertion-order-fix/validation" ] && echo "PASS" || echo "FAIL"
```

5. Registry row reflects lightweight patch:

```bash
grep "favorites-insertion-order-fix" .forge/efforts/README.md
# Expected row contains: lightweight | R4 | implementation
```

6. Scaffold commit created:

```bash
git log --oneline -1
# Expected: chore(favorites-insertion-order-fix): scaffold Favorites Insertion Order Fix effort
```

---

### Step A-2: Engineer Implements the Fix

**Input prompt:**
> "The bug is in the repository layer — the SQL query uses `SELECT *` without
> an ORDER BY clause. Let me add `ORDER BY created_at ASC`."

**Expected outcomes:**

1. Claude proceeds directly with implementation — no phase transition required
2. No discovery or planning prompts are surfaced
3. Fix is applied to the relevant source file (e.g., `FavoriteStoreRepository.java`)
4. `phases.implementation.status` in `.state.json` updates to `"in_progress"`:

```bash
jq '.phases.implementation.status' \
  .forge/efforts/favorites-insertion-order-fix/.state.json
# Expected: "in_progress"
```

---

### Step A-3: Engineer Commits and Opens PR

**Input prompt:**
> "That looks right. Let's commit and open a PR."

**Expected outcomes:**

1. Git commit staged and created with an appropriate message
2. PR created on the current branch
3. forge:review is listed as a **required status check** on the PR (blocks merge on failure):

```bash
gh pr checks
# Expected: forge:review appears as a required check
```

4. No arch-review, QA, or forge:verify checks are listed as required
5. Claude does NOT prompt for QA approval — patch efforts skip QA

---

### Step A-4: CI Review Runs and Passes

**Input prompt:**
> "CI just ran. forge:review came back clean."

**Expected outcomes:**

1. PR is unblocked (required status check passed)
2. Claude confirms the effort is ready to merge — no additional gates
3. After merge, effort is closed/graduated without a QA phase or verification report:

```bash
jq '.graduation.graduated' \
  .forge/efforts/favorites-insertion-order-fix/.state.json
# Expected: true
```

4. `currentPhase` advanced to final state without discovery, planning, arch-review,
   or QA phases ever appearing in `.state.json`

---

## Scenario B: Extension Effort — Add GET-by-ID Endpoint

**Context:** After the Favorite Stores feature ships, product requests a new endpoint
to retrieve a single favorite store by ID (for deep-link support).

---

### Step B-1: Engineer Describes the New Capability

**Input prompt:**
> "We need to add a GET endpoint to retrieve just one favorite store by ID —
> something like `GET /v1/members/{memberId}/favorites/{storeId}`."

**Expected outcomes:**

1. Claude identifies this as additive scope — a new capability on an existing feature
2. Claude asks whether to include a discovery phase:

```
Is the scope of this extension non-trivial enough to warrant a discovery phase? (yes/no)
```

---

### Step B-2: Engineer Opts Into Discovery

**Input prompt:**
> "Yes, let's do discovery — there are auth implications to check."

**Expected outcomes:**

1. forge:effort creates `.forge/efforts/favorites-get-by-id/` with base directory only:

```bash
ls .forge/efforts/favorites-get-by-id/
# Expected: .state.json
# (requirements/ and spec/ are created on first write by forge:elaborate and forge:spec-*)
```

2. No `validation/` directory (extensions skip architecture review):

```bash
[ ! -d ".forge/efforts/favorites-get-by-id/validation" ] && echo "PASS" || echo "FAIL"
```

4. `.state.json` fields:

```bash
jq '{tier, subtype, currentPhase, productionBound}' \
  .forge/efforts/favorites-get-by-id/.state.json
# Expected:
# {
#   "tier": "lightweight",
#   "subtype": "extension",
#   "currentPhase": "discovery",
#   "productionBound": true
# }
```

5. Risk was prompted and engineer supplied R2:

```bash
jq '.risk' .forge/efforts/favorites-get-by-id/.state.json
# Expected: "R2"
```

---

### Step B-3: Discovery — Document Requirements

**Input prompt:**
> "Business requirement: members must only be able to retrieve their own favorites,
> never another member's. Technical: the endpoint must validate that the `{memberId}`
> in the path matches the authenticated member's token claim."

**Expected outcomes:**

1. Claude writes `requirements/business.md` and `requirements/technical.md`;
   `forge:elaborate` creates the `requirements/` directory before the first write:

```bash
ls .forge/efforts/favorites-get-by-id/requirements/
# Expected: business.md  technical.md
```

2. PostToolUse hook updates artifact tracking:

```bash
jq '.phases.discovery.artifacts.requirements' \
  .forge/efforts/favorites-get-by-id/.state.json
# Expected:
# {
#   "business": "present",
#   "technical": "present"
# }
```

3. Claude writes `spec/api/favorites-api.yaml` with the new endpoint definition;
   `forge:spec-api` creates `spec/api/` before the first write:

```bash
ls .forge/efforts/favorites-get-by-id/spec/api/
# Expected: favorites-api.yaml
```

4. PostToolUse hook updates API spec tracking:

```bash
jq '.phases.discovery.artifacts.spec.api' \
  .forge/efforts/favorites-get-by-id/.state.json
# Expected: "present"
```

---

### Step B-4: Promote to Implementation

**Input prompt:**
> "Discovery looks good. Let's move to implementation."

**Expected outcomes:**

1. Claude surfaces the forge:promote ritual — lists discovery artifacts and asks for confirmation
2. Engineer confirms; `currentPhase` advances to `"implementation"`:

```bash
jq '.currentPhase' .forge/efforts/favorites-get-by-id/.state.json
# Expected: "implementation"
```

3. `phases.discovery.status` set to `"approved"`:

```bash
jq '.phases.discovery.status' .forge/efforts/favorites-get-by-id/.state.json
# Expected: "approved"
```

4. forge:arch-review is NOT invoked and NOT required — extensions bypass architecture review:

```bash
[ ! -f ".forge/efforts/favorites-get-by-id/validation/report.md" ] && echo "PASS" || echo "FAIL"
```

---

### Step B-5: Implementation and PR

**Input prompt:**
> "Implemented the handler, added the route, and wrote unit tests. Let's open a PR."

**Expected outcomes:**

1. PR created on the current branch
2. forge:review is listed as a **required status check** on the PR:

```bash
gh pr checks
# Expected: forge:review appears as a required check
```

3. forge:arch-review does NOT appear as a required check
4. Because risk is R2, QA is warranted — Claude surfaces the QA recommendation:

```
This extension is classified R2. QA review is recommended before merging.
```

5. No `forge:arch-review` required status check in CI configuration

---

## Scenario C: PoC Effort — Store Recommendations Prototype

**Context:** Product wants to explore whether Favorite Stores data can power a
store recommendation feature. Engineering proposes a quick proof-of-concept before
committing to a production build.

---

### Step C-1: Engineer Proposes a PoC

**Input prompt:**
> "Let's build a quick proof-of-concept for store recommendations using the
> favorites data."

**Expected outcomes:**

1. Claude identifies exploratory, non-committal framing → suggests PoC classification
2. Claude confirms: "This will be a non-production-bound effort. PoC code cannot be
   merged to a production branch as a shipping feature."
3. forge:effort scaffolds `.forge/efforts/store-recommendations-poc/`:

```bash
ls .forge/efforts/store-recommendations-poc/
# Expected: .state.json only — no subdirectories
```

4. `.state.json` fields:

```bash
jq '{tier, subtype, currentPhase, productionBound, risk}' \
  .forge/efforts/store-recommendations-poc/.state.json
# Expected:
# {
#   "tier": "lightweight",
#   "subtype": "poc",
#   "currentPhase": "implementation",
#   "productionBound": false,
#   "risk": "R4"
# }
```

5. Risk defaults to R4 without prompting:

```
Risk defaulted to R4 for poc efforts.
```

---

### Step C-2: Engineer Implements the PoC

**Input prompt:**
> "I'll use the existing favorites data to build a simple collaborative filter.
> I'm going to hardcode a few config values and skip input validation — this is
> just a demo."

**Expected outcomes:**

1. Claude proceeds without objection — PoC efforts carry no compliance requirements
2. No security review, input validation check, or test coverage requirement is enforced
3. Implementation proceeds with hardcoded values and minimal validation as described

---

### Step C-3: PoC CI Review Is Non-Blocking

**Input prompt:**
> "I have a commit ready. Let's push and see what CI says."

**Expected outcomes:**

1. PR created on a non-production branch (e.g., `poc/store-recommendations`)
2. forge:review runs but is configured as **optional** — failures do not block merge:

```bash
gh pr checks
# Expected: forge:review appears but is NOT marked as required
```

3. If forge:review detects a security or privacy violation (e.g., hardcoded credential),
   it reports the issue but does not block merge for PoC efforts:

```
forge:review: WARNING — hardcoded API key detected in RecommendationEngine.java
Status: advisory (non-blocking for PoC efforts)
```

---

### Step C-4: Engineer Attempts to Merge to Production Branch

**Input prompt:**
> "The demo went well. Let me merge this into main."

**Expected outcomes:**

1. System surfaces a blocking warning before merge proceeds:

```
WARNING: This effort is classified as a PoC (productionBound: false).

PoC code cannot be merged to a production-tracked branch (main).

To ship this capability:
  1. Create a new production effort based on the PoC findings
  2. Re-implement against an approved spec with full test coverage
  3. The PoC serves as a reference implementation — do not copy it wholesale

See ADR-006 for rationale.
```

2. Merge to `main` is NOT performed
3. The PoC branch remains on its non-production branch

---

### Step C-5: Engineer Creates a Follow-On Production Effort

**Input prompt:**
> "Got it. Let's create a proper production effort for store recommendations based
> on what we learned in the PoC."

**Expected outcomes:**

1. forge:effort is invoked to create a new full-tier effort
2. Claude asks whether to link the new effort as a follow-on to the PoC:

```
Should this effort record store-recommendations-poc as its source? (yes/no)
```

3. Engineer answers "yes"; new effort is created as a full-tier epic or story

4. PoC `.state.json` is updated with the new effort's ID in `spawnedWorkItems`:

```bash
jq '.spawnedWorkItems' .forge/efforts/store-recommendations-poc/.state.json
# Expected:
# [
#   "store-recommendations"
# ]
```

5. New production effort `.state.json` records the PoC as its origin:

```bash
jq '.parentId // .derivedFrom' .forge/efforts/store-recommendations/.state.json
# Expected: "store-recommendations-poc"
```

6. New effort starts in `discovery` phase — it does not inherit the PoC's
   implementation state:

```bash
jq '.currentPhase' .forge/efforts/store-recommendations/.state.json
# Expected: "discovery"
```

7. Claude reminds the engineer:

```
The PoC code is available as a reference implementation at
.forge/efforts/store-recommendations-poc/. Use it to inform design decisions
in the new effort's discovery phase — do not copy it into production directly.
```
