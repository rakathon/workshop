# Effort Branch Creation and Drift Detection — Test Scenario

**Task:** TASK-010
**Skills/Hooks under test:** `forge:effort`, `inject-workflow-context.sh`, `forge:project`

---

## Scenario 1: forge:effort creates working branch automatically

### Setup

- Current branch: `main`
- No active efforts: `.forge/efforts/README.md` has no effort rows (or `.forge/` does not yet exist)
- Repository initialized with `forge:init` (`CLAUDE.md` and `.forge/efforts/README.md` exist)

### Input

**Conversational prompt to Claude:**

> We need to build a favorites feature.

The conversational scope statement triggers `forge:effort`. When the skill asks for
clarifying details, supply:

- **Effort ID:** `favorite-stores`
- **Title:** `Favorite Stores`
- **Tier:** lightweight (or accept default)

### Expected Outcomes

1. `forge:effort` runs and scaffolds the effort directory.
2. After the scaffold commit, the skill runs:
   ```
   git checkout -b effort/favorite-stores
   ```
3. The engineer is now on branch `effort/favorite-stores` — no manual checkout needed.
4. The skill prints a confirmation:
   ```
   Working branch created: effort/favorite-stores
   ```
5. `.forge/efforts/favorite-stores/.state.json` is created with correct fields.
6. `.forge/efforts/README.md` has a new row for `favorite-stores`.

### Verify

- [ ] `git branch --show-current` = `effort/favorite-stores`
- [ ] `.forge/efforts/favorite-stores/` directory exists
- [ ] `.forge/efforts/favorite-stores/.state.json` exists
- [ ] `.state.json` contains `"id": "favorite-stores"`
- [ ] `.state.json` contains `"title": "Favorite Stores"` (or the title supplied)
- [ ] `.forge/efforts/README.md` contains a row for `favorite-stores`
- [ ] `main` branch does NOT include the `.forge/efforts/favorite-stores/` commit (it is on the effort branch)

---

## Scenario 2: forge:effort is idempotent (resume after interruption)

### Setup

- Branch `effort/favorite-stores` already exists (created in Scenario 1 or manually)
- Current branch: `main` (simulating that the engineer switched away or the session was interrupted)
- `.forge/efforts/favorite-stores/.state.json` already exists with prior scaffold content

### Input

Invoke `forge:effort` with the same effort ID:

> Resume the favorite-stores effort.

Or invoke directly: `forge:effort` → supply `favorite-stores` as the effort ID when prompted.

### Expected Outcomes

1. The skill detects that `effort/favorite-stores` already exists.
2. The skill runs `git checkout effort/favorite-stores` (without `-b`).
3. No error is produced from git.
4. No new scaffold commit is created (existing branch contents are unchanged).
5. The skill prints a confirmation that includes "resumed":
   ```
   Working branch: effort/favorite-stores (resumed)
   ```

### Verify

- [ ] `git branch --show-current` = `effort/favorite-stores`
- [ ] No git error output
- [ ] Existing branch commit history is unchanged (no new commits on the effort branch)
- [ ] `.forge/efforts/favorite-stores/.state.json` content is unchanged from Scenario 1
- [ ] Confirmation message contains "resumed"

---

## Scenario 3: Session start on correct branch — no warning

### Setup

- Active effort: `favorite-stores` (`.forge/efforts/README.md` has an active row for `favorite-stores`)
- Current branch: `effort/favorite-stores`

### Trigger

The SessionStart hook fires. This happens automatically at the start of each Claude Code
session. To test manually, run:

```bash
bash plugins/forge/hooks/session-start/inject-workflow-context.sh
```

### Expected Outcomes

1. The hook reads the current branch (`effort/favorite-stores`) and the active effort
   (`favorite-stores`).
2. The branches match: `effort/favorite-stores` = `effort/favorite-stores`.
3. No drift warning is emitted.
4. Normal context output begins:
   ```
   ## Forge — Active Workflow Context
   ```

### Verify

- [ ] Output does NOT contain `⚠️ Branch mismatch`
- [ ] Output does NOT contain `git checkout effort/`
- [ ] First non-blank line of output starts with `## Forge`
- [ ] Output contains the standard artifact inventory section

---

## Scenario 4: Session start on wrong branch — drift warning at top

### Setup

- Active effort: `favorite-stores` (`.forge/efforts/README.md` has an active row for `favorite-stores`)
- Current branch: `main`

### Trigger

The SessionStart hook fires. To test manually:

```bash
git checkout main
bash plugins/forge/hooks/session-start/inject-workflow-context.sh
```

### Expected Outcomes

1. The hook reads the current branch (`main`) and the active effort (`favorite-stores`).
2. The expected effort branch (`effort/favorite-stores`) does not match `main`.
3. A drift warning is emitted as the absolute first item in the output:
   ```
   ⚠️ **Branch mismatch detected:**
   Active effort: favorite-stores (effort/favorite-stores)
   Current branch: main

   Switch to the effort branch before making any changes:
     git checkout effort/favorite-stores
   ```
4. The warning appears BEFORE the `## Forge — Active Workflow Context` header.
5. The hook exits 0 (warning is informational, not blocking).

### Verify

- [ ] First non-blank line of output starts with `⚠️`
- [ ] Output does NOT start with `## Forge`
- [ ] Warning contains `Active effort: favorite-stores`
- [ ] Warning contains `effort/favorite-stores` as the expected branch
- [ ] Warning contains `Current branch: main`
- [ ] Warning contains `git checkout effort/favorite-stores`
- [ ] Hook exit code is `0` (not blocking)
- [ ] `## Forge — Active Workflow Context` header still appears later in the output

---

## Scenario 5: Session start with no active effort — no drift check

### Setup

- No active efforts: `.forge/efforts/README.md` has no effort rows, or `.forge/efforts/README.md` does not exist
- Current branch: `main` (or any branch)

### Trigger

The SessionStart hook fires. To test manually:

```bash
# Temporarily clear the registry
# (restore after test)
bash plugins/forge/hooks/session-start/inject-workflow-context.sh
```

### Expected Outcomes

1. The hook reads `.forge/efforts/README.md` and finds no active efforts.
2. No drift check is performed (there is no active effort ID to compare against).
3. The output includes a "no active efforts" message:
   ```
   No active efforts found.
   ```
4. No drift warning is emitted.

### Verify

- [ ] Output does NOT contain `⚠️ Branch mismatch`
- [ ] Output does NOT contain `git checkout effort/`
- [ ] Output contains a "no active efforts" message (exact wording may vary)
- [ ] Hook exits 0

---

## Scenario 6: forge:project creates branch in local repo

### Setup

- **Coordination repository:** `org/rewards-coordination` accessible via GitHub API
  with a `favorite-stores` effort at `.forge/efforts/favorite-stores/`
- **Local repository:** `org/rewards-backend`, initialized with `forge:init`
- Current branch in local repo: `main`
- No `favorite-stores-backend` effort exists locally

### Input

Invoke `forge:project` in the local repository:

> Let's start the backend work for the favorite-stores effort in the coordination repo.

Supply when prompted:

- `--coordination-repo org/rewards-coordination`
- `--effort-id favorite-stores`
- **Local deployable:** `backend`
- **Local effort ID:** `favorite-stores-backend` (accept proposed default)

### Expected Outcomes

1. `forge:project` fetches the coordination effort artifacts from `org/rewards-coordination`.
2. Projected files are created under `.forge/efforts/favorite-stores-backend/`.
3. After the scaffold commit, the skill creates and checks out the local branch:
   ```
   git checkout -b effort/favorite-stores-backend
   ```
4. `.forge/efforts/favorite-stores-backend/.state.json` is created with a `coordinationRef` field.
5. The engineer is now on branch `effort/favorite-stores-backend` in the local repo.

### Verify

- [ ] `git branch --show-current` = `effort/favorite-stores-backend`
- [ ] `.forge/efforts/favorite-stores-backend/` directory exists
- [ ] `.forge/efforts/favorite-stores-backend/.state.json` exists
- [ ] `.state.json` contains `"id": "favorite-stores-backend"`
- [ ] `.state.json` contains a `coordinationRef` field with `"repo": "org/rewards-coordination"`
- [ ] `.forge/efforts/README.md` in the local repo contains a row for `favorite-stores-backend`

---

## Scenario Summary

| # | Branch state | Active effort | Trigger | Expected result |
|---|--------------|---------------|---------|-----------------|
| 1 | `main` (no effort) | none | forge:effort conversational | `effort/favorite-stores` created and checked out |
| 2 | `main` (branch exists) | `favorite-stores` | forge:effort resume | `git checkout` (no `-b`); "resumed" confirmation |
| 3 | `effort/favorite-stores` | `favorite-stores` | SessionStart hook | No warning; output starts with `## Forge` |
| 4 | `main` | `favorite-stores` | SessionStart hook | `⚠️ Branch mismatch` warning at top; exit 0 |
| 5 | any | none | SessionStart hook | No warning; "no active efforts" message |
| 6 | `main` (local repo) | none (local) | forge:project | `effort/favorite-stores-backend` created; `coordinationRef` in `.state.json` |
