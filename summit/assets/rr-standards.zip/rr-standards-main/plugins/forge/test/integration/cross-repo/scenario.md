# Cross-Repository Effort — Test Scenario

**Task:** TASK-031
**Skills under test:** `forge:project`, `forge:upstream`, `forge:sync`, `forge:graduate`

---

## Setup

Before running any step, ensure the following repositories exist and are accessible
via the GitHub API:

**org/rewards-coordination** contains:

```
.forge/efforts/favorite-stores/
├── requirements/
│   └── business.md
├── plan/
│   └── plan.md
└── spec/
    └── system-flows.md
```

`plan/plan.md` must include a section that assigns responsibility to `backend` —
for example a table row or heading such as `## Backend Tasks`.

**org/rewards-backend** is initialized (`forge:init` has been run, `.forge/efforts/README.md`
exists). No `favorite-stores-backend` effort exists yet.

---

## Phase 1: Setup (Coordination Repository Artifacts)

**Repository:** `org/rewards-coordination`

This phase is pre-condition only — no forge commands are run here. The coordination
effort already exists as described in the Setup section above.

**Verify before proceeding:**

- `gh api repos/org/rewards-coordination/contents/.forge/efforts/favorite-stores/requirements/business.md` returns HTTP 200
- `gh api repos/org/rewards-coordination/contents/.forge/efforts/favorite-stores/plan/plan.md` returns HTTP 200

---

## Phase 2: Create Local Sub-Effort (forge:project)

**Repository:** `org/rewards-backend`

### Step 2.1 — Online: create the sub-effort

**Input prompt:**

> Let's start the backend work for the favorite-stores effort in the coordination repo.

The skill will ask for `--coordination-repo` and `--effort-id` if not provided.
Supply:

- `--coordination-repo org/rewards-coordination`
- `--effort-id favorite-stores`

When asked for the local deployable, answer: `backend`

When asked to confirm the proposed effort ID `favorite-stores-backend`, accept it.

When asked for a title, provide: `Favorite Stores — Backend`

**Expected outcomes:**

1. The skill fetches the plan from `org/rewards-coordination` and identifies the backend-scoped section.
2. The skill fetches `requirements/business.md` and `plan/plan.md` from the coordination effort.
3. Projected files are created:
   - `.forge/efforts/favorite-stores-backend/requirements/projected-business.md`
   - `.forge/efforts/favorite-stores-backend/plan/projected-plan.md`
4. Each projected file begins with a provenance header containing all five fields:
   ```
   <!-- forge:projection
     source_repo: org/rewards-coordination
     source_effort: favorite-stores
     source_file: .forge/efforts/favorite-stores/requirements/business.md
     source_commit: <blob-sha>
     projected_at: <ISO-8601>
   -->
   ```
5. `.forge/efforts/favorite-stores-backend/.state.json` exists and contains:
   ```json
   {
     "coordinationRef": {
       "branch": "main",
       "commitSha": "<head-sha-of-org/rewards-coordination>",
       "effortId": "favorite-stores",
       "projectedAt": "<ISO-8601>",
       "projections": [
         {
           "local": ".forge/efforts/favorite-stores-backend/requirements/projected-business.md",
           "source": ".forge/efforts/favorite-stores/requirements/business.md",
           "sourceSha": "<blob-sha>"
         },
         {
           "local": ".forge/efforts/favorite-stores-backend/plan/projected-plan.md",
           "source": ".forge/efforts/favorite-stores/plan/plan.md",
           "sourceSha": "<blob-sha>"
         }
       ],
       "repo": "org/rewards-coordination"
     },
     "id": "favorite-stores-backend",
     "title": "Favorite Stores — Backend"
   }
   ```
   (Other standard fields are present; only the cross-repo fields are listed above for brevity.)
6. `.forge/efforts/README.md` has a new row for `favorite-stores-backend` with parent reference `repo:org/rewards-coordination/favorite-stores`.
7. A git commit is created: `chore(favorite-stores-backend): create sub-effort from org/rewards-coordination/favorite-stores`

**Verify:**

- [ ] `projected-business.md` starts with `<!-- forge:projection`
- [ ] `source_repo` is `org/rewards-coordination`
- [ ] `source_effort` is `favorite-stores`
- [ ] `source_file` path matches the coordination repo path
- [ ] `source_commit` is a valid 40-character hex SHA (or abbreviated)
- [ ] `projected_at` is a valid ISO-8601 UTC timestamp
- [ ] `.state.json` has `coordinationRef.repo` = `org/rewards-coordination`
- [ ] `.state.json` has `coordinationRef.effortId` = `favorite-stores`
- [ ] `.state.json` has `coordinationRef.projections` with one entry per projected file
- [ ] `.forge/efforts/README.md` row contains `repo:org/rewards-coordination/favorite-stores`

---

### Step 2.2 — Offline variation: GitHub API unavailable

Simulate network failure by temporarily blocking the GitHub API (e.g., set an invalid
`GH_HOST`, or disconnect the test host from the network).

**Input prompt:**

> Let's start the backend work for the favorite-stores effort in the coordination repo.

Supply the same arguments as Step 2.1.

**Expected outcomes:**

1. The skill emits an error message in the standard format:
   ```
   Error: GitHub API unreachable for repos/org/rewards-coordination/contents/.forge/efforts/favorite-stores/plan/plan.md
   Reason: <network/auth error message>
   Action: Check network connectivity, run `gh auth login` to re-authenticate,
           and verify you have read access to org/rewards-coordination.
   No files were created. forge:project requires network access.
   ```
2. No files are created under `.forge/efforts/`.
3. `.forge/efforts/README.md` is not modified.
4. No git commit is made.

**Verify:**

- [ ] `.forge/efforts/favorite-stores-backend/` does not exist
- [ ] `.forge/efforts/README.md` is unchanged
- [ ] Error message names the specific unreachable URL
- [ ] Error message advises `gh auth login`

---

## Phase 3: Local Discovery Reveals Gap (forge:upstream)

**Repository:** `org/rewards-backend`

**Precondition:** Phase 2 (online) completed successfully. The `favorite-stores-backend` effort exists.

**Input prompt:**

> I realized the coordination requirements don't account for the pagination needed for mobile performance.

The skill will ask for clarifying information. Provide:

- **Target file:** `.forge/efforts/favorite-stores/requirements/business.md` (option 1 from the projected sources list)
- **Change description:** Add a pagination requirement for the favorites list endpoint to support mobile clients fetching stores in pages of 20
- **Rationale:** During backend API implementation, the favorites list endpoint was found to return the full store list in a single response. Mobile clients need paginated responses for acceptable performance; the coordination requirements do not specify this constraint.
- **Proposed content:** Add a requirement under the "Favorites List" section: "The favorites list endpoint MUST support cursor-based pagination with a default page size of 20 items and a maximum of 100 items per page."

**Expected outcomes:**

1. `upstream-proposals/001-add-pagination-requirement.md` is created at:
   `.forge/efforts/favorite-stores-backend/upstream-proposals/001-add-pagination-requirement.md`
2. The proposal document contains all required sections:
   - `# Upstream Proposal 001: Add Pagination Requirement`
   - `**Status:** proposed`
   - `**Target repository:** org/rewards-coordination`
   - `**Target file:** .forge/efforts/favorite-stores/requirements/business.md`
   - `**Created:** <ISO-8601>`
   - `## Change Description`
   - `## Rationale`
   - `## Proposed Content`
3. `.forge/efforts/favorite-stores-backend/.state.json` has one entry in `upstreamProposals`:
   ```json
   {
     "file": "upstream-proposals/001-add-pagination-requirement.md",
     "id": "001",
     "prUrl": null,
     "status": "proposed",
     "targetFile": ".forge/efforts/favorite-stores/requirements/business.md",
     "targetRepo": "org/rewards-coordination"
   }
   ```
4. A git commit is created: `docs(favorite-stores-backend): add upstream proposal 001`

**Verify:**

- [ ] File exists at `.forge/efforts/favorite-stores-backend/upstream-proposals/001-add-pagination-requirement.md`
- [ ] File has `**Status:** proposed`
- [ ] File has `**Target repository:** org/rewards-coordination`
- [ ] File has `**Target file:**` pointing to the coordination repo's requirements file
- [ ] File has all three required sections (`## Change Description`, `## Rationale`, `## Proposed Content`)
- [ ] `.state.json` `upstreamProposals` array has exactly one entry
- [ ] `upstreamProposals[0].status` = `"proposed"`
- [ ] `upstreamProposals[0].prUrl` = `null`
- [ ] `upstreamProposals[0].id` = `"001"`

---

### Step 3.1 — With --pr flag variation

Run the same prompt as Phase 3 but append `--pr` after describing the gap.

**Additional expected outcomes** (beyond those in Phase 3):

1. `gh pr create` is called against `org/rewards-coordination`.
2. On success: `.state.json` `upstreamProposals[0].prUrl` is set to the returned PR URL (non-null).
3. A second commit is created: `docs(favorite-stores-backend): record PR URL for upstream proposal 001`

**Offline variation (--pr, no network):**

1. The proposal document is written and committed locally (same as Phase 3 outcomes).
2. `gh pr create` fails; the skill prints a warning with the error reason and the manual `gh pr create` command.
3. `.state.json` `upstreamProposals[0].prUrl` remains `null`.
4. No second commit is made.

**Verify (--pr offline):**

- [ ] Proposal document exists locally
- [ ] `prUrl` = `null` in `.state.json`
- [ ] Warning message includes `gh pr create --repo org/rewards-coordination`

---

## Phase 4: Coordination Updated, Projection Stale (forge:sync)

**Repository:** `org/rewards-backend`

**Setup:** Push an update to `org/rewards-coordination` that adds the pagination
requirement to `.forge/efforts/favorite-stores/requirements/business.md`. Record:

- `OLD_SHA` — the `source_commit` value currently in `projected-business.md`'s provenance header (from Phase 2)
- `NEW_SHA` — the new blob SHA of `requirements/business.md` after the update

### Step 4.1 — Detect staleness (no --rematerialise)

**Input prompt:**

> Let's check if our projections are still current.

**Expected outcomes:**

1. `forge:sync` reads `coordinationRef.projections` from `.state.json`.
2. For `projected-business.md`, the remote blob SHA differs from `sourceSha`.
3. Output includes:
   ```
   favorite-stores-backend:

     stale        .forge/efforts/favorite-stores-backend/requirements/projected-business.md
                  local:   <OLD_SHA>
                  current: <NEW_SHA>
     current      .forge/efforts/favorite-stores-backend/plan/projected-plan.md

   Summary: 1 current, 1 stale, 0 unreachable

   Run with --rematerialise to update stale projections.
   ```
4. No files are modified. No commit is made.

**Verify:**

- [ ] Output shows `stale` for `projected-business.md`
- [ ] `local:` value matches the `source_commit` in the existing provenance header (`OLD_SHA`)
- [ ] `current:` value is `NEW_SHA` (differs from `OLD_SHA`)
- [ ] `projected-business.md` is not modified (provenance header still shows `OLD_SHA`)
- [ ] `.state.json` is not modified

---

### Step 4.2 — Re-materialise stale projection (--rematerialise)

**Input prompt:**

> Let's check if our projections are still current and update any that are stale.

Or equivalently, run `forge:sync --rematerialise` directly.

**Expected outcomes:**

1. `forge:sync` detects the same staleness as Step 4.1.
2. The stale `projected-business.md` is fetched from `org/rewards-coordination` and rewritten.
3. The rewritten file's provenance header contains the new SHA:
   ```
   <!-- forge:projection
     source_repo: org/rewards-coordination
     source_effort: favorite-stores
     source_file: .forge/efforts/favorite-stores/requirements/business.md
     source_commit: <NEW_SHA>
     projected_at: <new-ISO-8601>
   -->
   ```
4. `.state.json` `coordinationRef.projections` entry for `projected-business.md` has `sourceSha` updated to `NEW_SHA`.
5. `.state.json` `coordinationRef.commitSha` is updated to the new HEAD SHA of `org/rewards-coordination`.
6. `.state.json` `coordinationRef.projectedAt` is updated to the new timestamp.
7. A git commit is created: `chore(favorite-stores-backend): update stale projections from rewards-coordination`
8. Output includes a re-materialisation summary:
   ```
   forge:sync complete

     Re-materialised:
       .forge/efforts/favorite-stores-backend/requirements/projected-business.md
         source_commit: <OLD_SHA> → <NEW_SHA>

     Unchanged (already current):
       .forge/efforts/favorite-stores-backend/plan/projected-plan.md

     .state.json updated for: favorite-stores-backend
     Committed: chore(favorite-stores-backend): update stale projections from rewards-coordination
   ```

**Verify:**

- [ ] `projected-business.md` provenance header `source_commit` = `NEW_SHA`
- [ ] `projected-business.md` provenance header `projected_at` is a newer timestamp than from Phase 2
- [ ] `.state.json` `coordinationRef.projections[0].sourceSha` = `NEW_SHA`
- [ ] `.state.json` `coordinationRef.commitSha` reflects the latest HEAD of `org/rewards-coordination`
- [ ] Commit message matches `chore(favorite-stores-backend): update stale projections from rewards-coordination`

---

### Step 4.3 — Offline variation (forge:sync, no network)

Simulate network failure. Run `forge:sync` (without `--rematerialise`).

**Expected outcomes:**

1. Each projection is classified as `unreachable` with the error reason.
2. Output includes:
   ```
   favorite-stores-backend:

     unreachable  .forge/efforts/favorite-stores-backend/requirements/projected-business.md
                  reason: <network error>
     unreachable  .forge/efforts/favorite-stores-backend/plan/projected-plan.md
                  reason: <network error>

   Summary: 0 current, 0 stale, 2 unreachable

   Could not reach the coordination repository. Local projections remain usable;
   staleness could not be determined.
   ```
3. No files are modified. No commit is made.

**Verify:**

- [ ] Output contains `unreachable` for all projections
- [ ] Output contains the "Local projections remain usable" message
- [ ] `projected-business.md` and `projected-plan.md` are unmodified
- [ ] `.state.json` is unmodified

---

## Phase 5: Local Efforts Complete and Graduate (forge:graduate)

**Repository:** `org/rewards-backend`

**Precondition:** All implementation tasks in `favorite-stores-backend` are complete;
verification has passed; QA has signed off. The `.state.json` has at least one entry
in `deployables` (e.g., `"deployables": ["backend"]`).

### Step 5.1 — Graduate the backend sub-effort

**Input prompt:**

> Graduate the favorite-stores-backend effort.

**Expected outcomes:**

1. `forge:graduate` reads `.forge/efforts/favorite-stores-backend/.state.json`.
2. For each deployable listed (e.g., `backend`), the effort's requirements and
   spec artifacts are merged into the canonical deployable documentation.
3. `.state.json` is updated:
   - `graduation.graduated` = `true`
   - `graduation.graduatedAt` = `<ISO-8601>`
   - `graduation.graduatedTo` = list of canonical doc paths updated
4. The effort is removed from (or marked closed in) the active registry in `.forge/efforts/README.md`.
5. A graduation commit is created.

**Verify:**

- [ ] `.state.json` `graduation.graduated` = `true`
- [ ] `.state.json` `graduation.graduatedAt` is a valid ISO-8601 timestamp
- [ ] `.state.json` `graduation.graduatedTo` is non-empty
- [ ] `.forge/efforts/README.md` no longer shows `favorite-stores-backend` as an active effort
- [ ] Canonical deployable documentation for `backend` contains merged content from the effort

---

### Step 5.2 — Graduation with businessProducts (coordination effort)

**Repository:** `org/rewards-coordination`

**Precondition:** The coordination effort `favorite-stores` has `businessProducts`
populated (e.g., `"businessProducts": ["rewards-app"]`). All sub-efforts are
confirmed closed.

**Input prompt:**

> Graduate the favorite-stores effort in the coordination repo.

**Expected outcomes:**

1. `forge:graduate` reads `.forge/efforts/favorite-stores/.state.json`.
2. For each product in `businessProducts`, product documentation is updated.
3. The coordination registry reflects all sub-efforts closed.
4. `graduation.graduated` = `true` in the coordination effort's `.state.json`.

**Verify:**

- [ ] `.state.json` `graduation.graduated` = `true` for the coordination effort
- [ ] Product documentation updated for each entry in `businessProducts`
- [ ] `.forge/efforts/README.md` in `org/rewards-coordination` shows `favorite-stores` as graduated

---

## Scenario Summary

| Phase | Skill | Repository | Key assertion |
|-------|-------|------------|---------------|
| 2 (online) | `forge:project` | rewards-backend | Projected files created with all 5 provenance header fields |
| 2 (offline) | `forge:project` | rewards-backend | No files created; clear error message; no partial state |
| 3 | `forge:upstream` | rewards-backend | Proposal doc created; `.state.json` `upstreamProposals` updated |
| 3 (--pr) | `forge:upstream` | rewards-backend | PR created; `prUrl` recorded in `.state.json` |
| 4.1 | `forge:sync` | rewards-backend | Stale projection reported with old and new SHA |
| 4.2 | `forge:sync --rematerialise` | rewards-backend | Projection rewritten with new SHA in header and `.state.json` |
| 4.3 (offline) | `forge:sync` | rewards-backend | All projections unreachable; no modifications; usability message shown |
| 5.1 | `forge:graduate` | rewards-backend | Backend deployable docs updated; effort marked graduated |
| 5.2 | `forge:graduate` | rewards-coordination | Product docs updated; coordination effort marked graduated |
