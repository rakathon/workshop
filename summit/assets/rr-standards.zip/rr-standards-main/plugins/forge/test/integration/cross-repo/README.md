# Cross-Repository Effort — Integration Test Scenario

**Task:** TASK-031
**Capabilities under test:** `forge:project`, `forge:upstream`, `forge:sync`, `forge:graduate`
**Requirements:** BR-10, TR-4–6, TR-14, ADR-003
**Spec:** Cross-Repository Information Flow (all sections)

---

## What This Scenario Tests

This scenario exercises the full cross-repository effort lifecycle:

1. A coordination effort exists in a separate repository and contains cross-cutting
   requirements and a high-level plan.
2. `forge:project` fetches those artifacts via the GitHub API, materialises them as
   local projected files with provenance headers, and scaffolds a local sub-effort.
3. Local implementation work reveals a gap in the coordination requirements.
   `forge:upstream` records the proposed change and optionally creates a PR.
4. The coordination repository is updated to incorporate the gap. `forge:sync`
   detects the resulting staleness and re-materialises the projection.
5. Both the local sub-effort and the coordination effort graduate, producing correct
   canonical documentation.

---

## Repositories Required

| Repository | Role | Expected contents |
|------------|------|-------------------|
| `org/rewards-coordination` | Coordination (remote) | `.forge/efforts/favorite-stores/` with `requirements/business.md`, `plan/plan.md`, and `spec/` directory |
| `org/rewards-backend` | Local (backend sub-effort) | Initialized with `forge:init`; no `favorite-stores-backend` effort yet |

### Coordination Repository Seed Files

Before running this scenario, the coordination repository must contain:

```
.forge/efforts/favorite-stores/
├── requirements/
│   └── business.md          — user-facing requirements for the Favorite Stores feature
├── plan/
│   └── plan.md              — high-level plan with a backend-scoped section
└── spec/
    └── (system-level flow files)
```

The `plan/plan.md` must include a section that identifies `backend` as a responsible
deployable (e.g., a table row or heading that names the backend service).

---

## Key Verification Points

| Phase | What to verify |
|-------|----------------|
| forge:project | Provenance header contains all 5 fields: `source_repo`, `source_effort`, `source_file`, `source_commit`, `projected_at` |
| forge:project | `.state.json` has `coordinationRef` with `repo`, `effortId`, `branch`, `commitSha`, `projectedAt`, `projections` |
| forge:project | `.forge/efforts/README.md` row includes `repo:org/rewards-coordination/favorite-stores` as parent ref |
| forge:project (offline) | No files created; error message names the unreachable URL and advises `gh auth login` |
| forge:upstream | `upstream-proposals/001-add-pagination-requirement.md` created with all required sections |
| forge:upstream | `.state.json` `upstreamProposals` array has one entry with `status: "proposed"` |
| forge:sync (stale) | Reports `stale` with `local: <old-sha>` and `current: <new-sha>` per projection |
| forge:sync --rematerialise | Stale projection rewritten; provenance header `source_commit` updated to new SHA |
| forge:sync --rematerialise | `.state.json` `coordinationRef.projections[*].sourceSha` updated |
| forge:graduate | Each graduation updates its deployable's canonical docs |
| forge:graduate | Coordination registry reflects all sub-efforts closed |

---

## Related Skills

- [`plugins/forge/skills/cross-repo/project/SKILL.md`](../../../skills/cross-repo/project/SKILL.md)
- [`plugins/forge/skills/cross-repo/sync/SKILL.md`](../../../skills/cross-repo/sync/SKILL.md)
- [`plugins/forge/skills/cross-repo/upstream/SKILL.md`](../../../skills/cross-repo/upstream/SKILL.md)
- [`plugins/forge/skills/graduate/SKILL.md`](../../../skills/graduate/SKILL.md)

---

## Running the Scenario

Open `scenario.md` and follow each step in sequence. Each step specifies which
repository to use, the input prompt, and the exact outcomes to verify.
