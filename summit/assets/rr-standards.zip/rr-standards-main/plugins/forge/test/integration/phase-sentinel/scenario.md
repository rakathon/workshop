# Integration Test Scenario: Phase Sentinel

**Effort:** `loyalty-tiers` (used across sub-scenarios; reset between sub-scenarios)
**Type:** story | **Tier:** full | **Risk:** R3

Each sub-scenario below is independent. Reset the effort state between them
by deleting `.forge/efforts/loyalty-tiers/` and the registry row before starting
the next sub-scenario.

---

## Sub-Scenario A: forge:plan triggers discovery → planning + planning → implementation

Tests that invoking `forge:plan` while in discovery:
1. Offers to advance discovery → planning (Phase Entry Check)
2. After writing tasks.md, offers to advance planning → implementation (Phase Completion Check)

### Setup

Create an effort in discovery phase with all discovery artifacts present and a
passing validation report:

```bash
mkdir -p .forge/efforts/loyalty-tiers/requirements
mkdir -p .forge/efforts/loyalty-tiers/spec/api
mkdir -p .forge/efforts/loyalty-tiers/validation

# Minimal business requirements
cat > .forge/efforts/loyalty-tiers/requirements/business.md << 'EOF'
### BR-1: Tier Assignment
Members are assigned a loyalty tier (Bronze, Silver, Gold) based on annual spend.
EOF

# Minimal technical requirements
cat > .forge/efforts/loyalty-tiers/requirements/technical.md << 'EOF'
### TR-1: Tier Computation
Tier must be recomputed within 5 seconds of a qualifying transaction.
EOF

# Passing validation report
cat > .forge/efforts/loyalty-tiers/validation/report.md << 'EOF'
# Validation Report
**Result:** PASS
EOF

# Initial .state.json in discovery phase
cat > .forge/efforts/loyalty-tiers/.state.json << 'EOF'
{
  "id": "loyalty-tiers",
  "title": "Loyalty Tier Assignment",
  "type": "story",
  "tier": "full",
  "risk": "R3",
  "currentPhase": "discovery",
  "phases": {
    "discovery": { "status": "in_progress" },
    "planning": { "status": "not_started" },
    "implementation": { "status": "not_started" },
    "verification": { "status": "not_started" },
    "review": { "status": "not_started" }
  }
}
EOF
```

Add a registry row (phase=discovery, status=in_progress) to `.forge/efforts/README.md`.

### A.1 — forge:plan Phase Entry Check fires

**Input prompt:**
> "Generate the implementation plan for loyalty-tiers."

**Expected: Phase Entry Check fires before plan generation**

Claude should NOT immediately start generating tasks. Instead, it should first
invoke `forge:promote loyalty-tiers --target planning`, which shows:

```
Discovery readiness for loyalty-tiers:
  ✓ requirements/business.md — present
  ✓ requirements/technical.md — present
  ✓ validation/report.md — PASS
  ...

Advance discovery → planning? (yes/no)
```

Claude must wait for the engineer's response before proceeding.

**Verification before answering:**
```bash
jq '.currentPhase' .forge/efforts/loyalty-tiers/.state.json
# Expected: "discovery"
```

---

### A.2 — Confirm advancement

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` updated — discovery approved, now in planning:
   ```bash
   jq '{currentPhase: .currentPhase, discovery: .phases.discovery.status}' \
     .forge/efforts/loyalty-tiers/.state.json
   # Expected:
   # {
   #   "currentPhase": "planning",
   #   "discovery": "approved"
   # }
   ```

2. Commit created for discovery approval:
   ```bash
   git log --oneline -3
   # Expected: one commit matching "chore(loyalty-tiers): approve discovery phase"
   ```

3. Claude proceeds to generate tasks.md.

---

### A.3 — Phase Completion Check fires after tasks.md is written

After forge:plan writes and commits `plan/tasks.md`, it should invoke
`forge:promote loyalty-tiers --target implementation`, offering:

```
Plan complete with N tasks.
Advance planning → implementation? (yes/no)
```

**Verification that tasks.md exists before advancing:**
```bash
ls .forge/efforts/loyalty-tiers/plan/tasks.md
# Expected: file exists
```

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` updated — planning approved, now in implementation:
   ```bash
   jq '{currentPhase: .currentPhase, planning: .phases.planning.status}' \
     .forge/efforts/loyalty-tiers/.state.json
   # Expected:
   # {
   #   "currentPhase": "implementation",
   #   "planning": "approved"
   # }
   ```

2. Two promotion commits exist (one per phase approved):
   ```bash
   git log --oneline -5 | grep "approve"
   # Expected: two lines:
   #   "chore(loyalty-tiers): approve planning phase"
   #   "chore(loyalty-tiers): approve discovery phase"
   ```

3. Registry reflects implementation phase:
   ```bash
   grep "loyalty-tiers" .forge/efforts/README.md
   # Expected: row with "implementation" in the phase column
   ```

---

## Sub-Scenario B: forge:commit fallback — planning → implementation

Tests that `forge:commit` triggers planning → implementation when forge:plan's
Phase Completion Check was declined.

### Setup

Same as Sub-Scenario A setup, but start with `currentPhase = "planning"`,
`phases.planning.status = "in_progress"`, and a `plan/tasks.md` that exists.

### B.1 — forge:commit Phase Entry Check fires

Stage any file and invoke forge:commit:

**Input prompt:**
> "commit my changes"

**Expected: Phase Entry Check fires before staging/committing**

Claude should invoke `forge:promote loyalty-tiers --target implementation`, showing:

```
Planning readiness for loyalty-tiers:
  ✓ plan/tasks.md — present (N tasks)

Advance planning → implementation? (yes/no)
```

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` shows implementation:
   ```bash
   jq '.currentPhase' .forge/efforts/loyalty-tiers/.state.json
   # Expected: "implementation"
   ```

2. Commit for planning approval created:
   ```bash
   git log --oneline -3 | grep "approve planning"
   # Expected: one match
   ```

3. forge:commit then proceeds with the normal commit flow (staging, message proposal, etc.).

---

## Sub-Scenario C: Multi-step jump — forge:commit from discovery

Tests that `forge:commit` invoked while effort is in discovery offers to advance
through two phases (discovery → planning → implementation) at once.

### Setup

Same as Sub-Scenario A setup: `currentPhase = "discovery"`, all discovery artifacts
present, validation/report.md exists.

### C.1 — forge:commit invoked from discovery

**Input prompt:**
> "commit my implementation work"

**Expected: Multi-step Phase Entry Check fires**

Claude should invoke `forge:promote loyalty-tiers --target implementation`.
Because there are two phases in the gap (discovery and planning), the prompt shows:

```
Discovery readiness for loyalty-tiers:
  ✓ requirements/business.md — present
  ✓ requirements/technical.md — present
  ✓ validation/report.md — PASS

Planning readiness:
  ✗ plan/tasks.md — not found (you can still advance, but no task list exists)

Advance discovery → planning → implementation? (yes/no)
```

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` shows two phases approved and currentPhase=implementation:
   ```bash
   jq '{
     currentPhase: .currentPhase,
     discovery: .phases.discovery.status,
     planning: .phases.planning.status
   }' .forge/efforts/loyalty-tiers/.state.json
   # Expected:
   # {
   #   "currentPhase": "implementation",
   #   "discovery": "approved",
   #   "planning": "approved"
   # }
   ```

2. Two promotion commits, one per phase:
   ```bash
   git log --oneline -5 | grep "approve"
   # Expected: two lines (planning then discovery, newest first):
   #   "chore(loyalty-tiers): approve planning phase"
   #   "chore(loyalty-tiers): approve discovery phase"
   ```

3. forge:commit then proceeds with the normal commit flow.

---

## Sub-Scenario D: Validation gate — no validation/report.md

Tests that the validation gate fires when advancing out of discovery without a
validation report present.

### Setup

Same as Sub-Scenario A but omit `validation/report.md`:

```bash
rm -f .forge/efforts/loyalty-tiers/validation/report.md
```

### D.1 — forge:plan invoked without a validation report

**Input prompt:**
> "Generate the plan for loyalty-tiers."

**Expected: Validation gate fires inside forge:promote**

Before asking about phase advancement, Claude should show:

```
Discovery readiness for loyalty-tiers:
  ✓ requirements/business.md — present
  ✓ requirements/technical.md — present
  ✗ validation/report.md — not found

No validation report found. Run forge:validate before advancing
out of discovery? (yes/no/skip)
```

Claude must wait for a response before proceeding.

### D.2a — Engineer chooses to validate first

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `forge:validate` is invoked inline.
2. After forge:validate completes, `validation/report.md` is present:
   ```bash
   ls .forge/efforts/loyalty-tiers/validation/report.md
   # Expected: file exists
   ```
3. The phase advancement prompt then appears normally.

### D.2b — Engineer skips validation (alternate path)

**Reset to D.1 state** (delete validation/report.md again).

**Input prompt at D.1:**
> "Generate the plan for loyalty-tiers."

When the validation gate prompt appears:

**Input prompt:**
> "skip"

**Expected outcomes:**

1. `validation/report.md` is still absent (no forced creation):
   ```bash
   ls .forge/efforts/loyalty-tiers/validation/report.md
   # Expected: no such file
   ```

2. The phase advancement prompt then appears:
   ```
   Advance discovery → planning? (yes/no)
   ```

3. After confirming, `.state.json` discovery.status = "approved" despite no validation report.

---

## Sub-Scenario E: forge:verify triggers implementation → verification + verification → review

Tests Phase Entry and Completion Checks in forge:verify.

### Setup

Create effort in implementation phase with all tasks complete:

```bash
mkdir -p .forge/efforts/loyalty-tiers/requirements
mkdir -p .forge/efforts/loyalty-tiers/plan
mkdir -p .forge/efforts/loyalty-tiers/validation

cat > .forge/efforts/loyalty-tiers/requirements/business.md << 'EOF'
### BR-1: Tier Assignment
Members are assigned a loyalty tier based on annual spend.
EOF

cat > .forge/efforts/loyalty-tiers/plan/tasks.md << 'EOF'
# Implementation Plan: Loyalty Tier Assignment
- [x] [auto][wave:1] Create tier computation service (TASK-001) (abc1234)
EOF

cat > .forge/efforts/loyalty-tiers/.state.json << 'EOF'
{
  "id": "loyalty-tiers",
  "title": "Loyalty Tier Assignment",
  "type": "story",
  "tier": "full",
  "risk": "R3",
  "currentPhase": "implementation",
  "phases": {
    "discovery": { "status": "approved" },
    "planning": { "status": "approved" },
    "implementation": { "status": "in_progress", "completedTasks": ["TASK-001"], "remainingTasks": [] },
    "verification": { "status": "not_started" },
    "review": { "status": "not_started" }
  }
}
EOF
```

### E.1 — forge:verify Phase Entry Check fires

**Input prompt:**
> "Run verification on loyalty-tiers."

**Expected: Phase Entry Check fires before spawning the verification worker**

Claude should invoke `forge:promote loyalty-tiers --target verification`, showing:

```
Implementation readiness for loyalty-tiers:
  ✓ plan/tasks.md — 1/1 tasks complete

Advance implementation → verification? (yes/no)
```

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` updated:
   ```bash
   jq '{currentPhase: .currentPhase, impl: .phases.implementation.status}' \
     .forge/efforts/loyalty-tiers/.state.json
   # Expected:
   # {
   #   "currentPhase": "verification",
   #   "impl": "approved"
   # }
   ```

2. Commit created:
   ```bash
   git log --oneline -3 | grep "approve implementation"
   # Expected: one match
   ```

3. forge:verify then spawns the verification worker and produces `verification/report.md`.

---

### E.2 — Phase Completion Check fires after PASS

After the verification worker produces a PASS report, Claude should invoke
`forge:promote loyalty-tiers --target review`, showing:

```
Verification passed.
Advance verification → review? (yes/no)
```

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` updated:
   ```bash
   jq '{currentPhase: .currentPhase, verification: .phases.verification.status}' \
     .forge/efforts/loyalty-tiers/.state.json
   # Expected:
   # {
   #   "currentPhase": "review",
   #   "verification": "approved"
   # }
   ```

2. Commit created:
   ```bash
   git log --oneline -3 | grep "approve verification"
   # Expected: one match
   ```

---

## Sub-Scenario F: No-op — Phase Entry Check is silent when already at target

Tests that Phase Entry Checks produce no prompt and no state change when the
effort is already in the correct phase.

### Setup

Create effort with `currentPhase = "implementation"`.

### F.1 — forge:commit Phase Entry Check is a no-op

**Input prompt:**
> "commit my changes"

**Expected:**

1. Claude proceeds directly to the staging step — no phase advancement prompt appears.
2. `.state.json` is unchanged:
   ```bash
   jq '.currentPhase' .forge/efforts/loyalty-tiers/.state.json
   # Expected: "implementation" (unchanged)
   ```

### F.2 — forge:plan Phase Entry Check is a no-op (already in planning)

**Setup:** Set `currentPhase = "planning"`.

**Input prompt:**
> "Generate the implementation plan for loyalty-tiers."

**Expected:**

1. Claude proceeds directly to reading requirements — no advancement prompt for
   discovery → planning appears.
2. Phase Completion Check for planning → implementation fires normally after
   tasks.md is written.

---

## Sub-Scenario G: forge:promote --target direct invocation

Tests `forge:promote --target <phase>` invoked explicitly by the engineer.

### Setup

Create effort with `currentPhase = "discovery"`, all artifacts present,
validation/report.md with PASS.

### G.1 — Engineer explicitly promotes to implementation

**Input prompt:**
> "forge:promote loyalty-tiers --target implementation"

**Expected: Full gap summary shown**

```
Discovery readiness for loyalty-tiers:
  ✓ requirements/business.md — present
  ✓ requirements/technical.md — present
  ✓ validation/report.md — PASS

Planning readiness:
  ✗ plan/tasks.md — not found

Advance discovery → planning → implementation? (yes/no)
```

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` shows both phases approved:
   ```bash
   jq '{
     currentPhase: .currentPhase,
     discovery: .phases.discovery.status,
     planning: .phases.planning.status
   }' .forge/efforts/loyalty-tiers/.state.json
   # Expected:
   # {
   #   "currentPhase": "implementation",
   #   "discovery": "approved",
   #   "planning": "approved"
   # }
   ```

2. Two promotion commits (one per phase):
   ```bash
   git log --oneline -5 | grep "approve"
   # Expected: "chore(loyalty-tiers): approve planning phase"
   #           "chore(loyalty-tiers): approve discovery phase"
   ```

### G.2 — Engineer declines

**Reset to G.1 state.**

**Input prompt:**
> "forge:promote loyalty-tiers --target implementation"

When the prompt appears:

**Input prompt:**
> "no"

**Expected outcomes:**

1. `.state.json` is unchanged — currentPhase still "discovery":
   ```bash
   jq '.currentPhase' .forge/efforts/loyalty-tiers/.state.json
   # Expected: "discovery"
   ```

2. No new commits:
   ```bash
   git log --oneline -3 | grep "approve"
   # Expected: no output
   ```

---

## End-to-End State Transition Summary

```
Sub-Scenario A:
  discovery (in_progress)
    → discovery (approved)         ← forge:plan Phase Entry Check, confirmed
    → planning (in_progress)       ← auto
    → planning (approved)          ← forge:plan Phase Completion Check, confirmed
    → implementation (in_progress) ← auto

Sub-Scenario B:
  planning (in_progress)
    → planning (approved)          ← forge:commit Phase Entry Check, confirmed
    → implementation (in_progress) ← auto

Sub-Scenario C (multi-step):
  discovery (in_progress)
    → discovery (approved)         ← forge:commit Phase Entry Check (multi-step), confirmed
    → planning (approved)          ← same confirmation, same operation
    → implementation (in_progress) ← auto

Sub-Scenario D:
  discovery (in_progress)
    → (forge:validate offered)     ← validation gate in forge:promote
    → discovery (approved)         ← confirmation after validation
    → planning (in_progress)       ← auto

Sub-Scenario E:
  implementation (in_progress)
    → implementation (approved)    ← forge:verify Phase Entry Check, confirmed
    → verification (in_progress)   ← auto
    → (worker runs)
    → verification (approved)      ← forge:verify Phase Completion Check (PASS), confirmed
    → review (in_progress)         ← auto

Sub-Scenario F:
  implementation (in_progress)
    → (no prompt, forge:commit proceeds silently)

Sub-Scenario G:
  discovery (in_progress)
    → discovery (approved)         ← forge:promote --target implementation, confirmed
    → planning (approved)          ← same confirmation
    → implementation (in_progress) ← auto
```
