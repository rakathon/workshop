# Integration Test: Full-Tier Single-Repo Lifecycle

**Effort:** `favorite-stores`
**Type:** epic | **Tier:** full | **Risk:** R2
**Reference:** `.forge/efforts/forge-workflow/spec/user-flow.md`

---

## Prerequisites Check

Before starting, confirm the environment is clean:

```bash
cat .forge/efforts/README.md
# Expected: no row for "favorite-stores"

ls .forge/efforts/
# Expected: no "favorite-stores" directory
```

---

## Phase 1: Discovery

### Step 1.1 — Effort Creation from Product Brief

**Session context:** Engineer opens Claude Code. No active efforts exist.

**SessionStart hook expected output:**
```
## Forge — Active Workflow Context

No active efforts found in this repository.

The .forge/ directory is initialized. When you're ready to start a new piece of
work, describe what you need to build and Forge will scaffold the effort.
```

**Input prompt:**
> "We've got a new feature to build. The PM sent over a brief for Favorite Stores —
> members should be able to save stores they visit often and get them back quickly.
> Here's the document:
>
> Title: Favorite Stores
> Goal: Allow members to bookmark stores for quick access
> User stories:
>   - As a member, I can add a store to my favorites
>   - As a member, I can view my list of favorite stores
>   - As a member, I can remove a store from my favorites
>   - As a member, my favorites persist across sessions and devices
> Constraints:
>   - Max 50 favorites per member
>   - Must work offline (cached on device)
>   - Response time < 200ms for favorites retrieval
> Out of scope: Store recommendations based on favorites (future work)"

**Expected outcomes:**

1. Effort directory scaffolded:
   ```bash
   ls .forge/efforts/favorite-stores/
   # Expected: .state.json
   # (subdirectories are created on first use by forge:elaborate, forge:spec-*, forge:plan)
   ```

2. `.state.json` created with correct initial values:
   ```bash
   jq '{type, tier, currentPhase, "discovery_status": .phases.discovery.status}' \
     .forge/efforts/favorite-stores/.state.json
   # Expected:
   # {
   #   "type": "epic",
   #   "tier": "full",
   #   "currentPhase": "discovery",
   #   "discovery_status": "in_progress"
   # }
   ```

3. Registry row added to `.forge/efforts/README.md`:
   ```bash
   grep "favorite-stores" .forge/efforts/README.md
   # Expected: row containing "favorite-stores", "discovery", "in_progress"
   ```

4. Claude responds with clarifying questions (no explicit forge command was used):
   - Response asks about soft-delete vs hard-delete for removal
   - Response asks about whether the 50-store limit is global or per-region

---

### Step 1.2 — Business Requirements Extraction

**Input prompt:**
> "Hard delete is fine. The limit is global per member — same 50 stores regardless
> of region."

**Expected outcomes:**

1. Business requirements file written:
   ```bash
   ls .forge/efforts/favorite-stores/requirements/business.md
   # Expected: file exists
   ```

2. Requirements contain all five BRs:
   ```bash
   grep -c "^### BR-" .forge/efforts/favorite-stores/requirements/business.md
   # Expected: 5
   ```

3. BR-4 captures global limit and hard-delete decisions:
   ```bash
   grep -i "global" .forge/efforts/favorite-stores/requirements/business.md
   # Expected: line referencing global per-member limit
   grep -i "permanent\|hard.delete\|hard delete" \
     .forge/efforts/favorite-stores/requirements/business.md
   # Expected: at least one match
   ```

4. `.state.json` updated by PostToolUse hook:
   ```bash
   jq '.phases.discovery.artifacts.requirements.business' \
     .forge/efforts/favorite-stores/.state.json
   # Expected: "present"
   ```

---

### Step 1.3 — Technical Requirements

**Session context:** New session (Session 2). SessionStart hook fires.

**SessionStart hook expected output includes:**
```
**Current effort:** favorite-stores (epic)
**Phase:** discovery (in_progress)
**Artifacts:**
- requirements/business.md ✓
- requirements/technical.md (absent)
```

**Input prompt:**
> "Let's think through the technical requirements. This is a backend API — the iOS
> and Android apps will consume it. We're using PostgreSQL for storage. We already
> have a Redis cluster for caching."

**Expected outcomes:**

1. Technical requirements file written:
   ```bash
   ls .forge/efforts/favorite-stores/requirements/technical.md
   # Expected: file exists
   ```

2. Requirements contain all six TRs:
   ```bash
   grep -c "^### TR-" .forge/efforts/favorite-stores/requirements/technical.md
   # Expected: 6
   ```

3. TR-4 references both PostgreSQL and Redis:
   ```bash
   grep -i "postgresql\|postgres" .forge/efforts/favorite-stores/requirements/technical.md
   grep -i "redis" .forge/efforts/favorite-stores/requirements/technical.md
   # Expected: at least one match each
   ```

4. TR-5 addresses atomicity / race condition concern:
   ```bash
   grep -i "atomic\|race\|concurrent" \
     .forge/efforts/favorite-stores/requirements/technical.md
   # Expected: at least one match
   ```

5. `.state.json` updated:
   ```bash
   jq '.phases.discovery.artifacts.requirements.technical' \
     .forge/efforts/favorite-stores/.state.json
   # Expected: "present"
   ```

---

### Step 1.4 — API Specification

**Input prompt:**
> "Let's design the API. I'm thinking three endpoints: add, remove, and list."

**Expected outcomes:**

1. API spec file written:
   ```bash
   ls .forge/efforts/favorite-stores/spec/api/favorites-api.yaml
   # Expected: file exists
   ```

2. Spec defines all three operations:
   ```bash
   grep -c "summary:" .forge/efforts/favorite-stores/spec/api/favorites-api.yaml
   # Expected: 3
   ```

3. Auth is required on all endpoints:
   ```bash
   grep -c "security\|bearerAuth" .forge/efforts/favorite-stores/spec/api/favorites-api.yaml
   # Expected: at least 1
   ```

4. POST returns both 200 (duplicate) and 201 (new):
   ```bash
   grep -A2 "post:" .forge/efforts/favorite-stores/spec/api/favorites-api.yaml | grep "200:"
   grep -A2 "post:" .forge/efforts/favorite-stores/spec/api/favorites-api.yaml | grep "201:"
   # Expected: both present
   ```

5. `.state.json` updated:
   ```bash
   jq '.phases.discovery.artifacts.spec.api' \
     .forge/efforts/favorite-stores/.state.json
   # Expected: "present"
   ```

---

### Step 1.5 — Storage Schema

**Input prompt:**
> "What should the schema look like?"

**Expected outcomes:**

1. Storage schema file written:
   ```bash
   ls .forge/efforts/favorite-stores/spec/storage/favorites-schema.md
   # Expected: file exists
   ```

2. Schema covers both PostgreSQL and Redis:
   ```bash
   grep -i "postgresql\|table:" .forge/efforts/favorite-stores/spec/storage/favorites-schema.md
   grep -i "redis\|ttl" .forge/efforts/favorite-stores/spec/storage/favorites-schema.md
   # Expected: at least one match each
   ```

3. Unique constraint on (member_id, store_id) is defined:
   ```bash
   grep -i "unique" .forge/efforts/favorite-stores/spec/storage/favorites-schema.md
   # Expected: at least one match
   ```

4. Capacity enforcement mechanism is documented:
   ```bash
   grep -i "trigger\|50\|capacity" .forge/efforts/favorite-stores/spec/storage/favorites-schema.md
   # Expected: at least one match
   ```

5. `.state.json` updated:
   ```bash
   jq '.phases.discovery.artifacts.spec.storage' \
     .forge/efforts/favorite-stores/.state.json
   # Expected: "present"
   ```

---

### Step 1.6 — Architectural Decision Record

**Input prompt:**
> "I think we should enforce the 50-store cap with a database trigger rather than
> in application code. That way it's guaranteed even if we add another write path later."

**Expected outcomes:**

1. ADR file written with correct naming convention:
   ```bash
   ls .forge/efforts/favorite-stores/spec/arch-decisions/ADR-001-capacity-limit-via-db-trigger.md
   # Expected: file exists
   ```

2. ADR has required fields:
   ```bash
   grep "Status:" .forge/efforts/favorite-stores/spec/arch-decisions/ADR-001-capacity-limit-via-db-trigger.md
   grep "## Decision" .forge/efforts/favorite-stores/spec/arch-decisions/ADR-001-capacity-limit-via-db-trigger.md
   grep "## Alternatives Considered" \
     .forge/efforts/favorite-stores/spec/arch-decisions/ADR-001-capacity-limit-via-db-trigger.md
   grep "## Consequences" .forge/efforts/favorite-stores/spec/arch-decisions/ADR-001-capacity-limit-via-db-trigger.md
   # Expected: all four present
   ```

3. ADR status is "Accepted":
   ```bash
   grep "Status:.*Accepted" \
     .forge/efforts/favorite-stores/spec/arch-decisions/ADR-001-capacity-limit-via-db-trigger.md
   # Expected: match
   ```

4. `.state.json` records the ADR:
   ```bash
   jq '.phases.discovery.artifacts.adrsCreated' \
     .forge/efforts/favorite-stores/.state.json
   # Expected: array containing "ADR-001-capacity-limit-via-db-trigger.md"
   ```

---

## Phase 2: Architecture Review

### Step 2.1 — Architecture Review Trigger

**Session context:** Session 3. SessionStart hook fires.

**SessionStart hook expected output includes:**
```
**Discovery appears complete.** All expected artifact types are present.
**Next suggested action:** Run forge:arch-review to validate the design before
advancing to planning.
```

**Input prompt:**
> "Discovery looks good. Let's prepare the architecture review."

**Expected outcomes:**

1. Both review output files created:
   ```bash
   ls .forge/efforts/favorite-stores/validation/report.md
   ls .forge/efforts/favorite-stores/validation/arch-review.html
   # Expected: both files exist
   ```

2. `report.md` contains a result line:
   ```bash
   grep -i "result:" .forge/efforts/favorite-stores/validation/report.md
   # Expected: line containing "PASS" (with or without concerns)
   ```

3. `report.md` covers all required standard areas:
   ```bash
   grep -i "api\|contract\|rest" .forge/efforts/favorite-stores/validation/report.md
   grep -i "data model\|storage\|schema" .forge/efforts/favorite-stores/validation/report.md
   grep -i "security\|auth" .forge/efforts/favorite-stores/validation/report.md
   grep -i "privacy\|pii" .forge/efforts/favorite-stores/validation/report.md
   grep -i "traceability\|requirements" .forge/efforts/favorite-stores/validation/report.md
   # Expected: at least one match per area
   ```

4. `report.md` identifies the 409 error body as a failure:
   ```bash
   grep -i "409\|code.*field\|error.*body" .forge/efforts/favorite-stores/validation/report.md
   # Expected: at least one match referencing the missing `code` field
   ```

5. `report.md` includes counts summary:
   ```bash
   grep -iE "failures?.*[0-9]|concerns?.*[0-9]" \
     .forge/efforts/favorite-stores/validation/report.md
   # Expected: at least one match
   ```

6. `.state.json` records validation result:
   ```bash
   jq '.phases.validation.result' .forge/efforts/favorite-stores/.state.json
   # Expected: "PASS WITH CONCERNS" (or "PASS" if all concerns resolved)
   ```

---

### Step 2.2 — Resolving Review Findings

**Input prompt:**
> "The 409 error body issue is valid — let's fix the API spec to add the `code` field.
> The cascade question is a good catch, I'll add a note. The 200/201 concern is
> intentional design, I'll document it."

**Expected outcomes:**

1. API spec updated to include `code` field in 409 response:
   ```bash
   grep -i "code" .forge/efforts/favorite-stores/spec/api/favorites-api.yaml
   # Expected: match showing code field in error response schema
   ```

2. Storage schema updated with FK deletion behaviour note:
   ```bash
   grep -iE "cascade\|on delete\|deletion|orphan" \
     .forge/efforts/favorite-stores/spec/storage/favorites-schema.md
   # Expected: at least one match
   ```

3. API spec includes note about intentional 200 for duplicate-add:
   ```bash
   grep -i "intentional\|idempotent\|already present" \
     .forge/efforts/favorite-stores/spec/api/favorites-api.yaml
   # Expected: at least one match
   ```

4. PreToolUse hook did not block writes (discovery phase still in_progress — writes normal).

---

## Phase 3: Planning (via forge:plan Phase Entry Check)

### Step 3.1 — forge:plan triggers discovery → planning advancement

**Input prompt:**
> "Let's break this into tasks."

**Expected: Phase Entry Check fires before plan generation**

Because the effort is still in discovery, `forge:plan` invokes
`forge:promote favorite-stores --target planning` before proceeding.
Claude presents the discovery readiness summary and confirmation prompt:

```
Discovery readiness for favorite-stores:
  ✓ requirements/business.md — present
  ✓ requirements/technical.md — present
  ✓ spec/api/ — present
  ✓ spec/storage/ — present
  ✓ validation/report.md — PASS WITH CONCERNS

Advance discovery → planning? (yes/no)
```

Claude does NOT generate tasks until confirmation is given.

---

### Step 3.2 — Confirmation

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` updated with discovery approval:
   ```bash
   jq '{
     "discovery_status": .phases.discovery.status,
     "currentPhase": .currentPhase
   }' .forge/efforts/favorite-stores/.state.json
   # Expected:
   # {
   #   "discovery_status": "approved",
   #   "currentPhase": "planning"
   # }
   ```

2. `.state.json` records approver and timestamp:
   ```bash
   jq '.phases.discovery | keys' .forge/efforts/favorite-stores/.state.json
   # Expected: array including "approvedAt" and "approvedBy"
   ```

3. Registry row updated in `.forge/efforts/README.md`:
   ```bash
   grep "favorite-stores" .forge/efforts/README.md
   # Expected: row shows "planning" phase
   ```

4. Git commit created for discovery approval:
   ```bash
   git log --oneline -3
   # Expected: one commit matching "chore(favorite-stores): approve discovery phase"
   ```

5. forge:plan then proceeds to generate tasks.md.

---

### Step 3.3 — Implementation Plan and Phase Completion Check

**Context:** forge:plan generates tasks.md (same input prompt as Step 3.1 — plan generation
follows the confirmation from Step 3.2).

**Expected outcomes:**

1. Tasks file created:
   ```bash
   ls .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: file exists
   ```

2. Tasks file contains exactly 5 wave sections:
   ```bash
   grep -c "^## Wave" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: 5
   ```

3. Every task has `[type]` annotation:
   ```bash
   grep "^\- \[ \]" .forge/efforts/favorite-stores/plan/tasks.md | grep -v "\[auto\]\|\[tdd\]\|\[checkpoint\]"
   # Expected: no output (all tasks annotated)
   ```

4. Every task has `[wave:N]` annotation:
   ```bash
   grep "^\- \[ \]" .forge/efforts/favorite-stores/plan/tasks.md | grep -v "\[wave:[0-9]\]"
   # Expected: no output (all tasks have wave annotation)
   ```

5. Plan has 11 total tasks:
   ```bash
   grep -c "^\- \[ \]" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: 11
   ```

6. TASK-009 is annotated as `[checkpoint]`:
   ```bash
   grep "TASK-009" .forge/efforts/favorite-stores/plan/tasks.md | grep "\[checkpoint\]"
   # Expected: match
   ```

7. After writing tasks.md, forge:plan invokes `forge:promote favorite-stores --target implementation`
   (Phase Completion Check), offering:
   ```
   Plan complete with 11 tasks. Advance planning → implementation? (yes/no)
   ```
   The engineer may confirm or decline here. If declined, implementation advancement
   must happen later via forge:commit's Phase Entry Check or explicit forge:promote.

---

### Step 3.4 — Test Strategy

**Input prompt:**
> "Let's write up the test strategy before we start coding."

**Expected outcomes:**

1. Test strategy file created:
   ```bash
   ls .forge/efforts/favorite-stores/spec/test-strategy.md
   # Expected: file exists
   ```

2. Strategy covers unit tests, integration tests, and acceptance criteria:
   ```bash
   grep -i "## unit tests\|## integration tests\|## acceptance" \
     .forge/efforts/favorite-stores/spec/test-strategy.md
   # Expected: at least 3 matches (one per section)
   ```

3. Strategy maps acceptance criteria to BRs:
   ```bash
   grep -c "BR-[0-9]" .forge/efforts/favorite-stores/spec/test-strategy.md
   # Expected: 5 (one per BR)
   ```

---

### Step 3.5 — Advance Planning to Implementation (via forge:commit Phase Entry Check)

**Context:** The engineer declined the Phase Completion Check in Step 3.3 and is now
starting the first implementation commit.

**Input prompt:**
> "commit my work on TASK-001"

**Expected: forge:commit Phase Entry Check fires**

Because the effort is in planning, `forge:commit` invokes
`forge:promote favorite-stores --target implementation` before staging:

```
Planning readiness for favorite-stores:
  ✓ plan/tasks.md — present (11 tasks)

Advance planning → implementation? (yes/no)
```

**Input prompt:**
> "yes"

**Expected outcomes:**

1. `.state.json` updated:
   ```bash
   jq '{
     "planning_status": .phases.planning.status,
     "currentPhase": .currentPhase
   }' .forge/efforts/favorite-stores/.state.json
   # Expected:
   # {
   #   "planning_status": "approved",
   #   "currentPhase": "implementation"
   # }
   ```

2. Git commit created for planning approval:
   ```bash
   git log --oneline -3
   # Expected: one commit matching "chore(favorite-stores): approve planning phase"
   ```

3. forge:commit then proceeds with the normal staging/commit flow.

---

## Phase 4: Implementation

### Step 4.1 — Wave 1, TASK-001 (Quality Loop — Single Iteration Pass)

**Session context:** Session 4. SessionStart hook fires and reports implementation phase.

**Input prompt:**
> "Let's start building. Wave 1 first."

**Quality loop sequence for TASK-001:**

The test verifies the quality loop runs in order: implement → lint → validate → test.

**Expected outcomes after TASK-001:**

1. Migration file created in the correct path:
   ```bash
   ls db/migrations/*member_favorites*.sql
   # Expected: file exists
   ```

2. Migration includes table, unique constraint, and capacity trigger:
   ```bash
   grep -i "member_favorites" db/migrations/*member_favorites*.sql
   grep -i "unique\|constraint" db/migrations/*member_favorites*.sql
   grep -i "trigger\|before insert" db/migrations/*member_favorites*.sql
   # Expected: at least one match each
   ```

3. Task marked complete in `plan/tasks.md` with commit hash:
   ```bash
   grep "TASK-001" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: line starts with "- [x]" and ends with a commit hash in parentheses
   ```

   Pattern: `- [x] [auto][wave:1] ... (TASK-001) ([a-f0-9]{7,})`

4. Commit message follows convention:
   ```bash
   git log --oneline | grep "TASK-001"
   # Expected: commit message ending with "[TASK-001]"
   ```

5. PostToolUse hook recorded completion:
   ```bash
   jq '.phases.implementation.completedTasks' .forge/efforts/favorite-stores/.state.json
   # Expected: array containing "TASK-001"
   ```

---

### Step 4.2 — Wave 2, TASK-003 (Quality Loop — Multi-Iteration with TDD)

This step verifies the quality loop handles a TDD task requiring two iterations to pass.

**Input prompt:**
> "Next, let's implement the FavoritesRepository."

**Quality loop sequence for TASK-003 (TDD):**

**Iteration 1:**
1. RED phase: Tests written first. All tests fail.
2. GREEN phase: Implementation written. 8 of 9 pass; concurrent capacity test fails.

**Iteration 2:**
1. Fix applied (`@Transactional(isolation = SERIALIZABLE)` or equivalent).
2. Lint runs: checkstyle / linter reports missing Javadoc on `add()`.
3. Javadoc added.
4. Lint: clean.
5. Validate against spec: all method signatures and return values match spec.
6. Tests: all 9 pass.

**Expected outcomes:**

1. Test file created before implementation file:
   ```bash
   ls src/test/**/*FavoritesRepositoryTest*
   # Expected: file exists
   ```

2. Implementation file created:
   ```bash
   ls src/main/**/*FavoritesRepository*
   # Expected: file exists
   ```

3. All 9 tests pass (verified by Claude's report in the response).

4. Task marked complete in `plan/tasks.md`:
   ```bash
   grep "TASK-003" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: "- [x] [tdd][wave:2]" line with commit hash
   ```

5. Commit message references TDD task:
   ```bash
   git log --oneline | grep "TASK-003"
   # Expected: commit message ending with "[TASK-003]"
   ```

---

### Step 4.3 — TASK-009 Checkpoint (Open Decision Flow)

**Input prompt:**
> "I need to wire up the auth middleware but I'm not sure which claim in the JWT has
> the member ID. I need to check with the auth team."

**Expected outcomes:**

1. Open decision recorded in `.state.json`:
   ```bash
   jq '.openDecisions' .forge/efforts/favorite-stores/.state.json
   # Expected: array with one entry containing "blockedTask": "TASK-009"
   ```

2. Claude acknowledges the block and confirms other Wave 4 tasks can proceed.

3. TASK-009 remains `[ ]` (unchecked) in `plan/tasks.md`:
   ```bash
   grep "TASK-009" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: "- [ ]" (not checked)
   ```

**Resolution input prompt:**
> "Auth team confirmed: the claim is `member_uuid`."

**Expected outcomes:**

1. Open decision cleared:
   ```bash
   jq '.openDecisions' .forge/efforts/favorite-stores/.state.json
   # Expected: empty array []
   ```

2. TASK-009 implementation proceeds and is committed.

3. TASK-009 marked complete in `plan/tasks.md`:
   ```bash
   grep "TASK-009" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: "- [x] [checkpoint][wave:4]" line with commit hash
   ```

---

### Step 4.4 — Wave 5 and All Tasks Complete

**Session context:** Session 6. SessionStart hook reports all waves complete except Wave 5.

**Input prompt:**
> "Let's write the integration tests and then verify everything is working."

**Expected outcomes after TASK-010 and TASK-011:**

1. All 11 tasks marked complete in `plan/tasks.md`:
   ```bash
   grep -c "^\- \[x\]" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: 11
   ```

2. No unchecked tasks remain:
   ```bash
   grep "^\- \[ \]" .forge/efforts/favorite-stores/plan/tasks.md
   # Expected: no output
   ```

---

## Phase 5: Verification

### Step 5.1 — forge:verify

**Input prompt:**
> "All tasks are done. Let's verify before I open the PR."

**Expected outcomes:**

1. Verification report produced (as isolated sub-agent):
   ```bash
   ls .forge/efforts/favorite-stores/validation/verification-report.md
   # Expected: file exists
   ```

2. Report result is PASS:
   ```bash
   grep -i "\*\*Result.*PASS\|Result:.*PASS" \
     .forge/efforts/favorite-stores/validation/verification-report.md
   # Expected: match — "**Result: PASS**" or equivalent
   ```

3. All 5 BRs verified:
   ```bash
   grep -c "BR-[1-5].*✓\|BR-[1-5].*pass" \
     .forge/efforts/favorite-stores/validation/verification-report.md
   # Expected: 5
   ```

4. All 6 TRs verified:
   ```bash
   grep -c "TR-[1-6].*✓\|TR-[1-6].*pass" \
     .forge/efforts/favorite-stores/validation/verification-report.md
   # Expected: 6
   ```

5. "Gaps Found: None" (or equivalent) appears:
   ```bash
   grep -i "gaps.*none\|no gaps\|0 gaps" \
     .forge/efforts/favorite-stores/validation/verification-report.md
   # Expected: match
   ```

6. `.state.json` updated:
   ```bash
   jq '.phases.implementation.status' .forge/efforts/favorite-stores/.state.json
   # Expected: "complete"
   ```

---

## Phase 6: Graduation

### Step 6.1 — Effort Graduation

**Session context:** Session 8. QA has signed off.

**Input prompt:**
> "QA signed off. We're done with this effort."

**Expected outcomes:**

1. Deployable documentation updated — requirements:
   ```bash
   ls .forge/deployables/rewards-backend/requirements/
   # Expected: directory exists with content referencing favorites
   grep -ri "favorite" .forge/deployables/rewards-backend/requirements/
   # Expected: at least one match
   ```

2. Deployable documentation updated — API spec:
   ```bash
   ls .forge/deployables/rewards-backend/spec/api/favorites-api.yaml
   # Expected: file exists
   ```

3. Deployable documentation updated — storage schema:
   ```bash
   ls .forge/deployables/rewards-backend/spec/storage/favorites-schema.md
   # Expected: file exists
   ```

4. ADR-001 registered in deployable ADR index:
   ```bash
   grep -r "ADR-001\|capacity-limit\|db-trigger" .forge/deployables/rewards-backend/
   # Expected: at least one match
   ```

5. `.state.json` marks effort graduated:
   ```bash
   jq '.graduated' .forge/efforts/favorite-stores/.state.json
   # Expected: true
   ```

6. Registry row removed from `.forge/efforts/README.md`:
   ```bash
   grep "favorite-stores" .forge/efforts/README.md
   # Expected: no output (row removed or marked graduated)
   ```

7. Effort history preserved:
   ```bash
   ls .forge/efforts/favorite-stores/
   # Expected: directory still exists with all artifacts intact
   ```

8. Claude's response summarises what was promoted:
   - "1 ADR promoted"
   - "2 requirements documents promoted"
   - "1 API spec promoted"
   - "1 storage schema promoted"

---

## End-to-End Checklist

After completing all steps, verify the following cross-cutting concerns:

### Hook Behaviour

| Hook | Expected trigger points |
|------|------------------------|
| SessionStart | Sessions 1–8: correct effort context shown each time |
| PostToolUse | After every artifact write: `.state.json` updated |
| PreToolUse (inject-generation-standards.sh) | Before implementation writes: standards injected |
| PreToolUse (phase-context.sh) | During discovery edits: no block issued |

### State Transitions

```
discovery (in_progress)
  → discovery (approved)         ← forge:plan Phase Entry Check, Step 3.2
  → planning (in_progress)       ← auto on promote
  → planning (approved)          ← forge:commit Phase Entry Check, Step 3.5
  → implementation (in_progress) ← auto on promote
  → implementation (complete)    ← forge:verify Phase Entry Check, Step 5.1
  → verification (in_progress)   ← auto on promote
  → verification (approved)      ← forge:verify Phase Completion Check (PASS)
  → review (in_progress)         ← auto on promote
  → graduated: true              ← forge:graduate Step 6.1
```

### No Explicit Forge Commands Used by the Engineer

Throughout all 8 sessions the engineer issued zero explicit forge commands. Verify by
reviewing the input prompts above — none contain `forge:`, `/forge`, or any explicit
skill invocation. All workflow actions were triggered by natural language recognition.
