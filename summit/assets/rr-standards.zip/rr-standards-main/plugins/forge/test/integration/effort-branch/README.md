# Effort Branch Creation and Drift Detection — Integration Test Scenario

**Task:** TASK-010
**Capabilities under test:** `forge:effort`, `forge:project`, `inject-workflow-context.sh` (SessionStart hook)
**Requirements:** TR-1, TR-5, BR-3, BR-4
**Spec:** `forge-effort` capability — `spec/skills.md` (branch creation step), `spec/hooks.md` (drift detection)

---

## What This Scenario Tests

This scenario verifies two related behaviors introduced by the `forge-branching` capability:

1. **Branch creation in `forge:effort`** — When scaffolding a new effort, the skill must
   create and checkout an `effort/<id>` branch before any artifact commits are made.
   Resume behavior (branch already exists) must be idempotent.

2. **Branch drift detection in the SessionStart hook** — `inject-workflow-context.sh`
   must detect when the current git branch does not match the active effort's expected
   branch, and emit a warning at the top of the session context output before any other
   content.

---

## Scenarios Covered

| # | Description | Trigger | Key assertion |
|---|-------------|---------|---------------|
| 1 | `forge:effort` creates working branch automatically | Conversational scope statement on `main` | Branch `effort/favorite-stores` created and checked out |
| 2 | `forge:effort` is idempotent on resume | Effort branch already exists | `git checkout` (no `-b`), no error |
| 3 | Session start on correct branch — no warning | SessionStart hook on matching branch | No drift warning in output |
| 4 | Session start on wrong branch — drift warning at top | SessionStart hook on mismatched branch | Warning appears before `## Forge` header |
| 5 | Session start with no active effort — no drift check | SessionStart hook with empty registry | No warning emitted |
| 6 | `forge:project` creates branch for sub-effort | forge:project invoked with coordination repo | Local `effort/<sub-effort-id>` branch created |

---

## Key Verification Points

| Scenario | What to verify |
|----------|----------------|
| forge:effort (new) | `git branch --show-current` = `effort/favorite-stores` after skill completes |
| forge:effort (new) | `.forge/efforts/favorite-stores/.state.json` has `"id": "favorite-stores"` |
| forge:effort (resume) | No `git checkout -b` error; existing branch contents unchanged |
| forge:effort (resume) | Engineer confirmation includes "resumed" |
| SessionStart (match) | Output begins with `## Forge` — no `⚠️` prefix |
| SessionStart (mismatch) | First line of output starts with `⚠️ **Branch mismatch:**` |
| SessionStart (mismatch) | Warning contains `git checkout effort/favorite-stores` command |
| SessionStart (no effort) | Output does NOT contain `⚠️ Branch mismatch` |
| forge:project | `effort/favorite-stores-backend` branch exists and is checked out |
| forge:project | `.state.json` has `coordinationRef` field populated |

---

## Related Skills and Hooks

- [`plugins/forge/skills/workflow/effort/SKILL.md`](../../../skills/workflow/effort/SKILL.md) — branch creation step (step 5.5)
- [`plugins/forge/hooks/session-start/inject-workflow-context.sh`](../../../hooks/session-start/inject-workflow-context.sh) — drift detection logic
- [`plugins/forge/skills/cross-repo/project/SKILL.md`](../../../skills/cross-repo/project/SKILL.md) — sub-effort branch creation

---

## Running the Scenario

Open `scenario.md` and follow each scenario in sequence. Each scenario specifies the
initial git and filesystem state, the input or trigger, and the exact outcomes to
verify before moving to the next scenario.

Scenarios 1 and 2 build on each other (Scenario 2 requires the branch created in
Scenario 1). Scenarios 3–5 are independent of each other and of Scenarios 1–2.
Scenario 6 requires a coordination repository accessible via the GitHub API.
