# Branch Enforcement — Test Scenario

**Task:** TASK-009
**Hook under test:** `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`

---

## Invocation Convention

Each scenario invokes the hook directly as a shell script, setting environment
variables to simulate the Claude Code `PreToolUse` event. The general form is:

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"<git command here>"}' \
[OPTIONAL_VARS=...] \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh
echo "exit: $?"
```

Stderr is captured separately to verify the JSON diagnostic:

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"some work\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr.txt
echo "exit: $?"
cat stderr.txt
```

---

## Scenario 1: Direct commit blocked on main

### Setup

```sh
git checkout main
```

`.forge/efforts/README.md` exists and contains a table row with `in_progress` status for
effort `forge-branching`. Example minimal row:

```
| forge-branching | Forge Branch Policy | in_progress | ... |
```

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"some work\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr.txt
echo "exit: $?"
cat stderr.txt
```

### Expected Outcomes

**Exit code:** `2`

**stderr** contains valid JSON with the following field values:

| Field | Expected value |
|-------|----------------|
| `type` | `"branch_policy_violation"` |
| `blocked` | `true` |
| `currentBranch` | `"main"` |
| `activeEffort` | `"forge-branching"` |
| `nextAction` | contains the string `effort/forge-branching` |

**Assertions:**

- [ ] `echo "exit: $?"` prints `exit: 2`
- [ ] `stderr.txt` is valid JSON (parseable by `jq .`)
- [ ] `jq -r '.type' stderr.txt` = `branch_policy_violation`
- [ ] `jq -r '.blocked' stderr.txt` = `true`
- [ ] `jq -r '.currentBranch' stderr.txt` = `main`
- [ ] `jq -r '.activeEffort' stderr.txt` = `forge-branching`
- [ ] `jq -r '.nextAction' stderr.txt` contains `effort/forge-branching`
- [ ] No git commit was created (verify with `git log --oneline -1` — HEAD is unchanged)

---

## Scenario 2: Commit allowed on feature branch

### Setup

```sh
git checkout effort/forge-branching
```

`.forge/README.md` may or may not exist; its content does not affect this scenario.

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"some work\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr.txt
echo "exit: $?"
cat stderr.txt
```

### Expected Outcomes

**Exit code:** `0`

**stderr:** empty — no output produced

**Assertions:**

- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stderr.txt` is empty (size 0)
- [ ] No audit log file was written under `.forge/audit/`

---

## Scenario 3: git push to main blocked

### Setup

```sh
git checkout main
```

`.forge/efforts/README.md` exists with an `in_progress` row for `forge-branching` (same as
Scenario 1).

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git push origin main"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr.txt
echo "exit: $?"
cat stderr.txt
```

### Expected Outcomes

**Exit code:** `2`

**stderr** contains valid JSON with the following field values:

| Field | Expected value |
|-------|----------------|
| `type` | `"branch_policy_violation"` |
| `blocked` | `true` |
| `currentBranch` | `"main"` |
| `activeEffort` | `"forge-branching"` |

**Assertions:**

- [ ] `echo "exit: $?"` prints `exit: 2`
- [ ] `stderr.txt` is valid JSON
- [ ] `jq -r '.type' stderr.txt` = `branch_policy_violation`
- [ ] `jq -r '.blocked' stderr.txt` = `true`
- [ ] `jq -r '.currentBranch' stderr.txt` = `main`
- [ ] `jq -r '.activeEffort' stderr.txt` = `forge-branching`

---

## Scenario 4: Admin override — FORGE_ALLOW_MAIN_COMMIT=1

### Setup

```sh
git checkout main
```

`.forge/README.md` may or may not exist.

Remove any existing audit logs to make assertion clean:

```sh
rm -rf .forge/audit/
```

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
FORGE_ALLOW_MAIN_COMMIT=1 \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"admin work\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr.txt
echo "exit: $?"
```

### Expected Outcomes

**Exit code:** `0`

**stderr:** empty — override path does not emit a diagnostic

**Audit log:** a new file at `.forge/audit/<timestamp>.json` is created

**Assertions:**

- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stderr.txt` is empty
- [ ] `ls .forge/audit/` lists exactly one `.json` file with a timestamp filename
  matching the pattern `YYYY-MM-DDTHH-MM-SSZ.json`
- [ ] The audit file is valid JSON (parseable by `jq .`)
- [ ] `jq -r '.operation' .forge/audit/*.json` = `direct_commit_override`
- [ ] `jq -r '.reason' .forge/audit/*.json` = `FORGE_ALLOW_MAIN_COMMIT=1 set by engineer`
- [ ] `jq -r '.branch' .forge/audit/*.json` = `main`
- [ ] `jq -r '.timestamp' .forge/audit/*.json` is a valid ISO-8601 UTC timestamp
  (format `YYYY-MM-DDTHH:MM:SSZ`)

---

## Scenario 5: Non-commit git commands allowed on main

### Setup

```sh
git checkout main
```

### Input — three separate invocations

**5a — git status:**

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git status"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr_5a.txt
echo "exit: $?"
```

**5b — git log:**

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git log --oneline"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr_5b.txt
echo "exit: $?"
```

**5c — git diff:**

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git diff"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr_5c.txt
echo "exit: $?"
```

### Expected Outcomes

All three invocations must produce:

**Exit code:** `0`

**stderr:** empty

**Assertions (for each of 5a, 5b, 5c):**

- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] Corresponding stderr file is empty (size 0)
- [ ] No audit log file created

---

## Scenario 6: No active effort on main

### Setup

```sh
git checkout main
```

Ensure `.forge/efforts/README.md` does not exist, or exists but contains no row with
`in_progress` or `active` status:

```sh
# Option A: remove it entirely
rm -f .forge/README.md

# Option B: have it present with no active rows
# (file exists but no line matches 'in_progress' or 'active')
```

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"some work\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh 2>stderr.txt
echo "exit: $?"
cat stderr.txt
```

### Expected Outcomes

**Exit code:** `2`

**stderr** contains valid JSON with the following field values:

| Field | Expected value |
|-------|----------------|
| `type` | `"branch_policy_violation"` |
| `blocked` | `true` |
| `currentBranch` | `"main"` |
| `activeEffort` | `null` (JSON null, not the string `"null"`) |
| `nextAction` | contains `forge:effort` |

**Assertions:**

- [ ] `echo "exit: $?"` prints `exit: 2`
- [ ] `stderr.txt` is valid JSON
- [ ] `jq -r '.type' stderr.txt` = `branch_policy_violation`
- [ ] `jq -r '.blocked' stderr.txt` = `true`
- [ ] `jq -r '.currentBranch' stderr.txt` = `main`
- [ ] `jq '.activeEffort' stderr.txt` = `null` (jq null, not string)
- [ ] `jq -r '.nextAction' stderr.txt` contains `forge:effort`
- [ ] No git commit was created

---

## Scenario Summary

| # | Branch | Command | Override | Active effort | Expected exit | Key assertion |
|---|--------|---------|----------|---------------|---------------|---------------|
| 1 | `main` | `git commit` | none | `forge-branching` | 2 | JSON diagnostic; `activeEffort` = `forge-branching`; `nextAction` contains `effort/forge-branching` |
| 2 | `effort/forge-branching` | `git commit` | none | any | 0 | No output; no audit log |
| 3 | `main` | `git push origin main` | none | `forge-branching` | 2 | JSON diagnostic on stderr |
| 4 | `main` | `git commit` | `FORGE_ALLOW_MAIN_COMMIT=1` | any | 0 | Audit log at `.forge/audit/<timestamp>.json`; `reason` = `FORGE_ALLOW_MAIN_COMMIT=1 set by engineer` |
| 5a | `main` | `git status` | none | any | 0 | No output |
| 5b | `main` | `git log --oneline` | none | any | 0 | No output |
| 5c | `main` | `git diff` | none | any | 0 | No output |
| 6 | `main` | `git commit` | none | none | 2 | `activeEffort` is JSON null; `nextAction` contains `forge:effort` |
