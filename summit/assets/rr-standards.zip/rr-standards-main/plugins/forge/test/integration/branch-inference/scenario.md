# Scenario: Conversational Branch Type Inference

**TASK-015** — conversational branch type inference
**Reference:** `plugins/forge/templates/forge-claude-md-section.md` — "Creating branches" section

> **Note:** Every input prompt below is a conversational message to Claude Code. No explicit
> forge command is used in any scenario. Branch creation (or the decision not to create one)
> is triggered entirely by the agent reading the "Creating branches" section of the
> forge-managed CLAUDE.md and applying its inference rules.

---

## Scenario 1 — Fix Inference

### Setup

```bash
git checkout main
git branch --show-current
# Expected: main

# Confirm no active efforts
grep -v "graduated" .forge/efforts/README.md | grep -v "^|.*Phase"
# Expected: no active effort rows
```

### Input prompt

> "Let's fix the crash in the auth flow"

### Expected

Branch `fix/auth-flow-crash` is created and checked out. Claude's response contains a
confirmation message that names the branch.

### Verify

```bash
# 1. Current branch is correct
git branch --show-current
# Expected: fix/auth-flow-crash

# 2. Branch was actually created (not just named in response)
git branch | grep "fix/auth-flow-crash"
# Expected: fix/auth-flow-crash

# 3. Confirmation message cites the branch name
# (inspect Claude's response)
# Expected: response contains "(Created branch: fix/auth-flow-crash)"
#           or equivalent phrasing that names the branch
```

---

## Scenario 2 — Feature Inference

### Setup

```bash
git checkout main
git branch --show-current
# Expected: main
```

### Input prompt

> "We need to add a favorites endpoint to the API"

### Expected

A branch prefixed `feature/` is created and checked out. The slug is composed of lowercase
letters and hyphens only and is 40 characters or fewer.

### Verify

```bash
# 1. Current branch starts with feature/
git branch --show-current
# Expected: feature/<slug>   e.g. feature/favorites-endpoint
#           or feature/add-favorites-endpoint

# 2. Prefix is exactly feature/
git branch --show-current | grep "^feature/"
# Expected: match

# 3. Slug is lowercase hyphens only (no underscores, no uppercase, no slashes after prefix)
git branch --show-current | sed 's|^feature/||' | grep -E "^[a-z0-9][a-z0-9-]*$"
# Expected: match

# 4. Slug length ≤ 40 chars
SLUG=$(git branch --show-current | sed 's|^feature/||')
echo ${#SLUG}
# Expected: ≤ 40
```

---

## Scenario 3 — Refactor Inference

### Setup

```bash
git checkout main
git branch --show-current
# Expected: main
```

### Input prompt

> "Clean up the unused imports in the API layer"

### Expected

A branch prefixed `refactor/` is created and checked out. The slug describes the action.
Acceptable examples: `refactor/remove-unused-imports`, `refactor/api-layer-cleanup`.

### Verify

```bash
# 1. Current branch starts with refactor/
git branch --show-current
# Expected: refactor/<slug>

# 2. Prefix is exactly refactor/
git branch --show-current | grep "^refactor/"
# Expected: match

# 3. Slug is lowercase hyphens only
git branch --show-current | sed 's|^refactor/||' | grep -E "^[a-z0-9][a-z0-9-]*$"
# Expected: match
```

---

## Scenario 4 — Docs Inference

### Setup

```bash
git checkout main
git branch --show-current
# Expected: main
```

### Input prompt

> "Update the README with setup instructions"

### Expected

A branch prefixed `docs/` is created and checked out. Acceptable examples:
`docs/readme-setup-instructions`, `docs/setup-instructions`.

### Verify

```bash
# 1. Current branch starts with docs/
git branch --show-current
# Expected: docs/<slug>

# 2. Prefix is exactly docs/
git branch --show-current | grep "^docs/"
# Expected: match

# 3. Slug is lowercase hyphens only
git branch --show-current | sed 's|^docs/||' | grep -E "^[a-z0-9][a-z0-9-]*$"
# Expected: match
```

---

## Scenario 5 — Hotfix Inference

### Setup

```bash
git checkout main
git branch --show-current
# Expected: main
```

### Input prompt

> "This is an urgent prod issue with login — users can't sign in"

### Expected

A branch prefixed `hotfix/` is created and checked out. Urgency and production context
triggers `hotfix/` over `fix/`. Acceptable examples: `hotfix/login-issue`,
`hotfix/prod-login`, `hotfix/login-sign-in`.

### Verify

```bash
# 1. Current branch starts with hotfix/
git branch --show-current
# Expected: hotfix/<slug>

# 2. Prefix is exactly hotfix/
git branch --show-current | grep "^hotfix/"
# Expected: match

# 3. Slug is lowercase hyphens only
git branch --show-current | sed 's|^hotfix/||' | grep -E "^[a-z0-9][a-z0-9-]*$"
# Expected: match
```

---

## Scenario 6 — Chore Inference

### Setup

```bash
git checkout main
git branch --show-current
# Expected: main
```

### Input prompt

> "Bump the Redis dependency to 4.x"

### Expected

A branch prefixed `chore/` is created and checked out. Dependency upgrade language triggers
`chore/`. Acceptable examples: `chore/bump-redis-4`, `chore/redis-upgrade`,
`chore/upgrade-redis-4x`.

### Verify

```bash
# 1. Current branch starts with chore/
git branch --show-current
# Expected: chore/<slug>

# 2. Prefix is exactly chore/
git branch --show-current | grep "^chore/"
# Expected: match

# 3. Slug is lowercase hyphens only
git branch --show-current | sed 's|^chore/||' | grep -E "^[a-z0-9][a-z0-9-]*$"
# Expected: match
```

---

## Scenario 7 — Ambiguous Prompt: Agent Asks Before Creating

### Setup

```bash
git checkout main
git branch --show-current
# Expected: main

# Record the current branch list before the prompt
git branch > /tmp/branches-before.txt
```

### Input prompt

> "I want to do some work on the auth system"

### Expected

The agent does NOT create a branch. Instead it asks one clarifying question that lists
the available branch type options so the engineer can choose. The agent waits for the
answer before creating anything.

### Verify

```bash
# 1. No new branch was created
git branch > /tmp/branches-after.txt
diff /tmp/branches-before.txt /tmp/branches-after.txt
# Expected: no diff (branch list unchanged)

# 2. Current branch is still main
git branch --show-current
# Expected: main
```

Inspect Claude's response:

```
# 3. Response is a question (not a statement that a branch was created)
# Expected: response ends with "?" or contains "which type" / "what kind" / "can you clarify"
#           phrasing — i.e. it is asking the engineer something

# 4. Response lists at least 4 branch type options
# Expected: response mentions at least 4 of: fix, feature, refactor, docs, hotfix, chore, effort
#           e.g. "Is this a fix, feature, refactor, chore, or something else?"

# 5. Response asks only ONE question (not multiple clarifying questions at once)
# Expected: single question, not a list of questions
```

---

## Scenario 8 — Active Effort Exists: No Branch Created

### Setup

```bash
# Check out (or create) the active effort branch
git checkout effort/favorite-stores 2>/dev/null || git checkout -b effort/favorite-stores

git branch --show-current
# Expected: effort/favorite-stores

# Confirm effort is registered in .forge/efforts/README.md as active (not graduated)
grep "favorite-stores" .forge/efforts/README.md
# Expected: row present; status column does NOT say "graduated"

# Record branch state
git branch > /tmp/branches-before.txt
```

### Input prompt

> "Let's work on the favorites feature"

### Expected

The agent does NOT create a new branch. It recognizes that an active effort (`favorite-stores`)
already exists on branch `effort/favorite-stores` and responds naturally using that context.

### Verify

```bash
# 1. Current branch is still effort/favorite-stores (unchanged)
git branch --show-current
# Expected: effort/favorite-stores

# 2. No new branch was created
git branch > /tmp/branches-after.txt
diff /tmp/branches-before.txt /tmp/branches-after.txt
# Expected: no diff

# 3. No feature/, fix/, or other typed branch was created
git branch | grep -E "^  (feature|fix|refactor|docs|hotfix|chore)/"
# Expected: no output
```

Inspect Claude's response:

```
# 4. Response references the existing effort or feature context
# Expected: response mentions "favorite-stores", "favorites feature", or the existing effort —
#           it does NOT say "I've created branch" or "Created branch:"
```

---

## End-to-End Checklist

After completing all 8 scenarios, verify the following cross-cutting properties:

### Branch Naming Rules Applied Consistently

| Property | Rule |
|----------|------|
| Prefix | Exactly one of: `fix/`, `feature/`, `refactor/`, `docs/`, `hotfix/`, `chore/`, `effort/` |
| Slug characters | Lowercase `[a-z0-9-]` only — no underscores, uppercase, or extra slashes |
| Slug length | ≤ 40 characters |
| No active effort | Agent creates a new branch |
| Active effort present | Agent reuses the existing effort branch — no new branch |

### Inference Signal Words (reference)

| Prefix | Signal words observed in scenarios |
|--------|-----------------------------------|
| `fix/` | "fix", "crash", "broken" |
| `feature/` | "add", "new", "endpoint", "need to" |
| `refactor/` | "clean up", "unused", "remove" |
| `docs/` | "README", "documentation", "update the" + document noun |
| `hotfix/` | "urgent", "prod", "production issue", "can't sign in" |
| `chore/` | "bump", "upgrade", "dependency" |
| ambiguous | Vague subject + action with no clear type signal |

### No Explicit Forge Commands Used

Throughout all 8 scenarios the engineer issued zero explicit forge commands. Verify by
reviewing the input prompts above — none contain `forge:`, `/forge`, or any explicit
skill invocation. Branch inference is driven entirely by the CLAUDE.md "Creating branches"
section read at session start.
