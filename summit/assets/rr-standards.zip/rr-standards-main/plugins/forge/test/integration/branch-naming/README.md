# Branch Naming Convention — Integration Test Scenario

**Task:** TASK-014
**Capabilities under test:** `forge-branching`
**Requirements:** TR-7, TR-9, BR-6, BR-8
**Spec:** [`.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md`](../../../../.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md) — Branch Taxonomy Validation and Push-Time Alignment Warning

---

## What This Scenario Tests

This scenario verifies two distinct behaviors added to `enforce-branch-policy.sh` in Wave 5:

1. **Branch name format validation (TR-7):** On `git commit`, after confirming the
   current branch is not the default branch, the hook validates that the branch name
   matches the allowed taxonomy. Invalid names are blocked with exit 2 and a structured
   JSON diagnostic. Valid names proceed silently with exit 0.

2. **Push-time alignment warning (TR-9):** On `git push`, after the default-branch
   block check passes, the hook invokes `claude -p` to ask whether the commits and
   changed files match the branch type. If misaligned, a formatted warning is printed
   to stdout. The push always proceeds (exit 0) regardless of the alignment result.

Coverage:

1. `git commit` on `fix/auth-crash` — valid format, allowed silently
2. `git commit` on `wip-stuff` — invalid format, blocked with `branch_name_violation` diagnostic
3. `git commit` on `Feature/auth` — uppercase violates convention, blocked
4. `git push` with docs-only changes on `fix/` branch — alignment warning printed, exit 0
5. `git push` with feature commits on `fix/` branch — warning with suggested name, exit 0
6. `FORGE_SKIP_BRANCH_VALIDATION=1` on `git push` — both format and alignment checks skipped
7. Alignment check times out (>10 seconds) — push proceeds silently, no error output

---

## Hook Under Test

**File:** `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`

**Trigger mechanism:** Claude Code `PreToolUse` event, matcher `Bash`

**Environment variables consumed:**
- `CLAUDE_TOOL_NAME` — tool name (must equal `Bash` to proceed)
- `CLAUDE_TOOL_INPUT` — JSON object; hook extracts the `command` field
- `FORGE_SKIP_BRANCH_VALIDATION` — set to any non-empty value to bypass naming and alignment checks

---

## Allowed Branch Name Formats (TR-7)

The hook accepts branches matching this pattern:

```
^(effort/[a-z0-9][a-z0-9-]*|feature/[a-z0-9][a-z0-9-]*|fix/[a-z0-9][a-z0-9-]*|hotfix/[a-z0-9][a-z0-9-]*|chore/[a-z0-9][a-z0-9-]*|docs/[a-z0-9][a-z0-9-]*|refactor/[a-z0-9][a-z0-9-]*|release/[a-z0-9][a-z0-9.]*)$
```

All 8 allowed `allowedFormats` values emitted in diagnostics:

| Format | Description |
|--------|-------------|
| `effort/<id>` | Forge effort branch |
| `feature/<slug>` | New functionality |
| `fix/<slug>` | Bug fix |
| `hotfix/<slug>` | Urgent production fix |
| `chore/<slug>` | Maintenance |
| `docs/<slug>` | Documentation only |
| `refactor/<slug>` | Structural code change |
| `release/<version>` | Release preparation |

---

## Repository State Required

Each scenario specifies the git branch state as part of its setup. Scenarios 4 and 5
require commits ahead of `origin/main` so the hook has data to pass to `claude -p`.
Scenario 7 simulates a `claude` binary that is slow or absent — replace it with a
stub for reliable testing.

---

## Running the Scenario

Open `scenario.md` and work through each scenario. Each scenario specifies:

1. **Setup** — branch state and any filesystem or stub preconditions
2. **Input** — the exact environment variables and `CLAUDE_TOOL_INPUT` value to supply
3. **Expected Outcomes** — exit code, stdout content, stderr content
4. **Verify** — assertion checklist

All scenarios are independent and can be run in any order after establishing the
required setup state.

---

## Related Files

- **Hook implementation:** [`plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`](../../../hooks/pre-tool-use/enforce-branch-policy.sh)
- **Hook spec:** [`.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md`](../../../../.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md)
- **Technical requirements:** [`.forge/deployables/forge-plugin/capabilities/forge-branching/requirements/technical.md`](../../../../.forge/deployables/forge-plugin/capabilities/forge-branching/requirements/technical.md)
- **Branch enforcement tests:** [`plugins/forge/test/integration/branch-enforcement/`](../branch-enforcement/)
