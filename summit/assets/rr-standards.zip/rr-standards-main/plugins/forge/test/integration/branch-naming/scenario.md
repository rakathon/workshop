# Branch Naming Convention — Test Scenario

**Task:** TASK-014
**Hook under test:** `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`

---

## Invocation Convention

Each scenario invokes the hook directly as a shell script, setting environment
variables to simulate the Claude Code `PreToolUse` event:

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"<git command here>"}' \
[OPTIONAL_VARS=...] \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh
echo "exit: $?"
```

Capture stdout and stderr separately to assert on each stream independently:

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"fix auth crash\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
```

---

## Scenario 1: git commit on fix/auth-crash — valid format, allowed

### Setup

```sh
git checkout -b fix/auth-crash
```

No special filesystem state required. The hook only inspects the branch name for
format validation; it does not read `.forge/README.md` when the branch is valid.

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"fix auth crash\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
```

### Expected Outcomes

**Exit code:** `0`

**stdout:** empty — no warning produced for a valid branch name

**stderr:** empty — no JSON diagnostic emitted

### Verify

- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stdout.txt` is empty (size 0)
- [ ] `stderr.txt` is empty (size 0)

---

## Scenario 2: git commit on wip-stuff — invalid format, blocked

### Setup

```sh
git checkout -b wip-stuff
```

`wip-stuff` contains no `/` separator and matches no allowed type prefix. The hook
must block the commit and emit a structured diagnostic.

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"wip\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
cat stderr.txt
```

### Expected Outcomes

**Exit code:** `2`

**stdout:** empty — diagnostic goes to stderr, not stdout

**stderr** contains valid JSON with the following fields:

| Field | Expected value |
|-------|----------------|
| `type` | `"branch_name_violation"` |
| `blocked` | `true` |
| `currentBranch` | `"wip-stuff"` |
| `allowedFormats` | array with all 8 allowed format strings |
| `nextAction` | contains `git branch -m` and `<type>/<slug>` |

The `allowedFormats` array must contain all of: `"effort/<id>"`, `"feature/<slug>"`,
`"fix/<slug>"`, `"hotfix/<slug>"`, `"chore/<slug>"`, `"docs/<slug>"`,
`"refactor/<slug>"`, `"release/<version>"`.

### Verify

- [ ] `echo "exit: $?"` prints `exit: 2`
- [ ] `stdout.txt` is empty (size 0)
- [ ] `stderr.txt` is valid JSON (parseable by `jq .`)
- [ ] `jq -r '.type' stderr.txt` = `branch_name_violation`
- [ ] `jq -r '.blocked' stderr.txt` = `true`
- [ ] `jq -r '.currentBranch' stderr.txt` = `wip-stuff`
- [ ] `jq '.allowedFormats | length' stderr.txt` = `8`
- [ ] `jq -r '.allowedFormats[]' stderr.txt` includes `effort/<id>`, `feature/<slug>`, `fix/<slug>`, `hotfix/<slug>`, `chore/<slug>`, `docs/<slug>`, `refactor/<slug>`, `release/<version>`
- [ ] `jq -r '.nextAction' stderr.txt` contains `git branch -m`

---

## Scenario 3: git commit on Feature/auth — uppercase violates convention, blocked

### Setup

```sh
git checkout -b Feature/auth
```

`Feature/auth` uses an uppercase `F`. The regex pattern requires all lowercase
characters in both the type prefix and slug portions.

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"add auth feature\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
cat stderr.txt
```

### Expected Outcomes

**Exit code:** `2`

**stdout:** empty

**stderr** contains valid JSON with `type: "branch_name_violation"` and `currentBranch:
"Feature/auth"`. The `reason` field must communicate the naming convention requirement
(i.e. reference that the branch name does not follow naming conventions — naming implies
lowercase).

### Verify

- [ ] `echo "exit: $?"` prints `exit: 2`
- [ ] `stdout.txt` is empty (size 0)
- [ ] `stderr.txt` is valid JSON
- [ ] `jq -r '.type' stderr.txt` = `branch_name_violation`
- [ ] `jq -r '.blocked' stderr.txt` = `true`
- [ ] `jq -r '.currentBranch' stderr.txt` = `Feature/auth`
- [ ] `jq -r '.reason' stderr.txt` contains `naming convention` or `does not follow`

---

## Scenario 4: git push with docs-only changes on fix/ branch — alignment warning, push proceeds

### Setup

```sh
git checkout -b fix/update-readme
```

Create commits that only modify `.md` files so the hook sees purely documentation
changes on a `fix/` branch:

```sh
echo "# updated" >> README.md
git add README.md
git commit -m "update readme"

echo "# more docs" >> CONTRIBUTING.md
git add CONTRIBUTING.md
git commit -m "update contributing guide"
```

Ensure `origin/main` is reachable so `git log origin/main..HEAD` and
`git diff origin/main...HEAD` return content. In an isolated test repo, set up a bare
remote or use a local path remote.

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git push origin fix/update-readme"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
cat stdout.txt
```

### Expected Outcomes

**Exit code:** `0` — alignment check is advisory; push always proceeds

**stdout** contains the alignment warning. Expected content:
- Contains `⚠️` (warning symbol) or `Branch alignment check`
- References the current branch `fix/update-readme`
- Contains a suggestion with `docs/` prefix (e.g. `docs/update-readme`)

**stderr:** empty — warnings go to stdout, not stderr

### Verify

- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stderr.txt` is empty (size 0)
- [ ] `stdout.txt` is non-empty
- [ ] `grep -q "⚠\|Branch alignment" stdout.txt` exits 0
- [ ] `grep -qi "docs/" stdout.txt` exits 0 — suggestion contains `docs/` prefix

---

## Scenario 5: git push with feature commits on fix/ branch — warning with suggested feature/ name, push proceeds

### Setup

```sh
git checkout -b fix/auth-flow
```

Create commits that add new functionality (new source files, significant line additions)
to simulate feature work on a `fix/` branch:

```sh
mkdir -p src/auth
cat > src/auth/token_refresh.go << 'EOF'
package auth

// TokenRefresh handles OAuth token refresh flow
func TokenRefresh(token string) (string, error) {
    // ... 300 lines of new functionality
    return "", nil
}
EOF
git add src/auth/token_refresh.go
git commit -m "implement token refresh flow"

cat > src/auth/session.go << 'EOF'
package auth

// Session manages authenticated user sessions
type Session struct{}
EOF
git add src/auth/session.go
git commit -m "add session management"
```

Ensure `origin/main` is reachable (same requirement as Scenario 4).

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
CLAUDE_TOOL_INPUT='{"command":"git push origin fix/auth-flow"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
cat stdout.txt
```

### Expected Outcomes

**Exit code:** `0` — warning is advisory, push always proceeds

**stdout** contains an alignment warning referencing:
- The current branch `fix/auth-flow`
- A suggested name with `feature/` prefix (e.g. `feature/auth-flow` or
  `feature/auth-token-refresh`)
- A rename instruction (`git branch -m`)

**stderr:** empty

### Verify

- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stderr.txt` is empty (size 0)
- [ ] `stdout.txt` is non-empty
- [ ] `grep -q "⚠\|Branch alignment" stdout.txt` exits 0
- [ ] `grep -qi "feature/" stdout.txt` exits 0 — suggestion contains `feature/` prefix
- [ ] `grep -qi "git branch -m" stdout.txt` exits 0 — rename instruction present

---

## Scenario 6: FORGE_SKIP_BRANCH_VALIDATION=1 on git push — no checks, proceeds silently

### Setup

```sh
git checkout -b wip-stuff
```

`wip-stuff` is an invalid branch name. Without the bypass flag it would be blocked on
`git commit`. This scenario confirms the bypass suppresses both format validation
(on commit) and alignment checks (on push).

### Input — push variant (alignment check skipped)

```sh
CLAUDE_TOOL_NAME=Bash \
FORGE_SKIP_BRANCH_VALIDATION=1 \
CLAUDE_TOOL_INPUT='{"command":"git push origin wip-stuff"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
```

### Input — commit variant (format check also skipped)

```sh
CLAUDE_TOOL_NAME=Bash \
FORGE_SKIP_BRANCH_VALIDATION=1 \
CLAUDE_TOOL_INPUT='{"command":"git commit -m \"bypassing validation\""}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout_commit.txt 2>stderr_commit.txt
echo "exit: $?"
```

### Expected Outcomes

Both invocations must produce:

**Exit code:** `0`

**stdout:** empty — no warning produced when bypass is active

**stderr:** empty — no diagnostic emitted

### Verify

**Push variant:**
- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stdout.txt` is empty (size 0)
- [ ] `stderr.txt` is empty (size 0)

**Commit variant:**
- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stdout_commit.txt` is empty (size 0)
- [ ] `stderr_commit.txt` is empty (size 0)

---

## Scenario 7: Alignment check times out — push proceeds silently, no error

### Setup

```sh
git checkout -b fix/auth
```

Create at least one commit ahead of `origin/main`:

```sh
echo "fix" >> src/auth.go
git add src/auth.go
git commit -m "fix auth handler"
```

Install a `claude` stub that sleeps longer than the 10-second timeout and replace
`claude` in `PATH` for this invocation:

```sh
mkdir -p /tmp/test-stubs
cat > /tmp/test-stubs/claude << 'EOF'
#!/bin/sh
sleep 15
EOF
chmod +x /tmp/test-stubs/claude
```

### Input

```sh
CLAUDE_TOOL_NAME=Bash \
PATH="/tmp/test-stubs:$PATH" \
CLAUDE_TOOL_INPUT='{"command":"git push origin fix/auth"}' \
  sh plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh \
  >stdout.txt 2>stderr.txt
echo "exit: $?"
```

Note: this invocation will take approximately 10 seconds while the `timeout` command
waits for the stub to exceed the limit.

### Expected Outcomes

**Exit code:** `0` — timeout is handled gracefully; push proceeds

**stdout:** empty — no warning when `claude -p` times out or returns no result

**stderr:** empty — no error message about the timeout

### Verify

- [ ] `echo "exit: $?"` prints `exit: 0`
- [ ] `stdout.txt` is empty (size 0)
- [ ] `stderr.txt` is empty (size 0)
- [ ] Invocation completes within ~12 seconds (10-second timeout + small overhead)

---

## Scenario Summary

| # | Branch | Command | Bypass | Expected exit | Key assertion |
|---|--------|---------|--------|---------------|---------------|
| 1 | `fix/auth-crash` | `git commit` | none | 0 | No stdout, no stderr |
| 2 | `wip-stuff` | `git commit` | none | 2 | stderr JSON `type=branch_name_violation`; `allowedFormats` has 8 entries |
| 3 | `Feature/auth` | `git commit` | none | 2 | stderr JSON `type=branch_name_violation`; `currentBranch=Feature/auth` |
| 4 | `fix/update-readme` | `git push` | none | 0 | stdout warning with `docs/` suggestion |
| 5 | `fix/auth-flow` | `git push` | none | 0 | stdout warning with `feature/` suggestion and rename instruction |
| 6a | `wip-stuff` | `git push` | `FORGE_SKIP_BRANCH_VALIDATION=1` | 0 | No stdout, no stderr |
| 6b | `wip-stuff` | `git commit` | `FORGE_SKIP_BRANCH_VALIDATION=1` | 0 | No stdout, no stderr |
| 7 | `fix/auth` | `git push` | none (slow `claude` stub) | 0 | No stdout, no stderr; completes within ~12s |
