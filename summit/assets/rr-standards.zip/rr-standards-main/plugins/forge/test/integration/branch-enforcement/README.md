# Branch Enforcement — Integration Test Scenario

**Task:** TASK-009
**Capabilities under test:** `forge-branching`
**Requirements:** TR-2, TR-3, BR-2, BR-5
**Spec:** [`spec/hooks.md`](../../../../.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md) — Hook 1: enforce-branch-policy.sh

---

## What This Scenario Tests

This scenario verifies that `enforce-branch-policy.sh` (PreToolUse hook) correctly
blocks and allows `git commit` and `git push` commands based on the current branch,
active effort state, and admin override environment variables.

Coverage:

1. Direct `git commit` on `main` is blocked with a structured JSON diagnostic
2. `git commit` on a feature branch is allowed without any output
3. `git push origin main` on `main` is blocked with a structured JSON diagnostic
4. `FORGE_ALLOW_MAIN_COMMIT=1` allows the operation and writes an audit log
5. Non-commit/push git commands (`git status`, `git log`, `git diff`) are always allowed
6. Absence of an active effort produces a `null` `activeEffort` field and a
   `forge:effort`-directed `nextAction`

---

## Hook Under Test

**File:** `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`

**Trigger mechanism:** Claude Code `PreToolUse` event, matcher `Bash`

**Environment variables consumed:**
- `CLAUDE_TOOL_NAME` — tool name (must equal `Bash` to proceed)
- `CLAUDE_TOOL_INPUT` — JSON object; hook extracts the `command` field
- `FORGE_ALLOW_MAIN_COMMIT` — set to `1` to bypass enforcement for one operation
- `FORGE_ADMIN_OP` — set to a reason string by forge skills to bypass enforcement

---

## Repository State Required

Each scenario specifies the git branch state and `.forge/efforts/README.md` content as part
of its setup. No network access or external services are required — all assertions
are against local shell behavior, exit codes, and file system state.

---

## Running the Scenario

Open `scenario.md` and work through each scenario in order. Each scenario specifies:

1. **Setup** — branch state and filesystem preconditions to establish
2. **Input** — the exact environment variables and `CLAUDE_TOOL_INPUT` value to supply
3. **Expected outcomes** — exit code, stderr content, and any file system assertions

All scenarios are independent and can be run in any order after establishing the
required setup state.

---

## Related Files

- **Hook implementation:** [`plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`](../../../hooks/pre-tool-use/enforce-branch-policy.sh)
- **Hook spec:** [`.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md`](../../../../.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md)
- **Technical requirements:** [`.forge/deployables/forge-plugin/capabilities/forge-branching/requirements/technical.md`](../../../../.forge/deployables/forge-plugin/capabilities/forge-branching/requirements/technical.md)
