# Integration Test: Full-Tier Single-Repo Lifecycle

## Purpose

This scenario tests the complete Forge workflow for a full-tier epic from initial
product brief through effort graduation. It verifies that an engineer using only
natural conversation — no explicit Forge commands — gets the correct workflow
artifacts in the correct locations, with correct state tracking throughout.

**Reference:** `.forge/efforts/forge-workflow/spec/user-flow.md` — the canonical
user flow this test traces.

**Scenario:** Add a "Favorite Stores" feature to a rewards-backend API service.

---

## What This Test Verifies

- Effort scaffolding triggers from a natural description (no `forge:init-effort` invocation)
- Phase transitions happen via the `forge:promote` ritual with confirmation step
- `.state.json` updates automatically via the PostToolUse hook after each artifact write
- `.forge/efforts/README.md` registry row tracks effort phase and status
- Architecture review produces both `validation/report.md` and `validation/arch-review.html`
- Implementation plan has correct `[type]` and `[wave:N]` annotations on every task
- Quality loop runs during implementation (lint → validate against spec → test), with
  multi-iteration resolution demonstrated
- `forge:verify` produces a PASS report covering all BRs and TRs
- Graduation updates `.forge/deployables/rewards-backend/` and clears the registry row

---

## Prerequisites

- Repository initialized with `forge:init` (`.forge/` directory present)
- No active efforts in `.forge/efforts/README.md`
- `plugins/forge/` available (skills, hooks, and standards accessible)
- A brownfield codebase with `docs/codebase/STACK.md` and `docs/codebase/ARCHITECTURE.md`

---

## How to Run

This is a **manual scenario test** — execute each step in a Claude Code session and
verify the expected outcomes against the filesystem and `.state.json` contents.

### Setup

```bash
# From the rewards-backend repository root (with forge initialized)
ls .forge/
# Expected: README.md  efforts/  deployables/

cat .forge/efforts/README.md
# Expected: table with no active effort rows
```

### Execution

Follow `scenario.md` step by step. For each step:

1. Paste the input prompt into Claude Code
2. After Claude responds, run the verification commands listed under "Expected outcomes"
3. Mark the step pass or fail

### Verification Commands

Common patterns used throughout the scenario:

```bash
# Check file exists
ls .forge/efforts/favorite-stores/<path>

# Check .state.json field
jq '.<field>' .forge/efforts/favorite-stores/.state.json

# Check README registry row
grep "favorite-stores" .forge/efforts/README.md

# Check file content pattern
grep "<pattern>" .forge/efforts/favorite-stores/<path>
```

---

## Pass Criteria

The scenario passes when all steps in `scenario.md` produce their expected outcomes.
A single missing file, incorrect `.state.json` value, or absent annotation is a failure.

---

## Related Files

- `scenario.md` — the full step-by-step test scenario
- `.forge/efforts/forge-workflow/spec/user-flow.md` — reference user flow
- `plugins/forge/skills/forge-arch-review/` — arch review skill under test
- `plugins/forge/skills/forge-verify/` — verification skill under test
- `plugins/forge/skills/forge-graduate/` — graduation skill under test
- `plugins/forge/hooks/` — PostToolUse and PreToolUse hooks under test
