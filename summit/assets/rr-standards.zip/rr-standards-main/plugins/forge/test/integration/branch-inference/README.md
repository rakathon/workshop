# Integration Test: Conversational Branch Type Inference

## Purpose

This scenario tests that Claude Code correctly infers git branch types from conversational
prompts — no explicit forge command required. The engineer simply describes what they want to
work on and the agent creates or reuses the correct branch following the naming conventions
defined in the "Creating branches" section of the forge-managed CLAUDE.md.

**Reference:** `plugins/forge/templates/forge-claude-md-section.md` — "Creating branches"
section (the rules the agent reads at session start).

**TASK-015** — conversational branch type inference.

**Related requirement:** `forge-branching` effort, TR-8 (type inference keyword rules and
ambiguity handling).

---

## What This Test Verifies

- **Fix inference** — crash / bug / broken language triggers `fix/` prefix
- **Feature inference** — add / new feature / endpoint language triggers `feature/` prefix
- **Refactor inference** — clean up / remove / reorganize language triggers `refactor/` prefix
- **Docs inference** — README / documentation / update docs language triggers `docs/` prefix
- **Hotfix inference** — urgent / prod / production issue language triggers `hotfix/` prefix
- **Chore inference** — bump / upgrade / dependency language triggers `chore/` prefix
- **Ambiguous prompt** — vague intent causes agent to ask one clarifying question listing type
  options; agent does NOT create a branch until the engineer answers
- **Active effort guard** — when an effort branch is already active the agent does NOT create a
  new branch and instead uses the existing effort context

---

## Prerequisites

- Repository initialized with `forge:init` (`.forge/` directory present)
- `plugins/forge/templates/forge-claude-md-section.md` installed into project `CLAUDE.md`
  (the "Creating branches" section is active)
- For Scenario 8 only: effort `favorite-stores` exists on branch `effort/favorite-stores`

---

## How to Run

This is a **manual scenario test** — execute each step in a Claude Code session and verify
the expected outcomes against the filesystem.

### Setup (Scenarios 1–7)

```bash
# Start from a clean state on main
git checkout main
git status
# Expected: clean working tree, no uncommitted changes

git branch | grep -v "^\* main"
# Note any pre-existing branches — they should not affect results
```

### Setup (Scenario 8 only)

```bash
# Ensure the effort branch exists and is active
git checkout effort/favorite-stores 2>/dev/null || git checkout -b effort/favorite-stores
git branch --show-current
# Expected: effort/favorite-stores

# Confirm active effort is registered
grep "favorite-stores" .forge/efforts/README.md
# Expected: row present with status not "graduated"
```

### Execution

For each scenario:

1. Ensure the correct setup state (see `scenario.md`)
2. Paste the input prompt into Claude Code as a conversational message (not a forge command)
3. After Claude responds, run the verification commands listed under "Expected outcomes"
4. Mark the step pass or fail

### Common Verification Commands

```bash
# Check current branch
git branch --show-current

# Check a branch exists
git branch | grep "<branch-name>"

# Check a branch was NOT created
git branch | grep "<prefix>/"
# Expected: no output

# Check branch slug format (lowercase, hyphens only, ≤40 chars after prefix/)
git branch --show-current | sed 's|.*/||' | wc -c
# Expected: ≤41 (40 chars + newline)
```

---

## Pass Criteria

The scenario passes when all 8 steps in `scenario.md` produce their expected outcomes.

Key assertions per scenario:

| Scenario | Pass condition |
|----------|---------------|
| 1 — Fix | Branch `fix/auth-flow-crash` created; confirmation message cites the branch name |
| 2 — Feature | Branch starts with `feature/`; slug is lowercase hyphens; total slug ≤40 chars |
| 3 — Refactor | Branch starts with `refactor/` |
| 4 — Docs | Branch starts with `docs/` |
| 5 — Hotfix | Branch starts with `hotfix/` |
| 6 — Chore | Branch starts with `chore/` |
| 7 — Ambiguous | No branch created; response is a question listing ≥4 type options |
| 8 — Active effort | Branch unchanged (`effort/favorite-stores`); no new branch created |

A single wrong prefix, premature branch creation, or missed guard is a failure.

---

## Related Files

- `scenario.md` — full step-by-step test scenarios
- `plugins/forge/templates/forge-claude-md-section.md` — "Creating branches" rules under test
- `../full-tier-lifecycle/` — full workflow lifecycle reference
- `../lightweight-tier/` — lightweight effort patterns reference
