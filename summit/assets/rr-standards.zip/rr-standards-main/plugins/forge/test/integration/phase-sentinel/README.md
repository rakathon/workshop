# Integration Test: Phase Sentinel — Automatic Phase Advancement

## Purpose

This scenario tests the Phase Entry Check (PEC) behavior introduced in
`forge:plan`, `forge:commit`, and `forge:verify`. These skills now call
`forge:promote --target <phase>` automatically at natural workflow transition
points, keeping effort state aligned with the work that has actually been done.

---

## What This Test Verifies

- `forge:plan` invoked in discovery phase triggers the discovery → planning
  advancement prompt (Phase Entry Check)
- `forge:plan` completion triggers the planning → implementation advancement
  prompt (Phase Completion Check)
- `forge:commit` invoked in planning phase triggers planning → implementation
  advancement prompt (Phase Entry Check fallback)
- `forge:commit` invoked in discovery phase triggers a multi-step
  discovery → planning → implementation advancement (gap detection)
- `forge:verify` invoked in implementation phase triggers implementation →
  verification advancement prompt (Phase Entry Check)
- `forge:verify` PASS result triggers verification → review advancement
  prompt (Phase Completion Check)
- `forge:promote --target <phase>` advances multiple phases at once when
  invoked directly
- Validation gate: when advancing out of discovery without a validation
  report, the engineer is prompted to run `forge:validate` first
- No-op behavior: Phase Entry Checks are silent when the effort is already
  at or past the target phase

---

## Prerequisites

- Repository initialized with `forge:init` (`.forge/` directory present)
- No active efforts in `.forge/efforts/README.md`

---

## How to Run

This is a **manual scenario test** — execute each step in a Claude Code session
and verify the expected outcomes against the filesystem and `.state.json` contents.

### Setup

```bash
ls .forge/
# Expected: README.md  efforts/  deployables/

cat .forge/efforts/README.md
# Expected: table with no active effort rows
```

### Execution

Follow `scenario.md` step by step. For each step:

1. Paste the input prompt into Claude Code
2. After Claude responds, run the verification commands listed under "Expected outcomes"
3. Mark the step pass or fail

---

## Pass Criteria

The scenario passes when:
- Phase Entry Checks fire at each expected skill invocation
- The engineer is prompted with a chain summary for multi-step gaps
- Confirmation advances all phases in the gap, one commit per phase
- Decline leaves `.state.json` unchanged
- Validation gate prompts correctly when `validation/report.md` is absent
- No-op cases produce no prompt and no state change

---

## Related Files

- `scenario.md` — full step-by-step test scenario
- `plugins/forge/skills/promote/SKILL.md` — enhanced promote skill under test
- `plugins/forge/skills/plan/SKILL.md` — Phase Entry/Completion Checks
- `plugins/forge/skills/commit/SKILL.md` — Phase Entry Check
- `plugins/forge/skills/verify/SKILL.md` — Phase Entry/Completion Checks
