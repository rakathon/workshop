# Integration Test: Lightweight Tier Efforts

## Purpose

This scenario tests the three lightweight effort subtypes — patch, extension, and PoC
— verifying that each produces the correct scaffolding, state, and workflow behavior
without requiring the full discovery/planning/verification cycle.

**Reference:** ADR-006 (PoC code does not become production code), forge:effort SKILL.md
(Step 2–5 lightweight scaffolding rules).

**Scenario domain:** The same Favorite Stores feature from the full-tier lifecycle test,
used here for three follow-on work items that arise after the initial feature ships.

---

## What This Test Verifies

### Scenario A — Patch (bug fix)

- patch efforts start in `implementation` with no `requirements/` or `spec/` directories
- `.state.json` records `subtype: "patch"`, `tier: "lightweight"`, `productionBound: true`
- forge:review (CI check) is a required PR status check and blocks merge on failure
- Effort closes without a discovery, planning, arch-review, or QA phase

### Scenario B — Extension (add endpoint)

- extension efforts offer an optional discovery phase; engineer opts in here
- `requirements/` and `spec/` directories are scaffolded when discovery is selected
- `.state.json` records `subtype: "extension"`, `tier: "lightweight"`
- forge:arch-review is NOT required (extensions skip architecture review)
- forge:review is required for the PR
- QA is warranted at R2 risk

### Scenario C — PoC (proof of concept)

- PoC efforts are `productionBound: false`
- forge:review is OPTIONAL and non-blocking
- Security/privacy violations in CI do not block merge
- System warns when attempting to merge PoC code to a production-tracked branch
- PoC code cannot be directly promoted — a new production effort must be created
- When a follow-on production effort is created, the PoC `.state.json` gains a
  `spawnedWorkItems` entry

---

## Prerequisites

- Repository initialized with `forge:init` (`.forge/` directory present)
- Favorite Stores feature already shipped (graduate effort present in `.forge/`)
- `plugins/forge/` available (skills, hooks, and standards accessible)

---

## How to Run

This is a **manual scenario test** — execute each step in a Claude Code session and
verify the expected outcomes against the filesystem and `.state.json` contents.

Each scenario (A, B, C) is independent and can be run separately. Reset the `.forge/`
state between scenarios if running all three in sequence.

### Setup

```bash
# From the rewards-backend repository root (with forge initialized)
ls .forge/
# Expected: README.md  efforts/  deployables/

cat .forge/efforts/README.md
# Expected: table with no active effort rows (or only graduated rows)
```

### Execution

Follow `scenario.md` step by step. For each step:

1. Paste the input prompt into Claude Code
2. After Claude responds, run the verification commands listed under "Expected outcomes"
3. Mark the step pass or fail

### Verification Commands

Common patterns used throughout the scenario:

```bash
# Check .state.json field
jq '.<field>' .forge/efforts/<id>/.state.json

# Confirm directory does NOT exist
[ ! -d ".forge/efforts/<id>/requirements" ] && echo "PASS: no requirements/" || echo "FAIL: requirements/ present"

# Check README registry row
grep "<id>" .forge/efforts/README.md

# Check for spawned work item
jq '.spawnedWorkItems' .forge/efforts/<poc-id>/.state.json
```

---

## Pass Criteria

The scenario passes when all steps in `scenario.md` produce their expected outcomes.

Key assertions by scenario:
- **A (patch):** No `requirements/` directory; `currentPhase: "implementation"` at creation
- **B (extension):** `requirements/` present (engineer opted in); no `validation/` directory
- **C (PoC):** `productionBound: false`; production-branch merge attempt surfaces warning;
  follow-on effort creation updates `spawnedWorkItems` in PoC `.state.json`

---

## Related Files

- `scenario.md` — the full step-by-step test scenario (all three subtypes)
- `../full-tier-lifecycle/` — the full-tier baseline this test extends
- `plugins/forge/skills/effort/SKILL.md` — effort classification and scaffolding rules
- `.forge/efforts/forge-workflow/spec/arch-decisions/ADR-006-poc-code-does-not-become-production-code.md`
- `plugins/forge/skills/review/` — CI review skill (required vs optional behavior)
