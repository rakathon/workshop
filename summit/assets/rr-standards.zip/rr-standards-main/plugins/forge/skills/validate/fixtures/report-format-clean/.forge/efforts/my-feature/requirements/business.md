# Business Requirements — my-feature

## BR-1: Users need a way to search for products by name

When a user enters a search term, the system must return matching products
ordered by relevance.

**Acceptance criteria:**
- Search returns results in under 500ms
- Empty search term returns empty results, not an error
