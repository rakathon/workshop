---
name: forge:validate
description: >
  Full cross-reference validation of discovery artifacts against each other and
  organizational standards. Produces validation/report.md — the gate artifact
  read by forge:promote. Use whenever an engineer wants to validate discovery,
  asks "is my discovery ready to promote?", says "validate my specs", "check
  my requirements coverage", "run validation before promoting", "is my design
  complete?", or "validate my discovery artifacts". Trigger also on "run
  forge:validate" or any intent to check spec quality before moving to planning.
agent-type: orchestrator
---

# forge:validate

Validates all discovery artifacts for an effort: requirements traceability,
standards compliance, cross-spec consistency, and ADR quality. Produces
`validation/report.md` with a grep-extractable `**Result:** PASS | PASS WITH CONCERNS | FAIL`
line that `forge:promote` reads as its gate artifact.

This skill has two parts:
1. **Orchestrator steps** (ORC-*) — run in the engineer's session. Pre-flight checks,
   spawning the worker sub-agent, reading the result, and updating state.
2. **Worker steps** (STEP-*) — run inside a spawned sub-agent. All validation logic
   and report writing.

---

## Variables

- `<effort_id>` — the effort slug (e.g., `forge-validate`, `favorites-api`)
- `<effort_dir>` — `.forge/efforts/<effort_id>/`
- `<state_file>` — `<effort_dir>/.state.json`
- `<report_file>` — `<effort_dir>/validation/report.md`
- `<skills_root>` — the `plugins/forge/skills/` directory, located at `../` relative
  to this skill file (i.e., `plugins/forge/skills/validate/../` = `plugins/forge/skills/`).
  Used to locate sibling validator SKILL.md files for delegation in STEP-4.

**Resolving `<effort_id>` at runtime:**

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

---

## Orchestrator Steps

These steps run in the engineer's main session.

### ORC-1: Confirm Phase and State

Read `<state_file>`. Check:

1. `currentPhase` must be `"discovery"`.
2. `phases.discovery.status` must not be `"approved"`.

**If `currentPhase != "discovery"`:** Stop with:
> "forge:validate is for the discovery phase. The current phase is `<currentPhase>`.
> If discovery was already approved and you need to revalidate, run `forge:reopen discovery` first."

**If `phases.discovery.status == "approved"`:** Stop with:
> "Discovery is already approved. To re-run validation, first run `forge:reopen discovery`."

### ORC-2: Confirm Minimum Artifacts Exist

Check that `<effort_dir>/requirements/business.md` exists and is non-empty.
**If absent:** Stop with:
> "Business requirements not found at `<effort_dir>/requirements/business.md`.
> Run `forge:elaborate` to produce business requirements before validating."

### ORC-3: Check for Active Checkpoint

Read `<state_file>`. Check `phases.discovery.checkpoint` (if this field exists and
`activeSkill == "forge:validate"` and `lastCompletedStep` is non-null):

> "A previous forge:validate run was interrupted at step `<lastCompletedStep>`.
> Resume from that step, or start over?"

If resume: pass `resume_from_step` to the worker. If start over: proceed without it.
If no checkpoint field exists: proceed normally.

### ORC-4: Spawn the Worker

Spawn a sub-agent (via the Task tool). The sub-agent does not have this SKILL.md
in its context — you must include the full Worker Steps in the task prompt. Use
this template (substituting resolved variable values):

> You are the forge:validate worker. Run all validation checks on the discovery
> artifacts for effort `<effort_id>` and write `validation/report.md`.
>
> Variables:
> - effort_id: `<effort_id>`
> - effort_dir: `<effort_dir>`
> - resume_from_step: `<step name or null>`
> - tmp_prefix: `/tmp/forge-validate-<effort_id>`
>
> Read the full Worker Steps from `plugins/forge/skills/validate/SKILL.md`
> (the section "## Worker Steps" through "## Internal Agents") and follow
> them in order, starting from STEP-1 (or `resume_from_step` if provided).
>
> For standards compliance (STEP-4), delegate to the targeted validator skills
> by reading their SKILL.md files at `../validate-api/SKILL.md`,
> `../validate-storage/SKILL.md`, and `../validate-messaging/SKILL.md` relative
> to this skill file and following their worker steps.
>
> Use `<tmp_prefix>-traceability.json` and `<tmp_prefix>-cross-spec.json` as
> temp file paths for the internal agents. When complete, confirm
> `<effort_dir>/validation/report.md` has been written and committed.

### ORC-5: Read Result and Present to Engineer

After the worker sub-agent completes, read `<report_file>`.

Extract the result line:
```bash
grep '^\*\*Result:\*\*' "<effort_dir>/validation/report.md"
```

Present the full report to the engineer. If `<report_file>` does not exist (worker
failed before writing), surface the error and set state to `"failed"` in ORC-6.

### ORC-6: Update and Commit State

Update `<state_file>`:

| Result line | Set `phases.validation.status` to |
|-------------|----------------------------------|
| `**Result:** PASS` | `"passed"` |
| `**Result:** PASS WITH CONCERNS` | `"passed_with_concerns"` |
| `**Result:** FAIL` | `"failed"` |
| Report absent / worker failed | `"failed"` |

Then commit the state change:
```bash
git add "<state_file>"
git commit -m "chore(<effort_id>): record validation result"
```

Print:
> "Validation complete. Result: `<PASS | PASS WITH CONCERNS | FAIL>`
> Report: `<effort_dir>/validation/report.md`
> Next: resolve any REQUIRED findings, then run `forge:promote` to advance to planning."

---

## Worker Steps

The worker sub-agent follows these steps sequentially. The worker does not update
`.state.json` — state updates are handled by the orchestrator (ORC-6).

### STEP-1: Load Discovery Artifacts

Load the following files if they exist. Use the `effort_dir` variable passed by
the orchestrator — do not re-derive it.

| File | Required? |
|------|-----------|
| `requirements/business.md` | Required (pre-checked by orchestrator) |
| `requirements/technical.md` | Optional (absent = SUGGESTION in traceability check) |
| `spec/api/*.yaml` | Optional |
| `spec/storage/*.md` | Optional |
| `spec/messaging/*.md` | Optional |
| `spec/arch-decisions/*.md` | Optional |

Read each present file fully. For absent optional files/globs: note the domain as
"not present" — do not error.

Track which spec domains are present:
- `api_present` — true if any `spec/api/*.yaml` files loaded
- `storage_present` — true if any `spec/storage/*.md` files loaded
- `messaging_present` — true if any `spec/messaging/*.md` files loaded
- `adrs_present` — true if any `spec/arch-decisions/*.md` files loaded

Count total lines across all loaded files. Store as `<total_lines>`.

If resuming from a checkpoint, skip to the step named in `resume_from_step`.

### STEP-2: Choose Execution Mode

If `<total_lines>` > 1,000:

Spawn these sub-agents in parallel (only spawn for domains that are present):
- `requirements-traceability-agent` — always spawn
- `forge:validate-api` worker — spawn only if `api_present == true`
- `forge:validate-storage` worker — spawn only if `storage_present == true`
- `forge:validate-messaging` worker — spawn only if `messaging_present == true`
- `cross-spec-consistency-agent` — spawn only if more than one spec domain is present

For the targeted validator workers, follow their respective SKILL.md worker steps
(read via relative path as described in STEP-4). For the traceability and
cross-spec agents, see § Internal Agents below.

Each agent writes its result to a temp file at `<tmp_prefix>-<name>.json`.
Wait for all spawned agents to complete before proceeding to STEP-7.

If `<total_lines>` ≤ 1,000:

Run checks STEP-3 through STEP-6 sequentially in the current session.

### STEP-3: Requirements Traceability Check

For each BR-* identifier found in `requirements/business.md`:
- Reason semantically over all loaded spec artifacts to determine whether any
  addresses the BR's stated outcome. A literal string match of the identifier
  is not required — semantic coverage is sufficient.
- **If no spec artifact addresses a BR:** add finding:
  ```
  **REQUIRED** — BR-N has no covering spec artifact. Add a spec (API contract, storage schema, etc.) that addresses this requirement.
  ```

For each TR-* identifier in `requirements/technical.md` (if present):
- Reason semantically over all spec artifacts.
- **If no spec artifact addresses a TR:** add finding:
  ```
  **SUGGESTION** — TR-N has no covering spec artifact. Ensure a spec artifact addresses this technical constraint.
  ```

If `requirements/technical.md` is absent:
- Add finding:
  ```
  **SUGGESTION** — requirements/technical.md not found. Run forge:elaborate to produce technical requirements before promoting.
  ```

### STEP-4: Standards Compliance Check

Delegate standards compliance to the targeted validator skills. Each targeted
validator loads its own standards and enforcement policy files (with three-level
policy fallback: deployable → project → plugin default), so there is no need
to re-implement or duplicate that logic here.

For each spec domain that is present, spawn the corresponding validator as a
sub-agent by reading its SKILL.md and following its worker steps, passing
`effort_id` and `effort_dir` as context. Collect the inline report text the
sub-agent produces, then extract its findings for inclusion in `validation/report.md`.

**API specs** (`api_present == true`):
- Read `[../validate-api/SKILL.md](../validate-api/SKILL.md)` and follow its worker
  steps for the effort's `spec/api/` directory.
- Collect all `[REQUIRED]` and `[SUGGESTION]` findings from the inline report.
- Map `[REQUIRED]` → `**REQUIRED**`; `[SUGGESTION]` → `**SUGGESTION**` in the
  validation report.

**Storage specs** (`storage_present == true`):
- Read `[../validate-storage/SKILL.md](../validate-storage/SKILL.md)` and follow
  its worker steps for the effort's `spec/storage/` directory.
- Collect all findings as above.

**Messaging specs** (`messaging_present == true`):
- Read `[../validate-messaging/SKILL.md](../validate-messaging/SKILL.md)` and
  follow its worker steps for the effort's `spec/messaging/` directory.
- Collect all findings as above.

If a targeted validator SKILL.md is not found (e.g., the skill has not been
authored yet), add:
```
**SUGGESTION** — forge:validate-<domain> skill not found. Standards compliance
check for <domain> specs skipped. Install the skill to enable this check.
```

Each finding carried into the validation report must retain: source artifact
filename, rule ID, and the specific content that violates it.

### STEP-5: Cross-Spec Consistency Check

If fewer than two spec domains are present: skip this check. Add to the report:
"Single spec artifact present — cross-spec consistency check not applicable."

Otherwise, compare all spec artifacts against each other to detect conflicts.

**Conflict patterns to detect:**

| Pattern | Severity |
|---------|---------|
| API endpoint writes to a storage field not in the schema | REQUIRED |
| Messaging event references an entity type not in the storage schema | REQUIRED |
| Two spec artifacts define different schemas for the same named entity | REQUIRED |
| API endpoint returns a field not defined in any response schema or storage schema | SUGGESTION |
| A TR declares a performance SLA that no spec artifact addresses | SUGGESTION |

For each conflict found, add a finding with the appropriate severity:
```
**REQUIRED** — Cross-spec conflict between `<artifact_a>` and `<artifact_b>`:
<description of the conflict>
```
or:
```
**SUGGESTION** — Cross-spec inconsistency between `<artifact_a>` and `<artifact_b>`:
<description of the inconsistency>
```

### STEP-6: ADR Quality Check

If `adrs_present == false`: add to the report: "No ADRs present — ADR quality check not applicable."

Otherwise, for each file in `spec/arch-decisions/*.md`:
- Check for the presence of these four sections (case-insensitive heading match):
  - `Context` (or `## Context`)
  - `Decision` (or `## Decision`)
  - `Alternatives` (or `## Alternatives Considered`)
  - `Consequences` (or `## Consequences`)
- **Missing section(s):**
  ```
  **SUGGESTION** — ADR <filename>: missing section(s): <list of missing sections>. ADRs must document Context, Decision, Alternatives, and Consequences.
  ```
- **All sections present:** no finding for this file.

### STEP-7: Compute Overall Result

Collect all findings from STEP-3 through STEP-6 (or from the internal agents if
the parallel path was used in STEP-2).

| Condition | Result |
|-----------|--------|
| Any finding labelled `**REQUIRED**` | `FAIL` |
| No `**REQUIRED**` findings; one or more `**SUGGESTION**` findings | `PASS WITH CONCERNS` |
| No findings at all | `PASS` |

### STEP-8: Write validation/report.md

Create `<effort_dir>/validation/` if it does not exist.

Write `<effort_dir>/validation/report.md` with this exact structure:

```markdown
**Result:** PASS | PASS WITH CONCERNS | FAIL

## Requirements Traceability

<findings from STEP-3, or "All BRs and TRs covered. No uncovered requirements.">

## Standards Compliance

<findings from STEP-4, or "No spec artifacts present — standards compliance check not applicable." or "All checked artifacts comply with applicable standards.">

## Cross-Spec Consistency

<findings from STEP-5, or "No conflicts found." or "Single spec artifact — check not applicable.">

## ADR Quality

<findings from STEP-6, or "No ADRs present — check not applicable." or "All ADRs have required sections.">
```

**Critical format rules:**
- `**Result:**` must be the **first non-blank line** of the file. No title, no preamble, no blank lines before it.
- The value after `**Result:** ` must be exactly one of: `PASS`, `PASS WITH CONCERNS`, `FAIL`.
- Every individual finding must begin with `**REQUIRED**` or `**SUGGESTION**` in bold.

If `validation/report.md` already exists (a re-run): overwrite it silently. This is expected behavior.

### STEP-9: Commit the Report

Stage and commit the report file:

```bash
git add "<effort_dir>/validation/report.md"
git commit -m "docs(<effort_id>): design validation report"
```

If git reports "nothing to commit" (because the report is identical to the previous
run): treat this as success, not an error. The report was already committed.

If the commit fails for any other reason: surface the full error. Do not suppress it.
The orchestrator will read the error and surface it to the engineer.

---

## Internal Agents

Used only when `<total_lines>` > 1,000. Standards compliance agents (API, storage,
messaging) are handled by spawning the corresponding targeted validator skill workers
(see STEP-4 and STEP-2). The two remaining internal agents handle checks that have
no dedicated targeted validator.

Each agent writes its result JSON to a named temp file. Use the `<tmp_prefix>`
variable passed by the orchestrator (default: `/tmp/forge-validate-<effort_id>`):

| Agent | Temp file |
|-------|-----------|
| requirements-traceability-agent | `<tmp_prefix>-traceability.json` |
| cross-spec-consistency-agent | `<tmp_prefix>-cross-spec.json` |

### requirements-traceability-agent

**Prompt to use when spawning:**
> Read the provided business and technical requirements. For each BR-* and TR-*
> identifier, determine whether any of the provided spec artifacts semantically
> addresses it (coverage is intentional — not a string match). Write your result
> as JSON to `<tmp_path>`.

**Receives (pass as context in the spawn prompt):**
- Full text of `requirements/business.md`
- Full text of `requirements/technical.md` (or note "absent")
- Full text of all loaded spec artifacts

**Writes to `<tmp_path>`:**
```json
{
  "coverage_map": {
    "BR-1": ["spec/api/members.yaml"],
    "BR-2": [],
    "TR-1": ["spec/storage/postgres.md"],
    "TR-2": []
  },
  "uncovered_brs": ["BR-2"],
  "uncovered_trs": ["TR-2"],
  "technical_reqs_absent": false
}
```

### cross-spec-consistency-agent

**Only spawn if more than one spec domain is present.**

**Prompt to use when spawning:**
> Read all provided spec artifacts. Identify conflicts between them — look for API
> fields not in the storage schema, messaging events referencing undefined entities,
> conflicting entity definitions across artifacts, and performance SLAs stated in
> requirements that no spec artifact addresses. Write your conflicts as JSON to
> `<tmp_path>`.

**Receives:** Full text of all spec artifacts across all domains.

**Writes to `<tmp_path>`:**
```json
{
  "conflicts": [
    {
      "severity": "REQUIRED",
      "artifact_a": "spec/api/members.yaml",
      "artifact_b": "spec/storage/postgres.md",
      "description": "POST /members writes field `loyalty_tier` which is not defined in the members table schema."
    }
  ]
}
```

Returns `{"conflicts": []}` if no conflicts found.

---

## Deviation Rules

| Situation | Behavior |
|-----------|----------|
| `requirements/business.md` absent | Orchestrator stops in ORC-2; worker not spawned |
| `requirements/technical.md` absent | Worker adds SUGGESTION; continues |
| A targeted validator SKILL.md not found | Worker adds SUGGESTION noting the missing skill; continues |
| Fewer than two spec domains present | Cross-spec consistency check skipped; noted in report |
| No spec artifacts at all | Standards compliance and cross-spec checks marked not applicable; traceability check still runs |
| `validation/report.md` already exists | Worker overwrites silently (re-run is expected behavior) |
| Worker cannot write `validation/report.md` | Worker surfaces filesystem error; orchestrator sets validation.status = "failed" |
| Commit fails in STEP-9 | Worker surfaces error; orchestrator reads it and updates state accordingly |

---

## Output Summary

| Artifact | Path | Written by |
|----------|------|------------|
| Validation report | `<effort_dir>/validation/report.md` | Worker (STEP-8) |
| Report commit | `docs(<effort_id>): design validation report` | Worker (STEP-9) |
| State update | `<state_file>` — `phases.validation.status` | Orchestrator (ORC-6) |
| State commit | `chore(<effort_id>): record validation result` | Orchestrator (ORC-6) |

**The worker does not update `.state.json`.** State updates are the orchestrator's responsibility.

A successful `forge:validate` run produces:
1. `validation/report.md` with a grep-extractable `**Result:**` line as the first non-blank line.
2. A commit: `docs(<effort_id>): design validation report`.
3. An updated `phases.validation.status` in `.state.json` (written and committed by the orchestrator after reading the report).
