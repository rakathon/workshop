# Business Requirements — done-effort

## BR-1: Users need a feature

Some feature that was already designed.
