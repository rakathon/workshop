# Technical Requirements — my-feature

## TR-1 (← BR-1): Search API endpoint

The system must expose a GET /products/search endpoint that accepts a `q` query
parameter and returns an array of matching Product objects.

## TR-2 (← BR-1): Response time SLA

The search endpoint must return results in under 500ms at the 95th percentile.
