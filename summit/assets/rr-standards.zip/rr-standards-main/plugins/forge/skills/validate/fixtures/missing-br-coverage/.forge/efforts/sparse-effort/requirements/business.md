# Business Requirements — sparse-effort

## BR-1: Users need a product search feature

When a user searches for a product, the system returns matches.

## BR-2: Users need to export search results to CSV

Users must be able to download their search results as a CSV file.
