# forge:browserstack-to-bdd

Fetches a test case from BrowserStack Test Management using the REST API, converts
its steps to a Gherkin `.feature` file, and optionally chains directly into
`forge:build-playwright-tests` to produce a running Playwright spec in one pass.

---

## When to Use

Use `forge:browserstack-to-bdd` when test cases already exist in BrowserStack Test
Management and you want to bring them into the Playwright BDD test suite without
going through the full discovery flow.

Typical triggers:
- "Convert TC-72228 to a BDD test"
- "Fetch TC-181303 from BrowserStack and generate the feature file"
- "Import a BrowserStack test case for Canada"
- A QA engineer has already written test cases in BrowserStack and you want to
  automate them

This is an **alternate entry point** that replaces `forge:spec-tests` +
`forge:spec-ui-e2e` when the test specification already lives in BrowserStack.

---

## Usage

```
forge:browserstack-to-bdd <TC-ID> [feature-area]
```

| Argument | Description | Required | Example |
|---|---|---|---|
| `TC-ID` | BrowserStack test case identifier | Yes | `TC-72228` |
| `feature-area` | Feature area folder to write into | No | `signup-login`, `shopping-trip` |

### Examples

```
forge:browserstack-to-bdd TC-72228
forge:browserstack-to-bdd TC-72228 signup-login
forge:browserstack-to-bdd TC-181303 shopping-trip
```

---

## Pipeline Position

This skill is an alternate entry point that replaces `forge:spec-tests` +
`forge:spec-ui-e2e` — it feeds `.feature` files directly into
`forge:build-playwright-tests`. After writing the `.feature` file, the skill asks
whether to chain immediately into `forge:build-playwright-tests`.

For the full pipeline diagram, see `forge:build-playwright-tests`.

---

## What It Does

1. Reads BrowserStack credentials from the shell environment
2. Checks whether `features/<region>/<feature-area>/<TC-ID>.feature` already exists (prompts to overwrite)
3. Fetches the test case from the BrowserStack Test Management API
4. Strips HTML tags and decodes HTML entities from all step text
5. Infers user-type tag (`@anonymous`, `@regular`, `@signup`) and region tag from step content
6. Maps BrowserStack steps to Gherkin Given/When/Then format
7. Writes `features/<region>/<feature-area>/<TC-ID>.feature`
8. Prints the generated feature file and step mapping
9. Offers to chain into `forge:build-playwright-tests`

---

## Step Mapping

| BrowserStack step contains | Gherkin output |
|---|---|
| "navigate to" + homepage | `Given I navigate to the homepage` |
| "navigate to" + specific page | `And I navigate to <page>` |
| "log in" / "sign in" (first occurrence) | `Given I am logged in as a regular user` |
| "click" / "select" + element | `And I click <element>` |
| "enter" / "type" / "fill" + field | `And I enter <value> in the <field> field` |
| "close" + popup/modal | `And I close the popup if present` |
| "verify" / "should" / "confirm" | `Then I should see <outcome>` |
| "redirect" / "directed to" | `Then I should be redirected to <destination>` |

Inline selector hints (e.g. `"xpath=//td[@class='...']"`) are preserved verbatim.

---

## Output

```
features/<region>/<feature-area>/<TC-ID>.feature
```

Example:
```gherkin
Feature: TC-72228 Verify the Forgot Password button on the Sign In overlay
  User verifies the Forgot Password button is accessible from the Sign In overlay.

  @anonymous @canada-prod
  Scenario: Forgot Password button redirects to Password Help Page
    Given I navigate to the homepage
    When I click the Sign In button
    Then I should see the Forgot Password button
    And I click the Forgot Password button
    Then I should be redirected to the Password Help Page
```

---

## Prerequisites

The following environment variables must be set before running:

```
BROWSERSTACK_USERNAME=your_username
BROWSERSTACK_ACCESS_KEY=your_access_key
```

How they are set (shell profile, CI secrets, `.env` loaded by the caller) does not matter.
No project ID is needed — the API searches globally across all BrowserStack projects.

If either credential is missing, the skill stops with instructions to set them.

---

## Conventions

| Rule | Detail |
|---|---|
| Never hardcode credentials | Always read from the shell environment |
| Never write to `tests/` | This skill only writes `.feature` files |
| Strip all HTML | BrowserStack step text contains HTML — always cleaned |
| Preserve selector hints | Quoted selectors in steps are kept inline |
| One file per TC ID | Multiple TCs are never merged into one feature file |

---

## Related Skills

| Skill | When to use |
|---|---|
| `forge:spec-tests` | Author test suites from requirements during discovery — use when no BrowserStack TC exists |
| `forge:spec-ui-e2e` | Convert `ui-e2e-test-suite.md` to `.feature` files — use in the normal Forge flow |
| `forge:build-playwright-tests` | Generate Playwright `.spec.ts` from `.feature` files |
| `forge:ui-tests-run` | Run the generated `.spec.ts` files |
| `forge:ui-tests-fix` | Fix failing tests |
