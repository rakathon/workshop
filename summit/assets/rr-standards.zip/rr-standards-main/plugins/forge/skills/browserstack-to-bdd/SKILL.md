---
name: forge:browserstack-to-bdd
description: Fetch a test case by ID from BrowserStack Test Management, convert its steps to a Gherkin .feature file, and optionally chain into forge:build-playwright-tests to produce a ready-to-run Playwright spec. No project ID needed — the API searches globally. Trigger on: "browserstack to bdd", "convert browserstack test", "fetch test case from browserstack", "import from browserstack", "automate this BrowserStack TC", "we already have test cases in BrowserStack", or when given a BrowserStack TC identifier like "TC-72228". Also trigger when an engineer wants to skip the full forge:spec-tests discovery flow because test cases already exist in BrowserStack.
agent-type: inline
---

# forge:browserstack-to-bdd

Fetch a test case from BrowserStack Test Management using the REST API, convert
its steps to Gherkin BDD format, save as a `.feature` file, then optionally chain
into `forge:build-playwright-tests` to produce a ready-to-run Playwright spec.

**No project ID needed** — the API searches globally across all BrowserStack projects.

**Command:**
```
forge:browserstack-to-bdd <TC-ID> [feature-area]
```

---

## Arguments

- **First arg = TC identifier** (required): e.g. `TC-72228`
- **Second arg = feature area** (optional): the kebab-case subdirectory under `features/<region>/` that groups related tests — e.g. `signup-login`, `shopping-trip`, `sem`. It mirrors the BrowserStack folder the TC belongs to. If omitted, Claude infers it from the TC's BrowserStack folder name using the mapping table in Step 2.

Examples:
```
forge:browserstack-to-bdd TC-72228                    ← feature area auto-inferred
forge:browserstack-to-bdd TC-72228 signup-login       ← explicit feature area
forge:browserstack-to-bdd TC-181303 shopping-trip
```

**Batch conversion:** run the skill multiple times with different TC IDs, or ask Claude to convert a list of TC IDs in one session.

---

## Step 0: Load Credentials

Read `BROWSERSTACK_USERNAME` and `BROWSERSTACK_ACCESS_KEY` from the shell environment.
How they are set (shell profile, CI secrets, `.env` loaded by the caller) does not matter —
the skill only requires that they are present when it runs.

`BROWSERSTACK_PROJECT_ID` is **not needed** — the global API finds any TC across all projects.

If either variable is missing, stop:
```
❌ Missing BrowserStack credentials.

Set these environment variables:
  BROWSERSTACK_USERNAME=your_username
  BROWSERSTACK_ACCESS_KEY=your_access_key
```

---

## Step 1: Fetch Test Case from BrowserStack API

Use the **global endpoint** — no project ID required:

```bash
curl -s -u "$BROWSERSTACK_USERNAME:$BROWSERSTACK_ACCESS_KEY" \
  "https://test-management.browserstack.com/api/v2/test-cases?id=<TC-ID>"
```

Parse the JSON response. The TC will be the first item in `test_cases[]`.

Extract:
- `title` — test case name
- `description` — plain text
- `preconditions` — plain text
- `steps[]` — array of `{ step, result }` objects
- `tags[]` — array of tag strings
- `urls.self` — the BrowserStack URL (contains project numeric ID for reference)

**Strip all HTML tags** from every field: replace `<[^>]+>` with empty string,
trim whitespace, decode HTML entities (`&quot;` → `"`, `&amp;` → `&`, `&#39;` → `'`).

If the HTTP response is not 200:
- 401 → stop: `❌ BrowserStack authentication failed. Check BROWSERSTACK_USERNAME and BROWSERSTACK_ACCESS_KEY.`
- 429 → stop: `❌ BrowserStack rate limit hit. Wait a moment and retry.`
- Any other non-200 → stop: `❌ BrowserStack API returned HTTP <status>. Check your credentials and try again.`

If `test_cases` is empty:
```
❌ TC-XXXXX not found in BrowserStack.
   Check the TC ID is correct (e.g. TC-72228).
```

---

## Step 2: Infer Tags and Feature Area from Content

### Determine user-type tag

Scan title, description, preconditions, and steps for these keywords:

| Keyword found | Tag |
|---|---|
| "log in", "logged in", "sign in", "signed in", "credentials", "existing user" | `@regular` |
| "sign up", "register", "new user", "create account", "join" | `@signup` |
| None of the above | `@anonymous` |

### Determine region tag

Scan title and description:

| Content match | Region | Tag |
|---|---|---|
| "rakuten.ca" or "canada" | `ca` | `@canada-prod` |
| "rakuten.co.uk" or ".co.uk" or "uk" | `uk` | `@uk-prod` |
| None of the above | `us` | `@usa-prod` |

### Determine feature area (if not provided as arg)

Map the TC's BrowserStack folder name to a kebab-case feature area:

| BrowserStack folder | Feature area folder |
|---|---|
| SignUp & Login - Desktop | `signup-login` |
| Sign-up & Login - mWeb | `signup-login` |
| Shopping Trip | `shopping-trip` |
| SEM | `sem` |
| Favorites | `favorites` |
| Events | `events` |
| app_shell / AppShell | `appshell` |
| evergreen_rewards_hub | `rewards-hub` |
| Rewards Hub Milestones | `rewards-hub` |
| Bilt Experience | `bilt` |
| Amazon Offer | `amazon-offer` |
| Toast/T&C - mWeb | `toast-tc` |
| Unknown / not matched | use `general` and notify user |

---

## Step 3: Check If Feature File Already Exists

Now that region and feature area are known, check if
`features/<region>/<feature-area>/<TC-ID>.feature` already exists.

- If it exists → ask: `"Feature file already exists. Overwrite? [yes/no]"`
- If no → stop.
- If yes → continue and overwrite.

---

## Step 4: Map BrowserStack Steps to Gherkin

### First step rule

- `@regular` → `Given I am logged in as a regular user`
- `@signup` → `Given I create a new account`
- `@anonymous` → `Given I navigate to the homepage`

### Step mapping

| Step text contains | Gherkin line |
|---|---|
| "navigate to" + homepage/rakuten (first step) | `Given I navigate to the homepage` |
| "navigate to" + specific page/URL | `And I navigate to <page description>` |
| "log in" / "sign in" / "logged in" | `Given I am logged in as a regular user` |
| "click" or "select" + element | `And I click <element description>` |
| "enter" / "type" / "fill" + field | `And I enter <value> in the <field> field` |
| "close" + popup/modal/overlay | `And I close the popup if present` |
| "verify" / "validate" / "confirm" / "check" / "should" | `Then I should see <what to verify>` |
| "redirect" / "directed to" / "navigated to" | `Then I should be redirected to <destination>` |

### Selector hints

If a step contains a quoted selector like `"xpath=//..."` or `"#selector"`, preserve
it inline in the Gherkin step:
```gherkin
Then I should see element "xpath=//td[@class='pad-20-l f-13 lh-18']"
```

---

## Step 5: Write the Feature File

Output path: `features/<region>/<feature-area>/<TC-ID>.feature`

Create the directory if it does not exist.

```gherkin
Feature: <TC-ID> <title>
  <description — one line summary>

  @<usertype-tag> @<region-tag>
  Scenario: <title>
    <gherkin steps — one per line>
```

**Example:**

```gherkin
Feature: TC-72228 Verify the Forgot Password button on the Sign In overlay
  User verifies the Forgot Password button is accessible from the Sign In overlay.

  @anonymous @canada-prod
  Scenario: Forgot Password button redirects to Password Help Page
    Given I navigate to the homepage
    And I click the Sign In button
    Then I should see the Forgot Password button
    And I click the Forgot Password button
    Then I should be redirected to the Password Help Page
```

---

## Step 6: Print and Offer to Chain

Print the full feature file content.

Then print:
```
✅ Feature file written: features/<region>/<feature-area>/<TC-ID>.feature

Steps mapped from BrowserStack:
  1. <original step text> → <gherkin line>
  2. <original step text> → <gherkin line>
  ...

Run forge:build-playwright-tests to generate the Playwright spec now? [yes/no]
```

If yes → immediately invoke `forge:build-playwright-tests <feature-area> <TC-ID>`.

---

## Hard Rules

| Rule | Detail |
|---|---|
| **No project ID needed** | Use global API endpoint — works across all 160+ BrowserStack projects |
| **Never hardcode credentials** | Always read from the shell environment (shell profile, CI secrets, or `.env`) |
| **Never write to tests/** | This skill only writes `.feature` files |
| **Strip all HTML** | BrowserStack step text contains HTML — always clean it |
| **Preserve selector hints** | If a step contains a quoted selector, keep it inline |
| **Always print the feature file** | Show the user what was generated before chaining |
| **One feature file per TC ID** | Never merge multiple TCs into one file |
| **Feature area = folder name** | Mirrors BrowserStack folder structure, not region |
