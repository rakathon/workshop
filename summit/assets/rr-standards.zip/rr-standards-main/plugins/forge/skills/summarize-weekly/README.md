# forge:summarize-weekly

Generate or update weekly summary documents from meeting transcripts and git history.

Standalone skill — reads `.vtt`, `.txt`, and `.md` files directly. To pre-process raw recordings first, run `forge:transcripts-import`.

## Usage

```
/forge:summarize-weekly
```
