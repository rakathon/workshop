---
name: forge:summarize-weekly
description: Generate or update weekly summary documents for any project. Detects project name and paths automatically. Fills in missing weeks from meeting transcripts and git history. Standalone skill — does not require forge:report. Use when weekly summaries are missing, the current week needs updating, or before running forge:report. Trigger on: "generate weekly summary", "summarize this week", "update weekly summary", "create weekly update", "fill in missing weeks".
argument-hint: [--week YYYY-MM-DD]
---

# Weekly Summary Generator

Generate or update weekly summary documents for the current project. Automatically detects project name and paths from the repository, fills in any missing weeks, then updates the current week if needed.

**Note:** This skill runs standalone. To pre-process raw `.vtt`/`.txt` recordings into `.md` transcripts first, run `forge:transcripts-import`. This skill reads `.vtt`, `.txt`, and `.md` files directly.

## Week Definition

- **Start**: Monday at 12:01 AM
- **End**: Sunday at 11:59 PM
- The command can be run multiple times throughout a week to keep the summary up-to-date
- Always reads existing summary documents before updating (to preserve manual edits)

## Usage

- `/forge:summarize-weekly` (no arguments needed)
- Automatically finds and fills in missing weeks
- Then updates current week if there are new changes

## Instructions

### C0. Resolve Effort Context (runs first)

Determine which effort's meetings directory to use.

**C0.1 — Check branch name:**
```bash
git branch --show-current
```
If it matches `effort/<id>`, set `EFFORT_ID = <id>`.

**C0.2 — Scan effort state files (if no branch match):**
Scan `.forge/efforts/*/.state.json` for efforts where `currentPhase` is not `"closed"`:
- Exactly one found → use it as `EFFORT_ID`
- Multiple found → prompt: "Multiple active efforts found: <list>. Which effort should this summary cover?" Wait for selection.
- None found → proceed without effort context

**C0.3 — Set meetings directory:**
- If `EFFORT_ID` is set: `MEETINGS_DIR = .forge/efforts/<EFFORT_ID>/meetings/`
- Otherwise: `MEETINGS_DIR = meetings/` at the repository root

Report the resolved path to the user as part of project context output.

**C0.4 — Handle absent or empty meetings directory:**
If `MEETINGS_DIR` does not exist or contains no `.vtt`, `.txt`, or `.md` files:
> "No meeting transcripts found in `<MEETINGS_DIR>`. Proceeding using git history, git notes, and available documents."

Continue — do not stop.

---

### 1. Detect Project Context

Before doing anything else, discover the project name and output path from the repository itself. Do not hardcode either.

#### Detect project name

In order of preference:
1. Read `CLAUDE.md` at the repo root — look for the first H1 heading or a "Project:" or "project name" line
2. Read `README.md` — use the first H1 heading (`# ...`)
3. Fall back to the repository directory name (basename of the current working directory)

Use the detected name as `{PROJECT_NAME}` in the summary template.

#### Detect the weekly updates directory

Weekly summaries are committed artifacts and live alongside the entity's other synthesized content — not inside the generated-reports tree. Resolve `UPDATES_DIR` using the same context chain as `report/SKILL.md` C0.5 Step 3:

1. **Active effort** — `UPDATES_DIR = .forge/efforts/<EFFORT_ID>/weekly/`
2. **Deployable** — `UPDATES_DIR = .forge/deployables/<deployable-id>/weekly/`
3. **Product** — `UPDATES_DIR = .forge/products/<product-id>/weekly/`
4. **Repo root fallback** — `UPDATES_DIR = weekly/` at the repository root

`UPDATES_DIR` is always a sibling of the entity's other artifact directories (`meetings/`, `spec/`, `requirements/`). Do not place weekly summaries inside `{MEETINGS_DIR}`, `reports/`, or any other location.

---

### 1. Identify All Weeks with Activity

1. **Collect all activity dates** from:
   - Meeting transcript files: Search recursively in `{MEETINGS_DIR}` for `.vtt`, `.txt`, and `.md` files and extract their dates
   - Git commit history: Use `git log --all --pretty=format:"%ad" --date=short` to get all commit dates

2. **Derive week boundaries** for each date found:
   - For each date, calculate the Monday (start) and Sunday (end) of that week using ISO-8601 week numbering in the local system timezone
   - **Week start**: Monday at 00:01 (12:01 AM) local time
   - **Week end**: Sunday at 23:59 (11:59 PM) local time
   - The `START_DATE` and `END_DATE` used in filenames must always be the Monday and Sunday of the respective week in `YYYY-MM-DD` format, regardless of when within the week the skill is invoked
   - Create a unique list of weeks (no duplicates)

3. **Include current week** in the list even if no activity yet

---

### 2. Find Missing Week Summaries

1. List all existing summary files in `{UPDATES_DIR}`
2. Expected filename format: `YYYY-MM-DD-YYYY-MM-DD-summary.md`
   - Example: `2026-02-10-2026-02-16-summary.md`
3. Compare the list of weeks with activity against existing summary files
4. Identify which weeks are **missing** summaries

---

### 3. Generate Summaries for Missing Weeks

For each missing week (in chronological order):

1. **Gather source information** for that specific week (see step 5 below)
2. **Generate the summary** using the template (see step 6 below)
3. **Save the file** to `{UPDATES_DIR}`
4. Report which week was created

---

### 4. Update Current Week (if it exists)

After handling missing weeks:

1. Check if the current week's summary file already exists
2. If it exists:
   - Read the existing file completely
   - Gather current information (meetings + git history)
   - Check if there's new information not already in the summary
   - If there are updates, merge them into the existing file
   - Add/update the "Last updated" timestamp
3. Report whether the current week was updated or if it was already current

---

### 5. Gather Source Information (for each week)

When generating or updating a summary for a specific week, collect information from these sources in priority order (highest first):

**Source priority: documentation > meeting transcripts > Slack > git history**

Use higher-priority sources as authoritative; use lower-priority sources to fill gaps, confirm status, and surface timely updates. When sources conflict, prefer the higher-priority one and use the timestamp of each item to resolve ambiguity.

#### A. Meeting Transcripts
- Search recursively in `{MEETINGS_DIR}` for `.vtt`, `.txt`, and `.md` files (raw recordings and cleaned-up transcripts)
- Include only files with dates that fall within the **specific week** being processed
- **VTT files (Zoom — speaker attribution):** Parse speaker names and timestamped dialogue directly. Extract meeting topics, key decisions, action items, technical discussions, and important context.
- **TXT files (Whisper — no speakers):** Organize by topic. Extract meeting topics, key decisions, action items, technical discussions, and important context.
- **MD files (pre-processed transcripts):** Read directly. Extract meeting topics, key decisions, action items, technical discussions, and important context.

#### B. Slack Archives
- Search for `.md` files under `messages/slack/` (relative to the repo root or effort dir)
- Structure: `messages/slack/<channel-id>/<YYYY_MM>/<YYYY_MM_DD>/YYYY_MM_DD.md` — channel IDs are opaque, scan all subdirectories
- Include only files whose date falls within the **specific week** being processed
- Extract: real-time status updates, blocker resolutions, informal decisions, follow-ups to open questions from meetings
- **Do not use Slack to contradict formal docs or meeting decisions** — use it to fill gaps and confirm status
- Apply language sanitization (Step F3 / language cleanup rules): remove expletives and harsh personal criticisms; preserve all technical content, blockers, and honest assessments

#### C. Git Commit History

1. Collect commits for the week:
   ```bash
   git log --since="YYYY-MM-DD 00:01" --until="YYYY-MM-DD 23:59" --pretty=format:"%H %h %s (%ad)" --date=short
   ```
   (Use full SHA `%H` for notes lookup, short SHA `%h` for display.)

2. For each commit SHA, attempt to read its git note:
   ```bash
   git notes show <full-SHA>
   ```
   - Non-zero exit code → silently skip; use the commit message alone.
   - Output is not valid JSON → silently skip; use the commit message alone.
   - Valid JSON present → extract any of the following fields that exist and are non-null:
     - `workId` — the effort or work item this commit belongs to
     - `taskId` — the specific task (e.g. `TASK-001`)
     - `wave` — implementation wave
     - `taskType` — annotation (`auto`, `tdd`, `checkpoint`, `manual`)
     - `requirements` — requirements addressed by this commit
   - Unknown fields in the JSON are ignored — do not assume a fixed schema.

3. Enrich the commit entry: if note fields were extracted, use them to place the commit in the correct summary category (Development Work when `taskId` is present, Key Decisions when `requirements` is present) and annotate with the work item context.

4. Include ALL commits (code, documentation, context changes, etc.)
   Note: Work on the repository itself counts as project work.

---

### 6. Analyze and Categorize

Organize information into categories:
- **Development Work**: Code changes, features, bug fixes
- **Documentation**: New or updated docs, meeting notes
- **Decisions**: Key decisions made during meetings or in commits
- **Investigations**: Research, analysis, or exploration completed
- **Process & Tooling**: Improvements to development workflow, automation, commands
- **Meetings**: Significant meetings and their outcomes

---

### 7. Generate or Update the Summary

Use the template below, substituting `{PROJECT_NAME}` with the detected project name.

**Content Rules:**
- Be very concise and brief (management-focused)
- Use bulleted lists with short items (≤20 words per item)
- Focus on WHAT was done and WHY it matters
- Include decisions, not just tasks
- Mention investigations and their conclusions
- Include meta-work (tooling, commands, process improvements)
- Avoid excessive technical detail
- Use present/past tense appropriately

**Top 10 Highlights Section:**
- Must appear immediately after the Summary section
- Contains exactly 10 bullet points (no more, no fewer)
- Each bullet is 20 words or less
- Select the most important, impactful, or largest updates from the week
- Prioritize: major decisions, breakthroughs, completed deliverables, critical meetings, key findings
- Should give executive-level snapshot of the week's most significant items
- Draw from all categories (development, decisions, meetings, investigations, etc.)

**Update Strategy (for existing files):**
- Preserve manual edits and existing structure
- Add new information without duplicating existing content
- Merge related items logically
- Maintain chronological ordering within sections
- Add a note at the bottom: `Last updated: [current date and time]`

---

## Summary Document Template

```markdown
# Weekly Update: [Month DD] - [Month DD], [YEAR]

**Week of**: [Start Date] to [End Date]
**Project**: {PROJECT_NAME}

---

## Summary

[2-3 sentence overview of the week's progress and key achievements]

---

## Top 10 Highlights

- [Most important/impactful update #1 - max 20 words]
- [Most important/impactful update #2 - max 20 words]
- [Most important/impactful update #3 - max 20 words]
- [Most important/impactful update #4 - max 20 words]
- [Most important/impactful update #5 - max 20 words]
- [Most important/impactful update #6 - max 20 words]
- [Most important/impactful update #7 - max 20 words]
- [Most important/impactful update #8 - max 20 words]
- [Most important/impactful update #9 - max 20 words]
- [Most important/impactful update #10 - max 20 words]

---

## Development Work

- [Brief description of feature/change implemented]
- [Bug fix or technical improvement]

## Documentation

- [New or updated documentation]
- [Meeting transcripts processed]

## Key Decisions

- [Important decision made and rationale]
- [Architectural or design choice]

## Meetings & Discussions

- **[Meeting Name]** ([Date]): [Key outcomes or decisions]

## Process & Tooling

- [Workflow improvements]
- [Custom commands or automation created]

## Investigations & Research

- [Investigation topic]: [Key findings or conclusions]

## Blockers & Risks

- [Any impediments or concerns identified]

## Next Week's Focus

- [Planned priority items for next week]

---

*Last updated: [YYYY-MM-DD HH:MM]*
```

---

## Output

After completing the process, report to the user:

1. **Project context detected**: project name
2. **Meetings directory**: `{MEETINGS_DIR}` (resolved path)
3. **Weekly summaries directory**: `{UPDATES_DIR}` (resolved path — sibling of effort/deployable/product artifact directories)
4. **Missing weeks handled**: list each week created, with date range and full file path
5. **Current week status**: updated (what was added), already current, or newly created
6. **Summary**: total number of weeks processed

All files saved to: `{UPDATES_DIR}/{START_DATE}-{END_DATE}-summary.md`
