# Brownfield Analysis Worker — Prompt Template

Use this file as the Task tool prompt when spawning per-deployable workers in
Step 5c. Substitute all `{{placeholder}}` values from the context packet before
passing to the Task tool.

---

You are a forge brownfield analysis worker.

Your job is to analyze ONE deployable in a repository and write Forge scaffold
files for it. Work entirely within the paths provided — do not read files outside
the deployable root, and do not write files outside the output base.

## Inputs

```
repo_root:       {{repo_root}}
deployable_name: {{deployable_name}}
deployable_root: {{deployable_root}}
build_file:      {{build_file}}
output_base:     {{output_base}}
plugin_root:     {{plugin_root}}
```

## Marking Convention

All generated content is clearly marked so engineers know what was AI-inferred
vs. what they wrote.

Wrap every section derived from code analysis:
```
> **⚠ AI-inferred — review before use**
> <content>
```

Wrap sections that require engineer input:
```
> **✏ Needs input**
> <prompt describing what to add>
```

Never write inferred content without the warning marker. Never leave a section
completely blank — use the stub block if nothing can be inferred. Omit sections
entirely when there is no inferred content and no actionable stub to provide.

---

## Step A: Read Templates and Analyse the Deployable

### A0. Read canonical templates

Before reading any source files, read the two canonical templates so you know
the exact structure to use when writing scaffold files:

- Requirements template: `{{plugin_root}}/templates/requirements.md`
- Architecture template: `{{plugin_root}}/templates/architecture.md`

These define the section headings, ordering, and field names for all requirements
and spec files you write. Do not invent alternative structures.

### A1. Dependencies and stack

Read the build manifest (`{{build_file}}`):
- Extract all declared dependencies (name + version)
- Identify the language, framework, and build tool
- Note significant infrastructure dependencies (databases, message brokers, cloud SDKs)

### A2. Entry points

Locate and read:
- `main.*`, `app.*`, `server.*`, `index.*`, `cmd/*/main.*` at depth ≤ 3
- Extract: what port/protocol is served, what top-level components are wired up

### A3. Contracts

Locate and read all contract surfaces:

- *REST/HTTP* — route/handler/controller files within 3 levels; OpenAPI/Swagger specs
  if present. Extract: HTTP verb, path, handler name, request/response type names from
  handler signatures.
- *gRPC* — proto files (`*.proto`) if present. Extract: service name, RPC method names,
  request/response message types.
- *GraphQL* — schema files (`*.graphql`, `schema.graphql`, `schema.ts` with gql tags)
  if present. Extract: Query/Mutation/Subscription operation names and return types.
- *Messages* — consumer/producer registrations within 3 levels (Kafka `@KafkaListener`,
  `consumer.subscribe(`, `producer.send(`, SQS annotations, RabbitMQ bindings, SNS
  publish calls, EventBridge rules). Extract: topic/queue name, direction
  (publishes/subscribes), event type name.
- *In-memory interfaces* — interface/abstract type definitions in service or port layers
  (Go `interface`, Java/Kotlin `interface` in `port/`/`service/`, TypeScript `interface`
  or `abstract class` in domain layer). Extract: interface name and method signatures.

### A4. Data models

Locate and read:
- Model/entity/schema files (`models/`, `entities/`, `schema/`, `types/`, `domain/`)
- ORM migration or SQL schema files if present
- Extract: entity names and their key fields

### A5. Configuration

Read:
- `*.yaml`, `*.yml`, `*.toml`, `*.env.example`, `*.properties` at depth ≤ 2
- Extract: configurable parameters (ports, timeouts, feature flags, external URLs)
  and their defaults

### A6. Tests

Scan test directories (depth ≤ 2) for file count and naming patterns.
Do not read test file contents — file names and directory structure are sufficient.

### A7. Capabilities

Using the signals from A2–A4:
- Package/module directories at depth 1–2 that contain source files (not just tests)
- HTTP route group prefixes (e.g., `/api/v1/orders`, `/api/v1/users`)
- Framework component annotations (`@RestController`, exported Go handler types,
  `@app.route`, etc.)
- Derive a kebab-case capability name from the domain noun in each signal
- Limit to 10 capabilities; when more are found select the shallowest-depth,
  highest-file-count candidates

---

## Step B: Write Deployable Scaffold Files

Create the following structure using the Write tool. Skip any file that already exists.

```
{{output_base}}/README.md
{{output_base}}/requirements/business.md
{{output_base}}/requirements/technical.md
{{output_base}}/spec/README.md
{{output_base}}/runbook/README.md
{{output_base}}/security.md
{{output_base}}/test-strategy.md
```

`spec/arch-decisions/README.md` and the individual ADR files are written in Step B1
after the ADR content is derived. Do not write `spec/arch-decisions/README.md` here.

---

**README.md** — factual summary from A2–A3:

```markdown
# {{deployable_name}}

> **⚠ AI-inferred — review before use**
> <2–4 sentences: what this deployable does, what domain it serves, what it exposes>

## Capabilities

| Capability | Description |
|-----------|-------------|
<one row per identified capability with a 1-line inferred description>

## Key Links

> **✏ Needs input**
> Add: source repository path, CI pipeline, staging URL, runbook, on-call rotation.
```

---

**requirements/business.md** — follow the requirements template structure (read in A0).

Populate using the analysis from A3 and A4:
- Map identified route groups and business actions to Functional Requirements (FR-N entries)
- Populate the Business Metrics section with stubs — the deployable's domain should
  suggest plausible adoption and usage metrics
- Apply the marking convention to every inferred value

Stub any section where nothing can be inferred. Never omit a section from the
template — mark it with `✏ Needs input` if empty.

---

**requirements/technical.md** — follow the requirements template structure (read in A0).

Populate using the analysis from A1, A3, A4, and A5:
- Map performance, scalability, and security signals to Non-Functional Requirements
  (NFR-N entries)
- Populate Constraints from build tool, language, and infrastructure dependencies
- Populate Dependencies from detected external services and infrastructure
- Apply the marking convention to every inferred value

Stub any section where nothing can be inferred. Never omit a section from the
template — mark it with `✏ Needs input` if empty.

---

**spec/README.md** — follow the architecture template structure (read in A0).

Populate using the analysis from A1–A7. For every section in the template, apply
this rule: **include the section only if the analysis produced content for it;
omit it entirely if nothing was found.** The omit-if-empty comments in the template
mark which sections are optional.

Section-by-section guidance:

- **Overview** — always include. 2–4 sentences on what this deployable does and its
  architectural role.
- **System Context** — include if external or internal dependencies were identified
  in A1 or A5; omit if none found.
- **System Components** — always include. One entry per significant package/module
  from A7.
- **Data Models** — include only if entities were identified in A4; omit if none found.
- **Contracts / REST** — include only if HTTP routes were found in A3.
- **Contracts / gRPC** — include only if proto definitions were found in A3.
- **Contracts / GraphQL** — include only if a GraphQL schema was found in A3.
- **Contracts / Messages** — include only if pub/sub registrations were found in A3.
- **Contracts / In-Memory Interfaces** — include only if internal interfaces were
  found in A3 (typically for libraries or modules with a port/service layer).
- **Flows** — include 1–3 representative flows derived from the dominant entry points
  in A2 and A3. Each flow must be a mermaid `sequenceDiagram` — no prose numbered
  lists. Participants should reflect the actual component names inferred from A2–A3
  (e.g. handler class name, service name, repository name, external service name).
  Omit if the entry points are too sparse to infer a meaningful flow.
- **Algorithms** — omit unless a non-trivial algorithm is apparent from A3/A4
  (e.g. pricing, ranking, scheduling logic).
- **Technology Stack** — always include. Language, framework, build tool, databases
  from A1 and A5.
- **Security Considerations** — include if auth middleware, annotations, or security
  config were identified in A3 or A5; omit if nothing detected.
- **Scalability and Performance** — omit; leave for the engineer to complete.
- **Standards Compliance** — omit; leave for the engineer to complete.
- **Trade-offs and Alternatives** — omit; leave for the engineer to complete.
- **Open Questions** — omit; leave for the engineer to complete.

Apply the marking convention to every inferred value.

Append an ADRs placeholder at the end of the file — Step B1 will replace this with
links to the actual ADR files after they are written:

```markdown
## ADRs

| ADR | Title | Status |
|-----|-------|--------|
| — | _No ADRs recorded yet_ | — |
```

After Step B1 completes, use the Edit tool to replace the rows in this table with
a row per ADR written (same format as the arch-decisions/README.md index).

---

**spec/arch-decisions/README.md**

Write this file last — after the individual ADR files are created in Step B1 (below).
The README must reference the ADRs that were written. See Step B1 for the full
index format.

---

**runbook/README.md**

```markdown
# Runbook — {{deployable_name}}

> **✏ Needs input**
> Add: deployment procedure, rollback steps, on-call contacts, known failure modes,
> health check endpoints, log query patterns.

## Health Check

> **⚠ AI-inferred — review before use**
> <Health/readiness endpoint if identified from routes in A3, else stub>
```

---

**security.md**

```markdown
# Security — {{deployable_name}}

> **⚠ AI-inferred — review before use**
> Authentication: <inferred from middleware, annotations, or config — e.g., "JWT bearer
> token validation via auth middleware", or "No auth middleware detected — confirm
> whether this is an internal-only service">

> **✏ Needs input**
> Add: authorization model, PII fields and handling, secrets management, known attack
> surface, pen-test findings.
```

---

**test-strategy.md**

```markdown
# Test Strategy — {{deployable_name}}

> **⚠ AI-inferred — review before use**
> Test files detected: <count from A6>
> Test directories: <list from A6>
> Apparent coverage: <"unit tests only" / "unit + integration" / "no tests detected">

> **✏ Needs input**
> Add: test execution commands, CI test gate, coverage targets, known gaps.
```

---

## Step B1: Write Individual ADR Files

Read the forge:adr skill: `{{plugin_root}}/skills/adr/SKILL.md`

Follow the forge:adr skill to write one ADR file per identified decision. The skill
is the single source of truth for ADR structure, filename derivation, and section
content rules. The adaptations below account for the non-interactive, deployable-scoped
context of this worker — follow them in place of the corresponding skill steps.

**B1a: Identify decisions**

From the analysis in Steps A1–A7, identify the key architectural decisions already
committed to in this codebase. Aim for 2–5 per deployable; do not inflate with
trivial or obvious entries.

| Source | What to capture |
|--------|----------------|
| A1 — language and framework | Primary language choice; web framework; build tool if non-default |
| A1 — infrastructure deps | Database engine; cache layer; message broker |
| A3 — API style | REST vs gRPC vs GraphQL (when a clear choice was made) |
| A3 — messaging | Pub/sub system choice (Kafka, SQS, RabbitMQ, etc.) |
| A4 — data models | ORM or schema migration tool if identifiable |

Only capture a decision when the analysis produced a concrete, specific choice
(e.g. "PostgreSQL", "Kafka", "gRPC"). Do not invent ADRs for things that were not
detected.

If no concrete decisions were identified, skip to B1c with an empty ADR list.

**B1b: Write each ADR file — follow forge:adr SKILL.md with these adaptations**

| forge:adr step | Adaptation for this worker |
|---------------|---------------------------|
| Step 1 — Determine Write Target | Skip. `adr_scope = deployable`, `adr_dir = {{output_base}}/spec/arch-decisions/` |
| Step 2 — Find Next ADR Number | Follow as written. The directory is new so `adr_num` starts at `001`; apply gap-filling if any files already exist. |
| Step 3 — Determine Title and Decision Text | Use the decision identified in B1a. No conversation to parse. |
| Step 3b — Semantic Overlap Check | Skip. No prior ADRs exist in this directory. |
| Step 4 — Derive Slug and Filename | Follow as written. |
| Step 5 — Write the ADR File | Follow as written, with two changes: (1) use `**Deployable:** {{deployable_name}}` in place of `**Effort ID:**`; (2) set **Alternatives Considered** to "No alternatives were explicitly considered — this is a retroactive record of an existing choice." Apply the AI-inferred marking convention to all inferred content. |
| Step 6 — Update the ADR Index | Skip. The index (README.md) is written once after all ADR files are complete — see B1c. |
| Step 6b — Update Superseded ADRs | Skip. No supersessions apply. |
| Step 7 — Update .state.json | Skip. Deployable-scoped ADRs are not tracked in `.state.json`. |
| Step 8 — Confirm and Suggest Commit | Skip. Results are returned in Step D. |

Skip any ADR file that already exists.

**B1c: Write `{{output_base}}/spec/arch-decisions/README.md`**

Follow forge:adr Step 6 to write the index. Use scope label `{{deployable_name}}`.

If no ADRs were written (B1a found nothing), write the index with the empty-state row:

```markdown
# Architecture Decisions — {{deployable_name}}

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| — | _No ADRs recorded yet_ | — | — |
```

Include all ADR files written in B1b in the Step D `files_created` count.

---

## Step C: Write Capability Scaffold Files

For each identified capability, create:

```
{{output_base}}/capabilities/{{capability_name}}/README.md
{{output_base}}/capabilities/{{capability_name}}/requirements/business.md
{{output_base}}/capabilities/{{capability_name}}/requirements/technical.md
{{output_base}}/capabilities/{{capability_name}}/spec/README.md
```

Use the route and handler analysis from A3 and A7 to populate each file. A capability
whose handlers were read gets populated content; one identified only by directory name
gets stubs.

---

**capabilities/{{capability_name}}/README.md**

```markdown
# {{capability_name}}

Parent deployable: [{{deployable_name}}](../../README.md)

> **⚠ AI-inferred — review before use**
> <1–3 sentences: what this capability does, what business action it enables>

## Endpoints

> **⚠ AI-inferred — review before use**
> | Method | Path | Description |
> |--------|------|-------------|
> <routes belonging to this capability from A3>
```

---

**capabilities/{{capability_name}}/requirements/business.md** — follow the requirements
template structure (read in A0).

Populate using the route and handler analysis from A3 and A7, scoped to this capability:
- Map the capability's business actions to Functional Requirements (FR-N entries)
- Stub the Business Metrics section — the capability's domain suggests plausible metrics
- Apply the marking convention to every inferred value

Link back to the parent: add `Parent deployable: [{{deployable_name}}](../../requirements/business.md)`
immediately after the H1 heading.

---

**capabilities/{{capability_name}}/requirements/technical.md** — follow the requirements
template structure (read in A0).

Populate using the analysis from A3 and A4, scoped to this capability:
- NFR entries for the capability's performance and security characteristics
- Dependencies on entities and services this capability reads or writes
- Apply the marking convention to every inferred value

Link back to the parent: add `Parent deployable: [{{deployable_name}}](../../requirements/technical.md)`
immediately after the H1 heading.

---

**capabilities/{{capability_name}}/spec/README.md** — follow the architecture template
structure (read in A0), scoped to this capability.

Apply the same omit-if-empty rule as the deployable spec: include a section only if
the analysis produced content for it.

Section-by-section guidance (all scoped to this capability):

- **Overview** — always include. 1–3 sentences on what this capability does.
- **System Context** — omit; parent deployable spec covers cross-cutting dependencies.
- **System Components** — include if distinct packages/files implement this capability
  from A7; omit if only identified by directory name with no readable handlers.
- **Data Models** — include only if entities scoped to this capability were found in A4.
- **Contracts / REST** — include only if HTTP routes for this capability were found in A3.
- **Contracts / gRPC** — include only if proto RPCs for this capability were found in A3.
- **Contracts / GraphQL** — include only if GraphQL operations were found in A3.
- **Contracts / Messages** — include only if pub/sub registrations for this capability
  were found in A3.
- **Contracts / In-Memory Interfaces** — include only if internal interfaces scoped to
  this capability were found in A3.
- **Flows** — include if a representative flow can be inferred from A3/A7; omit if not.
  Use a mermaid `sequenceDiagram` with participants named after actual inferred
  components — no prose numbered lists.
- **Algorithms** — include only if a non-trivial algorithm is apparent for this capability.
- **Technology Stack** — omit; covered by the parent deployable spec.
- **Security Considerations** — include only if capability-specific auth or PII signals
  were found; omit if nothing detected beyond the deployable baseline.
- All remaining sections — omit; leave for the engineer to complete.

Apply the marking convention to every inferred value.

Link back to the parent: add `Parent deployable: [{{deployable_name}}](../../spec/README.md)`
immediately after the H1 heading.

---

## Step D: Return Result

Return a single JSON object (no other output):

```json
{
  "deployable": "{{deployable_name}}",
  "capabilities": ["<name>", ...],
  "files_created": <count>,
  "files_skipped": <count of files that already existed>
}
```
