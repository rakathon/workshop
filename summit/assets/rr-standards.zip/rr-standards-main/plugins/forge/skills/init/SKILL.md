---
name: forge:init
description: > 
  Initialize a repository for the Forge AI-accelerated development framework. Sets up .forge/ directory structure, 
  infers and records the branch naming convention, writes CLAUDE.md AI navigation context, and optionally scaffolds 
  deployable documentation from existing source code. Use this skill whenever an engineer wants to set up Forge in a 
  repository, says things like "initialize Forge", "set up forge here", "I want to start using Forge in this repo", 
  "initialize this repo for Forge", or asks how to get Forge running. Also invoke when a repository has the Forge plugin
  installed but no .forge/ directory yet, For version upgrades on already-initialized repositories, use forge:update 
  instead.
agent-type: orchestrator
argument-hint: "[--legacy-repo]"
---

# forge:init

Sets up a repository for the Forge AI-accelerated development framework:
- Creates the `.forge/` directory structure
- Infers and records the branch naming convention in `.forge/branching.md`
- Writes `.forge/.gitignore` so the active-effort pointer is never committed
- Creates or refreshes the `CLAUDE.md` forge-managed section with AI navigation context
- Optionally scaffolds `.forge/deployables/` from existing source code (brownfield analysis)

---

## Preconditions

**PC-1: Forge plugin is installed**

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record: `plugin_root`.

If the manifest cannot be read, stop with:
> "The Forge plugin does not appear to be installed or the manifest is missing.
> Try reinstalling the plugin."

**PC-2: Not inside a .forge subdirectory**

If the current working directory contains `/.forge/efforts/` or `/.forge/deployables/`,
stop with:
> "forge:init must be run from the repository root."

**PC-3: No duplicate managed markers in CLAUDE.md**

If `CLAUDE.md` exists, run:

```bash
grep -c '<!-- forge:managed:start -->' CLAUDE.md 2>/dev/null || echo 0
```

If the count is greater than one, stop with:
> "CLAUDE.md already contains duplicate forge:managed markers. Inspect and repair
> CLAUDE.md manually before running forge:init."

---

## Step 1: Read Plugin Metadata

**1a. Read version from plugin.json**

Read `<plugin_root>/.claude-plugin/plugin.json` using the Read tool (using the
`plugin_root` resolved in PC-1). Extract the `"version"` field value.

If `version` is empty or not a semver string (e.g., `0.5.0`), stop with:
> "Error: could not read version from plugin.json — plugin.json may be malformed."

**1b. Derive cache path identifiers**

The cache path follows the structure:
`~/.claude/plugins/cache/<marketplace_dir>/<sha>/forge/.claude-plugin/plugin.json`

From `plugin_root`, derive:

```
sha             = basename of plugin_root's parent directory
marketplace_dir = basename of the directory two levels above plugin_root
```

These identifiers are used in the Step 8 summary and passed to worker sub-agents that
need the absolute `plugin_root` path.

Record: `version`, `sha`, `marketplace_dir`.

---

## Step 2: Detect Initialization Mode

```bash
[ -d ".forge" ] && echo "exists" || echo "absent"
```

- **absent** → `mode = create`
- **exists** → read `.forge/version` and extract `active_version`. Compare to `version`
  from Step 1:
  - **Same version** → `mode = merge`. Print: "Existing .forge/ detected — running in merge mode (same version)"
  - **Different version** → `mode = upgrade`. Print the version mismatch and stop:
    > "forge:init detected a version change (initialized with vX.Y.Z, plugin is now
    > vA.B.C). Run `forge:update` to apply migrations and refresh CLAUDE.md."
    Do not proceed further. `forge:update` owns version upgrades — duplicating that
    logic here would create divergence.

In merge mode (same version), file writes skip files that already exist. Steps 5,
5a, 5b, 6, 6b, and 7 all apply — CLAUDE.md is refreshed in-place.

---

## Step 3: Determine Legacy Mode

Set `is_legacy=true` if `--legacy-repo` was passed as an argument, otherwise
`is_legacy=false`. Do not prompt the engineer.

Record: `is_legacy`.

---

## Step 3b: Brownfield Repository Analysis Offer

**Applies only when all of the following are true:**
- create mode (`.forge/` did not exist)
- `is_legacy=false`

Detect whether existing source code is present in the repository:

```bash
has_source=$(find . -maxdepth 4 \
  -not -path "./.git/*" \
  -not -path "./node_modules/*" \
  \( -name "go.mod" -o -name "pom.xml" -o -name "build.gradle" \
     -o -name "build.gradle.kts" -o -name "package.json" \
     -o -name "setup.py" -o -name "pyproject.toml" \
     -o -name "Cargo.toml" -o -name "Dockerfile" \
     -o -name "*.go" -o -name "*.java" -o -name "*.kt" \
     -o -name "*.py" -o -name "*.ts" -o -name "*.swift" \) \
  2>/dev/null | grep -v "node_modules" | head -1)
```

If `has_source` is empty, skip this step entirely — this is a greenfield repository.

If `has_source` is non-empty, present the following prompt and wait for the engineer's
response:

```
This appears to be a brownfield repository with existing source code.

Forge can analyze this repository to identify its deployables and capabilities,
then generate initial .forge/deployables/ scaffolding (requirements stubs, spec
outlines) based on what it finds. This gives your team a head start on the
documentation and avoids a blank-slate discovery session later.

You can skip this and scaffold deployables manually later using forge:effort.

  y  Analyze now and scaffold .forge/deployables/
  n  Skip — initialize without analysis [default]

Enter y/n [n]:
```

Map to `run_brownfield_analysis`:
- `y` or `Y` → `run_brownfield_analysis=true`
- anything else → `run_brownfield_analysis=false`

Do not re-prompt regardless of input — the default (`n`) is unambiguous.

Record: `run_brownfield_analysis`.

---

## Step 4: Determine forge_min_version

If `.claude-plugin/marketplace.json` exists, read the pinned version from it:

```bash
if [ -f ".claude-plugin/marketplace.json" ]; then
  pinned_ref=$(python3 -c "import json,sys; d=json.load(open('.claude-plugin/marketplace.json')); print(d.get('ref',''))" 2>/dev/null)
  forge_min_version="${pinned_ref#v}"   # strip leading "v"
else
  forge_min_version=""   # unpinned repo — no minimum version enforced
fi
```

Record: `forge_min_version`.

---

## Step 5: Create .forge/ Directory Structure

Read each template using a path relative to this skill's directory and write to the
destination. Use the Read tool to read, the Write tool to write — not Bash.

| Destination | Template source |
|-------------|-----------------|
| `.forge/README.md` | `<plugin_root>/templates/forge/README.md` |

For each file:
- File does not exist → write from template. Record: **created**
- File exists (merge mode) → skip. Record: **unchanged**

Subdirectory READMEs (efforts, deployables, products, spec) are created on demand
by the skills that need them — do not pre-create them here.

---

## Step 5a: Infer and Create `.forge/branching.md`

**Skip this step in merge mode if `.forge/branching.md` already exists.**

Read `<plugin_root>/skills/init/references/branching-templates.md` now. It contains
the full detection procedure (5a.1–5a.4: RR pipeline grep, git history inference,
CI filter extraction, priority order, and the four proposal prompts) and the
per-case file templates for 5a.5 (Cases A–E). Follow that file end-to-end.

Write the resulting `.forge/branching.md` using the Write tool. Record: **created**

---

## Step 5b: Write .forge/compliance (legacy repositories only)

**Only executes when `is_legacy=true` (create mode only).**

Write `.forge/compliance` with the following content:

```
coding_standards=exempt
reason=Legacy repository — initialized with forge:init
```

- File does not exist → write. Record: **created**

This file causes `inject-generation-standards.sh` to skip language guide injection
before code generation. Version enforcement and plugin drift detection are unaffected.

---

## Step 5c: Brownfield Deployable Scaffolding

**Only executes when `run_brownfield_analysis=true` (set in Step 3b).**

This step runs as an **orchestrator/worker split** (ADR-015). The orchestrator (this
skill, running in the engineer's session) handles deployable discovery and engineer
confirmation. It then spawns one isolated worker sub-agent per confirmed deployable
to perform capability analysis and file creation. Workers run concurrently so that
large monorepos with many deployables are not processed serially.

---

### Phase 1 [Orchestrator]: Identify Deployables

Read `<plugin_root>/skills/init/references/brownfield-discovery.md` for the full
discovery procedure (build file scan, Dockerfile scan, mono-repo heuristic, name
normalization, and the engineer confirmation prompt).

Use Bash and Glob tools only in the orchestrator — do not read source file contents.
Record the confirmed deployable list as: `[{name, root_dir, build_file}, ...]`.

---

### Phase 2 [Orchestrator → Workers]: Spawn Per-Deployable Workers

For each confirmed deployable, assemble a context packet and spawn one worker
sub-agent via the Task tool. Spawn all workers concurrently — do not wait for one
to finish before starting the next.

**Context packet per worker:**

```
repo_root:       <absolute path of the repository root>
deployable_name: <kebab-case name>
deployable_root: <absolute path of the deployable's root directory>
build_file:      <absolute path of the detected build manifest, or empty>
output_base:     <repo_root>/.forge/deployables/<deployable_name>
plugin_root:     <plugin_root>
```

**Worker prompt template:** Read `<plugin_root>/skills/init/references/brownfield-worker-prompt.md` now.
Substitute all `{{placeholder}}` values from the context packet into the template,
then pass the full rendered text as the Task tool prompt for each worker.

---

### Phase 3 [Orchestrator]: Collect Results

Wait for all workers to complete. Collect their JSON result objects.

Aggregate:
- `total_capabilities` — sum of `capabilities` array lengths across all workers
- `total_files_created` — sum of `files_created` across all workers
- `total_files_skipped` — sum of `files_skipped` across all workers

If any worker returns an error or non-JSON output, record that deployable as failed
and continue — do not abort the entire scaffolding run. Failed deployables are listed
in the Step 8 summary under a `Failed (manual scaffolding needed):` section.

Record each created file in the Step 8 summary under **Created**. Do not enumerate
individual files from workers — use the aggregate counts instead.

---

## Step 6: Write .forge/version

Obtain the current UTC timestamp:

```bash
initialized_at=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
```

Write the file with all fields substituted:

```
forge_min_version=<forge_min_version>
active_version=<version>
initialized_with=<version>
initialized_at=<initialized_at>
last_migrated_with=
last_migrated_at=
```

- `.forge/version` does not exist → write. Record: **created**
- `.forge/version` exists (merge mode, same version) → do not overwrite. Record: **unchanged**

---

## Step 6b: Write .forge/.gitignore

Ensure `.forge/.gitignore` exists and contains the `EFFORT` entry. Use the Read and
Write tools — not Bash.

Check whether the file exists by attempting to read `.forge/.gitignore`:

- **File does not exist** — use the Write tool to create `.forge/.gitignore` with
  `EFFORT` as the sole line. Record: **created**
- **File exists and already contains `EFFORT` as a line** — make no changes.
  Record: **unchanged**
- **File exists but does not contain `EFFORT`** — use the Edit tool to append `EFFORT`
  on a new line at the end of the file. Preserve all existing lines. Record: **updated**

---

## Step 7: Write CLAUDE.md

Template path: `<plugin_root>/templates/claude-md.md`

Read the template and substitute:
- `{{forge_version}}` → `v<version>`

**Create mode** (CLAUDE.md does not exist): write the rendered section as the entire
file. Record: **created**

**Merge mode, same version** (CLAUDE.md exists): skip — the managed section already
reflects the current version. Record: **unchanged**

**Create mode where CLAUDE.md exists but `.forge/` did not** (fresh `.forge/`, existing
project-level CLAUDE.md): treat as create — Forge has not added its section yet.
1. If `<!-- forge:managed:start -->` found: replace everything between the markers
   (inclusive) with the rendered section. Preserve all content outside. Use the Edit
   tool — not sed or awk. Record: **updated**
2. If marker not found: append the rendered section at the **end of the file**.
   - Use the Read tool to read the current file content.
   - Use the Edit tool with `old_string` set to the **last line** of the existing
     file and `new_string` set to that same last line, followed by two newlines and
     the rendered section. This ensures the insertion point is unambiguous and the
     content lands after all existing content — never inside a list or mid-paragraph.
   Record: **updated** (appended)

---

## Step 8: Print Summary

```
forge:init complete — forge v<version>

<if is_legacy=true:>
Legacy mode:     Coding standards injection disabled (.forge/compliance)
</if>
<if run_brownfield_analysis=true:>
Brownfield:      <N> deployable(s) scaffolded, <M> capabilities identified
                 <total_files_created> files created, <total_files_skipped> skipped
  <if any workers failed:>
  Failed (manual scaffolding needed):
    <list of deployable names whose workers returned errors>
  </if>
</if>

  Created:
    <files created, one per line — includes .forge/.gitignore if newly created>

  Updated:
    <files updated, one per line — includes .forge/.gitignore if EFFORT entry was appended>

  Unchanged:
    <files skipped (already existed), one per line — includes .forge/.gitignore if EFFORT already present; omit section if none>

Plugin: <marketplace_dir>/forge/<first 12 chars of sha>...
Pin: <forge_min_version if non-empty | unpinned>

Commit these files so your team gets the workspace structure:
  git add .forge/ CLAUDE.md
  git commit -m "chore: initialize forge v<version>"

If `.claude-plugin/marketplace.json` exists (forge:pin was run before forge:init),
include it in the commit so the team gets the version pin:
  git add .claude-plugin/ .forge/ CLAUDE.md
  git commit -m "chore: initialize forge v<version>"
```

