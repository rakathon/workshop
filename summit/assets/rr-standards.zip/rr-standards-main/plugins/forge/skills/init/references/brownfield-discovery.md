# Brownfield Deployable Discovery — Phase 1 Detail

Used by Step 5c Phase 1 of forge:init. The orchestrator runs this discovery logic
before spawning per-deployable workers.

---

## Identifying Candidate Deployables

**Build file scan** — each build manifest at depth ≤ 3 is a candidate deployable root:

```bash
find . -maxdepth 3 \
  -not -path "./.git/*" -not -path "./node_modules/*" \
  \( -name "go.mod" -o -name "pom.xml" -o -name "build.gradle" \
     -o -name "build.gradle.kts" -o -name "package.json" \
     -o -name "setup.py" -o -name "pyproject.toml" -o -name "Cargo.toml" \) \
  2>/dev/null
```

**Dockerfile scan** — a `Dockerfile` without a sibling build manifest also indicates
a deployable root.

**Mono-repo heuristic** — if all manifests are at depth 1 (repo root) and there are
multiple top-level directories containing source files, treat each top-level source
directory as a separate deployable.

---

## Deriving Deployable Names

For each candidate root, derive a deployable name:
- From the module/artifact name in the build file (e.g., `module` in `go.mod`,
  `artifactId` in `pom.xml`, `name` in `package.json`) by reading only that file
- Fall back to the directory name when no explicit name is declared

If only one deployable is identified and its root is the repository root, use the
repository directory name (`basename $(pwd)`) as the deployable name.

Normalize all names to `kebab-case` (lowercase; spaces, underscores, and slashes
replaced with hyphens).

---

## Engineer Confirmation Prompt

Present findings before creating any files:

```
Found <N> deployable(s):

  <index>. <name>  (<root-dir>)
     Build: <build-file>

  ...

  a  Accept these deployables and continue
  e  Edit the list before continuing
  s  Skip deployable scaffolding

Enter a/e/s [a]:
```

If the engineer enters `e`, accept their revised list (corrected names, removed
entries). If `s`, set `run_brownfield_analysis=false` and skip the rest of Step 5c.

Record the confirmed deployable list as: `[{name, root_dir, build_file}, ...]`.
