# forge:init

Initializes a repository for the Forge AI-accelerated development framework.

## What it does

- Creates the `.forge/` directory structure with `README.md` and `version` metadata
- Detects and records the repository's branch naming convention (from CI/CD pipeline,
  git history, or engineer input) in `.forge/branching.md`
- Creates or refreshes the `CLAUDE.md` forge-managed section with standards navigation
  instructions for AI agents
- Writes `.forge/.gitignore` to prevent the active-effort pointer from being committed
- Optionally scaffolds `.forge/deployables/` from existing source code (brownfield analysis)

`forge:init` does **not** handle version pinning — that is `forge:pin`'s responsibility.
Run `forge:pin` before or after `forge:init` (order does not matter).

## Usage

```
forge:init [--legacy-repo]
```

`--legacy-repo` — disables coding standards injection for repositories with existing code
that does not yet meet RR standards. Records the exemption in `.forge/compliance`.

## Relationship to forge:pin

`forge:init` and `forge:pin` are independent and order-independent:

| Goal | Commands |
|------|----------|
| Unpinned setup | `forge:init` only |
| Pinned setup, any order | `forge:pin` then `forge:init`, or `forge:init` then `forge:pin` |
| Upgrade an existing repo | `forge:pin --version X` then `forge:update` |

When `forge:pin` is run before `forge:init`, the commit reminder in the `forge:init`
summary automatically includes `.claude-plugin/` so the pin is shared with the team.

## Idempotency

Safe to re-run on an already-initialized repository. In merge mode, existing files
are skipped and only the CLAUDE.md managed section is refreshed. The summary lists
every file as Created, Updated, or Unchanged.

## Prerequisites

- Forge plugin installed in the current Claude Code session
  (`/plugin install forge@rr-standards` or `forge:pin` followed by plugin install)
- Python 3 installed (used for JSON parsing)
- Run from the repository root
