# Branching Convention — Detection and Templates

Full procedure for Step 5a of forge:init. Covers detection (5a.1–5a.4) and the
per-case file templates to write in 5a.5.

---

## Detection Procedure (5a.1–5a.4)

### 5a.1 — Detect RR standard CI/CD pipeline

```bash
grep -rl "rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml" .github/workflows/ 2>/dev/null | head -1
```

Output → `rr_pipeline_detected=true`. No output → `rr_pipeline_detected=false`.

### 5a.2 — Infer from git history

```bash
# Merge commit messages often embed branch names
git log --merges --pretty=format:"%s" -200 \
  | grep -oE "[a-zA-Z0-9_-]+/[a-zA-Z0-9_/.-]+" \
  | grep -vE "^(origin|HEAD)/" | sort | uniq -c | sort -rn | head -30

# Remote tracking branches
git branch -r --format="%(refname:short)" 2>/dev/null | sed 's|^origin/||' \
  | grep -vE "^(main|master|HEAD|develop)$"
```

Apply inference rules (≥ 60% match, minimum 5 samples):

| Signal | Inferred convention |
|--------|---------------------|
| Majority match `[A-Z]+-\d+/.*` | Jira-prefixed: `PROJ-123/description` |
| Majority match `[A-Z]+-\d+-.*` | Jira-hyphenated: `PROJ-123-description` |
| Majority match `feat/.*` or consistent commit-type prefixes | Conventional/GitHub-Flow |
| Majority match a consistent custom prefix | That custom convention |
| < 5 samples or no dominant pattern | No inference — fall through to 5a.3 |

### 5a.3 — Detect branch filters in CI workflow files

Only applies when `rr_pipeline_detected=false` and no confident history inference.

Use the Read tool — try `.github/workflows/ci.yaml` first, then `.github/workflows/ci.yml`.
If neither exists, set `ci_branches_detected=false` and skip.

Extract branch patterns from `on.push.branches` or `on.pull_request.branches`. Strip
`main`, `master`, `develop`, `HEAD`, `dependabot/**`. Extract the prefix before `/**` or `/*`.

**Confidence rule:** ≥ 2 distinct non-infrastructure prefixes from an include list →
`ci_branches_detected=true`. `branches-ignore` only → `ci_branches_detected=false`.

Priority order:
```
RR pipeline (5a.1) > history inference (5a.2) > CI filters (5a.3) > RR default
```

### 5a.4 — Present proposal for confirmation

**RR pipeline detected:**
```
Detected Rakuten Rewards standard CI/CD pipeline (helm-upgrade-nonprod).

Proposed default branch convention: <type>/<description>
  where <type> is one of: feat, feature, release, hotfix, bugfix
  Examples: feat/add-user-preferences, bugfix/auth-timeout, hotfix/payment-crash

Use this convention? [Y/n]
Or describe your convention in plain English or as a regex:
```

**Convention inferred from history:**
```
Detected branch naming convention: <inferred-pattern>
  (based on <N> of <total> recent branches, e.g. <example-1>, <example-2>)

Use this convention for Forge effort branches? [Y/n]
Or describe your convention in plain English or as a regex:
```

**CI branch filters detected:**
```
Detected branch filters in .github/workflows/ci.yaml:
  Allowed prefixes: <ci_branch_prefixes joined by ", ">
  (e.g. <example-1>, <example-2>)

Use this as the branch naming convention? [Y/n]
Or describe your convention in plain English or as a regex:
```

**No detection at all:**
```
Could not detect an existing branch naming convention.

Forge default (Rakuten Rewards standard): <type>/<description>
  where <type> is one of: feat, feature, release, hotfix, bugfix
  Examples: feat/add-user-preferences, bugfix/auth-timeout, hotfix/payment-crash

Use this convention? [Y/n]
Or describe your convention in plain English or as a regex:
```

Accept the engineer's response:
- `Y` / `y` / empty (Enter) → confirmed proposal, write the file (5a.5)
- `n` + plain English description → derive regex and prose, confirm before writing
- `n` + regex string → use verbatim as `branch_regex`, ask for a prose description

---

## File Templates (5a.5)

Use these verbatim templates when writing `.forge/branching.md`.
Do not add, remove, or rename prefixes beyond what each case specifies.

---

## Case A — RR pipeline convention confirmed
## Case C — No convention detected (Forge default)

Both cases write this file verbatim:

```markdown
---
branch_regex: "^(feat|feature|release|hotfix|bugfix)/[a-zA-Z0-9][a-zA-Z0-9-]*$"
---

# Branch Naming Convention

This repository uses the Rakuten Rewards standard CI/CD pipeline
(`rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml`).

Branch names must use one of the supported prefixes followed by a short lowercase
hyphenated description of the work.

Pattern: `<type>/<description>`

Allowed prefixes:
- `feat/`    — new feature (short form)
- `feature/` — new feature (long form)
- `release/` — release preparation
- `hotfix/`  — urgent production fix
- `bugfix/`  — bug fix

The description should be a short kebab-case summary, optionally prefixed with a
Jira ticket ID.

Examples:
- `feat/add-user-preferences`
- `feature/REWD-1234-add-gift-card-endpoint`
- `bugfix/null-pointer-payment`
- `hotfix/auth-timeout`
- `release/2.1.0`

When creating a branch for a Forge effort, use the effort title to derive the
description slug (lowercase, spaces to hyphens, strip special characters) and
choose the prefix that best matches the nature of the work.
```

---

## Case B — Convention inferred from git history

Write the file with:
- `branch_regex`: a regex that matches exactly the inferred pattern (no extra prefixes)
- Prose body: describes the inferred convention with examples drawn from the actual
  history samples

Do not add prefixes that were not present in the inferred pattern.

---

## Case D — CI branch filters detected

Build the regex from the detected `ci_branch_prefixes` only — no extras:

```
branch_regex: "^(<prefix1>|<prefix2>|...)/[a-zA-Z0-9][a-zA-Z0-9-]*$"
```

Write the prose body listing each detected prefix with a one-line description.
Reference the CI file that the filters were read from. Example (with prefixes
`feat`, `feature`, `bugfix`, `hotfix`, `release`):

```markdown
---
branch_regex: "^(feat|feature|bugfix|hotfix|release)/[a-zA-Z0-9][a-zA-Z0-9-]*$"
---

# Branch Naming Convention

Branch filters detected from `.github/workflows/ci.yaml`.

Branch names must use one of the CI-allowed prefixes followed by a short lowercase
hyphenated description of the work.

Pattern: `<type>/<description>`

Allowed prefixes:
- `feat/`    — new feature (short form)
- `feature/` — new feature (long form)
- `bugfix/`  — bug fix
- `hotfix/`  — urgent production fix
- `release/` — release preparation

Examples: `feat/add-user-preferences`, `bugfix/null-pointer-payment`

When creating a branch for a Forge effort, choose the prefix that matches the
nature of the work and derive the description slug from the effort title.
```

Do not add prefixes not present in the CI filters.

---

## Case E — Engineer provided custom input

- **Regex provided directly:** use it verbatim as `branch_regex`. Write a prose body
  that accurately describes the regex, with examples. Do not invent prefixes not
  present in the regex.
- **Plain English description:** derive the narrowest regex that matches only what was
  described. Confirm the regex with the engineer before writing. Write a prose body
  matching the confirmed description.
