# forge:update

Migrates a repository's committed Forge configuration to match the currently active
plugin version.

## What it does

`forge:update` is a **project configuration migration** — it does not update the
plugin itself. To update the plugin, run `/plugin install forge@forge-local` (pinned
repos) or the equivalent for your installation.

After updating the plugin, run `forge:update` to migrate the project's committed
configuration to match:

- Refreshes the `CLAUDE.md` forge-managed section with the new plugin template
- Creates any `.forge/` directories introduced in the new version
- Renames or restructures `.forge/` directories when the new version requires it
- Migrates `.state.json` schema fields when the work-item schema changes between versions
- Updates `.forge/version` with the new active version

All migrations are atomic — if any step fails, all changes are rolled back.

## Usage

```
forge:update [--yes]
```

| Flag | Description | Default |
|------|-------------|---------|
| `--yes` | Skip confirmation (MINOR/PATCH only) | false |

The target version is always derived from the project's pin
(`.claude-plugin/marketplace.json`) or, for unpinned repos, from the currently
installed plugin. To change the target version, run `forge:pin --version <semver>`
first, then run `forge:update`.

## MAJOR vs MINOR/PATCH migrations

**MINOR/PATCH** — new skills, updated standards, directory additions. Can be applied
with `--yes` to skip confirmation.

**MAJOR** — breaking changes to `.state.json` schema, hook behavior, or `.forge/`
structure. Always requires explicit confirmation. Blocked if any work item is in
active implementation — complete or pause active work before migrating.

## Migration manifests

Structural changes between versions (directory creation, file renames, schema
migrations) are declared in migration manifest files bundled with the plugin at
`<plugin-root>/migrations/<from>-to-<to>.json`. `forge:update` discovers all
applicable manifests for the version range being crossed and applies them in sequence.

If no manifest exists for a version transition, no structural changes are needed —
`forge:update` still runs its always-required operation (CLAUDE.md refresh).

See `plugins/forge/migrations/README.md` for the manifest format and supported
operation types.

## Re-run safety

If `forge:update` is interrupted mid-migration, re-running it is safe. Individual
operations are idempotent — already-applied steps are skipped rather than re-applied.
The version record in `.forge/version` is the last thing updated, so an incomplete
migration is always detectable and recoverable by re-running the skill.

## Examples

```
forge:update          # migrate to the pinned (or installed) version
forge:update --yes    # MINOR/PATCH: skip confirmation
```
