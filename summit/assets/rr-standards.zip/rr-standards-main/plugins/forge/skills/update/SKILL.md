---
name: forge:update
description: Migrate a repository's Forge configuration and directory structure to match the currently pinned (or installed) Forge version. Use this skill when an engineer wants to apply a version upgrade after running forge:pin, says things like "update forge", "apply forge migration", "migrate forge", "forge is showing a version warning", or "forge:update". Also invoke when the version enforcement hook reports that the repository configuration is behind the active version.
argument-hint: "[--yes]"
---

# forge:update

Migrates this repository's committed configuration — directory structure, CLAUDE.md,
and `.state.json` schemas — to be compatible with the currently active Forge version.

The target version is read from the project pin (`.claude-plugin/marketplace.json`)
if present, or from the highest version installed in the plugin cache. If the target
is older than the current `active_version`, stop and explain why (downgrade not supported).

## Arguments

| Flag | Description | Default |
|------|-------------|---------|
| `--yes` | Skip confirmation for MINOR/PATCH migrations | false |

---

## Preconditions

**PC-1: Repository is initialized**

If `.forge/version` does not exist, stop with:
> "This repository is not initialized. Run forge:init first."

Exit cleanly (success, not an error).

**PC-2: Forge plugin is installed**

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record: `plugin_root`.

If the manifest cannot be read, stop with:
> "The Forge plugin does not appear to be installed or the manifest is missing.
> Try reinstalling the plugin."

---

## Step 1: Read Current State

Read the current version from `.forge/version`:

```bash
current_version=$(grep "^active_version=" .forge/version | cut -d= -f2)
```

If `active_version` is empty or the field is missing, stop with:
> "Cannot read active_version from .forge/version. The file may be malformed.
> Inspect it manually or re-run forge:init."

Record: `current_version`.

---

## Step 2: Resolve Target Version

**If `.claude-plugin/marketplace.json` exists (pinned repo):**

```bash
target_ref=$(sed -n 's/.*"ref": *"\([^"]*\)".*/\1/p' .claude-plugin/marketplace.json)
target_version="${target_ref#v}"
```

The target is the pinned version. If `target_ref` is empty or the file is malformed,
stop with:
> "Cannot read pinned version from .claude-plugin/marketplace.json. Run forge:pin
> to re-establish the pin."

**If `.claude-plugin/marketplace.json` does not exist (unpinned repo):**

The target version is the running plugin version. Read it from the already-resolved
`plugin_root` (established in PC-2):

```bash
target_version=$(grep '"version"' "<plugin_root>/.claude-plugin/plugin.json" | sed 's/.*"version": *"\([^"]*\)".*/\1/')
```

The target is the currently running plugin version.

**Check for downgrade and no-op:**

Substitute `<current_version>` and `<target_version>` with the values from Steps 1–2:

```bash
# Extract major versions for comparison and classification
current_major=$(echo "<current_version>" | cut -d. -f1)
target_major=$(echo "<target_version>" | cut -d. -f1)

# Semver less-than: returns 0 if $1 < $2
version_lt() {
  local a b
  IFS='.' read -ra v1 <<< "$1"
  IFS='.' read -ra v2 <<< "$2"
  for i in 0 1 2; do
    a="${v1[$i]:-0}"; b="${v2[$i]:-0}"
    [ "$a" -lt "$b" ] && return 0
    [ "$a" -gt "$b" ] && return 1
  done
  return 1
}

if version_lt "<target_version>" "<current_version>"; then
  echo "DOWNGRADE"
elif [ "<target_version>" = "<current_version>" ]; then
  echo "NOOP"
fi
```

If output is `DOWNGRADE`, stop with:
> "Downgrade from v<current_version> to v<target_version> is not supported.
> To move to an older version, re-initialize the repository from scratch."

If output is `NOOP`, print:
> "forge:update: already at v<target_version>. Nothing to do."

Stop. Exit cleanly — this is a successful no-op, not an error.

If the output is neither `DOWNGRADE` nor `NOOP` (i.e., empty), the versions differ and a migration is needed — continue to Step 3.

Record: `target_version`, `target_ref` (or `"v<target_version>"` for unpinned repos).

---

## Step 3: Verify Plugin Version

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record: `plugin_root`.

After recording `plugin_root`, verify the installed version matches the target version:

```bash
cached_version=$(grep '"version"' "<plugin_root>/.claude-plugin/plugin.json" | sed 's/.*"version": *"\([^"]*\)".*/\1/')
```

If `cached_version` does not equal `target_version`, stop with:
> "The installed Forge plugin is v<cached_version> but the target is v<target_version>.
> Run `/plugin install forge@forge-local` to fetch the correct version, then re-run forge:update."

---

## Step 4: Classify Migration

Substitute `<current_version>` and `<target_version>` with the values from Steps 1–2:

```bash
current_major=$(echo "<current_version>" | cut -d. -f1)
target_major=$(echo "<target_version>" | cut -d. -f1)
if [ "$target_major" -gt "$current_major" ]; then
  migration_type="MAJOR"
else
  migration_type="MINOR/PATCH"
fi
```

---

## Step 5: Check for Active Work Items (MAJOR only)

Skip this step for MINOR/PATCH migrations.

Scan `.forge/efforts/*/.state.json` for active implementation tasks:

```bash
active_items=""
for state_file in .forge/efforts/*/.state.json; do
  [ -f "$state_file" ] || continue
  result=$(python3 - "$state_file" <<'PYEOF'
import json, sys
try:
    with open(sys.argv[1]) as f:
        state = json.load(f)
    impl = state.get("phases", {}).get("implementation", {})
    if state.get("currentPhase") == "implementation" and impl.get("status") == "in_progress":
        print(state.get("id", sys.argv[1]))
except Exception:
    pass
PYEOF
)
  if [ -n "$result" ]; then
    active_items="${active_items:+$active_items, }$result"
  fi
done

if [ -n "$active_items" ]; then
  # stop with warning
fi
```

If any active work items are found, stop with a warning listing their IDs:
> "The following work items are in active implementation: $active_items
> Complete or pause active work items before applying a MAJOR migration."

---

## Step 6: Discover Migration Manifests

Scan `<plugin_root>/migrations/` for all JSON manifest files matching the naming
convention `<from-version>-to-<to-version>.json`:

```bash
ls <plugin_root>/migrations/*.json 2>/dev/null
```

For each filename found, parse the `from` and `to` semver values by splitting on
`-to-` and stripping the `.json` suffix. For example, `1.0.0-to-2.0.0.json`
yields `from=1.0.0` and `to=2.0.0`.

After parsing `from` and `to` from a filename, validate that each is a valid semver
string matching the pattern `\d+\.\d+\.\d+`. If either value does not match:
  - Emit a warning: "Skipping malformed manifest filename: <filename>"
  - Exclude the manifest from the sequence
  - Continue processing other manifests

**Filter:** keep only manifests where `from` >= `current_version` AND `to` <=
`target_version`. Use `version_lt()` (defined in Step 2) for all comparisons:
- Keep if NOT `version_lt(from, current_version)` AND NOT `version_lt(target_version, to)`

**Sort:** order the kept manifests ascending by their `from` version.

**Validate ops:** before proceeding, scan every `steps` entry in every kept manifest
and collect the `op` values. The allowed set is:
`create-dir`, `rename`, `state-field`, `claude-md`, `git-config`

If any op value is not in the allowed set, stop immediately with:
> "Unknown op '<op>' in manifest '<filename>'. Migration aborted. Fix the manifest
> before re-running forge:update."

This validation runs before Step 8 so no files are changed before it completes.

**If no manifests found (or none pass the filter):** set `configuration_only=true`.
The always-required operation in Step 9 (CLAUDE.md refresh) still runs.
Record: `configuration_only=true`, `manifests=[]`.

**If manifests found:** record the ordered list and set `configuration_only=false`.

Record: `manifests` (ordered list), `configuration_only` flag.

---

## Step 7: Pre-Migration Report and Confirmation

```
forge:update — migration plan

  Current:  forge v<current_version>
  Target:   forge v<target_version>  (<target_ref>)
  Type:     <MAJOR | MINOR/PATCH>

  Manifests: <N> | none (configuration-only)
  <For each manifest in order:>
    - v<from> → v<to>  (<N> steps)
  <For each manifest, enumerate its steps:>
      <op>  <relevant paths or field names>

  Changes that will be applied:
    CLAUDE.md                        forge:managed section refreshed
    .forge/version                   active_version, forge_min_version, last_migrated_with, last_migrated_at updated
    <new .forge/ directories from manifests, if any>
    <.state.json schema changes from manifests, if any>

  <For MAJOR migrations only:>
  Active work items: none | <list of IDs from Step 5>

  Confirm? [y/N]
```

For MINOR/PATCH migrations, omit the Active work items line from the report entirely.

- **MAJOR**: always prompt, regardless of `--yes`. Require explicit `y`.
- **MINOR/PATCH with `--yes`**: skip prompt, print `(--yes: skipping confirmation)`.
- **MINOR/PATCH without `--yes`**: prompt. Require explicit `y`.

If the user does not confirm, stop with: "Migration cancelled."

---

## Step 8: Snapshot for Rollback

Read and store current contents of all files that will be modified. Use the Read tool.

For `rename` operations: collect the `from` path from every `rename` step across all
manifests.

```
snapshot = {
  "CLAUDE.md":              <current content, or ABSENT if the file does not exist>,
  ".forge/version":         <current content>
}
rename_froms = [<from path for each rename step across all manifests, in order>]
new_paths_created = []
```

Record ABSENT (not an empty string) for any file that does not currently exist.
The Rollback section uses this to determine whether to restore or delete.

If any manifest in the sequence contains a `state-field` step, read the current
contents of all `.forge/efforts/*/.state.json` files and add them to the snapshot:

  snapshot[".forge/efforts/<id>/.state.json"] = <current content>
  (one entry per file found)

If any snapshot read fails, stop with:
> "Cannot snapshot <file>. Migration aborted."

---

## Step 9: Apply Migration (atomic)

Apply in order. On any failure, execute Rollback and report the error.

### Always-required operation

This runs on every migration, regardless of whether manifests were found.

#### 9.1: Refresh CLAUDE.md forge:managed section

Read template from `<plugin_root>/templates/claude-md.md`. Substitute:
- `{{forge_version}}` → `v<target_version>`

Note: the current template does not use `{{marketplace_dir}}` or `{{sha}}` placeholders —
those substitutions are not needed.

Replace the content between `<!-- forge:managed:start -->` and
`<!-- forge:managed:end -->` (inclusive) with the rendered section using the Edit
tool. Preserve all content outside the markers. If no markers exist, append.

Idempotency: always re-applied — full replacement is safe.

### 9.2: Ensure .forge/.gitignore contains EFFORT

```bash
if [ ! -f ".forge/.gitignore" ]; then
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

- `.forge/.gitignore` does not exist → create with `EFFORT`. Record as created.
- Exists but missing `EFFORT` → append. Record as updated.
- Exists and already has `EFFORT` → no change. Record as unchanged.

Idempotency: always checked — safe to re-apply on every migration run.

### Manifest-declared operations

Skip this section if `configuration_only=true`.

For each manifest in the ordered sequence from Step 6, apply its `steps` array in
order:

#### `create-dir`

Create the directory at `path`.

Idempotency: skip silently if the directory already exists.

On creation, append `path` to `new_paths_created`.

#### `rename`

Move `from` to `to`.

Idempotency: skip silently if `from` is absent (rename was already applied).

Conflict check: if both `from` AND `to` exist simultaneously, stop with:
> "rename conflict: both '<from>' and '<to>' exist. This is not a rollback
> situation — resolve the conflict manually, then re-run forge:update."

Do not roll back on this conflict; the engineer must resolve it first.

On success, append `to` to `new_paths_created`.

#### `state-field`

For every `.forge/efforts/*/.state.json`, rename JSON field `field` to `rename`
at all levels of nesting.

**Note for manifest authors:** Because this operation renames at all nesting levels,
the field name must be unique within the `.state.json` schema. Renaming a common key
like `"status"` would incorrectly rename every `status` field in every section, not
just the intended one. Use specific field names (e.g., `"currentPhase"` rather than
`"phase"`) when authoring `state-field` operations.

**Idempotency rules (checked per file):**

- If the file already uses `rename` as the field name AND does not contain `field`:
  skip (already migrated). No output.
- If the file contains `field` but not `rename`: apply the rename.
- If the file contains BOTH `field` and `rename` (partial prior migration):
  emit a warning: `"state-field: both '<field>' and '<rename>' found in <path> — skipping (resolve manually)"`.
  Do not rename. The engineer must resolve this before re-running.
- If the file contains neither `field` nor `rename`:
  emit a warning: `"state-field: field '<field>' not found in <path> — skipping (possible manifest error)"`.
  This does not stop the migration — it is informational only.

#### `claude-md`

This op in a manifest is treated as a no-op — the always-required operation in 9.1
has already applied it. Including `claude-md` in a manifest is only needed when a
specific ordering relative to other structural steps is required.

#### `git-config`

For each entry in the `configs` array, add the key/value pair to the local git config
if it is not already present. Each entry has `key` (e.g. `remote.origin.push`) and
`value` (the refspec or setting value).

For each config entry:

```bash
git config --get-all <key> | grep -qF '<value>' \
  || git config --add <key> '<value>'
```

Idempotency: skip silently if the exact value is already registered under that key
(a key may have multiple values — `--get-all` checks all of them).

**Rollback:** git config entries are not rolled back on migration failure. They are
additive and safe to leave in place — re-running `forge:update` after fixing the
underlying failure is safe because the op is idempotent.

---

## Step 10: Update Version Record

This is the terminal write operation. Its completion is the signal that migration
succeeded.

Substitute `<target_version>` with the actual value, then run:

```bash
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
python3 - "<target_version>" "$TIMESTAMP" <<'PYEOF'
import re, sys

version, timestamp = sys.argv[1], sys.argv[2]

with open(".forge/version") as f:
    content = f.read()

def update_field(text, key, value):
    if re.search(rf'^{key}=', text, re.MULTILINE):
        return re.sub(rf'^{key}=.*', f'{key}={value}', text, flags=re.MULTILINE)
    return text.rstrip('\n') + f'\n{key}={value}\n'

content = update_field(content, 'active_version', version)
content = update_field(content, 'forge_min_version', version)
content = update_field(content, 'last_migrated_with', version)
content = update_field(content, 'last_migrated_at', timestamp)

with open(".forge/version", "w") as f:
    f.write(content)
PYEOF
```

Note: `initialized_with` and `initialized_at` are never modified by `forge:update`.

If Step 9 succeeds but Step 10 fails, the repository is fully migrated but the
version record was not updated. Re-running `forge:update` is safe — all Step 9
operations are idempotent and will be skipped on the second run.

---

## Step 11: Check forge:statusline Staleness

Check whether the engineer has the Forge statusline scripts installed and whether
they are current.

```python
python3 - <<'PYEOF'
import hashlib, sys
from pathlib import Path

installed = [
    Path.home() / '.claude' / 'forge-statusline.py',
    Path.home() / '.claude' / 'forge-subagent-statusline.py',
]
hash_file = Path('<plugin_root>') / 'statusline' / 'forge-statusline.py.sha256'

# Only check if at least one script is installed
if not any(p.exists() for p in installed):
    sys.exit(0)

if not hash_file.exists():
    sys.exit(0)

expected = [line.strip() for line in hash_file.read_text().splitlines()
            if line.strip() and not line.startswith('#')]
expected_hash = expected[0] if expected else ''

h = hashlib.sha256()
for p in sorted(installed, key=lambda x: x.name):
    if p.exists():
        h.update(p.read_bytes())
    else:
        print('STALE')
        sys.exit(0)

if h.hexdigest() != expected_hash:
    print('STALE')
else:
    print('CURRENT')
PYEOF
```

If the output is `STALE`, append to the update summary:

```
⚠️  forge:statusline scripts are out of date.
    Run /forge:statusline to update:
      ~/.claude/forge-statusline.py
      ~/.claude/forge-subagent-statusline.py
```

If the output is `CURRENT` or the scripts are not installed, print nothing extra.

---

## Step 12: Print Summary

```
forge:update complete — forge v<current_version> → v<target_version>

  Updated:
    CLAUDE.md                        (forge:managed section refreshed)
    .forge/version                   (active_version, forge_min_version, last_migrated_with, last_migrated_at updated)
    <new paths created, if any>

  Migration type: <MAJOR | MINOR/PATCH>

Commit these files so your team gets the updated configuration:
  git add CLAUDE.md .forge/
  git commit -m "chore: migrate forge to v<target_version>"
```

---

## Rollback

On any failure in Steps 9 or 10, restore all snapshotted files and reverse completed
renames. Apply the three loops in this exact order — the order matters when a rename
destination is also tracked in `new_paths_created`:

1. Restore snapshotted files first (includes any `.state.json` files from Step 8)
2. Delete newly created paths (removes any directories or files that should not exist)
3. Reverse completed renames last (moves `to` back to `from` — only if `to` still exists after step 2)

```
FOR each file in snapshot:
  Write original content back (or delete if snapshot recorded absence)
  (This includes any `.state.json` files captured in Step 8 if `state-field` operations were present.)
  IF this restore step itself fails:
    Report: "Rollback failed restoring <file>. Manual restore required."
    Print the snapshotted content for that file so the engineer can restore it manually.

FOR each path in new_paths_created (in reverse order):
  IF <path> is a directory:
    rm -rf <path>
  ELSE:
    rm -f <path>
    rmdir "$(dirname <path>)" 2>/dev/null || true  (only if now empty)

FOR each (from, to) pair in rename_froms (paired with corresponding rename step):
  IF <to> exists AND <from> does not exist:
    Move <to> back to <from>  (rename was applied — reverse it)
  IF this restore step itself fails:
    Report: "Rollback failed reversing rename <to> → <from>. Manual restore required."
    Print the snapshot entry for that path so the engineer can restore manually.
```

Print:
> "Migration failed at step <N>: <error>. All changes have been rolled back.
> Re-running forge:update is safe."

Stop.
