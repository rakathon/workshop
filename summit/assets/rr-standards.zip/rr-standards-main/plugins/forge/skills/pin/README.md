# forge:pin

Pins a repository to a specific Forge plugin version.

## Purpose

Creates a project-local marketplace (`forge-local`) that locks the team to an exact
Forge release. Every engineer who clones the repo loads the same plugin version,
eliminating drift from different global installations.

## When to Use

- Initial pinned setup: run `forge:pin` before (or after) `forge:init`
- Upgrading: run `forge:pin --version X.Y.Z`, then `/plugin install forge@forge-local`,
  then `forge:update` to apply structural migrations

Pinning is optional. Repos without a pin use whatever Forge version each engineer
has globally installed.

## Usage

```
forge:pin                    # pin to latest release
forge:pin --version 1.2.3    # pin to a specific version
```

## What It Does

1. Resolves the target version tag and commit SHA via GitHub API
2. Creates/updates `.claude-plugin/marketplace.json` with the cryptographic pin
3. Updates `.claude/settings.json` to register the forge-local marketplace and
   enable `forge@forge-local`
4. Updates `forge_min_version` in `.forge/version` if the repo is already initialized
5. Guides you through running `/plugin install forge@forge-local`

## Files Modified

| File | Change |
|------|--------|
| `.claude-plugin/marketplace.json` | Created or updated with new pin |
| `.claude/settings.json` | forge-local marketplace registered, forge@forge-local enabled |
| `.forge/version` | `forge_min_version` updated (if file exists) |
