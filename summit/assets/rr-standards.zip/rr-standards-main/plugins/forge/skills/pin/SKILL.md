---
name: forge:pin
description: Pin a repository to a specific Forge plugin version. Use this skill when an engineer wants to lock the team to a specific Forge version, says things like "pin forge to a version", "lock forge version", "I want everyone to use the same forge version", "update the forge pin", or "change which forge version this repo uses". Can be run before or after forge:init — the two skills are order-independent. Run forge:update after changing the pin to apply any structural migrations.
argument-hint: "[--version <semver>]"
---

# forge:pin

Pins this repository to a specific Forge plugin version by creating a project-local
marketplace that points to an exact release tag and commit SHA. Once pinned, every
engineer who clones the repo loads the same plugin version — eliminating "works on
my machine" problems caused by different global installations.

Pinning is optional. Repos without a pin load whatever version of Forge the engineer
has globally installed. `forge:pin` and `forge:init` are order-independent — run them
in whichever order makes sense. Run `forge:update` after changing the pin to migrate
repo contents to the new version.

## Arguments

| Flag | Description | Default |
|------|-------------|---------|
| `--version <semver>` | Pin to a specific release (e.g. `1.2.3` or `v1.2.3`) | latest release |

---

## Preconditions

**PC-1: gh is installed and authenticated**

```bash
gh auth status
```

If this fails, stop with:
> "GitHub CLI (`gh`) is not installed or not authenticated. Install it from
> https://cli.github.com, then run `gh auth login`."

**PC-2: Not inside a .forge subdirectory**

If the current working directory contains `/.forge/efforts/` or `/.forge/deployables/`,
stop with:
> "forge:pin must be run from the repository root."

---

## Step 1: Resolve Target Version

**If `--version <semver>` was provided:**

Strip a leading `v` if present (so both `1.2.3` and `v1.2.3` work), then resolve:

```bash
semver="<semver>"
semver="${semver#v}"   # strip leading v if present
tag="v${semver}"
sha=$(gh api repos/rewards-guilds/rr-standards/git/ref/tags/$tag \
      --template '{{.object.sha}}')
```

If the command fails or returns empty, the tag does not exist. Fail with:
> "Tag <tag> not found in rewards-guilds/rr-standards. Available releases:"

Then list releases:
```bash
gh release list --repo rewards-guilds/rr-standards --limit 10
```

Set `version = <semver>` (without the `v` prefix).

**If `--version` was not provided:**

```bash
tag=$(gh api repos/rewards-guilds/rr-standards/releases/latest \
      --template '{{.tag_name}}')
version="${tag#v}"
sha=$(gh api repos/rewards-guilds/rr-standards/git/ref/tags/${tag} \
      --template '{{.object.sha}}')
```

**On any `gh` failure:**
> "GitHub CLI request failed. If you are not authenticated, run: gh auth login"

Stop. Do not continue.

Record: `tag`, `version`, `sha`.

---

## Step 2: Apply Changes

This single Python invocation handles all three files — comparing current state to
desired state, writing only what needs to change, and reporting the result. The
output drives what happens next.

Substitute `<tag>`, `<version>`, and `<sha>` with the values from Step 1, then run:

```bash
mkdir -p .claude
python3 - "<tag>" "<version>" "<sha>" <<'PYEOF'
import json, re, os, sys

tag, version, sha = sys.argv[1], sys.argv[2], sys.argv[3]
changes = []
pin_changed = False

desired_source = {
    "source": "git-subdir",
    "url": "https://github.com/rewards-guilds/rr-standards.git",
    "path": "plugins/forge",
    "ref": tag,
    "sha": sha
}

# --- marketplace.json ---
marketplace_path = ".claude-plugin/marketplace.json"
if os.path.exists(marketplace_path):
    with open(marketplace_path) as f:
        existing = json.load(f)
    old_source = existing.get("plugins", [{}])[0].get("source", {})
    old_ref = old_source.get("ref", "")
    old_sha = old_source.get("sha", "")
    if old_ref == tag and old_sha == sha:
        changes.append(("unchanged", marketplace_path, None))
    else:
        existing["plugins"][0]["source"] = desired_source
        with open(marketplace_path, "w") as f:
            json.dump(existing, f, indent=2)
            f.write("\n")
        changes.append(("updated", marketplace_path, f"{old_ref} → {tag}, sha: {sha[:12]}..."))
        pin_changed = True
else:
    os.makedirs(".claude-plugin", exist_ok=True)
    manifest = {
        "$schema": "https://anthropic.com/claude-code/marketplace.schema.json",
        "name": "forge-local",
        "owner": {"name": "Platform Engineering"},
        "plugins": [{"name": "forge", "source": desired_source, "category": "development"}]
    }
    with open(marketplace_path, "w") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")
    changes.append(("created", marketplace_path, f"pinned to {tag}, sha: {sha[:12]}..."))
    pin_changed = True

# --- settings.json ---
settings_path = ".claude/settings.json"
try:
    with open(settings_path) as f:
        cfg = json.load(f)
    original = json.dumps(cfg, sort_keys=True)
except FileNotFoundError:
    cfg = {}
    original = None

cfg.setdefault("extraKnownMarketplaces", {})
cfg["extraKnownMarketplaces"]["forge-local"] = {
    "source": {"source": "directory", "path": "./.claude-plugin"}
}
cfg.setdefault("enabledPlugins", {})
cfg["enabledPlugins"] = {k: v for k, v in cfg["enabledPlugins"].items()
                         if not k.startswith("forge@")}
cfg["enabledPlugins"]["forge@forge-local"] = True

if json.dumps(cfg, sort_keys=True) != original:
    with open(settings_path, "w") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")
    action = "created" if original is None else "updated"
    changes.append((action, settings_path, "forge@forge-local enabled"))
else:
    changes.append(("unchanged", settings_path, None))

# --- .forge/version ---
version_path = ".forge/version"
if os.path.exists(version_path):
    with open(version_path) as f:
        content = f.read()
    m = re.search(r'^forge_min_version=(.*)', content, re.MULTILINE)
    current_min = m.group(1) if m else None
    if current_min == version:
        changes.append(("unchanged", version_path, None))
    else:
        if m:
            content = re.sub(r'^forge_min_version=.*', f'forge_min_version={version}',
                             content, flags=re.MULTILINE)
        else:
            content = content.rstrip('\n') + f'\nforge_min_version={version}\n'
        with open(version_path, "w") as f:
            f.write(content)
        changes.append(("updated", version_path, f"forge_min_version={version}"))

# --- Output ---
all_unchanged = all(status == "unchanged" for status, _, _ in changes)
if all_unchanged:
    print("STATUS: nothing_to_do")
else:
    print(f"STATUS: changed pin_changed={'true' if pin_changed else 'false'}")
    for status, path, detail in changes:
        detail_str = f" ({detail})" if detail else ""
        print(f"  {status}: {path}{detail_str}")
PYEOF
```

Read the output:

- If the first line is `STATUS: nothing_to_do` → print:
  > "Already pinned to `<tag>` with all settings configured. Nothing to do."
  > "(Note: `.forge/version` is updated only when it exists — run `forge:init` if the repo hasn't been set up yet.)"

  And stop.

- If the first line contains `pin_changed=true` → proceed to Step 3 (plugin install needed).
- If the first line contains `pin_changed=false` → skip Step 3, go directly to Step 4 (only settings/version were updated; plugin is already installed at the right version).

---

## Step 3: Instruct Plugin Installation

> **Only run this step if `pin_changed=true` from Step 2.**

The pin changed — the local marketplace needs to be registered so Claude Code can
load the pinned version. Print the following and **stop until the user confirms**:

> "`.claude-plugin/marketplace.json` is now pinned to `<tag>`. Please run this
> command now — type it directly in the chat (built-in Claude Code command, not
> a skill):
>
> `/plugin marketplace add ./`
>
> This registers the forge-local marketplace from the project's `.claude-plugin/`
> directory and loads the pinned version. Once done, reply here and I'll continue."

Wait for confirmation before continuing.

---

## Step 4: Print Summary

Populate each section from the output of Step 2. Omit sections with no entries.

```
forge:pin complete — forge <tag>

  Created:
    <files that were newly created, one per line with detail in parens>

  Updated:
    <files that were modified, one per line with change in parens>

  Unchanged:
    <files already at desired state — omit section if none>

Commit these files so the pin is shared with your team:
  git add .claude-plugin/marketplace.json .claude/settings.json
  git add .forge/version   # if it exists
  git commit -m "chore: pin forge to <tag>"

Next steps:
  forge:init    — if this repo hasn't been set up yet
  forge:update  — if the repo was previously initialized (migrates contents to <tag>)

Note: .forge/version is only updated when it already exists. If it doesn't appear
above, run forge:init to create it.
```
