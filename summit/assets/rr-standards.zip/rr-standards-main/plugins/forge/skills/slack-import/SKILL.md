---
name: forge:slack-import
description: > 
    Import Slack messages from all channels associated with an effort into dated markdown files. 
    Trigger on: "import slack messages", "sync slack", "pull slack messages", "run slack import", 
    "fetch slack history". Supports --from/--to date bounds, --channel to scope to one channel, 
    and --ci to import all efforts in the repository.
agent-type: orchestrator
argument-hint: "[--effort <id>] [--from <datetime>] [--to <datetime>] [--channel <channel-id>] [--lag-buffer <minutes>] [--thread-lookback <days>] [--ci]"
---

# forge:slack-import

Fetches messages from the effort's associated Slack channel(s), writes daily message
files with thread structure and Atlassian link enrichment, and advances the import
checkpoint. Supports optional date/time bounds for backfill or targeted imports.

---

## Arguments

| Argument | Required | Description |
|---|---|---|
| `--effort <effort_id>` | No | Target a specific effort by ID. If omitted, resolved via the standard chain (see `plugins/forge/skills/common/effort-resolution.md`). Mutually exclusive with `--ci`. |
| `--from <datetime>` | No | ISO 8601 start bound (inclusive). Overrides checkpoint. Single-effort mode only. |
| `--to <datetime>` | No | ISO 8601 end bound (inclusive). Defaults to `now - lag-buffer`. Single-effort mode only. |
| `--channel <channel-id>` | No | Limit import to a specific channel. If omitted, all channels in the effort's `slackChannels` array are imported. Single-effort mode only. |
| `--lag-buffer <minutes>` | No | Minutes to subtract from the current timestamp when computing the default `end`. Default: 5. Pass `0` to disable. Ignored when `--to` is provided explicitly. |
| `--thread-lookback <days>` | No | Number of days before `start` to scan for thread parents with new replies within the import window. Default: 30. Pass `0` to disable. |
| `--ci` | No | CI mode: scan the repository for all efforts with a non-empty `slackChannels` array and run the import for every channel of each effort. Mutually exclusive with `--effort`, `--from`, and `--to`. |

When neither `--from`, `--to`, nor `--ci` is provided, the import runs for the active
effort from its checkpoint through `now - lag-buffer` (default: 5 minutes). When
`--from` is provided without `--to`, the same default applies. The lag buffer ensures
messages that are in-flight or not yet indexed by the Slack API at query time are not
silently skipped — they will be caught on the next run when the overlapping window is
re-fetched and deduped.

---

## Preconditions

**PC-1: Target effort has a Slack channel (single-effort mode only)**

If `--ci` is not set, resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: `effort-required`
Pass `--effort` value as the explicit argument (Step 1 of the chain) when provided.

Then read the resolved effort's `.state.json`. If `slackChannels` is absent, null, or
empty, stop:
> "No Slack channels associated with this effort. Run `forge:slack-channel` first."

If `--channel` is provided, verify it exists as an `id` in `slackChannels`; if not, stop:
> "Channel `<id>` is not associated with this effort."

In CI mode these checks are applied per-effort during the scan (Step 0) rather than
as a global precondition.

Record:
- `effort_id` — the resolved effort ID
- `effort_dir` — `.forge/efforts/<effort_id>/`
- `messages_dir` — `<effort_dir>/messages/slack/`

For each channel entry: `channel_id = entry.id` (used for Slack API calls), `channel_name = entry.name` (used for directory paths).

**PC-2: Slack MCP available**

Check for `mcp__slack__*` tools. If absent, stop:

```
forge:slack-import error: Slack MCP not configured
Reason: The Slack MCP server is not available in this session.
Resolution: Ensure the Slack MCP server is declared in the Forge plugin's
            .mcp.json and that you have completed the OAuth authorization
            flow. Restart Claude Code and retry.
```

**PC-3: Atlassian MCP available**

Check for `mcp__atlassian__*` tools. If absent, proceed but skip link enrichment for
all messages and note: "Atlassian MCP unavailable — link enrichment skipped."

**PC-4: Checkpoint or --from present (single-effort mode only)**

If `--ci` is not set and no `.checkpoint` exists for a channel and `--from` is not
provided, stop and prompt per channel:
> "No import checkpoint found for `<channel-name>`. What date should the import start from? (YYYY-MM-DD)"

Use the engineer's response as `--from` for that channel. In CI mode, channels with
no checkpoint and no recoverable start are skipped with a warning rather than halting.

See Step 1 for the full checkpoint read rules.

**PC-5: Mutually exclusive flags**

If `--ci` is combined with `--effort`, `--from`, or `--to`, stop:
> "`--ci` runs all efforts from their own checkpoints and cannot be combined with
> `--effort`, `--from`, or `--to`. Use single-effort mode for targeted or bounded imports."

---

## Steps

### Step 0: CI Mode — Scan and Dispatch (--ci only)

If `--ci` is set:

1. Enumerate all directories under `.forge/efforts/`.
2. For each effort directory, read `.state.json`. Collect every effort where
   `slackChannels` is a non-empty array.
3. If no efforts have associated channels, stop:
   > "No efforts with associated Slack channels found. Nothing to import."
4. For each collected effort, and for each channel in that effort's `slackChannels`,
   run Steps 1–7 using that effort+channel pair as context. Per-channel errors are
   caught, logged, and do not halt remaining channels or efforts.
5. After all efforts and channels are processed, print the CI summary (Step 8 CI
   variant) and exit.

---

### Step 1: Resolve Target Channels and Import Range

In single-effort mode, determine the set of channels to import:
- If `--channel` is provided: import that channel only.
- If `--channel` is omitted: import all channels in `slackChannels`.

Run Steps 2–7 once per channel. Each channel uses its own `.checkpoint` at
`<messages_dir><channel-name>/.checkpoint`.

Determine `start` and `end` per channel:

| Condition | `start` | `end` |
|---|---|---|
| Neither `--from` nor `--to` | Read checkpoint from `.checkpoint` file | `now - lag-buffer` (UTC) |
| `--from` only | `--from` value | `now - lag-buffer` (UTC) |
| `--from` and `--to` | `--from` value | `--to` value |

`now` is captured once at the start of each channel run. `lag-buffer` is the value of
`--lag-buffer` (default: 5 minutes). When `--to` is provided explicitly, `lag-buffer`
is not applied.

**Checkpoint read rules:**

- If the `.checkpoint` file is **absent** and `--from` is not provided: stop and
  prompt (PC-4). In CI mode: skip with warning. (See also PC-4.)
- If the `.checkpoint` file is **present but malformed** (not a valid ISO 8601
  timestamp): stop immediately with a parse error:
  > "Checkpoint at `<path>` is malformed: `<raw content>`. Fix or delete the file and retry."
  Do not attempt to fall back or default. Do not run the import.
- If the `.checkpoint` file is **present and valid**: use its value as `start`.

If `start >= end`, stop:
> "Import range is empty: `<start>` to `<end>`. Nothing to import."

---

### Step 2: Fetch Messages

> **Note on tool names:** The tool names used in this step (`mcp__slack__get_channel_history`,
> `mcp__slack__get_thread_replies`, `mcp__slack__get_users`) are provisional. Verify
> the exact names exposed by the live Slack MCP server at implementation time
> (see `spec/mcp-config.md`).

**2a. Fetch channel history with cursor-based pagination**

Before making any Slack API calls, convert `start`, `end`, and `lookback_start` from
ISO 8601 strings to Unix timestamps (integer seconds since the Unix epoch, UTC). Use
the Bash tool to compute these values:

```bash
date -u -j -f "%Y-%m-%dT%H:%M:%SZ" "<ISO-timestamp>" "+%s"   # macOS
date -u -d "<ISO-timestamp>" "+%s"                             # Linux
```

Run the appropriate variant for the detected platform. Record the results as
`start_ts`, `end_ts`, and (when needed) `lookback_start_ts`. Use these Unix integer
values for all `oldest`/`latest` parameters in every Slack MCP call in Steps 2a–2c.

Call `mcp__slack__get_channel_history` with:
- `channel`: `channel_id` (from `entry.id`)
- `oldest`: `start_ts` (Unix seconds)
- `latest`: `end_ts` (Unix seconds)

After each response, check whether the result includes a pagination cursor. While a
cursor is returned, call `mcp__slack__get_channel_history` again with the same
`channel`, `oldest`, and `latest` values plus the cursor from the previous response.
Collect all top-level messages across all pages before proceeding.

If no messages are returned for the range across all pages, the in-window scan is
complete. Continue to Step 2b to check for late replies on pre-window threads (unless
`--thread-lookback 0` was passed, in which case skip directly to Step 6 to advance
the checkpoint and then Step 8 to log the run).

**2b. Fetch thread replies (in-window parents)**

For each top-level message from Step 2a where `reply_count > 0`, call
`mcp__slack__get_thread_replies` with:
- `channel`: `channel_id` (from `entry.id`)
- `ts`: the message's `ts` identifier (the thread parent timestamp)

Apply the same cursor-based pagination pattern — continue calling with the cursor until
no cursor is returned. Collect all replies across all pages.

Associate each reply with its parent message using the `thread_ts` field (which matches
the parent's `ts`).

**2c. Fetch late replies on pre-window thread parents**

Compute `lookback_start` = `start` minus `--thread-lookback` days (default 30).

Call `mcp__slack__get_channel_history` with:
- `channel`: `channel_id`
- `oldest`: `lookback_start_ts` (Unix seconds)
- `latest`: `start_ts` (exclusive upper bound — messages before the import window)

Paginate as in Step 2a. For each returned top-level message where `reply_count > 0`
and `latest_reply` timestamp falls within `[start, end]`, fetch that thread's replies
using `mcp__slack__get_thread_replies` (paginating as in Step 2b). Collect only replies
whose `ts` falls within `[start, end]` — discard replies outside the window.

These late replies are associated with their pre-window parent message. They are written
in Step 5 using the cross-day dual-write rule (reply's own day file gets a cross-reference;
parent's day file receives the full reply blockquote). If the parent's day file does not
yet exist (i.e., the parent predates the entire import history), create it with only the
parent message as context followed by the late reply — using the parent's display name,
timestamp, and message text.

Associate each reply with its parent message using the `thread_ts` field.

**2d. Resolve user IDs to display names**

Collect all unique user IDs from both top-level messages and thread replies (the `user`
field on each message object).

Call `mcp__slack__get_users` once to resolve them. If the tool paginates, follow cursors
until all users are fetched. Cache the resolved `user_id → display_name` mapping in
memory for the duration of the run. Do not call `mcp__slack__get_users` more than once
per channel run.

For any user ID not present in the resolved map (e.g., a deactivated account),
fall back to the raw user ID as the display name.

**2e. MCP failure handling**

PC-2 verifies the Slack MCP is present before this step is reached. If a Slack MCP
call fails mid-run (e.g., a transient network error), stop, report the failure, and
apply the partial write error policy: preserve last-good file state and do not advance
the checkpoint.

---

### Step 3: Group by Calendar Day

Partition **top-level messages only** by the calendar day of their timestamp (UTC).
For each day in the range that has top-level messages:

- If the daily file already exists, merge new messages in — deduplicate by `ts`
  identifier so no message is written twice.
- If the daily file does not exist, create it.

Thread replies are not bucketed in this step. Their placement into daily files
(same-day under parent, or cross-day dual-write) is handled in Step 5.

---

### Step 4: Enrich Atlassian Links

If the Atlassian MCP is unavailable (PC-3), skip this step entirely for all messages.

For each message (top-level and reply), scan the message text for URLs matching:
- `https://rakutenrewards.atlassian.net/wiki/` — Confluence page
- `https://rakutenrewards.atlassian.net/jira` — Jira issue
- `https://rakutenrewards.atlassian.net/browse` — Jira issue

Process each matched URL:

**Confluence URLs** — call `mcp__plugin_forge_atlassian__getConfluencePage` with the
page ID extracted from the URL. Extract the page ID as the numeric segment following
`/pages/` in the URL (e.g., `12345` from `/wiki/spaces/ENG/pages/12345` or
`/wiki/spaces/ENG/pages/12345/Page+Title`). From the response, extract:
- `title` — the page title
- A brief description (≤2 sentences) derived from the page body or abstract

Append inline immediately after the link as a Markdown blockquote:

```markdown
> **[Confluence]** <title> — <≤2 sentence description>
```

**Jira URLs** — call `mcp__plugin_forge_atlassian__getJiraIssue` with the issue key
extracted from the URL. Extract the issue key as the `PROJ-NNN` segment (e.g.,
`PDO-1234` from `/browse/PDO-1234`). From the response, extract:
- `key` — the issue key (e.g. `PDO-1234`)
- `fields.status.name` — the current status (e.g. `In Progress`)
- `fields.summary` — the issue summary
- A brief description (≤2 sentences) from `fields.description` if available

If `fields.description` is a structured object (Atlassian Document Format) rather
than a plain string, omit the description clause and render only:
`> **[Jira · <status>]** <key>: <summary>`

Append inline immediately after the link as a Markdown blockquote:

```markdown
> **[Jira · <status>]** <key>: <summary> — <≤2 sentence description>
```

**On enrichment failure** — if the MCP call returns an error or the resource is
inaccessible (e.g. 404, permission denied), append a failure note instead and
continue processing remaining links and messages:

```markdown
> [summary unavailable: <reason>]
```

**Enrichment inside thread replies** — when a link appears inside a thread reply
(which is already rendered as a `>` blockquote), the enrichment line still uses a
single `>` — do not add an extra level of indentation relative to the reply.

**Format reference** — the rendered output must match the examples in
`spec/storage/messages.md` (Confluence / Jira link enrichment section). Example:

```markdown
See design notes: https://rakutenrewards.atlassian.net/wiki/spaces/ENG/pages/12345
> **[Confluence]** Payment Flow Redesign — Covers the proposed v2 checkout sequence and rollback strategy.

Tracked in: https://rakutenrewards.atlassian.net/browse/PDO-1234
> **[Jira · In Progress]** PDO-1234: Migrate preferences API to v2 — Backend migration of member preference endpoints.
```

---

### Step 5: Write Daily Message Files

For each day, write (or update) `<messages_dir><channel-name>/YYYY-MM/YYYY-MM-DD.md`.
The enriched message set from Steps 2–4 is the input — all Atlassian link enrichment
is already resolved before this step writes any file.

**File format** (full spec in `spec/storage/messages.md`):

Front matter:
```markdown
# Slack Messages — <channel-name> — <YYYY-MM-DD>

*Channel: <channel-id>*
*Imported: <ISO 8601 datetime>*

---
```

Top-level message entry:
```markdown
**<display-name>** · <HH:MM> UTC

<message text, preserving line breaks>
```

Thread reply (blockquote indentation):
```markdown
> **<display-name>** · <HH:MM> UTC
>
> <message text, preserving line breaks>
```

All replies in a thread use a single `>` blockquote regardless of depth. Do not use
`>>` or deeper nesting even when a reply is itself a reply to another reply.
Separate consecutive replies within the same thread with a blank blockquote line
(`>`) between them to maintain valid Markdown paragraph separation.

Full thread example (from `spec/storage/messages.md`):
```markdown
**alice** · 09:14 UTC

Should we go with approach A or B for the storage layer?

> **bob** · 09:22 UTC
>
> I'd lean toward A — simpler migration path.
>
> **alice** · 09:31 UTC
>
> Agreed. Let's go with A.
```

Cross-day thread reference (written in the reply's own daily file):
```markdown
↩ Reply in thread from <YYYY-MM-DD> — [<parent message excerpt>](../<YYYY-MM>/<YYYY-MM-DD>.md#<anchor>)
```

- `<parent message excerpt>` — the first 60 characters of the parent message text,
  truncated at a word boundary with `…` if longer.
- `#<anchor>` — omit the anchor fragment for now; use the bare file path until a
  future enhancement defines anchor IDs. Write the cross-reference as:
  `↩ Reply in thread from <YYYY-MM-DD> — [<parent message excerpt>](../<YYYY-MM>/<YYYY-MM-DD>.md)`

**Ordering and placement rules:**

- Top-level messages appear in ascending order of their own `ts` timestamp. Thread
  reply timestamps do not affect a parent message's position in the file.
- Thread replies are nested directly under their parent message in ascending reply
  order (by reply `ts`).
- All replies at every depth use a single `>` blockquote — never `>>` or deeper.
- When a thread reply's calendar day differs from the parent's calendar day
  (cross-day reply): append the reply under the parent entry in the parent's daily
  file, and write the `↩ Reply in thread from…` cross-reference in the reply's own
  daily file. The parent file receives the **full reply blockquote text**. The
  reply's own day file receives **only the one-line cross-reference** — not the
  full reply content. This dual-write ensures each day's file is a complete record
  of all activity that occurred on that day — replies sent on a given day always
  appear in that day's file (as a cross-reference) even when the thread parent
  lives in an earlier file.
- Enriched Atlassian link summaries are rendered inline immediately after the
  original URL (already resolved in Step 4).

**Idempotency:**

If a daily file already exists, merge new messages in rather than overwriting.
Match existing messages by their `ts` field — do not write a message that is
already present. Only new `ts` values are appended. This is consistent with the
deduplication applied in Step 3. For thread replies, deduplicate by the reply's
own `ts` value within the parent's reply list — do not re-append a reply that
already exists under the parent.

**Directory creation:**

Create the `<messages_dir><channel-name>/YYYY-MM/` directory if it does not exist.

**Write failure handling:**

If any daily file fails to write:
- Preserve the last-good file state (do not leave partial writes)
- Report which day failed
- Do not advance the checkpoint (Step 6 must not run)

---

### Step 6: Advance Checkpoint

Determine whether to write the checkpoint based on the run type:

| Run type | Condition | Checkpoint action |
|---|---|---|
| Watermark-based | Neither `--from` nor `--to` provided | Write `end` to `.checkpoint` |
| Start-only | `--from` provided, `--to` not provided | Write `end` to `.checkpoint` |
| Fully bounded | Both `--from` and `--to` provided | Do NOT modify `.checkpoint` |

**Write rules for watermark-based and start-only runs:**

Write the `end` timestamp to `<messages_dir><channel-name>/.checkpoint` as a plain
ISO 8601 timestamp string — single line, no trailing newline.

Example: `2026-04-20T14:27:03Z` (i.e. `now - lag-buffer` at the time of the run)

Write the checkpoint even when zero messages were found — a confirmed-empty scan is
still a valid completed import. This prevents re-scanning already-confirmed-empty
ranges on subsequent runs.

Because `end = now - lag-buffer`, the next run's `oldest` overlaps the tail of this
run by `lag-buffer` minutes. Any messages in that overlap window are re-fetched and
silently deduped, guaranteeing no messages are silently skipped due to Slack API
delivery lag.

If Step 5 reported a write failure for any daily file, skip this step.

**For fully bounded runs** (`--from` and `--to` both provided): leave the existing
`.checkpoint` file unchanged. Do not create it if it does not exist.

---

### Step 7: Commit

Use `forge:commit` to stage and commit all written and updated files from this run
(daily message files and `.checkpoint`). In CI mode, run one `forge:commit` per
effort after its Steps 1–6 complete rather than a single commit for all efforts.

---

### Step 8: Log Run

**Single-effort mode:**

```
forge:slack-import complete
Effort:  <effort_id>
  Channel <channel-name> (<channel-id>):  <N> messages, <D> days written, checkpoint → <value>
  Channel <channel-name> (<channel-id>):  <N> messages, <D> days written, checkpoint → <value>
Enrichment: <K> links resolved, <L> unavailable (across all channels)
```

`checkpoint → <value>` always shows the written checkpoint timestamp, even when `N = 0`.
`checkpoint → unchanged` is only reported for fully bounded (`--from` + `--to`) runs.

**CI mode (printed after all efforts and channels are processed):**

```
forge:slack-import complete (CI mode)
Efforts scanned: <total with non-empty slackChannels>
  ✓ <effort_id>/<channel-name> (<channel-id>) — <N> messages, <D> days, checkpoint → <value>
  ✓ <effort_id>/<channel-name> (<channel-id>) — <N> messages, <D> days, checkpoint → <value>
  ✗ <effort_id>/<channel-name> (<channel-id>) — skipped: no checkpoint and no recoverable start date
  ✗ <effort_id>/<channel-name> (<channel-id>) — failed: <error summary>
```

---

## Error Handling

| Condition | Action |
|---|---|
| Slack MCP unavailable | Stop with MCP configuration error (PC-2) |
| Atlassian MCP unavailable | Proceed; skip enrichment; note in log (PC-3) |
| Checkpoint absent, no `--from` | Prompt for start date (single-effort); skip with warning (CI) |
| Checkpoint malformed | Stop with parse error; do not run — no silent fallback |
| Import range empty | Stop with range-empty message |
| Zero in-window messages, no thread lookback | Advance checkpoint to `end`; log 0 messages |
| Zero in-window messages, thread lookback enabled | Run Step 2c; advance checkpoint to `end` after |
| Partial write failure | Preserve last-good file state; report which day failed; do not advance checkpoint |
| Link enrichment error (single link) | Append `[summary unavailable: <reason>]`; continue |
| `--ci` combined with `--effort`, `--from`, or `--to` | Stop with mutual exclusion error (PC-5) |
| `--channel` not in `slackChannels` | Stop with channel-not-associated error (PC-1) |
