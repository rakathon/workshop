---
name: forge:ui
description: >
  Generate standards-compliant UI code using the Rakuten Rewards design system —
  correct component hierarchy, design tokens, and mobile-first responsive layout.
  Use this skill whenever someone asks to build, add, create, or generate any UI:
  pages, sections, components, landing pages, carousels, heroes, grids, forms,
  or any other visual element. Trigger on prompts like "build me a page",
  "add a hero section", "create a landing page", "I need a store carousel",
  "generate this UI", "build a [anything UI-related]", "implement this design",
  or "what components should I use for X". If the request involves producing or
  planning React/Kotlin/Swift UI code, use this skill — don't attempt it without
  loading the design system context first.
---

# forge:ui

Generates design-system-compliant UI code by detecting the target platform, loading
the relevant standards and language guides, and then producing output that satisfies
every organizational rule without the engineer needing to remember them.

The skill's value is in the loading step: standards and guides contain the token
vocabulary, component hierarchy, and responsive patterns that must be applied. Without
them in context, generated code will drift — wrong hex values, wrong import sources,
missing breakpoints. Load them first, then generate.

---

## Step 1 — Detect platform

Check for platform signals in the project root. Run these checks in parallel:

```bash
# Web: package.json exists and references the UIKit package
grep -l "@rakuten-rewards/uikit" package.json 2>/dev/null

# Android: Gradle build files present
ls build.gradle settings.gradle 2>/dev/null

# iOS: Swift package or Xcode project present
ls Package.swift *.xcodeproj 2>/dev/null
```

**Exactly one platform detected:** proceed with that platform.

**Multiple platforms detected** (monorepo): ask the engineer:
> "I detected multiple platforms in this repo. Which are you building for: Web, Android, or iOS?"
Wait for the answer, then proceed.

**No platform detected:** stop with:
> "I couldn't detect a supported design system platform in this directory.
> For Web, ensure `package.json` references `@rakuten-rewards/uikit`.
> For Android, a `build.gradle` or `settings.gradle` must be present.
> For iOS, a `Package.swift` or `.xcodeproj` must be present."

---

## Step 2 — Load standards and guides

Load the files for the detected platform before asking any questions or writing any code. This step is non-negotiable — the output cannot be validated against standards that aren't in context.

### Web (TypeScript/React)

Read all of these:

1. `plugins/forge/standards/frontend/design-tokens.md`
2. `plugins/forge/standards/frontend/component-selection.md`
3. `plugins/forge/standards/frontend/responsive-layout.md`
4. `plugins/forge/languages/typescript/react/default/guides/ui-design-system/AGENTS.md`

Then, based on what the engineer wants to build, load the relevant guide(s) from the `ui-design-system/` directory. The AGENTS.md tells you which guide to load for which task — don't load all four unless the task genuinely spans all of them. For most requests, `components.md` and `tokens.md` are sufficient; for full-page work, also load `responsive-layout.md` and `page-patterns.md`.

### Android (Kotlin) — not yet available

> "Android/Kotlin design system guides are not yet available in this plugin version.
> Check back after the next release, or raise this with the platform team."

### iOS (Swift) — not yet available

> "iOS/Swift design system guides are not yet available in this plugin version.
> Check back after the next release, or raise this with the platform team."

---

## Step 3 — Read UI spec (if present)

Check for a UI spec file. Look in order:
1. A path explicitly mentioned in the engineer's prompt
2. `spec/ui-spec.md` relative to the current working directory
3. Any file matching `**/ui-spec.md` one level deep

If found, read it. The spec's `mode` field changes how the rest of the skill operates:

| Mode | What it means for generation |
|------|------------------------------|
| `exploration` | Build the variants listed — breadth over polish; placeholder data is fine |
| `data-first` | Get the data shape visible quickly; minimal layout complexity, but token compliance and composite component selection still apply |
| `production` | Every state in **States Required** must be implemented; apply **Accessibility Notes** |

Note: `data-first` mode affects *scope and completeness* (fewer states, placeholder data is fine), not *standards compliance*. Token names and composite components are required in all modes — the design system rules do not have a "quick and dirty" exemption.

Extract: goal, scope, mode, data shape, variants (if any), design reference (if any),
required states (if any), accessibility notes (if any), out-of-scope items.

**If no spec file is found**, continue to Step 3a to gather intent conversationally.
**If a spec file is found**, skip Step 3a and proceed directly to Step 4 — the spec
replaces the clarifying questions.

---

## Step 3a — Clarify intent (no spec present)

Ask at most 3 questions. Never ask about colors, spacing, typography, or which
component library to use — those are answered by the standards already loaded.

Good questions:
- **Scope:** Is this a full page, a section within an existing page, or a standalone
  component?
- **Content:** What data does this UI display, and is it real data from a specific
  source or representative placeholder data?
- **Sections:** What sections or states should be included? (e.g. hero, feature grid,
  FAQ, loading state, empty state)

If the engineer's original prompt already answers these, skip straight to Step 4.

---

## Step 4 — Plan before coding

Before writing any TSX, state the plan. Keep it brief — a short bulleted list, not a
document. The engineer should be able to read it in 30 seconds and redirect if needed.

Always include:
- Each section/component listed top-to-bottom
- The UIKit component chosen for each (composite first — per `component-selection.md`)
- Any assumptions being made (placeholder data, image paths, etc.)

Additionally, by mode:

**exploration:** List each variant by name and the key structural difference between
them. Don't start coding until the engineer confirms the variant list.

**data-first:** State what data fields will be displayed and where they map to in the
UI. If the data shape is ambiguous, call it out before proceeding. Even in data-first
mode, reach for the right composite: a list of stores or merchants maps to
`StoreCarouselTopic` or `PromoTopic`, not a hand-built `SimpleGrid` with custom cards.

**production:** List every required state from the spec (default, loading, empty,
error, feature-specific). If any state is missing from the spec, flag it:
> "The spec doesn't describe a [loading] state — should I include a skeleton, a
> spinner, or omit it?"
Don't proceed past the plan until all required states are accounted for.

---

## Step 5 — Generate

Write the TSX. The loaded guides contain complete runnable examples — use them as
your starting point rather than writing from scratch. The `page-patterns.md` guide
has full page templates; `components.md` has per-component examples.

Keep these rules in mind while generating (they are enforced in Step 6):

- Every color must use a token name (`bg="fill.ctaPrimary"`, not `bg="#8529CD"`)
- Every spacing value must use a token name (`p="medium"`, not `p="16px"`)
- Every layout-affecting prop must have a responsive object starting with `base`
- All imports from `@rakuten-rewards/uikit` or `@rakuten-rewards/appshell` only —
  never `@chakra-ui/react`
- Composite section components (Topic components) take priority over hand-built
  primitive layouts
- When using `TextBlockTopic`, background color must go inside `topicData.backgroundProps`
  (e.g. `topicData={{ backgroundProps: { bg: "palette.purple_05", py: { base: "xlarge", medium: "xxlarge" } } }}`),
  not as a flat `background` or `bg` prop directly on the component

---

## Step 6 — Validate before emitting

Before presenting the final code to the engineer, scan it mentally against the loaded
standards. This is a quick self-check, not a lengthy audit — flag and fix anything
that would be an obvious violation:

| Check | What to look for |
|-------|-----------------|
| Raw hex colors | `#` followed by 3 or 6 hex chars in any prop value. Exception: gradient `bg` strings are permitted but must use only the two approved gradient strings documented in `tokens.md` — `linear-gradient(135deg, #e4e0fc 0%, #cfc0ff 100%)` (light) and `linear-gradient(135deg, #8529cd 0%, #480081 100%)` (dark). Any other hex combination in a gradient is a violation. |
| Raw pixel spacing | `px`, `em`, `rem` in *any* sizing prop — `p`, `m`, `gap`, `spacing`, `w`, `h`, `width`, `height`, `size`, `boxSize`, and responsive objects containing these props (e.g. `h={{ base: "140px" }}` is a violation even inside a responsive object) |
| Missing responsive props | Layout props (`templateColumns`, `display`, `py`) as bare strings when they should vary across breakpoints |
| Wrong import source | `from '@chakra-ui/react'` |
| Missed composite | A hand-built `Grid`+`Box` layout where a Topic component would apply — this applies in all modes including `data-first` |

Fix any violations found, then emit the code.

---

## Handling follow-up requests

If the engineer asks to modify or extend the output ("add a FAQ section", "make the
hero darker", "add a loading state"), treat it as a continuation:

- Standards are already loaded — no need to reload
- Apply the same validation pass before emitting the updated code
- If the modification touches a new section type, check whether a different guide
  needs to be loaded (e.g., adding a store carousel when only `tokens.md` was
  previously loaded)
