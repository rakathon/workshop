---
name: forge:validate-messaging
description: >
  Check message and event contracts against the organization's messaging standards and
  enforcement policy. Trigger on: "check my message contracts", "validate my event
  contracts", "does this event contract follow our standards?", "are there issues with
  my messaging spec?", "review my event schema", "is this contract correct?",
  "check these message contracts", "does my event design meet our standards?",
  "what's wrong with my event contract?", "give me feedback on my messaging contracts",
  "are my event contracts compliant?", "validate my Kafka contracts". Reads
  spec/messaging/*.md from the active effort, applies contracts.md / event-design.md /
  versioning.md rules, resolves enforcement severity from policy files (deployable
  override → project override → plugin default), and prints an inline findings report
  grouped by contract. Does NOT write validation/report.md or update state — use
  forge:validate for the phase-gate artifact.
agent-type: worker
argument-hint: "[effort-id]"
arguments: [effort_id]
---

# forge:validate-messaging

Validates all message and event contracts in `spec/messaging/` against the organizational
messaging standards. Produces an inline report grouped by contract. Does not write files
or update workflow state.

This is a Worker skill. It runs as an isolated sub-agent and does not share context
with the main engineer session.

---

## Classification

**Worker** — isolated sub-agent. The main session spawns this worker to validate
messaging contracts. The worker reads files, applies checks, and prints an inline
report. It does not write files or update `.state.json`.

---

## Inputs

| Input | Source |
|-------|--------|
| Effort ID | Argument passed by the engineer, or resolved via standard effort resolution chain |
| `spec/messaging/*.md` | All contract files in the effort directory |
| `standards/messaging/contracts.md` | Relative to this skill file: `../../standards/messaging/contracts.md` |
| `standards/messaging/event-design.md` | Relative to this skill file: `../../standards/messaging/event-design.md` |
| `standards/messaging/versioning.md` | Relative to this skill file: `../../standards/messaging/versioning.md` |
| Enforcement policy | Resolved per Step 1b fallback order |

---

## Worker Steps

### Step 1 — Load the Messaging Standards

Read the messaging standard files using paths relative to this skill file:

- [`../../standards/messaging/contracts.md`](../../standards/messaging/contracts.md) — contract identity, naming, topic/subject, compatibility
- [`../../standards/messaging/event-design.md`](../../standards/messaging/event-design.md) — envelope fields, naming conventions, schema type classification
- [`../../standards/messaging/versioning.md`](../../standards/messaging/versioning.md) — version strategy, migration, breaking change policy

If any standard file is absent, warn for that concern and continue applying the check
guidance in Steps 3–4 for the rules covered by the missing file.

---

### Step 1b — Resolve Enforcement Policies

Each standard may have a companion `.policy.md` that maps rule IDs to enforcement
severity (`blocking` → `[REQUIRED]`, `advisory` → `[SUGGESTION]`). Resolve each policy
independently using this fallback order — stop at the first file found:

1. **Deployable-level override** (if `<deployable_id>` is known from `.state.json`):
   `.forge/deployables/<deployable_id>/policies/messaging/<file>.policy.md`
2. **Project-level override:**
   `.forge/policies/messaging/<file>.policy.md`
3. **Plugin default** (relative to this skill file):
   `../../standards/messaging/<file>.policy.md`

Record which source was used for each standard. When no policy file is found at any
level, treat all rules from that standard as `blocking` and note this in the report
header.

---

### Step 2 — Resolve Effort Directory and Load Contracts

Resolve `<effort_dir>` using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

If no effort is resolved, stop with:
> "Cannot resolve effort. Pass the effort ID as an argument: `forge:validate-messaging <effort-id>`"

Load all `.md` files matching `<effort_dir>/spec/messaging/*.md`.

If no files match, report:
> "No messaging spec found in `<effort_dir>/spec/messaging/`. Run `forge:spec-messaging` first."
Then stop — this is not an error, just an early exit.

---

### Step 3 — Apply Per-Contract Checks

**The standards loaded in Step 1 are the authoritative source of rules; the policies
resolved in Step 1b are the authoritative source of severity.** Apply every rule from
the loaded standard files. For each violation, look up the rule ID in the effective
policy to determine whether to report `[REQUIRED]` (blocking) or `[SUGGESTION]`
(advisory). If no policy was found for a standard, treat all its rules as blocking.
If a rule has no entry in the policy table, treat it as blocking.

The check guidance below is derived from the loaded standards and serves as a
structured reference — it is not exhaustive. Rules present in the loaded standards
but not listed below must still be checked and reported using their policy severity.

For each contract file loaded in Step 2, apply the following checks in order. Use
content scanning: look for keywords, field labels, and patterns anywhere in the
markdown file. Do not require a specific YAML or table format — contracts may be authored
in varied markdown structures.

#### 3a. Contract Naming and Identity (contracts.md R-1, R-2)

| Check | Severity | What to look for |
|-------|----------|------------------|
| Contract name is present | REQUIRED | A `name:` field, or a heading containing the contract name |
| Contract name follows reversed-domain pattern: `<reversed-domain>.<domain>.<subdomain>[.<qualifier>]` (e.g., `com.example.loyalty.points.awarded`) | REQUIRED | At least 3 dot-separated segments; must not be a simple noun or single word |
| Namespace is declared | REQUIRED | A `namespace:` field (e.g., `com.example.loyalty`) — contracts.md R-1 requires all five identity fields: name, namespace, owner, version, compatibility |

#### 3b. Event Naming Convention (event-design.md R-2)

| Check | Severity | What to look for |
|-------|----------|------------------|
| Event name uses past tense for events (e.g., `order.completed`, `points.awarded`) or imperative mood for commands (e.g., `send.confirmation.email`) | REQUIRED | The last segment of the event name should be a past-tense verb (ending in -ed, -d) for events, or a base-form verb for commands. If the last segment is present-tense or ambiguous, flag it. |

#### 3c. Schema Completeness (event-design.md R-1, R-5; contracts.md R-1)

| Check | Severity | What to look for |
|-------|----------|------------------|
| Schema fields are defined | REQUIRED | A schema section, fields table, or field list with at least one field |
| All field names use snake_case | REQUIRED | Field names match `[a-z][a-z0-9_]*`. Flag any field name containing camelCase (mixed case) or kebab-case (hyphen) |
| Standard envelope fields present: `message_id`, `event_name`, `event_version`, `produced_at_ms`, `trace_id` | REQUIRED | All five field names must appear somewhere in the contract document |
| Monetary fields (if present) use amount/precision/currency tuple, not float | REQUIRED | If the contract mentions money, reward, amount, price, or cost: verify no `float` or `double` type appears for a money field |
| Date/timestamp fields (if present) use milliseconds since epoch (int64), not ISO 8601 strings | SUGGESTION | If the contract mentions date, time, or timestamp fields: check that the type is int64/long and field name ends in `_ms`, not a string type |

#### 3c-ii. Message Schema Type Classification (event-design.md R-7, R-8)

When the contract describes events triggered by direct user actions (button press, form
submission, page view, or navigation), check:

| Check | Severity | What to look for |
|-------|----------|------------------|
| User-triggered event uses UserInitiatedMessage schema | REQUIRED | If the event is described as triggered by a user action: verify `client_context` (with device, OS, browser, locale sub-fields), `member`, and `visit_id` fields are present in the schema |

When the contract describes events published by a public API endpoint on behalf of a
client caller, check:

| Check | Severity | What to look for |
|-------|----------|------------------|
| API-published event uses ApiInitiatedMessage schema | REQUIRED | If the event is described as published by an API endpoint handling a client HTTP request: verify `api_context` (with locale, user_agent, client_ip fields) is present in the schema |

If the event is described as a pure backend event (scheduled job, webhook, server-to-server
call with no client HTTP request), the base `Message` schema applies — do not flag these.

#### 3d. Ownership and Consumers (contracts.md R-1, R-7)

| Check | Severity | What to look for |
|-------|----------|------------------|
| Producer identity documented | REQUIRED | A `producer:`, `owner:`, or "produced by" section |
| At least one consumer identified, or consumers explicitly marked "unknown" | REQUIRED | A `consumers:`, `consumer:`, or "consumed by" section. If empty, must say "unknown" — silence is not acceptable |

#### 3e. Delivery Semantics

| Check | Severity | What to look for |
|-------|----------|------------------|
| Ordering guarantee documented | REQUIRED | A section or field stating FIFO, unordered, at-least-once, at-most-once, or equivalent |
| Idempotency approach documented | REQUIRED | A section or field describing how consumers handle duplicate delivery (e.g., deduplicate on `message_id`, idempotent operations, etc.) |

#### 3f. Versioning and Schema Registry (contracts.md R-1, R-3, R-4, R-5; versioning.md R-1, R-3, R-7)

| Check | Severity | What to look for |
|-------|----------|------------------|
| Schema version present (positive integer, e.g., `version: 1`) | REQUIRED | A `version:` field with an integer value ≥ 1 |
| Compatibility mode declared | REQUIRED | A `compatibility:` field. Expected value is `FORWARD_TRANSITIVE` per contracts.md R-5. Any other mode (Backward, Full, None) is accepted but append a note: "Non-standard compatibility mode — ensure justification is documented per contracts.md R-5." |
| Topic name present and includes version suffix (e.g., `loyalty.points.awarded.v1`) | REQUIRED | A `topic:` field whose value ends in `.v<N>` — both the presence of `topic:` and the version suffix are required |
| Subject name present and follows `<contract-name>-v<N>` format | REQUIRED | A `subject:` field whose value ends in `-v<N>` — both the presence of `subject:` and the format are required (contracts.md R-4, R-8) |
| Migration strategy documented (versioning.md R-7) | REQUIRED | For contracts at version > 1, or contracts that mention breaking changes: the migration strategy must be explicitly stated as one of: parallel operation, consumer-first, or producer-first. Merely acknowledging "breaking changes require a new version" is insufficient — the specific rollout strategy must be stated. |

#### 3g. Contract Scope and Event Semantics (contracts.md R-6; event-design.md R-6)

| Check | Severity | What to look for |
|-------|----------|------------------|
| Contract is focused on a single event type (not a broad catch-all) | SUGGESTION | If the contract name ends in `.events` or `.messages` (generic), flag as overly broad per contracts.md R-6 |
| Event is semantic (describes a business fact) rather than a generic CRUD operation | SUGGESTION | Flag event names whose last segment is a generic CRUD verb: `.updated`, `.changed`, `.modified`, `.processed`, `.created` where "created" wraps multiple distinct triggers. A semantic alternative would be `.submitted`, `.approved`, `.declined`, `.awarded`, `.registered`. Generic CRUD events force consumers to inspect the payload to infer meaning — surface this per event-design.md R-6. Do not flag past-tense verbs that are clearly semantic (e.g., `.completed`, `.cancelled`, `.awarded`). |

#### 3h. Consumer Failure Handling (SUGGESTION)

| Check | Severity | What to look for |
|-------|----------|------------------|
| Retry semantics for consumer failure handling | SUGGESTION | If no mention of retry, dead-letter queue, or error handling for consumer failures |

---

### Step 4 — Cross-Contract Checks

After all per-contract checks, perform:

**Duplicate event names:** Collect the contract name (`name:` field, or the primary event
name from the heading) from each contract file. If two or more files declare the same
event name, produce a REQUIRED finding:

```
### Cross-Contract
- [REQUIRED] Duplicate event name "<name>" declared in: <file1.md>, <file2.md>
```

---

### Step 5 — Print Inline Report

Format the report exactly as follows:

```
## Messaging Validation Report
**Standard:** standards/messaging/ (contracts.md, event-design.md, versioning.md)
**Policy:** no policy files found — all rules treated as REQUIRED  ← or "project override" / "deployable override"
**Effort:** <effort-id>
**Contracts checked:** <N>

### <ContractNameOrFileName>
- [REQUIRED] R-1 (contracts): <finding description> (note: <policy note if present>)
- [REQUIRED] R-5 (contracts): <finding description>
- [SUGGESTION] R-6 (event-design): <finding description>

### <NextContractNameOrFileName>
- (no issues found)

### Cross-Contract
- [REQUIRED] <finding if any>
  (omit this section if no cross-contract issues)

---
**Summary:** <X> REQUIRED, <Y> SUGGESTION
**Policy source:** contracts — no policy | event-design — no policy | versioning — no policy
```

Rules:
- Tag each finding with its rule ID and source standard: `R-2 (contracts)`, `R-7 (event-design)`.
- Append policy notes in parentheses when the policy entry has a non-empty Notes field.
- Group findings by contract file. Use the contract `name:` value as the heading if
  present; otherwise use the filename without extension.
- If a contract has no findings, print `- (no issues found)` under its heading.
- Omit the Cross-Contract section if no cross-contract issues exist.
- The Summary line always appears and counts totals across all contracts.
- REQUIRED findings must appear before SUGGESTION findings within each group.

---

### Step 6 — Explicit No-Write Prohibition

Do NOT:
- Write or modify any file in the effort directory.
- Write or modify `validation/report.md`.
- Update `.state.json`.
- Create any file anywhere on the filesystem.

The entire output of this skill is the inline report printed in Step 5.
If the engineer asks you to "save the report" or "write the findings", respond:
> "`forge:validate-messaging` is an inline editing aid and does not write files.
> Copy the report from the session if you need to preserve it."

---

## Output

Inline session report only. No files written. No state updated.

Example output for a contract with issues:

```
## Messaging Validation Report
**Standard:** standards/messaging/ (contracts.md, event-design.md, versioning.md)
**Policy:** no policy files found — all rules treated as REQUIRED
**Effort:** my-feature
**Contracts checked:** 2

### com.example.loyalty.points.awarded
- [REQUIRED] R-1 (contracts): Namespace not declared — all five identity fields required: name, namespace, owner, version, compatibility
- [REQUIRED] R-1 (contracts): Idempotency approach not documented
- [REQUIRED] R-5 (contracts): Compatibility mode not declared (expected FORWARD_TRANSITIVE unless justified)
- [REQUIRED] R-3 (contracts): Topic name missing version suffix (expected: loyalty.points.awarded.v1)
- [REQUIRED] R-4 (contracts): Subject field absent — required for schema registry pre-registration
- [SUGGESTION] (no policy): Consider adding retry semantics for consumer failure handling

### com.example.loyalty.tier.upgraded
- (no issues found)

---
**Summary:** 5 REQUIRED, 1 SUGGESTION
**Policy source:** contracts — no policy | event-design — no policy | versioning — no policy
```
