# Order Update Event

## Contract

```yaml
name: order.update
version: 1
owner: order-service
topic: orders.updates
```

## Schema

| Field | Type | Description |
|-------|------|-------------|
| orderId | string | The order identifier |
| memberId | string | Member ID |
| orderAmount | float | Total order value in dollars |
| updatedAt | string | ISO 8601 timestamp |

## Producer

order-service publishes this when an order changes.
