# com.example.loyalty.points.awarded

## Identity

```yaml
name: com.example.loyalty.points.awarded
namespace: com.example.loyalty
version: 1
owner: loyalty-service
compatibility: FORWARD_TRANSITIVE
topic: loyalty.points.awarded.v1
subject: com.example.loyalty.points.awarded-v1
```

## Producer

**loyalty-service** — publishes this event after points are credited to a member account.

## Consumers

- **notifications-service** — sends a push notification to the member
- **analytics-service** — records the points award for reporting

## Schema

| Field | Type | Description |
|-------|------|-------------|
| message_id | string (UUID) | Unique identifier for this message instance |
| event_name | string | Contract name |
| event_version | int32 | Contract version |
| produced_at_ms | int64 | Producer timestamp in milliseconds since epoch |
| trace_id | string | Distributed trace ID |
| member_id | string | The member receiving the points |
| points_awarded | int64 | Number of points credited |
| transaction_id | string | The originating transaction |
| awarded_at_ms | int64 | Timestamp of the award in milliseconds since epoch |

## Ordering

Unordered — consumers must not assume delivery order. Events are idempotent by `message_id`.

## Idempotency

Consumers deduplicate on `message_id`. Processing the same `message_id` twice produces no side effect — the points award is looked up by `transaction_id` and skipped if already applied.

## Breaking Change Policy

FORWARD_TRANSITIVE compatibility is declared. Non-breaking additions (optional fields with defaults) do not require a version increment. Breaking changes (field removal, type change) require incrementing the topic version and running old and new topics in parallel (parallel operation strategy) during a minimum 90-day migration window.
