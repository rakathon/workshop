# com.example.member.member.registered

## Identity

```yaml
name: com.example.member.member.registered
namespace: com.example.member
version: 1
owner: member-service
compatibility: FORWARD_TRANSITIVE
topic: member.member.registered.v1
subject: com.example.member.member.registered-v1
```

## Producer

**member-service** — publishes when a new member completes registration.

## Consumers

- **email-service** — sends welcome email
- **analytics-service** — records new member acquisition

## Schema

| Field | Type | Description |
|-------|------|-------------|
| message_id | string (UUID) | Unique identifier |
| event_name | string | Contract name |
| event_version | int32 | Contract version |
| produced_at_ms | int64 | Timestamp ms since epoch |
| trace_id | string | Trace correlation ID |
| member_id | string | New member identifier |
| email | string | Member email address |
| registered_at_ms | int64 | Registration timestamp ms since epoch |

## Ordering

Unordered — each registration event is independent.

## Idempotency

Consumers deduplicate on `message_id`. Email send is guarded by `message_id` idempotency key in the email service.

## Breaking Change Policy

FORWARD_TRANSITIVE. Breaking changes use parallel topic operation strategy.
