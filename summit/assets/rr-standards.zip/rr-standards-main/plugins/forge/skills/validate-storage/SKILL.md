---
name: forge:validate-storage
description: >
  Targeted validation of spec/storage/*.md against the applicable organizational
  storage standard. An inline editing aid for use during storage schema authoring —
  provides immediate standards feedback without writing gate artifacts. Not a
  substitute for forge:validate. Use during or immediately after forge:spec-storage
  to catch standard violations early, when reviewing an existing schema for compliance
  before promoting a discovery phase, or when making schema changes that may affect PII
  obligations or index design. Not a gate: does not write validation/report.md and does
  not replace forge:validate. Accepts --storage-spec <path> (file or directory) to
  validate a specific location, or --effort-id <id> to target a named effort. When
  invoked as a Worker sub-agent, the orchestrator must pass --effort-id explicitly.
agent-type: worker
argument-hint: "[--storage-spec <path>] [--effort-id <id>]"
---

# forge:validate-storage

Validates storage schema files in `spec/storage/` against the applicable organizational
storage standard. Produces an inline session report grouped by entity, with REQUIRED
and SUGGESTION findings. Runs as an isolated worker — produces no file output and makes
no state changes.

This is a Worker skill. It runs as an isolated sub-agent and does not share context
with the main engineer session.

---

## Arguments

| Argument | Description |
|----------|-------------|
| `--storage-spec <path>` | Path to a specific storage spec file or directory to validate. When a directory is given, all `.md` and `.sql` files inside it are validated. |
| `--effort-id <id>` | Effort ID to target. Resolves `<storage_dir>` to `.forge/efforts/<id>/spec/storage/`. |

Both arguments are optional. Providing **both** is an error (see Step 1).

---

## Variables

- `<effort_dir>` — `.forge/efforts/<effort-id>/` when a formal Forge effort is active
- `<storage_dir>` — resolved in Step 1
- `<plugin_root>` — the Forge plugin root, resolved via `plugins/forge/skills/common/plugin-root.md`

---

## Step 1: Resolve Storage Location

**Mutual-exclusion check:** If both `--storage-spec` and `--effort-id` are provided, stop:

```
Error: --storage-spec and --effort-id are mutually exclusive.

Usage:
  forge:validate-storage                          # auto-resolve effort via standard chain
  forge:validate-storage --effort-id <id>         # target a named effort
  forge:validate-storage --storage-spec <path>    # validate a specific file or directory
```

**If `--storage-spec` is provided:**
- If `<path>` is a file: set `<storage_dir>` to the file's parent directory; validate only that file in Step 2.
- If `<path>` is a directory: set `<storage_dir>` to `<path>`; validate all `.md` and `.sql` files in it.
- If `<path>` does not exist: stop with `"Error: path '<path>' not found."`.
- Omit the `**Effort:**` line from the report (see Step 6).

**If `--effort-id` is provided:**
- Verify `.forge/efforts/<id>/` exists. If not, stop: `"Effort '<id>' not found. Check .forge/efforts/README.md for valid effort IDs."`
- Set `<effort_dir>` = `.forge/efforts/<id>/` and `<storage_dir>` = `<effort_dir>/spec/storage/`.

**If neither argument is provided:**
- Resolve the active effort using the standard chain defined in:
    `plugins/forge/skills/common/effort-resolution.md`
  Skill category: effort-optional
- If an effort is resolved: set `<effort_dir>` and `<storage_dir>` from it.
- If no effort is resolved: set `<storage_dir>` = `spec/storage/` in the current working directory; omit the `**Effort:**` line from the report.

---

## Step 2: Locate Files and Detect Storage Technology

When `--storage-spec` was given as a file, the target file list is already known — skip
the directory scan and proceed directly to technology detection for that file.

Otherwise, locate all storage spec files in `<storage_dir>`:

```bash
ls <storage_dir>/*.md 2>/dev/null
ls <storage_dir>/*.sql 2>/dev/null
```

**If no files are found**, output:
```
No storage spec found in <storage_dir>.
Run forge:spec-storage first to create storage schema files.
```
Then stop — do not proceed.

Also load for context (if present — do not error if absent):
- `<storage_dir>/logical-schema.md` — entity-relationship model
- `<storage_dir>/query-patterns.md` — access patterns for index cross-referencing

For each file found (excluding `logical-schema.md` and `query-patterns.md`), determine
the storage technology using the filename:

| Filename pattern | Technology | Standard file |
|-----------------|------------|---------------|
| `postgres.sql`, `postgres.md`, `postgresql.md` | PostgreSQL | `standards/storage/postgresql.md` |
| `dynamo.md`, `dynamodb.md` | DynamoDB | `standards/storage/dynamodb.md` |
| `redis.md` | Redis | `standards/storage/redis.md` |
| `opensearch.md`, `elasticsearch.md` | OpenSearch | `standards/storage/opensearch.md` |
| `extension-storage.md` | Browser Extension Storage | `standards/storage/extension-storage.md` |

**If a filename matches none of the above**, list the unmatched files and ask:
```
Could not detect storage technology for: <filename>
What technology does this file describe?
  1. PostgreSQL
  2. DynamoDB
  3. Redis
  4. OpenSearch
  5. Browser Extension Storage
  6. Other (skip this file)
```
Wait for the engineer's response before continuing.

**Load the standard:**

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record: `plugin_root`.

If the manifest cannot be read, stop with:
> "The Forge plugin does not appear to be installed or the manifest is missing.
> Try reinstalling the plugin."

Load the standard at:

```
<plugin_root>/standards/storage/<type>.md
```

If the standard file does not exist at that path, warn and continue:
```
Warning: Standard file not found at <plugin_root>/standards/storage/<type>.md.
Applying general checks only for <filename>.
```

---

## Step 3: Apply Common Schema Checks Per Entity

Read each physical schema file. For `.sql` files, parse `CREATE TABLE` statements to
identify entities (tables). For `.md` files, parse markdown table rows or section
headings to identify entities.

For each entity or item type, apply:

### Check C1: Primary Key Defined

- **PostgreSQL**: Look for `PRIMARY KEY` constraint.
- **DynamoDB**: Look for `PK` (partition key) attribute definition.
- **Redis**: Verify a key naming pattern is specified.
- **OpenSearch**: Verify `_id` or document ID strategy is documented.

**If absent**: flag as `[REQUIRED] No primary key defined for entity <name>`.

### Check C2: All Fields Have Explicit Types

Scan each field/attribute definition for a type annotation.

- **PostgreSQL**: Each column must have a SQL type (e.g., `TEXT`, `UUID`, `TIMESTAMPTZ`).
- **DynamoDB**: Each attribute must have a type listed (e.g., `String`, `Number`, `Boolean`).
- **Redis**: Each hash field or value must have a documented type.
- **OpenSearch**: Each field in the mapping must have a `type` property.

**If any field lacks a type**: flag as `[REQUIRED] Field '<field>' in <entity> has no type defined`.

### Check C3: Soft-Delete Policy Documented

**For `.sql` files (DDL format):** Look for:
- A `deleted_at` column in the `CREATE TABLE` statement, OR
- A SQL comment containing "soft delete", "hard delete", or "deletion" near the table.

**For `.md` files:** Look for:
- A `deleted_at` field row in the schema table, OR
- An explicit policy statement: "records are hard-deleted", "hard delete", or "soft delete".

Note: "TTL handles deletion" is **not** an acceptable PostgreSQL or DynamoDB soft-delete
policy — TTL is a Redis/DynamoDB expiry concept, not a relational deletion strategy.
It remains acceptable only for Redis and OpenSearch key expiry documentation.

**If neither is present**: flag as
`[REQUIRED] No soft-delete policy documented for entity <name>. Add a deleted_at field or document the deletion approach (hard delete or soft delete).`

### Check C4: Indexes Are Query-Driven (if query-patterns.md is present)

Load `<storage_dir>/query-patterns.md` if it exists. If it is absent, skip this check
and surface it in the report summary as a skipped check (see Step 5).

**Unused indexes:** For each index defined in the schema, check whether a query pattern
in `query-patterns.md` justifies it. If no pattern matches:
flag as `[SUGGESTION] Index <name> on <entity> has no corresponding query pattern in query-patterns.md`.

**Unsupported patterns:** For each query pattern in `query-patterns.md`, verify that
a primary key, index, or key design supports it. If no supporting structure exists:
flag as `[REQUIRED] Query pattern '<pattern>' in query-patterns.md has no supporting index or key design`.

---

## Step 4: Apply PII Annotation Checks

Identify PII fields using the default detection list plus any explicit PII annotations.

**Default PII field names** — match these as **exact full field names** (case-insensitive),
not as substrings or suffixes. For example, `product_name` and `category_name` do NOT
match — only a field literally named `name` matches the bare `name` entry:

`email`, `name`, `first_name`, `last_name`, `full_name`, `phone`, `phone_number`, `dob`,
`date_of_birth`, `address`, `street`, `postal_code`, `zip_code`, `ip_address`,
`device_id`, `ssn`, `tax_id`, `credit_card`, `card_number`, `account_number`,
`gender`, `nationality`

**Important:** `name` triggers only on an exact field name match. Fields like
`product_name`, `category_name`, `display_name` do NOT trigger PII detection.
`first_name`, `last_name`, and `full_name` are separate entries that do trigger.

Also treat as PII: any field with a `_pii` suffix, any field with a comment or
annotation marking it as personal data.

**For each PII field found**, check:

### Check P1: Retention Period Documented

Look for a comment near the field or table that specifies retention duration
(e.g., `Retention: 7 years`, `retain for 3 years`, `7yr retention`).

**PostgreSQL example of compliant pattern:**
```sql
-- GDPR: Contains PII (email, first_name). Retention: 7 years. Deletion: anonymise on request.
CREATE TABLE members (
  email TEXT NOT NULL,
  first_name TEXT NOT NULL,
  ...
);
```

**DynamoDB example of compliant pattern:**
```
## Table: Members
<!-- GDPR: email is PII. Retention: 7 years. Deletion: anonymise on request. -->
```

**Redis example of compliant pattern:**
```
## Key: session:<user_id>
<!-- GDPR: Contains user_id (PII reference). Retention: TTL 24h. Deletion: expires automatically. -->
```

**OpenSearch example of compliant pattern:**
```json
{
  "_meta": {
    "gdpr": "Contains email (PII). Retention: 7 years. Deletion: anonymise on account closure."
  }
}
```

**If retention period is absent**: flag as
`[REQUIRED] Field '<field>' in <entity> appears to be PII — retention period not documented.
Add a GDPR comment: "Retention: <period>"`

### Check P2: Deletion Obligation Documented

Look for a comment near the field or table that specifies the deletion approach
(e.g., `Deletion: anonymise on request`, `hard delete on account closure`,
`deleted via TTL`).

**If deletion obligation is absent**: flag as
`[REQUIRED] Field '<field>' in <entity> appears to be PII — deletion obligation not documented.
Add a GDPR comment: "Deletion: <obligation>"`

---

## Step 5: Apply Technology-Specific Checks

Apply the checks below for the detected storage technology. These are derived from
the applicable organizational standard.

### PostgreSQL Checks

**PG-1: Timestamp fields use TIMESTAMPTZ**

Scan all column definitions for timestamp-related columns. Any column with a type of
`TIMESTAMP`, `DATETIME`, or `TIMESTAMP WITHOUT TIME ZONE` that is not `TIMESTAMPTZ`
should be flagged:
`[REQUIRED] Column '<col>' in <table> uses <type> — use TIMESTAMPTZ to avoid timezone ambiguity`

**PG-2: Composite primary key justification**

If a table uses a composite primary key (multiple columns in the `PRIMARY KEY` constraint),
check for a comment explaining why (e.g., `-- Composite PK: junction table`).
If no justification comment is present:
`[SUGGESTION] <table> uses a composite primary key — add a comment explaining why a surrogate UUID is not used`

**PG-3: Index naming convention**

Check that indexes follow the pattern `idx_<table>_<column(s)>`. Indexes named with other
patterns (e.g., just the column name, or without the table prefix):
`[SUGGESTION] Index '<name>' does not follow naming convention idx_<table>_<column> — rename for clarity`

**PG-4: UUID primary keys preferred**

If a table uses a serial, integer, or bigint primary key, flag as:
`[SUGGESTION] Table '<table>' uses a serial/integer primary key — prefer UUID (gen_random_uuid()) for distributed safety`

---

### DynamoDB Checks

**DY-1: entity_type field required**

Every item type definition must include an `entity_type` attribute (String, uppercase
snake_case value, e.g., `USER_PROFILE`).
`[REQUIRED] Item type '<name>' is missing the entity_type field — required by the DynamoDB standard`

**DY-2: schema_version field required**

Every item type definition must include a `schema_version` attribute (Number).
`[REQUIRED] Item type '<name>' is missing the schema_version field — required for schema evolution`

**DY-3: Partition key defined with access-pattern justification**

The PK design should be documented with the access pattern it supports
(e.g., `PK: USER#<user_id> — supports GetItem by user_id`). If no justification
comment is present:
`[SUGGESTION] Partition key for '<name>' has no documented access-pattern justification — add a note describing the access pattern it supports`

**DY-4: Sort key for entities with relationships**

If the logical schema (logical-schema.md) indicates a one-to-many or many-to-many
relationship for an entity, verify that a sort key (SK) is defined in the physical schema.
`[SUGGESTION] Entity '<name>' has relationships in the logical schema but no sort key is defined — consider SK for hierarchical queries`

**DY-5: Attribute names are snake_case**

All attribute names must use snake_case (lowercase with underscores).
Any attribute with camelCase, PascalCase, or mixed casing:
`[REQUIRED] Attribute '<attr>' in '<name>' must use snake_case per the DynamoDB standard`

**DY-6: Timestamp fields use ISO-8601**

Timestamp attributes must document the format. Compliant annotation contains
`ISO-8601 (UTC)` (or equivalent notation) in the `Role`, `Notes`, or type column
of the markdown schema table, or as a SQL/DDL comment for `.sql` files.
If a timestamp attribute has no format annotation:
`[REQUIRED] Timestamp attribute '<attr>' in '<name>' must document the format — add "ISO-8601 (UTC)" in the Notes or Role column`

**DY-7: GSI count**

Count the number of GSIs defined across all item types in the table.
- If > 10: `[SUGGESTION] <N> GSIs defined — consider consolidating to reduce cost and complexity`
- If > 20: `[REQUIRED] <N> GSIs defined — DynamoDB hard limit is 20 per table`

---

### Redis Checks

**RD-1: Key naming pattern documented**

The schema file must document a key naming pattern for each key type
(e.g., `session:<user_id>`, `cache:product:<id>`).
`[REQUIRED] Key type '<name>' has no naming pattern documented — add a pattern like "session:<user_id>"`

**RD-2: TTL documented for session/token/cache keys**

A key is considered a session/cache key if its name or description contains any of:
`session`, `token`, `auth`, `cache`, `tmp`, `temp`, or if it is described as
"expires", "short-lived", or "temporary".

For any key matching these indicators, verify that a TTL is documented.
`[REQUIRED] Key type '<name>' is a session/token/cache — TTL not documented`

**RD-3: Data structure type specified**

Each key definition must specify the Redis data structure used:
String, Hash, List, Set, or Sorted Set.
`[REQUIRED] Key type '<name>' does not specify the Redis data structure (String, Hash, List, Set, Sorted Set)`

---

### OpenSearch Checks

**OS-1: Field types defined in mapping**

Each field in the index mapping must have an explicit `type` (e.g., `keyword`, `text`,
`date`, `integer`, `boolean`).
`[REQUIRED] Field '<field>' in index '<index>' has no type defined in the mapping`

**OS-2: Analyzer documented for text search fields**

Fields of type `text` that are used for full-text search should have an analyzer
documented (e.g., `standard`, `english`, `custom`).
`[SUGGESTION] Text field '<field>' in '<index>' used for search — document the analyzer configuration`

**OS-3: Index name pattern**

Index names should follow the pattern `<service>-<entity>-<env>` (e.g., `rewards-products-prod`).
`[SUGGESTION] Index '<name>' does not follow naming convention <service>-<entity>-<env>`

---

### Browser Extension Storage Checks

**BE-1: Keys are namespaced**

All storage key names must be prefixed by a feature or module name, separated by `:` or `-`
(e.g., `auth:token`, `prefs:theme`, `cache:api:users`).

**Exempt from this check:** keys starting with `_` (underscore) are meta keys
(e.g., `_version`) and do not require a feature namespace prefix.

`[REQUIRED] Key '<key>' is not namespaced — prefix with a feature/module name (e.g., 'auth:<key>')`

**BE-2: Schema version documented**

The schema should include a `_version` key to enable migration tracking.
`[SUGGESTION] No schema version key (_version) documented — add to support future migrations`

**BE-3: Sensitive data encryption noted**

Any key storing tokens, credentials, API keys, or passwords must have a comment or
note stating that the data is encrypted before storage.
`[REQUIRED] Key '<key>' stores sensitive data — document that it is encrypted before storage`

---

## Step 6: Print Inline Report

After completing all checks for all schema files, print the validation report to the
session. Use the format below exactly.

When a formal effort was found, include the `**Effort:**` line. When no effort was found
(effort-less invocation), replace it with `**Location:** spec/storage/`.

```
## Storage Validation Report
**Effort:** <effort-id>
**Date:** <YYYY-MM-DD>

---

### File: spec/storage/<filename> (<Technology>)
**Standard applied:** standards/storage/<type>.md

#### Entity: <EntityName>

- [REQUIRED] <finding description>
- [REQUIRED] <finding description>
- [SUGGESTION] <finding description>

#### Entity: <AnotherEntity>

- [REQUIRED] <finding description>

---

### File: spec/storage/<another-file> (<Technology>)
**Standard applied:** standards/storage/<type>.md

#### Entity: <EntityName>

- No issues found.

---

## Summary

| Severity | Count |
|----------|-------|
| REQUIRED | N |
| SUGGESTION | M |

**Checks skipped:** <list any checks skipped due to absent files, e.g., "C4 index cross-referencing (query-patterns.md not found)">

**REQUIRED** findings must be resolved before discovery is approved.
**SUGGESTION** findings are recommended improvements — resolve or explicitly accept them.

Run forge:validate-storage again after making changes.
```

**If all checks pass with no findings:**
```
## Storage Validation Report
**Effort:** <effort-id>
**Date:** <YYYY-MM-DD>

All storage schema checks passed. No REQUIRED or SUGGESTION findings.

**Checks skipped:** <list any skipped checks, or omit this line if none>

Run forge:validate to perform the full discovery validation.
```

**If no effort was found** (effort-less invocation), replace `**Effort:** <effort-id>` with
`**Location:** spec/storage/` in both report variants above.

---

## Constraints

The following actions are **strictly prohibited**:

1. **Do NOT write to `validation/report.md`** — that file is owned exclusively by `forge:validate`.
2. **Do NOT modify `.state.json`** — phase state is managed by `forge:promote`.
3. **Do NOT write any other file** — all output is inline session content only.
4. **Do NOT run tests or lint** — `forge:validate-storage` reads and reports only.

Violating these constraints corrupts the workflow gate. Multiple invocations of
`forge:validate-storage` must be safe and produce no file-system side effects.

---

## Error Handling

| Condition | Action |
|-----------|--------|
| `spec/storage/` is absent or empty | Report "No storage spec found" and stop |
| Filename not recognized | Ask engineer for technology before continuing |
| Standard file not found in plugin | Warn; apply general checks; continue |
| `logical-schema.md` absent | Skip entity relationship cross-referencing; note it |
| `query-patterns.md` absent | Skip index cross-referencing (C4); surface as "Checks skipped" in report |
| File is not parseable as a schema | Note parsing failure; skip that file; continue with others |
