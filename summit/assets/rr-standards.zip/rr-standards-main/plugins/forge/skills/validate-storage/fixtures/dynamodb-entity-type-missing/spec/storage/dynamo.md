# DynamoDB Schema: UserProfiles Table

## Table: UserProfiles

Single-table design. All item types stored in `UserProfiles`.

## Item Type: UserProfile

| Attribute    | Type   | Role | Notes                  |
|-------------|--------|------|------------------------|
| PK          | String | PK   | USER#<user_id>         |
| SK          | String | SK   | PROFILE                |
| user_id     | String | Data | UUID                   |
| display_name| String | Data |                        |
| created_at  | String | Data |                        |
| updated_at  | String | Data |                        |

## GSIs

None defined.
