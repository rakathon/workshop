# Business Requirements — no-storage-spec

## BR-1: Test fixture for missing spec/storage directory

This fixture intentionally has no spec/storage/ directory to test
that forge:validate-storage reports a clear error and stops.
