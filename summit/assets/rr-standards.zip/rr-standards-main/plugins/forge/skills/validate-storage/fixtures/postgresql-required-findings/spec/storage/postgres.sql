-- Members table
CREATE TABLE members (
  id SERIAL PRIMARY KEY,
  email TEXT NOT NULL,
  first_name TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE INDEX idx_email ON members (email);
