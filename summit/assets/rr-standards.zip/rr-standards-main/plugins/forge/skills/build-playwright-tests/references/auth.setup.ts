import { test as setup, expect } from '@playwright/test';
import environments from '../../config/environments.json';
import path from 'path';

// Auth state file paths — one per user type per region
export const AUTH_FILES = {
  'canada-regular': path.join('.auth', 'canada-regular.json'),
  'usa-regular':    path.join('.auth', 'usa-regular.json'),
  'usa-amex':       path.join('.auth', 'usa-amex.json'),
  'usa-bilt':       path.join('.auth', 'usa-bilt.json'),
  'uk-regular':     path.join('.auth', 'uk-regular.json'),
  'uk-tcpp':        path.join('.auth', 'uk-tcpp.json'),
};

const envs = environments.environments as Record<string, string>;

// ── Canada Regular ────────────────────────────────────────────────────────────
setup('login: canada-regular', async ({ page }) => {
  const baseUrl = envs[process.env.TEST_ENV ?? 'canada-prod'];
  const email    = process.env.CA_REGULAR_EMAIL!;
  const password = process.env.CA_REGULAR_PASSWORD!;

  if (!email || !password) throw new Error('CA_REGULAR_EMAIL / CA_REGULAR_PASSWORD not set in .env');

  await page.goto(baseUrl);

  // MCP discovered: Sign In opens a sidebar form — no page navigation, URL stays same
  await page.locator('#header-main').getByRole('link', { name: 'Sign In' }).click();

  // Wait for the login form to appear (sidebar, not a new page)
  await expect(page.getByPlaceholder('Email')).toBeVisible({ timeout: 10000 });

  await page.getByPlaceholder('Email').fill(email);
  await page.getByPlaceholder('Password').fill(password);
  await page.getByRole('button', { name: 'Log in' }).click();

  // Wait for logged-in: Sign In link disappears from header
  await expect(page.locator('#header-main').getByRole('link', { name: 'Sign In' })).not.toBeVisible({ timeout: 15000 });
  await page.waitForLoadState('networkidle');

  await page.context().storageState({ path: AUTH_FILES['canada-regular'] });
});

// ── USA Regular ───────────────────────────────────────────────────────────────
setup('login: usa-regular', async ({ page }) => {
  const baseUrl  = envs[process.env.TEST_ENV ?? 'usa-prod'];
  const email    = process.env.US_REGULAR_EMAIL!;
  const password = process.env.US_REGULAR_PASSWORD!;

  if (!email || !password) throw new Error('US_REGULAR_EMAIL / US_REGULAR_PASSWORD not set in .env');

  await page.goto(baseUrl);
  await expect(page).toHaveURL(/rakuten/);

  // Click Sign In — USA opens iframe modal
  await page.locator('xpath=//button[normalize-space()="Sign In"]').click();
  await page.waitForSelector('iframe#appshell-auth-modal-iframe', { timeout: 10000 });

  const loginFrame = page.frameLocator('iframe#appshell-auth-modal-iframe');
  await loginFrame.locator('xpath=//input[@id="emailAddress"]').fill(email);
  await loginFrame.locator('xpath=//input[@id="password"]').fill(password);
  await loginFrame.locator('xpath=//button[@id="email-auth-btn"]').click();

  // Wait for logged-in indicator
  await expect(page.locator('xpath=//a[contains(@id,"$")]')).toBeVisible({ timeout: 15000 });

  await page.context().storageState({ path: AUTH_FILES['usa-regular'] });
});

// ── USA Amex ──────────────────────────────────────────────────────────────────
setup('login: usa-amex', async ({ page }) => {
  const baseUrl  = envs[process.env.TEST_ENV ?? 'usa-prod'];
  const email    = process.env.US_AMEX_EMAIL!;
  const password = process.env.US_AMEX_PASSWORD!;

  if (!email || !password) throw new Error('US_AMEX_EMAIL / US_AMEX_PASSWORD not set in .env');

  await page.goto(baseUrl);

  await page.locator('xpath=//button[normalize-space()="Sign In"]').click();
  await page.waitForSelector('iframe#appshell-auth-modal-iframe', { timeout: 10000 });

  const loginFrame = page.frameLocator('iframe#appshell-auth-modal-iframe');
  await loginFrame.locator('xpath=//input[@id="emailAddress"]').fill(email);
  await loginFrame.locator('xpath=//input[@id="password"]').fill(password);
  await loginFrame.locator('xpath=//button[@id="email-auth-btn"]').click();

  await expect(page.locator('xpath=//a[contains(@id,"$")]')).toBeVisible({ timeout: 15000 });

  await page.context().storageState({ path: AUTH_FILES['usa-amex'] });
});

// ── UK Regular ───────────────────────────────────────────────────────────────
setup('login: uk-regular', async ({ page }) => {
  const baseUrl  = envs[process.env.TEST_ENV ?? 'uk-prod'];
  const email    = process.env.UK_REGULAR_EMAIL!;
  const password = process.env.UK_REGULAR_PASSWORD!;

  if (!email || !password) throw new Error('UK_REGULAR_EMAIL / UK_REGULAR_PASSWORD not set in .env');

  await page.goto(baseUrl, { extraHTTPHeaders: { 'rrcountry': 'gb' } });

  // UK uses the same AppShell auth iframe as US
  await page.locator('xpath=//button[normalize-space()="Sign In"]').click();
  await page.waitForSelector('iframe#appshell-auth-modal-iframe', { timeout: 10000 });

  const loginFrame = page.frameLocator('iframe#appshell-auth-modal-iframe');
  await loginFrame.locator('xpath=//input[@id="emailAddress"]').fill(email);
  await loginFrame.locator('xpath=//input[@id="password"]').fill(password);
  await loginFrame.locator('xpath=//button[@id="email-auth-btn"]').click();

  await expect(page.locator('xpath=//a[contains(@id,"$")]')).toBeVisible({ timeout: 15000 });

  await page.context().storageState({ path: AUTH_FILES['uk-regular'] });
});

// ── UK TCPP (user with pending TCPP — must be provisioned via MAIT) ───────────
setup('login: uk-tcpp', async ({ page }) => {
  const baseUrl  = envs[process.env.TEST_ENV ?? 'uk-qa1'];
  const email    = process.env.UK_TCPP_EMAIL!;
  const password = process.env.UK_TCPP_PASSWORD!;

  if (!email || !password) throw new Error('UK_TCPP_EMAIL / UK_TCPP_PASSWORD not set in .env — provision a pending-TCPP user via MAIT first');

  await page.goto(baseUrl, { extraHTTPHeaders: { 'rrcountry': 'gb' } });

  await page.locator('xpath=//button[normalize-space()="Sign In"]').click();
  await page.waitForSelector('iframe#appshell-auth-modal-iframe', { timeout: 10000 });

  const loginFrame = page.frameLocator('iframe#appshell-auth-modal-iframe');
  await loginFrame.locator('xpath=//input[@id="emailAddress"]').fill(email);
  await loginFrame.locator('xpath=//input[@id="password"]').fill(password);
  await loginFrame.locator('xpath=//button[@id="email-auth-btn"]').click();

  await expect(page.locator('xpath=//a[contains(@id,"$")]')).toBeVisible({ timeout: 15000 });

  await page.context().storageState({ path: AUTH_FILES['uk-tcpp'] });
});

// ── USA Bilt ──────────────────────────────────────────────────────────────────
setup('login: usa-bilt', async ({ page }) => {
  const baseUrl  = envs[process.env.TEST_ENV ?? 'usa-prod'];
  const email    = process.env.US_BILT_EMAIL!;
  const password = process.env.US_BILT_PASSWORD!;

  if (!email || !password) throw new Error('US_BILT_EMAIL / US_BILT_PASSWORD not set in .env');

  await page.goto(baseUrl);

  await page.locator('xpath=//button[normalize-space()="Sign In"]').click();
  await page.waitForSelector('iframe#appshell-auth-modal-iframe', { timeout: 10000 });

  const loginFrame = page.frameLocator('iframe#appshell-auth-modal-iframe');
  await loginFrame.locator('xpath=//input[@id="emailAddress"]').fill(email);
  await loginFrame.locator('xpath=//input[@id="password"]').fill(password);
  await loginFrame.locator('xpath=//button[@id="email-auth-btn"]').click();

  await expect(page.locator('xpath=//a[contains(@id,"$")]')).toBeVisible({ timeout: 15000 });

  await page.context().storageState({ path: AUTH_FILES['usa-bilt'] });
});
