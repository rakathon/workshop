---
name: forge:build-playwright-tests
description: Full UI test lifecycle — scaffold repo if needed, MCP setup, detect input (BDD feature file), generate Playwright spec with live browser selector discovery, run, fix, validate, and report. Works in the forge pipeline (after forge:spec-ui-e2e or forge:browserstack-to-bdd produces .feature files) or standalone. Supports --fix flag to only fix failing tests. Trigger on: "build playwright tests", "generate playwright specs", "implement feature files", "write playwright code", "convert feature files to playwright", "run and fix tests", "I have .feature files, generate the specs", "feature files are ready now write the tests", or when a task in plan/tasks.md has type playwright-test. Also trigger when an engineer says the .feature files exist and wants the Playwright specs built.
agent-type: inline
---

# forge:build-playwright-tests

Full UI test lifecycle in one command:
**scaffold → MCP setup → detect input → generate spec → run → fix → validate → report**

**Position in the forge pipeline:**
```
forge:spec-ui-e2e          ← generates .feature files from ui-e2e-test-suite.md
forge:browserstack-to-bdd  ← generates .feature files from BrowserStack TCs
         ↓
forge:build-playwright-tests  ← THIS SKILL — .feature files → .spec.ts → run → fix
         ↓
forge:ui-tests-validate    ← verify spec correctness
forge:ui-tests-run         ← run existing specs
forge:ui-tests-fix         ← fix broken selectors
```

**Playwright MCP is not optional. Stop and fix it before doing anything else.**

**Command:**
```
forge:build-playwright-tests [feature-area|region] [test-id] [--fix]
```

---

## Arguments

- **First arg** (optional): feature area (`signup-login`, `shopping-trip`, `appshell` etc.) or region (`ca`, `us`, `uk`). If omitted, process all.
- **Second arg = test ID** (optional): e.g. `TC-72162`, `AS-01`. If omitted, process all missing tests.
- **`--fix` flag**: skip generation — only fix already-generated failing tests.

**Feature area / test ID auto-detection** (when no args given):
Search `features/` recursively — first match wins. Region comes from the `@env-tag` inside the `.feature` file, not the folder name.

---

## Step 0a: Scaffold Repo (if needed)

**Check if `config/environments.json` exists.**

If it exists → skip to Step 0b.

If it does NOT exist → this is a fresh repo. Do the following:

1. Write all files defined in `references/scaffold-template.md`
2. Copy the pre-built scripts using Bash (do NOT read their contents):
```bash
cp <plugin_root>/references/validate.js scripts/validate.js
cp <plugin_root>/references/auth.setup.ts tests/setup/auth.setup.ts
```
3. Run install commands from `references/scaffold-template.md`
4. Tell the user:
```
✅ Repo scaffolded. Fill in .env with your credentials before running tests.
```

> `<plugin_root>` is the path to this skill's directory — resolve it the same way other forge skills do via `plugins/forge/skills/common/plugin-root.md`.

---

## Step 0b: Verify Playwright MCP (MANDATORY)

Before reading any file or writing any code, confirm MCP is alive:

```
Use mcp__playwright__browser_navigate to go to https://www.rakuten.com/
```

**If it succeeds** → continue to Step 1.

**If it fails with "browser already in use":**
1. Run: `pkill -f "playwright-mcp" && pkill -f "npm exec @playwright/mcp"` (wait 2s)
2. Retry. If it works → continue.

**If it fails with "not found" / "tool does not exist" / MCP not configured:**
1. Run automatically:
   ```bash
   claude mcp add playwright -- npx @playwright/mcp@latest
   ```
2. Tell the user ONE thing:
   ```
   ✅ Playwright MCP has been added. Please restart Claude Code and re-run forge:build-playwright-tests.
   ```
3. STOP. Do not proceed without MCP.

**If MCP is configured but Chromium is missing:**
1. Run automatically:
   ```bash
   npm install
   npx playwright install chromium
   ```
2. Run `/mcp` in Claude Code to reconnect. Retry the navigate.

---

## Step 1: Read Config and Detect Input

1. Read `config/environments.json` and `config/users.json`.

2. **Determine feature file source:**

   **Forge pipeline flow** — if an active effort exists and
   `.forge/deployables/<deployable>/capabilities/<capability>/test/features/`
   contains `.feature` files → use that as the source.

   **Standalone flow** — otherwise, scan `features/` directory:
   - Feature area given (e.g. `signup-login`) → `features/signup-login/*.feature`
   - Region given (e.g. `ca`) → `features/ca/*.feature` (legacy structure)
   - Nothing given → `features/**/*.feature`

   If a test-id arg was provided, filter to only that file.

3. **Determine input type:**
   ```
   features/<any-folder>/<id>.feature exists? → use it
   not found                                  → tell user and stop
   ```

4. **Determine region from feature file tag** (not from folder name):
   - `@canada-prod` or `@canada-qa1` → region = `ca`
   - `@usa-prod` or `@usa-qa1` → region = `us`
   - `@uk-prod` or `@uk-qa1` → region = `uk`
   - `@appshell-qa` → region = `appshell`

5. **Check if spec already exists:**
   - BDD → `tests/bdd/<region>/<feature-area>/<id>.spec.ts`
   - Spec **missing** → go to Step 2 (Discover), then Step 5 (Run).
   - Spec **exists** + no `--fix` → skip, tell user spec already exists, stop.
   - Spec **exists** + `--fix` → go to Step 5 (Run); if test fails go to Step 6 (Fix).

---

## Step 2: Determine Discovery Environment

**Priority order (highest → lowest):**

1. **Env tag on BDD Scenario** — look up URL from `config/environments.json`:
   ```
   @canada-prod → https://www.rakuten.ca/
   @canada-qa1  → https://qa1-www.rakuten.ca/
   @usa-prod    → https://www.rakuten.com/
   @usa-qa1     → https://qa1-www.rakuten.com/
   @uk-prod     → https://www.rakuten.co.uk/   + rrcountry:gb
   @uk-qa1      → https://qa1-www.rakuten.co.uk/ + rrcountry:gb
   @appshell-qa → https://rakuten-rewards-appshell-qa.clientserv-np.rr-it.com/
   ```

2. **`TEST_ENV` in `.env` file.**

3. **Fallback from user-type tag:**
   - `@signup` → always use qa1 environment
   - `@anonymous` or `@regular` → use production

**For UK:** always inject `rrcountry: gb` header via MCP.

---

## Step 3: Live Browser Discovery

### 3a — Set up user

**`@regular` user:** Login handled by storageState — browser is pre-authenticated.
Read `tests/setup/auth.setup.ts` for login selectors and flow if storageState is not saved yet.

**`@signup` user — call Test Data Service:**

Read `TDS_BASE_URL` from `.env` (default: `https://testdataservices.vertical-np.rr-it.com/qa`).
Map env to TDS env from `tds_env_map` in `config/environments.json`.

```
POST {TDS_BASE_URL}/test_data_service/v2/{tds_env}/member
Body: { "name": "uifw_{region}_{timestamp}", "password": "rakubates", "emailSubscription": false }
```

Use returned `emailAddress` and password `rakubates`.
If TDS fails → fall back to: `rrqa_auto+unsub_uifw_{region}_${Date.now()}@rakuten.com`
If signup + prod/preview → stop with error directing to qa1.

**`@anonymous`:** Navigate to homepage. No login.

### 3b — Walk each step with MCP (DOM-first)

Use `mcp__playwright__browser_evaluate` for all discovery.
Take screenshot ONLY if DOM query returns confusing results.

```javascript
// Confirm current URL
window.location.href

// Find visible element candidates
[...document.querySelectorAll('a, button')].map(el => ({
  tag: el.tagName, text: el.textContent.trim().slice(0, 50),
  href: el.href || null, className: el.className, id: el.id,
  visible: el.offsetParent !== null
})).filter(el => el.text.length > 0 && el.visible).slice(0, 30)

// Verify element visible before using selector
const el = document.querySelector('your-selector');
const rect = el?.getBoundingClientRect();
({ width: rect?.width, height: rect?.height, visible: el?.offsetParent !== null })
```

**BDD step → MCP action:**

| Step | MCP action |
|---|---|
| `Given I navigate to...` | `browser_navigate`, confirm URL |
| `When I click...` | Query DOM, check bounding rect non-zero, record selector |
| `And I enter...` | Query DOM for input by label/placeholder/type |
| `And I close the popup...` | Query DOM for close button |
| `Then I should see...` | Query DOM, record selector |
| `Given I am logged in...` | storageState — no browser action |

**Selector preference:** CSS → Role → Text → XPath (last resort, prefix `xpath=`)

**NEVER use `{ force: true }`.** Find a visible selector instead.

### 3c — Record all selectors before writing code

```
Step | Action   | Description     | Selector
-----|----------|-----------------|----------------------------------
1    | Navigate | Homepage        | buildUrl()
2    | Click    | Sign In link    | #sign_in_header_button (CSS)
3    | Validate | Balance visible | xpath=//div[@class="balance"]
```

---

## Step 4: Generate the Spec File

**Output path:**
- BDD → `tests/bdd/<region>/<feature-area>/<id>.spec.ts`

Create directory if it does not exist.

### File header

```typescript
import { test, expect } from '@playwright/test';
import environments from '../../../../config/environments.json';
import users from '../../../../config/users.json';

const envKey      = process.env.TEST_ENV;
const userTypeKey = process.env.USER_TYPE;

if (!envKey) throw new Error('TEST_ENV is not set. Example: TEST_ENV=usa-prod npx playwright test');
if (!userTypeKey) throw new Error('USER_TYPE is not set. Example: USER_TYPE=anonymous npx playwright test');

const BASE_URL = (environments.environments as Record<string, string | null>)[envKey]!;
if (!BASE_URL) throw new Error(`No URL found for TEST_ENV="${envKey}". Check config/environments.json`);

const userType = (users.user_types as Record<string, any>)[userTypeKey];
if (!userType) throw new Error(`Unknown USER_TYPE="${userTypeKey}". Check config/users.json`);

const region = envKey.startsWith('canada') ? 'ca' : envKey.startsWith('uk') ? 'uk' : 'us';
if (!userType.regions.includes(region)) {
  throw new Error(`USER_TYPE="${userTypeKey}" is not valid for TEST_ENV="${envKey}". Allowed regions: ${userType.regions.join(', ')}`);
}

const userCreds = userType.credentials?.[region] ?? userType.credentials ?? {};
const username  = userCreds.username ? process.env[userCreds.username] : undefined;
const password  = userCreds.password ? process.env[userCreds.password] : undefined;

if (userType.requires_login) {
  if (!username) throw new Error(`Username not set. Add ${userCreds.username} to your .env file`);
  if (!password) throw new Error(`Password not set. Add ${userCreds.password} to your .env file`);
}

const generatedEmail    = process.env.TDS_GENERATED_EMAIL;
const generatedPassword = process.env.TDS_GENERATED_PASSWORD ?? 'rakubates';

function buildUrl(path?: string): string {
  if (!path || path.trim() === '') return BASE_URL;
  if (path.startsWith('/')) return `${BASE_URL.replace(/\/$/, '')}${path}`;
  return path;
}
```

**Import path depth:**
- BDD specs at `tests/bdd/<region>/<feature-area>/` → use `../../../../config/`

Always adjust the relative import path to match the actual spec file location.

### test.skip guard — first line inside each test()

```typescript
test.skip(userTypeKey !== 'anonymous', `Skipped — requires USER_TYPE=anonymous`);
// or 'regular' / 'signup' / 'amex' / 'bilt' / 'tcpp'
```

### signup qa1-guard — for signup tests

```typescript
if (envKey?.includes('prod') || envKey?.includes('preview')) {
  throw new Error(`signup tests require a QA environment. Use TEST_ENV=...-qa1`);
}
```

### Code patterns

**Navigate:**
```typescript
await page.goto(buildUrl());
await expect(page).toHaveURL(/rakuten/);
```

**Click:** `await page.locator('#id').click();`

**Fill input:** `await page.locator('input[type="email"]').fill(generatedEmail!);`

**Close popup:** `try { await page.locator('button[aria-label="Close"]').click({ timeout: 3000 }); } catch {}`

**Assert visible:** `await expect(page.locator('selector')).toBeVisible({ timeout: 10000 });`

**Assert URL:** `await expect(page).toHaveURL(/pattern/i, { timeout: 15000 });`

Add `// Given` / `// When` / `// Then` / `// And` comments matching Gherkin text exactly.

---

## Step 5: Run the Spec

Determine project from the test's user-type tag and region tag:

```bash
# BDD — Canada
TEST_ENV=canada-prod USER_TYPE=anonymous npx playwright test tests/bdd/ca/<feature-area>/<id>.spec.ts --project=bdd-canada-anonymous --headed
TEST_ENV=canada-prod USER_TYPE=regular   npx playwright test tests/bdd/ca/<feature-area>/<id>.spec.ts --project=bdd-canada-regular --headed
TEST_ENV=canada-qa1  USER_TYPE=signup    npx playwright test tests/bdd/ca/<feature-area>/<id>.spec.ts --project=bdd-canada-signup --headed

# BDD — USA
TEST_ENV=usa-prod USER_TYPE=anonymous npx playwright test tests/bdd/us/<feature-area>/<id>.spec.ts --project=bdd-us-anonymous --headed
TEST_ENV=usa-prod USER_TYPE=regular   npx playwright test tests/bdd/us/<feature-area>/<id>.spec.ts --project=bdd-us-regular --headed
TEST_ENV=usa-qa1  USER_TYPE=signup    npx playwright test tests/bdd/us/<feature-area>/<id>.spec.ts --project=bdd-us-signup --headed

# BDD — UK
TEST_ENV=uk-prod USER_TYPE=anonymous npx playwright test tests/bdd/uk/<feature-area>/<id>.spec.ts --project=bdd-uk-anonymous --headed
TEST_ENV=uk-prod USER_TYPE=regular   npx playwright test tests/bdd/uk/<feature-area>/<id>.spec.ts --project=bdd-uk-regular --headed
TEST_ENV=uk-qa1  USER_TYPE=signup    npx playwright test tests/bdd/uk/<feature-area>/<id>.spec.ts --project=bdd-uk-signup --headed

# BDD — AppShell
TEST_ENV=appshell-qa USER_TYPE=anonymous npx playwright test tests/bdd/us/appshell/<id>.spec.ts --project=bdd-appshell-anonymous --headed
TEST_ENV=appshell-qa USER_TYPE=regular   npx playwright test tests/bdd/us/appshell/<id>.spec.ts --project=bdd-appshell-regular --headed

```

**PASSED** → go to Step 7 (Validate).
**FAILED** → go to Step 6 (Fix).

---

## Step 6: Fix with MCP

1. Read the error. Identify which step/selector failed.
2. Navigate back to the failing page with MCP (inject `rrcountry: gb` for UK).
3. Query the DOM — DOM first, screenshot only if needed.
4. Check bounding rect is non-zero before using selector.
5. Fix the selector in the spec file. CSS preferred over XPath.
7. Re-run (Step 5). Repeat up to 3 cycles.

After 3 cycles without passing, stop:
```
<id>.spec.ts still failing after 3 fix cycles.
Last failure: <error summary>
Review manually before re-running.
```

---

## Step 7: Validate

```bash
node scripts/validate.js --region=<region>
```

**PASSED** → all contracts satisfied.
**FAILED** → report which locator/guard is missing.

---

## Step 8: Print Summary

```
forge:build-playwright-tests results:

✅ tests/bdd/us/signup-login/TC-69007.spec.ts  — @anonymous usa-prod    PASSED (generated)
✅ tests/bdd/us/signup-login/TC-68997.spec.ts  — @signup    usa-qa1     PASSED (generated)
   Signup email (TDS): rrqa_auto+unsub_uifw_us_1234567890@rakuten.com
⚠️  tests/bdd/us/signup-login/TC-69003.spec.ts — skipped (spec already exists)
❌ tests/bdd/us/shopping-trip/T9.spec.ts       — FAILED after 3 fix cycles

Validation:
✅ All locators and guards present

Next: review ❌ T9 manually — selector not found after 3 attempts
```

---

## Hard Rules

| Rule | Detail |
|---|---|
| **Scaffold first** | If config/ missing — create all files before doing anything else |
| **MCP is mandatory** | Auto-install if missing. Only ask user to restart Claude Code. |
| **Region from tag, not folder** | Read `@usa-prod`, `@canada-prod` etc. from .feature file — not from folder name |
| **appshell is a feature area** | Not a region. Uses `@appshell-qa` env tag. |
| **DOM first** | Use `browser_evaluate`. Screenshot only if DOM fails. |
| **No `{ force: true }`** | Always target visible elements only |
| **Selector order** | CSS → Role → Text → XPath (last resort) |
| **Signup = TDS** | Call TDS v2 API. Fall back to generated email only if TDS fails. |
| **UK = rrcountry header** | Always inject for uk-* envs |
| **Max 3 fix attempts** | Report blocker after 3 failures |
| **Skip existing specs** | Unless `--fix` flag passed |
