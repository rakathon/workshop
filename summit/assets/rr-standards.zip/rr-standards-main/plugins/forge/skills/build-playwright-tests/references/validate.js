#!/usr/bin/env node

/**
 * validate.js
 *
 * Deterministic validation script — no AI.
 * Validates every BDD .feature file against its generated .spec.ts.
 *
 * Usage:
 *   node scripts/validate.js --region=ca
 *   node scripts/validate.js --region=us
 *   node scripts/validate.js --region=uk
 *   node scripts/validate.js           (validates all regions)
 */

const fs   = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

// ── Argument parsing ──────────────────────────────────────────────────────────

const regionArg = process.argv.find(a => a.startsWith('--region='));
const regions   = regionArg
  ? [regionArg.split('=')[1]]
  : ['ca', 'us', 'uk', 'appshell'];

// ── BDD Feature File Parser ───────────────────────────────────────────────────

function parseFeature(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  const lines   = content.split('\n').map(l => l.trim()).filter(l => l.length > 0);

  const result = {
    featureId: null,
    title:     null,
    userType:  null,
    envTag:    null,
    steps:     [],
  };

  for (const line of lines) {
    if (line.startsWith('Feature:')) {
      const parts    = line.replace('Feature:', '').trim().split(' ');
      result.featureId = parts[0];
      result.title     = parts.slice(1).join(' ');
    }
    if (line.startsWith('@')) {
      const tags = line.split(/\s+/);
      for (const tag of tags) {
        if (['@anonymous','@regular','@signup','@amex','@bilt','@tcpp'].includes(tag))
          result.userType = tag.replace('@', '');
        if (tag.match(/@(canada|usa|uk|appshell)/))
          result.envTag = tag.replace('@', '');
      }
    }
    if (line.match(/^(Given|When|Then|And|But)/)) {
      result.steps.push(line);
    }
  }

  return result;
}

// ── Step → expected code patterns ────────────────────────────────────────────

function stepSubject(step) {
  const s = step.replace(/^(Given|When|Then|And|But)\s+/i, '').trim();

  if (/navigate to the homepage|proceed to rakuten|go to the homepage/i.test(s))
    return ['buildUrl()'];

  const navMatch = s.match(/navigate to (.+)/i);
  if (navMatch) return [navMatch[1].trim().split(' ').slice(0, 3).join(' ').toLowerCase()];

  if (/am logged in|logged in as/i.test(s)) return ['storageState'];

  if (/create a new account|sign up|register/i.test(s)) return ["'signup'"];

  if (/close the popup/i.test(s)) return ['try {', 'try{'];

  const clickMatch = s.match(/^(?:i\s+)?(?:click|select|tap)\s+(?:the\s+)?(.+)/i);
  if (clickMatch) {
    const elem = clickMatch[1].replace(/\s+button$|\s+link$|\s+icon$/i, '').trim();
    return elem.toLowerCase().split(/\s+/).filter(w => w.length > 3);
  }

  const fillMatch = s.match(/^(?:i\s+)?(?:enter|type|fill)\s+(.+)/i);
  if (fillMatch) return ['.fill('];

  const seeMatch = s.match(/should see\s+(?:the\s+)?(.+)/i);
  if (seeMatch) {
    const subject = seeMatch[1].replace(/\s+(button|link|modal|page|field|icon)$/i, '').trim();
    return subject.toLowerCase().split(/\s+/).filter(w => w.length > 3);
  }

  if (/redirect|navigated to|should be directed/i.test(s)) return ['.toHaveURL(', '.toBeVisible('];

  return [];
}

function stepRequiredPatterns(step) {
  const s = step.toLowerCase();
  const patterns = [];

  if (/navigate to the homepage|proceed to rakuten|go to the homepage/.test(s))
    patterns.push({ pattern: 'page.goto(buildUrl()', label: 'page.goto(buildUrl())' });

  else if (/navigate to/.test(s))
    patterns.push({ pattern: 'page.goto(', label: 'page.goto()' });

  else if (/am logged in|logged in as/.test(s))
    patterns.push({ pattern: 'storageState', label: 'storageState (login)' });

  else if (/create a new account|sign up/.test(s))
    patterns.push({ pattern: "'signup'", label: "test.skip guard for 'signup'" });

  else if (/close the popup/.test(s))
    patterns.push({ pattern: 'try {', label: 'try/catch for popup close' });

  else if (/^(?:i )?(?:click|select|tap)/.test(s.replace(/^(given|when|then|and|but)\s+/, '')))
    patterns.push({ pattern: '.click(', label: '.click()' });

  else if (/^(?:i )?(?:enter|type|fill)/.test(s.replace(/^(given|when|then|and|but)\s+/, '')))
    patterns.push({ pattern: '.fill(', label: '.fill()' });

  else if (/should see/.test(s))
    patterns.push({ pattern: '.toBeVisible(', label: '.toBeVisible()' });

  else if (/redirect|navigated to|should be directed/.test(s)) {
    patterns.push({ pattern: '.toHaveURL(', label: '.toHaveURL()' });
    patterns.push({ pattern: '.toBeVisible(', label: '.toBeVisible() after redirect' });
  }

  return patterns;
}

// ── BDD Spec Validator ────────────────────────────────────────────────────────

function validateBDDTest(featurePath, specPath) {
  const issues = [];
  const feature = parseFeature(featurePath);
  const code    = fs.readFileSync(specPath, 'utf8');
  const codeLow = code.toLowerCase();

  // ── Guards
  if (!code.includes('process.env.TEST_ENV'))
    issues.push('❌ Missing: process.env.TEST_ENV guard');
  if (!code.includes('process.env.USER_TYPE'))
    issues.push('❌ Missing: process.env.USER_TYPE guard');
  if (!code.includes('buildUrl'))
    issues.push('❌ Missing: buildUrl() helper');
  if (!code.includes('userType.regions.includes(region)'))
    issues.push('❌ Missing: region guard');
  if (/page\.goto\(['"]https?:\/\//.test(code))
    issues.push('❌ Hardcoded URL in page.goto() — use buildUrl()');

  // ── User type tag + skip guard
  if (feature.userType && !code.includes(`@${feature.userType}`))
    issues.push(`❌ Missing @${feature.userType} tag in test name`);
  if (feature.userType && !code.includes(`userTypeKey !== '${feature.userType}'`))
    issues.push(`❌ Missing test.skip guard for USER_TYPE=${feature.userType}`);

  // ── Feature ID present
  if (feature.featureId && !code.includes(feature.featureId))
    issues.push(`❌ Feature ID ${feature.featureId} not found in spec`);

  // ── Import path
  if (!code.includes("from '../../../../config/") && !code.includes("from '../../../config/"))
    issues.push('❌ Import path wrong — expected ../../../../config/ or ../../../config/');

  // ── Step coverage
  const patternCounts = {};
  const countIn = (pat) => {
    if (patternCounts[pat] === undefined)
      patternCounts[pat] = (code.split(pat).length - 1);
    return patternCounts[pat];
  };

  const needed   = {};
  const stepInfo = [];

  for (const step of feature.steps) {
    const required = stepRequiredPatterns(step);
    const subjects = stepSubject(step);

    for (const { pattern } of required) {
      needed[pattern] = (needed[pattern] || 0) + 1;
    }

    let subjectFound = subjects.length === 0;
    for (const candidate of subjects) {
      if (codeLow.includes(candidate.toLowerCase())) { subjectFound = true; break; }
    }

    stepInfo.push({ step, required, subjects, subjectFound });
  }

  for (const [pattern, count] of Object.entries(needed)) {
    const found = countIn(pattern);
    if (found < count)
      issues.push(`❌ Step coverage: need ${count}× \`${pattern}\` but found ${found}× in spec`);
  }

  for (const { step, subjects, subjectFound, required } of stepInfo) {
    if (!subjectFound && subjects.length > 0 && required.length > 0) {
      issues.push(`❌ No trace of step in spec: "${step}"\n     (looked for: ${subjects.map(s => `"${s}"`).join(', ')})`);
    }
  }

  return issues;
}

// ── BDD Region Validator ──────────────────────────────────────────────────────

function validateBDDRegion(region) {
  const featuresDir = path.join(ROOT, 'features', region);
  const bddSpecDir  = path.join(ROOT, 'tests', 'bdd', region);

  if (!fs.existsSync(featuresDir)) return;

  console.log(`\nVALIDATION REPORT — ${region.toUpperCase()} (features/${region}/)`);
  console.log('='.repeat(50));

  const featureFiles = [];
  const entries = fs.readdirSync(featuresDir);
  for (const entry of entries) {
    const entryPath = path.join(featuresDir, entry);
    const stat = fs.statSync(entryPath);
    if (stat.isDirectory()) {
      const subFiles = fs.readdirSync(entryPath)
        .filter(f => f.endsWith('.feature'))
        .map(f => ({ file: path.join(entryPath, f), subfolder: entry }));
      featureFiles.push(...subFiles);
    } else if (entry.endsWith('.feature')) {
      featureFiles.push({ file: entryPath, subfolder: '' });
    }
  }

  if (featureFiles.length === 0) {
    console.log('  ⚠️  No .feature files found');
    return;
  }

  for (const { file, subfolder } of featureFiles) {
    const featureId = path.basename(file, '.feature');

    const specSubDir = subfolder ? path.join(bddSpecDir, subfolder) : bddSpecDir;
    const specFile   = path.join(specSubDir, `${featureId}.spec.ts`);

    const featureLabel = subfolder
      ? `features/${region}/${subfolder}/${featureId}.feature`
      : `features/${region}/${featureId}.feature`;

    if (!fs.existsSync(specFile)) {
      console.log(`\n⏭️  ${featureId} — no spec file yet (${featureLabel})`);
      continue;
    }

    const specLabel = specFile.replace(ROOT + '/', '');
    const issues    = validateBDDTest(file, specFile);

    if (issues.length === 0) {
      console.log(`\n✅ ${featureId} [${specLabel}]`);
      totalPassed++;
    } else {
      console.log(`\n❌ ${featureId} [${specLabel}]`);
      issues.forEach(i => console.log(`   ${i}`));
      totalFailed++;
      totalIssues += issues.length;
    }
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────

let totalPassed = 0;
let totalFailed = 0;
let totalIssues = 0;

for (const region of regions) {
  validateBDDRegion(region);
}

console.log('\n' + '='.repeat(50));
console.log(`SUMMARY: ${totalPassed} passed, ${totalFailed} failed, ${totalIssues} issues found`);
console.log('');

if (totalFailed > 0) process.exit(1);