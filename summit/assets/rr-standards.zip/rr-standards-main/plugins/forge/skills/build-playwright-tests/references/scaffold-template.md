# Scaffold Template

Files and commands written by Step 0a when `config/environments.json` does not exist.

---

## Folder structure

```bash
mkdir -p config features tests/bdd tests/setup tests/reporter scripts .auth
touch .auth/.gitkeep
```

---

## `config/environments.json`

```json
{
  "environments": {
    "canada-prod":  "https://www.rakuten.ca/",
    "canada-qa1":   "https://qa1-www.rakuten.ca/",
    "usa-prod":     "https://www.rakuten.com/",
    "usa-qa1":      "https://qa1-www.rakuten.com/",
    "usa-preview":  "https://preview-www.rakuten.com/",
    "uk-prod":      "https://www.rakuten.co.uk/",
    "uk-qa1":       "https://qa1-www.rakuten.co.uk/",
    "appshell-qa":  "https://rakuten-rewards-appshell-qa.clientserv-np.rr-it.com/"
  },
  "extra_headers": {
    "uk-prod": { "rrcountry": "gb" },
    "uk-qa1":  { "rrcountry": "gb" }
  },
  "tds_env_map": {
    "canada-qa1": "qa1",
    "usa-qa1":    "qa1",
    "uk-qa1":     "qa1uk",
    "canada-prod": null,
    "usa-prod":    null,
    "uk-prod":     null
  }
}
```

---

## `config/users.json`

```json
{
  "user_types": {
    "anonymous": {
      "description": "No login required — browse-only tests.",
      "requires_login": false,
      "regions": ["ca", "us", "uk"],
      "credentials": {}
    },
    "regular": {
      "description": "Standard cashback member.",
      "requires_login": true,
      "regions": ["ca", "us", "uk"],
      "credentials": {
        "ca": { "username": "CA_REGULAR_EMAIL", "password": "CA_REGULAR_PASSWORD" },
        "us": { "username": "US_REGULAR_EMAIL", "password": "US_REGULAR_PASSWORD" },
        "uk": { "username": "UK_REGULAR_EMAIL", "password": "UK_REGULAR_PASSWORD" }
      }
    },
    "signup": {
      "description": "New user — created via Test Data Service. QA1 only.",
      "requires_login": false,
      "regions": ["ca", "us", "uk"],
      "credentials": {},
      "tds_name_prefix": { "ca": "uifw_ca", "us": "uifw_us", "uk": "uifw_uk" }
    },
    "amex": {
      "description": "Amex card user — USA only.",
      "requires_login": true,
      "regions": ["us"],
      "credentials": {
        "us": { "username": "US_AMEX_EMAIL", "password": "US_AMEX_PASSWORD" }
      }
    },
    "bilt": {
      "description": "Bilt card user — USA only.",
      "requires_login": true,
      "regions": ["us"],
      "credentials": {
        "us": { "username": "US_BILT_EMAIL", "password": "US_BILT_PASSWORD" }
      }
    },
    "tcpp": {
      "description": "User with pending TCPP update — provisioned via MAIT. QA1 only.",
      "requires_login": true,
      "regions": ["us", "uk"],
      "credentials": {
        "us": { "username": "US_TCPP_EMAIL", "password": "US_TCPP_PASSWORD" },
        "uk": { "username": "UK_TCPP_EMAIL", "password": "UK_TCPP_PASSWORD" }
      }
    }
  }
}
```

---

## `.env.example`

```bash
# ── BrowserStack ───────────────────────────────────────────────
BROWSERSTACK_USERNAME=
BROWSERSTACK_ACCESS_KEY=

# ── Canada ─────────────────────────────────────────────────────
CA_REGULAR_EMAIL=
CA_REGULAR_PASSWORD=

# ── USA ────────────────────────────────────────────────────────
US_REGULAR_EMAIL=
US_REGULAR_PASSWORD=
US_AMEX_EMAIL=
US_AMEX_PASSWORD=
US_BILT_EMAIL=
US_BILT_PASSWORD=
US_TCPP_EMAIL=
US_TCPP_PASSWORD=

# ── UK ─────────────────────────────────────────────────────────
UK_REGULAR_EMAIL=
UK_REGULAR_PASSWORD=
UK_TCPP_EMAIL=
UK_TCPP_PASSWORD=

# ── Test Data Service ──────────────────────────────────────────
TDS_BASE_URL=https://testdataservices.vertical-np.rr-it.com/qa
```

---

## `package.json`

```json
{
  "name": "ui-test-automation",
  "version": "1.0.0",
  "scripts": {
    "test": "playwright test",
    "validate": "node scripts/validate.js"
  },
  "devDependencies": {
    "@playwright/test": "^1.40.0",
    "dotenv": "^16.0.0",
    "typescript": "^5.0.0"
  }
}
```

---

## `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "strict": true,
    "esModuleInterop": true,
    "resolveJsonModule": true,
    "outDir": "./dist"
  },
  "include": ["tests/**/*.ts", "config/**/*.json"]
}
```

---

## `.gitignore`

```
node_modules/
.auth/
.env
dist/
test-results/
playwright-report/
.cache/
```

---

## `playwright.config.ts`

Write the full config with all projects:
- Setup projects: `setup-canada-regular`, `setup-usa-regular`, `setup-uk-regular`, `setup-uk-tcpp`
- BDD projects: `bdd-canada-anonymous/regular/signup`, `bdd-us-anonymous/regular/signup`, `bdd-uk-anonymous/regular/signup`, `bdd-appshell-anonymous/regular`

Follow the pattern from `references/playwright-impl-guide.md`.

---

## Install dependencies

```bash
npm install
npx playwright install chromium
```

