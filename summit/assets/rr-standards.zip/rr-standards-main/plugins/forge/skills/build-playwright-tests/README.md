# forge:build-playwright-tests

Full UI test lifecycle in one command. Reads Gherkin `.feature` files, uses a
**live browser via Playwright MCP** to discover real selectors, writes Playwright
`.spec.ts` files, runs them, fixes failures, and validates. All in one pass.

**Playwright MCP is mandatory.** The skill auto-installs it if missing.

---

## When to Use

Use `forge:build-playwright-tests` whenever you need to generate or fix Playwright
UI tests.

Typical triggers:
- "Build the Playwright tests for the favorites screen"
- "Generate specs from the feature files"
- "Implement the feature files"
- "Write the Playwright code"
- "Fix the failing CA tests"
- When `.feature` files exist in `features/` and need executable `.spec.ts` equivalents
- When a task in `plan/tasks.md` has type `playwright-test`

### Standalone use

If `.feature` files already exist in `features/<region>/` (written manually, by
`forge:spec-ui-e2e`, or by `forge:browserstack-to-bdd`), just run:

```
forge:build-playwright-tests ca
forge:build-playwright-tests ca E2E-02
```

No active Forge effort needed.

---

## Usage

```
forge:build-playwright-tests [region] [test-id] [--fix]
```

| Argument | Description | Example |
|---|---|---|
| `region` | Scope to a region (optional) | `ca`, `us`, `uk`, `appshell` |
| `test-id` | Specific test to process (optional) | `E2E-02`, `TC-72162` |
| `--fix` | Skip generation — only fix already-failing tests | |

### Examples

```
forge:build-playwright-tests ca                # all missing CA BDD tests
forge:build-playwright-tests ca E2E-02         # one specific test
forge:build-playwright-tests                   # auto-detect region from test IDs
forge:build-playwright-tests ca --fix          # fix all failing CA tests
forge:build-playwright-tests ca E2E-02 --fix   # fix one specific test
```

---

## Pipeline Position

```
Discovery                         Implementation (after UI is built)
──────────────────────────────    ────────────────────────────────────────────────
forge:spec-tests               →  forge:spec-ui-e2e  →  forge:build-playwright-tests
  (ui-e2e-test-suite.md)            (.feature files)       (.spec.ts — verified)

forge:browserstack-to-bdd      →                         forge:build-playwright-tests

Standalone (.feature files
already in features/)          →                         forge:build-playwright-tests
```

---

## What It Does

1. **Verifies Playwright MCP** — confirms the live browser is available; installs
   it automatically if missing
2. **Detects input** — BDD `.feature` file; auto-detects region from test ID if not
   provided
3. **Determines discovery environment** — from Scenario env tags, `.env` TEST_ENV,
   or inferred from user type (`signup` → always QA)
4. **Sets up user in browser** — logs in for `@regular` tests (reads auth flow from
   `tests/setup/auth.setup.ts`); calls Test Data Service for `@signup` tests;
   navigates to homepage for `@anonymous`
5. **Walks each Gherkin step with MCP** — uses `browser_evaluate` (DOM-first)
   to discover real selectors; checks bounding rect before recording any selector
6. **Generates `.spec.ts`** — real selectors only, no placeholders; correct
   boilerplate, `test.skip` guards, signup qa1-guard, `buildUrl()` throughout
7. **Runs the test immediately** after writing
8. **Fixes failures with MCP** — up to 3 cycles per test
9. **Validates** — runs `scripts/validate.js` to confirm locators and guards are present

---

## Output

| Source | Output path |
|---|---|
| BDD `.feature` file | `tests/bdd/<region>/<feature-area>/<id>.spec.ts` |

---

## Live Browser Discovery

The skill uses DOM inspection — not screenshots — to discover selectors:

```javascript
// Find visible candidates
[...document.querySelectorAll('a, button')].map(el => ({
  text: el.textContent.trim(),
  className: el.className,
  visible: el.offsetParent !== null
})).filter(el => el.visible).slice(0, 30)

// Confirm element is actionable before recording selector
const el = document.querySelector('selector');
const rect = el?.getBoundingClientRect();
({ width: rect?.width, height: rect?.height, visible: el?.offsetParent !== null })
```

**Selector preference:** CSS → Role → Text → XPath (last resort, prefix `xpath=`)

**Never uses `{ force: true }`** — always finds a visible, actionable element.

---

## Signup Tests — Test Data Service

For `@signup` scenarios, the skill calls the Test Data Service to create a fresh
member account:

```
POST {TDS_BASE_URL}/test_data_service/v2/{tds_env}/member
Body: { "name": "uifw_{region}_{timestamp}", "password": "rakubates", "emailSubscription": false }
```

Falls back to a generated email if TDS is unavailable. Signup tests always run
against a QA environment — production blocks account creation.

---

## Prerequisites

- Playwright MCP (auto-installed if missing — requires Claude Code restart)
- `features/<region>/*.feature` files (from `forge:spec-ui-e2e`,
  `forge:browserstack-to-bdd`, or written manually)
- `config/environments.json` and `config/users.json`
- Credentials in `.env` for non-anonymous tests

---

## Conventions

| Rule | Detail |
|---|---|
| MCP is mandatory | Auto-installs; only asks user to restart Claude Code |
| Output to `tests/bdd/` | Specs written to `tests/bdd/<region>/<feature-area>/` |
| Selector order | CSS → Role → Text → XPath (last resort) |
| No `{ force: true }` | Always find a visible selector |
| Signup = TDS | Call TDS v2 API; fall back only if TDS fails |
| UK = rrcountry header | Always inject `rrcountry: gb` for uk-* environments |
| Max 3 fix attempts | After 3 cycles still failing → report and move on |
| Skip existing specs | Unless `--fix` flag passed |

---

## Guides

`references/playwright-impl-guide.md` — the authoritative reference the skill reads
at runtime. Documents:
- Repository layout and config file structure (`environments.json`, `users.json`)
- Exact boilerplate every spec file must include
- Gherkin step → Playwright code patterns
- Locator strategy and DOM inspection snippets
- `playwright.config.ts` project conventions

---

## Related Skills

| Skill | When to use |
|---|---|
| `forge:spec-tests` | Author the `ui-e2e-test-suite.md` during discovery |
| `forge:spec-ui-e2e` | Convert `ui-e2e-test-suite.md` to `.feature` files (Forge flow) |
| `forge:browserstack-to-bdd` | Write `.feature` files from a BrowserStack TC |
| `forge:ui-tests-run` | Run the generated `.spec.ts` files without regenerating |
| `forge:ui-tests-fix` | Fix failing tests without regenerating |
| `forge:ui-tests-validate` | Validate spec correctness against source |
