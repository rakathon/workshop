# Playwright Implementation Guide

Implementation guide for Playwright BDD test generation. Documents the conventions of the
`ui-test-automation` repository and the live browser discovery process used to
generate correct, runnable `.spec.ts` files from Gherkin `.feature` files.

---

## Repository Layout

```
<project>/
├── features/             # Gherkin feature files (input — written by forge:spec-tests)
├── tests/
│   ├── bdd/              # BDD spec files (output — what this skill writes)
│   └── setup/            # Auth and test data setup (do not modify)
├── config/
│   ├── environments.json # Environment → URL mapping
│   └── users.json        # User type definitions, regions, credentials
├── playwright.config.ts  # Playwright project definitions
└── .auth/                # Saved session state (git-ignored)
```

**Rule:** BDD spec files go in `tests/bdd/`. The directory structure under
`tests/bdd/` mirrors whatever structure exists under `features/`. Create
directories as needed — do not assume any specific folder names exist.

---

## Config Files

Both files live at `config/` in the project root and must exist before the skill runs.

### config/environments.json

Maps environment keys to base URLs, extra headers, and Test Data Service environment names.

```json
{
  "environments": {
    "usa-prod":    "https://www.rakuten.com/",
    "canada-prod": "https://www.rakuten.ca/",
    "usa-qa1":     "https://qa1-www.rakuten.com/",
    "canada-qa1":  "https://qa1-www.rakuten.ca/",
    "usa-preview": "https://preview-www.rakuten.com/",
    "uk-prod":     "https://www.rakuten.co.uk/",
    "uk-qa1":      "https://qa1-www.rakuten.co.uk/",
    "appshell-qa": "https://rakuten-rewards-appshell-qa.clientserv-np.rr-it.com/"
  },
  "extra_headers": {
    "uk-prod": { "rrcountry": "gb" },
    "uk-qa1":  { "rrcountry": "gb" }
  },
  "tds_env_map": {
    "canada-qa1":  "qa1",
    "usa-qa1":     "qa1",
    "uk-qa1":      "qa1uk",
    "canada-prod": null,
    "usa-prod":    null,
    "uk-prod":     null
  }
}
```

- `environments` — every valid `TEST_ENV` value and its base URL. URL includes trailing slash.
- `extra_headers` — additional HTTP headers to inject for specific environments (UK requires `rrcountry: gb` in both MCP navigation and generated tests).
- `tds_env_map` — maps a `TEST_ENV` value to a TDS environment name for signup user creation. `null` means TDS is not available (prod/preview) — fall back to generated email.

### config/users.json

Defines all valid `USER_TYPE` values, their regions, login requirements, and credential env var names.

```json
{
  "user_types": {
    "anonymous": {
      "description": "No login required — browse-only tests. Works for CA, US, UK.",
      "requires_login": false,
      "regions": ["ca", "us", "uk"],
      "credentials": {}
    },
    "regular": {
      "description": "Standard cashback member. Works for CA, US, UK.",
      "requires_login": true,
      "regions": ["ca", "us", "uk"],
      "credentials": {
        "ca": { "username": "CA_REGULAR_EMAIL", "password": "CA_REGULAR_PASSWORD" },
        "us": { "username": "US_REGULAR_EMAIL", "password": "US_REGULAR_PASSWORD" },
        "uk": { "username": "UK_REGULAR_EMAIL", "password": "UK_REGULAR_PASSWORD" }
      }
    },
    "amex": {
      "description": "Amex card user — USA only.",
      "requires_login": true,
      "regions": ["us"],
      "credentials": {
        "us": { "username": "US_AMEX_EMAIL", "password": "US_AMEX_PASSWORD" }
      }
    },
    "bilt": {
      "description": "Bilt card user — USA only.",
      "requires_login": true,
      "regions": ["us"],
      "credentials": {
        "us": { "username": "US_BILT_EMAIL", "password": "US_BILT_PASSWORD" }
      }
    },
    "signup": {
      "description": "New user signup — calls Test Data Service to create fresh user. QA1 only.",
      "requires_login": false,
      "regions": ["ca", "us", "uk"],
      "credentials": {},
      "tds_name_prefix": { "ca": "uifw_ca", "us": "uifw_us", "uk": "uifw_uk" }
    },
    "tcpp": {
      "description": "User with a pending TCPP update — must be provisioned via MAIT. QA1 only.",
      "requires_login": true,
      "regions": ["us", "uk"],
      "credentials": {
        "us": { "username": "US_TCPP_EMAIL", "password": "US_TCPP_PASSWORD" },
        "uk": { "username": "UK_TCPP_EMAIL", "password": "UK_TCPP_PASSWORD" }
      }
    }
  }
}
```

- `requires_login` — if `true`, the credential env vars must be set in `.env` before running.
- `credentials` — values are env var **names**, not literal credentials. The skill reads `process.env[username]` at runtime.
- `regions` — valid regions for this user type. The skill throws at runtime if `TEST_ENV` region doesn't match.
- `tds_name_prefix` — used by the signup flow to name the TDS-created user per region.

---

## Playwright MCP — Mandatory

This skill uses Playwright MCP to browse the live site and discover real selectors.
**MCP is not optional.** Do not generate spec files without it.

### Verify MCP is working (first action)

```
Use mcp__playwright__browser_navigate to go to the project's base URL
```

**If it fails with "browser already in use":**
1. Run: `pkill -f "playwright-mcp" && pkill -f "npm exec @playwright/mcp"` (wait 2s)
2. Retry. If it works → continue.

**If it fails with "not found" / "tool does not exist" / MCP not configured:**
1. Run:
   ```bash
   claude mcp add playwright -- npx @playwright/mcp@latest
   ```
2. Tell the user:
   ```
   ✅ Playwright MCP has been added. Please restart Claude Code and re-run the skill.
   ```
3. STOP. Do not proceed without MCP.

**If Chromium is missing (browser launch fails):**
1. Run:
   ```bash
   npm install
   npx playwright install chromium
   ```
2. Run `/mcp` in Claude Code to reconnect. Retry navigate.

---

## Discovery Environment

Before opening MCP, determine which URL to use for live browser discovery.

**Priority order (highest → lowest):**

1. **Env tag on the Scenario line** — e.g. `@canada-prod`, `@canada-qa1`, `@usa-qa1`.
   Look up the URL in `config/environments.json`. Apply `extra_headers` if present
   (e.g. UK requires `rrcountry: gb`).

2. **`TEST_ENV` in `.env` file** — read `.env` and use that environment's URL.

3. **Fallback — infer from user-type tag:**
   - `@signup` → always use a qa/non-prod environment (production blocks signups)
   - `@anonymous` or `@regular` → use production

---

## User Setup via MCP

### regular user — storageState

Login is handled by Playwright's `storageState` — the browser is pre-authenticated.
No explicit login code in the test. Just navigate and proceed.

### anonymous user

Navigate to homepage. No login needed.

### signup user — Test Data Service

Read `TDS_BASE_URL` from `.env` (default: `https://testdataservices.vertical-np.rr-it.com/qa`).

Map environment to TDS env from `tds_env_map` in `config/environments.json`.

Call TDS v2 API:
```
POST {TDS_BASE_URL}/test_data_service/v2/{tds_env}/member
Body: { "name": "uifw_{region}_{timestamp}", "password": "rakubates", "emailSubscription": false }
```

Response: `emailAddress`, `id`, `ebtoken`. Use `emailAddress` and password `rakubates`.

**If TDS fails** → fall back to generated email:
`rrqa_auto+unsub_uifw_{region}_${Date.now()}@rakuten.com` with password `rakubates`.

If env is `prod` or `preview` and user type is `signup` → stop with error directing
the engineer to use a QA environment.

---

## Live Browser Discovery (DOM-First)

Use `mcp__playwright__browser_evaluate` to inspect the DOM. Take a screenshot only
if a DOM query returns confusing results.

### DOM inspection patterns

```javascript
// Confirm current URL
window.location.href

// Find all visible links with text
[...document.querySelectorAll('a')].map(a => ({
  text: a.textContent.trim(),
  href: a.href,
  className: a.className,
  visible: a.offsetParent !== null
})).filter(a => a.text.length > 0).slice(0, 20)

// Verify element is visible before using its selector
const el = document.querySelector('your-selector');
const rect = el?.getBoundingClientRect();
({ width: rect?.width, height: rect?.height, visible: el?.offsetParent !== null })
```

### Gherkin step → browser action

| Gherkin step | MCP action |
|---|---|
| `Given I navigate to the homepage` | `browser_navigate` to BASE_URL |
| `Given I navigate to <path>` | `browser_navigate` to BASE_URL + path |
| `Given I am logged in as ...` | storageState handles it — no browser action |
| `When I navigate to <description>` | `browser_navigate` (use DOM to find URL) |
| `When I click <description>` | Query DOM for element, verify bounding rect non-zero, then click |
| `When I enter <value> in the <field>` | Query DOM for input by label/placeholder/type |
| `And I close the popup if present` | Query DOM for close button |
| `Then I should see <description>` | Query DOM to find the element |
| `Then I should be redirected to <description>` | Confirm URL via `window.location.href` |

### Selector preference

1. **CSS** — `#id`, `.class`, `[data-attr]`, `button.class-name`
2. **Playwright role** — `getByRole('button', { name: 'Sign In' })`
3. **Playwright text** — `getByText('Join Now')`
4. **XPath** — last resort only; always prefix with `xpath=`

### Never use `{ force: true }` on clicks

If a selector matches a hidden element (zero bounding rect):
- Find a more specific selector targeting only the visible element
- Trigger hover/expand first if inside a dropdown, then click
- A forced click on a non-visible element does not reflect real user behaviour

### Record all discovered selectors before writing code

```
Step | Gherkin                               | Selector discovered
-----|---------------------------------------|----------------------------------
1    | Given I am logged in as regular user  | storageState
2    | When I navigate to the homepage       | buildUrl()
3    | And I close the popup if present      | button[aria-label="Close"]  (CSS)
4    | Then I should see my cashback balance | div.cashback-balance  (CSS)
```

---

## Spec File Boilerplate

Every BDD spec file must open with this exact boilerplate, verbatim.

```typescript
import { test, expect } from '@playwright/test';
import environments from '../../../../config/environments.json';
import users from '../../../../config/users.json';

const envKey      = process.env.TEST_ENV;
const userTypeKey = process.env.USER_TYPE;

if (!envKey) throw new Error('TEST_ENV is not set. Example: TEST_ENV=canada-prod npx playwright test');
if (!userTypeKey) throw new Error('USER_TYPE is not set. Example: USER_TYPE=anonymous npx playwright test');

const BASE_URL = (environments.environments as Record<string, string | null>)[envKey]!;
if (!BASE_URL) throw new Error(`No URL found for TEST_ENV="${envKey}". Check config/environments.json`);

const userType = (users.user_types as Record<string, any>)[userTypeKey];
if (!userType) throw new Error(`Unknown USER_TYPE="${userTypeKey}". Check config/users.json`);

const region = envKey.startsWith('canada') ? 'ca' : envKey.startsWith('uk') ? 'uk' : 'us';
if (!userType.regions.includes(region)) {
  throw new Error(`USER_TYPE="${userTypeKey}" is not valid for TEST_ENV="${envKey}". Allowed regions: ${userType.regions.join(', ')}`);
}

const userCreds = userType.credentials?.[region] ?? userType.credentials ?? {};
const username  = userCreds.username ? process.env[userCreds.username] : undefined;
const password  = userCreds.password ? process.env[userCreds.password] : undefined;

if (userType.requires_login) {
  if (!username) throw new Error(`Username not set. Add ${userCreds.username} to your .env file`);
  if (!password) throw new Error(`Password not set. Add ${userCreds.password} to your .env file`);
}

// signup: email/password injected at runtime via TDS or fallback
const generatedEmail    = process.env.TDS_GENERATED_EMAIL;
const generatedPassword = process.env.TDS_GENERATED_PASSWORD ?? 'rakubates';

function buildUrl(path?: string): string {
  if (!path || path.trim() === '') return BASE_URL;
  if (path.startsWith('/')) return `${BASE_URL.replace(/\/$/, '')}${path}`;
  return path;
}
```

**Import path depth:** BDD specs live at `tests/bdd/<region>/<feature-area>/`, which is
four levels deep — so the canonical import path is `../../../../config/`. Adjust if the
spec is at a different depth.

---

## Test Function Structure

```typescript
// Feature: {Feature title}
// Scenario: {Scenario name}
test('{Feature ID} {Scenario name} {space-separated tags}', async ({ page }) => {
  test.skip(userTypeKey !== '{primary_user_type}', `Skipped — this test requires USER_TYPE={primary_user_type}`);

  // signup qa1-guard (signup tests only)
  if (envKey?.includes('prod') || envKey?.includes('preview')) {
    throw new Error(`signup tests require a QA environment. Use TEST_ENV=...-qa1`);
  }

  // Given ...
  // When ...
  // Then ...
});
```

Add a `// Given ...` / `// When ...` / `// Then ...` comment before each step,
matching the Gherkin text exactly.

---

## Gherkin Step → Code Patterns

### Navigate
```typescript
await page.goto(buildUrl());
await expect(page).toHaveURL(/rakuten/);
```

### Click (CSS preferred)
```typescript
await page.locator('a.bonus-link').first().click();
await page.getByRole('button', { name: 'Sign In' }).click();
await page.locator('xpath=//a[@data-id]').first().click(); // XPath fallback
```

### Click — opens new tab
```typescript
const [newTab] = await Promise.all([
  page.context().waitForEvent('page'),
  page.locator('a.store-tile').first().click()
]);
await newTab.waitForLoadState();
await expect(newTab).toHaveURL(/store/i, { timeout: 15000 });
```

### Fill input
```typescript
await page.locator('input[type="email"]').fill(generatedEmail!);
await page.locator('input[type="password"]').fill(generatedPassword!);
await page.locator('input[name="search"]').fill('some value');
```

### Close popup
```typescript
try {
  await page.locator('button[aria-label="Close"]').click({ timeout: 3000 });
} catch {}
```

### Interact inside iframe
```typescript
const frame = page.frameLocator('iframe#modal-iframe');
await frame.locator('xpath=//input[@id="emailAddress"]').fill(username!);
await frame.locator('xpath=//input[@id="password"]').fill(password!);
await frame.locator('xpath=//button[@id="auth-btn"]').click();
```

### Assert visible
```typescript
await expect(page.locator('div.cashback-balance')).toBeVisible({ timeout: 10000 });
await expect(page.getByRole('heading', { name: /balance/i })).toBeVisible();
```

### Assert URL
```typescript
await expect(page).toHaveURL(/pattern/i, { timeout: 15000 });
```

### Assert text
```typescript
const text = await page.locator('selector').innerText();
await expect(text.toLowerCase()).toContain('expected value');
```

### Long-running / polling
```typescript
test.setTimeout(180000);
const deadline = Date.now() + 2 * 60 * 1000;
let recorded = false;
while (Date.now() < deadline) {
  const count = await page.locator('selector').count();
  if (count > 0) { recorded = true; break; }
  await page.waitForTimeout(5000);
  await page.reload();
}
expect(recorded).toBe(true);
```

---

## playwright.config.ts — Adding New Projects

When a new spec file is written for a user-type combination not yet covered in
`playwright.config.ts`, add a new project. Read the existing config to match
naming conventions.

**General pattern:**
```typescript
// Anonymous — no storageState
{
  name: 'bdd-canada-anonymous',
  testDir: './tests/bdd',
  use: { ...devices['Desktop Chrome'] },
  grep: /@anonymous/,
},

// Authenticated — requires storageState and setup dependency
{
  name: 'bdd-canada-regular',
  testDir: './tests/bdd',
  use: {
    ...devices['Desktop Chrome'],
    storageState: '.auth/<region>-regular.json',
  },
  grep: /@regular/,
  dependencies: ['setup-<region>-regular'],
},
```

Only add if the combination does not already exist.

---

## Running Tests

For the full command matrix (all regions, user types, and project names), see `forge:ui-tests-run`.

To run a single spec file during development:
```bash
TEST_ENV=<env> USER_TYPE=<user_type> npx playwright test <spec_path> --project=<project> --headed
```
