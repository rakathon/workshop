# Business Requirements

## BR-1: Members Can Add Payment Methods

Members must be able to add credit or debit cards to their account via Stripe tokenization.

**Acceptance criteria:**
- Raw card numbers are never stored by the system (Stripe tokenization only)
- Up to 5 cards can be stored per member

## BR-2: Members Can Remove Payment Methods

Members must be able to remove any non-default payment method.

## BR-3: Members Can Set a Default Payment Method

The default is used for all future purchases automatically.

## BR-4: Masked Card Display

Members see last 4 digits and card type only — no full card number exposed.
