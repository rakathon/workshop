# Business Requirements

## BR-1: Dark Mode Toggle Available in Settings

Members can toggle dark mode from their profile settings page.

**Acceptance criteria:**
- Toggle is accessible from the profile settings page
- Selection persists across sessions

## BR-2: Respects System Preference by Default

The theme defaults to the member's OS dark mode preference on first visit.

**Acceptance criteria:**
- First visit uses prefers-color-scheme media query result as the default
