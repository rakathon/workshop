# Business Requirements

*Extracted from: pm-doc.md*

## BR-1: Members Can Opt Out of Marketing Emails

Members must be able to register a preference to stop receiving marketing emails.
The preference must take effect within 24 hours of being set.

**Acceptance criteria:**
- A member who sets opt-out does not receive marketing emails after 24 hours
- The preference persists across sessions and devices

## BR-2: Confirmation on Opt-Out

When a member opts out, they receive a confirmation email at their registered address.

**Acceptance criteria:**
- Confirmation email is sent within 5 minutes of the opt-out being recorded

## BR-3: Preference Stored Against Member Profile (Implicit — not stated in PM document)

The preference is personal data associated with a specific member account. It must
be stored, retrievable, and deletable per data retention requirements.

**Acceptance criteria:**
- Preference is readable via the member profile API
- Preference is deleted when a member account is deleted (GDPR right to erasure)
