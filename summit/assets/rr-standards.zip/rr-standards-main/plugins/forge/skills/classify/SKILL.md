---
name: forge:classify
description: Assign an R1–R4 risk classification to the active effort. Use after requirements have been established and before deeper design work begins, or to revise an existing classification as design reveals new implications. Trigger on: "classify the risk", "what risk level is this?", "set the risk tier", "is this R1 or R2?", "how risky is this effort?", or when a suggestedRisk advisory is present in .state.json and needs confirmation. Reads the risk rubric, presents a recommendation with rationale, confirms with the engineer, and writes the committed classification to .state.json.
agent-type: orchestrator
---

# forge:classify

Assigns an R1–R4 risk tier to the active effort. Classification is a deliberate
decision, not a derivation — it requires engineer confirmation. A `suggestedRisk`
advisory in `.state.json` may serve as a starting point, but classification is
always the engineer's call.

Classification drives downstream ceremony: discovery depth, whether arch review
is required, whether implementation verification is required, and the PR approval
policy. Getting it right early — and updating it when design reveals new
implications — is the highest-leverage quality investment in the workflow.

---

## Step 0: Resolve Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

Record `effort_id` and `effort_dir` = `.forge/efforts/<effort_id>/`.

---

## Step 1: Read Current State

Read `<effort_dir>/.state.json`. Extract:

- `risk` — the current committed classification (if already set)
- `suggestedRisk` — advisory (if present)
- `suggestedRiskRationale` — rationale written alongside the suggestion

If `risk` is already set, surface it:
```
Current classification: <R?> (set previously)
```

If `suggestedRisk` is present, surface it as the starting point:
```
Suggested classification: <R?> — <suggestedRiskRationale>
```

If neither is set, proceed with no prior context.

---

## Step 2: Read Business Requirements

Read `<effort_dir>/requirements/business.md` if present. Extract the key domains,
data types, and integration points described — these are the primary signals for
the rubric in Step 3.

If `requirements/business.md` is absent, note it:
```
NOTE: requirements/business.md not found — classification will rely on rubric
criteria alone. Run forge:elaborate first for a more grounded recommendation.
```
Proceed without blocking.

---

## Step 3: Load the Risk Rubric

Read `standards/risk/classification.md` from the Forge plugin standards directory.
The CLAUDE.md in every initialized repository provides navigation context for the
plugin standards directory — use it to locate this file.

If the file cannot be found, use the built-in rubric below. Do not stop — the
rubric is stable and known:

| Tier | Core indicators |
|------|----------------|
| **R1** | Authentication, payments, PII at scale, data migrations with rollback risk, core platform capabilities |
| **R2** | New user-facing capability, external service integration, cross-team dependency, significant schema change |
| **R3** | Feature addition to existing capability, UI change, single-team scope, contained blast radius |
| **R4** | Documentation, logging, tooling, experimental work, minor copy change |

---

## Step 4: Apply the Rubric and Derive a Recommendation

Evaluate the requirements and domain against each rubric indicator. For each
tier from R1 downward, check whether any indicator applies. The classification
is the highest tier for which any indicator fires.

Prepare a recommendation in this format:

```
Recommended: <R?>

Why <R?>:
  ✓ <indicator that fired>
  ✓ <indicator that fired>

Why not higher (omit if recommending R1):
  ✗ <higher-tier indicator> — not present in this capability

Why not lower (omit if recommending R4):
  — <lower-tier threshold> would apply if <condition>, but this capability has <reason>
```

Omit "Why not higher" when recommending R1 (nothing higher exists).
Omit "Why not lower" when recommending R4 (nothing lower exists).

Show the reasoning explicitly. Engineers use this to catch misclassifications —
a security-relevant requirement that was missed, or an indicator that does not
actually apply on closer inspection.

If `suggestedRisk` from Step 1 matches your recommendation, note the agreement.
If it differs, explain why.

---

## Step 5: Confirm with the Engineer

Present the recommendation and wait for one of three responses:

**Confirm:** Engineer agrees. Proceed to Step 6 with the recommended tier.

**Override:** Engineer specifies a different tier. Ask:
```
Override to <R?>. What is the rationale? (brief note — recorded in .state.json)
```
Wait for a response. Accept any response including a single word. Proceed to
Step 6 with the engineer's tier and their stated rationale.

**Revise:** Engineer wants to reconsider the requirements before deciding. Stop.
Suggest running `forge:elaborate` or revisiting specific requirements. Do not
write anything to `.state.json`.

---

## Step 6: Write to .state.json

Read the current `.state.json`. Update the following fields — do not overwrite
other fields:

```json
"risk": "<R1|R2|R3|R4>",
"riskRationale": "<one sentence — the primary reason for this tier>"
```

Clear the advisory fields:
```json
"suggestedRisk": null,
"suggestedRiskRationale": null
```

If these advisory fields are absent, skip the clear step — do not add null fields.

---

## Step 7: Print Summary

```
Risk classification set: <R?> — <riskRationale>

What this means:
  <one-line consequence appropriate to the tier>

Next steps:
  forge:elaborate <effort-id>  — expand BRs into technical requirements
  forge:spec-api <effort-id> — begin API contract design (can run concurrently)
```

Tier-appropriate consequence lines:

| Tier | Consequence line |
|------|-----------------|
| R1 | Full discovery required · arch review meeting · verification required · AI + human PR approval |
| R2 | Full discovery required · verification required · AI + human PR approval |
| R3 | Discovery recommended · verification optional · AI approval sufficient |
| R4 | Lightweight process · no discovery required · AI approval sufficient |

---

## Re-invocation

`forge:classify` may be invoked at any point during the effort lifecycle to revise
the classification. When re-invoked after a classification is already set:

1. Show the current classification and its rationale
2. Show what has changed since it was set (prompt the engineer: "What new
   information prompted the revision?")
3. Re-run Steps 3–6 with the updated context

There is no restriction on escalating or de-escalating the tier — the engineer
decides based on what discovery has revealed.

---

## Error Handling

| Condition | Action |
|-----------|--------|
| `.state.json` not found | Stop: "No active effort found. Run forge:effort to initialize one." |
| `currentPhase` is not `discovery` | Warn: "Risk is typically classified during discovery, but classification can be revised at any phase. Proceed?" — continue if confirmed |
| Engineer does not confirm, override, or revise after two exchanges | Stop, suggest re-invoking when ready |
