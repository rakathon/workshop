#Requires -Version 5.1
<#
.SYNOPSIS
    Slack Auth -- PowerShell entry point for the forge:slack-auth skill.
    Used on native Windows (no WSL2, no bash). Pure PowerShell 5.1, no
    dependencies beyond what ships with Windows 10/11.

.DESCRIPTION
    Two-phase PKCE OAuth flow matching slack_auth.sh behaviour.

    --prepare   Non-blocking. Checks existing token, or generates PKCE state,
                opens browser, writes state to $env:TEMP\slack_auth_state.json,
                outputs AUTH_URL=... and exits immediately.

    --listen    Blocking (up to 5 min). Reads state file, starts HttpListener,
                waits for OAuth callback, exchanges code for token, stores result.

    --check     Show stored tokens and verify each is still valid.
    --revoke    Remove a stored token.

.EXAMPLE
    .\slack_auth.ps1 -prepare
    .\slack_auth.ps1 -listen
    .\slack_auth.ps1 -check
    .\slack_auth.ps1 -revoke
#>

param(
    [switch]$prepare,
    [switch]$listen,
    [switch]$check,
    [switch]$revoke
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Required for [System.Web.HttpUtility]::ParseQueryString in PowerShell 5.1
Add-Type -AssemblyName System.Web

# -- Constants ----------------------------------------------------------------
$CLIENT_ID     = "3414236285.11054762287428"
$REDIRECT_URI  = "http://localhost:3013/callback"
$CALLBACK_PORT = 3013
$TOKEN_FILE    = Join-Path $env:USERPROFILE ".slack_user_tokens.json"
$STATE_FILE    = Join-Path $env:TEMP "slack_auth_state.json"
$USER_SCOPES = @(
    "identify",
    "channels:history", "groups:history", "im:history", "mpim:history",
    "channels:read", "groups:read", "mpim:read", "emoji:read",
    "files:write", "files:read",
    "users:read", "users:read.email",
    "chat:write", "reactions:read", "reactions:write",
    "canvases:read", "canvases:write", "groups:write", "im:write", "mpim:write",
    "search:read"
)

# -- Utilities ----------------------------------------------------------------

function Is-UserToken([string]$t) {
    return $t -and ($t.StartsWith("xoxp-") -or $t.StartsWith("xoxe.xoxp-"))
}

function Invoke-SlackGet([string]$token, [string]$method, [hashtable]$params = @{}) {
    $url = "https://slack.com/api/$method"
    if ($params.Count -gt 0) {
        $qs = ($params.GetEnumerator() |
               ForEach-Object { "$($_.Key)=$([Uri]::EscapeDataString($_.Value))" }) -join "&"
        $url = "$url?$qs"
    }
    return Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $token"} -Method Get
}

function Load-Stored {
    if (-not (Test-Path $TOKEN_FILE)) { return @{} }
    $json = Get-Content $TOKEN_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
    $ht = @{}
    $json.PSObject.Properties | ForEach-Object { $ht[$_.Name] = $_.Value }
    return $ht
}

function Save-Stored([hashtable]$stored) {
    $tmp = "$TOKEN_FILE.tmp"
    $stored | ConvertTo-Json -Depth 5 | Set-Content -Path $tmp -Encoding UTF8
    Move-Item -Force -Path $tmp -Destination $TOKEN_FILE
    # Restrict to current user only (best-effort on NTFS)
    try {
        $acl = Get-Acl $TOKEN_FILE
        $acl.SetAccessRuleProtection($true, $false)
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,
            "FullControl", "Allow")
        $acl.SetAccessRule($rule)
        Set-Acl -Path $TOKEN_FILE -AclObject $acl
    } catch { }
}

function ConvertTo-EntryHash($obj) {
    $ht = @{}
    $obj.PSObject.Properties | ForEach-Object { $ht[$_.Name] = $_.Value }
    return $ht
}

function Refresh-TokenIfNeeded([hashtable]$entry) {
    if (-not $entry.ContainsKey("refresh_token")) { return $entry }
    $expiresAt = if ($entry.ContainsKey("expires_at")) { [long]$entry["expires_at"] } else { 0 }
    $now = [DateTimeOffset]::Now.ToUnixTimeSeconds()
    if ($now -lt ($expiresAt - 300)) { return $entry }

    $body = "client_id=$CLIENT_ID&grant_type=refresh_token&refresh_token=$($entry['refresh_token'])"
    $resp = Invoke-RestMethod -Uri "https://slack.com/api/tooling.tokens.rotate" `
        -Method Post -Body $body -ContentType "application/x-www-form-urlencoded"
    if (-not $resp.ok) { throw "Token refresh failed: $($resp.error)" }
    $entry["token"]         = $resp.token
    $entry["refresh_token"] = $resp.refresh_token
    # 'exp' from tooling.tokens.rotate is an absolute Unix timestamp
    $entry["expires_at"] = if ($resp.PSObject.Properties["exp"]) { [long]$resp.exp } `
                           else { $now + 43200 }
    return $entry
}

function Generate-PKCE {
    $bytes = New-Object byte[] 64
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $script:CODE_VERIFIER = [Convert]::ToBase64String($bytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")

    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $hashBytes = $sha256.ComputeHash([System.Text.Encoding]::ASCII.GetBytes($script:CODE_VERIFIER))
    $script:CODE_CHALLENGE = [Convert]::ToBase64String($hashBytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")

    $stateBytes = New-Object byte[] 16
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($stateBytes)
    $script:STATE = [Convert]::ToBase64String($stateBytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")
}

function Build-AuthUrl {
    $scopeStr = $USER_SCOPES -join ","
    $params = "client_id=$CLIENT_ID" +
              "&user_scope=$([Uri]::EscapeDataString($scopeStr))" +
              "&redirect_uri=$([Uri]::EscapeDataString($REDIRECT_URI))" +
              "&state=$([Uri]::EscapeDataString($script:STATE))" +
              "&code_challenge=$([Uri]::EscapeDataString($script:CODE_CHALLENGE))" +
              "&code_challenge_method=S256"
    return "https://slack.com/oauth/v2/authorize?$params"
}

function Write-StateFile([hashtable]$data) {
    $data | ConvertTo-Json | Set-Content -Path $STATE_FILE -Encoding UTF8
}

function Read-StateFile {
    if (-not (Test-Path $STATE_FILE)) {
        Write-Host "ERROR: State file not found: $STATE_FILE. Run -prepare first."
        exit 1
    }
    $json = Get-Content $STATE_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
    $ht = @{}
    $json.PSObject.Properties | ForEach-Object { $ht[$_.Name] = $_.Value }
    return $ht
}

# -- --check ------------------------------------------------------------------
if ($check) {
    $stored = Load-Stored
    if ($stored.Count -eq 0) {
        Write-Host "No tokens stored. Run forge:slack-auth to authenticate."
        exit 0
    }
    Write-Host ""
    Write-Host "Stored Slack user tokens:"
    Write-Host ""
    $needsSave = $false
    foreach ($tid in $stored.Keys) {
        $entry = ConvertTo-EntryHash $stored[$tid]
        try {
            $refreshed = Refresh-TokenIfNeeded $entry
            if ($refreshed["token"] -ne $entry["token"]) {
                $stored[$tid] = $refreshed
                $needsSave = $true
            }
            $entry = $refreshed
            $v     = Invoke-SlackGet $entry["token"] "auth.test"
            $status = if ($v.ok) { "[OK] valid" } else { "[FAIL] invalid ($($v.error))" }
        } catch {
            $status = "[FAIL] error ($_)"
        }
        $scopes  = $entry["scopes"]
        $fw      = if ($scopes -contains "files:write") { "[OK]" } else { "[FAIL]" }
        $rotNote = ""
        if ($entry.ContainsKey("expires_at")) {
            $rem = [long]$entry["expires_at"] - [DateTimeOffset]::Now.ToUnixTimeSeconds()
            $h   = [Math]::Floor([Math]::Max($rem, 0) / 3600)
            $m   = [Math]::Floor(([Math]::Max($rem, 0) % 3600) / 60)
            $rotNote = "`n    Rotation:    enabled - valid for ${h}h ${m}m"
        }
        Write-Host "  $($entry['team_name']) ($tid)"
        Write-Host "    Status:      $status"
        Write-Host "    User:        $($entry['user_name'])"
        Write-Host "    files:write: $fw$rotNote"
        Write-Host "    All scopes:  $($scopes -join ', ')"
        Write-Host ""
    }
    if ($needsSave) { Save-Stored $stored }
    exit 0
}

# -- --revoke -----------------------------------------------------------------
if ($revoke) {
    $stored = Load-Stored
    if ($stored.Count -eq 0) { Write-Host "No tokens stored."; exit 0 }

    if ($stored.Count -eq 1) {
        $tid      = @($stored.Keys)[0]
        $teamName = (ConvertTo-EntryHash $stored[$tid])["team_name"]
    } else {
        $items = @($stored.Keys)
        Write-Host "Stored workspaces:"
        for ($i = 0; $i -lt $items.Count; $i++) {
            $e = ConvertTo-EntryHash $stored[$items[$i]]
            Write-Host "  $($i+1). $($e['team_name']) ($($items[$i]))"
        }
        $choice = Read-Host "Enter number to revoke"
        $idx = [int]$choice - 1
        if ($idx -lt 0 -or $idx -ge $items.Count) { Write-Host "Invalid selection."; exit 1 }
        $tid      = $items[$idx]
        $teamName = (ConvertTo-EntryHash $stored[$tid])["team_name"]
    }

    $stored.Remove($tid)
    Save-Stored $stored
    Write-Host "Token for $teamName removed."
    Write-Host "Run forge:slack-auth to re-authenticate."
    exit 0
}

# -- --prepare ----------------------------------------------------------------
if ($prepare) {
    $stored = Load-Stored
    foreach ($tid in $stored.Keys) {
        $entry = ConvertTo-EntryHash $stored[$tid]
        try {
            $entry = Refresh-TokenIfNeeded $entry
            $v     = Invoke-SlackGet $entry["token"] "auth.test"
            if ($v.ok) {
                $scopes = $entry["scopes"]
                $fw     = if ($scopes -contains "files:write") { "[OK]" } else { "[FAIL]" }
                $note   = ""
                if ($entry.ContainsKey("expires_at")) {
                    $rem  = [long]$entry["expires_at"] - [DateTimeOffset]::Now.ToUnixTimeSeconds()
                    $h    = [Math]::Floor([Math]::Max($rem, 0) / 3600)
                    $m    = [Math]::Floor(([Math]::Max($rem, 0) % 3600) / 60)
                    $note = "valid for ${h}h ${m}m, then auto-refreshes"
                }
                $stored[$tid] = $entry
                Save-Stored $stored
                Write-Host "Valid token already stored for $($entry['team_name']) ($tid). $note"
                Write-Host "User: $($entry['user_name'])  |  files:write: $fw"
                exit 0
            }
        } catch {
            Write-Host "Token for $tid is invalid ($_), will re-authenticate."
        }
    }

    Generate-PKCE
    $authUrl = Build-AuthUrl

    Write-StateFile @{
        status        = "new"
        auth_url      = $authUrl
        code_verifier = $script:CODE_VERIFIER
        state         = $script:STATE
        platform      = "windows"
    }

    Start-Process $authUrl

    Write-Host "Platform: windows"
    Write-Host "Browser: opened"
    Write-Host "AUTH_URL=$authUrl"
    exit 0
}

# -- --listen -----------------------------------------------------------------
if ($listen) {
    $s = Read-StateFile
    if ($s["status"] -eq "existing") {
        Write-Host "Token already stored -- nothing to do."
        exit 0
    }

    $codeVerifier  = $s["code_verifier"]
    $expectedState = $s["state"]

    $listener = [System.Net.HttpListener]::new()
    $listener.Prefixes.Add("http://localhost:${CALLBACK_PORT}/")
    try {
        $listener.Start()
    } catch {
        Write-Host "ERROR: Cannot start listener on port ${CALLBACK_PORT}: $_"
        Write-Host "Another process may be using it. Check: netstat -an | findstr :${CALLBACK_PORT}"
        exit 1
    }

    Write-Host "Listening for OAuth callback on localhost:${CALLBACK_PORT}..."

    $asyncResult  = $listener.BeginGetContext($null, $null)
    $gotCallback  = $asyncResult.AsyncWaitHandle.WaitOne(300000)

    if (-not $gotCallback) {
        $listener.Stop()
        Remove-Item -Force $STATE_FILE -ErrorAction SilentlyContinue
        Write-Host "ERROR: Timed out after 5 minutes. Re-run forge:slack-auth to try again."
        exit 1
    }

    $context  = $listener.EndGetContext($asyncResult)
    $qs       = [System.Web.HttpUtility]::ParseQueryString($context.Request.Url.Query)
    $code     = $qs["code"]
    $err      = $qs["error"]
    $retState = $qs["state"]

    $successHtml = '<!DOCTYPE html><html><body style="font-family:sans-serif;text-align:center;padding:60px"><h2>Authentication successful!</h2><p>You can close this tab and return to the terminal.</p></body></html>'
    $failHtml    = "<!DOCTYPE html><html><body style='font-family:sans-serif;text-align:center;padding:60px'><h2>Authentication failed</h2><p>$err</p></body></html>"
    $html        = if ($code) { $successHtml } else { $failHtml }

    $buf = [System.Text.Encoding]::UTF8.GetBytes($html)
    $context.Response.ContentType = "text/html; charset=utf-8"
    $context.Response.OutputStream.Write($buf, 0, $buf.Length)
    $context.Response.Close()
    $listener.Stop()
    Remove-Item -Force $STATE_FILE -ErrorAction SilentlyContinue

    if (-not $code) {
        Write-Host "ERROR: Slack returned an error: $err"
        exit 1
    }
    if ($retState -ne $expectedState) {
        Write-Host "ERROR: State mismatch -- stale redirect. Re-run forge:slack-auth."
        exit 1
    }

    Write-Host "Authorization received. Exchanging code for token..."

    $encodedRedirect = [Uri]::EscapeDataString($REDIRECT_URI)
    $body = "code=$code&redirect_uri=$encodedRedirect&client_id=$CLIENT_ID&code_verifier=$codeVerifier"
    $resp = Invoke-RestMethod -Uri "https://slack.com/api/oauth.v2.access" `
        -Method Post -Body $body -ContentType "application/x-www-form-urlencoded"

    if (-not $resp.ok) {
        Write-Host "ERROR: Token exchange failed: $($resp.error)"
        Write-Host ($resp | ConvertTo-Json -Depth 5)
        exit 1
    }

    $userToken     = $resp.authed_user.access_token
    $grantedScopes = $resp.authed_user.scope -split ","
    $refreshTok    = if ($resp.authed_user.PSObject.Properties["refresh_token"]) { $resp.authed_user.refresh_token } else { $null }
    $expiresIn     = if ($resp.authed_user.PSObject.Properties["expires_in"])    { [long]$resp.authed_user.expires_in } else { $null }
    $expiresAt     = if ($expiresIn) { [DateTimeOffset]::Now.ToUnixTimeSeconds() + $expiresIn } else { $null }

    if (-not (Is-UserToken $userToken)) {
        Write-Host "ERROR: No user token in response. Check User Token Scopes at api.slack.com."
        Write-Host ($resp | ConvertTo-Json -Depth 5)
        exit 1
    }

    $v2 = Invoke-SlackGet $userToken "auth.test"
    if (-not $v2.ok) {
        Write-Host "ERROR: Token verification failed: $($v2.error)"
        exit 1
    }

    $teamId   = $v2.team_id
    $teamName = $v2.team
    $userName = $v2.user
    $userId   = $v2.user_id

    $stored = Load-Stored
    $entry  = @{
        team_name = $teamName
        team_id   = $teamId
        user_name = $userName
        user_id   = $userId
        token     = $userToken
        scopes    = $grantedScopes
    }
    if ($refreshTok) { $entry["refresh_token"] = $refreshTok }
    if ($expiresAt)  { $entry["expires_at"]    = $expiresAt  }
    $stored[$teamId] = $entry
    Save-Stored $stored

    $fw  = if ($grantedScopes -contains "files:write") { "[OK]" } else { "[FAIL]" }
    $rot = if ($expiresIn) { "`n   Token rotation: enabled (auto-refreshes every $([Math]::Floor($expiresIn / 3600))h)" } else { "" }

    Write-Host ""
    Write-Host "Slack authentication successful!"
    Write-Host ""
    Write-Host "   Workspace:   $teamName ($teamId)"
    Write-Host "   User:        $userName ($userId)"
    Write-Host "   files:write: $fw"
    Write-Host "   All scopes:  $($grantedScopes -join ', ')"
    Write-Host $rot
    Write-Host ""
    Write-Host "Token stored in $TOKEN_FILE"
    Write-Host "Other team members: run forge:slack-auth to authenticate as themselves."

    if ($grantedScopes -notcontains "files:write") {
        Write-Host ""
        Write-Host "WARNING: files:write was NOT granted. Add it under User Token Scopes at api.slack.com."
    }
    exit 0
}

Write-Host "Usage: slack_auth.ps1 [-prepare] [-listen] [-check] [-revoke]"
exit 1
