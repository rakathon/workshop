---
name: forge:slack-auth
description: >
  Obtain a personal Slack OAuth user token (xoxp-) for a workspace by running a
  local PKCE OAuth flow. No client secret required — safe for any team member to use.
  Stores the token in ~/.slack_user_tokens.json keyed by team_id. Required before
  forge:slack-file-transfer or any skill that needs user-level Slack permissions.
  Trigger on: "authenticate with Slack", "get a Slack token", "set up Slack auth",
  "run slack-auth", "I need to authorize Slack", "my Slack token is expired",
  "forge:slack-auth --check", "forge:slack-auth --revoke".
agent-type: orchestrator
argument-hint: "[--check|--revoke]"
---

# forge:slack-auth

Authenticate as yourself against a Slack workspace and obtain a personal user token.
Uses PKCE (no client secret) — safe to share with any team member with no per-user
configuration needed.

**Usage:**
- `forge:slack-auth` — run the OAuth flow
- `forge:slack-auth --check` — show stored tokens and scopes without re-authenticating
- `forge:slack-auth --revoke` — remove a stored token

---

## Step 0: Resolve Script Directory

Before running any scripts, resolve the path to this skill's bundled scripts.

Read `../../.claude-plugin/plugin.json` using the Read tool. The resolved absolute
path has the form `<plugin_root>/.claude-plugin/plugin.json`. Strip the
`/.claude-plugin/plugin.json` suffix to get `plugin_root`.

Set `skill_dir = "<plugin_root>/skills/slack-auth"`.

Use `skill_dir` for all script invocations in this skill. All `${skill_dir}` references
below should be replaced with the resolved absolute path.

For the full resolution procedure, see:
  `plugins/forge/skills/common/plugin-root.md`

---

## How to Run

### Detect which entry point to use

First detect the platform by running a Bash command that identifies the OS:

```bash
uname -s 2>/dev/null || echo "Windows"
```

- Output starts with `Darwin` → macOS → use `slack_auth.sh`
- Output starts with `Linux` + `/proc/version` contains `microsoft` → WSL2 → use `slack_auth.sh`
- Output starts with `Linux` → native Linux → use `slack_auth.sh`
- Command fails or output is `Windows` → native Windows → use `slack_auth.ps1`

### Entry point commands

**macOS / Linux / WSL2** — bash:
```bash
bash "${skill_dir}/slack_auth.sh" [--prepare|--listen|--check|--revoke]
```

**Native Windows** — PowerShell:
```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "${skill_dir}/slack_auth.ps1" [-prepare|-listen|-check|-revoke]
```

If the script was copied from WSL2 or downloaded, Windows may block it with a Zone.Identifier mark. Unblock it once with:
```powershell
Unblock-File "${skill_dir}/slack_auth.ps1"
```
After that it runs normally with no flags needed.

`skill_dir` is resolved in Step 0 above.

---

## Two-Phase OAuth Flow

The OAuth flow is split into two phases so Claude can surface the authorization URL
to the user via `AskUserQuestion` *before* the blocking listener starts — making it
always visible and copy-pasteable regardless of output buffering.

### Phase 1 — Prepare (non-blocking, instant)

```bash
# bash/sh platforms:
output=$(bash "${skill_dir}/slack_auth.sh" --prepare)

# native Windows:
output=$(powershell.exe -NoProfile -File "${skill_dir}/slack_auth.ps1" -prepare)
```

Parse `output` for a line starting with `AUTH_URL=`:

```python
auth_url = None
for line in output.splitlines():
    if line.startswith('AUTH_URL='):
        auth_url = line[len('AUTH_URL='):]
        break
```

If no `AUTH_URL=` line is found, the flow is complete — a valid token was already stored.
Show the output to the user (it includes workspace, user, and expiry info) and exit.
Do not proceed to Phase 2.

**Branch to Phase 2a or 2b:**
- If `output` contains `"Using URL-paste flow"` → proceed to **Phase 2b** (curl path, no local listener)
- Otherwise → proceed to **Phase 2a** (Python 3 or PowerShell, seamless callback)

### Phase 2a — Seamless listener (Python 3 / PowerShell path)

**Critical:** The listener must be running BEFORE the user clicks Allow in the browser. Send both tool calls in a **single message** so they start simultaneously:

**Tool call 1** — Bash with `run_in_background=true`:
```bash
# bash platforms:
bash "${skill_dir}/slack_auth.sh" --listen

# native Windows:
powershell.exe -NoProfile -File "${skill_dir}/slack_auth.ps1" -listen
```

**Tool call 2** — AskUserQuestion (sent in same message as tool call 1):
```
question: "Slack authorization is ready. The browser should have opened automatically.
           If not, copy this URL and open it in your browser:

           {auth_url}

           Once you have authorized in Slack, click Continue."
header: "Authorize Slack"
options:
  - label: "Continue — I've authorized in Slack"
  - label: "Cancel"
```

The listener is running within milliseconds. The user takes time to read, switch to the browser, and click Allow — by that point the listener is ready. When the callback arrives, the token is exchanged and stored in the background. The user then clicks Continue to confirm.

- If user selects "Continue": the background Bash task will have already completed (the token is written the moment the OAuth callback arrives). Collect the background task output — it contains the confirmation message with workspace name, user, and scopes. Display it to the user.
- If user selects "Cancel": inform the user the OAuth flow was abandoned. The background listener will time out on its own after 5 minutes. They can re-run `forge:slack-auth` at any time.

### Phase 2b — URL-paste flow (curl fallback, non-developer Mac)

When `--prepare` output includes `Using URL-paste flow`, the curl path is active. Use `AskUserQuestion` to collect the callback URL — the user must paste the full redirect URL from their browser address bar:

```
question: "Open this URL in your browser and click Allow.
           After authorizing, your browser will redirect to localhost:3013 and
           show a connection error — that is expected, nothing is listening.

           Copy the FULL URL from the browser address bar and paste it below
           using 'Other'.

           Authorization URL:
           {auth_url}"
header: "Paste callback URL"
options:
  - label: "Paste callback URL (use 'Other' to type/paste)"
  - label: "Cancel — abort the flow"
```

- If user pastes a URL: pass it to the listen phase:
  ```bash
  bash "${skill_dir}/slack_auth.sh" --listen "{pasted_callback_url}"
  ```
  Display the script output to the user.
- If user selects "Cancel": stop. Inform the user they can re-run `forge:slack-auth` at any time.

### --check and --revoke (single phase, no listener)

Run the appropriate command for the detected platform and display the output to the user:

```bash
bash "${skill_dir}/slack_auth.sh" --check    # macOS/Linux/WSL2
bash "${skill_dir}/slack_auth.sh" --revoke

powershell.exe -NoProfile -File "${skill_dir}/slack_auth.ps1" -check    # native Windows
powershell.exe -NoProfile -File "${skill_dir}/slack_auth.ps1" -revoke
```

---

## Files in This Skill

| File | Purpose |
|---|---|
| `slack_auth.sh` | Entry point for macOS, Linux, and WSL2. Detects runtime (Python 3 → PowerShell → curl), handles all modes. |
| `slack_auth.ps1` | Entry point for **native Windows** (no WSL2, no bash). Pure PowerShell — no other dependencies. |
| `slack_auth_listener.py` | Python HTTP listener flow. Called by `slack_auth.sh` when Python 3 is available. |

---

## Three-Path Architecture

The skill detects the best available runtime automatically. No installation is required on any supported platform.

| Runtime detected | Flow | Platforms |
|---|---|---|
| Python 3 (real, not macOS stub) | Seamless — local HTTP server receives the OAuth callback automatically | WSL2, macOS (developer), Linux, Windows with Python |
| PowerShell 5.1+ | Seamless — .NET `HttpListener` receives the callback | Native Windows (PowerShell is guaranteed built-in) |
| curl + openssl | URL-paste — user copies the redirect URL from browser address bar | Non-developer Mac (Claude Desktop only), any minimal system |

**Detection order:** Python 3 → PowerShell → curl+openssl.

The macOS Python 3 stub (present on macOS 12.3+ without Xcode) is detected and skipped — it would trigger an Xcode install dialog rather than running Python. The check is: `python3 -c "import sys; sys.exit(0)"`.

---

## URL-Paste Flow (curl path)

When neither Python 3 nor PowerShell is available:

1. The auth URL is printed in full to the terminal (always copy-pasteable)
2. The browser opens (or the user pastes the URL manually)
3. The user authorizes in Slack's web UI
4. Slack redirects to `http://localhost:3013/callback?code=...&state=...`
5. The browser shows "can't connect" — **this is expected**, nothing is listening
6. The user copies the full URL from the browser address bar and pastes it into the terminal
7. The script extracts the `code` and `state`, verifies state, and calls `oauth.v2.access` via curl

---

## App Configuration

| Setting | Value |
|---|---|
| Client ID | `3414236285.11054762287428` |
| Redirect URI | `http://localhost:3013/callback` |
| PKCE | Enabled (opted in at api.slack.com) |
| Token rotation | Enabled — 12h expiry, `refresh_token` issued, auto-refresh via `tooling.tokens.rotate` |

The Client ID is safe to commit — it cannot be used to obtain tokens without a user completing the browser-based OAuth flow.

---

## User Token Scopes

All of the following must be present in the app's **User Token Scopes** allowlist at api.slack.com → OAuth & Permissions. Scopes absent from the allowlist are silently dropped by Slack.

```
identify
channels:history, groups:history, im:history, mpim:history
channels:read, groups:read, mpim:read, emoji:read
files:write, files:read
users:read, users:read.email
chat:write
reactions:read, reactions:write
canvases:read, canvases:write
groups:write, im:write, mpim:write
search:read
```

---

## Token Storage

Tokens are stored in `~/.slack_user_tokens.json` (outside all repositories, `chmod 600`), keyed by Slack team ID. Each entry includes:

```json
{
  "T01EXAMPLE": {
    "team_name": "My Workspace",
    "team_id": "T01EXAMPLE",
    "user_name": "jane.smith",
    "user_id": "U02EXAMPLE",
    "token": "xoxe.xoxp-1-...",
    "scopes": ["channels:history", "files:write", "..."],
    "refresh_token": "xoxe-1-...",
    "expires_at": 1779169021
  }
}
```

---

## Token Rotation

This app has token rotation enabled:
- Tokens expire after **12 hours** (`expires_in: 43200`)
- Each token includes a `refresh_token`
- Refresh endpoint: `https://slack.com/api/tooling.tokens.rotate`
- The `exp` field in the refresh response is an **absolute Unix timestamp** (not seconds remaining)
- After refresh, both `token` and `refresh_token` are replaced — the old refresh token is immediately invalidated

---

## How Other Skills Load the Token

Include this in any skill that needs a user-level Slack token. It handles refresh automatically:

```python
import json, os, time, urllib.request, urllib.parse

CLIENT_ID = '3414236285.11054762287428'

def refresh_token_if_needed(entry):
    expires_at = entry.get('expires_at', 0)
    rt = entry.get('refresh_token')
    if not rt or time.time() < expires_at - 300:
        return entry
    post = urllib.parse.urlencode({
        'client_id': CLIENT_ID, 'grant_type': 'refresh_token', 'refresh_token': rt,
    }).encode('ascii')
    req = urllib.request.Request(
        'https://slack.com/api/tooling.tokens.rotate', data=post, method='POST',
        headers={'Content-Type': 'application/x-www-form-urlencoded'})
    with urllib.request.urlopen(req) as r:
        resp = json.loads(r.read())
    if not resp.get('ok'):
        raise RuntimeError(f"Token refresh failed: {resp.get('error')}")
    entry['token']         = resp['token']
    entry['refresh_token'] = resp['refresh_token']
    entry['expires_at']    = resp.get('exp', int(time.time()) + 43200)  # exp is absolute timestamp
    return entry

def load_user_token(team_id=None):
    """
    Load and auto-refresh a stored xoxp user token.
    Returns (token, entry_dict) or (None, None).
    """
    token_file = os.path.expanduser('~/.slack_user_tokens.json')
    if not os.path.exists(token_file):
        return None, None
    with open(token_file) as f:
        stored = json.load(f)
    if not stored:
        return None, None
    if team_id and team_id in stored:
        entry = stored[team_id]
    elif len(stored) == 1:
        team_id, entry = list(stored.items())[0]
    else:
        return None, None

    entry = refresh_token_if_needed(entry)
    stored[team_id] = entry
    tmp = token_file + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(stored, f, indent=2)
    os.replace(tmp, token_file)

    return entry['token'], entry
```

**Usage:**
```python
user_token, token_entry = load_user_token()
if user_token is None:
    print('No Slack user token found. Run forge:slack-auth first.')
else:
    # Use user_token for files.getUploadURLExternal, files.completeUploadExternal, etc.
    pass
```

**Note:** `load_user_token()` returns `(None, None)` silently when multiple workspaces are stored and no `team_id` is given. If your skill needs to handle multiple workspaces, use the two-step pattern from `forge:slack-file-transfer` Phase 0: call `load_stored_tokens()` to read all entries, present workspace selection to the user, then call `load_user_token(stored, team_id)` with the selected ID.

---

## Security Notes

- `~/.slack_user_tokens.json` is set to `chmod 600` via `os.chmod(path, 0o600)` — portable across all platforms, no subprocess required
- Client ID is public; Client Secret does not exist (PKCE flow)
- PKCE `code_verifier` is written to `/tmp/slack_auth_state.json` (chmod 600) during the flow and deleted immediately after the callback is received
- Local server (Python/PowerShell paths) binds to `localhost` only and shuts down after one callback
- `state` parameter verified before code exchange (CSRF protection)
- Each user's token is independent — one revoked token does not affect others
