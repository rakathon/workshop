# forge:slack-auth

Obtain a personal Slack user token (`xoxp-`) for one or more workspaces using
a browser-based PKCE OAuth flow. Stores the token locally for use by other skills
that need user-level Slack API access — particularly `forge:slack-file-transfer`.

---

## What it does

`forge:slack-auth` opens your browser to Slack's authorization page, where you
sign in as yourself (SSO-compatible). After you click Allow, the skill exchanges
the authorization code for a personal user token and saves it to
`~/.slack_user_tokens.json`. The token acts as you in the Slack API — same
channel access, same permissions as the Slack desktop app.

The flow uses PKCE (no client secret) so the skill is safe to share across a
team: every team member runs `/slack-auth` once and gets their own independent
token.

Token rotation is enabled: tokens expire after 12 hours and auto-refresh
transparently. You will not normally need to re-run the skill unless you revoke
the token.

## Usage

```
/slack-auth                  — run the OAuth flow (or confirm an existing token is valid)
/slack-auth --check          — show stored tokens and verify each is still live
/slack-auth --revoke         — remove a stored token
```

## When to use

- Before running `forge:slack-file-transfer` for the first time
- After a token is revoked or a new workspace needs to be authorized
- To verify which workspaces you currently have tokens for

## Prerequisites

None beyond a Slack account and access to a browser.

## Platform support

The skill detects the runtime environment automatically:

| Environment | Browser-open mechanism | Token exchange |
|---|---|---|
| WSL2 (Ubuntu on Windows) | PowerShell `Start-Process` | Python 3 HTTP listener |
| macOS (developer) | `open` command | Python 3 HTTP listener |
| macOS (Claude Desktop, no Python) | `open` command | URL-paste fallback |
| Native Windows (no WSL2) | Use `slack_auth.ps1` directly | PowerShell `HttpListener` |
| Linux | `xdg-open` | Python 3 HTTP listener |

On systems without Python 3 (non-developer Mac with Claude Desktop only), a
URL-paste fallback is used: after authorizing in the browser, the user copies
the redirect URL from the address bar and pastes it into the terminal.

## Output

A token entry is written to `~/.slack_user_tokens.json` (chmod 600), keyed by
Slack team ID. Each entry stores the token, scopes, and rotation metadata.
Other skills load the token from this file via `load_user_token()`.

## Files in this skill

| File | Purpose |
|---|---|
| `SKILL.md` | Skill instructions loaded by Claude when the skill runs |
| `slack_auth.sh` | Entry point for macOS, Linux, and WSL2 |
| `slack_auth.ps1` | Entry point for native Windows (no bash required) |
| `slack_auth_listener.py` | Python HTTP callback listener and all token operations |

## Relationship to other skills

`forge:slack-auth` is a prerequisite for `forge:slack-file-transfer`. It has
no dependency on any Slack MCP server — it uses the Slack Web API directly.
