---
name: forge:spec-api
description: Design REST API contracts during discovery. Default mode drafts the entire API from requirements and presents it for review in one pass. Use --interactive (or say "let's design this together") for resource-by-resource co-authoring. Flags: --resource <name> (scope to one resource), --file <path> (write contract to specific file), --deployable <name> (target deployable when no active effort), --capability <name> (target capability, requires --deployable). Trigger on: "design an API", "author the OpenAPI contract", "what endpoints do we need?", "design REST endpoints", "create the API spec", "draft the API", "generate the API contract". Works with or without a formal Forge effort — if no requirements file exists, describe the operations conversationally. Applies the organizational REST standard throughout.
agent-type: orchestrator
argument-hint: "[--interactive] [--resource <name>] [--file <path>] [--deployable <name>] [--capability <name>]"
---

# forge:spec-api

Produces a REST API contract (OpenAPI YAML) by applying the organizational REST
standard to the operations required by the effort. Works in two modes:

- **One-shot (default):** Drafts the complete API from requirements and presents the
  full contract for review. The engineer reviews and requests changes in a single pass.
- **Interactive (`--interactive`):** Co-authors one resource at a time. Use when the
  engineer wants to steer each design decision as it's made, or when requirements are
  sparse and the design needs more conversation.

The standard defines what makes a correct API. This skill's job is to apply that
standard and manage the workflow — not to re-embed the standard's rules inline.

**Variable resolution:**

| Variable | Value |
|----------|-------|
| `<effort_dir>` | `.forge/efforts/<effort-id>/` |
| `<deployable_dir>` | `.forge/deployables/<name>/` |
| `<capability_dir>` | `.forge/deployables/<name>/capabilities/<capability>/` |

**`<spec_dir>` and `<contract-name>`** are resolved in this priority order:

| Priority | Condition | `<spec_dir>` | `<contract-name>` |
|----------|-----------|--------------|-------------------|
| 1 | `--file <path>` provided | parent directory of `<path>` | filename stem of `<path>` (without `.yaml`); skip contract name proposal in Step 4 |
| 2 | Formal effort active (`.state.json` found) | `<effort_dir>/spec/api/` | determined in Step 4 |
| 3 | `--deployable <name>` provided | `<deployable_dir>/spec/api/` | determined in Step 4 |
| 4 | `--capability <name>` provided (requires `--deployable`) | `<capability_dir>/spec/api/` | determined in Step 4 |
| 5 | Inferred from conversation | same as corresponding flag above | determined in Step 4 |

**`<requirements_dir>`** is resolved in this priority order:
1. Formal effort active → `<effort_dir>/requirements/`
2. `--deployable <name>` provided → `<deployable_dir>/requirements/`
3. `--capability <name>` provided → `<capability_dir>/requirements/`
4. Inferred from conversation → same as corresponding option above
5. `--file <path>` provided with no other context → fall through to whichever of 1–4 applies
6. None of the above → ask the engineer to describe operations conversationally

**When no active effort and no flags:** determine context from the conversation (e.g.,
the engineer mentions a specific service or capability). Propose the inferred
deployable/capability and confirm before proceeding — treat a confirmed inference as
if the corresponding flag had been provided. If context is ambiguous, list available
deployables from `.forge/deployables/` and ask the engineer to choose.

---

## Step 1: Load the REST Standard

Load all four REST sub-standards:
- [`../../standards/api/rest/contracts.md`](../../standards/api/rest/contracts.md) — URI structure, versioning, naming, HTTP verbs
- [`../../standards/api/rest/protocol.md`](../../standards/api/rest/protocol.md) — response envelope, headers, status codes, errors
- [`../../standards/api/rest/security.md`](../../standards/api/rest/security.md) — authentication and authorization
- [`../../standards/api/rest/data.md`](../../standards/api/rest/data.md) — pagination, timestamps, decimal/currency types

For OpenAPI document construction conventions (schema reuse, field ordering, component
naming), read [`../../languages/openapi/default/guides/`](../../languages/openapi/default/guides/).

If any standard file is absent: warn for that concern and continue.

---

## Step 2: Read Requirements

Read `<requirements_dir>/business.md` and `<requirements_dir>/technical.md` (if
present). Extract the user-facing operations the API must expose.

If `<requirements_dir>` could not be resolved (no formal context), ask the engineer to
describe the operations directly.

---

## Step 3: Check for Existing Spec

Check whether `<spec_dir>` already contains files.

**If no existing spec is found:** continue to Step 4.

**If existing spec files are found:** surface them and ask:

```
Found existing API contract(s): <list of files>

Would you like to review the existing spec against the current requirements and
REST standard? (yes / no — no skips to authoring a new contract)
```

**If the engineer says yes — review path:**

1. Load each existing spec file.
2. **Requirements coverage:** for each BR and TR that implies an API operation, check
   whether a corresponding endpoint exists. List any requirements with no covering
   endpoint as gaps.
3. **Standards compliance:** apply the loaded REST standard to every endpoint — resource
   naming, HTTP method, status codes, error schema, auth declaration. List any violations.
4. Present findings:
   ```
   Review complete.
   Gaps (requirements with no endpoint): <list or "none">
   Violations (endpoints not meeting the REST standard): <list or "none">
   ```
5. If no gaps and no violations: confirm the spec is current and stop — no further
   authoring needed unless the engineer requests changes.
6. If gaps or violations exist: offer options:
   - **Fix inline** — address each finding resource-by-resource (gaps: add missing
     operations to the relevant resource block; violations: correct the violating
     endpoints within their resource block). Retain the existing contract's filename as
     `<contract-name>`; skip Step 4. Proceed directly to Step 6 to re-write the
     corrected contract.
   - **Review only** — present the findings and stop; engineer decides what to do next

**If the engineer says no:** proceed to Step 4 to author a new contract (the existing
files will be overwritten at Step 6).

---

## Step 4: Confirm Resource Scope and Contract Name

Propose a resource breakdown from the enumerated operations:

```
Based on the requirements, I propose:
  - <resource>: <one-line description of what it represents>

Confirm or adjust before I draft the contract.
```

If `--resource <name>` was provided, skip the resource breakdown proposal and proceed
directly to the contract name confirmation below.

Once the resource scope is confirmed, determine the contract filename. Follow the
naming rules in [`../../languages/openapi/default/guides/api/rest/contracts.md`](../../languages/openapi/default/guides/api/rest/contracts.md).
Propose the name to the engineer:

```
Contract file: <contract-name>.yaml
Confirm or provide a different name:
```

Skip this proposal if `--file <path>` was provided — the contract name is already set.

---

## Step 5: Draft the Contract

### One-shot mode (default)

Draft the complete OpenAPI contract for all confirmed resources, applying the loaded
REST standard throughout. Present the full draft for review:

```
Here is the complete API contract for <resource(s)>.

<full OpenAPI YAML>

Review the contract. Tell me what to change, or say "looks good" to proceed.
```

Apply the standard to every design decision as you draft — method selection, status
codes, error schema, auth declaration, pagination shape. The engineer reviews the
result, not each decision individually.

**Revision loop:** if the engineer requests changes, apply them to the affected
resource(s), re-present the updated contract, and repeat until the engineer confirms
"looks good."

### Interactive mode (`--interactive` or conversational trigger)

Design one resource at a time. For each resource:
1. Present the canonical path and all its operations as a complete YAML block — path
   established first, then each verb with request schema, response schema, status codes,
   and auth declaration
2. Apply the REST standard across all operations as you write them
3. Wait for engineer confirmation or revision of the full resource
4. Move to the next resource

After all resources are confirmed, assemble the complete contract and present it for a
final review before proceeding to Step 6:

```
Here is the assembled contract across all resources.

<full OpenAPI YAML>

Any final changes, or "looks good" to write it?
```

Use interactive mode when the engineer says "let's design this together", "walk me
through each resource", or similar — or when `--interactive` is passed explicitly.

### Non-standard choices (applies throughout drafting and review)

When an engineer requests or confirms a design that deviates from the REST standard:
1. Note the deviation and explain the standard's recommendation
2. Accept the engineer's choice if they confirm it
3. Record the rationale as an inline OpenAPI comment:
   ```yaml
   # NON-STANDARD: <engineer's rationale>
   ```
4. Flag it: "Run `forge:adr` to record this decision formally."

---

## Step 6: Write the Contract

Write to `<spec_dir>/<contract-name>.yaml`. For OpenAPI document structure, follow the
conventions in [`../../languages/openapi/default/guides/`](../../languages/openapi/default/guides/).

The contract must include a top-level `components/schemas/Error` object with at minimum
`code` (string) and `message` (string) fields, per the REST protocol standard. Every
endpoint that can return an error must reference this component in its error responses.

Create `<spec_dir>` if it does not exist.

---

## Step 7: Update .state.json

When inside a formal effort, set `phases.discovery.artifacts.spec.api = "present"`.

---

## Step 8: Review

Spawn a worker sub-agent to review the just-written contract. Pass it:
- The contract file(s) at `<spec_dir>/`
- `<requirements_dir>/business.md` and `<requirements_dir>/technical.md` — or, when
  requirements were provided conversationally (no `<requirements_dir>` resolved), pass
  the enumerated operations collected in Step 2 as inline text in place of requirements
  files
- The four REST sub-standard paths

The sub-agent performs two checks and returns findings in this structure:

```json
{
  "gaps": [
    { "req_id": "BR-1", "description": "No endpoint covers <operation>" }
  ],
  "violations": [
    { "path": "/offers/v1/stores", "method": "GET", "description": "<rule violated>" }
  ]
}
```

If both arrays are empty: report clean and proceed to Step 9.

If findings exist, present them to the engineer:

```
Review found <N> issue(s):

Gaps (requirements with no endpoint):
  - <BR/TR-id>: <description>

Violations (endpoints not meeting the REST standard):
  - <path> <METHOD>: <description>

Fix all? (yes / no / select)
```

- **yes** — fix every finding inline resource-by-resource, then re-run the sub-agent
  once to confirm. If issues remain after that single re-run, present them with a note
  that they were not fully resolved and proceed to Step 9.
- **no** — proceed to Step 9 without fixing; findings are surfaced but not blocking
- **select** — engineer chooses which findings to fix; fix those resource-by-resource,
  re-run the sub-agent once to confirm. If issues remain, present them and proceed to
  Step 9.

---

## Step 9: Commit

Stage `<spec_dir>/<contract-name>.yaml` and run `forge:commit`. The suggested
conventional commit message is:

```
docs(<scope>): design API contract for <contract-name>
```

Where `<scope>` is:
- The effort ID in a formal effort context
- The deployable name in a deployable context
- The capability name in a capability context

---

## Output Summary

```
forge:spec-api complete
Written to: <spec_dir>/<contract-name>.yaml
Next: forge:validate-api · forge:spec-storage · forge:adr
```

---

## Error Handling

| Condition | Action |
|-----------|--------|
| No requirements and no formal context | Ask engineer to describe operations directly |
| REST standard files absent | Warn per file; continue with general REST conventions |
| No active effort and context ambiguous | List available deployables; ask engineer to choose |
| `--capability` provided without `--deployable` | Stop: "`--capability` requires `--deployable <name>`" |
| Existing spec found, engineer declines review | Proceed to Step 4; existing files overwritten at Step 6 |
| Review sub-agent finds issues, engineer says no | Surface findings, proceed to Step 9 without fixing |
| `<spec_dir>` write fails | Surface error; stop; do not commit partial contract |
