# Business Requirements

## BR-1: Submit a Support Ticket
Members can submit a support ticket with a subject and description.

**Acceptance criteria:**
- Tickets are assigned an ID on creation
- Confirmation returned immediately
