# Business Requirements

## BR-1: Members Can Save Favourite Items
Members can save products to a favourites list for later reference.

**Acceptance criteria:**
- A saved item is associated with the member's account
- Duplicate saves are idempotent

## BR-2: Members Can Remove Favourites
Members can remove items from their favourites list.

**Acceptance criteria:**
- Removing an item that does not exist returns a clear error

## BR-3: Members Can View Their Favourites
Members can retrieve a paginated list of all their saved items.

**Acceptance criteria:**
- Results are ordered by most-recently-saved first
- Supports pagination
