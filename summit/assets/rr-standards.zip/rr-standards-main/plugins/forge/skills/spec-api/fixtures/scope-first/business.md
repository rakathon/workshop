# Business Requirements

## BR-1: Members Can Save Favourite Items
Members can save products to a favourites list.

## BR-2: Members Can Remove Favourites
Members can remove items from their favourites list.

## BR-3: Members Can View Their Favourites
Members can see all their saved items.
