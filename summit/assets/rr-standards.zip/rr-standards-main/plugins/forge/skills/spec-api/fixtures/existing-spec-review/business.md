# Business Requirements

## BR-1: Members Can Update Their Profile
Members must be able to update their display name and email address.

**Acceptance criteria:**
- Changes take effect immediately
- Email changes require re-verification

## BR-2: Members Can View Their Profile
Members can retrieve their current profile at any time.
