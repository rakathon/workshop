---
name: forge:report:sizing
description: Generate an Effort Sizing Report — pre-planning feasibility assessment with Dev Days and Sprint estimates, team sizing, and coordination/risk context. Equivalent to forge:report --report sizing.
argument-hint: [--out name] [--title text]
---

# Effort Sizing Report

Generates an **Effort Sizing Report** — the pre-planning feasibility assessment used before teams are assigned. Breaks down expected work into components with Dev Days and Sprint estimates. Used to validate scope and inform a go/no-go decision.

This skill is `forge:report` with `--report sizing` pre-applied.

## Instructions

1. Prepend `--report sizing` to any user-supplied arguments:
   `$RESOLVED_ARGUMENTS = "--report sizing " + $ARGUMENTS`

2. Read the main report skill instructions:
   `${CLAUDE_SKILL_DIR}/../report/SKILL.md`

3. Execute those instructions with `$ARGUMENTS = $RESOLVED_ARGUMENTS`.

## Sections included

`mandate` · `loe` · `coordination` · `slippage`
