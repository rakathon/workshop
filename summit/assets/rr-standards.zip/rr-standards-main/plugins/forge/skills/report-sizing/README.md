# forge:report:sizing

Generate an **Effort Sizing Report** — pre-planning feasibility assessment.

Equivalent to `/forge:report --report sizing`.

## Sections

`mandate` · `loe` · `coordination` · `slippage`

## Usage

```
/forge:report:sizing
/forge:report:sizing --out q3-sizing
/forge:report:sizing --title "Feature X Feasibility"
```
