---
name: forge:commit
description: >
  Use instead of raw git commit whenever committing implementation work. Triggered by:
  "commit this task", "create a commit for this implementation", "make a forge commit",
  or any time the engineer is about to commit during implementation. Handles staging,
  enforces branch convention, checks scope, proposes a conventional commit message,
  attaches a structured git note (ADR-008) for traceability, and marks the task complete.
agent-type: orchestrator
---

# forge:commit

Replaces raw `git commit` for implementation work. Handles the full commit ceremony:
staging, branch check, scope check, conventional commit message, git note attachment,
and task completion — in that order.

---

## Variables

- `<effort_id>` — the effort slug (e.g., `forge-commit`, `favorites-api`)
- `<effort_dir>` — `.forge/efforts/<effort_id>/`
- `<tasks_file>` — `<effort_dir>/plan/tasks.md`
- `<state_file>` — `<effort_dir>/.state.json`

**Resolving `<effort_id>` at runtime:**

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-optional

If no effort is resolved, continue without effort context — skip Steps 5 and 6.

---

## Step 0: Ensure Staged Changes Exist

Run:
```bash
git diff --cached --name-only
git status --short
```

**If staged changes already exist:** proceed to Step 1.

**If nothing is staged:** present the unstaged changes and offer options:

```
Nothing is staged. Here's what's changed:
  <list of modified/new files from git status>

How would you like to stage?
  1. Stage everything (git add -A)
  2. Stage specific files — tell me which ones
  3. Stage interactively (git add -p)
  4. Cancel — I'll stage manually
```

Act on the engineer's choice before continuing. After staging, re-run
`git diff --cached --name-only` to confirm something was staged. If still empty
after option 1 or 2, stop: "Nothing was staged. Nothing to commit."

---

## Phase Sentinel Check

Skip this check if no effort context was resolved.

Inspect the staged files already confirmed in Step 0:

```bash
git diff --cached --name-only
```

Classify each staged file path into one of these buckets:

| Bucket | Path pattern |
|--------|-------------|
| **outside-forge** | Does NOT start with `.forge/` |
| **discovery-artifact** | `.forge/efforts/<effort_id>/requirements/**` or `.forge/efforts/<effort_id>/spec/**` |
| **planning-artifact** | `.forge/efforts/<effort_id>/plan/**` |
| **forge-metadata** | Any other `.forge/` path (e.g., `.state.json`, `meetings/`, `validation/`) |

Apply the confidence rule: the sentinel fires only when the staged content is a
**confident signal** that implementation has started:

| Staged content | Sentinel action |
|----------------|----------------|
| Any file in **outside-forge** | Fire — source code outside `.forge/` is an implementation signal |
| Only **planning-artifact** files (no outside-forge, no discovery-artifact) | Fire — a plan being committed without discovery artifacts suggests planning is wrapping up |
| Any **discovery-artifact** file present | Skip — requirements or spec files indicate discovery work; do not advance |
| Only **forge-metadata** (no outside-forge, no discovery-artifact, no planning-artifact) | Skip — not confident; do not prompt |

**When the sentinel fires:**

Read `<effort_dir>/.state.json`. Check `currentPhase`:
- If `currentPhase` is **"implementation" or any later phase**: proceed silently to Step 1 —
  already in the right phase.
- If `currentPhase` is **before "implementation"**: invoke
  `forge:promote <effort_id> --target implementation` and wait for it to complete before
  proceeding to Step 1. forge:promote will surface advisory checks for all phases in the
  gap and ask the engineer to confirm advancement.

---

## Step 1: Check Branch Convention (Non-Blocking Guardrail)

Run:
```bash
git branch --show-current
```

**Resolve the expected convention:**

Check whether `.forge/branching.md` exists:

```bash
[ -f ".forge/branching.md" ] && echo "present" || echo "absent"
```

- **If present:** Read the full file. Extract the `branch_regex` from the YAML
  frontmatter and use it to validate the branch name. Also read the prose body —
  use it if suggesting a rename.
- **If absent:** Fall back to the Forge built-in default regex:
  `^(effort|feature|feat|fix|hotfix|chore|docs|refactor|release)/[a-z0-9][a-z0-9-]*$`

If the branch name matches the resolved regex, note it silently and continue.

If it does not match: surface the branch name, suggest a rename based on the
staged changes and the convention prose (e.g., `fix/<slug>` for a bug fix), and ask:
> "Rename the branch before committing, or proceed on the current branch?"

This is a guardrail, not a gate — proceed either way on the engineer's choice.

---

## Step 2: Check Scope

Compare staged file paths against `<tasks_file>` if it exists.

**No `<tasks_file>`:** note it briefly and continue. Scope cannot be verified
without a task list.

**Single clear task match:** confirm silently and continue without waiting:
> "Staged changes match TASK-NNN — [task title]."

**Ambiguous or mixed-concern:** Only flag this when the staged files clearly span
multiple unrelated areas — for example, files from two different service directories
with no obvious shared context. Do not flag when it is plausible that all changes
belong to one task (partial implementations, co-located test files, config alongside
source). When in doubt, proceed.

When flagging, list the files grouped by likely task and offer:
- **Proceed** — commit everything as staged
- **Select a subset** — help the engineer unstage files that don't belong
  (`git restore --staged <files>`), then continue
- **Cancel** — stop; engineer handles staging manually

**Already-completed task:** If the matching task is already marked `[x]`, note it:
> "TASK-NNN is already marked complete. Is this a follow-up commit for the same task?"

If yes: continue — the note will reference the same task and the SHA will be added
to the completed task record. If no: ask which task this commit belongs to.

---

## Step 3: Propose Conventional Commit Message

Derives a [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/)
message and shows its version impact in the context of the whole branch.

---

### 3.1 — Read branch commit history

Get all commits on this branch since it diverged from the default branch:

```bash
default_branch=$(git config init.defaultBranch 2>/dev/null || echo "main")
git log "${default_branch}..HEAD" --format="%s" 2>/dev/null
```

Parse each subject line for its conventional commit type. Classify each as:

| Type found | Release tier |
|-----------|--------------|
| `<type>!:` or body contains `BREAKING CHANGE:` | **major** |
| `feat:` / `feat(…):` | **minor** |
| `fix:` / `perf:` / `refactor:` / `build:` / `ci:` | **patch** |
| `test:` / `docs:` / `chore:` / `style:` | **none** |
| Unparseable (non-conventional) | **unknown** |

The **branch release tier** is the highest tier across all existing commits:
`major` > `minor` > `patch` > `none`. Record this as `branch_release_tier`.

If the branch has no commits yet (first commit), `branch_release_tier = none`.

---

### 3.2 — Determine commit type from context

Derive the type for *this* commit using the following signals in priority order.
Stop at the first signal that produces a clear answer.

**Signal 1 — Staged diff analysis (most objective)**

Read the staged diff:
```bash
git diff --cached --stat
git diff --cached --name-only
```

Apply these rules:

| Observation | Inferred type |
|-------------|--------------|
| Only `*_test.go`, `*.test.ts`, `*_spec.rb`, etc. | `test` |
| Only `*.md`, `docs/`, `README*` | `docs` |
| Only `*.yaml`/`*.yml` in `.github/` or CI config files | `ci` |
| Only build files (`Makefile`, `Dockerfile`, `*.gradle`, `pom.xml`, non-src) | `build` |
| Only `go.mod`/`go.sum`, `package.json`/`package-lock.json`, dependency files | `chore` |
| Source files changed but no new public API surface | `fix` or `refactor` (go to Signal 2) |
| New source files with new exported functions/endpoints/types | `feat` |
| Mixed test + source | use the source type |

**Signal 2 — Effort context (strong prior)**

Use the effort type and subtype from `<state_file>` if available:

| Effort type / subtype | Type prior |
|-----------------------|-----------|
| `patch` | `fix` |
| `refactor` | `refactor` |
| `spike` | `chore` |
| `poc` | `chore` |
| `epic` / `story` / `extension` | `feat` (if new surface) or `fix` |
| `task` | neutral — go to Signal 3 |

**Signal 3 — Task title keywords**

Read the matching task title from `<tasks_file>` if available:

| Keyword in task title | Type |
|-----------------------|------|
| add, introduce, implement, create, support, enable | `feat` |
| fix, repair, correct, resolve, handle, prevent | `fix` |
| refactor, restructure, extract, move, rename (internal) | `refactor` |
| improve, optimise, optimize, cache, reduce latency | `perf` |
| test, spec, coverage | `test` |
| document, docs, readme, changelog | `docs` |
| upgrade, bump, update deps, migrate | `chore` |

**If still ambiguous after all three signals:** ask a single focused question:

```
Is this commit introducing new functionality or fixing existing behaviour?

  1. New functionality    → feat
  2. Bug fix              → fix
  3. Internal change only → refactor / chore / perf / test / docs

Enter 1, 2, or 3:
```

Record the determined type as `commit_type`.

---

### 3.3 — Detect breaking change signals

Scan the staged diff for objective breaking change indicators:

```bash
git diff --cached
```

**Breaking change signals (any one is sufficient):**

- A previously-exported function/method/type is removed or renamed
  (look for `-func <Name>`, `-type <Name>`, `-export`, `- <Name>(` patterns in the diff)
- An HTTP endpoint is removed (look for removed route registrations)
- A required field is added to a public struct/type with no default
- A public interface gains a new method
- A function signature changes in a way callers must update (parameter added/removed/retyped)
- An environment variable or config key is renamed or removed

If any signal is found, surface it explicitly:

```
⚠️  Breaking change detected: <what was found — e.g. "exported function ProcessPayment removed">

This commit should use the breaking change marker. Choose:
  1. feat!(<scope>): <description>       — feature with breaking change → MAJOR bump
  2. fix!(<scope>): <description>        — fix with breaking change → MAJOR bump
  3. <type>(<scope>): <description>\n\nBREAKING CHANGE: <explanation>  — footer style
  4. Not a breaking change — I'll proceed with a regular commit

Enter 1, 2, 3, or 4:
```

If option 3: ask the engineer to describe the breaking change for the footer.
If option 4: proceed with the regular type from Step 3.2.
If no signals found: `is_breaking = false`, proceed without asking.

---

### 3.4 — Compute version impact

Using `commit_type`, `is_breaking`, and `branch_release_tier`:

| This commit | Branch already has | Effective release |
|-------------|-------------------|-------------------|
| breaking (`!` or footer) | anything | **MAJOR** |
| `feat` | nothing / patch / none | **MINOR** |
| `feat` | `feat` already | MINOR (no change — already minor) |
| `fix` / `perf` / `refactor` | nothing / none | **PATCH** |
| `fix` | `feat` already | PATCH for this commit, but branch stays **MINOR** |
| `fix` | breaking already | PATCH for this commit, but branch stays **MAJOR** |
| `test` / `docs` / `chore` / `ci` | anything | **no version bump** (this commit) |

Compute:
- `this_commit_tier` — the tier this commit contributes on its own
- `branch_release_tier_after` — the new branch-level tier after this commit is added

---

### 3.5 — Present proposal

Compose the proposed message:

```
type(scope): description
```

**scope:** effort ID (without `effort/` or branch-prefix prefix), or primary changed
package/module if no effort context. Omit scope only if the change is truly global.

**description:** imperative mood, present tense, no period at end, ≤72 chars total
(type + scope + description combined).

**Footer:** if `is_breaking = true` with footer style (option 3 from 3.3), append:

```
BREAKING CHANGE: <engineer's description>
```

Present the proposal with version impact context:

```
Proposed commit:
  feat(payment): add gift card redemption endpoint

Version impact:
  This commit:    minor  (new feature)
  Branch release: MINOR  ↑ (this commit sets the release tier)

  1. Yes — use this message
  2. Edit — provide a custom message
  3. Cancel — stop and let me commit manually

Enter 1, 2, or 3 [1]:
```

**When this commit's tier is lower than the branch already has:**

```
Proposed commit:
  fix(payment): handle null expiry in card validation

Version impact:
  This commit:    patch  (bug fix)
  Branch release: MINOR  ↑ (already set by earlier feat: commit — not changed by this fix)

  1. Yes — use this message
  2. Edit — provide a custom message
  3. Cancel — stop and let me commit manually

Enter 1, 2, or 3 [1]:
```

**When breaking:**

```
Proposed commit:
  feat!(auth): remove legacy session token support

Version impact:
  This commit:    MAJOR  ⚠️  (breaking change)
  Branch release: MAJOR  ↑

  1. Yes — use this message
  2. Edit — provide a custom message
  3. Cancel — stop and let me commit manually

Enter 1, 2, or 3 [1]:
```

**When no version bump:**

```
Proposed commit:
  test(payment): add unit tests for card expiry validation

Version impact:
  This commit:    none   (tests only)
  Branch release: MINOR  (unchanged — set by earlier feat: commit)

  1. Yes — use this message
  2. Edit — provide a custom message
  3. Cancel — stop and let me commit manually

Enter 1, 2, or 3 [1]:
```

**Handling the response:**

- **`1` / `y` / `yes` / empty (Enter)** → use the proposed message as-is, proceed to Step 4.
- **`2` / `e` / `edit`** → ask:
  ```
  Enter your commit message:
  ```
  Wait for the engineer's message. Use it verbatim — do not reformat.
  Parse the provided message to re-derive `commit_type` and `is_breaking` for Step 4.
- **`3` / `n` / `cancel`** → stop. Print: `Commit cancelled. Your changes remain staged — run git commit manually when ready.`
- **Any other text typed directly** → treat it as a custom message (same as option 2 response). This handles the case where the engineer types their message instead of selecting a number.

---

## Step 4: Create the Commit

Set `FORGE_COMMIT_IN_PROGRESS=1` on the commit command so the `enforce-branch-policy.sh`
hook recognises this as an authorised forge:commit invocation and does not redirect it:

```bash
FORGE_COMMIT_IN_PROGRESS=1 git commit -m "<confirmed-message>"
```

If the commit fails (hook rejection, nothing to commit, etc.), surface the error
and stop. Do not proceed to Steps 5–6 if no commit was created.

Capture the SHA after success:
```bash
git log -1 --format="%h"
```

---

## Step 5: Attach Structured Git Note (formal effort only)

Skip this step when there is no formal effort context (`<effort_dir>` was not resolved).

Build the note JSON:

| Field | Source |
|-------|--------|
| `workId` | `id` in `<state_file>`, or effort ID from branch name |
| `taskId` | `(TASK-NNN)` at end of matching task line in `<tasks_file>`; if ambiguous or not found, ask the engineer |
| `wave` | `[wave:N]` annotation on the task line; omit if absent |
| `taskType` | `[auto]`/`[tdd]`/`[checkpoint]`/`[manual]` annotation; default `auto` |
| `standardsApplied` | Standards applicable to the committed file types (see below) |

**Resolving `standardsApplied`:** infer from file extensions. `.go` → `languages/go/default`;
`.yaml` in `spec/api/` → `standards/api/rest`; etc. Omit irrelevant standards.

Write to a temp file and attach:
```bash
git notes add -F /tmp/forge-note-$(date +%s).json HEAD
```

Use the Write tool to create the temp file — do not use shell heredocs (fragile quoting).

**Git notes and remote visibility:** Push the note explicitly so it is visible
in CI and to other engineers without affecting normal branch push behaviour:

```bash
git push origin refs/notes/commits
```

If the push fails (e.g. no remote, permission error), surface the error as a
warning but do not stop — the commit itself succeeded.

---

## Step 6: Mark Task Complete (formal effort only)

Skip when there is no formal effort context.

Before marking complete, ask:
> "Does this commit complete TASK-NNN, or is this a partial/WIP commit?"

- **Completes the task:** invoke `forge:update-plan` to mark `[x]` and record the SHA.
  Report: `Task marked complete: TASK-NNN — <title> (SHA: <sha>)`
- **Partial/WIP:** skip `forge:update-plan`. The task stays open for the next commit.
  Report: `Committed. TASK-NNN remains open — run forge:commit again when it's complete.`

---

## Output Summary

| Step | Action | Behavior |
|------|--------|----------|
| 0 | Staging | Offers to stage if nothing staged; presents options |
| — | Phase sentinel | Formal effort only; fires only when staged content confidently signals implementation (source files outside `.forge/`, or plan-only artifacts); suppressed when discovery artifacts are present |
| 1 | Branch check | Non-blocking; suggests rename, continues either way |
| 2 | Scope check | Auto-proceeds on single match; advisory flag on clear mixed concerns |
| 3.1 | Branch history | Reads all prior commits on branch; computes current branch release tier |
| 3.2 | Commit type | Derived from diff → effort context → task title; asks only if ambiguous |
| 3.3 | Breaking change | Scans diff for objective signals; asks only if found |
| 3.4 | Version impact | Computes this-commit tier and branch-level tier after this commit |
| 3.5 | Proposal | Shows message + version impact; options: 1=accept 2=edit 3=cancel; bare text treated as custom message |
| 4 | Commit | Hard stop on failure |
| 5 | Git note | Formal effort only; flags if push refspec not configured |
| 6 | Task completion | Asks whether this commit completes the task before marking done |
