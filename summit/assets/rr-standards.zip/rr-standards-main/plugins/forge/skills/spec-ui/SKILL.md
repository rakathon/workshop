---
name: forge:spec-ui
description: >
  Conversationally author a UI spec (ui-spec.md) by walking the engineer through
  goal, mode, scope, data, and mode-specific details — then write the completed
  spec to disk ready for forge:ui to consume. Trigger when the engineer explicitly
  wants to plan or document a UI before building it: "write a UI spec", "spec out
  this page", "help me plan the UI", "let's design the UI before we build it",
  "I want to think through the UI design", "plan the UI for this feature",
  "I want to compare a few UI approaches before committing", "I have a Figma to
  implement and want to write a spec first". Do NOT trigger on requests to build or
  generate UI directly — those go to forge:ui. Do NOT trigger on general
  "explore approaches" or "show data from an API" prompts that aren't specifically
  about speccing a UI. The distinguishing signal is explicit intent to write a spec
  or plan before implementation begins.
agent-type: orchestrator
---

# forge:spec-ui

Walks the engineer through a focused interview to produce a `ui-spec.md` file that
fully describes what should be built. The output drives `forge:ui` — a well-filled
spec means `forge:ui` can generate code directly, skipping its clarifying questions.

When a Forge effort is active, reads all existing discovery artifacts first and uses
them as context — questions the requirements already answer are skipped, and
recommendations are derived from what the effort has established rather than invented
from scratch.

The interview is structured but not rigid. The goal is a complete spec, not a form.
If the engineer's answers make later questions unnecessary, skip them. If an answer
implies something that should be captured, capture it without asking.

---

## Step 0 — Resolve Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-optional

- **Effort found:** record `effort_id` and `effort_dir`. Continue to Step 1.
- **No effort found:** skip to Step 2 with no loaded context.

---

## Step 1 — Load Effort Context

Read every file that exists in:

- `<effort_dir>/requirements/` — all files (business.md, technical.md, user-stories.md)
- `<effort_dir>/spec/` — all files recursively (API contracts, storage schemas, messaging contracts)
- `<effort_dir>/.state.json`

Build an internal picture of what is already established:
- Which user-facing features and flows are described
- Which data entities, API endpoints, or events exist in the specs
- Which screens, routes, or surfaces are mentioned anywhere
- What the effort is trying to accomplish for users

Do not ask about anything the artifacts already answer clearly.

Check for an existing UI spec at `<effort_dir>/spec/ui-spec.md`. If found, read it
and skip to the [Existing Spec](#existing-spec) branch.

---

## Step 2 — Check for Existing Spec (No-Effort Mode)

*Only reached when no effort was found in Step 0.*

Check for `spec/ui-spec.md` in the current working directory. If found, read it and
go to the [Existing Spec](#existing-spec) branch. If not found, proceed to Step 3.

---

## Existing Spec

Read the spec, then ask:
> "I found an existing UI spec. Do you want to update it, or start a new one?"

- **Update:** carry the existing content as pre-filled answers; only ask about
  sections that are empty or that the engineer wants to change.
- **New:** proceed to Step 3 as if no spec exists.

---

## Step 3 — Open the Interview

### When effort context was loaded

Open with a brief orientation — what you have read and what you understand so far:

> "I've read the effort artifacts. Here's what I understand about the UI so far:
> [2–3 sentences: feature goal, key data surfaces, any screens or flows mentioned].
> I have a few questions to fill in before I can write a complete spec."

Then infer mode from the requirements context if signals are present:

| Signal in artifacts | Likely mode |
|---------------------|-------------|
| Design references, Figma links, or "design team" mentions | `production` |
| Specific API endpoints, data shapes, or hook names described | `data-first` |
| Multiple layout approaches compared, "explore", "prototype", or "demo" intent | `exploration` |

If a mode can be confidently inferred, state it and confirm:
> "Based on the requirements, this looks like [mode] work — [one-sentence rationale].
> Does that fit, or do you have a different intent?"

If no mode can be inferred from context, ask the open question from the no-context path below.

### When no effort context was loaded

Ask one open question:
> "What are you building, and what's driving it?"

Listen for signals that indicate mode — do not ask about mode explicitly yet:

| What the engineer says | Likely mode |
|------------------------|-------------|
| "trying out a few ideas", "want to compare approaches", "not sure which direction" | `exploration` |
| "have an API / data I want to display", "quick and dirty", "just need to see it working" | `data-first` |
| "have a Figma design", "design team gave me specs", "ready to productionize" | `production` |

After they answer, confirm the inferred mode — even when it seems obvious:
> "Sounds like this is [mode] work — [one-sentence rationale]. Does that fit?"

### Mode confirmation is not skippable

The engineer may have a different intent than the language implies, and a wrong mode
produces a spec that doesn't serve them. If they disagree, ask what's different and
adjust before continuing.

Record: `goal` (one sentence), `mode`.

---

## Step 4 — Interview Loop

Ask questions one at a time, each with a recommended answer. Do not ask open-ended
questions without a position. The engineer engages with the recommendation — accepting,
modifying, or rejecting it — rather than generating an answer from scratch.

**Skip any question whose answer is already clear from loaded artifacts.** Summarise
what you already know from the artifacts before asking; the engineer should not be
asked to repeat themselves.

**Recommendation rule:** When the effort has established relevant context, derive the
recommendation from that context. When it has not, offer a sensible default.

Example:
> "The API spec shows the endpoint returns `offerId`, `restaurantName`, `cashbackRate`,
> `logoUrl`, and `distanceMiles`. I'd suggest displaying all five in the card —
> `cashbackRate` is the primary hook so it should be visually prominent.
> Anything to add or drop?"

### Core questions (all modes)

These must be resolved before mode-specific questions. Skip any already answered by
the artifacts or a prior exchange.

**Scope:**
> "What's the scope — a full page, a section within an existing page, a standalone
> component, or a broader feature area?"
> I'd suggest [inferred scope from requirements or 'a full page' if unclear].

If they name a specific file path or route, capture it as `target_location`.

Record: `scope`, `target_location` (optional).

### Mode-specific questions

Run only the questions for the confirmed mode. Skip any already answered.

---

#### Exploration mode

**Data:**
> "What data or content will the variants display? Where does it come from?"
> [Recommend the data source described in requirements/specs if one exists.]

**Variants:**
> "What are the different approaches you want to compare? Give me a rough description
> of each — they should be distinct enough that you'd learn something different from
> each one."

Push gently if the variants are too similar:
> "Those sound fairly similar — what's the key structural difference you're trying to
> evaluate between them?"

Record: `data`, `variants[]`.

---

#### Data-first mode

**Data shape:**
> "What data are you displaying, and what does it look like? If there's an API
> endpoint or hook you're working with, what fields does it return?"
> [If an API spec exists, list the fields and ask the engineer to confirm or adjust.]

Accept partial information — the engineer may not know the full shape yet. Capture
what they know and note what's uncertain.

**Interactions:**
This question must be asked as a conversational turn — do not infer or skip it,
even when phrases like "nothing fancy" or "just get it visible" appear in the
prompt. Those phrases describe visual polish, not interaction requirements; a table
of 1000 rows with no pagination is a broken UI regardless of how simple the styling
is. The engineer must answer this question explicitly before you proceed.

Ask:
> "Do you need any interactions — search, filter, sort, or pagination? Even a simple
> table can need pagination if there's a lot of data."
> I'd suggest [recommendation based on data volume implied by requirements, or 'no
> interactions for this first cut' if no signal exists].

Wait for the engineer's answer. If they say no, record `interactions: none`.
If they say yes, note what's needed.

Record: `data` (fields, source, uncertainties), `interactions` (list or "none").

---

#### Production mode

**Design reference:**
> "Where is the design? A Figma link, a handoff document, or something else?"

If a Figma link or design reference was already mentioned in the requirements or
the engineer's invocation message, confirm it rather than asking:
> "I see the design is at [link] — is that still the right reference, or has it
> been updated?"

If Figma: capture the link and ask:
> "Which screens or frames should be included?"

**States:**
Always ask — do not infer states from the described UI, even when they seem obvious.
A state omitted from the spec is a state that won't be implemented.
> "What states does the UI need to handle beyond the default loaded state?"
> I'd suggest at minimum: loading/skeleton and error from the API. Any feature-specific
> states like 'empty', 'saved', or 'offer expired' would also belong here.

If the engineer draws a blank, prompt:
> "For example: loading/skeleton, empty state when there's no data, error from the
> API, or any feature-specific states like 'saved' or 'offer expired'?"

List each confirmed state as a checkbox item. If the engineer names a state that is
commonly paired with one they haven't mentioned (e.g., they say "loading" but not
"error"), ask about it specifically before moving on.

**Accessibility:**
Always ask — do not apply the baseline default without checking. The design team
may have specific requirements that aren't visible from the Figma description alone.
> "Are there any accessibility requirements from the design team beyond the standard
> baseline — for example, specific ARIA labelling, focus management, or screen reader
> text for non-obvious elements?"
> I'd suggest 'none beyond organizational baseline (WCAG 2.1 AA)' unless the design
> calls out something specific.

If they say no: record "None beyond organizational baseline (WCAG 2.1 AA)."

**Out of scope:**
Always ask — do not assume common exclusions.
> "What's explicitly out of scope for this implementation?"
> [If the effort has a known scope boundary — e.g., "mobile app is out of scope" from
> requirements — reflect it here and ask if there's anything to add.]

If the engineer hesitates, offer prompts:
> "For example: authentication, mobile app, analytics instrumentation, personalization,
> or server-side logic?"

Record: `design_reference`, `screens[]`, `states[]`, `accessibility_notes`, `out_of_scope[]`.

---

## Step 5 — Review Before Writing

Present a compact summary of what was captured:

```
Goal:    [goal]
Mode:    [mode]
Scope:   [scope] — [target_location if provided]
Data:    [data summary]
[Mode-specific fields condensed to one line each]
```

Ask:
> "Does this look right? Anything to change before I write the spec?"

Incorporate any corrections, then proceed to Step 6.

---

## Step 6 — Write the Spec File

Determine the output path:
1. If a Forge effort is active: `<effort_dir>/spec/ui-spec.md`
2. Otherwise: `spec/ui-spec.md` in the current working directory, creating `spec/` if
   it does not exist

Read `plugins/forge/templates/ui-spec-template.md` to get the canonical file structure.
Populate every section that has content; remove HTML comments from sections that are
filled in. Leave sections that don't apply to the current mode as empty sections with
a one-line note explaining why they're not needed (e.g., `<!-- not applicable: exploration mode -->`).

Write the file. Then confirm:

```
Spec written: [path]

Next step: run forge:ui to generate the implementation from this spec.
  /forge:ui
```

---

## Principles

**Don't ask what standards already answer.** Never ask about colors, typography,
spacing, which component library to use, or whether to make it responsive. Those are
answered by the design system.

**Don't ask what artifacts already answer.** Read the requirements and specs before
the interview. If a question is clearly answered there, use it — don't ask the engineer
to repeat themselves. Summarise what you've inferred and invite correction instead.

**Always recommend before asking.** Every question should include a recommended answer
with a brief rationale. The engineer should be confirming, adjusting, or rejecting a
proposal — not generating answers from scratch.

**Capture, don't interrogate.** If the engineer gives a long answer that covers multiple
questions, extract what you need and move on. The conversation should feel like a brief
planning discussion, not a form.

**One open question at a time.** Don't ask compound questions. If you need two pieces
of information, ask for the more important one first and let the answer inform whether
you need the second.

**Production mode deserves more rigour.** For exploration and data-first, incomplete
information is fine — the implementation will be exploratory anyway. For production,
push back if states or accessibility notes are thin: missing a state in the spec means
it won't be implemented.
