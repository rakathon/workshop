# Message Contract — Points Awarded

*Effort: loyalty-points*

## Contract

| Field | Value |
|-------|-------|
| Name | com.rakuten.rewards.loyalty.points.awarded |
| Namespace | com.rakuten.rewards.loyalty |
| Version | 1 |
| Owner | loyalty-service |
| Compatibility | FORWARD_TRANSITIVE |
| Topic | loyalty.points.awarded.v1 |
| Subject | com.rakuten.rewards.loyalty.points.awarded-v1 |
| Base class | ApiInitiatedMessage |

ApiInitiatedMessage provides: message_id, event_name, event_version, produced_at_ms,
trace_id, api_context (locale, user_agent, client_ip). These fields are pre-approved.

## Extension Fields

| Field | Type | Description |
|-------|------|-------------|
| member_id | string | The member who earned points |
| points_delta | int32 | Points awarded in this transaction |
| balance_after | int64 | New total point balance after this award |
| store_id | string | Partner store where the purchase occurred |
| purchase_id | string | The qualifying purchase that triggered the award |

## Producers

- loyalty-service (award endpoint)

## Consumers

- notification-service (sends push notification to member)
- analytics-service (aggregates earn metrics)

## Delivery Guarantee

At-least-once. Consumers must deduplicate on message_id.

## Idempotency

Consumers use message_id for deduplication. The loyalty service ensures at most one
event per purchase_id via the idempotency_key mechanism.
