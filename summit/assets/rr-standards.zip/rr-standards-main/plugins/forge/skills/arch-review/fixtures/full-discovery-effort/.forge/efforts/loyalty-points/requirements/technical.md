# Technical Requirements — Loyalty Points Award and Redeem

*Effort: loyalty-points*
*Elaborated from: requirements/business.md*
*Created: 2026-05-04*

---

## TR-1: Points API must support 500 RPS at p99 ≤ 100ms

*Traces to: BR-1, BR-2*

The award and redeem endpoints must handle 500 requests per second at p99 latency
≤ 100ms under normal load conditions. Burst capacity must support 3× sustained load
for up to 60 seconds.

---

## TR-2: Points balance cache TTL must be configurable between 5 and 60 seconds

*Traces to: BR-3*

The points balance is cached in ElastiCache. The TTL must be configurable at deploy
time (default: 15 seconds) to allow operators to trade freshness against cache
memory usage without a code change.

---

## TR-3: All write operations must be idempotent using a client-supplied idempotency key

*Traces to: BR-1, BR-2*

Award and redeem requests must accept an `idempotency-key` header. Duplicate requests
with the same key within a 24-hour window must return the same response without
re-processing.

---

## TR-4: Member PII must not appear in message payloads beyond member_id

*Traces to: BR-1*

Kafka messages produced by the loyalty service must contain only `member_id` as a
member identifier. Email, name, and other PII fields must not be included in events.
