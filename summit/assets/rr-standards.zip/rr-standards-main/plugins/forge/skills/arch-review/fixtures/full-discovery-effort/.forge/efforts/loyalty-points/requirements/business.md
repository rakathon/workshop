# Business Requirements — Loyalty Points Award and Redeem

*Effort: loyalty-points*
*Created: 2026-05-04*

---

## BR-1: Members can earn points for qualifying purchases

When a member completes a qualifying purchase at a partner store, their account is
credited with loyalty points based on the purchase amount and applicable reward rate.

**Acceptance criteria:**
- Points are credited within 60 seconds of purchase confirmation
- The member receives a push notification confirming points earned
- The transaction is idempotent — duplicate purchase events do not double-credit points

---

## BR-2: Members can redeem points at checkout

Members can apply accumulated loyalty points to reduce the cost of a purchase at
partner stores, at a rate of 100 points = $1.

**Acceptance criteria:**
- Members can redeem up to their full available balance
- Redemption is atomic — points are deducted and the discount applied in the same transaction
- If the redemption fails, points are returned to the member's balance within 5 seconds

---

## BR-3: Members can view their points balance and transaction history

Members can see their current points balance and a paginated history of earn and
redeem transactions.

**Acceptance criteria:**
- Balance is accurate to within 30 seconds of any transaction
- History shows at least 90 days of transactions
- Each entry shows: date, type (earn/redeem), amount, store name, running balance
