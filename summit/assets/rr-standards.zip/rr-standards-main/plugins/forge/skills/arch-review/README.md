# forge:arch-review

Generate an architecture review package for a discovery-phase effort. Produces a
presentation-quality HTML document for the architecture review meeting alongside the
machine-readable validation report.

---

## What It Does

1. **Validates** discovery artifacts — runs `forge:validate` if the report is absent or stale
2. **Interviews** the author on rollout approach, cost assumptions, risk mitigation, and afterword (one question at a time, like `forge:elaborate`)
3. **Fetches** current AWS pricing for identified infrastructure components
4. **Generates** a self-contained HTML document with nine sections (see below)
5. **Commits** both output artifacts atomically

---

## Usage

```
/forge:arch-review
```

Must be run during the discovery phase before calling `forge:promote`.

---

## Output Artifacts

### `validation/arch-review.html`

Self-contained HTML (opens from `file://`). Nine sections:

| # | Section | Content |
|---|---------|---------|
| 1 | Effort Overview | What we're building, why, BRs, TRs, delivery date |
| 2 | Validation Report | Findings tiered: "Must Examine" vs "Safe to Skip" |
| 3 | C4 Diagrams | System context + container diagrams (Mermaid) |
| 4 | Data Model | Logical ERD + physical schema; governance classification if available |
| 5 | Contracts | Interactive API accordion + messaging cards (base class + extensions only) |
| 6 | Risk Mitigation | Failures, abuse scenarios, cross-cutting security |
| 7 | Rollout | High-level phases, migration, feature flags, rollback |
| 8 | Cost Analysis | AWS infrastructure cost with interactive parameter sliders |
| 9 | Afterword | Future extensions and outstanding questions |

### `validation/report.md`

Machine-readable findings report. The `**Result:** PASS | PASS WITH CONCERNS | FAIL`
line on the first non-blank line is read by `forge:promote` as the gate artifact.

---

## Prerequisites

- Repository initialized with `forge:init`
- Active effort in the `discovery` phase with `phases.discovery.status != "approved"`
- At minimum: `requirements/business.md` must exist

---

## Related Skills

| Skill | Relationship |
|-------|-------------|
| `forge:validate` | Called automatically if report is absent or stale |
| `forge:elaborate` | Produces the requirements and spec artifacts arch-review reads |
| `forge:promote` | Reads `validation/report.md` before advancing to planning |
| `forge:reopen` | Required to re-run arch-review after discovery is approved (currently a stub) |
