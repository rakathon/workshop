# Storage Spec — Loyalty Points

*Effort: loyalty-points*

## Table: points_accounts

Stores the current points balance per member.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| member_id | VARCHAR(64) | PRIMARY KEY | Member identifier |
| balance | BIGINT | NOT NULL DEFAULT 0 | Current points balance |
| version | BIGINT | NOT NULL DEFAULT 1 | Optimistic lock version |
| updated_at | TIMESTAMPTZ | NOT NULL | Last modification time |

**Indexes:** PRIMARY KEY on member_id

---

## Table: points_transactions

Immutable ledger of all award and redeem events.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| transaction_id | UUID | PRIMARY KEY | Unique transaction ID |
| member_id | VARCHAR(64) | NOT NULL | FK → points_accounts |
| type | VARCHAR(10) | NOT NULL CHECK(type IN ('award','redeem')) | Transaction type |
| delta | BIGINT | NOT NULL | Points change (positive=award, negative=redeem) |
| balance_after | BIGINT | NOT NULL | Balance after this transaction |
| idempotency_key | VARCHAR(64) | UNIQUE | Client-supplied idempotency key |
| store_id | VARCHAR(64) | NOT NULL | Partner store identifier |
| created_at | TIMESTAMPTZ | NOT NULL | Transaction timestamp |

**Indexes:**
- PRIMARY KEY on transaction_id
- INDEX on (member_id, created_at DESC) — for history queries
- UNIQUE INDEX on idempotency_key — for deduplication

**Soft delete policy:** Transactions are immutable; no soft delete.
Points accounts use logical deletion via a `deleted_at TIMESTAMPTZ` column (not shown — added at migration time).

**Capacity estimate:** ~50M members × ~20 transactions/year = ~1B rows/year at ~200 bytes/row = ~200GB/year growth.
