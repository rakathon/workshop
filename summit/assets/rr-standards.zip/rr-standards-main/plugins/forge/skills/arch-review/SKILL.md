---
name: forge:arch-review
description: >
  Conduct a rollout/cost/risk interview, validate discovery artifacts, and generate
  a self-contained HTML architecture review package for the review meeting.
  Produces validation/arch-review.html (presentation document) and validation/report.md
  (machine-readable gate artifact for forge:promote). Use whenever an engineer is ready
  for an architecture review, says "generate the arch review", "prepare the review
  meeting document", "create the architecture review page", "run arch-review",
  "we have an arch review coming up", or any intent to produce a design review artifact
  before promoting discovery to planning. Also trigger when someone says
  "forge:arch-review" explicitly.
agent-type: orchestrator
---

# forge:arch-review

Validates discovery artifacts and generates a single self-contained HTML document
for the architecture review meeting. The document gives reviewers everything needed
to make an approve-or-send-back decision without accessing raw spec artifacts.

Before generating HTML, conducts a short pre-generation interview (rollout, cost,
risks, afterword) that supplements what's in the spec artifacts.

Two outputs are committed atomically:
- `<effort_dir>/validation/report.md` — machine-readable findings (gate artifact for `forge:promote`)
- `<effort_dir>/validation/arch-review.html` — presentation document (opens via `file://`)

**Size constraint:** The HTML file must not exceed 500KB. Summarise verbose spec content
rather than quoting it verbatim.

**External dependencies:** Two permitted external resources:
1. Google Fonts `@import` — for typography
2. Mermaid JS CDN `<script>` — for C4 diagram rendering. If opened offline, Mermaid
   diagrams render as readable plain text; the CDN is needed for rendered SVG.

---

## Variables

- `<effort_id>` — the effort slug
- `<effort_dir>` — `.forge/efforts/<effort_id>/`
- `<state_file>` — `<effort_dir>/.state.json`
- `<report_file>` — `<effort_dir>/validation/report.md`
- `<html_file>` — `<effort_dir>/validation/arch-review.html`

---

## Step 1: Resolve Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

---

## Step 2: Phase Guard

Read `<state_file>`. Check:
- `currentPhase` must be `"discovery"`
- `phases.discovery.status` must not be `"approved"`

If `currentPhase != "discovery"`: stop with:
> "forge:arch-review runs during the discovery phase. The current phase is `<currentPhase>`.
> If discovery was already approved and you need to re-run, first run `forge:reopen discovery`
> (note: forge:reopen is currently a stub — manually reset `phases.discovery.status`
> to `"in_progress"` in `.state.json` as a workaround)."

If `phases.discovery.status == "approved"`: stop with:
> "Discovery is already approved. To re-run arch-review, first run `forge:reopen discovery`."

---

## Step 3: Check and Run forge:validate

### 3.1 — Determine whether the validation report is current

A report is current if `<report_file>` exists AND it is newer than every file under
`<effort_dir>/requirements/` and `<effort_dir>/spec/`.

Use Python for portability across macOS and Linux:

```bash
python3 - <<'EOF'
import os, sys

report = sys.argv[1]
dirs = sys.argv[2:]

if not os.path.exists(report):
    print("stale")
    sys.exit(0)

report_ts = os.path.getmtime(report)
for d in dirs:
    if not os.path.isdir(d):
        continue
    for root, _, files in os.walk(d):
        for f in files:
            # skip git placeholders and interview-written supplement files
            if f in ('.gitkeep', 'rollout.md', 'cost.md', 'risks.md'):
                continue
            ts = os.path.getmtime(os.path.join(root, f))
            if ts > report_ts:
                print("stale")
                sys.exit(0)
print("current")
EOF
"<effort_dir>/validation/report.md" "<effort_dir>/requirements" "<effort_dir>/spec"
```

**Note:** After the interview in Step 5 writes new spec files, do NOT re-run this
freshness check. The interview spec files (`spec/rollout.md`, `spec/cost.md`,
`spec/risks.md`) are supplementary; `forge:validate` does not need to be re-run
after they are written.

If current: print "Validation report is current — skipping forge:validate." and proceed.

If stale or absent: print "Running forge:validate…" then invoke `forge:validate` and
wait for it to complete. If `forge:validate` fails, surface the error and stop.

---

## Step 4: Read All Discovery Artifacts

Read every file that exists in:
- `<effort_dir>/requirements/` — all files
- `<effort_dir>/spec/` — all files, recursively
- `<effort_dir>/validation/report.md`
- `<state_file>`

**Findings terminology:** `forge:validate` uses `**REQUIRED**` and `**SUGGESTION**`
as finding labels. Throughout this skill, treat them as follows:
- `**REQUIRED**` → FAIL tier (display with `.tag-fail` badge, text "REQUIRED")
- `**SUGGESTION**` → CONCERN tier (display with `.tag-concern` badge, text "SUGGESTION")

Note which spec subdirectories contain non-`.gitkeep` files:
- `api_present` — `<effort_dir>/spec/api/` has YAML files
- `storage_present` — `<effort_dir>/spec/storage/` has MD files
- `messaging_present` — `<effort_dir>/spec/messaging/` has MD files
- `adrs_present` — `<effort_dir>/spec/arch-decisions/` has MD files

Check for data-mapping output: look for any file matching
`<effort_dir>/spec/data-mapping*.md` or `<effort_dir>/spec/governance*.md`.
Set `data_mapping_present` accordingly.

Check for existing interview spec files (non-empty):
- `rollout_spec_present` — `<effort_dir>/spec/rollout.md` exists and is non-empty
- `cost_spec_present` — `<effort_dir>/spec/cost.md` exists and is non-empty
- `risks_spec_present` — `<effort_dir>/spec/risks.md` exists and is non-empty

---

## Step 5: Pre-Generation Interview

Before generating HTML, conduct a focused interview. Ask one question at a time, each
with a recommended answer. Write agreed answers immediately to the corresponding spec
file before asking the next question. Skip any topic whose spec file already exists.

All spec file paths are absolute using `<effort_dir>/spec/<filename>`.

### Topic 1: Rollout (skip if `rollout_spec_present`)

Infer signals from artifacts first:
- `storage_present` → likely a migration phase
- BR text containing "gradual", "experiment", "flag", "A/B" → feature flag candidate
- Multiple deployables in `.state.json` → coordinated rollout

Ask:
> "Walk me through the rollout approach at a high level — what phases are involved?
> Based on the spec artifacts I'd expect: [describe inferred signals].
> Does that match, or is the actual approach different?"

Write agreed answer to `<effort_dir>/spec/rollout.md`:
```markdown
# Rollout Plan — <effort_id>

## Phases
<agreed phases>

## Migration
<present / not required>

## Feature Flags / Experiments
<present / not required — describe if present>

## Rollback Approach
<agreed rollback strategy>
```

### Topic 2: Cost (skip if `cost_spec_present`)

Infer AWS services from spec artifacts:
- `storage_present` → likely RDS, DynamoDB, or ElastiCache
- `messaging_present` → likely MSK, SQS, SNS, or EventBridge
- Multiple services or deployables → likely ECS/EKS/Lambda compute

Ask:
> "Which AWS services will this effort add or significantly change? I see evidence of
> [inferred services]. Are there others?
> For the cost section, I'll build an interactive cost model for any variable cost
> drivers (e.g., cache TTL → ElastiCache memory, message volume → MSK cost).
> What are your key variable parameters and their expected baseline values?"

For each variable parameter not found in spec artifacts, ask:
> "What is your expected [parameter]? I'll use this as the baseline for the [service]
> cost model."

Write agreed answer to `<effort_dir>/spec/cost.md`:
```markdown
# Cost Analysis — <effort_id>

## AWS Services
<list with brief role>

## Variable Cost Drivers
| Parameter | Baseline Value | Service | Cost Impact |
|-----------|---------------|---------|-------------|
| <param>   | <value>       | <svc>   | <desc>      |

## Known Estimates
<any cost estimates the author can provide>
```

### Topic 3: Risk Mitigation (skip if `risks_spec_present`)

Infer candidates:
- `api_present` → auth bypass, rate limiting abuse
- `storage_present` → data corruption, backup failure
- `messaging_present` → duplicate processing, consumer lag

Ask:
> "What are the key failure modes and abuse scenarios for this effort?
> Based on the artifacts, I'd expect: [inferred candidates].
> Are there others? Also, any cross-cutting security concerns (secrets management,
> network policies, mTLS) not covered by the per-contract security analysis in §5?"

Write agreed answer to `<effort_dir>/spec/risks.md`:
```markdown
# Risk Mitigation — <effort_id>

## Failure Modes
<agreed failure modes with mitigation>

## Abuse Scenarios
<agreed abuse scenarios with mitigation>

## Cross-Cutting Security
<secrets management, network policies, mTLS, and other cross-cutting concerns>
```

### Topic 4: Afterword (always ask — stored in memory only)

Ask:
> "Any future extensions or outstanding questions for reviewers? These help reviewers
> understand the scope boundary and what's planned for later.
> I'd recommend capturing anything deliberately deferred."

Store the agreed answer in memory for use in §9. No separate file is written.

**Memory risk:** Steps 6–8 involve long operations (AWS fetches, multiple HTML passes).
If context pressure causes the afterword content to be unavailable when §9 is generated,
ask the author to repeat it rather than silently rendering the placeholder text.

### Concluding the interview

After all topics are covered (or skipped due to existing spec files), ask:
> "Ready to generate the architecture review document?
> (yes / skip remaining questions and generate / no — I want to add more)"

Proceed on "yes" or "skip". On "no", continue the conversation until the author is ready.

---

## Step 6: Fetch AWS Pricing

For each AWS service identified in `<effort_dir>/spec/cost.md` (or inferred from spec
artifacts), use the **WebFetch tool** to retrieve current pricing from AWS pricing pages:
- ElastiCache: `https://aws.amazon.com/elasticache/pricing/`
- MSK (Kafka): `https://aws.amazon.com/msk/pricing/`
- RDS: `https://aws.amazon.com/rds/pricing/`
- DynamoDB: `https://aws.amazon.com/dynamodb/pricing/`
- Lambda: `https://aws.amazon.com/lambda/pricing/`
- ECS/Fargate: `https://aws.amazon.com/fargate/pricing/`

Record the pricing tier relevant to the variable cost drivers identified in Step 5.
For any service where the fetch fails or pricing cannot be determined: note the gap.
The cost section (§8) will render a visible gap notice for that service rather than
silently omitting it.

---

## Step 7: Generate C4 Diagram Source

Generate Mermaid diagram source using the proper Mermaid C4 diagram types.

**System Context diagram** (always — use `C4Context`):

```
C4Context
  title System Context for <System Name>
  Person(user, "User", "Description of user")
  System(sys, "<System Name>", "Description")
  System_Ext(ext, "External System", "Description")
  Rel(user, sys, "Uses", "HTTPS")
  Rel(sys, ext, "Calls", "REST/Kafka")
```

**Container diagram** (when `.state.json` has >1 deployable, or when spec artifacts
reference multiple distinct services — use `C4Container`):

```
C4Container
  title Container Diagram for <System Name>
  Person(user, "User")
  Container(api, "API Service", "Node.js", "Handles requests")
  ContainerDb(db, "Database", "PostgreSQL", "Stores data")
  Container(worker, "Worker", "Java", "Processes events")
  Rel(user, api, "Uses", "HTTPS")
  Rel(api, db, "Reads/Writes", "SQL")
  Rel(api, worker, "Publishes", "Kafka")
```

Use actual entities from the spec artifacts rather than generic placeholders.
Both diagram types require `mermaid.js` to be loaded — the CDN script handles this.

---

## Step 8: Generate the HTML Document

Write `<html_file>` in passes to stay within tool-call size limits. The file is
valid HTML from Pass 1 onward.

**Pass 1 — Write the full HTML shell with CSS, nav, section placeholders:**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Architecture Review: <effort_id></title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,400;0,8..60,600;1,8..60,300&family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&display=swap');

    :root {
      --brand: #8529cd;
      --bg: #f9f6fe;
      --bg-alt: #ffffff;
      --text: #1a1a2e;
      --muted: #6b6b8a;
      --green: #009470; --green-bg: #e6f6f2; --green-border: #b3e8da;
      --red: #b83232; --red-bg: #fdf0f0; --red-border: #f5c0c0;
      --yellow: #b08000; --yellow-bg: #fdf8e6; --yellow-border: #eedda0;
      --blue: #1d4ed8; --blue-bg: #eff4ff; --blue-border: #bfcfff;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Source Serif 4', Georgia, serif; font-size: 16px; line-height: 1.6; color: var(--text); background: var(--bg); }

    nav { position: sticky; top: 0; z-index: 100; background: var(--bg); border-bottom: 2px solid var(--brand); padding: 0 2rem; display: flex; align-items: center; justify-content: space-between; height: 52px; }
    .nav-brand { font-family: 'IBM Plex Mono', monospace; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: var(--brand); }
    .nav-links { display: flex; gap: 1.5rem; list-style: none; }
    .nav-links a { font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--muted); text-decoration: none; }
    .nav-links a:hover { color: var(--brand); }
    .nav-badge { font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; padding: 0.25rem 0.75rem; border-radius: 2px; }
    .badge-pass { background: var(--green-bg); color: var(--green); border: 1px solid var(--green-border); }
    .badge-concern { background: var(--yellow-bg); color: var(--yellow); border: 1px solid var(--yellow-border); }
    .badge-fail { background: var(--red-bg); color: var(--red); border: 1px solid var(--red-border); }

    .section-wrap { padding: 72px 0; }
    .section-wrap.alt { background: var(--bg-alt); }
    .section-inner { max-width: 1100px; margin: 0 auto; padding: 0 2rem; }
    h2.section-title { font-family: 'Playfair Display', Georgia, serif; font-size: 28px; font-weight: 700; letter-spacing: -0.015em; color: var(--text); border-bottom: 2px solid var(--brand); padding-bottom: 0.5rem; margin-bottom: 1.5rem; }
    .section-meta { font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--muted); margin-bottom: 2rem; }
    h3 { font-family: 'Source Serif 4', serif; font-size: 1.1rem; font-weight: 600; margin: 1.5rem 0 0.75rem; color: var(--text); }

    table { width: 100%; border-collapse: collapse; margin: 1.5rem 0; font-size: 0.9rem; }
    th { font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; background: var(--brand); color: #fff; padding: 0.6rem 1rem; text-align: left; }
    td { padding: 0.6rem 1rem; border-bottom: 1px solid #e8e0f0; vertical-align: top; }
    tr:hover td { background: rgba(133,41,205,0.03); }

    .tag { font-family: 'IBM Plex Mono', monospace; font-size: 0.65rem; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; padding: 0.15rem 0.5rem; border-radius: 2px; white-space: nowrap; display: inline-block; }
    .tag-fail { background: var(--red-bg); color: var(--red); border: 1px solid var(--red-border); }
    .tag-concern { background: var(--yellow-bg); color: var(--yellow); border: 1px solid var(--yellow-border); }
    .tag-pass { background: var(--green-bg); color: var(--green); border: 1px solid var(--green-border); }

    .card { border: 1px solid #e8e0f0; border-radius: 4px; padding: 1.5rem; margin-bottom: 1rem; background: #fff; }
    .card-title { font-family: 'IBM Plex Mono', monospace; font-size: 0.85rem; font-weight: 600; color: var(--brand); margin-bottom: 0.75rem; }
    .card-meta { font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem; color: var(--muted); margin-bottom: 1rem; }
    details summary { font-family: 'IBM Plex Mono', monospace; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; cursor: pointer; color: var(--brand); margin-top: 0.75rem; }
    pre { font-family: 'IBM Plex Mono', monospace; font-size: 0.8rem; background: #f5f0fc; padding: 1rem; border-radius: 4px; overflow-x: auto; margin-top: 0.5rem; white-space: pre-wrap; }

    .gap-notice { background: var(--yellow-bg); border: 1px solid var(--yellow-border); border-left: 4px solid var(--yellow); padding: 1rem 1.5rem; border-radius: 0 4px 4px 0; margin: 1rem 0; }
    .gap-notice p { font-family: 'IBM Plex Mono', monospace; font-size: 0.8rem; color: var(--yellow); }

    .mermaid { background: #fff; border: 1px solid #e8e0f0; border-radius: 4px; padding: 1.5rem; margin: 1rem 0; }

    .cost-control { margin: 1.5rem 0; }
    .cost-control label { font-family: 'IBM Plex Mono', monospace; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; display: block; margin-bottom: 0.5rem; }
    .cost-control input[type=range] { width: 100%; accent-color: var(--brand); }
    .cost-result { font-family: 'IBM Plex Mono', monospace; font-size: 0.85rem; font-weight: 600; color: var(--brand); margin-top: 0.5rem; }

    @media print {
      nav { display: none; }
      .section-wrap { padding: 2rem 0; page-break-before: always; }
      .section-wrap:first-of-type { page-break-before: avoid; }
    }
  </style>
  <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
</head>
<body>
<nav>
  <span class="nav-brand">Arch Review — <effort_id></span>
  <ul class="nav-links">
    <li><a href="#overview">Overview</a></li>
    <li><a href="#validation">Validation</a></li>
    <li><a href="#c4">C4 Diagrams</a></li>
    <li><a href="#data-model">Data Model</a></li>
    <li><a href="#contracts">Contracts</a></li>
    <li><a href="#risks">Risk Mitigation</a></li>
    <li><a href="#rollout">Rollout</a></li>
    <li><a href="#cost">Cost Analysis</a></li>
    <li><a href="#afterword">Afterword</a></li>
  </ul>
  <span class="nav-badge RESULT_BADGE_CLASS">OVERALL_RESULT</span>
</nav>
<main>
<!-- SECTION:overview -->
<!-- SECTION:validation -->
<!-- SECTION:c4 -->
<!-- SECTION:data-model -->
<!-- SECTION:contracts -->
<!-- SECTION:risks -->
<!-- SECTION:rollout -->
<!-- SECTION:cost -->
<!-- SECTION:afterword -->
</main>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    if (window.mermaid) {
      mermaid.initialize({ startOnLoad: true, theme: 'neutral' });
    }
  });
</script>
</body>
</html>
```

**Pass 2–10** — Inject each section by replacing its `<!-- SECTION:id -->` placeholder.
Use the Edit tool for sections under 4KB. For sections ≥4KB, use this Python heredoc
pattern via Bash to avoid shell quoting pitfalls:

```bash
python3 - "<html_file>" <<'PYEOF'
import sys
path = sys.argv[1]
html = open(path, encoding='utf-8').read()
section = """<full section HTML here, no escaping needed>"""
html = html.replace('<!-- SECTION:data-model -->', section, 1)
open(path, 'w', encoding='utf-8').write(html)
PYEOF
```

Replace `<!-- SECTION:data-model -->` with the appropriate placeholder ID for each pass.
The file is valid HTML from Pass 1 onward.

**Alternating background pattern:** Apply `.alt` to even-numbered sections:
§1 overview — no alt, §2 validation — alt, §3 c4 — no alt, §4 data-model — alt,
§5 contracts — no alt, §6 risks — alt, §7 rollout — no alt, §8 cost — alt, §9 afterword — no alt.

---

### Section Content

#### §1 — Overview (`id="overview"`)

Source: `requirements/business.md`, `requirements/technical.md`, `.state.json`.

Render:
- One-paragraph summary: what are we building, why, for whom
- Table of BRs (ID, description, acceptance criteria)
- Table of TRs (ID, constraint, traces-to)
- If any BR or TR mentions a delivery date, surface it prominently as a callout

```html
<div class="section-wrap" id="overview">
  <div class="section-inner">
    <p class="section-meta">Architecture Review · <DATE> · Risk: <RISK> · Phase: Discovery</p>
    <h2 class="section-title">Effort Overview</h2>
    <p>...</p>
    <h3>Business Requirements</h3>
    <table><tr><th>ID</th><th>Requirement</th><th>Acceptance Criteria</th></tr>...</table>
    <h3>Technical Constraints</h3>
    <table><tr><th>ID</th><th>Constraint</th><th>Traces To</th></tr>...</table>
  </div>
</div>
```

#### §2 — Validation Report (`id="validation"`)

Source: `<effort_dir>/validation/report.md`.

**Terminology mapping** (apply throughout §2):
- `**REQUIRED**` findings → FAIL tier → `<span class="tag tag-fail">REQUIRED</span>`
- `**SUGGESTION**` findings → CONCERN tier → `<span class="tag tag-concern">SUGGESTION</span>`

**Priority tiering rule:**
- **Must Examine In Depth:**
  - All `**REQUIRED**` findings
  - `**SUGGESTION**` findings whose text mentions: security, privacy, PII, authentication,
    authorisation, authorization, uncovered BR, or a BR identifier (e.g. "BR-1")
- **Safe to Skip If Time-Limited:** all remaining `**SUGGESTION**` findings

**Area column:** Use the section heading from `report.md` under which the finding appears
(e.g., "Requirements Traceability", "Standards Compliance", "Cross-Spec Consistency",
"ADR Quality").

```html
<div class="section-wrap alt" id="validation">
  <div class="section-inner">
    <p class="section-meta">Validated · <REPORT TIMESTAMP></p>
    <h2 class="section-title">Validation Report</h2>
    <h3>Must Examine In Depth</h3>
    <table>
      <tr><th>Severity</th><th>Area</th><th>Finding</th></tr>
      <!-- REQUIRED findings + high-priority SUGGESTION findings -->
    </table>
    <h3>Safe to Skip If Time-Limited</h3>
    <table>
      <tr><th>Severity</th><th>Area</th><th>Finding</th></tr>
      <!-- remaining SUGGESTION findings -->
    </table>
  </div>
</div>
```

If the report has no findings at all, render a single green callout: "No findings — all
checks passed."

#### §3 — C4 Diagrams (`id="c4"`)

Source: Mermaid diagram source generated in Step 7.

Always include the System Context diagram. Include Container diagram when applicable.
Existing ADRs in `spec/arch-decisions/` may describe architectural components — reference
them in diagram labels and link their titles in the surrounding prose where relevant.

Embed Mermaid source inside `<div class="mermaid">` elements. The CDN script loaded in
`<head>` will render them. If offline (no Mermaid), the source text is still readable.

```html
<div class="section-wrap" id="c4">
  <div class="section-inner">
    <h2 class="section-title">C4 Diagrams</h2>
    <h3>System Context</h3>
    <div class="mermaid">
C4Context
  title System Context for ...
  ...
    </div>
    <!-- Container diagram section if applicable -->
  </div>
</div>
```

#### §4 — Data Model (`id="data-model"`)

Source: `<effort_dir>/spec/storage/` files.

Always wrap in the section container with `.alt`:

```html
<div class="section-wrap alt" id="data-model">
  <div class="section-inner">
    <h2 class="section-title">Data Model</h2>
    <!-- content below -->
  </div>
</div>
```

If `storage_present`:
- Render a logical ERD using Mermaid `erDiagram`
- Render a physical schema summary (tables, key columns, types, indexes) as prose or table
- If `data_mapping_present`: add a governance column to each table showing each field's
  classification (PII / Sensitive / Public / System) from the data-mapping output
- If `!data_mapping_present`: render a gap notice:

```html
<div class="gap-notice">
  <p>⚠ GOVERNANCE CLASSIFICATION NOT ASSESSED — Data-mapping governance classification
  has not been run for this effort. Field-level privacy classification is absent.
  Complete governance classification before the review meeting to populate this column.</p>
</div>
```

If `!storage_present`: render "No storage spec artifacts found for this effort."

#### §5 — Contracts (`id="contracts"`)

Always wrap in the section container (no `.alt`):

```html
<div class="section-wrap" id="contracts">
  <div class="section-inner">
    <h2 class="section-title">Contracts</h2>
    <!-- content below -->
  </div>
</div>
```

**API contracts** (if `api_present`):

Render each OpenAPI spec as an accordion — one `<details>` element per endpoint:

```html
<details>
  <summary>
    <span class="tag tag-pass">GET</span> /path/to/resource — Endpoint summary
    &nbsp;<span class="tag tag-pass">AUTH ✓</span>
    &nbsp;<span class="tag tag-fail">INPUT VALIDATION ✗</span>
  </summary>
  <div style="padding: 1rem;">
    <strong>Request:</strong> <pre>...</pre>
    <strong>Responses:</strong> <pre>...</pre>
  </div>
</details>
```

Auth badge: `.tag-pass` "AUTH ✓" if `security` is declared on the endpoint;
`.tag-fail` "AUTH ✗" if absent.

Input validation badge: `.tag-pass` "INPUT VALIDATION ✓" if request body/params have
schema constraints (type, minLength, pattern, etc.); `.tag-concern` "INPUT VALIDATION ~"
if partial; `.tag-fail` "INPUT VALIDATION ✗" if none.

If `!api_present`: render "No API spec artifacts found for this effort."

**Messaging contracts** (if `messaging_present`):

One card per event type. The three base classes provide pre-approved envelope fields —
do NOT list `message_id`, `event_name`, `event_version`, `produced_at_ms`, `trace_id`
as extension fields; these are already approved. For UserInitiatedMessage, also omit
`client_context`, `member`, `visit_id`, `cdn`, `security`. For ApiInitiatedMessage,
also omit `api_context` fields.

```html
<div class="card">
  <div class="card-title">com.example.loyalty.points.awarded</div>
  <div class="card-meta">
    Topic: loyalty.points.awarded.v1 · Compatibility: FORWARD_TRANSITIVE ·
    Base: <span class="tag tag-pass">ApiInitiatedMessage</span>
  </div>
  <p><small>ApiInitiatedMessage provides the standard envelope plus api_context
  (locale, user_agent, client_ip). These fields are pre-approved and not shown.</small></p>
  <strong>Producer:</strong> loyalty-service<br>
  <strong>Consumers:</strong> analytics-service, notification-service<br>
  <strong>Consumer trust model:</strong> Consumers validate message_id for idempotency<br>
  <strong>Delivery guarantee:</strong> at-least-once · <strong>Idempotency:</strong> deduplicate on message_id<br>
  <details>
    <summary>Extension fields (beyond base class)</summary>
    <pre>member_id: string — the member who earned points
points_delta: int32 — points awarded in this transaction
balance_after: int32 — new total point balance</pre>
  </details>
</div>
```

If `!messaging_present`: render "No messaging spec artifacts found for this effort."

#### §6 — Risk Mitigation (`id="risks"`)

Source: `<effort_dir>/spec/risks.md` (written during interview).

Always wrap in the section container with `.alt`:

```html
<div class="section-wrap alt" id="risks">
  <div class="section-inner">
    <h2 class="section-title">Risk Mitigation</h2>
    <!-- content below -->
  </div>
</div>
```

Three subsections: Failure Modes, Abuse Scenarios, Cross-Cutting Security.
If `<effort_dir>/spec/risks.md` is absent (interview was skipped): render a gap notice:

```html
<div class="gap-notice">
  <p>⚠ RISK ANALYSIS NOT CAPTURED — Run forge:arch-review again and complete the
  risk mitigation interview to populate this section.</p>
</div>
```

#### §7 — Rollout (`id="rollout"`)

Source: `<effort_dir>/spec/rollout.md` (written during interview).

Always wrap in the section container (no `.alt`):

```html
<div class="section-wrap" id="rollout">
  <div class="section-inner">
    <h2 class="section-title">Rollout</h2>
    <!-- content below -->
  </div>
</div>
```

Render phases, migration status, feature flag status, and rollback approach as labelled
blocks.

If `<effort_dir>/spec/rollout.md` is absent or empty: render a gap notice:
```html
<div class="gap-notice">
  <p>⚠ ROLLOUT PLAN NOT CAPTURED — Run forge:arch-review again and complete the
  rollout interview to populate this section.</p>
</div>
```

#### §8 — Cost Analysis (`id="cost"`)

Source: `<effort_dir>/spec/cost.md` + AWS pricing fetched in Step 6.

Always wrap in the section container with `.alt`:

```html
<div class="section-wrap alt" id="cost">
  <div class="section-inner">
    <h2 class="section-title">Cost Analysis</h2>
    <!-- content below -->
  </div>
</div>
```

If `<effort_dir>/spec/cost.md` is absent (interview was skipped): render a gap notice:

```html
<div class="gap-notice">
  <p>⚠ COST ANALYSIS NOT CAPTURED — Run forge:arch-review again and complete the
  cost interview to populate this section.</p>
</div>
```

For each variable cost driver in `spec/cost.md`, render an interactive control using
only inline JavaScript (no CDN, no framework). Use a unique function name per slider to
avoid collisions when multiple controls appear on the same page (e.g. `updateCacheCost`,
`updateMskCost`). Substitute pricing constants from Step 6:

```html
<div class="cost-control">
  <label>CACHE TTL (MINUTES) — currently: <span id="ttl-display">15</span> min</label>
  <input type="range" min="1" max="1440" value="15"
         oninput="document.getElementById('ttl-display').textContent=this.value; updateCacheCost(this.value)">
  <div class="cost-result" id="cache-cost-result"></div>
</div>
<script>
  (function() {
    var pricePerGbHour = PRICE_PER_GB_HOUR_FROM_STEP6;
    var estimatedEntries = ESTIMATED_ENTRIES_FROM_SPEC;
    var entrySizeBytes = ENTRY_SIZE_BYTES_FROM_SPEC;
    function updateCacheCost(ttlMinutes) {
      var memGb = (estimatedEntries * entrySizeBytes / (1024*1024*1024)) * (1440 / ttlMinutes);
      var monthly = memGb * pricePerGbHour * 730;
      document.getElementById('cache-cost-result').textContent =
        'Est. memory: ' + memGb.toFixed(2) + ' GB  ·  Monthly cost: ~$' + monthly.toFixed(2);
    }
    window.updateCacheCost = updateCacheCost;
    updateCacheCost(15);
  })();
</script>
```

The IIFE pattern (`(function() { ... })()`) prevents variable leakage when multiple cost
controls appear in the same page.

For services where pricing could not be fetched in Step 6: render a gap notice instead
of a slider.

#### §9 — Afterword (`id="afterword"`)

Source: interview answers from Topic 4 (held in memory).

```html
<div class="section-wrap" id="afterword">
  <div class="section-inner">
    <h2 class="section-title">Afterword</h2>
    <h3>Future Extensions</h3>
    <ul><!-- from interview --></ul>
    <h3>Outstanding Questions</h3>
    <ul><!-- from interview --></ul>
  </div>
</div>
```

If no afterword content was captured: render "No future extensions or outstanding
questions were identified during this review."

---

## Step 9: Compute Overall Result Badge

Extract the result from `<report_file>`:

```bash
grep '^\*\*Result:\*\*' "<effort_dir>/validation/report.md"
```

The output is a line like `**Result:** PASS WITH CONCERNS`. Extract the text after
`**Result:** ` and strip whitespace. Map to badge:

| Result value | Badge class | Display text |
|---|---|---|
| `PASS` | `badge-pass` | `PASS` |
| `PASS WITH CONCERNS` | `badge-concern` | `PASS WITH CONCERNS` |
| `FAIL` | `badge-fail` | `FAIL` |
| (no match / unrecognised) | `badge-concern` | `UNKNOWN` |

Use the Edit tool to replace the `RESULT_BADGE_CLASS` and `OVERALL_RESULT` literals
in the nav line of `<html_file>`. The nav line is always under 4KB so the Edit tool
is appropriate here.

---

## Step 10: Commit All Artifacts

### 10.1 — Branch guard

Check the current branch:
```bash
git branch --show-current
```

If the current branch is `main` or `master`: warn the engineer:
> "You are on `<branch>`. This commit should land on an effort branch, not directly
> on `<branch>`. Continue anyway? (yes/no)"
If "no": stop without committing.

### 10.2 — Ensure validation directory exists

```bash
mkdir -p "<effort_dir>/validation"
```

### 10.3 — Stage and commit

Stage all artifacts — including any spec files written during the interview (these may
be new untracked files on first run):

```bash
git add "<effort_dir>/validation/report.md"
git add "<effort_dir>/validation/arch-review.html"
git add "<effort_dir>/spec/rollout.md" 2>/dev/null || true
git add "<effort_dir>/spec/cost.md" 2>/dev/null || true
git add "<effort_dir>/spec/risks.md" 2>/dev/null || true
git commit -m "docs(<effort_id>): generate architecture review package"
```

The `|| true` on spec file adds is intentional — if a spec file wasn't written (topic
was skipped), the add is a no-op and should not fail the commit.

If `git` reports "nothing to commit" (identical re-run): treat as success.
If the commit fails for any other reason: surface the full error; do not suppress it.

---

## Step 11: Print Summary

Count findings from `<report_file>`:
- `required_count` — count of lines matching `^\*\*REQUIRED\*\*`
- `suggestion_count` — count of lines matching `^\*\*SUGGESTION\*\*`

```
forge:arch-review complete
Effort:     <effort_id>
Result:     <PASS | PASS WITH CONCERNS | FAIL>
REQUIRED:   <required_count>  (must resolve before forge:promote)
SUGGESTION: <suggestion_count>

Artifacts written:
  <effort_dir>/validation/report.md
  <effort_dir>/validation/arch-review.html

Next step: Open arch-review.html in a browser and share with the team.
           Run forge:promote once all REQUIRED findings are resolved.
```

---

## Error Handling

| Condition | Action |
|-----------|--------|
| Phase guard fails | Stop with clear message (Step 2) |
| `forge:validate` fails | Surface error; stop — do not generate HTML from stale data |
| AWS pricing fetch fails for a service | Note gap; render gap notice in §8; continue |
| Interview skipped by author | Use existing spec files; render gap notices where files are absent |
| Generated HTML would exceed 500KB | Summarise verbose spec content; do not quote verbatim |
| `validation/` directory absent | Create in Step 10.2 |
| Commit fails on protected branch | Surface error; prompt engineer to choose a branch (Step 10.1) |
| `requirements/business.md` absent | Note in §1 and §2; continue generating remaining sections |
