---
name: forge:statusline
description: Install the Forge-aware Claude Code statusline. Copies forge-statusline.py and forge-subagent-statusline.py to ~/.claude/ and writes statusLine and subagentStatusLine entries to ~/.claude/settings.json. Safe: stops if a non-Forge statusline is already configured unless --replace is passed. Use --uninstall to remove. Trigger on: "install the forge statusline", "set up the statusline", "forge statusline", "/forge:statusline".
argument-hint: "[--replace] [--uninstall]"
---

# forge:statusline

Installs and manages the Forge-aware Claude Code statusline. The skill copies two Python
scripts to `~/.claude/` and configures both `statusLine` and `subagentStatusLine` in
`~/.claude/settings.json`. The statusline renders the current model, working directory,
session cost, context usage, and active Forge effort in every Claude Code prompt.

---

## Arguments

| Flag | Description | Default |
|------|-------------|---------|
| `--replace` | Override an existing non-Forge statusline configuration | false |
| `--uninstall` | Remove both Forge statusline scripts and clear settings entries | false |

---

## Preconditions

Check the following before proceeding:

1. **Plugin is installed** — the plugin root must be resolvable (verified in Step 1).
2. **Mutually exclusive flags** — if both `--replace` and `--uninstall` are passed, stop
   immediately:
   > "`--replace` and `--uninstall` cannot be used together."

---

## Install Flow

Run this flow when `--uninstall` is NOT passed.

### Step 1 — Resolve Plugin Root

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record `plugin_root`. The script sources are:
- `<plugin_root>/statusline/forge-statusline.py`
- `<plugin_root>/statusline/forge-subagent-statusline.py`

If either source file is not present at the expected path, stop:
> "Forge statusline scripts not found at `<plugin_root>/statusline/`. The plugin cache
> may be incomplete. Try reinstalling or updating the Forge plugin."

---

### Step 2 — Check Existing Settings

Read `~/.claude/settings.json`. If the file does not exist, treat both settings as absent
and proceed to Step 3.

Inspect `statusLine.command` and `subagentStatusLine.command` as a pair:

| State | Action |
|-------|--------|
| Both absent | Proceed to Step 3 |
| `statusLine.command` == `~/.claude/forge-statusline.py` AND `subagentStatusLine.command` == `~/.claude/forge-subagent-statusline.py` | Compare installed scripts to source (content); if both match, print "already current" and stop; if either differs, proceed to Step 3 to update |
| Either key points to anything else | Stop unless `--replace` was passed |

When stopping due to a conflict, name the conflicting key:

- If only `statusLine` conflicts:
  > "`statusLine` is already configured with a custom command. Use `--replace` to override
  > both settings."
- If only `subagentStatusLine` conflicts:
  > "`subagentStatusLine` is already configured with a custom command. Use `--replace` to
  > override both settings."
- If both conflict:
  > "`statusLine` and `subagentStatusLine` are already configured with custom commands.
  > Use `--replace` to override both settings."

**Content comparison** (when both keys already point to Forge scripts):

```python3 - <<'PYEOF'
import sys
from pathlib import Path

plugin_root = sys.argv[1]

src_main    = Path(plugin_root) / 'statusline' / 'forge-statusline.py'
src_sub     = Path(plugin_root) / 'statusline' / 'forge-subagent-statusline.py'
dest_main   = Path.home() / '.claude' / 'forge-statusline.py'
dest_sub    = Path.home() / '.claude' / 'forge-subagent-statusline.py'

main_match = dest_main.exists() and dest_main.read_bytes() == src_main.read_bytes()
sub_match  = dest_sub.exists()  and dest_sub.read_bytes()  == src_sub.read_bytes()

if main_match and sub_match:
    print('current')
else:
    print('stale')
PYEOF
```

If the output is `current`, print:
```
forge:statusline — already current. No changes made.
```
Then stop.

---

### Step 3 — Copy Scripts

Copy both scripts to `~/.claude/` and make them executable.

```python3 - <<'PYEOF'
import shutil, stat, sys
from pathlib import Path

plugin_root = sys.argv[1]

scripts = [
    ('forge-statusline.py',         'forge-statusline.py'),
    ('forge-subagent-statusline.py','forge-subagent-statusline.py'),
]

dest_dir = Path.home() / '.claude'
dest_dir.mkdir(parents=True, exist_ok=True)

for src_name, dest_name in scripts:
    src  = Path(plugin_root) / 'statusline' / src_name
    dest = dest_dir / dest_name
    shutil.copy2(src, dest)
    dest.chmod(dest.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

print('ok')
PYEOF
```

If the script exits with a non-zero status or does not print `ok`, stop:
> "Failed to copy statusline scripts to `~/.claude/`. Check directory permissions."

---

### Step 4 — Merge Settings

Read `~/.claude/settings.json` (create an empty object if the file does not exist),
merge both statusline keys, and write back — preserving all other keys.

```python3 - <<'PYEOF'
import json, sys
from pathlib import Path

settings_path = Path.home() / '.claude' / 'settings.json'
cfg = {}
if settings_path.exists():
    try:
        cfg = json.loads(settings_path.read_text())
    except json.JSONDecodeError:
        cfg = {}

cfg['statusLine'] = {
    'type': 'command',
    'command': str(Path.home() / '.claude' / 'forge-statusline.py'),
    'padding': 2
}
cfg['subagentStatusLine'] = {
    'type': 'command',
    'command': str(Path.home() / '.claude' / 'forge-subagent-statusline.py')
}

settings_path.write_text(json.dumps(cfg, indent=2) + '\n')
print('ok')
PYEOF
```

If the script exits with a non-zero status or does not print `ok`, stop:
> "Failed to write `~/.claude/settings.json`. Check file permissions. No settings were
> changed."

---

### Step 5 — Print Summary

```
forge:statusline installed

  Scripts:  ~/.claude/forge-statusline.py
            ~/.claude/forge-subagent-statusline.py
  Settings: ~/.claude/settings.json (statusLine + subagentStatusLine configured)

The statusline will appear after your next interaction with Claude Code.
Re-run /forge:statusline to update the scripts when you upgrade Forge.
```

---

## Uninstall Flow

Run this flow when `--uninstall` is passed.

**Step 1 — Remove scripts**

```python3 - <<'PYEOF'
import sys
from pathlib import Path

scripts = [
    Path.home() / '.claude' / 'forge-statusline.py',
    Path.home() / '.claude' / 'forge-subagent-statusline.py',
]

for p in scripts:
    if p.exists():
        p.unlink()

print('ok')
PYEOF
```

**Step 2 — Remove settings entries**

Read `~/.claude/settings.json`, remove both `statusLine` and `subagentStatusLine` keys
(if present), and write back — preserving all other keys. If the file does not exist,
skip silently.

```python3 - <<'PYEOF'
import json, sys
from pathlib import Path

settings_path = Path.home() / '.claude' / 'settings.json'
if not settings_path.exists():
    print('ok')
    sys.exit(0)

try:
    cfg = json.loads(settings_path.read_text())
except json.JSONDecodeError:
    cfg = {}

cfg.pop('statusLine', None)
cfg.pop('subagentStatusLine', None)

settings_path.write_text(json.dumps(cfg, indent=2) + '\n')
print('ok')
PYEOF
```

**Step 3 — Print confirmation**

```
forge:statusline removed. Restart Claude Code to clear the display.
```

---

## Error Handling

| Condition | Action |
|-----------|--------|
| `--replace` and `--uninstall` both passed | Stop immediately: "`--replace` and `--uninstall` cannot be used together." |
| Plugin root not found (manifest unreadable) | Stop: "The Forge plugin does not appear to be installed or the manifest is missing. Try reinstalling the plugin." |
| Scripts not present in plugin cache | Stop: "Forge statusline scripts not found at `<plugin_root>/statusline/`. The plugin cache may be incomplete. Try reinstalling or updating the Forge plugin." |
| Conflict on existing settings without `--replace` | Stop; name the conflicting key(s); instruct the user to use `--replace` to override both. |
| Script copy fails | Stop: "Failed to copy statusline scripts to `~/.claude/`. Check directory permissions." |
| `settings.json` write failure | Stop: "Failed to write `~/.claude/settings.json`. Check file permissions. No settings were changed." |
