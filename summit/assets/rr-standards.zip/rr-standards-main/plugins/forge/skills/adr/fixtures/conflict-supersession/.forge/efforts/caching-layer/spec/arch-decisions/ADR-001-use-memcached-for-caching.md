# ADR-001: Use Memcached for Caching

**Status:** Accepted
**Effort ID:** caching-layer
**Date:** 2026-01-10

## Context
The API needs a fast, low-latency cache layer for session data.

## Decision
We will use Memcached for session caching.

## Alternatives Considered
Redis was considered but Memcached was chosen for its simplicity and lower memory overhead at the time.

## Consequences
Memcached becomes an operational dependency. No support for complex data structures.
