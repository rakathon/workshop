---
name: forge:adr
description: Capture an architectural decision record (ADR). Triggered automatically when a decision is made conversationally ("we'll use X because Y") or invoke explicitly to record a decision. Writes to the active effort, a specific deployable, or the repository level. Determines the next ADR number (filling gaps), writes the ADR file, and updates state.
argument-hint: "[title] [decision] [--effort <id>] [--deployable <id>] [--status Proposed]"
arguments: [title, decision]
---

# forge:adr

Captures an architectural decision as an ADR file. ADRs are scoped to one of three
locations depending on context:

| Scope | Path | When to use |
|-------|------|-------------|
| Effort | `.forge/efforts/<effort_id>/spec/arch-decisions/` | Decision made during active work on an effort |
| Deployable | `.forge/deployables/<deployable_id>/spec/arch-decisions/` | Decision added directly to a deployable — e.g. retroactively after an effort is complete |
| Repository | `.forge/spec/arch-decisions/` | Cross-cutting decisions not specific to any one deployable |

Works both when invoked explicitly and when triggered automatically by a conversational
decision statement.

---

## Arguments

All arguments are optional. When omitted, the skill derives what it can from conversation context.

| Argument | Description |
|----------|-------------|
| `title` | The decision subject, as a short phrase. Used to derive the ADR filename slug and the heading. Inferred from conversation if omitted. |
| `decision` | The decision itself, in one or two sentences. Written into the Decision section. Inferred from conversation if omitted. |
| `--effort <id>` | Write the ADR to this effort's `spec/arch-decisions/` directory. Overrides automatic effort detection. |
| `--deployable <id>` | Write the ADR directly to this deployable's `spec/arch-decisions/` directory. Use when recording a decision retroactively after an effort has been graduated. |
| `--status Proposed` | Set the ADR status to `Proposed` instead of the default `Accepted`. |

When neither `title` nor `decision` is provided, both are derived from the conversation.
When `title` is provided but `decision` is not, derive the decision body from context.
When both are provided, use them directly and derive Context, Alternatives Considered,
and Consequences from conversation.

---

## Preconditions

**PC-1:** Forge is initialized in this repository (`.forge/README.md` exists).

If PC-1 is not met, stop with:
> "This repository is not initialized with Forge. Run `forge:init` first."

An active effort is not required. ADRs can be written to an effort, a deployable, or
the repository level — Step 1 determines the right target from arguments and context.

---

## Step 1: Determine Write Target [orchestrator-only]

Resolve the ADR scope using the following priority order. Stop at the first match and
set `adr_scope`, `adr_dir`, and optionally `effort_id` / `deployable_id`.

**1. Explicit `--effort <id>` argument**
- Set `adr_scope = effort`, `effort_id = <id>`, `adr_dir = .forge/efforts/<id>/spec/arch-decisions/`
- Read `.forge/efforts/<id>/.state.json`. If it does not exist, stop — the effort
  directory is malformed.

**2. Explicit `--deployable <id>` argument**
- Set `adr_scope = deployable`, `deployable_id = <id>`, `adr_dir = .forge/deployables/<id>/spec/arch-decisions/`
- Confirm `.forge/deployables/<id>/` exists. If not, stop:
  > "Deployable `<id>` not found in `.forge/deployables/`. Check the deployable ID and try again."

**3. Active effort from context** (when neither flag was passed)

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-optional

If an effort is resolved:
- Set `adr_scope = effort`, `effort_id = <id>`, `adr_dir = .forge/efforts/<id>/spec/arch-decisions/`
- Read `.forge/efforts/<id>/.state.json`.

**4. Ambiguous or no context — ask the engineer**

If no scope can be determined (no active effort, no explicit flags, or multiple open
efforts with no clear match), present the available options and ask:

```
Where should I record this ADR?

  1. Effort — associate with an active effort
     <list open efforts by ID>
  2. Deployable — add directly to a deployable (e.g. retroactively)
     <list deployables by ID, if any>
  3. Repository — cross-cutting decision not specific to one deployable

Enter a number or type an effort/deployable ID:
```

Map the response to `adr_scope`, `adr_dir`, and the appropriate ID.

**After resolving scope**, read `.forge/efforts/README.md` before writing.

Record: `adr_scope` (`effort` | `deployable` | `repository`), `adr_dir`,
and `effort_id` or `deployable_id` as applicable (may be none for repository scope).

---

## Step 2: Find Next ADR Number [orchestrator-only]

Scan `<adr_dir>` for files matching `ADR-NNN-*.md`.

1. Extract the numeric component from each matching filename
2. Find the lowest positive integer not present in the set (gap-filling)
3. Zero-pad to three digits — this is `adr_num`

**Gap-filling rule:** If ADR-001 and ADR-003 exist but ADR-002 does not, the next ADR
is ADR-002. If the series is contiguous (001, 002, 003), the next is ADR-004.

If `<adr_dir>` does not exist, create it:

```bash
mkdir -p <adr_dir>
```

`adr_num` is `001`.

If the directory exists but contains no ADR files (only README.md or .gitkeep), `adr_num`
is `001`.

---

## Step 3: Determine Title and Decision Text

If `title` was provided as an argument, use it. Otherwise, extract the decision subject
from the most recent decision statement in the conversation.

If `decision` was provided as an argument, use it. Otherwise, extract the decision from
the conversation, stated clearly and directly (no hedging).

**Conversational trigger patterns — use judgment to recognize:**

| Pattern type | Examples |
|-------------|---------|
| Direct decision statement | "we'll use X", "we're going with X", "let's use X" |
| Rationale-bearing decision | "we'll use X because Y", "let's go with X — it gives us Y" |
| Explicit decision announcement | "we've decided to X", "the decision is X", "I've decided to X" |
| Commitment after discussion | "okay, let's go with option B", "I think X is the right call" |

These are intent signals, not NLP rules. Distinguish casual technology mentions from
genuine architectural commitments. "I'm reading about DynamoDB" is not a decision.
"Let's use DynamoDB for the session table" is.

If the conversation contains multiple distinct decisions in a single exchange, create
one ADR per decision with sequential numbers. Ask the engineer to confirm if there is
ambiguity about whether statements represent separate decisions.

**When context is insufficient:** If neither a `title` argument nor a clear decision
statement can be found in the conversation, enter a short clarifying exchange:

1. Ask: "What decision should I record?" — wait for the engineer's response
2. If the response is a bare title with no rationale, ask: "What was the reasoning or
   context behind this decision?" — wait, then use the response to populate Context
   and Consequences
3. Do not proceed to Step 4 until both title and decision text are determined

Do not fabricate a title or decision — ask rather than guess.

---

## Step 3b: Semantic Overlap Check

Run this check after the title is determined and before deriving the filename.
Record `superseded_adrs = []` at the start of this step.

**Collect existing ADR titles:**

Read the title line (`# ADR-NNN: <Title>`) from every file matching `ADR-NNN-*.md`
in `<adr_dir>`. Build a list of `{ number, title, path, scope }` entries.

**Cross-scope check (effort scope only):**

If `adr_scope = effort`, also attempt to find the associated deployable:

1. Check `<effort_dir>/.state.json` for a `deployableId` field — if present, use it
2. Otherwise check whether `.forge/deployables/<effort_id>/` exists — if so, use `<effort_id>` as the deployable ID
3. If a deployable is found, read ADR titles from `.forge/deployables/<deployable_id>/spec/arch-decisions/` and add them to the list, tagged with the deployable scope

**Classify each candidate:**

For each existing ADR whose title appears to address the same concern as the proposed
title, read its `## Decision` section and classify it:

- **Duplicate** — same concern, same choice
  ("Use Redis for session caching" vs "Use Redis as the session store")
- **Conflict** — same concern, different choice
  ("Use Memcached for caching" vs "Use Redis for caching")

If title comparison alone is unambiguous, reading the Decision section is optional.
When the title is ambiguous, always read the Decision section before classifying.

**If conflicts are found**, present them and ask:

```
This decision conflicts with an existing ADR:
  - ADR-002: Use Memcached for Caching  [effort: user-auth-service]
    Decision: We will use Memcached for session caching.

Does the new ADR supersede ADR-002?

  1. Yes — write new ADR and mark ADR-002 as Superseded by ADR-NNN
  2. No — these address different aspects, proceed without changing ADR-002
  3. Cancel — do not write the new ADR
```

- Engineer selects **1** → append `{ number, path, scope }` to `superseded_adrs`; continue to Step 4
- Engineer selects **2** → continue to Step 4 (no change to old ADR)
- Engineer selects **3** → stop without writing any files

If multiple conflicts exist, present each in turn and collect a response for each.

**If only duplicates are found** (no conflicts), present them and ask:

```
The following existing ADR(s) may cover the same decision:
  - ADR-003: Use Redis for Session Cache  [effort: user-auth-service]

Is "<proposed title>" a distinct architectural decision?

  1. Yes, it's distinct — proceed with new ADR
  2. No, it's a duplicate — cancel
```

- Engineer selects **1** → continue to Step 4
- Engineer selects **2** → stop without writing any files

**If no overlap of any kind is found** → proceed silently to Step 4; do not mention the check.

---

## Step 4: Derive Slug and Filename

Convert the title to kebab-case:

- Lowercase all characters
- Replace spaces and underscores with hyphens
- Remove punctuation
- Collapse consecutive hyphens to one
- Trim leading and trailing hyphens
- Truncate to 60 characters at a word boundary

Filename: `ADR-<adr_num>-<slug>.md`
Full path: `<adr_dir>/ADR-<adr_num>-<slug>.md`

Examples:
- `ADR-001-three-tier-claude-md-context-design.md`
- `ADR-007-quality-loop-at-task-execution-not-verification.md`
- `ADR-012-use-postgresql-for-session-storage.md`

If this path already exists, prompt the engineer:
> "ADR-<adr_num> already exists at that path. Confirm to overwrite, or provide a different title."

Do not overwrite without confirmation. ADR filenames are permanent once committed — never
rename existing ADR files.

---

## Step 5: Write the ADR File [orchestrator-only]

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record: `plugin_root`.

If the manifest cannot be read, stop with:
> "The Forge plugin does not appear to be installed or the manifest is missing.
> Try reinstalling the plugin."

Read `<plugin_root>/templates/adr.md` to get the canonical ADR file structure.
Populate all four sections from that template. No section may be left empty — if
the conversation does not provide enough material, write a concise inference rather
than leaving it blank.

**Scope metadata line:** The template contains `**Effort ID:** [effort-id]`. Adjust
this line based on scope:
- Effort scope: `**Effort ID:** <effort-id>`
- Deployable scope: replace with `**Deployable:** <deployable-id>`
- Repository scope: omit the line entirely

**Section population guidance:**

- **Context:** From conversation — what problem was being solved, what constraints existed.
  If the engineer provided only a title and decision, derive context from the surrounding discussion.
- **Decision:** From the `decision` argument, or derived from conversation. Stated directly:
  "We will use X." Not hedged.
- **Alternatives Considered:** From any alternatives discussed before the decision. If none
  were explicitly discussed, write: "No alternatives were explicitly considered."
- **Consequences:** From any follow-on discussion. If not discussed, infer from the nature
  of the decision: what it enables, what it constrains, what must now be true.

**Status field values:**

| Value | When to use |
|-------|-------------|
| `Accepted` | The decision is current and in force (default) |
| `Proposed` | The decision is under consideration but not yet committed |
| `Deprecated` | The decision was once accepted but no longer applies |
| `Superseded` | The decision was replaced by a later ADR (reference the superseding ADR) |

All ADRs start with status `Accepted`. If the engineer explicitly requests `Proposed` status
(the decision is tentative), set `Status: Proposed` instead.

If the engineer provides a different set of section headers, do not silently accept them.
Inform the engineer that all four sections are required and proceed with the standard template.

---

## Step 6: Update the ADR Index [orchestrator-only]

Read `<adr_dir>/README.md`.

If the file does not exist, create it. Use the appropriate scope label in the heading:
- Effort scope: `Architecture Decisions — <effort-id>`
- Deployable scope: `Architecture Decisions — <deployable-id>`
- Repository scope: `Architecture Decisions — Repository`

```markdown
# Architecture Decisions — <scope-label>

| ADR | Title | Status | Date |
|-----|-------|--------|------|
```

Append a row for the new ADR, inserting in numeric order:

```
| [ADR-<adr_num>](ADR-<adr_num>-<slug>.md) | <Title> | Accepted | <YYYY-MM-DD> |
```

The index must always be sorted by ADR number.

---

## Step 6b: Update Superseded ADRs [orchestrator-only]

**Only executes if `superseded_adrs` is non-empty** (engineer confirmed supersession
in Step 3b).

For each entry in `superseded_adrs`:

1. Read the ADR file at `<entry.path>`
2. Replace the Status line:
   ```
   **Status:** Accepted
   ```
   with:
   ```
   **Status:** Superseded by ADR-<adr_num>
   ```
   Use the Edit tool — do not rewrite the full file.

3. Update the corresponding index file. The index to update is:
   - `<adr_dir>/README.md` if the superseded ADR is in the same scope
   - `.forge/deployables/<deployable_id>/spec/arch-decisions/README.md` if cross-scope

   Find the row for the superseded ADR by number and change its Status column:
   ```
   | [ADR-002](...) | Use Memcached for Caching | Accepted    | 2026-01-10 |
   ```
   becomes:
   ```
   | [ADR-002](...) | Use Memcached for Caching | Superseded  | 2026-01-10 |
   ```

---

## Step 7: Update `.state.json` adrsCreated [orchestrator-only]

**Skip this step if `adr_scope` is `deployable` or `repository`.** Only effort-scoped ADRs are tracked in `.state.json`.

Append `ADR-<adr_num>-<slug>` (without `.md`) to the `adrsCreated` array in
`<effort_dir>/.state.json`. Do not overwrite the array — append to it.

ADRs are not phase-specific. Always write to `phases.discovery.artifacts.adrsCreated`,
regardless of the effort's current phase. Read the current `.state.json` before writing
to avoid clobbering other fields.

---

## Step 8: Confirm and Suggest Commit

Print a summary of what was written:

```
ADR written: <adr_dir>/ADR-<adr_num>-<slug>.md
Index updated: <adr_dir>/README.md
State updated: <effort_dir>/.state.json           ← effort scope only
Superseded: <path-to-old-adr> → Superseded by ADR-<adr_num>   ← if any
```

Suggested commit:

```
  git add <adr_dir>/ [<effort_dir>/.state.json] [<superseded-adr-paths>]
  git commit -m "docs(<scope-label>): ADR-<adr_num> <decision-subject>"
```

Where:
- `<scope-label>` is the effort ID, deployable ID, or `repo` for repository-wide ADRs
- `<decision-subject>` is the title, truncated to 60 characters if necessary
- The `.state.json` line is omitted for deployable and repository scope
- Each superseded ADR file and its index are included in the `git add` if Step 6b ran

Do not run the commit — the engineer commits when ready.
