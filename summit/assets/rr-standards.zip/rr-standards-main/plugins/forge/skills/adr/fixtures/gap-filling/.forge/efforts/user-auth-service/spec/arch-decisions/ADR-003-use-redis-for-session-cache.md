# ADR-003: Use Redis for Session Cache

**Status:** Accepted
**Effort ID:** user-auth-service
**Date:** 2026-01-12

## Context
We needed fast session lookups.

## Decision
We will use Redis for session caching.

## Alternatives Considered
Memcached was considered; Redis chosen for richer data structures.

## Consequences
Adds Redis as an operational dependency.
