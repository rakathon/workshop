# Architecture Decisions — caching-layer

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-001](ADR-001-use-redis-for-session-cache.md) | Use Redis for Session Cache | Accepted | 2026-01-15 |
