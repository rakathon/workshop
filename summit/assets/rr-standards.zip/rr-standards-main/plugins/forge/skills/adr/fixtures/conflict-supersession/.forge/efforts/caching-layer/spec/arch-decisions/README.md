# Architecture Decisions — caching-layer

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-001](ADR-001-use-memcached-for-caching.md) | Use Memcached for Caching | Accepted | 2026-01-10 |
