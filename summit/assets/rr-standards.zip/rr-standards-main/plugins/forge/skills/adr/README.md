# forge:adr

Record an architectural decision. ADRs can be scoped to an active effort, a specific deployable, or the repository as a whole.

---

## What It Does

`forge:adr` captures an architectural decision as a structured ADR file. It:

1. Identifies the active effort from context, branch name, or explicit argument
2. Scans existing ADR files and determines the next number, filling any gaps in the sequence
3. Derives the title and decision text from explicit arguments or conversation context
4. Writes the ADR file using the standard four-section template
5. Creates or updates the ADR index (`spec/arch-decisions/README.md`)
6. Appends the new ADR to `adrsCreated` in `.state.json`
7. Prints the files written and a suggested commit command

ADRs are scoped to the active effort. Each effort maintains its own series starting at
ADR-001. Numbers are not global to the repository.

---

## When to Use

Use `forge:adr` whenever an architectural decision is made that should be recorded for
future reference:

- Choosing a technology, framework, or library ("we'll use PostgreSQL for session storage")
- Selecting a design pattern or architectural approach ("event sourcing for the transaction log")
- Deciding on an API design, data model, or integration strategy
- Making a trade-off between competing approaches

### Automatic triggering

Claude recognizes decision statements in conversation and triggers `forge:adr`
automatically without an explicit invocation:

| Pattern | Example |
|---------|---------|
| Direct decision | "we'll use Redis for caching" |
| Decision with rationale | "let's use Kafka because we need fan-out" |
| Commitment after discussion | "okay, let's go with option B" |
| Explicit announcement | "the decision is to use REST over GraphQL" |

Casual mentions of technology are not decisions. "I'm reading about DynamoDB" does not
trigger `forge:adr`. "Let's use DynamoDB for the session table" does.

---

## Usage

### Explicit invocation

```
/forge:adr
```

Claude will ask for a title and decision if not provided.

### With arguments

```
/forge:adr "Use PostgreSQL for session storage" --decision "We will use PostgreSQL for the session table because it is already provisioned and we do not need a separate Redis cluster."
```

### Conversational invocation

```
"We're going with PostgreSQL for session storage — it's already in our stack and
we don't want to manage a separate cache cluster for this."
```

Claude captures the title ("Use PostgreSQL for session storage"), the decision, and
the rationale from the conversation and writes the ADR automatically.

### Arguments

| Argument | Description |
|----------|-------------|
| `title` | The decision subject as a short phrase (optional — inferred from conversation) |
| `decision` | The decision in one or two sentences (optional — inferred from conversation) |
| `--effort <id>` | Write to this effort's `spec/arch-decisions/` directory |
| `--deployable <id>` | Write directly to this deployable's `spec/arch-decisions/` directory |
| `--status Proposed` | Set status to `Proposed` for tentative decisions (default: `Accepted`) |

---

## ADR Numbering

ADR numbers are scoped to the active effort, starting at ADR-001. The skill uses
gap-filling: if ADR-001 and ADR-003 exist but ADR-002 does not, the next ADR is
ADR-002. This ensures accidental deletions do not corrupt the numbering sequence.

Numbers are zero-padded to three digits: ADR-001, ADR-012, ADR-100.

---

## ADR Format

Every ADR uses the standard four-section template:

```markdown
# ADR-NNN: <Title>

**Status:** Accepted
**Effort ID:** <effort-id>
**Date:** <YYYY-MM-DD>

## Context

<Why this decision was needed — the problem, constraints, and conversation context.>

## Decision

<The decision itself, stated clearly and directly. "We will use X.">

## Alternatives Considered

<Alternatives discussed and why they were not chosen. If none: "No alternatives
were explicitly considered.">

## Consequences

<What this decision means going forward — what is now easier, harder, or constrained.>
```

All four sections are required. `forge:adr` populates every section; no section is
left empty.

### Status values

| Status | Meaning |
|--------|---------|
| `Accepted` | Decision is current and in force (default) |
| `Proposed` | Decision is under consideration, not yet committed |
| `Deprecated` | Decision was once accepted but no longer applies |
| `Superseded` | Decision was replaced by a later ADR |

---

## What It Creates

Depending on scope, the ADR lands in one of three locations:

```
.forge/efforts/<effort_id>/spec/arch-decisions/    ← effort scope (during active work)
.forge/deployables/<deployable_id>/spec/arch-decisions/  ← deployable scope (retroactive)
.forge/spec/arch-decisions/                        ← repository scope (cross-cutting)
```

In each case the skill writes:
```
<scope-dir>/
├── README.md                          ← index (created or updated)
└── ADR-NNN-<kebab-case-title>.md      ← new ADR file
```

For effort-scoped ADRs, `.forge/efforts/<id>/.state.json` is also updated to record the
new ADR in the `phases.discovery.artifacts.adrsCreated` array.

---

## Multiple Decisions in One Exchange

If a conversation contains multiple distinct architectural decisions, `forge:adr` creates
one ADR per decision with sequential numbers. Claude will ask for confirmation if it is
unclear whether statements represent separate decisions.

---

## Examples

### Record a technology choice

```
"Let's use DynamoDB for the leaderboard table — single-digit millisecond reads
and we don't need relational queries for this use case."
```

Produces: `ADR-001-use-dynamodb-for-leaderboard-table.md`

### Record a design pattern decision

```
/forge:adr "Event sourcing for transaction log"
```

Claude derives the decision and context from the surrounding conversation.
Produces: `ADR-002-event-sourcing-for-transaction-log.md`

### Record a tentative decision

```
/forge:adr "Use GraphQL for mobile API" --status Proposed
```

Produces an ADR with `Status: Proposed` — useful for decisions still under review.

---

## Prerequisites

- Repository must be initialized with Forge (`.forge/README.md` must exist)
- An active effort is not required. When no scope can be determined from context or
  arguments, the skill asks where to write the ADR.

---

## Related Skills

| Skill | When to use |
|-------|-------------|
| `forge:effort` | Create the effort before recording ADRs |
| `forge:status` | Check the effort's current artifacts, including ADRs created |
| `forge:promote` | Advance the effort to the next phase after discovery is complete |
| `forge:graduate` | Promote effort artifacts (including ADRs) to canonical deployable documentation |
