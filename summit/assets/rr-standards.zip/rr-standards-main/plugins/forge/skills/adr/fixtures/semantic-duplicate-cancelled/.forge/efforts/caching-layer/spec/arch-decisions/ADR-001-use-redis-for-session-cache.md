# ADR-001: Use Redis for Session Cache

**Status:** Accepted
**Effort ID:** caching-layer
**Date:** 2026-01-15

## Context
The API performs a session lookup on every authenticated request. Hitting the primary database on each call adds unnecessary load and latency.

## Decision
We will use Redis for session caching.

## Alternatives Considered
Memcached was considered but rejected because Redis supports richer data structures needed for future rate-limiting work.

## Consequences
Redis becomes an operational dependency. Session TTL management must be handled explicitly.
