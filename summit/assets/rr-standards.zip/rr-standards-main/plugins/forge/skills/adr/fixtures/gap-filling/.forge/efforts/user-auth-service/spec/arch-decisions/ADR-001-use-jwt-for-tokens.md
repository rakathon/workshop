# ADR-001: Use JWT for Tokens

**Status:** Accepted
**Effort ID:** user-auth-service
**Date:** 2026-01-10

## Context
We needed a stateless authentication mechanism.

## Decision
We will use JWT for access tokens.

## Alternatives Considered
Session cookies rejected due to horizontal scaling constraints.

## Consequences
Tokens are self-contained. Token revocation requires a denylist.
