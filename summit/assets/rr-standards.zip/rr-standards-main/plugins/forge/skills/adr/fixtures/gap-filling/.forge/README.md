# Forge
| Effort ID | Status | Phase |
|-----------|--------|-------|
| user-auth-service | active | discovery |
