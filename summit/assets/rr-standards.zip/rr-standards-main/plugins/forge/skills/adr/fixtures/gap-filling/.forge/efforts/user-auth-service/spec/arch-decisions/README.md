# Architecture Decisions — user-auth-service

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-001](ADR-001-use-jwt-for-tokens.md) | Use JWT for Tokens | Accepted | 2026-01-10 |
| [ADR-003](ADR-003-use-redis-for-session-cache.md) | Use Redis for Session Cache | Accepted | 2026-01-12 |
