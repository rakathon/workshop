---
name: forge:pause
description: Pause the current work session and create a structured handoff record. Use when ending work for the day, handing off to a colleague, or when context is depleting. Persists current position, open decisions, and next action to .state.json so the next session can resume exactly where this one left off.
---

# forge:pause

Persists mid-task session state to `.state.json` so a subsequent session can resume
without information loss. The conversational equivalent is Claude recognizing a
"let's pick this up tomorrow" or "I need to stop here" signal and persisting pause
state automatically.

---

## Preconditions

**PC-1: An active effort exists**

An effort directory must be present under `.forge/efforts/` with a `.state.json` file.

**PC-2: Work state exists to persist**

The effort must be in a phase where mid-task state exists (typically implementation,
but also applicable during discovery or planning when work is incomplete).

---

## Step 1: Identify the Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

If no effort is found, stop with:
> "No active effort found. Run `forge:effort` to create one."

---

## Step 2: Read `.state.json`

Read `.forge/efforts/<id>/.state.json`. Capture: `currentPhase`, `openDecisions`,
and any existing `phases.implementation.checkpoint` or `phases.implementation.remainingTasks`.

---

## Step 3: Identify Current Task State

Based on `currentPhase`:

- **implementation**: Read `plan/tasks.md` to identify which task is in progress
  (the last task marked in-progress, or the last attempted task). If the file does not
  exist, note that no task plan is present.
- **discovery**: Identify which artifact was most recently worked on based on the
  session context.
- **planning**: Identify the current planning state from the session context.

If the current task is in a failed or blocked state (e.g., a quality loop exceeded
its iteration limit), describe the exact failure to the engineer before proceeding.
Ask whether to note it in the pause state or take action before stopping.

---

## Step 4: Compose the `pauseState` Object

Synthesize from the current session context:

```json
{
  "activeTask": "<TASK-ID or null>",
  "activePhase": "<currentPhase value>",
  "contextSummary": "<2-3 sentence summary of where we are and what decisions were made this session>",
  "lastCompletedStep": "<description of last completed step>",
  "nextAction": "<specific description of the next step the resuming agent should take>",
  "pausedAt": "<ISO-8601 timestamp>"
}
```

**`contextSummary` requirements:** Must include enough detail that a new session can
resume without reading the full conversation history. Capture:

- The problem being solved or the artifact being produced
- Any decisions made this session that are not yet in an ADR
- Any constraints or concerns that are in-context but not in state files

**`nextAction` requirements:** Must be specific and actionable — not "continue
implementation" but "implement the token validation middleware in
`src/middleware/auth.ts` (TASK-003, Wave 2)".

---

## Step 5: Write `pauseState` to `.state.json`

Merge the `pauseState` object into the existing `.state.json`. Preserve all other
fields unchanged. Maintain alphabetical key ordering at every nesting level.

The resulting `.state.json` will contain:

```json
{
  ...existing fields...,
  "pauseState": {
    "activePhase": "<currentPhase>",
    "activeTask": "<TASK-ID or null>",
    "contextSummary": "<summary>",
    "lastCompletedStep": "<step>",
    "nextAction": "<next step>",
    "pausedAt": "<ISO-8601>"
  }
}
```

---

## Step 6: Commit the Updated `.state.json`

Stage and commit only `.state.json`:

```bash
git add .forge/efforts/<id>/.state.json
git commit -m "chore(<id>): pause session — <brief description of where work stopped>"
```

The brief description should be 3-6 words summarizing the stopping point
(e.g., "mid token validation implementation" or "after discovery phase approved").

If the commit fails, surface the error and stop. Do not delete `.forge/EFFORT` if
the commit has not succeeded.

---

## Step 6b: Delete Active Effort Pointer

After the commit succeeds, delete `.forge/EFFORT` if it exists:

```bash
rm -f .forge/EFFORT
```

This clears the session-local active effort pointer. The file must be deleted, not
emptied — an absent file is the canonical "no active effort" state. The next session
will re-establish the pointer via `forge:resume` or by being prompted on first use.

Print: "Active effort pointer cleared."

---

## Step 7: Print Confirmation

Print a summary:

```
Paused: <effort-id>

  Paused at:    <pausedAt>
  Active task:  <activeTask or "none">
  Phase:        <activePhase>

  Context:
    <contextSummary>

  Next action when resuming:
    <nextAction>
```

If any `openDecisions` are present, list them:

```
  Open decisions to resolve before resuming:
    OD-001: <description> [blocks <blockedTask or "no specific task">]
    ...
```

Then:

> "Run `forge:resume` at the start of the next session to restore this context."

---

## Deviation Rules

**Autonomous:**
- Composing the `contextSummary` from the current session context.
- Deriving the `nextAction` from the current task state and phase.
- Deriving the commit message brief description from the stopping point.

**Escalate to engineer:**
- If the current task is in a failed or blocked state — describe the exact failure
  before pausing so the engineer can decide whether to note it in `pauseState` or
  take action first.
- If the engineer is in the middle of a multi-step operation that cannot be safely
  interrupted — warn and ask whether to complete the step before pausing.

---

## [orchestrator-only]

- Reading session conversation history to compose the `contextSummary`.
- Printing the pause confirmation to the engineer.
- This skill always runs in the main session, never as a sub-agent.
