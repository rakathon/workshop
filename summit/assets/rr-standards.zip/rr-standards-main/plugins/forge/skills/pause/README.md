# forge:pause

Saves the current work session state so the next session can pick up exactly where
this one left off.

## Purpose

When you stop working mid-task — end of day, context window depleting, handing off
to a colleague — `forge:pause` captures where you are and what needs to happen next.
It writes a structured `pauseState` record to `.state.json` and commits it, so the
resuming session gets an immediate, accurate handoff rather than reconstructing context
from scratch.

## When to Use

- End of a work session when implementation is in progress
- Handing off to a colleague mid-task
- Context window approaching capacity and you want to preserve state before starting
  a fresh session
- Any time you want to ensure the next session starts with full context

The SessionStart hook will automatically surface any pause state at the beginning of
the next session. Run `forge:resume` to restore full context and clear the pause
record.

## Usage

```
forge:pause
```

No arguments required. `forge:pause` derives everything from the current session
context and `.state.json`.

## What It Does

1. Identifies the active effort
2. Reads the current phase and task state from `.state.json` and `plan/tasks.md`
3. Composes a context summary and specific next action from the current session
4. Writes the `pauseState` object to `.state.json`
5. Commits the updated state
6. Prints a confirmation showing what was recorded and any open decisions to resolve

## Output

A confirmation message showing the paused state:

```
Paused: <effort-id>

  Paused at:    2026-03-27T14:30:00Z
  Active task:  TASK-003
  Phase:        implementation

  Context:
    Implementing token validation middleware. Decided to use a stateless JWT approach
    (no revocation list) after reviewing the auth team's constraints. The middleware
    skeleton exists but the claim extraction logic is not yet written.

  Next action when resuming:
    Implement extractMemberIdClaim() in src/middleware/auth.ts, then write the
    unit tests in test/middleware/auth.test.ts (TASK-003, Wave 2).

  Open decisions to resolve before resuming:
    OD-001: JWT claim name for member ID [blocks TASK-009]

Run forge:resume at the start of the next session to restore this context.
```

## Files Modified

| File | Change |
|------|--------|
| `.forge/efforts/<id>/.state.json` | `pauseState` object written and committed |
