---
name: forge:update-plan
description: >
  Mark one or more implementation tasks complete in plan/tasks.md and .state.json.
  Records each task's commit SHA inline for traceability, moves tasks from
  remainingTasks to completedTasks, and queues Jira sync. Handles multiple tasks
  completed in the same commit or across several commits by scanning the git log
  window rather than reading only HEAD. Run after forge:commit — can be run once
  after several commits without losing per-task SHA accuracy.
agent-type: orchestrator
argument-hint: "[TASK-NNN]"
arguments: [task_id]
---

# forge:update-plan

Marks one or more implementation tasks complete in `plan/tasks.md`, records each
task's commit SHA inline for permanent traceability, moves tasks from `remainingTasks`
to `completedTasks` in `.state.json`, and sets `jira.syncStatus = "pending"` to
trigger Jira sync.

Run after `forge:commit`. If you ran several commits before calling this skill, it
will scan back through those commits and assign the correct SHA to each task
automatically.

---

## Variables

- `<effort_id>` — the effort slug (e.g., `forge-update-plan`, `favorites-api`)
- `<effort_dir>` — `.forge/efforts/<effort_id>/`
- `<tasks_file>` — `<effort_dir>/plan/tasks.md` (resolved to a real path)
- `<state_file>` — `<effort_dir>/.state.json` (resolved to a real path)
- `<task_mappings>` — list of `{task_id, sha, sha_short}` entries built in Step 2;
  one entry per task to be marked complete. All subsequent steps operate over this list.
- `<window>` — git log depth to scan, computed as `max(len(remainingTasks) × 2, 10)`

---

## Step 1: Resolve Effort Context

**Resolving `<effort_id>` at runtime:**

1. Check `.forge/EFFORT`. If the file exists and contains a non-empty string, use that
   string as `<effort_id>` (trim whitespace). Verify `.forge/efforts/<effort_id>/.state.json`
   exists before proceeding with it.

2. If `.forge/EFFORT` is absent or empty, check the current branch name:
   ```bash
   git rev-parse --abbrev-ref HEAD
   ```
   Strip any branch-type prefix (`feat/`, `feature/`, `effort/`, `fix/`, `chore/`,
   `refactor/`, `docs/`, `hotfix/`, `release/`). Check whether the remainder matches
   a directory name under `.forge/efforts/`. If so, use it as `<effort_id>`.

   Example: branch `feat/forge-update-plan` → strip `feat/` → check
   `.forge/efforts/forge-update-plan/` → found → `<effort_id>` = `forge-update-plan`.

3. If no branch match: read `.forge/efforts/README.md`. If exactly one effort is listed
   as in-progress or in implementation phase, use it.

4. If multiple efforts are active and no branch match is found: list them and ask the
   engineer which effort this task belongs to.

5. If no effort can be resolved: stop with:
   > "No active effort found. Run `forge:effort` to initialize one, or ensure you are
   > on an effort branch."

Once resolved, read `<state_file>`. Verify `phases.implementation` exists. Extract
`remainingTasks` and `completedTasks` arrays — store them in working context for use
in subsequent steps without re-reading the file.

Compute `<window>` = max(len(remainingTasks) × 2, 10).

---

## Step 2: Build Task Mappings

This step builds `<task_mappings>`: a list of `{task_id, sha, sha_short}` entries —
one per task that should be marked complete, each bound to the correct commit SHA.

**Priority 1 — Explicit argument:**

If the engineer invoked `forge:update-plan TASK-NNN` (one specific task ID):

Scan the git log window for that task's commit:
```bash
git log -<window> --format="COMMIT %H %h%n%s %N%n---END---"
```
Parse each commit block (separated by `---END---`). Search each block's text for the
pattern `TASK-NNN`. Use the SHA from the first commit block that contains it.

If the task ID is not found in any commit in the window, fall back to HEAD:
```bash
git log -1 --format="%H %h"
```
Warn: "TASK-NNN not found in the last `<window>` commits; recording HEAD SHA."

Add one entry to `<task_mappings>`: `{task_id: "TASK-NNN", sha: <full>, sha_short: <short>}`.

**Priority 2 — Auto-detect from git log window:**

If no explicit argument was given, scan the window for ALL remaining tasks:

```bash
git log -<window> --format="COMMIT %H %h%n%s %N%n---END---"
```

Parse each commit block. For each block:
1. Extract all `TASK-\d+` patterns from the block's text (subject + notes).
2. Filter to only those IDs that appear in `remainingTasks`.
3. For each matched task ID not yet in `<task_mappings>`: add
   `{task_id, sha: <this commit's full SHA>, sha_short: <this commit's short SHA>}`.

Process commits in order (newest first). If the same task ID appears in multiple
commits, use the newest commit's SHA (first occurrence wins).

Non-task commits (no TASK-NNN in subject/notes) are silently skipped.

If `<task_mappings>` is non-empty after scanning: proceed to Step 3.

If `<task_mappings>` is empty (no task refs found in recent commits): fall through to
Priority 3.

**Priority 3 — Interactive selection:**

Use the `remainingTasks` list from Step 1. Cross-reference with `<tasks_file>` to
display each task's title alongside its ID. Present the list:

```
Could not auto-detect any tasks from the last <window> commits. Which tasks did
your recent commits complete? (Enter task IDs separated by spaces, e.g. TASK-001 TASK-003)

  TASK-001 — Author `forge:update-plan` SKILL.md + create capability directory
  TASK-002 — ...

Enter task IDs:
```

Wait for the engineer's response. For each selected task ID, record HEAD SHA:
```bash
git log -1 --format="%H %h"
```
Add one entry per selected task to `<task_mappings>`, all with the same HEAD SHA.

---

## Step 3: Guard — Filter Already-Complete Tasks

For each entry in `<task_mappings>`, check whether its `task_id` already appears in
`completedTasks` (extracted in Step 1). If found, remove it from `<task_mappings>`
and print:
> "Task `<task_id>` is already complete — skipping."

Also verify each remaining entry's `task_id` is in `remainingTasks`. If a task is
absent from both `remainingTasks` and `completedTasks`, warn:
> "Task `<task_id>` was not found in remainingTasks or completedTasks. Please confirm
> the task ID is correct."
Then ask whether to include or skip it before proceeding.

If `<task_mappings>` is empty after filtering (all tasks already complete), stop with:
> "All specified tasks are already marked complete. No changes made."

---

## Step 4: Update plan/tasks.md

Read `<tasks_file>` once with the Read tool.

Detect which format the file uses by scanning for the first task entry:

- **Block format** (current): tasks appear as `### TASK-NNN [type][wave:N]` headings
  followed by a multi-line body with structured fields
- **Legacy format**: tasks appear as single-line checkboxes:
  `- [ ] [type][wave:N] Description (TASK-NNN)`

Apply the appropriate transformation for each entry in `<task_mappings>`:

**Block format transformation:**

Locate the heading line `### <task_id> `. Add a `**Completed:**` field at the end of
the task block, immediately before the next `---` separator or the next `### TASK-`
heading (whichever comes first). If a `**Completed:**` field already exists in the
block (the task was previously marked), replace it.

The inserted line:
```
**Completed:** <sha_short>
```

Example — before:
```markdown
### TASK-001 [auto][wave:1]

Add the favorites table migration.

**Satisfies:** TR-001
**Standards:** `standards/storage/schema-design.md`
**Required tests:** none (migration task)

---
```

After:
```markdown
### TASK-001 [auto][wave:1]

Add the favorites table migration.

**Satisfies:** TR-001
**Standards:** `standards/storage/schema-design.md`
**Required tests:** none (migration task)
**Completed:** a3f9b12

---
```

**Legacy format transformation:**

Find the line containing `(<task_id>)` and apply:
1. Change `- [ ]` to `- [x]`
2. Append ` — <sha_short>` to the end of the line

Result: `- [x] [auto][wave:1] Some task description (TASK-001) — a3f9b12`

---

Use the Edit tool for each transformation. The `old_string` must include enough
surrounding context to be unique.

Note: `forge:verify` reads `**Completed:** <sha_short>` (block format) or the SHA
appended after the task ID (legacy format) to locate the implementing commit. Always
use `<sha_short>` — not the full SHA — so verify can parse it correctly.

If a task cannot be found in either format, stop with:
> "Could not find task `<task_id>` in `<tasks_file>`. Please update plan/tasks.md manually."

---

## Step 5: Update .state.json

Read `<state_file>` once with the Read tool. Use the Edit tool for surgical changes —
do not use Write unless rewriting the entire file with complete current contents.

For each entry in `<task_mappings>`:

**5a — Move task from remainingTasks to completedTasks:**

Remove `"<task_id>"` from `phases.implementation.remainingTasks`.

Add to `phases.implementation.completedTasks`:
```json
{ "taskId": "<task_id>", "sha": "<sha>" }
```
(Full SHA stored so downstream tools can run `git show <sha>` unambiguously.)

**5b — Set jira.syncStatus** (once, after processing all tasks):

If a `jira` key exists at the top level, set `jira.syncStatus` to `"pending"`.
If no `jira` key exists, add it:
```json
"jira": { "syncStatus": "pending" }
```

**Do not modify `phases.implementation.status`** — managed exclusively by
`forge:promote`. Leave it as-is regardless of whether `remainingTasks` is now empty.

**Preserve all other fields** — do not reorder or remove any existing keys.

---

## Step 6: Stage and Commit

Stage the two modified files:
```bash
git add .forge/efforts/<effort_id>/plan/tasks.md .forge/efforts/<effort_id>/.state.json
```

Verify something was staged:
```bash
git diff --cached --name-only
```

If nothing is staged (unexpected), stop with an error.

Build the commit message from all task IDs in `<task_mappings>`:
- Single task: `chore(<effort_id>): mark TASK-001 complete (a3f9b12)`
- Multiple tasks: `chore(<effort_id>): mark TASK-001, TASK-002 complete`

Create the commit. If it fails, surface the error and stop.

---

## Step 7: Report Success

Print a concise summary:

```
N task(s) marked complete. Jira sync queued.

  TASK-001 — SHA a3f9b12 — plan/tasks.md updated, moved to completedTasks
  TASK-002 — SHA c8d1e34 — plan/tasks.md updated, moved to completedTasks
  State: jira.syncStatus = "pending"
  Commit: chore(<effort_id>): mark TASK-001, TASK-002 complete
```

If `remainingTasks` is empty after this update, add:
```
  All tasks complete. Run `forge:promote` to advance to the next phase, then
  `forge:verify` to validate the implementation.
```

---

## Error Handling Summary

| Situation | Action |
|-----------|--------|
| No effort context found | Stop with guidance to check branch or run `forge:effort` |
| No tasks detected and no explicit arg | Display remaining tasks, prompt selection |
| Task already in completedTasks | Skip with message; continue with others |
| Task not in remainingTasks or completedTasks | Warn and ask to include or skip |
| Task not found in plan/tasks.md (either format) | Stop with manual update instruction |
| git commit fails | Surface error, stop |
