# Test Task Generation Guide

Called from Step 5.5E of `forge:plan`. Scans for BDD suite files produced by
`forge:spec-tests` and generates the corresponding test tasks to include in
`plan/tasks.md`.

---

## Section 1 — Scan Locations

Check two locations for suite files:

1. `<effort_dir>/spec/test/` — effort-scoped suites written when no `--capability`
   was provided to `forge:spec-tests`
2. `.forge/deployables/*/capabilities/*/test/` — capability-scoped suites

Collect every file that matches a pattern in Section 2. If no files are found in
either location, skip the rest of this guide. The Output Summary will note:
`Test tasks: none — run forge:spec-tests, then re-run forge:plan to generate test tasks`

---

## Section 2 — File-to-Type Mapping

| Filename pattern | Task `type` |
|---|---|
| `e2e-test-suite.md` | `e2e-test` |
| `*-contract-test-suite.md` | `contract-test` |
| `*-ext-api-test-suite.md` | `external-api-integration-tests` |
| `integration-test-suite.md` | see note below |

**`integration-test-suite.md` subtype resolution:** Scan the file for scenario
blocks. Subtype is identified by the `**Subtype:**` field written by `forge:spec-tests`:

- Any scenario with `**Subtype:** storage` → the file contains storage integration
  scenarios → generate a `storage-integration-tests` task.
- Any scenario with `**Subtype:** messaging` → the file contains messaging integration
  scenarios → generate an `external-api-integration-tests` task.

When both subtypes are present in the same file, generate one task per subtype,
both pointing to the same `target:` file. If no `**Subtype:**` field is found in
any scenario, skip the file and warn: `integration-test-suite.md has no subtype
annotations — re-run forge:spec-tests to regenerate.`

---

## Section 3 — Task Fields

For each suite file found, produce one test task (or two for mixed
`integration-test-suite.md` — see Section 2) with the following fields:

The task heading uses the type value as its bracket annotation (e.g. `[e2e-test]`),
matching what `forge:build-tests` Step 1 scans for. Example heading:
`### TASK-004 [e2e-test][wave:4]`

Body fields:

**`type:`** — the test type from Section 2 (e.g. `e2e-test`, `contract-test`).
This is the field `forge:build-tests` reads to identify the task — it must be present
and match exactly.

**`target:`** — suite file path relative to the repo root (e.g.,
`.forge/efforts/<id>/spec/test/e2e-test-suite.md`).

**`language:`** — detect by reading `<plugin_root>/skills/build-tests/guides/language-detection.md`.

**`depends_on:`** — infer from the suite file's `*Capability/Effort:*` metadata
line. Match the capability or effort path against the implementation tasks already
enumerated in Step 5E:
- If the suite is effort-scoped (`<effort_dir>/spec/test/`), set `depends_on` to the
  IDs of the last-wave implementation tasks for this effort (the tasks that produce
  the component the tests exercise).
- If the suite is capability-scoped, set `depends_on` to the implementation task(s)
  that implement the named capability.
- If no clear match exists, leave `depends_on` empty and add a comment:
  `<!-- depends_on: confirm before implementation -->`.

**`Required tests:`** — extract SC-N titles from the `## Test Coverage Map` table in
the suite file. List each as:
`- SC-N: <title>`

---

## Section 4 — Idempotency Rule

Before generating any test task, check whether `plan/tasks.md` already exists.

If it does, read all existing task entries. For each candidate test task, check
whether any existing task already has an identical `target:` value pointing to the
same suite file. If a match is found, **skip that candidate** — do not duplicate.

Only append tasks for suite files not yet represented in `plan/tasks.md`. Existing
tasks (implementation and test) are never modified or renumbered.

**Task ID assignment:** Assign IDs continuing from the highest existing TASK-NNN in
the file, or starting from TASK-001 if the file does not exist yet.
