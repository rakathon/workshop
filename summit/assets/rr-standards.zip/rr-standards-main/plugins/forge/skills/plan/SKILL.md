---
name: forge:plan
description: >
  Planning skill with two modes. When a Forge effort is active, generates a structured
  plan from discovery artifacts. When no Forge effort is active, degrades gracefully into
  a conversational planning assistant with no Forge-specific steps.
  Trigger on: "generate a plan", "let's plan this", "break this into tasks", "plan this
  out", or "plan the initiative".
argument-hint: "[effort-id]"
arguments: [effort_id]
---

# forge:plan

Reads the effort's discovery artifacts and produces the appropriate planning artifact
based on the effort type:

- **initiative / program** → `plan/epics.md`: named child epics with high-level outputs,
  relevant requirements, and measurable success criteria
- **epic / story / task / spike** → `plan/tasks.md`: wave-ordered, annotated implementation
  tasks each with applicable standards, requirement traceability, and required tests

The conversational equivalent is an engineer saying "let's break this into tasks",
"generate a plan", or "what do we need to build?"

---

## Mode Detection

Before doing anything else, determine whether a Forge effort is active. Run the
standard resolution chain from `plugins/forge/skills/common/effort-resolution.md`,
**but treat this skill as effort-optional**:

- Steps 1–3 are identical to the standard chain (explicit argument → `.forge/EFFORT`
  → in-session context).
- **Step 4 differs**: if no effort is resolved, do **not** prompt the engineer.
  Instead enter **Conversational mode**.

**Conversational mode** — no Forge effort is active or applicable. Proceed as a
helpful planning assistant without any Forge-specific steps: ask the engineer what
they are trying to build, help them think through tasks, dependencies, and sequencing
conversationally, and present the result in whatever format is most useful for the
conversation. Do not reference Forge effort IDs, `.state.json`, templates, or any
other Forge artifact. Do not write any files unless the engineer explicitly asks.
Emit no error or warning about missing Forge setup — just plan.

If an effort was resolved, record `effort_id` and `effort_dir` = `.forge/efforts/<effort_id>/`.

All steps below apply to **Forge mode only**.

---

## Preconditions (Forge mode)

**PC-1: Discovery artifacts exist**

Check that at least one of the following exists:
- `.forge/efforts/<id>/requirements/business.md`
- `.forge/efforts/<id>/requirements/technical.md`

If neither exists, stop with:
> "No discovery artifacts found for effort '<id>'. Run `forge:elaborate` or create
> requirements/ artifacts before generating a plan."

---

## Phase Entry Check [orchestrator-only]

Read `<effort_dir>/.state.json`.

Check `currentPhase` against the phase sequence:
- If `currentPhase` is **"planning" or any later phase**: proceed directly to Step 1 — no
  phase check needed, no output to the engineer. Do not narrate this decision; simply continue.
- If `currentPhase` is **before "planning"** (i.e., "discovery" or earlier): invoke
  `forge:promote <effort_id> --target planning` and wait for it to complete before
  proceeding to Step 1. forge:promote will show the advisory readiness check, offer
  to run forge:validate if no validation report exists, and ask the engineer to confirm.

---

## Step 1: Determine effort type and dispatch [orchestrator-only]

Read `.forge/efforts/<id>/.state.json`. Extract the `type` field.

- If `type` is `"initiative"` or `"program"` → proceed to the **Initiative Path**
  (Steps 2I–4I) and skip the Epic Path entirely.
- If `type` is `"epic"`, `"story"`, `"task"`, or `"spike"` → proceed to the
  **Epic Path** (Steps 2E–9E) and skip the Initiative Path entirely.

---

## INITIATIVE PATH

### Step 2I: Read requirements artifacts [orchestrator-only]

Read `.forge/efforts/<id>/requirements/business.md` and
`.forge/efforts/<id>/requirements/technical.md`.

Extract:
- The strategic goals and user-visible outcomes the initiative must achieve
- The key constraints (technical, compliance, resource, timeline)
- Any explicit sub-problem groupings or phases already described in the docs

If either file is absent, note the gap and continue with what is available.

### Step 3I: Identify and describe child epics [orchestrator-only]

Break the initiative down into a set of named epics. An epic is a coherent slice of
work that:
- Delivers a meaningful, independently releasable unit of value
- Can be staffed and planned on its own (it will have its own discovery/spec/plan cycle)
- Has a clear boundary with other epics (minimal shared state or ordering dependencies)

For each epic, derive:

1. **Name** — a short, descriptive title (3–8 words)
2. **Deployable** — the deployable name (slug, e.g. `rewards-api`) that owns and
   implements this epic. This is the identifier used under `.forge/deployables/` in
   the owning repository, not the repo name itself. An initiative almost always spans
   multiple deployables; assign each epic to exactly one. `forge:project` reads this
   field to materialize the epic as a local effort in the correct deployable.
   If the owning deployable is unknown, write `tbd` and flag it for resolution before
   promoting.
   **Repo** — if the deployable lives in a different repository from the coordination
   repo, also record the repo name as a separate `Repo:` field. If the deployable lives
   in the same repository, do not write a Repo field at all — not even a placeholder.
3. **High-Level Output** — one paragraph describing the concrete deliverable(s) when
   this epic is complete: what exists, what works, what a user or system can do
4. **Relevant Requirements** — list the BR-*/TR-* IDs from the initiative requirements
   that this epic is responsible for satisfying. Quote the requirement text briefly so
   the epic can be understood without re-reading the initiative requirements
5. **Success Criteria** — 3–6 measurable, unambiguous conditions that confirm this
   epic is complete. Each criterion must be testable by an automated check, a
   stakeholder demo, or a defined process (e.g., load test result, audit log review).
   Avoid criteria that require subjective judgement.
6. **Dependencies** — list any other epics that must be fully or partially complete
   before this epic can start (or proceed past a certain point)

Do not invent epics that have no basis in the requirements. Do not omit a logical
work grouping that the requirements imply but do not state explicitly.

Aim for 3–8 epics. If you find fewer than 3, consider whether the effort is actually
initiative-scale. If you find more than 8, look for epics that should be merged.

### Step 4I: Write plan/epics.md [orchestrator-only]

**4I.1 — Locate and read the template**

Check for a project-local template first, then fall back to the plugin-bundled one:

```
.forge/templates/plan/epics.md          ← project override (use if present)
templates/forge/efforts/plan/epics.md   ← plugin default (use otherwise)
```

Read whichever file exists. Treat the template as the authoritative definition of what
the output document must contain. Identify every section heading and bracketed
placeholder — these are what you must populate. Do not assume the template has a fixed
set of sections; if a project override adds or removes sections, honor those changes.

**4I.2 — Populate and write**

Before writing, ensure the directory exists:

```bash
mkdir -p .forge/efforts/<id>/plan
```

Write `.forge/efforts/<id>/plan/epics.md` by filling every section and placeholder
found in the template with content derived from Steps 2I and 3I. Repeat the per-epic
block (from the first `---` separator to the next) once for each epic identified.

Additional rules that apply regardless of template shape:
- Assign EPIC IDs sequentially: EPIC-001, EPIC-002, etc., in recommended delivery
  order (foundational epics first)
- Every epic must have a Deployable field; use `tbd` only if the owning repo cannot
  be determined from the requirements
- Omit any optional section (e.g., "Dependencies") when there is nothing to put in it

---

After writing `plan/epics.md`, skip to **Step 9: Commit**.

---

## EPIC PATH

### Step 2E: Read requirements artifacts [orchestrator-only]

Read `.forge/efforts/<id>/requirements/business.md` and
`.forge/efforts/<id>/requirements/technical.md`.

Build an internal understanding of:
- What the effort is trying to deliver (business goals, user-visible outcomes)
- The technical constraints, non-functional requirements, and acceptance criteria
- Any explicit task hints in the technical requirements (e.g., "must implement a
  repository layer", "requires a migration")
- The full list of requirement IDs (BR-*, TR-*) so tasks can be traced back to them

If either file is absent, note the gap and continue with what is available.

### Step 3E: Read spec artifacts [orchestrator-only]

Read all spec artifacts that exist under `.forge/efforts/<id>/spec/`. For each
artifact type, extract the implementation obligations it creates:

- `spec/api/*.yaml` or `spec/api/*.md` → endpoint handlers to implement,
  request/response contracts to satisfy
- `spec/storage/*.md` → data access objects, migration tasks, schema changes
- `spec/messaging/*.md` → producers, consumers, event schemas to implement
- `spec/test-strategy.md` → test types required, coverage expectations
- `spec/arch-decisions/ADR-*.md` → constraints and decisions that shape task design

For each ADR, note how it constrains implementation choices. Example: "ADR-003: use
repository pattern" implies repository layer tasks must follow the pattern and service
layer tasks depend on repository tasks.

If a spec directory or file does not exist, skip it without error.

### Step 4E: Identify applicable standards and guides [orchestrator-only]

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record: `plugin_root`.

Read `<plugin_root>/standards/AGENTS.md` to understand which standards domains are
available. Then, based on the spec artifacts and requirement content, identify which
standards and language guides apply to this effort. Examples:

- An effort with `spec/api/` artifacts → `standards/api/contracts.md`,
  `standards/api/protocol.md`, `standards/api/security.md`
- An effort with `spec/storage/` artifacts → `standards/storage/` guides
- An effort with `spec/messaging/` artifacts → `standards/messaging/` guides
- Any effort with test-strategy or TDD tasks → `standards/testing/` guides
- Language-specific work → `languages/<lang>/` guides

Record the list of applicable standards (short reference name + file path relative
to plugin root). This list is used in Step 7E to annotate tasks.

### Step 5E: Identify implementation tasks [orchestrator-only]

Enumerate the complete set of tasks required to deliver the effort. A task is a unit
of work that:
- Produces a specific, verifiable artifact or behavior change
- Can be assigned to a single agent or engineer
- Has a clear, testable completion condition

Tasks must be grounded in the requirements and spec artifacts read in Steps 2E–3E.
Do not invent tasks that have no basis in the artifacts. Do not omit tasks implied
by the artifacts but not stated explicitly.

For each task, also identify:
- Which BR-*/TR-* requirement IDs it satisfies (can be multiple)
- Which named test functions must exist and pass before the task is considered
  complete. Each entry must use the exact function name (e.g. `TestFooRepository_Add`)
  and a one-line description of what it verifies. Derive from `spec/test-strategy.md`
  and the spec contracts; if neither exists, identify the minimal test surface from
  the requirement the task satisfies.
  **Exception:** `[auto]` tasks (scaffolding, migrations, config) have no testable
  behavior — always write `none (<reason>)`, e.g. `none (scaffolding task)` or
  `none (migration task)`. Do not invent tests for these tasks.

Common task categories (derive from the spec — this list is not exhaustive):
- Infrastructure / scaffolding (directory structure, config files, dependency additions)
- Data migration or schema change
- Repository / data access layer
- Service / business logic layer
- API handler / controller
- Integration wiring (middleware, DI setup, event subscription)
- Test fixtures and helpers
- Documentation updates

**Cluster assignment:** After enumerating all tasks, group them by the user story or
feature cluster they deliver. For each cluster, identify which infrastructure tasks
(API routes, schema migrations, utility libraries, scaffolding) are first required by
that cluster. Assign those tasks to that cluster — do not extract them into a
standalone foundational wave. An infrastructure task belongs in a shared early wave
only if two or more clusters genuinely require it before either can start.

When a utility is consumed by multiple clusters, assign it to the earliest cluster
that requires it. Treat shared types and foundational utilities the same way — they
belong in the first cluster that depends on them, not in an infrastructure-first wave.

**Cluster delivery sequence:** After grouping tasks into clusters, order the clusters
by the priority in which their user stories should be delivered — derived from the
requirements, product brief, or the stated order of user stories. This ordering is
the **cluster delivery sequence**. Cluster N+1 should not begin before Cluster N is
observable. Use this sequence as the definition of "earlier" and "later" in Step 7E's
tie-breaking rule: a cluster is "later" if it has a higher position in the delivery
sequence.

### Step 5.5E: Discover test suite files and generate test tasks [orchestrator-only]

Follow `plugins/forge/skills/plan/references/test-task-generation.md` to scan for suite
files produced by `forge:spec-tests` and generate the corresponding test tasks. The
guide defines the scan locations, file-to-type mapping, task field population,
`depends_on` inference, and the idempotency rule (skip tasks whose `target:` already
exists in `plan/tasks.md`).

Add all generated test tasks to the internal task list before proceeding to Step 6E —
they participate in dependency analysis and wave assignment like any other task.

### Step 6E: Analyze dependencies between tasks [orchestrator-only]

For each task, identify which other tasks it depends on. A dependency exists when:
- Task B requires an artifact produced by task A (e.g., a repository interface that
  a service layer depends on)
- Task B requires a decision resolved by task A (e.g., a configuration task that
  sets a value consumed by an implementation task)
- Task B cannot be tested without task A's output (e.g., an integration test that
  requires a working repository layer)

Record the complete dependency graph internally before assigning waves. Do not
assign waves until the full dependency graph is known.

### Step 7E: Assign waves [orchestrator-only]

Apply the wave assignment algorithm:

1. Assign `wave:1` to all tasks that have no dependencies on any other pending task
2. For each remaining task, assign `wave:N+1` where N is the highest wave number
   among its direct dependencies
3. If a task depends on tasks from multiple waves, assign it to the wave after the
   highest-wave dependency
4. Repeat until all tasks are assigned a wave
5. Verify: no task in wave N depends on a task in wave N or higher
6. **Tie-breaking:** When a task has no dependencies and would otherwise land in
   wave 1, but it is only required by a cluster later in the delivery sequence
   (higher cluster number), assign it to the same wave as the earliest task in
   that cluster that consumes it. A task should appear in the earliest wave where
   it is **needed**, not the earliest wave where it is **permitted**.

Tasks in the same wave are independent and can be executed in parallel on separate
git worktrees.

### Step 8E: Assign type annotations [orchestrator-only]

Apply the following heuristics in order. The **first matching rule wins**.

> **Reserved types:** `contract-test`, `e2e-test`, `storage-integration-tests`, and
> `external-api-integration-tests` are assigned exclusively by Step 5.5E. The
> heuristics below never produce these types — they apply only to implementation tasks.

**`[manual]`** — assign if the task requires a human action that an agent cannot
perform:
- Provisioning infrastructure resources in a console or ticket system
- Deploying to a restricted environment
- Performing a production data migration that requires DBA approval
- Any action gated by an organizational process outside the codebase

**`[checkpoint]`** — assign if the task involves any of:
- Confirming an interface or contract with another team before implementation begins
- Making an architectural choice that affects the design of downstream tasks
- Introducing an external dependency that must be provisioned or approved (service
  account, third-party API key, infrastructure resource)
- Wiring an integration point where the correct behavior depends on a decision not
  fully resolved in the spec
- Any task where proceeding incorrectly would require significant rework of
  subsequent wave tasks

A checkpoint task's description **must** include a note explaining what needs to
be confirmed. Use the format:
`Task description — confirm <specific thing> before proceeding`
or `Task description — verify <specific thing> after completing`

**`[tdd]`** — assign if the task implements any of:
- A repository or data access layer (queries, persistence, cache operations)
- A service layer or use case (business logic, application services)
- A domain model (entities, aggregates, value objects with behavior)
- An API handler or controller where the spec defines the expected request/response
- Any logic where a spec artifact (API contract, storage schema) defines the exact
  expected behavior — the spec is the test specification and tests must exist and be
  failing before implementation code is written

**`[auto]`** — assign to all other tasks: scaffolding, configuration, test fixture
setup, documentation, migrations, any fully specified task with no ambiguity and
no external dependency.

### Step 9E: Write plan/tasks.md [orchestrator-only]

**9E.1 — Locate and read the template**

Check for a project-local template first, then fall back to the plugin-bundled one:

```
.forge/templates/plan/tasks.md          ← project override (use if present)
templates/forge/efforts/plan/tasks.md   ← plugin default (use otherwise)
```

Read whichever file exists. Identify:
- The document header (everything before the first wave or task block)
- The per-task block structure: which fields appear in each task entry, and what
  format they use (field names, list style, etc.)
- Any wave grouping headers

Treat the template as the authoritative definition of the task format. Do not
assume fixed field names — if a project override renames `**Satisfies:**` to
`**Requirements:**` or adds a new `**Owner:**` field, populate every field the
template defines.

**9E.2 — Populate and write**

Before writing, ensure the directory exists:

```bash
mkdir -p .forge/efforts/<id>/plan
```

Write `.forge/efforts/<id>/plan/tasks.md` by:
1. Writing the document header from the template, substituting the effort title
2. For each wave, writing a wave header following the template's heading style
3. For each task in the wave (sorted by task ID), writing one task block that
   mirrors the template's per-task structure, with all fields populated from the
   analysis in Steps 5E–8E

Additional rules that apply regardless of template shape:
- Assign task IDs sequentially in wave-then-dependency order: TASK-001, TASK-002, etc.
- `forge:plan` writes uncompleted tasks only; completion SHAs are recorded by the
  implementation skill when the task passes its quality loop

---

## Step 9.5E: Write delivery diagram [orchestrator-only]

Add a Mermaid Gantt diagram immediately after the intro paragraph in `plan/tasks.md`
(before the first wave section). The diagram shows when each story/feature cluster
becomes observable — when a user or automated test can exercise it end-to-end.

**Diagram structure:**

```
gantt
    title  <Effort Title> — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section <Cluster Name>
    <Task description>   :task1, 1, 2
    <Task description>   :crit, task2, 2, 3
    <Cluster observable> :milestone, m1, 3, 0

    section <Next Cluster>
    ...
```

Rules:
- Use wave numbers (not dates) on the X-axis
- Each story/feature cluster is a `section`
- Each task appears as a bar spanning its assigned wave
- Mark `[checkpoint]` tasks as `crit`
- Place a `milestone` marker for each cluster at the wave where it first becomes
  observable. Observable means:
  - **UI/frontend** — a user can exercise the feature end-to-end in a browser
  - **API** — the endpoint is callable and returns correct responses against real data
  - **Backend service/library** — the integration tests for that component pass
  - **Data/migration** — the schema change is applied and queries return correct results
- When two clusters overlap in the same wave (one completing, one bootstrapping),
  annotate the wave with a comment in the diagram: `%% Wave N: <ClusterA> completes, <ClusterB> begins`

---

## Step 10E: Write plan/plan.md (coordination efforts only) [orchestrator-only]

This step applies to **epic-path efforts only**. Skip for initiative/program efforts.

Read `.forge/efforts/<id>/.state.json`. Check whether this is a coordination effort:
a coordination effort has `"type": "coordination"` or a non-empty `"deployables"` array.

If this is **not** a coordination effort, skip this step.

If this **is** a coordination effort:

**10E.1 — Locate and read the template**

```
.forge/templates/plan/plan.md          ← project override (use if present)
templates/forge/efforts/plan/plan.md   ← plugin default (use otherwise)
```

Read whichever file exists. Identify the per-deployable section structure: what
headings and sub-sections each deployable entry contains.

**10E.2 — Populate and write**

Write `.forge/efforts/<id>/plan/plan.md` by repeating the per-deployable block once
for each deployable in the effort, populating every section the template defines.

Each section must be self-contained: an engineer reading only their deployable's
section must understand what they need to deliver, how completion will be assessed,
and what they are waiting on from other teams. Omit any optional sub-section (e.g.,
"Cross-Deployable Dependencies") when there is nothing to put in it.

---

## Step 11: Commit [orchestrator-only]

Stage and commit all written artifacts.

**Initiative/program path:**

```bash
git add .forge/efforts/<id>/plan/epics.md
git commit -m "chore(<id>): generate initiative epic breakdown"
```

**Epic path:**

```bash
git add .forge/efforts/<id>/plan/tasks.md
```

If `plan/plan.md` was also written:

```bash
git add .forge/efforts/<id>/plan/plan.md
```

```bash
git commit -m "chore(<id>): generate implementation plan"
```

If both `plan/tasks.md` and `plan/plan.md` were written, commit both in the same
commit. Do not split them.

---

## Phase Completion Check [orchestrator-only]

Read `<effort_dir>/.state.json`. Check `currentPhase`:
- If `currentPhase` is **"implementation" or any later phase**: proceed directly to the
  Output Summary — no output to the engineer.
- If `currentPhase` is **"planning"**: invoke `forge:promote <effort_id> --target implementation`
  and wait for it to complete before printing the Output Summary. This offers the engineer
  a chance to advance planning → implementation immediately since the plan is now complete.

For **initiative/program** efforts: skip the phase completion check — initiatives do not
advance to implementation directly; each child epic has its own lifecycle.

---

## Output Summary

**Initiative/program path:**

```
Epic plan:    .forge/efforts/<id>/plan/epics.md
Epics:        <N> epics across <D> deployables
Next:         Run `forge:project <id>` to materialize each epic as a local effort
              in its assigned deployable repository.
```

**Epic path:**

```
Plan written: .forge/efforts/<id>/plan/tasks.md
Tasks:        <N> tasks across <W> waves (includes <N> test tasks from suite files)
              (or: <N> tasks across <W> waves — no test tasks; run forge:spec-tests, then re-run forge:plan)
Waves:        <list of wave numbers and task counts, e.g., "wave:1 (3), wave:2 (4), wave:3 (2)")
```

If `plan/plan.md` was written:
```
Coord plan:   .forge/efforts/<id>/plan/plan.md
Deployables:  <list of deployable names>
```

```
Next:         Begin implementation with `forge:implement <id> TASK-001`.
```
