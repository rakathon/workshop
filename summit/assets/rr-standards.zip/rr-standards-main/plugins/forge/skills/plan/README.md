# forge:plan

A planning skill with two modes:

**Forge mode** — when a Forge effort is active, generates a structured plan from
the effort's discovery artifacts. Output depends on effort type:
- **initiative / program** → `plan/epics.md`: named child epics with high-level
  outputs, requirement traceability, and measurable success criteria
- **epic / story / task / spike** → `plan/tasks.md`: wave-ordered, annotated
  implementation tasks with standards references, requirement traceability, and
  required tests per task

**Conversational mode** — when no Forge effort is active, acts as a helpful
planning assistant. Thinks through tasks, dependencies, and sequencing
conversationally without writing any Forge artifacts.

---

## What it does

### For initiative / program efforts

1. Reads `requirements/business.md` and `requirements/technical.md`
2. Breaks the initiative into named child epics (3–8 epics)
3. For each epic: describes the high-level output, lists relevant BR-*/TR-*
   requirements, defines measurable success criteria, and notes inter-epic dependencies
4. Writes `plan/epics.md`
5. Commits the artifact

### For epic / story / task / spike efforts

1. Reads all discovery artifacts: `requirements/business.md`,
   `requirements/technical.md`, and all spec files (`spec/api/`, `spec/storage/`,
   `spec/messaging/`, `spec/test-strategy.md`, `spec/arch-decisions/ADR-*.md`)
2. Identifies applicable Forge standards and language guides from the plugin
3. Enumerates implementation tasks grounded in those artifacts
4. For each task: maps to BR-*/TR-* requirements, identifies applicable standards,
   and specifies the named unit/integration tests that must pass for completion
5. Analyzes dependencies between tasks to determine execution order
6. Assigns each task a **type annotation** governing how an agent executes it
7. Assigns each task a **wave annotation** governing when it runs relative to others
8. Writes `plan/tasks.md`
9. For coordination efforts: also writes `plan/plan.md`
10. Commits the plan artifacts

---

## Usage

```
forge:plan <effort-id>
```

**Example:**

```
forge:plan favorites-feature
```

---

## When to use

Run `forge:plan` any time you want to plan — Forge setup is not required.

**With an active Forge effort:** run after discovery artifacts are complete and
approved — typically after `forge:arch-review` passes and the effort has been
promoted to the planning phase. Re-run if requirements or spec artifacts change.

**Without a Forge effort:** just invoke the skill and describe what you want to
build. No setup needed.

---

## Prerequisites

**Conversational mode:** none.

**Forge mode:**
- Forge initialized in the repository (`forge:init` was run)
- At least one discovery artifact exists:
  - `.forge/efforts/<id>/requirements/business.md`, or
  - `.forge/efforts/<id>/requirements/technical.md`

---

## Output format

### plan/epics.md (initiative / program efforts)

```markdown
# Initiative Plan: <Effort Title>

This plan breaks the initiative into child epics. Each epic will have its own
discovery, specification, and implementation cycle.

---

## EPIC-001: <Epic Name>

### High-Level Output

<One paragraph describing the concrete deliverable when this epic is complete.>

### Relevant Requirements

- **BR-001** — <brief quote of requirement text>
- **TR-003** — <brief quote of requirement text>

### Success Criteria

- [ ] <Measurable condition 1>
- [ ] <Measurable condition 2>

### Dependencies

- Depends on: EPIC-NNN (<reason>)
```

### plan/tasks.md (epic / story / task / spike efforts)

```markdown
# Implementation Plan: <Effort Title>

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Foundation

### TASK-001 [auto][wave:1]

Scaffold the favorites module directory structure.

**Satisfies:** n/a
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-002 [tdd][wave:1]

Implement FavoritesRepository with Add, Remove, and List operations.

**Satisfies:** BR-002, TR-004, TR-005
**Standards:** `standards/storage/schema-design.md`, `languages/go/repository-pattern.md`
**Required tests:**
- Unit: `TestFavoritesRepository_Add` — verifies row insertion and ID return
- Unit: `TestFavoritesRepository_List` — verifies pagination and user scoping
- Integration: `TestFavoritesRepository_Integration` — real DB, verifies constraint enforcement

---

## Wave 2 — Core Implementation

### TASK-003 [tdd][wave:2]

Implement FavoritesService with business rules for duplicate prevention.

**Satisfies:** BR-003, TR-006
**Standards:** `standards/api/contracts.md`, `languages/go/service-layer.md`
**Required tests:**
- Unit: `TestFavoritesService_AddDuplicate` — verifies duplicate rejection
- Unit: `TestFavoritesService_Add` — verifies happy path
```

### Type annotations

| Annotation | Meaning | Applied when |
|------------|---------|--------------|
| `[auto]` | Agent proceeds autonomously | Scaffolding, configuration, migrations, fully-specified tasks |
| `[tdd]` | RED → GREEN → REFACTOR required | Repository/data access, service/business logic, domain models, API handlers with spec contracts |
| `[checkpoint]` | Agent pauses for human decision | External contract confirmation, architectural choices, integration wiring with unresolved decisions |
| `[manual]` | Human action required | Infrastructure provisioning, restricted-environment deployments, DBA-required changes |

### Wave annotations

Tasks in `wave:1` have no dependencies and can start immediately. Tasks in `wave:N`
depend on tasks in earlier waves and cannot start until all wave `N-1` tasks are
complete. Tasks within the same wave are independent and can run in parallel.

---

## plan/plan.md (coordination efforts only)

When an epic-path effort spans multiple deployable repositories, `forge:plan` also
writes `plan/plan.md` — a deployable-scoped view of the plan. This file is used by
`forge:project` to materialize local sub-efforts in each deployable repository.

Each deployable section lists:
- Acceptance criteria for that deployable
- Cross-deployable dependencies (what other deployables must deliver and when)

---

## Relationship to other skills

| Skill | Relationship |
|-------|-------------|
| `forge:effort` | Creates the effort directory structure that `forge:plan` reads |
| `forge:arch-review` | Reviews the design before planning; run before `forge:plan` |
| `forge:implement` | Executes individual tasks from the generated `plan/tasks.md` |
| `forge:project` | Uses `plan/plan.md` (for coordination efforts) to create sub-efforts |
| `forge:update-plan` | Updates task status as work progresses |
