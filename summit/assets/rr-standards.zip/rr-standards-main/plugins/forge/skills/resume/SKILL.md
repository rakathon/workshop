---
name: forge:resume
description: Resume a paused effort, restoring context from the last pause state. Use at the start of a new session when a pause record exists, or when asked to "pick up where we left off". The SessionStart hook automatically surfaces pause state — forge:resume provides the full context restoration.
---

# forge:resume

Restores pause state from `.state.json` and re-injects the context the resuming agent
needs to continue without reconstruction. Typically triggered automatically by the
SessionStart hook when it detects a populated `pauseState` field — this skill provides
the explicit invocation path for the same behavior.

---

## Preconditions

**PC-1: An active effort with a populated `pauseState` field**

The target effort must have a `.state.json` with a non-null `pauseState` field.

**PC-2: Effort directory is intact**

The effort directory and its scaffolded artifacts must be present.

---

## Step 1: Identify the Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

If no effort is found, stop with:
> "No active effort found. Run `forge:effort` to create one or `forge:status` to see
> current state."

---

## Step 2: Read `.state.json`

Read `.forge/efforts/<id>/.state.json` in full. Capture: `currentPhase`,
`openDecisions`, `pauseState`, and the `phases` object.

---

## Step 3: Check for `pauseState`

If `pauseState` is `null` or absent, stop with:

> "No pause state found for `<id>`. Nothing to resume."
> "Run `forge:status` to see the current effort state."

Otherwise proceed to Step 4.

---

## Step 4: Re-inject Context

Present the pause state clearly:

```
Resuming: <effort-id>

  Last session summary:
    <pauseState.contextSummary>

  Active phase:         <pauseState.activePhase>
  Active task:          <pauseState.activeTask or "none">
  Last completed step:  <pauseState.lastCompletedStep or "not recorded">
  Paused at:            <pauseState.pausedAt>

  Suggested next action:
    <pauseState.nextAction>
```

---

## Step 5: Surface Open Decisions

Read `openDecisions` from `.state.json`. If any are present:

```
  Open decisions:
    OD-001: <description> [blocks <blockedTask or "no specific task">]
    ...
```

If any open decisions block tasks that are part of the suggested next action, call
this out explicitly:

> "Note: OD-001 blocks TASK-009. The suggested next action does not depend on this
> decision, but it will need to be resolved before TASK-009 can proceed."

If open decisions were not resolved between sessions, ask the engineer whether to
proceed with the suggested next action or resolve the blocking decisions first.

---

## Step 6: Check Artifact Currency

Read the current artifact inventory from `.state.json` (`phases.<phase>.artifacts`).

For each artifact listed as `"present"` or `"draft"` in the state, verify the
corresponding file exists on disk. If any expected file is absent, surface the gap:

> "Warning: `.forge/efforts/<id>/spec/api.md` is recorded as present in `.state.json`
> but does not exist on disk. This may indicate the file was not saved before the
> session ended."

If the `pauseState.activeTask` references a task in `plan/tasks.md`, read
`plan/tasks.md` and confirm the task still exists. If the referenced task no longer
exists (e.g., the plan was revised between sessions), surface the discrepancy:

> "The paused task `<activeTask>` no longer appears in `plan/tasks.md`. The plan may
> have been revised between sessions. What should the next step be?"

Do not assume the pause state is consistent with the file system — surface any gaps
and let the engineer decide.

---

## Step 7: Clear `pauseState`

After presenting the context, clear the `pauseState` field:

```json
{
  ...existing fields...,
  "pauseState": null
}
```

This signals that the effort is actively in progress, not paused. Write the updated
`.state.json` immediately. Maintain alphabetical key ordering at every nesting level.

---

## Step 7b: Write Active Effort Pointer

Write the effort ID to `.forge/EFFORT`:

```bash
echo "<id>" > .forge/EFFORT
```

This file is gitignored and serves as the session-local pointer to the active effort.
Writing it here ensures that subsequent skill invocations in this session can identify
the active effort without prompting.

Print: "Active effort: <id>"

---

## Step 7c: Branch Guard

Before committing, run the branch guard defined in:
  `plugins/forge/skills/common/branch-guard.md`
Suggested branch: `effort/<id>`

---

## Step 8: Commit

Stage and commit only `.state.json`:

```bash
git add .forge/efforts/<id>/.state.json
git commit -m "chore(<id>): resume session"
```

---

## Step 9: Ready to Proceed

Confirm context is restored:

> "Context restored. Ready to continue `<effort-id>`."

Then ask:

> "Shall I proceed with the suggested next action, or do you want to take a different
> direction?"

Do not begin the resumed task automatically. Wait for the engineer to confirm or
redirect before taking any implementation actions.

---

## Deviation Rules

**Autonomous:**
- Clearing `pauseState` after re-injection — this is always done once context is presented.
- Surfacing the next action from the preserved state.

**Escalate to engineer:**
- If the `nextAction` references a task that no longer exists in `plan/tasks.md` —
  surface the discrepancy and ask for clarification before proceeding.
- If open decisions that were unresolved at pause time are still unresolved — list
  them and ask whether to proceed with the blocked tasks anyway or resolve the
  decisions first.
- If artifact files recorded as present are absent on disk — surface the gap and
  ask whether to recreate the file before resuming.

---

## [orchestrator-only]

- Printing the resume summary to the engineer.
- Deciding whether to wait for confirmation before proceeding with the resumed task.
- This skill always runs in the main session, never as a sub-agent.
