# forge:resume

Restores pause state at the start of a new session so work continues exactly where
the previous session left off.

## Purpose

When a session ends mid-task, `forge:pause` records where you are. `forge:resume`
reads that record and re-injects the full context — what was being worked on, what
decisions were made, what needs to happen next — so the resuming session does not
have to reconstruct state from scratch.

The SessionStart hook automatically surfaces a notice when pause state exists.
`forge:resume` provides the full context restoration and clears the pause record
once the engineer has acknowledged.

## When to Use

- Start of a new session when picking up mid-task work
- Anytime you want to see the full handoff context from the previous session
- When the SessionStart hook reports that a pause record exists
- When asked to "pick up where we left off"

## Usage

```
forge:resume                     # resume the current active effort
forge:resume <effort-id>         # resume a specific effort by ID
```

## What It Does

1. Identifies the active effort (or the effort specified by ID)
2. Reads `pauseState` from `.state.json`
3. Presents the full context: summary, active task, last completed step, and
   suggested next action
4. Surfaces any open decisions that were unresolved at pause time
5. Checks that artifact files recorded in state still exist on disk
6. Clears `pauseState` and commits the updated `.state.json`
7. Asks whether to proceed with the suggested next action or take a different
   direction — does not start work automatically

## Output

A context summary showing everything the resuming session needs:

```
Resuming: forge-workflow

  Last session summary:
    Implementing token validation middleware. Decided to use a stateless JWT
    approach (no revocation list) after reviewing the auth team's constraints.
    The middleware skeleton exists but the claim extraction logic is not written.

  Active phase:         implementation
  Active task:          TASK-003
  Last completed step:  Created middleware file skeleton with empty handler
  Paused at:            2026-03-27T14:30:00Z

  Suggested next action:
    Implement extractMemberIdClaim() in src/middleware/auth.ts, then write
    the unit tests in test/middleware/auth.test.ts (TASK-003, Wave 2).

  Open decisions:
    OD-001: JWT claim name for member ID [blocks TASK-009]

Context restored. Ready to continue forge-workflow.
Shall I proceed with the suggested next action, or do you want to take a
different direction?
```

## Files Modified

| File | Change |
|------|--------|
| `.forge/efforts/<id>/.state.json` | `pauseState` cleared and committed |
