---
name: forge:verify
description: Verify that the completed implementation delivers the effort's stated requirements. Single-pass semantic check: reads discovery artifacts and implementation code, confirms each BR and TR has implementation evidence, identifies stubs and missing integration wiring, produces verification/report.md with PASS/FAIL per requirement and code locations for gaps. Runs as an isolated worker sub-agent.
---

# forge:verify

Performs a single-pass semantic verification of a completed effort's implementation.
Reads all discovery artifacts and the source files changed by each task, confirms that
every BR and TR has real implementation evidence, checks for stubs and missing wiring,
and writes `verification/report.md` with a binary PASS or FAIL result.

This is a Worker skill. It runs as an isolated sub-agent and does not share context
with the main engineer session.

---

## Classification

**Worker** — isolated sub-agent. The orchestrator (main session) spawns this worker
after confirming all tasks are complete. The worker reads files, verifies, and writes
the report. It does not read session state, conversation history, or per-task loop
state.

---

## Preconditions

Before the orchestrator spawns this worker, the main session must confirm:

**PC-1: All tasks complete**

All tasks in `plan/tasks.md` must be marked `[x]` with a commit SHA recorded inline:

```
- [x] [auto][wave:1] Task description (TASK-001) (a3f9b12)
```

If any task is incomplete, stop with:
> "Not all tasks are marked complete. Verify must not run until all tasks have commit
> SHAs. Incomplete tasks: <list them>."

**PC-2: Discovery artifacts exist**

At minimum one of the following must exist:
- `.forge/efforts/<id>/requirements/business.md`
- `.forge/efforts/<id>/requirements/technical.md`

If neither exists, stop with:
> "No discovery artifacts found for effort '<id>'. Cannot verify without requirements."

**PC-3: Not in escalation state**

If `.state.json` has `pause.reason = "quality_loop_limit_reached"`, that task work
must be resolved before verification. Stop with:
> "Effort '<id>' has an unresolved quality loop escalation on <taskId>. Resolve the
> escalation before running verify."

---

## [Orchestrator-Only] Resolve Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

Record `effort_id` and `effort_dir` = `.forge/efforts/<effort_id>/`. Pass `effort_dir`
to the worker sub-agent.

---

## [Orchestrator-Only] Triggering forge:verify

The main session triggers `forge:verify` when:
- The engineer explicitly requests verification ("let's verify", "forge:verify", "check the implementation")
- The engineer signals readiness to open a PR and all tasks are marked complete
- `forge:promote` is invoked and `verification/report.md` is absent

**Orchestrator steps:**

1. Read `.forge/efforts/<id>/.state.json` to confirm the effort ID and that implementation phase tasks are all done.
2. Confirm PC-1, PC-2, and PC-3 are satisfied.
3. **Phase Entry Check:** read `<effort_dir>/.state.json`. Check `currentPhase`:
   - If `currentPhase` is **"verification" or any later phase**: proceed directly to
     step 4 — no output to the engineer.
   - If `currentPhase` is **before "verification"**: invoke
     `forge:promote <effort_id> --target verification` and wait for it to complete
     before proceeding. forge:promote will show advisory checks and ask the engineer
     to confirm advancement through all phases in the gap.
4. Spawn the worker sub-agent with the effort directory path as input.
5. Wait for `verification/report.md` to be written.
6. Read `verification/report.md` and present the findings to the engineer.
   - Do not re-interpret or second-guess the worker's findings.
   - Present the summary paragraph and gap list as written.
   - If PASS: invoke `forge:promote <effort_id> --target review` to offer advancement
     to the review phase. Then confirm the implementation is ready for PR.
   - If FAIL: present the gap list; inform the engineer that implementation must resume
     before the effort can advance to review.

---

## Worker Steps

### Step 1 — Load discovery artifacts

Read the following files from the effort directory. Extract structured lists of
identifiers and descriptions from each.

```
requirements/business.md       → Extract all BR-* entries (ID + short title)
requirements/technical.md      → Extract all TR-* entries (ID + short title)
spec/arch-decisions/ADR-*.md   → Extract all ADR decisions (ID + decision statement)
spec/README.md                 → Extract design constraints (if present)
spec/api/                      → Extract API contract shapes (if present)
spec/storage/                  → Extract data model shapes (if present)
spec/messaging/                → Extract event schemas (if present)
```

If a file or directory does not exist, skip it. A missing `spec/api/` is not an error;
missing `requirements/business.md` when no TRs exist is not an error. Record which
artifacts were found.

### Step 2 — Load the implementation plan

Read `plan/tasks.md`.

For each completed task (checkbox marked `[x]`), extract:
- Task ID (e.g., `TASK-001`)
- Task description (the text of the task line, excluding annotations and ID)
- Commit SHA (the 7-character SHA at the end of the task line)
- Requirements addressed: identify from the task description and acceptance criteria
  which BRs and TRs this task was intended to deliver

A task addresses a requirement if:
- The task description explicitly names the requirement (e.g., "Implement BR-3: user profile update")
- The task description describes behavior that is the only implementation path for that requirement
- The task's acceptance criteria reference the requirement

Record for each task: which BRs and which TRs it is responsible for.

### Step 3 — Map requirements to tasks

Build a coverage map:

```
For each BR in requirements/business.md:
  → Which task(s) are responsible for delivering it?
  → If no task found: flag as PLANNING GAP

For each TR in requirements/technical.md:
  → Which task(s) are responsible?
  → If no task found: flag as PLANNING GAP

For each ADR:
  → Which task(s) are responsible for compliance?
  → If no tasks implement the prescribed approach: flag as PLANNING GAP
```

A planning gap is a FAIL. Record the gap immediately with the note:
"No task found for this requirement."

### Step 4 — Load implementation code

For each completed task's commit SHA, read the source files changed in that commit.

To identify changed files for a commit SHA, use:
```bash
git show --name-only --format="" <sha>
```

Read each changed file. Focus on the files directly relevant to the task's stated
purpose — if a commit includes incidental changes (whitespace, formatting), weight
the substantive files more heavily.

If a commit SHA cannot be resolved (e.g., the repository history is not available),
note this in the report and flag the associated requirements as unverifiable.

### Step 5 — Verify each requirement

For each BR in the coverage map, apply all three checks:

**Check 1 — Implementation evidence**

Does the responsible task's commit contain code that delivers the requirement's
stated behavior? Look for:
- An endpoint handler, service method, or function that implements the stated feature
- A storage access pattern that persists or retrieves the relevant data
- A test that confirms the behavior exists (for [tdd] tasks)

If no evidence is found: FAIL with "No implementation found."

**Check 2 — Stub detection**

Is the implementation real or a placeholder? A stub is any of:
- A function or method body consisting solely of: `return null`, `return undefined`,
  `return {}`, `throw new Error("not implemented")`, `TODO`, `FIXME`, `panic("TODO")`,
  or a language-equivalent placeholder
- An interface implementation where every method is a stub
- A configuration entry that references a handler or callback that is itself a stub

If a stub is found in a load-bearing path: FAIL with "Stub detected."

**Check 3 — Integration wiring**

Are all components connected end-to-end? Missing wiring is any of:
- A component registered in configuration but never called in a request path
- An event emitter with no subscriber, or a subscriber that is never registered
- A middleware or interceptor defined but not added to the chain
- A dependency injected into a constructor but never used in any method body

If missing wiring is found: FAIL with "Missing integration wiring."

For each TR, apply the same three checks, plus:

**Check 4 — Spec contract compliance**

Does the implementation match the spec-level contract this TR is supposed to fulfill?
- If TR specifies a REST endpoint shape (from `spec/api/`): does the handler match
  the method, path, request body, and response shape?
- If TR specifies a data model (from `spec/storage/`): does the repository/schema
  match the specified fields and types?
- If TR specifies an event schema (from `spec/messaging/`): does the producer/consumer
  match the specified event structure?

If the implementation diverges from the spec contract: FAIL with "Implementation
does not match spec contract."

For each ADR, apply:

**Check 5 — ADR compliance**

Does the implementation follow the prescribed approach? Does the implementation
contradict the decision?

For prescriptive ADRs (e.g., "use optimistic locking", "use repository pattern"):
confirm the prescribed approach is used in the relevant code.

For prohibitive ADRs (e.g., "do not use global state"): confirm the prohibited
pattern is absent.

If compliance cannot be confirmed or a contradiction is found: FAIL.

**Recording results**

For each requirement, record:
- ID (BR-N, TR-N) and short title
- PASS or FAIL
- If PASS: the file path and line/function where the implementation was found
- If FAIL: a gap reference number (Gap 1, Gap 2, ...) for use in the Gaps section

### Step 6 — Write verification/report.md

Create the directory `verification/` if it does not exist. Write `verification/report.md`.

The overall result is:
- **PASS** if every BR, TR, and ADR received PASS in Step 5
- **FAIL** if any BR, TR, or ADR received FAIL in Step 5

Use the following format exactly:

```markdown
# Verification Report

**Result:** PASS | FAIL
**Effort:** <effort-id>
**Date:** <ISO-8601 timestamp, e.g., 2026-03-27T14:32:00Z>

## Summary

[One paragraph. If PASS: confirm the implementation delivers the effort's stated goals,
note the total number of requirements verified, and confirm no stubs or missing wiring
were found. If FAIL: summarize the critical gaps — how many requirements failed and
the nature of the failures. Do not editorialize; state findings plainly.]

## Requirement Coverage

### Business Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| BR-1 | <title> | PASS | Implemented in `src/api/favorites.ts:45` |
| BR-2 | <title> | FAIL | No implementation found — see Gap 1 |

### Technical Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| TR-1 | <title> | PASS | Implemented in `src/storage/repo.go:88` |
| TR-2 | <title> | FAIL | Stub detected — see Gap 2 |

## ADR Compliance

| ADR | Decision (short) | Status | Notes |
|-----|------------------|--------|-------|
| ADR-001 | Use optimistic locking | PASS | Used in `storage/repo.go:88` |
| ADR-002 | Use repository pattern | FAIL | Service layer calls DB directly — see Gap 3 |

## Gaps

[Omit this section entirely if Result is PASS.]

### Gap 1 — <short title>

**Requirement:** BR-2
**Location:** (missing) or `src/auth/session.ts:42` — `validateSession()`
**Description:** [Plain language description of what is missing or incomplete.
State the specific gap — do not give implementation advice.]

### Gap 2 — <short title>

**Requirement:** TR-2
**Location:** `src/handlers/profile.ts:15` — `updateProfile()`
**Description:** Function body returns `{}` unconditionally. No update logic is present.

[... additional gaps ...]
```

**Format rules:**
- `Result:` on the fourth line (after title and two metadata lines) — scannable
- Every FAIL row in a coverage table must reference a Gap entry by number
- Every Gap entry must include a specific code location — file path and function name
  or line number; use `(missing)` only when the code does not exist at all
- The Summary paragraph is required for both PASS and FAIL
- Omit the Gaps section entirely when the result is PASS
- Omit the ADR Compliance table if no ADRs were found in the effort

After writing, commit the report:

```bash
git add verification/report.md
git commit -m "chore(<effort-id>): write verification report"
```

---

## PASS / FAIL Semantics

**PASS:** The implementation delivers the effort's stated goals. Every BR and TR has
real implementation evidence. No stubs in load-bearing paths. No missing integration
wiring. All ADRs complied with.

**FAIL:** One or more requirements are not delivered. The verification report identifies
exactly what is missing and where. Implementation must resume before `forge:promote`
can advance to the verification phase.

There is no intermediate result. A concern that does not constitute a gap — a style
preference, a potential future risk, a non-binding observation — is out of scope and
must not appear as a FAIL. If worth noting, include it in the Summary paragraph as
context only, clearly distinguishing it from findings.

---

## Constraints

- `forge:verify` must not run the test suite or linter. Those are the quality loop's
  responsibility, executed per task at implementation time.
- `forge:verify` must not modify implementation code. It reads and reports only.
- The worker does not read session state (`.state.json`), conversation history, or
  per-task loop state. It derives all context from the effort's artifact files.
