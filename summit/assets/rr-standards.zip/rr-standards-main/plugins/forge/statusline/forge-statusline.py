#!/usr/bin/env python3
"""Forge-aware Claude Code statusline script.

Wide layout (≥130 cols), 2 lines:
  Line 1: 🌿 branch [effort-id · phase] | $cost Xm Xs | Model | 📁 dirname
  Line 2: color-coded context progress bar

Narrow layout (<130 cols), 2 lines:
  Line 1: 🌿 branch [effort · phase]
  Line 2: ████████░░ 80% | $cost Xm Xs | Model

Install via /forge:statusline skill. Do not run directly.
"""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path


# ── Constants ─────────────────────────────────────────────────────────────────

CACHE_TTL             = 5    # seconds
NARROW_THRESHOLD      = 130  # columns below which compact 2-line layout is used
BRANCH_MIN_CHARS      = 8    # minimum branch chars to show before giving up truncation


def _terminal_cols() -> int:
    # stdin/stdout are piped by Claude Code so shutil.get_terminal_size() always
    # returns its fallback. Open /dev/tty directly to get the real terminal width.
    try:
        with open("/dev/tty") as tty:
            return os.get_terminal_size(tty.fileno()).columns
    except Exception:
        pass
    try:
        return int(os.environ["COLUMNS"])
    except Exception:
        return 130


def _find_forge_root(cwd: str) -> "Path | None":
    """Walk up from cwd to find the nearest directory containing .forge/."""
    path = Path(cwd).resolve()
    while True:
        if (path / ".forge").is_dir():
            return path
        parent = path.parent
        if parent == path:
            return None
        path = parent


def _resolve_context(cwd: str, worktree: "dict | None") -> "tuple[str | None, dict]":
    """Return (branch, effort) in a single pass, using at most one git subprocess call.

    The branch is read from the worktree dict when in a worktree session, otherwise
    from git.  The effort is resolved from .forge/EFFORT first, then from the branch
    name — so when the branch already tells us the effort ID we reuse it without a
    second git call.
    """
    # ── Branch ────────────────────────────────────────────────────────────────
    if worktree:
        branch: "str | None" = worktree.get("branch") or worktree.get("name") or None
    else:
        try:
            branch = subprocess.check_output(
                ["git", "branch", "--show-current"],
                cwd=cwd or ".",
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip() or None
        except Exception:
            branch = None

    # ── Effort ────────────────────────────────────────────────────────────────
    forge_root = _find_forge_root(cwd) if cwd else None
    if not forge_root:
        return branch, {}

    effort_id: "str | None" = None

    effort_file = forge_root / ".forge" / "EFFORT"
    if effort_file.exists():
        effort_id = effort_file.read_text().strip() or None

    if not effort_id and branch and branch.startswith("effort/"):
        effort_id = branch.split("/", 1)[1]

    if not effort_id:
        return branch, {}

    state_path = forge_root / ".forge" / "efforts" / effort_id / ".state.json"
    if not state_path.exists():
        return branch, {}

    try:
        state = json.loads(state_path.read_text())
        effort = {"id": effort_id, "phase": state.get("currentPhase", "?")}
    except Exception:
        effort = {}

    return branch, effort


def _get_context_cached(cwd: str, session_id: str, worktree: "dict | None") -> "tuple[str | None, dict]":
    """Return (branch, effort), with effort cached per session for CACHE_TTL seconds."""
    safe_id    = re.sub(r"[^a-zA-Z0-9_-]", "_", session_id)
    cache_path = Path(f"/tmp/forge-statusline-{safe_id}")
    if cache_path.exists():
        age = time.time() - cache_path.stat().st_mtime
        if age < CACHE_TTL:
            try:
                cached = json.loads(cache_path.read_text())
                if "effort" in cached:  # validates new cache format
                    return cached.get("branch"), cached.get("effort", {})
            except Exception:
                pass
    branch, effort = _resolve_context(cwd, worktree)
    try:
        cache_path.write_text(json.dumps({"branch": branch, "effort": effort}))
    except Exception:
        pass
    return branch, effort


# ── Display helpers ───────────────────────────────────────────────────────────

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")

def _visible_len(s: str) -> int:
    """Return the number of terminal columns a string occupies, ignoring ANSI escapes.

    Emoji and other wide characters occupy 2 columns each.
    """
    plain = _ANSI_RE.sub("", s)
    width = 0
    for ch in plain:
        cp = ord(ch)
        # Broad check for East Asian wide / emoji ranges
        if (
            0x1100 <= cp <= 0x115F   # Hangul Jamo
            or 0x2E80 <= cp <= 0x303E  # CJK Radicals / Kangxi
            or 0x3040 <= cp <= 0x33FF
            or 0x3400 <= cp <= 0x4DBF
            or 0x4E00 <= cp <= 0xA4CF
            or 0xA960 <= cp <= 0xA97F
            or 0xAC00 <= cp <= 0xD7FF
            or 0xF900 <= cp <= 0xFAFF
            or 0xFE10 <= cp <= 0xFE19
            or 0xFE30 <= cp <= 0xFE6F
            or 0xFF01 <= cp <= 0xFF60
            or 0xFFE0 <= cp <= 0xFFE6
            or 0x1B000 <= cp <= 0x1B0FF
            or 0x1F004 <= cp <= 0x1F0CF
            or 0x1F300 <= cp <= 0x1FAFF  # Misc symbols, emoji
            or 0x20000 <= cp <= 0x2FFFD
            or 0x30000 <= cp <= 0x3FFFD
        ):
            width += 2
        else:
            width += 1
    return width


def _is_1m_context(model_id: str, model_name: str) -> bool:
    """Return True if the model uses a 1M token context window."""
    return "1m" in (model_id + " " + model_name).lower()


GREEN  = "\033[32m"
YELLOW = "\033[33m"
ORANGE = "\033[38;5;208m"
RED    = "\033[31m"
RESET  = "\033[0m"


def _ctx_color(pct: int, is_1m: bool) -> str:
    """Return the ANSI color code for the given context usage percentage."""
    if is_1m:
        return RED if pct >= 22 else ORANGE if pct >= 20 else YELLOW if pct >= 18 else GREEN
    return RED if pct >= 60 else ORANGE if pct >= 50 else YELLOW if pct >= 40 else GREEN


def _bar(pct: int, is_1m: bool = False) -> str:
    """Return a colored progress bar string for the given percentage.

    Thresholds differ by context window size:
      200k: yellow ≥40% (80k), orange ≥50% (100k), red ≥60% (120k)
      1M:   yellow ≥18% (180k), orange ≥20% (200k), red ≥22% (220k)
    """
    color  = _ctx_color(pct, is_1m)
    filled = min(pct * 10 // 100, 10)
    bar    = "█" * filled + "░" * (10 - filled)
    return f"{color}{bar}{RESET}"


# ── Display builders ─────────────────────────────────────────────────────────

def build_line2(pct: int, is_1m: bool = False) -> str:
    """Wide layout line 2: colored progress bar with percentage."""
    pct    = int(pct or 0)
    color  = _ctx_color(pct, is_1m)
    return f"{_bar(pct, is_1m)} {color}{pct}%{RESET}"


def _truncate_branch(branch: str, effort_suffix: str, cols: int) -> str:
    """Return branch name, truncated with … if needed to fit within cols alongside effort_suffix."""
    prefix = "🌿 "
    full = f"{prefix}{branch}{effort_suffix}"
    if _visible_len(full) <= cols:
        return branch
    budget = cols - _visible_len(prefix) - _visible_len(effort_suffix)
    if budget < BRANCH_MIN_CHARS:
        return branch  # too narrow to truncate meaningfully — let it trail
    truncated = ""
    for ch in branch:
        if _visible_len(truncated + ch + "…") <= budget:
            truncated += ch
        else:
            break
    return truncated + "…"


def build_line1(
    model: str,
    dirname: str,
    cost_usd: float,
    dur_ms: int,
    worktree: "dict | None",
    cwd: str,
    session_id: str,
    cols: int = 200,
) -> str:
    """Wide layout line 1: git/effort context first, cost, model, dir."""
    mins     = int(dur_ms) // 60000
    secs     = (int(dur_ms) % 60000) // 1000
    cost_str = f"${float(cost_usd):.2f} {mins}m{secs:02d}s"

    branch, effort = _get_context_cached(cwd, session_id, worktree)
    effort_str     = f" [{effort['id']} · {effort['phase']}]" if effort else ""

    parts = []
    if branch:
        fixed_suffix   = f"{effort_str} | {cost_str} | {model} | 📁 {dirname}"
        display_branch = _truncate_branch(branch, effort_str, cols - _visible_len(fixed_suffix) - _visible_len("🌿 "))
        parts.append(f"🌿 {display_branch}{effort_str}")
    elif effort:
        parts.append(f"[{effort['id']} · {effort['phase']}]")
    parts.append(cost_str)
    parts.append(model)
    parts.append(f"📁 {dirname}")

    return " | ".join(parts)


def build_narrow(
    model: str,
    pct: int,
    cost_usd: float,
    dur_ms: int,
    worktree: "dict | None",
    cwd: str,
    session_id: str,
    cols: int = 80,
    is_1m: bool = False,
) -> str:
    """Narrow layout, 2 lines.

    Line 1: 🌿 branch [effort · phase]   (branch truncated to fit cols;
            falls back to just [effort · phase] on detached HEAD)
    Line 2: bar % | $cost Xm Xs | model  (trails off if terminal is very narrow)
    """
    branch, effort = _get_context_cached(cwd, session_id, worktree)
    effort_suffix  = f" [{effort['id']} · {effort['phase']}]" if effort else ""

    if branch:
        display_branch = _truncate_branch(branch, effort_suffix, cols)
        line1 = f"🌿 {display_branch}{effort_suffix}"
    elif effort:
        line1 = f"[{effort['id']} · {effort['phase']}]"
    else:
        line1 = None

    mins     = int(dur_ms) // 60000
    secs     = (int(dur_ms) % 60000) // 1000
    cost_str = f"${float(cost_usd):.2f} {mins}m{secs:02d}s"
    pct_int  = int(pct or 0)
    color    = _ctx_color(pct_int, is_1m)
    line2    = " | ".join([f"{_bar(pct_int, is_1m)} {color}{pct_int}%{RESET}", cost_str, model])

    return "\n".join(filter(None, [line1, line2]))


# ── Entry point ──────────────────────────────────────────────────────────────

def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        print("░░░░░░░░░░ 0% | Claude")
        return

    model_data = data.get("model") or {}
    model      = model_data.get("display_name", "Claude")
    model_id   = model_data.get("id", "")
    workspace  = data.get("workspace") or {}
    cwd        = workspace.get("current_dir") or data.get("cwd", "")
    dirname    = Path(cwd).name if cwd else "—"
    session_id = data.get("session_id", "default")

    cost_data  = data.get("cost") or {}
    cost_usd   = cost_data.get("total_cost_usd") or 0
    dur_ms     = cost_data.get("total_duration_ms") or 0

    ctx        = data.get("context_window") or {}
    pct        = int(ctx.get("used_percentage") or 0)

    worktree   = data.get("worktree")
    is_1m      = _is_1m_context(model_id, model)

    cols = _terminal_cols()
    if cols < NARROW_THRESHOLD:
        print(build_narrow(model, pct, cost_usd, dur_ms, worktree, cwd, session_id, cols=cols, is_1m=is_1m))
    else:
        print(build_line1(model, dirname, cost_usd, dur_ms, worktree, cwd, session_id, cols=cols))
        print(build_line2(pct, is_1m))



if __name__ == "__main__":
    main()
