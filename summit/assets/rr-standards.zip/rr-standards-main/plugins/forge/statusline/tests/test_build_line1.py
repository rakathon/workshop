import importlib.util
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

_module_path = Path(__file__).parent.parent / "forge-statusline.py"
_spec = importlib.util.spec_from_file_location("forge_statusline", _module_path)
forge_statusline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(forge_statusline)
sys.modules["forge_statusline"] = forge_statusline

build_line1  = forge_statusline.build_line1
_visible_len = forge_statusline._visible_len
_ANSI_RE     = forge_statusline._ANSI_RE


def _stripped(s: str) -> str:
    return _ANSI_RE.sub("", s)


def test_build_line1_basic():
    with patch.object(forge_statusline, "_get_context_cached", return_value=(None, {})):
        result = build_line1("Opus", "myproject", 0.01, 90000, None, "/some/path", "s1")
    assert "Opus" in result
    assert "📁 myproject" in result


def test_build_line1_with_branch():
    with patch.object(forge_statusline, "_get_context_cached", return_value=("feat/foo", {})):
        result = build_line1("Opus", "myproject", 0.01, 90000, None, "/some/path", "s1")
    assert "feat/foo" in result
    assert "🌿" in result


def test_build_line1_with_effort():
    effort = {"id": "my-effort", "phase": "implementation"}
    with patch.object(forge_statusline, "_get_context_cached", return_value=("effort/my-effort", effort)):
        result = build_line1("Opus", "myproject", 0.01, 90000, None, "/some/path", "s1")
    assert "my-effort · implementation" in result
    assert "🌿" in result


def test_build_line1_effort_shown_on_detached_head():
    """Active effort must appear even with no branch (detached HEAD)."""
    effort = {"id": "EF-99", "phase": "discovery"}
    with patch.object(forge_statusline, "_get_context_cached", return_value=(None, effort)):
        result = build_line1("Opus", "myproject", 0.0, 0, None, "/some/path", "s1")
    assert "EF-99" in result
    assert "discovery" in result


def test_build_line1_worktree_mode():
    worktree = {"branch": "worktree-my-feature", "name": "my-feature"}
    with patch.object(forge_statusline, "_get_context_cached", return_value=("worktree-my-feature", {})):
        result = build_line1("Opus", "myproject", 0.0, 0, worktree, "/some/path", "s1")
    assert "worktree-my-feature" in result
    assert "🌿" in result


def test_build_line1_no_git_repo():
    with patch.object(forge_statusline, "_get_context_cached", return_value=(None, {})):
        result = build_line1("Opus", "myproject", 0.0, 0, None, "/some/path", "s1")
    assert "🌿" not in result
    assert "Opus" in result


def test_build_line1_cost_format():
    with patch.object(forge_statusline, "_get_context_cached", return_value=(None, {})):
        result = build_line1("Opus", "myproject", 1.234, 125000, None, "/p", "s1")
    assert "$1.23" in result
    assert "2m05s" in result


def test_build_line1_branch_truncated_to_fit():
    # At 130 cols the budget for the branch name is ~91 chars; use 100 to force truncation
    long_branch = "fix/" + "x" * 96
    with patch.object(forge_statusline, "_get_context_cached", return_value=(long_branch, {})):
        result = build_line1("Opus", "myproject", 0.12, 60000, None, "/p", "s1", cols=130)
    visible = _stripped(result)
    assert _visible_len(visible) <= 130
    assert "…" in visible
