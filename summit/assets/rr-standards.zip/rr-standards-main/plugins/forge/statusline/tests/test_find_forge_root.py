import importlib.util
import tempfile
import os
from pathlib import Path
import pytest
import sys

_module_path = Path(__file__).parent.parent / "forge-statusline.py"
_spec = importlib.util.spec_from_file_location("forge_statusline", _module_path)
_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_module)
_find_forge_root = _module._find_forge_root


def test_find_forge_root_finds_cwd_itself(tmp_path):
    forge_dir = tmp_path / ".forge"
    forge_dir.mkdir()
    result = _find_forge_root(str(tmp_path))
    assert result == tmp_path


def test_find_forge_root_finds_ancestor(tmp_path):
    forge_dir = tmp_path / ".forge"
    forge_dir.mkdir()
    child = tmp_path / "src" / "components"
    child.mkdir(parents=True)
    result = _find_forge_root(str(child))
    assert result == tmp_path


def test_find_forge_root_returns_none_at_root(tmp_path):
    # A directory with no .forge anywhere up the tree
    no_forge = tmp_path / "no_forge_here"
    no_forge.mkdir()
    result = _find_forge_root(str(no_forge))
    assert result is None
