import importlib.util
import json
import os
import sys
import time
from pathlib import Path
from unittest.mock import patch

import pytest

_module_path = Path(__file__).parent.parent / "forge-statusline.py"
_spec = importlib.util.spec_from_file_location("forge_statusline", _module_path)
forge_statusline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_spec.loader.exec_module(forge_statusline) or forge_statusline)
_spec.loader.exec_module(forge_statusline)
sys.modules["forge_statusline"] = forge_statusline

_resolve_context    = forge_statusline._resolve_context
_get_context_cached = forge_statusline._get_context_cached


# ── helpers ──────────────────────────────────────────────────────────────────

def _make_forge_repo(tmp_path, effort_id="my-effort", phase="implementation"):
    forge = tmp_path / ".forge" / "efforts" / effort_id
    forge.mkdir(parents=True)
    state = {"id": effort_id, "currentPhase": phase}
    (forge / ".state.json").write_text(json.dumps(state))
    return tmp_path


# ── _resolve_context tests ───────────────────────────────────────────────────

def test_resolve_reads_effort_file(tmp_path):
    _make_forge_repo(tmp_path, effort_id="my-effort")
    (tmp_path / ".forge" / "EFFORT").write_text("my-effort\n")
    with patch("subprocess.check_output", return_value="main\n"):
        _, effort = _resolve_context(str(tmp_path), None)
    assert effort["id"] == "my-effort"
    assert effort["phase"] == "implementation"


def test_resolve_falls_back_to_branch(tmp_path):
    _make_forge_repo(tmp_path, effort_id="my-effort")
    with patch("subprocess.check_output", return_value="effort/my-effort\n"):
        _, effort = _resolve_context(str(tmp_path), None)
    assert effort["id"] == "my-effort"


def test_resolve_branch_from_git(tmp_path):
    _make_forge_repo(tmp_path)
    (tmp_path / ".forge" / "EFFORT").write_text("my-effort")
    with patch("subprocess.check_output", return_value="feat/something\n"):
        branch, _ = _resolve_context(str(tmp_path), None)
    assert branch == "feat/something"


def test_resolve_branch_from_worktree():
    worktree = {"branch": "worktree-branch", "name": "wt-name"}
    branch, _ = _resolve_context("/nonexistent", worktree)
    assert branch == "worktree-branch"


def test_resolve_no_title_field(tmp_path):
    _make_forge_repo(tmp_path, effort_id="my-effort")
    (tmp_path / ".forge" / "EFFORT").write_text("my-effort")
    _, effort = _resolve_context(str(tmp_path), None)
    assert "title" not in effort
    assert "id" in effort
    assert "phase" in effort


def test_resolve_returns_empty_when_no_forge(tmp_path):
    no_forge = tmp_path / "no_forge"
    no_forge.mkdir()
    with patch("subprocess.check_output", return_value="main\n"):
        branch, effort = _resolve_context(str(no_forge), None)
    assert effort == {}


def test_resolve_returns_empty_on_corrupt_state(tmp_path):
    forge = tmp_path / ".forge" / "efforts" / "bad-effort"
    forge.mkdir(parents=True)
    (forge / ".state.json").write_text("not valid json{{{")
    (tmp_path / ".forge" / "EFFORT").write_text("bad-effort")
    _, effort = _resolve_context(str(tmp_path), None)
    assert effort == {}


def test_resolve_single_git_call_on_effort_branch(tmp_path):
    """When branch is effort/<id>, only one git subprocess call should occur."""
    _make_forge_repo(tmp_path, effort_id="my-effort")
    with patch("subprocess.check_output", return_value="effort/my-effort\n") as mock_git:
        _resolve_context(str(tmp_path), None)
    assert mock_git.call_count == 1


# ── _get_context_cached tests ────────────────────────────────────────────────

def test_cache_hit(tmp_path):
    _make_forge_repo(tmp_path, effort_id="my-effort")
    (tmp_path / ".forge" / "EFFORT").write_text("my-effort")
    session_id = "test-session-cache-hit"
    cache_path = Path(f"/tmp/forge-statusline-{session_id}")
    cache_path.write_text(json.dumps({"branch": "cached-branch", "effort": {"id": "cached", "phase": "review"}}))

    with patch.object(forge_statusline, "_resolve_context") as mock_resolve:
        branch, effort = _get_context_cached(str(tmp_path), session_id, None)

    mock_resolve.assert_not_called()
    assert branch == "cached-branch"
    assert effort["id"] == "cached"
    cache_path.unlink(missing_ok=True)


def test_cache_miss_after_ttl(tmp_path):
    _make_forge_repo(tmp_path, effort_id="my-effort")
    (tmp_path / ".forge" / "EFFORT").write_text("my-effort")
    session_id = "test-session-cache-miss"
    cache_path = Path(f"/tmp/forge-statusline-{session_id}")
    cache_path.write_text(json.dumps({"branch": "stale", "effort": {"id": "stale"}}))
    old_time = time.time() - 10
    os.utime(cache_path, (old_time, old_time))

    with patch("subprocess.check_output", return_value="main\n"):
        _, effort = _get_context_cached(str(tmp_path), session_id, None)
    assert effort.get("id") == "my-effort"
    cache_path.unlink(missing_ok=True)


def test_cache_uses_session_id(tmp_path):
    _make_forge_repo(tmp_path, effort_id="my-effort")
    (tmp_path / ".forge" / "EFFORT").write_text("my-effort")
    for sid in ("sess-a", "sess-b"):
        Path(f"/tmp/forge-statusline-{sid}").unlink(missing_ok=True)

    with patch("subprocess.check_output", return_value="main\n"):
        _get_context_cached(str(tmp_path), "sess-a", None)
        _get_context_cached(str(tmp_path), "sess-b", None)

    assert Path("/tmp/forge-statusline-sess-a").exists()
    assert Path("/tmp/forge-statusline-sess-b").exists()
    for sid in ("sess-a", "sess-b"):
        Path(f"/tmp/forge-statusline-{sid}").unlink(missing_ok=True)


def test_cache_session_id_sanitised(tmp_path):
    """Malicious session_id must not escape /tmp."""
    session_id = "../etc/passwd"
    cache_path = Path("/tmp/forge-statusline-__etc_passwd")
    cache_path.unlink(missing_ok=True)
    with patch.object(forge_statusline, "_resolve_context", return_value=(None, {})):
        _get_context_cached(str(tmp_path), session_id, None)
    assert not Path("/tmp/forge-statusline-../etc/passwd").exists()
    cache_path.unlink(missing_ok=True)
