import importlib.util
import re
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

_module_path = Path(__file__).parent.parent / "forge-statusline.py"
_spec = importlib.util.spec_from_file_location("forge_statusline", _module_path)
forge_statusline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(forge_statusline)
sys.modules["forge_statusline"] = forge_statusline

build_narrow  = forge_statusline.build_narrow
_visible_len  = forge_statusline._visible_len
_ANSI_RE      = forge_statusline._ANSI_RE


def _stripped_lines(out: str) -> list[str]:
    return [_ANSI_RE.sub("", l) for l in out.splitlines()]


def test_narrow_two_lines_with_branch():
    with patch.object(forge_statusline, "_get_context_cached", return_value=("main", {})):
        out = build_narrow("Opus", 50, 0.05, 90000, None, "/p", "s", cols=80)
    lines = _stripped_lines(out)
    assert len(lines) == 2
    assert "main" in lines[0]
    assert "50%" in lines[1]
    assert "Opus" in lines[1]


def test_narrow_cost_on_line2():
    with patch.object(forge_statusline, "_get_context_cached", return_value=("main", {})):
        out = build_narrow("Opus", 50, 1.23, 125000, None, "/p", "s", cols=80)
    lines = _stripped_lines(out)
    assert "$1.23" in lines[1]
    assert "2m05s" in lines[1]


def test_narrow_branch_truncated_to_fit():
    long_branch = "fix/this-is-a-very-long-branch-name-that-should-be-truncated"
    with patch.object(forge_statusline, "_get_context_cached", return_value=(long_branch, {})):
        out = build_narrow("Opus", 50, 0.0, 0, None, "/p", "s", cols=60)
    lines = _stripped_lines(out)
    assert _visible_len(lines[0]) <= 60
    assert lines[0].startswith("🌿 ")
    assert "…" in lines[0]


def test_narrow_branch_fits_no_truncation():
    with patch.object(forge_statusline, "_get_context_cached", return_value=("main", {})):
        out = build_narrow("Opus", 50, 0.0, 0, None, "/p", "s", cols=80)
    lines = _stripped_lines(out)
    assert "main" in lines[0]
    assert "…" not in lines[0]


def test_narrow_effort_suffix_preserved_on_truncation():
    long_branch = "fix/this-is-a-very-long-branch-name-that-overflows"
    effort = {"id": "EF-42", "phase": "implementation"}
    with patch.object(forge_statusline, "_get_context_cached", return_value=(long_branch, effort)):
        out = build_narrow("Opus", 50, 0.0, 0, None, "/p", "s", cols=60)
    lines = _stripped_lines(out)
    assert "[EF-42 · implementation]" in lines[0]
    assert _visible_len(lines[0]) <= 60


def test_narrow_no_branch_no_effort_one_line():
    with patch.object(forge_statusline, "_get_context_cached", return_value=(None, {})):
        out = build_narrow("Opus", 50, 0.0, 0, None, "/p", "s", cols=80)
    lines = _stripped_lines(out)
    assert len(lines) == 1
    assert "50%" in lines[0]
    assert "Opus" in lines[0]


def test_narrow_effort_shown_on_detached_head():
    """Active effort must be visible even with no branch."""
    effort = {"id": "EF-99", "phase": "discovery"}
    with patch.object(forge_statusline, "_get_context_cached", return_value=(None, effort)):
        out = build_narrow("Opus", 50, 0.0, 0, None, "/p", "s", cols=80)
    lines = _stripped_lines(out)
    assert len(lines) == 2
    assert "EF-99" in lines[0]
    assert "discovery" in lines[0]
