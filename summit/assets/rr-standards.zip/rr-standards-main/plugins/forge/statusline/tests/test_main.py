import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))
import forge_statusline


VALID_INPUT = {
    "model": {"id": "claude-opus-4-7", "display_name": "Opus"},
    "workspace": {"current_dir": "/home/user/myproject"},
    "session_id": "test-session-123",
    "cost": {"total_cost_usd": 0.05, "total_duration_ms": 120000},
    "context_window": {"used_percentage": 45},
}


def _run_main(stdin_data: str, columns: int = 200) -> tuple[str, int]:
    """Run forge-statusline.py as a subprocess with a fixed terminal width."""
    script = Path(__file__).parent.parent / "forge-statusline.py"
    env = {**subprocess.os.environ, "COLUMNS": str(columns)}
    result = subprocess.run(
        [sys.executable, str(script)],
        input=stdin_data,
        capture_output=True,
        text=True,
        env=env,
    )
    return result.stdout, result.returncode


def test_main_wide_output():
    """Wide layout (≥130 cols): line1 has model+dir, line2 has bar."""
    stdout, rc = _run_main(json.dumps(VALID_INPUT), columns=200)
    lines = stdout.strip().splitlines()
    assert rc == 0
    assert len(lines) == 2
    assert "Opus" in lines[0]
    assert "myproject" in lines[0]
    assert "%" in lines[1]


def test_main_narrow_output():
    """Narrow layout (<130 cols): line2 has bar + cost + model; line1 present when branch resolves."""
    import os, uuid
    data = dict(VALID_INPUT)
    data["workspace"] = {"current_dir": os.path.dirname(__file__)}
    data["session_id"] = str(uuid.uuid4())  # unique session avoids cache pollution
    stdout, rc = _run_main(json.dumps(data), columns=80)
    lines = stdout.strip().splitlines()
    assert rc == 0
    assert len(lines) == 2
    bar_line = lines[1]
    assert "Opus" in bar_line
    assert "%" in bar_line
    assert "$" in bar_line


def test_main_graceful_on_empty_json():
    stdout, rc = _run_main("{}", columns=200)
    lines = stdout.strip().splitlines()
    assert rc == 0
    assert len(lines) == 2


def test_main_graceful_on_invalid_json():
    stdout, rc = _run_main("not valid json }{{{")
    assert rc == 0
    assert len(stdout.strip()) > 0


def test_main_worktree_mode():
    import uuid
    data = dict(VALID_INPUT)
    data["worktree"] = {"branch": "worktree-my-feature", "name": "my-feature"}
    data["session_id"] = str(uuid.uuid4())
    stdout, rc = _run_main(json.dumps(data), columns=200)
    assert rc == 0
    assert "worktree-my-feature" in stdout


def test_main_context_bar_color_red():
    data = dict(VALID_INPUT)
    data["context_window"] = {"used_percentage": 95}
    stdout, rc = _run_main(json.dumps(data), columns=200)
    assert rc == 0
    assert "\033[31m" in stdout
