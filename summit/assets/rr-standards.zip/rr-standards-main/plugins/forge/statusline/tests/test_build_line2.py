import importlib.util
import sys
from pathlib import Path
import pytest

_module_path = Path(__file__).parent.parent / "forge-statusline.py"
_spec = importlib.util.spec_from_file_location("forge_statusline", _module_path)
_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_module)
build_line2 = _module.build_line2


def test_build_line2_green_below_70():
    result = build_line2(50)
    assert "\033[32m" in result
    assert "50%" in result


def test_build_line2_yellow_70_to_89():
    result = build_line2(75)
    assert "\033[33m" in result
    assert "75%" in result


def test_build_line2_red_at_90():
    result = build_line2(90)
    assert "\033[31m" in result
    assert "90%" in result


def test_build_line2_handles_zero():
    result = build_line2(0)
    assert "0%" in result
    assert "░░░░░░░░░░" in result


def test_build_line2_handles_none():
    result = build_line2(None)
    assert "0%" in result


def test_build_line2_full_bar():
    result = build_line2(100)
    assert "██████████" in result
    assert "100%" in result
