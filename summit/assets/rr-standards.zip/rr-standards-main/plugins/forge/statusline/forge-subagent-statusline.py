#!/usr/bin/env python3
"""Forge subagent panel statusline script.

Reads the subagentStatusLine JSON from stdin and emits one JSON line per
visible agent row, formatted as: [type] name · status · Xtk

Install via /forge:statusline skill. Do not run directly.
"""
import json
import sys


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        return

    tasks = data.get("tasks") or []
    for task in tasks:
        task_id = task.get("id", "")
        name    = task.get("name", "?")
        kind    = task.get("type", "?")
        status  = task.get("status", "?")
        raw     = task.get("tokenCount") or 0
        if raw >= 1_000_000:
            tok_str = f"{raw / 1_000_000:.1f}M"
        elif raw >= 1_000:
            tok_str = f"{raw / 1_000:.1f}k"
        else:
            tok_str = str(raw)
        content = f"[{kind}] {name} · {status} · {tok_str}tk"
        print(json.dumps({"id": task_id, "content": content}))


if __name__ == "__main__":
    main()
