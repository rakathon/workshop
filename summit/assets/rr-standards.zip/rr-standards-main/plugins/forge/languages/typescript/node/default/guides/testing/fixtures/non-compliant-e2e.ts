// WRONG: imports supertest — supertest mounts the app in-process.
// E2E tests must call the real deployed service via axios, not a local server handle.
import request from 'supertest'
import app from '../app'

// WRONG: file is named .test.ts (not .e2e.test.ts) — it will be picked up by the
// standard jest.config.ts and run as part of the unit test suite.
describe('PointsWorkflow', () => {
  it('earns points', async () => {
    // WRONG: supertest mounts the app in-process — this is not E2E testing.
    // E2E tests must issue real HTTP calls to a deployed service.
    const res = await request(app)
      .post('/points/v1/members/member-1/transactions')
      .send({ amount_cents: 1000, merchant_id: 'merchant-1' })

    expect(res.status).toBe(201)
    // WRONG: no afterAll cleanup — test data created in the real DB is never removed.
  })

  it('checks balance', async () => {
    // WRONG: hardcoded localhost URL instead of loading from loadConfig() via e2e.properties.
    // WRONG: hardcoded auth token — secrets must come from environment variables via config.authToken.
    const res = await fetch('http://localhost:3000/points/v1/members/member-1/balance', {
      headers: { Authorization: 'Bearer hardcoded-token-abc123' },
    })
    const body = await res.json()
    // WRONG: no ENVIRONMENT_TO_TEST production guard — this test would run in production and mutate live data.
    expect(body.data.balance).toBeGreaterThan(0)
  })
})
