# ui-design-system — TypeScript/React UIKit Guides

## Directory purpose

Implementation guides for building UI with the `@rakuten-rewards/uikit` and
`@rakuten-rewards/appshell` design system. Load the relevant guide for the specific
task — they are focused and do not need to be loaded together.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `tokens.md` | Concrete token values and prop usage for color, spacing, typography, shadow, and border-radius | Writing or reviewing any component prop that accepts a color, spacing, or typography value; checking whether a token name is correct |
| `components.md` | Runnable examples for every UIKit component tier: Topic composites, layout primitives, Button, Accordion, AppShell; includes anti-patterns table | Choosing which UIKit component to use for a section; building any page section from scratch; reviewing component imports |
| `responsive-layout.md` | Mobile-first breakpoint patterns, standard section padding, grid column progressions, and complete section examples | Any component with layout-affecting props; building multi-section pages; reviewing responsive prop correctness |
| `page-patterns.md` | Homepage and category landing page section order; complete generic category landing page template | Starting a new page; prototyping a full-page layout; establishing section sequence for a feature |
