# TypeScript Guide — External Store Subscriptions with useSyncExternalStore

Guide: 1.0.0 | Implements: standards/frontend/external-store-subscriptions.md@1.0.0

## Overview

This guide shows how to implement the External Store Subscriptions standard in a TypeScript and React project using the `useSyncExternalStore` hook. It covers wrapping browser event sources and third-party stores in a custom hook with a stable subscribe/snapshot pair, handling server-side rendering with a server snapshot, and avoiding the common `useEffect`-based anti-pattern. A codebase following this guide will subscribe to external state without memory leaks, stale reads, or infinite re-render loops.

## Related standard

[External Store Subscriptions](../../../../../../standards/frontend/external-store-subscriptions.md)

## Prerequisites

- React 18+
- TypeScript 5+
- No additional packages required — [`useSyncExternalStore`](https://react.dev/reference/react/useSyncExternalStore) is built into React 18

## Implementation

### Wrapping a browser event source (R-1, R-2, R-3, R-4, R-5, R-8)

Define `subscribe` and `getSnapshot` outside the hook so their references are stable across renders:

```typescript
// hooks/useWindowWidth.ts
import { useSyncExternalStore } from 'react'

// Defined outside the hook — stable references, no re-subscription on every render (R-5)
const subscribe = (callback: () => void) => {
  window.addEventListener('resize', callback)
  return () => window.removeEventListener('resize', callback) // cleanup returned (R-2)
}

// Primitive return value — same reference when unchanged, no infinite loop (R-3)
// Pure — no side effects, does not mutate anything (R-4)
const getSnapshot = () => window.innerWidth

// Deterministic fallback — no browser APIs on the server (R-6)
const getServerSnapshot = () => 1024

// Encapsulated in a named hook — not inlined at call sites (R-8)
export function useWindowWidth() {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
}
```

### Wrapping multiple events from the same source (R-2)

When a store emits via multiple events, all listeners must be registered in one `subscribe` call and all removed in the returned cleanup:

```typescript
// hooks/useOnlineStatus.ts
import { useSyncExternalStore } from 'react'

const subscribe = (callback: () => void) => {
  window.addEventListener('online', callback)
  window.addEventListener('offline', callback)
  return () => {
    window.removeEventListener('online', callback)
    window.removeEventListener('offline', callback)
  }
}

const getSnapshot = () => navigator.onLine
const getServerSnapshot = () => true // assume online when server-rendering

export function useOnlineStatus() {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
}
```

### Subscribing to a custom observable store (R-1, R-3, R-5, R-8)

This pattern applies to any store that exposes a `subscribe(listener)` method and a way to read current state — common in Redux, Zustand, and hand-rolled stores. The key difference from browser event sources is that the snapshot reads directly from the store's state, which may be an object:

```typescript
// stores/userPreferencesStore.ts — a simple hand-rolled observable store
type UserPreferences = { theme: 'light' | 'dark'; language: string }

let state: UserPreferences = { theme: 'light', language: 'en' }
const listeners = new Set<() => void>()

export const userPreferencesStore = {
  subscribe: (listener: () => void) => {
    listeners.add(listener)
    return () => listeners.delete(listener) // cleanup (R-2)
  },
  getSnapshot: () => state, // must return same reference if state unchanged (R-3)
  setState: (next: Partial<UserPreferences>) => {
    state = { ...state, ...next } // new reference only when state actually changes
    listeners.forEach(l => l())
  },
}

// hooks/useUserPreferences.ts
import { useSyncExternalStore } from 'react'
import { userPreferencesStore } from '../stores/userPreferencesStore'

// Stable references — store methods are defined once on the store object (R-5)
export function useUserPreferences() {
  return useSyncExternalStore(
    userPreferencesStore.subscribe,
    userPreferencesStore.getSnapshot,
  )
}
```

### Wrapping an existing third-party store (R-1, R-3)

For stores you don't own (e.g., a library's store), adapt their subscribe/getState interface directly. Confirm the store returns a stable state reference when unchanged — check the library's documentation:

```typescript
// hooks/useCartItems.ts
import { useSyncExternalStore } from 'react'
import { cartStore } from '../stores/cartStore'

const subscribe = (callback: () => void) => cartStore.subscribe(callback)

// cartStore.getState() must return a stable reference when cart is unchanged —
// confirm this with the store's documentation or implementation (R-3)
const getSnapshot = () => cartStore.getState()

export function useCartItems() {
  return useSyncExternalStore(subscribe, getSnapshot)
}
```

## Verification

1. TypeScript compilation passes with no errors — run `tsc --noEmit`
2. In React DevTools, the component re-renders when the external source changes (e.g., resize the window for `useWindowWidth`) — confirm the displayed value updates without a page reload
3. In React DevTools Profiler, confirm no unexpected re-renders when the store value has not changed — validates snapshot reference stability (R-3)
4. On a server-rendered page, open the Network tab and confirm no hydration mismatch warnings in the console — validates `getServerSnapshot` is correct (R-6)
5. Remove the cleanup return from `subscribe`, navigate away from the component, then trigger the event — confirm no stale listener warnings appear in the console, then restore the cleanup
