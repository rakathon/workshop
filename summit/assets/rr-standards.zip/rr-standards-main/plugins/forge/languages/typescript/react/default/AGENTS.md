# TypeScript/React Guides — Current

## Directory purpose

Implementation guides for React/TypeScript frontend applications. This is the default
version directory for all new React work using TypeScript. Covers React-specific patterns
and libraries including data fetching, state management, and component design.

## File index

| Entry | Purpose | When to reference |
|-------|---------|-------------------|
| `guides/` | TypeScript/React implementation guides organised by domain area | When reviewing or generating TypeScript frontend code |
| `guides/data-fetching/` | React Query key factory patterns for client-side data fetching | Any TypeScript/React code that fetches data using TanStack Query (React Query) |
| `guides/ui-design-system/` | UIKit design system implementation — tokens, component selection, responsive layout, and page patterns | Any TypeScript/React code using `@rakuten-rewards/uikit` or `@rakuten-rewards/appshell`; UI prototyping; production feature implementation from a design spec |
| `guides/ui-design-system/tokens.md` | Concrete token values and usage patterns (color, spacing, typography, shadow, border-radius) | Writing or reviewing any component prop that accepts a color, spacing, or typography value |
| `guides/ui-design-system/components.md` | Runnable examples for every UIKit component tier: Topic composites, layout primitives, Button, Accordion, AppShell | Building any page section; choosing which UIKit component to use |
| `guides/ui-design-system/responsive-layout.md` | Mobile-first breakpoint patterns, section padding, grid progressions, full section examples | Any component with layout-affecting props; building multi-section pages |
| `guides/ui-design-system/page-patterns.md` | Complete homepage and category landing page patterns, dining page example | Starting a new page or feature; workshop and prototyping sessions |

## Navigation

- [Standards library](../../../../standards/) — language-agnostic standards these guides implement

## Linter

ESLint. Projects use either flat config (`eslint.config.js`) or legacy format
(`.eslintrc.js` / `.eslintrc.json`) — check the project root to determine which applies.

Run the linter: `yarn lint` (maps to `eslint`)
Auto-fix: `yarn lint:fix` (maps to `eslint --fix`)

All generated TypeScript code must pass ESLint with zero errors before being emitted.
