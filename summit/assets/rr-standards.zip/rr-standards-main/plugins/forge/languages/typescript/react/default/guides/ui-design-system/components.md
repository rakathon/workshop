---
guide_version: 1.0.0
implements: standards/frontend/component-selection.md@1.0.0
---

# Component Selection & Usage — TypeScript/React Implementation

Guide: 1.0.0 | Implements: standards/frontend/component-selection.md@1.0.0

## Overview

Runnable examples for every component tier: Topic composites first, then layout
primitives, then specialised patterns. All imports are from `@rakuten-rewards/uikit`
unless noted.

## Related standard

[`standards/frontend/component-selection.md`](../../../../../../standards/frontend/component-selection.md)

## Prerequisites

- `@rakuten-rewards/uikit` ^6.x installed
- `@rakuten-rewards/appshell` installed
- TypeScript strict mode enabled

## Implementation

### Topic components (use first — component-selection.md R-1)

#### TextBlockTopic — text + image sections

The most-used composite. Handles full-width sections with optional background, text,
image, and CTA. Always prefer this over a hand-built `Grid` + `Box` layout.

```tsx
import { TextBlockTopic } from '@rakuten-rewards/uikit';

// Text left, image right
<TextBlockTopic
  topicData={{
    backgroundProps: { bg: 'fill.default', py: { base: 'xlarge', medium: 'xxlarge' } },
    isInverse: false,
  }}
  textBlock={{
    variant: 'left',
    heading: 'Headline Here',
    body: 'Body text.',
    ctaText: 'Shop Now',
    ctaUrl: '/shop',
    isExternal: false,
    imageUrl: '/assets/photos/lifestyle/image.jpg',
    imageAlt: 'Descriptive alt text',
    isInverse: false,
  }}
/>

// Centered hero — no image
<TextBlockTopic
  topicData={{
    backgroundProps: { bg: 'palette.purple_25', py: { base: 'xlarge', medium: 'xxlarge' } },
    isInverse: false,
  }}
  textBlock={{ variant: 'emphasized', heading: 'Hero Headline', body: 'Supporting copy.', ctaText: 'Get Started', ctaUrl: '/' }}
/>

// Dark background — set isInverse on both topicData and textBlock
<TextBlockTopic
  topicData={{ backgroundImgUrl: '/assets/bg.jpg', isInverse: true }}
  textBlock={{ variant: 'right', heading: 'Title', body: 'Body.', isInverse: true,
    imageUrl: '/assets/img.jpg', imageAlt: 'Alt text' }}
/>
```

Variants: `left` (text left, image right) · `right` (image left, text right) · `emphasized` (centered, no image)

#### StoreCarouselTopic — horizontal store carousels

```tsx
import { StoreCarouselTopic } from '@rakuten-rewards/uikit';

<StoreCarouselTopic
  topicData={{
    title: 'Featured Stores',
    topicCTA: 'See All',
    topicCTAUri: '/stores',
    backgroundProps: { bg: 'fill.default', py: { base: 'xlarge', medium: 'xxlarge' } },
    isInverse: false,
  }}
  stores={[
    {
      id: '1',
      logoImage: '/stores/nike/logo.png',
      logoImageAlt: 'Nike',
      logoBg: '#ffffff',
      href: '/store/nike',
      isExternal: false,
      rewardText: '5% Cash Back',
      previousRewardText: 'was 3%',
      tag: '12 deals',
      shouldLazyLoadImage: true,
    },
  ]}
/>
```

Multi-row config: `topicData.rows={{ base: { max: 2 }, medium: { max: 3 } }}`

#### PageHeroCarouselTopic — full-width hero

```tsx
import { PageHeroCarouselTopic } from '@rakuten-rewards/uikit';

<PageHeroCarouselTopic
  topicData={{ title: 'Featured', topicCTA: 'See All', topicCTAUri: '/' }}
  pageHeroes={[
    {
      id: '1',
      imageUrl: { base: '/hero-sm.jpg', medium: '/hero-lg.jpg' },
      eyebrow: 'Limited Time',
      bannerText: '30% off your first month',
      ctaText: 'Shop Now',
      ctaUrl: '/store',
      rewardText: '10% Cash Back',
      imageAltText: 'Hero image',
      showGradientOverlay: false,
      overrideTextColor: 'text.inverse',
      placement: 'standard',
    },
  ]}
/>
```

#### PromoTopic — promotional grids

```tsx
import { PromoTopic } from '@rakuten-rewards/uikit';

<PromoTopic
  topicData={{
    title: 'Top Picks',
    topicCTA: 'See All',
    topicCTAUri: '/stores',
    rows: { base: { max: 2 }, mediumSm: { max: 4 }, large: { max: 3 } },
    backgroundProps: { bg: 'fill.default', py: { base: 'xlarge', medium: 'xxlarge' } },
  }}
  stores={stores}
/>
```

#### Other Topic components

| Component | Import | Use for |
|-----------|--------|---------|
| `StoreMarkCarouselTopic` | `@rakuten-rewards/uikit` | Logo-only carousel |
| `StoreMarkGridTopic` | `@rakuten-rewards/uikit` | Grid of store logos |
| `CategoryCarouselTopic` | `@rakuten-rewards/uikit` | Category navigation carousel |
| `ProductCarouselTopic` | `@rakuten-rewards/uikit` | Product showcase |
| `SectionHeroCarouselTopic` | `@rakuten-rewards/uikit` | Section-level heroes |
| `FeaturedGiftCardCarouselTopic` | `@rakuten-rewards/uikit` | Gift card carousel |
| `FeaturedGiftCardGridTopic` | `@rakuten-rewards/uikit` | Gift card grid |
| `HotDealsTopic` | `@rakuten-rewards/uikit` | Hot deals showcase |
| `RecommendedStoreListTopic` | `@rakuten-rewards/uikit` | Curated store list |

---

### Layout primitives (when no Topic applies — component-selection.md R-2)

#### Background + Container (component-selection.md R-5)

Always compose these two: `Background` owns the color/image; `Container` owns max-width.

```tsx
import { Background, Container, VStack } from '@rakuten-rewards/uikit';

<Background bg="palette.purple_05" py={{ base: 'xlarge', medium: 'xxlarge' }}>
  <Container>
    <VStack spacing="large">
      {/* content */}
    </VStack>
  </Container>
</Background>

// With background image
<Background
  backgroundImage="url('/assets/bg.jpg')"
  backgroundSize="cover"
  backgroundPosition="center"
  py={{ base: 'xlarge', medium: 'xxlarge' }}
>
  <Container>
    {/* section content */}
  </Container>
</Background>
```

#### Grid layouts

```tsx
import { Grid, GridItem } from '@rakuten-rewards/uikit';

// 3-column icon/step grid (component-selection.md + responsive-layout.md R-4)
<Grid templateColumns={{ base: '1fr', medium: 'repeat(3, 1fr)' }} gap="large" w="100%">
  <GridItem>
    <VStack spacing="medium" align="center" textAlign="center">
      <Box bg="fill.default" borderRadius="50%" w="80px" h="80px"
          display="flex" alignItems="center" justifyContent="center">
        <Image src="/assets/icons/step1.svg" alt="Step 1 icon" w="40px" h="40px" />
      </Box>
      <Heading as="h3" textStyle="descriptor" color="text.primary">Step 1</Heading>
      <Paragraph color="text.secondary">Description of this step.</Paragraph>
    </VStack>
  </GridItem>
</Grid>
```

#### Flex stacks

```tsx
import { VStack, HStack, Flex } from '@rakuten-rewards/uikit';

// Centered CTA section
<VStack spacing="large" align="center" textAlign="center">
  <Heading as="h2" textStyle="h2" color="text.primary">Call to Action</Heading>
  <Paragraph color="text.secondary">Supporting text.</Paragraph>
  <HStack spacing="medium">
    <Button variant="primary" size="large">Primary</Button>
    <Button variant="secondary" size="large">Secondary</Button>
  </HStack>
</VStack>
```

---

### Button

```tsx
import { Button } from '@rakuten-rewards/uikit';

<Button variant="primary" size="large">Shop Now</Button>
<Button variant="secondary" size="medium">Learn More</Button>
<Button variant="tertiary" size="small">See Details</Button>
<Button variant="primary" isInverse>On dark background</Button>
<Button isFullWidth variant="primary">Full Width</Button>
```

Variants: `primary` (purple bg) · `secondary` (white bg, purple border) · `tertiary` (text only)
Sizes: `small` · `medium` · `large`

---

### FAQ / Accordion (component-selection.md R-3)

Do not use `ExpandableTextBlockTopic`. Use Chakra's `Accordion` directly:

```tsx
import {
  Accordion, AccordionItem, AccordionButton, AccordionPanel, AccordionIcon,
  Box, Heading, Paragraph,
} from '@rakuten-rewards/uikit';

<Accordion allowToggle w="100%">
  <AccordionItem border="none" borderBottom="1px solid" borderColor="border.divider">
    <AccordionButton py="medium" px="0">
      <Box flex="1" textAlign="left">
        <Heading as="h3" textStyle="descriptor" color="text.primary">
          Question text?
        </Heading>
      </Box>
      <AccordionIcon />
    </AccordionButton>
    <AccordionPanel pb="medium" px="0">
      <Paragraph color="text.secondary">Answer text.</Paragraph>
    </AccordionPanel>
  </AccordionItem>
</Accordion>
```

---

### AppShell components

Import from `@rakuten-rewards/appshell`:

```tsx
import { HeaderVariant, FooterVariant } from '@rakuten-rewards/appshell';

// In page getInitialProps:
headerVariant: HeaderVariant.DEFAULT,      // full header with nav
// HeaderVariant.LOGO_ONLY               — logo only, no nav
// HeaderVariant.LOGO_WITH_SIGNIN        — logo + sign-in button

footerVariant: FooterVariant.DEFAULT,      // full footer
// FooterVariant.MINIMAL                 — minimal footer
```

---

### Standard import block

```tsx
import {
  Background,
  Box,
  Button,
  Container,
  Flex,
  Grid,
  GridItem,
  Heading,
  HStack,
  Image,
  Paragraph,
  Text,
  VStack,
} from '@rakuten-rewards/uikit';
import { HeaderVariant, FooterVariant } from '@rakuten-rewards/appshell';
```

---

### Anti-patterns

| Pattern | Why it's wrong | Correct approach |
|---------|---------------|------------------|
| Importing from `@chakra-ui/react` | Bypasses UIKit theme | Import from `@rakuten-rewards/uikit` |
| Using `ExpandableTextBlockTopic` for FAQs | Adds unwanted borders | Use `Accordion` directly |
| Wrapping `<Container bg="...">` | Mixes concerns | Use `<Background>` + `<Container>` |
| Building text+image with `Grid`+`Box` | Duplicates `TextBlockTopic` | Use `TextBlockTopic` |
| `fontSize="40px"` on headings | Bypasses textStyle tokens | Use `<Heading textStyle="h2">` |

## Verification

Run the project TypeScript compiler to confirm no import errors:

```bash
yarn tsc --noEmit
```

Confirm no direct Chakra imports remain:

```bash
grep -rn "from '@chakra-ui/react'" src/
# Should return no matches
```
