// fixtures/non-compliant-data.ts
// This code violates several rules from the REST API Data standard.
// It looks like plausible production TypeScript/Express but contains multiple violations.

import { Request, Response, Router } from 'express'

const router = Router()

// ── R-1, R-2 VIOLATIONS: Pagination ──────────────────────────────────────────

// R-1 VIOLATION: collection endpoint returns unbounded list — no limit or cursor
// R-2 VIOLATION: no pagination wrapper in the response
router.get('/stores', async (_req: Request, res: Response): Promise<void> => {
  const stores = await storeService.findAll()
  res.json(stores)  // R-1 VIOLATION: raw unbounded array, no pagination
})

// R-2 VIOLATION: wrong field names — uses meta.cursor instead of pagination.next,
//   and after/page_size instead of cursor/limit
router.get('/offers', async (req: Request, res: Response): Promise<void> => {
  const after = req.query.after as string | undefined   // R-2 VIOLATION: should be 'cursor'
  const pageSize = Number(req.query.page_size ?? 20)    // R-2 VIOLATION: should be 'limit'
  const { offers, nextCursor } = await offerService.list({ after, pageSize })
  res.json({
    data: offers,
    meta: {                    // R-2 VIOLATION: should be 'pagination', not 'meta'
      cursor: nextCursor,      // R-2 VIOLATION: should be 'next', not 'cursor'
    },
  })
})

// ── R-3 VIOLATIONS: Optimistic concurrency ────────────────────────────────────

// R-3 VIOLATION: PUT handler ignores version_token — no concurrency check
router.put('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const { store_id } = req.params
  // R-3 VIOLATION: version_token not read from req.body — concurrent updates silently overwrite
  const updated = await storeService.update(store_id, req.body)
  res.json({ data: updated })
})

// R-3 VIOLATION: 409 response omits latest entity state
router.put('/products/:product_id', async (req: Request, res: Response): Promise<void> => {
  const { product_id } = req.params
  const { version_token, ...updates } = req.body
  const current = await productService.getById(product_id)
  if (current && current.version_token !== version_token) {
    // R-3 VIOLATION: 409 body contains only error info, not the latest entity state
    // Client must make an extra GET to re-read before retrying
    res.status(409).json({
      errors: [{ code: 'VERSION_CONFLICT', message: 'Concurrent modification detected' }],
      // Missing: data: current
    })
    return
  }
  const updated = await productService.update(product_id, updates)
  res.json({ data: updated })
})

// ── R-4 VIOLATIONS: Timestamps ───────────────────────────────────────────────

router.get('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const store = await storeService.getById(req.params.store_id)
  res.json({
    data: {
      id: store.id,
      name: store.name,
      created_at: store.createdAt,             // R-4 VIOLATION: raw Date object — serialises with ms (.000Z)
      updated_at: store.updatedAt.getTime(),   // R-4 VIOLATION: epoch integer instead of ISO 8601 string
      // Correct: toTimestamp(store.createdAt) → "2024-03-15T14:30:00Z"
    }
  })
})

// R-4 VIOLATION: toISOString() without millisecond truncation
router.get('/orders/:order_id', async (req: Request, res: Response): Promise<void> => {
  const order = await orderService.getById(req.params.order_id)
  res.json({
    data: {
      id: order.id,
      created_at: order.createdAt.toISOString(),  // R-4 VIOLATION: produces "2024-03-15T14:30:00.000Z"
      // Correct: order.createdAt.toISOString().replace(/\.\d{3}Z$/, 'Z')
    }
  })
})

// ── R-5, R-6 VIOLATIONS: Decimal and currency ─────────────────────────────────

router.get('/offers/:offer_id', async (req: Request, res: Response): Promise<void> => {
  const offer = await offerService.getById(req.params.offer_id)
  res.json({
    data: {
      id: offer.id,
      name: offer.name,
      price: 12.99,                               // R-5 VIOLATION: JSON float — precision loss possible
      discount_rate: 0.15,                        // R-5 VIOLATION: JSON float — should be { value: 15, scale: 2 }
      total: { amount: 42.50, currency: 'USD' },  // R-6 VIOLATION: float amount + missing scale field
      // Correct price:        { value: 1299, scale: 2 }
      // Correct discount:     { value: 15, scale: 2 }
      // Correct total:        { amount: 4250, currency: 'USD', scale: 2 }
    }
  })
})

// R-6 VIOLATION: currency amount stored as separate fields instead of structured object
router.get('/wallets/:wallet_id', async (req: Request, res: Response): Promise<void> => {
  const wallet = await walletService.getById(req.params.wallet_id)
  res.json({
    data: {
      member_id: wallet.memberId,
      balance: wallet.balance,     // R-6 VIOLATION: raw float — no structure, no scale
      currency: wallet.currency,   // R-6 VIOLATION: currency separate from amount — not a MoneyAmount
      // Correct: { amount: <integer>, currency: 'USD', scale: 2 }
    }
  })
})

// ── R-8 VIOLATION: Localization ───────────────────────────────────────────────

// R-8 VIOLATION: Accept-Language header never read — always returns English content
router.get('/stores/:store_id/content', async (req: Request, res: Response): Promise<void> => {
  // R-8 VIOLATION: locale hardcoded to 'en-US' regardless of client preference
  const content = await contentService.getStoreContent(req.params.store_id, { locale: 'en-US' })
  res.json({ data: content })
  // Correct: const locale = negotiateLocale(req.headers['accept-language'])
  //          contentService.getStoreContent(id, { locale })
})

export { router }

// Stub service declarations (not part of the standard — omit in real service)
declare const storeService: {
  findAll(): Promise<unknown[]>
  getById(id: string): Promise<{ id: string; name: string; version_token: string; createdAt: Date; updatedAt: Date }>
  update(id: string, data: unknown): Promise<unknown>
}
declare const offerService: {
  list(opts: { after?: string; pageSize: number }): Promise<{ offers: unknown[]; nextCursor?: string }>
  getById(id: string): Promise<{ id: string; name: string }>
}
declare const productService: {
  getById(id: string): Promise<{ id: string; version_token: string } | null>
  update(id: string, data: unknown): Promise<unknown>
}
declare const orderService: {
  getById(id: string): Promise<{ id: string; createdAt: Date }>
}
declare const walletService: {
  getById(id: string): Promise<{ memberId: string; balance: number; currency: string }>
}
declare const contentService: {
  getStoreContent(id: string, opts: { locale: string }): Promise<unknown>
}
