# TypeScript/Node.js Guide — REST API Security

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/security.md@1.0.1

## Overview

Shows how to satisfy the REST API Security standard in a Node.js/Express service using
TypeScript. Covers Express middleware for `Authorization: Bearer` / `euid` cookie
authentication on public member-data endpoints; JWT signature, expiry, and role validation
on admin (`-admin`) contract routes; and server-to-server token validation on sensitive
internal (`-int`) endpoints. An Express service that follows this guide will enforce the
correct authentication strategy per contract type and return 401/403 on credential
failures.

## Related standard

[REST API Security](../../../../../../../standards/api/rest/security.md)

## Prerequisites

- Node.js 20+
- TypeScript 5.x (`typescript ^5.6.3`)
- Express 4.x (`express ^4.21.2`, `@types/express ^4.17.21`)
- `jsonwebtoken ^9.0.2`, `@types/jsonwebtoken ^9.0.7` — JWT signature and expiry validation (R-1, R-2)
- `cookie-parser ^1.4.7`, `@types/cookie-parser ^1.4.7` — parse `euid` cookie for public contract auth (R-1)

## Implementation

### Public contract authentication (R-1)

Accept `Authorization: Bearer <ebtoken>` or `euid` cookie on every public endpoint that
accesses member data. Return 401 on missing or invalid credentials.

```typescript
// src/middleware/ebtokenAuth.ts
import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'

export interface MemberClaims {
  memberId: string
  region: string
  // extend with org-specific claims as needed
}

/**
 * R-1: Authenticate member-data requests via ebtoken.
 * Accepts: Authorization: Bearer <ebtoken>  OR  Cookie: euid=<ebtoken>
 * Returns 401 on missing or invalid token.
 */
export function ebtokenAuth(req: Request, res: Response, next: NextFunction): void {
  const token = extractEbtoken(req)
  if (!token) {
    res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'ebtoken required — provide Authorization: Bearer or euid cookie' }],
      meta: { status: { code: 'Unauthorized' }, operation: { request_id: crypto.randomUUID() } },
    })
    return
  }

  try {
    const claims = jwt.verify(token, process.env.EBTOKEN_PUBLIC_KEY!) as MemberClaims
    res.locals.member = claims
    next()
  } catch {
    res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'Invalid or expired ebtoken' }],
      meta: { status: { code: 'Unauthorized' }, operation: { request_id: crypto.randomUUID() } },
    })
  }
}

function extractEbtoken(req: Request): string | null {
  // 1. Authorization: Bearer <ebtoken>
  const authHeader = req.headers['authorization']
  if (authHeader?.startsWith('Bearer ')) return authHeader.slice(7)
  // 2. euid cookie (browser clients — R-1 alternative)
  return (req.cookies as Record<string, string>)['euid'] ?? null
}
```

```typescript
// src/core/routes/index.ts — apply per-route on member-scoped paths only
import { ebtokenAuth } from '../middleware/ebtokenAuth'

// Public endpoints with no member data — no auth middleware
publicRouter.get('/stores', listStoresHandler)

// Member-scoped endpoints — ebtokenAuth required (R-1)
publicRouter.get(
  '/regions/:region_id/members/:member_guid/experiences/:experience_name',
  ebtokenAuth,
  getExperienceHandler
)
publicRouter.get(
  '/regions/:region_id/members/:member_guid/offers',
  ebtokenAuth,
  listMemberOffersHandler
)
```

```typescript
// src/core/app.ts — cookie-parser must be registered before ebtokenAuth
import cookieParser from 'cookie-parser'

app.use(cookieParser())
```

### Admin contract authorization (R-2)

Validate JWT signature, expiry, **and** required role(s) on every `-admin` contract
request. All three checks must pass; a missing role returns 403 (not 401).

```typescript
// src/middleware/adminAuth.ts
import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'

export interface AdminClaims {
  operatorId: string
  roles: string[]
}

/**
 * R-2: Validate JWT signature + expiry + required role on every admin request.
 * Returns 401 on missing/invalid token; 403 on insufficient roles.
 */
export function requireAdminRole(role: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const authHeader = req.headers['authorization']
    if (!authHeader?.startsWith('Bearer ')) {
      res.status(401).json({
        errors: [{ code: 'UNAUTHORIZED', message: 'Bearer token required' }],
        meta: { status: { code: 'Unauthorized' }, operation: { request_id: crypto.randomUUID() } },
      })
      return
    }

    let claims: AdminClaims
    try {
      // R-2: validates signature AND expiry in one call — both must pass
      claims = jwt.verify(authHeader.slice(7), process.env.ADMIN_JWT_PUBLIC_KEY!) as AdminClaims
    } catch {
      res.status(401).json({
        errors: [{ code: 'UNAUTHORIZED', message: 'Invalid or expired admin token' }],
        meta: { status: { code: 'Unauthorized' }, operation: { request_id: crypto.randomUUID() } },
      })
      return
    }

    // R-2: check required role — insufficient roles → 403 (not 401)
    if (!claims.roles.includes(role)) {
      res.status(403).json({
        errors: [{ code: 'FORBIDDEN', message: `Role '${role}' required` }],
        meta: { status: { code: 'Forbidden' }, operation: { request_id: crypto.randomUUID() } },
      })
      return
    }

    res.locals.operator = claims
    next()
  }
}
```

```typescript
// src/core/routes/index.ts — admin router uses requireAdminRole on every route
import { requireAdminRole } from '../middleware/adminAuth'

// app.use('/purchase_experience-admin/v1', adminRouter)

adminRouter.get(
  '/stores',
  requireAdminRole('store_admin'),  // R-2: signature + expiry + role — all three checked
  listAllStoresHandler
)
adminRouter.delete(
  '/stores/:store_id',
  requireAdminRole('store_admin'),
  deleteStoreHandler
)
```

### Sensitive internal endpoint authentication (R-3)

For `-int` endpoints that perform sensitive operations (member balance, PII, payment
methods, account deletion), require a server-to-server token. Non-sensitive `-int`
endpoints need no authentication middleware.

```typescript
// src/middleware/s2sAuth.ts
import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'

export interface ServiceIdentity {
  serviceId: string
}

/**
 * R-3: Validate server-to-server token on sensitive -int endpoints.
 * Returns 401 on missing or invalid token.
 */
export function s2sAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization']
  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'Server-to-server token required' }],
      meta: { status: { code: 'Unauthorized' }, operation: { request_id: crypto.randomUUID() } },
    })
    return
  }

  try {
    const identity = jwt.verify(
      authHeader.slice(7),
      process.env.S2S_PUBLIC_KEY!
    ) as ServiceIdentity
    res.locals.service = identity
    next()
  } catch {
    res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'Invalid server-to-server token' }],
      meta: { status: { code: 'Unauthorized' }, operation: { request_id: crypto.randomUUID() } },
    })
  }
}
```

```typescript
// src/core/routes/index.ts — apply s2sAuth only on sensitive -int routes
import { s2sAuth } from '../middleware/s2sAuth'

// app.use('/wallet-int/v1', internalRouter)

// R-3: sensitive — modifies member balance → s2sAuth required
internalRouter.put(
  '/regions/:region_id/members/:member_id/balance',
  s2sAuth,
  updateMemberBalanceHandler
)

// R-3: sensitive — accesses PII → s2sAuth required
internalRouter.get(
  '/regions/:region_id/members/:member_id/profile',
  s2sAuth,
  getMemberProfileHandler
)

// Non-sensitive internal route — no s2sAuth required
internalRouter.get('/platform_configs', listPlatformConfigsHandler)
```

## Verification

1. Confirm every member-scoped public route has `ebtokenAuth` middleware before the handler:
   ```bash
   grep -rn 'members/:member_guid' src/core/routes/ | xargs grep -L 'ebtokenAuth'
   ```
   Any file listed is missing R-1 authentication — add `ebtokenAuth` before the handler.

2. Confirm `cookieParser()` is registered before any route that uses `ebtokenAuth`:
   ```bash
   grep -n 'cookieParser\|ebtokenAuth\|app\.use' src/core/app.ts
   ```
   `cookieParser()` must appear before the first route mount.

3. Confirm every admin router route uses `requireAdminRole(...)`:
   ```bash
   grep -rn 'adminRouter\.' src/core/routes/ | grep -v 'requireAdminRole'
   ```
   Any match is a R-2 violation — every admin route must validate signature, expiry, and role.

4. Confirm sensitive `-int` routes have `s2sAuth` middleware:
   ```bash
   grep -rn 'balance\|profile\|payment\|account' src/core/routes/ | grep 'internalRouter' | xargs grep -L 's2sAuth'
   ```
   Any sensitive endpoint listed is missing R-3 authentication.

5. Confirm 401 is returned (not 403) for missing/invalid tokens, and 403 (not 401) for
   insufficient roles — search for role-check branches:
   ```bash
   grep -rn 'roles.includes\|hasRole' src/middleware/ -A 3 | grep 'status(4'
   ```
   Role-check failures must return `status(403)`; token validation failures must return `status(401)`.

6. Run the linter — all source files must pass with no errors:
   ```bash
   yarn lint
   ```
