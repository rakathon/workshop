// users/queries.ts
// Compliant: factory centralised and co-located with fetchers (R-1, R-4),
// keys structured hierarchically (R-2), all values serialisable (R-3),
// same factory used on client and server (R-5).

export const userKeys = {
  all: () => ['users'] as const,
  lists: () => [...userKeys.all(), 'list'] as const,
  list: (filters: UserListFilters) => [...userKeys.lists(), filters] as const,
  details: () => [...userKeys.all(), 'detail'] as const,
  detail: (id: string) => [...userKeys.details(), id] as const,
} satisfies Record<string, (...args: unknown[]) => readonly unknown[]>

// Client — hooks
export function useUser(id: string) {
  return useQuery({
    queryKey: userKeys.detail(id),
    queryFn: () => fetchUser(id),
  })
}

export function useUsers(filters: UserListFilters) {
  return useQuery({
    queryKey: userKeys.list(filters),
    queryFn: () => fetchUsers(filters),
  })
}

// Server — app/users/[id]/page.tsx (Next.js RSC)
export async function prefetchUser(queryClient: QueryClient, id: string) {
  await queryClient.prefetchQuery({
    queryKey: userKeys.detail(id),  // same factory — guaranteed cache hit on hydration
    queryFn: () => fetchUser(id),
  })
}

// Cache invalidation — hierarchy enables targeted subtree clearing
export function invalidateUsers(queryClient: QueryClient) {
  // Invalidate all user data
  queryClient.invalidateQueries({ queryKey: userKeys.all() })
}

export function invalidateUserLists(queryClient: QueryClient) {
  // Invalidate only lists — detail queries unaffected
  queryClient.invalidateQueries({ queryKey: userKeys.lists() })
}
