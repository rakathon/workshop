// fixtures/compliant-contracts.ts
// A realistic Express service satisfying all REST API contracts rules.
// Referenced by contracts.test.yaml as a whole-file compliant example.

import { Router, Request, Response, NextFunction } from 'express'

// R-5: Separate Router instances per contract type
const publicRouter = Router()    // no suffix — public contract
const internalRouter = Router()  // -int suffix — server-to-server

// R-1, R-2: Version is the static second segment in the mount path — never a dynamic param
// app.use('/purchase_experience/v1', publicRouter)
// app.use('/purchase_experience-int/v1', internalRouter)

// ── Public routes ────────────────────────────────────────────────────────────

// R-10: member-scoped path includes /regions/:region_id/members/:member_guid
// R-4:  all params are snake_case
// R-7:  GET for reads
publicRouter
  .route('/regions/:region_id/members/:member_guid/experiences/:experience_name')
  .get(
    (req: Request, res: Response, next: NextFunction): void => {
      void processRequest(req, res, next, getExperience)
    }
  )
  .all((_req: Request, res: Response): void => {
    res.status(405).json({
      errors: [{ code: 'METHOD_NOT_ALLOWED', message: 'HTTP method not supported for this endpoint' }],
      meta: { status: { code: 'MethodNotAllowed' } }
    })
  })

// R-3: plural snake_case collection segment ('experiences')
// R-7: POST for creates
publicRouter
  .route('/regions/:region_id/experiences')
  .get((req: Request, res: Response, next: NextFunction): void => {
    void processRequest(req, res, next, listExperiences)
  })
  .post((req: Request, res: Response, next: NextFunction): void => {
    void processRequest(req, res, next, createExperience)  // returns 201 + Location
  })
  .all((_req: Request, res: Response): void => {
    res.status(405).json({
      errors: [{ code: 'METHOD_NOT_ALLOWED', message: 'HTTP method not supported for this endpoint' }],
      meta: { status: { code: 'MethodNotAllowed' } }
    })
  })

// ── Internal routes ──────────────────────────────────────────────────────────

// R-10: internal contract uses :member_id (integer), not :member_guid
// R-5:  mounted at /purchase_experience-int/v1 — separate from public router
internalRouter
  .route('/regions/:region_id/members/:member_id/experiences/:experience_name')
  .get((req: Request, res: Response, next: NextFunction): void => {
    void processAdminRequest(req, res, next, getExperienceInternal)
  })
  .all((_req: Request, res: Response): void => {
    res.status(405).json({
      errors: [{ code: 'METHOD_NOT_ALLOWED', message: 'HTTP method not supported for this endpoint' }],
      meta: { status: { code: 'MethodNotAllowed' } }
    })
  })

// R-4: snake_case param :feature_name (not :featureName)
// R-7: GET / PUT / DELETE with correct verb semantics
internalRouter
  .route('/features/:feature_name')
  .get((req: Request, res: Response, next: NextFunction): void => {
    void processAdminRequest(req, res, next, getFeature)
  })
  .put((req: Request, res: Response, next: NextFunction): void => {
    void processAdminRequest(req, res, next, replaceFeature)   // R-7: PUT = full replacement
  })
  .delete((req: Request, res: Response, next: NextFunction): void => {
    void processAdminRequest(req, res, next, deleteFeature)
  })
  .all((_req: Request, res: Response): void => {
    res.status(405).json({
      errors: [{ code: 'METHOD_NOT_ALLOWED', message: 'HTTP method not supported for this endpoint' }],
      meta: { status: { code: 'MethodNotAllowed' } }
    })
  })

// R-6: breaking change — v2 router mounted alongside v1, v1 untouched
// app.use('/purchase_experience/v2', publicV2Router)

export { publicRouter, internalRouter }

// Stub type declarations (not part of the standard — omit in real service)
declare function processRequest(req: Request, res: Response, next: NextFunction, handler: unknown): Promise<void>
declare function processAdminRequest(req: Request, res: Response, next: NextFunction, handler: unknown): Promise<void>
declare const getExperience: unknown
declare const listExperiences: unknown
declare const createExperience: unknown
declare const getExperienceInternal: unknown
declare const getFeature: unknown
declare const replaceFeature: unknown
declare const deleteFeature: unknown
