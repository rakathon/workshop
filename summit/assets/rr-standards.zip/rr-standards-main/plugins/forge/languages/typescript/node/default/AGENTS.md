# TypeScript/Node.js Guides — Current

## Directory purpose

Implementation guides for TypeScript/Node.js backend services. This is the default
version directory for all new Node.js work using TypeScript. Covers server-side patterns
including HTTP/REST API design with Express.

## File index

| Entry | Purpose | When to reference |
|-------|---------|-------------------|
| `guides/` | TypeScript/Node.js implementation guides organised by domain area | When reviewing or generating TypeScript server-side code |
| `guides/api/rest/` | Express router patterns implementing the REST API Contracts standard — contract type separation, versioned mounting, `snake_case` params, HTTP verbs, member-scoped URIs | Designing or implementing any HTTP/REST API route file in a TypeScript/Node.js service |
| `guides/testing/e2e.md` | E2E test framework using Jest + axios — FULL_FRAMEWORK and ADD_TEST_ONLY modes, isolated `jest.e2e.config.ts`, config via `e2e.properties`, real HTTP calls to deployed services | Writing or reviewing E2E tests for any TypeScript/Node.js HTTP service |

## Navigation

- [Standards library](../../../../standards/) — language-agnostic standards these guides implement

## Linter

`ts-standard` (`ts-standard ^12.0.2`). Configuration is declared in `package.json` under
the `"ts-standard"` key, pointing at `tsconfig.json` (`"project": "tsconfig.json"`). There
is no separate `.eslintrc` file — ts-standard manages its own ESLint rules internally.

Run the linter: `yarn lint` (maps to `ts-standard`)
Auto-fix: `yarn lint:fix` (maps to `ts-standard --fix`)

All generated TypeScript code must pass `yarn lint` with zero errors before being emitted.
