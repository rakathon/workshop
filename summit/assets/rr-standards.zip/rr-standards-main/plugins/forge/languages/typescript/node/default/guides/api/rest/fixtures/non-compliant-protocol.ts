// fixtures/non-compliant-protocol.ts
// This code violates several rules from the REST API Protocol standard.
// It looks like plausible production TypeScript/Express but contains multiple violations.

import { Request, Response, NextFunction, Router } from 'express'

const router = Router()

// R-1 VIOLATION: no Client-Agent header middleware registered
// R-4 VIOLATION: compression() not registered — gzip disabled

// ── R-5, R-6 VIOLATIONS: No envelope, no meta ─────────────────────────────────

// R-5 VIOLATION: success response is raw object — no data/meta wrapper
// R-6 VIOLATION: no meta field at all — no status.code, no request_id
router.get('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const store = await storeService.getById(req.params.store_id)
  if (!store) {
    // R-8 VIOLATION: error response is a plain string, not an errors array
    res.status(404).json({ message: 'Store not found' })
    return
  }
  // R-5 VIOLATION: raw payload — missing data wrapper and meta
  res.status(200).json(store)
})

// R-5 VIOLATION: collection response missing pagination and meta
router.get('/stores', async (_req: Request, res: Response): Promise<void> => {
  const stores = await storeService.findAll()
  // R-5 VIOLATION: raw array — no data wrapper, no pagination, no meta
  res.status(200).json(stores)
})

// R-7 VIOLATION: POST create returns 200 instead of 201 + Location
router.post('/stores', async (req: Request, res: Response): Promise<void> => {
  const created = await storeService.create(req.body)
  // R-7 VIOLATION: 200 on create — must be 201 with Location header
  // R-5 VIOLATION: no envelope — raw created object
  res.status(200).json(created)
  // Missing: res.status(201).location(`/stores/v1/stores/${created.id}`)
})

// R-7 VIOLATION: 400 returned for business rule violation (should be 422)
router.post('/stores/:store_id/publish', async (req: Request, res: Response): Promise<void> => {
  const store = await storeService.getById(req.params.store_id)
  if (!store) { res.status(404).json({ message: 'Not found' }); return }
  if (!storeService.canPublish(req.params.store_id)) {
    // R-7 VIOLATION: 400 for a business rule failure — should be 422 Unprocessable Entity
    res.status(400).json({ error: 'Store cannot be published in current state' })
    return
  }
  res.status(200).json({ published: true })
})

// R-2 VIOLATION: custom header uses deprecated X- prefix
// (declared as X-Client-Agent instead of Client-Agent)
export function requireClientAgentWrong(req: Request, res: Response, next: NextFunction): void {
  if (!req.headers['x-client-agent']) {  // R-2 VIOLATION: X- prefix is deprecated
    res.status(400).json({ error: 'X-Client-Agent header is required' })
    return
  }
  next()
}

// R-6 VIOLATION: meta present but missing request_id — only has status.code
function badMeta(statusCode: string) {
  return { status: { code: statusCode } }
  // Missing: operation: { request_id: uuidv4() }
}

// R-8 VIOLATION: error response uses single error object instead of errors array
router.put('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const { version_token, ...updates } = req.body
  const current = await storeService.getById(req.params.store_id)
  if (!current) {
    // R-8 VIOLATION: single error object — must be non-empty errors array
    // R-5 VIOLATION: no meta field
    res.status(404).json({ code: 'NOT_FOUND', message: 'Store not found' })
    return
  }
  const updated = await storeService.update(req.params.store_id, updates)
  // R-5 VIOLATION: missing meta on success
  res.status(200).json({ data: updated })
})

// R-3 VIOLATION: 429 response missing Retry-After header
export function rateLimitHandler(_req: Request, res: Response): void {
  // R-3 VIOLATION: no Retry-After header on 429
  res.status(429).json({
    errors: [{ code: 'RATE_LIMIT_EXCEEDED', message: 'Too many requests' }],
    // Missing: .set('Retry-After', '60')
  })
}

export { router }

// Stub service declarations
declare const storeService: {
  getById(id: string): Promise<{ id: string; name: string } | null>
  findAll(): Promise<{ id: string }[]>
  create(data: unknown): Promise<{ id: string }>
  update(id: string, data: unknown): Promise<{ id: string }>
  canPublish(id: string): boolean
}
