---
guide_version: 1.0.0
implements: standards/frontend/design-tokens.md@1.0.0
---

# Design Tokens — TypeScript/React Implementation

Guide: 1.0.0 | Implements: standards/frontend/design-tokens.md@1.0.0

## Overview

Concrete token values and usage patterns for the `@rakuten-rewards/uikit` Chakra theme.
All values are passed as prop strings — no CSS, no style objects.

## Related standard

[`standards/frontend/design-tokens.md`](../../../../../../standards/frontend/design-tokens.md)

## Prerequisites

- `@rakuten-rewards/uikit` installed
- `@rakuten-rewards/appshell` installed (for AppShell components)
- Next.js project configured with the AppShell `next.config.js` extension

## Implementation

### Spacing tokens

Pass token names as strings to any spacing prop (`p`, `px`, `py`, `m`, `mt`, `mb`,
`gap`, `spacing`).

```tsx
// Token     Value   Usage
// xxsmall   4px     tight internal padding
// xsmall    8px     icon-to-label gap
// small     12px    compact list spacing
// medium    16px    standard internal padding
// venti     20px    slightly more than medium
// grande    24px    card-level gap
// large     32px    component-level separation
// xlarge    48px    section-level vertical padding (mobile)
// xxlarge   64px    section-level vertical padding (desktop)

<Box p="medium" />
<VStack spacing="large" />
<Background py={{ base: "xlarge", medium: "xxlarge" }} />
```

Standard section vertical padding (required by responsive-layout.md R-3):

```tsx
<Background bg="palette.purple_05" py={{ base: "xlarge", medium: "xxlarge" }}>
  <Container>...</Container>
</Background>
```

### Color tokens

#### Semantic fill (use for `bg` prop)

```tsx
bg="fill.default"                  // #FFFFFF — default white background
bg="fill.ctaPrimary"               // #8529CD — primary CTA button background
bg="fill.preferenceBackground"     // #F4F3FE — light purple background
bg="fill.listviewBackground"       // #D9ECFF — light blue background
bg="fill.sectionInversePrimary"    // #242463 — dark blue inverse section
bg="fill.sectionInverseSecondary"  // #252525 — near-black inverse section
```

#### Brand palette (use for `bg` and `color` props)

```tsx
bg="brand.purple"        // #8529CD — Rakuten Rewards primary purple
bg="brand.darkIndigo"    // #242463 — dark indigo
bg="palette.purple_05"   // #F4F3FE — 5% purple tint (subtle section backgrounds)
bg="palette.purple_15"   // #E4E0FC — 15% purple tint
bg="palette.purple_25"   // #CFC0FF — 25% purple tint
bg="palette.purple_400"  // #480081 — deep purple (logo strips, accents)
```

#### Semantic text (use for `color` prop)

```tsx
color="text.primary"    // #252525 — body text, headings
color="text.secondary"  // #575757 — supporting text
color="text.tertiary"   // #737373 — captions, metadata
color="text.inverse"    // #FFFFFF — text on dark/purple backgrounds
color="text.cashback"   // #8529CD — cashback amounts and highlights
color="text.action"     // #8529CD — links and interactive text
```

#### Border colors

```tsx
borderColor="border.primary"       // #252525 — strong borders
borderColor="border.inverse"       // #FFFFFF — borders on dark backgrounds
borderColor="border.divider"       // #B9B9B9 — subtle separators
borderColor="border.iconContainer" // #DDDDDD — icon container outlines
```

#### State colors

```tsx
color="state.error"    // #B90037
color="state.success"  // #33823F
color="state.warning"  // #EE6B00
color="state.info"     // #3E3E9D
bg="state.hover"       // #9B50D6 — lighter purple hover
bg="state.pressed"     // #7119B8 — darker purple pressed
```

#### Gradient exception (design-tokens.md R-6)

Gradients are the only case where hex values are used directly in `bg`. Use the
hex values that correspond to the named tokens above:

```tsx
// Light purple gradient
bg="linear-gradient(135deg, #e4e0fc 0%, #cfc0ff 100%)"
// (palette.purple_15 → palette.purple_25)

// Dark purple gradient
bg="linear-gradient(135deg, #8529cd 0%, #480081 100%)"
// (brand.purple → palette.purple_400)
```

### Typography tokens

Always use `<Heading>` with `as` and `textStyle` — never raw `<Text fontSize>` for
headings. Use `<Paragraph>` for all body copy.

```tsx
import { Heading, Paragraph, Text } from '@rakuten-rewards/uikit';

// Headings
<Heading as="h1" textStyle="h1">Page title</Heading>          // 48px desktop / 32px mobile
<Heading as="h2" textStyle="h2">Section heading</Heading>     // 40px desktop / 28px mobile
<Heading as="h3" textStyle="h3">Subsection</Heading>          // 32px desktop / 24px mobile
<Heading textStyle="descriptor">Bold label</Heading>           // bold descriptor
<Heading textStyle="descriptorLarge">Large label</Heading>     // large bold descriptor

// Body
<Paragraph>Standard body text</Paragraph>

// Special
<Text textStyle="cashback">7% Cash Back</Text>

// Precise control (only when no textStyle covers the need)
<Text fontSize="body">14px text</Text>
<Text fontSize="large">18px text</Text>
<Text fontSize="xlarge">20px text</Text>
```

### Shadow tokens

```tsx
boxShadow="default"            // standard card elevation
boxShadow="defaultEmphasized"  // stronger elevation
boxShadow="listView"           // list items
boxShadow="modal"              // modals and overlays
```

### Border radius tokens

```tsx
borderRadius="tag"   // 4px — tags, small chips
borderRadius="ui"    // 8px — standard cards, buttons, inputs
borderRadius="cta"   // 20px — pill buttons, large CTAs
borderRadius="50%"   // circles — avatars, icon containers
```

## Verification

To confirm correct token usage, verify no raw hex colors or pixel values appear in
component props:

```bash
# Find raw hex values in component props (should return no matches)
grep -rn 'color="#\|bg="#\|borderColor="#' src/

# Find raw pixel spacing in props (should return no matches in prop positions)
grep -rn 'p="\d\+px\|py="\d\+px\|gap="\d\+px' src/
```
