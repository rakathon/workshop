---
guide_version: 1.0.0
---

# Page Patterns — TypeScript/React

Guide: 1.0.0 | Standalone (no single companion standard — implements design-tokens,
component-selection, and responsive-layout standards in combination)

## Overview

Complete page-level composition patterns for Rakuten Rewards web pages. These patterns
are prescriptive: use them as the starting structure for new pages and features rather
than designing section order from scratch.

## Related standard

Standalone guide. Implements:
- [`standards/frontend/component-selection.md`](../../../../../../standards/frontend/component-selection.md)
- [`standards/frontend/design-tokens.md`](../../../../../../standards/frontend/design-tokens.md)
- [`standards/frontend/responsive-layout.md`](../../../../../../standards/frontend/responsive-layout.md)

## Prerequisites

- All prerequisites from `tokens.md`, `components.md`, and `responsive-layout.md`

## Implementation

### Homepage pattern

Build sections top-to-bottom in this order:

```
1. Hero / sign-up CTA         — TextBlockTopic (emphasized) or PageHeroCarouselTopic
2. Featured store grid         — StoreCarouselTopic (rows=2) or PromoTopic
3. "How It Works" steps        — Grid + Box (3 columns, icons)
4. Social proof / stats        — TextBlockTopic (emphasized) or custom Background+Grid
5. Alternating feature sections — Multiple TextBlockTopic (left/right variants)
6. Stats grid                  — Grid (4 columns on desktop, 2 on mobile)
7. Final CTA                   — Background + Container + VStack + Button
```

### Category landing page pattern (Dining, Travel, etc.)

```
1. Category hero               — TextBlockTopic with category background
2. Featured merchants          — StoreCarouselTopic filtered to category
3. Category "How It Works"     — Grid + Box (3–4 steps with category icons)
4. Value prop sections         — 2–3 TextBlockTopic alternating left/right
5. FAQ                         — Background + Accordion (NOT ExpandableTextBlockTopic)
6. Final CTA                   — Background + VStack + Button
```

### Category landing page — complete example

Replace `{/* ... */}` placeholder comments with real content for the specific category.

```tsx
import * as React from 'react';
import {
  Accordion, AccordionButton, AccordionIcon, AccordionItem, AccordionPanel,
  Background, Box, Button, Container, Grid, GridItem,
  Heading, Image, Paragraph, StoreCarouselTopic, TextBlockTopic, VStack,
} from '@rakuten-rewards/uikit';

// Provide category-specific data from your feature's data layer
const featuredStores = [
  { id: '1', logoImage: '/stores/<id>/logo.png', logoImageAlt: '<Store Name>',
    logoBg: '#ffffff', href: '/store/<id>', rewardText: '<N>% Cash Back' },
];

const howItWorksSteps = [
  { icon: '/assets/icons/<Icon>.svg', iconAlt: '<Step 1 icon>',
    title: '<Step 1 title>', description: '<Step 1 description>' },
  { icon: '/assets/icons/<Icon>.svg', iconAlt: '<Step 2 icon>',
    title: '<Step 2 title>', description: '<Step 2 description>' },
  { icon: '/assets/icons/<Icon>.svg', iconAlt: '<Step 3 icon>',
    title: '<Step 3 title>', description: '<Step 3 description>' },
];

export const CategoryLandingPage = () => (
  <Box>
    {/* 1. Hero */}
    <TextBlockTopic
      topicData={{
        backgroundProps: { bg: 'palette.purple_25', py: { base: 'xlarge', medium: 'xxlarge' } },
        isInverse: false,
      }}
      textBlock={{
        variant: 'emphasized',
        heading: '<Category headline>',
        body: '<Supporting value proposition>',
        ctaText: '<Primary CTA label>',
        ctaUrl: '/<category>',
      }}
    />

    {/* 2. Featured partners */}
    <StoreCarouselTopic
      topicData={{
        title: '<Featured Partners heading>',
        topicCTA: 'See All',
        topicCTAUri: '/<category>/stores',
        backgroundProps: { bg: 'fill.default', py: { base: 'xlarge', medium: 'xxlarge' } },
        isInverse: false,
      }}
      stores={featuredStores}
    />

    {/* 3. How It Works */}
    <Background bg="palette.purple_05" py={{ base: 'xlarge', medium: 'xxlarge' }}>
      <Container>
        <VStack spacing="xlarge">
          <Heading as="h2" textStyle="h2" textAlign="center" color="text.primary">
            How It Works
          </Heading>
          <Grid templateColumns={{ base: '1fr', medium: 'repeat(3, 1fr)' }} gap="large" w="100%">
            {howItWorksSteps.map((step) => (
              <GridItem key={step.title}>
                <VStack spacing="medium" align="center" textAlign="center">
                  <Box bg="fill.default" borderRadius="50%" w="80px" h="80px"
                      display="flex" alignItems="center" justifyContent="center" boxShadow="default">
                    <Image src={step.icon} alt={step.iconAlt} w="40px" h="40px" />
                  </Box>
                  <Heading as="h3" textStyle="descriptor" color="text.primary">{step.title}</Heading>
                  <Paragraph color="text.secondary">{step.description}</Paragraph>
                </VStack>
              </GridItem>
            ))}
          </Grid>
        </VStack>
      </Container>
    </Background>

    {/* 4. Value props — alternate left/right, alternate background tint */}
    <TextBlockTopic
      topicData={{ backgroundProps: { bg: 'fill.default', py: { base: 'xlarge', medium: 'xxlarge' } } }}
      textBlock={{
        variant: 'left',
        heading: '<Value prop 1 heading>',
        body: '<Value prop 1 body>',
        imageUrl: '/assets/photos/<category>/image1.jpg',
        imageAlt: '<Descriptive alt text>',
        ctaText: '<CTA label>',
        ctaUrl: '/<path>',
      }}
    />
    <TextBlockTopic
      topicData={{ backgroundProps: { bg: 'palette.purple_05', py: { base: 'xlarge', medium: 'xxlarge' } } }}
      textBlock={{
        variant: 'right',
        heading: '<Value prop 2 heading>',
        body: '<Value prop 2 body>',
        imageUrl: '/assets/photos/<category>/image2.jpg',
        imageAlt: '<Descriptive alt text>',
        ctaText: '<CTA label>',
        ctaUrl: '/<path>',
      }}
    />

    {/* 5. FAQ */}
    <Background bg="palette.purple_05" py={{ base: 'xlarge', medium: 'xxlarge' }}>
      <Container maxW="800px">
        <VStack spacing="large" align="flex-start">
          <Heading as="h2" textStyle="h2" color="text.primary">
            Frequently Asked Questions
          </Heading>
          <Accordion allowToggle w="100%">
            {[
              { q: '<Question 1>?', a: '<Answer 1>.' },
              { q: '<Question 2>?', a: '<Answer 2>.' },
            ].map((item) => (
              <AccordionItem key={item.q} border="none" borderBottom="1px solid" borderColor="border.divider">
                <AccordionButton py="medium" px="0">
                  <Box flex="1" textAlign="left">
                    <Heading as="h3" textStyle="descriptor" color="text.primary">{item.q}</Heading>
                  </Box>
                  <AccordionIcon />
                </AccordionButton>
                <AccordionPanel pb="medium" px="0">
                  <Paragraph color="text.secondary">{item.a}</Paragraph>
                </AccordionPanel>
              </AccordionItem>
            ))}
          </Accordion>
        </VStack>
      </Container>
    </Background>

    {/* 6. Final CTA */}
    <Background bg="fill.ctaPrimary" py={{ base: 'xlarge', medium: 'xxlarge' }}>
      <Container maxW="600px">
        <VStack spacing="large" textAlign="center">
          <Heading as="h2" textStyle="h2" color="text.inverse">
            {/* CTA section heading */}
          </Heading>
          <Paragraph color="text.inverse">{/* Supporting text */}</Paragraph>
          <Button variant="primary" size="large" isInverse>{/* CTA label */}</Button>
        </VStack>
      </Container>
    </Background>
  </Box>
);
```

### Background progression for multi-section pages

Stack sections using this color sequence to create visual rhythm without jarring jumps:

```
fill.default         → white, neutral
palette.purple_05    → very subtle tint
palette.purple_15    → light purple
palette.purple_25    → medium purple
fill.ctaPrimary      → brand purple (CTA sections only)
fill.sectionInversePrimary  → dark blue (inverse sections)
```

## Verification

Confirm the page renders without console errors at `localhost:3000`:

```bash
# After yarn dev is running:
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/your-page
# Should return 200
```

Confirm TypeScript compiles cleanly:

```bash
yarn tsc --noEmit
```
