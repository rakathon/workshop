# TypeScript Language Guides

## Directory purpose

TypeScript-specific implementation guides for rr-standards. Guides are separated by
runtime target (`node/` for backend Node.js services, `react/` for frontend React
applications) and versioned by language era under subdirectories; `default/` within
each runtime is the target for all new TypeScript work.

## File index

| Entry | Purpose | When to reference |
|-------|---------|-------------------|
| `node/` | TypeScript/Node.js guides for backend HTTP services | Any TypeScript code running in Node.js (Express, REST APIs, server-side tooling) |
| `node/default/` | Guides for current TypeScript/Node.js (the default target) | All new Node.js TypeScript code unless a specific older version is required |
| `react/` | TypeScript/React guides for frontend applications | Any TypeScript code running in a React application |
| `react/default/` | Guides for current TypeScript/React (the default target) | All new React TypeScript code unless a specific older version is required |

## Navigation

- [Standards library](../../standards/) — language-agnostic standards these guides implement
