# TypeScript/Node.js Guide — REST API Data

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/data.md@1.0.1

## Overview

Shows how to satisfy the REST API Data standard in a Node.js/Express service using
TypeScript. Covers cursor-based and offset pagination with Express route handlers;
ISO 8601 UTC timestamp serialization; decimal and currency value/scale encoding;
optimistic concurrency with `version_token` and 409 conflict responses; OpenTelemetry
header propagation; and `Accept-Language`-driven response localization. An Express
service that follows this guide will produce data representations, pagination shapes,
and concurrency behavior that comply with the standard.

## Related standard

[REST API Data](../../../../../../../standards/api/rest/data.md)

## Prerequisites

- Node.js 20+
- TypeScript 5.x (`typescript ^5.6.3`)
- Express 4.x (`express ^4.21.2`, `@types/express ^4.17.21`)
- `@opentelemetry/api ^1.9.0` — read and forward `traceparent`/`tracestate` headers (R-7)
- `uuid ^10.0.0` — generate UUID version tokens for optimistic concurrency (R-3)

## Implementation

### Pagination (R-1, R-2)

Cursor-based pagination is the default. Accept `cursor` and `limit` query params; return
`pagination.next` on the response. Omit `next` on the last page. Only include
`pagination.previous` when a client use case requires backward navigation. Use
offset-based pagination only when the UI requires page-number display.

```typescript
// src/middleware/pagination.ts
export interface CursorPage<T> {
  data: T[]
  pagination: { next?: string; previous?: string }
}

export interface OffsetPage<T> {
  data: T[]
  pagination: { num_pages: number; num_results: number }
}

// Cursor-based (default)
export function cursorResponse<T>(
  data: T[],
  next: string | undefined,
  previous?: string
): CursorPage<T> {
  const pagination: CursorPage<T>['pagination'] = {}
  if (next !== undefined) pagination.next = next
  if (previous !== undefined) pagination.previous = previous
  return { data, pagination }
}

// Offset-based (only when UI requires page numbers)
export function offsetResponse<T>(
  data: T[],
  numPages: number,
  numResults: number
): OffsetPage<T> {
  return { data, pagination: { num_pages: numPages, num_results: numResults } }
}
```

```typescript
// Example route — cursor-based collection endpoint
import { Request, Response } from 'express'
import { cursorResponse } from '../middleware/pagination'

router.get('/items', async (req: Request, res: Response): Promise<void> => {
  const cursor = req.query.cursor as string | undefined
  const limit = Math.min(Number(req.query.limit ?? 20), 100)

  const { items, nextCursor } = await itemService.list({ cursor, limit })

  res.json(cursorResponse(items, nextCursor))
  // nextCursor is undefined on the last page → pagination.next is omitted
})
```

### Optimistic concurrency (R-3)

Every resource that supports concurrent writes must include a `version_token` field.
Clients echo it back unchanged on PUT/PATCH. Reject mismatches with HTTP 409 and include
the latest entity state in the response body.

```typescript
import { v4 as uuidv4 } from 'uuid'

// When creating or updating a resource, generate a new version_token
export function nextVersionToken(): string {
  return uuidv4()
}
```

```typescript
// PUT handler with optimistic concurrency check
router.put('/items/:item_id', async (req: Request, res: Response): Promise<void> => {
  const { item_id } = req.params
  const { version_token, ...updates } = req.body

  const current = await itemService.getById(item_id)
  if (!current) {
    res.status(404).json({ errors: [{ code: 'NOT_FOUND', message: 'Item not found' }] })
    return
  }

  if (current.version_token !== version_token) {
    // Return latest entity state so client can re-apply their change without a second round-trip
    res.status(409).json({
      errors: [{ code: 'VERSION_CONFLICT', message: 'Resource was modified by another request' }],
      data: current,
    })
    return
  }

  const updated = await itemService.update(item_id, { ...updates, version_token: nextVersionToken() })
  res.json({ data: updated })
})
```

### Timestamps (R-4)

Serialize all timestamps as `YYYY-MM-DDTHH:MM:SSZ` strings. Never send a JS `Date`
object or Unix epoch number directly on the wire.

```typescript
// src/utils/time.ts

/** Serialize a Date to ISO 8601 UTC, truncated to seconds. */
export function toTimestamp(date: Date): string {
  return date.toISOString().replace(/\.\d{3}Z$/, 'Z')
  // "2024-03-15T14:30:00.000Z" → "2024-03-15T14:30:00Z"
}

/** Parse an ISO 8601 UTC timestamp string back to a Date. */
export function fromTimestamp(value: string): Date {
  return new Date(value)
}
```

```typescript
// In response serialization — always call toTimestamp() before sending
res.json({
  data: {
    id: item.id,
    name: item.name,
    created_at: toTimestamp(item.createdAt),   // ✓ "2024-03-15T14:30:00Z"
    updated_at: toTimestamp(item.updatedAt),
    // Wrong: created_at: item.createdAt        ← Date object serializes as full ISO with ms
    // Wrong: created_at: item.createdAt.getTime() ← Unix ms epoch number
  }
})
```

### Decimal numbers (R-5)

Represent precision-sensitive decimals as `{ value: number, scale: number }` where the
real value equals `value × 10^(−scale)`. Never use a JSON floating-point for monetary,
percentage, or other precision-sensitive values.

```typescript
// src/types/decimal.ts
export interface Decimal {
  value: number   // integer
  scale: number   // non-negative integer
}

/** Encode a decimal string (e.g. "12.34") to a Decimal object. */
export function toDecimal(raw: string): Decimal {
  const [intPart, fracPart = ''] = raw.split('.')
  const scale = fracPart.length
  const value = parseInt(`${intPart}${fracPart}`, 10)
  return { value, scale }
}

/** Decode a Decimal back to a numeric string. */
export function fromDecimal({ value, scale }: Decimal): string {
  if (scale === 0) return String(value)
  const str = String(Math.abs(value)).padStart(scale + 1, '0')
  const int = str.slice(0, -scale) || '0'
  const frac = str.slice(-scale)
  return `${value < 0 ? '-' : ''}${int}.${frac}`
}
```

```typescript
// In a response body — use Decimal objects, never raw floats
res.json({
  data: {
    price: toDecimal('12.34'),   // { value: 1234, scale: 2 }  ✓
    tax_rate: toDecimal('0.15'), // { value: 15,   scale: 2 }  ✓
    // Wrong: price: 12.34       ← JSON float, rounding error possible
  }
})
```

### Currency amounts (R-6)

Represent currency amounts as `{ amount: number, currency: string, scale: number }` using
an ISO 4217 currency code.

```typescript
// src/types/currency.ts
export interface CurrencyAmount {
  amount: number    // integer
  currency: string  // ISO 4217 code, e.g. "USD", "JPY"
  scale: number     // non-negative integer
}

export function toCurrencyAmount(
  amountStr: string,
  currency: string
): CurrencyAmount {
  const { value, scale } = toDecimal(amountStr)
  return { amount: value, currency, scale }
}
```

```typescript
// In a response body
res.json({
  data: {
    total: toCurrencyAmount('10.50', 'USD'),  // { amount: 1050, currency: 'USD', scale: 2 }  ✓
    tax:   toCurrencyAmount('0.84', 'USD'),   // { amount: 84,   currency: 'USD', scale: 2 }  ✓
    // JPY has no decimal places
    fee:   { amount: 500, currency: 'JPY', scale: 0 },
  }
})
```

### Distributed tracing (R-7)

Propagate `traceparent` and `tracestate` headers on every outbound service call using
`@opentelemetry/api`. Read the headers from the incoming request and forward them
downstream.

```typescript
// src/middleware/tracing.ts
import { context, propagation, ROOT_CONTEXT } from '@opentelemetry/api'
import { Request, Response, NextFunction } from 'express'

/**
 * Extract W3C trace context from incoming headers and attach it to the
 * async-local context so downstream calls can propagate it.
 */
export function tracingMiddleware(req: Request, _res: Response, next: NextFunction): void {
  const extracted = propagation.extract(ROOT_CONTEXT, req.headers)
  context.with(extracted, next)
}
```

```typescript
// src/core/app.ts — attach before all route handlers
import { tracingMiddleware } from './middleware/tracing'

app.use(tracingMiddleware)
```

```typescript
// src/clients/serviceClient.ts — forward trace context on outbound calls
import { context, propagation } from '@opentelemetry/api'

export async function callDownstream(url: string, body: unknown): Promise<Response> {
  const headers: Record<string, string> = { 'content-type': 'application/json' }
  // Inject current trace context into outbound headers
  propagation.inject(context.active(), headers)
  // headers now contains traceparent and tracestate (if present)
  return fetch(url, { method: 'POST', headers, body: JSON.stringify(body) })
}
```

### Localization (R-8)

Parse the `Accept-Language` header, respect quality weighting, and return localized
content for the best available match. Fall back to the region default when no accepted
locale is available or the header is absent.

```typescript
// src/utils/locale.ts

const SUPPORTED_LOCALES = ['en-US', 'en', 'ja', 'fr-FR', 'fr'] as const
type SupportedLocale = typeof SUPPORTED_LOCALES[number]
const DEFAULT_LOCALE: SupportedLocale = 'en-US'

/**
 * Parse Accept-Language header and return the best supported locale.
 * Respects quality weighting (e.g. "en-US,en;q=0.9,ja;q=0.8").
 */
export function negotiateLocale(acceptLanguage: string | undefined): SupportedLocale {
  if (!acceptLanguage) return DEFAULT_LOCALE

  const candidates = acceptLanguage
    .split(',')
    .map(part => {
      const [tag, q] = part.trim().split(';q=')
      return { tag: tag.trim(), q: q !== undefined ? parseFloat(q) : 1.0 }
    })
    .sort((a, b) => b.q - a.q)

  for (const { tag } of candidates) {
    // Exact match first
    const exact = SUPPORTED_LOCALES.find(l => l.toLowerCase() === tag.toLowerCase())
    if (exact) return exact
    // Language-only fallback (e.g. "en-GB" → "en")
    const lang = tag.split('-')[0].toLowerCase()
    const fallback = SUPPORTED_LOCALES.find(l => l.toLowerCase() === lang)
    if (fallback) return fallback
  }

  return DEFAULT_LOCALE
}
```

```typescript
// In a route handler — resolve locale and pass to service
router.get('/items/:item_id', async (req: Request, res: Response): Promise<void> => {
  const locale = negotiateLocale(req.headers['accept-language'])
  const item = await itemService.getById(req.params.item_id, { locale })
  res.json({ data: item })
})
```

## Verification

1. Check all collection endpoints cap results — every `router.get(...)` that returns an
   array must call `cursorResponse()` or `offsetResponse()`:
   ```bash
   grep -rn 'res\.json' src/ | grep -v 'pagination\|cursorResponse\|offsetResponse'
   ```
   Any collection response not going through one of these helpers is a R-1/R-2 violation.

2. Confirm every write endpoint reads and echoes `version_token`:
   ```bash
   grep -rn 'router\.put\|router\.patch' src/ | xargs grep -L 'version_token'
   ```
   Any file listed does not implement R-3 — add the concurrency check.

3. Search for bare Date objects or epoch numbers in response bodies:
   ```bash
   grep -rn '\.getTime()\|new Date(' src/ | grep 'res\.json'
   ```
   Any match is a R-4 violation — replace with `toTimestamp()`.

4. Search for raw floating-point numeric literals in response bodies:
   ```bash
   grep -rn 'res\.json' src/ | grep -E '[0-9]+\.[0-9]+'
   ```
   Review each match — monetary, percentage, or precision-sensitive values must use
   `toDecimal()` or `toCurrencyAmount()` instead.

5. Confirm `tracingMiddleware` is registered before all route handlers in `app.ts`:
   ```bash
   grep -n 'tracingMiddleware\|app\.use' src/core/app.ts
   ```
   `tracingMiddleware` must appear before the first route `app.use()` call.

6. Run the linter — all source files must pass with no errors:
   ```bash
   yarn lint
   ```
