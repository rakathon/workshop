// fixtures/compliant-protocol.ts
// A realistic Express service satisfying all REST API Protocol standard rules.
// Referenced by protocol.test.yaml as a whole-file compliant example.

import { Request, Response, NextFunction, Router } from 'express'
import compression from 'compression'
import { v4 as uuidv4 } from 'uuid'

// ── R-5, R-6: Response envelope types ────────────────────────────────────────

interface Meta {
  status: { code: string }
  operation: { request_id: string }  // R-6: UUID per response
}

interface DataResponse<T> { data: T; meta: Meta }
interface ListResponse<T> { data: T[]; pagination?: { next?: string }; meta: Meta }
interface ErrorDetail { code: string; message: string; details?: { field: string; value?: unknown; constraint?: string }; trace_id?: string }
interface ErrorResponse { errors: ErrorDetail[]; meta: Meta }

// R-6: always generate a fresh UUID request_id
function makeMeta(statusCode: string): Meta {
  return { status: { code: statusCode }, operation: { request_id: uuidv4() } }
}

// ── R-1, R-2: Client-Agent middleware ─────────────────────────────────────────

// R-4: gzip compression — registered at app level (not shown here; see app.ts)
// app.use(compression())

/**
 * R-1: Require Client-Agent header on all requests.
 * R-2: Header is "Client-Agent" — not "X-Client-Agent" (no X- prefix).
 */
export function requireClientAgent(req: Request, res: Response, next: NextFunction): void {
  if (!req.headers['client-agent']) {
    res.status(400).json({
      errors: [{ code: 'MISSING_CLIENT_AGENT', message: 'Client-Agent header is required' }],
      meta: makeMeta('BadRequest'),
    } satisfies ErrorResponse)
    return
  }
  next()
}

// ── R-5, R-6, R-7: Success response helpers ───────────────────────────────────

const router = Router()

// R-5: single-entity success — data + meta (no errors, no pagination)
router.get('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const store = await storeService.getById(req.params.store_id)
  if (!store) throw new NotFoundError('Store not found')
  // R-5: data + meta only on success — no errors key
  res.status(200).json({ data: store, meta: makeMeta('OK') } satisfies DataResponse<typeof store>)
})

// R-5: collection success — data + pagination + meta
router.get('/stores', async (req: Request, res: Response): Promise<void> => {
  const cursor = req.query.cursor as string | undefined
  const limit = Math.min(Number(req.query.limit ?? 20), 100)
  const { stores, nextCursor } = await storeService.list({ cursor, limit })
  const body: ListResponse<typeof stores[0]> = { data: stores, meta: makeMeta('OK') }
  if (nextCursor) body.pagination = { next: nextCursor }
  res.status(200).json(body)
})

// R-7: POST create returns 201 + Location (never 200)
router.post('/stores', async (req: Request, res: Response): Promise<void> => {
  const created = await storeService.create(req.body)
  res.status(201)
    .location(`/stores/v1/stores/${created.id}`)  // R-7: Location header required
    .json({ data: created, meta: makeMeta('Created') } satisfies DataResponse<typeof created>)
})

// ── R-3, R-5, R-7, R-8: Global error handler ──────────────────────────────────

class NotFoundError extends Error { readonly statusCode = 404; readonly code = 'NOT_FOUND' }
class ValidationError extends Error {
  readonly statusCode = 400; readonly code = 'VALIDATION_ERROR'
  constructor(message: string, readonly field?: string) { super(message) }
}
class BusinessRuleError extends Error {
  readonly statusCode = 422; readonly code: string  // R-7: 422 for business rule failures
  constructor(code: string, message: string) { super(message); this.code = code }
}
class RateLimitError extends Error {
  readonly statusCode = 429; readonly code = 'RATE_LIMIT_EXCEEDED'
  constructor(readonly retryAfterSeconds: number) { super('Rate limit exceeded') }
}
class ServiceUnavailableError extends Error {
  readonly statusCode = 503; readonly code = 'SERVICE_UNAVAILABLE'
  constructor(readonly retryAfterSeconds: number) { super('Service temporarily unavailable') }
}
class VersionConflictError extends Error {
  readonly statusCode = 409; readonly code = 'VERSION_CONFLICT'
  constructor(readonly currentState: unknown) { super('Version conflict') }
}

export function globalErrorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction): void {
  // R-7: 409 — R-5 exception: 409 must also include data with current entity state
  if (err instanceof VersionConflictError) {
    res.status(409).json({ errors: [{ code: err.code, message: err.message }], data: err.currentState, meta: makeMeta('Conflict') })
    return
  }
  // R-3: Retry-After on 429 and 503
  if (err instanceof RateLimitError) {
    res.status(429).set('Retry-After', String(err.retryAfterSeconds))
      .json(errBody(err.code, err.message, 'TooManyRequests'))
    return
  }
  if (err instanceof ServiceUnavailableError) {
    res.status(503).set('Retry-After', String(err.retryAfterSeconds))
      .json(errBody(err.code, err.message, 'ServiceUnavailable'))
    return
  }
  if (err instanceof NotFoundError) { res.status(404).json(errBody(err.code, err.message, 'NotFound')); return }
  if (err instanceof ValidationError) {
    const body = errBody(err.code, err.message, 'BadRequest')
    if (err.field) body.errors[0].details = { field: err.field }  // R-8: optional details with field
    res.status(400).json(body); return
  }
  if (err instanceof BusinessRuleError) {
    // R-7: 422 for business rule violations — not 400
    res.status(422).json(errBody(err.code, err.message, 'UnprocessableEntity')); return
  }
  // R-7: NEVER return 200 for errors — catch-all is 500
  res.status(500).json(errBody('INTERNAL_ERROR', 'An unexpected error occurred', 'InternalError'))
}

// R-5, R-8: error responses have errors + meta ONLY — no data field
function errBody(code: string, message: string, statusCode: string): ErrorResponse {
  return { errors: [{ code, message }], meta: makeMeta(statusCode) }
}

export { router }

// Stub service declarations
declare const storeService: {
  getById(id: string): Promise<{ id: string; name: string } | null>
  list(opts: { cursor?: string; limit: number }): Promise<{ stores: { id: string }[]; nextCursor?: string }>
  create(data: unknown): Promise<{ id: string }>
}
