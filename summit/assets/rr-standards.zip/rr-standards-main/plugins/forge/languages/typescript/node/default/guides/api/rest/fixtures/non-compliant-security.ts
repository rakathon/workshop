// fixtures/non-compliant-security.ts
// This code violates several rules from the REST API Security standard.
// It looks like plausible production TypeScript/Express but contains multiple violations.

import { Request, Response, NextFunction, Router } from 'express'
import jwt from 'jsonwebtoken'

const publicRouter = Router()
const adminRouter = Router()
const internalRouter = Router()

// ── R-1 VIOLATIONS ────────────────────────────────────────────────────────────

// R-1 VIOLATION: member-scoped public endpoint has no authentication middleware
publicRouter.get(
  '/regions/:region_id/members/:member_guid/experiences/:experience_name',
  // R-1 VIOLATION: no ebtokenAuth middleware — member data accessible without credentials
  getExperienceHandler
)

// R-1 VIOLATION: only checks Authorization header — ignores euid cookie
// A browser client sending euid cookie will be rejected even with a valid token
export function incompleteEbtokenAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization']
  if (!authHeader?.startsWith('Bearer ')) {
    // R-1 VIOLATION: rejects valid euid cookie requests — cookie is a required alternative
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Bearer token required' }] })
    return
  }
  try {
    jwt.verify(authHeader.slice(7), process.env.EBTOKEN_PUBLIC_KEY!)
    next()
  } catch {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Invalid token' }] })
  }
}

publicRouter.get(
  '/regions/:region_id/members/:member_guid/offers',
  incompleteEbtokenAuth,  // R-1 VIOLATION: ignores euid cookie — only Bearer accepted
  listMemberOffersHandler
)

// ── R-2 VIOLATIONS ────────────────────────────────────────────────────────────

// R-2 VIOLATION: admin endpoint has no JWT validation whatsoever
adminRouter.get(
  '/stores',
  // R-2 VIOLATION: no requireAdminRole middleware — anyone can access admin endpoints
  listAllStoresHandler
)

// R-2 VIOLATION: validates JWT but skips role check — anyone with a valid token can admin
export function jwtButNoRoleCheck(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization']
  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Bearer token required' }] })
    return
  }
  try {
    jwt.verify(authHeader.slice(7), process.env.ADMIN_JWT_PUBLIC_KEY!)
    // R-2 VIOLATION: token is validated but roles are never checked
    // Any authenticated user can reach admin endpoints regardless of their role
    next()
  } catch {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Invalid token' }] })
  }
}

adminRouter.delete(
  '/stores/:store_id',
  jwtButNoRoleCheck,  // R-2 VIOLATION: no role check — privilege escalation possible
  deleteStoreHandler
)

// R-2 VIOLATION: returns 403 for missing token instead of 401
export function wrongStatusOnMissingToken(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization']
  if (!authHeader?.startsWith('Bearer ')) {
    // R-2 VIOLATION: 403 Forbidden for missing token — should be 401 Unauthorized
    res.status(403).json({ errors: [{ code: 'FORBIDDEN', message: 'Token required' }] })
    return
  }
  try {
    const claims = jwt.verify(authHeader.slice(7), process.env.ADMIN_JWT_PUBLIC_KEY!) as { roles: string[] }
    if (!claims.roles.includes('store_admin')) {
      res.status(403).json({ errors: [{ code: 'FORBIDDEN', message: 'Role required' }] })
      return
    }
    next()
  } catch {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Invalid token' }] })
  }
}

// ── R-3 VIOLATIONS ────────────────────────────────────────────────────────────

// R-3 VIOLATION: sensitive balance endpoint has no s2sAuth middleware
internalRouter.put(
  '/regions/:region_id/members/:member_id/balance',
  // R-3 VIOLATION: modifying member balance is a sensitive operation — s2sAuth required
  updateBalanceHandler
)

// R-3 VIOLATION: PII endpoint uses ebtokenAuth instead of s2sAuth
// ebtokenAuth is for public member-facing endpoints, not for server-to-server -int calls
export function ebtokenAuthOnInternalRoute(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization']
  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Token required' }] })
    return
  }
  try {
    // R-3 VIOLATION: validates as an ebtoken (member JWT) — should validate as s2s token
    jwt.verify(authHeader.slice(7), process.env.EBTOKEN_PUBLIC_KEY!)
    next()
  } catch {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Invalid token' }] })
  }
}

internalRouter.get(
  '/regions/:region_id/members/:member_id/profile',
  ebtokenAuthOnInternalRoute,  // R-3 VIOLATION: wrong auth strategy for sensitive -int route
  getMemberProfileHandler
)

export { publicRouter, adminRouter, internalRouter }

// Stub handler declarations
declare function getExperienceHandler(req: Request, res: Response): void
declare function listMemberOffersHandler(req: Request, res: Response): void
declare function listAllStoresHandler(req: Request, res: Response): void
declare function deleteStoreHandler(req: Request, res: Response): void
declare function updateBalanceHandler(req: Request, res: Response): void
declare function getMemberProfileHandler(req: Request, res: Response): void
