---
guide_version: 1.0.0
implements: standards/frontend/responsive-layout.md@1.0.0
---

# Responsive Layout — TypeScript/React Implementation

Guide: 1.0.0 | Implements: standards/frontend/responsive-layout.md@1.0.0

## Overview

Concrete patterns for mobile-first responsive layout using the UIKit breakpoint system.
All examples use the Chakra responsive object syntax with UIKit theme keys.

## Related standard

[`standards/frontend/responsive-layout.md`](../../../../../../standards/frontend/responsive-layout.md)

## Prerequisites

- `@rakuten-rewards/uikit` installed and theme applied via AppShell `next.config.js`

## Implementation

### Breakpoint reference

Use only these keys (responsive-layout.md R-2). Most layouts need only `base`,
`medium`, and `large`:

```tsx
// base    — mobile (< 600px) — always required as the starting value
// medium  — tablet (≥ 600px) — most common second breakpoint
// large   — desktop (≥ 1440px) — desktop layout

// Fine-grained breakpoints (use only when design requires):
// smallMd — 360px   smallLg  — 400px
// mediumMd — 960px  mediumLg — 1280px
// largeMd  — 1600px largeLg  — 1920px
```

### Standard section vertical padding (responsive-layout.md R-3)

Every top-level page section must use this pattern:

```tsx
<Background bg="palette.purple_05" py={{ base: 'xlarge', medium: 'xxlarge' }}>
  <Container>
    {/* section content */}
  </Container>
</Background>
```

`xlarge` = 48px on mobile, `xxlarge` = 64px on tablet and above.

### Standard grid column progressions (responsive-layout.md R-4)

```tsx
// 3-column content grid (how-it-works, feature icons)
templateColumns={{ base: '1fr', medium: 'repeat(3, 1fr)' }}

// 2-column content grid (text + image, split layout)
templateColumns={{ base: '1fr', medium: 'repeat(2, 1fr)' }}

// 4-column stat grid
templateColumns={{ base: 'repeat(2, 1fr)', medium: 'repeat(4, 1fr)' }}

// Store/product grid
templateColumns={{ base: 'repeat(2, 1fr)', medium: 'repeat(3, 1fr)', large: 'repeat(4, 1fr)' }}
```

### Responsive typography

`<Heading>` and `<Paragraph>` handle responsive sizing internally via `textStyle`.
Don't override with responsive `fontSize`:

```tsx
// Correct — textStyle encodes the responsive scale
<Heading as="h1" textStyle="h1">Page Title</Heading>
// h1: 32px mobile → 48px desktop

<Heading as="h2" textStyle="h2">Section Heading</Heading>
// h2: 28px mobile → 40px desktop

// Only use responsive fontSize for non-heading Text where no textStyle fits
<Text fontSize={{ base: 'body', medium: 'large' }}>Custom label</Text>
```

### Responsive visibility

```tsx
// Show on desktop only
<Box display={{ base: 'none', large: 'block' }}>
  <DesktopNav />
</Box>

// Show on mobile only
<Box display={{ base: 'block', medium: 'none' }}>
  <MobileMenu />
</Box>
```

### Responsive spacing

```tsx
// Section-level gap (between major sections)
<VStack spacing={{ base: 'xlarge', medium: 'xxlarge' }}>

// Component-level gap (between cards in a grid)
<Grid gap={{ base: 'medium', medium: 'large' }}>

// Inline padding adjustment
<Box px={{ base: 'medium', medium: 'xlarge' }}>
```

### Complete section examples

#### Hero with gradient background

```tsx
<Background
  bg="linear-gradient(135deg, #8529cd 0%, #480081 100%)"
  py={{ base: 'xlarge', medium: 'xxlarge' }}
>
  <Container maxW="800px">
    <VStack spacing="large" textAlign="center">
      <Heading as="h1" textStyle="h1" color="text.inverse">
        Hero Headline
      </Heading>
      <Paragraph fontSize="large" color="text.inverse">
        Supporting text that describes the value proposition.
      </Paragraph>
      <HStack spacing="medium" justify="center" flexWrap="wrap">
        <Button variant="primary" size="large">Primary CTA</Button>
        <Button variant="secondary" size="large" isInverse>Secondary CTA</Button>
      </HStack>
    </VStack>
  </Container>
</Background>
```

#### 3-column feature/steps section

```tsx
<Background bg="palette.purple_05" py={{ base: 'xlarge', medium: 'xxlarge' }}>
  <Container>
    <VStack spacing="xlarge">
      <Heading as="h2" textStyle="h2" textAlign="center" color="text.primary">
        How It Works
      </Heading>
      <Grid
        templateColumns={{ base: '1fr', medium: 'repeat(3, 1fr)' }}
        gap="large"
        w="100%"
      >
        {steps.map((step) => (
          <GridItem key={step.id}>
            <VStack spacing="medium" align="center" textAlign="center">
              <Box
                bg="fill.default"
                borderRadius="50%"
                w="80px"
                h="80px"
                display="flex"
                alignItems="center"
                justifyContent="center"
                boxShadow="default"
              >
                <Image src={step.icon} alt={step.iconAlt} w="40px" h="40px" />
              </Box>
              <Heading as="h3" textStyle="descriptor" color="text.primary">
                {step.title}
              </Heading>
              <Paragraph color="text.secondary">{step.description}</Paragraph>
            </VStack>
          </GridItem>
        ))}
      </Grid>
    </VStack>
  </Container>
</Background>
```

#### Stats grid

```tsx
<Background bg="fill.sectionInversePrimary" py={{ base: 'xlarge', medium: 'xxlarge' }}>
  <Container>
    <Grid
      templateColumns={{ base: 'repeat(2, 1fr)', medium: 'repeat(4, 1fr)' }}
      gap={{ base: 'large', medium: 'xlarge' }}
    >
      {stats.map((stat) => (
        <GridItem key={stat.label} textAlign="center">
          <Heading as="h3" textStyle="h2" color="text.cashback">{stat.value}</Heading>
          <Paragraph color="text.inverse">{stat.label}</Paragraph>
        </GridItem>
      ))}
    </Grid>
  </Container>
</Background>
```

#### Final CTA section

```tsx
<Background bg="fill.ctaPrimary" py={{ base: 'xlarge', medium: 'xxlarge' }}>
  <Container maxW="600px">
    <VStack spacing="large" textAlign="center">
      <Heading as="h2" textStyle="h2" color="text.inverse">
        Ready to start earning?
      </Heading>
      <Paragraph color="text.inverse">
        Join 17 million members earning Cash Back every day.
      </Paragraph>
      <Button variant="primary" size="large" isInverse>
        Join Free
      </Button>
      <Text fontSize="body" color="text.inverse" opacity={0.7}>
        Free to join. No fees ever.
      </Text>
    </VStack>
  </Container>
</Background>
```

### Background color progression

Use this sequence when stacking multiple page sections to create visual rhythm:

```tsx
bg="fill.default"        // white — neutral sections
bg="palette.purple_05"   // #F4F3FE — very subtle tint
bg="palette.purple_15"   // #E4E0FC — light purple
bg="palette.purple_25"   // #CFC0FF — medium purple
bg="palette.purple_400"  // #480081 — deep purple (use sparingly)
bg="fill.ctaPrimary"     // #8529CD — brand purple (CTA sections)
bg="fill.sectionInversePrimary"  // #242463 — dark blue
```

## Verification

Check that no breakpoints outside the allowed set are used:

```bash
# Find any use of Chakra default breakpoints (sm, md, lg, xl, 2xl) — should be empty
grep -rn '"sm":\|"md":\|"lg":\|"xl":\|"2xl":' src/
```

Confirm mobile-first baseline is always set:

```bash
# Find responsive objects without a 'base' key — a proxy check
# (manual review required for full coverage)
grep -rn 'medium:.*large:' src/ | grep -v 'base:'
```
