import { loadConfig, type E2EConfig } from '../api/config'
import { doGet, doPost, doDelete, urlJoin, bearerAuth } from '../api/helpers'

// SC-1 | Verifies: BR-1 — validates the earn-points flow against the real deployed service.
// Non-production only — creates and deletes test transactions.
describe('sc1_earn_and_verify_points', () => {
  let config: E2EConfig

  beforeAll(async () => {
    if (process.env.E2E_SKIP === 'true') return
    config = await loadConfig()
  })

  it('sc1_earn_and_verify_points', async () => {
    if (process.env.E2E_SKIP === 'true') {
      console.warn('E2E tests skipped — config unavailable')
      return
    }

    if (process.env.ENVIRONMENT_TO_TEST === 'production') {
      console.warn('SC-1 creates test data — skipping in production environment')
      return
    }

    const base = config.baseUrl

    // Unique per test run — parallel-safe, traceable synthetic data (R-4, R-8)
    const memberId = `test-member-${Date.now()}`

    // Step 1: Capture pre-earn balance
    const balanceResp = await doGet(
      urlJoin(base, `/points/v1/members/${memberId}/balance`),
      bearerAuth(config.authToken!),
    )
    expect(balanceResp.status).toBe(200)
    const beforeBalance: number = balanceResp.data.data.balance

    // Step 2: Earn points via a qualifying transaction
    const earnResp = await doPost(
      urlJoin(base, `/points/v1/members/${memberId}/transactions`),
      { amount_cents: 1000, merchant_id: 'merchant-e2e' },
      bearerAuth(config.authToken!),
    )
    expect(earnResp.status).toBe(201)
    const transactionId: string = earnResp.data.data.transaction_id
    const pointsEarned: number = earnResp.data.data.points_earned
    expect(transactionId).toBeTruthy()
    expect(pointsEarned).toBeGreaterThan(0)

    // Register cleanup immediately after resource creation — runs even if later assertions fail
    afterAll(async () => {
      await doDelete(
        urlJoin(base, `/points/v1/members/${memberId}/transactions/${transactionId}`),
        bearerAuth(config.authToken!),
      )
    })

    // Step 3: Verify the balance increased by the earned points (complete observable journey)
    const afterResp = await doGet(
      urlJoin(base, `/points/v1/members/${memberId}/balance`),
      bearerAuth(config.authToken!),
    )
    expect(afterResp.status).toBe(200)
    expect(afterResp.data.data.balance).toBe(beforeBalance + pointsEarned)
  })
})
