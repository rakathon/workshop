// fixtures/compliant-security.ts
// A realistic Express service satisfying all REST API Security standard rules.
// Referenced by security.test.yaml as a whole-file compliant example.

import { Request, Response, NextFunction, Router } from 'express'
import jwt from 'jsonwebtoken'
import cookieParser from 'cookie-parser'

// ── R-1: Public contract — ebtoken authentication ─────────────────────────────

export interface MemberClaims { memberId: string; region: string }

/**
 * R-1: Authenticate member-data requests.
 * Accepts Authorization: Bearer <ebtoken>  OR  Cookie: euid=<ebtoken>
 * Returns 401 on missing or invalid token.
 */
export function ebtokenAuth(req: Request, res: Response, next: NextFunction): void {
  const token = extractEbtoken(req)
  if (!token) {
    // 401 — no credential provided
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'ebtoken required' }] })
    return
  }
  try {
    const claims = jwt.verify(token, process.env.EBTOKEN_PUBLIC_KEY!) as MemberClaims
    res.locals.member = claims
    next()
  } catch {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Invalid or expired ebtoken' }] })
  }
}

function extractEbtoken(req: Request): string | null {
  // R-1: accept Bearer header first
  const authHeader = req.headers['authorization']
  if (authHeader?.startsWith('Bearer ')) return authHeader.slice(7)
  // R-1: accept euid cookie as alternative (browser clients)
  return (req.cookies as Record<string, string>)['euid'] ?? null
}

// Public router — cookie-parser required before ebtokenAuth
// app.use(cookieParser())
// app.use('/purchase_experience/v1', publicRouter)

const publicRouter = Router()

// Non-member-data endpoint — no auth required
publicRouter.get('/stores', listStoresHandler)

// R-1: member-scoped endpoints require ebtokenAuth
publicRouter.get(
  '/regions/:region_id/members/:member_guid/experiences/:experience_name',
  ebtokenAuth,      // R-1: validates Bearer OR euid cookie
  getExperienceHandler
)
publicRouter.get(
  '/regions/:region_id/members/:member_guid/offers',
  ebtokenAuth,
  listMemberOffersHandler
)

// ── R-2: Admin contract — JWT + expiry + role ─────────────────────────────────

export interface AdminClaims { operatorId: string; roles: string[] }

/**
 * R-2: Validate JWT signature, expiry, AND required role.
 * All three checks must pass — skipping any one is non-compliant.
 * Returns 401 on invalid/missing token; 403 on insufficient role.
 */
export function requireAdminRole(role: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const authHeader = req.headers['authorization']
    if (!authHeader?.startsWith('Bearer ')) {
      res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Bearer token required' }] })
      return
    }
    let claims: AdminClaims
    try {
      // R-2: jwt.verify checks both signature AND expiry
      claims = jwt.verify(authHeader.slice(7), process.env.ADMIN_JWT_PUBLIC_KEY!) as AdminClaims
    } catch {
      res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Invalid or expired admin token' }] })
      return
    }
    // R-2: role check — insufficient role → 403 (not 401)
    if (!claims.roles.includes(role)) {
      res.status(403).json({ errors: [{ code: 'FORBIDDEN', message: `Role '${role}' required` }] })
      return
    }
    res.locals.operator = claims
    next()
  }
}

// Admin router — every route uses requireAdminRole
// app.use('/purchase_experience-admin/v1', adminRouter)

const adminRouter = Router()

adminRouter.get(
  '/stores',
  requireAdminRole('store_admin'),   // R-2: all three checks on every admin route
  listAllStoresHandler
)
adminRouter.delete(
  '/stores/:store_id',
  requireAdminRole('store_admin'),
  deleteStoreHandler
)

// ── R-3: Internal contract — S2S auth on sensitive endpoints ──────────────────

export interface ServiceIdentity { serviceId: string }

/**
 * R-3: Validate server-to-server token on sensitive -int endpoints.
 * Returns 401 on missing or invalid token.
 */
export function s2sAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization']
  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Server-to-server token required' }] })
    return
  }
  try {
    const identity = jwt.verify(authHeader.slice(7), process.env.S2S_PUBLIC_KEY!) as ServiceIdentity
    res.locals.service = identity
    next()
  } catch {
    res.status(401).json({ errors: [{ code: 'UNAUTHORIZED', message: 'Invalid server-to-server token' }] })
  }
}

// Internal router
// app.use('/wallet-int/v1', internalRouter)

const internalRouter = Router()

// R-3: sensitive — modifies member balance → s2sAuth required
internalRouter.put('/regions/:region_id/members/:member_id/balance', s2sAuth, updateBalanceHandler)

// R-3: sensitive — accesses PII → s2sAuth required
internalRouter.get('/regions/:region_id/members/:member_id/profile', s2sAuth, getMemberProfileHandler)

// R-3: sensitive — payment method change → s2sAuth required
internalRouter.put('/regions/:region_id/members/:member_id/payment_method', s2sAuth, updatePaymentHandler)

// Non-sensitive internal route — no s2sAuth required per R-3
internalRouter.get('/platform_configs', listPlatformConfigsHandler)

export { publicRouter, adminRouter, internalRouter }

// Stub handler declarations
declare function listStoresHandler(req: Request, res: Response): void
declare function getExperienceHandler(req: Request, res: Response): void
declare function listMemberOffersHandler(req: Request, res: Response): void
declare function listAllStoresHandler(req: Request, res: Response): void
declare function deleteStoreHandler(req: Request, res: Response): void
declare function updateBalanceHandler(req: Request, res: Response): void
declare function getMemberProfileHandler(req: Request, res: Response): void
declare function updatePaymentHandler(req: Request, res: Response): void
declare function listPlatformConfigsHandler(req: Request, res: Response): void
