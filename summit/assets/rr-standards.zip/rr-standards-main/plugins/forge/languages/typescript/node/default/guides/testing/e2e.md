# TypeScript/Node.js Guide — End-to-End Testing

Guide: 1.0.1 | Implements: standards/testing/e2e.md@1.0.0

## Overview

Shows how to write end-to-end tests for a TypeScript/Node.js HTTP service using
Jest (via `ts-jest`) and `axios`. E2E tests issue real HTTP requests against a
**deployed service instance** (local, QA, lt1, prod, or any other configured
environment) and validate observable HTTP behaviour.

These tests do not start the application, do not use supertest's in-process server,
and do not use any mock HTTP library. They work with any Node.js HTTP framework
(Express, Fastify, Koa, or plain `http`).

**E2E vs Integration Testing:**

| Aspect | E2E (this guide) | Integration |
|---|---|---|
| Target | Real deployed service via HTTP | In-process server via supertest |
| Libraries | Jest + axios | Jest + supertest |
| Location | `tests/system/e2e/api/` | `tests/integration/` |
| Jest config | `jest.e2e.config.ts` | `jest.config.ts` |

## Related standard

[E2E Testing Standard](../../../../../../standards/testing/e2e.md)

## Prerequisites

Add the following dev dependencies (not prod dependencies — E2E tests are never
bundled into the application):

```bash
yarn add --dev jest ts-jest @types/jest axios
```

No additional packages are required. Do not add `supertest`, `nock`, `msw`, or any
other HTTP mock/intercept library — tests call real deployed endpoints via `axios`.

---

## HTTP request/response logging

Every HTTP call is automatically logged via `console.log` so the output is captured
by Jest's per-test capture mechanism into the `jest-junit` XML `<system-out>` element
for that specific test case. No per-test boilerplate is required — the helpers call
`logAPICall` before returning.

> **Why `console.log` and not pino?** Pino writes directly to `process.stdout`,
> bypassing Jest's capture. `console.log` is the correct mechanism here.

---

## Implementation

### Framework detection file

The presence of this file indicates the E2E framework is already installed:
```text
tests/system/e2e/api/setup.ts
```

If this file exists, add tests only (ADD_TEST_ONLY mode). If absent, generate the
complete framework (FULL_FRAMEWORK mode).

---

### Full framework setup (FULL_FRAMEWORK mode)

Generate these files:

#### `jest.e2e.config.ts` — isolated Jest configuration

Place at the **project root** alongside the existing `jest.config.ts`. This keeps E2E
tests completely separate — `jest` (or `yarn test`) never runs them; only
`yarn test:e2e` does.

```typescript
import type { Config } from 'jest'

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  testMatch: ['**/tests/system/e2e/**/*.e2e.test.ts'],
  globalSetup: './tests/system/e2e/api/setup.ts',
  testTimeout: 30000,
  verbose: true,
}

export default config
```

> **Note:** `testMatch` uses the `.e2e.test.ts` suffix so there is no overlap with
> unit tests (`.test.ts`) or integration tests (`.int.test.ts`).

#### `tests/system/e2e/api/setup.ts` — suite-level setup (framework detection file)

```typescript
import { loadConfig } from './config'

export default async function globalSetup (): Promise<void> {
  try {
    await loadConfig()
  } catch (err) {
    console.warn(`E2E tests skipped: ${(err as Error).message}`)
    // Graceful skip — missing config means the environment is not available.
    // Jest does not support skipping from globalSetup, so we set a flag that
    // each test checks via the e2eConfig fixture.
    process.env.E2E_SKIP = 'true'
  }
}
```

#### `tests/system/e2e/api/config.ts` — config loader

```typescript
import * as fs from 'fs'
import * as path from 'path'

export interface E2EConfig {
  baseUrl: string
  apiKey: string | undefined
  authToken: string | undefined
}

let _config: E2EConfig | undefined

export async function loadConfig (): Promise<E2EConfig> {
  if (_config !== undefined) return _config

  const env = process.env.ENVIRONMENT_TO_TEST ?? 'local'
  const propsPath = path.join(__dirname, 'testdata', 'e2e.properties')
  const props = parsePropertiesFile(propsPath)

  const baseUrl = props[`base.url.${env}`]
  if (baseUrl === undefined) {
    throw new Error(`base.url.${env} not found in e2e.properties`)
  }

  _config = {
    baseUrl,
    apiKey: process.env.API_KEY,
    authToken: process.env.AUTH_TOKEN,
  }

  return _config
}

function parsePropertiesFile (filePath: string): Record<string, string> {
  const content = fs.readFileSync(filePath, 'utf-8')
  const result: Record<string, string> = {}
  for (const raw of content.split('\n')) {
    const line = raw.trim()
    if (line === '' || line.startsWith('#')) continue
    const idx = line.indexOf('=')
    if (idx === -1) continue
    result[line.slice(0, idx).trim()] = line.slice(idx + 1).trim()
  }
  return result
}
```

#### `tests/system/e2e/api/helpers.ts` — HTTP helpers

```typescript
import axios, { type AxiosResponse } from 'axios'

const client = axios.create({ timeout: 30_000 })

export function urlJoin (base: string, path: string): string {
  return base.replace(/\/$/, '') + '/' + path.replace(/^\//, '')
}

export function bearerAuth (token: string): Record<string, string> {
  return { Authorization: `Bearer ${token}` }
}

export function apiKeyAuth (key: string): Record<string, string> {
  return { 'X-API-Key': key }
}

export function tokenAuth (token: string): Record<string, string> {
  return { Authorization: token }
}

interface APICallEntry {
  method: string
  url: string
  requestBody: unknown
  statusCode: number
  responseHeaders: Record<string, string>
  responseBody: unknown
}

// console.log is captured by Jest per-test and embedded in jest-junit XML.
// Do NOT use pino here — pino writes to process.stdout directly,
// bypassing Jest's capture mechanism.
function logAPICall (entry: APICallEntry): void {
  console.log(JSON.stringify({ api_call: entry }))
}

export async function doGet (
  url: string,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.get(url, { headers, validateStatus: () => true })
  logAPICall({
    method: 'GET',
    url,
    requestBody: undefined,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}

export async function doPost (
  url: string,
  body: unknown,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.post(url, body, { headers, validateStatus: () => true })
  logAPICall({
    method: 'POST',
    url,
    requestBody: body,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}

export async function doPut (
  url: string,
  body: unknown,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.put(url, body, { headers, validateStatus: () => true })
  logAPICall({
    method: 'PUT',
    url,
    requestBody: body,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}

export async function doDelete (
  url: string,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.delete(url, { headers, validateStatus: () => true })
  logAPICall({
    method: 'DELETE',
    url,
    requestBody: undefined,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}
```

> **Note:** `validateStatus: () => true` prevents axios from throwing on 4xx/5xx
> responses. Status code assertions are made explicitly in each test.

#### `tests/system/e2e/api/testdata/e2e.properties` — environment URLs

```properties
# E2E Test Configuration — non-sensitive values only
# Sensitive values (API keys, tokens) go in environment variables
# Set ENVIRONMENT_TO_TEST to any configured environment name before running tests
# Environment names are arbitrary — add entries for every environment the project uses

base.url.local=http://localhost:3000
base.url.qa=https://api-qa.example.com
base.url.lt1=https://api-lt1.example.com
base.url.prod=https://api.example.com
```

Add entries only for the environments the project uses.

---

### Adding a test (ADD_TEST_ONLY mode)

Read the existing `config.ts` to confirm the `E2EConfig` interface fields. Generate
only the new test file following the existing patterns.

```typescript
import { loadConfig, type E2EConfig } from './config'
import { doGet, doPost, doDelete, urlJoin, bearerAuth } from './helpers'

// SC-<N> | Verifies: BR-<N> — validates the complete <description> flow against the real deployed service.
describe('sc<n>_<description>', () => {
  let config: E2EConfig

  beforeAll(async () => {
    if (process.env.E2E_SKIP === 'true') return
    config = await loadConfig()
  })

  it('sc<n>_<description>', async () => {
    if (process.env.E2E_SKIP === 'true') {
      console.warn('E2E tests skipped — config unavailable')
      return
    }

    const base = config.baseUrl

    // Step 1: First API call
    const step1Resp = await doPost(urlJoin(base, '/api/v1/resource'), { field: 'value' })
    expect(step1Resp.status).toBe(201)
    const resourceId: string = step1Resp.data.data.id
    expect(resourceId).toBeTruthy()

    // Clean up test data when the test ends
    afterAll(async () => {
      await doDelete(urlJoin(base, `/api/v1/resource/${resourceId}`))
    })

    // Step 2: Follow-up call
    const step2Resp = await doGet(urlJoin(base, `/api/v1/resource/${resourceId}`))
    expect(step2Resp.status).toBe(200)
    expect(step2Resp.data.data.id).toBe(resourceId)
  })
})
```

**With authentication:**
```typescript
// Bearer token
const resp = await doGet(url, bearerAuth(config.authToken!))

// API key
const resp = await doGet(url, apiKeyAuth(config.apiKey!))

// Raw token (Authorization header, no Bearer prefix)
const resp = await doGet(url, tokenAuth(config.authToken!))
```

Skip gracefully when required secrets are absent:
```typescript
if (config.authToken === undefined) {
  console.warn('Skipping — AUTH_TOKEN environment variable is not set')
  return
}
```

**Production guard (R-3):** Tests that create or mutate data must skip in production:
```typescript
if (process.env.ENVIRONMENT_TO_TEST === 'production') {
  console.warn('Skipping destructive test in production')
  return
}
```

**File naming:** `sc<n>_<description>.e2e.test.ts` — e.g., `sc1_earn_points.e2e.test.ts`
**Describe block:** `sc<n>_<description>` — e.g., `sc1_earn_points`
**It block:** mirrors the describe name or a concise behaviour statement

---

### Add `test:e2e` script to `package.json`

Add these entries to the `"scripts"` block — do **not** modify the existing `"test"` script:

```json
"test:e2e": "jest --config jest.e2e.config.ts",
"test:e2e:smoke": "jest --config jest.e2e.config.ts --testNamePattern smoke"
```

---

### Configuration

Non-sensitive values live in `tests/system/e2e/api/testdata/e2e.properties`, keyed by
environment. Secrets are read from environment variables at suite startup. Never commit
secrets to `e2e.properties`.

The `ENVIRONMENT_TO_TEST` environment variable selects the environment (defaults to
`local` if not set). The value is arbitrary — any name is valid as long as a matching
`base.url.<name>` entry exists in `e2e.properties` (e.g. `qa1`, `lt1`, `qa1geo1`).

---

### Running the tests

```bash
# Set environment (optional — defaults to local)
export ENVIRONMENT_TO_TEST=local

# Run all E2E tests
yarn test:e2e

# Run only smoke tests
yarn test:e2e:smoke

# Run a specific scenario
yarn test:e2e --testNamePattern sc1

# Run against lt1
ENVIRONMENT_TO_TEST=lt1 yarn test:e2e

# Run against any environment
ENVIRONMENT_TO_TEST=qa1geo1 yarn test:e2e

# With auth token
AUTH_TOKEN=your-token yarn test:e2e
```

---

## Verification

1. Confirm `jest.e2e.config.ts` exists at the project root and the existing `jest.config.ts` was NOT modified.
2. Confirm `testMatch` in `jest.e2e.config.ts` uses `*.e2e.test.ts` — no overlap with unit or integration tests.
3. Confirm `validateStatus: () => true` is set on the axios client — status assertions are explicit in tests.
4. Confirm `setup.ts` sets `process.env.E2E_SKIP = 'true'` on config error (graceful skip).
5. Confirm no supertest, nock, msw, or any mock HTTP library usage.
6. Confirm `testdata/e2e.properties` contains entries for all configured environments.
7. Confirm `test:e2e` script is added to `package.json` without modifying the existing `test` script.
8. Confirm `helpers.ts` contains `logAPICall` using `console.log` (not pino).
9. Confirm all HTTP helpers (`doGet`, `doPost`, `doPut`, `doDelete`) call `logAPICall` before returning.
10. Run `yarn test:e2e` — tests must pass or skip cleanly.
11. Run `yarn test` — E2E files must be excluded from normal test runs.
12. Run `yarn lint` — all generated TypeScript files must pass with zero errors.
