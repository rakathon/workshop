# TypeScript Guide — React Query Key Factories

Guide: 0.1.0 | Implements: standards/frontend/data-fetching.md@0.0.1

## Overview

This guide shows how to implement the Client-Side Data Fetching standard in a TypeScript and React project using React Query (TanStack Query v5). It covers defining type-safe query configurations with `queryOptions` and `infiniteQueryOptions`, structuring key factories for targeted cache invalidation, and consuming the same definitions in both client-side hooks and server-side `prefetchQuery` calls. A codebase following this guide will have consistent, type-safe cache keys that prevent hydration mismatches and enable precise cache invalidation.

## Related standard

[Client-Side Data Fetching](../../../../../../standards/frontend/data-fetching.md)

## Prerequisites

- React 18+
- TanStack Query v5 (`@tanstack/react-query`)
- TypeScript 5+
- A configured `QueryClient` and `QueryClientProvider` in your app

## Implementation

### Defining a key factory (R-1, R-2, R-3, R-4)

Co-locate the key factory with the fetchers for that resource. Use `as const` on every
tuple so TypeScript infers the narrowest possible type for each key — this gives precise
type checking at call sites and prevents accidental key widening.

```typescript
// users/queries.ts — key factory co-located with fetchers (R-4)
export const userKeys = {
  all: () => ['users'] as const,
  lists: () => [...userKeys.all(), 'list'] as const,
  list: (filters: UserListFilters) => [...userKeys.lists(), filters] as const,
  details: () => [...userKeys.all(), 'detail'] as const,
  detail: (id: string) => [...userKeys.details(), id] as const,
} satisfies Record<string, (...args: unknown[]) => readonly unknown[]>
```

Keys narrow from resource → scope → parameters (R-2), and all values are strings or
plain objects — no class instances, Dates, or Symbols (R-3). Use this factory for
targeted invalidation (see below); prefer `queryOptions` for defining queries.

### Defining queries with `queryOptions` (R-1, R-4, R-5)

Use `queryOptions` to co-locate a query's key and fetcher as a single typed unit. This
eliminates the possibility of a key/fetcher mismatch and allows the same definition to
be consumed in hooks, prefetch calls, and router loaders without duplicating configuration.

```typescript
// users/queries.ts — queryOptions co-locates key and fetcher (R-4)
export const userDetailQueryOptions = (id: string) => queryOptions({
  queryKey: userKeys.detail(id),
  queryFn: () => fetchUser(id),
})

export const userListQueryOptions = (filters: UserListFilters) => queryOptions({
  queryKey: userKeys.list(filters),
  queryFn: () => fetchUsers(filters),
})
```

The same options object is consumed identically in hooks and prefetch — no key/fetcher
mismatch is possible (R-5):

```typescript
// in a component
const { data } = useQuery(userDetailQueryOptions(id))

// in a server-side prefetch
await queryClient.prefetchQuery(userDetailQueryOptions(id))
```

### Defining infinite queries with `infiniteQueryOptions`

Use `infiniteQueryOptions` for paginated or "load more" data. The `initialPageParam`
and `getNextPageParam` fields are required in v5.

```typescript
// posts/queries.ts
export const postsInfiniteQueryOptions = (filters: PostFilters) => infiniteQueryOptions({
  queryKey: postKeys.list(filters),
  queryFn: ({ pageParam }) => fetchPosts({ ...filters, page: pageParam }),
  initialPageParam: 0,
  getNextPageParam: (lastPage, allPages) =>
    lastPage.hasMore ? allPages.length : undefined,
})

// in a component
const { data, fetchNextPage, hasNextPage } = useInfiniteQuery(postsInfiniteQueryOptions(filters))

// prefetch the first page server-side
await queryClient.prefetchInfiniteQuery(postsInfiniteQueryOptions(filters))
```

### Targeted invalidation via hierarchy (R-2)

```typescript
// Invalidate all user data
queryClient.invalidateQueries({ queryKey: userKeys.all() })

// Invalidate only lists, leave detail queries intact
queryClient.invalidateQueries({ queryKey: userKeys.lists() })
```

## Verification

1. TypeScript compilation passes with no errors on key factory usage — run `tsc --noEmit`
2. In React Query Devtools, all queries for the same resource share a common key prefix (e.g., `["users", ...]`) — expanding the cache shows the expected hierarchy
3. On a server-rendered page, open the Network tab and confirm no duplicate fetch fires on mount for prefetched queries — the client reuses the dehydrated cache entry
4. Hover over a `useQuery(userDetailQueryOptions(id))` call in your editor — confirm `data` is inferred as the return type of `fetchUser` with no explicit generic required
