// fixtures/compliant-data.ts
// A realistic Express service satisfying all REST API Data standard rules.
// Referenced by data.test.yaml as a whole-file compliant example.

import { Request, Response, NextFunction, Router } from 'express'
import { v4 as uuidv4 } from 'uuid'
import { context, propagation, ROOT_CONTEXT } from '@opentelemetry/api'

const router = Router()

// ── R-1, R-2: Pagination ──────────────────────────────────────────────────────

// R-2: cursor/limit request params; pagination.next response field (forward-only by default)
interface CursorPage<T> {
  data: T[]
  pagination: { next?: string }
}

function cursorResponse<T>(data: T[], next: string | undefined): CursorPage<T> {
  const pagination: { next?: string } = {}
  if (next !== undefined) pagination.next = next  // R-2: omit next on last page
  return { data, pagination }
}

// R-1: collection endpoint is bounded — limit capped at 100, default 20
router.get('/stores', async (req: Request, res: Response): Promise<void> => {
  const cursor = req.query.cursor as string | undefined
  const limit = Math.min(Number(req.query.limit ?? 20), 100)
  const { stores, nextCursor } = await storeService.list({ cursor, limit })
  res.json(cursorResponse(stores, nextCursor))
})

// ── R-3: Optimistic concurrency ───────────────────────────────────────────────

// R-3: version_token on resource; PUT requires client to echo token; 409 includes latest state
router.put('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const { store_id } = req.params
  const { version_token, ...updates } = req.body

  const current = await storeService.getById(store_id)
  if (!current) {
    res.status(404).json({ errors: [{ code: 'NOT_FOUND', message: 'Store not found' }] })
    return
  }

  if (current.version_token !== version_token) {
    // R-3: 409 must include the latest entity state so client can re-apply without extra round-trip
    res.status(409).json({
      errors: [{ code: 'VERSION_CONFLICT', message: 'Resource was modified by another request' }],
      data: current,
    })
    return
  }

  const updated = await storeService.update(store_id, {
    ...updates,
    version_token: uuidv4(),  // R-3: generate new UUID token on each successful write
  })
  res.json({ data: updated })
})

// ── R-4: Timestamps ───────────────────────────────────────────────────────────

// R-4: serialize to YYYY-MM-DDTHH:MM:SSZ — truncate milliseconds, never send Date object
function toTimestamp(date: Date): string {
  return date.toISOString().replace(/\.\d{3}Z$/, 'Z')
  // "2024-03-15T14:30:00.000Z" → "2024-03-15T14:30:00Z"
}

router.get('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const store = await storeService.getById(req.params.store_id)
  if (!store) {
    res.status(404).json({ errors: [{ code: 'NOT_FOUND', message: 'Store not found' }] })
    return
  }
  res.json({
    data: {
      id: store.id,
      name: store.name,
      version_token: store.version_token,
      listing_fee: store.listing_fee,           // R-6: already a CurrencyAmount
      created_at: toTimestamp(store.createdAt), // R-4: ISO 8601 UTC string, no milliseconds
      updated_at: toTimestamp(store.updatedAt), // R-4: never send raw Date or epoch integer
    }
  })
})

// ── R-5: Decimal numbers ──────────────────────────────────────────────────────

// R-5: value/scale tuple — never use JSON float for monetary or precision-sensitive values
interface Decimal {
  value: number  // integer
  scale: number  // non-negative integer
}

function toDecimal(raw: string): Decimal {
  const [intPart, fracPart = ''] = raw.split('.')
  const scale = fracPart.length
  const value = parseInt(`${intPart}${fracPart}`, 10)
  return { value, scale }
}

// ── R-6: Currency amounts ─────────────────────────────────────────────────────

// R-6: amount/currency/scale — amount is integer, scale is non-negative integer, currency is ISO 4217
interface CurrencyAmount {
  amount: number    // integer
  currency: string  // ISO 4217, e.g. "USD", "JPY"
  scale: number     // non-negative integer
}

function toCurrencyAmount(amountStr: string, currency: string): CurrencyAmount {
  const { value, scale } = toDecimal(amountStr)
  return { amount: value, currency, scale }
}

router.get('/offers/:offer_id', async (req: Request, res: Response): Promise<void> => {
  const offer = await offerService.getById(req.params.offer_id)
  res.json({
    data: {
      id: offer.id,
      name: offer.name,
      discount_rate: toDecimal('0.15'),            // R-5: { value: 15, scale: 2 } not 0.15
      price: toCurrencyAmount('12.99', 'USD'),     // R-6: { amount: 1299, currency: 'USD', scale: 2 }
      valid_until: toTimestamp(offer.validUntil),  // R-4: ISO 8601 UTC
    }
  })
})

// ── R-7: Distributed tracing ──────────────────────────────────────────────────

// R-7: extract W3C traceparent/tracestate from incoming request and propagate downstream
export function tracingMiddleware(req: Request, _res: Response, next: NextFunction): void {
  const extracted = propagation.extract(ROOT_CONTEXT, req.headers)
  context.with(extracted, next)
}

// R-7: inject active trace context into outbound headers on all downstream calls
async function callDownstream(url: string, body: unknown): Promise<Response> {
  const headers: Record<string, string> = { 'content-type': 'application/json' }
  propagation.inject(context.active(), headers)  // adds traceparent + tracestate
  return fetch(url, { method: 'POST', headers, body: JSON.stringify(body) })
}

// ── R-8: Localization ─────────────────────────────────────────────────────────

const SUPPORTED_LOCALES = ['en-US', 'en', 'ja', 'fr-FR', 'fr'] as const
type SupportedLocale = typeof SUPPORTED_LOCALES[number]
const DEFAULT_LOCALE: SupportedLocale = 'en-US'

// R-8: parse Accept-Language with quality weighting; fall back to region default
function negotiateLocale(acceptLanguage: string | undefined): SupportedLocale {
  if (!acceptLanguage) return DEFAULT_LOCALE

  const candidates = acceptLanguage
    .split(',')
    .map(part => {
      const [tag, q] = part.trim().split(';q=')
      return { tag: tag.trim(), q: q !== undefined ? parseFloat(q) : 1.0 }
    })
    .sort((a, b) => b.q - a.q)

  for (const { tag } of candidates) {
    const exact = SUPPORTED_LOCALES.find(l => l.toLowerCase() === tag.toLowerCase())
    if (exact) return exact
    const lang = tag.split('-')[0].toLowerCase()
    const fallback = SUPPORTED_LOCALES.find(l => l.toLowerCase() === lang)
    if (fallback) return fallback
  }

  return DEFAULT_LOCALE
}

router.get('/stores/:store_id/content', async (req: Request, res: Response): Promise<void> => {
  const locale = negotiateLocale(req.headers['accept-language'])  // R-8: honour Accept-Language
  const content = await contentService.getStoreContent(req.params.store_id, { locale })
  res.json({ data: content })
})

export { router }

// Stub service declarations (not part of the standard — omit in real service)
declare const storeService: {
  list(opts: { cursor?: string; limit: number }): Promise<{ stores: unknown[]; nextCursor?: string }>
  getById(id: string): Promise<{ id: string; name: string; version_token: string; listing_fee: CurrencyAmount; createdAt: Date; updatedAt: Date } | null>
  update(id: string, data: unknown): Promise<unknown>
}
declare const offerService: {
  getById(id: string): Promise<{ id: string; name: string; validUntil: Date }>
}
declare const contentService: {
  getStoreContent(id: string, opts: { locale: string }): Promise<unknown>
}
declare function callDownstreamStub(url: string, body: unknown): Promise<Response>
