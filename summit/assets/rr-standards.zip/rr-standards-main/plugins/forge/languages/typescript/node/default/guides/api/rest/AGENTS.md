# TypeScript REST API Guides

This directory contains TypeScript/Node.js implementation guides for the REST API
standards family. Each guide covers a distinct concern of HTTP/REST API design and
maps to a companion standard under `plugins/forge/standards/api/rest/`. Load the guide
that matches the concern you are implementing or reviewing; load multiple guides when
a task spans concerns (e.g. both contract shape and data representation).

## File index

| Name | Purpose | When to reference |
|------|---------|-------------------|
| `contracts.md` | How to satisfy the REST API Contracts standard in Express: router separation, versioned mounts, snake_case params, HTTP verb assignment, member-scoped URIs, OpenAPI validation | Designing or reviewing URI structure, versioning, route naming, or contract type separation |
| `data.md` | How to satisfy the REST API Data standard in Express: cursor/offset pagination, optimistic concurrency with `version_token`, ISO 8601 timestamps, decimal/currency value-scale encoding, OpenTelemetry tracing headers, Accept-Language localization | Designing or reviewing request/response field types, pagination shapes, concurrent write handling, or tracing |
| `protocol.md` | How to satisfy the REST API Protocol standard in Express: `Client-Agent` middleware, gzip compression, response envelope types (`data`/`errors`/`meta`/`pagination`), status code helpers, `Retry-After` on 429/503, global error handler | Designing or reviewing response structure, HTTP status code selection, error array shape, or meta fields |
| `security.md` | How to satisfy the REST API Security standard in Express: ebtoken/euid-cookie auth middleware for public member-data routes, JWT+role validation for admin routes, server-to-server token validation for sensitive `-int` endpoints | Designing or reviewing authentication middleware, 401/403 handling, or contract-type security strategy |
| `contracts.test.yaml` | Golden compliant/non-compliant examples for behavioral validation of `contracts.md` | Running `rr-standards:test` or `rr-standards:validate --active` against the contracts guide |
| `data.test.yaml` | Golden compliant/non-compliant examples for behavioral validation of `data.md` | Running `rr-standards:test` or `rr-standards:validate --active` against the data guide |
| `protocol.test.yaml` | Golden compliant/non-compliant examples for behavioral validation of `protocol.md` | Running `rr-standards:test` or `rr-standards:validate --active` against the protocol guide |
| `security.test.yaml` | Golden compliant/non-compliant examples for behavioral validation of `security.md` | Running `rr-standards:test` or `rr-standards:validate --active` against the security guide |
| `fixtures/compliant-contracts.ts` | Realistic Express service satisfying all REST API Contracts rules | Referenced by `contracts.test.yaml ex-c1`; whole-file compliant baseline for contracts |
| `fixtures/non-compliant-contracts.ts` | Express service with intentional contracts rule violations (R-2, R-3, R-4, R-5, R-7, R-10) | Referenced by contracts tests; illustrates common mistakes |
| `fixtures/compliant-data.ts` | Realistic Express service satisfying all REST API Data rules | Referenced by `data.test.yaml ex-cf1`; whole-file compliant baseline for data |
| `fixtures/non-compliant-data.ts` | Express service with intentional data rule violations (R-1–R-6, R-8) | Referenced by `data.test.yaml ex-ncf1`; illustrates common data mistakes |
| `fixtures/compliant-protocol.ts` | Realistic Express service satisfying all REST API Protocol rules | Referenced by `protocol.test.yaml ex-cf1`; whole-file compliant baseline for protocol |
| `fixtures/non-compliant-protocol.ts` | Express service with intentional protocol rule violations (R-1–R-8) | Referenced by `protocol.test.yaml ex-ncf1`; illustrates common protocol mistakes |
| `fixtures/compliant-security.ts` | Realistic Express service satisfying all REST API Security rules | Referenced by `security.test.yaml ex-cf1`; whole-file compliant baseline for security |
| `fixtures/non-compliant-security.ts` | Express service with intentional security rule violations (R-1–R-3) | Referenced by `security.test.yaml ex-ncf1`; illustrates common security mistakes |

## Navigation

- Standards being implemented: [`plugins/forge/standards/api/rest/`](../../../../../../../standards/api/rest/)
- Parent language guide index: [`plugins/forge/languages/typescript/node/default/guides/api/`](../)
