// users/queries.ts
// Non-compliant: violates R-1 (no factory — hand-written keys at every call site),
// R-2 (flat string keys — no hierarchy), R-3 (Date instance in key),
// R-4 (key constants defined in a separate file), R-5 (server/client key mismatch).

// Defined elsewhere in keys/userKeys.ts — not co-located with fetchers (R-4 violated)
const USER_KEY = 'users'
const USER_DETAIL_KEY = 'detail'
const USER_LIST_KEY = 'list'

// R-1 violated: no shared factory — keys assembled from loose constants at each call site
// R-2 violated: flat interpolated strings instead of a hierarchical array
export function useUser(id: string) {
  return useQuery({
    queryKey: [`${USER_KEY}-${USER_DETAIL_KEY}-${id}`],
    queryFn: () => fetchUser(id),
  })
}

export function useUsers(filters: UserListFilters) {
  return useQuery({
    queryKey: [`${USER_KEY}-${USER_LIST_KEY}`],
    queryFn: () => fetchUsers(filters),
  })
}

// R-3 violated: Date instance is not serialisable
export function useReportByDate(date: Date) {
  return useQuery({
    queryKey: ['reports', 'by-date', date],
    queryFn: () => fetchReport(date),
  })
}

// R-5 violated: server uses a different hand-written key from the client
// Client produces: 'users-detail-<id>'
// Server produces: ['user', id]  ← mismatch — cache miss on hydration
export async function prefetchUser(queryClient: QueryClient, id: string) {
  await queryClient.prefetchQuery({
    queryKey: ['user', id],
    queryFn: () => fetchUser(id),
  })
}
