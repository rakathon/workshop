// Compliant E2E helpers — logAPICall via console.log (not pino), wired into all HTTP helpers.
// console.log is captured by Jest per-test and embedded in jest-junit XML <system-out>.

import axios, { type AxiosResponse } from 'axios'

const client = axios.create({ timeout: 30_000 })

export function urlJoin (base: string, path: string): string {
  return base.replace(/\/$/, '') + '/' + path.replace(/^\//, '')
}

export function bearerAuth (token: string): Record<string, string> {
  return { Authorization: `Bearer ${token}` }
}

export function apiKeyAuth (key: string): Record<string, string> {
  return { 'X-API-Key': key }
}

export function tokenAuth (token: string): Record<string, string> {
  return { Authorization: token }
}

interface APICallEntry {
  method: string
  url: string
  requestBody: unknown
  statusCode: number
  responseHeaders: Record<string, string>
  responseBody: unknown
}

// console.log is captured by Jest per-test and embedded in jest-junit XML.
// Do NOT use pino here — pino writes to process.stdout directly,
// bypassing Jest's capture mechanism.
function logAPICall (entry: APICallEntry): void {
  console.log(JSON.stringify({ api_call: entry }))
}

export async function doGet (
  url: string,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.get(url, { headers, validateStatus: () => true })
  logAPICall({
    method: 'GET',
    url,
    requestBody: undefined,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}

export async function doPost (
  url: string,
  body: unknown,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.post(url, body, { headers, validateStatus: () => true })
  logAPICall({
    method: 'POST',
    url,
    requestBody: body,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}

export async function doPut (
  url: string,
  body: unknown,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.put(url, body, { headers, validateStatus: () => true })
  logAPICall({
    method: 'PUT',
    url,
    requestBody: body,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}

export async function doDelete (
  url: string,
  headers: Record<string, string> = {}
): Promise<AxiosResponse> {
  const resp = await client.delete(url, { headers, validateStatus: () => true })
  logAPICall({
    method: 'DELETE',
    url,
    requestBody: undefined,
    statusCode: resp.status,
    responseHeaders: resp.headers as Record<string, string>,
    responseBody: resp.data,
  })
  return resp
}
