// fixtures/non-compliant-contracts.ts
// This code violates several rules from the REST API Contracts standard.
// It looks like plausible production TypeScript/Express but contains multiple violations.

import { Router, Request, Response, NextFunction } from 'express'

// R-5 VIOLATION: single router used for all contract types — public and internal mixed together
const apiRouter = Router()

// R-2 VIOLATION: version is a dynamic route parameter instead of a static mount path segment
// app.use('/purchase_experience', apiRouter)
// Correct: app.use('/purchase_experience/v1', publicRouter)

// ── Routes ───────────────────────────────────────────────────────────────────

// R-2 VIOLATION: :version is a dynamic param — allows any string, not just 'v1'
// R-4 VIOLATION: :experienceName uses camelCase instead of snake_case
// R-10 VIOLATION: missing /regions/:region_id prefix on member-scoped path
apiRouter.get(
  '/:version/members/:member_guid/experiences/:experienceName',
  // R-10 VIOLATION: /regions/:region_id is missing — member path must be
  //   /regions/:region_id/members/:member_guid/...
  (req: Request, res: Response, next: NextFunction): void => {
    void processRequest(req, res, next, getExperience)
  }
)

// R-3 VIOLATION: collection segment 'experience' is singular instead of plural
// R-7 VIOLATION: POST used to update an existing resource (should be PUT or PATCH)
apiRouter.get('/experience/:experience_id', getExperienceHandler)
apiRouter.post('/experience/:experience_id', updateExperienceHandler)
// Correct: apiRouter.get('/experiences/:experience_id', ...)
//          apiRouter.put('/experiences/:experience_id', ...)  or .patch()

// R-5 VIOLATION: internal -int routes mixed into the same router as public routes
// R-4 VIOLATION: :featureName uses camelCase instead of snake_case
apiRouter.get('/platform_configs', listPlatformConfigs)  // internal route on public router
apiRouter.put(
  '/features/:featureName',   // R-4 VIOLATION: camelCase param — should be :feature_name
  (req: Request, res: Response, next: NextFunction): void => {
    void processRequest(req, res, next, replaceFeature)
  }
)

// R-2 VIOLATION: version placed inside the route string instead of in the mount path
// Introducing v2 now requires changing every route string below
apiRouter.get('/v1/regions/:region_id/offers', listOffers)
apiRouter.post('/v1/regions/:region_id/offers', createOffer)
// Correct: app.use('/purchase_experience/v1', publicRouter) and router.get('/regions/:region_id/offers', ...)

// R-10 VIOLATION: public contract uses :member_id (sequential integer) instead of :member_guid
// R-7 VIOLATION: no .all() guard — unsupported methods are silently ignored
apiRouter.get(
  '/regions/:region_id/members/:member_id/offers',
  // R-10 VIOLATION: :member_id exposes internal integer ID on a public endpoint
  (req: Request, res: Response, next: NextFunction): void => {
    void processRequest(req, res, next, listMemberOffers)
  }
)
// Missing: .all() returning 405 for unsupported methods

export { apiRouter }

// Stub type declarations
declare function processRequest(req: Request, res: Response, next: NextFunction, handler: unknown): Promise<void>
declare const getExperience: unknown
declare function getExperienceHandler(req: Request, res: Response): void
declare function updateExperienceHandler(req: Request, res: Response): void
declare function listPlatformConfigs(req: Request, res: Response): void
declare function replaceFeature(req: Request, res: Response): void
declare function listOffers(req: Request, res: Response): void
declare function createOffer(req: Request, res: Response): void
declare function listMemberOffers(req: Request, res: Response): void
