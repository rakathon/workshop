# TypeScript/Node.js Guide — REST API Contracts

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/contracts.md@1.0.1

## Overview

Shows how to satisfy the REST API Contracts standard in a Node.js/Express service using
TypeScript. Covers Express router structure for public, internal, and admin contract types;
versioned route mounting; `snake_case` path parameter naming; HTTP verb assignment; and
member-scoped URI patterns. An Express service that follows this guide will produce URI
structures, versioning, and naming that comply with the standard.

## Related standard

[REST API Contracts](../../../../../../../standards/api/rest/contracts.md)

## Prerequisites

- Node.js 20+
- TypeScript 5.x (`typescript ^5.6.3`)
- Express 4.x (`express ^4.21.2`, `@types/express ^4.17.21`)
- `express-openapi-validate ^0.6.1` — validates requests against the OpenAPI spec at route level (R-9)
- `js-yaml ^4.1.1` — loads the OpenAPI YAML spec at startup

## Implementation

### Router separation by contract type (R-5)

Create one Express `Router` instance per contract type and mount each with its contract
name. Never mix public, admin, and internal routes in the same router.

```typescript
// src/core/routes/index.ts
import { Router } from 'express'

const publicRouter = Router()    // no suffix — public contract
const internalRouter = Router()  // -int suffix — server-to-server

// Mount with the full contract name prefix
// Public:   /purchase_experience/v1/...
// Internal: /purchase_experience-int/v1/...
app.use('/purchase_experience/v1', publicRouter)
app.use('/purchase_experience-int/v1', internalRouter)
```

For admin contracts (`-admin`), add a third router:

```typescript
const adminRouter = Router()
app.use('/purchase_experience-admin/v1', adminRouter)
```

### Versioned route mounting (R-1, R-2)

The version segment `v<N>` belongs in the `app.use()` mount path — **not** inside the
route string and **not** as a dynamic parameter.

```typescript
// Correct — version is static in the mount path
app.use('/purchase_experience/v1', publicRouter)
publicRouter.get('/regions/:region_id/members/:member_guid/experiences/:experience_name', handler)
// Resulting URI: /purchase_experience/v1/regions/.../experiences/...

// Wrong — version as a dynamic route parameter
publicRouter.get('/purchase_experience/:version/regions/:region_id/...', handler)
// ↑ allows any string in :version; not compliant with R-2

// Wrong — version inside the route string
publicRouter.get('/purchase_experience/v1/regions/:region_id/...', handler)
// ↑ duplicates the mount prefix; breaks if the mount path changes
```

When a breaking change requires a new version, create a new router and mount it
alongside the existing one — never modify v1 routes (see Breaking changes below).

### Collection and parameter naming (R-3, R-4)

All route path segments and parameter names must be plural `snake_case`.

```typescript
// Correct — plural snake_case collection, snake_case param
publicRouter.get('/experiences/:experience_name', handler)
internalRouter.get('/platform_configs/:platform_config_id', handler)
internalRouter.get('/platform_configs/:platform_config_id/publish', publishHandler)

// Wrong — camelCase parameter name
internalRouter.route('/features/:featureName')  // ← :featureName violates R-4
// Correct version:
internalRouter.route('/features/:feature_name') // ← :feature_name

// Wrong — singular collection segment
internalRouter.get('/feature/:feature_name', handler)  // ← 'feature' is singular
// Correct:
internalRouter.get('/features/:feature_name', handler) // ← 'features' is plural
```

Access corrected params via `req.params.feature_name` (not `req.params.featureName`).

### HTTP verb assignment (R-7)

| Intent | Express method | Notes |
|--------|---------------|-------|
| Read single resource or collection | `.get()` | |
| Create resource | `.post()` | Must return 201 + `Location` header |
| Full idempotent replacement | `.put()` | Requires `version_token` if resource supports concurrent writes |
| Partial update | `.patch()` | |
| Delete | `.delete()` | |
| Query with very long parameters | `.post()` | Only when GET URL length would exceed limits; document why |

Always add `.all()` to return 405 for unsupported methods:

```typescript
internalRouter
  .route('/features/:feature_name')
  .get((req, res, next): void => {
    void processRequest(req, res, next, getFeatureConfig)
  })
  .put(
    rateLimit(50, 60000),
    (req, res, next): void => { void processRequest(req, res, next, saveFeatureConfig) }
  )
  .delete(
    rateLimit(50, 60000),
    (req, res, next): void => { void processRequest(req, res, next, deleteFeatureConfig) }
  )
  .all((_req, res): void => {
    res.status(405).json({
      errors: [{ code: 'METHOD_NOT_ALLOWED', message: 'HTTP method not supported for this endpoint' }],
      meta: { status: { code: 'MethodNotAllowed' } }
    })
  })
```

### Member-scoped URI structure (R-10)

Any endpoint accessing member data must include
`/regions/:region_id/members/:member_guid` (public) or
`/regions/:region_id/members/:member_id` (internal) before the member-scoped collection.

```typescript
// Public contract — member identified by GUID (non-sequential unique identifier)
publicRouter.get(
  '/regions/:region_id/members/:member_guid/experiences/:experience_name',
  validateRegionMiddleware,
  openApiValidator.validate('get', '/purchase_experience/{version}/regions/{region_id}/members/{member_guid}/experiences/{experience_name}'),
  authenticateRequest,
  (req, res, next): void => { void processRequest(req, res, next, getExperience) }
)

// Internal contract — member identified by integer member ID
internalRouter.get(
  '/regions/:region_id/members/:member_id/experiences/:experience_name',
  (req, res, next): void => { void processAdminRequest(req, res, next, getExperienceInternal) }
)

// Wrong — member data without /regions/:region_id/members/:member_guid prefix
publicRouter.get('/members/:member_guid/experiences/:experience_name', handler)
// ↑ missing /regions/:region_id/ prefix — violates R-10

// Wrong — integer member_id on a public contract
publicRouter.get('/regions/:region_id/members/:member_id/experiences/:experience_name', handler)
// ↑ exposes internal integer ID on public contract — use :member_guid instead
```

### Breaking changes — new version (R-6)

When a breaking change is required, add a new versioned mount alongside the existing
one. Never modify or remove the previous version's routes.

```typescript
// src/core/routes/index.ts

// v1 — never modified after v2 is introduced
import { publicV1Router } from './v1/public'
app.use('/purchase_experience/v1', publicV1Router)

// v2 — new router for the breaking change
import { publicV2Router } from './v2/public'
app.use('/purchase_experience/v2', publicV2Router)
```

Directory structure for versioned routes:

```
src/core/routes/
  v1/
    public.ts      ← unchanged after v2 is introduced
    internal.ts
  v2/
    public.ts      ← new file for breaking change
    internal.ts
  index.ts         ← mounts all versions
```

### OpenAPI spec validation (R-9)

Load the OpenAPI spec once at startup and attach the validator as middleware before the
business logic handler on each route. See the
[OpenAPI contracts guide](../../../../../../openapi/default/guides/api/rest/contracts.md)
for authoring the spec itself.

```typescript
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { load as loadYaml } from 'js-yaml'
import { OpenApiDocument, OpenApiValidator } from 'express-openapi-validate'

const openApiDocument = loadYaml(
  readFileSync(resolve(process.cwd(), 'docs/api.yaml'), 'utf-8')
) as OpenApiDocument
const openApiValidator = new OpenApiValidator(openApiDocument, {
  ajvOptions: { coerceTypes: true }
})

// Attach per-route — validates request shape before business logic runs
publicRouter.get(
  '/regions/:region_id/members/:member_guid/experiences/:experience_name',
  openApiValidator.validate('get', '/purchase_experience/{version}/regions/{region_id}/members/{member_guid}/experiences/{experience_name}'),
  authenticateRequest,
  handler
)
```

## Verification

1. Check all route mount paths — each starts with `/<contract-name>/v<N>/`; no `:version` dynamic parameter in the mount path.
2. Search for camelCase route parameters:
   ```bash
   grep -rn ':\w*[A-Z]' src/core/routes/
   ```
   Any match is a R-4 violation — rename to `snake_case`.
3. Confirm every `.route()` block also has `.all()` returning 405 — no route should silently accept unsupported methods.
4. For every endpoint accessing member data, confirm the path contains `/regions/:region_id/members/:member_guid` (public contract) or `/regions/:region_id/members/:member_id` (internal `-int` contract).
5. Confirm public and internal routes are mounted on separate routers — no admin or `-int` routes mixed into the public router.
6. Run the linter — all route files must pass with no errors:
   ```bash
   yarn lint
   ```
