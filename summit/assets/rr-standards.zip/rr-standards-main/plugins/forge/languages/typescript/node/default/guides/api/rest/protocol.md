# TypeScript/Node.js Guide — REST API Protocol

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/protocol.md@1.0.1

## Overview

Shows how to satisfy the REST API Protocol standard in a Node.js/Express service using
TypeScript. Covers `Client-Agent` header validation middleware; gzip response compression;
the response envelope shape (`data`, `errors`, `meta`, `pagination`); required `meta`
fields; correct HTTP status codes including 201+`Location` for creates; `Retry-After` on
429/503; and the error array structure for all non-2xx responses. An Express service that
follows this guide will produce responses with consistent structure, operational metadata,
and error representations that comply with the standard.

## Related standard

[REST API Protocol](../../../../../../../standards/api/rest/protocol.md)

## Prerequisites

- Node.js 20+
- TypeScript 5.x (`typescript ^5.6.3`)
- Express 4.x (`express ^4.21.2`, `@types/express ^4.17.21`)
- `compression ^1.7.4`, `@types/compression ^1.7.5` — gzip response compression (R-4)
- `uuid ^10.0.0` — generate `request_id` UUIDs for `meta.operation.request_id` (R-6)

## Implementation

### Response envelope types (R-5, R-6)

Define shared TypeScript types for the envelope and meta fields once; import them in every
route handler.

```typescript
// src/types/response.ts
import { v4 as uuidv4 } from 'uuid'

export interface Meta {
  status: { code: string }
  operation: { request_id: string }
}

export interface DataResponse<T> {
  data: T
  meta: Meta
}

export interface ListResponse<T> {
  data: T[]
  pagination?: { next?: string; num_pages?: number; num_results?: number }
  meta: Meta
}

export interface ErrorDetail {
  code: string
  message: string
  details?: { field: string; value?: unknown; constraint?: string }
  trace_id?: string
}

export interface ErrorResponse {
  errors: ErrorDetail[]
  meta: Meta
}

// R-6: generate a fresh UUID request_id for every response
export function makeMeta(statusCode: string): Meta {
  return {
    status: { code: statusCode },
    operation: { request_id: uuidv4() },
  }
}
```

### Client-Agent header middleware (R-1, R-2)

Require `Client-Agent` on every request. Custom headers must not use the deprecated
`X-` prefix.

```typescript
// src/middleware/clientAgent.ts
import { Request, Response, NextFunction } from 'express'
import { ErrorResponse, makeMeta } from '../types/response'

/**
 * R-1: Require the Client-Agent header on all API calls.
 * R-2: The header is named "Client-Agent" — not "X-Client-Agent".
 */
export function requireClientAgent(req: Request, res: Response, next: NextFunction): void {
  if (!req.headers['client-agent']) {
    res.status(400).json({
      errors: [{ code: 'MISSING_CLIENT_AGENT', message: 'Client-Agent header is required' }],
      meta: makeMeta('BadRequest'),
    } satisfies ErrorResponse)
    return
  }
  next()
}
```

```typescript
// src/core/app.ts — attach before all route handlers
import { requireClientAgent } from './middleware/clientAgent'

app.use(requireClientAgent)
```

### gzip compression (R-4)

Enable gzip compression at the app level. Express does not compress by default.

```typescript
// src/core/app.ts
import compression from 'compression'

// R-4: enable gzip — Content-Encoding: gzip returned unless response is small
app.use(compression())
```

### Success response helpers (R-5, R-6, R-7)

```typescript
// src/middleware/respond.ts
import { Response } from 'express'
import { DataResponse, ListResponse, makeMeta } from '../types/response'

// R-5: single-entity success — data + meta only (no errors, no pagination)
export function respondOk<T>(res: Response, data: T): void {
  res.status(200).json({ data, meta: makeMeta('OK') } satisfies DataResponse<T>)
}

// R-7: POST creation — 201 + Location header (never 200)
export function respondCreated<T>(res: Response, data: T, location: string): void {
  res.status(201).location(location).json({ data, meta: makeMeta('Created') } satisfies DataResponse<T>)
}

// R-5: collection success — data + optional pagination + meta
export function respondList<T>(
  res: Response,
  data: T[],
  pagination?: ListResponse<T>['pagination']
): void {
  const body: ListResponse<T> = { data, meta: makeMeta('OK') }
  if (pagination) body.pagination = pagination
  res.status(200).json(body)
}
```

```typescript
// Example routes using the helpers
router.get('/stores', async (req: Request, res: Response): Promise<void> => {
  const { stores, nextCursor } = await storeService.list()
  respondList(res, stores, nextCursor ? { next: nextCursor } : undefined)
})

router.get('/stores/:store_id', async (req: Request, res: Response): Promise<void> => {
  const store = await storeService.getById(req.params.store_id)
  if (!store) {
    throw new NotFoundError('Store not found')
  }
  respondOk(res, store)
})

router.post('/stores', async (req: Request, res: Response): Promise<void> => {
  const created = await storeService.create(req.body)
  // R-7: 201 + Location — never 200 for creates
  respondCreated(res, created, `/stores/v1/stores/${created.id}`)
})
```

### Global error handler (R-3, R-5, R-6, R-7, R-8)

Centralise all error-to-status-code mapping in one Express error handler. This ensures
`errors + meta` (never `data`) on every non-2xx response.

```typescript
// src/middleware/errorHandler.ts
import { Request, Response, NextFunction } from 'express'
import { ErrorResponse, makeMeta } from '../types/response'

// Domain error types — extend as needed
export class NotFoundError extends Error { readonly statusCode = 404; readonly code = 'NOT_FOUND' }
export class ValidationError extends Error {
  readonly statusCode = 400; readonly code = 'VALIDATION_ERROR'
  constructor(message: string, readonly field?: string) { super(message) }
}
export class BusinessRuleError extends Error {
  readonly statusCode = 422; readonly code: string
  constructor(code: string, message: string) { super(message); this.code = code }
}
export class VersionConflictError extends Error {
  readonly statusCode = 409; readonly code = 'VERSION_CONFLICT'
  constructor(readonly currentState: unknown) { super('Resource was modified by another request') }
}
export class RateLimitError extends Error {
  readonly statusCode = 429; readonly code = 'RATE_LIMIT_EXCEEDED'
  constructor(readonly retryAfterSeconds: number) { super('Rate limit exceeded') }
}
export class ServiceUnavailableError extends Error {
  readonly statusCode = 503; readonly code = 'SERVICE_UNAVAILABLE'
  constructor(readonly retryAfterSeconds: number) { super('Service temporarily unavailable') }
}

export function globalErrorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  // R-7: 409 version conflict — R-5 exception: must include current entity state in data
  if (err instanceof VersionConflictError) {
    res.status(409).json({
      errors: [{ code: err.code, message: err.message }],
      data: err.currentState,
      meta: makeMeta('Conflict'),
    })
    return
  }

  // R-3: Retry-After header on 429 and 503
  if (err instanceof RateLimitError) {
    res.status(429)
      .set('Retry-After', String(err.retryAfterSeconds))
      .json(errorBody(err.code, err.message, 'TooManyRequests'))
    return
  }
  if (err instanceof ServiceUnavailableError) {
    res.status(503)
      .set('Retry-After', String(err.retryAfterSeconds))
      .json(errorBody(err.code, err.message, 'ServiceUnavailable'))
    return
  }

  // R-7: typed domain errors → correct status code
  if (err instanceof NotFoundError) {
    res.status(404).json(errorBody(err.code, err.message, 'NotFound'))
    return
  }
  if (err instanceof ValidationError) {
    const body = errorBody(err.code, err.message, 'BadRequest')
    if (err.field) body.errors[0].details = { field: err.field }
    res.status(400).json(body)
    return
  }
  if (err instanceof BusinessRuleError) {
    res.status(422).json(errorBody(err.code, err.message, 'UnprocessableEntity'))
    return
  }

  // R-7: NEVER return 200 for error conditions — catch-all returns 500
  console.error('Unhandled error', err)
  res.status(500).json(errorBody('INTERNAL_ERROR', 'An unexpected error occurred', 'InternalError'))
}

// R-5, R-8: error responses have errors + meta ONLY — never a data field
function errorBody(code: string, message: string, statusCode: string): ErrorResponse {
  return { errors: [{ code, message }], meta: makeMeta(statusCode) }
}
```

```typescript
// src/core/app.ts — register AFTER all routes; must be last middleware
import { globalErrorHandler } from './middleware/errorHandler'

app.use(globalErrorHandler)
```

## Verification

1. Confirm `requireClientAgent` and `compression()` are registered before route handlers:
   ```bash
   grep -n 'requireClientAgent\|compression\|app\.use' src/core/app.ts
   ```
   Both must appear before the first route `app.use()` call.

2. Confirm `globalErrorHandler` is the last `app.use()` call:
   ```bash
   grep -n 'app\.use' src/core/app.ts | tail -5
   ```
   `globalErrorHandler` must be the final entry.

3. Check that no route handler calls `res.status(200)` for error conditions:
   ```bash
   grep -rn 'status(200)' src/core/routes/
   ```
   Any match in an error path is a R-7 violation.

4. Confirm POST handlers use `respondCreated()` (not `respondOk()`):
   ```bash
   grep -rn 'router\.post\|\.post(' src/core/routes/ | xargs grep -L 'respondCreated'
   ```
   Any file listed uses the wrong helper for creates — replace with `respondCreated(res, data, location)`.

5. Confirm `Retry-After` is set on 429/503 — check `RateLimitError` and `ServiceUnavailableError`
   constructors are always called with a `retryAfterSeconds` argument:
   ```bash
   grep -rn 'RateLimitError\|ServiceUnavailableError' src/
   ```
   Every throw must pass a numeric seconds argument.

6. Run the linter — all source files must pass with no errors:
   ```bash
   yarn lint
   ```
