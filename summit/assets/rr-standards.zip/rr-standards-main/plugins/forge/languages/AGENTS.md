# Language Guides

## Directory purpose

This directory contains implementation guides for rr-standards across the languages
and specification formats used at Rakuten Rewards. Each subdirectory covers one
language or spec format and its guides for translating language-agnostic standards
into concrete, idiomatic implementations.

## Directory layout

```
languages/
├── AGENTS.md              ← this file
├── <language>/
│   ├── AGENTS.md          ← language-specific navigation and version selection rules
│   ├── default/           ← guides for the recommended version of this language
│   │   └── guides/
│   └── <version>/         ← guides for a specific older (or alternative) version
│       └── guides/
```

**Examples of version directories:**

| Language     | default points to      | Version dirs you may find  |
|--------------|------------------------|----------------------------|
| `java`       | Java 21 (LTS)          | `8/`, `11/`, `21/`, `25/`  |
| `openapi`    | OpenAPI 3.x            | `3.0/`, `3.1/`             |
| `go`         | latest stable          | `1.21/`, `1.22/`           |
| `typescript` | current stable (5.x)   | —                          |
| `kotlin`     | current stable         | —                          |
| `swift`      | current stable (uses `current/` dir) | —            |

## Choosing a version

The rules below apply to every language unless the language's own `AGENTS.md`
overrides them. **Version is always detected from the project — never asked of the user.**

1. **Detect from project files first.** Before loading any guides, inspect the
   project's build and configuration files to determine the language version in use.
   See the language's own `AGENTS.md` for which files and fields to inspect.

2. **Match to a version directory.** Using the detected version, check whether a
   matching directory exists (e.g. `java/8/guides/`). See the language's own
   `AGENTS.md` for version matching conventions.

3. **Fall back to `default/` when undetectable or unmatched.** If no version signal
   is found in the project, or if no directory matches the detected version, load
   guides from `default/`. Note the fallback in your response so the user can verify
   the assumption.

## Avoiding duplication

Guides are **not** duplicated across version directories. If a pattern is unchanged
between versions, it lives only in `default/`. Version-specific directories should
contain only the guides that differ from `default/`. When loading guides for an older
version, check whether the relevant guide exists in the version directory; if it does
not, fall back to `default/` for that guide.

## Languages available

| Language   | Directory      | Notes |
|------------|----------------|-------|
| Go         | `go/`          | Server-side services |
| Java       | `java/`        | Version dirs: `default/` (Java 21 LTS), `8/` |
| Kotlin     | `kotlin/`      | Version dirs: `default/` |
| OpenAPI    | `openapi/`     | REST API contract specification; version dirs: `default/` |
| Swift      | `swift/`       | Version dirs: `current/` |
| TypeScript | `typescript/`  | Version dirs: `default/` |

*Add a row here whenever a new language directory is introduced.*

## Navigation

- [Standards root](../standards/) — language-agnostic standards these guides implement
- [Forge plugin root](../README.md) — plugin overview
