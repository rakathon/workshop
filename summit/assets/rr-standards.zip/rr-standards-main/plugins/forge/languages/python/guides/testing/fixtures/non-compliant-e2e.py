"""Non-compliant E2E test — Django TestClient, django_db, hardcoded URL, raise instead of skip."""
from __future__ import annotations

import unittest

import pytest
from django.test import TestCase, Client


# WRONG: inherits from Django's TestCase — spins up Django test infrastructure locally.
# E2E tests must use plain pytest functions with session-scoped fixtures.
class PointsE2ETest(TestCase):

    def setUp(self) -> None:
        # WRONG: Django TestClient calls the local WSGI app, not the deployed service.
        self.client = Client()

    # WRONG: @pytest.mark.django_db accesses the local test database.
    # E2E tests must never touch internal state — only HTTP-observable behaviour.
    @pytest.mark.django_db
    def test_earn_points(self) -> None:
        # WRONG: hardcoded localhost URL — should load from e2e.ini via base_url fixture.
        import requests
        response = requests.get("http://localhost:8000/points/v1/members/member-1/balance")

        # WRONG: raises an exception instead of pytest.skip() when token is missing.
        # E2E tests should skip gracefully so CI does not fail when no server is running.
        import os
        token = os.getenv("AUTH_TOKEN")
        if not token:
            raise ValueError("AUTH_TOKEN is not set")  # should be pytest.skip(...)

        # WRONG: using Django TestClient instead of the session-scoped requests.Session.
        resp = self.client.get("/points/v1/members/member-1/balance")
        self.assertEqual(resp.status_code, 200)
        # WRONG: accessing response body without checking the envelope first.
        # If RESPONSE_ENVELOPE=True, fields are nested under response.json()["data"].
        self.assertIsNotNone(resp.json()["balance"])  # should be resp.json()["data"]["balance"]

    # WRONG: no @pytest.mark.smoke or @pytest.mark.regression — test cannot be filtered.
    def test_unauthenticated(self) -> None:
        resp = self.client.get("/points/v1/members/member-1/balance")
        # WRONG: fixture is not session-scoped and re-creates state for every test.
        self.assertEqual(resp.status_code, 401)
