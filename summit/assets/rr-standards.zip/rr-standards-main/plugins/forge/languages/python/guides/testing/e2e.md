# Python Guide — End-to-End Testing

Guide: 1.0.1 | Implements: standards/testing/e2e.md@1.0.0

## Overview

Shows how to write end-to-end tests for a Python API service using pytest and the
`requests` library. E2E tests issue real HTTP requests against a **deployed service
instance** (local, QA, lt1, prod, or any other configured environment) and validate
observable HTTP behaviour.
These tests do not start the application, do not use Django/FastAPI/Flask test clients,
and do not use Testcontainers.

Supports Django (with optional DRF response envelope), FastAPI, and Flask. The
framework detection only affects auth header patterns — the framework structure is
identical across all three.

**E2E vs Integration Testing:**

| Aspect | E2E (this guide) | Integration |
|---|---|---|
| Target | Real deployed service via HTTP | Django/FastAPI/Flask TestClient + containers |
| Libraries | pytest, requests | pytest, TestClient, Testcontainers |
| Location | `tests/system/e2e/` | `tests/integration/` |
| DB marker | Never `@pytest.mark.django_db` | May use Django test DB |

## Related standard

[E2E Testing Standard](../../../../standards/testing/e2e.md)

## Prerequisites

Use the project's existing virtual environment — it already includes pytest and requests.

One additional dev dependency is required for request/response logging:

```bash
pip install structlog
# or add to pyproject.toml / requirements-dev.txt:
# structlog>=23.0
```

Use `pytest` and the `requests` library for HTTP calls. Do not substitute `httpx`,
`unittest.mock`, or any other HTTP client.

---

## HTTP request/response logging

Every HTTP call made through `api_session` is automatically logged via `structlog` so
the output is captured by pytest's stdout capture into the JUnit XML `<system-out>`
element for that specific test case. No per-test boilerplate is required — the response
hook fires automatically after every request.

---

## Implementation

### Framework detection file

The presence of this file indicates the E2E framework is already installed:
```text
tests/system/e2e/conftest.py
```

If this file exists, add tests only (ADD_TEST_ONLY mode). If absent, generate the complete framework (FULL_FRAMEWORK mode).

### Web framework detection

Detect the web framework for auth pattern context:

1. Check `requirements.txt`, `pyproject.toml`, or `setup.cfg`:
   - `django` or `djangorestframework` → Django
   - `fastapi` → FastAPI
   - `flask` → Flask

2. Fall back to scanning source imports if dependency files are ambiguous.

3. **DRF response envelope (Django only):** Search for a renderer class extending
   `BaseRenderer` or `JSONRenderer`. If found, the API wraps responses in
   `{"meta": …, "data": {…}}` — test assertions must access `response.json()["data"]`.

---

### Full framework setup (FULL_FRAMEWORK mode)

Generate these files:

#### `tests/system/e2e/config/e2e_config.py` — config enums

```python
from __future__ import annotations

import configparser
import os
from enum import Enum
from pathlib import Path

_CONFIG_PATH = Path(__file__).parent / "e2e.ini"


class E2EConfig(Enum):
    """Non-sensitive configuration keys — loaded from e2e.ini."""
    BASE_URL = "base_url"
    # Add additional non-sensitive keys as needed


class E2ESecret(Enum):
    """Sensitive keys — loaded from environment variables."""
    ENVIRONMENT_TO_TEST = "ENVIRONMENT_TO_TEST"
    API_KEY = "API_KEY"
    AUTH_TOKEN = "AUTH_TOKEN"
    # Add additional secret keys as needed


def load_config() -> dict[E2EConfig, str]:
    """Load non-sensitive config for the current environment."""
    env = os.getenv(E2ESecret.ENVIRONMENT_TO_TEST.value, "local")
    parser = configparser.ConfigParser()
    parser.read(_CONFIG_PATH)
    if not parser.has_section(env):
        raise KeyError(f"No [{env}] section in e2e.ini")
    return {key: parser.get(env, key.value) for key in E2EConfig}


def load_secrets() -> dict[E2ESecret, str | None]:
    """Load sensitive config from environment variables."""
    return {key: os.getenv(key.value) for key in E2ESecret}
```

#### `tests/system/e2e/conftest.py` — session-scoped fixtures

```python
from __future__ import annotations

from typing import Any

import pytest
import requests
import structlog

from tests.system.e2e.config.e2e_config import E2EConfig, E2ESecret, load_config, load_secrets


def _log_api_call(response: requests.Response, **kwargs: Any) -> None:
    log = structlog.get_logger()
    log.info(
        "api_call",
        method=response.request.method,
        url=response.request.url,
        request_headers=dict(response.request.headers),
        request_body=response.request.body,
        status_code=response.status_code,
        response_headers=dict(response.headers),
        response_body=response.text,
    )


@pytest.fixture(scope="session")
def e2e_config() -> dict[E2EConfig, str]:
    """Load non-sensitive E2E configuration once per test session."""
    try:
        return load_config()
    except Exception as exc:
        pytest.skip(f"E2E config unavailable: {exc}")


@pytest.fixture(scope="session")
def e2e_secrets() -> dict[E2ESecret, str | None]:
    """Load E2E secrets from environment variables once per test session."""
    return load_secrets()


@pytest.fixture(scope="session")
def base_url(e2e_config: dict) -> str:
    """Resolved base URL for the target environment."""
    url = e2e_config.get(E2EConfig.BASE_URL)
    if not url:
        pytest.skip("BASE_URL not configured — skipping E2E tests")
    return url


@pytest.fixture(scope="session")
def api_session(base_url: str) -> requests.Session:
    """Pre-configured requests.Session with base headers, shared for the entire session."""
    session = requests.Session()
    session.headers.update({
        "Content-Type": "application/json",
        "Accept": "application/json",
    })
    session.hooks["response"].append(_log_api_call)
    yield session
    session.close()
```

#### `tests/system/e2e/config/e2e.ini` — environment URLs

```ini
# E2E Test Configuration — non-sensitive values only
# Sensitive values (API keys, tokens) go in environment variables
# Set ENVIRONMENT_TO_TEST to any configured environment name before running tests
# Environment names are arbitrary — add entries for every environment the project uses

[local]
base_url = http://localhost:8000

[qa]
base_url = https://api-qa.example.com

[lt1]
base_url = https://api-lt1.example.com

[prod]
base_url = https://api.example.com
```

Add sections only for the environments the project uses.

#### `tests/system/e2e/pyproject.toml` — isolated pytest configuration

**Do NOT modify the project's root `pyproject.toml`.** The root config may have
`addopts = "--cov-fail-under=80"` which fails when E2E tests skip due to no server.
Instead, create an isolated pytest config in the E2E directory:

```toml
[tool.pytest.ini_options]
# "../../.." resolves to the project root so `tests.system.e2e.*` imports work
pythonpath = ["../../..", "."]
markers = [
    "e2e_smoke: smoke tests — fast validation of critical paths",
    "e2e_regression: regression tests — full workflow validation",
    "e2e_non_production: destructive tests — creates or mutates data; never run in production",
]
```

When `pytest tests/system/e2e/` is run from the project root, pytest uses this file as
rootdir — fully isolated from the app's coverage config.

#### `__init__.py` files — make `tests` a Python package

Create empty files at:
- `tests/__init__.py`
- `tests/system/__init__.py`
- `tests/system/e2e/__init__.py`
- `tests/system/e2e/config/__init__.py`

These are required for the `from tests.system.e2e.config...` import in `conftest.py`.

---

### Adding a test (ADD_TEST_ONLY mode)

Read existing `conftest.py` to confirm fixture names. Generate only the new test file
in `tests/system/e2e/`.

```python
from __future__ import annotations

import pytest
import requests

from tests.system.e2e.config.e2e_config import E2ESecret


@pytest.mark.e2e_smoke
def test_sc<n>_<description>(base_url: str, api_session: requests.Session) -> None:
    """SC-<N> | Verifies: BR-<N> — validates the complete <description> flow against the real deployed service."""

    # Step 1: First API call
    response = api_session.post(
        f"{base_url}/api/v1/resource",
        json={"field": "value"},
    )
    assert response.status_code == 201, response.text
    body = response.json()
    # If DRF response envelope: body = response.json()["data"]
    resource_id = body["data"]["id"]
    assert resource_id, "expected non-empty resource ID"

    # Step 2: Follow-up call
    response = api_session.get(f"{base_url}/api/v1/resource/{resource_id}")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["data"]["id"] == resource_id
```

**With authentication:**
```python
# Bearer token (FastAPI / Flask / DRF JWT)
api_session.headers["Authorization"] = f"Bearer {e2e_secrets[E2ESecret.AUTH_TOKEN]}"

# DRF Token auth
api_session.headers["Authorization"] = f"Token {e2e_secrets[E2ESecret.AUTH_TOKEN]}"

# API key
api_session.headers["X-API-Key"] = e2e_secrets[E2ESecret.API_KEY]
```

Skip gracefully when required secrets are absent:
```python
if not e2e_secrets.get(E2ESecret.AUTH_TOKEN):
    pytest.skip("AUTH_TOKEN environment variable is not set")
```

**DRF response envelope:**
When `RESPONSE_ENVELOPE = True`, access nested data:
```python
body = response.json()
assert "data" in body, f"Expected envelope, got: {body}"
resource = body["data"]
```

**Test marks:**
- `@pytest.mark.e2e_smoke` — fast critical-path tests
- `@pytest.mark.e2e_regression` — full workflow validation
- `@pytest.mark.e2e_non_production` — destructive tests that must not run in production

**File naming:** `test_sc<n>_<description>_e2e.py` — e.g., `test_sc1_earn_points_e2e.py`
**Function naming:** `test_sc<n>_<description>` — e.g., `test_sc1_earn_points_returns_201`

---

### Configuration

Non-sensitive values live in `tests/system/e2e/config/e2e.ini`, sectioned by
environment. Secrets are sourced from environment variables at session startup via
`load_secrets()`. Never commit secrets to `e2e.ini`.

The `ENVIRONMENT_TO_TEST` value is arbitrary — any name is valid as long as a matching
`[<name>]` section exists in `e2e.ini` (e.g. `qa1`, `lt1`, `qa1geo1`).

---

### Running the tests

```bash
# Activate the project venv (already has pytest + requests)
source .venv/bin/activate

# Set environment (optional — defaults to local)
export ENVIRONMENT_TO_TEST=local

# Run all E2E tests
pytest tests/system/e2e/

# Run only smoke tests
pytest tests/system/e2e/ -m e2e_smoke

# Run regression tests
pytest tests/system/e2e/ -m e2e_regression

# Run against lt1
ENVIRONMENT_TO_TEST=lt1 pytest tests/system/e2e/

# Run against any environment
ENVIRONMENT_TO_TEST=qa1geo1 pytest tests/system/e2e/

# With auth token
AUTH_TOKEN=your-token pytest tests/system/e2e/

# Verbose
pytest tests/system/e2e/ -v
```

---

## Verification

1. Confirm no `@pytest.mark.django_db` in any E2E test — these are pure HTTP client tests.
2. Confirm no Django/FastAPI/Flask TestClient usage — calls go to real deployed URLs.
3. Confirm all fixtures are `scope="session"`.
4. Confirm `pytest.skip()` (not `raise`) is used when config or secrets are absent.
5. Confirm `tests/system/e2e/pyproject.toml` exists and root `pyproject.toml` was NOT modified.
6. Confirm `__init__.py` files exist at all four package levels.
7. Confirm `conftest.py` defines `_log_api_call` using `structlog`.
8. Confirm `api_session` fixture mounts `_log_api_call` on `session.hooks["response"]`.
9. Run `pytest tests/system/e2e/ -v` — tests must pass or skip cleanly.
10. Run `ruff check tests/system/e2e/` — zero violations required.
