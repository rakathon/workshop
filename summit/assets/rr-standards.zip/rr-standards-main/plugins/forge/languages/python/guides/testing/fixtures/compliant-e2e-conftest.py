"""Compliant E2E conftest — _log_api_call mounted on session.hooks["response"] via structlog."""
from __future__ import annotations

from typing import Any

import pytest
import requests
import structlog

from tests.system.e2e.config.e2e_config import E2EConfig, E2ESecret, load_config, load_secrets


def _log_api_call(response: requests.Response, **kwargs: Any) -> None:
    log = structlog.get_logger()
    log.info(
        "api_call",
        method=response.request.method,
        url=response.request.url,
        request_headers=dict(response.request.headers),
        request_body=response.request.body,
        status_code=response.status_code,
        response_headers=dict(response.headers),
        response_body=response.text,
    )


@pytest.fixture(scope="session")
def e2e_config() -> dict[E2EConfig, str]:
    """Load non-sensitive E2E configuration once per test session."""
    try:
        return load_config()
    except Exception as exc:
        pytest.skip(f"E2E config unavailable: {exc}")


@pytest.fixture(scope="session")
def e2e_secrets() -> dict[E2ESecret, str | None]:
    """Load E2E secrets from environment variables once per test session."""
    return load_secrets()


@pytest.fixture(scope="session")
def base_url(e2e_config: dict) -> str:
    """Resolved base URL for the target environment."""
    url = e2e_config.get(E2EConfig.BASE_URL)
    if not url:
        pytest.skip("BASE_URL not configured — skipping E2E tests")
    return url


@pytest.fixture(scope="session")
def api_session(base_url: str) -> requests.Session:
    """Pre-configured requests.Session with base headers and automatic API call logging."""
    session = requests.Session()
    session.headers.update({
        "Content-Type": "application/json",
        "Accept": "application/json",
    })
    session.hooks["response"].append(_log_api_call)
    yield session
    session.close()
