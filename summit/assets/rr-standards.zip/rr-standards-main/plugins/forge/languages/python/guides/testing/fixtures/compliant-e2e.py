"""Compliant E2E test — session fixtures, requests, pytest.skip, env guard, unique ID."""
from __future__ import annotations

import pytest
import requests

from tests.system.e2e.config.e2e_config import E2ESecret


# @pytest.mark.e2e_non_production: creates and deletes test data — never run in production
@pytest.mark.e2e_smoke
@pytest.mark.e2e_non_production
def test_sc1_earn_points_and_balance_is_updated(
    base_url: str,
    api_session: requests.Session,
    e2e_secrets: dict,
) -> None:
    """SC-1 | Verifies: BR-1 — validates the earn-points flow against the real deployed service."""
    env = e2e_secrets.get(E2ESecret.ENVIRONMENT_TO_TEST) or "local"
    if env == "production":
        pytest.skip("SC-1 creates test data — skipping in production environment")

    auth_token = e2e_secrets.get(E2ESecret.AUTH_TOKEN)
    if not auth_token:
        pytest.skip("AUTH_TOKEN environment variable is not set")

    api_session.headers["Authorization"] = f"Bearer {auth_token}"

    # Deterministic synthetic ID: service name + fixed test-run seed makes data
    # identifiable and reproducible when TEST_RUN_ID is set in CI (R-4, R-8)
    test_run_id = e2e_secrets.get(E2ESecret.ENVIRONMENT_TO_TEST) or "local"
    member_id = f"test-member-sc1-{test_run_id}"

    # Step 1: Capture pre-earn balance
    response = api_session.get(f"{base_url}/points/v1/members/{member_id}/balance")
    assert response.status_code == 200, response.text
    body = response.json()
    assert "data" in body, f"expected envelope, got: {body}"
    before_balance = body["data"]["balance"]

    # Step 2: Earn points via a qualifying transaction
    response = api_session.post(
        f"{base_url}/points/v1/members/{member_id}/transactions",
        json={"amount_cents": 1000, "merchant_id": "merchant-e2e"},
    )
    assert response.status_code == 201, response.text
    body = response.json()
    assert "data" in body, f"expected envelope, got: {body}"
    transaction_id = body["data"]["transaction_id"]
    assert transaction_id, "expected non-empty transaction_id"
    points_earned = body["data"]["points_earned"]
    assert points_earned > 0, f"expected points_earned > 0, got {points_earned}"

    # Clean up test data after the test (non-production only — guarded above)
    try:
        # Step 3: Verify the balance increased by the earned points (complete observable journey)
        response = api_session.get(f"{base_url}/points/v1/members/{member_id}/balance")
        assert response.status_code == 200, response.text
        body = response.json()
        assert "data" in body, f"expected envelope, got: {body}"
        assert body["data"]["balance"] == before_balance + points_earned, (
            f"expected balance {before_balance + points_earned} after earn, "
            f"got {body['data']['balance']}"
        )
    finally:
        api_session.delete(
            f"{base_url}/points/v1/members/{member_id}/transactions/{transaction_id}"
        )
