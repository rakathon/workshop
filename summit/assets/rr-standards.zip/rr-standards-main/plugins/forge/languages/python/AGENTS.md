# languages/python/

This directory contains language-specific implementation guides for Python. Each guide
shows how to implement a companion language-agnostic standard using idiomatic Python
and the libraries chosen by this project. Guides are organised under `guides/<domain>/`
to mirror the structure of the `standards/` directory.

## File index

| File | Purpose | When to reference |
|---|---|---|
| `guides/` | Language-specific implementation guides, organised by domain, mirroring the `standards/` directory structure | When looking for Python implementation guidance for a specific standard domain |
| `guides/testing/e2e.md` | Python implementation of the E2E testing standard — pytest + requests patterns, session-scoped fixtures, INI-based configuration, framework auto-detection (Django / FastAPI / Flask) | When generating or reviewing E2E tests for a Python service |
| `guides/testing/e2e.test.yaml` | Golden examples for behavioral validation of the Python E2E testing guide — compliant and non-compliant test snippets | When running behavioral effectiveness tests or adding new test cases for the Python E2E guide |

## Navigation

- [Standards taxonomy](../../standards/TAXONOMY.md) — artifact types, naming conventions, and directory structure for this plugin
- [E2E Testing standard](../../standards/testing/e2e.md) — language-agnostic rules that the Python guides implement

## Linter

**Linter:** `ruff` (linting) + `mypy` (type checking)
**Config file:** `pyproject.toml` at the repository root

All Python code generated from guides in this directory must pass `ruff check` and
`mypy`. Individual guides must not restate lint rules — this is the single authoritative
linter declaration for Python in this plugin.
