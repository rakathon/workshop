# Java 8 Guide — Integration Testing

Guide: 1.0.0 | Implements: standards/testing/integration-testing.md@1.0.0

## Overview

Shows how to satisfy the Integration Testing standard in Java 8 using Spring Boot
2.7.x Test and Testcontainers. Testcontainers supports Java 8 natively. Uses
`javax.servlet.*` in MockMvc configurations and avoids `var`. All container
lifecycle and property injection patterns are identical to the Java 21 guide.

## Related standard

[Integration Testing Standard](../../../../../../../standards/testing/integration-testing.md)

## Prerequisites

- Spring Boot 2.7.x (`spring-boot-starter-test`)
- Testcontainers (`org.testcontainers:testcontainers`,
  `testcontainers:postgresql`, `testcontainers:kafka`)
- AWS SDK v2 with DynamoDB Local for DynamoDB tests

Maven test dependencies:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.testcontainers</groupId>
    <artifactId>junit-jupiter</artifactId>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.testcontainers</groupId>
    <artifactId>postgresql</artifactId>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.testcontainers</groupId>
    <artifactId>kafka</artifactId>
    <scope>test</scope>
</dependency>
```

---

## Implementation

### Base integration test class

Start containers once per JVM run using `static` lifecycle. Use
`@DynamicPropertySource` to inject container addresses before the Spring context
starts.

```java
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@Testcontainers
public abstract class IntegrationTestBase {

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("rewards_test")
            .withUsername("test")
            .withPassword("test");

    @Container
    static KafkaContainer kafka =
        new KafkaContainer(
            DockerImageName.parse("confluentinc/cp-kafka:7.6.0"));

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        registry.add("spring.kafka.bootstrap-servers",
            kafka::getBootstrapServers);
    }

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected ObjectMapper objectMapper;
}
```

### Testing repository interactions (FR-1, FR-5)

Test your repository's behavior against a real PostgreSQL container. Use
`@Transactional` to roll back after each test.

```java
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@Transactional
class StoreRepositoryIntegrationTest extends IntegrationTestBase {

    @Autowired
    private StoreRepository storeRepository;

    @Test
    void givenStoreSaved_whenFindById_thenReturnsStore() {
        // Arrange
        Store store = Store.builder()
            .id(UUID.randomUUID())
            .name("Test Store")
            .versionToken(UUID.randomUUID())
            .createdAt(Instant.now())
            .updatedAt(Instant.now())
            .build();
        storeRepository.save(store);

        // Act
        Optional<Store> found = storeRepository.findById(store.getId());

        // Assert
        assertThat(found).isPresent();
        assertThat(found.get().getName()).isEqualTo("Test Store");
    }

    @Test
    void givenNonExistentId_whenFindById_thenReturnsEmpty() {
        Optional<Store> found = storeRepository.findById(UUID.randomUUID());
        assertThat(found).isEmpty();
    }

    @Test
    void givenVersionTokenMismatch_whenReplace_thenThrowsVersionConflict() {
        // Arrange
        Store store = storeRepository.save(Store.builder()
            .id(UUID.randomUUID())
            .name("Store A")
            .versionToken(UUID.randomUUID())
            .createdAt(Instant.now())
            .updatedAt(Instant.now())
            .build());
        UUID staleToken = UUID.randomUUID();

        // Act / Assert
        assertThatThrownBy(
            () -> storeRepository.replaceWithVersionCheck(
                store.getId(), "Store B", staleToken))
            .isInstanceOf(VersionConflictException.class);
    }
}
```

### Testing the HTTP layer — MockMvc (FR-1)

```java
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.exists;
import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class StoreControllerIntegrationTest extends IntegrationTestBase {

    @Test
    void givenValidRequest_whenCreateStore_thenReturns201WithLocation()
        throws Exception {

        CreateStoreRequest body = new CreateStoreRequest("New Store");
        String json = objectMapper.writeValueAsString(body);

        mockMvc.perform(
                post("/store/v1/stores")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Client-Agent", "test-service/1.0.0")
                    .content(json))
            .andExpect(status().isCreated())
            .andExpect(header().exists("Location"))
            .andExpect(jsonPath("$.data.name").value("New Store"))
            .andExpect(jsonPath("$.meta.operation.request_id")
                .value(notNullValue()));
    }

    @Test
    void givenMissingClientAgent_whenListStores_thenReturns400()
        throws Exception {

        mockMvc.perform(get("/store/v1/stores"))
            .andExpect(status().isBadRequest());
    }

    @Test
    void givenMalformedBody_whenCreateStore_thenReturns400WithErrorsArray()
        throws Exception {

        mockMvc.perform(
                post("/store/v1/stores")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Client-Agent", "test-service/1.0.0")
                    .content("{invalid json"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.errors").isArray())
            .andExpect(jsonPath("$.errors[0].code").exists());
    }
}
```

### Testing Kafka consumer interactions (FR-1, FR-2)

```java
import org.springframework.kafka.core.KafkaTemplate;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

class OrderEventConsumerIntegrationTest extends IntegrationTestBase {

    @Autowired
    private KafkaTemplate<String, OrderEvent> kafkaTemplate;

    @Autowired
    private OrderRepository orderRepository;

    @Test
    void givenOrderCreatedEvent_whenConsumed_thenOrderPersistedInDatabase()
        throws Exception {

        String orderId = UUID.randomUUID().toString();
        OrderEvent event = OrderEvent.builder()
            .orderId(orderId)
            .type("CREATED")
            .occurredAt(Instant.now())
            .build();

        kafkaTemplate.send("order-events", orderId, event).get();

        await()
            .atMost(10, TimeUnit.SECONDS)
            .pollInterval(200, TimeUnit.MILLISECONDS)
            .untilAsserted(() ->
                assertThat(orderRepository.findById(orderId)).isPresent());
    }
}
```

### Test data isolation

**Prefer `@Transactional`** on test classes — Spring rolls back after each test:

```java
@Transactional
class UserRepositoryIntegrationTest extends IntegrationTestBase { ... }
```

**Use `@Sql`** when the code under test commits its own transaction:

```java
import org.springframework.test.context.jdbc.Sql;

@Sql(scripts = "/sql/insert-stores.sql",
     executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
@Sql(scripts = "/sql/delete-stores.sql",
     executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
@Test
void givenExistingStores_whenListStores_thenReturnsPagedResults() { ... }
```

---

## Verification

1. Run `mvn verify` — all integration tests must pass and containers must start
   without errors.
2. Grep for `@Mock` in integration test classes — confirm no external component
   (database, Kafka, cache) is mocked; all use real Testcontainers instances.
3. Confirm each test class extends `IntegrationTestBase` and does not spin up
   separate container instances.
4. Time the full integration test run — must complete in under 15 minutes.
5. Grep for `var ` in test files — must be zero (Java 8 does not support `var`).
6. Run `mvn checkstyle:check` — zero violations required.
