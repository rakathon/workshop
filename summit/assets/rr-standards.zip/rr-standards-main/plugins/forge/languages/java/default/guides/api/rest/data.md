# Java Guide — REST API Data

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/data.md@1.0.0

## Overview

Shows how to satisfy the REST API Data standard in a Spring Boot 3.x service. Covers
Java record types for cursor and offset pagination, `version_token` on mutable
resources, `Instant` serialization for timestamps, a `DecimalValue` value object for
precision-sensitive numbers, a `MoneyAmount` value object for currency, and tracing
header propagation. A service that follows this guide represents data fields without
precision loss and supports concurrent writers without data races.

## Related standard

[REST API Data](../../../../../../standards/api/rest/data.md)

## Prerequisites

- Spring Boot 3.x with Jackson snake_case configured (see `contracts.md`)
- `java.time.Instant` for timestamps (no external library required)
- `io.opentelemetry:opentelemetry-api` for tracing context propagation

---

## Implementation

### Pagination response types (R-1, R-2)

Define both pagination styles as Java records. Use cursor-based pagination by default;
offset-based only when the UI requires page-number navigation.

```java
// Default — forward-only cursor pagination
public record CursorPagination(
    @Nullable String next) {}          // absent on the last page

// Cursor pagination with backward navigation
// Add 'previous' only when clients need to go back through results
public record CursorPaginationBidirectional(
    @Nullable String next,
    @Nullable String previous) {}      // absent on the first page

// Offset pagination — only when UI requires page numbers
public record OffsetPagination(
    int numPages,
    int numResults) {}
```

Every collection controller method **must** accept a `limit` (or `size`) parameter to
bound the response (R-1). Never return an unbounded list.

```java
@GetMapping
public ResponseEntity<ListResponse<Store>> listStores(
    @RequestParam(defaultValue = "20") @Min(1) @Max(100) int limit,
    @RequestParam(required = false) String cursor,
    HttpServletRequest request) {

    var page = storeService.findAll(cursor, limit);
    var pagination = page.hasNext()
        ? new CursorPagination(page.nextCursor())
        : new CursorPagination(null);

    return ResponseEntity.ok(
        new ListResponse<>(page.items(), pagination,
            Meta.ok(RequestContext.requestId(request))));
}
```

Offset-based pagination parameters when UI navigation requires it:

```java
@GetMapping
public ResponseEntity<ListResponse<Report>> listReports(
    @RequestParam(defaultValue = "1") @Min(1) int page,
    @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size,
    HttpServletRequest request) {

    var result = reportService.findAll(page, size);
    var pagination = new OffsetPagination(result.totalPages(), result.total());
    return ResponseEntity.ok(
        new ListResponse<>(result.items(), pagination,
            Meta.ok(RequestContext.requestId(request))));
}
```

### Optimistic concurrency — `version_token` (R-3)

Every resource that supports `PUT` or `PATCH` must include a `version_token` UUID
field. The client echoes the token unchanged on write; the service returns `409` with
the current entity state if the token does not match.

```java
// Resource record — returned on GET
public record Store(
    UUID id,
    String name,
    UUID versionToken,    // required; mapped to "version_token" by Jackson
    Instant createdAt,
    Instant updatedAt) {}

// Write request — version_token is required
public record ReplaceStoreRequest(
    @NotBlank String name,
    @NotNull UUID versionToken) {}   // clients must always send the current token
```

Service-layer optimistic concurrency check:

```java
@Service
public class StoreService {

    public Store replace(String storeId, ReplaceStoreRequest request) {
        Store current = repository.findById(storeId)
            .orElseThrow(() -> new ResourceNotFoundException(storeId));

        if (!current.versionToken().equals(request.versionToken())) {
            // Return the current entity so the client can retry with the latest token
            throw new VersionConflictException(current);
        }
        Store updated = current.withName(request.name())
            .withVersionToken(UUID.randomUUID())
            .withUpdatedAt(Instant.now());
        return repository.save(updated);
    }
}
```

### Timestamp format — `Instant` to ISO 8601 (R-4)

Use `java.time.Instant` for all timestamp fields. Jackson serializes `Instant` to
ISO 8601 UTC (`2024-06-15T09:30:00Z`) when dates-as-timestamps is disabled.

```java
// In JacksonConfig — disable epoch-second serialization
@Bean
public Jackson2ObjectMapperBuilderCustomizer timestampConfig() {
    return builder -> builder
        .featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
        .modules(new JavaTimeModule());
}
```

```java
// Correct — Instant serializes to "2024-06-15T09:30:00Z"
public record Store(
    UUID id,
    String name,
    Instant createdAt,
    Instant updatedAt) {}

// Wrong — long epoch integer
public record Store(
    UUID id,
    String name,
    long createdAt) {}   // violates R-4
```

### Decimal numbers — value/scale tuple (R-5)

Never use `double` or `float` for monetary, percentage, or other precision-sensitive
values. Define a `DecimalValue` record that represents the number as an integer
mantissa and a scale exponent.

```java
/**
 * Lossless decimal representation.
 * Real value = value × 10^(−scale).
 * Example: 15.00% → DecimalValue(1500, 2).
 */
public record DecimalValue(
    long value,     // unscaled integer mantissa
    int scale) {    // number of decimal places (exponent magnitude)

    public DecimalValue {
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
    }

    public BigDecimal toBigDecimal() {
        return new BigDecimal(value).movePointLeft(scale);
    }

    public static DecimalValue of(BigDecimal bd) {
        int s = bd.scale() < 0 ? 0 : bd.scale();
        long v = bd.movePointRight(s).longValueExact();
        return new DecimalValue(v, s);
    }
}
```

Usage in a response record:

```java
// Correct — lossless DecimalValue
public record Offer(
    UUID id,
    String name,
    DecimalValue discountPercentage) {}   // e.g., {"value": 1500, "scale": 2} = 15.00%

// Wrong — float loses precision
public record Offer(
    UUID id,
    String name,
    double discountPercentage) {}   // violates R-5
```

### Currency amounts (R-6)

```java
/**
 * Currency amount with explicit scale. ISO 4217 currency code required.
 * Example: $10.50 → MoneyAmount(1050, "USD", 2).
 */
public record MoneyAmount(
    long amount,       // integer amount in currency's smallest unit × 10^scale
    String currency,   // ISO 4217 code, e.g., "USD", "JPY", "EUR"
    int scale) {       // decimal places: 0 for JPY, 2 for USD/EUR

    public MoneyAmount {
        if (currency == null || currency.length() != 3) {
            throw new IllegalArgumentException(
                "currency must be a 3-character ISO 4217 code");
        }
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
    }
}
```

Usage:

```java
// Correct — { "amount": 1050, "currency": "USD", "scale": 2 } = $10.50
public record Wallet(
    UUID memberId,
    MoneyAmount balance) {}

// Wrong — float precision loss
public record Wallet(
    UUID memberId,
    double balance) {}   // violates R-6
```

### Distributed tracing — `traceparent` header (R-7)

Extract and propagate the W3C `traceparent` header on all inbound requests. With
OpenTelemetry this is handled automatically when the `opentelemetry-spring-boot-starter`
dependency is present; the trace context is attached to the MDC.

For services not yet using the OTel starter, extract manually:

```java
@Component
public class TracingInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(
        HttpServletRequest request,
        HttpServletResponse response,
        Object handler) {

        String traceparent = request.getHeader("traceparent");
        if (traceparent != null) {
            MDC.put("traceparent", traceparent);
            String tracestate = request.getHeader("tracestate");
            if (tracestate != null) {
                MDC.put("tracestate", tracestate);
            }
        }
        return true;
    }

    @Override
    public void afterCompletion(
        HttpServletRequest request,
        HttpServletResponse response,
        Object handler,
        @Nullable Exception ex) {

        MDC.remove("traceparent");
        MDC.remove("tracestate");
    }
}
```

### Localization — `Accept-Language` header (R-8)

Accept and honour the `Accept-Language` header. Fall back to the region default
when no accepted locale is available.

```java
@GetMapping("/offers/v1/regions/{region_id}/offers/{offer_id}")
public ResponseEntity<DataResponse<Offer>> getOffer(
    @PathVariable("region_id") String regionId,
    @PathVariable("offer_id") String offerId,
    @RequestHeader(
        value = "Accept-Language",
        required = false,
        defaultValue = "") String acceptLanguage,
    HttpServletRequest request) {

    Locale locale = LocaleUtils.resolve(acceptLanguage, regionId);
    Offer offer = offerService.find(offerId, locale);
    return ResponseEntity.ok(
        new DataResponse<>(offer,
            Meta.ok(RequestContext.requestId(request))));
}
```

---

## Verification

1. Inspect every collection endpoint and confirm a `limit` (or `size`) query
   parameter is present — no handler returns an unbounded list.
2. Inspect every resource record that has a `PUT` or `PATCH` handler and confirm it
   includes `version_token` (type `UUID`); the write request record also requires it.
3. Confirm the service layer throws `VersionConflictException` (mapped to `409`) when
   the token does not match, and the `409` response body includes the current entity state.
4. Send `GET` on a resource and confirm timestamp fields serialize to
   `"YYYY-MM-DDTHH:MM:SSZ"` — no epoch integers.
5. Confirm no field carrying a percentage, rate, or price uses `double` or `float`;
   all use `DecimalValue` or `MoneyAmount`.
6. Send a request with a `traceparent` header and confirm it appears in structured
   log output for that request.
7. Run `mvn checkstyle:check` — zero violations required.
