// Compliant Kafka producer config — idempotent with acks=all, JSON serializers
@Configuration
public class KafkaProducerConfig {
    @Bean
    public ProducerFactory<String, Object> producerFactory(KafkaProperties props) {
        Map<String, Object> config = new HashMap<>(props.buildProducerProperties(null));
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);  // exactly-once per partition
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate(
            ProducerFactory<String, Object> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }
}

// Compliant consumer config — deserializers, trusted packages, DLT routing after 3 attempts
@Configuration
public class KafkaConsumerConfig {

    @Bean
    public ConsumerFactory<String, Object> consumerFactory(KafkaProperties props) {
        Map<String, Object> config = new HashMap<>(props.buildConsumerProperties(null));
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        config.put(JsonDeserializer.TRUSTED_PACKAGES, "com.rakutenrewards.*");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory(
        ConsumerFactory<String, Object> consumerFactory,
        KafkaTemplate<String, Object> kafkaTemplate) {
        var factory = new ConcurrentKafkaListenerContainerFactory<String, Object>();
        factory.setConsumerFactory(consumerFactory);
        // DLT routing after 3 attempts (1 + 2 retries)
        factory.setCommonErrorHandler(new DefaultErrorHandler(
            new DeadLetterPublishingRecoverer(kafkaTemplate), new FixedBackOff(1_000L, 2L)));
        return factory;
    }
}

// Idempotent consumer — deduplicates by topic+orderId+offset key
@Component
public class OrderEventConsumer {
    @KafkaListener(topics = "order-events", groupId = "rewards-store-service",
        containerFactory = "kafkaListenerContainerFactory")
    @Transactional
    public void handleOrderCreated(@Payload OrderCreatedEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.OFFSET) long offset) {
        String eventKey = topic + ":" + event.orderId() + ":" + offset;
        if (processedEvents.existsByKey(eventKey)) return;  // idempotent skip
        projectionService.applyOrderCreated(event);
        processedEvents.markProcessed(eventKey);
    }
}

// DLT consumer — logs and emits metric; never re-throws to avoid looping
@Component
public class OrderEventDltConsumer {
    private static final Logger log = LoggerFactory.getLogger(OrderEventDltConsumer.class);

    @KafkaListener(topics = "order-events.DLT", groupId = "rewards-store-service-dlt")
    public void handleDlt(@Payload byte[] payload,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.EXCEPTION_MESSAGE) String exceptionMessage) {
        log.error("Message landed in DLT topic={} error={}", topic, exceptionMessage);
        meterRegistry.counter("kafka.dlt.messages", "topic", topic).increment();
    }
}
