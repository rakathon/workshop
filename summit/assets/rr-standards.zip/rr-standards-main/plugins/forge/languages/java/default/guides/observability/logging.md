# Java Guide — Structured Logging

Guide: 1.0.0

## Overview

Shows how to implement structured JSON logging in a Java 21 Spring Boot 3.x service
using SLF4J, Logback, and `logstash-logback-encoder`. Covers Logback configuration
for JSON output, MDC (Mapped Diagnostic Context) for per-request correlation fields,
log level selection, PII exclusion rules, and the company SonarQube custom quality
profile requirements for logging hygiene. A service that follows this guide produces
machine-parseable JSON logs that Datadog can index and correlate with distributed
traces.

## Related standard

[Observability Standards](../../../../../../../standards/observability/)

## Prerequisites

- SLF4J (`org.slf4j:slf4j-api`) — included in Spring Boot
- Logback Classic (`ch.qos.logback:logback-classic`) — included in Spring Boot
- `net.logstash.logback:logstash-logback-encoder` (add explicitly)

Maven dependency:

```xml
<dependency>
    <groupId>net.logstash.logback</groupId>
    <artifactId>logstash-logback-encoder</artifactId>
    <version>7.4</version>
</dependency>
```

---

## Implementation

### Logback configuration — structured JSON

Replace the default `logback-spring.xml` with a configuration that routes all log
output to a `LogstashEncoder` appender in production and a human-readable pattern
appender in local development.

`src/main/resources/logback-spring.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>

  <!-- Local development: human-readable output -->
  <springProfile name="local,test">
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
      <encoder>
        <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
      </encoder>
    </appender>
    <root level="DEBUG">
      <appender-ref ref="CONSOLE"/>
    </root>
  </springProfile>

  <!-- Production / staging / CI: structured JSON -->
  <springProfile name="!local &amp; !test">
    <appender name="JSON_CONSOLE"
              class="ch.qos.logback.core.ConsoleAppender">
      <encoder
          class="net.logstash.logback.encoder.LogstashEncoder">
        <!-- Include MDC fields as top-level JSON keys -->
        <includeMdcKeyName>request_id</includeMdcKeyName>
        <includeMdcKeyName>traceparent</includeMdcKeyName>
        <includeMdcKeyName>member_id</includeMdcKeyName>
        <includeMdcKeyName>service</includeMdcKeyName>
        <!-- Always include service name and version -->
        <customFields>{"service":"${SERVICE_NAME}","version":"${SERVICE_VERSION}"}</customFields>
        <fieldNames>
          <timestamp>timestamp</timestamp>
          <message>message</message>
          <logger>logger</logger>
          <level>level</level>
          <thread>thread</thread>
        </fieldNames>
      </encoder>
    </appender>
    <root level="INFO">
      <appender-ref ref="JSON_CONSOLE"/>
    </root>
  </springProfile>

</configuration>
```

Each log line in production produces a JSON object like:

```json
{
  "timestamp": "2024-06-15T09:30:00.000Z",
  "level": "INFO",
  "logger": "com.rakutenrewards.store.StoreController",
  "message": "Store created",
  "service": "store-service",
  "version": "1.2.0",
  "request_id": "a3c2f1e0-...",
  "traceparent": "00-4bf92f35...",
  "member_id": "m-789"
}
```

### Logger declaration

Declare one `private static final Logger` per class. Use the class as the logger name.
Do not use string literals for the logger name.

```java
// Correct
private static final Logger log = LoggerFactory.getLogger(StoreService.class);

// Wrong — string literal breaks IDE navigation and refactoring
private static final Logger log = LoggerFactory.getLogger("StoreService");
```

### MDC — per-request correlation fields

Populate MDC fields at the start of every request so all log lines within that
request carry the correlation context. Clear MDC after the request completes.

```java
@Component
public class RequestContextFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        UUID requestId = UUID.randomUUID();
        MDC.put("request_id", requestId.toString());

        String traceparent = request.getHeader("traceparent");
        if (traceparent != null) {
            MDC.put("traceparent", traceparent);
        }

        // Store request_id in request attribute for response envelope
        request.setAttribute("requestId", requestId);

        try {
            chain.doFilter(request, response);
        } finally {
            MDC.clear();  // always clear; prevents cross-request contamination
        }
    }
}
```

Set the member ID in MDC after JWT validation:

```java
// In EbtokenAuthFilter, after successful token validation:
MDC.put("member_id", claims.memberGuid());
```

### Log level selection

| Situation | Level |
|-----------|-------|
| Request received, resource created, state transitioned | `INFO` |
| Operation succeeded but with a notable condition (retry, fallback used) | `WARN` |
| Unhandled exception; operation failed; alert-worthy condition | `ERROR` |
| Internal state useful for diagnosis (not enabled in production by default) | `DEBUG` |
| High-volume internal tracing (not enabled unless explicitly debugging) | `TRACE` |

```java
// INFO — normal operations
log.info("Store created storeId={}", store.id());

// WARN — degraded but not failed
log.warn("DynamoDB throttled on table={} attempt={} retrying",
    tableName, attempt);

// ERROR — failure; alert-worthy
log.error("Failed to publish order event orderId={}", order.id(), ex);

// DEBUG — diagnostic; disabled in production by default
log.debug("Evaluating discount rule ruleId={} memberId={}",
    rule.id(), memberId);
```

### Structured log fields — use parameterized messages

Never concatenate strings in log statements. Use SLF4J's `{}` placeholders:

```java
// Correct — lazy evaluation, no string allocation when level is disabled
log.info("Order processed orderId={} memberId={} durationMs={}",
    order.id(), order.memberId(), durationMs);

// Wrong — always allocates the string even when DEBUG is disabled
log.debug("Order processed: " + order.id() + " member: " + order.memberId());
```

For complex structured context, use Logback's `StructuredArguments`:

```java
import static net.logstash.logback.argument.StructuredArguments.kv;

log.info("Payment processed {}",
    kv("payment_id", payment.id()));

// Produces: {"message":"Payment processed","payment_id":"pay-123"}
```

### PII exclusion rules

Never log the following fields under any log level — they must not appear in log
output, even in DEBUG or TRACE:

- Full credit card numbers, CVVs, or payment tokens
- Raw passwords or authentication secrets
- Social security numbers or national ID numbers
- Full member email addresses in production logs (use hashed or truncated form if needed)
- ebtoken JWT values (log only the subject claim, never the raw token string)

```java
// Wrong — logs full email
log.info("Member logged in email={}", member.email());

// Correct — use identifier only
log.info("Member logged in memberId={}", member.id());

// Wrong — logs raw JWT
log.debug("Validating token={}", rawToken);

// Correct — log only the parsed subject
log.debug("Validating token for memberId={}", claims.subject());
```

### SonarQube logging hygiene (from SG-JAVA-CUSTOM-PROFILE-07-2025)

The company SonarQube profile enforces the following logging rules. These are
**blocking** in CI:

- `java:S2629` — Log arguments must not use string concatenation; use `{}` placeholders.
- `java:S3457` — Log arguments must not call `.toString()` explicitly; SLF4J handles
  this via `{}`.
- `java:S4792` — Logger configuration must not be adjustable from user-controlled input.
- Catch and log exceptions with `log.error("...", ex)` — never swallow exceptions
  silently.

---

## Verification

1. Start the service with the `default` profile (not `local`) and send a request —
   confirm log output is a single-line JSON object per log statement with `timestamp`,
   `level`, `message`, `request_id`, and `traceparent` fields.
2. Grep `src/main/java` for `+ order` or any string concatenation in a `log.*()` call
   — must be zero results; all must use `{}` placeholders.
3. Grep `src/main/java` for `MDC.put("request_id"` — confirm it is set by the filter
   and `MDC.clear()` is called in the `finally` block.
4. Send a request and check that `request_id` in the response envelope
   (`meta.operation.request_id`) matches the `request_id` in the corresponding log lines.
5. Run `mvn checkstyle:check` — zero violations required.
