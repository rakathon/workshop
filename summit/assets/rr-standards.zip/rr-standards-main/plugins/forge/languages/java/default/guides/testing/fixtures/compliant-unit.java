// Compliant unit test demonstrating all key patterns from the guide
@ExtendWith(MockitoExtension.class)
class DiscountServiceTest {

    @Mock
    private MemberRepository memberRepository;   // external dependency: mocked

    @Mock
    private Clock clock;                          // time source: always injected, never Instant.now()

    @InjectMocks
    private DiscountService discountService;

    private static final Instant FIXED_NOW = Instant.parse("2024-06-15T12:00:00Z");

    @BeforeEach
    void setupClock() {
        given(clock.instant()).willReturn(FIXED_NOW);
        given(clock.getZone()).willReturn(ZoneOffset.UTC);
    }

    // REQ-PRICING-003: Premium members receive 10% discount on all orders
    // Naming: given<Precondition>_when<Action>_then<Outcome>
    @Test
    void givenPremiumMember_whenCalculateDiscount_thenReturnsTenPercent() {
        // Arrange
        Member member = new Member("m-1", true);
        given(memberRepository.findById("m-1")).willReturn(Optional.of(member));

        // Act — single action
        DecimalValue discount = discountService.calculateDiscount("m-1", new BigDecimal("100.00"));

        // Assert — static expected value, not derived: 100.00 * 0.10 = 10.00
        assertThat(discount.toBigDecimal()).isEqualByComparingTo(new BigDecimal("10.00"));
    }

    // REQ-AUTH-007: Expired tokens must be rejected immediately
    @Test
    void givenExpiredToken_whenValidate_thenReturnsFalse() {
        // Arrange — token expired 1 second before the fixed clock time
        Token token = new Token(FIXED_NOW.minusSeconds(1));

        // Act — single action
        boolean result = discountService.isValid(token);

        // Assert
        assertThat(result).isFalse();
    }

    // REQ-PRICING-004: Non-premium members receive no discount
    @Test
    void givenNonPremiumMember_whenCalculateDiscount_thenReturnsZero() {
        // Arrange
        Member member = new Member("m-2", false);
        given(memberRepository.findById("m-2")).willReturn(Optional.of(member));

        // Act
        DecimalValue discount = discountService.calculateDiscount("m-2", new BigDecimal("100.00"));

        // Assert
        assertThat(discount.toBigDecimal()).isEqualByComparingTo(BigDecimal.ZERO);
    }
}

// JaCoCo configuration enforcing 90% line and branch coverage
// pom.xml — requires BOTH prepare-agent and check executions:
// <plugin><groupId>org.jacoco</groupId><artifactId>jacoco-maven-plugin</artifactId>
//   <executions>
//     <execution><id>prepare-agent</id><goals><goal>prepare-agent</goal></goals></execution>
//     <execution><id>check</id><phase>verify</phase><goals><goal>check</goal></goals>
//       <configuration><rules><rule><limits>
//         <limit><counter>LINE</counter><value>COVEREDRATIO</value><minimum>0.90</minimum></limit>
//         <limit><counter>BRANCH</counter><value>COVEREDRATIO</value><minimum>0.90</minimum></limit>
//       </limits></rule></rules></configuration></execution>
//   </executions></plugin>
