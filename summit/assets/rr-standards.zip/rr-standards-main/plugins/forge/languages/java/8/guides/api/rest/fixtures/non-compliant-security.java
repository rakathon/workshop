// This security config violates several rules from the REST API Security standard.
// It looks like plausible production Spring Security 5.7.x code but contains multiple violations.

// ---- R-1 VIOLATION: MemberDataSecurityConfig.java ----
// Member-data endpoint uses HTTP Basic auth instead of ebtoken Bearer/euid cookie.
// Basic auth is not the approved scheme for public member-data contracts.
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Configuration
@EnableWebSecurity
public class MemberDataSecurityConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain memberDataFilterChain(HttpSecurity http) throws Exception {

        return http
            .requestMatcher(new AntPathRequestMatcher("/store/v1/**"))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            // R-1 VIOLATION: HTTP Basic auth instead of EbtokenAuthFilter with Bearer/euid cookie
            .httpBasic()
                .and()
            .authorizeRequests()
                .antMatchers("/store/v1/regions/*/members/**").authenticated()
                .antMatchers("/offers/v1/regions/*/members/**").authenticated()
                .anyRequest().permitAll()
                .and()
            .build();
    }
}

// ---- ApiKeyAuthFilter.java ----
// R-1 VIOLATION: Uses X-API-Key header instead of Bearer token or euid cookie
public class ApiKeyAuthFilter extends OncePerRequestFilter {

    private final ApiKeyStore apiKeyStore;

    public ApiKeyAuthFilter(ApiKeyStore apiKeyStore) {
        this.apiKeyStore = apiKeyStore;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        // R-1 VIOLATION: X-API-Key is not the approved auth scheme for member-data endpoints;
        // should be Authorization: Bearer <ebtoken> or euid cookie
        String apiKey = request.getHeader("X-API-Key");
        if (apiKey != null && apiKeyStore.isValid(apiKey)) {
            UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(apiKey, null,
                    Collections.singletonList(new SimpleGrantedAuthority("ROLE_api_client")));
            SecurityContextHolder.getContext().setAuthentication(auth);
        }
        chain.doFilter(request, response);
    }
}

// ---- AdminContractSecurityConfig.java ----
// R-2 VIOLATION: Admin contract endpoint has no role validation — permits all authenticated
@Configuration
@EnableWebSecurity
public class AdminContractSecurityConfig {

    @Bean
    @Order(2)
    public SecurityFilterChain adminFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .requestMatcher(new AntPathRequestMatcher("/store-admin/v1/**"))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .addFilterBefore(
                new EbtokenAuthFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeRequests()
                // R-2 VIOLATION: No role validation — any authenticated user can reach admin endpoints.
                // Should be .anyRequest().hasAuthority("ROLE_store_admin")
                .anyRequest().authenticated()
                .and()
            .build();
    }
}

// ---- InternalContractSecurityConfig.java ----
// R-3 VIOLATION: Sensitive -int balance endpoint has no authentication at all
@Configuration
@EnableWebSecurity
public class InternalContractSecurityConfig {

    @Bean
    @Order(3)
    public SecurityFilterChain internalFilterChain(HttpSecurity http) throws Exception {

        return http
            .requestMatcher(new AntPathRequestMatcher("/wallet-int/v1/**"))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            // R-3 VIOLATION: No ServerToServerAuthFilter added; no token validation at all
            .authorizeRequests()
                // R-3 VIOLATION: /wallet-int/v1/balance (sensitive operation) is publicly accessible
                .antMatchers("/wallet-int/v1/balance").permitAll()
                .anyRequest().authenticated()
                .and()
            .build();
    }
}
