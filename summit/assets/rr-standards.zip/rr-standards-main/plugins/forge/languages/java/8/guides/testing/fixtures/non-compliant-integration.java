// Non-compliant Java 8 integration test — mocks external components, no Testcontainers
@SpringBootTest
class OrderServiceIntegrationTest {

    // WRONG: mocking the database in an integration test — defeats the purpose
    @MockBean
    private OrderRepository orderRepository;

    // WRONG: mocking Kafka — should use real container
    @MockBean
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    private OrderService orderService;

    @Test
    void testCreateOrder() {
        // WRONG: mock returns a pre-canned response — doesn't test real DB interaction
        given(orderRepository.save(any())).willReturn(
            new Order(UUID.randomUUID(), "m-1", OrderStatus.PENDING));

        Order result = orderService.create(new CreateOrderRequest("m-1"));

        // WRONG: verifying mock interaction instead of real state
        verify(orderRepository).save(any());
        assertThat(result.getId()).isNotNull();
    }
}
