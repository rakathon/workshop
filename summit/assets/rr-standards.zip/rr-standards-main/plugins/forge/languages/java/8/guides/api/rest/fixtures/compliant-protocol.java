// ---- Meta.java ----
// R-6: Required meta fields — status.code and operation.request_id (UUID) in every response
// Java 8: Lombok @Value/@Builder instead of records
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class Meta {
    StatusInfo status;
    OperationInfo operation;

    @Value
    @Builder
    public static class StatusInfo {
        String code;
    }

    @Value
    @Builder
    public static class OperationInfo {
        UUID requestId;
    }

    public static Meta ok(UUID requestId) {
        return Meta.builder()
            .status(StatusInfo.builder().code("OK").build())
            .operation(OperationInfo.builder().requestId(requestId).build())
            .build();
    }

    public static Meta of(String code, UUID requestId) {
        return Meta.builder()
            .status(StatusInfo.builder().code(code).build())
            .operation(OperationInfo.builder().requestId(requestId).build())
            .build();
    }
}

// ---- DataResponse.java ----
// R-5: Success responses wrap payload in 'data' field with 'meta'; no 'errors' on success
@Value
@Builder
public class DataResponse<T> {
    T data;
    Meta meta;
}

// ---- ListResponse.java ----
// R-5: Collection success response with 'data', optional 'pagination', and 'meta'
@Value
@Builder
public class ListResponse<T> {
    List<T> data;
    @Nullable Object pagination;
    Meta meta;
}

// ---- ErrorDetail.java ----
@Value
@Builder
public class ErrorDetail {
    String code;
    String message;
    @Nullable ErrorField details;
    @Nullable UUID traceId;

    @Value
    @Builder
    public static class ErrorField {
        String field;
        @Nullable Object value;
        @Nullable String constraint;
    }
}

// ---- ErrorResponse.java ----
// R-5, R-6: Error responses have 'errors' + 'meta' ONLY — never a 'data' field
@Value
@Builder
public class ErrorResponse {
    List<ErrorDetail> errors;
    Meta meta;
}

// ---- StoreController.java ----
// R-1: Client-Agent header validation via @RequestHeader
// R-7: POST for creation returns 201 Created with Location header
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    @GetMapping
    public ResponseEntity<ListResponse<Store>> listStores(
        @RequestHeader("Client-Agent") String clientAgent,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        List<Store> stores = storeService.findAll();
        return ResponseEntity.ok(
            ListResponse.<Store>builder()
                .data(stores)
                .pagination(null)
                .meta(Meta.ok(requestId))
                .build());
    }

    @GetMapping("/{store_id}")
    public ResponseEntity<DataResponse<Store>> getStore(
        @PathVariable("store_id") String storeId,
        @RequestHeader("Client-Agent") String clientAgent,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        Store store = storeService.findById(storeId);
        return ResponseEntity.ok(DataResponse.<Store>builder()
            .data(store)
            .meta(Meta.ok(requestId))
            .build());
    }

    // R-7: POST create returns 201 Created + Location header (never 200)
    @PostMapping
    public ResponseEntity<DataResponse<Store>> createStore(
        @RequestBody @Valid CreateStoreRequest body,
        @RequestHeader("Client-Agent") String clientAgent,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        Store created = storeService.create(body);
        URI location = URI.create("/store/v1/stores/" + created.getId());

        return ResponseEntity
            .created(location)              // 201 + Location header (R-7)
            .body(DataResponse.<Store>builder()
                .data(created)
                .meta(Meta.ok(requestId))
                .build());
    }

    @DeleteMapping("/{store_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)  // R-7: 204 for deletion
    public void deleteStore(
        @PathVariable("store_id") String storeId,
        @RequestHeader("Client-Agent") String clientAgent) {
        storeService.delete(storeId);
    }
}

// ---- GlobalExceptionHandler.java ----
// R-6, R-7, R-8: All errors return ErrorResponse (errors + meta, NEVER data on errors)
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // R-7: 400 for unparseable request body
    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleUnparseable(
        HttpMessageNotReadableException ex, HttpServletRequest request) {
        return errorResponse("MALFORMED_REQUEST", ex.getMessage(), request);
    }

    // R-7: 400 for bean validation failures
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidation(
        MethodArgumentNotValidException ex, HttpServletRequest request) {
        List<ErrorDetail> errors = new ArrayList<>();
        for (FieldError fe : ex.getBindingResult().getFieldErrors()) {
            errors.add(ErrorDetail.builder()
                .code("VALIDATION_ERROR")
                .message(fe.getDefaultMessage())
                .details(ErrorDetail.ErrorField.builder()
                    .field(fe.getField())
                    .value(fe.getRejectedValue())
                    .build())
                .build());
        }
        return ErrorResponse.builder()
            .errors(errors)
            .meta(Meta.of("BadRequest", RequestContext.requestId(request)))
            .build();
    }

    // R-7: 401 for authentication failures
    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleAuth(AuthenticationException ex, HttpServletRequest request) {
        return errorResponse("UNAUTHORIZED", ex.getMessage(), request);
    }

    // R-7: 403 for insufficient roles
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handleForbidden(AccessDeniedException ex, HttpServletRequest request) {
        return errorResponse("FORBIDDEN", ex.getMessage(), request);
    }

    // R-7: 404 for missing resources
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleNotFound(ResourceNotFoundException ex, HttpServletRequest request) {
        return errorResponse("NOT_FOUND", ex.getMessage(), request);
    }

    // R-7: 409 for version_token mismatch — return current entity state in 'data' for retry
    // R-5 exception: 409 includes 'data' with current entity state (not an error-only response)
    @ExceptionHandler(VersionConflictException.class)
    public ResponseEntity<DataResponse<?>> handleConflict(
        VersionConflictException ex, HttpServletRequest request) {
        return ResponseEntity
            .status(HttpStatus.CONFLICT)
            .body(DataResponse.builder()
                .data(ex.getCurrentState())
                .meta(Meta.of("Conflict", RequestContext.requestId(request)))
                .build());
    }

    // R-7: 422 for business-rule violations on well-formed requests
    @ExceptionHandler(BusinessRuleException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ErrorResponse handleBusinessRule(BusinessRuleException ex, HttpServletRequest request) {
        return errorResponse(ex.getCode(), ex.getMessage(), request);
    }

    // R-7: 429 with Retry-After header (R-3)
    @ExceptionHandler(RateLimitExceededException.class)
    public ResponseEntity<ErrorResponse> handleRateLimit(
        RateLimitExceededException ex, HttpServletRequest request) {
        return ResponseEntity
            .status(HttpStatus.TOO_MANY_REQUESTS)
            .header("Retry-After", String.valueOf(ex.retryAfterSeconds()))  // R-3
            .body(errorResponse("RATE_LIMIT_EXCEEDED", ex.getMessage(), request));
    }

    // R-7: 503 with Retry-After header (R-3)
    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity<ErrorResponse> handleServiceUnavailable(
        ServiceUnavailableException ex, HttpServletRequest request) {
        return ResponseEntity
            .status(HttpStatus.SERVICE_UNAVAILABLE)
            .header("Retry-After", String.valueOf(ex.retryAfterSeconds()))  // R-3
            .body(errorResponse("SERVICE_UNAVAILABLE", ex.getMessage(), request));
    }

    // R-7: NEVER return 200 for error conditions — catch-all returns 500
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleUnexpected(Exception ex, HttpServletRequest request) {
        log.error("Unhandled exception", ex);
        return errorResponse("INTERNAL_ERROR", "An unexpected error occurred", request);
    }

    private ErrorResponse errorResponse(String code, String message, HttpServletRequest request) {
        return ErrorResponse.builder()
            .errors(Collections.singletonList(
                ErrorDetail.builder().code(code).message(message).build()))
            .meta(Meta.of(code, RequestContext.requestId(request)))
            .build();
    }
}
