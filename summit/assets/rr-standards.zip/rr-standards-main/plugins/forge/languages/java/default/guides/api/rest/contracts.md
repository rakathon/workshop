# Java Guide — REST API Contracts

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/contracts.md@1.0.0

## Overview

Shows how to satisfy the REST API Contracts standard in a Spring Boot 3.x service.
Covers controller URI structure, path variable naming, HTTP verb mapping, API
versioning via path prefixes, sunset header emission, and the Jackson naming strategy
that bridges Java camelCase to the required snake_case wire format. A Spring Boot
controller that follows this guide produces URIs and field names that comply with the
standard.

## Related standard

[REST API Contracts](../../../../../../standards/api/rest/contracts.md)

## Prerequisites

- Java 21, Spring Boot 3.x (`spring-boot-starter-web`)
- Jackson (`com.fasterxml.jackson.core:jackson-databind`) — included in the web starter
- Springdoc OpenAPI (`org.springdoc:springdoc-openapi-starter-webmvc-ui`) for R-9

---

## Implementation

### Base path and version prefix (R-1, R-2)

Every controller in a contract shares a base path of `/<contract_name>/v<N>`. Declare
the version prefix once on the class-level `@RequestMapping` so that all methods
in the controller inherit it.

```java
@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    @GetMapping
    public ResponseEntity<ListStoresResponse> listStores(...) { ... }

    @GetMapping("/{store_id}")
    public ResponseEntity<GetStoreResponse> getStore(
        @PathVariable("store_id") String storeId) { ... }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<CreateStoreResponse> createStore(
        @RequestBody @Valid CreateStoreRequest request) { ... }

    @PutMapping("/{store_id}")
    public ResponseEntity<UpdateStoreResponse> replaceStore(
        @PathVariable("store_id") String storeId,
        @RequestBody @Valid ReplaceStoreRequest request) { ... }

    @PatchMapping("/{store_id}")
    public ResponseEntity<UpdateStoreResponse> updateStore(
        @PathVariable("store_id") String storeId,
        @RequestBody @Valid UpdateStoreRequest request) { ... }

    @DeleteMapping("/{store_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteStore(
        @PathVariable("store_id") String storeId) { ... }
}
```

Do **not** pass the version as a query parameter or request header (R-2):

```java
// Wrong — version in query parameter
@GetMapping("/stores?version=v1")

// Wrong — version as Accept header variant
@GetMapping(value = "/stores", headers = "X-API-Version=1")
```

### Path variable naming — snake_case in path, camelCase in Java (R-3, R-4)

The standard requires `snake_case` for all URI segments and path parameter names.
Spring binds `@PathVariable` by the name given in the annotation string, which is the
wire name. The Java method parameter name may be camelCase.

```java
// Correct — path variable name is snake_case; Java param is camelCase
@GetMapping("/stores/{store_id}/conditions/{condition_id}")
public ResponseEntity<GetConditionResponse> getStoreCondition(
    @PathVariable("store_id") String storeId,
    @PathVariable("condition_id") String conditionId) { ... }

// Wrong — path variable name is camelCase
@GetMapping("/stores/{storeId}/conditions/{conditionId}")
```

Use plural `snake_case` nouns for every collection segment (R-3):

```java
// Correct
@RequestMapping("/store/v1/member_offers")

// Wrong — singular
@RequestMapping("/store/v1/member_offer")

// Wrong — camelCase
@RequestMapping("/store/v1/memberOffers")
```

### JSON field naming — Jackson snake_case mapping (R-4)

Configure Jackson to serialize all field names as `snake_case` globally. Apply this
once in your Spring Boot auto-configuration.

```java
@Configuration
public class JacksonConfig {

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer snakeCaseNaming() {
        return builder -> builder
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }
}
```

Or in `application.yml`:

```yaml
spring:
  jackson:
    property-naming-strategy: SNAKE_CASE
```

With this in place, Java record components and POJO fields named `storeId`,
`createdAt`, etc. are serialized as `store_id`, `created_at` on the wire without
per-field `@JsonProperty` annotations.

### Contract type suffixes (R-5)

The contract name (first path segment) carries the suffix — admin and internal
contracts are differentiated by the base path only.

```java
// Public contract — no suffix
@RestController
@RequestMapping("/store/v1")
public class StoreController { ... }

// Admin contract — -admin suffix
@RestController
@RequestMapping("/store-admin/v1")
public class StoreAdminController { ... }

// Internal server-to-server contract — -int suffix
@RestController
@RequestMapping("/store-int/v1")
public class StoreInternalController { ... }
```

### HTTP verb mapping (R-7)

| Intent | Annotation | Notes |
|--------|-----------|-------|
| Read single or collection | `@GetMapping` | |
| Create resource | `@PostMapping` | Return `201 Created` + `Location` header |
| Full idempotent replacement | `@PutMapping` | Requires `version_token` if resource supports concurrent writes |
| Partial update | `@PatchMapping` | |
| Delete | `@DeleteMapping` | Return `204 No Content` |
| Query with long parameters | `@PostMapping` | Only when GET URL length would exceed limits; add `summary` explaining why |

### Breaking changes — new version (R-6)

When a breaking change is required, introduce a new version controller class. The
original controller remains unchanged and continues serving existing clients.

```java
// Original version — do not modify after publishing
@RestController
@RequestMapping("/store/v1/stores")
public class StoreV1Controller { ... }

// New version for breaking change
@RestController
@RequestMapping("/store/v2/stores")
public class StoreV2Controller { ... }
```

### Sunset and deprecation headers (R-8)

During the sunset window of a deprecated version, add `Deprecation`, `Sunset`, and
`Link` headers to every response. Use a Spring `HandlerInterceptor` so the version
controller itself does not need to be modified.

```java
@Component
public class V1SunsetInterceptor implements HandlerInterceptor {

    // Sunset date agreed with clients
    private static final String DEPRECATION = "Sun, 11 Nov 2025 23:59:59 GMT";
    private static final String SUNSET = "Wed, 11 Mar 2026 23:59:59 GMT";
    private static final String LINK = "</store/v2/stores>; rel=\"latest-version\"";

    @Override
    public boolean preHandle(
        HttpServletRequest request,
        HttpServletResponse response,
        Object handler) {

        response.setHeader("Deprecation", DEPRECATION);
        response.setHeader("Sunset", SUNSET);
        response.setHeader("Link", LINK);
        return true;
    }
}

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new V1SunsetInterceptor())
            .addPathPatterns("/store/v1/**");
    }
}
```

### Member data URI structure (R-10)

All paths that access member-scoped resources must include
`/regions/{region_id}/members/{member_id}` before the member-scoped collection.
The path parameter name differs by contract type.

```java
// Public contract — member GUID
@RestController
@RequestMapping("/offers/v1/regions/{region_id}/members/{member_guid}/offers")
public class MemberOffersController {

    @GetMapping
    public ResponseEntity<ListMemberOffersResponse> listMemberOffers(
        @PathVariable("region_id") String regionId,
        @PathVariable("member_guid") String memberGuid) { ... }
}

// Internal contract — member ID (integer)
@RestController
@RequestMapping("/offers-int/v1/regions/{region_id}/members/{member_id}/offers")
public class MemberOffersInternalController {

    @GetMapping
    public ResponseEntity<ListMemberOffersResponse> listMemberOffers(
        @PathVariable("region_id") String regionId,
        @PathVariable("member_id") long memberId) { ... }
}
```

Non-compliant patterns to avoid:

```java
// Wrong — member data without /regions/{region_id}/members/{member_id} prefix
@RequestMapping("/offers/v1/member_offers")

// Wrong — missing region prefix
@RequestMapping("/offers/v1/members/{member_guid}/offers")

// Wrong — integer ID on a public contract
@RequestMapping("/offers/v1/regions/{region_id}/members/{member_id}/offers")
// 'member_id' implies integer — use 'member_guid' on public contracts
```

### OpenAPI specification (R-9)

Add the Springdoc OpenAPI dependency and annotate the main class. The spec is
generated at `/v3/api-docs` and the UI at `/swagger-ui.html`.

```java
@SpringBootApplication
@OpenAPIDefinition(
    info = @Info(
        title = "Store API",
        version = "1"   // major version only — matches /store/v1/... in paths
    )
)
public class StoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(StoreApplication.class, args);
    }
}
```

---

## Verification

1. Start the service and inspect each controller path in Swagger UI or `/v3/api-docs`.
   Confirm every path matches `/<contract>/v<N>/<collection>...`.
2. Grep for `@PathVariable` annotations and confirm every name string is
   `[a-z][a-z0-9]*(_[a-z0-9]+)*` — no camelCase, no uppercase, no hyphens in path
   variable names.
3. Confirm the base path's first segment ends with `-admin`, `-int`, or has no suffix
   as appropriate for each controller.
4. For each `@PostMapping` that creates a resource, confirm the handler returns
   `ResponseEntity` with status `201` and a `Location` header.
5. For every path that accesses member-scoped data, confirm
   `/regions/{region_id}/members/{...}` appears before the member collection.
   Confirm `member_guid` on public contracts and `member_id` on `-int` contracts.
6. Run `mvn checkstyle:check` — zero violations required.
