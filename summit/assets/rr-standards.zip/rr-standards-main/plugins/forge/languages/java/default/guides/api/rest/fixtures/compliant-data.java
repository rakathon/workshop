// ---- CursorPagination.java ----
// R-1, R-2: Default forward-only cursor pagination record
public record CursorPagination(@Nullable String next) {}

// ---- DecimalValue.java ----
// R-5: Lossless decimal — value/scale tuple instead of double/float
public record DecimalValue(long value, int scale) {

    public DecimalValue {
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
    }

    public BigDecimal toBigDecimal() {
        return new BigDecimal(value).movePointLeft(scale);
    }

    public static DecimalValue of(BigDecimal bd) {
        int s = bd.scale() < 0 ? 0 : bd.scale();
        long v = bd.movePointRight(s).longValueExact();
        return new DecimalValue(v, s);
    }
}

// ---- MoneyAmount.java ----
// R-6: Currency amount with explicit scale and ISO 4217 code
public record MoneyAmount(long amount, String currency, int scale) {

    public MoneyAmount {
        if (currency == null || currency.length() != 3) {
            throw new IllegalArgumentException(
                "currency must be a 3-character ISO 4217 code");
        }
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
    }
}

// ---- Store.java ----
// R-3: Resource record with UUID versionToken for optimistic concurrency
// R-4: Instant fields for timestamps (not long epoch integers)
public record Store(
    UUID id,
    String name,
    UUID versionToken,     // R-3: required for concurrent write protection
    MoneyAmount listingFee, // R-6: MoneyAmount, not double
    Instant createdAt,     // R-4: Instant serializes to ISO 8601 UTC
    Instant updatedAt) {}  // R-4: Instant, not long epoch

// ---- ReplaceStoreRequest.java ----
// R-3: Write request requires @NotNull UUID versionToken
public record ReplaceStoreRequest(
    @NotBlank String name,
    @NotNull UUID versionToken) {}  // R-3: clients must echo current token

// ---- Offer.java ----
// R-5: DecimalValue for precision-sensitive decimal (discount percentage)
public record Offer(
    UUID id,
    String name,
    DecimalValue discountPercentage,  // R-5: value/scale tuple, not double
    MoneyAmount price,                // R-6: MoneyAmount, not BigDecimal or double
    Instant validUntil) {}            // R-4: Instant, not long

// ---- JacksonConfig.java ----
// R-4: Disable WRITE_DATES_AS_TIMESTAMPS so Instant serializes to ISO 8601 UTC
@Configuration
public class JacksonConfig {

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jacksonConfig() {
        return builder -> builder
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE)
            .featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .modules(new JavaTimeModule());
    }
}

// ---- StoreController.java ----
// R-1: Collection endpoint has @RequestParam @Min(1) @Max(100) int limit — never unbounded
@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    // R-1: Bounded limit parameter (default 20, max 100)
    @GetMapping
    public ResponseEntity<ListResponse<Store>> listStores(
        @RequestParam(defaultValue = "20") @Min(1) @Max(100) int limit,
        @RequestParam(required = false) String cursor,
        HttpServletRequest request) {

        var page = storeService.findAll(cursor, limit);
        var pagination = page.hasNext()
            ? new CursorPagination(page.nextCursor())
            : new CursorPagination(null);

        return ResponseEntity.ok(
            new ListResponse<>(page.items(), pagination,
                Meta.ok(RequestContext.requestId(request))));
    }
}

// ---- StoreService.java ----
// R-3: Service layer throws VersionConflictException on token mismatch
@Service
public class StoreService {

    public Store replace(String storeId, ReplaceStoreRequest request) {
        Store current = repository.findById(storeId)
            .orElseThrow(() -> new ResourceNotFoundException(storeId));

        // R-3: Reject mismatch with 409 and include current entity state
        if (!current.versionToken().equals(request.versionToken())) {
            throw new VersionConflictException(current);
        }

        Store updated = new Store(
            current.id(),
            request.name(),
            UUID.randomUUID(),   // new version token on each successful write
            current.listingFee(),
            current.createdAt(),
            Instant.now());
        return repository.save(updated);
    }
}
