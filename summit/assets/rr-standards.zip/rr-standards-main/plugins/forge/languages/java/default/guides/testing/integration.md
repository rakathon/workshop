# Java Guide — Integration Testing

Guide: 1.0.0 | Implements: standards/testing/integration-testing.md@1.0.0

## Overview

Shows how to satisfy the Integration Testing standard in Java 21 using Spring Boot
Test and Testcontainers. Covers Testcontainers setup for PostgreSQL, DynamoDB Local,
and Kafka; `MockMvc` for HTTP layer testing; test data isolation with `@Sql` and
`@Transactional`; and CI container engine selection (Podman preferred). A test suite
that follows this guide validates all external component interactions against real
containers, with no ad-hoc mocks of external components.

## Related standard

[Integration Testing Standard](../../../../../../../standards/testing/integration-testing.md)

## Prerequisites

- Spring Boot 3.x (`spring-boot-starter-test`)
- Testcontainers (`org.testcontainers:testcontainers`,
  `testcontainers:postgresql`, `testcontainers:kafka`)
- AWS SDK v2 for DynamoDB (`software.amazon.awssdk:dynamodb-enhanced`)
- DynamoDB Local Testcontainer
  (`com.amazonaws:DynamoDBLocal` or community Testcontainers image)

Maven test dependencies:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.testcontainers</groupId>
    <artifactId>junit-jupiter</artifactId>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.testcontainers</groupId>
    <artifactId>postgresql</artifactId>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.testcontainers</groupId>
    <artifactId>kafka</artifactId>
    <scope>test</scope>
</dependency>
```

---

## Implementation

### Base integration test class

Create a single abstract base class that starts all required containers once per
test-suite JVM run (using `@Container` static lifecycle + `@DynamicPropertySource`).
This avoids restarting containers for every test class.

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
public abstract class IntegrationTestBase {

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("rewards_test")
            .withUsername("test")
            .withPassword("test");

    @Container
    static KafkaContainer kafka =
        new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.0"));

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // PostgreSQL
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        // Kafka
        registry.add("spring.kafka.bootstrap-servers",
            kafka::getBootstrapServers);
    }

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected ObjectMapper objectMapper;
}
```

### Testing repository interactions — real database (FR-1, FR-5)

Test that your service's repository correctly reads and writes to PostgreSQL. Do not
test whether PostgreSQL itself works — test your repository's behavior.

```java
@Transactional                       // rolls back after each test
class StoreRepositoryIntegrationTest extends IntegrationTestBase {

    @Autowired
    private StoreRepository storeRepository;

    @Test
    void givenStoreSaved_whenFindById_thenReturnsStore() {
        // Arrange — insert test data
        Store store = new Store(UUID.randomUUID(), "Test Store",
            UUID.randomUUID(), Instant.now(), Instant.now());
        storeRepository.save(store);

        // Act
        Optional<Store> found = storeRepository.findById(store.id());

        // Assert
        assertThat(found).isPresent();
        assertThat(found.get().name()).isEqualTo("Test Store");
    }

    @Test
    void givenNonExistentId_whenFindById_thenReturnsEmpty() {
        // Act
        Optional<Store> found = storeRepository.findById(UUID.randomUUID());

        // Assert
        assertThat(found).isEmpty();
    }

    @Test
    void givenVersionTokenMismatch_whenReplace_thenThrowsVersionConflict() {
        // Arrange
        Store store = storeRepository.save(
            new Store(UUID.randomUUID(), "Store A",
                UUID.randomUUID(), Instant.now(), Instant.now()));
        UUID staleToken = UUID.randomUUID();   // not the stored token

        // Act / Assert
        assertThatThrownBy(
            () -> storeRepository.replaceWithVersionCheck(
                store.id(), "Store B", staleToken))
            .isInstanceOf(VersionConflictException.class);
    }
}
```

### Testing the HTTP layer — `MockMvc` (FR-1)

Test that the controller layer serializes requests and responses correctly, applies
the correct status codes, and enforces required headers.

```java
class StoreControllerIntegrationTest extends IntegrationTestBase {

    @Test
    void givenValidRequest_whenCreateStore_thenReturns201WithLocation()
        throws Exception {

        String body = objectMapper.writeValueAsString(
            new CreateStoreRequest("New Store"));

        mockMvc.perform(
                post("/store/v1/stores")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Client-Agent", "test-service/1.0.0")
                    .content(body))
            .andExpect(status().isCreated())
            .andExpect(header().exists("Location"))
            .andExpect(jsonPath("$.data.name").value("New Store"))
            .andExpect(jsonPath("$.meta.operation.request_id").exists());
    }

    @Test
    void givenMissingClientAgent_whenListStores_thenReturns400()
        throws Exception {

        mockMvc.perform(get("/store/v1/stores"))
            .andExpect(status().isBadRequest());
    }

    @Test
    void givenMalformedBody_whenCreateStore_thenReturns400WithErrorsArray()
        throws Exception {

        mockMvc.perform(
                post("/store/v1/stores")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Client-Agent", "test-service/1.0.0")
                    .content("{invalid json"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.errors").isArray())
            .andExpect(jsonPath("$.errors[0].code").exists());
    }
}
```

### Testing Kafka consumer interactions (FR-1, FR-2)

Test that your consumer correctly handles messages from real Kafka containers.

```java
class OrderEventConsumerIntegrationTest extends IntegrationTestBase {

    @Autowired
    private KafkaTemplate<String, OrderEvent> kafkaTemplate;

    @Autowired
    private OrderRepository orderRepository;

    @Test
    void givenOrderCreatedEvent_whenConsumed_thenOrderPersistedInDatabase()
        throws Exception {

        String orderId = UUID.randomUUID().toString();
        var event = new OrderEvent(orderId, "CREATED", Instant.now());

        // Act — publish to Kafka; consumer processes asynchronously
        kafkaTemplate.send("order-events", orderId, event).get();

        // Assert — poll until the order appears or timeout
        await()
            .atMost(10, TimeUnit.SECONDS)
            .pollInterval(200, TimeUnit.MILLISECONDS)
            .untilAsserted(() ->
                assertThat(orderRepository.findById(orderId)).isPresent());
    }
}
```

### Test data isolation strategies

**Prefer `@Transactional` on test classes**: Spring rolls back the transaction after
each test method, leaving the database clean for the next test.

```java
@Transactional
class UserRepositoryIntegrationTest extends IntegrationTestBase {
    // Each @Test runs in a transaction that is rolled back on completion
}
```

**Use `@Sql` when the rollback strategy is insufficient** (e.g., the code under test
commits its own transaction):

```java
@Sql(scripts = "/sql/insert-stores.sql",
     executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
@Sql(scripts = "/sql/delete-stores.sql",
     executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
@Test
void givenExistingStores_whenListStores_thenReturnsPagedResults() { ... }
```

### Performance constraints (from standard)

- Each integration test must complete in **< 10 seconds**.
- The full integration test suite must complete in **< 15 minutes**.
- Use `@Container static` lifecycle so containers start once per JVM, not once per
  test class.
- Mark slow test classes with a custom JUnit 5 tag and run them in a separate Maven
  profile if needed.

---

## Verification

1. Run `mvn verify -Pfailsafe` (or equivalent) — all integration tests must pass and
   containers must start without errors.
2. Inspect every `@Mock` annotation in `src/test/java` under integration test
   classes — confirm no external component (database, Kafka, REST client) is mocked;
   all use real Testcontainers instances.
3. Confirm each test class extends `IntegrationTestBase` (or equivalent) and does not
   spin up separate container instances.
4. Time the full integration test run — must complete in under 15 minutes.
5. Run `mvn checkstyle:check` — zero violations required.
