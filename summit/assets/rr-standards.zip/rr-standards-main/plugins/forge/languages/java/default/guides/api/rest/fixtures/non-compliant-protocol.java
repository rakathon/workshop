// This controller and error handler violate several rules from the REST API Protocol standard.
// The code looks like plausible production Java but contains multiple violations.

// ---- StoreDto.java ----
// R-5 VIOLATION: Flat DTO with no response envelope — no 'data', 'errors', or 'meta' fields
public class StoreDto {
    private UUID id;
    private String name;
    private String region;
    // No 'meta' block — violates R-5 and R-6
}

// ---- StoreController.java ----
// Multiple protocol violations
@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    // R-5, R-6 VIOLATION: Returns flat DTO directly with no envelope or meta block
    @GetMapping("/{store_id}")
    public ResponseEntity<StoreDto> getStore(
        @PathVariable("store_id") String storeId) {
        // R-5 VIOLATION: No data/meta envelope; just raw DTO
        StoreDto store = storeService.findById(storeId);
        return ResponseEntity.ok(store);
    }

    // R-5, R-6, R-7 VIOLATION: Returns flat response with no envelope
    @PostMapping
    public ResponseEntity<StoreDto> createStore(
        @RequestBody CreateStoreRequest body) {
        StoreDto created = storeService.create(body);
        // R-7 VIOLATION: Returns 200 OK for creation instead of 201 Created
        // R-5 VIOLATION: No data/meta envelope
        return ResponseEntity.ok(created);
        // Missing Location header — R-7 violation
    }

    // R-5, R-7 VIOLATION: Inline error handling returning 200 with success:false pattern
    @PutMapping("/{store_id}")
    public ResponseEntity<Map<String, Object>> replaceStore(
        @PathVariable("store_id") String storeId,
        @RequestBody ReplaceStoreRequest body) {

        try {
            StoreDto updated = storeService.replace(storeId, body);
            // R-5 VIOLATION: Ad-hoc map, not the required data/meta envelope
            return ResponseEntity.ok(Map.of("result", updated));
        } catch (ValidationException e) {
            // R-7 VIOLATION: Returns 200 with success:false for a validation error
            // Should return 400 Bad Request with ErrorResponse (errors + meta)
            return ResponseEntity.ok(Map.of(
                "success", false,
                "error", e.getMessage()
            ));
        } catch (ResourceNotFoundException e) {
            // R-7 VIOLATION: Returns 200 with success:false for a not-found condition
            // Should return 404 Not Found with ErrorResponse
            return ResponseEntity.ok(Map.of(
                "success", false,
                "error", "Store not found: " + storeId
            ));
        }
    }
}

// ---- OfferController.java ----
@RestController
@RequestMapping("/offers/v1")
public class OfferController {

    // R-6 VIOLATION: Error response includes 'data' field (must not be present on errors)
    // R-7 VIOLATION: 200 returned for not-found condition
    @GetMapping("/regions/{region_id}/offers/{offer_id}")
    public ResponseEntity<Map<String, Object>> getOffer(
        @PathVariable("region_id") String regionId,
        @PathVariable("offer_id") String offerId) {

        Offer offer = offerService.find(offerId, regionId);
        if (offer == null) {
            // R-7 VIOLATION: should be 404 Not Found, not 200 OK
            // R-6 VIOLATION: error response includes 'data' field
            return ResponseEntity.ok(Map.of(
                "data", (Object) null,       // R-6 VIOLATION: data present on error response
                "errors", List.of(Map.of("code", "NOT_FOUND", "message", "Offer not found")),
                "meta", Map.of("status", Map.of("code", "NotFound"))
            ));
        }
        // R-5 VIOLATION: No proper meta block with operation.request_id
        return ResponseEntity.ok(Map.of("data", offer));
    }
}

// ---- RateLimitExceptionHandler.java ----
@RestControllerAdvice
public class RateLimitExceptionHandler {

    // R-3 VIOLATION: 429 response is missing the required Retry-After header
    @ExceptionHandler(RateLimitExceededException.class)
    public ResponseEntity<Map<String, Object>> handleRateLimit(
        RateLimitExceededException ex) {

        // R-3 VIOLATION: No Retry-After header set — clients cannot know when to retry
        return ResponseEntity
            .status(HttpStatus.TOO_MANY_REQUESTS)
            // Missing: .header("Retry-After", String.valueOf(ex.retryAfterSeconds()))
            .body(Map.of(
                "errors", List.of(Map.of("code", "RATE_LIMIT_EXCEEDED", "message", ex.getMessage()))
                // R-5 VIOLATION: No meta block
            ));
    }
}
