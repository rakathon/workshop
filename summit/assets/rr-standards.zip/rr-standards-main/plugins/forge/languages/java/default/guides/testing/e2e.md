# Java Guide — End-to-End Testing

Guide: 2.0.1 | Implements: standards/testing/e2e.md@1.0.0

## Overview

Shows how to write end-to-end tests for a Java Spring Boot service using RestAssured.
E2E tests issue real HTTP requests against a **deployed service instance** (local, QA,
lt1, prod, or any other configured environment) and validate the observable behaviour
from a client's perspective.

These tests do **not** start the application. They do **not** use `@SpringBootTest`,
`@Testcontainers`, or any in-process server. The service must already be running and
reachable at the configured base URL.

## Related standard

[E2E Testing Standard](../../../../../standards/testing/e2e.md)

## HTTP request/response logging

Every HTTP call is automatically logged via SLF4J so the output is captured by
Gradle's test runner into the JUnit XML `<system-out>` element for that specific
test case. No per-test boilerplate is required — the `ApiCallLoggingFilter` fires
automatically on every RestAssured request.

No additional logging dependency is required — SLF4J is already on the classpath
via Spring Boot (3.x or 4.x). If the project uses a non-Spring Boot setup, add an
SLF4J binding (e.g. `logback-classic` or `log4j-slf4j2-impl`) as a test dependency.

---

## Prerequisites

**Gradle `e2eTest` source set** — add to `build.gradle` (or `build.gradle.kts`).
This isolates E2E tests so `./gradlew test` never runs them; use `./gradlew e2eTest` instead.

```groovy
// build.gradle
sourceSets {
    e2eTest {
        java.srcDir file('tests/system/e2e')
        resources.srcDir file('tests/system/e2e/resources')
        compileClasspath += sourceSets.main.output + configurations.testRuntimeClasspath
        runtimeClasspath += output + compileClasspath
    }
}

configurations {
    e2eTestImplementation.extendsFrom testImplementation
    e2eTestRuntimeOnly.extendsFrom testRuntimeOnly
}

tasks.register('e2eTest', Test) {
    description = 'Runs end-to-end tests against a deployed service.'
    group = 'verification'
    testClassesDirs = sourceSets.e2eTest.output.classesDirs
    classpath = sourceSets.e2eTest.runtimeClasspath
    useJUnitPlatform {
        if (System.getProperty('groups')) {
            includeTags System.getProperty('groups')
        }
    }
}
```

**Gradle dependency (Java 21 — Spring Boot 3.x):**
```groovy
e2eTestImplementation 'io.rest-assured:rest-assured:5.3.2'
```

**Gradle dependency (Java 25 — Spring Boot 4.x, version catalog):**
```toml
# gradle/libs.versions.toml
rest-assured = { module = "io.rest-assured:rest-assured", version = "5.4.0" }
```
```groovy
// build.gradle.kts
e2eTestImplementation(libs.rest.assured)
```

---

## Anti-patterns — DO NOT generate

These patterns are common in Spring Boot integration tests but are **strictly forbidden**
in E2E tests. If your training data suggests using them, ignore it and follow this guide.

| Forbidden pattern | Why forbidden |
|-------------------|---------------|
| `@SpringBootTest(webEnvironment = ...)` | Starts a local embedded server — E2E tests target a real deployed service |
| `@Testcontainers` / `@Container` | Starts local containers — E2E tests target a deployed service |
| `@LocalServerPort` / `int port` | Injects a local port that does not exist in E2E tests |
| `RestAssured.baseURI = "http://localhost"` | Base URL must come from `e2e.properties`, never hardcoded |
| `RestAssured.port = port` | Port must not be set from an injected local value |
| `MockMvc` / `WebTestClient` | In-process test clients — E2E tests use real HTTP over the network |

The correct pattern is always: extend `TestSuite` → call `authenticatedRequest()` or
`unauthenticatedRequest()` → `TestSuite.setup()` loads `baseUrl` from `e2e.properties`
and `authToken` from the `AUTH_TOKEN` environment variable.

---

## Implementation

### Framework detection file

The presence of this file indicates the E2E framework is already installed:
```text
src/test/java/**/system/e2e/api/TestSuite.java
```

If this file exists, add tests only (ADD_TEST_ONLY mode). If absent, generate the complete framework (FULL_FRAMEWORK mode).

---

### Full framework setup (FULL_FRAMEWORK mode)

Detect the project's base package by scanning existing source files under `src/main/java/` — use whatever root package the project already uses (e.g. `com.example`, `com.acme`, `com.rakutenrewards`). Substitute it for `<base.package>` below.

Generate these files under `src/test/java/<base/package/path>/<service>/system/e2e/api/`:

#### `ApiCallLoggingFilter.java` — RestAssured filter for automatic logging

```java
package com.rakutenrewards.<service>.system.e2e.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class ApiCallLoggingFilter implements Filter {
    private static final Logger log = LoggerFactory.getLogger(ApiCallLoggingFilter.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public Response filter(FilterableRequestSpecification req,
                           FilterableResponseSpecification res,
                           FilterContext ctx) {
        Response response = ctx.next(req, res);
        try {
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("method",           req.getMethod());
            entry.put("url",              req.getURI());
            entry.put("request_headers",  headersToMap(req.getHeaders()));
            entry.put("request_body",     req.getBody());
            entry.put("status_code",      response.getStatusCode());
            entry.put("response_headers", headersToMap(response.getHeaders()));
            entry.put("response_body",    response.getBody().asString());
            log.info("api_call: {}", mapper.writeValueAsString(entry));
        } catch (Exception e) {
            log.warn("api_call logging failed: {}", e.getMessage());
        }
        return response;
    }

    private Map<String, String> headersToMap(io.restassured.http.Headers headers) {
        return headers.asList().stream()
            .collect(Collectors.toMap(
                io.restassured.http.Header::getName,
                io.restassured.http.Header::getValue,
                (a, b) -> a
            ));
    }
}
```

#### `TestConfigurationProperty.java` — non-sensitive config keys

```java
package <base.package>.<service>.system.e2e.api;

public enum TestConfigurationProperty {
    BASE_URL("base.url");

    private final String key;

    TestConfigurationProperty(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
```

#### `TestEnvironmentProperty.java` — sensitive keys from environment variables

```java
package <base.package>.<service>.system.e2e.api;

public enum TestEnvironmentProperty {
    ENVIRONMENT_TO_TEST,
    API_KEY,
    AUTH_TOKEN;
}
```

#### `TestSuite.java` — abstract base class

```java
package <base.package>.<service>.system.e2e.api;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public abstract class TestSuite {

    protected static String baseUrl;
    protected static String authToken;

    @BeforeAll
    static void setup() throws IOException {
        String env = System.getenv(TestEnvironmentProperty.ENVIRONMENT_TO_TEST.name());
        if (env == null || env.isBlank()) {
            env = "local";
        }

        Properties props = new Properties();
        try (InputStream in = TestSuite.class.getClassLoader()
                .getResourceAsStream("e2e.properties")) {
            if (in == null) {
                Assumptions.abort("E2E tests skipped — e2e.properties not found on classpath");
                return;
            }
            props.load(in);
        }

        baseUrl = props.getProperty(TestConfigurationProperty.BASE_URL.getKey() + "." + env);
        if (baseUrl == null || baseUrl.isBlank()) {
            Assumptions.abort("E2E tests skipped — no base.url." + env + " configured in e2e.properties");
            return;
        }

        authToken = System.getenv(TestEnvironmentProperty.AUTH_TOKEN.name());

        RestAssured.baseURI = baseUrl;
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
    }

    protected static RequestSpecification authenticatedRequest() {
        return given()
            .filter(new ApiCallLoggingFilter())
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .header("Authorization", "Bearer " + authToken);
    }

    protected static RequestSpecification unauthenticatedRequest() {
        return given()
            .filter(new ApiCallLoggingFilter())
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON);
    }
}
```

#### `tests/system/e2e/resources/e2e.properties` — environment base URLs

```properties
# E2E Test Configuration — non-sensitive values only
# Sensitive values (API keys, tokens) go in environment variables
# Set ENVIRONMENT_TO_TEST to any configured environment name before running tests
# Environment names are arbitrary — add entries for every environment the project uses

base.url.local=http://localhost:8080
base.url.qa=https://api-qa.example.com
base.url.lt1=https://api-lt1.example.com
base.url.prod=https://api.example.com
```

Add entries only for the environments the project uses. The environment name is the
value of `ENVIRONMENT_TO_TEST` — any name is valid (e.g. `qa1`, `lt1`, `qa1geo1`)
as long as a matching `base.url.<name>` entry exists in this file.

---

### Adding tests (ADD_TEST_ONLY mode)

Read the existing `TestSuite.java` to confirm helper method names. Generate only the new test class extending `TestSuite`.

---

### Test class pattern

```java
package <base.package>.<service>.system.e2e.api;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.hamcrest.Matchers.*;

// SC-1 | Verifies: BR-1
// @Tag("e2e_non_production"): creates or mutates data — never run in production
// @Tag("e2e_smoke"): must pass before a deployment is considered stable
@Tag("e2e_non_production")
@Tag("e2e_smoke")
class TestSC1_<DescriptionTest> extends TestSuite {

    @Test
    void sc1_<description>() {
        authenticatedRequest()
            .body("""
                { "field": "value" }
                """)
        .when()
            .post("/v1/<resource>")
        .then()
            .statusCode(201)
            .body("data.id", notNullValue())
            .body("data.field", equalTo("value"));
    }
}
```

**Authentication scenarios:**
```java
// SC-N: unauthenticated request returns 401
@Test
void sc<n>_missing_auth_header_returns_401() {
    unauthenticatedRequest()
    .when()
        .get("/v1/<resource>")
    .then()
        .statusCode(401);
}
```

**File naming:** `TestSC<N>_<Description>Test.java`

One test class per scenario. Name the class and test method after the scenario ID.

---

### Synthetic test data (R-4 and R-8)

Use a per-run unique ID to isolate test data between concurrent runs (R-8). A random
UUID is the correct mechanism — it ensures no two runs collide on the same data:

```java
// Per-run unique ID — ensures parallel runs don't collide on the same test data (R-8)
// UUID.randomUUID() generates a unique value per run; the data itself is fully synthetic
// (no real PII), satisfying R-4.
private final String testRunId = UUID.randomUUID().toString();
```

Use `testRunId` to build all synthetic field values that must be unique across runs,
e.g. `"test-member-" + testRunId`. This satisfies **both** R-4 (no real PII — data is
generated, not sourced from real users) and R-8 (unique per run — parallel-safe).

---

### Running the tests

```bash
# Run all E2E tests
./gradlew e2eTest

# Run only smoke tests
./gradlew e2eTest -Dgroups="e2e_smoke"

# Run against lt1
ENVIRONMENT_TO_TEST=lt1 AUTH_TOKEN=<token> ./gradlew e2eTest

# Run against any environment
ENVIRONMENT_TO_TEST=qa1geo1 AUTH_TOKEN=<token> ./gradlew e2eTest

# Run a single scenario class
./gradlew e2eTest --tests "*TestSC1_*"
```

---

## Verification

1. Confirm no `@SpringBootTest` annotation in any E2E test class.
2. Confirm no `@Testcontainers` or container fields in any E2E test class.
3. Confirm `baseUrl` is loaded from `e2e.properties` — never hardcoded.
4. Confirm `authToken` and other secrets are loaded from environment variables — never from `e2e.properties`.
5. Confirm test classes extend `TestSuite` and are named `TestSC<N>_<Description>Test`.
6. Confirm every test class carries `@Tag("e2e_non_production")` and/or `@Tag("e2e_smoke")` as appropriate.
7. Confirm `ApiCallLoggingFilter.java` is generated as part of the framework.
8. Confirm `TestSuite.authenticatedRequest()` and `unauthenticatedRequest()` attach `.filter(new ApiCallLoggingFilter())`.
9. Run `./gradlew e2eTest` — tests must pass or skip cleanly.
10. Run `./gradlew test` — E2E tests must not appear (source set isolation).
