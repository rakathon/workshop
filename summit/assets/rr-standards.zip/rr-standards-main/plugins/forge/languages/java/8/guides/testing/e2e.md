# Java 8 Guide — End-to-End Testing

Guide: 1.0.0 | Implements: standards/testing/e2e-testing.md@1.0.0

## Overview

Shows how to write end-to-end tests for a Spring Boot 2.7.x Java 8 service using
RestAssured. E2E tests issue real HTTP requests against a deployed service instance
and validate the observable behaviour from a client's perspective. No internal state
assertions — only response codes, headers, and body fields. Uses Spring Boot 2.x
`@SpringBootTest` with `RANDOM_PORT` and `javax.*` imports.

## Related standard

[E2E Testing Standard](../../../../../../../standards/testing/e2e-testing.md)

## Prerequisites

- `io.rest-assured:rest-assured`
- `io.rest-assured:spring-mock-mvc`
- A `e2e` Spring profile with real or stubbed backing services

Maven dependencies:

```xml
<dependency>
    <groupId>io.rest-assured</groupId>
    <artifactId>rest-assured</artifactId>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>io.rest-assured</groupId>
    <artifactId>spring-mock-mvc</artifactId>
    <scope>test</scope>
</dependency>
```

---

## Implementation

### Base E2E test class

```java
import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("e2e")
@Testcontainers
public abstract class E2ETestBase {

    @LocalServerPort
    protected int port;

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("rewards_e2e")
            .withUsername("e2e")
            .withPassword("e2e");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @BeforeEach
    void configureRestAssured() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = port;
        RestAssured.defaultParser = Parser.JSON;
    }
}
```

### Asserting the complete response contract

```java
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;

class StoreApiE2ETest extends E2ETestBase {

    @Test
    void givenNoStores_whenListStores_thenReturnsEmptyDataArray() {
        given()
            .header("Client-Agent", "e2e-test/1.0.0")
            .accept(ContentType.JSON)
        .when()
            .get("/store/v1/stores")
        .then()
            .statusCode(200)
            .body("data", hasSize(0))
            .body("meta.status.code", equalTo("OK"))
            .body("meta.operation.request_id", notNullValue());
    }

    @Test
    void givenValidRequest_whenCreateStore_thenReturns201WithLocation() {
        String body = "{ \"name\": \"E2E Store\" }";

        String location =
            given()
                .header("Client-Agent", "e2e-test/1.0.0")
                .contentType(ContentType.JSON)
                .body(body)
            .when()
                .post("/store/v1/stores")
            .then()
                .statusCode(201)
                .header("Location", startsWith("/store/v1/stores/"))
                .body("data.name", equalTo("E2E Store"))
                .body("data.version_token", notNullValue())
                .extract()
                .header("Location");

        // Confirm the created resource is retrievable at the Location URI
        given()
            .header("Client-Agent", "e2e-test/1.0.0")
        .when()
            .get(location)
        .then()
            .statusCode(200)
            .body("data.name", equalTo("E2E Store"));
    }

    @Test
    void givenMissingClientAgent_whenCallAnyEndpoint_thenReturns400() {
        given()
            .accept(ContentType.JSON)
        .when()
            .get("/store/v1/stores")
        .then()
            .statusCode(400);
    }

    @Test
    void givenStaleVersionToken_whenReplaceStore_thenReturns409WithCurrentState() {
        // First: create a store
        String createBody = "{ \"name\": \"Conflict Store\" }";
        String storeId =
            given()
                .header("Client-Agent", "e2e-test/1.0.0")
                .contentType(ContentType.JSON)
                .body(createBody)
            .when()
                .post("/store/v1/stores")
            .then()
                .statusCode(201)
                .extract()
                .path("data.id");

        // Then: PUT with a stale version token
        String staleBody =
            "{ \"name\": \"Updated\","
            + " \"version_token\": \"00000000-0000-0000-0000-000000000000\" }";

        given()
            .header("Client-Agent", "e2e-test/1.0.0")
            .contentType(ContentType.JSON)
            .body(staleBody)
        .when()
            .put("/store/v1/stores/" + storeId)
        .then()
            .statusCode(409)
            .body("data", notNullValue())
            .body("meta.status.code", equalTo("Conflict"));
    }
}
```

### Testing pagination bounds

```java
@Test
void givenManyStores_whenListWithLimit_thenReturnsBoundedPage() {
    given()
        .header("Client-Agent", "e2e-test/1.0.0")
        .queryParam("limit", 2)
    .when()
        .get("/store/v1/stores")
    .then()
        .statusCode(200)
        .body("data", hasSize(2))
        .body("pagination.next", notNullValue());
}
```

### Authentication E2E scenarios

```java
@Test
void givenNoToken_whenAccessMemberData_thenReturns401() {
    given()
        .header("Client-Agent", "e2e-test/1.0.0")
    .when()
        .get("/offers/v1/regions/JPN/members/" + TEST_MEMBER_GUID + "/offers")
    .then()
        .statusCode(401);
}

@Test
void givenValidToken_whenAccessMemberData_thenReturns200() {
    given()
        .header("Client-Agent", "e2e-test/1.0.0")
        .header("Authorization", "Bearer " + E2E_TEST_TOKEN)
    .when()
        .get("/offers/v1/regions/JPN/members/" + TEST_MEMBER_GUID + "/offers")
    .then()
        .statusCode(200)
        .body("data", notNullValue());
}
```

---

## Verification

1. Run `mvn verify -Pe2e` — all tests must pass.
2. Review every E2E test and confirm it asserts only on HTTP-observable state —
   no direct repository or database queries in assertions.
3. Confirm every response body assertion checks `meta.status.code` and
   `meta.operation.request_id`.
4. Confirm collection endpoint tests supply a `limit` parameter and assert on the
   size of the `data` array.
5. Grep for `var ` in test files — must be zero (Java 8 does not support `var`).
6. Run `mvn checkstyle:check` — zero violations required.
