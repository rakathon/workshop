# Java 8 Guide — Unit Testing

Guide: 1.0.0 | Implements: standards/testing/unit-testing.md@1.0.0

## Overview

Shows how to satisfy the Unit Testing standard in Java 8 using JUnit 5, Mockito, and
AssertJ. JUnit 5 supports Java 8 as its minimum runtime. All patterns are identical
to the Java 21 guide except that explicit type declarations replace `var` and Lombok
classes replace records in Arrange blocks.

## Related standard

[Unit Testing Standard](../../../../../../../standards/testing/unit-testing.md)

## Prerequisites

- JUnit 5 (`org.junit.jupiter:junit-jupiter`)
- Mockito (`org.mockito:mockito-junit-jupiter`)
- AssertJ (`org.assertj:assertj-core`)
- JaCoCo Maven plugin for coverage reporting

Maven test dependencies:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
    <!-- includes JUnit 5, Mockito, AssertJ, Spring Test -->
</dependency>
```

---

## Implementation

### Test class structure (FR-15, FR-10)

Every test class follows AAA (Arrange-Act-Assert). Annotate with
`@ExtendWith(MockitoExtension.class)` for automatic mock injection.

```java
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.util.Optional;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class DiscountServiceTest {

    @Mock
    private MemberRepository memberRepository;

    @Mock
    private OfferRepository offerRepository;

    @InjectMocks
    private DiscountService discountService;

    @Test
    void givenPremiumMember_whenCalculateDiscount_thenReturnsTenPercent() {
        // Arrange
        Member member = Member.builder()
            .id("m-1")
            .premium(true)
            .build();
        given(memberRepository.findById("m-1"))
            .willReturn(Optional.of(member));
        DecimalValue amount =
            DecimalValue.of(new BigDecimal("100.00"));

        // Act
        DecimalValue discount =
            discountService.calculateDiscount("m-1", amount);

        // Assert
        assertThat(discount.toBigDecimal())
            .isEqualByComparingTo(new BigDecimal("10.00"));
    }

    @Test
    void givenNonPremiumMember_whenCalculateDiscount_thenReturnsZero() {
        // Arrange
        Member member = Member.builder()
            .id("m-2")
            .premium(false)
            .build();
        given(memberRepository.findById("m-2"))
            .willReturn(Optional.of(member));
        DecimalValue amount =
            DecimalValue.of(new BigDecimal("100.00"));

        // Act
        DecimalValue discount =
            discountService.calculateDiscount("m-2", amount);

        // Assert
        assertThat(discount.getValue()).isZero();
    }
}
```

### Test naming convention

Use the pattern `given<Precondition>_when<Action>_then<ExpectedOutcome>`:

```java
// Correct
void givenExpiredToken_whenValidate_thenThrowsInvalidTokenException()
void givenEmptyCart_whenCheckout_thenThrowsEmptyCartException()
void givenValidRequest_whenCreateStore_thenReturnsCreatedStore()

// Wrong — vague
void testCreate()
void test1()
```

### Mock discipline (FR-3, FR-4)

Mock **external dependencies**; use **real objects** for domain logic and value objects.

```java
@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository repository;   // external: database

    @Mock
    private EmailClient emailClient;      // external: REST API

    @Mock
    private Clock clock;                  // external: time source

    @InjectMocks
    private OrderService orderService;

    // Use real instances for internal value objects:
    // OrderId, Money, OrderItem — no mocking needed
}
```

### Deterministic time — inject `Clock` (FR-9)

Never call `Instant.now()` directly in business logic. Inject `java.time.Clock`.

```java
// Production code
@Service
public class TokenService {

    private final Clock clock;

    public TokenService(Clock clock) {
        this.clock = clock;
    }

    public boolean isValid(Token token) {
        return token.getExpiresAt().isAfter(Instant.now(clock));
    }
}

// Test
@ExtendWith(MockitoExtension.class)
class TokenServiceTest {

    private static final Instant FIXED_NOW =
        Instant.parse("2024-06-15T12:00:00Z");

    @Mock
    private Clock clock;

    @InjectMocks
    private TokenService tokenService;

    @BeforeEach
    void setupClock() {
        given(clock.instant()).willReturn(FIXED_NOW);
        given(clock.getZone()).willReturn(ZoneOffset.UTC);
    }

    @Test
    void givenTokenExpiresInFuture_whenIsValid_thenReturnsTrue() {
        // Arrange
        Token token = Token.builder()
            .expiresAt(FIXED_NOW.plusSeconds(3600))
            .build();

        // Act
        boolean result = tokenService.isValid(token);

        // Assert
        assertThat(result).isTrue();
    }

    @Test
    void givenExpiredToken_whenIsValid_thenReturnsFalse() {
        // Arrange
        Token token = Token.builder()
            .expiresAt(FIXED_NOW.minusSeconds(1))
            .build();

        // Act
        boolean result = tokenService.isValid(token);

        // Assert
        assertThat(result).isFalse();
    }
}
```

### Static expected values — AssertJ assertions (FR-7)

Compare against a statically computed expected value, never two derived values:

```java
@Test
void givenTwoItems_whenCalculateTotal_thenReturnsSumPlusTax() {
    // Arrange
    List<Item> items = Arrays.asList(
        Item.builder()
            .price(DecimalValue.of(new BigDecimal("10.00")))
            .build(),
        Item.builder()
            .price(DecimalValue.of(new BigDecimal("20.00")))
            .build());

    // Act
    BigDecimal total =
        priceCalculator.calculateTotal(items, TAX_RATE_8_PCT);

    // Assert — 30.00 subtotal + 2.40 tax = 32.40 (hand-calculated)
    assertThat(total).isEqualByComparingTo(new BigDecimal("32.40"));
}
```

### Single act per test (FR-20)

Each test method must contain exactly one action in the Act phase:

```java
// Correct — one action, multiple assertions
@Test
void givenValidRequest_whenCreateOrder_thenOrderIsCreatedWithCorrectFields() {
    CreateOrderRequest request = new CreateOrderRequest(
        "member-1", Arrays.asList("item-1"));

    Order order = orderService.create(request);   // single action

    assertThat(order.getId()).isNotNull();
    assertThat(order.getMemberId()).isEqualTo("member-1");
    assertThat(order.getStatus()).isEqualTo(OrderStatus.PENDING);
}
```

### JaCoCo coverage configuration (FR-1)

Configure JaCoCo to enforce 90% minimum line and branch coverage:

```xml
<!-- pom.xml -->
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <executions>
        <execution>
            <id>prepare-agent</id>
            <goals><goal>prepare-agent</goal></goals>
        </execution>
        <execution>
            <id>check</id>
            <phase>verify</phase>
            <goals><goal>check</goal></goals>
            <configuration>
                <rules>
                    <rule>
                        <limits>
                            <limit>
                                <counter>LINE</counter>
                                <value>COVEREDRATIO</value>
                                <minimum>0.90</minimum>
                            </limit>
                            <limit>
                                <counter>BRANCH</counter>
                                <value>COVEREDRATIO</value>
                                <minimum>0.90</minimum>
                            </limit>
                        </limits>
                    </rule>
                </rules>
            </configuration>
        </execution>
    </executions>
</plugin>
```

---

## Verification

1. Run `mvn test` — all tests must pass.
2. Run `mvn verify` — confirm JaCoCo reports ≥90% line coverage and ≥90% branch
   coverage; the build must fail if either is below threshold.
3. Grep for `Instant.now()` and `LocalDate.now()` in `src/main/java` — no direct
   calls; all must use an injected `Clock`.
4. Grep for `var ` in test files — must be zero (Java 8 does not support `var`).
5. Run `mvn checkstyle:check` — zero violations required.
