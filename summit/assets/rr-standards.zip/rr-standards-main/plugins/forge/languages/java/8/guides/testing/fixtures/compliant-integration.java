// Compliant Java 8 integration test — real containers, no mocks for external deps
// Matches the Java 8 guide: datasource username/password wired, ObjectMapper autowired,
// Lombok @Builder for test data, AAA with comments, @Transactional rollback

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@Testcontainers
public abstract class IntegrationTestBase {

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("rewards_test")
            .withUsername("test")
            .withPassword("test");

    @Container
    static KafkaContainer kafka =
        new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.0"));

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);   // required by guide
        registry.add("spring.datasource.password", postgres::getPassword);   // required by guide
        registry.add("spring.kafka.bootstrap-servers", kafka::getBootstrapServers);
    }

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected ObjectMapper objectMapper;
}

// Repository test using real PostgreSQL — Lombok @Builder for test data (Java 8 idiom)
@Transactional   // rolls back after each test
class StoreRepositoryIntegrationTest extends IntegrationTestBase {

    @Autowired
    private StoreRepository storeRepository;

    @Test
    void givenStoreSaved_whenFindById_thenReturnsStore() {
        // Arrange — build a valid Store using the Lombok @Builder
        Store store = Store.builder()
            .id(UUID.randomUUID())
            .name("Test Store")
            .versionToken(UUID.randomUUID())
            .createdAt(Instant.now())
            .updatedAt(Instant.now())
            .build();
        storeRepository.save(store);

        // Act
        Optional<Store> found = storeRepository.findById(store.getId());

        // Assert — real DB round-trip, not a mock
        assertThat(found).isPresent();
        assertThat(found.get().getName()).isEqualTo("Test Store");
    }

    @Test
    void givenVersionTokenMismatch_whenReplace_thenThrowsVersionConflict() {
        // Arrange — store saved with known token; request uses different stale token
        Store store = storeRepository.save(Store.builder()
            .id(UUID.randomUUID())
            .name("Store A")
            .versionToken(UUID.randomUUID())
            .createdAt(Instant.now())
            .updatedAt(Instant.now())
            .build());
        UUID staleToken = UUID.randomUUID();

        // Act / Assert — concurrency guard enforced by real DB write
        assertThatThrownBy(
            () -> storeRepository.replaceWithVersionCheck(
                store.getId(), "Store B", staleToken))
            .isInstanceOf(VersionConflictException.class);
    }
}

// HTTP layer test via MockMvc — objectMapper for type-safe serialization
class StoreControllerIntegrationTest extends IntegrationTestBase {

    @Test
    void givenValidRequest_whenCreateStore_thenReturns201WithLocation() throws Exception {
        // Arrange
        CreateStoreRequest body = new CreateStoreRequest("New Store");
        String json = objectMapper.writeValueAsString(body);

        // Act / Assert
        mockMvc.perform(post("/store/v1/stores")
                .contentType(MediaType.APPLICATION_JSON)
                .header("Client-Agent", "test/1.0")
                .content(json))
            .andExpect(status().isCreated())
            .andExpect(header().exists("Location"));
    }
}
