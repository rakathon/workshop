# Java Guide — REST API Protocol

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/protocol.md@1.0.0

## Overview

Shows how to satisfy the REST API Protocol standard in a Spring Boot 3.x service.
Covers the response envelope record types, `ResponseEntity` usage, `@RestControllerAdvice`
error handling, `Client-Agent` header validation, `Retry-After` emission on 429 and 503,
and the `gzip` response content-encoding declaration. A service that follows this guide
produces uniformly enveloped responses, surfaces errors consistently, and applies the
correct HTTP status codes.

## Related standard

[REST API Protocol](../../../../../../standards/api/rest/protocol.md)

## Prerequisites

- Spring Boot 3.x (`spring-boot-starter-web`)
- Jackson with snake_case naming configured (see `contracts.md`)

---

## Implementation

### Response envelope records (R-5, R-6, R-8)

Define the envelope types once as Java records. All success responses wrap the
payload in `data`; all error responses use `errors` + `meta`. Never include a
`data` field on error responses.

```java
// Shared meta block — included in every response
public record Meta(StatusInfo status, OperationInfo operation) {

    public record StatusInfo(String code) {}

    public record OperationInfo(UUID requestId) {}

    public static Meta ok(UUID requestId) {
        return new Meta(
            new StatusInfo("OK"),
            new OperationInfo(requestId));
    }

    public static Meta of(String code, UUID requestId) {
        return new Meta(
            new StatusInfo(code),
            new OperationInfo(requestId));
    }
}

// Success response — single entity
public record DataResponse<T>(T data, Meta meta) {}

// Success response — collection with optional pagination
public record ListResponse<T>(
    List<T> data,
    @Nullable Object pagination,
    Meta meta) {}

// Error detail
public record ErrorDetail(
    String code,
    String message,
    @Nullable ErrorField details,
    @Nullable UUID traceId) {

    public record ErrorField(
        String field,
        @Nullable Object value,
        @Nullable String constraint) {}
}

// Error response — never has a 'data' field
public record ErrorResponse(List<ErrorDetail> errors, Meta meta) {}
```

### `ResponseEntity` usage in controllers (R-5, R-7)

Use `ResponseEntity` to explicitly set the status code and headers. Do not
return a raw object when headers or non-200 status codes are involved.

```java
@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    @GetMapping
    public ResponseEntity<ListResponse<Store>> listStores(
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        List<Store> stores = storeService.findAll();
        return ResponseEntity.ok(
            new ListResponse<>(stores, null, Meta.ok(requestId)));
    }

    @PostMapping                              // R-7: 201 for creation
    public ResponseEntity<DataResponse<Store>> createStore(
        @RequestBody @Valid CreateStoreRequest body,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        Store created = storeService.create(body);
        URI location = URI.create("/store/v1/stores/" + created.id());

        return ResponseEntity
            .created(location)              // sets Location header (R-7)
            .body(new DataResponse<>(created, Meta.ok(requestId)));
    }

    @DeleteMapping("/{store_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)  // R-7: 204 for deletion
    public void deleteStore(@PathVariable("store_id") String storeId) {
        storeService.delete(storeId);
    }
}
```

### Global error handler — `@RestControllerAdvice` (R-6, R-7, R-8)

Handle all exceptions in one place. Map each exception type to the correct status
code and an `ErrorResponse` body.

```java
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log =
        LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // R-7: 400 for requests that fail to parse or have unexpected shape
    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleUnparseable(
        HttpMessageNotReadableException ex,
        HttpServletRequest request) {

        return errorResponse("MALFORMED_REQUEST", ex.getMessage(), request);
    }

    // R-7: 400 for bean-validation failures
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidation(
        MethodArgumentNotValidException ex,
        HttpServletRequest request) {

        List<ErrorDetail> errors = ex.getBindingResult()
            .getFieldErrors().stream()
            .map(fe -> new ErrorDetail(
                "VALIDATION_ERROR",
                fe.getDefaultMessage(),
                new ErrorDetail.ErrorField(
                    fe.getField(), fe.getRejectedValue(), null),
                null))
            .toList();
        return new ErrorResponse(errors,
            Meta.of("BadRequest", RequestContext.requestId(request)));
    }

    // R-7: 401 for auth failures
    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleAuth(
        AuthenticationException ex,
        HttpServletRequest request) {

        return errorResponse("UNAUTHORIZED", ex.getMessage(), request);
    }

    // R-7: 403 for insufficient roles
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handleForbidden(
        AccessDeniedException ex,
        HttpServletRequest request) {

        return errorResponse("FORBIDDEN", ex.getMessage(), request);
    }

    // R-7: 404 for missing resources
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleNotFound(
        ResourceNotFoundException ex,
        HttpServletRequest request) {

        return errorResponse("NOT_FOUND", ex.getMessage(), request);
    }

    // R-7: 409 for version_token mismatches (see data.md)
    @ExceptionHandler(VersionConflictException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ResponseEntity<DataResponse<?>> handleConflict(
        VersionConflictException ex,
        HttpServletRequest request) {

        // Return the current entity state so the client can retry with the latest token
        return ResponseEntity
            .status(HttpStatus.CONFLICT)
            .body(new DataResponse<>(ex.currentState(),
                Meta.of("Conflict", RequestContext.requestId(request))));
    }

    // R-7: 422 for business-rule violations on well-formed requests
    @ExceptionHandler(BusinessRuleException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ErrorResponse handleBusinessRule(
        BusinessRuleException ex,
        HttpServletRequest request) {

        return errorResponse(ex.code(), ex.getMessage(), request);
    }

    // R-7: 429 with Retry-After (R-3)
    @ExceptionHandler(RateLimitExceededException.class)
    public ResponseEntity<ErrorResponse> handleRateLimit(
        RateLimitExceededException ex,
        HttpServletRequest request) {

        return ResponseEntity
            .status(HttpStatus.TOO_MANY_REQUESTS)
            .header("Retry-After", String.valueOf(ex.retryAfterSeconds()))
            .body(errorResponse("RATE_LIMIT_EXCEEDED", ex.getMessage(), request));
    }

    // R-7: 503 with Retry-After (R-3)
    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity<ErrorResponse> handleServiceUnavailable(
        ServiceUnavailableException ex,
        HttpServletRequest request) {

        return ResponseEntity
            .status(HttpStatus.SERVICE_UNAVAILABLE)
            .header("Retry-After", String.valueOf(ex.retryAfterSeconds()))
            .body(errorResponse("SERVICE_UNAVAILABLE", ex.getMessage(), request));
    }

    // Never return 200 for an error condition (R-7)
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleUnexpected(
        Exception ex,
        HttpServletRequest request) {

        log.error("Unhandled exception", ex);
        return errorResponse("INTERNAL_ERROR",
            "An unexpected error occurred", request);
    }

    private ErrorResponse errorResponse(
        String code, String message, HttpServletRequest request) {

        return new ErrorResponse(
            List.of(new ErrorDetail(code, message, null, null)),
            Meta.of(code, RequestContext.requestId(request)));
    }
}
```

### Client-Agent header (R-1)

Validate that the `Client-Agent` header is present on all requests. Add it as a
required `@RequestHeader` on each method, or enforce it globally via an interceptor.

```java
// Per-method — explicit contract
@GetMapping
public ResponseEntity<ListResponse<Store>> listStores(
    @RequestHeader("Client-Agent") String clientAgent,
    HttpServletRequest request) { ... }

// Or globally via interceptor
@Component
public class ClientAgentInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(
        HttpServletRequest request,
        HttpServletResponse response,
        Object handler) throws Exception {

        if (request.getHeader("Client-Agent") == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                "Client-Agent header is required");
            return false;
        }
        return true;
    }
}
```

### Custom headers — no `X-` prefix (R-2)

When defining custom headers, omit the `X-` prefix.

```java
// Correct
response.setHeader("Client-Agent", value);
response.setHeader("Retry-After", "30");

// Wrong
response.setHeader("X-Client-Agent", value);   // X- prefix prohibited
response.setHeader("X-Request-ID", requestId); // use meta.operation.request_id instead
```

### Status code selection guide (R-7)

| Situation | Status code |
|-----------|-------------|
| Read success | `200 OK` |
| Resource created | `201 Created` + `Location` header |
| Delete success | `204 No Content` |
| Request body fails to parse | `400 Bad Request` |
| Bean validation failures | `400 Bad Request` |
| Auth credentials missing/invalid | `401 Unauthorized` |
| Authenticated but insufficient roles | `403 Forbidden` |
| Resource does not exist | `404 Not Found` |
| `version_token` mismatch | `409 Conflict` + current entity state |
| Business rule violation (well-formed request) | `422 Unprocessable Entity` |
| Rate limit exceeded | `429 Too Many Requests` + `Retry-After` |
| Service temporarily unavailable | `503 Service Unavailable` + `Retry-After` |

**Never return `200` for an error condition** (R-7). The `success: false` pattern in
a `200` body is non-compliant.

---

## Verification

1. Call a `POST` that creates a resource — confirm `201` with a `Location` header
   pointing to the new resource URI.
2. Call an endpoint with a malformed body — confirm `400` with an `errors` array in
   the response body.
3. Trigger a rate limit (or throw `RateLimitExceededException` in a test) — confirm
   `429` with a `Retry-After` header.
4. Confirm no handler method or advice returns `200` for any exception path.
5. Confirm all `2xx` responses contain a `meta` block with `status.code` and
   `operation.request_id`; non-2xx responses contain `errors` and `meta` but no `data`.
6. Run `mvn checkstyle:check` — zero violations required.
