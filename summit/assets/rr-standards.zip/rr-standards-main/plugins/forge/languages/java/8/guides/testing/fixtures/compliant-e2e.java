// Compliant Java 8 E2E test — HTTP-observable assertions only, tagged, full contract check
// Extends E2ETestBase which provides: RANDOM_PORT SpringBootTest, PostgreSQLContainer,
// DynamicPropertySource for url/username/password, RestAssured setup, TEST_ENV detection,
// and @AfterEach cleanup strategy. RestAssured API is identical to Java 21 version.
// No 'var' keyword used (Java 8 compatible).
@Tag("e2e")
@Tag("non-production")  // creates real data — never run in production
class StoreApiE2ETest extends E2ETestBase {

    // REQ-STORE-002: POST with valid body must return 201, Location header, and response envelope
    // Smoke test — covers the critical create flow
    @Test
    @Tag("smoke-test")
    void givenValidRequest_whenCreateStore_thenReturns201WithEnvelope() {
        String location = given()
            .header("Client-Agent", "e2e-test/1.0.0")
            .contentType(ContentType.JSON)
            .body("{\"name\":\"E2E Store\"}")
        .when()
            .post("/store/v1/stores")
        .then()
            .statusCode(201)
            .header("Location", startsWith("/store/v1/stores/"))
            .body("data.name", equalTo("E2E Store"))
            .body("data.version_token", notNullValue())         // response envelope
            .body("meta.status.code", equalTo("OK"))            // meta block
            .body("meta.operation.request_id", notNullValue())  // correlation ID
            .extract().header("Location");

        // Verify resource is retrievable at the Location URI
        given().header("Client-Agent", "e2e-test/1.0.0")
        .when().get(location)
        .then().statusCode(200).body("data.name", equalTo("E2E Store"));
    }

    // REQ-STORE-003: Collection endpoints must respect limit and return pagination cursors
    // Test creates its own stores so it owns the data lifecycle and can run independently
    @Test
    void givenManyStores_whenListWithLimit_thenReturnsBoundedPage() {
        // Arrange — create test stores owned by this test (NFR-3: test independence)
        given().header("Client-Agent", "e2e-test/1.0.0").contentType(ContentType.JSON)
            .body("{\"name\":\"Page Store 1\"}").when().post("/store/v1/stores")
            .then().statusCode(201);
        given().header("Client-Agent", "e2e-test/1.0.0").contentType(ContentType.JSON)
            .body("{\"name\":\"Page Store 2\"}").when().post("/store/v1/stores")
            .then().statusCode(201);
        given().header("Client-Agent", "e2e-test/1.0.0").contentType(ContentType.JSON)
            .body("{\"name\":\"Page Store 3\"}").when().post("/store/v1/stores")
            .then().statusCode(201);

        // Act + Assert — verify bounded page and pagination cursor
        given()
            .header("Client-Agent", "e2e-test/1.0.0")
            .queryParam("limit", 2)
        .when()
            .get("/store/v1/stores")
        .then()
            .statusCode(200)
            .body("data", hasSize(2))
            .body("pagination.next", notNullValue());
    }

    // REQ-AUTH-001: Requests without authentication token to protected endpoints must return 401
    @Test
    @Tag("smoke-test")
    void givenNoToken_whenAccessMemberData_thenReturns401() {
        given().header("Client-Agent", "e2e-test/1.0.0")
        .when().get("/offers/v1/regions/JPN/members/" + MEMBER_GUID + "/offers")
        .then().statusCode(401);
    }

    // REQ-STORE-009: Requests missing Client-Agent header must be rejected with 400
    @Test
    void givenMissingClientAgent_whenListStores_thenReturns400() {
        given()   // no Client-Agent header — intentionally omitted
        .when().get("/store/v1/stores")
        .then().statusCode(400);
    }
}
