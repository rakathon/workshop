# Java Guide — Unit Testing

Guide: 1.0.0 | Implements: standards/testing/unit-testing.md@1.0.0

## Overview

Shows how to satisfy the Unit Testing standard in Java 21 using JUnit 5, Mockito, and
AssertJ. Covers test class structure, mock discipline, AAA pattern, naming conventions,
clock injection for determinism, and JaCoCo coverage configuration. A test suite that
follows this guide meets the 90% line and branch coverage requirement and remains fast,
isolated, and deterministic.

## Related standard

[Unit Testing Standard](../../../../../../../standards/testing/unit-testing.md)

## Prerequisites

- JUnit 5 (`org.junit.jupiter:junit-jupiter`)
- Mockito (`org.mockito:mockito-junit-jupiter`)
- AssertJ (`org.assertj:assertj-core`)
- JaCoCo Maven plugin for coverage reporting

Maven test dependencies:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
    <!-- includes JUnit 5, Mockito, AssertJ, Spring Test -->
</dependency>
```

---

## Implementation

### Test class structure (FR-15, FR-10)

Every test class follows AAA (Arrange-Act-Assert). Keep `@BeforeEach` to minimal
shared setup only — prefer per-test `Arrange` blocks so each test is self-contained.

```java
@ExtendWith(MockitoExtension.class)
class DiscountServiceTest {

    @Mock
    private MemberRepository memberRepository;

    @Mock
    private OfferRepository offerRepository;

    @InjectMocks
    private DiscountService discountService;

    @Test
    void givenPremiumMember_whenCalculateDiscount_thenReturnsTenPercent() {
        // Arrange
        Member member = new Member("m-1", true /* isPremium */);
        given(memberRepository.findById("m-1")).willReturn(Optional.of(member));

        // Act
        DecimalValue discount =
            discountService.calculateDiscount("m-1", DecimalValue.of(
                new BigDecimal("100.00")));

        // Assert
        assertThat(discount.toBigDecimal())
            .isEqualByComparingTo(new BigDecimal("10.00"));
    }

    @Test
    void givenNonPremiumMember_whenCalculateDiscount_thenReturnsZero() {
        // Arrange
        Member member = new Member("m-2", false);
        given(memberRepository.findById("m-2")).willReturn(Optional.of(member));

        // Act
        DecimalValue discount =
            discountService.calculateDiscount("m-2", DecimalValue.of(
                new BigDecimal("100.00")));

        // Assert
        assertThat(discount.value()).isZero();
    }
}
```

### Test naming convention

Name tests using the pattern `given<Precondition>_when<Action>_then<ExpectedOutcome>`:

```java
// Correct
void givenExpiredToken_whenValidate_thenThrowsInvalidTokenException()
void givenEmptyCart_whenCheckout_thenThrowsEmptyCartException()
void givenValidRequest_whenCreateStore_thenReturnsCreatedStore()

// Wrong — vague
void testCreate()
void test1()
void shouldWork()
```

### Mock discipline — what to mock, what not to mock (FR-3, FR-4)

Mock **external dependencies** (databases, REST clients, Kafka, clocks). Use **real
objects** for internal domain logic, value objects, and pure functions.

```java
@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository repository;   // external: database

    @Mock
    private EmailClient emailClient;      // external: REST API

    @Mock
    private Clock clock;                  // external: time source

    @InjectMocks
    private OrderService orderService;

    // Internal objects used directly — no mocking
    // OrderId, Money, OrderItem etc. are value objects: use real instances
}
```

Mocks must respect the real contract (FR-4). Use `@Mock` annotation rather than
ad-hoc stubs to ensure Mockito enforces the interface:

```java
// Correct — Mockito creates a type-safe mock from the interface
@Mock
private ProductApi productApi;

// Wrong — manual stub that may not match the real interface
private ProductApi productApi = (category) -> new ArrayList<>();
```

### Deterministic time — inject `Clock` (FR-9)

Never call `Instant.now()` or `LocalDate.now()` directly in business logic.
Inject `java.time.Clock` and use it; the test overrides the clock with a fixed instant.

```java
// Production code
@Service
public class TokenService {

    private final Clock clock;

    public TokenService(Clock clock) {
        this.clock = clock;
    }

    public boolean isValid(Token token) {
        return token.expiresAt().isAfter(Instant.now(clock));
    }
}

// Test
@ExtendWith(MockitoExtension.class)
class TokenServiceTest {

    private static final Instant FIXED_NOW =
        Instant.parse("2024-06-15T12:00:00Z");

    @Mock
    private Clock clock;

    @InjectMocks
    private TokenService tokenService;

    @BeforeEach
    void setupClock() {
        given(clock.instant()).willReturn(FIXED_NOW);
        given(clock.getZone()).willReturn(ZoneOffset.UTC);
    }

    @Test
    void givenTokenExpiresInFuture_whenIsValid_thenReturnsTrue() {
        // Arrange
        var token = new Token(FIXED_NOW.plusSeconds(3600));  // expires in 1 hour

        // Act
        boolean result = tokenService.isValid(token);

        // Assert
        assertThat(result).isTrue();
    }

    @Test
    void givenExpiredToken_whenIsValid_thenReturnsFalse() {
        // Arrange
        var token = new Token(FIXED_NOW.minusSeconds(1));   // expired 1 second ago

        // Act
        boolean result = tokenService.isValid(token);

        // Assert
        assertThat(result).isFalse();
    }
}
```

### Static expected values — AssertJ assertions (FR-7)

Compare against a statically computed expected value, never two derived values:

```java
// Correct — expected value calculated by hand, asserted against actual
@Test
void givenTwoItems_whenCalculateTotal_thenReturnsSumPlusTax() {
    var items = List.of(
        new Item(DecimalValue.of(new BigDecimal("10.00"))),
        new Item(DecimalValue.of(new BigDecimal("20.00"))));

    BigDecimal total = priceCalculator.calculateTotal(items, TAX_RATE_8_PCT);

    // 30.00 subtotal + 2.40 tax = 32.40 (hand-calculated)
    assertThat(total).isEqualByComparingTo(new BigDecimal("32.40"));
}

// Wrong — both values derived; test would pass even if both are wrong
@Test
void givenTwoItems_whenCalculateTotal_thenEqualsExpected() {
    BigDecimal total = priceCalculator.calculateTotal(items, TAX_RATE_8_PCT);
    BigDecimal expected = priceCalculator.calculateExpected(items);   // derived!
    assertThat(total).isEqualByComparingTo(expected);   // circular
}
```

### Single act per test (FR-20)

Each test method must contain exactly one method call or action in the Act phase.
Multiple assertions on the result of that single action are acceptable.

```java
// Correct — one action, multiple assertions
@Test
void givenValidRequest_whenCreateOrder_thenOrderIsCreatedWithCorrectFields() {
    var request = new CreateOrderRequest("member-1", List.of("item-1"));

    Order order = orderService.create(request);   // single action

    assertThat(order.id()).isNotNull();
    assertThat(order.memberId()).isEqualTo("member-1");
    assertThat(order.status()).isEqualTo(OrderStatus.PENDING);
}

// Wrong — two actions in one test
@Test
void testOrderLifecycle() {
    Order created = orderService.create(request);   // action 1
    Order cancelled = orderService.cancel(created.id());  // action 2 — split this
    assertThat(cancelled.status()).isEqualTo(OrderStatus.CANCELLED);
}
```

### JaCoCo coverage configuration (FR-1)

Configure JaCoCo to enforce 90% minimum line and branch coverage at build time:

```xml
<!-- pom.xml -->
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <executions>
        <execution>
            <id>prepare-agent</id>
            <goals><goal>prepare-agent</goal></goals>
        </execution>
        <execution>
            <id>check</id>
            <phase>verify</phase>
            <goals><goal>check</goal></goals>
            <configuration>
                <rules>
                    <rule>
                        <limits>
                            <limit>
                                <counter>LINE</counter>
                                <value>COVEREDRATIO</value>
                                <minimum>0.90</minimum>
                            </limit>
                            <limit>
                                <counter>BRANCH</counter>
                                <value>COVEREDRATIO</value>
                                <minimum>0.90</minimum>
                            </limit>
                        </limits>
                    </rule>
                </rules>
            </configuration>
        </execution>
    </executions>
</plugin>
```

---

## Verification

1. Run `mvn test` — all tests must pass.
2. Run `mvn verify` — confirm JaCoCo reports ≥90% line coverage and ≥90% branch
   coverage; the build must fail if either is below threshold.
3. Grep for `Instant.now()` and `LocalDate.now()` in `src/main/java` — no direct
   calls allowed; all must use an injected `Clock`.
4. Grep for `new ArrayList<>()` or similar ad-hoc stubs masking as mocks — confirm
   all external dependencies use `@Mock`.
5. Run `mvn checkstyle:check` — zero violations required.
