// Non-compliant Java 8 Kafka configuration — uses wrong error handler class and wrong header constant
// These violations are specifically relevant to Spring Kafka 2.x (Java 8 / Spring Boot 2.7.x)

// ---- KafkaConsumerConfig.java ----
// VIOLATION: Uses DefaultErrorHandler which is only available in Spring Kafka 3.x (Spring Boot 3.x)
// In Spring Boot 2.7.x / Spring Kafka 2.x, this class does not exist.
// The correct class is SeekToCurrentErrorHandler.
import org.springframework.kafka.listener.DefaultErrorHandler;  // WRONG: Spring Kafka 3.x only

@Configuration
public class KafkaConsumerConfig {

    @Bean
    public ConsumerFactory<String, Object> consumerFactory(
        KafkaProperties properties) {

        Map<String, Object> config =
            new HashMap<>(properties.buildConsumerProperties());
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
            StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
            JsonDeserializer.class);
        config.put(JsonDeserializer.TRUSTED_PACKAGES,
            "com.rakutenrewards.*");
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object>
        kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> consumerFactory,
            KafkaTemplate<String, Object> kafkaTemplate) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
            new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);

        // VIOLATION: DefaultErrorHandler does not exist in Spring Kafka 2.x
        // Should be SeekToCurrentErrorHandler for Spring Boot 2.7.x
        factory.setCommonErrorHandler(
            new DefaultErrorHandler(
                new DeadLetterPublishingRecoverer(kafkaTemplate),
                new FixedBackOff(1_000L, 2L)));

        return factory;
    }
}

// ---- OrderCreatedEvent.java ----
// Java 8 violation: plain class instead of Lombok @Value/@Builder — mutable, not immutable
public class OrderCreatedEvent {
    // WRONG: mutable fields — should be immutable with Lombok @Value
    public String orderId;
    public String memberId;
    public String status;
    public Instant createdAt;

    // WRONG: no-args constructor with no builder — verbose and error-prone
    public OrderCreatedEvent() {}
}

// ---- OrderEventConsumer.java ----
// VIOLATION: Uses RECEIVED_PARTITION header constant from Spring Kafka 3.x
// In Spring Kafka 2.x the constant is RECEIVED_PARTITION_ID
@Component
public class OrderEventConsumer {

    private static final Logger log =
        LoggerFactory.getLogger(OrderEventConsumer.class);

    @KafkaListener(
        topics = "order-events",
        groupId = "rewards-store-service")
    public void handleOrderCreated(
        @Payload OrderCreatedEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,  // WRONG: Spring Kafka 3.x constant
        @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("Received order event orderId={} topic={} partition={} offset={}",
            event.orderId, topic, partition, offset);
    }
}

// ---- OrderEventPublisher.java ----
// VIOLATION: Uses CompletableFuture.whenComplete — Spring Kafka 3.x API
// In Spring Kafka 2.x, kafkaTemplate.send() returns ListenableFuture, not CompletableFuture
@Service
public class OrderEventPublisher {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public OrderEventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishOrderCreated(Order order) {
        OrderCreatedEvent event = new OrderCreatedEvent();
        event.orderId = order.getId();
        event.memberId = order.getMemberId();

        // VIOLATION: .completable().whenComplete() is Spring Kafka 3.x API
        // Spring Kafka 2.x returns ListenableFuture — use addCallback instead
        kafkaTemplate.send("order-events", order.getId(), event)
            .completable()
            .whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Failed to publish event", ex);
                }
            });
    }
}
