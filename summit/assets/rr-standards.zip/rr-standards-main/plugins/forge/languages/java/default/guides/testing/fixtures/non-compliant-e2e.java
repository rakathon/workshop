// Non-compliant E2E test — uses @SpringBootTest local server instead of deployed service,
// hardcodes base URL, and does not extend TestSuite.

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)  // WRONG: starts local server
@ActiveProfiles("test")
class WalletE2ETest {

    @LocalServerPort
    private int port;  // WRONG: local port injection — not a real deployed service

    @Test
    void testWalletRedeem() {
        RestAssured.baseURI = "http://localhost";  // WRONG: hardcoded localhost
        RestAssured.port = port;                   // WRONG: using injected local port

        given()
            .contentType(ContentType.JSON)
            .header("Authorization", "Bearer hardcoded-token")  // WRONG: hardcoded secret
            .body("{ \"points\": 50 }")
        .when()
            .post("/v1/wallet/redeem")
        .then()
            .statusCode(200);
        // WRONG: no sc1_ prefix on test method, does not extend TestSuite,
        // base URL not from e2e.properties, auth token not from environment variable
    }
}
