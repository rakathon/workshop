// ---- JacksonConfig.java ----
// R-4: Global snake_case mapping — no per-field @JsonProperty needed
@Configuration
public class JacksonConfig {
    @Bean
    public Jackson2ObjectMapperBuilderCustomizer snakeCaseNaming() {
        return builder -> builder
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }
}

// ---- Response DTOs — Lombok @Value/@Builder (Java 8 idiom, no records) ----
@Value
@Builder
public class ListStoresResponse {
    List<Store> data;
    Meta meta;
}

@Value
@Builder
public class GetStoreResponse {
    Store data;
    Meta meta;
}

@Value
@Builder
public class CreateStoreResponse {
    Store data;
    Meta meta;
}

@Value
@Builder
public class UpdateStoreResponse {
    Store data;
    Meta meta;
}

// ---- StoreController.java ----
// R-1, R-2: URI /<contract>/v<N>/<collections>, version as v1 in second segment
// R-3: Plural snake_case collection segment "stores"
// R-5: No suffix = public contract
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    // R-7: GET for read
    @GetMapping
    public ResponseEntity<ListStoresResponse> listStores(HttpServletRequest req) {
        List<Store> stores = storeService.findAll();
        return ResponseEntity.ok(ListStoresResponse.builder()
            .data(stores)
            .meta(Meta.ok(requestId(req)))
            .build());
    }

    // R-3, R-4: snake_case path variable name in annotation string
    @GetMapping("/{store_id}")
    public ResponseEntity<GetStoreResponse> getStore(
        @PathVariable("store_id") String storeId, HttpServletRequest req) {
        Store store = storeService.findById(storeId);
        return ResponseEntity.ok(GetStoreResponse.builder()
            .data(store)
            .meta(Meta.ok(requestId(req)))
            .build());
    }

    // R-7: POST for create; returns 201 Created + Location header
    @PostMapping
    public ResponseEntity<CreateStoreResponse> createStore(
        @RequestBody @Valid CreateStoreRequest request, HttpServletRequest req) {
        Store created = storeService.create(request);
        URI location = URI.create("/store/v1/stores/" + created.getId());
        return ResponseEntity
            .created(location)                          // R-7: 201 + Location header
            .body(CreateStoreResponse.builder()
                .data(created)
                .meta(Meta.ok(requestId(req)))
                .build());
    }

    // R-7: PUT for full replacement
    @PutMapping("/{store_id}")
    public ResponseEntity<UpdateStoreResponse> replaceStore(
        @PathVariable("store_id") String storeId,
        @RequestBody @Valid ReplaceStoreRequest request, HttpServletRequest req) {
        Store updated = storeService.replace(storeId, request);
        return ResponseEntity.ok(UpdateStoreResponse.builder()
            .data(updated)
            .meta(Meta.ok(requestId(req)))
            .build());
    }

    // R-7: DELETE for deletion
    @DeleteMapping("/{store_id}")
    public ResponseEntity<Void> deleteStore(@PathVariable("store_id") String storeId) {
        storeService.delete(storeId);
        return ResponseEntity.noContent().build();      // R-7: 204 No Content
    }
}

// ---- StoreAdminController.java ----
// R-5: -admin suffix on contract name for admin APIs
@RestController
@RequestMapping("/store-admin/v1/stores")
public class StoreAdminController {
    @GetMapping
    public ResponseEntity<ListStoresResponse> listAllStores(HttpServletRequest req) {
        return ResponseEntity.ok(ListStoresResponse.builder()
            .data(storeService.findAll())
            .meta(Meta.ok(requestId(req)))
            .build());
    }
}

// ---- StoreInternalController.java ----
// R-5: -int suffix for internal server-to-server APIs
@RestController
@RequestMapping("/store-int/v1/stores")
public class StoreInternalController {
    @GetMapping
    public ResponseEntity<ListStoresResponse> listStoresInternal(HttpServletRequest req) {
        return ResponseEntity.ok(ListStoresResponse.builder()
            .data(storeService.findAll())
            .meta(Meta.ok(requestId(req)))
            .build());
    }
}

// ---- MemberOffersController.java ----
// R-10: Public contract uses member_guid (String — non-sequential unique identifier)
// R-1: Regional pattern /regions/{region_id}/members/{member_guid}/
@RestController
@RequestMapping("/offers/v1/regions/{region_id}/members/{member_guid}/offers")
public class MemberOffersController {
    @GetMapping
    public ResponseEntity<ListMemberOffersResponse> listMemberOffers(
        @PathVariable("region_id") String regionId,
        @PathVariable("member_guid") String memberGuid,   // String, not long — R-10
        HttpServletRequest req) {
        List<Offer> offers = offerService.findForMember(regionId, memberGuid);
        return ResponseEntity.ok(ListMemberOffersResponse.builder()
            .data(offers)
            .meta(Meta.ok(requestId(req)))
            .build());
    }
}

// ---- MemberOffersInternalController.java ----
// R-10: Internal contract (-int) uses member_id (long — incrementing integer)
@RestController
@RequestMapping("/offers-int/v1/regions/{region_id}/members/{member_id}/offers")
public class MemberOffersInternalController {
    @GetMapping
    public ResponseEntity<ListMemberOffersResponse> listMemberOffers(
        @PathVariable("region_id") String regionId,
        @PathVariable("member_id") long memberId,         // long, not String — R-10
        HttpServletRequest req) {
        return ResponseEntity.ok(ListMemberOffersResponse.builder()
            .data(offerService.findForMember(regionId, memberId))
            .meta(Meta.ok(requestId(req)))
            .build());
    }
}

// ---- V1SunsetInterceptor.java + WebConfig registration ----
// R-8: Sunset headers during deprecation window, registered via WebMvcConfigurer
public class V1SunsetInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object h) {
        res.setHeader("Deprecation", "Sun, 11 Nov 2025 23:59:59 GMT");
        res.setHeader("Sunset", "Wed, 11 Mar 2026 23:59:59 GMT");
        res.setHeader("Link", "</store/v2/stores>; rel=\"latest-version\"");
        return true;
    }
}

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new V1SunsetInterceptor())
            .addPathPatterns("/store/v1/**");             // R-8: registered for deprecated version
    }
}

// ---- StoreApplication.java ----
// R-9: OpenAPI spec; info.version is major version only
// Uses springdoc-openapi-ui (Spring Boot 2.7.x artifact, not starter-webmvc-ui)
@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "Store API", version = "1"))  // "1" not "1.2.3"
public class StoreApplication {
    public static void main(String[] args) { SpringApplication.run(StoreApplication.class, args); }
}
