// ---- Meta.java ----
// R-6: Required meta fields — status.code and operation.request_id (UUID) in every response
public record Meta(StatusInfo status, OperationInfo operation) {

    public record StatusInfo(String code) {}

    public record OperationInfo(UUID requestId) {}

    public static Meta ok(UUID requestId) {
        return new Meta(new StatusInfo("OK"), new OperationInfo(requestId));
    }

    public static Meta of(String code, UUID requestId) {
        return new Meta(new StatusInfo(code), new OperationInfo(requestId));
    }
}

// ---- DataResponse.java ----
// R-5: Success responses wrap payload in 'data' field with 'meta'; no 'errors' on success
public record DataResponse<T>(T data, Meta meta) {}

// ---- ListResponse.java ----
// R-5: Collection success response with 'data', optional 'pagination', and 'meta'
public record ListResponse<T>(List<T> data, @Nullable Object pagination, Meta meta) {}

// ---- ErrorDetail.java ----
public record ErrorDetail(
    String code,
    String message,
    @Nullable ErrorField details,
    @Nullable UUID traceId) {

    public record ErrorField(String field, @Nullable Object value, @Nullable String constraint) {}
}

// ---- ErrorResponse.java ----
// R-5, R-6: Error responses have 'errors' + 'meta' ONLY — never a 'data' field
public record ErrorResponse(List<ErrorDetail> errors, Meta meta) {}

// ---- application.yml (gzip compression — R-4) ----
// server.compression.enabled: true
// server.compression.mime-types: application/json,application/xml,text/plain
// (gzip enabled at server level; Content-Encoding: gzip returned unless response is small)

// ---- StoreController.java ----
// R-1: Client-Agent header validation via @RequestHeader
// R-7: POST for creation returns 201 Created with Location header
@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    @GetMapping
    public ResponseEntity<ListResponse<Store>> listStores(
        @RequestHeader("Client-Agent") String clientAgent,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        List<Store> stores = storeService.findAll();
        return ResponseEntity.ok(
            new ListResponse<>(stores, null, Meta.ok(requestId)));
    }

    @GetMapping("/{store_id}")
    public ResponseEntity<DataResponse<Store>> getStore(
        @PathVariable("store_id") String storeId,
        @RequestHeader("Client-Agent") String clientAgent,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        Store store = storeService.findById(storeId);
        return ResponseEntity.ok(new DataResponse<>(store, Meta.ok(requestId)));
    }

    // R-7: POST create returns 201 Created + Location header (never 200)
    @PostMapping
    public ResponseEntity<DataResponse<Store>> createStore(
        @RequestBody @Valid CreateStoreRequest body,
        @RequestHeader("Client-Agent") String clientAgent,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        Store created = storeService.create(body);
        URI location = URI.create("/store/v1/stores/" + created.id());

        return ResponseEntity
            .created(location)              // 201 + Location header (R-7)
            .body(new DataResponse<>(created, Meta.ok(requestId)));
    }

    @DeleteMapping("/{store_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)  // R-7: 204 for deletion
    public void deleteStore(
        @PathVariable("store_id") String storeId,
        @RequestHeader("Client-Agent") String clientAgent) {
        storeService.delete(storeId);
    }
}

// ---- GlobalExceptionHandler.java ----
// R-6, R-7, R-8: All errors return ErrorResponse (errors + meta, NEVER data on errors)
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // R-7: 400 for unparseable request body
    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleUnparseable(
        HttpMessageNotReadableException ex, HttpServletRequest request) {
        return errorResponse("MALFORMED_REQUEST", ex.getMessage(), request);
    }

    // R-7: 400 for bean validation failures
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidation(
        MethodArgumentNotValidException ex, HttpServletRequest request) {
        List<ErrorDetail> errors = ex.getBindingResult().getFieldErrors().stream()
            .map(fe -> new ErrorDetail(
                "VALIDATION_ERROR", fe.getDefaultMessage(),
                new ErrorDetail.ErrorField(fe.getField(), fe.getRejectedValue(), null), null))
            .toList();
        return new ErrorResponse(errors,
            Meta.of("BadRequest", RequestContext.requestId(request)));
    }

    // R-7: 401 for authentication failures
    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleAuth(AuthenticationException ex, HttpServletRequest request) {
        return errorResponse("UNAUTHORIZED", ex.getMessage(), request);
    }

    // R-7: 403 for insufficient roles (access denied)
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handleForbidden(AccessDeniedException ex, HttpServletRequest request) {
        return errorResponse("FORBIDDEN", ex.getMessage(), request);
    }

    // R-7: 404 for missing resources
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleNotFound(ResourceNotFoundException ex, HttpServletRequest request) {
        return errorResponse("NOT_FOUND", ex.getMessage(), request);
    }

    // R-7: 409 for version_token mismatch — R-5 EXCEPTION: 409 Conflict for optimistic
    // concurrency failures MUST include 'data' with the current resource state so the
    // client can re-apply its change without an extra read round-trip (per R-5 exception).
    @ExceptionHandler(VersionConflictException.class)
    public ResponseEntity<DataResponse<?>> handleConflict(
        VersionConflictException ex, HttpServletRequest request) {
        // R-5 explicitly permits 'data' on 409 Conflict for optimistic concurrency:
        // "Exception: 409 Conflict responses for optimistic concurrency failures must
        //  additionally include data with the current resource state"
        return ResponseEntity
            .status(HttpStatus.CONFLICT)
            .body(new DataResponse<>(ex.currentState(),
                Meta.of("Conflict", RequestContext.requestId(request))));
    }

    // R-7: 422 for business-rule violations on well-formed requests
    @ExceptionHandler(BusinessRuleException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ErrorResponse handleBusinessRule(BusinessRuleException ex, HttpServletRequest request) {
        return errorResponse(ex.code(), ex.getMessage(), request);
    }

    // R-7: 429 with Retry-After header (R-3)
    @ExceptionHandler(RateLimitExceededException.class)
    public ResponseEntity<ErrorResponse> handleRateLimit(
        RateLimitExceededException ex, HttpServletRequest request) {
        return ResponseEntity
            .status(HttpStatus.TOO_MANY_REQUESTS)
            .header("Retry-After", String.valueOf(ex.retryAfterSeconds()))  // R-3
            .body(errorResponse("RATE_LIMIT_EXCEEDED", ex.getMessage(), request));
    }

    // R-7: 503 with Retry-After header (R-3)
    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity<ErrorResponse> handleServiceUnavailable(
        ServiceUnavailableException ex, HttpServletRequest request) {
        return ResponseEntity
            .status(HttpStatus.SERVICE_UNAVAILABLE)
            .header("Retry-After", String.valueOf(ex.retryAfterSeconds()))  // R-3
            .body(errorResponse("SERVICE_UNAVAILABLE", ex.getMessage(), request));
    }

    // R-7: NEVER return 200 for error conditions — catch-all returns 500
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleUnexpected(Exception ex, HttpServletRequest request) {
        log.error("Unhandled exception", ex);
        return errorResponse("INTERNAL_ERROR", "An unexpected error occurred", request);
    }

    private ErrorResponse errorResponse(String code, String message, HttpServletRequest request) {
        return new ErrorResponse(
            List.of(new ErrorDetail(code, message, null, null)),
            Meta.of(code, RequestContext.requestId(request)));
    }
}
