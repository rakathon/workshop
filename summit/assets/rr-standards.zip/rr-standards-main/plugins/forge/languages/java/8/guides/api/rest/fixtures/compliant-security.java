// ---- PublicContractSecurityConfig.java ----
// R-1: EbtokenAuthFilter on member-data endpoints; accepts Bearer header OR euid cookie
// Spring Security 5.7.x style — uses .requestMatcher() and .authorizeRequests()
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Configuration
@EnableWebSecurity
public class PublicContractSecurityConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain memberDataFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .requestMatcher(new OrRequestMatcher(
                new AntPathRequestMatcher("/store/v1/**"),
                new AntPathRequestMatcher("/offers/v1/**")))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .addFilterBefore(
                new EbtokenAuthFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeRequests()
                // Non-member data endpoints — no auth required
                .antMatchers(HttpMethod.GET, "/store/v1/stores").permitAll()
                // Member-scoped paths require authentication (R-1)
                .antMatchers("/store/v1/regions/*/members/**").authenticated()
                .antMatchers("/offers/v1/regions/*/members/**").authenticated()
                .anyRequest().permitAll()
                .and()
            .build();
    }
}

// ---- EbtokenAuthFilter.java ----
// R-1: Accepts Bearer header OR euid cookie; 401 on invalid token
// Uses javax.servlet.* (Java 8 / Spring Boot 2.7.x)
public class EbtokenAuthFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenAuthFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = extractToken(request);
        if (token != null) {
            try {
                MemberClaims claims = validator.validate(token);
                EbtokenAuthentication auth = new EbtokenAuthentication(claims);
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch (InvalidTokenException ex) {
                SecurityContextHolder.clearContext();
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                    "Invalid or expired ebtoken");
                return;
            }
        }
        chain.doFilter(request, response);
    }

    private String extractToken(HttpServletRequest request) {
        // 1. Bearer header (Authorization: Bearer <ebtoken>)
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        // 2. euid cookie (for browser clients — R-1 alternative)
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("euid".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}

// ---- AdminContractSecurityConfig.java ----
// R-2: EbtokenRoleFilter on -admin contract; validates JWT + required roles; 403 on missing role
// Spring Security 5.7.x: .requestMatcher() and .authorizeRequests().anyRequest().hasAuthority()
@Configuration
@EnableWebSecurity
public class AdminContractSecurityConfig {

    @Bean
    @Order(2)
    public SecurityFilterChain adminFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .requestMatcher(new AntPathRequestMatcher("/store-admin/v1/**"))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .addFilterBefore(
                new EbtokenRoleFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeRequests()
                .anyRequest().hasAuthority("ROLE_store_admin")   // R-2: role check required
                .and()
            .exceptionHandling()
                .authenticationEntryPoint(
                    (req, res, ex) -> res.sendError(HttpServletResponse.SC_UNAUTHORIZED))
                .accessDeniedHandler(
                    (req, res, ex) -> res.sendError(HttpServletResponse.SC_FORBIDDEN))
                .and()
            .build();
    }
}

// ---- EbtokenRoleFilter.java ----
// R-2: Validates JWT + extracts roles as ROLE_<role> granted authorities
public class EbtokenRoleFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenRoleFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Bearer token required");
            return;
        }
        try {
            AdminClaims claims = validator.validateAdmin(authHeader.substring(7));
            // Roles extracted from JWT claims as ROLE_<role> granted authorities (R-2)
            List<SimpleGrantedAuthority> authorities = new ArrayList<>();
            for (String role : claims.getRoles()) {
                authorities.add(new SimpleGrantedAuthority("ROLE_" + role));
            }
            UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(
                    claims.getOperatorId(), null, authorities);
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid or expired admin token");
            return;
        }
        chain.doFilter(request, response);
    }
}

// ---- InternalContractSecurityConfig.java ----
// R-3: ServerToServerAuthFilter on sensitive -int endpoints; 401 on missing s2s token
@Configuration
@EnableWebSecurity
public class InternalContractSecurityConfig {

    @Bean
    @Order(3)
    public SecurityFilterChain internalFilterChain(
        HttpSecurity http,
        ServerToServerTokenValidator s2sValidator) throws Exception {

        return http
            .requestMatcher(new OrRequestMatcher(
                new AntPathRequestMatcher("/wallet-int/v1/**"),
                new AntPathRequestMatcher("/pii-int/v1/**")))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .addFilterBefore(
                new ServerToServerAuthFilter(s2sValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeRequests()
                .anyRequest().authenticated()
                .and()
            .build();
    }
}

// ---- ServerToServerAuthFilter.java ----
// R-3: Validates server-to-server token; 401 on missing or invalid token
public class ServerToServerAuthFilter extends OncePerRequestFilter {

    private final ServerToServerTokenValidator validator;

    public ServerToServerAuthFilter(ServerToServerTokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = request.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Server-to-server token required");
            return;
        }
        try {
            ServiceIdentity identity = validator.validate(token.substring(7));
            UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(
                    identity.getServiceId(), null,
                    Collections.singletonList(new SimpleGrantedAuthority("ROLE_service")));
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid server-to-server token");
            return;
        }
        chain.doFilter(request, response);
    }
}
