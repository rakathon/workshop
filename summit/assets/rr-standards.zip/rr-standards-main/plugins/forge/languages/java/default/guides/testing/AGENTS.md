# Testing — Java Guides

## Directory purpose

Java testing implementation guides covering the three test layers — unit, integration,
and end-to-end. Each guide specifies the recommended frameworks, project structure,
and patterns for that layer. Load the guide that matches the layer you are authoring
or reviewing.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `unit.md` | JUnit 5 + Mockito + AssertJ patterns; AAA structure; mock discipline; coverage targets | Writing or reviewing unit tests |
| `unit.test.yaml` | Behavioral effectiveness tests for the Java unit testing guide | Running behavioral validation or adding new test cases for the Java unit guide |
| `integration.md` | Spring Boot Test + Testcontainers; MockMvc HTTP layer; test data setup; parallel safety | Writing or reviewing integration tests against real containers |
| `integration.test.yaml` | Behavioral effectiveness tests for the Java integration testing guide | Running behavioral validation or adding new test cases for the Java integration guide |
| `e2e.md` | End-to-end test patterns with RestAssured against a running service; environment bootstrap; CI integration | Writing or reviewing full end-to-end test suites |
| `e2e.test.yaml` | Behavioral effectiveness tests for the Java E2E testing guide | Running behavioral validation or adding new test cases for the Java E2E guide |
| `fixtures/` | Compliant and non-compliant Java fixture files used by `.test.yaml` behavioral tests | When authoring or reviewing `.test.yaml` test cases |

## Navigation

- [Java default root](../../AGENTS.md)
- [Unit testing standard](../../../../../standards/testing/unit.md)
- [Integration testing standard](../../../../../standards/testing/integration.md)
- [E2E testing standard](../../../../../standards/testing/e2e.md)
