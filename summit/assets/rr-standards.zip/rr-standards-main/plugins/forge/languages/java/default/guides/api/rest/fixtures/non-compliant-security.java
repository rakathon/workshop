// This security config violates several rules from the REST API Security standard.
// It looks like plausible production Spring Security code but contains multiple violations.

// ---- R-1 VIOLATION: MemberDataSecurityConfig.java ----
// Member-data endpoint uses HTTP Basic auth instead of ebtoken Bearer/euid cookie.
// Basic auth is not the approved scheme for public member-data contracts.
@Configuration
@EnableWebSecurity
public class MemberDataSecurityConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain memberDataFilterChain(HttpSecurity http) throws Exception {

        return http
            .securityMatcher("/store/v1/**", "/offers/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            // R-1 VIOLATION: HTTP Basic auth instead of EbtokenAuthFilter with Bearer/euid cookie
            .httpBasic(Customizer.withDefaults())
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/store/v1/regions/*/members/**")
                    .authenticated()
                .requestMatchers("/offers/v1/regions/*/members/**")
                    .authenticated()
                .anyRequest().permitAll())
            .build();
    }
}

// ---- ApiKeyAuthFilter.java ----
// R-1 VIOLATION: Uses X-API-Key header instead of Bearer token or euid cookie
// for some endpoints (non-standard scheme not approved for member-data contracts)
public class ApiKeyAuthFilter extends OncePerRequestFilter {

    private final ApiKeyStore apiKeyStore;

    public ApiKeyAuthFilter(ApiKeyStore apiKeyStore) {
        this.apiKeyStore = apiKeyStore;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        // R-1 VIOLATION: X-API-Key is not the approved auth scheme for member-data endpoints;
        // should be Authorization: Bearer <ebtoken> or euid cookie
        String apiKey = request.getHeader("X-API-Key");
        if (apiKey != null && apiKeyStore.isValid(apiKey)) {
            var auth = new UsernamePasswordAuthenticationToken(apiKey, null,
                List.of(new SimpleGrantedAuthority("ROLE_api_client")));
            SecurityContextHolder.getContext().setAuthentication(auth);
        }
        chain.doFilter(request, response);
    }
}

// ---- AdminContractSecurityConfig.java ----
// R-2 VIOLATION: Admin contract endpoint has no role validation — permits all authenticated
@Configuration
@EnableWebSecurity
public class AdminContractSecurityConfig {

    @Bean
    @Order(2)
    public SecurityFilterChain adminFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .securityMatcher("/store-admin/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(
                new EbtokenAuthFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                // R-2 VIOLATION: No role validation — any authenticated user can reach admin endpoints.
                // Should be .anyRequest().hasAuthority("ROLE_store_admin")
                .anyRequest().authenticated())
            .build();
    }
}

// ---- InternalContractSecurityConfig.java ----
// R-3 VIOLATION: Sensitive -int balance endpoint has no authentication at all
@Configuration
@EnableWebSecurity
public class InternalContractSecurityConfig {

    @Bean
    @Order(3)
    public SecurityFilterChain internalFilterChain(HttpSecurity http) throws Exception {

        return http
            .securityMatcher("/wallet-int/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            // R-3 VIOLATION: No ServerToServerAuthFilter added; no token validation at all
            .authorizeHttpRequests(authz -> authz
                // R-3 VIOLATION: /wallet-int/v1/balance (sensitive operation) is publicly accessible
                .requestMatchers("/wallet-int/v1/balance")
                    .permitAll()
                .anyRequest().authenticated())
            .build();
    }
}
