// Compliant Java 8 unit test demonstrating all key patterns from the guide
// Java 8 differences: Lombok @Builder for test data, Arrays.asList(), no var keyword
@ExtendWith(MockitoExtension.class)
class DiscountServiceTest {

    @Mock
    private MemberRepository memberRepository;   // external dependency: mocked

    @Mock
    private Clock clock;                          // time source: always injected, never Instant.now()

    @InjectMocks
    private DiscountService discountService;

    private static final Instant FIXED_NOW = Instant.parse("2024-06-15T12:00:00Z");

    @BeforeEach
    void setupClock() {
        given(clock.instant()).willReturn(FIXED_NOW);
        given(clock.getZone()).willReturn(ZoneOffset.UTC);
    }

    // Naming: given<Precondition>_when<Action>_then<Outcome>
    @Test
    void givenPremiumMember_whenCalculateDiscount_thenReturnsTenPercent() {
        // Arrange — Lombok @Builder for test data construction (Java 8 idiom)
        Member member = Member.builder()
            .id("m-1")
            .premium(true)
            .build();
        given(memberRepository.findById("m-1")).willReturn(Optional.of(member));

        // Act
        DecimalValue discount = discountService.calculateDiscount("m-1", new BigDecimal("100.00"));

        // Assert — static expected value, not derived
        assertThat(discount.toBigDecimal()).isEqualByComparingTo(new BigDecimal("10.00"));
    }

    @Test
    void givenExpiredToken_whenValidate_thenReturnsFalse() {
        // Arrange — token expired before fixed clock time
        Token token = new Token(FIXED_NOW.minusSeconds(1));

        // Act — single action
        boolean result = discountService.tokenValidator().isValid(token);

        // Assert
        assertThat(result).isFalse();
    }

    @Test
    void givenCartWithMultipleItems_whenCalculateTotalDiscount_thenReturnsCorrectValue() {
        // Arrange — Arrays.asList() instead of List.of() (Java 8 compatible)
        List<Item> items = Arrays.asList(
            Item.builder().price(DecimalValue.of(new BigDecimal("50.00"))).build(),
            Item.builder().price(DecimalValue.of(new BigDecimal("50.00"))).build()
        );
        Member member = Member.builder().id("m-2").premium(false).build();
        given(memberRepository.findById("m-2")).willReturn(Optional.of(member));

        // Act
        DecimalValue discount = discountService.calculateCartDiscount("m-2", items);

        // Assert
        assertThat(discount.toBigDecimal()).isEqualByComparingTo(new BigDecimal("5.00"));
    }
}

// JaCoCo configuration enforcing 90% line and branch coverage
// pom.xml excerpt:
// <plugin><groupId>org.jacoco</groupId><artifactId>jacoco-maven-plugin</artifactId>
//   <execution><id>check</id><goals><goal>check</goal></goals>
//     <configuration><rules><rule><limits>
//       <limit><counter>LINE</counter><value>COVEREDRATIO</value><minimum>0.90</minimum></limit>
//       <limit><counter>BRANCH</counter><value>COVEREDRATIO</value><minimum>0.90</minimum></limit>
//     </limits></rule></rules></configuration></execution></plugin>
