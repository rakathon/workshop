# REST API — Java Guides

## Directory purpose

Spring MVC / Spring Boot 3.x implementations of the four REST API sub-standards.
Each sub-guide covers one concern and shows the exact Java constructs — annotations,
POJOs, controller structures, and filter configurations — that satisfy the
corresponding standard's rules. Load all four when scaffolding a new Spring Boot
REST service from scratch; load individual guides when reviewing or generating a
specific aspect of an existing service.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `contracts.md` | `@RestController` URI structure, `@PathVariable` naming, HTTP verb mapping, version path prefixes, sunset headers | Authoring or reviewing controller routing, URI design, or versioning decisions |
| `security.md` | Spring Security filter chains for JWT bearer, euid cookie, and server-to-server auth; role validation on admin contracts | Authoring or reviewing any Spring Security configuration |
| `protocol.md` | Response envelope records, `ResponseEntity` usage, `@RestControllerAdvice` error handling, status code selection | Authoring or reviewing response shapes, error bodies, or status code choices |
| `data.md` | Pagination response types, `version_token` on write requests, `Instant` timestamps, decimal/currency value objects, tracing header propagation | Authoring or reviewing request/response body field definitions |

## Navigation

- [Java default root](../../../AGENTS.md)
- [REST API standards](../../../../../../standards/api/rest/) — the standards these guides implement
