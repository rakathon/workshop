# Testing — Java 8 Guides

## Directory purpose

Java 8 testing implementation guides covering unit, integration, and end-to-end
test layers. All guides target Spring Boot 2.7.x and use JUnit 5, Mockito, AssertJ,
and Testcontainers — all of which support Java 8.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `unit.md` | JUnit 5 + Mockito + AssertJ patterns; AAA structure; mock discipline; clock injection; coverage targets | Writing or reviewing unit tests |
| `integration.md` | Spring Boot 2.x Test + Testcontainers; MockMvc HTTP layer; test data setup; parallel safety | Writing or reviewing integration tests against real containers |
| `e2e.md` | End-to-end test patterns with RestAssured against a Spring Boot 2.x service | Writing or reviewing full end-to-end test suites |

## Navigation

- [Java 8 root](../../AGENTS.md)
- [Unit testing standard](../../../../../../../standards/testing/unit-testing.md)
- [Integration testing standard](../../../../../../../standards/testing/integration-testing.md)
- [E2E testing standard](../../../../../../../standards/testing/e2e-testing.md)
