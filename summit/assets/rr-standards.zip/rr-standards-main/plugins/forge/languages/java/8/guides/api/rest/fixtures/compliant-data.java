// ---- CursorPagination.java ----
// R-1, R-2: Default forward-only cursor pagination — Lombok @Value (Java 8, no records)
import lombok.Value;
import lombok.Builder;

@Value
@Builder
public class CursorPagination {
    String next;
}

// ---- DecimalValue.java ----
// R-5: Lossless decimal — value/scale tuple instead of double/float
// Java 8: @Value class with explicit constructor validation (no compact constructor)
@Value
public class DecimalValue {
    long value;
    int scale;

    public DecimalValue(long value, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
        this.value = value;
        this.scale = scale;
    }

    public BigDecimal toBigDecimal() {
        return new BigDecimal(value).movePointLeft(scale);
    }

    public static DecimalValue of(BigDecimal bd) {
        int s = bd.scale() < 0 ? 0 : bd.scale();
        long v = bd.movePointRight(s).longValueExact();
        return new DecimalValue(v, s);
    }
}

// ---- MoneyAmount.java ----
// R-6: Currency amount with explicit scale and ISO 4217 code
// Java 8: @Value class with explicit constructor validation
@Value
public class MoneyAmount {
    long amount;
    String currency;
    int scale;

    public MoneyAmount(long amount, String currency, int scale) {
        if (currency == null || currency.length() != 3) {
            throw new IllegalArgumentException(
                "currency must be a 3-character ISO 4217 code");
        }
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
        this.amount = amount;
        this.currency = currency;
        this.scale = scale;
    }
}

// ---- Store.java ----
// R-3: Resource with UUID versionToken for optimistic concurrency
// R-4: Instant fields for timestamps (not long epoch integers)
@Value
@Builder
public class Store {
    UUID id;
    String name;
    UUID versionToken;      // R-3: required for concurrent write protection
    MoneyAmount listingFee; // R-6: MoneyAmount, not double
    Instant createdAt;      // R-4: Instant serializes to ISO 8601 UTC
    Instant updatedAt;      // R-4: Instant, not long epoch
}

// ---- ReplaceStoreRequest.java ----
// R-3: Write request requires @NotNull UUID versionToken
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Value
@Builder
public class ReplaceStoreRequest {
    @NotBlank String name;
    @NotNull UUID versionToken;  // R-3: clients must echo current token
}

// ---- Offer.java ----
// R-5: DecimalValue for precision-sensitive decimal (discount percentage)
@Value
@Builder
public class Offer {
    UUID id;
    String name;
    DecimalValue discountPercentage;  // R-5: value/scale tuple, not double
    MoneyAmount price;                // R-6: MoneyAmount, not BigDecimal or double
    Instant validUntil;               // R-4: Instant, not long
}

// ---- TracingFilter.java ----
// R-7: Propagate W3C traceparent and tracestate headers via MDC
// Uses javax.servlet.* (Java 8 / Spring Boot 2.7.x); matches guide implementation
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.slf4j.MDC;

@Component
public class TracingFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String traceparent = request.getHeader("traceparent");
        if (traceparent != null) {
            MDC.put("traceparent", traceparent);
            String tracestate = request.getHeader("tracestate");
            if (tracestate != null) {
                MDC.put("tracestate", tracestate);
            }
        }
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.remove("traceparent");
            MDC.remove("tracestate");
        }
    }
}

// ---- OfferController (localized endpoint) ----
// R-8: Accept-Language header resolved via LocaleUtils.resolve for full quality-weight support
@RestController
@RequestMapping("/offers/v1")
class OfferController {

    @GetMapping("/regions/{region_id}/offers/{offer_id}")
    public ResponseEntity<DataResponse<Offer>> getOffer(
        @PathVariable("region_id") String regionId,
        @PathVariable("offer_id") String offerId,
        @RequestHeader(
            value = "Accept-Language",
            required = false,
            defaultValue = "") String acceptLanguage,
        HttpServletRequest request) {

        Locale locale = LocaleUtils.resolve(acceptLanguage, regionId);  // full quality-weight resolution
        Offer offer = offerService.find(offerId, locale);
        return ResponseEntity.ok(DataResponse.<Offer>builder()
            .data(offer)
            .meta(Meta.ok(RequestContext.requestId(request)))
            .build());
    }
}

// ---- JacksonConfig.java ----
// R-4: Disable WRITE_DATES_AS_TIMESTAMPS so Instant serializes to ISO 8601 UTC
@Configuration
public class JacksonConfig {

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jacksonConfig() {
        return builder -> builder
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE)
            .featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .modules(new JavaTimeModule());
    }
}

// ---- StoreController.java ----
// R-1: Collection endpoint has @RequestParam @Min(1) @Max(100) int limit — never unbounded
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    // R-1: Bounded limit parameter (default 20, max 100)
    @GetMapping
    public ResponseEntity<ListResponse<Store>> listStores(
        @RequestParam(defaultValue = "20") @Min(1) @Max(100) int limit,
        @RequestParam(required = false) String cursor,
        HttpServletRequest request) {

        Page<Store> page = storeService.findAll(cursor, limit);
        CursorPagination pagination = page.hasNext()
            ? CursorPagination.builder().next(page.nextCursor()).build()
            : CursorPagination.builder().next(null).build();

        return ResponseEntity.ok(
            ListResponse.<Store>builder()
                .data(page.getItems())
                .pagination(pagination)
                .meta(Meta.ok(RequestContext.requestId(request)))
                .build());
    }
}

// ---- StoreService.java ----
// R-3: Service layer throws VersionConflictException on token mismatch
@Service
public class StoreService {

    public Store replace(String storeId, ReplaceStoreRequest request) {
        Store current = repository.findById(storeId)
            .orElseThrow(() -> new ResourceNotFoundException(storeId));

        // R-3: Reject mismatch with 409 and include current entity state
        if (!current.getVersionToken().equals(request.getVersionToken())) {
            throw new VersionConflictException(current);
        }

        Store updated = Store.builder()
            .id(current.getId())
            .name(request.getName())
            .versionToken(UUID.randomUUID())    // new version token on each successful write
            .listingFee(current.getListingFee())
            .createdAt(current.getCreatedAt())
            .updatedAt(Instant.now())
            .build();
        return repository.save(updated);
    }
}
