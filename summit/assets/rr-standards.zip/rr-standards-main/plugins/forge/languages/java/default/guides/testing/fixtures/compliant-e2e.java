// Compliant E2E test — extends TestSuite, RestAssured, real deployed service, sc1_ naming
// TestSuite loads baseUrl from e2e.properties and authToken from AUTH_TOKEN env var.
// No @SpringBootTest, no Testcontainers, no local server startup.

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.hamcrest.Matchers.*;

// SC-1 | Verifies: BR-1
// @Tag("e2e_non_production"): destructive — creates and redeems wallet points; never run in production
// @Tag("e2e_smoke"): must pass before a deployment is considered stable
@Tag("e2e_non_production")
@Tag("e2e_smoke")
class TestSC1_WalletRedeemTest extends TestSuite {

    // Unique per test run — ensures parallel-safe, reproducible synthetic data (R-4, R-8)
    private final String testRunId = UUID.randomUUID().toString();

    @Test
    void sc1_member_with_points_can_redeem_and_balance_is_updated() {
        // Step 1: Redeem points for this test run's synthetic wallet entry
        String transactionId =
            authenticatedRequest()
                .body("""
                    { "points": 50, "testRunId": "%s" }
                    """.formatted(testRunId))
            .when()
                .post("/v1/wallet/redeem")
            .then()
                .statusCode(200)
                .body("data.transactionId", notNullValue())
                .body("data.remainingBalance", greaterThanOrEqualTo(0))
                .extract().path("data.transactionId");

        // Step 2: Verify the balance reflects the redemption (complete observable journey)
        authenticatedRequest()
        .when()
            .get("/v1/wallet/balance")
        .then()
            .statusCode(200)
            .body("data.lastTransactionId", equalTo(transactionId));
    }
}
