# Java 8 Guide — REST API Contracts

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/contracts.md@1.0.0

## Overview

Shows how to satisfy the REST API Contracts standard in a Spring Boot 2.7.x service
targeting Java 8. Covers controller URI structure, path variable naming, HTTP verb
mapping, versioning via path prefixes, sunset header emission, and the Jackson naming
strategy that bridges Java camelCase to the required snake_case wire format.

## Related standard

[REST API Contracts](../../../../../../standards/api/rest/contracts.md)

## Prerequisites

- Java 8, Spring Boot 2.7.x (`spring-boot-starter-web`)
- Jackson (`com.fasterxml.jackson.core:jackson-databind`) — included in the web starter
- Springdoc OpenAPI for Spring Boot 2.x
  (`org.springdoc:springdoc-openapi-ui`) for R-9

---

## Implementation

### Base path and version prefix (R-1, R-2)

Every controller in a contract shares a base path of `/<contract_name>/v<N>`. Declare
the version prefix once on the class-level `@RequestMapping`.

```java
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import javax.validation.Valid;

@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    @GetMapping
    public ResponseEntity<ListStoresResponse> listStores() { ... }

    @GetMapping("/{store_id}")
    public ResponseEntity<GetStoreResponse> getStore(
        @PathVariable("store_id") String storeId) { ... }

    @PostMapping
    public ResponseEntity<CreateStoreResponse> createStore(
        @RequestBody @Valid CreateStoreRequest request) { ... }

    @PutMapping("/{store_id}")
    public ResponseEntity<UpdateStoreResponse> replaceStore(
        @PathVariable("store_id") String storeId,
        @RequestBody @Valid ReplaceStoreRequest request) { ... }

    @PatchMapping("/{store_id}")
    public ResponseEntity<UpdateStoreResponse> updateStore(
        @PathVariable("store_id") String storeId,
        @RequestBody @Valid UpdateStoreRequest request) { ... }

    @DeleteMapping("/{store_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteStore(
        @PathVariable("store_id") String storeId) { ... }
}
```

Do **not** pass the version as a query parameter or request header (R-2):

```java
// Wrong — version in query parameter
@GetMapping("/stores?version=v1")

// Wrong — version as header variant
@GetMapping(value = "/stores", headers = "X-API-Version=1")
```

### Path variable naming — snake_case in path, camelCase in Java (R-3, R-4)

The standard requires `snake_case` for all URI segments and path parameter names.
Spring binds `@PathVariable` by the name given in the annotation string.

```java
// Correct — path variable name is snake_case; Java param is camelCase
@GetMapping("/stores/{store_id}/conditions/{condition_id}")
public ResponseEntity<GetConditionResponse> getStoreCondition(
    @PathVariable("store_id") String storeId,
    @PathVariable("condition_id") String conditionId) { ... }

// Wrong — path variable name is camelCase
@GetMapping("/stores/{storeId}/conditions/{conditionId}")
```

Use plural `snake_case` nouns for every collection segment (R-3):

```java
// Correct
@RequestMapping("/store/v1/member_offers")

// Wrong — singular
@RequestMapping("/store/v1/member_offer")

// Wrong — camelCase
@RequestMapping("/store/v1/memberOffers")
```

### JSON field naming — Jackson snake_case mapping (R-4)

Configure Jackson globally to serialize all field names as `snake_case`.

```java
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonConfig {

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer snakeCaseNaming() {
        return builder -> builder
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }
}
```

Or in `application.yml`:

```yaml
spring:
  jackson:
    property-naming-strategy: SNAKE_CASE
```

With this in place, Lombok/POJO fields named `storeId`, `createdAt` are serialized
as `store_id`, `created_at` on the wire without per-field `@JsonProperty` annotations.

### Contract type suffixes (R-5)

The contract name (first path segment) carries the suffix.

```java
// Public contract — no suffix
@RestController
@RequestMapping("/store/v1")
public class StoreController { ... }

// Admin contract — -admin suffix
@RestController
@RequestMapping("/store-admin/v1")
public class StoreAdminController { ... }

// Internal server-to-server — -int suffix
@RestController
@RequestMapping("/store-int/v1")
public class StoreInternalController { ... }
```

### HTTP verb mapping (R-7)

| Intent | Annotation | Notes |
|--------|-----------|-------|
| Read single or collection | `@GetMapping` | |
| Create resource | `@PostMapping` | Return `201 Created` + `Location` header |
| Full idempotent replacement | `@PutMapping` | Requires `version_token` if resource supports writes |
| Partial update | `@PatchMapping` | |
| Delete | `@DeleteMapping` | Return `204 No Content` |
| Query with long parameters | `@PostMapping` | Only when GET URL length would exceed limits |

### Breaking changes — new version (R-6)

Introduce a new controller class for the new version. The original remains unchanged.

```java
// Original version — do not modify after publishing
@RestController
@RequestMapping("/store/v1/stores")
public class StoreV1Controller { ... }

// New version for breaking change
@RestController
@RequestMapping("/store/v2/stores")
public class StoreV2Controller { ... }
```

### Sunset and deprecation headers (R-8)

Use a `HandlerInterceptor` to add `Deprecation`, `Sunset`, and `Link` headers to all
responses from a deprecated version controller.

```java
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

public class V1SunsetInterceptor implements HandlerInterceptor {

    private static final String DEPRECATION = "Sun, 11 Nov 2025 23:59:59 GMT";
    private static final String SUNSET = "Wed, 11 Mar 2026 23:59:59 GMT";
    private static final String LINK = "</store/v2/stores>; rel=\"latest-version\"";

    @Override
    public boolean preHandle(
        HttpServletRequest request,
        HttpServletResponse response,
        Object handler) {

        response.setHeader("Deprecation", DEPRECATION);
        response.setHeader("Sunset", SUNSET);
        response.setHeader("Link", LINK);
        return true;
    }
}

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new V1SunsetInterceptor())
            .addPathPatterns("/store/v1/**");
    }
}
```

### Member data URI structure (R-10)

All paths accessing member-scoped resources must include
`/regions/{region_id}/members/{member_id}` before the member-scoped collection.

```java
// Public contract — member GUID
@RestController
@RequestMapping("/offers/v1/regions/{region_id}/members/{member_guid}/offers")
public class MemberOffersController {

    @GetMapping
    public ResponseEntity<ListMemberOffersResponse> listMemberOffers(
        @PathVariable("region_id") String regionId,
        @PathVariable("member_guid") String memberGuid) { ... }
}

// Internal contract — member ID (integer)
@RestController
@RequestMapping("/offers-int/v1/regions/{region_id}/members/{member_id}/offers")
public class MemberOffersInternalController {

    @GetMapping
    public ResponseEntity<ListMemberOffersResponse> listMemberOffers(
        @PathVariable("region_id") String regionId,
        @PathVariable("member_id") long memberId) { ... }
}
```

Non-compliant patterns to avoid:

```java
// Wrong — missing /regions/{region_id}/members/{member_id} prefix
@RequestMapping("/offers/v1/member_offers")

// Wrong — missing region prefix
@RequestMapping("/offers/v1/members/{member_guid}/offers")

// Wrong — integer ID on a public contract
@RequestMapping("/offers/v1/regions/{region_id}/members/{member_id}/offers")
```

### OpenAPI specification (R-9)

Add the Springdoc OpenAPI dependency for Spring Boot 2.x and annotate the main class.

```xml
<!-- pom.xml — Springdoc for Spring Boot 2.x -->
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-ui</artifactId>
    <version>1.7.0</version>
</dependency>
```

```java
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(
    info = @Info(
        title = "Store API",
        version = "1"   // major version only
    )
)
public class StoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(StoreApplication.class, args);
    }
}
```

---

## Verification

1. Start the service and inspect each controller path in Swagger UI (`/swagger-ui.html`)
   or `/v3/api-docs`. Confirm every path matches `/<contract>/v<N>/<collection>...`.
2. Grep for `@PathVariable` annotations and confirm every name string is
   `[a-z][a-z0-9]*(_[a-z0-9]+)*`.
3. Confirm the base path's first segment ends with `-admin`, `-int`, or has no suffix
   as appropriate.
4. For each `@PostMapping` that creates a resource, confirm the handler returns
   `ResponseEntity` with status `201` and a `Location` header.
5. For every path that accesses member-scoped data, confirm
   `/regions/{region_id}/members/{...}` appears before the member collection.
6. Run `mvn checkstyle:check` — zero violations required.
