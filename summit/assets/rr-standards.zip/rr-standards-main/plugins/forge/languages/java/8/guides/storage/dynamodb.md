# Java 8 Guide — DynamoDB

Guide: 1.0.0 | Implements: standards/storage/dynamodb.md@1.0.0

## Overview

Shows how to satisfy the DynamoDB standard in Java 8 using AWS SDK v2's
`DynamoDbEnhancedClient`. AWS SDK v2 supports Java 8 as its minimum runtime.
All patterns are identical to the Java 21 guide except that Lombok `@Data` classes
replace records for entity beans, and explicit type declarations replace `var`.

## Related standard

[DynamoDB Standard](../../../../../../../standards/storage/dynamodb.md)

## Prerequisites

- AWS SDK v2: `software.amazon.awssdk:dynamodb-enhanced`
- Lombok for entity classes

Maven dependency:

```xml
<dependency>
    <groupId>software.amazon.awssdk</groupId>
    <artifactId>dynamodb-enhanced</artifactId>
</dependency>
```

---

## Implementation

### Client configuration

```java
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;

@Configuration
public class DynamoDbConfig {

    @Bean
    public DynamoDbClient dynamoDbClient(
        @Value("${aws.region}") String region) {

        return DynamoDbClient.builder()
            .region(Region.of(region))
            .build();
    }

    @Bean
    public DynamoDbEnhancedClient dynamoDbEnhancedClient(
        DynamoDbClient client) {

        return DynamoDbEnhancedClient.builder()
            .dynamoDbClient(client)
            .build();
    }
}
```

### Entity mapping — `@DynamoDbBean` with Lombok

In Java 8, DynamoDB enhanced client requires getter/setter-based JavaBean conventions.
Use Lombok `@Data` (not `@Value`) so Lombok generates setters — the enhanced client
needs them.

```java
import lombok.Data;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbVersionAttribute;

@DynamoDbBean
@Data
public class UserProfileItem {

    private String pk;            // "USER#<userId>"
    private String sk;            // "PROFILE"
    private String entityType;
    private Integer schemaVersion;
    private String userId;
    private String email;
    private String firstName;
    private String createdAt;     // ISO 8601 UTC string
    private String updatedAt;
    private Long version;         // optimistic concurrency

    @DynamoDbPartitionKey
    @DynamoDbAttribute("pk")
    public String getPk() { return pk; }

    @DynamoDbSortKey
    @DynamoDbAttribute("sk")
    public String getSk() { return sk; }

    @DynamoDbAttribute("entity_type")
    public String getEntityType() { return entityType; }

    @DynamoDbAttribute("schema_version")
    public Integer getSchemaVersion() { return schemaVersion; }

    @DynamoDbAttribute("user_id")
    public String getUserId() { return userId; }

    @DynamoDbAttribute("email")
    public String getEmail() { return email; }

    @DynamoDbAttribute("first_name")
    public String getFirstName() { return firstName; }

    @DynamoDbAttribute("created_at")
    public String getCreatedAt() { return createdAt; }

    @DynamoDbAttribute("updated_at")
    public String getUpdatedAt() { return updatedAt; }

    @DynamoDbVersionAttribute
    @DynamoDbAttribute("version")
    public Long getVersion() { return version; }
}
```

### Single-table key constants

```java
public final class TableKeys {

    private TableKeys() {}

    public static String userPk(String userId) {
        return "USER#" + userId;
    }

    public static String orderPk(String orderId) {
        return "ORDER#" + orderId;
    }

    public static final String PROFILE_SK = "PROFILE";

    public static String orderSk(String date, String sequence) {
        return "ORDER#" + date + "#" + sequence;
    }
}
```

### Repository — CRUD operations

```java
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class UserProfileRepository {

    private static final String TABLE_NAME = "prod_users_profiles";

    private final DynamoDbTable<UserProfileItem> table;

    public UserProfileRepository(DynamoDbEnhancedClient client) {
        this.table = client.table(TABLE_NAME,
            TableSchema.fromBean(UserProfileItem.class));
    }

    public Optional<UserProfileItem> findByUserId(String userId) {
        Key key = Key.builder()
            .partitionValue(TableKeys.userPk(userId))
            .sortValue(TableKeys.PROFILE_SK)
            .build();
        return Optional.ofNullable(table.getItem(key));
    }

    public void save(UserProfileItem item) {
        table.putItem(item);
    }

    public void update(UserProfileItem item) {
        table.updateItem(item);
    }

    public void delete(String userId) {
        Key key = Key.builder()
            .partitionValue(TableKeys.userPk(userId))
            .sortValue(TableKeys.PROFILE_SK)
            .build();
        table.deleteItem(key);
    }

    public List<UserProfileItem> findOrdersForUser(String userId) {
        QueryConditional queryConditional = QueryConditional.keyEqualTo(
            Key.builder()
                .partitionValue(TableKeys.userPk(userId))
                .build());
        return table.query(queryConditional)
            .items()
            .stream()
            .collect(Collectors.toList());
    }
}
```

### Optimistic concurrency

Map `ConditionalCheckFailedException` to the application's `VersionConflictException`:

```java
import software.amazon.awssdk.services.dynamodb.model.ConditionalCheckFailedException;

public void updateProfile(UserProfileItem item) {
    try {
        table.updateItem(item);
    } catch (ConditionalCheckFailedException ex) {
        UserProfileItem current = findByUserId(item.getUserId())
            .orElseThrow(() -> new ResourceNotFoundException(item.getUserId()));
        throw new VersionConflictException(current);
    }
}
```

### Pagination with `lastEvaluatedKey`

```java
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import java.util.Map;

public PageResult<UserProfileItem> listOrders(
    String userId,
    int limit,
    Map<String, AttributeValue> cursor) {

    QueryEnhancedRequest queryRequest = QueryEnhancedRequest.builder()
        .queryConditional(QueryConditional.keyEqualTo(
            Key.builder()
                .partitionValue(TableKeys.userPk(userId))
                .build()))
        .limit(limit)
        .exclusiveStartKey(cursor)
        .build();

    Page<UserProfileItem> page = table.query(queryRequest)
        .stream()
        .findFirst()
        .orElseThrow();

    return new PageResult<>(
        page.items().stream().collect(Collectors.toList()),
        page.lastEvaluatedKey());
}
```

### Timestamps — ISO 8601 UTC strings

```java
item.setCreatedAt(Instant.now().toString());  // "2024-06-15T09:30:00Z"
item.setUpdatedAt(Instant.now().toString());
```

### DynamoDB Local in integration tests

```java
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import java.net.URI;

@Testcontainers
class UserProfileRepositoryIntegrationTest {

    @Container
    static GenericContainer<?> dynamoDbLocal =
        new GenericContainer<>("amazon/dynamodb-local:2.3.0")
            .withExposedPorts(8000)
            .withCommand("-jar DynamoDBLocal.jar -inMemory -sharedDb");

    private UserProfileRepository repository;

    @BeforeEach
    void setup() {
        String endpoint = "http://localhost:"
            + dynamoDbLocal.getMappedPort(8000);

        DynamoDbClient rawClient = DynamoDbClient.builder()
            .endpointOverride(URI.create(endpoint))
            .region(Region.US_EAST_1)
            .credentialsProvider(StaticCredentialsProvider.create(
                AwsBasicCredentials.create("fakeKey", "fakeSecret")))
            .build();

        DynamoDbEnhancedClient client =
            DynamoDbEnhancedClient.builder()
                .dynamoDbClient(rawClient)
                .build();

        DynamoDbTable<UserProfileItem> table = client.table(
            "test_users_profiles",
            TableSchema.fromBean(UserProfileItem.class));
        table.createTable(CreateTableEnhancedRequest.builder()
            .provisionedThroughput(
                ProvisionedThroughput.builder()
                    .readCapacityUnits(5L)
                    .writeCapacityUnits(5L)
                    .build())
            .build());

        repository = new UserProfileRepository(client);
    }

    @Test
    void givenSavedUser_whenFindById_thenReturnsUser() {
        UserProfileItem item = new UserProfileItem();
        item.setPk("USER#test-1");
        item.setSk("PROFILE");
        item.setEntityType("USER_PROFILE");
        item.setSchemaVersion(1);
        item.setUserId("test-1");
        item.setEmail("user@example.com");
        item.setCreatedAt(Instant.now().toString());

        repository.save(item);
        Optional<UserProfileItem> found = repository.findByUserId("test-1");

        assertThat(found).isPresent();
        assertThat(found.get().getEmail()).isEqualTo("user@example.com");
    }
}
```

---

## Verification

1. Grep for `table.scan()` in production source — no calls allowed in the request
   path; only in background migration jobs.
2. Inspect every `@DynamoDbBean` class and confirm a `@DynamoDbVersionAttribute`
   field is present on entities that support writes.
3. Confirm every `@DynamoDbAttribute` annotation uses `snake_case`.
4. Confirm timestamps are stored as ISO 8601 strings, not `long` epoch values.
5. Grep for `var ` in source files — must be zero (Java 8 does not support `var`).
6. Run integration tests against DynamoDB Local — all must pass.
7. Run `mvn checkstyle:check` — zero violations required.
