// ---- PublicContractSecurityConfig.java ----
// R-1: EbtokenAuthFilter on member-data endpoints; accepts Bearer header OR euid cookie
// Returns 401 on missing/invalid token
@Configuration
@EnableWebSecurity
public class PublicContractSecurityConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain memberDataFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .securityMatcher("/store/v1/**", "/offers/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(
                new EbtokenAuthFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                // Non-member data endpoints — no auth required
                .requestMatchers(HttpMethod.GET, "/store/v1/stores")
                    .permitAll()
                // Member-scoped paths require authentication (R-1)
                .requestMatchers("/store/v1/regions/*/members/**")
                    .authenticated()
                .requestMatchers("/offers/v1/regions/*/members/**")
                    .authenticated()
                .anyRequest().permitAll())
            .build();
    }
}

// ---- EbtokenAuthFilter.java ----
// R-1: Accepts Bearer header OR euid cookie; 401 on invalid token
public class EbtokenAuthFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenAuthFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = extractToken(request);
        if (token != null) {
            try {
                MemberClaims claims = validator.validate(token);
                var auth = new MemberAuthentication(claims);
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch (InvalidTokenException ex) {
                SecurityContextHolder.clearContext();
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                    "Invalid or expired ebtoken");
                return;
            }
        }
        chain.doFilter(request, response);
    }

    private String extractToken(HttpServletRequest request) {
        // 1. Bearer header (Authorization: Bearer <ebtoken>)
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        // 2. euid cookie (for browser clients — R-1 alternative)
        if (request.getCookies() != null) {
            for (Cookie cookie : request.getCookies()) {
                if ("euid".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}

// ---- AdminContractSecurityConfig.java ----
// R-2: EbtokenRoleFilter on -admin contract; validates JWT + required roles; 403 on missing role
@Configuration
@EnableWebSecurity
public class AdminContractSecurityConfig {

    @Bean
    @Order(2)
    public SecurityFilterChain adminFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .securityMatcher("/store-admin/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(
                new EbtokenRoleFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                .anyRequest().hasAuthority("ROLE_store_admin"))
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint(
                    (req, res, e) -> res.sendError(HttpServletResponse.SC_UNAUTHORIZED))
                .accessDeniedHandler(
                    (req, res, e) -> res.sendError(HttpServletResponse.SC_FORBIDDEN)))
            .build();
    }
}

// ---- EbtokenRoleFilter.java ----
// R-2: Validates JWT + required roles; roles extracted as ROLE_<role> granted authorities
public class EbtokenRoleFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenRoleFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Bearer token required");
            return;
        }
        try {
            AdminClaims claims = validator.validateAdmin(authHeader.substring(7));
            // Roles extracted from JWT claims as ROLE_<role> granted authorities (R-2)
            var authorities = claims.roles().stream()
                .map(r -> new SimpleGrantedAuthority("ROLE_" + r))
                .toList();
            var auth = new UsernamePasswordAuthenticationToken(
                claims.operatorId(), null, authorities);
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid or expired admin token");
            return;
        }
        chain.doFilter(request, response);
    }
}

// ---- InternalContractSecurityConfig.java ----
// R-3: ServerToServerAuthFilter on sensitive -int endpoints; 401 on missing s2s token
@Configuration
@EnableWebSecurity
public class InternalContractSecurityConfig {

    @Bean
    @Order(3)
    public SecurityFilterChain internalFilterChain(
        HttpSecurity http,
        ServerToServerTokenValidator s2sValidator) throws Exception {

        return http
            .securityMatcher("/wallet-int/v1/**", "/pii-int/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(
                new ServerToServerAuthFilter(s2sValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                .anyRequest().authenticated())
            .build();
    }
}

// ---- ServerToServerAuthFilter.java ----
// R-3: Validates server-to-server token; 401 on missing or invalid token
public class ServerToServerAuthFilter extends OncePerRequestFilter {

    private final ServerToServerTokenValidator validator;

    public ServerToServerAuthFilter(ServerToServerTokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = request.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Server-to-server token required");
            return;
        }
        try {
            ServiceIdentity identity = validator.validate(token.substring(7));
            var auth = new UsernamePasswordAuthenticationToken(
                identity.serviceId(), null,
                List.of(new SimpleGrantedAuthority("ROLE_service")));
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid server-to-server token");
            return;
        }
        chain.doFilter(request, response);
    }
}
