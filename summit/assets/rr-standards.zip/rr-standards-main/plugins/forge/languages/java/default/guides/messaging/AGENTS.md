# Messaging — Java Guides

## Directory purpose

Java messaging implementation guides using Spring Kafka. Each guide covers one
concern — producing or consuming — and shows complete, runnable Spring Kafka
configurations. Load the guide that matches the messaging role of the service
being authored or reviewed.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `kafka.md` | Spring Kafka `KafkaTemplate` producer; `@KafkaListener` consumer; serialization; error handling; consumer group configuration | Any Kafka producer or consumer code is being authored or reviewed |

## Navigation

- [Java default root](../../AGENTS.md)
- [Messaging standards](../../../../../../../standards/messaging/)
