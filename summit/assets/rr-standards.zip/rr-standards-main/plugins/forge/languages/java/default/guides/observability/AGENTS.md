# Observability — Java Guides

## Directory purpose

Java observability implementation guides. Each guide covers one concern — structured
logging, metrics, or tracing. Load the relevant guide when generating or reviewing
observability instrumentation in a Java service.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `logging.md` | SLF4J + Logback structured JSON logging; MDC correlation fields; log levels; PII exclusion rules | Any logging code is being authored or reviewed |

## Navigation

- [Java default root](../../AGENTS.md)
- [Observability standards](../../../../../../../standards/observability/)
