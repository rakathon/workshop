// Compliant TestSuite — attaches ApiCallLoggingFilter on both request helpers.
// All HTTP calls made via authenticatedRequest() or unauthenticatedRequest()
// are automatically logged into JUnit XML <system-out> via SLF4J.

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public abstract class TestSuite {

    protected static String baseUrl;
    protected static String authToken;

    @BeforeAll
    static void setup() throws IOException {
        String env = System.getenv("ENVIRONMENT_TO_TEST");
        if (env == null || env.isBlank()) {
            env = "local";
        }

        Properties props = new Properties();
        try (InputStream in = TestSuite.class.getClassLoader()
                .getResourceAsStream("e2e.properties")) {
            if (in == null) {
                Assumptions.abort("E2E tests skipped — e2e.properties not found on classpath");
                return;
            }
            props.load(in);
        }

        baseUrl = props.getProperty("base.url." + env);
        if (baseUrl == null || baseUrl.isBlank()) {
            Assumptions.abort("E2E tests skipped — no base.url." + env + " configured in e2e.properties");
            return;
        }

        authToken = System.getenv("AUTH_TOKEN");

        RestAssured.baseURI = baseUrl;
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
    }

    protected static RequestSpecification authenticatedRequest() {
        return given()
            .filter(new ApiCallLoggingFilter())
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .header("Authorization", "Bearer " + authToken);
    }

    protected static RequestSpecification unauthenticatedRequest() {
        return given()
            .filter(new ApiCallLoggingFilter())
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON);
    }
}
