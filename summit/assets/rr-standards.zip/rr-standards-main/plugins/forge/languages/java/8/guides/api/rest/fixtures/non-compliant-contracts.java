// This controller violates several rules from the REST API Contracts standard.
// It looks like plausible production Java 8 code but contains multiple org-specific violations.

// ---- NO JacksonConfig ----
// R-4 VIOLATION: No global snake_case mapping. Response fields serialized in camelCase
// because there is no Jackson2ObjectMapperBuilderCustomizer bean configuring SNAKE_CASE.

// ---- StoreDto.java ----
// R-4 VIOLATION: camelCase field names will serialize as camelCase (storeId, storeName)
// instead of the required snake_case (store_id, store_name)
public class StoreDto {
    private UUID storeId;       // serializes as "storeId" — should be "store_id"
    private String storeName;   // serializes as "storeName" — should be "store_name"
    private Instant createdAt;  // serializes as "createdAt" — should be "created_at"
}

// ---- StoreController.java ----
// R-3, R-4 VIOLATION: path variable uses camelCase name in annotation
// R-7 VIOLATION: using @GetMapping for a resource creation operation
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    // R-3, R-4 VIOLATION: {storeId} is camelCase — should be {store_id}
    @GetMapping("/{storeId}")
    public ResponseEntity<StoreDto> getStore(
        @PathVariable("storeId") String storeId) { return null; }

    // R-7 VIOLATION: GET used for resource creation — should be POST
    @GetMapping("/create")
    public ResponseEntity<StoreDto> createStore(@RequestParam String name) { return null; }

    // R-3, R-4 VIOLATION: sub-collection segment uses camelCase
    @GetMapping("/{storeId}/storeConditions/{conditionId}")
    public ResponseEntity<ConditionDto> getCondition(
        @PathVariable("storeId") String storeId,
        @PathVariable("conditionId") String conditionId) { return null; }
}

// ---- MemberOffersController.java ----
// R-10 VIOLATION: Public contract (no -int suffix) uses member_id (integer type)
// instead of member_guid (String/UUID). On public contracts, member_guid must be used.
// R-1 VIOLATION: Member data URI missing /regions/{region_id}/ prefix
@RestController
@RequestMapping("/offers/v1/members/{member_id}/offers")  // missing /regions/{region_id}/
public class MemberOffersController {
    @GetMapping
    public ResponseEntity<OffersDto> listMemberOffers(
        @PathVariable("member_id") long memberId) { return null; }  // integer on public — wrong
}

// ---- StoreAdminController.java ----
// R-5 VIOLATION: Admin controller uses "-admin" in the class name but the @RequestMapping
// path is missing the required -admin suffix on the contract name
@RestController
@RequestMapping("/store/v1/admin/stores")  // should be /store-admin/v1/stores
public class StoreAdminController {
    @GetMapping
    public ResponseEntity<ListStoresResponse> listAllStores() { return null; }
}

// ---- StoreApplication.java ----
// R-9 VIOLATION: info.version uses full semantic version string instead of major version only
@SpringBootApplication
@OpenAPIDefinition(
    info = @Info(title = "Store API", version = "1.2.3")  // should be "1" only
)
public class StoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(StoreApplication.class, args);
    }
}
