# Java 8 Guide — REST API Security

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/security.md@1.0.0

## Overview

Shows how to satisfy the REST API Security standard in a Spring Boot 2.7.x service
targeting Java 8. Covers Spring Security 5.x `SecurityFilterChain` beans for JWT
bearer token validation, euid cookie authentication, and server-to-server token
validation. Uses `javax.servlet.*` throughout.

## Related standard

[REST API Security](../../../../../../standards/api/rest/security.md)

## Prerequisites

- Spring Boot 2.7.x with `spring-boot-starter-security`
- `io.jsonwebtoken:jjwt-api` and `jjwt-impl` (or the company JWT validation library)
- Familiarity with Spring Security 5.x `SecurityFilterChain` and `OncePerRequestFilter`

---

## Implementation

### Public endpoints with member data — ebtoken and euid cookie (R-1)

Configure a `SecurityFilterChain` bean for each contract type. Spring Security 5.7.x
supports the `SecurityFilterChain` bean approach (same pattern as Spring Security 6.x
but with `javax.*` imports).

```java
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;

@Configuration
@EnableWebSecurity
public class PublicContractSecurityConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain memberDataFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .requestMatcher(new AntPathRequestMatcher("/offers/v1/**"))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .addFilterBefore(
                new EbtokenAuthFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeRequests()
                .antMatchers(HttpMethod.GET, "/store/v1/stores").permitAll()
                .antMatchers("/offers/v1/regions/*/members/**").authenticated()
                .anyRequest().permitAll()
                .and()
            .build();
    }
}
```

The `EbtokenAuthFilter` handles both Bearer header and `euid` cookie:

```java
public class EbtokenAuthFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenAuthFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = extractToken(request);
        if (token != null) {
            try {
                MemberClaims claims = validator.validate(token);
                EbtokenAuthentication auth = new EbtokenAuthentication(claims);
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch (InvalidTokenException ex) {
                SecurityContextHolder.clearContext();
                response.sendError(
                    HttpServletResponse.SC_UNAUTHORIZED,
                    "Invalid or expired token");
                return;
            }
        }
        chain.doFilter(request, response);
    }

    private String extractToken(HttpServletRequest request) {
        // 1. Bearer header
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        // 2. euid cookie (browser clients)
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("euid".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}
```

### Admin contract endpoints — ebtoken with role validation (R-2)

Configure a dedicated `SecurityFilterChain` for admin contracts. Extract roles from
JWT claims and set them as granted authorities so Spring Security's `hasAuthority`
check works.

```java
@Configuration
@EnableWebSecurity
public class AdminContractSecurityConfig {

    @Bean
    @Order(2)
    public SecurityFilterChain adminFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .requestMatcher(new AntPathRequestMatcher("/store-admin/v1/**"))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .addFilterBefore(
                new EbtokenRoleFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeRequests()
                .anyRequest().hasAuthority("ROLE_store_admin")
                .and()
            .exceptionHandling()
                .authenticationEntryPoint(
                    (req, res, ex) ->
                        res.sendError(HttpServletResponse.SC_UNAUTHORIZED))
                .accessDeniedHandler(
                    (req, res, ex) ->
                        res.sendError(HttpServletResponse.SC_FORBIDDEN))
                .and()
            .build();
    }
}
```

```java
public class EbtokenRoleFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenRoleFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.sendError(
                HttpServletResponse.SC_UNAUTHORIZED, "Bearer token required");
            return;
        }
        try {
            AdminClaims claims =
                validator.validateAdmin(authHeader.substring(7));
            List<SimpleGrantedAuthority> authorities = new ArrayList<>();
            for (String role : claims.getRoles()) {
                authorities.add(new SimpleGrantedAuthority("ROLE_" + role));
            }
            UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(
                    claims.getOperatorId(), null, authorities);
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(
                HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid or expired admin token");
            return;
        }
        chain.doFilter(request, response);
    }
}
```

### Sensitive internal endpoints — server-to-server auth (R-3)

Configure a dedicated filter chain for sensitive `-int` operations.

```java
@Configuration
@EnableWebSecurity
public class InternalContractSecurityConfig {

    @Bean
    @Order(3)
    public SecurityFilterChain internalFilterChain(
        HttpSecurity http,
        ServerToServerTokenValidator s2sValidator) throws Exception {

        return http
            .requestMatcher(
                new OrRequestMatcher(
                    new AntPathRequestMatcher("/wallet-int/v1/**"),
                    new AntPathRequestMatcher("/pii-int/v1/**")))
            .csrf().disable()
            .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .addFilterBefore(
                new ServerToServerAuthFilter(s2sValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeRequests()
                .anyRequest().authenticated()
                .and()
            .build();
    }
}
```

```java
public class ServerToServerAuthFilter extends OncePerRequestFilter {

    private final ServerToServerTokenValidator validator;

    public ServerToServerAuthFilter(ServerToServerTokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = request.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            response.sendError(
                HttpServletResponse.SC_UNAUTHORIZED,
                "Server-to-server token required");
            return;
        }
        try {
            ServiceIdentity identity =
                validator.validate(token.substring(7));
            List<SimpleGrantedAuthority> authorities =
                Collections.singletonList(
                    new SimpleGrantedAuthority("ROLE_service"));
            UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(
                    identity.getServiceId(), null, authorities);
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(
                HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid server-to-server token");
            return;
        }
        chain.doFilter(request, response);
    }
}
```

---

## Verification

1. Call a member-data endpoint without an `Authorization` header or `euid` cookie —
   confirm `401 Unauthorized`.
2. Call the same endpoint with a valid ebtoken Bearer header — confirm `200 OK`.
3. Call an `-admin` endpoint with a token that lacks the required role — confirm
   `403 Forbidden`.
4. Call a sensitive `-int` endpoint without a server-to-server token — confirm
   `401 Unauthorized`.
5. Confirm all `requestMatcher` patterns cover every path in each contract with no
   gaps that would fall through to the wrong filter chain.
6. Run `mvn checkstyle:check` — zero violations required.
