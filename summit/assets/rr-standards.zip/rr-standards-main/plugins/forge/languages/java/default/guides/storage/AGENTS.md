# Storage — Java Guides

## Directory purpose

Java data-access implementation guides for the storage backends used in the Rewards
platform. Each guide shows AWS SDK v2 patterns for the target store. Load the guide
that matches the storage technology of the service you are authoring or reviewing.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `dynamodb.md` | AWS SDK v2 `DynamoDbEnhancedClient`; `@DynamoDbBean` entity mapping; single-table key design; optimistic concurrency; pagination | Any DynamoDB read/write code is being authored or reviewed |

## Navigation

- [Java default root](../../AGENTS.md)
- [DynamoDB standard](../../../../../../../standards/storage/dynamodb.md)
