// Non-compliant Kafka config — no idempotence, no DLT, no duplicate handling
@Configuration
public class KafkaProducerConfigBad {
    @Bean
    public ProducerFactory<String, Object> producerFactory(KafkaProperties props) {
        Map<String, Object> config = new HashMap<>(props.buildProducerProperties(null));
        // WRONG: no ENABLE_IDEMPOTENCE_CONFIG = true
        // WRONG: no ACKS_CONFIG = "all"
        // WRONG: default retries (0) — messages dropped on transient failures
        return new DefaultKafkaProducerFactory<>(config);
    }
}

@Configuration
public class KafkaConsumerConfigBad {
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> factory(
        ConsumerFactory<String, Object> cf) {
        var factory = new ConcurrentKafkaListenerContainerFactory<String, Object>();
        factory.setConsumerFactory(cf);
        // WRONG: no error handler, no DLT — failed messages are lost
        return factory;
    }
}

// Non-idempotent consumer — processes duplicates
@Component
public class OrderEventConsumerBad {
    @KafkaListener(topics = "order-events", groupId = "rewards-store")
    public void handle(@Payload OrderCreatedEvent event) {
        // WRONG: no deduplication — if message redelivered, processes twice
        projectionService.apply(event);
    }
    // WRONG: no DLT consumer — failed messages go unmonitored
}
