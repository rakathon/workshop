// Non-compliant Java 8 DynamoDB entity — camelCase attrs, epoch timestamp, no version, scan
@DynamoDbBean
@Data
public class OrderItemBad {
    private String pk;
    private String orderId;
    private Long createdAtEpoch;  // WRONG: epoch long — should be ISO 8601 string
    // WRONG: no version field — no optimistic concurrency protection

    @DynamoDbPartitionKey
    @DynamoDbAttribute("pk")
    public String getPk() { return pk; }

    @DynamoDbAttribute("orderId")    // WRONG: camelCase — should be "order_id"
    public String getOrderId() { return orderId; }

    @DynamoDbAttribute("createdAtEpoch")  // WRONG: camelCase AND epoch type
    public Long getCreatedAtEpoch() { return createdAtEpoch; }
    // WRONG: missing @DynamoDbVersionAttribute
}

// Repository using Scan in request path — critical violation
@Repository
public class OrderRepositoryBad {
    public List<OrderItemBad> findAll() {
        // CRITICAL VIOLATION: Scan reads entire table — prohibited in request path
        // Java 8: .collect(Collectors.toList())
        return table.scan().items().stream().collect(Collectors.toList());
    }

    public void update(OrderItemBad item) {
        // WRONG: putItem with no version check — concurrent writes silently overwrite
        table.putItem(item);
    }
}
