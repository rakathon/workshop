# Storage — Java 8 Guides

## Directory purpose

Java 8 data-access implementation guides. AWS SDK v2 supports Java 8 natively;
these guides use the same `DynamoDbEnhancedClient` API as the Java 21 guides but
replace records with Lombok classes and remove `var`.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `dynamodb.md` | AWS SDK v2 `DynamoDbEnhancedClient`; `@DynamoDbBean` entity mapping; single-table key design; optimistic concurrency; pagination | Any DynamoDB read/write code is being authored or reviewed |

## Navigation

- [Java 8 root](../../AGENTS.md)
- [DynamoDB standard](../../../../../../../standards/storage/dynamodb.md)
