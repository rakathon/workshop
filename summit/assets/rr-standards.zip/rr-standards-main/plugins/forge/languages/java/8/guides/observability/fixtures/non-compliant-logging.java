// Non-compliant logging — string concatenation, PII, no MDC
// Violations are framework-agnostic; identical to Java 21 non-compliant version
@Service
public class AuthService {
    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    public void login(String email, String password, String token) {
        // WRONG: string concatenation in log statement (SonarQube S2629)
        log.info("Login attempt for email: " + email);

        // WRONG: logging PII — email and raw password
        log.debug("Authenticating user email=" + email + " password=" + password);

        // WRONG: logging raw JWT/auth token — security violation
        log.debug("Using auth token: " + token);

        // WRONG: exception swallowed silently — no log
        try {
            authProvider.authenticate(email, password);
        } catch (AuthException ex) {
            // silent catch — no logging, no rethrow
        }
    }
    // WRONG: no MDC setup — no request_id or traceparent correlation in any log line
}
