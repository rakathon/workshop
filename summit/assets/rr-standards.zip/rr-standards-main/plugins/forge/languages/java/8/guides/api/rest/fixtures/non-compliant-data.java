// This code violates several rules from the REST API Data standard.
// It looks like plausible production Java 8 but contains multiple violations.

// ---- Store.java ----
// R-3 VIOLATION: Resource has no versionToken field
// R-4 VIOLATION: Timestamps stored as long epoch integers instead of Instant
@Value
@Builder
public class Store {
    UUID id;
    String name;
    // R-3 VIOLATION: No versionToken field — concurrent writes have no conflict detection
    long createdAt;     // R-4 VIOLATION: epoch long instead of Instant / ISO 8601
    long updatedAt;     // R-4 VIOLATION: epoch long instead of Instant / ISO 8601
}

// ---- ReplaceStoreRequest.java ----
// R-3 VIOLATION: Write request accepts any update without concurrency check
import javax.validation.constraints.NotBlank;

@Value
@Builder
public class ReplaceStoreRequest {
    @NotBlank String name;
    // R-3 VIOLATION: No versionToken field — clients can overwrite each other's changes
}

// ---- Offer.java ----
// R-5 VIOLATION: Discount percentage field is double (IEEE 754 float — precision loss)
// R-6 VIOLATION: Price field is BigDecimal with no value/scale structure
@Value
@Builder
public class Offer {
    UUID id;
    String name;
    double discountPercentage;  // R-5 VIOLATION: should be DecimalValue(value, scale)
    BigDecimal price;           // R-6 VIOLATION: should be MoneyAmount(amount, currency, scale)
    long validUntil;            // R-4 VIOLATION: epoch long instead of Instant
}

// ---- Wallet.java ----
// R-6 VIOLATION: Balance stored as double instead of MoneyAmount
@Value
@Builder
public class Wallet {
    UUID memberId;
    double balance;     // R-6 VIOLATION: float precision loss; no currency or scale
    String currency;    // R-6 VIOLATION: currency separate, not structured MoneyAmount
}

// ---- StoreController.java ----
// R-1 VIOLATION: Collection endpoint has no limit parameter — returns unbounded list
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    // R-1 VIOLATION: No limit or size parameter; returns all records unconditionally
    @GetMapping
    public ResponseEntity<List<Store>> listStores() {
        // R-1 VIOLATION: No pagination — unbounded list can return thousands of records
        List<Store> allStores = storeService.findAll();
        return ResponseEntity.ok(allStores);
    }

    // R-3 VIOLATION: Service method accepts write with no version_token check
    @PutMapping("/{store_id}")
    public ResponseEntity<Store> replaceStore(
        @PathVariable("store_id") String storeId,
        @RequestBody ReplaceStoreRequest body) {
        // R-3 VIOLATION: No concurrency check — concurrent updates silently overwrite each other
        Store updated = storeService.replaceWithoutConcurrencyCheck(storeId, body);
        return ResponseEntity.ok(updated);
    }
}

// ---- StoreService.java ----
// R-3 VIOLATION: No VersionConflictException thrown — no optimistic locking
@Service
public class StoreService {

    // R-1 VIOLATION: findAll() with no limit — returns entire table
    public List<Store> findAll() {
        return repository.findAll();
    }

    // R-3 VIOLATION: Replaces store without checking version token
    public Store replaceWithoutConcurrencyCheck(String storeId, ReplaceStoreRequest request) {
        Store current = repository.findById(storeId)
            .orElseThrow(() -> new ResourceNotFoundException(storeId));

        // R-3 VIOLATION: No version token comparison — last write always wins
        Store updated = Store.builder()
            .id(current.getId())
            .name(request.getName())
            .createdAt(System.currentTimeMillis())  // R-4 VIOLATION: epoch millis not Instant
            .updatedAt(System.currentTimeMillis())  // R-4 VIOLATION: epoch millis not Instant
            .build();
        return repository.save(updated);
    }
}
