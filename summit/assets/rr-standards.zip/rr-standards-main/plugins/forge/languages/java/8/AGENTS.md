# Java 8 Language Guides

## Directory purpose

Java 8 implementation guides for rr-standards. These guides are fully self-contained
for services that target Java 8 and Spring Boot 2.7.x. All code examples use Java 8
idioms: Lombok `@Value`/`@Builder` in place of records, explicit type declarations
instead of `var`, `javax.*` instead of `jakarta.*`, and Spring Security 5.x filter
chain patterns. Do not cross-reference `default/` when working on a Java 8 service —
everything needed is in this directory.

## File index

| Path | Purpose | When to reference |
|------|---------|-------------------|
| `guides/api/rest/` | Spring MVC implementations of the four REST API sub-standards (Spring Boot 2.7.x) | Any Java 8 REST API is being authored or reviewed |
| `guides/testing/unit.md` | JUnit 5 + Mockito + AssertJ unit testing patterns for Java 8 | Writing or reviewing unit tests |
| `guides/testing/integration.md` | Spring Boot 2.x Test + Testcontainers integration patterns | Writing or reviewing integration tests |
| `guides/testing/e2e.md` | End-to-end test patterns with RestAssured against a Spring Boot 2.x service | Writing or reviewing end-to-end test suites |
| `guides/storage/dynamodb.md` | AWS SDK v2 DynamoDB enhanced client patterns (Java 8 compatible) | Any DynamoDB read/write code is being authored or reviewed |
| `guides/messaging/kafka.md` | Spring Kafka 2.x producer and consumer patterns | Any Kafka producer or consumer code is being authored or reviewed |
| `guides/observability/logging.md` | SLF4J + Logback structured JSON logging for Java 8 services | Any logging code is being authored or reviewed |

## Linter

**Checkstyle 10.x** with the Google Java Style Guide configuration
(`config/checkstyle/google_checks.xml`). All generated Java code must pass
`mvn checkstyle:check` with zero violations before review.

Key style rules enforced:
- 2-space block indentation
- 100-character line limit
- No wildcard imports
- K&R brace style (opening brace on same line)
- Javadoc required on all `public` and `protected` declarations

All new services should also target the company SonarQube quality profile
`SG-JAVA-CUSTOM-PROFILE-07-2025`. See the
[SonarQube Java Specific Rules](https://rakutenrewards.atlassian.net/wiki/spaces/GUILDS/pages/43231117492/SonarQube+Java+Specific+Rules)
Confluence page for the custom rule thresholds in effect.

## Key Java 8 vs Java 21 differences applied throughout these guides

| Concept | Java 21 (default/) | Java 8 (this directory) |
|---------|-------------------|------------------------|
| Immutable DTOs | `record Foo(String a, int b) {}` | Lombok `@Value @Builder class Foo` |
| Type inference | `var items = new ArrayList<>()` | `List<String> items = new ArrayList<>()` |
| Multi-line strings | `"""..."""` (text block) | `String.format(...)` or `+` concatenation |
| Servlet API | `jakarta.servlet.*` | `javax.servlet.*` |
| Validation API | `jakarta.validation.*` | `javax.validation.*` |
| Spring Boot | 3.x | 2.7.x |
| Spring Security | 6.x | 5.7.x |
| Immutable lists | `List.of(...)` | `Arrays.asList(...)` or `Collections.unmodifiableList(...)` |

## Navigation

- [Java language root](../AGENTS.md) — version directory selection
- [Java default (Java 21) guides](../default/AGENTS.md)
- [Languages root](../../AGENTS.md)
