# Messaging — Java 8 Guides

## Directory purpose

Java 8 messaging implementation guides using Spring Kafka 2.x (included in
Spring Boot 2.7.x). The API surface is identical to Spring Kafka 3.x used in
the Java 21 guides; the differences are Lombok classes instead of records and
`javax.*` imports.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `kafka.md` | Spring Kafka 2.x `KafkaTemplate` producer; `@KafkaListener` consumer; serialization; error handling; consumer group configuration | Any Kafka producer or consumer code is being authored or reviewed |

## Navigation

- [Java 8 root](../../AGENTS.md)
- [Messaging standards](../../../../../../../standards/messaging/)
