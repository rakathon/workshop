// Non-compliant Java 8 E2E test — direct service calls, missing headers, no envelope check
@SpringBootTest
class OrderE2ETest {

    @Autowired
    private OrderService orderService;   // WRONG: direct service call in E2E test

    @Autowired
    private OrderRepository repository;  // WRONG: direct DB access in E2E test

    @Test
    void testCreateOrder() {
        // WRONG: calling service directly, not testing via HTTP
        Order order = orderService.create(new CreateOrderRequest("m-1"));
        assertThat(order.getId()).isNotNull();  // not testing HTTP observable behaviour

        // WRONG: direct database assertion instead of HTTP assertion
        assertThat(repository.findById(order.getId())).isPresent();
    }

    @Test
    void testListOrders() {
        // WRONG: RestAssured call missing Client-Agent header
        given()
        .when().get("/store/v1/stores")
        .then().statusCode(200)
            .body("size()", greaterThan(0));  // WRONG: no envelope check (data/meta)
    }
}
