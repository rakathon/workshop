# Java 8 Guide — Kafka

Guide: 1.0.0

## Overview

Shows how to produce and consume Kafka messages in a Spring Boot 2.7.x Java 8 service
using Spring Kafka 2.x. The Spring Kafka API is largely identical to the Java 21
guide; the differences are Lombok `@Value`/`@Builder` classes instead of records,
`javax.*` imports, and explicit type declarations instead of `var`.

## Related standard

[Messaging Standards](../../../../../../../standards/messaging/)

## Prerequisites

- `spring-boot-starter` with `spring-kafka` (Spring Kafka 2.9.x via Spring Boot 2.7.x)
- Lombok for event classes
- Jackson for JSON serialization

Maven dependency:

```xml
<dependency>
    <groupId>org.springframework.kafka</groupId>
    <artifactId>spring-kafka</artifactId>
</dependency>
```

---

## Implementation

### Producer configuration

```java
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaProducerConfig {

    @Bean
    public ProducerFactory<String, Object> producerFactory(
        KafkaProperties properties) {

        Map<String, Object> config =
            new HashMap<>(properties.buildProducerProperties());
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
            StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
            JsonSerializer.class);
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate(
        ProducerFactory<String, Object> producerFactory) {

        return new KafkaTemplate<>(producerFactory);
    }
}
```

### Event class — Lombok `@Value` instead of record

```java
import lombok.Builder;
import lombok.Value;
import java.time.Instant;

@Value
@Builder
public class OrderCreatedEvent {
    String orderId;
    String memberId;
    String status;
    Instant createdAt;
}
```

### Producing events

```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.kafka.support.SendResult;
import java.time.Instant;

@Service
public class OrderEventPublisher {

    private static final String TOPIC = "order-events";
    private static final Logger log =
        LoggerFactory.getLogger(OrderEventPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public OrderEventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishOrderCreated(Order order) {
        OrderCreatedEvent event = OrderCreatedEvent.builder()
            .orderId(order.getId())
            .memberId(order.getMemberId())
            .status(order.getStatus().name())
            .createdAt(Instant.now())
            .build();

        // Spring Kafka 2.x uses ListenableFuture; addCallback for async result
        kafkaTemplate.send(TOPIC, order.getId(), event)
            .addCallback(new ListenableFutureCallback<SendResult<String, Object>>() {

                @Override
                public void onSuccess(SendResult<String, Object> result) {
                    log.debug("Published order-created event orderId={} offset={}",
                        order.getId(),
                        result.getRecordMetadata().offset());
                }

                @Override
                public void onFailure(Throwable ex) {
                    log.error("Failed to publish order-created event orderId={}",
                        order.getId(), ex);
                }
            });
    }
}
```

### Consumer configuration

```java
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.SeekToCurrentErrorHandler;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.util.backoff.FixedBackOff;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaConsumerConfig {

    @Bean
    public ConsumerFactory<String, Object> consumerFactory(
        KafkaProperties properties) {

        Map<String, Object> config =
            new HashMap<>(properties.buildConsumerProperties());
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
            StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
            JsonDeserializer.class);
        config.put(JsonDeserializer.TRUSTED_PACKAGES,
            "com.rakutenrewards.*");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object>
        kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> consumerFactory,
            KafkaTemplate<String, Object> kafkaTemplate) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
            new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);

        // Spring Kafka 2.x uses SeekToCurrentErrorHandler (not DefaultErrorHandler)
        factory.setErrorHandler(
            new SeekToCurrentErrorHandler(
                new DeadLetterPublishingRecoverer(kafkaTemplate),
                new FixedBackOff(1_000L, 2L)));

        return factory;
    }
}
```

### Consuming events — `@KafkaListener`

```java
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class OrderEventConsumer {

    private static final Logger log =
        LoggerFactory.getLogger(OrderEventConsumer.class);

    private final OrderProjectionService projectionService;

    public OrderEventConsumer(OrderProjectionService projectionService) {
        this.projectionService = projectionService;
    }

    @KafkaListener(
        topics = "order-events",
        groupId = "rewards-store-service",
        containerFactory = "kafkaListenerContainerFactory")
    public void handleOrderCreated(
        @Payload OrderCreatedEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
        @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("Received order event orderId={} topic={} partition={} offset={}",
            event.getOrderId(), topic, partition, offset);

        projectionService.applyOrderCreated(event);
    }
}
```

**Note:** In Spring Kafka 2.x the header constant is `RECEIVED_PARTITION_ID` (not
`RECEIVED_PARTITION` as in Spring Kafka 3.x).

### Idempotent consumer pattern

```java
import org.springframework.transaction.annotation.Transactional;

@Component
public class IdempotentOrderEventConsumer {

    private final OrderProjectionService projectionService;
    private final ProcessedEventRepository processedEvents;

    public IdempotentOrderEventConsumer(
        OrderProjectionService projectionService,
        ProcessedEventRepository processedEvents) {

        this.projectionService = projectionService;
        this.processedEvents = processedEvents;
    }

    @KafkaListener(topics = "order-events", groupId = "rewards-store-service")
    @Transactional
    public void handleOrderCreated(
        @Payload OrderCreatedEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.OFFSET) long offset) {

        String eventKey = topic + ":" + event.getOrderId() + ":" + offset;

        if (processedEvents.existsByKey(eventKey)) {
            return;
        }
        projectionService.applyOrderCreated(event);
        processedEvents.markProcessed(eventKey);
    }
}
```

### Dead-letter topic consumer

```java
@Component
public class OrderEventDltConsumer {

    private static final Logger log =
        LoggerFactory.getLogger(OrderEventDltConsumer.class);

    @KafkaListener(
        topics = "order-events.DLT",
        groupId = "rewards-store-service-dlt")
    public void handleDlt(
        @Payload byte[] payload,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.EXCEPTION_MESSAGE) String exceptionMessage) {

        log.error("Message landed in DLT topic={} error={}",
            topic, exceptionMessage);
    }
}
```

### `application.yml` configuration

```yaml
spring:
  kafka:
    bootstrap-servers: ${KAFKA_BOOTSTRAP_SERVERS:localhost:9092}
    consumer:
      group-id: rewards-store-service
      auto-offset-reset: earliest
      enable-auto-commit: false
    producer:
      acks: all
      retries: 2147483647
      properties:
        enable.idempotence: true
```

---

## Verification

1. Publish a test event — confirm the listener logs the receipt and the projected
   state is updated.
2. Publish a malformed message — confirm the service does not crash and the message
   is routed to the `.DLT` topic after exhausting retries.
3. Publish the same event twice — confirm the idempotent consumer processes it only
   once.
4. Grep for `RECEIVED_PARTITION` (without `_ID` suffix) — must be zero; Java 8 /
   Spring Kafka 2.x requires `RECEIVED_PARTITION_ID`.
5. Grep for `var ` in source files — must be zero.
6. Run `mvn checkstyle:check` — zero violations required.
