/**
 * Integration test base class — real PostgreSQL and Kafka containers, no external mocks.
 * Setup: PostgreSQL 16-alpine (rewards_test), Kafka 7.6. Containers started once per JVM
 * via static @Container fields to avoid per-class restart overhead.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@Testcontainers
public abstract class IntegrationTestBase {

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("rewards_test")
            .withUsername("test")
            .withPassword("test");

    @Container
    static KafkaContainer kafka =
        new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.0"));

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // Wire all three PostgreSQL properties so Spring Boot can authenticate
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        // Kafka bootstrap address from live container
        registry.add("spring.kafka.bootstrap-servers", kafka::getBootstrapServers);
    }

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected ObjectMapper objectMapper;
}

/**
 * Tests StoreRepository persistence and retrieval against real PostgreSQL.
 * Validates INSERT/SELECT/constraint behaviour — not the DB itself, but the repository mapping.
 * @Transactional rolls back after each test, leaving DB clean for the next method.
 */
@Transactional
class StoreRepositoryIntegrationTest extends IntegrationTestBase {

    @Autowired
    private StoreRepository storeRepository;

    // REQ-STORE-001: A saved store must be retrievable by its ID
    @Test
    void givenStoreSaved_whenFindById_thenReturnsStore() {
        // Arrange — persist via real PostgreSQL container
        Store store = new Store(UUID.randomUUID(), "Test Store");
        storeRepository.save(store);

        // Act
        Optional<Store> found = storeRepository.findById(store.id());

        // Assert — validates actual DB round-trip
        assertThat(found).isPresent();
        assertThat(found.get().name()).isEqualTo("Test Store");
    }

    // REQ-STORE-010: findById with unknown ID must return empty Optional, not throw
    @Test
    void givenNonExistentId_whenFindById_thenReturnsEmpty() {
        // Act — UUID guaranteed not in DB
        Optional<Store> found = storeRepository.findById(UUID.randomUUID());

        // Assert
        assertThat(found).isEmpty();
    }

    // REQ-STORE-005: Optimistic locking — stale version token must raise VersionConflictException
    @Test
    void givenVersionTokenMismatch_whenReplace_thenThrowsVersionConflict() {
        // Arrange — save a store, then use a stale (random) version token
        Store store = storeRepository.save(new Store(UUID.randomUUID(), "Store A"));
        UUID staleToken = UUID.randomUUID();  // not the stored version token

        // Act + Assert — must throw, not silently overwrite
        assertThatThrownBy(
            () -> storeRepository.replaceWithVersionCheck(store.id(), "Store B", staleToken))
            .isInstanceOf(VersionConflictException.class);
    }
}

/**
 * Tests the HTTP layer for store endpoints through the full Spring MVC stack
 * with real PostgreSQL. Validates status codes, headers, response envelope, and error handling.
 */
class StoreControllerIntegrationTest extends IntegrationTestBase {

    // REQ-STORE-002: POST with valid body must return 201, Location header, and response envelope
    @Test
    void givenValidRequest_whenCreateStore_thenReturns201WithLocation() throws Exception {
        String body = objectMapper.writeValueAsString(new CreateStoreRequest("New Store"));

        mockMvc.perform(post("/store/v1/stores")
                .contentType(MediaType.APPLICATION_JSON)
                .header("Client-Agent", "test-service/1.0.0")
                .content(body))
            .andExpect(status().isCreated())
            .andExpect(header().exists("Location"))
            .andExpect(jsonPath("$.data.name").value("New Store"))
            .andExpect(jsonPath("$.meta.operation.request_id").exists());
    }

    // REQ-STORE-009: Requests missing Client-Agent header must be rejected with 400
    @Test
    void givenMissingClientAgent_whenListStores_thenReturns400() throws Exception {
        mockMvc.perform(get("/store/v1/stores"))
            .andExpect(status().isBadRequest());
    }

    // REQ-STORE-011: Malformed JSON body must return 400 with errors array
    @Test
    void givenMalformedBody_whenCreateStore_thenReturns400WithErrorsArray() throws Exception {
        mockMvc.perform(post("/store/v1/stores")
                .contentType(MediaType.APPLICATION_JSON)
                .header("Client-Agent", "test-service/1.0.0")
                .content("{invalid json"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.errors").isArray())
            .andExpect(jsonPath("$.errors[0].code").exists());
    }
}
