// Compliant Java 8 DynamoDB entity — snake_case attrs, version field, ISO 8601 timestamps
// AWS SDK v2 API supports Java 8; patterns identical to Java 21 version
@DynamoDbBean
@Data
public class OrderItem {
    private String pk;            // "ORDER#<orderId>"
    private String sk;            // "ITEM#<itemId>"
    private String entityType;    // "ORDER_ITEM"
    private Integer schemaVersion;
    private String orderId;
    private String itemId;
    private String createdAt;     // ISO 8601: "2024-06-15T09:30:00Z" — NOT epoch long
    private Long version;         // optimistic concurrency via @DynamoDbVersionAttribute

    @DynamoDbPartitionKey
    @DynamoDbAttribute("pk")
    public String getPk() { return pk; }

    @DynamoDbSortKey
    @DynamoDbAttribute("sk")
    public String getSk() { return sk; }

    @DynamoDbAttribute("entity_type")   // snake_case attribute name
    public String getEntityType() { return entityType; }

    @DynamoDbAttribute("schema_version")
    public Integer getSchemaVersion() { return schemaVersion; }

    @DynamoDbAttribute("order_id")
    public String getOrderId() { return orderId; }

    @DynamoDbAttribute("item_id")       // snake_case — explicit annotation required for camelCase field
    public String getItemId() { return itemId; }

    @DynamoDbAttribute("created_at")    // snake_case, ISO 8601 string value
    public String getCreatedAt() { return createdAt; }

    @DynamoDbVersionAttribute           // SDK manages version increment + conflict detection
    @DynamoDbAttribute("version")
    public Long getVersion() { return version; }
}

// Repository using Query (not Scan)
@Repository
public class OrderRepository {
    public List<OrderItem> findByOrderId(String orderId) {
        // Correct: Query by partition key — never scan
        QueryConditional qc = QueryConditional.keyEqualTo(
            Key.builder().partitionValue("ORDER#" + orderId).build());
        // Java 8: .collect(Collectors.toList()) instead of .toList()
        return table.query(qc).items().stream().collect(Collectors.toList());
        // NEVER: table.scan()  ← prohibited in request path
    }

    public void update(OrderItem item) {
        try {
            table.updateItem(item);  // @DynamoDbVersionAttribute auto-checks version
        } catch (ConditionalCheckFailedException ex) {
            throw new VersionConflictException(item);
        }
    }
}
