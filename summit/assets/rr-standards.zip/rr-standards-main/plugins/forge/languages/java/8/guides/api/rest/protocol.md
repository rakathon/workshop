# Java 8 Guide — REST API Protocol

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/protocol.md@1.0.0

## Overview

Shows how to satisfy the REST API Protocol standard in a Spring Boot 2.7.x service
targeting Java 8. Covers Lombok-based response envelope classes, `ResponseEntity`
usage, `@RestControllerAdvice` error handling, `Client-Agent` header validation,
`Retry-After` emission on 429 and 503, and correct HTTP status code selection.
Uses `javax.servlet.*` and `javax.validation.*` throughout.

## Related standard

[REST API Protocol](../../../../../../standards/api/rest/protocol.md)

## Prerequisites

- Spring Boot 2.7.x (`spring-boot-starter-web`)
- Lombok (`org.projectlombok:lombok`) for immutable response classes
- Jackson with snake_case naming configured (see `contracts.md`)

---

## Implementation

### Response envelope classes (R-5, R-6, R-8)

In Java 8 use Lombok `@Value` (immutable) and `@Builder` instead of records.
All success responses wrap the payload in `data`; all error responses use
`errors` + `meta`. Never include `data` on an error response.

```java
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;
import java.util.UUID;

// Shared meta block — included in every response
@Value
@Builder
public class Meta {
    StatusInfo status;
    OperationInfo operation;

    @Value
    @Builder
    public static class StatusInfo {
        String code;
    }

    @Value
    @Builder
    public static class OperationInfo {
        UUID requestId;
    }

    public static Meta ok(UUID requestId) {
        return Meta.builder()
            .status(StatusInfo.builder().code("OK").build())
            .operation(OperationInfo.builder().requestId(requestId).build())
            .build();
    }

    public static Meta of(String code, UUID requestId) {
        return Meta.builder()
            .status(StatusInfo.builder().code(code).build())
            .operation(OperationInfo.builder().requestId(requestId).build())
            .build();
    }
}

// Success response — single entity
@Value
@Builder
public class DataResponse<T> {
    T data;
    Meta meta;
}

// Success response — collection with optional pagination
@Value
@Builder
public class ListResponse<T> {
    List<T> data;
    Object pagination;   // null when no pagination info
    Meta meta;
}

// Error detail
@Value
@Builder
public class ErrorDetail {
    String code;
    String message;
    ErrorField details;   // nullable
    UUID traceId;         // nullable

    @Value
    @Builder
    public static class ErrorField {
        String field;
        Object value;      // nullable
        String constraint; // nullable
    }
}

// Error response — never has a 'data' field
@Value
@Builder
public class ErrorResponse {
    List<ErrorDetail> errors;
    Meta meta;
}
```

### `ResponseEntity` usage in controllers (R-5, R-7)

```java
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.net.URI;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/store/v1/stores")
public class StoreController {

    @GetMapping
    public ResponseEntity<ListResponse<Store>> listStores(
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        List<Store> stores = storeService.findAll();
        return ResponseEntity.ok(
            ListResponse.<Store>builder()
                .data(stores)
                .meta(Meta.ok(requestId))
                .build());
    }

    @PostMapping                              // R-7: 201 for creation
    public ResponseEntity<DataResponse<Store>> createStore(
        @RequestBody @Valid CreateStoreRequest body,
        HttpServletRequest request) {

        UUID requestId = RequestContext.requestId(request);
        Store created = storeService.create(body);
        URI location = URI.create("/store/v1/stores/" + created.getId());

        return ResponseEntity
            .created(location)              // sets Location header (R-7)
            .body(DataResponse.<Store>builder()
                .data(created)
                .meta(Meta.ok(requestId))
                .build());
    }

    @DeleteMapping("/{store_id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)  // R-7: 204 for deletion
    public void deleteStore(@PathVariable("store_id") String storeId) {
        storeService.delete(storeId);
    }
}
```

### Global error handler — `@RestControllerAdvice` (R-6, R-7, R-8)

```java
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.http.converter.HttpMessageNotReadableException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log =
        LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // R-7: 400 for unparseable request body
    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleUnparseable(
        HttpMessageNotReadableException ex,
        HttpServletRequest request) {

        return errorResponse("MALFORMED_REQUEST", ex.getMessage(), request);
    }

    // R-7: 400 for bean-validation failures
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidation(
        MethodArgumentNotValidException ex,
        HttpServletRequest request) {

        List<ErrorDetail> errors = new ArrayList<>();
        for (FieldError fe : ex.getBindingResult().getFieldErrors()) {
            errors.add(ErrorDetail.builder()
                .code("VALIDATION_ERROR")
                .message(fe.getDefaultMessage())
                .details(ErrorDetail.ErrorField.builder()
                    .field(fe.getField())
                    .value(fe.getRejectedValue())
                    .build())
                .build());
        }
        return ErrorResponse.builder()
            .errors(errors)
            .meta(Meta.of("BadRequest", RequestContext.requestId(request)))
            .build();
    }

    // R-7: 401 for auth failures
    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleAuth(
        AuthenticationException ex,
        HttpServletRequest request) {

        return errorResponse("UNAUTHORIZED", ex.getMessage(), request);
    }

    // R-7: 403 for insufficient roles
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handleForbidden(
        AccessDeniedException ex,
        HttpServletRequest request) {

        return errorResponse("FORBIDDEN", ex.getMessage(), request);
    }

    // R-7: 404 for missing resources
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleNotFound(
        ResourceNotFoundException ex,
        HttpServletRequest request) {

        return errorResponse("NOT_FOUND", ex.getMessage(), request);
    }

    // R-7: 409 for version_token mismatches — return current entity state
    @ExceptionHandler(VersionConflictException.class)
    public ResponseEntity<DataResponse<?>> handleConflict(
        VersionConflictException ex,
        HttpServletRequest request) {

        return ResponseEntity
            .status(HttpStatus.CONFLICT)
            .body(DataResponse.builder()
                .data(ex.getCurrentState())
                .meta(Meta.of("Conflict", RequestContext.requestId(request)))
                .build());
    }

    // R-7: 422 for business-rule violations on well-formed requests
    @ExceptionHandler(BusinessRuleException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ErrorResponse handleBusinessRule(
        BusinessRuleException ex,
        HttpServletRequest request) {

        return errorResponse(ex.getCode(), ex.getMessage(), request);
    }

    // R-7: 429 with Retry-After (R-3)
    @ExceptionHandler(RateLimitExceededException.class)
    public ResponseEntity<ErrorResponse> handleRateLimit(
        RateLimitExceededException ex,
        HttpServletRequest request) {

        return ResponseEntity
            .status(HttpStatus.TOO_MANY_REQUESTS)
            .header("Retry-After", String.valueOf(ex.getRetryAfterSeconds()))
            .body(errorResponse("RATE_LIMIT_EXCEEDED", ex.getMessage(), request));
    }

    // R-7: 503 with Retry-After (R-3)
    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity<ErrorResponse> handleServiceUnavailable(
        ServiceUnavailableException ex,
        HttpServletRequest request) {

        return ResponseEntity
            .status(HttpStatus.SERVICE_UNAVAILABLE)
            .header("Retry-After", String.valueOf(ex.getRetryAfterSeconds()))
            .body(errorResponse("SERVICE_UNAVAILABLE", ex.getMessage(), request));
    }

    // Never return 200 for an error condition (R-7)
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleUnexpected(
        Exception ex,
        HttpServletRequest request) {

        log.error("Unhandled exception", ex);
        return errorResponse("INTERNAL_ERROR",
            "An unexpected error occurred", request);
    }

    private ErrorResponse errorResponse(
        String code, String message, HttpServletRequest request) {

        return ErrorResponse.builder()
            .errors(Collections.singletonList(
                ErrorDetail.builder().code(code).message(message).build()))
            .meta(Meta.of(code, RequestContext.requestId(request)))
            .build();
    }
}
```

### Client-Agent header (R-1)

```java
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class ClientAgentInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(
        HttpServletRequest request,
        HttpServletResponse response,
        Object handler) throws Exception {

        if (request.getHeader("Client-Agent") == null) {
            response.sendError(
                HttpServletResponse.SC_BAD_REQUEST,
                "Client-Agent header is required");
            return false;
        }
        return true;
    }
}
```

### Status code selection guide (R-7)

| Situation | Status code |
|-----------|-------------|
| Read success | `200 OK` |
| Resource created | `201 Created` + `Location` header |
| Delete success | `204 No Content` |
| Request body fails to parse | `400 Bad Request` |
| Bean validation failures | `400 Bad Request` |
| Auth credentials missing/invalid | `401 Unauthorized` |
| Authenticated but insufficient roles | `403 Forbidden` |
| Resource does not exist | `404 Not Found` |
| `version_token` mismatch | `409 Conflict` + current entity state |
| Business rule violation (well-formed request) | `422 Unprocessable Entity` |
| Rate limit exceeded | `429 Too Many Requests` + `Retry-After` |
| Service temporarily unavailable | `503 Service Unavailable` + `Retry-After` |

**Never return `200` for an error condition** (R-7).

---

## Verification

1. Call a `POST` that creates a resource — confirm `201` with a `Location` header.
2. Call an endpoint with a malformed body — confirm `400` with an `errors` array.
3. Trigger a rate limit — confirm `429` with a `Retry-After` header.
4. Confirm no handler method returns `200` for any exception path.
5. Confirm all `2xx` responses contain `meta.status.code` and
   `meta.operation.request_id`; non-2xx responses contain `errors` and `meta` but
   no `data`.
6. Run `mvn checkstyle:check` — zero violations required.
