// Compliant Java 8 Kafka configuration — Spring Kafka 2.x with SeekToCurrentErrorHandler
// Key Java 8 differences:
// - SeekToCurrentErrorHandler (not DefaultErrorHandler which is Spring Kafka 3.x)
// - ListenableFuture.addCallback (not CompletableFuture.whenComplete)
// - RECEIVED_PARTITION_ID header constant (not RECEIVED_PARTITION)
// - Lombok @Value/@Builder for event classes

// ---- KafkaProducerConfig.java ----
@Configuration
public class KafkaProducerConfig {

    @Bean
    public ProducerFactory<String, Object> producerFactory(
        KafkaProperties properties) {

        Map<String, Object> config =
            new HashMap<>(properties.buildProducerProperties());
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
            StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
            JsonSerializer.class);
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate(
        ProducerFactory<String, Object> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }
}

// ---- OrderCreatedEvent.java ----
// Lombok @Value/@Builder — Java 8 idiom (no records)
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class OrderCreatedEvent {
    String orderId;
    String memberId;
    String status;
    Instant createdAt;
}

// ---- OrderEventPublisher.java ----
// Spring Kafka 2.x: ListenableFuture.addCallback for async result handling
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.kafka.support.SendResult;

@Service
public class OrderEventPublisher {

    private static final String TOPIC = "order-events";
    private static final Logger log =
        LoggerFactory.getLogger(OrderEventPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public OrderEventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishOrderCreated(Order order) {
        OrderCreatedEvent event = OrderCreatedEvent.builder()
            .orderId(order.getId())
            .memberId(order.getMemberId())
            .status(order.getStatus().name())
            .createdAt(Instant.now())
            .build();

        // Spring Kafka 2.x: ListenableFuture.addCallback (not CompletableFuture.whenComplete)
        kafkaTemplate.send(TOPIC, order.getId(), event)
            .addCallback(new ListenableFutureCallback<SendResult<String, Object>>() {

                @Override
                public void onSuccess(SendResult<String, Object> result) {
                    log.debug("Published order-created event orderId={} offset={}",
                        order.getId(),
                        result.getRecordMetadata().offset());
                }

                @Override
                public void onFailure(Throwable ex) {
                    log.error("Failed to publish order-created event orderId={}",
                        order.getId(), ex);
                }
            });
    }
}

// ---- KafkaConsumerConfig.java ----
// Spring Kafka 2.x: SeekToCurrentErrorHandler (not DefaultErrorHandler from Spring Kafka 3.x)
import org.springframework.kafka.listener.SeekToCurrentErrorHandler;

@Configuration
public class KafkaConsumerConfig {

    @Bean
    public ConsumerFactory<String, Object> consumerFactory(
        KafkaProperties properties) {

        Map<String, Object> config =
            new HashMap<>(properties.buildConsumerProperties());
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
            StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
            JsonDeserializer.class);
        config.put(JsonDeserializer.TRUSTED_PACKAGES,
            "com.rakutenrewards.*");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object>
        kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> consumerFactory,
            KafkaTemplate<String, Object> kafkaTemplate) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
            new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);

        // Spring Kafka 2.x: SeekToCurrentErrorHandler with DLQ and fixed backoff
        // (DefaultErrorHandler is only available in Spring Kafka 3.x / Spring Boot 3.x)
        factory.setErrorHandler(
            new SeekToCurrentErrorHandler(
                new DeadLetterPublishingRecoverer(kafkaTemplate),
                new FixedBackOff(1_000L, 2L)));

        return factory;
    }
}

// ---- OrderEventConsumer.java ----
// Spring Kafka 2.x: RECEIVED_PARTITION_ID header constant (not RECEIVED_PARTITION from 3.x)
@Component
public class OrderEventConsumer {

    private static final Logger log =
        LoggerFactory.getLogger(OrderEventConsumer.class);

    private final OrderProjectionService projectionService;

    public OrderEventConsumer(OrderProjectionService projectionService) {
        this.projectionService = projectionService;
    }

    @KafkaListener(
        topics = "order-events",
        groupId = "rewards-store-service",
        containerFactory = "kafkaListenerContainerFactory")
    public void handleOrderCreated(
        @Payload OrderCreatedEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,  // Spring Kafka 2.x constant
        @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("Received order event orderId={} topic={} partition={} offset={}",
            event.getOrderId(), topic, partition, offset);

        projectionService.applyOrderCreated(event);
    }
}
