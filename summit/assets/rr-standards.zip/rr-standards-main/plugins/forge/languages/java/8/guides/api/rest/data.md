# Java 8 Guide — REST API Data

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/data.md@1.0.0

## Overview

Shows how to satisfy the REST API Data standard in a Spring Boot 2.7.x service
targeting Java 8. Covers Lombok-based pagination response classes, `version_token`
on mutable resources, `Instant` serialization for timestamps, `DecimalValue` and
`MoneyAmount` value objects, and tracing header propagation. Uses
`javax.validation.*` throughout.

## Related standard

[REST API Data](../../../../../../standards/api/rest/data.md)

## Prerequisites

- Spring Boot 2.7.x with Jackson snake_case configured (see `contracts.md`)
- Lombok (`org.projectlombok:lombok`)
- `java.time.Instant` (available since Java 8)
- `javax.validation:validation-api` (included via spring-boot-starter-validation)

---

## Implementation

### Pagination response classes (R-1, R-2)

Define pagination styles as Lombok `@Value` classes. Use cursor-based by default;
offset-based only when the UI requires page-number navigation.

```java
import lombok.Builder;
import lombok.Value;

// Default — forward-only cursor pagination
@Value
@Builder
public class CursorPagination {
    String next;    // null on the last page
}

// Cursor pagination with backward navigation
@Value
@Builder
public class CursorPaginationBidirectional {
    String next;     // null on the last page
    String previous; // null on the first page
}

// Offset pagination — only when UI requires page numbers
@Value
@Builder
public class OffsetPagination {
    int numPages;
    int numResults;
}
```

Every collection controller method **must** accept a `limit` (or `size`) parameter:

```java
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import org.springframework.web.bind.annotation.RequestParam;

@GetMapping
public ResponseEntity<ListResponse<Store>> listStores(
    @RequestParam(defaultValue = "20") @Min(1) @Max(100) int limit,
    @RequestParam(required = false) String cursor,
    HttpServletRequest request) {

    Page<Store> page = storeService.findAll(cursor, limit);
    CursorPagination pagination = CursorPagination.builder()
        .next(page.hasNext() ? page.getNextCursor() : null)
        .build();

    return ResponseEntity.ok(
        ListResponse.<Store>builder()
            .data(page.getItems())
            .pagination(pagination)
            .meta(Meta.ok(RequestContext.requestId(request)))
            .build());
}
```

### Optimistic concurrency — `version_token` (R-3)

Every resource that supports `PUT` or `PATCH` must include a `version_token` UUID
field. Use Lombok `@Value` for the response class and `@Data` for the request class.

```java
// Resource class — returned on GET
@Value
@Builder
public class Store {
    UUID id;
    String name;
    UUID versionToken;    // mapped to "version_token" by Jackson snake_case config
    Instant createdAt;
    Instant updatedAt;
}

// Write request — version_token is required
@Data
public class ReplaceStoreRequest {

    @NotBlank
    private String name;

    @NotNull
    private UUID versionToken;   // clients must always send the current token
}
```

Service-layer optimistic concurrency check:

```java
@Service
public class StoreService {

    public Store replace(String storeId, ReplaceStoreRequest request) {
        Store current = repository.findById(storeId)
            .orElseThrow(() -> new ResourceNotFoundException(storeId));

        if (!current.getVersionToken().equals(request.getVersionToken())) {
            throw new VersionConflictException(current);
        }
        Store updated = Store.builder()
            .id(current.getId())
            .name(request.getName())
            .versionToken(UUID.randomUUID())
            .createdAt(current.getCreatedAt())
            .updatedAt(Instant.now())
            .build();
        return repository.save(updated);
    }
}
```

### Timestamp format — `Instant` to ISO 8601 (R-4)

Use `java.time.Instant` for all timestamp fields. Disable epoch-second serialization
in Jackson.

```java
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@Bean
public Jackson2ObjectMapperBuilderCustomizer timestampConfig() {
    return builder -> builder
        .featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
        .modules(new JavaTimeModule());
}
```

Maven dependency for `JavaTimeModule` (Spring Boot 2.x includes it, but declare
explicitly if needed):

```xml
<dependency>
    <groupId>com.fasterxml.jackson.datatype</groupId>
    <artifactId>jackson-datatype-jsr310</artifactId>
</dependency>
```

```java
// Correct — Instant serializes to "2024-06-15T09:30:00Z"
@Value
@Builder
public class Store {
    UUID id;
    String name;
    Instant createdAt;
    Instant updatedAt;
}

// Wrong — long epoch integer
@Value
@Builder
public class Store {
    UUID id;
    String name;
    long createdAt;   // violates R-4
}
```

### Decimal numbers — value/scale tuple (R-5)

Never use `double` or `float` for precision-sensitive values.

```java
import lombok.Value;
import java.math.BigDecimal;

/**
 * Lossless decimal representation.
 * Real value = value × 10^(−scale).
 * Example: 15.00% → DecimalValue(1500, 2).
 */
@Value
public class DecimalValue {
    long value;   // unscaled integer mantissa
    int scale;    // number of decimal places

    public DecimalValue(long value, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
        this.value = value;
        this.scale = scale;
    }

    public BigDecimal toBigDecimal() {
        return new BigDecimal(value).movePointLeft(scale);
    }

    public static DecimalValue of(BigDecimal bd) {
        int s = bd.scale() < 0 ? 0 : bd.scale();
        long v = bd.movePointRight(s).longValueExact();
        return new DecimalValue(v, s);
    }
}
```

Usage in a response class:

```java
// Correct — lossless DecimalValue
@Value
@Builder
public class Offer {
    UUID id;
    String name;
    DecimalValue discountPercentage;  // {"value": 1500, "scale": 2} = 15.00%
}

// Wrong — float loses precision
@Value
@Builder
public class Offer {
    UUID id;
    String name;
    double discountPercentage;   // violates R-5
}
```

### Currency amounts (R-6)

```java
/**
 * Currency amount with explicit scale. ISO 4217 currency code required.
 * Example: $10.50 → MoneyAmount(1050, "USD", 2).
 */
@Value
public class MoneyAmount {
    long amount;     // integer amount in currency's smallest unit × 10^scale
    String currency; // ISO 4217 code, e.g., "USD", "JPY", "EUR"
    int scale;       // decimal places: 0 for JPY, 2 for USD/EUR

    public MoneyAmount(long amount, String currency, int scale) {
        if (currency == null || currency.length() != 3) {
            throw new IllegalArgumentException(
                "currency must be a 3-character ISO 4217 code");
        }
        if (scale < 0) {
            throw new IllegalArgumentException("scale must be non-negative");
        }
        this.amount = amount;
        this.currency = currency;
        this.scale = scale;
    }
}
```

### Distributed tracing — `traceparent` header (R-7)

```java
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.slf4j.MDC;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class TracingFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String traceparent = request.getHeader("traceparent");
        if (traceparent != null) {
            MDC.put("traceparent", traceparent);
            String tracestate = request.getHeader("tracestate");
            if (tracestate != null) {
                MDC.put("tracestate", tracestate);
            }
        }
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.remove("traceparent");
            MDC.remove("tracestate");
        }
    }
}
```

### Localization — `Accept-Language` header (R-8)

```java
import org.springframework.web.bind.annotation.RequestHeader;

@GetMapping("/offers/v1/regions/{region_id}/offers/{offer_id}")
public ResponseEntity<DataResponse<Offer>> getOffer(
    @PathVariable("region_id") String regionId,
    @PathVariable("offer_id") String offerId,
    @RequestHeader(
        value = "Accept-Language",
        required = false,
        defaultValue = "") String acceptLanguage,
    HttpServletRequest request) {

    Locale locale = LocaleUtils.resolve(acceptLanguage, regionId);
    Offer offer = offerService.find(offerId, locale);
    return ResponseEntity.ok(
        DataResponse.<Offer>builder()
            .data(offer)
            .meta(Meta.ok(RequestContext.requestId(request)))
            .build());
}
```

---

## Verification

1. Inspect every collection endpoint and confirm a `limit` (or `size`) query
   parameter is present.
2. Inspect every resource class that has a `PUT` or `PATCH` handler and confirm it
   includes a `versionToken` field (type `UUID`); the write request class also
   requires it with `@NotNull`.
3. Confirm the service layer throws `VersionConflictException` (mapped to `409`)
   when the token does not match.
4. Send `GET` on a resource and confirm timestamp fields serialize to
   `"YYYY-MM-DDTHH:MM:SSZ"` — no epoch integers.
5. Confirm no field carrying a percentage, rate, or price uses `double` or `float`.
6. Run `mvn checkstyle:check` — zero violations required.
