# Java (Default / Java 21 LTS) Language Guides

## Directory purpose

Java 21 LTS implementation guides for rr-standards. Each guide shows how to satisfy
a language-agnostic standard — or a domain convention — using idiomatic Java 21,
Spring Boot 3.x, and the AWS SDK v2. Load the relevant guide(s) when generating or
reviewing Java source code.

## File index

| Path | Purpose | When to reference |
|------|---------|-------------------|
| `guides/api/rest/` | Spring MVC implementations of the four REST API sub-standards | Any Java REST API is being authored or reviewed |
| `guides/testing/unit.md` | JUnit 5 + Mockito unit testing patterns | Writing or reviewing unit tests |
| `guides/testing/integration.md` | Spring Boot Test + Testcontainers integration patterns | Writing or reviewing integration tests |
| `guides/testing/e2e.md` | End-to-end test patterns with real HTTP clients | Writing or reviewing end-to-end test suites |
| `guides/storage/dynamodb.md` | AWS SDK v2 DynamoDB enhanced client patterns | Any DynamoDB read/write code is being authored or reviewed |
| `guides/messaging/kafka.md` | Spring Kafka producer and consumer patterns | Any Kafka producer or consumer code is being authored or reviewed |
| `guides/observability/logging.md` | SLF4J + Logback structured JSON logging | Any logging code is being authored or reviewed |

## Linter

**Checkstyle 10.x** with the Google Java Style Guide configuration
(`config/checkstyle/google_checks.xml`). All generated Java code must pass
`mvn checkstyle:check` with zero violations before review.

Key style rules enforced:
- 2-space block indentation
- 100-character line limit
- No wildcard imports
- K&R brace style (opening brace on same line)
- Javadoc required on all `public` and `protected` declarations

All new services should also target the company SonarQube quality profile
`SG-JAVA-CUSTOM-PROFILE-07-2025`. See the
[SonarQube Java Specific Rules](https://rakutenrewards.atlassian.net/wiki/spaces/GUILDS/pages/43231117492/SonarQube+Java+Specific+Rules)
Confluence page for the custom rule thresholds in effect (e.g., max 25 methods per
class, max 15 class couplings, max 10 switch cases).

## Navigation

- [Java language root](../AGENTS.md) — version directory selection
- [Java 8 notes](../8/AGENTS.md) — Java 8 compatibility differences
- [Standards root](../../../standards/) — the language-agnostic standards these guides implement
