// Compliant E2E logging filter — ApiCallLoggingFilter implements RestAssured Filter.
// Logs every HTTP call via SLF4J so output lands in JUnit XML <system-out>.
// SLF4J is already on the classpath via Spring Boot (3.x or 4.x); non-Spring Boot projects add an SLF4J binding as a test dep.

import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class ApiCallLoggingFilter implements Filter {
    private static final Logger log = LoggerFactory.getLogger(ApiCallLoggingFilter.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public Response filter(FilterableRequestSpecification req,
                           FilterableResponseSpecification res,
                           FilterContext ctx) {
        Response response = ctx.next(req, res);
        try {
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("method",           req.getMethod());
            entry.put("url",              req.getURI());
            entry.put("request_headers",  headersToMap(req.getHeaders()));
            entry.put("request_body",     req.getBody());
            entry.put("status_code",      response.getStatusCode());
            entry.put("response_headers", headersToMap(response.getHeaders()));
            entry.put("response_body",    response.getBody().asString());
            log.info("api_call: {}", mapper.writeValueAsString(entry));
        } catch (Exception e) {
            log.warn("api_call logging failed: {}", e.getMessage());
        }
        return response;
    }

    private Map<String, String> headersToMap(io.restassured.http.Headers headers) {
        return headers.asList().stream()
            .collect(Collectors.toMap(
                io.restassured.http.Header::getName,
                io.restassured.http.Header::getValue,
                (a, b) -> a
            ));
    }
}
