# Java Guide — Kafka

Guide: 1.0.0

## Overview

Shows how to produce and consume Kafka messages in a Spring Boot 3.x service using
Spring Kafka. Covers `KafkaTemplate` for type-safe production, `@KafkaListener` for
consumption, JSON serialization with schema-aware deserialization, consumer group
configuration, dead-letter topic (DLT) routing for poison messages, and idempotent
consumer patterns. A service that follows this guide produces and consumes messages
reliably without data loss or duplicate processing under restart scenarios.

## Related standard

[Messaging Standards](../../../../../../../standards/messaging/)

## Prerequisites

- `spring-boot-starter` with `spring-kafka`
- Jackson for JSON serialization (included in the web starter)
- Testcontainers Kafka module for integration tests

Maven dependency:

```xml
<dependency>
    <groupId>org.springframework.kafka</groupId>
    <artifactId>spring-kafka</artifactId>
</dependency>
```

---

## Implementation

### Producer configuration

Configure a `KafkaTemplate` bean with JSON serialization. The key is a `String`
(typically the entity ID or partition routing key); the value is the event record.

```java
@Configuration
public class KafkaProducerConfig {

    @Bean
    public ProducerFactory<String, Object> producerFactory(
        KafkaProperties properties) {

        Map<String, Object> config = new HashMap<>(
            properties.buildProducerProperties(null));
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
            StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
            JsonSerializer.class);
        // Idempotent producer — exactly-once delivery per partition
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate(
        ProducerFactory<String, Object> producerFactory) {

        return new KafkaTemplate<>(producerFactory);
    }
}
```

### Producing events

Define event records with snake_case-compatible field names. Send with the entity
ID as the Kafka message key to ensure all events for the same entity go to the same
partition (ordering guarantee).

```java
// Event record — field names mapped to snake_case by Jackson
public record OrderCreatedEvent(
    String orderId,
    String memberId,
    String status,
    Instant createdAt) {}

@Service
public class OrderEventPublisher {

    private static final String TOPIC = "order-events";
    private static final Logger log =
        LoggerFactory.getLogger(OrderEventPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public OrderEventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishOrderCreated(Order order) {
        var event = new OrderCreatedEvent(
            order.id(),
            order.memberId(),
            order.status().name(),
            Instant.now());

        kafkaTemplate.send(TOPIC, order.id(), event)
            .whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Failed to publish order-created event "
                        + "for orderId={}", order.id(), ex);
                } else {
                    log.debug("Published order-created event "
                        + "for orderId={} offset={}",
                        order.id(),
                        result.getRecordMetadata().offset());
                }
            });
    }
}
```

### Consumer configuration

Configure a `ConsumerFactory` with JSON deserialization and a `ConcurrentKafkaListenerContainerFactory`
that routes failed records to a dead-letter topic after exhausting retries.

```java
@Configuration
public class KafkaConsumerConfig {

    @Bean
    public ConsumerFactory<String, Object> consumerFactory(
        KafkaProperties properties) {

        Map<String, Object> config = new HashMap<>(
            properties.buildConsumerProperties(null));
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
            StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
            JsonDeserializer.class);
        config.put(JsonDeserializer.TRUSTED_PACKAGES,
            "com.rakutenrewards.*");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object>
        kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> consumerFactory,
            KafkaTemplate<String, Object> kafkaTemplate) {

        var factory =
            new ConcurrentKafkaListenerContainerFactory<String, Object>();
        factory.setConsumerFactory(consumerFactory);

        // Dead-letter topic after 3 attempts (1 try + 2 retries)
        factory.setCommonErrorHandler(
            new DefaultErrorHandler(
                new DeadLetterPublishingRecoverer(kafkaTemplate),
                new FixedBackOff(1_000L, 2L)));

        return factory;
    }
}
```

### Consuming events — `@KafkaListener`

Annotate the listener method with the topic and consumer group. The consumer group ID
should be specific to the service so different services can each process all messages
independently.

```java
@Component
public class OrderEventConsumer {

    private static final Logger log =
        LoggerFactory.getLogger(OrderEventConsumer.class);

    private final OrderProjectionService projectionService;

    public OrderEventConsumer(OrderProjectionService projectionService) {
        this.projectionService = projectionService;
    }

    @KafkaListener(
        topics = "order-events",
        groupId = "rewards-store-service",
        containerFactory = "kafkaListenerContainerFactory")
    public void handleOrderCreated(
        @Payload OrderCreatedEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
        @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("Received order event orderId={} topic={} partition={} offset={}",
            event.orderId(), topic, partition, offset);

        projectionService.applyOrderCreated(event);
    }
}
```

### Idempotent consumer pattern

Consumers must be idempotent: processing the same message twice must not corrupt
state. Track processed message IDs to skip duplicates.

```java
@Component
public class IdempotentOrderEventConsumer {

    private final OrderProjectionService projectionService;
    private final ProcessedEventRepository processedEvents;

    public IdempotentOrderEventConsumer(
        OrderProjectionService projectionService,
        ProcessedEventRepository processedEvents) {

        this.projectionService = projectionService;
        this.processedEvents = processedEvents;
    }

    @KafkaListener(topics = "order-events", groupId = "rewards-store-service")
    @Transactional
    public void handleOrderCreated(
        @Payload OrderCreatedEvent event,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.OFFSET) long offset) {

        String eventKey = topic + ":" + event.orderId() + ":" + offset;

        if (processedEvents.existsByKey(eventKey)) {
            // Already processed — skip silently
            return;
        }
        projectionService.applyOrderCreated(event);
        processedEvents.markProcessed(eventKey);
    }
}
```

### Dead-letter topic handling

When a message fails after all retries, Spring Kafka routes it to
`<original-topic>.DLT`. Monitor the DLT and alert on non-zero message counts.

```java
@Component
public class OrderEventDltConsumer {

    private static final Logger log =
        LoggerFactory.getLogger(OrderEventDltConsumer.class);

    @KafkaListener(
        topics = "order-events.DLT",
        groupId = "rewards-store-service-dlt")
    public void handleDlt(
        @Payload byte[] payload,
        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
        @Header(KafkaHeaders.EXCEPTION_MESSAGE) String exceptionMessage) {

        // Log and alert — do not re-throw; DLT must not loop back
        log.error("Message landed in DLT topic={} error={}",
            topic, exceptionMessage);
        // Emit a metric for alerting
        meterRegistry.counter("kafka.dlt.messages",
            "topic", topic).increment();
    }
}
```

### Consumer `application.yml` configuration

```yaml
spring:
  kafka:
    bootstrap-servers: ${KAFKA_BOOTSTRAP_SERVERS:localhost:9092}
    consumer:
      group-id: rewards-store-service
      auto-offset-reset: earliest
      enable-auto-commit: false     # manual acknowledgement via Spring Kafka
    producer:
      acks: all
      retries: 2147483647           # Integer.MAX_VALUE
      properties:
        enable.idempotence: true
```

---

## Verification

1. Start the service with a local Kafka container and publish a test event — confirm
   the listener logs the receipt and the projected state is updated.
2. Publish a malformed message (wrong JSON shape) — confirm the service does not crash
   and the message is routed to the `.DLT` topic after exhausting retries.
3. Publish the same event twice using the same key and offset — confirm the idempotent
   consumer processes it only once (check the projection state, not just log output).
4. Run `mvn checkstyle:check` — zero violations required.
