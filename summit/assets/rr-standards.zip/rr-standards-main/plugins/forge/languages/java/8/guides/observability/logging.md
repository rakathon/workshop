# Java 8 Guide — Structured Logging

Guide: 1.0.0

## Overview

Shows how to implement structured JSON logging in a Java 8 Spring Boot 2.7.x service
using SLF4J, Logback, and `logstash-logback-encoder`. SLF4J and Logback support Java
8 natively. The implementation is identical to the Java 21 guide except for
`javax.servlet.*` imports in the filter. All MDC patterns, log level guidance, PII
exclusion rules, and SonarQube logging requirements are the same.

## Related standard

[Observability Standards](../../../../../../../standards/observability/)

## Prerequisites

- SLF4J + Logback Classic — included in Spring Boot 2.7.x
- `net.logstash.logback:logstash-logback-encoder`

Maven dependency:

```xml
<dependency>
    <groupId>net.logstash.logback</groupId>
    <artifactId>logstash-logback-encoder</artifactId>
    <version>7.4</version>
</dependency>
```

---

## Implementation

### Logback configuration — structured JSON

`src/main/resources/logback-spring.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>

  <!-- Local development: human-readable output -->
  <springProfile name="local,test">
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
      <encoder>
        <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
      </encoder>
    </appender>
    <root level="DEBUG">
      <appender-ref ref="CONSOLE"/>
    </root>
  </springProfile>

  <!-- Production / staging / CI: structured JSON -->
  <springProfile name="!local &amp; !test">
    <appender name="JSON_CONSOLE"
              class="ch.qos.logback.core.ConsoleAppender">
      <encoder
          class="net.logstash.logback.encoder.LogstashEncoder">
        <includeMdcKeyName>request_id</includeMdcKeyName>
        <includeMdcKeyName>traceparent</includeMdcKeyName>
        <includeMdcKeyName>member_id</includeMdcKeyName>
        <includeMdcKeyName>service</includeMdcKeyName>
        <customFields>{"service":"${SERVICE_NAME}","version":"${SERVICE_VERSION}"}</customFields>
        <fieldNames>
          <timestamp>timestamp</timestamp>
          <message>message</message>
          <logger>logger</logger>
          <level>level</level>
          <thread>thread</thread>
        </fieldNames>
      </encoder>
    </appender>
    <root level="INFO">
      <appender-ref ref="JSON_CONSOLE"/>
    </root>
  </springProfile>

</configuration>
```

### Logger declaration

```java
// Correct
private static final Logger log =
    LoggerFactory.getLogger(StoreService.class);

// Wrong — string literal breaks refactoring
private static final Logger log =
    LoggerFactory.getLogger("StoreService");
```

### MDC — per-request correlation fields

```java
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class RequestContextFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        UUID requestId = UUID.randomUUID();
        MDC.put("request_id", requestId.toString());

        String traceparent = request.getHeader("traceparent");
        if (traceparent != null) {
            MDC.put("traceparent", traceparent);
            String tracestate = request.getHeader("tracestate");
            if (tracestate != null) {
                MDC.put("tracestate", tracestate);
            }
        }
        request.setAttribute("requestId", requestId);
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.clear();
        }
    }
}
```

Set the member ID in MDC after JWT validation:

```java
// In EbtokenAuthFilter, after successful token validation:
MDC.put("member_id", claims.getMemberGuid());
```

### Log level selection

| Situation | Level |
|-----------|-------|
| Request received, resource created, state transitioned | `INFO` |
| Operation succeeded but with a notable condition (retry, fallback used) | `WARN` |
| Unhandled exception; operation failed; alert-worthy condition | `ERROR` |
| Internal state useful for diagnosis (not enabled in production by default) | `DEBUG` |
| High-volume internal tracing (not enabled unless explicitly debugging) | `TRACE` |

```java
// INFO — normal operations
log.info("Store created storeId={}", store.getId());

// WARN — degraded but not failed
log.warn("DynamoDB throttled on table={} attempt={} retrying",
    tableName, attempt);

// ERROR — failure; alert-worthy
log.error("Failed to publish order event orderId={}", order.getId(), ex);

// DEBUG — diagnostic; disabled in production
log.debug("Evaluating discount rule ruleId={} memberId={}",
    rule.getId(), memberId);
```

### Structured log fields — parameterized messages

Never concatenate strings in log statements:

```java
// Correct — lazy evaluation, no string allocation when level is disabled
log.info("Order processed orderId={} memberId={} durationMs={}",
    order.getId(), order.getMemberId(), durationMs);

// Wrong — always allocates the string
log.debug("Order processed: " + order.getId()
    + " member: " + order.getMemberId());
```

For structured key-value fields use `StructuredArguments`:

```java
import static net.logstash.logback.argument.StructuredArguments.kv;

log.info("Payment processed {}", kv("payment_id", payment.getId()));
// Produces: {"message":"Payment processed","payment_id":"pay-123"}
```

### PII exclusion rules

Never log the following under any log level:

- Full credit card numbers, CVVs, or payment tokens
- Raw passwords or authentication secrets
- Social security numbers or national ID numbers
- Full member email addresses in production logs
- ebtoken JWT values (log only the parsed subject/memberId)

```java
// Wrong — logs full email
log.info("Member logged in email={}", member.getEmail());

// Correct — use ID only
log.info("Member logged in memberId={}", member.getId());

// Wrong — logs raw JWT
log.debug("Validating token={}", rawToken);

// Correct — log parsed subject only
log.debug("Validating token for memberId={}", claims.getSubject());
```

### SonarQube logging hygiene (SG-JAVA-CUSTOM-PROFILE-07-2025)

Blocking rules enforced in CI:

- `java:S2629` — Log arguments must not use string concatenation; use `{}` placeholders.
- `java:S3457` — Log arguments must not call `.toString()` explicitly.
- `java:S4792` — Logger configuration must not be adjustable from user-controlled input.
- Always log caught exceptions with `log.error("...", ex)` — never swallow silently.

---

## Verification

1. Start the service with the default profile and send a request — confirm log output
   is single-line JSON with `timestamp`, `level`, `message`, `request_id`, and
   `traceparent` fields.
2. Grep `src/main/java` for string concatenation inside `log.*()` calls — must be
   zero; all must use `{}` placeholders.
3. Grep for `MDC.put("request_id"` — confirm it is set in the filter and
   `MDC.clear()` is called in the `finally` block.
4. Send a request and check that `meta.operation.request_id` in the response matches
   `request_id` in the corresponding log lines.
5. Grep for `var ` in source files — must be zero.
6. Run `mvn checkstyle:check` — zero violations required.
