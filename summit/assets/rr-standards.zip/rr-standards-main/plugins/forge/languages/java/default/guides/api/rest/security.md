# Java Guide — REST API Security

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/security.md@1.0.0

## Overview

Shows how to satisfy the REST API Security standard in a Spring Boot 3.x service.
Covers Spring Security filter chains for JWT bearer token validation (ebtoken), euid
cookie authentication, and server-to-server token validation for sensitive `-int`
operations. A service that follows this guide enforces the correct authentication
mechanism on public, admin, and internal contract endpoints.

## Related standard

[REST API Security](../../../../../../standards/api/rest/security.md)

## Prerequisites

- Spring Boot 3.x with `spring-boot-starter-security`
- `io.jsonwebtoken:jjwt-api` and `jjwt-impl` (or the company JWT validation library)
- Familiarity with Spring Security `SecurityFilterChain` and `OncePerRequestFilter`

---

## Implementation

### Public endpoints with member data — ebtoken and euid cookie (R-1)

Endpoints that access member data must validate either an `Authorization: Bearer
<ebtoken>` header or an `euid` cookie. Configure a single `SecurityFilterChain` bean
per contract type. The filter validates JWT signature and expiry; the member identity
is extracted from claims and placed in the `SecurityContext`.

```java
@Configuration
@EnableWebSecurity
public class PublicContractSecurityConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain memberDataFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .securityMatcher("/offers/v1/**", "/store/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(
                new EbtokenAuthFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                // Endpoints that return only non-member data — no auth required
                .requestMatchers(HttpMethod.GET, "/store/v1/stores")
                    .permitAll()
                // All member-scoped paths require authentication
                .requestMatchers("/offers/v1/regions/*/members/**")
                    .authenticated()
                .anyRequest().permitAll())
            .build();
    }
}
```

The `EbtokenAuthFilter` handles both the Bearer header and the `euid` cookie:

```java
public class EbtokenAuthFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenAuthFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = extractToken(request);
        if (token != null) {
            try {
                MemberClaims claims = validator.validate(token);
                var auth = new MemberAuthentication(claims);
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch (InvalidTokenException ex) {
                SecurityContextHolder.clearContext();
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                    "Invalid or expired token");
                return;
            }
        }
        chain.doFilter(request, response);
    }

    private String extractToken(HttpServletRequest request) {
        // 1. Bearer header
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        // 2. euid cookie (browser clients)
        if (request.getCookies() != null) {
            for (Cookie cookie : request.getCookies()) {
                if ("euid".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}
```

Public endpoints with **no member data** require no authentication. Set them to
`permitAll()` in the filter chain (as shown for `/store/v1/stores` above).

### Admin contract endpoints — ebtoken with role validation (R-2)

Every operation on a `-admin` contract requires a valid ebtoken **and** the presence
of required roles in the JWT claims. Configure a separate `SecurityFilterChain` for
admin contracts.

```java
@Configuration
@EnableWebSecurity
public class AdminContractSecurityConfig {

    @Bean
    @Order(2)
    public SecurityFilterChain adminFilterChain(
        HttpSecurity http,
        EbtokenValidator ebtokenValidator) throws Exception {

        return http
            .securityMatcher("/store-admin/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(
                new EbtokenRoleFilter(ebtokenValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                .anyRequest().hasAuthority("ROLE_store_admin"))
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint(
                    (req, res, e) ->
                        res.sendError(HttpServletResponse.SC_UNAUTHORIZED))
                .accessDeniedHandler(
                    (req, res, e) ->
                        res.sendError(HttpServletResponse.SC_FORBIDDEN)))
            .build();
    }
}
```

The `EbtokenRoleFilter` extracts roles from JWT claims and sets them as granted
authorities, so Spring Security's `hasAuthority` check works:

```java
public class EbtokenRoleFilter extends OncePerRequestFilter {

    private final EbtokenValidator validator;

    public EbtokenRoleFilter(EbtokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Bearer token required");
            return;
        }
        try {
            AdminClaims claims = validator.validateAdmin(
                authHeader.substring(7));
            var authorities = claims.roles().stream()
                .map(r -> new SimpleGrantedAuthority("ROLE_" + r))
                .toList();
            var auth = new UsernamePasswordAuthenticationToken(
                claims.operatorId(), null, authorities);
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid or expired admin token");
            return;
        }
        chain.doFilter(request, response);
    }
}
```

### Sensitive internal endpoints — server-to-server auth (R-3)

Sensitive `-int` operations (balance modification, PII access, payment method changes,
account deletion) require a validated server-to-server token. Configure a dedicated
filter chain.

```java
@Configuration
@EnableWebSecurity
public class InternalContractSecurityConfig {

    @Bean
    @Order(3)
    public SecurityFilterChain internalFilterChain(
        HttpSecurity http,
        ServerToServerTokenValidator s2sValidator) throws Exception {

        return http
            .securityMatcher("/wallet-int/v1/**", "/pii-int/v1/**")
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(sm ->
                sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(
                new ServerToServerAuthFilter(s2sValidator),
                UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                .anyRequest().authenticated())
            .build();
    }
}
```

Sensitive operation categories that require `server_to_server` auth:
- `balance_modification` — `PATCH /wallet-int/v1/members/{member_id}/balance`
- `pii_access` — `GET /pii-int/v1/members/{member_id}/profile`
- `payment_method_change` — endpoints modifying payment instruments
- `account_deletion` — endpoints deleting member accounts

```java
public class ServerToServerAuthFilter extends OncePerRequestFilter {

    private final ServerToServerTokenValidator validator;

    public ServerToServerAuthFilter(ServerToServerTokenValidator validator) {
        this.validator = validator;
    }

    @Override
    protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String token = request.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Server-to-server token required");
            return;
        }
        try {
            ServiceIdentity identity = validator.validate(token.substring(7));
            var auth = new UsernamePasswordAuthenticationToken(
                identity.serviceId(), null,
                List.of(new SimpleGrantedAuthority("ROLE_service")));
            SecurityContextHolder.getContext().setAuthentication(auth);
        } catch (InvalidTokenException ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                "Invalid server-to-server token");
            return;
        }
        chain.doFilter(request, response);
    }
}
```

---

## Verification

1. Start the service and call a member-data endpoint without an `Authorization` header
   or `euid` cookie — confirm the response is `401 Unauthorized`.
2. Call the same endpoint with a valid ebtoken Bearer header — confirm `200 OK`.
3. Call an `-admin` endpoint with a token that lacks the required role — confirm
   `403 Forbidden`.
4. Call a sensitive `-int` endpoint without a server-to-server token — confirm
   `401 Unauthorized`.
5. Confirm no endpoint in a `-admin` contract is reachable with `200` without a valid
   token by reviewing `SecurityFilterChain` `securityMatcher` coverage.
6. Run `mvn checkstyle:check` — zero violations required.
