# Java Guide — DynamoDB

Guide: 1.0.0 | Implements: standards/storage/dynamodb.md@1.0.0

## Overview

Shows how to satisfy the DynamoDB standard in Java 21 using AWS SDK v2's
`DynamoDbEnhancedClient`. Covers `@DynamoDbBean` entity mapping, single-table key
design with the composite `{TYPE}#{id}` pattern, optimistic concurrency via the
`version` attribute, pagination with `lastEvaluatedKey`, and transaction support.
A DynamoDB repository that follows this guide stores data safely, avoids table scans,
and detects concurrent write conflicts.

## Related standard

[DynamoDB Standard](../../../../../../../standards/storage/dynamodb.md)

## Prerequisites

- AWS SDK v2: `software.amazon.awssdk:dynamodb-enhanced`
- Spring Boot 3.x DynamoDB auto-configuration (or manual `DynamoDbClient` bean)

Maven dependencies:

```xml
<dependency>
    <groupId>software.amazon.awssdk</groupId>
    <artifactId>dynamodb-enhanced</artifactId>
</dependency>
```

---

## Implementation

### Client configuration

```java
@Configuration
public class DynamoDbConfig {

    @Bean
    public DynamoDbClient dynamoDbClient(
        @Value("${aws.region}") String region) {

        return DynamoDbClient.builder()
            .region(Region.of(region))
            .build();
    }

    @Bean
    public DynamoDbEnhancedClient dynamoDbEnhancedClient(
        DynamoDbClient client) {

        return DynamoDbEnhancedClient.builder()
            .dynamoDbClient(client)
            .build();
    }
}
```

### Entity mapping — `@DynamoDbBean` (naming conventions)

Field names stored in DynamoDB use `snake_case` (per the standard). Map Java
camelCase fields to snake_case DynamoDB attribute names using `@DynamoDbAttribute`.

```java
@DynamoDbBean
public class UserProfileItem {

    private String pk;            // "USER#<userId>"
    private String sk;            // "PROFILE"
    private String entityType;    // "USER_PROFILE"
    private Integer schemaVersion;
    private String userId;
    private String email;
    private String firstName;
    private String createdAt;     // ISO 8601 UTC string
    private String updatedAt;
    private Long version;         // optimistic concurrency

    @DynamoDbPartitionKey
    @DynamoDbAttribute("pk")
    public String getPk() { return pk; }
    public void setPk(String pk) { this.pk = pk; }

    @DynamoDbSortKey
    @DynamoDbAttribute("sk")
    public String getSk() { return sk; }
    public void setSk(String sk) { this.sk = sk; }

    @DynamoDbAttribute("entity_type")
    public String getEntityType() { return entityType; }
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    @DynamoDbAttribute("schema_version")
    public Integer getSchemaVersion() { return schemaVersion; }
    public void setSchemaVersion(Integer schemaVersion) {
        this.schemaVersion = schemaVersion;
    }

    @DynamoDbAttribute("user_id")
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    @DynamoDbAttribute("email")
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @DynamoDbAttribute("first_name")
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @DynamoDbAttribute("created_at")
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @DynamoDbAttribute("updated_at")
    public String getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @DynamoDbVersionAttribute          // enables SDK-managed optimistic concurrency
    @DynamoDbAttribute("version")
    public Long getVersion() { return version; }
    public void setVersion(Long version) { this.version = version; }
}
```

### Single-table key design

Use composite PK format `{ENTITY_TYPE}#{identifier}` and SK to express
hierarchical relationships.

```java
// Key constants — centralize to avoid string scatter
public final class TableKeys {
    public static String userPk(String userId) {
        return "USER#" + userId;
    }
    public static String orderPk(String orderId) {
        return "ORDER#" + orderId;
    }
    public static final String PROFILE_SK = "PROFILE";
    public static String orderSk(String date, String sequence) {
        return "ORDER#" + date + "#" + sequence;
    }
}
```

### Repository — CRUD operations

```java
@Repository
public class UserProfileRepository {

    private static final String TABLE_NAME = "prod_users_profiles";

    private final DynamoDbTable<UserProfileItem> table;

    public UserProfileRepository(DynamoDbEnhancedClient client) {
        this.table = client.table(TABLE_NAME,
            TableSchema.fromBean(UserProfileItem.class));
    }

    public Optional<UserProfileItem> findByUserId(String userId) {
        var key = Key.builder()
            .partitionValue(TableKeys.userPk(userId))
            .sortValue(TableKeys.PROFILE_SK)
            .build();
        return Optional.ofNullable(table.getItem(key));
    }

    public void save(UserProfileItem item) {
        // version is managed by @DynamoDbVersionAttribute —
        // first put sets version=1; subsequent puts auto-increment and
        // throw ConditionalCheckFailedException on conflict
        table.putItem(item);
    }

    public void update(UserProfileItem item) {
        // updateItem also checks the version attribute automatically
        table.updateItem(item);
    }

    public void delete(String userId) {
        var key = Key.builder()
            .partitionValue(TableKeys.userPk(userId))
            .sortValue(TableKeys.PROFILE_SK)
            .build();
        table.deleteItem(key);
    }
}
```

### Optimistic concurrency (per standard)

The `@DynamoDbVersionAttribute` annotation on the `version` field instructs the
enhanced client to add a condition expression on every `putItem` / `updateItem`
call. If the condition fails, the SDK throws `ConditionalCheckFailedException`.

Map that to the application's `VersionConflictException` in the repository or service:

```java
public void updateProfile(UserProfileItem item) {
    try {
        table.updateItem(item);
    } catch (ConditionalCheckFailedException ex) {
        // Re-read the current state so the caller can retry with the latest version
        UserProfileItem current = findByUserId(item.getUserId())
            .orElseThrow(() -> new ResourceNotFoundException(item.getUserId()));
        throw new VersionConflictException(current);
    }
}
```

### Query operations — avoid scans

Always specify the partition key. Use `QueryConditional` for range queries on the
sort key. Never use `Scan` in a request path.

```java
// Correct — query by partition key
public List<UserProfileItem> findOrdersForUser(String userId) {
    var queryConditional = QueryConditional.keyEqualTo(
        Key.builder()
            .partitionValue(TableKeys.userPk(userId))
            .build());

    return table.query(queryConditional)
        .items()
        .stream()
        .toList();
}

// Correct — sort key range (e.g., orders between two dates)
public List<UserProfileItem> findOrdersBetween(
    String userId, String startDate, String endDate) {

    var queryConditional = QueryConditional.sortBetween(
        Key.builder()
            .partitionValue(TableKeys.userPk(userId))
            .sortValue("ORDER#" + startDate)
            .build(),
        Key.builder()
            .partitionValue(TableKeys.userPk(userId))
            .sortValue("ORDER#" + endDate + "\uFFFF")   // inclusive end
            .build());

    return table.query(queryConditional)
        .items()
        .stream()
        .toList();
}

// Wrong — never use scan in the request path
// table.scan().items().forEach(...);  // full table read — prohibited
```

### Pagination with `lastEvaluatedKey`

Use the SDK's built-in `SdkIterable` and respect the `limit` parameter to avoid
returning unbounded results.

```java
public PageResult<UserProfileItem> listOrders(
    String userId, int limit, @Nullable Map<String, AttributeValue> cursor) {

    var queryRequest = QueryEnhancedRequest.builder()
        .queryConditional(QueryConditional.keyEqualTo(
            Key.builder()
                .partitionValue(TableKeys.userPk(userId))
                .build()))
        .limit(limit)
        .exclusiveStartKey(cursor)
        .build();

    Page<UserProfileItem> page = table.query(queryRequest)
        .stream()
        .findFirst()
        .orElseThrow();

    return new PageResult<>(
        page.items(),
        page.lastEvaluatedKey());   // null on the last page
}
```

### Timestamps — ISO 8601 UTC strings

Store all timestamps as ISO 8601 UTC strings (not epoch integers):

```java
item.setCreatedAt(Instant.now().toString());  // "2024-06-15T09:30:00Z"
item.setUpdatedAt(Instant.now().toString());
```

### DynamoDB Local in integration tests

```java
@Testcontainers
class UserProfileRepositoryIntegrationTest {

    @Container
    static GenericContainer<?> dynamoDbLocal =
        new GenericContainer<>("amazon/dynamodb-local:2.3.0")
            .withExposedPorts(8000)
            .withCommand("-jar DynamoDBLocal.jar -inMemory -sharedDb");

    private DynamoDbEnhancedClient client;
    private UserProfileRepository repository;

    @BeforeEach
    void setup() {
        String endpoint = "http://localhost:" +
            dynamoDbLocal.getMappedPort(8000);

        DynamoDbClient rawClient = DynamoDbClient.builder()
            .endpointOverride(URI.create(endpoint))
            .region(Region.US_EAST_1)
            .credentialsProvider(StaticCredentialsProvider.create(
                AwsBasicCredentials.create("fakeKey", "fakeSecret")))
            .build();

        client = DynamoDbEnhancedClient.builder()
            .dynamoDbClient(rawClient)
            .build();

        // Create the table before each test
        DynamoDbTable<UserProfileItem> table = client.table(
            "test_users_profiles",
            TableSchema.fromBean(UserProfileItem.class));
        table.createTable(CreateTableEnhancedRequest.builder()
            .provisionedThroughput(
                ProvisionedThroughput.builder()
                    .readCapacityUnits(5L)
                    .writeCapacityUnits(5L)
                    .build())
            .build());

        repository = new UserProfileRepository(client);
    }

    @Test
    void givenSavedUser_whenFindById_thenReturnsUser() {
        var item = new UserProfileItem();
        item.setPk("USER#test-1");
        item.setSk("PROFILE");
        item.setEntityType("USER_PROFILE");
        item.setSchemaVersion(1);
        item.setUserId("test-1");
        item.setEmail("user@example.com");
        item.setCreatedAt(Instant.now().toString());

        repository.save(item);
        Optional<UserProfileItem> found = repository.findByUserId("test-1");

        assertThat(found).isPresent();
        assertThat(found.get().getEmail()).isEqualTo("user@example.com");
    }
}
```

---

## Verification

1. Grep for `table.scan()` in production source code — no calls allowed in
   request-path code; only in background migration jobs.
2. Inspect every `@DynamoDbBean` class and confirm a `@DynamoDbVersionAttribute`
   field is present on any entity that supports writes.
3. Confirm every `@DynamoDbAttribute` annotation uses `snake_case`.
4. Confirm every timestamp stored as a DynamoDB String attribute contains an ISO 8601
   value (not a `long` epoch).
5. Run integration tests against DynamoDB Local — all must pass.
6. Run `mvn checkstyle:check` — zero violations required.
