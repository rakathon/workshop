# Observability — Java 8 Guides

## Directory purpose

Java 8 observability implementation guides. SLF4J, Logback, and
logstash-logback-encoder all support Java 8; the logging guide is substantively
identical to the Java 21 version with `javax.*` imports and no `var`.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `logging.md` | SLF4J + Logback structured JSON logging; MDC correlation fields; log levels; PII exclusion rules | Any logging code is being authored or reviewed |

## Navigation

- [Java 8 root](../../AGENTS.md)
- [Observability standards](../../../../../../../standards/observability/)
