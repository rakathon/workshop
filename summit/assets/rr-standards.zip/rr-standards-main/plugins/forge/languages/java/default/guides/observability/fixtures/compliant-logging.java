// Compliant logging — parameterized messages, MDC, no PII
@Component
public class RequestContextFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
        throws ServletException, IOException {
        UUID requestId = UUID.randomUUID();
        MDC.put("request_id", requestId.toString());         // correlation
        String traceparent = req.getHeader("traceparent");
        if (traceparent != null) MDC.put("traceparent", traceparent);
        req.setAttribute("requestId", requestId);
        try {
            chain.doFilter(req, res);
        } finally {
            MDC.clear();  // always clear to prevent cross-request contamination
        }
    }
}

@Service
public class OrderService {
    private static final Logger log = LoggerFactory.getLogger(OrderService.class);

    public Order create(CreateOrderRequest request) {
        // Correct: {} placeholder, no string concat, no PII
        log.info("Creating order for memberId={}", request.memberId());

        Order order = repository.save(new Order(request));

        // Correct: structured args, no email/password logged
        log.info("Order created orderId={} memberId={}", order.id(), request.memberId());
        return order;
    }

    public void processPayment(Order order) {
        try {
            paymentClient.charge(order);
        } catch (PaymentException ex) {
            // Correct: ERROR level with exception, no payment token logged
            log.error("Payment failed for orderId={}", order.id(), ex);
            throw ex;
        }
    }
}
