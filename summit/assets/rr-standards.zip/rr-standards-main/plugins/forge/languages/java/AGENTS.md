# Java Language Guides

## Directory purpose

Contains Java implementation guides for rr-standards. The directory is organized by
Java version because significant language and API differences between Java 8 and modern
Java (21 LTS) affect how several standards are implemented in practice. Choose the
subdirectory that matches the Java version of the service you are working on.

## File index

| Directory | Purpose | When to reference |
|-----------|---------|-------------------|
| `default/` | Java 21 LTS guides — Spring Boot 3.x, Jakarta EE, records, var | Default choice for all new services and any service on Java 11 or later |
| `8/` | Java 8 compatibility notes — patterns that differ on legacy Java 8 services | Only when the target runtime is pinned to Java 8 |

## Navigation

- [Languages root](../AGENTS.md) — all language guides
- [Standards root](../../standards/) — the language-agnostic standards these guides implement
