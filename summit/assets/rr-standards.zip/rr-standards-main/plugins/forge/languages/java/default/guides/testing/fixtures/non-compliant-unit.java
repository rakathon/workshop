// Non-compliant unit test — multiple violations
@SpringBootTest  // WRONG: uses full Spring context for a unit test (slow, not isolated)
class OrderServiceTest {

    @Autowired
    private OrderService orderService;  // real bean, not unit under test with mocked deps

    // WRONG: Instant.now() called directly — non-deterministic
    @Test
    void testCreateOrder() {
        Order order = orderService.create(new CreateOrderRequest("m-1"));
        // WRONG: two derived values compared (circular logic)
        Order expected = orderService.findById(order.getId());
        assertThat(order.getCreatedAt()).isEqualTo(expected.getCreatedAt());
        // WRONG: multiple actions in one test
        orderService.cancel(order.getId());
        assertThat(orderService.findById(order.getId()).getStatus()).isEqualTo(CANCELLED);
    }

    // WRONG: vague test name
    @Test
    void test1() {
        // Mocking internal domain object — violates "don't mock internals" rule
        Money price = mock(Money.class);
        when(price.getAmount()).thenReturn(100L);
        assertThat(orderService.calculateTax(price)).isGreaterThan(0);
    }
}
