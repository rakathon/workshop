// WRONG: missing //go:build e2e tag — this file will be compiled in normal `go test ./...` runs.

package api

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestPointsWorkflow(t *testing.T) {
	// WRONG: httptest.NewServer starts a local fake server — this is not E2E testing.
	// E2E tests must call the real deployed service at the URL from e2e.properties.
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	server := httptest.NewServer(handler)
	defer server.Close()

	// WRONG: hardcoded localhost URL instead of loading from testConfig.BaseURL.
	resp, err := http.Get("http://localhost:8080/points/v1/members/member-1/balance")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()

	// WRONG: no assertStatus helper — raw status check with no diagnostic output on failure.
	if resp.StatusCode != 200 {
		t.Fail()
	}
	// WRONG: no t.Cleanup for test data teardown.
}

// WRONG: function not named Test<WorkflowName> — Go test runner will not discover it.
// WRONG: no //go:build e2e tag.
func RunSmokeCheck(t *testing.T) {
	// WRONG: uses testConfig without checking if suite was initialised (no TestMain guard).
	resp, _ := http.Get(testConfig.BaseURL + "/health")
	if resp.StatusCode != 200 {
		t.Error("health check failed")
	}
	// WRONG: response body never closed — resource leak.
}
