//go:build e2e

package api

import (
	"fmt"
	"net/http"
	"os"
	"testing"
	"time"
)

// TestSC1_EarnAndVerifyPoints validates the earn-points flow against the real deployed service.
// Non-production only — creates and deletes test transactions.
func TestSC1_EarnAndVerifyPoints(t *testing.T) {
	env := os.Getenv("ENVIRONMENT_TO_TEST")
	if env == "" {
		env = "local"
	}
	if env == "production" {
		t.Skip("SC-1 creates test data — skipping in production environment")
	}

	base := testConfig.BaseURL

	// Unique per test run — parallel-safe, traceable synthetic data (R-4, R-8)
	memberID := fmt.Sprintf("test-member-%d", time.Now().UnixNano())

	// Step 1: Capture pre-earn balance
	var balanceResp struct {
		Data struct {
			Balance int `json:"balance"`
		} `json:"data"`
	}
	resp := doGet(t, urlJoin(base, "/points/v1/members/"+memberID+"/balance"),
		bearerAuth(testConfig.AuthToken),
	)
	assertStatus(t, resp, http.StatusOK)
	parseJSON(t, resp, &balanceResp)
	beforeBalance := balanceResp.Data.Balance

	// Step 2: Earn points via a qualifying transaction
	var earnResp struct {
		Data struct {
			TransactionID string `json:"transaction_id"`
			PointsEarned  int    `json:"points_earned"`
		} `json:"data"`
	}
	resp = doPost(t, urlJoin(base, "/points/v1/members/"+memberID+"/transactions"),
		map[string]any{"amount_cents": 1000, "merchant_id": "merchant-e2e"},
		bearerAuth(testConfig.AuthToken),
	)
	assertStatus(t, resp, http.StatusCreated)
	parseJSON(t, resp, &earnResp)

	if earnResp.Data.TransactionID == "" {
		t.Fatal("expected non-empty transaction_id")
	}
	if earnResp.Data.PointsEarned <= 0 {
		t.Errorf("expected points_earned > 0, got %d", earnResp.Data.PointsEarned)
	}

	// Register cleanup immediately after resource creation — runs even if later assertions fail
	t.Cleanup(func() {
		resp := doDelete(t,
			urlJoin(base, "/points/v1/members/"+memberID+"/transactions/"+earnResp.Data.TransactionID),
			bearerAuth(testConfig.AuthToken),
		)
		resp.Body.Close()
	})

	// Step 3: Verify the balance increased by the earned points (complete observable journey)
	resp = doGet(t, urlJoin(base, "/points/v1/members/"+memberID+"/balance"),
		bearerAuth(testConfig.AuthToken),
	)
	assertStatus(t, resp, http.StatusOK)
	parseJSON(t, resp, &balanceResp)

	expected := beforeBalance + earnResp.Data.PointsEarned
	if balanceResp.Data.Balance != expected {
		t.Errorf("expected balance %d after earn, got %d", expected, balanceResp.Data.Balance)
	}
}

// TestSmokeHealthEndpoint confirms the service is reachable before running scenario tests.
// Safe in all environments — read-only.
func TestSmokeHealthEndpoint(t *testing.T) {
	resp := doGet(t, urlJoin(testConfig.BaseURL, "/health"), nil)
	assertStatus(t, resp, http.StatusOK)
	resp.Body.Close()
}
