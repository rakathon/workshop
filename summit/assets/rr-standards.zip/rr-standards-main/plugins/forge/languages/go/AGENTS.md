# languages/go/

This directory contains language-specific implementation guides for Go. Each guide shows how to implement a companion language-agnostic standard using idiomatic Go and the libraries chosen by this project. Guides are organised under `guides/<domain>/` to mirror the structure of the `standards/` directory.

## File index

| File | Purpose | When to reference |
|---|---|---|
| `guides/` | Language-specific implementation guides, organised by domain, mirroring the `standards/` directory structure | When looking for Go implementation guidance for a specific standard domain |
| `guides/observability/logging.md` | Go implementation of the logging standard — ZeroLog patterns, field constants, context propagation, and error enrichment | When generating or reviewing any logging instrumentation in Go |
| `guides/observability/logging.test.yaml` | Golden examples for behavioral validation of the Go logging guide — compliant and non-compliant ZeroLog snippets | When running behavioral effectiveness tests or adding new test cases for the Go logging guide |
| `guides/testing/e2e.md` | Go E2E testing guide — stdlib testing + net/http, config.go, TestMain, HTTP helpers, build tags | When generating or reviewing E2E tests for a Go service |
| `guides/testing/e2e.test.yaml` | Golden examples for behavioral validation of the Go E2E testing guide — compliant and non-compliant test snippets | When running behavioral effectiveness tests or adding new test cases for the Go E2E guide |

## Navigation

- [Standards taxonomy](../../standards/TAXONOMY.md) — artifact types, naming conventions, and directory structure for this plugin
- [Logging standard](../../standards/observability/logging.md) — language-agnostic rules that the Go guides implement

## Linter

**Linter:** `golangci-lint`
**Config file:** `.golangci.yml` at the repository root

All Go code generated from guides in this directory must pass `golangci-lint run`. Individual guides must not restate lint rules — this is the single authoritative linter declaration for Go in this plugin.
