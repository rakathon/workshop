# Go Guide — End-to-End Testing

Guide: 1.0.1 | Implements: standards/testing/e2e.md@1.0.0

## Overview

Shows how to write end-to-end tests for a Go HTTP service using the stdlib `testing`
package and `net/http`. E2E tests issue real HTTP requests against a **deployed service
instance** (local, QA, lt1, prod, or any other configured environment) and validate
observable HTTP behaviour.
These tests do not start the application, do not use Testcontainers, and do not use
`httptest`. They work with any Go HTTP framework (Echo, gin, chi, stdlib `net/http`).

**E2E vs Integration Testing:**

| Aspect | E2E (this guide) | Integration |
|---|---|---|
| Target | Real deployed service via HTTP | `httptest.NewServer` + local containers |
| Dependencies | stdlib only | testify, Testcontainers |
| Location | `tests/system/e2e/api/` | `tests/integration/` |
| Build tag | `//go:build e2e` | `//go:build integration` |

## Related standard

[E2E Testing Standard](../../../../standards/testing/e2e.md)

## Prerequisites

- Go 1.21+
- No new dependencies — E2E tests use only stdlib packages:
  `testing`, `net/http`, `encoding/json`, `bufio`, `os`, `fmt`, `bytes`, `io`, `strings`, `time`, `log`

---

## HTTP request/response logging

Every HTTP call is automatically logged via `t.Logf` so the output is captured by
`gotestsum` into the JUnit XML `<system-out>` element for that specific test case.
No per-test boilerplate is required — the helpers call `logAPICall` before returning.

---

## Implementation

### Framework detection file

The presence of this file indicates the E2E framework is already installed:
```text
tests/system/e2e/api/suite_test.go
```

If this file exists, add tests only (ADD_TEST_ONLY mode). If absent, generate the complete framework (FULL_FRAMEWORK mode).

---

### Full framework setup (FULL_FRAMEWORK mode)

Generate these files in `tests/system/e2e/api/`:

#### `config.go` — Config struct and loader

```go
//go:build e2e

package api

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// Config holds non-sensitive configuration loaded from e2e.properties
// and secrets loaded from environment variables.
type Config struct {
	BaseURL  string
	APIKey   string // loaded from API_KEY env var (empty if not set)
	AuthToken string // loaded from AUTH_TOKEN env var (empty if not set)
}

// testConfig is the package-level config used by all test functions.
var testConfig *Config

func loadConfig() (*Config, error) {
	env := os.Getenv("ENVIRONMENT_TO_TEST")
	if env == "" {
		env = "local"
	}

	props, err := loadPropertiesFile("testdata/e2e.properties")
	if err != nil {
		return nil, fmt.Errorf("loading e2e.properties: %w", err)
	}

	baseURL, ok := props["base.url."+env]
	if !ok {
		return nil, fmt.Errorf("base.url.%s not found in e2e.properties", env)
	}

	return &Config{
		BaseURL:   baseURL,
		APIKey:    os.Getenv("API_KEY"),
		AuthToken: os.Getenv("AUTH_TOKEN"),
	}, nil
}

func loadPropertiesFile(path string) (map[string]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	props := make(map[string]string)
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) == 2 {
			props[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
		}
	}
	return props, scanner.Err()
}
```

> **Note:** `config.go` must NOT have the `_test.go` suffix — Go would treat it as a
> separate package from the other `_test.go` files. The `//go:build e2e` tag keeps it
> out of normal builds.

#### `suite_test.go` — `TestMain` for suite-level setup

```go
//go:build e2e

package api

import (
	"log"
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	cfg, err := loadConfig()
	if err != nil {
		// Graceful skip — not a test failure.
		// Missing config means the environment is not available; don't fail CI.
		log.Printf("E2E tests skipped: %v", err)
		os.Exit(0)
	}
	testConfig = cfg
	os.Exit(m.Run())
}
```

#### `helpers_test.go` — HTTP helpers

```go
//go:build e2e

package api

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"
)

var httpClient = &http.Client{Timeout: 30 * time.Second}

// logAPICall logs the request and response for every HTTP call via t.Logf so the
// output is captured by gotestsum into the JUnit XML <system-out> element.
func logAPICall(t *testing.T, req *http.Request, reqBody []byte, resp *http.Response) {
	t.Helper()
	respBody, _ := io.ReadAll(resp.Body)
	resp.Body = io.NopCloser(bytes.NewReader(respBody))
	entry := map[string]any{
		"test":             t.Name(),
		"method":           req.Method,
		"url":              req.URL.String(),
		"request_headers":  req.Header,
		"request_body":     string(reqBody),
		"status_code":      resp.StatusCode,
		"response_headers": resp.Header,
		"response_body":    string(respBody),
	}
	b, _ := json.Marshal(entry)
	t.Logf("api_call: %s", b)
}

func doGet(t *testing.T, url string, headers map[string]string) *http.Response {
	t.Helper()
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		t.Fatalf("doGet: new request: %v", err)
	}
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doGet %s: %v", url, err)
	}
	logAPICall(t, req, nil, resp)
	return resp
}

func doPost(t *testing.T, url string, body any, headers map[string]string) *http.Response {
	t.Helper()
	b, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("doPost: marshal body: %v", err)
	}
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(b))
	if err != nil {
		t.Fatalf("doPost: new request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doPost %s: %v", url, err)
	}
	logAPICall(t, req, b, resp)
	return resp
}

func doPut(t *testing.T, url string, body any, headers map[string]string) *http.Response {
	t.Helper()
	b, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("doPut: marshal body: %v", err)
	}
	req, err := http.NewRequest(http.MethodPut, url, bytes.NewReader(b))
	if err != nil {
		t.Fatalf("doPut: new request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doPut %s: %v", url, err)
	}
	logAPICall(t, req, b, resp)
	return resp
}

func doDelete(t *testing.T, url string, headers map[string]string) *http.Response {
	t.Helper()
	req, err := http.NewRequest(http.MethodDelete, url, nil)
	if err != nil {
		t.Fatalf("doDelete: new request: %v", err)
	}
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doDelete %s: %v", url, err)
	}
	logAPICall(t, req, nil, resp)
	return resp
}

// assertStatus fails the test with response body context if the status doesn't match.
func assertStatus(t *testing.T, resp *http.Response, expected int) {
	t.Helper()
	if resp.StatusCode != expected {
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		t.Fatalf("expected status %d, got %d: %s", expected, resp.StatusCode, string(body))
	}
}

// parseJSON decodes the response body into v and closes the body.
func parseJSON(t *testing.T, resp *http.Response, v any) {
	t.Helper()
	defer resp.Body.Close()
	if err := json.NewDecoder(resp.Body).Decode(v); err != nil {
		t.Fatalf("parseJSON: %v", err)
	}
}

// urlJoin joins a base URL and a path, avoiding double slashes.
func urlJoin(base, path string) string {
	return strings.TrimRight(base, "/") + "/" + strings.TrimLeft(path, "/")
}

// bearerAuth returns an Authorization: Bearer header map.
func bearerAuth(token string) map[string]string {
	return map[string]string{"Authorization": fmt.Sprintf("Bearer %s", token)}
}

// apiKeyAuth returns an X-API-Key header map.
func apiKeyAuth(key string) map[string]string {
	return map[string]string{"X-API-Key": key}
}

// tokenAuth returns an Authorization header map using the raw token value.
// Use when the service reads the Authorization header directly without
// a "Bearer " prefix (common in internal API key patterns).
func tokenAuth(token string) map[string]string {
	return map[string]string{"Authorization": token}
}
```

#### `testdata/e2e.properties` — environment URLs

```properties
# E2E Test Configuration — non-sensitive values only
# Sensitive values (API keys, tokens) go in environment variables
# Set ENVIRONMENT_TO_TEST to any configured environment name before running tests
# Environment names are arbitrary — add entries for every environment the project uses

base.url.local=http://localhost:8080
base.url.qa=https://api-qa.example.com
base.url.lt1=https://api-lt1.example.com
base.url.prod=https://api.example.com
```

Add entries only for the environments the project uses.

---

### Adding a test (ADD_TEST_ONLY mode)

Read existing `config.go` to understand the `Config` struct fields. Generate only the
new test file following the existing patterns.

```go
//go:build e2e

package api

import (
	"net/http"
	"testing"
)

// TestSC<N>_<Description> validates SC-N against the real deployed service.
func TestSC<N>_<Description>(t *testing.T) {
	base := testConfig.BaseURL

	// Step 1: First API call
	var step1Resp struct {
		Data struct {
			ID string `json:"id"`
		} `json:"data"`
	}
	resp := doPost(t, urlJoin(base, "/api/v1/resource"), map[string]any{
		"field": "value",
	}, nil)
	assertStatus(t, resp, http.StatusCreated)
	parseJSON(t, resp, &step1Resp)

	resourceID := step1Resp.Data.ID
	if resourceID == "" {
		t.Fatal("expected non-empty resource ID")
	}

	// Clean up test data when the test ends
	t.Cleanup(func() {
		resp := doDelete(t, urlJoin(base, "/api/v1/resource/"+resourceID), nil)
		resp.Body.Close()
	})

	// Step 2: Follow-up call
	var step2Resp struct {
		Data struct {
			ID    string `json:"id"`
			Field string `json:"field"`
		} `json:"data"`
	}
	resp = doGet(t, urlJoin(base, "/api/v1/resource/"+resourceID), nil)
	assertStatus(t, resp, http.StatusOK)
	parseJSON(t, resp, &step2Resp)

	if step2Resp.Data.ID != resourceID {
		t.Errorf("expected resource ID %q, got %q", resourceID, step2Resp.Data.ID)
	}
}
```

**With authentication:**
```go
// Bearer token
resp := doGet(t, url, bearerAuth(testConfig.AuthToken))

// API key
resp := doGet(t, url, apiKeyAuth(testConfig.APIKey))

// Raw token (Authorization header, no Bearer prefix)
resp := doGet(t, url, tokenAuth(testConfig.AuthToken))
```

**Smoke test naming (health/readiness checks only — not scenario tests):**
```go
// Prefix with TestSmoke for easy filtering of non-scenario health checks
func TestSmokeHealthEndpoint(t *testing.T) { ... }
```

**File naming:**
- `sc<n>_<description>_e2e_test.go` — e.g., `sc1_earn_points_e2e_test.go`
- Function: `TestSC<N>_<Description>` — e.g., `TestSC1_EarnPointsReturns201`

---

### Configuration

Non-sensitive values live in `tests/system/e2e/api/testdata/e2e.properties`, keyed by
environment. Secrets are read from environment variables at suite startup. Never commit
secrets to `e2e.properties`.

The `ENVIRONMENT_TO_TEST` environment variable selects the environment (defaults to
`local` if not set). The value is arbitrary — any name is valid as long as a matching
`base.url.<name>` entry exists in `e2e.properties` (e.g. `qa1`, `lt1`, `qa1geo1`).

**Production guard (R-3):** Tests that create or mutate data must skip in production.
Add this check at the top of any test that writes data:

```go
if os.Getenv("ENVIRONMENT_TO_TEST") == "production" {
    t.Skip("skipping destructive test in production")
}
```

---

### Running the tests

```bash
# Set environment (optional — defaults to local)
export ENVIRONMENT_TO_TEST=local

# Run all E2E tests
go test -tags=e2e -v ./tests/system/e2e/api/...

# Run only smoke tests
go test -tags=e2e -v -run TestSmoke ./tests/system/e2e/api/...

# Run a specific scenario test
go test -tags=e2e -v -run TestSC1 ./tests/system/e2e/api/...

# Run against lt1
ENVIRONMENT_TO_TEST=lt1 go test -tags=e2e -v ./tests/system/e2e/api/...

# Run against any environment
ENVIRONMENT_TO_TEST=qa1geo1 go test -tags=e2e -v ./tests/system/e2e/api/...

# With auth token
AUTH_TOKEN=your-token go test -tags=e2e -v ./tests/system/e2e/api/...
```

**Makefile targets (optional):**
```makefile
.PHONY: e2e e2e-smoke

e2e:
	ENVIRONMENT_TO_TEST=$(ENV) go test -tags=e2e -v ./tests/system/e2e/api/...

e2e-smoke:
	ENVIRONMENT_TO_TEST=$(ENV) go test -tags=e2e -v -run "TestSC|TestSmoke" ./tests/system/e2e/api/...
```

---

## Verification

1. Confirm all files in `tests/system/e2e/api/` have `//go:build e2e` as the first line.
2. Confirm all files declare `package api`.
3. Confirm `config.go` does NOT have the `_test.go` suffix.
4. Confirm `TestMain` in `suite_test.go` uses `os.Exit(0)` on config error (graceful skip).
5. Confirm no Testcontainers or `httptest.NewServer` usage.
6. Confirm `testdata/e2e.properties` contains entries for all configured environments.
7. Confirm `helpers_test.go` contains `logAPICall`.
8. Confirm all HTTP helpers (`doGet`, `doPost`, `doPut`, `doDelete`) call `logAPICall` before returning.
9. Run `go test -tags=e2e -v ./tests/system/e2e/api/...` — tests must pass or skip cleanly.
10. Run `go test ./...` (without e2e tag) — E2E files must be excluded from normal builds.
