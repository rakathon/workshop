//go:build e2e

package api

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"
)

var httpClient = &http.Client{Timeout: 30 * time.Second}

// logAPICall logs the request and response for every HTTP call via t.Logf so the
// output is captured by gotestsum into the JUnit XML <system-out> element.
func logAPICall(t *testing.T, req *http.Request, reqBody []byte, resp *http.Response) {
	t.Helper()
	respBody, _ := io.ReadAll(resp.Body)
	resp.Body = io.NopCloser(bytes.NewReader(respBody))
	entry := map[string]any{
		"test":             t.Name(),
		"method":           req.Method,
		"url":              req.URL.String(),
		"request_headers":  req.Header,
		"request_body":     string(reqBody),
		"status_code":      resp.StatusCode,
		"response_headers": resp.Header,
		"response_body":    string(respBody),
	}
	b, _ := json.Marshal(entry)
	t.Logf("api_call: %s", b)
}

func doGet(t *testing.T, url string, headers map[string]string) *http.Response {
	t.Helper()
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		t.Fatalf("doGet: new request: %v", err)
	}
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doGet %s: %v", url, err)
	}
	logAPICall(t, req, nil, resp)
	return resp
}

func doPost(t *testing.T, url string, body any, headers map[string]string) *http.Response {
	t.Helper()
	b, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("doPost: marshal body: %v", err)
	}
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(b))
	if err != nil {
		t.Fatalf("doPost: new request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doPost %s: %v", url, err)
	}
	logAPICall(t, req, b, resp)
	return resp
}

func doPut(t *testing.T, url string, body any, headers map[string]string) *http.Response {
	t.Helper()
	b, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("doPut: marshal body: %v", err)
	}
	req, err := http.NewRequest(http.MethodPut, url, bytes.NewReader(b))
	if err != nil {
		t.Fatalf("doPut: new request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doPut %s: %v", url, err)
	}
	logAPICall(t, req, b, resp)
	return resp
}

func doDelete(t *testing.T, url string, headers map[string]string) *http.Response {
	t.Helper()
	req, err := http.NewRequest(http.MethodDelete, url, nil)
	if err != nil {
		t.Fatalf("doDelete: new request: %v", err)
	}
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		t.Fatalf("doDelete %s: %v", url, err)
	}
	logAPICall(t, req, nil, resp)
	return resp
}

func assertStatus(t *testing.T, resp *http.Response, expected int) {
	t.Helper()
	if resp.StatusCode != expected {
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		t.Fatalf("expected status %d, got %d: %s", expected, resp.StatusCode, string(body))
	}
}

func parseJSON(t *testing.T, resp *http.Response, v any) {
	t.Helper()
	defer resp.Body.Close()
	if err := json.NewDecoder(resp.Body).Decode(v); err != nil {
		t.Fatalf("parseJSON: %v", err)
	}
}

func urlJoin(base, path string) string {
	return strings.TrimRight(base, "/") + "/" + strings.TrimLeft(path, "/")
}

func bearerAuth(token string) map[string]string {
	return map[string]string{"Authorization": fmt.Sprintf("Bearer %s", token)}
}

func apiKeyAuth(key string) map[string]string {
	return map[string]string{"X-API-Key": key}
}

func tokenAuth(token string) map[string]string {
	return map[string]string{"Authorization": token}
}
