# Go Logging Guide

Guide: 1.1.0 | Implements: standards/observability/logging.md@1.1.0

## Overview

This guide shows how to implement the logging standard in Go using the ZeroLog library. Following it produces structured, context-enriched JSON logs that satisfy all ten rules in the companion standard.

## Related standard

- [Logging Standard](../../../../standards/observability/logging.md)

## Prerequisites

Add the following dependencies:

```go
import (
    "github.com/rs/zerolog"
    "github.com/rs/zerolog/log"
    "github.com/rs/zerolog/pkgerrors"
    "github.com/rs/zerolog/hlog" // for HTTP handlers
)
```

Initialise the logger once in `cmd/<service_name>/main.go`:

```go
func init() {
    zerolog.TimeFieldFormat = zerolog.TimeFormatUnix
    zerolog.ErrorStackMarshaler = pkgerrors.MarshalStack
    zerolog.SetGlobalLevel(zerolog.InfoLevel)
}
```

## Implementation

### Structured output and static messages (R-1, R-2, R-9)

Use ZeroLog's chained API. Never use `.Msgf()` or string concatenation in `.Msg()`. Message values must be lowercase.

```go
// correct — variable in field, static lowercase message
log.Ctx(ctx).Info().
    Int(constants.LogBatchID, batchID).
    Str(constants.LogStatus, "completed").
    Msg("batch processing finished")

// incorrect — variable in message
log.Ctx(ctx).Info().Msgf("batch %d processing finished with status %s", batchID, status)

// incorrect — uppercase message
log.Ctx(ctx).Info().Msg("Batch Processing Finished")
```

### Log field constants (R-3)

Define all field name constants in `internal/constants/log_constants.go` and import them everywhere. Never use ad-hoc string keys.

```go
const (
    LogMemberID          = "member_id"
    LogBatchID           = "batch_id"
    LogBundleID          = "bundle_id"
    LogPaymentID         = "payment_id"
    LogPaymentMethodID   = "payment_method_id"
    LogPaymentMethodName = "payment_method"
    LogStatus            = "state"
    LogPreviousStatus    = "previous_state"
    LogRegionID          = "region_id"
    LogHandler           = "handler"
    LogAppType           = "app_type"
)
```

```go
// correct
log.Ctx(ctx).Info().Int(constants.LogMemberID, memberID).Msg("withdrawal initiated")

// incorrect — ad-hoc key breaks cross-service queries
log.Ctx(ctx).Info().Int("user_id", memberID).Msg("withdrawal initiated")
```

### Context propagation (R-4)

Enrich the logger once at the handler or worker entry point using `WithContext()`. All downstream calls retrieve it via `log.Ctx(ctx)` — never call the global logger in business logic.

Implement `GetContextData()` on each handler/manager to declare its context fields:

```go
func (f PaypalFulfillment) GetContextData(ctx context.Context) map[string]any {
    return map[string]any{
        constants.LogBundleID:          f.data.BatchID,
        constants.LogPaymentMethodID:   constants.PaymentMethodPaypal,
        constants.LogPaymentMethodName: constants.GetPaymentMethodNameByID(constants.PaymentMethodPaypal),
    }
}
```

Enrich once; never repeat fields at individual call sites:

```go
// correct — enrich once at the top
func ProcessPayment(ctx context.Context, paymentID int) {
    l := log.With().
        Str(constants.LogRegionID, regionID).
        Str(constants.LogAppType, appType).
        Int(constants.LogPaymentID, paymentID).
        Logger()
    ctx = l.WithContext(ctx)

    log.Ctx(ctx).Info().Msg("processing started")
    log.Ctx(ctx).Info().Msg("processing completed")
}

// incorrect — fields repeated at every call site
func ProcessPayment(ctx context.Context, paymentID int) {
    log.Ctx(ctx).Info().
        Str(constants.LogRegionID, regionID).
        Int(constants.LogPaymentID, paymentID).
        Msg("processing started")
    log.Ctx(ctx).Info().
        Str(constants.LogRegionID, regionID).
        Int(constants.LogPaymentID, paymentID).
        Msg("processing completed")
}
```

### Error enrichment (R-5)

Use `.Err(err)` to attach the error object. ZeroLog captures the stack trace via `pkgerrors`. Use a static message — do not embed the error string in `.Msg()`.

```go
// correct
log.Ctx(ctx).Err(err).
    Str(constants.LogAccountID, accountID).
    Msg("failed to update bank account")

// incorrect — error string embedded in message
log.Ctx(ctx).Error().Msg("failed to update bank account: " + err.Error())
```

### Log level selection (R-6)

| Level | Method | When to use |
|---|---|---|
| debug | `.Debug()` | Cache operations, detailed diagnostics — disabled in production |
| info | `.Info()` | Normal operations, state transitions, successful completions |
| warn | `.Warn()` | Unexpected but recoverable situations |
| error | `.Err(err)` | Failures requiring investigation |
| fatal | `.Fatal()` | Unrecoverable errors requiring shutdown |

### Contextual completeness (R-10)

At each handler or worker entry point, include the identifiers of all entities in scope when enriching the context. The `GetContextData()` pattern is the idiomatic way to ensure this — every handler declares its relevant entity IDs once and they propagate automatically.

```go
// correct — all relevant entity IDs declared at entry point
ctx = hlog.FromRequest(r).With().
    Str(constants.LogHandler, "update_bank_account").
    Str(constants.LogRegionID, s.regionID).
    Int(constants.LogMemberID, req.MemberID).
    Str(constants.LogAccountID, accountID).
    Logger().
    WithContext(ctx)

// incorrect — entity IDs omitted; logs for this operation are not queryable by member or account
ctx = hlog.FromRequest(r).With().
    Str(constants.LogHandler, "update_bank_account").
    Logger().
    WithContext(ctx)
```

### Complete handler example

```go
func (s *Server) UpdateBankAccount(w http.ResponseWriter, r *http.Request) {
    ctx := r.Context()

    // enrich context at entry point (R-4)
    ctx = hlog.FromRequest(r).With().
        Str(constants.LogAppType, constants.LogAppPayment).
        Str(constants.LogRegionID, s.regionID).
        Str(constants.LogHandler, "update_bank_account").
        Logger().
        WithContext(ctx)

    accountID := chi.URLParam(r, "id")

    var req UpdateBankAccountRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        log.Ctx(ctx).Err(err).Msg("failed to decode request body")
        http.Error(w, "invalid request", http.StatusBadRequest)
        return
    }

    log.Ctx(ctx).Info().
        Str(constants.LogAccountID, accountID).
        Int(constants.LogMemberID, req.MemberID).
        Msg("bank account update initiated")

    account, err := s.PaymentStore.UpdateBankAccountByID(ctx, accountID, req)
    if err != nil {
        log.Ctx(ctx).Err(err).
            Str(constants.LogAccountID, accountID).
            Msg("failed to update bank account")
        http.Error(w, "update failed", http.StatusInternalServerError)
        return
    }

    log.Ctx(ctx).Info().
        Str(constants.LogAccountID, accountID).
        Str(constants.LogStatus, "updated").
        Msg("bank account updated successfully")

    json.NewEncoder(w).Encode(account)
}
```

## Verification

Run the service locally and confirm that each log line is valid JSON containing the three required fields (`level`, `time`, `msg`):

```bash
go run ./cmd/<service_name>/... 2>&1 | head -5 | jq '{level, time, msg}'
```

Expected output:

```json
{
  "level": "info",
  "time": 1699200000,
  "msg": "server started"
}
```

In production, verify structured fields are queryable in Datadog:

| Goal | Query |
|---|---|
| All logs for a member | `@member_id:12345` |
| Errors in a region | `@region_id:usa level:error` |
| Full request trace | `@trace_id:abc123` |
| Handler failures | `@handler:update_bank_account level:error` |
