# OpenAPI Guide — REST API Protocol

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/protocol.md@1.0.0

## Overview

Shows how to satisfy the REST API Protocol standard in an OpenAPI 3.x document.
Covers the response envelope schema, required headers (Client-Agent, Retry-After),
status code documentation, gzip declaration, and the error array structure. An OpenAPI
document that follows this guide defines responses that are consistently enveloped,
carry required metadata, and surface errors uniformly.

## Related standard

[REST API Protocol](../../../../standards/api/rest/protocol.md)

## Prerequisites

- OpenAPI 3.0.x or 3.1.x
- Understanding of OpenAPI `$ref` for schema reuse across response definitions

## Implementation

### Shared response schemas (R-5, R-6, R-8)

Define envelope components once in `components/schemas` and `$ref` them from every
response. This enforces the envelope uniformly and keeps individual operation
definitions concise.

```yaml
components:
  schemas:

    Meta:
      type: object
      required: [status, operation]
      properties:
        status:
          type: object
          required: [code]
          properties:
            code:
              type: string
              description: Human-readable status string (e.g., "OK", "NotFound")
        operation:
          type: object
          required: [request_id]
          properties:
            request_id:
              type: string
              format: uuid
              description: UUID identifying this request for correlation

    ErrorDetail:
      type: object
      required: [code, message]
      properties:
        code:
          type: string
          description: Machine-readable error identifier (SCREAMING_SNAKE_CASE)
        message:
          type: string
          description: Human-readable error description
        details:
          type: object
          properties:
            field:
              type: string
            value: {}
            constraint:
              type: string
        trace_id:
          type: string
          format: uuid

    ErrorResponse:
      type: object
      required: [errors, meta]
      properties:
        errors:
          type: array
          minItems: 1
          items:
            $ref: "#/components/schemas/ErrorDetail"
        meta:
          $ref: "#/components/schemas/Meta"

    # Reusable success response wrapper — substitute T for the data schema
    # Use inline $ref composition per operation (see examples below)
```

### Shared response header definitions (R-1, R-2, R-3)

```yaml
components:
  headers:

    RetryAfter:
      description: Seconds to wait before retrying. Required on 429 and 503.
      schema:
        type: integer
        minimum: 1

  parameters:

    ClientAgent:
      name: Client-Agent
      in: header
      required: true
      description: >
        Identifies the calling application and version (e.g., rewards-app/2.1.0).
        Must not use the deprecated X- prefix. Must not be sent as User-Agent.
      schema:
        type: string
```

### Operation response definitions (R-5, R-6, R-7, R-8)

Use the shared schemas and the correct status codes for every operation.

```yaml
paths:
  /store/v1/stores:
    get:
      summary: List stores
      operationId: listStores
      parameters:
        - $ref: "#/components/parameters/ClientAgent"
      responses:
        "200":
          description: Store list
          headers:
            Content-Encoding:
              schema:
                type: string
                enum: [gzip]     # R-4: gzip declared on success responses
          content:
            application/json:
              schema:
                type: object
                required: [data, meta]
                properties:
                  data:
                    type: array
                    items:
                      $ref: "#/components/schemas/Store"
                  pagination:
                    $ref: "#/components/schemas/CursorPagination"
                  meta:
                    $ref: "#/components/schemas/Meta"
        "401":
          description: Authentication failed
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ErrorResponse"
        "429":
          description: Rate limit exceeded
          headers:
            Retry-After:
              $ref: "#/components/headers/RetryAfter"   # R-3: required
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ErrorResponse"
        "503":
          description: Service unavailable
          headers:
            Retry-After:
              $ref: "#/components/headers/RetryAfter"   # R-3: required
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ErrorResponse"

    post:
      summary: Create store
      operationId: createStore
      responses:
        "201":                              # R-7: 201 for resource creation
          description: Store created
          headers:
            Location:                       # R-7: Location required on 201
              schema:
                type: string
                format: uri
                example: /store/v1/stores/456
          content:
            application/json:
              schema:
                type: object
                required: [data, meta]
                properties:
                  data:
                    $ref: "#/components/schemas/Store"
                  meta:
                    $ref: "#/components/schemas/Meta"
        "400":
          description: Malformed request — fails to parse or has unexpected shape
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ErrorResponse"
        "422":
          description: Well-formed request that fails a business rule
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ErrorResponse"
```

### Status code selection guide (R-7)

| Situation | Status code |
|-----------|-------------|
| Read success | 200 |
| Resource created | 201 + Location header |
| No content | 204 |
| Request body fails to parse | 400 |
| Auth credentials missing/invalid | 401 |
| Authenticated but insufficient roles | 403 |
| Resource does not exist | 404 |
| Version token mismatch | 409 (see `data.md`) |
| Business rule violation (well-formed request) | 422 |
| Rate limit exceeded | 429 + Retry-After |
| Service temporarily unavailable | 503 + Retry-After |

**Never return 200 for an error condition** (R-7). The `success: false` anti-pattern
must not appear.

### Custom headers — no X- prefix (R-2)

When defining custom request or response headers, omit the `X-` prefix.

```yaml
# Correct
Client-Agent: rewards-app/2.1.0

# Wrong
X-Client-Agent: rewards-app/2.1.0
X-Request-ID: abc123         # use meta.operation.request_id in response body instead
```

## Verification

1. Every success response schema includes `data` and `meta` (with `status.code` and
   `operation.request_id`); collection responses include `pagination`.
2. Every non-2xx response schema uses `$ref: "#/components/schemas/ErrorResponse"`;
   no non-2xx response has a `data` field.
3. Every `post` operation that creates a resource has a `201` response with a
   `Location` header defined.
4. Every `429` and `503` response has a `Retry-After` header defined.
5. No custom header name starts with `X-`.
6. No operation returns `200` for a condition that is an error.
