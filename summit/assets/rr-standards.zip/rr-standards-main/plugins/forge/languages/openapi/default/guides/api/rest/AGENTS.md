# REST API — OpenAPI Guides

## Directory purpose

OpenAPI implementations of the four REST API sub-standards. Each sub-guide covers one
concern (contracts, security, protocol, data) and shows the exact OpenAPI constructs
that satisfy the corresponding standard's rules. Load all four when authoring a new API
spec from scratch; load individual guides when reviewing or generating a specific aspect.

## File index

| File | Purpose | When to reference |
|------|---------|-------------------|
| `contracts.md` | Paths, versioning, naming, HTTP verbs, and OpenAPI `info` | Authoring or reviewing URI structure, path parameters, operation IDs, or the `info.version` field |
| `contracts.test.yaml` | Generation-lift test cases for `contracts.md` | Running `rr-standards:validate --active` against the contracts guide |
| `security.md` | `securitySchemes`, per-operation `security` requirements | Authoring or reviewing authentication on any endpoint |
| `security.test.yaml` | Generation-lift test cases for `security.md` | Running `rr-standards:validate --active` against the security guide |
| `protocol.md` | Response schemas, status codes, headers, error structure | Authoring or reviewing response shapes, status code choices, or header definitions |
| `protocol.test.yaml` | Generation-lift test cases for `protocol.md` | Running `rr-standards:validate --active` against the protocol guide |
| `data.md` | Pagination schemas, `version_token`, timestamp format, decimal and currency schemas | Authoring or reviewing request/response body field definitions |
| `data.test.yaml` | Generation-lift test cases for `data.md` | Running `rr-standards:validate --active` against the data guide |

## Navigation

- [OpenAPI language root](../../../../AGENTS.md)
- [REST API standards](../../../../../../standards/api/rest/) — the standards these guides implement
