# OpenAPI Language Guides

## Directory purpose

This directory contains guides for implementing rr-standards REST API standards using
OpenAPI. An OpenAPI document is the specification-language artifact for a REST API
contract — the design-time equivalent of what Go or Java source code is at implementation
time. These guides show how each language-agnostic rule in the REST API standards maps
to concrete OpenAPI constructs (paths, schemas, securitySchemes, response objects).

## Version layout

Guides are organized by version under this directory:

```
openapi/
├── AGENTS.md          ← this file
├── default/           ← recommended version (OpenAPI 3.x)
│   └── guides/
└── <version>/         ← version-specific guides (e.g. 3.0/, 3.1/)
    └── guides/
```

## Choosing a version

Version is **always detected from the project** — never asked of the user.

1. **Detect from the spec file.** Read the `openapi:` field at the top of the
   OpenAPI document being worked on (e.g. `openapi: 3.1.0`). Use the major.minor
   value for directory matching (e.g. `3.1.0` → `3.1/`).

2. **Match to a version directory.** Check whether a directory for the detected
   version exists (e.g. `3.1/guides/`). If it does, load guides from there.

3. **Fall back to `default/` when undetectable or unmatched.** If no `openapi:`
   field is present, or no directory matches the detected version, load guides
   from `default/`. Note the fallback in your response.

## Avoiding duplication

Guides are **not** duplicated across version directories. If a pattern is unchanged
between versions, it lives only in `default/`. Version-specific directories contain
only the guides that differ from `default/`. When loading guides for a specific
version, check whether the relevant guide exists in that version directory; if it
does not, fall back to `default/` for that guide.

## File index

| Path | Purpose | When to reference |
|------|---------|-------------------|
| `default/guides/api/rest/` | OpenAPI implementations of the four REST API sub-standards | Any time an OpenAPI document for a REST API is being authored or reviewed |

## Navigation

- [Languages root](../AGENTS.md) — versioning conventions for all languages
- [REST API standards](../../standards/api/rest/) — the standards these guides implement

## Linter

No linter configured for OpenAPI documents at this time.
