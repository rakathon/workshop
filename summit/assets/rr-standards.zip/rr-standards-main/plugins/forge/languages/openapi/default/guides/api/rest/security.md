# OpenAPI Guide — REST API Security

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/security.md@1.0.0

## Overview

Shows how to satisfy the REST API Security standard in an OpenAPI 3.x document.
Covers `securitySchemes` component definitions for the ebtoken JWT and euid cookie,
per-operation `security` requirements, and extension fields for admin contract
validation requirements. An OpenAPI document that follows this guide declares
authentication correctly for public member data endpoints, admin contracts, and
sensitive internal operations.

## Related standard

[REST API Security](../../../../standards/api/rest/security.md)

## Prerequisites

- OpenAPI 3.0.x or 3.1.x
- Familiarity with [OpenAPI Security Scheme Object](https://spec.openapis.org/oas/v3.1.0#security-scheme-object)

## Implementation

### Security scheme definitions (R-1, R-2, R-3)

Declare all security schemes once in `components/securitySchemes`. Do not redefine
them per-operation.

```yaml
components:
  securitySchemes:

    # Used on public endpoints accessing member data (R-1)
    ebtoken_bearer:
      type: http
      scheme: bearer
      description: >
        Rakuten ebtoken JWT. Required on all public endpoints that access member data.
        The token is validated for signature, expiry, and member identity.

    # Alternative to ebtoken_bearer for browser clients (R-1)
    euid_cookie:
      type: apiKey
      in: cookie
      name: euid
      description: >
        Rakuten ebtoken JWT delivered as a cookie. Functionally equivalent to
        ebtoken_bearer; use when the client cannot set Authorization headers.

    # Used on sensitive internal -int endpoints (R-3)
    server_to_server:
      type: http
      scheme: bearer
      description: >
        Server-to-server authentication token per the secure server-to-server
        communication standard. Required on -int endpoints that perform sensitive
        operations (balance modification, PII access, payment method changes,
        account deletion).
```

### Public endpoints accessing member data (R-1)

Apply `ebtoken_bearer` OR `euid_cookie` to every operation that returns or accepts
member-specific data. Listing both in the `security` array means either is accepted.

```yaml
paths:
  /offers/v1/regions/{region_id}/member_offers:
    get:
      summary: List member offers
      operationId: listMemberOffers
      security:
        - ebtoken_bearer: []
        - euid_cookie: []
      responses:
        "200":
          description: Member offer list
        "401":
          description: Missing or invalid token
```

Public endpoints that access **no member data** require no `security` entry.

```yaml
  /store/v1/stores:
    get:
      summary: List stores (public catalogue — no member data)
      operationId: listStores
      # No security block — this endpoint returns non-member data
```

### Admin contract endpoints (R-2)

Every operation in an `-admin` contract requires `ebtoken_bearer` and must validate
signature, expiry, and required roles. Document the required roles using the
`x-required-roles` extension.

```yaml
paths:
  /store-admin/v1/stores:
    get:
      summary: List all stores (admin)
      operationId: adminListStores
      security:
        - ebtoken_bearer: []
      x-required-roles:
        - store_admin
      description: >
        Validates JWT signature, expiry, and store_admin role on every request.
        Returns 401 on signature or expiry failure; 403 on missing role.
      responses:
        "200":
          description: Store list
        "401":
          description: JWT signature invalid or expired
        "403":
          description: Caller does not have the store_admin role

  /store-admin/v1/stores/{store_id}:
    delete:
      summary: Delete store (admin)
      operationId: adminDeleteStore
      security:
        - ebtoken_bearer: []
      x-required-roles:
        - store_admin
```

### Sensitive internal endpoints (R-3)

Apply `server_to_server` to every `-int` operation that performs a sensitive
operation. The sensitivity category must be documented.

```yaml
paths:
  /wallet-int/v1/members/{member_id}/balance:
    patch:
      summary: Adjust member balance
      operationId: adjustMemberBalance
      security:
        - server_to_server: []
      x-sensitivity: balance_modification
      responses:
        "200":
          description: Balance adjusted
        "401":
          description: Server-to-server auth token missing or invalid

  /pii-int/v1/members/{member_id}/profile:
    get:
      summary: Get member PII
      operationId: getMemberPii
      security:
        - server_to_server: []
      x-sensitivity: pii_access
```

Sensitive operation categories requiring `server_to_server` auth:
- `balance_modification`
- `pii_access`
- `payment_method_change`
- `account_deletion`

## Verification

1. Every operation that accesses member data has `ebtoken_bearer` or `euid_cookie`
   (or both) in its `security` array.
2. Every operation in an `-admin` contract has `ebtoken_bearer` and an
   `x-required-roles` extension with at least one role.
3. Every sensitive `-int` operation has `server_to_server` in its `security` array
   and an `x-sensitivity` extension documenting the category.
4. 401 and 403 responses are documented on all secured operations (see `protocol.md`
   for the full error response schema).
