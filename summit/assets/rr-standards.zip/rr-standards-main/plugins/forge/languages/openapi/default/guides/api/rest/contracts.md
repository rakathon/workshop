# OpenAPI Guide — REST API Contracts

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/contracts.md@1.0.0

## Overview

Shows how to satisfy the REST API Contracts standard in an OpenAPI 3.x document.
Covers `info`, `paths`, path parameter naming, `operationId` conventions, HTTP verb
assignment, and the OpenAPI `info.version` field. An OpenAPI document that follows
this guide will produce URI structures, versioning, naming, and verb mappings that
comply with the standard.

## Related standard

[REST API Contracts](../../../../standards/api/rest/contracts.md)

## Prerequisites

- OpenAPI 3.0.x or 3.1.x
- A text editor or IDE with OpenAPI support (e.g., VS Code + Redocly extension)

## Implementation

### `info` block — title and version (R-2, R-9)

The `info.version` field carries the **major version number only**, matching the `v<N>`
in the path. Do not use a full semantic version string here.

```yaml
openapi: "3.1.0"
info:
  title: Store API
  version: "1"        # major version only — matches /store/v1/... in paths
```

### Paths — URI structure and versioning (R-1, R-2)

Every path follows `/<contract_name>/v<N>/<collections>[/{id}][/<sub_collection>[/{id}]][/<method>]`.
For region-specific data, insert `/regions/{region_id}/` before the collection.

```yaml
paths:
  # Collection
  /store/v1/stores:
    get:
      summary: List stores
      operationId: listStores

  # Single entity
  /store/v1/stores/{store_id}:
    get:
      summary: Get store
      operationId: getStore
    put:
      summary: Replace store
      operationId: replaceStore
    patch:
      summary: Update store fields
      operationId: updateStore
    delete:
      summary: Delete store
      operationId: deleteStore

  # Sub-collection
  /store/v1/stores/{store_id}/conditions:
    get:
      summary: List conditions for store
      operationId: listStoreConditions
    post:
      summary: Create condition
      operationId: createStoreCondition

  /store/v1/stores/{store_id}/conditions/{condition_id}:
    get:
      summary: Get condition
      operationId: getStoreCondition

  # Regional data (R-1 regional variant) — region-scoped collection, no specific member
  /offers/v1/regions/{region_id}/offers:
    get:
      summary: List all offers available in a region
      operationId: listRegionOffers

  # Member-scoped data — public contract: member_guid identifies the member (R-10)
  /offers/v1/regions/{region_id}/members/{member_guid}/offers:
    get:
      summary: List offers for a member
      operationId: listMemberOffers

  # Member-scoped data — internal contract: member_id identifies the member (R-10)
  /offers-int/v1/regions/{region_id}/members/{member_id}/offers:
    get:
      summary: List offers for a member (internal)
      operationId: listMemberOffersInternal

  # Custom method — member-scoped action (R-10 + R-7)
  /auth/v1/regions/{region_id}/members/{member_guid}/login:
    post:
      summary: Log member in
      operationId: loginMember
```

### Collection naming — plural snake_case (R-3, R-4)

Path segments and path parameter names must be `snake_case` matching
`[a-z][a-z0-9]*(_[a-z0-9]+)*`. Use plural nouns for collection segments.

```yaml
# Correct
/store/v1/member_offers/{offer_id}

# Wrong — singular
/store/v1/member_offer/{offerId}

# Wrong — camelCase
/store/v1/memberOffers/{offerId}
```

### Query and body parameter naming (R-4)

All parameter names and request/response body field names must be `snake_case`.

```yaml
parameters:
  - name: store_id        # correct
    in: path
    required: true
    schema:
      type: string
  - name: region_id       # correct
    in: path
    required: true
    schema:
      type: string
  - name: limit           # correct (no multi-word, no camelCase)
    in: query
    schema:
      type: integer
```

### Contract type suffixes (R-5)

The contract name (first path segment) carries the suffix — not the path itself.

```yaml
# Public contract — no suffix
paths:
  /store/v1/stores: ...

# Admin contract — -admin suffix on contract name
paths:
  /store-admin/v1/stores: ...

# Internal server-to-server — -int suffix on contract name
paths:
  /store-int/v1/stores: ...
```

### HTTP verb mapping (R-7)

| Intent | Verb | Notes |
|--------|------|-------|
| Read single or collection | `get` | |
| Create resource | `post` | Returns 201 + Location |
| Full idempotent replacement | `put` | Requires `version_token` if resource supports concurrent writes |
| Partial update | `patch` | |
| Delete | `delete` | |
| Query with long parameters | `post` | Only when GET URL length would exceed limits; document why |

### Breaking changes — new version (R-6)

When a breaking change is required, create a new major-version path block. Do not
modify the existing version's paths.

```yaml
# Original version remains unchanged
paths:
  /store/v1/stores:
    get: ...

# New version for breaking change
  /store/v2/stores:
    get:
      summary: List stores (v2 — response schema changed)
```

### Member data URI structure (R-10)

All paths that access member-scoped resources must include
`/regions/{region_id}/members/{member_id}` before the member-scoped collection.
The ID type in the `members` path parameter differs by contract type:

| Contract type | `{member_id}` field name | ID type |
|---------------|--------------------------|---------|
| Public (no suffix) | `member_guid` | Member GUID — system-wide non-sequential unique identifier |
| Internal (`-int`) | `member_id` | Member ID — monotonically incrementing integer |

```yaml
paths:
  # Public contract — member GUID
  /offers/v1/regions/{region_id}/members/{member_guid}/offers:
    get:
      summary: List offers for a member
      operationId: listMemberOffers
      parameters:
        - name: region_id
          in: path
          required: true
          schema:
            type: string
        - name: member_guid
          in: path
          required: true
          schema:
            type: string
            description: Member GUID (system-wide non-sequential unique identifier)

  # Internal contract — member ID
  /offers-int/v1/regions/{region_id}/members/{member_id}/offers:
    get:
      summary: List offers for a member (internal)
      operationId: listMemberOffersInternal
      parameters:
        - name: member_id
          in: path
          required: true
          schema:
            type: integer
            description: Member ID (monotonically incrementing integer)
```

Non-compliant patterns to avoid:

```yaml
# Wrong — member data without /regions/{region_id}/members/{member_id} prefix
/offers/v1/member_offers:          # missing region and member path segments
/offers/v1/members/{member_id}/offers:  # missing region prefix

# Wrong — integer member ID exposed on a public contract
/offers/v1/regions/{region_id}/members/{member_id}/offers:
  # 'member_id' implies an integer — use 'member_guid' on public contracts
```

### OpenAPI specification requirement (R-9)

The OpenAPI document itself is the specification. Every API contract must have one.
The document filename should match the contract name: `store.yaml`, `offers.yaml`, etc.

## Verification

1. Open the spec in Swagger UI or Redoc and confirm every path matches the pattern
   `/<contract>/v<N>/<collection>...`.
2. Check each path parameter and query parameter name against the regex
   `[a-z][a-z0-9]*(_[a-z0-9]+)*` — no camelCase, no uppercase, no hyphens in names.
3. Confirm the contract name (first segment) ends with `-admin`, `-int`, or has no suffix
   as appropriate.
4. For each operation, confirm the HTTP verb matches the intent table above.
5. For every path that accesses member-scoped data, confirm `/regions/{region_id}/members/{member_id}`
   appears before the member-scoped collection. Confirm the path parameter name is `member_guid`
   on public contracts and `member_id` on `-int` contracts.
6. Run `/rr-standards:validate plugins/forge/standards/api/rest/contracts.md --active` to check
   this spec against the golden examples.
