# OpenAPI Guide — REST API Data

Guide: 1.0.0 | Implements: plugins/forge/standards/api/rest/data.md@1.0.0

## Overview

Shows how to satisfy the REST API Data standard in an OpenAPI 3.x document.
Covers pagination schemas, optimistic concurrency (`version_token`), timestamp format,
decimal and currency type schemas, distributed tracing headers, and `Accept-Language`
response documentation. An OpenAPI document that follows this guide defines field
schemas that prevent precision loss, pagination that bounds collections, and concurrent
write resources that detect conflicts.

## Related standard

[REST API Data](../../../../standards/api/rest/data.md)

## Prerequisites

- OpenAPI 3.0.x or 3.1.x
- Familiarity with OpenAPI schema composition (`allOf`, `$ref`)

## Implementation

### Pagination schemas (R-1, R-2)

Define both pagination styles in `components/schemas`. Use cursor-based by default;
offset only when UI requires page-number navigation.

```yaml
components:
  schemas:

    # Forward-only cursor pagination — use this by default.
    # Include 'previous' only when clients require backward navigation;
    # omit it from the schema entirely if forward-only iteration is sufficient.
    CursorPagination:
      description: >
        Default pagination style. Use for all collection endpoints unless the UI
        requires page-number navigation. Omit 'next' on the last page.
      type: object
      properties:
        next:
          type: string
          description: Opaque cursor for the next page. Absent on the last page.

    # Add 'previous' only when clients need to navigate backward.
    CursorPaginationBidirectional:
      description: >
        Cursor pagination with backward navigation. Use only when clients need to
        go back through results. Omit 'next' on the last page; omit 'previous'
        on the first page.
      type: object
      properties:
        next:
          type: string
          description: Opaque cursor for the next page. Absent on the last page.
        previous:
          type: string
          description: Opaque cursor for the previous page. Absent on the first page.

    OffsetPagination:
      description: >
        Use only when the UI requires page-number navigation. Do not mix with
        CursorPagination within a contract.
      type: object
      required: [num_pages, num_results]
      properties:
        num_pages:
          type: integer
          minimum: 0
        num_results:
          type: integer
          minimum: 0
```

Collection request parameters for each style:

```yaml
components:
  parameters:

    # Cursor-based
    CursorParam:
      name: cursor
      in: query
      schema:
        type: string
      description: Opaque pagination cursor from a previous response.

    LimitParam:
      name: limit
      in: query
      schema:
        type: integer
        minimum: 1
        maximum: 100
        default: 20

    # Offset-based (only when UI requires page numbers)
    PageParam:
      name: page
      in: query
      schema:
        type: integer
        minimum: 1
        default: 1

    SizeParam:
      name: size
      in: query
      schema:
        type: integer
        minimum: 1
        maximum: 100
        default: 20
```

Every collection endpoint **must** include `limit` (or `size`) to bound the response
(R-1). Never omit both and return an unbounded list.

### Optimistic concurrency (R-3)

Every resource that supports PUT or PATCH must include `version_token` in its schema.
Require it on write operations.

```yaml
components:
  schemas:

    Store:
      type: object
      required: [id, name, version_token]
      properties:
        id:
          type: string
          format: uuid
        name:
          type: string
        version_token:          # required on every resource that supports writes
          type: string
          format: uuid
          description: >
            Echo this value unchanged in PUT/PATCH requests. The server returns
            409 Conflict with the latest entity state if the token does not match.
        created_at:
          type: string
          format: date-time     # R-4: use date-time format (ISO 8601 UTC)
        updated_at:
          type: string
          format: date-time

    StoreUpdateRequest:
      type: object
      required: [version_token]   # clients must always send the token
      properties:
        name:
          type: string
        version_token:
          type: string
          format: uuid
```

Document the 409 response on every PUT and PATCH operation:

```yaml
paths:
  /store/v1/stores/{store_id}:
    put:
      summary: Replace store
      responses:
        "200":
          description: Store replaced
        "409":
          description: >
            Version token mismatch — another writer updated this resource.
            Response body contains the current entity state.
          content:
            application/json:
              schema:
                type: object
                required: [data, meta]
                properties:
                  data:
                    $ref: "#/components/schemas/Store"
                  meta:
                    $ref: "#/components/schemas/Meta"
```

### Timestamp format (R-4)

Use `type: string` with `format: date-time`. OpenAPI's `date-time` maps to ISO 8601
UTC (`YYYY-MM-DDTHH:MM:SSZ`). Never use `type: integer` for timestamps.

```yaml
# Correct
created_at:
  type: string
  format: date-time
  example: "2024-06-15T09:30:00Z"

# Wrong — Unix epoch integer
created_at:
  type: integer
  description: Unix timestamp   # violates R-4
```

### Decimal numbers as value/scale tuples (R-5)

Never use `type: number` or `type: number, format: float/double` for monetary,
percentage, or other precision-sensitive values. Define a reusable tuple schema.

```yaml
components:
  schemas:

    DecimalValue:
      description: >
        Lossless decimal representation. Real value = value × 10^(−scale).
        Example: 15.00% → {value: 1500, scale: 2}.
      type: object
      required: [value, scale]
      properties:
        value:
          type: integer
          description: Unscaled integer mantissa
        scale:
          type: integer
          minimum: 0
          description: Number of decimal places (exponent magnitude)
      example:
        value: 1500
        scale: 2
```

Usage:

```yaml
# Correct
discount_percentage:
  $ref: "#/components/schemas/DecimalValue"

# Wrong
discount_percentage:
  type: number    # IEEE 754 float — precision loss for values like 0.1
```

### Currency amounts (R-6)

```yaml
components:
  schemas:

    MoneyAmount:
      description: Currency amount with explicit scale. ISO 4217 currency code required.
      type: object
      required: [amount, currency, scale]
      properties:
        amount:
          type: integer
          description: Integer amount in the currency's smallest unit × 10^scale
        currency:
          type: string
          pattern: "^[A-Z]{3}$"
          description: ISO 4217 currency code (e.g., USD, JPY, EUR)
        scale:
          type: integer
          minimum: 0
          description: Decimal places (0 for JPY, 2 for USD/EUR)
      examples:
        usd_ten_fifty:
          value: { amount: 1050, currency: USD, scale: 2 }   # $10.50
        jpy_five_hundred:
          value: { amount: 500, currency: JPY, scale: 0 }    # ¥500
```

### Distributed tracing headers (R-7)

Document `traceparent` and `tracestate` as required request headers on all operations.
Define them once in `components/parameters`.

```yaml
components:
  parameters:

    TraceParent:
      name: traceparent
      in: header
      required: true
      description: >
        W3C trace context header. Format: version-trace_id-span_id-flags.
        Propagated via OpenTelemetry across all service calls.
      schema:
        type: string
        pattern: "^[0-9a-f]{2}-[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{2}$"
        example: "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01"

    TraceState:
      name: tracestate
      in: header
      required: false
      description: Vendor-specific trace metadata (e.g., DataDog, Jaeger sampling state).
      schema:
        type: string
```

### Localization (R-8)

Document `Accept-Language` as a request parameter and state the fallback behaviour.

```yaml
components:
  parameters:

    AcceptLanguage:
      name: Accept-Language
      in: header
      required: false
      description: >
        BCP 47 language tag with optional quality weighting
        (e.g., ja-JP,ja;q=0.9,en;q=0.8). The server returns user-facing text
        and images localized to the best available match. Falls back to the
        region default when no accepted locale is available or the header is absent.
      schema:
        type: string
        example: "ja-JP,ja;q=0.9,en;q=0.8"
```

## Verification

1. Every collection operation includes `limit` (or `size`) as a request parameter —
   no operation can return an unbounded list.
2. Every resource schema that has PUT or PATCH operations includes `version_token`
   (type: string, format: uuid); the write request schema requires it.
3. Every PUT and PATCH operation documents a `409` response.
4. All timestamp fields use `type: string, format: date-time` — no `type: integer`.
5. No precision-sensitive field uses `type: number` — all use `$ref: DecimalValue`
   or `$ref: MoneyAmount`.
6. `traceparent` is declared as a required header parameter on all operations.
