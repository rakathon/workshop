# Kotlin Guides - Default

## Directory Purpose

Implementation guides for current Kotlin. This is the default version directory for
all new Kotlin work.

---

## File Index

| Name | Purpose | When to reference |
|------|---------|-------------------|
| `guides/` | Kotlin implementation guides organized by domain area | When generating or reviewing Kotlin code that must satisfy a standard |

---

## Navigation

- [`languages/AGENTS.md`](../../AGENTS.md) — navigation for the full languages directory
- [`standards/`](../../../../../standards/) — language-agnostic standards that Kotlin guides implement

---

## Linter

All generated and reviewed Kotlin code must pass both linters:

- **ktlint** — formatting and style; config: `.editorconfig` at project root
  - Check: `./gradlew ktlintCheck`
  - Auto-fix: `./gradlew ktlintFormat`
- **detekt** — static analysis; config: `config/detekt/detekt.yml`
  - Check: `./gradlew detekt`

Individual guides must not restate these linter requirements. Adjust config paths to
match your project's actual layout.
