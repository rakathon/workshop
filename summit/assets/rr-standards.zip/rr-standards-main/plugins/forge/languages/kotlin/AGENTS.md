# Kotlin Language Guides

## Directory Purpose

The `plugins/forge/languages/kotlin/` directory contains Kotlin-specific implementation guides for
standards defined in `standards/`. It is the authoritative source for how to satisfy
language-agnostic rules in Kotlin projects.
Guides live under `guides/<area>/` and are organized by the same domain categories as
the parent standards.

---

## File Index

| Name | Purpose | When to reference |
|------|---------|-------------------|
| `default/` | Default Kotlin implementation guides and linter configuration | For all standard Kotlin development work |

---

## Navigation

- [`languages/AGENTS.md`](../AGENTS.md) — navigation for the full languages directory
- [`standards/`](../../../../standards/) — language-agnostic standards that Kotlin guides implement

