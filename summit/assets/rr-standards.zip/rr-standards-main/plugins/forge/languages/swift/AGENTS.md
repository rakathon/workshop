# Swift Language Guides

## Directory purpose

Swift-specific implementation guides for rr-standards. Guides are versioned by
language era under subdirectories; `current/` is the default for all new Swift work.
Additional directories (e.g. `swift5/`) may be added for backwards-compatibility contexts.

## File index

| Entry | Purpose | When to reference |
|-------|---------|-------------------|
| `current/` | Guides for current Swift (the default target) | All new Swift code unless a specific older version is required |

## Navigation

- [Standards library](../../standards/) — language-agnostic standards these guides implement
