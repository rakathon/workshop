# Swift Guides — Current

## Directory purpose

Implementation guides for current Swift. This is the default version directory for
all new Swift work.

## File index

| Entry | Purpose | When to reference |
|-------|---------|-------------------|
| `guides/` | Swift implementation guides (linting, config templates) | When reviewing or generating Swift code |

## Navigation

- [Standards library](../../../standards/) — language-agnostic standards these guides implement

## Linter

SwiftLint. Config: `.swiftlint.yml` at the repository root
(see `current/guides/resources/swiftlint.yml` for the reference template). All generated
Swift code must pass `swiftlint lint` with zero errors before being emitted.
