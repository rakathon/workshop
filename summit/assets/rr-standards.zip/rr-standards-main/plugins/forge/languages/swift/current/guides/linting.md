# Swift Linting Guide

Guide: 1.0.0 | Standalone

## Overview

How to run SwiftLint on changed Swift lines during review or generation.

## Related standard

Standalone.

## Prerequisites

Check that SwiftLint is installed and meets the minimum required version (0.57.0):

```bash
swiftlint version
```

- If the command is not found: halt and tell the user:
  > "SwiftLint is required but not installed. Install it using your project's tooling setup, then retry."
- If the reported version is below `0.57.0`: halt and tell the user:
  > "SwiftLint <version> is installed but 0.57.0 or later is required. Update it using your project's tooling setup, then retry."

Also confirm a `.swiftlint.yml` exists at the repository root. If absent: halt and tell
the user, pointing to [`resources/swiftlint.yml`](resources/swiftlint.yml) as a starting
template to copy to the repo root and adjust as needed.

## Implementation

Run SwiftLint from the project root so the root `.swiftlint.yml` is picked up as the
base configuration. Subdirectories may contain their own `.swiftlint.yml` files that
extend or override the root config for that scope — SwiftLint applies the nearest
config to each file automatically when run from the root.

Get the list of changed Swift files from the diff, then run SwiftLint against them:

```bash
swiftlint lint --path <changed-file>
```

Run once per changed file. If multiple files changed, run for each.

## Verification

SwiftLint exits `0` when there are no errors. Any non-zero exit or output lines indicate
violations. Report all violations as-is from SwiftLint output.
