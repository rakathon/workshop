# Swift Guides

## Directory purpose

Swift implementation guides covering linting and configuration. Load the relevant
guide before emitting or reviewing Swift code.

## File index

| Entry | Purpose | When to reference |
|-------|---------|-------------------|
| `linting.md` | How to run SwiftLint on changed files during review or generation | Always — load before emitting or reviewing Swift code |
| `resources/` | Reference configuration templates | When a project needs to bootstrap a config file |

## Navigation

- [Swift current](../AGENTS.md) — parent version directory
- [Standards library](../../../../standards/) — language-agnostic standards these guides implement
