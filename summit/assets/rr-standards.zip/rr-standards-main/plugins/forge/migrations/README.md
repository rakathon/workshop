# Forge Migration Manifests

This directory contains migration manifests consumed by `forge:update` when upgrading a project from one Forge plugin version to another.

---

## Filename Convention

Manifests use the naming pattern:

```
<from-version>-to-<to-version>.json
```

For example: `v1.2.0-to-v2.0.0.json`

A manifest is only present when migration steps are required for that version transition. An absent manifest means no structural changes are needed — `forge:update` will still run its always-required operation (see [Always-Required Operations](#always-required-operations)), but no manifest steps are applied.

---

## JSON Schema

Each manifest is a JSON object with the following top-level fields:

| Field | Type | Description |
|---|---|---|
| `from` | string (semver) | The version being migrated from |
| `to` | string (semver) | The version being migrated to |
| `breaking` | boolean | `true` for MAJOR version migrations |
| `steps` | array | Ordered list of operations to apply |

### Full Example

```json
{
  "from": "1.2.0",
  "to": "2.0.0",
  "breaking": true,
  "steps": [
    { "op": "create-dir",  "path": ".forge/capabilities" },
    { "op": "rename",      "from": ".forge/spec/interfaces", "to": ".forge/interfaces" },
    { "op": "state-field", "field": "currentPhase", "rename": "phase" },
    { "op": "claude-md",   "action": "refresh" }
  ]
}
```

---

## Supported Operation Types

All operations are designed to be **idempotent** — re-running a migration after a partial failure is safe. The specific idempotency behaviour for each operation is described below.

### Summary Table

| `op` | Required Fields | Purpose |
|---|---|---|
| `create-dir` | `path` | Creates a directory if absent |
| `rename` | `from`, `to` | Moves a file or directory |
| `state-field` | `field`, `rename` | Renames a field in `.state.json` files |
| `claude-md` | `action` | Refreshes the forge-managed section of CLAUDE.md |
| `git-config` | `configs` | Adds git config key/value pairs to the local clone |

### `create-dir`

**Required field:** `path`

Creates the directory at `path` if it does not already exist.

**Idempotency:** Skipped silently if the directory already exists.

```json
{ "op": "create-dir", "path": ".forge/capabilities" }
```

### `rename`

**Required fields:** `from`, `to`

Moves a file or directory from `from` to `to`.

**Idempotency:** Skipped silently if `from` is absent (indicates the rename was already applied). Aborts with an error if both `from` and `to` exist — this is an ambiguous state that requires engineer resolution before re-running.

```json
{ "op": "rename", "from": ".forge/spec/interfaces", "to": ".forge/interfaces" }
```

### `state-field`

**Required fields:** `field`, `rename`

Renames the JSON field `field` to `rename` in every `.forge/efforts/*/.state.json` file.

**Idempotency:** Skips any file that already uses the new field name.

```json
{ "op": "state-field", "field": "currentPhase", "rename": "phase" }
```

### `claude-md`

**Required field:** `action` (value: `"refresh"`)

Replaces the forge-managed section of `CLAUDE.md` with the current plugin template.

**Idempotency:** Always re-applied. A full replacement is safe to repeat.

```json
{ "op": "claude-md", "action": "refresh" }
```

### `git-config`

**Required field:** `configs` — an array of `{ "key": "...", "value": "..." }` objects.

Adds each key/value pair to the local git config if not already present. Uses
`git config --add` so existing values under the same key are not replaced.

**Idempotency:** Skipped per-entry if the exact value is already registered under
that key (`git config --get-all <key>` is checked first).

**Rollback:** Not rolled back on failure — git config entries are additive and safe to
leave in place. Re-running `forge:update` after fixing the failure is safe.

```json
{
  "op": "git-config",
  "configs": [
    { "key": "remote.origin.push",  "value": "refs/notes/*:refs/notes/*" },
    { "key": "remote.origin.fetch", "value": "+refs/notes/*:refs/notes/*" }
  ]
}
```

---

## Always-Required Operations

`claude-md` is available as a manifest-declared operation, but `forge:update` also runs it as an **always-required operation on every migration** regardless of whether any manifest declares it. This ensures CLAUDE.md is always up to date after an upgrade.

Including `claude-md` in a manifest is only needed when the migration requires a specific ordering relative to other structural steps.

Note: plugin hooks are registered automatically by Claude Code from the installed plugin. `forge:update` does not write to `.claude/settings.json`.

---

## Unrecognised Operations

An unrecognised `op` value causes `forge:update` to **abort before applying any changes**. This is a hard failure — no partial migration is applied.

If a manifest contains an unrecognised operation, it must be corrected before the migration can proceed.

---

## Version Control

All manifests must be committed to version control. `forge:update` reads migration manifests from the installed plugin cache, not from the project repository.
