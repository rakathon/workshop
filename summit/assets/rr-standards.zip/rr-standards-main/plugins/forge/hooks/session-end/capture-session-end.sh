#!/usr/bin/env bash
# forge — session end telemetry
# Trigger: SessionEnd (fires once when the session terminates)
# Scope:   Project — registered in hooks/hooks.json with "async": true.
#          Fires from any repo; Forge enrichment fields are empty strings outside
#          Forge-initialized repositories.
#
# Purpose: Capture a session_end event with token usage, model, estimated cost,
#          and turn count so leadership can track forge usage and spend per engineer.

# DIAGNOSTIC — remove once confirmed working
echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") hook=capture-session-end CWD=$(pwd)" >> /tmp/forge-session-end-debug.txt

# Read stdin BEFORE any early-exit guard (stdin is a one-shot read)
_HOOK_INPUT=$(cat)

# DIAGNOSTIC — log stdin summary
echo "  stdin_len=${#_HOOK_INPUT}" >> /tmp/forge-session-end-debug.txt

export FORGE_SESSION_ID
FORGE_SESSION_ID=$(printf '%s' "$_HOOK_INPUT" | jq -r '.session_id // ""' 2>/dev/null || echo "")
_TRANSCRIPT_PATH=$(printf '%s' "$_HOOK_INPUT" | jq -r '.transcript_path // ""' 2>/dev/null || echo "")

# Source telemetry library
_HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/telemetry.sh
source "${_HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true

# ─── Parse transcript for token usage, model, and session metadata ───────────
#
# The transcript JSONL has one entry per message. Each assistant entry contains:
#   message.model, message.usage (input/output/cache tokens),
#   version (CC version), entrypoint, gitBranch
#
# Pricing (per million tokens, approximate):
#   claude-opus-4-7:   input $5,    output $25, cache_read $0.50, cache_create $6.25
#   claude-opus-4-6:   input $5,    output $25, cache_read $0.50, cache_create $6.25
#   claude-sonnet-4-6: input $3,    output $15, cache_read $0.30, cache_create $3.75
#   claude-haiku-4-5:  input $1,    output $5,  cache_read $0.10, cache_create $1.25

_METADATA="{}"

if [ -n "$_TRANSCRIPT_PATH" ] && [ -f "$_TRANSCRIPT_PATH" ] && command -v python3 >/dev/null 2>&1; then
  _METADATA=$(python3 - "$_TRANSCRIPT_PATH" "$FORGE_SESSION_ID" 2>/dev/null <<'PYEOF'
import json, sys, os

transcript_path = sys.argv[1]
session_id      = sys.argv[2]

result = {
    "model": "", "cc_version": "", "entrypoint": "", "git_branch": "",
    "turns": 0, "input_tokens": 0, "output_tokens": 0,
    "cache_read_tokens": 0, "cache_creation_tokens": 0,
    "estimated_cost_usd": 0.0
}

PRICING = {
    "claude-opus-4-7":   {"i": 5.0,   "o": 25.0, "cr": 0.50,  "cc": 6.25},
    "claude-opus-4-6":   {"i": 5.0,   "o": 25.0, "cr": 0.50,  "cc": 6.25},
    "claude-sonnet-4-6": {"i": 3.0,   "o": 15.0, "cr": 0.30,  "cc": 3.75},
    "claude-sonnet-4-5": {"i": 3.0,   "o": 15.0, "cr": 0.30,  "cc": 3.75},
    "claude-haiku-4-5":  {"i": 1.0,   "o": 5.0,  "cr": 0.10,  "cc": 1.25},
}
DEFAULT_PRICING = {"i": 3.0, "o": 15.0, "cr": 0.30, "cc": 3.75}

try:
    # Claude Code writes the same assistant entry multiple times when parallel
    # tool calls are made (once per tool result received). Deduplicate by the
    # full usage tuple before accumulating to avoid counting one API call N times.
    seen_usage = set()
    with open(transcript_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Only process entries for this session
            if entry.get("sessionId") != session_id:
                continue

            if entry.get("type") != "assistant":
                continue

            msg = entry.get("message", {})
            usage = msg.get("usage", {})
            key = (
                usage.get("input_tokens", 0),
                usage.get("output_tokens", 0),
                usage.get("cache_creation_input_tokens", 0),
                usage.get("cache_read_input_tokens", 0),
            )
            if key in seen_usage:
                continue
            seen_usage.add(key)

            result["turns"] += 1

            result["model"]       = msg.get("model", result["model"])
            result["cc_version"]  = result["cc_version"]  or entry.get("version", "")
            result["entrypoint"]  = result["entrypoint"]  or entry.get("entrypoint", "")
            result["git_branch"]  = result["git_branch"]  or entry.get("gitBranch", "")

            result["input_tokens"]          += key[0]
            result["output_tokens"]         += key[1]
            result["cache_creation_tokens"] += key[2]
            result["cache_read_tokens"]     += key[3]

    p = PRICING.get(result["model"], DEFAULT_PRICING)
    result["estimated_cost_usd"] = round(
        result["input_tokens"]          * p["i"]  / 1_000_000 +
        result["output_tokens"]         * p["o"]  / 1_000_000 +
        result["cache_read_tokens"]     * p["cr"] / 1_000_000 +
        result["cache_creation_tokens"] * p["cc"] / 1_000_000,
        6
    )
except Exception:
    pass

print(json.dumps(result))
PYEOF
  )

  # Fall back to empty object if python3 returned nothing usable
  printf '%s' "$_METADATA" | python3 -c "import sys,json; json.load(sys.stdin)" 2>/dev/null \
    || _METADATA="{}"
fi

echo "  calling telemetry_event session_end" >> /tmp/forge-session-end-debug.txt
telemetry_event "session_end" "" "$_METADATA"
echo "  telemetry_event returned, waiting for curl..." >> /tmp/forge-session-end-debug.txt

# Wait for the background curl subprocess launched by telemetry_event to finish
# before this async hook process exits, so the POST is not dropped mid-flight.
wait

echo "  done" >> /tmp/forge-session-end-debug.txt
exit 0
