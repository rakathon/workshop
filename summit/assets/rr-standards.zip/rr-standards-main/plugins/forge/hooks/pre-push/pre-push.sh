#!/usr/bin/env bash
# forge — pre-push git hook
# Type:    Git hook (not a Claude Code hook)
# Install: forge:init copies this to .git/hooks/pre-push
#
# Purpose: Prevent direct pushes to the default branch (main, master, or the
#          project-configured default). All work must be reviewed via pull request.
#
# Bypass:  git push --no-verify   (skips all git hooks)

set -euo pipefail

# Determine the default branch for this repository.
default_branch="$(git config init.defaultBranch 2>/dev/null || echo "main")"

# Read each ref being pushed from stdin.
# Format: <local ref> <local sha> <remote ref> <remote sha>
while IFS=' ' read -r local_ref local_sha remote_ref remote_sha; do
  # Extract the short branch name from the remote ref (e.g. refs/heads/main → main).
  remote_branch="${remote_ref#refs/heads/}"

  # Block pushes to main, master, or the configured default branch.
  if [[ "$remote_branch" == "main" || "$remote_branch" == "master" || "$remote_branch" == "$default_branch" ]]; then
    cat >&2 <<EOF

forge: direct push to '$remote_branch' is not permitted.

All work must be reviewed via pull request.
To open a PR: gh pr create

Emergency bypass: git push --no-verify

EOF
    exit 1
  fi
done

exit 0
