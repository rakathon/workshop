#!/usr/bin/env bash
# forge — route-to-skills UserPromptSubmit hook
# Trigger: UserPromptSubmit
# Scope:   Project — registered in hooks/hooks.json.
#          Fires after the engineer submits a prompt, before Claude responds.
#          Must complete in < 300ms.
#
# Purpose: Safety net for high-confidence workflow intent. The CLAUDE.md Tier 1
#          intent patterns are the primary recognition mechanism. This hook catches
#          edge cases where targeted re-injection materially improves Claude's action
#          selection — explicit skill invocations, graduation events, cross-repo ops.
#
# Exit codes: Always 0. Never exits 2. This hook never blocks.

set -euo pipefail

# ─── 1. Read stdin and source telemetry ───────────────────────────────────────

# Hooks receive input via stdin as JSON — not via environment variables.
HOOK_INPUT=$(cat)

# Export session_id for telemetry correlation
export FORGE_SESSION_ID
FORGE_SESSION_ID=$(printf '%s' "$HOOK_INPUT" | jq -r '.session_id // ""' 2>/dev/null || echo "")
TRANSCRIPT_PATH=$(printf '%s' "$HOOK_INPUT" | jq -r '.transcript_path // ""' 2>/dev/null || echo "")

_HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/telemetry.sh
source "${_HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true

# ─── Record turn-start markers used by Stop/StopFailure hooks ──────────────────
if [ -n "$FORGE_SESSION_ID" ]; then
  _TURN_START_TS=$(date +%s)
  printf '%s' "$_TURN_START_TS" > "/tmp/claude-turn-start-${FORGE_SESSION_ID}.txt"

  # Queue one marker per visible turn so Stop/StopFailure can aggregate all
  # assistant transcript entries produced between prompt submit and turn stop.
  _QUEUE_FILE="/tmp/claude-turn-window-queue-${FORGE_SESSION_ID}.jsonl"
  _LOCK_DIR="/tmp/claude-turn-window-lock-${FORGE_SESSION_ID}.d"
  _START_OFFSET=0
  if [ -n "$TRANSCRIPT_PATH" ] && [ -f "$TRANSCRIPT_PATH" ]; then
    _START_OFFSET=$(wc -c < "$TRANSCRIPT_PATH" 2>/dev/null | tr -d '[:space:]' || echo "0")
  fi

  _PROMPT_PREVIEW=$(printf '%s' "$HOOK_INPUT" | jq -r '.prompt // ""' 2>/dev/null | cut -c1-120 || echo "")
  _MARKER=$(jq -nc \
    --arg session_id "$FORGE_SESSION_ID" \
    --arg transcript_path "$TRANSCRIPT_PATH" \
    --arg prompt_preview "$_PROMPT_PREVIEW" \
    --argjson started_at "$_TURN_START_TS" \
    --argjson start_offset "${_START_OFFSET:-0}" \
    '{
      session_id: $session_id,
      transcript_path: $transcript_path,
      started_at: $started_at,
      start_offset: $start_offset,
      prompt_preview: $prompt_preview
    }' 2>/dev/null || echo "")

  if [ -n "$_MARKER" ]; then
    _lock_acquired=0
    for _attempt in 1 2 3 4 5; do
      if mkdir "$_LOCK_DIR" 2>/dev/null; then
        _lock_acquired=1
        break
      fi
      sleep 0.05
    done
    if [ "$_lock_acquired" -eq 1 ]; then
      printf '%s\n' "$_MARKER" >> "$_QUEUE_FILE"
      rmdir "$_LOCK_DIR" 2>/dev/null || true
    fi
  fi
fi

# ─── 2. Extract the user prompt ───────────────────────────────────────────────

PROMPT=$(printf '%s' "$HOOK_INPUT" | jq -r '.prompt // ""' 2>/dev/null || echo "")
[ -n "$PROMPT" ] || exit 0

# Normalize to lowercase for case-insensitive matching
PROMPT_LOWER=$(printf '%s' "$PROMPT" | tr '[:upper:]' '[:lower:]')

# ─── 3. Guard: only run in Forge-initialized repositories ─────────────────────
#   Exception: forge commands bypass the guard so telemetry is captured even on
#   repos where .forge/ does not yet exist (e.g. forge:init on a new repo).
_is_forge_cmd=0
if printf '%s' "$PROMPT_LOWER" | grep -qE '(^|[[:space:]])/?(forge):[a-z]'; then
  _is_forge_cmd=1
fi
if [ "$_is_forge_cmd" -eq 0 ]; then
  [ -f ".forge/README.md" ] || exit 0
fi

# ─── 3. Signal detection ──────────────────────────────────────────────────────
#
# Order of precedence (highest-confidence first):
#   A. Explicit skill invocations  — /forge:<cmd> or forge:<cmd>
#   B. Graduation / completion     — "close this effort", "graduate", "we're done"
#   C. Cross-repo / sub-effort ops — "sub-effort", "project this effort", "start the ... work for"
#
# Low-confidence or ambiguous prompts: exit 0 with no output.

# ─── A. Explicit skill invocations ────────────────────────────────────────────

# Detect /forge:<skill> or forge:<skill> (with or without leading slash)
if printf '%s' "$PROMPT_LOWER" | grep -qE '(^|[[:space:]])/?(forge):[a-z]'; then
  # Extract the skill name
  SKILL=$(printf '%s' "$PROMPT_LOWER" | grep -oE '/?(forge):[a-z][a-z0-9_-]*' | head -1 | sed -E 's|/?forge:||')

  # Propagate active skill to Stop/StopFailure hook (cleared on non-skill turns)
  [ -n "$FORGE_SESSION_ID" ] && printf '%s' "forge:${SKILL}" > "/tmp/forge-active-skill-${FORGE_SESSION_ID}.txt"

  # Capture telemetry — event_type is 'skill_requested' (prompt-level intent).
  # Actual execution is captured as 'skill_invoked' by the PostToolUse hook.
  telemetry_event "skill_requested" "forge:${SKILL}"

  # Read current effort ID from .forge/efforts/README.md (best-effort; skip if slow)
  EFFORT_ID=""
  if [ -f ".forge/efforts/README.md" ]; then
    EFFORT_ID=$(grep -oP '(?<=efforts/)[^/]+(?=/)' .forge/efforts/README.md 2>/dev/null | head -1 || true)
  fi

  # Build routing context
  CONTEXT="⚒️🔥⚒️ Forge skill invocation detected: forge:${SKILL}

Available forge skills:
- forge:init      — Initialize a new repository with the Forge workflow structure
- forge:pin       — Pin the Forge plugin to a specific version in this project
- forge:update    — Migrate .forge/ structure to the current plugin version
- forge:status    — Show current effort state, phase, and artifact inventory
- forge:plan      — Generate or update the implementation plan for the current effort
- forge:promote   — Promote the current effort phase (discovery → planning → implementation → validation)
- forge:graduate  — Graduate a completed effort (archive artifacts into deployables/)
- forge:project   — Project this effort to a remote repository as a sub-effort
- forge:pause     — Pause the current effort with a next-action note
- forge:resume    — Resume a paused effort
- forge:verify    — Run pre-graduation validation checks
- forge:help      — List all available forge skills and their purpose"

  if [ -n "$EFFORT_ID" ]; then
    CONTEXT="${CONTEXT}

Current effort: ${EFFORT_ID}
Artifact routing for this effort:
- Business requirements → .forge/efforts/${EFFORT_ID}/requirements/business.md
- Technical requirements → .forge/efforts/${EFFORT_ID}/requirements/technical.md
- API specification → .forge/efforts/${EFFORT_ID}/spec/api/
- Storage schema → .forge/efforts/${EFFORT_ID}/spec/storage/
- Messaging contracts → .forge/efforts/${EFFORT_ID}/spec/messaging/
- Architecture decisions → .forge/efforts/${EFFORT_ID}/spec/arch-decisions/ADR-NNN-*.md
- Implementation plan → .forge/efforts/${EFFORT_ID}/plan/tasks.md
- Validation report → .forge/efforts/${EFFORT_ID}/validation/report.md"
  fi

  # Escape for JSON (replace backslashes, double-quotes, and encode newlines)
  CONTEXT_JSON=$(printf '%s' "$CONTEXT" | sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{printf "%s\\n", $0}' | tr -d '\n')
  printf '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"%s"}}' "$CONTEXT_JSON"
  exit 0
fi

# ─── B. Graduation / completion signals ───────────────────────────────────────

GRADUATION_SIGNAL=0
if printf '%s' "$PROMPT_LOWER" | grep -qE \
    '(graduate|graduation|close.*(effort|this out)|effort.*(done|complete|finished)|mark.*done|we.?re done|let.?s close|closing.*effort|wrap.*up.*effort|effort.*wrap)'; then
  GRADUATION_SIGNAL=1
fi

if [ "$GRADUATION_SIGNAL" -eq 1 ]; then
  CONTEXT="⚒️🔥⚒️ Effort graduation / completion detected.

Pre-graduation checklist (all must be satisfied before running forge:graduate):
1. All tasks in plan/tasks.md are complete with commit SHAs recorded
2. forge:verify report shows PASS or PASS WITH CONCERNS (not FAIL)
3. QA sign-off has been recorded in validation/report.md
4. All open decisions are resolved (no blocking ODs remain)
5. Post-approval modifications (if any) have been reconciled

Graduation action: forge:graduate
Graduation will:
- Archive effort artifacts into .forge/deployables/<deployable-name>/
- Update the deployable's canonical documentation
- Mark the effort as closed in .forge/efforts/README.md
- Record graduation SHA and timestamp in .state.json

If any pre-graduation condition is unmet, run forge:verify to identify blockers."

  CONTEXT_JSON=$(printf '%s' "$CONTEXT" | sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{printf "%s\\n", $0}' | tr -d '\n')
  printf '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"%s"}}' "$CONTEXT_JSON"
  exit 0
fi

# ─── C. Cross-repo / sub-effort operations ────────────────────────────────────

CROSS_REPO_SIGNAL=0
if printf '%s' "$PROMPT_LOWER" | grep -qE \
    '(sub.?effort|project.*effort|effort.*project|start.*work.*for|backend.*work.*for|frontend.*work.*for|create.*effort.*in|new.*effort.*for.*repo|coordination)'; then
  CROSS_REPO_SIGNAL=1
fi

if [ "$CROSS_REPO_SIGNAL" -eq 1 ]; then
  CONTEXT="⚒️🔥⚒️ Cross-repository / sub-effort operation detected.

Sub-effort coordination uses forge:project to project an effort into a remote repository.

coordinationRef schema (stored in .state.json):
{
  \"coordinationRef\": {
    \"type\": \"sub-effort\",
    \"coordinationRepo\": \"<org>/<repo>\",
    \"effortId\": \"<effort-id-in-remote-repo>\",
    \"projections\": [
      {
        \"sourceFile\": \".forge/efforts/<id>/requirements/technical.md\",
        \"sourceSha\": \"<sha-at-projection-time>\",
        \"targetRepo\": \"<org>/<repo>\",
        \"targetFile\": \".forge/efforts/<id>/requirements/technical.md\",
        \"projectedAt\": \"<ISO-8601>\"
      }
    ]
  }
}

Usage: forge:project
- Projects the current effort's artifacts to a remote repository
- Creates a matching effort structure in the target repo
- Records projection SHAs for staleness tracking
- The SessionStart hook checks for upstream changes on each session

For creating a new sub-effort in a remote repo: use forge:project with the target
repository name. The remote repo must have Forge initialized (forge:init)."

  CONTEXT_JSON=$(printf '%s' "$CONTEXT" | sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{printf "%s\\n", $0}' | tr -d '\n')
  printf '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"%s"}}' "$CONTEXT_JSON"
  exit 0
fi

# ─── D. Low-confidence or ambiguous signal — let CLAUDE.md handle it ──────────

# No forge skill detected — clear the active-skill file so Stop/StopFailure
# does not attribute this turn to the previous turn's skill.
[ -n "$FORGE_SESSION_ID" ] && printf '' > "/tmp/forge-active-skill-${FORGE_SESSION_ID}.txt"

exit 0
