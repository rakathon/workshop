#!/usr/bin/env bash
# forge — per-turn telemetry
# Trigger: Stop, StopFailure (fires once at the end of every turn)
# Scope:   Project — registered in hooks/hooks.json with "async": true.
#          Runs in the background after the agentic loop completes; does not
#          add latency to turn completion.
#
# Purpose: Emit a turn_complete event with model, token counts, estimated cost,
#          duration, and the active forge skill (if any) so usage can be tracked
#          at the per-turn level — finer granularity than session_end.
#
# Exit codes: Always 0. Never exits 2.

set -euo pipefail

# ─── 1. Read stdin ────────────────────────────────────────────────────────────

HOOK_INPUT=$(cat)

# ─── 2. Session correlation ───────────────────────────────────────────────────

export FORGE_SESSION_ID
FORGE_SESSION_ID=$(printf '%s' "$HOOK_INPUT" | jq -r '.session_id // ""' 2>/dev/null || echo "")

# ─── 3. Source telemetry library ──────────────────────────────────────────────

_HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/telemetry.sh
source "${_HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true

# ─── 4. Compute turn duration ─────────────────────────────────────────────────

_NOW=$(date +%s)
_DURATION_SECONDS=""
_TURN_START_FILE="/tmp/claude-turn-start-${FORGE_SESSION_ID}.txt"

if [ -n "$FORGE_SESSION_ID" ] && [ -f "$_TURN_START_FILE" ]; then
  _START=$(cat "$_TURN_START_FILE" 2>/dev/null || echo "")
  if [ -n "$_START" ] && [ "$_START" -gt 0 ] 2>/dev/null; then
    _DURATION_SECONDS=$(( _NOW - _START ))
  fi
  rm -f "$_TURN_START_FILE"
fi

# ─── 5. Read active skill ─────────────────────────────────────────────────────

_ACTIVE_SKILL=""
_ACTIVE_SKILL_FILE="/tmp/forge-active-skill-${FORGE_SESSION_ID}.txt"

if [ -n "$FORGE_SESSION_ID" ] && [ -f "$_ACTIVE_SKILL_FILE" ]; then
  _ACTIVE_SKILL=$(cat "$_ACTIVE_SKILL_FILE" 2>/dev/null || echo "")
fi

# ─── 5b. Consume turn-start marker for prompt-to-stop slice aggregation ───────

_TURN_MARKER=""
_TURN_QUEUE_FILE="/tmp/claude-turn-window-queue-${FORGE_SESSION_ID}.jsonl"
_TURN_LOCK_DIR="/tmp/claude-turn-window-lock-${FORGE_SESSION_ID}.d"

if [ -n "$FORGE_SESSION_ID" ] && [ -f "$_TURN_QUEUE_FILE" ]; then
  _lock_acquired=0
  for _attempt in 1 2 3 4 5 6 7 8 9 10; do
    if mkdir "$_TURN_LOCK_DIR" 2>/dev/null; then
      _lock_acquired=1
      break
    fi
    sleep 0.05
  done

  if [ "$_lock_acquired" -eq 1 ]; then
    _TURN_MARKER=$(sed -n '1p' "$_TURN_QUEUE_FILE" 2>/dev/null || echo "")
    if [ -n "$_TURN_MARKER" ]; then
      _tmp_queue=$(mktemp "/tmp/claude-turn-window-queue-${FORGE_SESSION_ID}.XXXXXX" 2>/dev/null || echo "")
      if [ -n "$_tmp_queue" ]; then
        sed '1d' "$_TURN_QUEUE_FILE" > "$_tmp_queue" 2>/dev/null || true
        mv "$_tmp_queue" "$_TURN_QUEUE_FILE" 2>/dev/null || rm -f "$_tmp_queue"
      fi
    fi
    rmdir "$_TURN_LOCK_DIR" 2>/dev/null || true
  fi
fi

# ─── 6. Discriminate Stop vs StopFailure; extract documented fields ──────────
#
# Documented fields:
#   Both:         session_id, transcript_path
#   Stop:         stop_hook_active (bool), last_assistant_message (string — Claude's output)
#   StopFailure:  error (string — API/runtime error text), error_details (object, optional),
#                 last_assistant_message (string, optional — rendered error text, NOT Claude output)
#
# Discrimination: `error` is only present on StopFailure. Use it as the gate.
#   StopFailure → skip transcript parsing; emit nulls for token/cost fields.
#   Stop        → parse transcript, matching by last_assistant_message content.

_IS_FAILURE=$(printf '%s' "$HOOK_INPUT" | jq -r 'if has("error") then "true" else "false" end' 2>/dev/null || echo "false")
_ERROR_TEXT=$(printf '%s' "$HOOK_INPUT" | jq -r '.error // ""' 2>/dev/null || echo "")
_ERROR_DETAILS=$(printf '%s' "$HOOK_INPUT" | jq -c '.error_details // null' 2>/dev/null || echo "null")
_TRANSCRIPT_PATH=$(printf '%s' "$HOOK_INPUT" | jq -r '.transcript_path // ""' 2>/dev/null || echo "")

# stop_reason: use documented error text for failures, "end_turn" for success
if [ "$_IS_FAILURE" = "true" ]; then
  _STOP_REASON="${_ERROR_TEXT:-error}"
else
  _STOP_REASON="end_turn"
fi

# ─── 7. Parse this turn's token usage from transcript ──────────────────────────
#
# Primary method: sum all assistant transcript entries added between the
# UserPromptSubmit marker and this Stop/StopFailure event. This makes per-turn
# accounting reconcile with session_end while preserving the engineer-visible
# "one emitted event per visible turn" model.
#
# Fallback method: if the marker queue is unavailable, fall back to the older
# single-entry match based on last_assistant_message. This keeps telemetry alive
# for in-flight sessions that began before the queue marker existed.

_LAST_ASSISTANT_MSG=$(printf '%s' "$HOOK_INPUT" | jq -r '.last_assistant_message // ""' 2>/dev/null || echo "")

_MODEL=""
_INPUT_TOKENS="null"
_OUTPUT_TOKENS="null"
_CACHE_READ_TOKENS="null"
_CACHE_CREATION_TOKENS="null"
_ESTIMATED_COST="null"
_TURN_SLICE_USED=0

if [ -n "$_TURN_MARKER" ] && command -v python3 >/dev/null 2>&1; then
  _TURN_DATA=$(python3 - "$_TURN_MARKER" "$FORGE_SESSION_ID" "$_TRANSCRIPT_PATH" 2>/dev/null <<'PYEOF'
import json, os, sys

marker = json.loads(sys.argv[1])
session_id = sys.argv[2]
stop_transcript_path = sys.argv[3]

transcript_path = marker.get("transcript_path") or stop_transcript_path
start_offset = int(marker.get("start_offset") or 0)

PRICING = {
    "claude-opus-4-7":   {"i": 5.0,   "o": 25.0, "cr": 0.50,  "cc": 6.25},
    "claude-opus-4-6":   {"i": 5.0,   "o": 25.0, "cr": 0.50,  "cc": 6.25},
    "claude-sonnet-4-6": {"i": 3.0,   "o": 15.0, "cr": 0.30,  "cc": 3.75},
    "claude-sonnet-4-5": {"i": 3.0,   "o": 15.0, "cr": 0.30,  "cc": 3.75},
    "claude-haiku-4-5":  {"i": 1.0,   "o": 5.0,  "cr": 0.10,  "cc": 1.25},
}
DEFAULT_PRICING = {"i": 3.0, "o": 15.0, "cr": 0.30, "cc": 3.75}

result = {
    "model": None,
    "assistant_entries": 0,
    "input_tokens": None,
    "output_tokens": None,
    "cache_read_tokens": None,
    "cache_creation_tokens": None,
    "estimated_cost_usd": None,
    "end_offset": start_offset,
}

try:
    if transcript_path and os.path.isfile(transcript_path):
        end_offset = os.path.getsize(transcript_path)
        result["end_offset"] = end_offset
        input_tokens = 0
        output_tokens = 0
        cache_read_tokens = 0
        cache_creation_tokens = 0
        assistant_entries = 0
        last_model = ""
        # Claude Code writes the same assistant entry multiple times when parallel
        # tool calls are made (once per tool result received). Deduplicate by the
        # full usage tuple before accumulating to avoid counting one API call N times.
        seen_usage = set()
        with open(transcript_path, "rb") as f:
            f.seek(max(0, start_offset))
            chunk = f.read(max(0, end_offset - max(0, start_offset)))
        for raw_line in chunk.splitlines():
            line = raw_line.decode("utf-8", errors="ignore").strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if entry.get("sessionId") != session_id or entry.get("type") != "assistant":
                continue
            msg = entry.get("message", {})
            usage = msg.get("usage", {})
            key = (
                usage.get("input_tokens", 0),
                usage.get("output_tokens", 0),
                usage.get("cache_creation_input_tokens", 0),
                usage.get("cache_read_input_tokens", 0),
            )
            if key in seen_usage:
                continue
            seen_usage.add(key)
            assistant_entries += 1
            last_model = msg.get("model", last_model)
            input_tokens += key[0]
            output_tokens += key[1]
            cache_creation_tokens += key[2]
            cache_read_tokens += key[3]

        if assistant_entries > 0:
            p = PRICING.get(last_model, DEFAULT_PRICING)
            cost = round(
                input_tokens * p["i"] / 1_000_000 +
                output_tokens * p["o"] / 1_000_000 +
                cache_read_tokens * p["cr"] / 1_000_000 +
                cache_creation_tokens * p["cc"] / 1_000_000,
                6
            )
            result.update({
                "model": last_model,
                "assistant_entries": assistant_entries,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cache_read_tokens": cache_read_tokens,
                "cache_creation_tokens": cache_creation_tokens,
                "estimated_cost_usd": cost,
            })
except Exception:
    pass

print(json.dumps(result))
PYEOF
  )

  if printf '%s' "$_TURN_DATA" | python3 -c "import sys,json; json.load(sys.stdin)" 2>/dev/null; then
    _MODEL=$(printf '%s' "$_TURN_DATA" | jq -r '.model // ""' 2>/dev/null || echo "")
    _INPUT_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.input_tokens // "null"' 2>/dev/null || echo "null")
    _OUTPUT_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.output_tokens // "null"' 2>/dev/null || echo "null")
    _CACHE_READ_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.cache_read_tokens // "null"' 2>/dev/null || echo "null")
    _CACHE_CREATION_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.cache_creation_tokens // "null"' 2>/dev/null || echo "null")
    _ESTIMATED_COST=$(printf '%s' "$_TURN_DATA" | jq -r '.estimated_cost_usd // "null"' 2>/dev/null || echo "null")
    _TURN_SLICE_USED=1
  fi
fi

if [ "$_TURN_SLICE_USED" -eq 0 ] \
    && [ "$_IS_FAILURE" = "false" ] \
    && [ -n "$_LAST_ASSISTANT_MSG" ] \
    && [ -n "$_TRANSCRIPT_PATH" ] && [ -f "$_TRANSCRIPT_PATH" ] \
    && command -v python3 >/dev/null 2>&1; then
  _TURN_DATA=$(python3 - "$_TRANSCRIPT_PATH" "$FORGE_SESSION_ID" "$_LAST_ASSISTANT_MSG" 2>/dev/null <<'PYEOF'
import json, sys

transcript_path      = sys.argv[1]
session_id           = sys.argv[2]
last_assistant_msg   = sys.argv[3]

FINGERPRINT_LEN = 120
fingerprint = last_assistant_msg[:FINGERPRINT_LEN]

PRICING = {
    "claude-opus-4-7":   {"i": 5.0,   "o": 25.0, "cr": 0.50,  "cc": 6.25},
    "claude-opus-4-6":   {"i": 5.0,   "o": 25.0, "cr": 0.50,  "cc": 6.25},
    "claude-sonnet-4-6": {"i": 3.0,   "o": 15.0, "cr": 0.30,  "cc": 3.75},
    "claude-sonnet-4-5": {"i": 3.0,   "o": 15.0, "cr": 0.30,  "cc": 3.75},
    "claude-haiku-4-5":  {"i": 1.0,   "o": 5.0,  "cr": 0.10,  "cc": 1.25},
}
DEFAULT_PRICING = {"i": 3.0, "o": 15.0, "cr": 0.30, "cc": 3.75}

result = {"model": None, "input_tokens": None, "output_tokens": None,
          "cache_read_tokens": None, "cache_creation_tokens": None,
          "estimated_cost_usd": None}

def entry_text(entry):
    content = entry.get("message", {}).get("content", [])
    if isinstance(content, str):
        return content
    parts = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            parts.append(block.get("text", ""))
    return "".join(parts)

try:
    matched_entry = None
    with open(transcript_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if entry.get("sessionId") != session_id or entry.get("type") != "assistant":
                continue
            text = entry_text(entry)
            if fingerprint and text[:FINGERPRINT_LEN] == fingerprint:
                matched_entry = entry

    if matched_entry:
        msg   = matched_entry.get("message", {})
        usage = msg.get("usage", {})
        model = msg.get("model", "")
        it  = usage.get("input_tokens", 0)
        ot  = usage.get("output_tokens", 0)
        crt = usage.get("cache_read_input_tokens", 0)
        cct = usage.get("cache_creation_input_tokens", 0)

        p = PRICING.get(model, DEFAULT_PRICING)
        cost = round(
            it  * p["i"]  / 1_000_000 +
            ot  * p["o"]  / 1_000_000 +
            crt * p["cr"] / 1_000_000 +
            cct * p["cc"] / 1_000_000,
            6
        )
        result.update({
            "model": model,
            "input_tokens": it,
            "output_tokens": ot,
            "cache_read_tokens": crt,
            "cache_creation_tokens": cct,
            "estimated_cost_usd": cost,
        })
except Exception:
    pass

print(json.dumps(result))
PYEOF
  )

  if printf '%s' "$_TURN_DATA" | python3 -c "import sys,json; json.load(sys.stdin)" 2>/dev/null; then
    _MODEL=$(printf '%s' "$_TURN_DATA" | jq -r '.model // ""' 2>/dev/null || echo "")
    _INPUT_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.input_tokens // "null"' 2>/dev/null || echo "null")
    _OUTPUT_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.output_tokens // "null"' 2>/dev/null || echo "null")
    _CACHE_READ_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.cache_read_tokens // "null"' 2>/dev/null || echo "null")
    _CACHE_CREATION_TOKENS=$(printf '%s' "$_TURN_DATA" | jq -r '.cache_creation_tokens // "null"' 2>/dev/null || echo "null")
    _ESTIMATED_COST=$(printf '%s' "$_TURN_DATA" | jq -r '.estimated_cost_usd // "null"' 2>/dev/null || echo "null")
  fi
fi

# ─── 8. Build metadata and emit event ─────────────────────────────────────────

if command -v jq >/dev/null 2>&1; then
  _DURATION_ARG="null"
  [ -n "$_DURATION_SECONDS" ] && _DURATION_ARG="$_DURATION_SECONDS"

  _METADATA=$(jq -n \
    --arg     model                 "$_MODEL" \
    --argjson input_tokens          "$_INPUT_TOKENS" \
    --argjson output_tokens         "$_OUTPUT_TOKENS" \
    --argjson cache_read_tokens     "$_CACHE_READ_TOKENS" \
    --argjson cache_creation_tokens "$_CACHE_CREATION_TOKENS" \
    --argjson estimated_cost_usd    "$_ESTIMATED_COST" \
    --argjson duration_seconds      "$_DURATION_ARG" \
    --arg     stop_reason           "$_STOP_REASON" \
    --argjson error_details         "$_ERROR_DETAILS" \
    --argjson is_failure            "$_IS_FAILURE" \
    '{
      model:                 $model,
      input_tokens:          $input_tokens,
      output_tokens:         $output_tokens,
      cache_read_tokens:     $cache_read_tokens,
      cache_creation_tokens: $cache_creation_tokens,
      estimated_cost_usd:    $estimated_cost_usd,
      duration_seconds:      $duration_seconds,
      stop_reason:           $stop_reason,
      error_details:         (if $is_failure then $error_details else null end)
    }' 2>/dev/null) || _METADATA="{}"

  telemetry_event "turn_complete" "$_ACTIVE_SKILL" "$_METADATA"
  # This hook runs async (hooks.json: "async": true), so Claude Code does not wait
  # for it. The script itself is the background process — run curl to completion
  # here rather than spawning another background child.
  wait
fi

exit 0
