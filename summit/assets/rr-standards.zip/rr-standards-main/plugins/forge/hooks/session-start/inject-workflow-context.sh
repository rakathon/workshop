#!/usr/bin/env bash
# forge — inject workflow context
# Trigger: SessionStart
# Scope:   Project — only runs in Forge-initialized repositories.
#          Must complete in < 2 seconds. GitHub API staleness checks run in
#          background subprocesses with a 1.5-second timeout.
#
# Purpose: Inject the current workflow state into Claude's context at the start
#          of every session so the agent knows what is in progress before the
#          engineer says anything. Fulfills TR-11 (session start context) and
#          BR-4 (immediately readable state).

# Read stdin and extract session_id + source for telemetry correlation.
# stdin must be consumed before any early-exit guard — it is a one-shot read.
_HOOK_INPUT=$(cat)
export FORGE_SESSION_ID
FORGE_SESSION_ID=$(printf '%s' "$_HOOK_INPUT" | jq -r '.session_id // ""' 2>/dev/null || echo "")
_SESSION_SOURCE=$(printf '%s' "$_HOOK_INPUT" | jq -r '.source // ""' 2>/dev/null || echo "")

# Source telemetry library and fire session_start event.
# SessionStart fires on: startup | resume | clear | compact.
# Only emit session_start telemetry on genuine new sessions (startup), not on
# resumes or compactions — those share the same session_id as the original session.
# Telemetry fires from any repo; Forge enrichment fields are null outside Forge repos.
_HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/telemetry.sh
source "${_HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true
[ "$_SESSION_SOURCE" = "startup" ] && telemetry_event "session_start"

# Everything below is Forge-specific workflow context injection.
# Only relevant in Forge-initialized repositories.
[ -f ".forge/README.md" ] || exit 0

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Escape a string for safe embedding in a JSON string value.
# Handles backslashes, double-quotes, and newlines.
# Uses awk for newline joining to stay compatible with macOS BSD sed.
json_escape() {
  printf '%s' "$1" \
    | sed 's/\\/\\\\/g' \
    | sed 's/"/\\"/g' \
    | awk 'NR>1{printf "\\n"} {printf "%s", $0}'
}

# Read a top-level string field from a .state.json file without jq.
# Usage: state_field <file> <key>
state_field() {
  local file="$1" key="$2"
  sed -n "s/.*\"${key}\": *\"\([^\"]*\)\".*/\1/p" "$file" 2>/dev/null | head -1
}

# ---------------------------------------------------------------------------
# Parse the active effort registry from .forge/efforts/README.md
# ---------------------------------------------------------------------------
# The registry table has the form:
#   | <id> | <title> | <type> | <tier> | <risk> | [<parent> |] <phase> | <status> |
# The optional "Parent" column was added in newer repos, so column count varies.
# Child entries (→ prefixed) and the header / separator rows are present too.
# We collect every row where status is "in_progress".
# awk is used to locate the ID and Status columns by header name so the parser
# is resilient to schema evolution (extra columns, different ordering).

# ---------------------------------------------------------------------------
# Identify the current effort
# ---------------------------------------------------------------------------
# Resolution order (branch names are NOT consulted):
#   1. .forge/EFFORT file — session-local pointer written by forge:effort/resume
#   2. Degrade silently — no prompting in hooks

current_effort=""

# Step 1: .forge/EFFORT file
if [ -f ".forge/EFFORT" ]; then
  _effort_id=$(cat ".forge/EFFORT" | tr -d '[:space:]')
  # Validate: allow only alphanumeric characters and hyphens (kebab-case IDs only).
  # Reject anything that could be used as a path traversal or shell injection vector.
  if printf '%s' "$_effort_id" | grep -qE '^[a-zA-Z0-9][a-zA-Z0-9-]*$' && \
     [ -d ".forge/efforts/${_effort_id}" ]; then
    current_effort="$_effort_id"
  else
    # Stale or unsafe pointer — remove silently
    rm -f ".forge/EFFORT"
  fi
fi

# Step 2: Scan registry for in-progress efforts and prompt the engineer to pick one.
# Only runs when .forge/EFFORT is absent or stale.

# ---------------------------------------------------------------------------
# Build the context output
# ---------------------------------------------------------------------------

build_context() {
  local effort_id="$1"
  local state_file=".forge/efforts/${effort_id}/.state.json"

  if [ ! -f "$state_file" ]; then
    printf "WARNING: .state.json missing for effort '%s' — skipping.\n" "$effort_id"
    return
  fi

  # Read base fields
  local title type tier risk current_phase
  title=$(state_field "$state_file" "title")
  type=$(state_field  "$state_file" "type")
  tier=$(state_field  "$state_file" "tier")
  risk=$(state_field  "$state_file" "risk")
  current_phase=$(state_field "$state_file" "currentPhase")

  # Read current phase status (the status field inside phases.<currentPhase>)
  local phase_status
  phase_status=$(awk -v ph="\"${current_phase}\": {" '
    $0 ~ ph {found=1}
    found && /"status"/ {
      sub(/.*"status": *"/, ""); sub(/".*/, ""); print; exit
    }
  ' "$state_file" 2>/dev/null)

  printf "⚒️🔥⚒️ ## Forge — Active Workflow Context\n\n"

  # -------------------------------------------------------------------------
  # Pause state — surfaced at TOP if active (spec: highest priority)
  # -------------------------------------------------------------------------
  if grep -q '"pauseState"' "$state_file" 2>/dev/null; then
    local pause_reason
    pause_reason=$(sed -n 's/.*"pauseReason": *"\([^"]*\)".*/\1/p' "$state_file" | head -1)
    printf "⏸ **PAUSED — Resume this session first:**\n"
    [ -n "$pause_reason" ] && printf "Reason: %s\n" "$pause_reason"
    local next_step
    next_step=$(sed -n 's/.*"nextStep": *"\([^"]*\)".*/\1/p' "$state_file" | head -1)
    [ -n "$next_step" ] && printf "Next step: %s\n" "$next_step"
    printf "\n"
  fi

  printf "**Current effort:** %s (%s)\n" "$effort_id" "$type"
  printf "**Phase:** %s (%s)\n" "$current_phase" "$phase_status"
  printf "**Tier:** %s | **Risk:** %s\n\n" "$tier" "$risk"

  # -------------------------------------------------------------------------
  # Artifact inventory
  # -------------------------------------------------------------------------
  printf "**Artifacts:**\n"

  # Discovery artifacts — one sed extraction per field; no eval.
  # Each value is validated against the allowlist {"present","absent"} before use.
  local biz tech api storage messaging
  _allowlist_artifact() {
    case "$1" in present|absent) printf '%s' "$1" ;; *) printf 'absent' ;; esac
  }
  biz=$(      _allowlist_artifact "$(sed -n 's/.*"business": *"\([^"]*\)".*/\1/p'   "$state_file" 2>/dev/null | head -1)" )
  tech=$(     _allowlist_artifact "$(sed -n 's/.*"technical": *"\([^"]*\)".*/\1/p'  "$state_file" 2>/dev/null | head -1)" )
  api=$(      _allowlist_artifact "$(sed -n 's/.*"api": *"\([^"]*\)".*/\1/p'        "$state_file" 2>/dev/null | head -1)" )
  storage=$(  _allowlist_artifact "$(sed -n 's/.*"storage": *"\([^"]*\)".*/\1/p'    "$state_file" 2>/dev/null | head -1)" )
  messaging=$(_allowlist_artifact "$(sed -n 's/.*"messaging": *"\([^"]*\)".*/\1/p'  "$state_file" 2>/dev/null | head -1)" )

  artifact_icon() { [ "$1" = "present" ] && printf "✓" || printf "(absent)"; }

  printf -- "- requirements/business.md %s\n"  "$(artifact_icon "$biz")"
  printf -- "- requirements/technical.md %s\n" "$(artifact_icon "$tech")"
  printf -- "- spec/api/ %s\n"                  "$(artifact_icon "$api")"
  printf -- "- spec/storage/ %s\n"              "$(artifact_icon "$storage")"
  printf -- "- spec/messaging/ %s\n"            "$(artifact_icon "$messaging")"

  # ADRs created
  local adr_count
  adr_count=$(grep -c '"ADR-' "$state_file" 2>/dev/null || echo 0)
  if [ "$adr_count" -gt 0 ]; then
    printf -- "- spec/arch-decisions/ ✓ (%s ADR(s))\n" "$adr_count"
  else
    printf -- "- spec/arch-decisions/ (absent)\n"
  fi

  # Planning / implementation artifacts
  if [ -f ".forge/efforts/${effort_id}/plan/tasks.md" ]; then
    printf -- "- plan/tasks.md ✓\n"
  fi
  if [ -f ".forge/efforts/${effort_id}/validation/report.md" ]; then
    printf -- "- validation/report.md ✓\n"
  fi

  # -------------------------------------------------------------------------
  # Derive next suggested action from phase + artifact state
  # -------------------------------------------------------------------------
  printf "\n**Next suggested action:** "
  case "$current_phase" in
    discovery)
      if [ "$biz" != "present" ]; then
        printf "Create business requirements (requirements/business.md).\n"
      elif [ "$tech" != "present" ]; then
        printf "Create technical requirements (requirements/technical.md).\n"
      elif [ "$api" != "present" ] && [ "$storage" != "present" ]; then
        printf "Begin design work — create API specifications or architecture decisions based on the technical requirements.\n"
      else
        printf "Complete discovery artifacts and request discovery approval.\n"
      fi
      ;;
    validation)
      printf "Create or update the validation report (validation/report.md).\n"
      ;;
    planning)
      if ! grep -q '"plan/tasks.md"' "$state_file" 2>/dev/null; then
        printf "Create the implementation plan (plan/tasks.md).\n"
      else
        printf "Review and finalize the implementation plan, then advance to implementation.\n"
      fi
      ;;
    implementation)
      local remaining
      remaining=$(awk '/"remainingTasks"/{found=1} found && match($0, /[A-Z]+-[0-9]+/){print substr($0, RSTART, RLENGTH); found=0}' "$state_file" 2>/dev/null | head -1)
      if [ -n "$remaining" ]; then
        printf "Work on remaining implementation tasks (next: %s).\n" "$remaining"
      else
        printf "Continue implementation work.\n"
      fi
      ;;
    verification)
      printf "Run verification against acceptance criteria.\n"
      ;;
    review)
      printf "Complete engineering review.\n"
      ;;
    qa)
      printf "Complete QA sign-off.\n"
      ;;
    deployment)
      printf "Execute deployment.\n"
      ;;
    operations)
      printf "Monitor post-deployment operations.\n"
      ;;
    *)
      printf "Continue work on the current phase.\n"
      ;;
  esac

  # -------------------------------------------------------------------------
  # Open decisions
  # -------------------------------------------------------------------------
  printf "\n**Open decisions:** "
  local od_section
  od_section=$(awk '/"openDecisions"/{found=1} found && /\]/{print; exit} found{print}' "$state_file" 2>/dev/null)
  if echo "$od_section" | grep -q '"id"'; then
    printf "\n"
    while IFS= read -r line; do
      local od_id od_desc od_task
      od_id=$(printf '%s' "$line" | sed -n 's/.*"id": *"\([^"]*\)".*/\1/p')
      od_desc=$(printf '%s' "$line" | sed -n 's/.*"description": *"\([^"]*\)".*/\1/p')
      od_task=$(printf '%s' "$line" | sed -n 's/.*"blockedTask": *"\([^"]*\)".*/\1/p')
      [ -n "$od_id" ] || continue
      if [ -n "$od_task" ]; then
        printf -- "- %s: %s (blocks %s)\n" "$od_id" "$od_desc" "$od_task"
      else
        printf -- "- %s: %s\n" "$od_id" "$od_desc"
      fi
    done < <(awk '/"openDecisions"/{found=1} found && /\}/{
        printf "%s\n", buf $0; buf=""
      } found && !/\]/ && !/openDecisions/{
        if ($0 ~ /"id":/) buf = $0
        else buf = buf " " $0
      } found && /\]/{exit}' "$state_file" 2>/dev/null)
  else
    printf "none\n"
  fi

  # -------------------------------------------------------------------------
  # Post-approval modifications
  # -------------------------------------------------------------------------
  printf "\n**Post-approval modifications:** "
  if grep -q '"postApprovalModifications"' "$state_file" 2>/dev/null; then
    local pam_files
    pam_files=$(grep -A2 '"postApprovalModifications"' "$state_file" 2>/dev/null | \
      sed -n 's/.*"file": *"\([^"]*\)".*/\1/p')
    if [ -n "$pam_files" ]; then
      printf "\n"
      while IFS= read -r f; do
        printf -- "- %s\n" "$f"
      done <<< "$pam_files"
    else
      printf "none\n"
    fi
  else
    printf "none\n"
  fi

  # (Pause state moved to top of output — see above)

  # -------------------------------------------------------------------------
  # Upstream proposals
  # -------------------------------------------------------------------------
  if grep -q '"upstreamProposals"' "$state_file" 2>/dev/null; then
    local proposals_section
    proposals_section=$(awk '/"upstreamProposals"/{found=1} found && /\]/{exit} found{print}' "$state_file" 2>/dev/null)
    if echo "$proposals_section" | grep -q '"status": *"proposed"'; then
      printf "\n**Pending upstream proposals:**\n"
      # Extract proposal IDs and target repos with proposed status
      local current_id=""
      local current_target=""
      local current_target_repo=""
      while IFS= read -r line; do
        local val
        val=$(printf '%s' "$line" | sed -n 's/.*"id": *"\([^"]*\)".*/\1/p')
        [ -n "$val" ] && current_id="$val"
        val=$(printf '%s' "$line" | sed -n 's/.*"targetFile": *"\([^"]*\)".*/\1/p')
        [ -n "$val" ] && current_target="$val"
        val=$(printf '%s' "$line" | sed -n 's/.*"targetRepo": *"\([^"]*\)".*/\1/p')
        [ -n "$val" ] && current_target_repo="$val"
        if printf '%s' "$line" | grep -q '"status": *"proposed"'; then
          printf -- "- Proposal %s: %s in %s\n" "$current_id" "$current_target" "$current_target_repo"
        fi
      done <<< "$proposals_section"
    fi
  fi

  # -------------------------------------------------------------------------
  # Staleness check (non-blocking, background subprocess)
  # -------------------------------------------------------------------------
  if grep -q '"coordinationRef"' "$state_file" 2>/dev/null; then
    # Check if coordinationRef is not null
    local coord_repo
    coord_repo=$(sed -n 's/.*"repo": *"\([^"]*\)".*/\1/p' "$state_file" | head -1)

    if [ -n "$coord_repo" ] && [ "$coord_repo" != "null" ]; then
      # Extract projections: pairs of (source, sourceSha)
      local stale_files=()
      local tmp_stale
      tmp_stale=$(mktemp 2>/dev/null || echo "/tmp/forge_stale_$$")

      # Run staleness checks in background subprocesses
      local source_file source_sha latest_sha
      while IFS= read -r proj_line; do
        local s_file s_sha
        s_file=$(printf '%s' "$proj_line" | sed -n 's/.*"source": *"\([^"]*\)".*/\1/p')
        s_sha=$(printf '%s' "$proj_line"  | sed -n 's/.*"sourceSha": *"\([^"]*\)".*/\1/p')
        [ -n "$s_file" ] || continue
        [ -n "$s_sha"  ] || continue

        # Background subprocess per projection, 1.5s timeout
        # Use -f query params instead of URL interpolation to avoid misparse on
        # special characters (spaces, &, ;) in file paths or repo names.
        (
          if command -v timeout >/dev/null 2>&1; then
            latest=$(timeout 1.5 gh api "repos/${coord_repo}/commits" \
              --method GET -f "path=${s_file}" -f "per_page=1" \
              --jq '.[0].sha' 2>/dev/null || true)
          else
            latest=$(gh api "repos/${coord_repo}/commits" \
              --method GET -f "path=${s_file}" -f "per_page=1" \
              --jq '.[0].sha' 2>/dev/null || true)
          fi
          if [ -n "$latest" ] && [ "$latest" != "$s_sha" ] && [ "$latest" != "null" ]; then
            printf "STALE:%s:%s\n" "$s_file" "$coord_repo" >> "$tmp_stale"
          fi
        ) &
      done < <(awk '/"projections"/{found=1} found && /\]/{exit} found{print}' "$state_file" 2>/dev/null)

      # Hard 1.5s timeout: kill any remaining background jobs then wait
      ( sleep 1.5; kill $(jobs -p 2>/dev/null) 2>/dev/null ) &
      local killer_pid=$!
      wait 2>/dev/null
      kill "$killer_pid" 2>/dev/null

      if [ -s "$tmp_stale" ]; then
        printf "\n⚠️ **Staleness warnings:**\n"
        while IFS=: read -r _ stale_file stale_repo; do
          printf -- "- %s is behind HEAD in %s — run forge:sync to update.\n" "$stale_file" "$stale_repo"
        done < "$tmp_stale"
      fi
      rm -f "$tmp_stale"
    fi
  fi

  # -------------------------------------------------------------------------
  # Artifact routing table
  # -------------------------------------------------------------------------
  printf "\n**Artifact routing table:**\n"
  printf -- "- Business requirements → .forge/efforts/%s/requirements/business.md\n"                      "$effort_id"
  printf -- "- Technical requirements → .forge/efforts/%s/requirements/technical.md\n"                    "$effort_id"
  printf -- "- API specification → .forge/efforts/%s/spec/api/\n"                                         "$effort_id"
  printf -- "- Storage schema → .forge/efforts/%s/spec/storage/\n"                                        "$effort_id"
  printf -- "- Messaging contracts → .forge/efforts/%s/spec/messaging/\n"                                 "$effort_id"
  printf -- "- Architecture decisions → .forge/efforts/%s/spec/arch-decisions/ADR-NNN-*.md\n"             "$effort_id"
  printf -- "- Test strategy → .forge/efforts/%s/spec/test-strategy.md\n"                                 "$effort_id"
  printf -- "- Implementation plan → .forge/efforts/%s/plan/tasks.md\n"                                   "$effort_id"
  printf -- "- Coordination plan → .forge/efforts/%s/plan/plan.md\n"                                      "$effort_id"
  printf -- "- Validation report → .forge/efforts/%s/validation/report.md\n"                              "$effort_id"
  printf -- "- Architecture review HTML → .forge/efforts/%s/validation/arch-review.html\n"                "$effort_id"
}

# ---------------------------------------------------------------------------
# Parse in-progress efforts from the registry
# ---------------------------------------------------------------------------
# Used when .forge/EFFORT is absent. Reads the registry table in
# .forge/efforts/README.md and collects every row where status is "in_progress".
# The table schema (from newest to oldest) may or may not include a Parent column;
# awk locates ID and Status by header name so it is resilient to column additions.

parse_in_progress_efforts() {
  local registry=".forge/efforts/README.md"
  [ -f "$registry" ] || return

  awk '
    /^\| *ID *\|/ {
      # Parse header to find column indices (1-based after splitting on |)
      n = split($0, cols, "|")
      id_col = 0; status_col = 0
      for (i = 1; i <= n; i++) {
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", cols[i])
        if (cols[i] == "ID")     id_col = i
        if (cols[i] == "Status") status_col = i
      }
      next
    }
    /^\| *[-:]/ { next }   # separator row
    id_col > 0 && status_col > 0 && /\|/ {
      n = split($0, cols, "|")
      id  = cols[id_col];     gsub(/^[[:space:]]+|[[:space:]]+$/, "", id)
      st  = cols[status_col]; gsub(/^[[:space:]]+|[[:space:]]+$/, "", st)
      # Strip leading → from child effort IDs
      gsub(/^→ */, "", id)
      if (st == "in_progress" && id != "") print id
    }
  ' "$registry"
}

# ---------------------------------------------------------------------------
# Assemble the final output
# ---------------------------------------------------------------------------

if [ -n "$current_effort" ]; then
  context=$(build_context "$current_effort")
  printf '{"systemMessage": "%s"}' "$(json_escape "$context")"
else
  # No active effort — collect in-progress efforts and ask the engineer to pick one
  mapfile -t in_progress < <(parse_in_progress_efforts)

  if [ "${#in_progress[@]}" -eq 0 ]; then
    # Truly nothing in flight — stay silent
    exit 0
  fi

  # Build a numbered list with title and phase from each effort's .state.json
  nl=$'\n'
  msg="⚒️🔥⚒️ ## Forge — No Active Effort${nl}${nl}No active effort is set for this session. The following efforts are in progress:${nl}${nl}"
  i=1
  for eid in "${in_progress[@]}"; do
    sf=".forge/efforts/${eid}/.state.json"
    if [ -f "$sf" ]; then
      etitle=$(state_field "$sf" "title")
      ephase=$(state_field "$sf" "currentPhase")
      msg="${msg}${i}. **${eid}** — ${etitle} (${ephase})${nl}"
    else
      msg="${msg}${i}. **${eid}**${nl}"
    fi
    i=$((i + 1))
  done

  msg="${msg}${nl}${nl}**To activate an effort:** invoke \`forge:effort --select <id>\` with the effort ID, or \`forge:effort --select <N>\` with the number from the list above. To create a new effort, invoke \`forge:effort\`."
  printf '{"systemMessage": "%s"}' "$(json_escape "$msg")"
fi
exit 0
