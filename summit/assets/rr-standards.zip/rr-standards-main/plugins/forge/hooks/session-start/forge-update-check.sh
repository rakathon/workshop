#!/usr/bin/env bash
# forge — plugin version drift check
# Trigger: SessionStart
# Scope:   User (global) — registered in hooks/hooks.json alongside forge-version-check.sh.
#          Runs in every Claude Code session regardless of which repository is open.
#          Must complete in < 500ms.
#
# Purpose: Detect when the installed Forge plugin version differs from the version
#          recorded in .forge/version. When they differ, forge:update should be run
#          to update the version record and apply any .forge/ directory structure
#          migrations introduced by the new version.

set -euo pipefail

# Only relevant in Forge-initialized repositories
[ -f ".forge/version" ] || exit 0

# Read the version last registered by forge:init / forge:update
active_version=$(grep "^active_version=" .forge/version 2>/dev/null | cut -d= -f2)
[ -n "$active_version" ] || exit 0

# Derive the plugin root from this script's own location — always resolves to
# the version that is actually running, regardless of how many versions are installed.
# Script lives at: <plugin_root>/hooks/session-start/forge-update-check.sh
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
plugin_root="$(cd "$script_dir/../.." && pwd)"
plugin_json="$plugin_root/.claude-plugin/plugin.json"

# Can't compare if plugin.json is missing — degrade silently
[ -f "$plugin_json" ] || exit 0

# Read the installed version from plugin.json (no jq dependency)
installed_version=$(sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' "$plugin_json" | head -1)
[ -n "$installed_version" ] || exit 0

# Returns the banner as a JSON-safe string (newlines encoded as literal \n)
banner_json() {
  local f="$script_dir/../forge-banner.txt"
  [ -f "$f" ] && awk '{printf "%s\\n", $0}' "$f" | tr -d '\n' || true
}

# Warn if the versions differ
if [ "$installed_version" != "$active_version" ]; then
  banner=$(banner_json)
  printf '{"systemMessage": "⚒️🔥⚒️ %sFORGE: plugin version mismatch\\n==================================\\ninstalled:  v%s\\nregistered: v%s\\n\\nRun /forge:update to update the version record\\nand apply any .forge/ directory migrations.\\n"}' \
    "$banner" "$installed_version" "$active_version"
fi

exit 0
