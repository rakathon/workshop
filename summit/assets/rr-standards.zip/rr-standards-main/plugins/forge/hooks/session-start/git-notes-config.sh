#!/usr/bin/env bash
# forge — git notes refspec configuration
# Trigger: SessionStart
# Scope:   User (global) — registered in hooks/hooks.json.
#          Runs in every Claude Code session regardless of which repository is open.
#          Must complete in < 500ms.
#
# Purpose: Ensure the local clone has the fetch refspec for refs/notes/* so that
#          forge:commit notes written by other engineers are received on git pull.
#          The push refspec is intentionally NOT set here — forge:commit pushes notes
#          explicitly after attaching them. Setting remote.origin.push overrides git's
#          default push behaviour and causes bare `git push` to skip branch commits.

set -euo pipefail

# Only relevant in Forge-initialized repositories
[ -f ".forge/version" ] || exit 0

# Only relevant when a remote named origin exists
git remote get-url origin >/dev/null 2>&1 || exit 0

push_refspec='refs/notes/*:refs/notes/*'
fetch_refspec='+refs/notes/*:refs/notes/*'

added=0
removed=0

# Remove the push refspec if a previous version of this hook added it.
# Setting remote.origin.push overrides git's default push behaviour and causes
# bare `git push` to silently skip branch commits.
if git config --get-all remote.origin.push 2>/dev/null | grep -qF "$push_refspec"; then
  git config --unset remote.origin.push "$push_refspec" 2>/dev/null || true
  removed=1
fi

if ! git config --get-all remote.origin.fetch 2>/dev/null | grep -qF "$fetch_refspec"; then
  git config --add remote.origin.fetch "$fetch_refspec"
  added=1
fi

if [ "$removed" -eq 1 ] && [ "$added" -eq 1 ]; then
  printf '{"systemMessage": "[forge] Configured git notes fetch refspec and removed push refspec for this clone."}\n'
elif [ "$removed" -eq 1 ]; then
  printf '{"systemMessage": "[forge] Removed git notes push refspec from this clone (was breaking bare git push)."}\n'
elif [ "$added" -eq 1 ]; then
  printf '{"systemMessage": "[forge] Configured git notes fetch refspec for this clone (refs/notes/*)."}\n'
fi

exit 0
