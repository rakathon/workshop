#!/usr/bin/env bash
# forge — version enforcement hook
# Trigger: SessionStart
# Scope:   User (global) — registered in hooks/hooks.json at plugin install time.
#          Runs in every Claude Code session regardless of which repository is open.
#          Must complete in < 500ms (TR-8).

# Only relevant in Forge-initialized repositories
[ -f ".forge/version" ] || exit 0

# Resolve script directory for banner path
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Returns the banner as a JSON-safe string (newlines encoded as literal \n)
banner_json() {
  local f="$script_dir/../forge-banner.txt"
  [ -f "$f" ] && awk '{printf "%s\\n", $0}' "$f" | tr -d '\n' || true
}

# Read version fields from .forge/version (key=value format)
forge_min=$(grep "^forge_min_version=" .forge/version | cut -d= -f2)
active=$(grep "^active_version=" .forge/version | cut -d= -f2)

if [ -z "$active" ]; then
  banner=$(banner_json)
  printf '{"systemMessage": "⚒️🔥⚒️ %sFORGE: .forge/version is malformed\\n=====================================\\nactive_version is missing.\\n\\nDelete .forge/version and run /forge:init to recreate it.\\n"}' \
    "$banner"
  exit 0
fi

# No minimum version enforced for unpinned repos
[ -n "$forge_min" ] || exit 0

# Semver comparison: returns 0 if $1 >= $2
version_gte() {
  local a b IFS=.
  local v1=($1) v2=($2)
  for i in 0 1 2; do
    a="${v1[$i]:-0}"; b="${v2[$i]:-0}"
    [ "$a" -gt "$b" ] && return 0
    [ "$a" -lt "$b" ] && return 1
  done
  return 0
}

# Detect active implementation task — used to soften version mismatch block.
# Uses grep rather than sed range patterns for reliable cross-platform parsing.
has_active_impl() {
  for state_file in .forge/efforts/*/.state.json; do
    [ -f "$state_file" ] || continue
    # Check currentPhase=implementation AND that the implementation block
    # specifically contains in_progress. The second grep uses [^}]* to stay
    # within the implementation object, avoiding false positives from other
    # phases (e.g. discovery.status=in_progress in a reverted work item).
    if grep -q '"currentPhase": *"implementation"' "$state_file" && \
       grep -q '"implementation" *: *{[^}]*"in_progress"' "$state_file"; then
      return 0
    fi
  done
  return 1
}

# Check active version meets project minimum
if ! version_gte "$active" "$forge_min"; then
  banner=$(banner_json)
  if has_active_impl 2>/dev/null; then
    printf '{"systemMessage": "⚒️🔥⚒️ %sFORGE: plugin version out of date\\n====================================\\nactive:   v%s\\nminimum:  v%s\\n\\nUpdate the rr-standards marketplace after this task:\\nclaude plugin update forge@rr-standards\\n"}' \
      "$banner" "$active" "$forge_min"
  else
    printf '{"systemMessage": "⚒️🔥⚒️ %sFORGE: plugin version out of date\\n====================================\\nactive:   v%s\\nminimum:  v%s\\n\\nUpdate the rr-standards marketplace:\\nclaude plugin update forge@rr-standards\\n"}' \
      "$banner" "$active" "$forge_min"
  fi
  exit 0
fi

# Extract major version for mandatory deadline check
major=$(echo "$forge_min" | cut -d. -f1)

# Fetch VERSIONS.json via gh (authenticated — works with private repositories).
# Use timeout if available (GNU/Linux); on macOS without coreutils, gh runs without
# a timeout — the deadline check degrades gracefully if gh is unresponsive.
if command -v timeout >/dev/null 2>&1; then
  encoded=$(timeout 1 gh api "repos/rewards-guilds/rr-standards/contents/VERSIONS.json" \
    --template '{{.content}}' 2>/dev/null)
else
  encoded=$(gh api "repos/rewards-guilds/rr-standards/contents/VERSIONS.json" \
    --template '{{.content}}' 2>/dev/null)
fi
versions_json=$(printf '%s' "$encoded" | tr -d '\n' | base64 -d 2>/dev/null)

# Degrade silently if VERSIONS.json is unreachable
[ -n "$versions_json" ] || exit 0

# Extract mandatoryAfter — prefer "forge" key, fall back to legacy "v${major}" key
mandatory_after=$(printf '%s' "$versions_json" | \
  sed -n '/"forge"[[:space:]]*:/,/}/{s/.*"mandatoryAfter": *"\([^"]*\)".*/\1/p;}' | \
  head -1)
if [ -z "$mandatory_after" ]; then
  mandatory_after=$(printf '%s' "$versions_json" | \
    sed -n "/\"v${major}\"/,/}/{s/.*\"mandatoryAfter\": *\"\([^\"]*\)\".*/\1/p;}" | \
    head -1)
fi

[ -n "$mandatory_after" ] || exit 0

today=$(date -u +%Y-%m-%d)

# Error if mandatory deadline has passed.
# ISO 8601 dates (YYYY-MM-DD) sort correctly as strings.
if [ "$today" \> "$mandatory_after" ] || [ "$today" = "$mandatory_after" ]; then
  banner=$(banner_json)
  printf '{"systemMessage": "⚒️🔥⚒️ %sFORGE: plugin support ended\\n=============================\\nforge v%s support ended on %s\\n\\nUpdate the rr-standards marketplace:\\nclaude plugin update forge@rr-standards\\n"}' \
    "$banner" "$major" "$mandatory_after"
  exit 0
fi

exit 0
