#!/usr/bin/env bash
# forge — workflow state update hook
# Trigger: PostToolUse (Write|Edit)
# Scope:   Project — registered in hooks/hooks.json.
#          Fires after any successful Write or Edit tool call.
#
# Purpose: Detect when an artifact under .forge/efforts/ was written and
#          automatically update .state.json to reflect the new artifact
#          presence (and any post-approval modification). This makes state
#          management invisible — engineers and agents produce artifacts,
#          and state is a side effect.
#
# Exit codes: Always 0. PostToolUse hooks cannot exit 2.
# Performance: Must complete in under 500ms. Reads/writes .state.json
#              only. No network calls.

set -euo pipefail

# Source telemetry library
_HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/telemetry.sh
source "${_HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true

# ─── 1. Extract the written file path ────────────────────────────────────────

# Hooks receive input via stdin as JSON — not via environment variables.
HOOK_INPUT=$(cat)

# Export session_id for telemetry correlation
export FORGE_SESSION_ID
FORGE_SESSION_ID=$(printf '%s' "$HOOK_INPUT" | jq -r '.session_id // ""' 2>/dev/null || echo "")

FILE_PATH=$(printf '%s' "$HOOK_INPUT" | jq -r '.tool_input.file_path // ""' 2>/dev/null || echo "")

if [ -z "$FILE_PATH" ]; then
  exit 0
fi

# ─── 2. Only operate on .forge/efforts/ paths ────────────────────────────────

# Strip leading ./ if present
FILE_PATH="${FILE_PATH#./}"

case "$FILE_PATH" in
  .forge/efforts/*) ;;
  *)                exit 0 ;;
esac

# ─── 3. Extract effort ID from path ──────────────────────────────────────────
# Path form: .forge/efforts/<effort-id>/...

EFFORT_ID=$(echo "$FILE_PATH" | sed 's|^\.forge/efforts/\([^/]*\)/.*|\1|')

if [ -z "$EFFORT_ID" ] || [ "$EFFORT_ID" = "$FILE_PATH" ]; then
  exit 0
fi

# ─── 4. Guard: do not self-referentially process .state.json writes ──────────

RELATIVE_PATH=$(echo "$FILE_PATH" | sed "s|^\.forge/efforts/${EFFORT_ID}/||")

if [ "$RELATIVE_PATH" = ".state.json" ]; then
  exit 0
fi

# ─── 5. Read .state.json ─────────────────────────────────────────────────────

STATE_FILE=".forge/efforts/${EFFORT_ID}/.state.json"

if [ ! -f "$STATE_FILE" ]; then
  exit 0
fi

# Validate it's parseable JSON — exit silently if corrupt
if ! jq empty "$STATE_FILE" 2>/dev/null; then
  exit 0
fi

# ─── 6. Determine artifact category and build jq update expression ───────────

ARTIFACT_PHASE=""
JQ_UPDATE=""

case "$RELATIVE_PATH" in

  requirements/business.md)
    ARTIFACT_PHASE="discovery"
    JQ_UPDATE='.phases.discovery.artifacts.requirements.business = "present"'
    ;;

  requirements/technical.md)
    ARTIFACT_PHASE="discovery"
    JQ_UPDATE='.phases.discovery.artifacts.requirements.technical = "present"'
    ;;

  spec/api/*.yaml|spec/api/*.yml|spec/api/*.md)
    ARTIFACT_PHASE="discovery"
    JQ_UPDATE='.phases.discovery.artifacts.spec.api = "present"'
    ;;

  spec/storage/*.md)
    ARTIFACT_PHASE="discovery"
    JQ_UPDATE='.phases.discovery.artifacts.spec.storage = "present"'
    ;;

  spec/messaging/*.md)
    ARTIFACT_PHASE="discovery"
    JQ_UPDATE='.phases.discovery.artifacts.spec.messaging = "present"'
    ;;

  spec/test-strategy.md)
    ARTIFACT_PHASE="discovery"
    JQ_UPDATE='.phases.discovery.artifacts.spec.testStrategy = "present"'
    ;;

  spec/arch-decisions/ADR-*.md)
    ARTIFACT_PHASE="discovery"
    ADR_FILENAME=$(basename "$RELATIVE_PATH")
    JQ_UPDATE="if (.phases.discovery.artifacts.adrsCreated | index(\"${ADR_FILENAME}\")) == null
               then .phases.discovery.artifacts.adrsCreated += [\"${ADR_FILENAME}\"]
               else . end"
    ;;

  plan/tasks.md)
    ARTIFACT_PHASE="planning"
    JQ_UPDATE='if .phases.planning.status == "not_started"
               then .phases.planning.status = "in_progress"
               else . end'
    ;;

  validation/report.md)
    ARTIFACT_PHASE="validation"
    # Parse overall result from the report file (PASS / PASS WITH CONCERNS / FAIL)
    VALIDATION_RESULT=""
    REPORT_FILE=".forge/efforts/${EFFORT_ID}/validation/report.md"
    if [ -f "$REPORT_FILE" ]; then
      if grep -qi "PASS WITH CONCERNS" "$REPORT_FILE" 2>/dev/null; then
        VALIDATION_RESULT="passed_with_concerns"
      elif grep -qi "\bFAIL\b" "$REPORT_FILE" 2>/dev/null; then
        VALIDATION_RESULT="failed"
      elif grep -qi "\bPASS\b" "$REPORT_FILE" 2>/dev/null; then
        VALIDATION_RESULT="passed"
      fi
    fi

    if [ -n "$VALIDATION_RESULT" ]; then
      JQ_UPDATE="(if .phases.validation.status == \"not_started\" then .phases.validation.status = \"in_progress\" else . end) | .phases.validation.result = \"${VALIDATION_RESULT}\""
    else
      JQ_UPDATE='if .phases.validation.status == "not_started"
                 then .phases.validation.status = "in_progress"
                 else . end'
    fi
    ;;

  validation/arch-review.html)
    ARTIFACT_PHASE="validation"
    JQ_UPDATE='if (.phases.validation.artifacts | index("validation/arch-review.html")) == null
               then .phases.validation.artifacts += ["validation/arch-review.html"]
               else . end'
    ;;

  *)
    # Unrecognized path — exit silently (not all writes are artifact writes)
    exit 0
    ;;
esac

# ─── 7. Check for post-approval modification ─────────────────────────────────
# If the artifact's phase status is "approved" AND currentPhase is a later
# phase, append a postApprovalModifications record.

PHASE_ORDER="discovery validation planning implementation verification review qa deployment operations"

phase_index() {
  local target="$1"
  local i=0
  for p in $PHASE_ORDER; do
    if [ "$p" = "$target" ]; then
      echo "$i"
      return 0
    fi
    i=$((i + 1))
  done
  echo "999"
}

CURRENT_PHASE=$(jq -r '.currentPhase // ""' "$STATE_FILE")
ARTIFACT_PHASE_STATUS=$(jq -r ".phases.${ARTIFACT_PHASE}.status // \"\"" "$STATE_FILE" 2>/dev/null || echo "")

POST_APPROVAL_UPDATE=""

if [ -n "$ARTIFACT_PHASE" ] && [ -n "$CURRENT_PHASE" ] && [ "$ARTIFACT_PHASE_STATUS" = "approved" ]; then
  artifact_idx=$(phase_index "$ARTIFACT_PHASE")
  current_idx=$(phase_index "$CURRENT_PHASE")
  if [ "$current_idx" -gt "$artifact_idx" ]; then
    NOW=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    POST_APPROVAL_UPDATE=" | .phases.${ARTIFACT_PHASE}.postApprovalModifications += [{\"file\": \"${RELATIVE_PATH}\", \"modifiedAt\": \"${NOW}\", \"modifiedDuringPhase\": \"${CURRENT_PHASE}\"}]"
  fi
fi

# ─── 8. Apply updates to .state.json ─────────────────────────────────────────

FULL_UPDATE="${JQ_UPDATE}${POST_APPROVAL_UPDATE}"

# Snapshot phase/status before update for README change detection
OLD_PHASE_STATUS=$(jq -r ".phases.${ARTIFACT_PHASE}.status // \"\"" "$STATE_FILE" 2>/dev/null || echo "")

UPDATED=$(jq "${FULL_UPDATE}" "$STATE_FILE") || exit 0
printf '%s\n' "$UPDATED" > "$STATE_FILE"

# ─── 9. Update .forge/efforts/README.md row if phase status changed ──────────
# The registry uses the format:
#   | effort-id | Title | type | tier | risk | parent | phase | status |
# This update is best-effort and only fires when the artifact phase status
# changed (e.g., not_started → in_progress). currentPhase transitions are
# handled by forge:promote skills; this hook only updates phase-level status.

README_FILE=".forge/efforts/README.md"

if [ -f "$README_FILE" ]; then
  NEW_PHASE_STATUS=$(jq -r ".phases.${ARTIFACT_PHASE}.status // \"\"" "$STATE_FILE" 2>/dev/null || echo "")

  if [ "$OLD_PHASE_STATUS" != "$NEW_PHASE_STATUS" ] && [ -n "$NEW_PHASE_STATUS" ]; then
    # Update the status column in the row matching this effort ID.
    # Row pattern (columns separated by | ):
    #   | effort-id | ... | phase | status |
    # We replace the last two pipe-delimited fields (phase and status) on the
    # matching row. The effort ID may be prefixed with → arrows for child items.
    CURRENT_PHASE_IN_README=$(jq -r '.currentPhase // ""' "$STATE_FILE")

    # Build a sed expression that matches the row by effort ID and updates
    # the phase and status columns (last two data columns before the trailing |)
    # Pattern: find a line containing " effort-id " and replace the last
    # two | ... | fields with the current values.
    ESCAPED_ID=$(printf '%s' "$EFFORT_ID" | sed 's/[\/&]/\\&/g')
    ESCAPED_PHASE=$(printf '%s' "$CURRENT_PHASE_IN_README" | sed 's/[\/&]/\\&/g')
    ESCAPED_STATUS=$(printf '%s' "$NEW_PHASE_STATUS" | sed 's/[\/&]/\\&/g')

    # Match rows that have the effort ID in the ID column (first data column).
    # The ID column may have leading spaces/arrows but always ends before the
    # first " | " separator. Replace the last two fields on matching lines.
    TEMP_FILE=$(mktemp)
    sed "s|\(.*| ${ESCAPED_ID} |.*| \)[^|]* | [^|]* |$|\1${ESCAPED_PHASE} | ${ESCAPED_STATUS} |" \
      "$README_FILE" > "$TEMP_FILE" 2>/dev/null && mv "$TEMP_FILE" "$README_FILE" || rm -f "$TEMP_FILE"
  fi
fi

# ─── 10. Emit telemetry for phase transition ──────────────────────────────────

if [ "$OLD_PHASE_STATUS" != "$NEW_PHASE_STATUS" ] && [ -n "$NEW_PHASE_STATUS" ]; then
  _telem_metadata=$(jq -n \
    --arg phase "$ARTIFACT_PHASE" \
    --arg from  "$OLD_PHASE_STATUS" \
    --arg to    "$NEW_PHASE_STATUS" \
    '{"phase":$phase,"from":$from,"to":$to}')
  telemetry_event "phase_transition" "" "$_telem_metadata"
fi

exit 0
