#!/usr/bin/env bash
# forge — tool execution telemetry
# Trigger: PostToolUse, PostToolUseFailure (Skill | mcp__.* | Agent)
# Scope:   All repos — fires whenever a Skill, MCP tool, or Agent tool completes
#          or fails. Forge enrichment fields (forge_version, effort_id, phase) are
#          populated only when .forge exists; null otherwise.
#
# Events emitted:
#   skill_invoked  / skill_failed
#   mcp_invoked    / mcp_failed
#   agent_invoked  / agent_failed
#
# Exit codes: Always 0. Never exits 2.

set -euo pipefail

# ─── 1. Read stdin ────────────────────────────────────────────────────────────
#
# PostToolUse documented common fields:
#   session_id, tool_name, tool_use_id, tool_input (object)
#
# PostToolUseFailure additional documented fields:
#   error (string), is_interrupt (bool)

HOOK_INPUT=$(cat)

# ─── 2. Session correlation ───────────────────────────────────────────────────

export FORGE_SESSION_ID
FORGE_SESSION_ID=$(printf '%s' "$HOOK_INPUT" | jq -r '.session_id // ""' 2>/dev/null || echo "")

# ─── 3. Source telemetry library ──────────────────────────────────────────────

_HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/telemetry.sh
source "${_HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true

# ─── 4. Extract common fields ─────────────────────────────────────────────────

_TOOL_NAME=$(printf '%s' "$HOOK_INPUT" | jq -r '.tool_name // ""' 2>/dev/null || echo "")
_TOOL_USE_ID=$(printf '%s' "$HOOK_INPUT" | jq -r '.tool_use_id // ""' 2>/dev/null || echo "")
_TOOL_INPUT=$(printf '%s' "$HOOK_INPUT" | jq -c '.tool_input // {}' 2>/dev/null || echo "{}")

# Discriminate success vs failure by presence of the documented `error` field
_IS_FAILURE=$(printf '%s' "$HOOK_INPUT" | jq -r 'if has("error") then "true" else "false" end' 2>/dev/null || echo "false")
_ERROR=$(printf '%s' "$HOOK_INPUT" | jq -r '.error // ""' 2>/dev/null || echo "")
_IS_INTERRUPT=$(printf '%s' "$HOOK_INPUT" | jq -r '.is_interrupt // false' 2>/dev/null || echo "false")

# ─── 5. Map tool name to family and event type ────────────────────────────────

_FAMILY=""
_SKILL_NAME=""
_MCP_SERVER=""
_MCP_TOOL=""
_AGENT_PROMPT_SUMMARY=""

case "$_TOOL_NAME" in
  Skill)
    _FAMILY="skill"
    # skill_name is the first positional arg in tool_input for the Skill tool
    _SKILL_NAME=$(printf '%s' "$_TOOL_INPUT" | jq -r '.skill // .name // ""' 2>/dev/null || echo "")
    ;;
  Agent)
    _FAMILY="agent"
    # Summarise the agent prompt to first 120 chars to keep metadata compact
    _AGENT_PROMPT_SUMMARY=$(printf '%s' "$_TOOL_INPUT" | jq -r '.prompt // ""' 2>/dev/null \
      | cut -c1-120 || echo "")
    ;;
  mcp__*)
    _FAMILY="mcp"
    # tool_name format: mcp__<server>__<tool>
    # Split on the SECOND occurrence of __ (double-underscore) so server names
    # containing single underscores (e.g. my_server) are preserved correctly.
    _MCP_WITHOUT_PREFIX=$(printf '%s' "$_TOOL_NAME" | sed 's/^mcp__//')
    _MCP_SERVER=$(printf '%s' "$_MCP_WITHOUT_PREFIX" | sed 's/__.*$//')
    _MCP_TOOL=$(printf '%s' "$_MCP_WITHOUT_PREFIX" | sed 's/^[^_]*__//' | sed 's/^.*__//')
    # Re-extract using awk for correctness: field 1 is server, field 2 is tool
    if command -v awk >/dev/null 2>&1; then
      _MCP_SERVER=$(printf '%s' "$_MCP_WITHOUT_PREFIX" | awk -F'__' '{print $1}')
      _MCP_TOOL=$(printf '%s' "$_MCP_WITHOUT_PREFIX" | awk -F'__' '{for(i=2;i<=NF;i++) printf "%s%s",$i,(i<NF?"__":""); print ""}')
    fi
    ;;
  *)
    # Should not reach here given the matchers in hooks.json, but exit cleanly
    exit 0
    ;;
esac

if [ "$_IS_FAILURE" = "true" ]; then
  _EVENT_TYPE="${_FAMILY}_failed"
else
  _EVENT_TYPE="${_FAMILY}_invoked"
fi

# ─── 6. Build metadata ────────────────────────────────────────────────────────

if ! command -v jq >/dev/null 2>&1; then
  exit 0
fi

# Summarise tool_input to first 200 chars of its JSON representation
_TOOL_INPUT_SUMMARY=$(printf '%s' "$_TOOL_INPUT" | jq -c '.' 2>/dev/null | cut -c1-200 || echo "")

_METADATA=$(jq -n \
  --arg  tool_name            "$_TOOL_NAME" \
  --arg  tool_use_id          "$_TOOL_USE_ID" \
  --arg  tool_input_summary   "$_TOOL_INPUT_SUMMARY" \
  --arg  error                "$_ERROR" \
  --argjson is_interrupt      "$_IS_INTERRUPT" \
  --argjson is_failure        "$_IS_FAILURE" \
  --arg  skill_name           "$_SKILL_NAME" \
  --arg  mcp_server           "$_MCP_SERVER" \
  --arg  mcp_tool             "$_MCP_TOOL" \
  --arg  agent_prompt_summary "$_AGENT_PROMPT_SUMMARY" \
  '{
    tool_name:            $tool_name,
    tool_use_id:          $tool_use_id,
    tool_input_summary:   ($tool_input_summary | if . == "" then null else . end),
    error:                ($error | if . == "" then null else . end),
    is_interrupt:         (if $is_failure == "true" then $is_interrupt else null end),
    skill_name:           ($skill_name | if . == "" then null else . end),
    mcp_server:           ($mcp_server | if . == "" then null else . end),
    mcp_tool:             ($mcp_tool   | if . == "" then null else . end),
    agent_prompt_summary: ($agent_prompt_summary | if . == "" then null else . end)
  }' 2>/dev/null) || _METADATA="{}"

# ─── 7. Emit event ────────────────────────────────────────────────────────────

# Top-level skill_name mapping (plan step 5):
#   Skill  → actual skill name (e.g. "forge:plan")
#   mcp    → full tool name   (e.g. "mcp__github__search_issues")
#   agent  → literal "Agent"
case "$_FAMILY" in
  skill) _TOP_SKILL="$_SKILL_NAME" ;;
  mcp)   _TOP_SKILL="$_TOOL_NAME" ;;
  agent) _TOP_SKILL="Agent" ;;
  *)     _TOP_SKILL="" ;;
esac

telemetry_event "$_EVENT_TYPE" "$_TOP_SKILL" "$_METADATA"

exit 0
