#!/usr/bin/env bash
# forge — skill invocation telemetry
# Trigger: PostToolUse (Skill)
# Scope:   Project — registered in hooks/hooks.json.
#          Fires after every successful Skill tool call.
#
# Purpose: Record a telemetry event for any forge skill invocation.
#          event_type is the bare skill name (e.g. "status", "init", "pin").
#
# Note: PostToolUse does not fire for the Skill tool per Claude Code docs.
#       This file is kept for future use if that changes.
#
# Exit codes: Always 0. PostToolUse hooks cannot exit 2.

set -euo pipefail

# Only relevant in Forge-initialized repositories
[ -f ".forge/README.md" ] || exit 0

# Source telemetry library
_HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/telemetry.sh
source "${_HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true

# ─── 1. Read stdin ────────────────────────────────────────────────────────────

HOOK_INPUT=$(cat)

# Export session_id for telemetry correlation
export FORGE_SESSION_ID
FORGE_SESSION_ID=$(printf '%s' "$HOOK_INPUT" | jq -r '.session_id // ""' 2>/dev/null || echo "")

# ─── 2. Extract skill name from tool_input ────────────────────────────────────

SKILL=$(printf '%s' "$HOOK_INPUT" | jq -r '.tool_input.skill // ""' 2>/dev/null || echo "")
[ -n "$SKILL" ] || exit 0

# Only record telemetry for forge skills (with or without leading "forge:" prefix)
case "$SKILL" in
  forge:*) ;;
  *)       exit 0 ;;
esac

# Strip "forge:" prefix — event_type is the bare skill name (e.g. "status", "init")
SKILL="${SKILL#forge:}"

# ─── 3. Record telemetry ──────────────────────────────────────────────────────

telemetry_event "skill_invoked" "forge:${SKILL}"

exit 0
