#!/usr/bin/env bash
# forge — phase context hook
# Trigger: PreToolUse (Write|Edit)
# Scope:   Files under .forge/efforts/ only
#
# Before any Write or Edit to a .forge/efforts/ path, informs Claude whether
# the write is atypical for the current phase (e.g., modifying requirements/
# while in the implementation phase). Exits 0 in all cases — writes are never
# blocked (ADR-002: phase gates inform, not block).

# Get the target file path from Claude Code hook input environment.
# Claude Code sets CLAUDE_TOOL_INPUT_FILE_PATH for Write, CLAUDE_TOOL_INPUT_PATH for Edit.
FILE_PATH="${CLAUDE_TOOL_INPUT_FILE_PATH:-${CLAUDE_TOOL_INPUT_PATH:-}}"

# If no path available, proceed silently.
if [ -z "$FILE_PATH" ]; then
  exit 0
fi

# Normalize: strip leading ./ if present.
FILE_PATH="${FILE_PATH#./}"

# Only apply to paths under .forge/efforts/.
if [[ "$FILE_PATH" != .forge/efforts/* ]]; then
  exit 0
fi

# Extract effort ID: .forge/efforts/<effort-id>/...
# Strip the .forge/efforts/ prefix, then take the first path segment.
rest="${FILE_PATH#.forge/efforts/}"
EFFORT_ID="${rest%%/*}"

if [ -z "$EFFORT_ID" ]; then
  exit 0
fi

# The path relative to the effort root (after .forge/efforts/<id>/)
EFFORT_REL="${rest#"$EFFORT_ID"/}"

STATE_JSON=".forge/efforts/${EFFORT_ID}/.state.json"

# If .state.json is absent or unreadable, proceed silently.
if [ ! -f "$STATE_JSON" ]; then
  exit 0
fi

# Read current phase from .state.json using jq.
CURRENT_PHASE=$(jq -r '.currentPhase // empty' "$STATE_JSON" 2>/dev/null)
if [ -z "$CURRENT_PHASE" ]; then
  exit 0
fi

# Determine the artifact category from the file path.
# Map path prefix to the phase it belongs to.
if [[ "$EFFORT_REL" == requirements/* ]]; then
  ARTIFACT_PHASE="discovery"
  ARTIFACT_CATEGORY="requirements"
elif [[ "$EFFORT_REL" == spec/* ]]; then
  ARTIFACT_PHASE="discovery"
  ARTIFACT_CATEGORY="spec"
elif [[ "$EFFORT_REL" == validation/* ]]; then
  # Validation writes are neutral — not atypical in any phase.
  exit 0
elif [[ "$EFFORT_REL" == plan/* ]]; then
  ARTIFACT_PHASE="planning"
  ARTIFACT_CATEGORY="plan"
else
  # No recognized artifact category (e.g., .state.json itself, or other paths).
  exit 0
fi

# Phase ordering for comparison: discovery < planning < implementation < validation
phase_order() {
  case "$1" in
    discovery)      echo 1 ;;
    planning)       echo 2 ;;
    implementation) echo 3 ;;
    validation)     echo 4 ;;
    *)              echo 0 ;;
  esac
}

ARTIFACT_ORDER=$(phase_order "$ARTIFACT_PHASE")
CURRENT_ORDER=$(phase_order "$CURRENT_PHASE")

# If artifact phase is not earlier than the current phase, this is a typical write.
if [ "$ARTIFACT_ORDER" -ge "$CURRENT_ORDER" ]; then
  exit 0
fi

# Artifact phase is earlier than current phase — potentially atypical.
# Only emit a notice if the earlier phase has been approved.
PHASE_STATUS=$(jq -r --arg phase "$ARTIFACT_PHASE" '.phases[$phase].status // empty' "$STATE_JSON" 2>/dev/null)

if [ "$PHASE_STATUS" != "approved" ]; then
  # Phase not approved yet — treat as typical write (no approval to protect).
  exit 0
fi

# Atypical write: modifying an artifact from an approved earlier phase.
# Read approvedAt timestamp if available.
APPROVED_AT=$(jq -r --arg phase "$ARTIFACT_PHASE" '.phases[$phase].approvedAt // empty' "$STATE_JSON" 2>/dev/null)

if [ -n "$APPROVED_AT" ]; then
  APPROVAL_NOTE="(approved on ${APPROVED_AT})"
else
  APPROVAL_NOTE="(status: approved)"
fi

# Emit informational context. Claude Code injects stdout as pre-tool context.
# This is purely informational — the write proceeds regardless (ADR-002).
printf '⚒️🔥⚒️ Note: You are modifying %s, which was produced during the %s phase %s. The effort is currently in the %s phase.\nThis modification will be tracked as a post-approval change in .state.json and must be\nreconciled before graduation. The write will proceed.\n' \
  "$EFFORT_REL" \
  "$ARTIFACT_PHASE" \
  "$APPROVAL_NOTE" \
  "$CURRENT_PHASE"

exit 0
