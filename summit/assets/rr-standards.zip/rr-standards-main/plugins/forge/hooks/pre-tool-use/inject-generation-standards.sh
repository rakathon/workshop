#!/usr/bin/env bash
# forge — generation standards injection hook
# Trigger: PreToolUse (Write|Edit)
# Scope:   Project — registered in .claude/settings.json with absolute path
#          to this script within the pinned plugin cache entry.
#
# Outputs the applicable language guide to stdout before each Write/Edit so
# Claude Code injects it as context. Standards are enforced at generation
# time without engineer invocation (TR-6).

set -e

# Resolve plugin root from this script's own location:
#   <plugin_root>/hooks/pre-tool-use/inject-generation-standards.sh
PLUGIN_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"

# Check for coding standards exemption (TR-9.2)
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  [ "$cs" = "exempt" ] && exit 0
fi

# Get target file path from Claude Code hook input environment
FILE_PATH="${CLAUDE_TOOL_INPUT_FILE_PATH:-${CLAUDE_TOOL_INPUT_PATH:-}}"

if [ -z "$FILE_PATH" ]; then
  exit 0  # no path available — proceed without injection
fi

# Detect language from file extension
ext="${FILE_PATH##*.}"
language=""
case "$ext" in
  go)             language="go" ;;
  java)           language="java" ;;
  kt|kts)         language="kotlin" ;;
  swift)          language="swift" ;;
  ts|tsx)         language="typescript" ;;
  js|jsx|mjs|cjs) language="javascript" ;;
  py)             language="python" ;;
  rb)             language="ruby" ;;
  rs)             language="rust" ;;
esac

if [ -z "$language" ]; then
  exit 0  # no standard for this extension — proceed silently
fi

# Resolve language guide path relative to plugin root
LANG_GUIDE="$PLUGIN_ROOT/languages/$language/guide.md"

if [ ! -f "$LANG_GUIDE" ]; then
  printf "forge: no language guide for .%s files\n" "$ext" >&2
  exit 0
fi

# Inject guide content — Claude Code reads stdout and injects as context
cat "$LANG_GUIDE"
exit 0
