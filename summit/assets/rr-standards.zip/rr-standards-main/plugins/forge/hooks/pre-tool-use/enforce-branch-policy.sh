#!/usr/bin/env sh
# enforce-branch-policy.sh — PreToolUse hook
# Blocks git commit / git push on the default branch unless an admin override is active.
# Also validates branch name format on git commit (TR-7) and emits alignment warnings
# on git push (TR-9).

# Step 1: Check tool name — only intercept Bash tool calls
if [ "${CLAUDE_TOOL_NAME}" != "Bash" ]; then
  exit 0
fi

# Step 2: Extract command from CLAUDE_TOOL_INPUT and check for git commit / git push
#
# Strategy: two-pass detection to handle compound commands, heredocs, and multiline input.
#
# Pass 1 — fast substring check directly on the raw JSON input.
#   Catches: "git commit", "git push" anywhere in the tool input blob, including
#   compound commands (git add ... && git commit) and heredoc-based commit messages.
#   This is intentionally broad; Pass 2 / later checks narrow it down.
raw_input="${CLAUDE_TOOL_INPUT:-}"
has_git_commit=0
has_git_push=0
case "${raw_input}" in
  *"git commit"*) has_git_commit=1 ;;
esac
case "${raw_input}" in
  *"git push"*) has_git_push=1 ;;
esac

if [ "${has_git_commit}" -eq 0 ] && [ "${has_git_push}" -eq 0 ]; then
  exit 0
fi

# Pass 2 — extract the full command string for finer-grained checks below.
#   Best-effort; if extraction fails, fall back to the raw-input signals from Pass 1.
command_value=""
if command -v jq >/dev/null 2>&1; then
  command_value=$(printf '%s' "${raw_input}" | jq -r '.command // empty' 2>/dev/null)
fi
# If jq unavailable or returned empty, use the raw input as the command value so
# downstream grep/case checks still work.
if [ -z "${command_value}" ]; then
  command_value="${raw_input}"
fi

# Step 3: Check admin override
_write_audit_log() {
  _audit_branch="$1"
  _audit_reason="$2"
  _audit_timestamp=$(date -u +"%Y-%m-%dT%H-%M-%SZ" 2>/dev/null || echo "unknown")
  _audit_iso=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || echo "unknown")
  _audit_dir=".forge/audit"
  mkdir -p "${_audit_dir}" 2>/dev/null
  cat > "${_audit_dir}/${_audit_timestamp}.json" <<AUDIT
{
  "operation": "direct_commit_override",
  "reason": "${_audit_reason}",
  "branch": "${_audit_branch}",
  "timestamp": "${_audit_iso}"
}
AUDIT
}

if [ "${FORGE_ALLOW_MAIN_COMMIT}" = "1" ] || [ -n "${FORGE_ADMIN_OP}" ]; then
  # Determine current branch for audit log (best effort; failures ignored)
  _override_branch=$(git branch --show-current 2>/dev/null || echo "")
  # Determine audit reason: FORGE_ADMIN_OP takes precedence
  if [ -n "${FORGE_ADMIN_OP}" ]; then
    _override_reason="${FORGE_ADMIN_OP}"
  else
    _override_reason="FORGE_ALLOW_MAIN_COMMIT=1 set by engineer"
  fi
  _write_audit_log "${_override_branch}" "${_override_reason}"
  exit 0
fi

# Step 4: Get current branch
current_branch=$(git branch --show-current 2>/dev/null || echo "")
if [ -z "${current_branch}" ]; then
  exit 0
fi

# Step 5: Determine default branch
default_branch=$(git config init.defaultBranch 2>/dev/null)
if [ -z "${default_branch}" ]; then
  default_branch="main"
fi

# Step 6: Compare — allow if not on the default branch
if [ "${current_branch}" != "${default_branch}" ]; then
  # Not on default branch — proceed to format validation and alignment checks below
  :
else
  # Step 7: Block — on default branch with no override active
  # Attempt to read the active effort ID from .forge/efforts/README.md
  active_effort="null"
  next_action="Create an effort branch first: use forge:effort to start a new effort"

  if [ -f ".forge/efforts/README.md" ]; then
    # Look for a table row where the Status column contains "in_progress" or "active"
    # The table format is: | effort-id | ... | in_progress | ... |
    # Extract the first matching effort ID (first pipe-delimited field after leading pipe)
    effort_id=$(grep -m1 'in_progress\|active' .forge/efforts/README.md 2>/dev/null | sed 's/^[[:space:]]*|[[:space:]]*//' | sed 's/[[:space:]]*|.*//' 2>/dev/null)
    if [ -n "${effort_id}" ]; then
      # Sanitize for JSON embedding (remove quotes and backslashes)
      effort_id=$(printf '%s' "${effort_id}" | tr -d '"\\')
      active_effort="\"${effort_id}\""
      next_action="Switch to your effort branch: git checkout effort/${effort_id}"
    fi
  fi

  # Emit structured diagnostic to stderr and exit 2
  cat >&2 <<JSON
{
  "type": "branch_policy_violation",
  "blocked": true,
  "reason": "Direct commits to '${default_branch}' are not permitted. All work must happen on a feature branch and be merged via pull request.",
  "currentBranch": "${current_branch}",
  "activeEffort": ${active_effort},
  "nextAction": "${next_action}"
}
JSON

  exit 2
fi

# forge:commit intercept — redirect raw git commit to forge:commit skill
# Applies to git commit only, unless forge:commit itself is running (FORGE_COMMIT_IN_PROGRESS=1)
if echo "${command_value}" | grep -q "git commit"; then
  if [ -z "${FORGE_COMMIT_IN_PROGRESS}" ]; then
    # Only redirect when Forge is initialized in this repo
    if [ -f ".forge/README.md" ]; then
      cat >&2 <<JSON
{
  "type": "forge_commit_redirect",
  "blocked": true,
  "reason": "Raw git commit detected. Use forge:commit instead — it enforces conventional commit standards, validates branch naming, computes semantic version impact, and records traceability metadata.",
  "nextAction": "Run forge:commit to create this commit with full Forge ceremony."
}
JSON
      exit 2
    fi
  fi
fi

# Branch name format validation (TR-7) — applies to git commit only
if echo "${command_value}" | grep -q "git commit"; then
  # Skip if bypass flag set
  if [ -n "${FORGE_SKIP_BRANCH_VALIDATION}" ]; then
    exit 0
  fi

  # Resolve branch_regex from .forge/branching.md frontmatter (TR-3)
  # Falls back to Forge built-in default if absent or field missing
  branch_regex=""
  if [ -f ".forge/branching.md" ]; then
    branch_regex=$(python3 -c "
import re
try:
  content = open('.forge/branching.md').read()
  m = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
  if m:
    for line in m.group(1).splitlines():
      if line.strip().startswith('branch_regex:'):
        val = line.split(':', 1)[1].strip().strip('\"').strip(\"'\")
        print(val)
        break
except:
  pass
" 2>/dev/null)
  fi

  if [ -z "${branch_regex}" ]; then
    branch_regex="^(effort|feature|feat|fix|hotfix|chore|docs|refactor|release)/[a-z0-9][a-z0-9-]*$"
  fi

  if ! echo "${current_branch}" | grep -qE "${branch_regex}"; then
    # invalid branch name — emit diagnostic and exit 2
    cat >&2 <<JSON
{
  "type": "branch_name_violation",
  "blocked": true,
  "reason": "Branch '${current_branch}' does not follow this repository's naming convention.",
  "currentBranch": "${current_branch}",
  "convention": "See .forge/branching.md for this repository's branch naming convention.",
  "nextAction": "Rename your branch to match the convention: git branch -m <new-name>"
}
JSON
    exit 2
  fi
fi

# Push-time alignment warning (TR-9) — applies to git push only, warning only (exit 0)
if echo "${command_value}" | grep -q "git push"; then
  # Skip if bypass flag set
  if [ -n "${FORGE_SKIP_BRANCH_VALIDATION}" ]; then
    exit 0
  fi
  # Skip effort branches — always aligned
  if echo "${current_branch}" | grep -qE "^effort/"; then
    exit 0
  fi
  # Extract type prefix
  branch_type="${current_branch%%/*}"
  # Get commits and files being pushed
  push_commits=$(git log "origin/${default_branch}..HEAD" --oneline 2>/dev/null | head -20)
  push_files=$(git diff "origin/${default_branch}...HEAD" --name-only 2>/dev/null | head -30)
  # Only check if there are commits to push
  if [ -z "${push_commits}" ]; then
    exit 0
  fi
  # Build prompt for claude
  alignment_prompt="Branch: ${current_branch} (type: ${branch_type}). Commits: ${push_commits}. Files: ${push_files}. Does the branch type match the work? Reply YES or NO. If NO, suggest a better branch name in format <type>/<slug>."
  # Run claude -p with timeout
  alignment_result=$(echo "${alignment_prompt}" | timeout 10 claude -p --max-tokens 60 2>/dev/null || echo "")
  # Parse result — if contains NO, emit warning
  if echo "${alignment_result}" | grep -qi "^no\b"; then
    suggestion=$(echo "${alignment_result}" | grep -oE '[a-z]+/[a-z0-9-]+' | head -1)
    printf "⚒️🔥⚒️ ⚠️  Branch alignment check: branch name may not match the work being pushed.\n"
    printf "   Current branch: %s\n" "${current_branch}"
    if [ -n "${suggestion}" ]; then
      printf "   Suggestion: %s\n" "${suggestion}"
      printf "   To rename before opening PR: git branch -m %s\n" "${suggestion}"
    fi
    printf "   Push continues.\n\n"
  fi
  # Always exit 0 — alignment check is advisory only
  exit 0
fi

exit 0
