#!/usr/bin/env bash
# forge — telemetry library
# Source this file and call telemetry_event to capture forge usage events.
# POSTs a JSON payload to the forge-events API endpoint.
# Override the endpoint with FORGE_TELEMETRY_URL if needed.
#
# Usage:
#   source "${HOOK_DIR}/../lib/telemetry.sh" 2>/dev/null || true
#   telemetry_event "skill_invoked" "forge:plan"
#   telemetry_event "session_start"
#   telemetry_event "phase_transition" "" '{"phase":"discovery","from":"not_started","to":"in_progress"}'

# Default telemetry endpoint — override by setting FORGE_TELEMETRY_URL in the environment
_FORGE_TELEMETRY_URL="${FORGE_TELEMETRY_URL:-https://rr-productivity-portal-prod.shared.rr-it.com/api/forge-events}"

# telemetry_event <event_type> [skill_name] [metadata_json]
#   event_type    — one of: session_start, session_end, skill_invoked, phase_transition
#   skill_name    — optional, e.g. "forge:plan" (leave empty for non-skill events)
#   metadata_json — optional valid JSON object string (default: {})
#
# Session correlation: hooks set FORGE_SESSION_ID before calling telemetry_event.
# The value comes from the hook stdin JSON field "session_id".
telemetry_event() {
    local event_type="${1:-unknown}"
    local skill_name="${2:-}"
    local metadata="${3:-}"
    [ -n "$metadata" ] || metadata="{}"
    local session_id="${FORGE_SESSION_ID:-}"

    # Resolve git project root so hooks fired from a subdirectory still work.
    local _forge_root
    _forge_root=$(git rev-parse --show-toplevel 2>/dev/null || echo "")

    # Forge enrichment is best-effort — events are emitted from any repo.
    # _is_forge_repo controls whether forge_version, effort_id, and phase are populated.
    local _is_forge_repo=0
    local _forge_dir=""
    if [ -n "$_forge_root" ] && [ -d "${_forge_root}/.forge" ]; then
        _is_forge_repo=1
        _forge_dir="${_forge_root}/.forge"
    elif [ -d ".forge" ]; then
        _is_forge_repo=1
        _forge_dir="$(pwd)/.forge"
    fi
    echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") telemetry_event called event=$event_type is_forge_repo=${_is_forge_repo} forge_root=${_forge_root} cwd=$(pwd)" >> /tmp/forge-telemetry-debug.txt

    # Generate a UUID — uuidgen is standard on macOS
    local event_id
    event_id=$(uuidgen 2>/dev/null \
        || printf '%s-%s-%s-%s-%s' \
            "$(date +%s)" "$$" "$RANDOM" "$RANDOM" "$RANDOM")

    local event_timestamp
    event_timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

    # Repo name: derive from git remote, fall back to directory basename.
    # Cached in FORGE_REPO_NAME for the lifetime of the shell process — the remote
    # URL is static for a session and this avoids forking git on every event.
    if [ -z "${FORGE_REPO_NAME:-}" ]; then
        FORGE_REPO_NAME=$(git remote get-url origin 2>/dev/null | sed 's|.*/||; s|\.git$||' || true)
        [ -z "$FORGE_REPO_NAME" ] && FORGE_REPO_NAME=$(basename "$(pwd)" 2>/dev/null || echo "unknown")
        export FORGE_REPO_NAME
    fi
    local repo_name="$FORGE_REPO_NAME"

    # Forge enrichment fields — populated only when inside a Forge-initialized repo.
    local forge_version="" effort_id="" phase=""
    if [ "$_is_forge_repo" -eq 1 ] && [ -n "$_forge_dir" ]; then
        forge_version=$(grep "^active_version=" "${_forge_dir}/version" 2>/dev/null | cut -d= -f2 || echo "")

        # Active effort ID and phase — pick the first non-closed/completed effort found.
        local _sf
        if [ -d "${_forge_dir}/efforts" ] && command -v jq >/dev/null 2>&1; then
            for _sf in "${_forge_dir}"/efforts/*/.state.json; do
                [ -f "$_sf" ] || continue
                local _candidate_id _candidate_phase
                _candidate_id=$(jq -r '.id // ""' "$_sf" 2>/dev/null || echo "")
                _candidate_phase=$(jq -r '.currentPhase // ""' "$_sf" 2>/dev/null || echo "")
                [ -n "$_candidate_id" ] || continue
                case "$_candidate_phase" in
                    complete|closed|graduated) continue ;;
                esac
                effort_id="$_candidate_id"
                phase="$_candidate_phase"
                break
            done
        fi
    fi

    # Sanitize metadata: normalize through jq so --argjson never sees malformed input.
    # Separate capture from exit-code check — jq on some versions outputs partial JSON
    # before exiting non-zero (e.g. trailing garbage after a valid object), so the
    # compound $(cmd) || fallback form is not reliable.
    if command -v jq >/dev/null 2>&1; then
        local _sanitized
        _sanitized=$(printf '%s' "$metadata" | jq -c '.' 2>/dev/null)
        if [ $? -eq 0 ] && [ -n "$_sanitized" ]; then
            metadata="$_sanitized"
        else
            metadata="{}"
        fi
    fi

    # Build JSON payload using jq for safe escaping
    local payload
    if command -v jq >/dev/null 2>&1; then
        payload=$(jq -n \
            --arg event_id        "$event_id" \
            --arg event_timestamp "$event_timestamp" \
            --arg event_type      "$event_type" \
            --arg engineer_id     "${USER:-unknown}" \
            --arg repo_name       "$repo_name" \
            --arg skill_name      "$skill_name" \
            --arg effort_id       "$effort_id" \
            --arg phase           "$phase" \
            --arg forge_version   "$forge_version" \
            --arg session_id      "$session_id" \
            --argjson metadata    "$metadata" \
            '{
                event_id:        $event_id,
                event_timestamp: $event_timestamp,
                event_type:      $event_type,
                engineer_id:     $engineer_id,
                repo_name:       $repo_name,
                skill_name:      $skill_name,
                effort_id:       $effort_id,
                phase:           $phase,
                forge_version:   $forge_version,
                session_id:      $session_id,
                metadata:        $metadata
            }' 2>/tmp/forge-telemetry-jq-err.txt) || {
        echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") jq_failed event=$event_type metadata_len=${#metadata} metadata_preview=$(printf '%s' "$metadata" | head -c 200) jq_err=$(cat /tmp/forge-telemetry-jq-err.txt 2>/dev/null | head -c 200)" >> /tmp/forge-telemetry-debug.txt
        return 0
    }
    else
        return 0  # jq required for safe JSON construction
    fi

    # POST fire-and-forget: background subprocess, 5s timeout, logs status code
    ( _http_status=$(curl --silent --max-time 5 \
        -X POST \
        -H "Content-Type: application/json" \
        -d "$payload" \
        -o /tmp/forge-telemetry-response.txt \
        -w "%{http_code}" \
        "$_FORGE_TELEMETRY_URL" 2>/tmp/forge-telemetry-curl-err.txt)
      echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") event=$event_type curl_status=$_http_status response=$(cat /tmp/forge-telemetry-response.txt 2>/dev/null)" >> /tmp/forge-telemetry-debug.txt
    ) &
}
