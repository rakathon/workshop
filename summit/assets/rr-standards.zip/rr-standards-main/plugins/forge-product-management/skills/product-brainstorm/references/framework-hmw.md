# Framework: How Might We (HMW)

**When to use:** Problem Exploration and Solution Ideation modes. Converts a vague problem
into generative questions that open up solution space.

## Step-by-step

1. Take the PM's problem statement or situation. Reframe it as an HMW question:
   Format: `"How might we [do X] so that [outcome Y]?"`

2. Generate 5–10 HMW variations before stopping. Each should be:
   - Broad enough to allow many different solutions
   - Specific enough to be actionable (not "how might we improve things?")
   - Varied in framing — try user-centric, company-centric, constraint-removing, and
     constraint-amplifying versions

3. Variation types to use:
   - **User outcome:** "How might we make it effortless for [user] to [job]?"
   - **Remove obstacle:** "How might we eliminate the need for [painful step]?"
   - **Invert:** "How might we make [the hard case] the default?"
   - **Scale:** "How might we do this for 10x the users with no extra effort?"

4. After generating 5–10 HMWs, ask the PM: "Which of these feel most generative to you?
   We'll use those to drive the next round."

5. Select 2–3 HMWs to carry into the next step.
