# forge:product-brainstorm

A structured, opinionated brainstorming partner for product managers. Runs interactive
ideation sessions using seven proven PM frameworks, auto-detecting the right mode from
the PM's opening statement — no explicit mode selection needed.

Works in both Forge-initialized projects and plain directories (Claude Desktop / Cowork /
any environment without `.forge/`). No Forge setup, active effort, or product directory
is required to run a brainstorm session.

---

## Usage

```
forge:product-brainstorm
```

No arguments required. Start by describing what you want to think through. The skill
infers the session mode from your opening statement and names it before proceeding.

---

## When to Use

- You need to explore a problem that isn't clearly defined yet
- You need ideas for a feature, initiative, or response to a customer need
- You have a solution hypothesis and want to surface the assumptions underneath it
- You're weighing strategic tradeoffs or positioning options
- You feel stuck, or a brainstorm has been converging too quickly on obvious ideas
- Any time you say: "I need to brainstorm", "help me think through this", "I need ideas for...", "how might we...", "I'm trying to decide between...", or "let's ideate"

---

## How It Works

Every session follows a five-step structure:

1. **Frame** — Establish the goal, the user, and what is actually fixed vs. assumed to be fixed
2. **Diverge** — Generate ideas using one or two frameworks selected for the mode
3. **Provoke** — Introduce at least one provocation to break fixation before converging
4. **Converge** — Cluster, score informally, and select 2–3 ideas worth developing further
5. **Capture** — Close with an explicit prompt to persist output and name next steps

---

## Session Modes

The skill auto-detects one of four modes from how the PM opens the conversation:

| Mode | When it applies |
|------|-----------------|
| **Problem Exploration** | The problem isn't clearly defined; framing is fuzzy; "we're getting complaints but I don't know why" |
| **Solution Ideation** | The problem is stated, but solutions are not; "I need ideas for...", "how might we..." |
| **Assumption Testing** | A solution hypothesis exists; "I'm worried whether X will work", "we're planning to do X but I'm not sure about Y" |
| **Strategy Exploration** | Strategic tradeoffs, positioning, or prioritization; "I'm trying to decide between...", "should we do X or Y" |

The detected mode is stated at the start of the session. If the opening is genuinely ambiguous,
the skill asks one targeted question to resolve it rather than presenting a list to choose from.

---

## Frameworks

Seven frameworks are available. The skill selects one or two per session based on the detected mode:

| Framework | Best for |
|-----------|----------|
| **How Might We (HMW)** | Converting vague problems into generative questions; opening up solution space |
| **Jobs to Be Done (JTBD)** | Clarifying customer motivation; surfacing the real competition and opportunity |
| **OST-lite** | Mapping outcomes → opportunities → solutions → key assumptions in a lightweight in-session sketch |
| **First Principles** | Breaking inherited assumptions; redesigning from real constraints only |
| **SCAMPER** | Evolving an existing product, feature, or process through seven structured lenses |
| **OODA Loop** | Competitive and fast-moving situations; sense-making before generating strategic options |
| **Reverse Brainstorming** | Breaking fixation; surfacing hidden assumptions by inverting the problem |

Default framework pairings by mode:

| Mode | Primary | Secondary |
|------|---------|-----------|
| Problem Exploration | HMW | JTBD |
| Solution Ideation | HMW or SCAMPER | Reverse Brainstorming |
| Assumption Testing | OST-lite | First Principles |
| Strategy Exploration | OODA Loop | First Principles |

---

## Anti-Pattern Interception

The skill names and redirects PM anti-patterns when they appear:

- **Solutioning before framing** — jumping to a specific solution before the problem is clear
- **Feature parity trap** — framing the goal as matching a competitor feature
- **Anchoring on constraints** — treating an inherited assumption as a fixed constraint
- **One-idea brainstorm** — refining the same idea instead of generating real alternatives

---

## Session Output

At the close of every session, the skill prompts to capture output. If requested, it can:

- Draft a concise summary: opportunity, 2–3 ideas, key assumptions, next step
- Write an OST-lite sketch in a format compatible with `forge:product-discover`
- Save to the right location for your environment:
  - **Forge mode:** `<product_dir>/` or the active effort's `spec/` directory
  - **Plain mode:** `<product_name>/brainstorm-<date>.md` or any filename you choose

---

## Related Skills

| Skill | Relationship |
|-------|-------------|
| `forge:product-strategy` | Strategy-level work across the whole product; product-brainstorm is a thinking-partner tool that can feed into strategy sessions |
| `forge:elaborate` | Structured discovery for a specific effort; product-brainstorm can help clarify the problem space before elaborate begins |
| `forge:effort` | product-brainstorm can surface ideas that become efforts; use forge:effort to formalize them |
| `forge:product` | Creates the product directory that other PM skills write artifacts into |
