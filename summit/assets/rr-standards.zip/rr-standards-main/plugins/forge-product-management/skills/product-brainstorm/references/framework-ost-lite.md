# Framework: OST-lite (Opportunity Solution Tree, session-level)

**When to use:** Assumption Testing mode and any session where the PM has a hypothesis but
hasn't mapped the full opportunity space. This is a lightweight in-session sketch, not a
substitute for a full `forge:product-discover` artifact.

## Step-by-step

1. **Outcome:** State the desired business or customer outcome in one sentence — this is
   the root of the tree. If the PM can't state it, stop and clarify before continuing.
   Example: "Increase trial-to-paid conversion for self-serve accounts."

2. **Opportunities (3–5):** Brainstorm 3–5 distinct customer problems or needs that, if
   solved, would drive the outcome. These are opportunities, not solutions.
   Example: "Users don't understand value during trial period."

3. **Solutions (2–3 per opportunity):** For each opportunity, sketch 2–3 solution directions.
   Keep these brief — a phrase, not a spec.

4. **Key assumption per solution:** For each solution, name the single most important
   assumption that must be true for it to work.
   Example: "Assumes users will watch a setup video if prompted."

5. Review the tree with the PM: "Which solutions have the weakest assumptions? Those are
   the highest-risk bets. Which have assumptions we can test cheaply?"

Use this tree to drive the rest of the Assumption Testing session.
