# Framework: Jobs to Be Done (JTBD)

**When to use:** Problem Exploration mode, or early in Solution Ideation when the customer
motivation is fuzzy.

## Step-by-step

1. Ask the PM to describe a specific moment when the user reaches for the product or
   feature. Make it concrete: "Tell me about the last time a real user did this."

2. Apply the JTBD template to articulate the job:
   `"When [situation/trigger], I want to [motivation/progress], so I can [expected outcome]."`
   Draft 2–3 versions — functional, emotional, and social jobs are often distinct:
   - **Functional job:** the practical task (e.g., "track my expenses quickly")
   - **Emotional job:** how they want to feel (e.g., "feel in control of my finances")
   - **Social job:** how they want to be perceived (e.g., "look responsible to my partner")

3. Ask: "What were they using before this product to get this job done? Why did that fall short?"
   This surfaces the real competition (often not what we assume) and the gap the product fills.

4. Ask: "Is there a version of this job they can't get done at all today — not just imperfectly?"
   That's often where the highest-value opportunity lives.

5. Synthesize: "The core job seems to be [one sentence]. The current solution fails because
   [reason]. That suggests the real opportunity is [reframe]."
