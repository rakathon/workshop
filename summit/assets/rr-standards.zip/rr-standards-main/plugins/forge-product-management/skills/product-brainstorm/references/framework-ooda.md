# Framework: OODA Loop

**When to use:** Strategy Exploration mode, especially in competitive or fast-moving,
ambiguous situations.

## Step-by-step

1. **Observe:** What signals are actually in the environment right now?
   Ask the PM to enumerate: "What data, customer feedback, competitor moves, or market
   signals are you tracking?" List them without interpretation.

2. **Orient:** What do those signals mean given your specific context?
   Ask: "What does this tell us about where the market is going?" and "What assumptions
   in our current strategy does this challenge or confirm?"
   Distinguish between signals that are noise and signals that represent a real shift.

3. **Decide:** What options do you have given that orientation?
   Generate 3–5 distinct option directions. Emphasize that options should be genuinely
   different, not variations of the same approach. Apply the test: "If option A is right,
   is option B wrong? If so, they're real alternatives."

4. **Act:** What is the smallest action that would generate the most learning fastest?
   Ask: "What could we do in the next two weeks that would tell us whether our orientation
   is correct?" Favor reversible, cheap experiments over large bets.

5. After completing one OODA loop, ask: "Given what we've sketched, do we need to revise
   our Observe step? Are there signals we should be collecting that we aren't?"
