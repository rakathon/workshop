# Framework: Reverse Brainstorming

**When to use:** Solution Ideation mode when the team is stuck or converging too quickly
on obvious ideas. Also useful as a provocation step in any mode.

## Step-by-step

1. State the problem as originally framed: "We want to [achieve X]."

2. Invert it: "How could we guarantee that we fail to achieve X? How could we make this
   as bad as possible for our users?"

3. Generate 5–10 "make it worse" ideas without filtering. Encourage absurdity — the
   stranger the better.
   Examples: "Require users to re-authenticate every 3 minutes." "Show the error message
   in a font size of 6pt." "Make users wait 48 hours for confirmation."

4. For each "make it worse" idea, invert it back:
   - "Require re-authentication every 3 minutes" → "Minimize authentication friction as much
     as possible — maybe eliminate it in low-risk contexts entirely."

5. Evaluate the inverted list: "Which of these are ideas we wouldn't have generated directly?
   Which ones are actually worth exploring?"

The value of Reverse Brainstorming is that constraints and failure modes surface non-obvious
solutions. Often the "how to make it worse" list contains hidden assumptions about why the
current design is the way it is.
