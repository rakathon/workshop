# Capture — Persisting Session Output

When the PM wants to save session output, help them do any of the following.

Use `env_mode`, `products_root`, and `product_dir` (set in Step 0) to resolve paths.
Never hardcode `.forge/` paths — use the variables from `skills/common/environment.md`.

---

## Summary draft

Draft a concise summary with:
- **Opportunity:** one-sentence restatement of the problem/opportunity
- **Top ideas (2–3):** brief description of each selected idea
- **Key assumptions:** the most important assumption under each idea
- **Next step:** one concrete action to take

---

## OST-lite artifact

If an OST-lite was produced during the session, write it out in a format
compatible with `forge:product-discover`:

```
Outcome: [one sentence]

Opportunities:
- [opportunity 1]
- [opportunity 2]
- [opportunity 3]

Solutions per opportunity:
[opportunity 1]:
  - [solution A] — key assumption: [assumption]
  - [solution B] — key assumption: [assumption]
...
```

---

## Where to save

### Forge mode (`env_mode = forge`)

| Artifact type | Save location |
|---|---|
| Discovery artifact / OST sketch | `<effort_dir>/spec/` (active effort, if one exists) |
| Product-level capture / brief | `<product_dir>/` (e.g. `<product_dir>/briefs/<topic>.md`) |
| No active effort | Ask PM: "Should I save this to your product directory, or would you like to start a Forge effort first?" |

To formalize any idea as a work item, suggest `forge:effort`.

### Plain mode (`env_mode = plain`)

| Artifact type | Save location |
|---|---|
| Discovery artifact / OST sketch | `<product_dir>/` or a file the PM names |
| Product-level capture / brief | `<product_dir>/briefs/<topic>.md` |
| No product directory | Ask the PM what filename to use and write it to the current directory |

In plain mode, ask the PM: "Where would you like me to save this? I can write it to
`<product_name>/brainstorm-<date>.md` or any filename you prefer."

Do not instruct the PM to run shell commands in plain mode. Use the Write tool
directly to create the file.
