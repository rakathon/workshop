# Framework: First Principles

**When to use:** Assumption Testing and Strategy Exploration modes. Useful for breaking
from incumbent approaches and redesigning from real constraints only.

## Step-by-step

1. State the current approach or assumption being challenged. Example: "We're assuming
   the product must integrate with [tool X] because our users are used to it."

2. Decompose to fundamental constraints. For each element of the current approach, ask:
   "What must be true here? Is this a physical/regulatory/economic constraint, or is it
   a convention we've inherited?" Push until you reach something that genuinely can't be changed.

3. Separate real constraints from inherited assumptions. Make a two-column list:
   - **Real constraints:** things that are actually fixed (regulatory, physical, budget-hard)
   - **Inherited assumptions:** things that feel fixed but could be challenged

4. Rebuild from real constraints only. Ask: "If we only had to satisfy [real constraints],
   what would we build?" Ignore analogies to what competitors do or what users currently expect.

5. Ask: "What does this suggest we could do differently from the conventional approach?"
   The goal is at least one non-obvious solution direction before returning to evaluate.
