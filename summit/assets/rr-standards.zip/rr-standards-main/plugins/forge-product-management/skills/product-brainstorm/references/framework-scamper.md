# Framework: SCAMPER

**When to use:** Solution Ideation mode, especially when the PM has an existing product,
feature, or process they want to evolve.

## Step-by-step

Apply each lens to the existing solution or process in sequence. Each lens must generate
at least one concrete question for this specific situation.

1. **Substitute:** What component, step, or ingredient could be replaced?
   Template: "What if instead of [X], we used [Y]?"

2. **Combine:** What two things could be merged to create something new?
   Template: "What would happen if [X] and [Y] were one thing?"

3. **Adapt:** What could be borrowed from a different context or industry?
   Template: "How does [adjacent domain] solve this? What would it look like to bring that approach here?"

4. **Modify / Magnify:** What happens if we exaggerate or minimize a dimension?
   Template: "What if this feature were 10x faster / cheaper / larger / simpler?"

5. **Put to other uses:** Could this be used in a different context or for a different user?
   Template: "Who else might want this exact thing we've already built?"

6. **Eliminate:** What could be removed to make it simpler or more focused?
   Template: "What if we cut [X] entirely? What would break, and what would improve?"

7. **Reverse / Rearrange:** What if the order or structure were flipped?
   Template: "What if the user did [step Y] before [step X]? What if we reversed who owns [responsibility]?"

After running all seven lenses, identify the 2–3 most interesting questions generated and
use those to drive the next round of idea generation.
