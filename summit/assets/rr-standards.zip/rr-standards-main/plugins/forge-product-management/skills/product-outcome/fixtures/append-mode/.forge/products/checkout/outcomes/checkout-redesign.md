# Outcome Review: Checkout Redesign

**Effort ID:** checkout-redesign
**Product:** checkout
**PRD Goals:** Reduce checkout abandonment by simplifying the payment flow from 5 steps to 3.
**Review Date:** 2025-10-15

---

## Measurement: 2025-10-15

### Effort Summary

**Effort ID:** checkout-redesign
**Title:** Checkout Redesign
**PRD Goals:** Reduce checkout abandonment; simplify payment flow to 3 steps
**Planned Close Date:** 2025-09-30
**Actual Close Date:** 2025-10-10
**Slippage:** 10 days
**Scope Changes:** Added Apple Pay integration after original estimate

### Metrics vs. Targets

| Metric | Type | Target | Actual | Delta | Status |
|--------|------|--------|--------|-------|--------|
| Checkout completion rate | Leading | +8% (79%) | 77% | −2% | Missed |
| Average checkout duration | Leading | < 90s | 95s | +5s | Partial |
| 30-day repeat purchase rate | Lagging | +5% (43%) | Pending | — | Pending |

### What Worked

- Step reduction from 5 to 3 was implemented successfully and received positive user feedback
- Apple Pay integration (scope addition) drove 18% of completions in the first two weeks

### What Didn't

- Checkout completion rate improved by only 6%, missing the 8% target
- Mobile users still showed higher abandonment at the payment entry step

### Open Questions

- Does Apple Pay cannibalise or add net completions?
- What is causing the remaining abandonment on mobile at step 2?

### Recommended Next Actions

- Run a mobile-specific UX review of the payment entry step
- Re-measure 30-day repeat purchase rate at 60-day mark
