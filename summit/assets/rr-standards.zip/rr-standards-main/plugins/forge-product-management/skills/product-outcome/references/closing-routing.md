# Closing Prompt Routing

This reference defines how to route the PM's response to the closing prompt in Step 6.

---

## The Closing Prompt

After writing the outcome document, always ask:

> "What should change in discovery or strategy as a result of this outcome?"

Wait for the PM's response. This step is **not optional** — always ask it, regardless
of whether all metrics were met.

---

## Routing Logic

### Discovery gaps or unvalidated assumptions

Trigger: PM identifies gaps in customer understanding, unvalidated assumptions, or
metrics that were hard to measure because the underlying user behavior was unclear.

Response:
> "It sounds like a discovery update would be valuable. Consider running
> `forge:product-discover` to incorporate this learning into your Opportunity Solution Tree
> and update the assumption log."

### Strategy direction, OKRs, or roadmap priorities

Trigger: PM identifies a need to revisit strategic direction, change which bets the
team is making, update OKRs, or re-prioritize the roadmap.

Response:
> "This sounds like it warrants a strategy refresh. Consider running
> `forge:product-strategy` in refresh mode to update the diagnosis, guiding policy,
> or roadmap in light of these outcomes."

### New opportunity

Trigger: PM identifies a new opportunity that surfaced from the outcomes (e.g., an
unexpected positive result that opens a new market, or a missed metric that reveals
an unaddressed need).

Response:
> "A new coherent action may belong on the roadmap. Consider running
> `forge:product-strategy` in refresh mode to evaluate where this fits."

### No changes needed

Trigger: PM says the outcomes were satisfactory and no changes are needed.

Response:
> "Noted — this outcome has been recorded. You can re-run `forge:product-outcome` for the
> same effort at any time to append a 30-, 60-, or 90-day follow-up measurement."

---

## Post-routing: Update the Document

In all cases, record the PM's answer (a brief paraphrase) in the `## Recommended
Next Actions` section of the outcome document if it adds detail beyond what was
already written. Do not re-write the section — append a bullet if warranted.
