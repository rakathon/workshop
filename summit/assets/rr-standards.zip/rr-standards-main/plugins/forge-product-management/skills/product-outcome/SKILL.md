---
name: forge:product-outcome
description: >
  Measures actual outcomes against PRD goals for a graduated effort. Reads
  goals and success metrics from requirements/prd.md, gathers actuals from
  Annalise/Snowflake and Jira, compares results against targets, and writes a
  structured outcome document. Re-invokable for 30/60/90-day follow-up reviews —
  subsequent runs append a new dated measurement section without overwriting prior
  records. Closes the product learning loop with a required closing prompt that
  feeds back into discovery or strategy. Works in both Forge-initialized projects
  and plain directories (Claude Desktop / Cowork).
when_to_use: >
  Trigger on: "run an outcome review", "measure the outcomes", "how did this effort
  perform?", "did we hit our metrics?", "post-launch review", "outcome review for",
  "what were the results of", "measure the impact of", "30-day review", "60-day review",
  "90-day review", "follow-up outcome", "write an outcome doc", "forge:product-outcome",
  or any time a PM wants to evaluate whether a graduated effort achieved its PRD goals.
argument-hint: "[effort-id]"
arguments: [effort_id]
agent-type: orchestrator
---

# forge:product-outcome

Produces a structured outcome document for a graduated effort by comparing
actual metrics against the PRD targets. Re-invokable over time — each run appends
a new dated measurement section so that 30/60/90-day follow-up reviews accumulate
in a single file per effort.

---

## Plugin Root Resolution

Resolve the plugin root using:
`plugins/forge-product-management/skills/common/plugin-root.md`

This sets `plugin_root`. All reference file paths below are relative to it.

Reference files used by this skill — read each before the step where it is first needed:

- `<plugin_root>/skills/product-outcome/references/outcome-templates.md` — document templates (read at Step 5, before writing)
- `<plugin_root>/skills/product-outcome/references/closing-routing.md` — routing logic for the closing prompt (read at Step 6)

Do not load reference files until the step where they are needed.

---

## Step 0: Environment Detection

Load `<plugin_root>/skills/common/environment.md` and follow its instructions to set:

- `env_mode` — `forge` or `plain`
- `products_root` — base directory for all products
- `efforts_root` — base directory for efforts (Forge mode only)

---

## Step 1: Identify Effort to Review

### Forge mode

If an effort ID was passed as an argument, use it directly. Otherwise ask:

> "Which effort would you like to run an outcome review for? You can give me the
> effort ID (e.g. `product-management`) or the effort title."

Search for the effort directory:

1. Check `<efforts_root>/<id>/` — use a direct match if provided.
2. If a title was given, scan `<efforts_root>/README.md` for a matching row and
   resolve the effort ID from it.
3. If no match is found, list all directories under `<efforts_root>/` and ask the
   PM to identify the correct one.

Set `effort_id` and `effort_dir = <efforts_root>/<effort_id>/`.

### Plain mode

There is no effort tracking system. Ask:

> "Which product are we reviewing outcomes for?"

Set `effort_dir = <products_root>/<product_name>/`.

Do not reference `.forge/EFFORT`, `<efforts_root>/`, or `.state.json`.

---

## Step 2: Scope Guard — Check for PRD

Check whether `<effort_dir>/requirements/prd.md` exists.

**If the file is absent, HARD STOP.** Do not proceed. Output exactly:

### Forge mode message

> "Effort `<effort_id>` has no `requirements/prd.md`. `forge:product-outcome` only applies
> to PRD-originated efforts. If this was an engineering-only effort without a PM PRD,
> no outcome review is needed."

### Plain mode message

> "No `requirements/prd.md` found in `<effort_dir>/requirements/`. `forge:product-outcome`
> only applies to work that has a PM PRD. Please add a PRD first, then re-invoke this
> skill."

Do not suggest workarounds. Do not offer to continue with other files. End the skill.

---

## Step 3: Read the PRD

Read `<effort_dir>/requirements/prd.md` in full.

Extract and hold in working memory:

- **Goals** — the stated product goals or desired outcomes
- **Success metrics** — all metrics listed, noting which are leading indicators
  (early signals, typically measurable within weeks) and which are lagging indicators
  (business results, typically measurable over months)
- **Targets** — the numeric or qualitative target for each metric
- **Non-goals** — explicitly out-of-scope outcomes
- **Planned timeline** — the target close or launch date stated in the PRD

If any of these sections are absent or ambiguous in the PRD, note what is missing.
You will use those gaps when populating the "Open Questions" section later.

---

## Step 4: Gather Actuals

Attempt to gather actuals from each source in order. For each source that is
unavailable or returns no relevant data, fall back to asking the PM directly.

**4.1 — Snowflake / Annalise (metric actuals)**

If Snowflake or Annalise tools are available in this session:

1. For each success metric identified in Step 3, formulate a natural-language query
   describing the metric.
2. Attempt to retrieve the current value and trend for each metric.
3. Record each result as `{ metric, actual_value, measurement_date, source }`.

If a query returns no data or the tool is unavailable, mark that metric as
`source: manual` and include it in the Step 4.3 fallback list.

**4.2 — Jira (delivery actuals)**

If the Atlassian MCP is available in this session:

1. Search for Jira issues linked to this effort (use the effort ID or PRD title as
   search terms).
2. Record:
   - Total issues: planned count vs. completed count
   - Actual close date (date of last issue completion or epic closure)
   - Scope changes: issues added after the original estimate
   - Any issues still open or rolled over
3. Record as `{ planned_close, actual_close, slippage_days, scope_changes }`.

If Jira is unavailable or no issues are found, mark delivery data as `source: manual`
and include it in the Step 4.3 fallback list.

**4.3 — Manual fallback**

For any metric or data point marked `source: manual`, ask the PM directly:

> "I wasn't able to pull actuals automatically for the following items. Can you
> paste the current values?"

List each outstanding item. Accept the PM's input and record each value with
`source: PM-provided`.

After collecting all actuals, confirm the complete set with the PM before writing:

> "Here is what I have for actuals:
> [list each metric with target and actual]
> Does anything need correcting before I write the outcome document?"

Apply any corrections.

---

## Step 5: Determine Output Path

Resolve the product name:

### Forge mode

Check in order:

1. `<effort_dir>/.state.json` — look for a `productName` or `product` field.
2. `<effort_dir>/requirements/prd.md` — look for a product name in the document
   header or metadata.
3. If neither resolves, ask: > "Which product does this effort belong to?"

Set:

```
product_dir  = <products_root>/<product_name>/
outcomes_dir = <product_dir>/outcomes/
output_file  = <outcomes_dir>/<effort_id>.md
```

### Plain mode

`product_dir` was already set in Step 1 as `<products_root>/<product_name>/`.

Set:

```
outcomes_dir = <product_dir>/outcomes/
output_file  = <outcomes_dir>/<product_name>.md
```

---

### Both modes

**Check whether `output_file` already exists:**

- **Does NOT exist** — this is the first outcome review. Proceed to Step 6 in **create mode**.
- **Already exists** — this is a follow-up review (30-, 60-, or 90-day re-invocation). Proceed to Step 6 in **append mode**.

A single file accumulates all measurement snapshots. The date of each review appears
inside the file as the `## Measurement: YYYY-MM-DD` heading, not in the filename.

Do not use `mkdir -p` or other shell commands. Write the first file inside
`outcomes_dir` and the Write tool will create the directory automatically.

---

## Step 6: Write Outcome Document

Read `<plugin_root>/skills/product-outcome/references/outcome-templates.md` for the full
templates. Use the template matching the current mode:

- **Create mode** — write a new file at `output_file` with the full document structure.
- **Append mode** — append a new measurement section to the end of the existing file.
  Do not modify or overwrite any prior content.

Every measurement section (whether in create or append mode) **must contain exactly
these sections in this order**:

1. **Effort Summary** — planned vs. actual close date, slippage, scope changes
2. **Metrics vs. Targets** — table with columns: Metric, Type, Target, Actual, Delta, Status
   - Status values: Met / Missed / Partial / Pending
3. **What Worked** — 2–5 observations backed by metric or delivery evidence
4. **What Didn't** — 2–5 observations backed by metric or delivery evidence
5. **Open Questions** — gaps for future work to address
6. **Recommended Next Actions** — concrete next steps naming the artifact or skill to update

Do not rename these sections. Do not merge them. Do not substitute "Assessment" or
other headings for "What Worked" / "What Didn't".

Populate every section using the data gathered in Steps 3 and 4. Do not leave
placeholder text. For any section where data is genuinely unavailable, write a brief
note explaining why (e.g. "Measurement window not yet reached" or "Metric definition
was ambiguous in PRD — see Open Questions").

After writing, confirm the output path to the PM:

> "Outcome document written to `<output_file>`."

---

## Step 7: Closing Prompt (Required)

Read `<plugin_root>/skills/product-outcome/references/closing-routing.md` now for full
routing logic. The routing reference defines how to respond based on the PM's answer.

This step is not optional. Ask the PM this exact question and **wait for their response**
before routing:

> "What should change in discovery or strategy as a result of this outcome?"

Do not present multiple-choice options. Do not skip directly to a routing recommendation.
Ask the open question, receive the PM's answer, then follow the routing logic in the
reference file.
