# Outcome Document Templates

Use these templates when writing the outcome document in Step 5.

---

## Create Mode — Full Document

Use this template when creating a new outcome file (first review for this effort).

```markdown
# Outcome Review: <Effort Title>

**Effort ID:** <effort_id>
**Product:** <product_name>
**PRD Goals:** <one-sentence summary of stated goals from prd.md>
**First Review Date:** <YYYY-MM-DD>

---

## Measurement: <YYYY-MM-DD>

### Effort Summary

**Effort ID:** <effort_id>
**Title:** <effort title>
**PRD Goals:** <goals extracted in Step 2>
**Planned Close Date:** <from PRD timeline>
**Actual Close Date:** <from Jira or PM-provided>
**Slippage:** <N days / on time / data unavailable>
**Scope Changes:** <summary of any scope additions or removals>

### Metrics vs. Targets

| Metric | Type | Target | Actual | Delta | Status |
|--------|------|--------|--------|-------|--------|
| <metric name> | Leading/Lagging | <target> | <actual> | <delta> | Met / Missed / Partial / Pending |

_Status key: Met = at or above target. Missed = below target. Partial = directionally
correct but below target. Pending = measurement window not yet reached._

### What Worked

_2–5 specific observations backed by evidence from the metrics table or delivery data._

- <observation with supporting evidence>
- <observation with supporting evidence>

### What Didn't

_2–5 specific observations backed by evidence from the metrics table or delivery data._

- <observation with supporting evidence>
- <observation with supporting evidence>

### Open Questions

_Questions that remain unanswered and that future work should address. Include gaps
identified from absent PRD sections and any metrics marked Pending._

- <question>
- <question>

### Recommended Next Actions

_Concrete next steps that feed back into discovery or strategy. Be specific — name
the artifact or skill that should be updated._

- <action>
- <action>
```

---

## Append Mode — New Measurement Section

Use this block when re-invoking for a follow-up review. Append to the end of the
existing file, after a blank line.

```markdown

---

## Measurement: <YYYY-MM-DD>

### Effort Summary

**Planned Close Date:** <from original PRD>
**Actual Close Date:** <from Jira or PM-provided>
**Slippage:** <N days / on time / data unavailable>
**Scope Changes:** <any changes since last review>

### Metrics vs. Targets

| Metric | Type | Target | Actual | Delta | Status |
|--------|------|--------|--------|-------|--------|
| <metric name> | Leading/Lagging | <target> | <actual> | <delta> | Met / Missed / Partial / Pending |

### What Worked

- <observation with supporting evidence>

### What Didn't

- <observation with supporting evidence>

### Open Questions

- <question>

### Recommended Next Actions

- <action>
```

---

## Populating Instructions

- Replace every `<placeholder>` with real data gathered in Steps 2 and 3.
- Do not leave placeholder text. For any section where data is genuinely
  unavailable, write a brief note explaining why (e.g. "Measurement window not yet
  reached" or "Metric definition was ambiguous in PRD — see Open Questions").
- The `Delta` column should show the arithmetic difference (actual minus target) or
  a directional label (e.g. "+12%", "−3 days", "no data") as appropriate for the metric type.
