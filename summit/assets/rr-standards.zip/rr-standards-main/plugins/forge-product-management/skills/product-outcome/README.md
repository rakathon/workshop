# forge:product-outcome

Measures actual outcomes against PRD goals for a graduated effort. Reads
goals and success metrics from `requirements/prd.md`, gathers actuals from
Annalise/Snowflake and Jira, compares results against targets, and writes a
structured outcome document. Re-invokable for 30/60/90-day follow-up reviews.

Works in both **Forge-initialized projects** and **plain directories** (Claude Desktop /
Cowork / any environment without `.forge/`).

---

## Usage

```
forge:product-outcome
forge:product-outcome <effort-id>
```

In a **Forge project**, if no effort ID is provided, Claude will prompt for the effort
to review by ID or title.

In a **plain directory** (Claude Desktop / Cowork), Claude will ask which product to
review — no effort ID is required.

---

## When to use

- Running a post-launch review to evaluate whether an effort achieved its PRD goals
- Conducting 30-, 60-, or 90-day follow-up measurements on a previously reviewed effort
- Any time a PM says "run an outcome review", "how did this effort perform?", "did we
  hit our metrics?", "measure the impact of", or "forge:product-outcome"

---

## Prerequisites

- The effort must have a `requirements/prd.md` — this skill applies only to
  PRD-originated efforts. If the file is absent, the skill stops immediately.
- **Forge mode:** a product directory must exist under `.forge/products/<product-name>/`
  (created by `forge:product`)
- **Plain mode:** a product directory must exist at `./<product-name>/`
  (created by `forge:product`)
- Annalise/Snowflake and Atlassian MCP tools are optional — the skill degrades
  gracefully and falls back to asking the PM for actuals when they are unavailable

---

## Output artifacts

| Mode | Written to |
|------|-----------|
| Forge | `.forge/products/<product-name>/outcomes/` |
| Plain | `./<product-name>/outcomes/` |

| File | Purpose |
|------|---------|
| `<effort-id>.md` (Forge) / `<product-name>.md` (plain) | Outcome document — all measurement snapshots accumulate in one file |

Each outcome document includes:

- **Effort Summary** — planned vs. actual close date, slippage, and scope changes
- **Metrics vs. Targets table** — each PRD success metric with target, actual, delta,
  and status (Met / Missed / Partial / Pending)
- **What Worked** — specific observations backed by metric or delivery evidence
- **What Didn't** — specific observations backed by metric or delivery evidence
- **Open Questions** — unanswered questions and gaps for future work to address
- **Recommended Next Actions** — concrete next steps feeding back into discovery or strategy

---

## Re-invocation behavior

Running `forge:product-outcome` for the same effort more than once appends a new dated
`## Measurement: YYYY-MM-DD` section to the existing outcome file. Prior records are
never overwritten. This allows a single file to accumulate the 30-, 60-, and 90-day
measurement snapshots for each effort.

---

## Closing prompt

After writing the outcome document, the skill always asks:

> "What should change in discovery or strategy as a result of this outcome?"

Based on the PM's response, it directs next steps to the appropriate skill:

- Discovery gaps or unvalidated assumptions → `forge:product-discover`
- Strategy direction, OKRs, or roadmap priorities → `forge:product-strategy` (refresh mode)
- New roadmap opportunity → `forge:product-strategy` (refresh mode)

---

## Relationship to other skills

| Skill | Relationship |
|-------|-------------|
| `forge:product` | Creates the product directory that `forge:product-outcome` writes outcomes into |
| `forge:product-strategy` | Outcome reviews feed back into strategy refreshes when goals were missed or new opportunities surfaced |
| `forge:product-discover` | Outcome reviews feed back into discovery when gaps in customer understanding are identified |
| `forge:graduate` | Graduates an effort's implementation artifacts; `forge:product-outcome` is typically run after graduation to measure results |
