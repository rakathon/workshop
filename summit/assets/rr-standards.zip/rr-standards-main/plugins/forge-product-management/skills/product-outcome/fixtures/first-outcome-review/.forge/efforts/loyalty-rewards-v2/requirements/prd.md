# PRD: Loyalty Rewards V2 — Gamification Features

**Product:** loyalty
**Author:** Jane PM
**Date:** 2025-10-01

## Goals

Increase member engagement and redemption rates by introducing gamification elements
(streaks, badges, tier challenges) into the loyalty programme app.

## Success Metrics

| Metric | Type | Target |
|--------|------|--------|
| 30-day active redemption rate | Leading | +15% vs. baseline (32%) |
| Average sessions per active member per month | Leading | 4.2 sessions (baseline 2.8) |
| 90-day member retention | Lagging | 68% (baseline 61%) |
| Net Promoter Score | Lagging | +8 points (baseline 34) |

## Non-Goals

- This effort does not redesign the points accrual model.
- This effort does not include B2B partner portal changes.

## Timeline

Target launch: 2025-12-01. Target effort close: 2025-12-15.
