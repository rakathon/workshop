# PRD: Checkout Redesign

**Product:** checkout
**Author:** Alex PM
**Date:** 2025-08-01

## Goals

Reduce checkout abandonment by simplifying the payment flow from 5 steps to 3.

## Success Metrics

| Metric | Type | Target |
|--------|------|--------|
| Checkout completion rate | Leading | +8% (baseline 71%) |
| Average checkout duration | Leading | < 90 seconds (baseline 140s) |
| 30-day repeat purchase rate | Lagging | +5% (baseline 38%) |

## Timeline

Target launch: 2025-09-15. Target effort close: 2025-09-30.
