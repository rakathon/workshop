---
name: forge:product-scorecard
description: >
  Reads the product metric hierarchy from metrics.md and produces a dated scorecard
  snapshot — pulling current values from Annalise/Snowflake where available and
  prompting the PM for manual values otherwise. Compares each metric against its
  healthy range, assigns a health status (healthy/watch/at-risk), and writes the
  result to metrics/scorecards/YYYY-MM-DD.md. Same-day re-runs append a new
  timestamped section rather than overwriting. Surfaces recommended actions for
  any at-risk or watch metric.
when_to_use: >
  Trigger on: "run the scorecard", "check our metrics", "how are our metrics
  looking", "pull the scorecard", "generate a product scorecard", "update the
  scorecard", "check product health", "what's the status of our metrics",
  "run a metrics check", "forge:product-scorecard", or any time a PM wants a
  current snapshot of their product metric hierarchy.
argument-hint: "[product-name]"
arguments: [product_name]
agent-type: orchestrator
---

# forge:product-scorecard

Generates a dated product metrics scorecard by reading the product's confirmed
metric hierarchy from `metrics.md`, pulling current values per metric, comparing
against healthy ranges, and writing a structured snapshot to
`<product_dir>/metrics/scorecards/YYYY-MM-DD.md`.

A scorecard without a defined metric hierarchy is not a scorecard. If `metrics.md`
is absent, this skill stops immediately and redirects to `forge:product-strategy`.

---

## Step 0: Environment Detection and Product Resolution

**0.0 — Detect environment**

Load `skills/common/environment.md`. Run the detection check:

```
[ -d ".forge" ] && echo "forge" || echo "plain"
```

Set `env_mode = forge | plain`.

Then set path variables:

- **Forge mode:** `products_root = .forge/products`
- **Plain mode:** `products_root = .`

**0.1 — Identify product**

If a product name was provided as an argument (e.g. `forge:product-scorecard rewards-app`),
use it directly. Otherwise:

1. **Forge mode only:** Check for `.forge/EFFORT`. If it exists, read it and resolve
   the product name from the effort's `productName` field in its `.state.json`.
2. If no active effort (or in plain mode), list directories under `<products_root>`.
   If exactly one exists, use it. If multiple exist, ask:
   > "Which product should I run the scorecard for? Available products: [list]"
   If none exist, ask the PM for the product name directly.

Set `product_name` and `product_dir = <products_root>/<product_name>/`.

**0.2 — Check for metrics.md**

Check whether `<product_dir>/metrics.md` exists.

If it does **not** exist:

> "`metrics.md` is not defined for this product. Run `forge:product-strategy` first —
> it will guide you through defining the metric hierarchy as part of the strategy
> session."

**Stop here. Do not continue. Do not offer a degraded mode.**

If it exists: proceed to Step 1.

---

## Step 1: Parse metrics.md

Read `<product_dir>/metrics.md` in full. Extract for every metric:

**North Star section:** metric name, definition, data source, cadence, baseline,
healthy range (low and high bounds).

**L1 Inputs section:** metric name, which metric it Drives (should be "North Star"),
definition, data source, cadence, baseline, healthy range.

**L2 Diagnostics section:** metric name, which L1 it Explains, definition, data
source, cadence, baseline, healthy range.

Build an internal list of all metrics with their full wiring. Confirm the count:
> "I found [N] metrics in your hierarchy: 1 North Star, [X] L1 inputs,
> [Y] L2 diagnostics. Pulling current values now."

Proceed to Step 2.

---

## Step 2: Pull Current Values

Process every metric in the list. For each metric, apply this logic based on its
`Data source` field:

**If source is `annalise` or contains "annalise":**
Attempt to query via the Annalise MCP tool using the metric's definition and name.
If the query succeeds, record the returned value. If the query fails or the tool is
unavailable, fall through to manual prompt.

**If source is `snowflake` or contains "snowflake":**
Attempt to query via the Snowflake MCP tool. If the query succeeds, record the
returned value. If the query fails or the tool is unavailable, fall through to
manual prompt.

**If source is `manual`, or the automated query failed, or the tool is unavailable:**
Prompt the PM for the current value:
> "**[Metric name]** ([definition]): What is the current value?
> (Baseline: [baseline], Healthy range: [healthy range])"

Wait for the PM's response before moving to the next metric. Accept numeric values,
percentages, or short descriptive values. If the PM types "skip" or "unknown",
record the value as `—` (unavailable) and assign status `unknown`.

Process all metrics before moving to Step 3. Do not skip any metric silently.

---

## Step 3: Compute Scorecard

For each metric with a recorded current value, determine:

**Status** — compare current value against the healthy range from `metrics.md`:

- `healthy` — current value falls within the healthy range
- `watch` — current value is outside the healthy range but within 15% of the
  nearest bound
- `at-risk` — current value is more than 15% outside the nearest healthy range bound
- `unknown` — value was not available (PM skipped or source unavailable)

For metrics where the healthy range is directional (e.g. "above 40%" or "below 5%"),
treat the stated bound as the threshold and apply the same 15% buffer rule.

**Trend** — compare current value against the baseline from `metrics.md`:

- `improving` — current value has moved in the positive direction relative to baseline
- `stable` — current value is within 5% of baseline (relative change)
- `declining` — current value has moved in the negative direction relative to baseline
- `unknown` — baseline or current value not available

Positive direction is determined by context: for metrics where higher is better
(e.g. retention rate), improving = higher than baseline. For metrics where lower is
better (e.g. error rate, churn), improving = lower than baseline. Use the metric's
definition to determine direction.

Record status and trend for every metric. Proceed to Step 4.

---

## Step 4: Write Scorecard File

**4.1 — Resolve file path**

Set `run_date` = today's date in `YYYY-MM-DD` format.
Set `run_time` = current time in `HH:MM` format (24-hour).
Set `scorecard_path = <product_dir>/metrics/scorecards/<run_date>.md`.

**4.2 — New file vs. same-day re-run**

If `<scorecard_path>` does **not** exist:

Write `<scorecard_path>` using the **New-File Template** in
`references/scorecard-templates.md`. Fill in all metric rows, the summary
table, overall health, and recommended actions (see Step 5). Use the Write
tool directly — do not run `mkdir -p` (the Write tool creates parent
directories automatically, and in plain mode the PM may not have a terminal).

If `<scorecard_path>` **already exists** (same-day re-run):

Read the existing file. Append a new run section at the end using the
**Same-Day Re-Run (Append) Template** in `references/scorecard-templates.md`.
Do not modify any existing content.

**4.3 — Overall health**

Determine `Overall health` for the summary as follows:
- `Healthy` — North Star is healthy and no L1 is at-risk
- `Needs Attention` — North Star is healthy but one or more L1s are at-risk or
  watch, OR North Star is watch
- `At Risk` — North Star is at-risk

---

## Step 5: Surface Recommended Actions

For every metric with status `at-risk` or `watch`, generate a concrete next step
using the language in `references/recommended-actions.md`. Write all recommended
actions under the `### Recommended Actions` section of the scorecard.

If all metrics are healthy, write the "All Metrics Healthy" message from
`references/recommended-actions.md`, substituting the next scheduled date.

After writing the scorecard file, print a session summary:

> "Scorecard written to `<scorecard_path>`.
>
> **Overall health: [value]**
> - North Star: [name] → [status] ([current value] vs. healthy range [range])
> - L1s: [X healthy], [Y watch], [Z at-risk]
> - L2s: [X healthy], [Y watch], [Z at-risk]
>
> [If any at-risk or watch metrics exist:]
> [N] metrics need attention — see Recommended Actions in the scorecard."
