# Metric Hierarchy: rewards-app

## North Star

| Metric | Definition | Data source | Cadence | Baseline | Healthy Range |
|---|---|---|---|---|---|
| Monthly Active Redeemers | % of enrolled members who redeem a reward in a rolling 30-day window | manual | weekly | 38% | 35%–55% |

## L1 Inputs

| Metric | Drives | Definition | Data source | Cadence | Baseline | Healthy Range |
|---|---|---|---|---|---|---|
| Offer Click-Through Rate | North Star | % of members who click an offer after seeing it | manual | weekly | 12% | 10%–20% |
| Redemption Completion Rate | North Star | % of started redemptions that complete successfully | manual | weekly | 82% | 75%–95% |

## L2 Diagnostics

| Metric | Explains | Definition | Data source | Cadence | Baseline | Healthy Range |
|---|---|---|---|---|---|---|
| Personalized Offer Impressions | Offer Click-Through Rate | % of offer impressions that are personalized | manual | weekly | 45% | 40%–70% |
| Checkout Error Rate | Redemption Completion Rate | % of redemption attempts that fail with an error | manual | weekly | 3% | 0%–5% |
