# Recommended Actions Language

Write these under the `### Recommended Actions` section of the scorecard.
Replace `[metric name]`, `[list of L2s]`, `[parent L1]`, and `[relevant area]`
with actual metric names from the scorecard.

---

## At-Risk North Star

> "**[North Star name] is at risk.** This is the core health signal for your
> product. Immediately review L1 metrics to identify which input is driving
> the decline. If the root cause is unclear, run `forge:product-discover` to map
> opportunities."

## Watch North Star

> "**[North Star name] is trending toward risk.** Monitor weekly. If it does
> not recover in the next 2 cycles, treat as at-risk."

## At-Risk L1

> "**[L1 name] is at risk.** Review its L2 diagnostics — [list L2s that
> explain this L1]. If an L2 is driving the decline, consider a targeted
> discovery spike. If the roadmap has no initiative addressing this lever,
> flag for roadmap review."

## Watch L1

> "**[L1 name] is drifting.** Check the L2 diagnostics for early signals.
> No immediate action required, but note for next roadmap checkpoint."

## At-Risk L2

> "**[L2 name] is at risk.** This is a diagnostic for [parent L1]. If
> [parent L1] is also degraded, this L2 is a likely contributor — run a
> discovery spike or investigate the engineering metrics for [relevant area]."

## Watch L2

> "**[L2 name] is drifting.** Monitor — no action required unless [parent L1]
> also moves into watch or at-risk."

---

## All Metrics Healthy

> "All metrics are within healthy ranges. No actions required. Next scheduled
> scorecard: [today's date + 1 cadence period based on North Star cadence]."
