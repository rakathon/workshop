# forge:product-scorecard

Generates a dated product metrics scorecard by reading the product's confirmed metric
hierarchy from `metrics.md`, pulling current values for each metric, comparing against
healthy ranges, and writing a structured snapshot to
`<product_dir>/metrics/scorecards/YYYY-MM-DD.md`.

---

## Usage

```
forge:product-scorecard
forge:product-scorecard <product-name>
```

If no product name is supplied, the skill auto-detects the environment, then resolves
the product from the active effort (Forge mode) or by listing the products root
directory. When multiple products exist and no effort is active, the skill asks which
product to run the scorecard for.

---

## When to use

- Checking current product health against defined metric targets
- Running a regular metrics review (weekly, monthly, or per cadence)
- Any time a PM says "run the scorecard", "check our metrics", "how are our metrics
  looking", "pull the scorecard", "generate a product scorecard", "update the scorecard",
  "check product health", "what's the status of our metrics", or "run a metrics check"

---

## Prerequisites

| Prerequisite | Notes |
|---|---|
| `metrics.md` present at `<product_dir>/metrics.md` | **Hard stop** — if absent the skill stops immediately and redirects to `forge:product-strategy`. No degraded mode. |
| Annalise / Snowflake MCP tools (optional) | Used to pull metric values automatically where the data source is `annalise` or `snowflake`. Falls back to manual prompt if unavailable. |

`<product_dir>` is resolved at runtime:

- **Forge mode** (`.forge/` present): `product_dir = .forge/products/<product-name>/`
- **Plain mode** (Claude Desktop / Cowork): `product_dir = ./<product-name>/`

No Forge initialisation is required in plain mode. The skill works in any directory
that contains a product folder created by `forge:product`.

---

## Output artifact

| File | Purpose |
|---|---|
| `<product_dir>/metrics/scorecards/YYYY-MM-DD.md` | Dated scorecard snapshot with metric values, health statuses, trends, and recommended actions |

### Same-day re-runs

Running the skill more than once on the same day **appends** a new timestamped
`## Run: HH:MM` section to the existing scorecard file. Existing content is never
overwritten. Each run section contains the full metric tables, summary, and
recommended actions for that run.

---

## Health status logic

Each metric is assigned a status by comparing its current value against the healthy
range defined in `metrics.md`:

| Status | Condition |
|---|---|
| `healthy` | Current value falls within the healthy range |
| `watch` | Current value is outside the healthy range but within 15% of the nearest bound |
| `at-risk` | Current value is more than 15% outside the nearest healthy range bound |
| `unknown` | Value was not available (skipped or source unavailable) |

**Overall health** is derived from the North Star and L1 Input statuses:

| Overall health | Condition |
|---|---|
| `Healthy` | North Star is healthy and no L1 is at-risk |
| `Needs Attention` | North Star is healthy but one or more L1s are at-risk or watch, OR North Star is watch |
| `At Risk` | North Star is at-risk |

---

## Scorecard structure

Each scorecard file (or appended run section) contains:

- **North Star** table — metric name, current value, baseline, healthy range, status, trend
- **L1 Inputs** table — same columns plus which North Star metric each input drives
- **L2 Diagnostics** table — same columns plus which L1 metric each diagnostic explains
- **Summary** table — count of healthy / watch / at-risk / unknown per level
- **Recommended Actions** — concrete next steps for every metric with status `watch` or
  `at-risk`; if all metrics are healthy, states next scheduled scorecard date

---

## Relationship to other skills

| Skill | Relationship |
|---|---|
| `forge:product-strategy` | Defines the metric hierarchy in `metrics.md` — must be run before `forge:product-scorecard` can operate |
| `forge:product` | Registers the product directory — prerequisite for all PM-facing skills |
| `forge:effort` | Forge mode only — efforts may reference a product; the scorecard uses the active effort to resolve which product to score. Not used in plain mode. |
