# forge-product-management — Plugin Root Resolution

This fragment defines the canonical method for locating the plugin root at runtime.
Use it in any skill that needs to access plugin resources (references, templates)
from the cache.

**Do not use** `find ~/.claude/plugins/cache` — it is fragile when multiple plugin
versions are cached.

**Usage in a skill:**
> Resolve the plugin root using:
>   `plugins/forge-product-management/skills/common/plugin-root.md`

---

## Resolution Steps

**Step 1 — Read the plugin manifest**

Read `../../.claude-plugin/plugin.json` using the Read tool. The path is relative to
this skill's directory (i.e., `skills/<skill-name>/SKILL.md` → `../../.claude-plugin/`
resolves to the plugin root's `.claude-plugin/` directory).

If the file cannot be read, stop with:
> "The forge-product-management plugin does not appear to be installed or the manifest
> is missing. Try reinstalling the plugin."

**Step 2 — Derive plugin_root from the resolved absolute path**

The Read tool resolves the relative path to an absolute path. That path has the form:
```
<plugin_root>/.claude-plugin/plugin.json
```

Strip `/.claude-plugin/plugin.json` from the end to get `plugin_root`.

Example:
```
Resolved path:  /Users/alice/.claude/plugins/cache/rr-standards/forge-product-management/1.0.0/.claude-plugin/plugin.json
plugin_root:    /Users/alice/.claude/plugins/cache/rr-standards/forge-product-management/1.0.0
```

Record: `plugin_root`.

**Step 3 — Use plugin_root to reference resources**

Plugin resources are at predictable paths relative to `plugin_root`:

| Resource | Path |
|----------|------|
| Skill references | `<plugin_root>/skills/<skill-name>/references/` |
| Skill fixtures | `<plugin_root>/skills/<skill-name>/fixtures/` |
| Templates | `<plugin_root>/templates/` |

---

## Worker Sub-agents

Skills running as Worker sub-agents typically receive `plugin_root` as an explicit
argument from their orchestrator. Use the passed value directly — do not re-run this
resolution. If `plugin_root` is absent from the arguments, run these steps to derive it.
