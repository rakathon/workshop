# forge-product-management — Environment Detection

This fragment defines how every skill in this plugin detects whether it is running in
a Forge-initialized project or a plain directory (e.g. Claude Desktop / Cowork), and
sets the canonical path variables used throughout the skill.

**Load this fragment at the very start of Step 0 (or the first step) of every skill.**

---

## Detection

Check whether `.forge/` exists in the current working directory:

```
[ -d ".forge" ] && echo "forge" || echo "plain"
```

- Result `forge` → **Forge mode**
- Result `plain` → **Plain mode** (Claude Desktop / Cowork / any non-Forge environment)

Set `env_mode = forge | plain`.

In plain mode, `./` is the equivalent of `.forge/` — the same subdirectory structure
is used, rooted at the working directory instead of `.forge/`.

---

## Path Variables

Set these variables immediately after detection. Use them everywhere — never
hardcode paths directly in skill steps.

### Forge mode

```
forge_root    = .forge
products_root = .forge/products
efforts_root  = .forge/efforts
effort_file   = .forge/EFFORT
```

### Plain mode

```
forge_root    = .
products_root = ./products
efforts_root  = ./efforts
effort_file   = (not used — ask PM for effort name directly)
```

### In both modes

```
product_dir = <products_root>/<product_name>/
```

---

## Effort Handling

For skills that operate on a specific effort (a scoped piece of work with its own
requirements directory), set `effort_dir` as follows:

### Forge mode

- Active effort: read `.forge/EFFORT` to get `effort_id`
- Effort dir: `<efforts_root>/<effort_id>/`
- Product name: read from `<effort_dir>/.state.json` → `productName` field

### Plain mode

- Effort dir: `<efforts_root>/<effort-name>/`
- When the skill asks "which effort?", ask for the effort name directly

**Do not reference `.forge/EFFORT`, `.forge/efforts/`, or `.state.json` in plain mode.**

---

## Shell Commands in Plain Mode

In plain mode, the PM may not have a terminal. Do not instruct them to run shell
commands. Use the Write and Read tools directly instead of `mkdir -p` or `cat`.

Create directories implicitly by writing the first file inside them — the Write tool
creates parent directories automatically.

---

## Quick Reference

| What you need | Forge mode | Plain mode |
|---|---|---|
| Forge root | `.forge/` | `./` |
| Products root | `.forge/products/` | `./products/` |
| Product base dir | `.forge/products/<name>/` | `./products/<name>/` |
| Strategy file | `.forge/products/<name>/strategy.md` | `./products/<name>/strategy.md` |
| Briefs dir | `.forge/products/<name>/briefs/` | `./products/<name>/briefs/` |
| Discovery dir | `.forge/products/<name>/discovery/` | `./products/<name>/discovery/` |
| Competitive dir | `.forge/products/<name>/competitive/` | `./products/<name>/competitive/` |
| Outcomes dir | `.forge/products/<name>/outcomes/` | `./products/<name>/outcomes/` |
| Metrics dir | `.forge/products/<name>/metrics/` | `./products/<name>/metrics/` |
| Research dir | `.forge/products/<name>/research/` | `./products/<name>/research/` |
| Efforts root | `.forge/efforts/` | `./efforts/` |
| Effort dir | `.forge/efforts/<id>/` | `./efforts/<name>/` |
| PRD requirements | `.forge/efforts/<id>/requirements/` | `./efforts/<name>/requirements/` |
| Active effort check | Read `.forge/EFFORT` | Ask PM for effort name |
