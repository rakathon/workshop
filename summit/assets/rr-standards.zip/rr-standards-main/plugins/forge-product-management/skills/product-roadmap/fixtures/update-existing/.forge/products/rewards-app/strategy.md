---
product: rewards-app
last_updated: 2026-05-01
---

# Product Strategy: Rewards App

*Last updated: 2026-05-01*

## Diagnosis

Members who do not redeem a reward within the first 30 days churn at 2.4× the rate of
those who do, resulting in 90-day retention of 34% versus an industry benchmark of 52%.

## Guiding Policy

Strategic pillars:
1. First-redemption acceleration — reduce time-to-first-redemption for new members
2. High-value member retention — improve 90-day retention for ARPU > $6 members

## Coherent Actions

| Initiative | Strategic pillar | Horizon | Success metric | Company OKR | Effort ID |
|---|---|---|---|---|---|
| Onboarding redemption nudge | First-redemption acceleration | now | % new members redeeming ≤14d ≥ 40% | OKR-2026-1 | effort/onboarding-nudge |
| Personalised offer engine v2 | High-value member retention | next | 90d retention ARPU>$6 ≥ 50% | OKR-2026-2 | |
| Lapsed member win-back | High-value member retention | later | Win-back rate ≥ 15% | OKR-2026-2 | |
