# Roadmap Templates

Two canonical formats for `roadmap.md`. Choose based on the PM's answer to the
format question in create mode.

---

## Format A — Now / Next / Later (horizons)

```markdown
# Product Roadmap: <Product Name>

*Last updated: YYYY-MM-DD*
*Strategy version: <date from strategy.md>*

## Horizon: Now (<timeframe>)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|
| <initiative name> | <pillar> | <OKR ref> | Active | effort/... |

## Horizon: Next (<timeframe>)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## Horizon: Later (<timeframe>)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## Completed
| Initiative | Effort ID | Completed |
|---|---|---|
```

---

## Format B — Quarterly Grid

```markdown
# Product Roadmap: <Product Name>

*Last updated: YYYY-MM-DD*
*Strategy version: <date from strategy.md>*

## <Q1_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## <Q2_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## <Q3_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## <Q4_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## Completed
| Initiative | Effort ID | Completed |
|---|---|---|
```

---

## Column Guidance

| Column | Description |
|--------|-------------|
| `Initiative` | Name from the coherent actions table in `strategy.md`. Link to the coherent action row using a markdown anchor if possible, otherwise note "See strategy.md". |
| `Strategic pillar` | The pillar this initiative belongs to, verbatim from `strategy.md`. |
| `OKR` | The OKR objective label or key result reference from `okrs.md`. |
| `Status` | One of: `Active`, `Planned`, `Deprioritized`, `Complete`. |
| `Effort ID` | The `forge:effort` ID if one exists, otherwise blank. |
