# forge:product-roadmap

Creates and maintains the product roadmap at `<products_root>/<name>/roadmap.md`
(`.forge/products/<name>/roadmap.md` in a Forge-initialized project, or
`./<name>/roadmap.md` in a plain directory such as Claude Desktop / Cowork).
This skill is the **sole owner** of `roadmap.md` — no other skill writes to this file.

---

## What It Does

`forge:product-roadmap` turns the coherent actions and OKRs produced by
`forge:product-strategy` into a living roadmap document. It operates in two modes:

- **Create mode** — builds a new `roadmap.md` from scratch when none exists yet.
- **Update mode** — evolves an existing `roadmap.md` (add initiatives, shift horizons,
  mark complete, or back-fill effort IDs).

---

## Usage

```
forge:product-roadmap
```

No argument is required. Claude will ask which product to work on and list the
directories under the products root (`.forge/products/` in Forge mode, `.` in plain
mode). In Forge mode, if there is an active effort Claude can infer the product name
automatically.

---

## When to Use

| Situation | Mode |
|-----------|------|
| Strategy is confirmed and no roadmap exists yet | Create |
| Adding a new initiative to an existing roadmap | Update |
| Moving an initiative to a different horizon or quarter | Update |
| Marking an initiative complete | Update |
| Back-filling a Forge effort ID for a roadmap row | Update |

This skill is also triggered automatically at the end of `forge:product-strategy`
when no `roadmap.md` exists yet.

---

## Prerequisites

| Artifact | Why it is needed |
|----------|-----------------|
| `<products_root>/<name>/strategy.md` | Provides the coherent actions table and strategic pillars |
| `<products_root>/<name>/okrs.md` | Provides OKR references for each initiative |

`<products_root>` is `.forge/products` in a Forge-initialized project and `.` in a
plain directory (Claude Desktop / Cowork). A Forge-initialized repository is **not**
required — plain directories are fully supported.

If either file is missing, the skill will stop and direct you to run
`forge:product-strategy` first.

---

## Supported Formats

When creating a new roadmap, you choose one of two formats:

### Now / Next / Later (horizon map)

Three rolling horizons — **Now**, **Next**, and **Later** — each with a timeframe label
you provide (e.g., "Now = Q3 2026, Next = Q4 2026 – Q1 2027, Later = 2027+"). Best
suited for continuous discovery and rolling planning cycles.

### Quarterly grid

Four fixed quarters with labels you specify (e.g., Q3 2026 / Q4 2026 / Q1 2027 /
Q2 2027). Best suited for fixed planning cycles.

Both formats use the same column structure per section:

| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

Both formats also include a **Completed** section where finished initiatives are
archived.

Valid `Status` values: `Active`, `Planned`, `Deprioritized`, `Complete`.

---

## Output Artifact

| File | Purpose |
|------|---------|
| `<products_root>/<name>/roadmap.md` | The roadmap document. Owned exclusively by this skill. |

`forge:product-strategy` may read `roadmap.md` for context during a refresh, but
does not modify it.

---

## Constraints

- Rows are **never deleted**. Deprioritized or completed initiatives are moved to
  `Deprioritized` status or the `## Completed` section.
- The only permitted write to `strategy.md` from this skill is back-filling a blank
  `Effort ID` cell in the coherent actions table.
- Always re-reads artifact files at invocation time; never reuses content from a prior
  conversation turn.

---

## Related Skills

| Skill | Relationship |
|-------|-------------|
| `forge:product` | Creates the product directory that this skill writes into |
| `forge:product-strategy` | Produces `strategy.md` and `okrs.md` that this skill reads; also triggers this skill automatically when no roadmap exists |
| `forge:effort` | Start an effort for any Now-horizon (or Q1) initiative that does not have an effort ID yet |
