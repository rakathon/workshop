---
name: forge:product-roadmap
description: >
  Creates and maintains a product roadmap from confirmed coherent actions and OKRs.
  Supports two modes: create (first roadmap from forge:product-strategy output) and
  update (evolving an existing roadmap.md). Is the sole owner of roadmap.md — no other
  skill writes this file.
when_to_use: >
  Trigger on: "build the roadmap", "create a roadmap", "generate the roadmap",
  "update the roadmap", "add something to the roadmap", "mark this complete on the
  roadmap", "shift this to next quarter", "what's on the roadmap", "roadmap planning",
  "forge:product-roadmap", or any time a PM wants to create or update a product
  roadmap after strategy has been confirmed. Also triggered automatically at the end
  of forge:product-strategy when no roadmap.md exists yet.
argument-hint: "[product-name]"
arguments: [product_name]
agent-type: worker
---

# forge:product-roadmap

Creates and maintains `<products_root>/<name>/roadmap.md`. This skill is the **sole
owner** of `roadmap.md` — no other skill writes to this file. `forge:product-strategy`
may read it for context during refresh mode but does not modify it.

---

## Plugin Root Resolution

Resolve the plugin root using:
`plugins/forge-product-management/skills/common/plugin-root.md`

This sets `plugin_root`. Reference files below are relative to it.

---

## Step 0 — Environment detection

Load `plugins/forge-product-management/skills/common/environment.md`.

Follow the detection instructions there to set:
- `env_mode` = `forge` or `plain`
- `products_root` = `.forge/products` (forge) or `.` (plain)

Do not hardcode `.forge/products/` anywhere in the steps below. Use `products_root`
for all path construction.

---

## Step 1 — Identify the product and detect mode

1. **Forge mode only:** Check for an active effort. If `.forge/EFFORT` exists, read it
   to get the effort ID and locate the associated product name from `.state.json`
   (`productName` field).
   **Plain mode:** Skip the effort check — ask the PM for the product name directly.
2. If no product name has been determined yet, ask: "Which product are you working on?"
   then list the directories under `<products_root>/`.
3. Set `PRODUCT_DIR` = `<products_root>/<name>/`.
4. Check whether `PRODUCT_DIR/roadmap.md` exists.
   - If it does **not** exist → **Create mode**: read
     `plugins/forge-product-management/skills/product-roadmap/references/create-mode.md`
     and follow it.
   - If it **does** exist → **Update mode**: read
     `plugins/forge-product-management/skills/product-roadmap/references/update-mode.md`
     and follow it.

Read each reference file before executing its steps. Do not pre-load both files.

---

## Constraints

- **Never delete** a roadmap row. Mark it `Deprioritized` or `Complete` instead.
- **Never modify** `strategy.md` pillars, diagnosis, or guiding policy. The only
  permitted write to `strategy.md` is back-filling a blank `effort_id` cell in the
  coherent actions table (update mode step 6d).
- **Never write `roadmap.md` from any other skill.** If another skill needs roadmap
  content, it must read `roadmap.md`, not generate it.
- Always re-read artifact files at the start of each invocation; never reuse content
  from a prior conversation turn.
- In plain mode, do not run shell commands. Use the Read and Write tools directly.
