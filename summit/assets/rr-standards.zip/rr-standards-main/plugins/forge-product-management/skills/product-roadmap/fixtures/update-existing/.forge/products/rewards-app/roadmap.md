# Product Roadmap: Rewards App

*Last updated: 2026-05-10*
*Strategy version: 2026-05-01*

## Horizon: Now (Q3 2026)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|
| Onboarding redemption nudge | First-redemption acceleration | OKR-2026-1 | Active | effort/onboarding-nudge |

## Horizon: Next (Q4 2026 – Q1 2027)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|
| Personalised offer engine v2 | High-value member retention | OKR-2026-2 | Planned | |

## Horizon: Later (2027+)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|
| Lapsed member win-back | High-value member retention | OKR-2026-2 | Planned | |

## Completed
| Initiative | Effort ID | Completed |
|---|---|---|
