# Update Mode — Full Procedure

Entered when `PRODUCT_DIR/roadmap.md` already exists. Evolves the roadmap through
four targeted operations.

---

## Step 5 — Read current state

1. Re-read `PRODUCT_DIR/roadmap.md` (do not reuse content from any prior turn).
2. Re-read `PRODUCT_DIR/strategy.md` to get the current coherent actions table and pillars.
3. Re-read `PRODUCT_DIR/okrs.md`.
4. Ask the PM what they want to do. Present the menu:

   > "What would you like to update?
   > 1. Add a new initiative to a horizon
   > 2. Shift an initiative to a different horizon
   > 3. Mark an initiative complete
   > 4. Back-fill an effort ID for an initiative
   > 5. Multiple of the above"

   Wait for the answer.

---

## Step 6 — Apply the change

### 6a — Add a new initiative

1. Ask the PM for the initiative details:
   - Name
   - Which horizon or quarter it belongs to
   - Which strategic pillar it maps to (show the pillar list from `strategy.md`)
   - Which OKR it supports (show OKR list from `okrs.md`)

2. **Pillar check:** Verify the named pillar exists verbatim in `strategy.md`. If the
   initiative does not map to any existing pillar, surface this warning before proceeding:

   > "This initiative doesn't map to an existing strategic pillar in `strategy.md`.
   > This looks like a strategy change — it doesn't map to an existing coherent action
   > in `strategy.md`. Consider running `forge:product-strategy` in refresh mode to
   > update the strategy first, then add this to the roadmap."

   Ask: "Do you want to proceed anyway, or run `forge:product-strategy` first?"
   Only continue if the PM confirms they want to proceed.

3. Add the new row to the correct horizon section in `roadmap.md` with `Status = Planned`
   and blank `Effort ID`.

4. Update the `Last updated` date at the top of `roadmap.md` to today.

---

### 6b — Shift an initiative to a different horizon

1. Ask which initiative and which horizon it should move to.
2. Move the row from its current horizon section to the target section.
3. Do not change any other columns.
4. Update the `Last updated` date.

---

### 6c — Mark an initiative complete

1. Ask which initiative is complete and the effort ID (if not already in the table).
2. Remove the row from its current horizon section.
3. Add a row to the `## Completed` section with columns: Initiative, Effort ID, Completed
   (today's date).
4. Update the `Last updated` date.

---

### 6d — Back-fill an effort ID

1. Ask which initiative and what effort ID to record.
2. Update the `Effort ID` column for that row in `roadmap.md`.
3. Also update the `effort_id` column for the matching coherent action row in
   `strategy.md` if that column exists and is currently blank. This is the only
   modification `forge:product-roadmap` is permitted to make to `strategy.md`.
4. Update the `Last updated` date in `roadmap.md`.

---

## Step 7 — Confirm and close

After any update, show the PM the diff (list of lines added or changed) and confirm:

> "Updated `roadmap.md`. Here is what changed:
> - <list each change as a bullet>"

If the PM requested multiple changes (option 5 in Step 5), return to Step 5 after each
change until all are done, then give a single consolidated summary.
