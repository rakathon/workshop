# OKRs: Rewards App — 2026

## Objective 1 (OKR-2026-1): Increase new member activation rate

- KR1: % of new members redeeming within 14 days: 22% → 40%
- KR2: Average days-to-first-redemption: 18 days → 9 days

## Objective 2 (OKR-2026-2): Improve retention in high-value cohort

- KR1: 90-day retention for ARPU>$6 members: 34% → 50%
- KR2: NDR across all members: 88% → 98%
