# Create Mode — Full Procedure

Entered when `PRODUCT_DIR/roadmap.md` does not exist. Builds a fresh roadmap from
confirmed strategy artifacts.

---

## Step 2 — Read strategy inputs

1. Read `PRODUCT_DIR/strategy.md`. Extract:
   - The coherent actions table (all rows: Initiative, Strategic pillar, Owner, Effort ID).
   - The guiding policy pillars list.
   - The `Last updated` date at the top of the file — record as `STRATEGY_DATE`.
2. Read `PRODUCT_DIR/okrs.md`. Extract all OKRs (objective + key results).
3. If either file is missing, stop and tell the PM:
   > "I need both `strategy.md` and `okrs.md` to build the roadmap. Run
   > `forge:product-strategy` first to produce these artifacts."

   (`PRODUCT_DIR` was set in Step 1 using `products_root` from environment detection.
   Do not hardcode `.forge/products/` here.)

---

## Step 3 — Ask format preference

Ask the PM exactly one question:

> "Do you want a **Now / Next / Later** horizon map or a **quarterly grid** (Q1/Q2/Q3/Q4)?
> - Now/Next/Later works well for continuous discovery and rolling planning.
> - Quarterly grid works well when you have fixed planning cycles."

Wait for the answer. Record the choice as `FORMAT` = `horizons` or `quarterly`.

If `FORMAT = quarterly`, also ask:
> "What quarters should I use? (e.g., Q3 2026 / Q4 2026 / Q1 2027 / Q2 2027)"

Wait for the answer. Record the four quarter labels as `Q1_LABEL`, `Q2_LABEL`,
`Q3_LABEL`, `Q4_LABEL`.

---

## Step 4 — Assign initiatives and write roadmap.md

**4.1 — Initiative placement**

Present all coherent actions as a numbered list. Ask the PM to assign each to a
horizon or quarter:

For horizons format:
> "Please assign each initiative to a horizon. Reply with the number and horizon,
> e.g.: 1=Now, 2=Next, 3=Later"

For quarterly format:
> "Please assign each initiative to a quarter. Reply with the number and quarter,
> e.g.: 1=Q3 2026, 2=Q4 2026"

Wait for assignments from the PM.

**4.2 — OKR mapping**

Map each coherent action to its OKR. Use the OKR references already in `strategy.md`
if present. If a coherent action has no OKR mapping, use "—".

**4.3 — Timeframe labels (horizons format only)**

If `FORMAT = horizons`, ask the PM:
> "What timeframe should each horizon cover? For example: Now = Q3 2026,
> Next = Q4 2026 – Q1 2027, Later = 2027+"

Wait for the answer.

**4.4 — Write roadmap.md**

Use the template below that matches `FORMAT`. Substitute all placeholders:
- `<Product Name>` — the product name
- `YYYY-MM-DD` for `Last updated` — today's date
- `<date from strategy.md>` for `Strategy version` — `STRATEGY_DATE`
- Horizon/quarter section headings and timeframe labels
- Initiative rows, one per coherent action, placed in the correct section

Default `Status` values:
- Initiatives assigned to Now (or Q1) → `Active`
- Initiatives assigned to Next, Later, or Q2+ → `Planned`

**Template for Now / Next / Later format:**

```markdown
# Product Roadmap: <Product Name>

*Last updated: YYYY-MM-DD*
*Strategy version: <date from strategy.md>*

## Horizon: Now (<timeframe>)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## Horizon: Next (<timeframe>)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## Horizon: Later (<timeframe>)
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## Completed
| Initiative | Effort ID | Completed |
|---|---|---|
```

**Template for quarterly grid format:**

```markdown
# Product Roadmap: <Product Name>

*Last updated: YYYY-MM-DD*
*Strategy version: <date from strategy.md>*

## <Q1_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## <Q2_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## <Q3_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## <Q4_LABEL>
| Initiative | Strategic pillar | OKR | Status | Effort ID |
|---|---|---|---|---|

## Completed
| Initiative | Effort ID | Completed |
|---|---|---|
```

Both templates **require** the `*Strategy version: ...*` header line and the `## Completed`
section. Do not omit either.

Write the completed file to `PRODUCT_DIR/roadmap.md`.

**4.5 — Confirm**

In Forge mode:
> "Roadmap written to `PRODUCT_DIR/roadmap.md`. Run `forge:effort` to start an effort
> for any Now-horizon initiative that doesn't have one yet."

In plain mode:
> "Roadmap written to `PRODUCT_DIR/roadmap.md`."
