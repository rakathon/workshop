# No-Web-Search Fallback — Manual Competitor Research

Entered when WebFetch / web search is unavailable.

**IMPORTANT: Do not use model training knowledge as a substitute for web search.**
Competitive analysis requires current data. Model training knowledge is stale — it
will not reflect recent product launches, pricing changes, funding rounds, or
market shifts. Using it without disclosure would mislead the PM. The only acceptable
fallback is to gather information from the PM interactively.

Announce:
> "Web search is unavailable, and I won't substitute model training data — it's too
> stale for accurate competitive analysis. Instead, I'll ask you structured questions
> about each competitor so we can build an accurate picture together."

## Per-competitor information gathering

For each competitor in the list (from Step 1.3, or discovered by asking the PM):

Ask the following in a single message (to avoid excessive back-and-forth):

> "For **<Competitor>**, please share whatever you know about:
> 1. **Product overview** — what it does, core use cases, target customer
> 2. **Key features** — flagship capabilities, any recently launched features
> 3. **Pricing** — pricing model and published tiers if you know them
> 4. **Positioning** — how they describe themselves, their homepage headline or tagline
> 5. **Customer evidence** — named customers, reviews you've seen, analyst mentions
> 6. **Recent moves** — funding, acquisitions, product launches in the last year
> 7. **Apparent strengths/weaknesses** — from your own experience, sales calls, or reviews
>
> You can leave any field blank if unknown — I'll mark it as `?` in the analysis."

Record the PM's answers as the research data for that competitor.

## Market trends (manual)

After all competitors are covered, ask:
> "What macro trends are you seeing in the **<product_category>** market?
> For example: AI feature adoption, pricing pressure, regulatory shifts,
> platform consolidation. List 3–5 if you can, even rough observations."

Use the PM's answer as the market trends source.

## Proceed normally

Once information is gathered for all competitors, continue from Step 3 (present
research summary for confirmation). Mark all data as sourced from PM input rather
than web research. Note in the brief's `Research notes` section:
> "Web search unavailable; all data sourced from PM input. Independent verification
> recommended before using this brief for major strategic decisions."
