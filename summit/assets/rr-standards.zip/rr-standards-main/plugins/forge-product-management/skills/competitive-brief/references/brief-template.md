# Brief File Template

Use this template when writing the brief file in Step 9.

Write to: `<product_dir>/competitive/<brief_name>.md`

```markdown
---
product: <product_name>
brief: <brief_focus>
date: <YYYY-MM-DD>
competitors: [<list of competitor names>]
strategic_implication: <true|false>
---

Note: always use `date` as the key name — never `refresh_date`, `last_updated`, or `refreshed`.

# Competitive Brief — <brief_focus>

*Product: <product_name> | Date: <date>*

---

## Executive Summary

<3–5 sentence summary of the most important findings: the competitive landscape in
a nutshell, our primary differentiated position, the single most important threat or
opportunity.>

---

## Feature Matrix

<feature matrix table — grouped by cluster, our product in the first data column>

| Feature / Capability | <Our Product> | <Competitor A> | <Competitor B> | ... |
|---------------------|:---:|:---:|:---:|:---:|
| **Cluster 1**       |     |     |     |     |
| Feature X           | ✓   | ✓   | ~   |     |
| Feature Y           | ~   | ✓   | ✗   |     |
| **Cluster 2**       |     |     |     |     |
| Feature Z           | ✗   | ✓   | ?   |     |

*Key: ✓ supported · ~ partial/limited · ✗ absent · ? unknown*

### Where we lead
- <capability or dimension where we are clearly ahead>

### Where we lag
- <capability or dimension where most competitors are ahead>

---

## Positioning Analysis

### Competitive positioning summaries

**<Our Product>**
<3–5 sentences: stated target customer, emphasised capabilities/values, competitive
claim, tone and brand character>

**<Competitor A>**
<3–5 sentences>

*(repeat for each competitor)*

### Positioning map

<Narrative description of the landscape: which positioning territories are crowded,
which are open/underserved, where our product's positioning sits relative to the
field, and any messaging inconsistency between what we say and what others say
about us.>

---

## Win / Loss Signals

### Where we win

| Customer type / use case | Reason | Confidence |
|--------------------------|--------|-----------|
| <type> | <reason from reviews, case studies, or PM input> | High / Medium / Low |

### Where we lose

| Competitor | Customer type / use case | Reason | Confidence |
|------------|--------------------------|--------|-----------|
| <name> | <type> | <reason> | High / Medium / Low |

### Where data is thin

- <scenario with no clear signal>
- *Recommended: collect first-party data from <sales calls / churn reasons / NPS verbatims>*

---

## Market Trends

### <Trend Name>

**What is happening:** <2–3 sentences with evidence>
**Who is moving on it:** <which competitors are capitalising>
**Implication for us:** <threat / opportunity / tailwind>
**Time horizon:** Near-term (0–12 months) / Medium-term (1–3 years) / Structural

*(repeat for 3–5 trends, ordered by combined urgency and impact — most urgent first)*

---

## Research notes

*Sources consulted:*
- <URL or source type>

*Data gaps:* <areas where public data was unavailable or unreliable>
*Last updated:* <YYYY-MM-DD>
```
