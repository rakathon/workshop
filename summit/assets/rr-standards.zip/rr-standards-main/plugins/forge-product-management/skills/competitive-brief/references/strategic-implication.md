# Strategic Implication Surface — Step 10

Entered when `strategic_implication = true` is set in Step 8.

## Present the finding

Present the specific finding and ask:
> "This brief surfaces a potentially significant strategic implication:
>
> **<one-sentence description of the threat / gap / opportunity>**
>
> This kind of finding typically warrants updating your product strategy to account
> for it. Would you like to:
> (1) **Run `forge:product-strategy` in refresh mode** — update your diagnosis and
>     pillars to reflect this new competitive reality
> (2) **Note it as an open question** — I'll add a flagged item to the brief so you
>     can revisit it at your next strategy review
> (3) **Skip for now**"

## Option 1 — Invoke refresh

Invoke `forge:product-strategy` if the skill is available, passing `product_name`
and `mode = refresh`. Otherwise remind the PM:
> "Run `forge:product-strategy --mode refresh` in your next session to update the
> strategy diagnosis."

## Option 2 — Note it as an open question

Append this section to the brief file:

```markdown
## Strategic Open Questions

| # | Finding | Recommended action | Date flagged |
|---|---------|-------------------|--------------|
| 1 | <one-sentence finding> | <e.g., "Revisit positioning pillar 2 in next strategy refresh"> | <YYYY-MM-DD> |
```

If a `## Strategic Open Questions` section already exists (from a prior refresh),
append a new row to the table rather than replacing it.

## Option 3 — Skip

Acknowledge and close:
> "Noted. The implication is recorded in the brief's `strategic_implication: true`
> frontmatter field. You can act on it in a future `forge:product-strategy` session."
