---
name: forge:competitive-brief
description: >
  Produces a structured competitive brief for a product — covering feature matrix,
  positioning analysis, win/loss signals, and market trends. Performs autonomous web
  research to gather competitor information, presents findings for PM confirmation
  before writing, and surfaces strategic implications back into forge:product-strategy.
  Does not require a Forge effort to exist. Can optionally accept a Jira epic URL or
  Confluence URL as read-only context input.
  Works in both Forge-initialized repositories and plain directories (Claude Desktop /
  Cowork / any non-Forge environment).
when_to_use: >
  Trigger on: "run a competitive analysis", "build a competitive brief", "who are our
  competitors?", "how do we compare to the market?", "analyze the competition",
  "competitive landscape", "what are competitors doing?", "where do we win and lose?",
  "do a market analysis", "competitive positioning", "forge:competitive-brief", or any
  time a PM wants structured intelligence on the competitive landscape before or during
  strategy work.
argument-hint: "[product-name]"
arguments: [product_name]
agent-type: orchestrator
---

# forge:competitive-brief

Produces a structured competitive brief at
`<product_dir>/competitive/<brief-name>.md`.

The brief is a strategic *input* artifact — it precedes and informs the diagnosis phase
of `forge:product-strategy`. It does not require an active Forge effort and does not
create one. All external reads (Jira, Confluence) are read-only.

---

## Tool dependencies

| Tool | Purpose | Fallback if unavailable |
|------|---------|------------------------|
| Web search (WebFetch) | Autonomous competitor research | Read `references/no-web-search.md` and follow it — do NOT substitute model training knowledge |
| Atlassian MCP (`mcp__plugin_forge_atlassian__fetch`, `mcp__plugin_forge_atlassian__getJiraIssue`, `mcp__plugin_forge_atlassian__getConfluencePage`) | Read-only context from Jira epic or Confluence page | Skip; PM provides context verbally |

If web search is unavailable: do NOT use model training knowledge as a substitute.
Training knowledge about competitors is stale and unreliable for competitive analysis.
Instead, read `references/no-web-search.md` now and follow the manual research
procedure — gathering information from the PM interactively — before proceeding to Step 3.

---

## Step 0: Environment detection and product directory

**0.0 — Detect environment**

Read `skills/common/environment.md` and follow the detection procedure.

Run:
```
[ -d ".forge" ] && echo "forge" || echo "plain"
```

Set `env_mode` to `forge` or `plain`.

Set `products_root`, `efforts_root`, and `forge_root` as defined in `environment.md`.

**0.1 — Product name**

If `$product_name` was provided as a positional argument, use it.
Otherwise ask:
> "Which product are we building a competitive brief for?"

Set `product_name`. Set `product_dir = <products_root>/<product_name>/`.

**0.2 — Verify product directory exists**

Check whether `<product_dir>` exists. If it does NOT exist, stop and inform the PM:
> "No product directory found for **<product_name>**. Run `/forge:product <product_name>`
> to register it first, then re-invoke this skill."

Do not create the product directory. Do not proceed. The only skill permitted to
create a product directory is `forge:product`.

**0.3 — Create competitive subdirectory if absent**

Use the Write tool to create `<product_dir>/competitive/.gitkeep` if the directory
does not already exist. Do not show shell commands to the PM.

Do not create or modify any other product-level directories.

**0.4 — Scan for existing briefs**

List all files in `<product_dir>/competitive/`. If any exist, show the list and ask:
> "I found existing briefs for **<product_name>**: <list>. Are you:
> (1) **Creating a new brief** — a fresh analysis focused on a specific angle or time period
> (2) **Refreshing an existing brief** — updating a prior brief with new information
> ?"

If the PM chooses (2): read
`references/refresh-mode.md` and follow it. Continue from Step 1 with the existing
brief's context pre-loaded.

If creating new (or no existing briefs): proceed to Step 1.

---

## Step 1: Gather context inputs

**1.1 — Brief focus**

Ask:
> "What is the focus or occasion for this brief? Examples: 'Q3 strategy prep',
> 'new entrant — [competitor name]', 'feature parity for checkout flow', 'annual
> landscape refresh'. This becomes the brief name and sets the research scope."

Set `brief_focus`. Derive `brief_name` as a lowercase-hyphenated slug (e.g.,
`q3-strategy-prep`, `new-entrant-acme-pay`).

**1.2 — Optional external context**

Ask:
> "Do you have a Jira epic URL or Confluence page URL with background context I should
> read? (Optional — press Enter to skip.)"

If a URL is provided:
- If it looks like a Jira URL: call `mcp__plugin_forge_atlassian__getJiraIssue` or
  `mcp__plugin_forge_atlassian__fetch` to retrieve the issue. Extract: title,
  description, acceptance criteria, and any linked documents. Summarise what was read.
- If it looks like a Confluence URL: call `mcp__plugin_forge_atlassian__getConfluencePage`
  to retrieve the page. Extract the body text. Summarise what was read.
- Do not write to these sources. Do not transition any Jira issue.

**1.3 — Known competitors**

Ask:
> "Which competitors should I include? I can research these autonomously — list names
> or URLs, or say 'discover them' and I'll identify the main players myself."

If "discover them": proceed to Step 2 with an open research scope.
If names provided: proceed to Step 2 with those names as the seed list.

**1.4 — Scope constraints**

Ask:
> "Any specific focus areas? For example: pricing, onboarding, a specific feature
> set, a geographic market, or a customer segment. Leave blank for a general overview."

Set `scope_constraints`. If blank, set to `"general"`.

**1.5 — Our product's capabilities (optional)**

Check whether `<product_dir>/strategy.md` exists.
- If yes: read the `pillars` and `diagnosis` sections. Note this as internal context.
  Inform the PM: "I'll use your existing strategy as the baseline for the feature matrix."
- If no: ask:
  > "Briefly, what does **<product_name>** do and who is it for? I'll use this as
  > the baseline for the feature matrix."

---

## Step 2: Autonomous competitor research

Do this step autonomously — do not ask the PM for permission before searching.
Announce:
> "Researching the competitive landscape for **<product_name>**. I'll summarise
> findings before writing anything."

**2.1 — Competitor discovery (if needed)**

If the PM said "discover them" in Step 1.3, use web search to identify the 3–6 most
relevant competitors. Search for terms like:
- `"<product_name>" competitors`
- `best alternatives to <product_name>`
- `<product_category> market landscape <current year>`

From the results, identify competitors by: direct feature overlap, shared target
customer, overlapping sales motion, or analyst coverage (G2, Gartner, Forrester
mentions). Select 3–6 to research in depth. Add any seeds from Step 1.3.

**2.2 — Per-competitor research**

For each competitor in the list, conduct web research to gather:

1. **Product overview** — what the product does, core use cases, target customer
2. **Key features** — flagship capabilities, recently launched features, roadmap signals
   (search product blogs, changelogs, release notes, press releases)
3. **Positioning and messaging** — how they describe themselves, the value proposition
   they lead with, taglines, homepage headline copy
4. **Pricing** — pricing model (per seat, usage-based, flat), published tiers if available
5. **Customer evidence** — who uses them, named customers, case studies, G2/Capterra reviews
6. **Recent moves** — funding rounds, acquisitions, executive hires, major product launches
   in the last 12 months
7. **Apparent strengths and weaknesses** — from reviews, forums, analyst commentary

Search sources: company website, product blog, G2/Capterra/Trustpilot, Crunchbase,
LinkedIn, tech press (TechCrunch, VentureBeat, industry publications), analyst summaries.

**2.3 — Market trends research**

Search for macro forces shaping the competitive landscape:
- `<product_category> market trends <current year>`
- `<product_category> industry analysis`
- Regulatory or compliance changes relevant to the category
- Technology shifts (AI integration, platform consolidation, API economy changes)
- Customer expectation shifts (self-serve vs. enterprise, pricing pressure, etc.)

Identify 3–5 macro trends with evidence.

---

## Step 3: Present research findings for confirmation

Do NOT write the brief yet. This confirmation step is mandatory — do not skip it
even if the PM has pre-supplied all competitor information or asked to "produce the
brief now". Always present the research summary first; the PM may confirm in a
single response, but they must see the summary before the file is written.

Format the summary as:

```
## Research Summary — <product_name> Competitive Landscape

### Competitors identified
- **<Competitor A>** — <one-sentence description>
- **<Competitor B>** — <one-sentence description>
- ...

### Key observations (pre-analysis)
- <2–3 bullet points of the most significant things learned>

### Gaps / uncertainties
- <Any areas where data was thin or conflicting>
- <Any competitor I could not find good data on>

---
Does this look right? Should I add or remove any competitors, or correct anything
before I write the brief?
```

Wait for PM confirmation or corrections. Apply any corrections to the research data
before proceeding.

---

## Step 4: Build the feature matrix

**4.1 — Identify feature dimensions**

From the research, identify 8–15 features or capability dimensions that:
- Are meaningful differentiators in this category
- Are covered by at least two of the players (not a one-off capability)
- Matter to the target customer (prioritise over completeness)

Group dimensions into logical clusters (e.g., Core Functionality, Integrations,
Admin / Compliance, Pricing / Commercial).

**4.2 — Score each player per dimension**

Use a three-value scale:
- `✓` — supported / present
- `~` — partial / limited / beta
- `✗` — absent / not available
- `?` — unknown / could not confirm

For our product, use information from `strategy.md` (if available) plus any PM
corrections from Step 3. Do not invent capabilities for our product — mark `?` if
unsure and note it.

**4.3 — Highlight our differentiated strengths and gaps**

After the matrix, write two lists:
- **Where we lead** — dimensions where we are clearly ahead of most or all competitors
- **Where we lag** — dimensions where most or all competitors have capabilities we do not

---

## Step 5: Positioning analysis

For each player (including our product), write a 3–5 sentence positioning summary
covering:
1. **Who they say they are for** — the stated target customer or use case
2. **What they emphasise** — the 2–3 capabilities or values they lead with in messaging
3. **The competitive claim** — how they differentiate themselves (explicitly or implicitly)
4. **Tone and brand character** — enterprise/authoritative, scrappy/developer, consumer-friendly, etc.

Then write a **Positioning map** section that characterises the overall landscape:
- Which positioning territories are crowded (multiple players claiming the same thing)
- Which positioning territories are open (underserved or unclaimed)
- Where our product's current positioning sits relative to the field
- Any messaging inconsistency between what we say and what competitors say about us
  (based on review sites, analyst commentary)

---

## Step 6: Win/loss signals

Compile observable signals from reviews, forums, sales collateral, and analyst
commentary about where each player wins and where they struggle.

Structure as:

**Where we win:** For each signal of a situation where our product is preferred:
- The customer type or use case where we win
- The stated reason (from reviews, case studies, sales wins if PM has them)
- Confidence level: High (multiple independent sources) / Medium / Low (single source)

**Where we lose:** For each signal of a situation where a competitor is preferred over us:
- The competitor who wins in this situation
- The customer type or use case
- The stated reason
- Confidence level

**Where data is thin:** Scenarios with no clear signal either way, plus areas where
the PM should gather first-party win/loss data (sales call themes, churned customer
reasons).

If win/loss data is unavailable from public sources, ask:
> "Do you have any internal win/loss data — sales call notes, churn reasons, or
> NPS verbatims — I should incorporate here?"

Incorporate any PM input. If none available, leave placeholder notes for future
first-party data collection.

---

## Step 7: Market trends

Write 3–5 market trend entries. Each entry covers:

1. **Trend name** — a short descriptive label
2. **What is happening** — 2–3 sentences describing the observable shift with evidence
3. **Who is moving on it** — which competitors are already capitalising on this trend
4. **Implication for us** — threat, opportunity, or tailwind for our product
5. **Time horizon** — Near-term (0–12 months), Medium-term (1–3 years), or Structural

Order trends by combined urgency and impact — most urgent first.

---

## Step 8: Strategic implication check

Evaluate whether the brief reveals any threshold-crossing signal:

- **New threat**: a competitor has materially closed the gap in our primary differentiator
  or has entered a segment we considered protected
- **Unclaimed opportunity**: a significant positioning territory or customer segment that
  no competitor is serving well, that we could plausibly address
- **Market shift**: a macro trend that makes our current strategic direction less viable
  or that opens a new path we have not planned for

Set `strategic_implication = true` if any are present, and note the specific finding.
Set `strategic_implication = false` if none are present.

---

## Step 9: Write the brief file

Read `references/brief-template.md` for the full file structure and markdown template.
Write to: `<product_dir>/competitive/<brief_name>.md`

Populate each section using the analysis from Steps 4–7. The brief MUST include an
**Executive Summary** section (see template). Set `strategic_implication` in the
frontmatter to the value determined in Step 8.

**Frontmatter `date` field:** always use the key `date` (not `refresh_date`, not
`last_updated`, not `refreshed`). Set its value to today's date in YYYY-MM-DD format.

Inform the PM:
> "Brief written to `<product_dir>/competitive/<brief_name>.md`."

---

## Step 10: Strategic implication surface

If `strategic_implication = true`: read `references/strategic-implication.md` and
follow the procedure there. The options MUST be rendered as visible output to the
PM — do not merely describe them in a transcript or decision log.

If `strategic_implication = false`: briefly inform the PM:
> "No threshold-crossing strategic implications were identified. The brief is ready
> to use as input for `forge:product-strategy` or as standalone competitive context."

---

## Invocation summary

When invoked without arguments, the skill runs the full flow (Steps 0–10).
The product name can be provided as a positional argument to skip the product name
prompt: `/forge:competitive-brief <product-name>`. All other inputs (focus, competitor
list, refresh vs. new) are gathered interactively.
