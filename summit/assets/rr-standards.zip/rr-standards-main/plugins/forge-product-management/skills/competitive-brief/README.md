# forge:competitive-brief

Produces a structured competitive brief for a product — covering feature matrix,
positioning analysis, win/loss signals, and market trends. Performs autonomous web
research to gather competitor information, presents findings for PM confirmation
before writing, and surfaces strategic implications back into `forge:product-strategy`.

---

## Usage

```
forge:competitive-brief
forge:competitive-brief --product <name>
forge:competitive-brief --product <name> --focus <text>
forge:competitive-brief --product <name> --competitors <name,name,...>
forge:competitive-brief --product <name> --refresh <brief-name>
```

Optional arguments:

| Argument | Effect |
|----------|--------|
| `--product <name>` | Skip the product name prompt |
| `--focus <text>` | Skip the brief focus prompt |
| `--competitors <name,name,...>` | Use this list; skip autonomous competitor discovery |
| `--refresh <brief-name>` | Load an existing brief for refresh; skip new/refresh prompt |

Accepts optional external context at invocation time:
- A Jira epic URL (read-only — extracted for background context)
- A Confluence page URL (read-only — extracted for background context)

---

## When to use

- Before or during `forge:product-strategy` — to ground the diagnosis in real market data
- When a new competitor has entered the market and you need a rapid assessment
- For a quarterly or annual competitive landscape refresh
- Any time a PM asks "run a competitive analysis", "who are our competitors?", "how do we compare to the market?", "where do we win and lose?", "analyze the competition", "competitive landscape", or "competitive positioning"

---

## Prerequisites

- A product directory for the target product — run `forge:product` first if absent (the skill creates the `competitive/` subdirectory automatically)
- **No `.forge/` required** — the skill works in plain directories (Claude Desktop / Cowork) as well as Forge-initialized repositories:
  - **Forge mode** (`.forge/` present): product directory is `.forge/products/<product-name>/`
  - **Plain mode** (no `.forge/`): product directory is `./<product-name>/` relative to the working directory
- Web search (WebFetch) recommended for autonomous research — degrades gracefully if unavailable; Claude prompts the PM to paste competitor information instead
- Atlassian MCP tools optional — used only if a Jira or Confluence URL is provided as context input

---

## Output artifacts

All artifacts are written under `<product_dir>/competitive/`
(`.forge/products/<product-name>/competitive/` in Forge mode, `./<product-name>/competitive/` in plain mode):

| File | Purpose |
|------|---------|
| `<brief-name>.md` | The competitive brief: executive summary, feature matrix, positioning analysis, win/loss signals, market trends, and research notes |

Brief names are lowercase-hyphenated slugs derived from the brief focus (e.g., `q3-strategy-prep.md`, `new-entrant-acme-pay.md`).

Refreshing an existing brief overwrites the file in place.

---

## What the brief contains

| Section | Contents |
|---------|----------|
| Executive Summary | 3–5 sentence summary of the competitive landscape, primary differentiated position, and the single most important threat or opportunity |
| Feature Matrix | 8–15 capability dimensions across all players, scored ✓/~/✗/?; highlights where we lead and where we lag |
| Positioning Analysis | Per-player positioning summaries plus a narrative positioning map identifying crowded and open territories |
| Win / Loss Signals | Observable signals from reviews, forums, and analyst commentary; flags where first-party data should be collected |
| Market Trends | 3–5 macro trends ordered by urgency and impact, each with implications for our product |
| Research Notes | Sources consulted, data gaps, and last-updated date |

If a threshold-crossing strategic implication is detected (new threat, unclaimed opportunity, or market shift), the skill flags it and offers to invoke `forge:product-strategy` in refresh mode.

---

## Relationship to other skills

| Skill | Relationship |
|-------|-------------|
| `forge:product` | Creates the product directory that competitive-brief writes into; run this first if the product is not yet registered |
| `forge:product-strategy` | competitive-brief is a strategic *input* to product-strategy; run competitive-brief before or during the diagnosis phase of product-strategy |
| `forge:effort` | Not invoked by this skill — competitive-brief does not create or require a Forge effort |
