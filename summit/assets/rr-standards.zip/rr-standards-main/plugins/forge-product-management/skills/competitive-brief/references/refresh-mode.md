# Refresh Mode — Updating an Existing Competitive Brief

Entered when the PM selects "Refreshing an existing brief" in Step 0.3, or when
`--refresh <brief-name>` is passed as an argument.

## Load the existing brief

1. Read the full content of `<product_dir>/competitive/<brief-name>.md`.
2. Note from frontmatter:
   - `date` — the brief's last-updated date
   - `competitors` — the previously researched list
   - `strategic_implication` — the prior value (will be re-evaluated)
3. Note from body: the prior executive summary, feature matrix scores, and any
   open strategic questions flagged in a `## Strategic Open Questions` section.

## Determine what has changed

Inform the PM:
> "I've loaded the existing brief from **<date>**. It covered: <competitor list>.
> What has changed since then? For example: a new competitor, a product launch,
> pricing changes, or just a scheduled annual refresh?"

Accept the PM's answer as `change_summary`. This guides research prioritisation.

## Scoped research in Step 2

When performing Step 2 in refresh mode:
- Prioritise researching changes the PM explicitly called out.
- For each previously covered competitor, search for activity in the last
  `<months since brief date>` months: product launches, pricing changes, funding,
  and major customer wins or losses.
- Add any new competitors identified since the last brief.
- Re-run the market trends research (Step 2.3) — trends evolve faster than features.

## Presenting findings in Step 3

In the research summary (Step 3), lead with a **"What's changed since <date>"**
subsection before the full competitor list:

```
## Research Summary — <product_name> Competitive Landscape (Refresh)

### What's changed since <date>
- <notable change 1>
- <notable change 2>
- <no significant changes detected for <Competitor X>>

### Competitors (confirmed / updated)
- **<Competitor A>** — <updated one-sentence description if changed>
...
```

## Overwrite, don't append

At Step 9 (write the file), overwrite the existing file entirely — do not append
sections. Preserve the same `<brief-name>.md` filename.

**Critical frontmatter rules for refresh:**
- Set the `date` field (not `refreshed`, not `last_updated` — the field name is `date`)
  to today's date in YYYY-MM-DD format.
- Re-evaluate `strategic_implication` from scratch based on the refreshed data.
- Keep all other frontmatter fields (`product`, `brief`, `competitors`) updated to
  reflect the refreshed content.
