# forge:product

Register a new product by creating its directory and writing an `AGENTS.md` navigation
guide. Works in Forge-initialized repositories and in plain directories (Claude Desktop
/ Cowork / any non-Forge environment).

---

## What It Does

`forge:product` detects whether it is running inside a Forge-initialized repository
(`.forge/` present) or a plain directory, then creates the product directory at the
appropriate location:

| Environment | Product directory |
|-------------|------------------|
| Forge mode | `.forge/products/<product-name>/` |
| Plain mode | `./<product-name>/` |

It writes an `AGENTS.md` navigation guide documenting the full PM artifact taxonomy and
stubs a `deployables.md` registry file. This is the entry point for all PM-facing
skills that need a product home, such as `forge:product-strategy`.

---

## Usage

### With argument

```
/forge:product rewards-checkout
```

### Without argument

```
/forge:product
```

Claude will prompt for the product name.

---

## Prerequisites

- **Forge mode**: a product with the same name must not already exist under `.forge/products/`
- **Plain mode**: no prerequisites — the skill can run in any directory without Forge
  initialization

---

## Related Skills

| Skill | When to use |
|-------|-------------|
| `forge:product-strategy` | Build a strategy document for this product |
| `forge:init` | Initialize the repository for Forge (Forge mode only) |
