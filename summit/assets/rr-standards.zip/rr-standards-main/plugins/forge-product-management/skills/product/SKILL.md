---
name: forge:product
description: Register a new product by creating its directory and writing an AGENTS.md navigation guide. Works in Forge-initialized repositories (.forge/ present) and in plain directories (Claude Desktop / Cowork / any non-Forge environment). Use when a PM wants to register a new product, says "create a product", "add a product", "initialize a product", "set up a product in forge", "register a new product", or "forge:product <name>". This is the entry point for all PM-facing Forge skills — run before forge:product-strategy or any other PM skill.
argument-hint: "[product-name]"
arguments: [product_name]
agent-type: orchestrator
---

# forge:product

Creates a new product directory at `<products_root>/<product-name>/`, writes an
`AGENTS.md` navigation guide documenting the full PM artifact taxonomy, and stubs a
`deployables.md` registry. This is the entry point for all PM-facing Forge skills —
run it before `forge:product-strategy` or any other PM skill.

Works in both Forge-initialized repositories and plain directories (Claude Desktop /
Cowork / any non-Forge environment).

---

## Step 0: Detect Environment

Load `plugins/forge-product-management/skills/common/environment.md` and follow its
instructions to set `env_mode` and `products_root`.

**Forge mode** (`env_mode = forge`): `.forge/` exists in the working directory.
- `products_root = .forge/products`

**Plain mode** (`env_mode = plain`): `.forge/` does not exist.
- `products_root = .`
- No Forge initialization is required. The skill can run in any directory.

---

## Step 1: Determine Product Name

If a product name was provided as an argument, use it directly.

Otherwise ask:
```
What is the product name?
```

Slugify the name (apply in order):
1. Lowercase all characters
2. Replace spaces and underscores with hyphens
3. Strip all characters that are not alphanumeric or hyphens (`[^a-z0-9-]`)
4. Collapse consecutive hyphens to one
5. Trim leading and trailing hyphens

If slugification produces an empty string, ask the PM to provide a valid name
(must contain at least one alphanumeric character).

Set `product_name` to the slug.

**Duplicate check:**

Check whether `<products_root>/<product_name>` already exists:

```bash
[ -d "<products_root>/<product_name>" ] && echo "exists" || echo "ok"
```

If exists, stop with:
> "A product named `<product_name>` already exists at `<products_root>/<product_name>/`. Run `forge:product-strategy` to work with it."

---

## Step 2: Create Product Directory and Stub Files

Do not run `mkdir -p`. Use the Write tool to create files — it creates parent
directories automatically. In plain mode the PM may not have a terminal.

Write `<products_root>/<product_name>/deployables.md`:

```markdown
# Deployables — <product_name>

Registry of the technical deployable units that collectively implement this product.
A deployable is an independently shippable unit (service, app, library, pipeline).
Update this table as deployables are added to or removed from the product's implementation.

| Deployable | Repository | Role | Capability path | Notes |
|------------|------------|------|-----------------|-------|
| | | | | |

<!-- Role examples: primary backend, iOS/Android client, web frontend, data pipeline, ML model -->
<!-- Capability path: .forge/deployables/<name>/capabilities/<capability>/ (use "(this repo)" for local deployables) -->
```

---

## Step 3: Write AGENTS.md

**3.1 — Resolve plugin root**

Read `plugins/forge-product-management/skills/common/plugin-root.md` and follow its
instructions to derive `plugin_root`.

**3.2 — Read the AGENTS.md template**

Read the file at `<plugin_root>/skills/product/references/agents-template.md`.

If the file cannot be found, print:
```
Warning: Could not resolve plugin root — writing AGENTS.md from built-in content.
```
and use the inline fallback below as the template content.

**3.3 — Substitute and write**

Replace every occurrence of `<product_name>` in the template with the actual product
slug. Write the result to `<products_root>/<product_name>/AGENTS.md`.

**Inline fallback content** (used only when the template file cannot be read):

````markdown
# <product_name> — Navigation Guide

This directory is the home for all product management artifacts for **<product_name>**.
Read this file before looking for or placing any artifact related to this product.

## Root-Level Files

| File | Purpose | Produced by | Lifecycle stage |
|------|---------|-------------|----------------|
| `AGENTS.md` | This file — directory navigation guide | `forge:product` | initialization |
| `vision.md` | Stable product identity: target users, key needs, unique value proposition, business goals | `forge:product-vision` | strategy |
| `strategy.md` | Rumelt diagnosis + Roger Martin guiding policy (pillars + exclusions) + coherent actions table | `forge:product-strategy` | strategy |
| `okrs.md` | Product-level OKRs cascaded from company OKRs; cross-referenced in `strategy.md` | `forge:product-strategy` | strategy |
| `metrics.md` | North Star / L1 / L2 metric hierarchy with measurement wiring | `forge:product-strategy` | strategy |
| `roadmap.md` | Outcome-based now/next/later or quarterly roadmap | `forge:product-roadmap` | strategy |
| `deployables.md` | Registry of the deployable units that collectively implement this product | `forge:product` (stub) | ongoing |

## Subdirectories

| Directory | Produced by | Contents |
|-----------|-------------|---------|
| `discovery/` | `forge:product-discover` | OST, assumption log, interview snapshots |
| `competitive/` | `forge:competitive-brief` | One file per competitor analysis brief |
| `research/` | `forge:product-synthesis` | Structured research synthesis documents |
| `research/raw/` | PM (manual) | Raw source artifacts committed for traceability |
| `metrics/scorecards/` | `forge:product-scorecard` | Dated scorecard snapshots (`YYYY-MM-DD.md`) |
| `briefs/` | `forge:product-brief` | One brief per coherent action ready for implementation |
| `outcomes/` | `forge:product-outcome` | Post-launch outcome reviews, keyed by effort ID and review date |
| `references/` | `forge:product-strategy` | Date-stamped raw inputs used during strategy sessions |
| `strategy-archive/` | `forge:product-strategy` | Archived strategy documents from pivot mode |
````

---

## Step 4: Print Summary

**Forge mode** (`env_mode = forge`):

```
Product created: <product_name>
Directory:       .forge/products/<product_name>/
Files written:   AGENTS.md, deployables.md

Next steps:
  Run `forge:product-strategy` to build a strategy for this product.
```

**Plain mode** (`env_mode = plain`):

```
Product created: <product_name>
Directory:       ./<product_name>/
Files written:   AGENTS.md, deployables.md

Next steps:
  Run `forge:product-strategy` to build a strategy for this product.
```
