# Product Strategy: Rewards App

## Coherent Actions

| Initiative | Strategic Pillar | Owner | Effort ID |
|-----------|-----------------|-------|-----------|
| Loyalty Tier Redesign | Member Retention | PM-Alice | — |
| Checkout Rewards Prompt | Conversion | PM-Bob | — |
| Points Balance Dashboard | Engagement | PM-Alice | — |
