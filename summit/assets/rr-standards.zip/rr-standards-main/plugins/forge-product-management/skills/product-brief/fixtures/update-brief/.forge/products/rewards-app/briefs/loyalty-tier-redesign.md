# Brief: Loyalty Tier Redesign

*Product: rewards-app*
*Created: 2026-01-15*
*Status: Draft*

---

## Problem Statement

Members cannot identify their tier status after checkout, leading to confusion.
Evidenced by 23% of tier-related support tickets.

---

## Target User

High-value members (Tier 3+) who want to track progress toward the next reward tier.

---

## Hypothesis

We believe surfacing tier progress post-checkout will result in a 10% increase in
repeat purchase rate because members with visible tier status buy again 2× more often.

---

## Success Criteria

- Repeat purchase rate increases by 10% within 30 days of launch
- Tier-related support tickets decrease by 20%

---

## Rough Scope

### Includes

Post-checkout confirmation screen with tier progress indicator.

### Excludes

Redesign of the main loyalty dashboard. Push notifications. Tier upgrade emails.

---

## Strategic Alignment

Loyalty Tier Redesign — Member Retention pillar

---

## Effort Link

*Back-filled after `forge:effort` runs. Will contain: effort ID, Jira ticket number,
and link to `.forge/efforts/<id>/`.*
