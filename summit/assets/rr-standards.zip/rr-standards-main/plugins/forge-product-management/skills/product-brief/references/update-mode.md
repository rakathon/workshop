# Update Mode — Editing an Existing Brief

Triggered when `BRIEF_FILE` already exists (detected in Step 3).

## Behaviour

When updating:
1. Read the existing brief file in full.
2. For each interview section (Steps 4–9), display the **current value** first:
   > "Current value: [existing content]"
   > "Press Enter to keep this, or type a replacement."
3. If the PM presses Enter (empty response), retain the existing value unchanged.
4. If the PM types a response, replace the section with the new value.
5. After collecting all sections, rewrite the entire brief file using the
   template in `references/brief-template.md`, preserving the original
   *Created* date and updating *Status* to `Draft` if it was previously
   something else (e.g., `Ready`).

## Sections that change on update

| Section | Behaviour |
|---------|-----------|
| Problem Statement | Re-interview; prompt for evidence if still missing |
| Target User | Re-interview |
| Hypothesis | Re-interview |
| Success Criteria | Re-interview; prompt for second metric if still only one |
| Rough Scope (Includes) | Re-interview |
| Rough Scope (Excludes) | Re-interview |
| Strategic Alignment | Re-present coherent actions list (or open question if strategy.md absent) |
| Effort Link | **Never overwrite** — this section is owned by `forge:effort` |

## Note on Effort Link

If the brief already has an Effort Link filled in by `forge:effort`, preserve it
exactly — do not replace it with the placeholder text.
