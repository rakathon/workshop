---
name: forge:product-brief
description: >
  Scopes a single initiative by interviewing the PM through the seven required brief
  sections and writing the result to <products_root>/<name>/briefs/<initiative-slug>.md.
  Acts as the gateway between product-level discovery and effort-level implementation —
  run after forge:product-strategy confirms a coherent action is ready to scope, and
  before forge:effort creates the Jira ticket and effort directory.
  Does NOT require an active Forge effort. Works in plain directories (Claude Desktop /
  Cowork) with no .forge/ present.
when_to_use: >
  Trigger on: "write a product brief", "scope this initiative", "create a brief",
  "let's brief this out", "I want to write a brief for", "turn this into a brief",
  "brief this coherent action", "forge:product-brief", "help me scope this feature",
  "I'm ready to scope an initiative", "prepare this for engineering", or any time a PM
  wants to formally scope a roadmap initiative before kicking off implementation.
argument-hint: "[product-name] [initiative-name]"
arguments: [product_name, initiative_name]
agent-type: worker
---

# forge:product-brief

Scopes a single initiative by interviewing the PM through the seven required brief
sections and writing `<products_root>/<name>/briefs/<initiative-slug>.md`. This skill
is the **sole owner** of files under `briefs/`. It does not create Jira tickets or
effort directories — those steps happen in `forge:effort`.

---

## Step 0 — Detect environment

Load `skills/common/environment.md` and follow the detection instructions exactly.

Set:
- `env_mode` = `forge` or `plain`
- `products_root` = `.forge/products` (forge mode) or `.` (plain mode)

Use `products_root` in every path reference below. Never hardcode `.forge/products/`.

---

## Step 1 — Identify the product

1. If a product name was supplied as an argument, use it. Otherwise:
   a. List all directories under `<products_root>/`.
   b. Ask: "Which product is this brief for?"
2. Set `PRODUCT_DIR` = `<products_root>/<name>/` (i.e. `product_dir` from environment.md).
3. If `PRODUCT_DIR` does not exist, stop and tell the PM:
   > "No product directory found for **<name>**. Run `forge:product <name>`
   > to register it first, then re-invoke this skill."

---

## Step 2 — Read strategy for coherent actions

1. Check whether `PRODUCT_DIR/strategy.md` exists.
   - **If absent:** warn the PM:
     > "I could not find `strategy.md` for **<name>**. I'll proceed with the brief,
     > but you'll need to manually fill in the Strategic Alignment section. Run
     > `forge:product-strategy` first to avoid this gap."
     Set `COHERENT_ACTIONS` = empty.
   - **If present:** read the full file. Extract the coherent actions table — all rows
     including Initiative name, Strategic pillar, owner, and effort ID (if any).
     Store as `COHERENT_ACTIONS`.

---

## Step 3 — Resolve the initiative slug

1. Ask the PM:
   > "What is the name of the initiative you want to scope? (e.g., 'Loyalty Tier
   > Redesign', 'Checkout Rewards Prompt')"
2. Derive `INITIATIVE_SLUG` from the response: lowercase, spaces replaced with
   hyphens, no special characters. For example: `loyalty-tier-redesign`.
3. Set `BRIEF_FILE` = `PRODUCT_DIR/briefs/<INITIATIVE_SLUG>.md`.
4. Check whether `BRIEF_FILE` already exists.
   - **If it does:** this is **update mode** — read the file and follow
     `references/update-mode.md` for how to pre-fill each section.
     Inform the PM:
     > "A brief for **<initiative-slug>** already exists. I'll walk through each
     > section with the current value shown. Press Enter to keep it, or type a
     > replacement."
   - **If it does not:** this is **create mode** — inform the PM:
     > "Starting a new brief for **<initiative-slug>**. I'll interview you through
     > each section one at a time."

---

## Step 4 — Interview: Problem Statement

Ask — one question, wait for a response before proceeding:

> **Problem Statement**
>
> What problem are we solving? Describe it in three parts:
> 1. What is the problem?
> 2. Who experiences it?
> 3. What evidence do we have that it is real? (data, research, support tickets, user
>    interviews — anything concrete)
>
> Example: "High-value members cannot easily identify their next reward tier, causing
> confusion after checkout. Evidenced by 23% of tier-related support tickets and a
> Q3 user research finding that 41% of members misidentify their tier status."

Store the response as `PROBLEM_STATEMENT`. If the response lacks evidence, prompt once:
> "Can you add any concrete evidence — a metric, research finding, or support signal?"

---

## Step 5 — Interview: Target User

Ask:

> **Target User**
>
> Who is the primary user segment this initiative serves?
> Describe them and their key job to be done — what are they trying to accomplish?
>
> Example: "High-value members (Tier 3+) who want to understand their progress toward
> the next reward tier so they can make informed purchase decisions."

Store as `TARGET_USER`.

---

## Step 6 — Interview: Hypothesis

Ask:

> **Hypothesis**
>
> Complete this sentence:
>
> "We believe that **[doing X]** will result in **[outcome Y]** because **[evidence or
> assumption Z]**."
>
> Example: "We believe that surfacing tier progress on the post-checkout confirmation
> screen will result in a 10% increase in repeat purchase rate within 30 days because
> our research shows members who know their tier status buy again 2× more often."

Store as `HYPOTHESIS`.

---

## Step 7 — Interview: Success Criteria

Ask:

> **Success Criteria**
>
> What 2–4 measurable outcomes would tell us this initiative succeeded? Focus on
> outcomes (behaviour changes, metric movements), not outputs (features shipped).
>
> Avoid: "We shipped the redesign" or "The feature is live."
> Aim for: "Repeat purchase rate increases by X%", "Tier-related support tickets
> decrease by Y%", "Member satisfaction score (CSAT) for tier clarity improves
> from Z to Z+N."

Store as `SUCCESS_CRITERIA`. If fewer than 2 criteria are provided, prompt once:
> "Can you add at least one more measurable outcome? What would 'success' look like
> in the data 60–90 days after launch?"

---

## Step 8 — Interview: Rough Scope

Ask in two parts. Wait for each response before asking the next.

**Part A — In scope:**
> **Rough Scope: Includes**
>
> What does this initiative include? Describe the capabilities, surfaces, or user
> flows that are in scope. One paragraph is fine — precision comes later in the PRD.

**Part B — Out of scope:**
> **Rough Scope: Excludes**
>
> What does this initiative explicitly NOT include? Name the things that might seem
> related but are deliberately deferred or out of bounds.

Store `SCOPE_IN` and `SCOPE_OUT` separately.

---

## Step 9 — Interview: Strategic Alignment

**When `COHERENT_ACTIONS` is non-empty** (strategy.md was present):

1. Present the list to the PM:
   > "Here are the coherent actions in your current strategy. Which one does this
   > initiative advance?"
   >
   > <list each action as a numbered item: "N. <Initiative name> — <Strategic pillar>">

2. Ask the PM to select one by number or name.
3. Store the selected entry verbatim as `STRATEGIC_ALIGNMENT` (include the initiative
   name, pillar, and any effort ID already in the table).

**When `COHERENT_ACTIONS` is empty** (strategy.md was absent or had no coherent actions):

Ask:
> **Strategic Alignment**
>
> Which strategic pillar or coherent action does this initiative advance? If you have
> a `strategy.md`, describe how this work connects to the overall direction.

Store as `STRATEGIC_ALIGNMENT`.

---

## Step 10 — Write the brief

1. Create the briefs directory if it does not exist:
   `PRODUCT_DIR/briefs/`

2. Write `BRIEF_FILE` using the template in `references/brief-template.md`.
   Substitute each stored variable. The header block **must** include these four
   metadata fields in this order:
   - `*Product: <product-name>*`
   - `*Created: <YYYY-MM-DD>*`
   - `*Status: Draft*`
   - `*Effort Link: Back-filled after forge:effort runs.*`

   Additional rules:
   - In **update mode**: preserve the original *Created* date. Never overwrite the
     Effort Link if it has already been filled in by `forge:effort`.
   - In **create mode**: use today's date; set Status to `Draft`; leave Effort Link
     as the placeholder.

3. Confirm to the PM:
   > "Brief written to `<BRIEF_FILE>`."

---

## Step 11 — Surface the graduate-to-PRD path

After confirming the write, deliver the message appropriate for the current `env_mode`:

**Forge mode** — deliver verbatim:

> **Next steps**
>
> This brief lives at product level and is not duplicated into any effort directory.
>
> When this brief is ready for implementation:
> 1. Run **`forge:effort`** to create the effort directory and Jira ticket. The effort
>    ID will be written back to the "Effort Link" section of this brief.
> 2. Run **`forge:prd`** inside that effort to write the three-file PRD
>    (`prd.md`, `business.md`, `user-stories.md`) from this brief.
> 3. Hand off to engineering — they run **`forge:elaborate`** to deepen requirements
>    and produce technical specifications.
>
> To update this brief, invoke `forge:product-brief` again with the same initiative
> name and I'll walk through each section with your current values pre-filled.

**Plain mode** — deliver verbatim:

> **Next steps**
>
> This brief lives in `<PRODUCT_DIR>/briefs/` and is ready for the next stage.
>
> When this brief is ready for implementation:
> 1. Run **`forge:prd`** to write the three-file PRD (`prd.md`, `business.md`,
>    `user-stories.md`) from this brief. The effort setup step (`forge:effort`) is
>    not required in a plain directory — you can go directly to `forge:prd`.
> 2. Hand off to engineering — they run **`forge:elaborate`** to deepen requirements
>    and produce technical specifications.
>
> To update this brief, invoke `forge:product-brief` again with the same initiative
> name and I'll walk through each section with your current values pre-filled.
