# Brief File Template

Use this template when writing a new brief or rewriting an updated one.
Substitute each `<VARIABLE>` with the value collected during the interview.
Leave the Effort Link section with its placeholder text — it is back-filled
after `forge:effort` runs.

```markdown
# Brief: <Initiative Name>

*Product: <product-name>*
*Created: <YYYY-MM-DD>*
*Status: Draft*

---

## Problem Statement

<PROBLEM_STATEMENT>

---

## Target User

<TARGET_USER>

---

## Hypothesis

<HYPOTHESIS>

---

## Success Criteria

<SUCCESS_CRITERIA>

---

## Rough Scope

### Includes

<SCOPE_IN>

### Excludes

<SCOPE_OUT>

---

## Strategic Alignment

<STRATEGIC_ALIGNMENT>

---

## Effort Link

*Back-filled after `forge:effort` runs (Forge mode) or left blank in plain mode.
In Forge mode will contain: effort ID, Jira ticket number, and link to the effort directory.*
```
