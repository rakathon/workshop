# forge:product-brief

Scope a single initiative by interviewing the PM through seven required sections and
writing the result to `<products_root>/<name>/briefs/<initiative-slug>.md`. This is
the gateway between product-level strategy and effort-level implementation — run it
after `forge:product-strategy` has confirmed a coherent action is ready to scope, and
before `forge:effort` creates the Jira ticket and effort directory.

Works in both **Forge mode** (a repository with `.forge/`) and **plain mode**
(any directory — Claude Desktop / Cowork, no git, no `.forge/`).

---

## Usage

```
forge:product-brief
forge:product-brief <product-name>
forge:product-brief <product-name> <initiative-name>
```

If arguments are omitted, Claude will prompt for the product and initiative name
interactively.

---

## When to use

- Scoping a coherent action from your product strategy before kicking off implementation
- Writing a formal brief for an initiative to hand off to engineering
- Updating an existing brief — the skill re-opens each section with current values pre-filled
- Any time a PM says "write a product brief", "scope this initiative", "create a brief",
  "brief this coherent action", "help me scope this feature", or "prepare this for engineering"

---

## Prerequisites

- A product directory created by `forge:product` (`<products_root>/<name>/` must exist).
  In **Forge mode** this is `.forge/products/<name>/`; in **plain mode** it is `./<name>/`.
  No Forge initialization (`.forge/`) is required — the skill runs in any directory.
- A strategy document at `<products_root>/<name>/strategy.md` is strongly recommended —
  the skill proceeds without it but cannot auto-populate the Strategic Alignment section

---

## Output artifact

| Mode | File | Purpose |
|------|------|---------|
| Forge | `.forge/products/<name>/briefs/<initiative-slug>.md` | The scoped brief, including all seven sections and a placeholder Effort Link back-filled after `forge:effort` runs |
| Plain | `./<name>/briefs/<initiative-slug>.md` | Same content; Effort Link section is left blank (no effort tracking in plain mode) |

`forge:product-brief` is the **sole owner** of files under `briefs/`. It does not
create Jira tickets or effort directories — those steps happen in `forge:effort`.

---

## Interview sections

The skill walks through seven sections, one at a time, waiting for a response before
proceeding:

| # | Section | What it captures |
|---|---------|-----------------|
| 1 | **Problem Statement** | The problem, who experiences it, and concrete evidence (data, research, support signals) |
| 2 | **Target User** | Primary user segment and their key job to be done |
| 3 | **Hypothesis** | A structured "We believe X will result in Y because Z" statement |
| 4 | **Success Criteria** | 2–4 measurable outcome-based metrics that define success |
| 5 | **Rough Scope: Includes** | Capabilities, surfaces, or user flows that are in scope |
| 6 | **Rough Scope: Excludes** | Things that are deliberately deferred or out of bounds |
| 7 | **Strategic Alignment** | Which coherent action or strategic pillar this initiative advances — auto-populated from `strategy.md` if available |

The skill prompts once for stronger evidence if the Problem Statement lacks it, and
once for an additional metric if fewer than two Success Criteria are provided.

---

## Relationship to other skills

| Skill | Relationship |
|-------|-------------|
| `forge:product` | Creates the product directory — must be run before this skill |
| `forge:product-strategy` | Produces the coherent actions this skill scopes; run before `forge:product-brief` to auto-populate Strategic Alignment |
| `forge:effort` | Run after this skill in **Forge mode** — creates the Jira ticket and effort directory; its effort ID is written back to the brief's Effort Link section. **Skipped in plain mode** — go directly to `forge:prd` |
| `forge:prd` | Run inside the effort (after `forge:effort`) to produce the three-file PRD (`prd.md`, `business.md`, `user-stories.md`) from this brief |
| `forge:elaborate` | Run by engineering inside the effort to deepen requirements and produce technical specifications |
