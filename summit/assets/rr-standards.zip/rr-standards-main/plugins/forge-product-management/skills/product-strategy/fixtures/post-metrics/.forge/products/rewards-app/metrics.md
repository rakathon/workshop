# Metric Hierarchy: Rewards App

*Last updated: 2026-05-28*
*Strategy version: 2026-05-28*

## North Star

| Metric | Definition | Data source | Cadence | Baseline | Healthy range |
|---|---|---|---|---|---|
| 90-day retention rate | % of members still active 90 days after first redemption | Annalise: member_retention table | Weekly | 34% | 48%–60% |

## L1 Inputs

| Metric | Drives | Definition | Data source | Cadence | Baseline | Healthy range |
|---|---|---|---|---|---|---|
| % new members redeeming within 14 days | North Star | % of members acquired in last 30 days who completed a redemption within 14 days of signup | Annalise: redemption_events table | Weekly | 22% | 35%–45% |
| Average days-to-first-redemption | North Star | Median days from signup to first completed redemption | Annalise: redemption_events table | Weekly | 18 days | 7–12 days |
| 90-day retention for ARPU>$6 cohort | North Star | 90-day retention rate for members with average monthly spend >$6 | Annalise: member_retention + spend tables | Monthly | 34% | 48%–60% |

## L2 Diagnostics

| Metric | Explains | Definition | Data source | Cadence | Baseline | Healthy range |
|---|---|---|---|---|---|---|
| Onboarding step completion rate | % new members redeeming within 14 days | % of new members completing each onboarding step | Annalise: onboarding_funnel table | Weekly | 61% | 75%–90% |
| Day-3 notification open rate | % new members redeeming within 14 days | % of push/email nudges opened by day-3 members | Annalise: notification_events table | Weekly | 18% | 30%–45% |
| Offer relevance score | % new members redeeming within 14 days | Self-reported relevance (1–5) at point of redemption | Annalise: redemption_feedback table | Weekly | 3.1 | 4.0–4.8 |
