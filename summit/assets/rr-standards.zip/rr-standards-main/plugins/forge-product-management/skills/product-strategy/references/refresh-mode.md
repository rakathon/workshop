# Refresh Mode Procedure

Activated when `mode = refresh`. Executes instead of Steps 3–9 of the main flow.

**R1 — Re-run research**

Repeat the research dispatch from Step 3.1 using the current date. Write new
research files with today's date in the filename — do not overwrite prior research files.

**R2 — Diff against existing strategy**

Compare new research signals against the evidence recorded in the existing `strategy.md` diagnosis.
Identify:
- Changed internal metrics (churn, ARPU, retention trend)
- Changed competitor positions
- New market data points that contradict or support the existing diagnosis

**R3 — Present targeted diff**

For each section that needs updating, present the current text and proposed change:
> "**Diagnosis** — the evidence has changed:
> Current: [current diagnosis text]
> Suggested update: [updated text based on new research]
> Confirm this change? (yes / no / edit)"

Do not write any changes until PM confirms each one.

**R4 — Update in-place**

After all confirmed changes, update `strategy.md` in-place. Update the `last_refreshed`
date in the header. Update `roadmap.md` if any coherent actions changed.
