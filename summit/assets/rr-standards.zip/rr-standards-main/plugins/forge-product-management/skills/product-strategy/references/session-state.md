# Session State — forge:product-strategy

Specification for `strategy-session.md` — the pause record that persists session
state across context resets and session boundaries.

The file lives at `<product_dir>/strategy-session.md` (where `product_dir` is set by Step 0 environment detection).
It is created when a session is in progress and updated at every step.
It is deleted when the strategy session completes (all artifacts written and confirmed).

Compatible with the `forge:resume` session-start hook — the hook reads this file
and surfaces it to the PM at the start of a new session.

---

## Required YAML Frontmatter

```yaml
---
product: <product-name>              # matches the directory name under products_root
stage: <stage-slug>                  # see Stage Slugs below
mode: create | refresh | pivot       # which mode the session is in
paused_at: <ISO-8601 timestamp>      # when the session was paused
awaiting: <free text>                # what is needed to resume; "nothing" if PM-initiated pause
generated_references:                # research files already written to references/
  - competitor-analysis-<YYYY-MM-DD>.md
  - market-research-<YYYY-MM-DD>.md
outstanding_references:              # research files expected but not yet available
  - <description of what is needed>
---
```

### Stage Slugs

| Slug | Meaning |
|------|---------|
| `init` | Session started; product identified; OKRs not yet received |
| `diagnosis` | Building the diagnosis (DIBB framing in progress) |
| `diagnosis-quality-gate` | Diagnosis proposed; blocked on quality gate (specificity/evidence/singularity) |
| `guiding-policy` | Diagnosis approved; building strategic pillars |
| `exclusions` | Pillars confirmed; capturing strategic exclusions |
| `coherent-actions` | Exclusions captured; building coherent actions table |
| `okr-cascade` | Coherent actions confirmed; deriving product-level OKRs |
| `metrics` | OKRs written; building metric hierarchy (North Star, L1s, L2s) |
| `roadmap` | Metrics written; handing off to forge:product-roadmap |
| `effort-scaffolding` | Roadmap confirmed; offering to create Forge efforts |
| `complete` | All artifacts written; session done (file should be deleted) |

---

## Body Structure

After the frontmatter, the body is free-form Markdown. It should contain:

1. **Partial work** — any content that has been confirmed by the PM but not yet
   written to the final artifact. For example, if the diagnosis has been confirmed
   but `strategy.md` has not been written yet, record the confirmed diagnosis text here.
2. **Open questions** — any unresolved questions the PM was working through when
   paused.
3. **Research context** — brief summary of what the research has shown so far, so
   the next session can resume informed.

---

## Examples

### Example 1: Blocked on competitor research

```yaml
---
product: rewards-app
stage: diagnosis
mode: create
paused_at: 2026-05-26T14:30:00Z
awaiting: Competitor pricing analysis for loyalty SaaS competitors (top 5 by market share). Can be web-researched or provided by PM.
generated_references:
  - market-research-2026-05-26.md
outstanding_references:
  - competitor-analysis: pricing tiers and feature comparison for Top Rewards, LoyaltyLion, Yotpo, Smile.io, Antavo
---

## Partial Work

**Data confirmed:** MAU retention at 60-day mark is 34% vs industry benchmark of 52%.
**Observations confirmed:** Users who redeem within the first 30 days show 2.4× higher 90-day retention.
**Beliefs confirmed:** The critical barrier is time-to-first-redemption, not product complexity.

**Bet (draft — not yet quality-gate approved):** The primary barrier to growth is that
new users take >14 days to reach their first reward redemption, destroying the retention
flywheel before it can establish itself.

## Open Questions

- Does competitor analysis support the time-to-redemption framing, or will it reveal
  a different market positioning gap?
- PM needs to confirm: is this SaaS B2B or B2C? (affects PLG/MOAT lens applicability)
```

---

### Example 2: PM-initiated pause (no blocker)

```yaml
---
product: checkout-flow
stage: guiding-policy
mode: refresh
paused_at: 2026-05-26T16:00:00Z
awaiting: nothing
generated_references:
  - competitor-analysis-2026-05-26.md
  - data-analysis-conversion-rate-2026-05-26.md
outstanding_references: []
---

## Partial Work

**Diagnosis (confirmed):** checkout abandonment rate of 41% is driven by friction at
the payment method selection step, where users with non-standard payment methods (BNPL,
crypto, regional wallets) have a 78% drop-off rate vs 12% for credit card users.

**Pillar 1 (confirmed):** Expand payment method coverage to achieve parity with regional
market leaders. OKR-2026-1. Success: <5% drop-off rate variance across payment methods.

**Pillar 2 (draft — not confirmed):** Streamline the checkout flow to reduce steps from
6 to 3 for returning users.

## Open Questions

- PM wants to confirm Pillar 2 text with the design lead before proceeding.
- Strategic exclusion to discuss: cryptocurrency payments — in scope or not?
```

---

### Example 3: Blocked on data lake availability

```yaml
---
product: enterprise-analytics
stage: diagnosis
mode: create
paused_at: 2026-05-26T10:15:00Z
awaiting: Annalise and Snowflake MCP tools need to be enabled in the Claude Code session. Re-invoke forge:product-strategy once connected to get churn rate, ARPU, and NDR for the enterprise segment (last 4 quarters).
generated_references: []
outstanding_references:
  - internal-metrics: enterprise segment churn rate, ARPU, NDR (Q3 2025 – Q2 2026)
---

## Partial Work

No internal metrics available yet. Web research completed:
- Enterprise analytics market growing at 13% CAGR
- Top competitors: Tableau, Looker, Power BI
- Differentiator gap identified: self-serve data modeling (currently an engineering bottleneck)

## Open Questions

- Are internal metrics confirming the self-serve bottleneck hypothesis, or is churn driven
  by something else (pricing, integrations, performance)?
```
