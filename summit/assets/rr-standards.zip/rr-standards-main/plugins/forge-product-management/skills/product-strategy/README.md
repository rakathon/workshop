# forge:product-strategy

Guides a product manager through producing a structured product strategy document
using an opinionated methodology (Rumelt's strategy kernel + Roger Martin + Spotify
DIBB + North Star + Bungay strategic gap model). Handles create, refresh, and pivot
modes. Performs autonomous market and competitor research, queries internal data via
Annalise/Snowflake when available, enforces a quality gate on the diagnosis, cascades
OKRs, builds a metric hierarchy, and scaffolds Forge efforts for each coherent action.
Roadmap creation is delegated to `forge:product-roadmap`.

## Usage

```
forge:product-strategy
forge:product-strategy <product-name>
```

Accepts optional external inputs at invocation time:
- A file path to an existing roadmap, board deck, or prior strategy document
- A Confluence URL
- Pasted content

## When to use

- Starting a brand-new product strategy from scratch
- Doing a quarterly strategy refresh — re-running research and updating what has changed
- Pivoting because market conditions or prior strategy have materially changed
- Any time a PM says "I need to build a product strategy", "let's do strategy", "help me think through our strategy", or "forge:product-strategy"

## Prerequisites

- A product directory registered by `forge:product <product-name>` — required in both Forge and plain modes
- Company OKRs available (file, URL, or ready to paste) — optional, degrades gracefully if absent
- Annalise and/or Snowflake MCP tools connected for established products (optional — degrades gracefully if absent)

This skill works in **Forge mode** (repository with `.forge/`) and **plain mode**
(Claude Desktop / Cowork — no git, no `.forge/`). In plain mode, artifacts are written
under `./<product-name>/` in the current working directory instead of `.forge/products/<product-name>/`.
The `forge:product <product-name>` prerequisite still applies — it creates the product
directory before this skill is invoked.

## Output artifacts

All artifacts are written under `<product_dir>/` (`.forge/products/<product-name>/` in Forge mode, `./<product-name>/` in plain mode):

| File | Purpose |
|------|---------|
| `strategy.md` | Main strategy document: Diagnosis, Guiding Policy, Strategic Exclusions, Coherent Actions, History |
| `okrs.md` | Product-level OKRs cascaded from company OKRs |
| `metrics.md` | Metric hierarchy: North Star, primary, secondary, and guardrail metrics |
| `strategy-session.md` | Pause record — present when a session is in progress or paused; deleted on completion |
| `references/` | All research artifacts generated during the session |
| `strategy-archive/` | Archived prior strategies from pivot mode |

## Relationship to other skills

| Skill | Relationship |
|-------|-------------|
| `forge:product-roadmap` | product-strategy hands off to forge:product-roadmap for roadmap creation; product-strategy does not write roadmap.md itself |
| `forge:elaborate` | elaborate works *within* an effort; product-strategy works *above* efforts, at the product level |
| `forge:effort` | product-strategy invokes forge:effort to scaffold each coherent action after strategy is confirmed |
| `forge:pause` | product-strategy uses the same pause/resume pattern; strategy-session.md is compatible with the forge:resume hook |
| `forge:classify` | not invoked by this skill — strategy-level work does not have R1–R4 risk classification |
