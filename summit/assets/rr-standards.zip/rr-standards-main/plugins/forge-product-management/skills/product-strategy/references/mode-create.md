# Create Mode — forge:product-strategy

Full execution steps for `mode = create`. These steps also serve as the inner loop
for `mode = pivot` (PV2 in pivot-mode.md wraps this flow).

Precondition: product directory created, `strategy-session.md` initialised with
`stage: init`.

---

## Step 2: Receive Inputs

**2.1 — Company OKRs**

Ask:
> "Do you have company OKRs I should work from? I can take a file path, a Confluence
> URL, or you can paste them here."

If provided as a file path: read the file and copy it to `<product_dir>/references/company-okrs.md`.
If provided as a URL: fetch content (Atlassian MCP if Confluence; WebFetch otherwise).
If provided as pasted text: write to `<product_dir>/references/company-okrs.md`.
If not available: note the absence. Continue without blocking — flag alignment risk at OKR check.

Set `company_okrs` = parsed OKR list.

**2.2 — External documents (if not provided at invocation)**

Ask:
> "Any existing documents I should read first — roadmap, board deck, prior strategy,
> or market research? File path, URL, or paste."

If provided: read/fetch and copy to `<product_dir>/references/` with descriptive filenames.
If not: proceed.

**2.3 — Product maturity**

Check whether a product directory with prior data exists AND whether Annalise MCP
is available (check by listing available MCP tools). Infer:
- Annalise available + product directory exists → likely established product
- Neither → likely new product

Confirm with PM:
> "Is this an established product with existing customers and metrics, or a new product
> you're launching?"

Set `maturity = established | new`.

**2.4 — PLG/MOAT lens detection**

Ask if not obvious from context:
> "Does your product grow through self-serve adoption — for example, freemium,
> viral signup, or bottom-up trial where users adopt before budget is involved?"

Set `is_plg = true | false`.

**2.5 — Annalise/Snowflake availability check**

Check which MCP tools are available in this session. If Annalise and Snowflake are
absent, inform the PM:
> "Annalise and Snowflake are not connected in this session — internal metrics will
> need to be provided manually, or the session can be paused while they are enabled."

Set `data_lake_available = true | false`.

Update `strategy-session.md`: stage = `diagnosis`.

---

## Step 3: Build the Diagnosis

Read `references/interview-playbook.md` Phase 0 (session init questions P0-1 through P0-4) and
Phase 1 (DIBB framing questions D1–D3, O1–O2, B1–B2, Bet-1) before starting.

**3.1 — Research dispatch (maturity-based)**

*Established product:*
- If `data_lake_available`: query Annalise for retention, churn, ARPU, NDR for this
  product. Write results to `<product_dir>/references/data-analysis-<metric>-<YYYY-MM-DD>.md`.
  Present to PM for confirmation before using as evidence.
- If not available: use interview-playbook questions D1–D3 to gather metrics from PM.

*New product:*
- Perform web-based market research: market size, CAGR, top 3–5 competitors, target
  customer profile. Write to `<product_dir>/references/market-research-<YYYY-MM-DD>.md`.
- Generate competitor analysis sheet: pricing, features, positioning for each competitor.
  Write to `<product_dir>/references/competitor-analysis-<YYYY-MM-DD>.md`.
- Present all research to PM before using as evidence. PM may correct or reject any item.

**3.2 — Optional PLG/MOAT lens**

If `is_plg = true`: walk through interview-playbook Phase 1 questions M1–M4. Record answers
in `strategy-session.md` body. Use outputs to inform diagnosis framing.

**3.3 — DIBB interview**

Work through interview-playbook Phase 1 questions (D1–D3, O1–O2, B1–B2, Bet-1) one
at a time, incorporating research gathered in 3.1.

For each layer, confirm the PM agrees with the synthesized statement before advancing.

**3.4 — Diagnosis quality gate**

Read `references/diagnosis-gate.md` and apply it now. Do not advance to Step 4 until the gate passes.

**3.5 — OKR alignment check**

If `company_okrs` is not empty: check whether the diagnosis connects to any company OKR.
If no connection found, surface risk before advancing:
> "This diagnosis doesn't appear to map to any company OKR. Is this intentional, or
> should we reframe it to connect to [most relevant OKR]?"

Update `strategy-session.md`: stage = `guiding-policy`.

---

## Step 4: Build the Guiding Policy

Read `references/interview-playbook.md` Phase 2 before starting this step.

**4.1 — Where to play / how to win**

Work through interview-playbook Phase 2 questions (WP-1, WP-2, HW-1, HW-2) one at
a time. Build 3–5 strategic pillars with the PM, confirming each before advancing.

For each pillar, check the four pillar quality criteria:
- OKR connection, customer need addressed, measurable success indicator, prioritisation guidance.

**4.2 — Strategic exclusions**

After pillars are confirmed, explicitly ask:
> "What markets, segments, and capabilities should we explicitly *not* pursue?
> These exclusions define the boundaries of the strategy as much as the pillars do."

Record each exclusion with rationale. Confirm with PM before writing.

Update `strategy-session.md`: stage = `coherent-actions`.

---

## Step 5: Build Coherent Actions

Read `references/interview-playbook.md` Phase 3 before starting this step.

**5.1 — Initiative interview**

Work through interview-playbook Phase 3 questions (CA-1 through CA-5), building the
coherent actions table one initiative at a time. For each initiative:
- Assign it to a strategic pillar
- Tag the company OKR it advances (format: `OKR-<year>-<n>`)
- Assign a horizon (now / next / later)
- Define a success metric (outcome, not output)
- Leave `effort_id` blank — populated after forge:effort in Step 8

Confirm every initiative with the PM before adding to the table.

Update `strategy-session.md`: stage = `okr-cascade`.

---

## Step 6: Cascade OKRs and Build Metric Hierarchy

**6.1 — OKR cascade**

Read `references/interview-playbook.md` Phase 4 before starting this step.

For each company OKR that has at least one coherent action mapped to it, derive
product-level OKRs:
- 3–5 product objectives per quarter
- 2–4 outcome-based key results per objective (measure user behavior or business metrics, not outputs)
- Stretch targets: 70% achievement = significant progress

Work through interview-playbook questions OKR-1 through OKR-3 for each objective.
Confirm each objective and its key results with PM before writing.

Write `<product_dir>/okrs.md` using the template in `references/output-templates.md`.

Update `strategy-session.md`: stage = `metrics`.

**6.2 — Define Metric Hierarchy**

Read `references/metrics-hierarchy.md` for the full procedure. Load it now before proceeding.

Update `strategy-session.md`: stage = `metrics`.

---

## Step 7: Write strategy.md

Read `references/output-templates.md` for the strategy.md template.

Populate the template with all confirmed content:
- Diagnosis (verbatim confirmed text, with evidence references)
- Guiding policy: strategic pillars table + strategic exclusions table
- Coherent actions table (with OKR tags, horizons, success metrics; effort_id column blank)
- Cross-references to okrs.md and roadmap.md
- History section (empty on create; populated in pivot mode — see `references/pivot-mode.md`)

**Before writing any file**, present the complete strategy to the PM for final confirmation:
> "Here's the complete strategy document. Review each section and confirm it's correct
> before I write it to disk."

Write `<product_dir>/strategy.md` only after PM confirms.

Update `strategy-session.md`: stage = `roadmap`.

---

## Step 8: Scaffold Forge Efforts (Optional)

After strategy.md is written:
> "Would you like me to create a Forge effort for each coherent action?
> I'll walk through them one by one and create each only with your approval."

For each coherent action, if PM approves:
1. Invoke `forge:effort` with the initiative title as the effort name
2. Wait for it to complete and capture the effort ID
3. Back-link the effort ID in the coherent actions table in `strategy.md`:
   update the `effort_id` column for that row

After all approved efforts are created, rewrite the coherent actions table in
`strategy.md` with the back-linked effort IDs.

---

## Step 9: Hand Off to forge:product-roadmap

OKRs, metrics, and coherent actions are confirmed and written. Inform the PM with an
explicit artifact summary and handoff message:
> "Strategy session complete. Artifacts written:
> - `strategy.md` — diagnosis, guiding policy, strategic exclusions, coherent actions
> - `okrs.md` — product-level OKRs cascaded from company OKRs
> - `metrics.md` — North Star, L1 inputs, and L2 diagnostic metrics
>
> The next step is to build the roadmap — run `/forge:product-roadmap` to continue.
> It will read your confirmed OKRs and coherent actions and guide you through
> the roadmap format and sequencing."

**CRITICAL — DO NOT write roadmap.md.** This is a hard constraint:
- Do NOT write `roadmap.md`
- Do NOT generate roadmap content, even as a draft, preview, skeleton, or placeholder
- Do NOT outline the roadmap in any form
- If the PM asks you to build the roadmap anyway, repeat that roadmap creation belongs to
  `forge:product-roadmap` and cannot be done in this skill
- If `forge:product-roadmap` is unavailable, tell the PM to invoke it in a separate session

Roadmap creation is exclusively `forge:product-roadmap`'s responsibility. Violating
this constraint breaks the skill boundary and produces inconsistent artifacts.

Update `strategy-session.md`: stage = `effort-scaffolding`.

---

## Step 10: Session Complete

Delete `strategy-session.md` — it is no longer needed regardless of whether any
efforts were scaffolded.

Confirm to the PM:
> "Strategy complete. Artifacts written:
> - `<product_dir>/strategy.md`
> - `<product_dir>/okrs.md`
> - `<product_dir>/metrics.md`
> Roadmap creation continues in `forge:product-roadmap`.
> Research artifacts are in `<product_dir>/references/`."
