# Resume Procedure

Activated when an existing `strategy-session.md` is found and the PM chooses to resume.

Resume from `strategy-session.md`. Read the frontmatter and body.

Map `stage` to the correct step and sub-step:

| Stage | Resume at |
|-------|-----------|
| `init` | Step 1.3 (mode detection) |
| `diagnosis` | Step 3.3 (DIBB interview — restore partial work from body) |
| `diagnosis-quality-gate` | Step 3.4 (quality gate — use partial diagnosis from body) |
| `guiding-policy` | Step 4.1 |
| `exclusions` | Step 4.2 |
| `coherent-actions` | Step 5.1 |
| `okr-cascade` | Step 6.1 |
| `metrics` | Step 6.2 (read metrics-hierarchy.md; restore partial metrics work from body) |
| `roadmap` | Step 9 (hand off to forge:product-roadmap) |
| `effort-scaffolding` | Step 8 |

If `awaiting` is not "nothing":
> "To resume, I need: <awaiting>. Do you have that ready now, or would you like to
> continue without it? (provide it / continue without / pause again)"

If new research is provided:
- Accept it as a file path, URL, or pasted content
- Copy to `<product_dir>/references/` with appropriate filename
- Incorporate into the diagnosis research context

Restore partial work from the `strategy-session.md` body: pre-populate any
confirmed content from prior session so the PM does not repeat confirmed answers.

No strategy artifacts are written without PM confirmation, even when resuming.
