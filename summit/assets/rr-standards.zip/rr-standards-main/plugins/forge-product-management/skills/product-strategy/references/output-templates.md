# Output Templates — forge:product-strategy

Templates for all three persistent artifacts written by the skill.
Use these verbatim as the structural skeleton; populate each section with
confirmed PM-approved content before writing to disk.

---

## strategy.md

```markdown
# Product Strategy: <Product Name>

*Created: <YYYY-MM-DD>*
*Last refreshed: <YYYY-MM-DD>* <!-- update in refresh mode; omit on first create -->
*Mode: create | refresh | pivot*

---

## Diagnosis

<!-- Rumelt: one specific, evidence-backed problem statement. Not a goal. Not a list. -->
<!-- DIBB framing: Data → Observations → Beliefs → Bet -->

**Data:** <quantitative signal — internal metric or external benchmark>

**Observations:** <patterns and anomalies derived from the data>

**Beliefs:** <causal hypothesis — why this is the critical challenge>

**Bet:** <the diagnosis — a confident, falsifiable statement of the single barrier>

*Evidence:* <reference to supporting research artifact(s) in references/>

---

## Guiding Policy

<!-- Roger Martin: where to play and how to win -->
<!-- 3–5 North Star pillars; each must connect to a company OKR, address a customer need,
     have a measurable success indicator, and provide prioritisation guidance -->

### Strategic Pillars

| # | Pillar | Where We Play | How We Win | OKR | Success Indicator |
|---|--------|---------------|-----------|-----|-------------------|
| 1 | <Pillar name> | <market/segment/channel> | <competitive advantage> | OKR-<year>-<n> | <metric> |
| 2 | ... | | | | |

### Strategic Exclusions

<!-- Roger Martin: clarity requires defining what the product will NOT do -->
<!-- Record markets, segments, and capabilities explicitly out of scope -->

| Exclusion | Rationale |
|-----------|-----------|
| <market/segment/capability> | <why out of scope> |

---

## Coherent Actions

<!-- Bungay: initiatives that collectively close the knowledge, alignment, and effect gaps -->
<!-- Each initiative must reinforce the others -->

| Initiative | Strategic Pillar | Owner | Horizon | Success Metric | Company OKR | Effort ID |
|------------|-----------------|-------|---------|----------------|-------------|-----------|
| <title> | <pillar name> | <team/person> | now / next / later | <measurable outcome> | OKR-<year>-<n> | <!-- back-filled by forge:effort --> |

---

## OKRs

*See [okrs.md](okrs.md) for full product-level OKRs cascaded from company OKRs.*

---

## Roadmap

*See [roadmap.md](roadmap.md) for the outcome-based roadmap.*

---

## History

<!-- Populated in pivot mode; absent on first create -->
<!-- Links to strategy-archive/ entries -->

| Version | Date | Notes |
|---------|------|-------|
| <!-- [strategy-<date>.md](strategy-archive/strategy-<date>.md) --> | | |
```

---

## okrs.md

```markdown
# Product OKRs: <Product Name>

*Quarter: Q<N> <YYYY>*
*Cascaded from: [Company OKRs](<path or URL provided by PM>)*
*Linked from: [strategy.md](strategy.md)*

---

<!-- Structural constraints (from methodology):
     - 3–5 objectives per quarter
     - 2–4 key results per objective
     - Key results measure outcomes (user behavior, business metrics), never outputs
     - Stretch targets: 70% achievement = significant progress
     - Each objective is directly traceable to one company OKR -->

## Objective 1: <Outcome-framed objective title>

*Cascades from: OKR-<year>-<n> — <company OKR title>*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| <outcome metric> | <current> | <target> | <stretch> |
| ... | | | |

---

## Objective 2: ...
```

---

## roadmap.md

**Note: roadmap.md is NOT written by forge:product-strategy.** Roadmap creation
is exclusively handled by `forge:product-roadmap`. This template is provided here
for reference only — to show what the roadmap will look like after handoff.

```markdown
# Product Roadmap: <Product Name>

*Format: now/next/later | Q<N>–Q<N+2> <YYYY>*  <!-- PM chooses at session time -->
*Linked from: [strategy.md](strategy.md)*

---

<!-- Each cell: coherent action + OKR it advances + success metric that defines done -->
<!-- This is a communication artifact, not a delivery commitment -->

## Now / Q<N>

| Initiative | OKR | Success Metric |
|------------|-----|----------------|
| <coherent action title> | OKR-<year>-<n> | <measurable outcome> |

## Next / Q<N+1>

| Initiative | OKR | Success Metric |
|------------|-----|----------------|

## Later / Q<N+2>+

| Initiative | OKR | Success Metric |
|------------|-----|----------------|
```
