# Retention Analysis — Rewards App

*Generated: 2026-01-15*
*Source: Annalise MCP*

| Metric | Value | Industry Benchmark |
|--------|-------|-------------------|
| 30-day retention | 58% | 62% |
| 90-day retention | 34% | 52% |
| ARPU | $4.20/month | $6.10/month |
| NDR | 88% | 105% |

Key finding: users who redeem within first 30 days show 2.4× higher 90-day retention.
