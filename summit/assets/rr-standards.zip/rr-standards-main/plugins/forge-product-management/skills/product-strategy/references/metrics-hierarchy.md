# Metric Hierarchy — forge:product-strategy

Full procedure for Step 6.2: deriving and writing the metric hierarchy after
OKRs are confirmed.

---

## 6.2.0 — Check for existing `metrics.md`

If `metrics.md` exists (refresh or pivot mode):
- Read it and present a summary to the PM.
- In **refresh mode**: proceed to 6.2.4 (update targets and L2s only; do not re-derive
  North Star or L1s unless PM requests it).
- In **pivot mode**: ask the pivot decision question before proceeding:
  > "`metrics.md` currently defines **[North Star metric]** as your North Star. Does
  > this pivot change what you're fundamentally measuring — the core value you're trying
  > to maximise for customers?"
  >
  > - **No** → keep the North Star and L1s; update L2s and targets at Steps 6.2.3–6.2.4
  > - **Yes** → archive `metrics.md` to `strategy-archive/metrics-<YYYY-MM-DD>.md`
  >   alongside strategy.md; run the full branch from 6.2.1

  The PM must actively answer this question. Do not infer the answer from the strategy
  pivot content.

If `metrics.md` does not exist: proceed to 6.2.1.

---

## 6.2.1 — Derive North Star candidate from OKRs

Read the confirmed `okrs.md`. Identify the key result that:
- Measures direct customer value delivery (not revenue, not output)
- Is the single metric that, if it moved in the right direction, would indicate the
  product is succeeding for customers

Present the candidate to the PM:
> "Based on your OKRs, I think your North Star metric is likely **[candidate]** — it
> measures [rationale]. Does that fit, or is there a better single metric that captures
> the core value this product delivers to customers?"

Accept PM's answer. Confirm it is:
- A single metric (not a composite or ratio of two unrelated things)
- Measuring customer value, not business output
- Theoretically movable by product decisions

If the PM can't identify one, offer the framing:
> "Imagine your product is working perfectly for customers. What number would be visibly
> higher than it is today?"

---

## 6.2.2 — Derive L1 inputs from OKRs

Read the confirmed key results from `okrs.md`. For each KR that is not the North Star,
assess whether it is a **leading input** to the North Star — i.e., if this metric moves,
the North Star is likely to follow.

Present candidates:
> "Your remaining key results suggest these L1 metrics — the product-level drivers of
> your North Star:
> - [KR-1] → measures [what]
> - [KR-2] → measures [what]
> - [KR-3] → measures [what]
>
> Do these cover the main levers, or are there important L1 metrics not reflected in
> the current OKRs?"

Allow the PM to add, remove, or rename. Confirm the final L1 list (3–5 metrics).

---

## 6.2.3 — Define L2 diagnostics per L1

For each confirmed L1, define 2–3 L2 diagnostic metrics — the team/feature-level metrics
that explain *why* the L1 is moving or not.

L2s are typically not in OKRs (they are too operational). Interview the PM for each L1:
> "For **[L1 metric]**: what 2–3 team-level metrics would tell you *why* it's moving?
> These are the signals your engineers and designers watch day-to-day."

Examples to prompt if the PM is stuck:
- For a retention L1: "Things like day-7 retention by onboarding path, feature adoption
  rate for the sticky features, or support ticket volume?"
- For an activation L1: "Things like time-to-first-value, step completion rates in the
  activation funnel, or setup abandonment rate?"

Confirm each L2 set before moving to the next L1.

---

## 6.2.4 — Measurement wiring

For each metric in the hierarchy (North Star, all L1s, all L2s), define:

| Field | Question to PM |
|---|---|
| **Data source** | "Where does this metric live? Annalise table, Snowflake query, manual dashboard, or something else?" |
| **Update cadence** | "How often should the scorecard pull this — weekly, monthly, or event-driven?" |
| **Current baseline** | "What's the current value? (Can be approximate — we'll update it on first scorecard run.)" |
| **Healthy target range** | "What range would you call healthy? Not just a single target — a band." |

If Annalise/Snowflake is available in the session, attempt to resolve the current
baseline automatically. Present to PM for confirmation before writing.

If a metric has no automated source, note it as `source: manual` in `metrics.md` — the
scorecard skill will prompt the PM to paste the value at run time.

---

## 6.2.5 — Write `metrics.md`

Present the complete draft to PM for confirmation before writing.

Write `<product_dir>/metrics.md` using this template:

```markdown
# Metric Hierarchy: <Product Name>

*Last updated: YYYY-MM-DD*
*Strategy version: <date of strategy.md>*

## North Star

| Metric | Definition | Data source | Cadence | Baseline | Healthy range |
|---|---|---|---|---|---|
| <name> | <what it measures and why it matters> | <source> | <cadence> | <value> | <low–high> |

## L1 Inputs

| Metric | Drives | Definition | Data source | Cadence | Baseline | Healthy range |
|---|---|---|---|---|---|---|
| <name> | North Star | <definition> | <source> | <cadence> | <value> | <low–high> |

## L2 Diagnostics

| Metric | Explains | Definition | Data source | Cadence | Baseline | Healthy range |
|---|---|---|---|---|---|---|
| <name> | <L1 name> | <definition> | <source> | <cadence> | <value> | <low–high> |
```

---

## Refresh mode behaviour for Step 6.2

1. Show current `metrics.md` to PM.
2. Ask: "Have any metrics changed — new sources, retired metrics, updated targets, or new L2s?"
3. If yes: walk through only the changed metrics, confirm each update.
4. If no: skip `metrics.md` entirely — it does not need updating every refresh cycle.
5. Update `last_updated` and `strategy_version` fields on any write.

Do not archive `metrics.md` on refresh — it is updated in-place.
