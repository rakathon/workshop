# Pause Procedure

A pause can occur:
1. **Automatically** — when required research is not available and cannot be obtained
   in the current session
2. **PM-initiated** — PM says "let's stop here", "I need to think about this", etc.

On pause:
1. Update `strategy-session.md` with current stage and `awaiting` description
2. Write any confirmed-but-unwritten content to `strategy-session.md` body
3. Report to PM:
   > "Session paused. State saved to `strategy-session.md`.
   > Stage: <stage>
   > Awaiting: <awaiting>
   > Re-invoke `forge:product-strategy` to resume."

No partial artifacts are written to `strategy.md`, `okrs.md`, or `metrics.md` during
a pause — those files are written only when the full section is confirmed.
