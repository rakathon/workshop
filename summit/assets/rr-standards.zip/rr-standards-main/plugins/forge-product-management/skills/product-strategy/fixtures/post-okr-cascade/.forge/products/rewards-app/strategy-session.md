---
product: rewards-app
stage: metrics
mode: create
paused_at: 2026-05-28T14:00:00Z
awaiting: nothing
generated_references:
  - data-analysis-retention-2026-01-15.md
outstanding_references: []
---

## Confirmed Diagnosis

The primary barrier to member retention is that users who do not redeem a reward within the first 30 days churn at 2.4× the rate of those who do, resulting in 90-day retention of 34% vs. an industry benchmark of 52%.

## Confirmed Pillars

1. First-redemption acceleration — reduce time-to-first-redemption for new members
2. High-value member retention — improve 90-day retention for members with ARPU > $6

## Confirmed Coherent Actions

| Initiative | Pillar | Horizon | Success Metric | Company OKR |
|---|---|---|---|---|
| Onboarding redemption nudge | First-redemption acceleration | now | % of new members redeeming within 14 days ≥ 40% | OKR-2026-1 |
| Personalised offer engine v2 | High-value member retention | next | 90-day retention for ARPU>$6 cohort ≥ 50% | OKR-2026-2 |

## Confirmed OKRs

**Objective 1:** Increase new member activation rate
- KR1: % of new members redeeming within 14 days: 22% → 40%
- KR2: Average days-to-first-redemption: 18 days → 9 days

**Objective 2:** Improve retention in high-value cohort
- KR1: 90-day retention for ARPU>$6 members: 34% → 50%
- KR2: NDR across all members: 88% → 98%
