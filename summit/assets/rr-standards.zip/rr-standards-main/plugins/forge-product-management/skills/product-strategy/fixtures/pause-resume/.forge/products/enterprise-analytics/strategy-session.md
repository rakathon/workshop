---
product: enterprise-analytics
stage: diagnosis
mode: create
paused_at: 2026-05-20T10:15:00Z
awaiting: Annalise and Snowflake MCP tools need to be enabled in the Claude Code session. Re-invoke forge:product-strategy once connected to get churn rate, ARPU, and NDR for the enterprise segment (last 4 quarters).
generated_references:
  - market-research-2026-05-20.md
outstanding_references:
  - internal-metrics: enterprise segment churn rate, ARPU, NDR (Q3 2025 – Q2 2026)
---

## Partial Work

No internal metrics available yet. Web research completed:
- Enterprise analytics market growing at 13% CAGR
- Top competitors: Tableau, Looker, Power BI, Sigma
- Differentiator gap identified: self-serve data modeling (currently an engineering bottleneck for our customers)
- Market positioning: we play in mid-market (500–5000 seat orgs); competitors strong at enterprise (10k+) and SMB (<100)

## Open Questions

- Are internal metrics confirming the self-serve bottleneck hypothesis, or is churn driven by something else (pricing, integrations, performance)?
- PM to confirm: is our go-to-market top-down (VP Analytics buyers) or bottom-up (data analyst self-serve adoption)?
