# Product Strategy: checkout

*Created: 2025-11-10*
*Last refreshed: 2026-02-14*
*Mode: create*

---

## Diagnosis

**Data:** Checkout abandonment rate is 41% overall; 78% for users with non-standard payment methods vs 12% for credit card users.

**Observations:** Payment method friction is the dominant drop-off point.

**Beliefs:** The critical barrier is payment method coverage gaps driving disproportionate abandonment in high-value customer segments.

**Bet:** The primary barrier to checkout conversion growth is that users with BNPL, regional wallet, and crypto payment preferences face a 78% abandonment rate, generating an estimated $2.1M annual revenue leakage.

*Evidence:* references/data-analysis-abandonment-2025-11-10.md

---

## Guiding Policy

### Strategic Pillars

| # | Pillar | Where We Play | How We Win | OKR | Success Indicator |
|---|--------|---------------|-----------|-----|-------------------|
| 1 | Payment Parity | BNPL + regional markets | Broadest payment method coverage in segment | OKR-2025-2 | <5% drop-off variance across methods |
| 2 | Returning User Acceleration | All segments | Fewest steps for authenticated users | OKR-2025-1 | 3-step checkout for 80% of returning users |

### Strategic Exclusions

| Exclusion | Rationale |
|-----------|-----------|
| Cryptocurrency payments | Regulatory uncertainty; <0.5% of abandonment |
| B2B invoice checkout | Different product surface; out of scope this year |

---

## Coherent Actions

| Initiative | Strategic Pillar | Owner | Horizon | Success Metric | Company OKR | Effort ID |
|------------|-----------------|-------|---------|----------------|-------------|-----------|
| Expand payment methods (BNPL + 3 regional wallets) | Payment Parity | Platform team | now | <5% drop-off variance | OKR-2025-2 | checkout-payment-expansion |
| Streamline returning user flow | Returning User Acceleration | UX team | next | 3-step checkout for 80% returning users | OKR-2025-1 | checkout-ux-simplification |

---

## OKRs

*See [okrs.md](okrs.md)*

---

## Roadmap

*See [roadmap.md](roadmap.md)*
