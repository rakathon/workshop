# Diagnosis Quality Gate — forge:product-strategy

Applies at Step 3.4. All three tests must pass before advancing to the Guiding Policy phase.
The gate is also used during refresh and pivot modes whenever the diagnosis changes.

---

## The Three Tests

### QG-1 — Specificity

Does the diagnosis name a concrete barrier or condition in the market or product?

❌ Fail: "We need to grow faster" / "Our product isn't competitive" / "We have too much churn"
✅ Pass: "Our 14-day time-to-first-redemption is 3× the category benchmark, destroying
   retention before the value loop can establish itself"

Specificity fails when:
- The statement is a goal or aspiration (what the PM wants to achieve)
- The statement is a list of problems rather than a single condition
- The statement describes a symptom without naming the specific mechanism

---

### QG-2 — Evidence

Does the diagnosis reference at least one quantitative signal?

For **established products**: the signal must be an internal metric (retention rate,
churn, ARPU, NDR, activation rate, or similar).

For **new products with no internal data**: a qualitative market signal is acceptable
(e.g., "category benchmark" or "competitor X captures 40% of segment Y").

❌ Fail: "Customers seem frustrated with onboarding" / "We think we're losing to competitors"
✅ Pass: "Our 90-day retention is 34% vs. 52% industry benchmark; users who redeem
   within 30 days show 2.4× higher retention"

---

### QG-3 — Singularity

Does the diagnosis identify ONE root challenge?

❌ Fail: "We have poor retention AND high churn AND weak differentiation AND..."
✅ Pass: One specific, evidence-backed problem statement. If multiple problems exist,
   the PM must choose the single most critical barrier for this strategy cycle.

---

## Applying the Gate

For each failing test, do not simply explain what is wrong. Always offer a concrete
improved restatement:

> "The diagnosis [fails the specificity/evidence/singularity test] because [specific reason].
> Here's a sharper version grounded in the research we gathered:
> '[improved restatement]'.
> Does this capture what you mean, or should we refine it further?"

The improved restatement must:
- Be grounded in research or data already gathered (do not invent signals)
- Pass all three tests itself
- Use the PM's own language and domain context where possible

**Do not advance to the Guiding Policy phase until all three tests pass.**

If the PM rejects all proposed restatements, ask:
> "What specific barrier, if removed, would most unlock growth for this product right now?"
> This often produces a more specific answer than asking for a diagnosis directly.
