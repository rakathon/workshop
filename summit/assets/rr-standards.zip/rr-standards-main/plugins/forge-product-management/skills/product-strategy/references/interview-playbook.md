# Interview Playbook — forge:product-strategy

Phase-by-phase question bank for the product strategy session.
Ask questions one at a time. Each question includes a recommended answer
structure to offer the PM when they are unsure how to respond.

---

## Phase 0: Session Initialization

**P0-1 — Product identification**
> "Which product are we building a strategy for?"
*Recommended answer form:* Product name and one-sentence description of what it does.

**P0-2 — Company OKRs**
> "Do you have company OKRs you're working from this quarter? I can take a file path,
> a Confluence URL, or you can paste them here."
*Recommended answer form:* 3–5 company objectives with key results. If unavailable,
proceed without them and flag the missing alignment risk later.

**P0-3 — Product maturity**
> "Is this an established product with existing customers and data, or a new product
> you're launching?"
*Recommended answer form:* Established (has users, revenue, internal metrics) or
New (pre-revenue, greenfield, or new product line).

**P0-4 — External inputs (if not provided at invocation)**
> "Do you have any existing documents I should read first — a roadmap, board deck,
> prior strategy, or market research?"
*Recommended answer form:* File path(s), URL(s), or "no, let's start fresh".

---

## Phase 1: Diagnosis (DIBB Framing)

Goal: arrive at a falsifiable, evidence-backed bet on the single most critical challenge.

### Data layer

**D1 — Internal signals (established products)**
> "What do you know about how the product is performing right now?
> Key numbers I'm looking for: retention/churn rate, ARPU or revenue trend,
> Net Dollar Retention, and feature adoption for your core value prop."
*Recommended answer form:* "Our 90-day retention is X%, churn is Y%, ARPU is $Z."
*Note: for established products, attempt Annalise query before asking this.*

**D2 — External signals (new products or supplemental)**
> "What does the market look like? Do you know the market size, growth rate,
> and who the top 3–5 competitors are?"
*Recommended answer form:* Market size + CAGR + competitor names.
*Note: attempt web research before asking this.*

**D3 — Customer signals**
> "What are customers telling you? What are the most common complaints,
> churn reasons, or unmet needs you hear?"
*Recommended answer form:* Top 2–3 themes from support, sales, or interviews.

### Observations layer

**O1 — Pattern identification**
> "Looking at the data we've gathered — what patterns or anomalies stand out to you?
> What is surprising or not what you expected?"
*Recommended answer form:* "I notice that X segment is much worse/better than Y."

**O2 — Benchmark gap**
> "How does this compare to industry benchmarks or competitors?
> Where is the biggest gap?"
*Recommended answer form:* "We're X points below benchmark on Y metric."

### Beliefs layer

**B1 — Root cause hypothesis**
> "Why do you think this is happening? What's the causal story behind these patterns?"
*Recommended answer form:* "I believe the root cause is X because Y."

**B2 — Confidence check**
> "How confident are you in that hypothesis? Is there evidence that directly supports
> it, or is it an informed guess at this point?"
*Recommended answer form:* "High confidence — we have data. / Medium — it's a hypothesis."

### Bet layer

**Bet-1 — Draft synthesis**
> "Based on everything we've discussed, how would you state the single most critical
> challenge your product must overcome right now? Try to express it as a specific
> barrier, not a goal."
*Recommended answer form:* "The primary barrier is [specific condition] as evidenced
by [quantitative signal]."

### Diagnosis Quality Gate (three tests — all must pass before advancing)

**QG-1 — Specificity test**
Does the diagnosis name a concrete barrier or market position?
❌ Fail: "We need to grow faster" / "Our product isn't competitive"
✅ Pass: "Our 14-day time-to-first-redemption is 3× the category benchmark, destroying
   retention before the value loop establishes itself"

**QG-2 — Evidence test**
Does the diagnosis reference at least one quantitative signal (internal, external,
or a qualitative market signal for new products with no internal data)?
❌ Fail: "Customers seem frustrated with onboarding"
✅ Pass: "Our 90-day retention is 34% vs. 52% industry benchmark; users who redeem
   within 30 days show 2.4× higher retention"

**QG-3 — Singularity test**
Does the diagnosis identify ONE root challenge, not a list?
❌ Fail: "We have poor retention AND high churn AND weak differentiation AND..."
✅ Pass: one specific, evidence-backed problem statement

**If any test fails:** offer a concrete improved restatement:
> "The diagnosis as stated [fails specificity/evidence/singularity test] because
> [reason]. Here's a sharper version grounded in the research:
> '[improved restatement]'. Does this capture what you mean, or should we refine it?"

### OKR Alignment Check (before advancing to guiding policy)

> "Does this diagnosis connect to any of the company OKRs you shared?
> If not, that's fine — but it's worth flagging."

If no connection: surface risk before proceeding:
> "This diagnosis doesn't appear to map to any company OKR. Is this intentional —
> perhaps the OKRs need updating — or should we reframe the diagnosis to connect
> to [OKR-<year>-<n>]?"

---

## Phase 1 Optional Lens: PLG / MOAT (Product-Led Growth Products Only)

Apply when `is_plg = true` — products that grow through self-serve adoption
(freemium, viral signup, bottom-up trial). Does not apply to managed marketplaces,
consumer platforms, or enterprise sales-led products.

**M1 — Market Strategy**
> "How is your product positioned — dominant (category leader), disruptive
> (challenging incumbents on price/simplicity), or differentiated (unique segment)?"

**M2 — Ocean Conditions**
> "Is this a known category where customers already understand the problem
> (red ocean), or are you creating new demand and educating the market (blue ocean)?"

**M3 — Audience**
> "Does your go-to-market motion go top-down (executive buyers, enterprise sales)
> or bottom-up (end users adopt, then pull in budget)?"

**M4 — Time-to-Value**
> "How quickly does a new user experience the core value of your product?
> In minutes, days, or weeks?"

---

## Phase 2: Guiding Policy

Goal: 3–5 strategic pillars that directly address the diagnosed challenge.

### Where to Play

**WP-1 — Target segment**
> "Which customer segment, geography, or channel should we double down on?
> Where does this product win most clearly?"

**WP-2 — Explicit exclusions**
> "What markets, segments, or customer types should we explicitly NOT pursue?
> Stating what we won't do is as important as stating what we will."
*Recommended answer form:* "We won't pursue [X] because [Y]."

### How to Win

**HW-1 — Competitive advantage**
> "What is the one thing that makes us the best choice in the segments we've chosen
> to play in? What would customers lose if we disappeared?"

**HW-2 — Pillar derivation**
> "Given the diagnosis and where we're playing — what are the 3–5 strategic priorities
> that directly address the challenge? Each should be a direction, not a feature or task."
*Recommended answer form:* "Pillar 1: [name] — [direction]. Connected to [OKR]."

### Pillar Quality Check (per pillar)

Each pillar must pass four tests before advancing:
1. **OKR connection** — maps to at least one company OKR
2. **Customer need** — addresses an identified customer need from the diagnosis
3. **Measurability** — has at least one success indicator that can be tracked
4. **Prioritisation guidance** — provides direction for trade-off decisions

---

## Phase 3: Coherent Actions

Goal: initiatives where each reinforces the others, closing Bungay's three gaps.

**CA-1 — Bungay knowledge gap**
> "What do we need to know or learn first before we can execute? Is there a research
> or validation step that reduces uncertainty?"

**CA-2 — Bungay alignment gap**
> "How will teams know what to do differently as a result of this strategy?
> What initiative most directly changes day-to-day team behavior?"

**CA-3 — Bungay effect gap**
> "How will we know if the strategy is working? What initiative produces the clearest
> measurable signal that we're on track?"

**CA-4 — OKR tagging**
For each initiative:
> "Which company OKR does this initiative advance? Use the format OKR-<year>-<n>."

**CA-5 — Horizon assignment**
> "Is this a now (this quarter), next (next quarter), or later (6–12 months) initiative?"

---

## Phase 4: OKR Cascade

Goal: 3–5 product-level objectives with 2–4 outcome-based key results each.

**OKR-1 — Objective framing**
> "For each company OKR that has an initiative mapped to it — what is the
> product-level outcome that would constitute meaningful progress this quarter?
> State it as an objective, not a task."

**OKR-2 — Key result design**
> "What would you measure to know this objective was achieved?
> Try to express it as a user behavior or business metric change, not a feature shipped."

**OKR-3 — Stretch calibration**
> "Is this a realistic target (70% confidence), or a stretch target (50% confidence)?
> The structural constraint is 70% achievement = significant progress."

---

## Phase 5: Roadmap

Goal: a communication artifact mapping initiatives to outcomes by horizon.

**RM-1 — Format preference**
> "For the roadmap format — would you prefer now/next/later (timeless)
> or a quarterly grid (Q1/Q2/Q3)?"

**RM-2 — Success metric review**
For each initiative in the roadmap:
> "What metric or condition defines 'done' for this initiative?"
*Recommended answer form:* An outcome metric, not a delivery milestone.
