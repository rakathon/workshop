# forge:product-synthesis

Synthesizes raw user research into a structured, evidence-grounded findings document
using rigorous qualitative and quantitative methodology. Accepts any combination of
five input types and produces a six-section synthesis document covering findings,
behaviorally-defined personas, opportunity areas with impact sizing, and concrete
recommendations.

---

## Usage

```
forge:product-synthesis
```

Invoke the skill and provide research material in any form:
- Pasted text (interview notes, transcripts, survey exports, ticket lists)
- File paths (Claude reads each file before proceeding)
- Confluence URLs (page content is fetched)
- Descriptions of data without raw data (Claude will prompt for the actual material)

---

## When to Use

- You have raw research material and need structured synthesis before making product decisions
- You want to analyze customer interviews and find the patterns across them
- You have survey results and need findings, not just averages
- You want to understand what support tickets and feature requests are telling you
- You have multiple research sources and need them triangulated into a single view
- Any time you say "synthesize this research", "analyze these interviews", "make sense of this user data", "what do these findings mean", "analyze survey results", "turn these notes into insights", "summarize user feedback", or "what did users tell us"

---

## Accepted Input Types

| Source Type | Captures Well | Limitations | Weight |
|---|---|---|---|
| Interview notes / transcripts | Motivation, context, latent needs, emotional intensity, the "why" behind behavior | Small n, recall bias, social desirability in stated preferences | High for explanation; stated preferences treated as weak signal |
| Survey responses | Scale, distribution across user base, quantified attitudes, segment comparisons | Context, causation, nuance; responders skew toward engaged users | High for frequency/scale; low for causation |
| Support tickets / feature requests | Acute pain points, actual user language, users motivated enough to report | Skewed toward power users and frustrated users; silent majority absent | High for friction signals; low for satisfaction signals |
| Product analytics data | Actual behavior at scale, funnel drop-off, retention patterns, feature adoption | Explains what happened, not why; measures only what was instrumented | Highest for behavioral ground truth |
| Usability study notes | Task-level friction, confusion points, workflow mismatches | Artificial lab conditions; small n; predefined tasks | High for UX friction diagnosis; moderate for prioritization |

---

## Methodologies Applied

The skill selects methodologies based on what inputs are present:

- **Thematic analysis** — applied to interview notes, open-ended survey responses, support tickets, and usability notes. Follows a six-step process: familiarization, initial coding, theme development, theme review, theme refinement, and documentation. Themes are named as insights, not topics.
- **Affinity mapping** — applied when data is large and unstructured, or when themes are not yet visible across heterogeneous source types. Decomposes material into atomic observations, clusters by natural similarity, and converts clusters into named themes.
- **Triangulation** — applied whenever two or more source types are present. Checks for agreement, silence, and conflict across sources. Source conflicts are never averaged or papered over — they are reported explicitly with a most-likely explanation and a recommended resolution test.
- **Survey data interpretation** — applied to all quantitative and mixed-method surveys. Always reports full distributions rather than averages. Checks for sampling bias, applies segmentation before reporting overall numbers, and applies thematic analysis to open-ended responses.
- **Qual + quant integration** — applied when both qualitative and quantitative sources are present. Identifies the direction of integration (qual explaining a quant anomaly, or quant testing a qual hypothesis) and uses confirmation, expansion, or discordance strategies as appropriate.

---

## Output

### Six-Section Synthesis Document

| Section | Contents |
|---|---|
| **1. Research Overview** | Sources used (type, time period, volume), methodologies applied, known limitations, synthesis date |
| **2. Key Findings** | 5–8 findings, each with evidence (minimum 2 items), frequency, impact rating, and confidence rating. Behavioral findings labeled `[Behavioral]`; stated-preference findings labeled `[Stated]`. |
| **3. User Segments / Personas** | 3–5 behaviorally-defined personas, each with defining behavior, jobs to be done, frustrations, success definition, research evidence, and estimated size |
| **4. Opportunity Areas** | Unmet needs mapped to findings and personas, each with impact sizing using the formula: addressable users × frequency × severity |
| **5. Recommendations** | 3–7 concrete recommendations, each traceable to a finding and an opportunity area. Typed as build, research, or instrument recommendations. |
| **6. Open Questions** | All unresolved questions, each with why it matters, recommended method to answer, and rough effort estimate |

### Output Artifact Path

The skill detects the environment at startup and resolves output paths accordingly. No Forge initialization is required.

| Context | Forge mode path | Plain mode path |
|---|---|---|
| Active effort | `<effort_dir>/research/synthesis.md` | (not applicable — no effort tracking) |
| Product directory exists | `<product_dir>/research/synthesis.md` | `<product_dir>/research/synthesis.md` |
| Neither | PM is prompted, or `./research/synthesis.md` | PM is prompted, or `./research/synthesis.md` |

In Forge mode, `effort_dir = .forge/efforts/<effort-id>/` and `product_dir = .forge/products/<product-name>/`.
In plain mode (Claude Desktop / Cowork / no `.forge/`), `product_dir = ./<product-name>/`.

---

## Quality Gates

The skill will not write the synthesis document until:
- At least one source type has been read (actual content reviewed, not described)
- At least 3 thematic codes have been identified
- At least 1 finding can be completed with all five required fields

If the research corpus is limited (a single source type with fewer than 5 data points), the skill proceeds but flags findings as directional hypotheses rather than validated conclusions.

---

## Relationship to Other Skills

| Skill | Relationship |
|-------|-------------|
| `forge:elaborate` | elaborate gathers requirements through a structured interview; product-synthesis processes existing raw research material into findings |
| `forge:product-strategy` | product-synthesis produces a `synthesis.md` findings document; product-strategy consumes research findings as inputs to diagnosis and guiding policy |
| `forge:product` | product-synthesis can write to a product directory created by forge:product |
