# Synthesis Document Template

Write the synthesis as a single Markdown document with all six sections. Every section is required — do not omit a section because data is sparse. For sparse sections, write what is known and flag what is missing.

**Target output path** (resolved in Step 0 of the skill — use path variables, not hardcoded paths):
- Active Forge effort → `<effort_dir>/research/synthesis.md`
- Product directory exists → `<product_dir>/research/synthesis.md`
- Neither → ask the PM where to save, or write to `./research/synthesis.md`

In plain mode (no `.forge/`): skip the active effort check; use `<product_dir> = ./<product_name>/`.

---

## Section 1: Research Overview

State:
- Sources used (list each with type, time period, and volume — e.g., "12 customer interviews conducted March–April 2026; 340-response survey fielded April 2026; 6 months of support tickets Jan–June 2026")
- Total participants or data points per source
- Methodological approach applied (which methods were used and why)
- Known limitations and sampling biases
- Synthesis date

---

## Section 2: Key Findings

Include 5–8 findings. Every finding requires all five fields. Do not include a finding that cannot be completed.

**Ordering:** Lead with the finding that has the highest combination of impact and confidence. Save lower-confidence findings for last. Do not bury the lead.

**Labels:** When a finding is based primarily on behavioral data (observations, analytics), label it `[Behavioral]`. When based primarily on stated preferences, label it `[Stated]`. Behavioral findings carry higher evidentiary weight.

```
### Finding [N]: <Insight statement — one sentence, describes what you learned>

**Evidence:**
- [Quote or observation] — [Source ID, participant, or data reference]
- [Quote or observation] — [Source ID, participant, or data reference]
(Minimum 2 evidence items. Add more when available.)

**Frequency:** [n] independent [participants / sources / data points]
**Impact:** High / Medium / Low — [one sentence justification]
**Confidence:** High / Medium / Low — [one sentence justification, noting if any contradicting evidence exists]
```

---

## Section 3: User Segments / Personas

Include the completed personas (use persona-template.md). Include a short framing paragraph before the personas:

"These personas are behaviorally defined from [sources]. They represent distinct usage patterns, not demographic groups."

If the data does not support persona development (e.g., single source, fewer than 8 participants), state: "Insufficient data to define stable behavioral personas. The following proto-personas are directional hypotheses, not validated segments." Then write the templates with lower-confidence language.

---

## Section 4: Opportunity Areas

For each unmet need or underserved job revealed by the research, write one opportunity entry.

**Impact formula:** addressable users × frequency × severity = impact score

Severity scale:
- 1 = minor inconvenience, user continues with slight friction
- 2 = noticeable friction, user completes goal with workaround
- 3 = significant friction, task takes meaningfully longer or requires outside help
- 4 = frequent failure, user regularly cannot complete goal
- 5 = blocks key job entirely, user cannot proceed

**Presentation rule:** Express all values as ranges, not false precision.

Good: "Affects 40–60% of active users (estimated from survey segmentation). Occurs 2–4 times per week for affected users. Severity 3/5. Impact score: 80–240 per 1,000 active users per week."

When sizing data is unavailable: "Insufficient data to size — recommend [specific data collection approach]."

```
### Opportunity: <Name>

**Unmet need:** <What users are trying to do that the product doesn't support well>
**Grounded in findings:** Finding [N], Finding [N]
**Grounded in personas:** [Persona name(s)]
**Impact sizing:** [Apply formula above — express as ranges]
**Current workaround:** <How users are solving this today, if any>
```

Each opportunity must map to at least one key finding and one persona.

---

## Section 5: Recommendations

Write 3–7 concrete recommendations. Each must be:
- Traceable to at least one key finding (cite it)
- Traceable to at least one opportunity area (cite it)
- Specific enough to evaluate: "investigate whether async notifications reduce alert fatigue" is actionable; "improve notifications" is not

Include at least one research recommendation if any key finding has Low confidence.

**Types:**
- **Build recommendations:** changes to the product
- **Research recommendations:** follow-on research to resolve uncertainty
- **Instrument recommendations:** data collection needed before a decision can be made

```
### Recommendation [N]: <Action>

**Rationale:** <Why this is the right action, grounded in findings>
**Grounded in:** Finding [N]; Opportunity: [Name]
**Priority:** High / Medium / Low — [brief justification]
**Suggested next step:** <Most immediate concrete action>
```

---

## Section 6: Open Questions

List all questions the research left unresolved. Do not omit this section — empty open questions usually means the synthesis was not done rigorously enough. Good research generates more questions than it answers.

For each question, state:
- The question
- Why it matters (which decision it would inform)
- Recommended method to answer it
- Rough effort to answer it (e.g., "2-week targeted survey", "5 contextual inquiry sessions", "add 3 analytics events and wait 30 days for data")
