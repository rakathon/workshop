---
name: forge:product-synthesis
description: >
  Synthesizes raw user research into structured, evidence-grounded findings using
  rigorous qualitative and quantitative methodology. Accepts five input types:
  interview notes and transcripts, survey responses (quantitative and open-ended),
  support tickets and feature requests, product analytics data, and usability study
  notes. Produces a six-section synthesis document with key findings, behaviorally-
  defined personas, opportunity areas with impact sizing, and concrete recommendations.
when_to_use: >
  Trigger on: "synthesize this research", "analyze these interviews", "make sense of
  this user data", "what do these findings mean", "analyze survey results", "turn these
  notes into insights", "write up the research", "what patterns are in this data",
  "summarize user feedback", "what did users tell us", "forge:product-synthesis",
  or any time a PM has raw research material and needs structured synthesis before
  making product decisions.
agent-type: executor
---

# forge:product-synthesis

Synthesizes raw user research into a structured findings document using rigorous
methodology. Works from any combination of five input types and produces a six-section
output covering findings, personas, opportunities, and recommendations.

For detailed method procedures, see `references/` alongside this file.

---

## Step 0: Environment Detection and Input Audit

**0.0 — Detect environment.** Load `common/environment.md` and set:

```
env_mode      = forge | plain          # forge if .forge/ exists, plain otherwise
products_root = .forge/products        # forge mode
              = .                      # plain mode
```

**Determine output path:**

- **Forge mode:**
  1. Check for an active effort: read `.forge/EFFORT` → `effort_id` → `effort_dir = .forge/efforts/<effort_id>/`. If found, output to `<effort_dir>/research/synthesis.md`.
  2. Otherwise check whether a product directory exists under `products_root`. If found, output to `<product_dir>/research/synthesis.md`.
  3. Otherwise ask the PM where to save, or default to `./research/synthesis.md`.

- **Plain mode:**
  1. Skip the active effort check entirely (no `.forge/EFFORT` or `.forge/efforts/`).
  2. Ask the PM for the product name. Check whether `<products_root>/<product_name>/` exists. If found, output to `<product_dir>/research/synthesis.md` (where `product_dir = ./<product_name>/`).
  3. Otherwise ask the PM where to save, or default to `./research/synthesis.md`.

Do not run shell commands in plain mode — use the Read and Write tools directly.

---

## Step 0 (continued): Receive and Audit Inputs

**0.1 — Classify each input** into one of the five source types:

| Source Type | Captures Well | Weight |
|---|---|---|
| Interview notes / transcripts | Motivation, context, latent needs, emotional intensity | High for explanation; stated preferences = weak signal |
| Survey responses | Scale, distribution, quantified attitudes | High for frequency/scale; low for causation |
| Support tickets / feature requests | Acute pain points, actual user language | High for friction; low for satisfaction |
| Product analytics data | Actual behavior at scale, funnel drop-off, retention | Highest for behavioral ground truth |
| Usability study notes | Task-level friction, confusion points | High for UX friction; moderate for prioritization |

**0.2 — Warn on limited corpus.** If only a single source type is present with fewer than 5 data points:

> "This synthesis is based on limited data ([n] [source type]). Findings should be treated as directional hypotheses, not validated conclusions."

Proceed regardless — do not block on corpus size.

**0.3 — Declare the methodology** — state which methods you will apply, then load the corresponding reference files:

| Input present | Load |
|---|---|
| Interview notes, open-ended surveys, support tickets, or usability notes | `references/method-thematic-analysis.md` |
| Data is large/unstructured and themes not yet visible | `references/method-affinity-mapping.md` |
| Two or more source types present | `references/method-triangulation.md` |
| Any interview data | `references/method-interview-analysis.md` |
| Quantitative survey data present | `references/method-survey-interpretation.md` |
| Both qual and quant sources present | `references/method-qual-quant-integration.md` |

Always load for output: `references/synthesis-template.md` and `references/persona-template.md`.

If a reference file is not accessible, use the inline guidance below.

---

## Step 1: Apply Analytical Methods

### Thematic analysis (when applicable)

Read all material before labeling. Code meaningful segments descriptively. Group codes into themes — each requiring ≥3 independent observations. Name themes as insights, not topics ("PMs can't self-serve onboarding" not "onboarding"). For each theme record: name, definition, evidence (≥2 items), frequency, impact (H/M/L), confidence (H/M/L).

### Interview note analysis (when applicable)

Separate observations into three buckets and weight them differently:
- **Observations** — what the person *did* (behavioral — strongest signal). Mark `[OBSERVED]`.
- **Behaviors** — patterns across a participant's actions within/across sessions.
- **Stated preferences** — what the person *said* they wanted. Treat as weak signal. When a stated preference conflicts with an observation, weight the observation.

Flag intensity signals (frustration, delight, resignation) with `[HIGH INTENSITY]`. Intensity predicts importance.

A finding is significant when it appears in ≥3 independent participants. Never present a one-participant story as a pattern.

### Survey data interpretation (when applicable)

Always report distributions, not just averages. A satisfaction score of 3.0/5 could mean "everyone is mildly neutral" or "half give 5 and half give 1" — completely different implications. If raw distribution is unavailable, flag this as a data gap. Segment results by user tenure, engagement level, and plan tier before reporting overall numbers.

### Triangulation (when applicable)

When two or more sources address the same behavior: identify where they agree (highest-confidence signal), where they are silent, and where they conflict. When sources conflict, do not average them — report explicitly:

> **Source conflict identified:** [Source A] suggests [finding A]. [Source B] suggests [finding B]. These cannot both be fully correct.  
> **Most likely explanation:** [hypothesis]  
> **Recommended resolution:** [specific follow-on test]

### Qual + quant integration (when applicable)

State the integration direction: "qual explaining a quant anomaly" or "quant testing a qual hypothesis." Use confirmation, expansion, or discordance strategies. When sources disagree, report it — disagreement is itself a finding.

---

## Step 2: Build Personas

Build 3–5 behaviorally-defined personas. Personas must be defined by what users *do*, not demographics. Verify each appears in ≥2 independent sources. Name each persona after their behavior ("The Reluctant Delegator"), not their role ("The Enterprise Admin").

For each persona, include: defining behavior (grounded in observed patterns), jobs to be done (functional/emotional/social), specific frustrations with evidence, what success looks like, research evidence (source references), and estimated size/frequency.

If data is insufficient (single source, <8 participants), label these "proto-personas — directional hypotheses, not validated segments."

---

## Step 3: Assemble the Synthesis Document

Write all six sections. Do not omit any section — write what is known and flag gaps.

**Output path:** Determined in Step 0. Write to `<effort_dir>/research/synthesis.md` (Forge mode with active effort), `<product_dir>/research/synthesis.md` (product directory found), or `./research/synthesis.md` (fallback). See Step 0 for the full resolution logic.

### Section 1: Research Overview
Sources (type, time period, volume), total participants per source, methods applied, known limitations and sampling biases, synthesis date.

### Section 2: Key Findings (5–8 findings)
Lead with highest impact+confidence finding. For each:
- **Label `[Behavioral]`** when based on observations/analytics; **`[Stated]`** when based on stated preferences. Behavioral findings carry higher evidentiary weight.
- **Evidence:** minimum 2 items (quotes, observations, or data references with source IDs)
- **Frequency:** number of independent participants/sources
- **Impact:** High / Medium / Low with one-sentence justification
- **Confidence:** High / Medium / Low — never High unless ≥3 independent sources

### Section 3: User Segments / Personas
Framing paragraph + completed personas from Step 2. "These personas are behaviorally defined from [sources]. They represent distinct usage patterns, not demographic groups."

### Section 4: Opportunity Areas
For each unmet need: state the unmet need, findings it's grounded in, personas it affects, impact sizing (addressable users × frequency × severity, expressed as ranges), and current workaround. Each opportunity must map to ≥1 finding and ≥1 persona.

**Severity scale:** 1 = minor inconvenience | 2 = workaround exists | 3 = significant friction | 4 = frequent failure | 5 = blocks key job entirely

Express sizing as ranges: "Affects 40–60% of active users. Occurs 2–4×/week. Severity 3/5." If data unavailable: "Insufficient data — recommend [specific collection approach]."

### Section 5: Recommendations (3–7)
Each must be traceable to ≥1 finding and ≥1 opportunity. Be specific enough to evaluate. Type each as **Build**, **Research**, or **Instrument**. Include at least one Research recommendation if any finding has Low confidence.

### Section 6: Open Questions
Every unresolved question with: why it matters, recommended method to answer, and rough effort estimate. Do not omit — good research generates more questions than it answers.

---

## Step 4: Review and Present

**Internal consistency check:** every finding has ≥2 evidence items; every opportunity maps to ≥1 finding and ≥1 persona; every recommendation maps to ≥1 finding and ≥1 opportunity; no averages reported without distributions; source conflicts documented.

**Confidence calibration rule:** Never report a finding as High confidence without ≥3 independent sources. Never report an opportunity as High impact without at least a partial sizing estimate. Overconfident synthesis is worse than no synthesis.

Show the PM: number of findings/personas/opportunities/recommendations, the highest-confidence finding, the highest-impact opportunity, and the most significant open question. Then offer the full document and ask if they want to explore any area deeper or add more data.
