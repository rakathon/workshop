# Interview Note Analysis

Apply to: all direct customer conversation records.

## 4.1 — Separate observation types

As you read each interview, sort observations into three buckets:

- **Observations:** what the person did (behavioral — strongest signal). Example: "Opened a second browser tab to manually cross-reference data." Behavioral data is stronger than stated preferences.
- **Behaviors:** patterns across a participant's actions within or across sessions. Example: "In three separate instances across the session, participant navigated away from the page rather than using the back button." Behaviors are observations elevated to patterns.
- **Stated preferences:** what the person said they wanted — record these, but treat them as weak signal. Example: "Said they would use a bulk export feature if it existed." Stated preferences are unreliable for two reasons: users predict their own behavior poorly, and they often request solutions rather than articulating needs.

When a stated preference conflicts with an observation from the same participant, weight the observation. Record the conflict explicitly.

## 4.2 — Mark intensity signals

Flag observations where the participant showed strong emotion: frustration, delight, confusion, resignation. These are intensity signals. Intensity predicts importance — a participant who sighs, laughs, uses profanity, or physically gestures when describing a problem is signaling that this problem matters more than a calm description of the same problem.

Use a simple marking: [HIGH INTENSITY] next to the observation. Do not filter these out; surface them in findings.

## 4.3 — Cross-interview patterns

A finding from interview data is significant when:
- It appears in ≥3 independent participants
- The participants were not led to this observation by a direct question (unprompted mentions are stronger)
- The participants are in different contexts or segments (same-segment repetition has lower weight)

A single vivid anecdote is context for a finding, not the finding itself. When surfacing interview-derived findings, state: "Observed in [n] of [total] participants" — never present a one-participant story as a pattern.
