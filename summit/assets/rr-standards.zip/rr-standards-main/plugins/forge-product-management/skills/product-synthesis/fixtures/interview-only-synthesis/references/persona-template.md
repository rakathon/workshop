# Persona Template

Build 3–5 behaviorally-defined personas from the synthesized findings. Do not exceed 5 — more means the data was over-segmented.

**Personas must be behaviorally defined, not demographically defined.** A demographic persona ("35–45 year old urban professional") does not predict product behavior. A behavioral persona does.

For each persona:
1. Identify a distinct behavior pattern that separates this group from others. Ground it in specific observations from the research corpus.
2. Verify the persona appears in ≥2 independent sources.
3. Estimate its relative size using any available analytics or survey data.
4. Complete the six-field template below.

**Behavioral naming rule:** Persona names should describe what the person does, not who they are.  
Bad: "The Enterprise Admin."  
Good: "The Reluctant Delegator" (describes behavior: assigns tasks but checks every output).  
Names should be memorable and immediately predictive of behavior.

---

## Persona: \<Behavior-Based Name\>

**Defining behavior:** \<What they do that makes them distinct from other users. Ground in a specific, observed pattern — not a demographic or job title.\>

**Jobs to be done:** \<Primary functional job (what they're trying to accomplish), emotional job (how they want to feel), and social job (how they want to be perceived). Each job should be grounded in research evidence.\>

**Frustrations:** \<Specific friction points, each with an evidence reference. Do not list general dissatisfaction — name the specific failure mode.\>

**What success looks like:** \<What this person would celebrate if the product worked perfectly. Should be concrete enough to evaluate a design against.\>

**Research evidence:** \<Which sources, sessions, or data points define this persona. List specific references — e.g., "Interview P3, P7, P12; support ticket cluster 4; analytics cohort: users with <2 sessions in first 14 days."\>

**Size / frequency:** \<Estimated proportion of user base, with method. Example: "~30% of active users based on analytics cohort analysis." If unknown: "Size unknown — recommend adding behavioral segment to analytics."\>
