# Triangulation

Apply when two or more source types are present.

## 3.1 — Methodological triangulation

Use multiple methods to study the same question. When interviews, surveys, and analytics data address the same user behavior:
1. State the question each source addresses (they may be measuring different aspects).
2. Identify where they agree — this is your highest-confidence signal.
3. Identify where they are silent (one source doesn't speak to an aspect the other covers).
4. Identify where they conflict — treat this as the most important finding to investigate.

## 3.2 — Source triangulation

Check whether a finding holds across different user segments, channels, or data sources:
- Does the theme appear in enterprise users and SMB users?
- Does it appear in inbound support tickets and proactively-gathered interview data?
- Does it appear in both new users and experienced users?

A finding that holds only in one segment is still a valid finding — but report it with that scope.

## 3.3 — Temporal triangulation

If data spans multiple time periods, compare them explicitly:
- Is this a persistent pattern or a transient signal (e.g., response to a recent release)?
- Has the issue worsened, improved, or stayed stable over time?
- Are there cohort effects (new users report this more than veterans)?

## 3.4 — Handling disagreement between sources

When sources conflict, do not average them or paper over the contradiction. Report it explicitly using this format:

> **Source conflict identified:** [Qual source] suggests [finding A]. [Quant source] suggests [finding B]. These cannot both be fully correct.  
> **Most likely explanation:** [hypothesis — e.g., survey captures stated intent, analytics captures actual behavior, and they diverge because X]  
> **Recommended resolution:** [specific test or follow-on research to resolve — e.g., "run a targeted survey with behavioral segmentation", "replay session recordings for users in the drop-off cohort"]

Never collapse a disagreement into a consensus the data does not support. Contradictions often contain the most useful product signal.
