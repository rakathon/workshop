# Affinity Mapping

Apply when: data is large and unstructured, themes are not yet visible, or you are working across multiple heterogeneous source types.

Skip this method if thematic analysis produced a clear theme structure with good coverage.

## Step 2.1 — Capture

Decompose each document into its smallest meaningful units of observation — one distinct idea, complaint, behavior, or request per note. Write each as a complete sentence. If two ideas appear in the same sentence, split them. Goal: no compound observations.

## Step 2.2 — Cluster

Group notes by natural similarity. Do not impose a pre-existing taxonomy. Let the data determine the groupings. If a note could fit in two clusters, place it in the one where it adds most information, and flag it for review.

## Step 2.3 — Label

Give each cluster a label that describes what the observations share. Labels describe the nature of the similarity, not just the subject area.

Good label: "Users invent workarounds because in-product tools are too rigid."  
Bad label: "Flexibility."

## Step 2.4 — Organize

If clusters naturally aggregate into larger groups (meta-themes), identify super-clusters. This is warranted when you have 15+ clusters and clear organizing logic emerges. Do not force super-clusters — flat structure is acceptable.

## Step 2.5 — Convert to themes

Convert each cluster (or super-cluster) into a theme using the thematic analysis naming rule: insight, not topic. These themes feed into the key findings in the synthesis document.
