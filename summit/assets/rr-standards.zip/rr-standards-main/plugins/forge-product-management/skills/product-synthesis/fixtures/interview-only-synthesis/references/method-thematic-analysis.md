# Thematic Analysis

Apply to: interview notes, open-ended survey responses, support tickets, usability notes.

## Step 1.1 — Familiarization

Read all material in full before labeling anything. Do not begin coding on first read. Note initial impressions, surprising observations, and apparent contradictions. These notes are working memory, not output.

## Step 1.2 — Initial coding

Re-read the material and label meaningful segments with descriptive codes. Codes should describe what is happening in the user's words or actions, not your interpretation yet. Examples of good codes: "confused by navigation after onboarding", "manually exports data to spreadsheet", "mentions approval process as blocker". One segment can carry multiple codes. Be exhaustive — over-coding is corrected in theme development, under-coding loses signal permanently.

## Step 1.3 — Theme development

Group codes into candidate themes. A theme requires at least 3 independent observations to be declared. An observation from the same participant in the same session counts as one, not three. Themes must be distinct — if two candidate themes consistently appear together in the same observations, they may be a single theme or one may be a sub-theme.

## Step 1.4 — Theme review

Check each candidate theme against the raw data:
- Does the supporting evidence actually support this theme, or did you read into it?
- Are any two themes describing the same underlying phenomenon?
- Is there evidence that contradicts this theme? Record contradictions — they are findings too.

Discard or merge themes that do not survive this check.

## Step 1.5 — Theme refinement

Name each theme as an insight, not a topic. The theme name should describe what you learned, not just what area it covers.

Bad theme names (topic): "onboarding", "notifications", "data export"  
Good theme names (insight): "PMs can't start without engineering help during onboarding", "notification volume trains users to ignore all alerts", "data export is a workaround for a missing in-product workflow"

## Step 1.6 — Document each theme

For every confirmed theme, record:
- **Name:** insight-form label
- **Definition:** one sentence describing what this theme means
- **Evidence:** minimum 2 quotes, observations, or data point references (use source IDs or line references)
- **Frequency:** number of independent participants or sources where this theme appeared
- **Impact:** high / medium / low — assessed effect on the user's ability to accomplish their goal
- **Confidence:** high / medium / low — strength of evidence (high = ≥5 independent sources, clearly supported; medium = 3–4 sources, some ambiguity; low = fewer than 3 sources or contradicted elsewhere)
