# Qual + Quant Integration

Apply when both qualitative and quantitative sources are present.

## 6.1 — The feedback loop

Qualitative and quantitative research are most powerful when they feed each other:
- **Qual generates hypotheses → quant tests them at scale.** If interviews suggest "users abandon because onboarding takes too long," check funnel data for the step where time-to-complete predicts drop-off.
- **Quant surfaces anomalies → qual explains why.** If analytics show 40% of users never return after their first session, interviews explain the experience driving that decision.

Before integrating, state which direction applies: "In this synthesis, qual is explaining a quant anomaly" or "quant is testing a qual hypothesis."

## 6.2 — Integration strategies

Choose the appropriate integration strategy based on what the data shows:

- **Confirmation:** qual and quant agree on both the finding and its magnitude. This is your highest-confidence signal. State: "Finding confirmed by both [qual source] and [quant source] — high confidence."
- **Expansion:** quant shows *what* is happening; qual explains *why*. State: "Analytics confirm [behavior] at scale ([n] users). Interviews explain this is because [mechanism]."
- **Discordance:** sources disagree — a pattern strong in interviews does not appear in analytics, or a metric anomaly has no corresponding qual explanation. Do not collapse this into a consensus. Follow the disagreement protocol from method-triangulation.md § 3.4.

## 6.3 — When sources disagree

Report the disagreement, identify the most likely explanation, and recommend a test to resolve it. Do not infer a consensus from disagreeing data. The disagreement itself is a finding: it means your mental model of user behavior is incomplete.
