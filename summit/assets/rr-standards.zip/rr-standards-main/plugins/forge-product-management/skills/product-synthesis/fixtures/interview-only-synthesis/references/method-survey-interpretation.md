# Survey Data Interpretation

Apply to: all quantitative survey data and mixed-method surveys with open-ended responses.

## 5.1 — Always report distributions, not averages

For every quantitative measure, report the full distribution before or instead of the average. A single number hides more than it reveals.

Example:
- Weak: "Average NPS: 32"
- Strong: "NPS: 40% promoters (9–10), 35% passives (7–8), 25% detractors (0–6). Net: +15 after segment normalization."

## 5.2 — Averages-without-distributions trap

This is a required check. Call it out explicitly whenever you encounter it in the data:

A satisfaction score of 3.0/5 could mean:
- (a) Every respondent gave a 3 — everyone is mildly neutral, and a moderate improvement might push most to 4.
- (b) Half gave 5 and half gave 1 — deeply split users, and an intervention that satisfies one group may alienate the other.

These two interpretations imply completely different product decisions. Always check the distribution before interpreting any average. If the raw distribution is not available, flag this as a data gap and recommend obtaining it before acting on the metric.

## 5.3 — Segmentation before reporting

Break all results by relevant user segments before reporting overall numbers. Segments to consider: user tenure (new / established), engagement level (high / medium / low activity), plan tier, geography, role/persona. Overall numbers often mask segment-level extremes that are more actionable.

Example: "Overall NPS is 32, but NPS for users in their first 30 days is -12, while users past 90 days are +58. The aggregate number obscures a severe new-user problem."

If segmentation data is unavailable, state: "Segmentation data not available — overall numbers may mask segment-level patterns. Recommend rerunning with user segment breakdowns."

## 5.4 — Open-ended survey responses

Apply thematic analysis (method-thematic-analysis.md) to open-ended responses. Do not count themes as a substitute for reading the responses. Theme frequency (number of respondents mentioning a theme) is useful for prioritization but is not the same as reading representative responses and understanding the full texture of each theme.

## 5.5 — Beware sampling bias

Survey respondents are not a random sample of your users. They are:
- More likely to be engaged users (lower engagement users don't complete surveys)
- More likely to have strong opinions (neutral users opt out)
- More likely to be power users (if triggered in-product)

State the known sampling method and its bias implications before interpreting results.
