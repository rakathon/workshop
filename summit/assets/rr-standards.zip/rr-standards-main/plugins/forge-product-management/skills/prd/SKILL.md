---
name: forge:prd
description: >
  Interviews a product manager question-by-question to produce a three-file PRD:
  prd.md (problem statement, goals, non-goals, success metrics, open questions,
  timeline), business.md (BR-N entries with explicit MoSCoW tiers and acceptance
  criteria), and user-stories.md (Connextra-format stories grouped by persona/theme
  with acceptance criteria). Works in both Forge-initialized repositories and plain
  directories (Claude Desktop / Cowork). Optionally seeds context from a product
  brief. Confirms each section before writing. Ends by surfacing a handoff to
  forge:elaborate for engineering requirements.
when_to_use: >
  Trigger on: "write the PRD", "create the PRD", "let's write the PRD", "I need a PRD",
  "draft the product requirements", "build out the requirements doc", "write requirements
  for this effort", "I want to document the problem and goals", "document what we're
  building", "create business requirements", "write user stories", "forge:prd", or any
  time a PM wants to produce structured effort-level requirements before engineering
  design begins.
agent-type: orchestrator
---

# forge:prd

Produces three requirement artifacts by interviewing the PM question-by-question,
confirming each section before writing, then handing off to `forge:elaborate` for
engineering requirements.

Output files, all written to `<effort_dir>/requirements/`:
- `prd.md` — problem statement, goals, non-goals, success metrics, open questions, timeline
- `business.md` — BR-N entries with explicit MoSCoW tiers and acceptance criteria
- `user-stories.md` — Connextra-format stories grouped by persona/theme

`prd.md` cross-references the other two files rather than duplicating their content.

---

## Step 0: Environment Detection and Effort Resolution

**0.1 — Load environment fragment**

Load `common/environment.md` and execute the detection check:

```
[ -d ".forge" ] && echo "forge" || echo "plain"
```

Set `env_mode = forge | plain`.

Then set path variables:

**Forge mode:**
```
products_root = .forge/products
efforts_root  = .forge/efforts
effort_file   = .forge/EFFORT
```

**Plain mode:**
```
products_root = .
efforts_root  = (not used)
effort_file   = (not used)
```

**0.2 — Resolve effort and set `effort_dir`**

**Forge mode:**

Check whether `.forge/EFFORT` exists and contains an effort ID.

- If present, read it to get `effort_id`. Set `effort_dir = .forge/efforts/<effort_id>/`.
- If absent, list available efforts by reading `.forge/efforts/README.md` (or listing
  `.forge/efforts/`). Ask the PM:
  > "Which effort should I write the PRD for? (e.g. `product-management`)"
  Set `effort_id` from their answer. Set `effort_dir = .forge/efforts/<effort_id>/`.
- If no efforts exist at all, stop immediately. Follow the error-handling instructions
  in `references/error-handling.md` ("No active effort — Forge mode").

**Plain mode:**

Ask the PM:
> "Which product are we writing the PRD for?"

Set `product_name` from their answer. Set `product_dir = <products_root>/<product_name>/`.

Check whether `product_dir` exists. If it does not exist, stop:
> "No product directory found for **<product_name>**. Run `/forge:product <product_name>`
> to register it first, then re-invoke this skill."

If it exists, set `effort_dir = <product_dir>`.

Do not reference `.forge/EFFORT`, `.forge/efforts/`, or `.state.json` in plain mode.

**0.3 — Read existing requirements (if any)**

Check whether any of the three output files already exist in `<effort_dir>/requirements/`.
Use the Read tool directly — do not show shell commands to the PM.

If `prd.md` already exists, read it and inform the PM:
> "I found an existing prd.md. I'll update it section by section. Any section you
> skip will keep its current content."

Also read `user-stories.md` if it exists to determine the highest US-N already assigned.

If none exist, proceed fresh.

**0.4 — Read effort context (Forge mode only)**

In Forge mode, read `.state.json` and any existing requirement files to understand
what has already been decided. Use the Read tool — do not show shell commands to the PM.

---

## Step 1: Optional — Load Product Brief

**1.1 — Check for product briefs**

Scan for product brief files that may seed context. Use the Read tool to list
`<products_root>/*/briefs/` — do not show shell commands to the PM.

If brief files exist, inform the PM:
> "I found the following product briefs that may be relevant:
> <list files>
> Should I use one of these as starting context for the PRD?"

If the PM confirms, read the chosen brief file in full before proceeding. Extract any
problem framing, goals, or personas already documented there — surface them to the PM
as candidate answers during the interview rather than pre-filling silently.

If no briefs exist or the PM declines, proceed with a blank slate.

---

## Step 2: Interview — Problem Statement

Ask these questions one at a time. Wait for the PM's answer before asking the next.
Do not batch multiple questions in one turn.

**Q1:**
> "What is the core problem we are solving? Describe it in 1–2 sentences: what is
> broken or missing, and who experiences it?"

**Q2:**
> "What evidence do we have that this problem is real? (e.g. customer research,
> support ticket volume, NPS data, revenue impact)"

**Q3:**
> "Who is the primary user or customer segment affected?"

After receiving all three answers, synthesize them into a draft problem statement
(1–2 paragraphs). Show it to the PM:
> "Here is the draft problem statement:
>
> ---
> <draft>
> ---
>
> Does this capture the problem correctly, or would you like to adjust anything?"

Incorporate feedback and confirm before moving on.

---

## Step 3: Interview — Goals

**Q4:**
> "What are the 3–5 goals this effort must achieve? Each goal should be specific and
> falsifiable — something we could measure and declare 'done' or 'not done'."

The PM must provide at least 3 goals. If they give fewer, ask:
> "Can you give me at least one more goal? Ideally we have 3–5 measurable goals."

For each goal the PM gives, ask:
> "How would we measure that goal? What number or threshold would tell us we succeeded?"

After collecting 3–5 goals with measurements, show the drafted list:
> "Here are the goals:
>
> 1. <goal> — measured by <metric/threshold>
> 2. <goal> — measured by <metric/threshold>
> ...
>
> Does this look right?"

If the PM provides fewer than 3 goals and declines to add more, follow the
error-handling instructions in `references/error-handling.md` ("Fewer than 3 goals").

Confirm before continuing.

---

## Step 4: Interview — Non-Goals (Required, Minimum 3)

This section is mandatory. The non-goals list must not be empty.

**Q5:**
> "What is explicitly out of scope for this effort? Non-goals help the team stay
> focused and prevent scope creep. Let me suggest some candidates based on what
> you've told me so far, and you can confirm or replace them."

Surface at least 3 candidate non-goals derived from the problem statement and goals.
Use the pattern: "We are not doing X because Y." For example:
> "Candidate non-goals:
>
> 1. We are not building a self-serve admin UI — because operational tooling is out of
>    scope for v1 and would add significant delivery risk.
> 2. We are not migrating legacy data — because data migration is a separate effort
>    with its own dependencies.
> 3. We are not supporting mobile-native clients — because the initial target persona
>    uses web only.
>
> Do these match your intent? Add, remove, or rewrite any of them."

Collect the PM's confirmed list. If the PM tries to confirm fewer than 3, follow the
error-handling instructions in `references/error-handling.md` ("Fewer than 3 non-goals").

Confirm the final list before continuing.

---

## Step 5: Interview — Success Metrics

**Q6:**
> "What leading indicators will tell us early that we are on track? (e.g. weekly
> active users of a new feature, error rate dropping, conversion rate in a funnel step)"

**Q7:**
> "What lagging indicators will confirm final success? (e.g. 30-day retention,
> quarterly revenue attributed to this feature, NPS improvement at 90 days)"

Show the combined metrics list:
> "Here are the success metrics:
>
> **Leading indicators (early signal):**
> - <metric>
>
> **Lagging indicators (final outcome):**
> - <metric>
>
> Does this cover how we will know this effort succeeded?"

Confirm before continuing.

---

## Step 6: Interview — Open Questions

**Q8:**
> "What questions still need to be answered before or during implementation? List
> anything unresolved — technical unknowns, design decisions, legal reviews, data
> requirements."

For each question the PM gives, ask:
> "Who owns answering this — engineering, design, legal, or data? And when does it
> need to be resolved by?"

Format each question as:
```
- <Question text> [owner: <eng/design/legal/data>] [due: <date or milestone>]
```

If the PM has no open questions, prompt:
> "Are you confident there are no unresolved decisions in engineering (e.g. tech
> feasibility), design (e.g. UX patterns), legal (e.g. compliance obligations), or
> data (e.g. tracking plan approved)?"

Accept "none confirmed" only after this check.

---

## Step 7: Interview — Timeline and Dependencies

**Q9:**
> "What is the target delivery date or milestone for this effort?"

**Q10:**
> "Are there any blocking dependencies — other teams, external systems, or preceding
> efforts that must complete before this one can ship?"

Show the draft timeline section:
> "Timeline / Dependencies:
>
> - Target: <date/milestone>
> - Dependencies: <list or 'None identified'>
>
> Does this look correct?"

Confirm before continuing.

---

## Step 8: Interview — Business Requirements

**Q11:**
> "Let's capture the business requirements. What must the system do to deliver on
> the goals we just defined? List each capability or behavior the system must have."

Collect the full list of capabilities from the PM, then process each one in turn:

For each requirement, assign the next available BR-N number (starting at BR-1 if none
exist, or continuing from the last BR in an existing business.md). Then ask:
> "Is BR-<N> a P0 (must have for v1 launch), P1 (high value, include if capacity
> allows), or P2 (nice to have, can defer)?"

Then ask:
> "What are 2–3 acceptance criteria for BR-<N> — specific, testable conditions that
> confirm it is done?"

After collecting all requirements, show the full list:
> "Here are the business requirements:
>
> **BR-1: <title>** (P0)
> <statement>
> AC: <criteria>
>
> **BR-2: <title>** (P1)
> ...
>
> Does this cover everything the system must do? Any missing capabilities?"

Confirm before writing.

---

## Step 9: Interview — User Stories

**Q12:**
> "Who are the primary personas who will use this? List 2–4 user types."

For each persona:
> "What is the most important thing <persona> needs to do with this feature, and
> why do they need it?"

Generate Connextra-format stories from the PM's answers:
> "As a <persona>, I want <action>, so that <outcome>."

For each story, ask:
> "What are 2–3 acceptance criteria for this story — testable conditions that
> confirm the story is delivered?"

Check independence: if any two stories cannot be tested without each other, propose
splitting or sequencing them:
> "Story US-<N> and US-<M> seem coupled. Let me suggest splitting US-<N> into
> two smaller, independently testable stories."

US-N numbers must be globally unique within the file. If `user-stories.md` already
exists, continue numbering from the highest US-N already present.

Group stories by persona or theme. After collecting all stories, show the grouped list
and confirm:
> "Here are the user stories, grouped by persona. Does this look right? Any missing
> scenarios?"

Confirm before writing.

---

## Step 10: Write the Three Files

Write each file only after its section has been confirmed. Write all three files
before surfacing the handoff. Use the Write tool directly — do not show shell
commands to the PM.

**10.1 — Write `requirements/prd.md`**

Read the template from `references/template-prd.md`. Substitute all placeholders with
the PM's confirmed answers. Write to: `<effort_dir>/requirements/prd.md`

**10.2 — Write `requirements/business.md`**

Read the template from `references/template-business.md`. Repeat the BR block for
each requirement. Write to: `<effort_dir>/requirements/business.md`

Rules:
- Every BR-N entry must carry an explicit `**Priority:**` line. No entry may be left untiered.
- If a `business.md` already exists with PM-authored BR-N entries, append new entries only.
  Do not modify existing BR-N text or priority tiers. Follow guidance in
  `references/error-handling.md` ("File write conflict") if a conflict is detected.

**10.3 — Write `requirements/user-stories.md`**

Read the template from `references/template-user-stories.md`. Repeat the group/story
block for each persona. Write to: `<effort_dir>/requirements/user-stories.md`

Rules:
- Stories must be grouped by persona or theme — not listed flat.
- US-N numbers must be globally unique within the file.
- Each story must be independently testable. If a story cannot be tested without
  another story being complete first, it must be split before writing.

---

## Step 11: Confirm and Summarize

After all three files are written, confirm to the PM. Use the correct identifier for
the mode:

**Forge mode** — use `effort_id`:
> "The PRD for **<effort_id>** is complete. Three files written:
>
> - `<effort_dir>/requirements/prd.md`
> - `<effort_dir>/requirements/business.md`
> - `<effort_dir>/requirements/user-stories.md`
>
> **Summary:**
> - Goals: <N> measurable goals defined
> - Non-goals: <N> explicit non-goals confirmed
> - Business requirements: <N> BR-N entries (<N> P0, <N> P1, <N> P2)
> - User stories: <N> stories across <N> personas
> - Open questions: <N> (owners: <list owners>)
>
> **Next step:** Run `forge:elaborate` to deepen the engineering requirements.
> forge:elaborate will read business.md and add technical requirements (TR-N),
> ADRs, and storage/API/messaging specs — without modifying the PM-authored BRs
> or their MoSCoW tiers."

**Plain mode** — use `product_name`:
> "The PRD for **<product_name>** is complete. Three files written:
>
> - `<effort_dir>/requirements/prd.md`
> - `<effort_dir>/requirements/business.md`
> - `<effort_dir>/requirements/user-stories.md`
>
> **Summary:**
> - Goals: <N> measurable goals defined
> - Non-goals: <N> explicit non-goals confirmed
> - Business requirements: <N> BR-N entries (<N> P0, <N> P1, <N> P2)
> - User stories: <N> stories across <N> personas
> - Open questions: <N> (owners: <list owners>)
>
> **Next step:** Share these files with your engineering team, or run `forge:elaborate`
> to deepen the engineering requirements."

---

## Error Handling

See `references/error-handling.md` for full error-handling procedures, including:
- No active effort (Forge mode) / no product directory (plain mode)
- Fewer than 3 goals
- Fewer than 3 non-goals
- File write conflict (existing PM-authored BRs)
- PM interrupts mid-session
