# forge:prd

Interviews a product manager question-by-question to produce three requirement
artifacts, then hands off to `forge:elaborate` for engineering requirements. Works
in both Forge-initialized repositories and plain directories (Claude Desktop / Cowork).

---

## What It Does

`forge:prd` walks a PM through a structured interview — one question at a time —
collecting problem statement, goals, non-goals, success metrics, open questions,
timeline, business requirements, and user stories. Each section is shown to the PM
for confirmation before anything is written to disk.

In **Forge mode** (a `.forge/` directory is present), all three output files are
written under `.forge/efforts/<effort-id>/requirements/`.

In **plain mode** (no `.forge/` directory — e.g. Claude Desktop or Cowork), output
files are written under `<product-name>/requirements/` relative to the working
directory.

If a product brief exists under the product's `briefs/` directory, the skill can
optionally seed context from it before the interview begins.

If any of the three output files already exist, the skill resumes from where it left
off — confirmed sections are skipped, existing BR-N entries are never overwritten.

---

## Usage

```
forge:prd
```

No arguments required. In Forge mode, the skill resolves the active effort from
`.forge/EFFORT` automatically. If no effort is active, it lists available efforts and
asks which one to target. In plain mode, the skill asks: "Which product are we
writing the PRD for?"

---

## When to Use

- Writing a PRD for a new Forge effort before engineering design begins
- Writing a PRD in Claude Desktop or Cowork without a git repo
- Adding or updating business requirements for an in-progress effort
- Writing user stories for a PM-authored effort
- Any time a PM says "write the PRD", "I need a PRD", "create business requirements",
  "write user stories", "draft the product requirements", or "forge:prd"

---

## Prerequisites

- A product directory created with `forge:product` (required in both modes)
- **Forge mode only:** A Forge repository initialized with `.forge/` and an active
  Forge effort created with `forge:effort` (or one selected during the skill)
- **Plain mode:** No additional prerequisites beyond the product directory

---

## Output Artifacts

All three files are written to `<effort_dir>/requirements/` (where `effort_dir` is
`.forge/efforts/<effort-id>/` in Forge mode, or `<product-name>/` in plain mode):

| File | Contents |
|------|----------|
| `prd.md` | Problem statement, goals (3–5 measurable), non-goals (minimum 3), success metrics (leading and lagging indicators), open questions with owners and due dates, timeline and dependencies. Cross-references `business.md` and `user-stories.md` rather than duplicating their content. |
| `business.md` | BR-N entries with explicit MoSCoW priority tiers (P0/P1/P2) and 2–3 acceptance criteria per requirement. |
| `user-stories.md` | Connextra-format stories ("As a … I want … so that …") grouped by persona or theme, each with 2–3 testable acceptance criteria. US-N numbers are globally unique within the file. |

---

## Interview Structure

The skill asks questions in this order and waits for a PM answer before proceeding:

1. **Problem Statement** — core problem, supporting evidence, affected user segment
2. **Goals** — 3–5 specific, falsifiable goals with measurable thresholds
3. **Non-Goals** — at least 3 explicit out-of-scope items (required; the skill will
   not proceed with fewer than 3 confirmed)
4. **Success Metrics** — leading indicators (early signal) and lagging indicators
   (final outcome)
5. **Open Questions** — unresolved decisions with owner and due date
6. **Timeline and Dependencies** — target date/milestone and blocking dependencies
7. **Business Requirements** — system capabilities mapped to MoSCoW tiers with
   acceptance criteria
8. **User Stories** — personas, actions, outcomes, and acceptance criteria

---

## Relationship to Other Skills

| Skill | Relationship |
|-------|-------------|
| `forge:effort` | In Forge mode, must be run first to create the effort that `forge:prd` writes into. Not required in plain mode. |
| `forge:elaborate` | Runs after `forge:prd` — reads `business.md` to add technical requirements (TR-N), ADRs, and storage/API/messaging specs without modifying PM-authored BRs or their priority tiers |
| `forge:product-strategy` | Works at the product level above efforts; `forge:prd` works within a single effort |
| `forge:product` | Creates the product directory that holds briefs `forge:prd` can optionally seed from |
| `forge:validate` | Validates discovery artifacts (including the requirements files written by `forge:prd`) before promoting to planning |
