# Business Requirements: Loyalty Program v2

*Effort ID: loyalty-v2*
*Last updated: 2026-05-01*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained
-->

---

## BR-1: Partner Merchant Redemption

**Priority:** P0

The system must allow members to redeem loyalty points at any integrated partner
merchant during the online checkout flow.

**Acceptance Criteria:**
- [ ] A member can select "Pay with points" at checkout on a partner merchant site
- [ ] The points balance is deducted in real time upon successful redemption
- [ ] A confirmation receipt is sent to the member's registered email

---

## BR-2: Redemption History

**Priority:** P1

The system must show members a chronological history of all partner redemptions.

**Acceptance Criteria:**
- [ ] Redemption history is accessible from the member dashboard within 2 clicks
- [ ] Each entry shows merchant name, points redeemed, date, and order reference
