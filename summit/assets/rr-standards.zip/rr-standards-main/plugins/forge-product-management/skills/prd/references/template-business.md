# Business Requirements: <Effort Title>

*Product / Effort: <product_name_or_effort_id>*
*Last updated: <YYYY-MM-DD>*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained
-->

---

## BR-1: <Short Title>

**Priority:** P0

<Requirement statement — one or two sentences describing what the system must do.>

**Acceptance Criteria:**
- [ ] <measurable, testable criterion>
- [ ] <measurable, testable criterion>

---

## BR-2: <Short Title>

**Priority:** P1

<Requirement statement.>

**Acceptance Criteria:**
- [ ] <measurable, testable criterion>
- [ ] <measurable, testable criterion>
