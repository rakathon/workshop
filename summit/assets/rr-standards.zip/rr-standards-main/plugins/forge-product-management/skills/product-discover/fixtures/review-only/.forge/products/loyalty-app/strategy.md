# Product Strategy: Loyalty App

## Desired Outcome
Increase 90-day member retention from 42% to 55%

## Strategic Pillars
1. Reduce friction in the points redemption experience
2. Increase member awareness of program value before points expire
