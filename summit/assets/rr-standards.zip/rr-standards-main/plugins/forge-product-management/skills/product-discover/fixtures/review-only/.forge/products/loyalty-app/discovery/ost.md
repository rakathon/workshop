## Desired Outcome
Increase 90-day member retention from 42% to 55%

## Opportunities
### OPP-1: Members don't understand point expiration rules
Members frequently discover their points have expired only after attempting to redeem them.
**Source:** interviews/2026-04-10-loyalty-member-onboarding.md
**Status:** Validated

#### Solutions
- SOL-1a: Proactive expiration warning email 30 days in advance

#### Assumption Tests
- AT-1a: Members want expiration warnings → see assumptions.md#AT-1a
- AT-1b: Email open rates are high enough → see assumptions.md#AT-1b
