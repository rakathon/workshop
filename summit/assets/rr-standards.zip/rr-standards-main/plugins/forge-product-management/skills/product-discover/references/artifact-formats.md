# Artifact Formats — forge:product-discover

Reference file for the exact file formats used when writing discovery artifacts.
Load this file only when executing Step 6 (Write Artifacts).

---

## ost.md

Write `<discovery_dir>/ost.md` using this exact structure:

```markdown
## Desired Outcome
<The north star metric or outcome the team is working toward>

## Opportunities
### OPP-1: <Opportunity title>
<Description: what customer problem or unmet need is this?>
**Source:** <interview IDs or research that surfaced this>
**Status:** Validated / Emerging / Invalidated

#### Solutions
- SOL-1a: <Solution idea>
- SOL-1b: <Solution idea>

#### Assumption Tests
- AT-1a: <What assumption does this test?> → see assumptions.md#AT-1a
```

Rules:
- Do not delete invalidated opportunities. Mark them `**Status:** Invalidated` and
  append a rationale note: `**Invalidated because:** <reason>`.
- Preserve all existing opportunity IDs unchanged.
- Append new opportunities after existing ones.
- Update solutions and assumption test links in place for existing opportunities.

---

## assumptions.md

Write `<discovery_dir>/assumptions.md` using this exact entry format:

```markdown
## AT-<id>: <Assumption title>

**Related opportunity:** OPP-<id>
**Type:** Desirability / Feasibility / Viability
**Risk level:** High / Medium / Low
**Test status:** Untested / In Progress / Validated / Invalidated
**Confidence:** <0–100%>
**Test design:** <How will this be tested? What would falsify it?>
**Result:** <Filled in after test runs>
```

Rules:
- Never delete assumption entries. If an assumption is disproved, set
  `**Test status:** Invalidated` and fill in `**Result:**` with findings.
- Preserve existing AT-<id> values.
- Append new assumptions after existing ones.
- Update test status, confidence, and result in place for existing assumptions.

---

## Interview Snapshot

Name: `<discovery_dir>/interviews/<YYYY-MM-DD>-<description>.md`

Use today's date for YYYY-MM-DD. Derive a 2–4 word description from the participant
role and topic (e.g., `2026-05-28-loyalty-user-checkout.md`).

Write the file using this exact structure:

```markdown
# Interview: <date> — <description>

## Participant
<Role, not name — e.g., "Loyalty program member, 2 years active, mobile-primary">

## Context
<What was the participant trying to accomplish? What prompted the conversation?>

## Key Observations
<Behaviors observed, not just stated preferences. Use quotes for direct speech.>
- <Observation 1>
- <Observation 2>

## Signals of Intensity
<What did the participant feel strongly about? What caused visible frustration or delight?>
- <Signal 1>

## OST Implications
<Which opportunities does this support or challenge? Reference by OPP-id.>
- OPP-<id>: <how this changes our view of the opportunity>
```

Rules:
- Existing interview files are never modified after creation.
- Each invocation adds a new file only if new interview input was provided.
- No interview file is added for review-only runs.
