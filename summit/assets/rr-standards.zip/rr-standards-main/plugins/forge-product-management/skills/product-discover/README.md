# forge:product-discover

Runs the Torres Continuous Discovery Habits (CDH) loop for a product — outcome
definition, opportunity mapping, OST maintenance, assumption logging, and test
design. Synthesizes qualitative insight from direct customer contact: interviews,
usability sessions, and field observations.

This is a recurring skill. Each invocation reads existing artifacts, incorporates
new input, updates artifacts in place, and surfaces a change summary.

---

## Usage

```
forge:product-discover
forge:product-discover <product-name>
```

Accepts session input in any of the following forms:

- Interview notes or transcript — pasted inline or as a file path
- Usability session notes — pasted inline or as a file path
- Field observation notes — pasted inline or as a file path
- A URL to a research document (fetched automatically)
- An outcome update — a change to the north star metric
- A new solution hypothesis
- An assumption test result from a prior experiment

---

## When to Use

- After any customer interview, usability session, or field observation
- To record the outcome of an assumption test
- To update the Opportunity Solution Tree with new signals
- To review the current state of discovery without adding new input
- When a PM says "run discovery", "update the OST", "I talked to customers",
  "add interview notes", "validate an assumption", "design an experiment",
  or "forge:product-discover"

---

## Prerequisites

- Product directory created by `forge:product` — run it first if the directory
  does not exist
- **Forge mode** (`.forge/` exists): product directory is `.forge/products/<product-name>/`
- **Plain mode** (no `.forge/`, e.g. Claude Desktop / Cowork): product directory is
  `./<product-name>/` in the current working directory

A Forge-initialized repository is **not** required. The skill detects the environment
automatically and adjusts all paths and prompts accordingly.

A strategy document (`strategy.md`) is **not** required. The skill is
lifecycle-aware: if no strategy exists it enters pre-strategy mode and surfaces
a handoff to `forge:product-strategy` at the end of the session. If a strategy
exists it reads the current desired outcome and confirms it before proceeding.

---

## Output Artifacts

All artifacts are written under `<product-dir>/discovery/` (`.forge/products/<product-name>/discovery/`
in Forge mode; `./<product-name>/discovery/` in plain mode):

| File | Purpose |
|------|---------|
| `ost.md` | Opportunity Solution Tree — desired outcome, opportunities (OPP-N), solutions (SOL-Na), and assumption test links |
| `assumptions.md` | Assumption Log — all assumptions (AT-N) with type, risk level, confidence, test design, and result |
| `interviews/<YYYY-MM-DD>-<description>.md` | Per-session snapshot — participant context, key observations, signals of intensity, and OST implications |

### Notes on artifact behavior

- `ost.md` and `assumptions.md` are updated in place on each invocation.
  Existing IDs (OPP-N, SOL-Na, AT-N) are never changed or deleted — invalidated
  entries are marked with a status and rationale, not removed.
- Interview snapshots are append-only. Each session with new input adds one new
  file; existing files are never modified.
- No files are written on review-only runs (invoked with no new input).

---

## Re-invocation Behavior

`forge:product-discover` is designed to be run repeatedly as new customer learning
arrives. On each invocation:

1. All existing artifacts are read from disk before accepting new input.
2. New interview or observation input is additive — it does not replace prior
   sessions.
3. Opportunity and assumption IDs are preserved across runs.
4. If no new input is provided, the skill runs a validation check and change
   summary without modifying any files.

The skill does not maintain a session state file between invocations. Each run
is self-contained.

---

## Relationship to Other Skills

| Skill | Relationship |
|-------|-------------|
| `forge:product` | Creates the product directory that `forge:product-discover` writes into — run first |
| `forge:product-strategy` | Translates validated discovery insight into a formal strategy with diagnosis, pillars, and roadmap. Surfaced by this skill in pre-strategy mode |
| `forge:product-brief` | Scopes a validated opportunity into an initiative. Surfaced by this skill when an opportunity meets the validation threshold |
| `forge:product-synthesis` | Handles structured, multi-source data (surveys, analytics, support ticket corpora). If structured data is provided to `forge:product-discover`, the skill redirects to `forge:product-synthesis` |
