## AT-1a: Members want expiration warnings

**Related opportunity:** OPP-1
**Type:** Desirability
**Risk level:** High
**Test status:** Validated
**Confidence:** 85%
**Test design:** Survey 50 members — ask if they would opt in to expiration alerts
**Result:** 82% of surveyed members said they would opt in to expiration alerts

## AT-1b: Email open rates are high enough to drive behavior change

**Related opportunity:** OPP-1
**Type:** Feasibility
**Risk level:** High
**Test status:** Validated
**Confidence:** 78%
**Test design:** A/B test expiration warning emails — measure open and click-through rates
**Result:** Pilot email sent to 500 members achieved 34% open rate and 12% click-through; sufficient to drive meaningful engagement
