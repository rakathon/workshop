---
name: forge:product-discover
description: >
  Runs the Torres Continuous Discovery Habits (CDH) loop for a product: outcome
  definition, opportunity mapping, OST maintenance, assumption logging, and test
  design. Synthesizes qualitative insight from direct customer contact — interviews,
  usability sessions, and field observations. Recurring — re-invoke as new learning
  arrives; subsequent runs update existing artifacts in place and add new interview
  snapshots. Lifecycle-aware: on first run (no strategy.md) surfaces a handoff to
  forge:product-strategy; on ongoing runs surfaces forge:product-brief when an
  opportunity is sufficiently validated.
when_to_use: >
  Trigger on: "run discovery", "update the OST", "I did some customer interviews",
  "let's do discovery", "add interview notes", "update assumptions", "map opportunities",
  "I talked to customers", "validate an assumption", "design an experiment",
  "forge:product-discover", or any time a PM wants to record and synthesize customer
  insight into a structured Opportunity Solution Tree.
argument-hint: "[product-name]"
arguments: [product_name]
agent-type: orchestrator
---

# forge:product-discover

Runs the full Torres Continuous Discovery Habits (CDH) loop for a product, producing
and maintaining three artifacts: `discovery/ost.md` (Opportunity Solution Tree),
`discovery/assumptions.md` (Assumption Log), and per-session interview snapshots under
`discovery/interviews/`.

This is a recurring skill. Every invocation reads existing artifacts, incorporates new
input, updates artifacts in place, and surfaces a change summary. Sessions can be
interrupted — no partial writes occur until confirmed content is ready.

**Artifact formats** (exact file structures for ost.md, assumptions.md, and interview
snapshots) are in `references/artifact-formats.md`. Load that file before executing
Step 6.

---

## Execution Paths

Three distinct execution paths exist. Determine which applies in Step 0:

| Path | Condition | Steps executed |
|------|-----------|----------------|
| **First run** | No discovery artifacts exist yet | 0 → 1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 |
| **Subsequent run** | Existing artifacts found, new input provided | 0 → 1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 |
| **Review-only** | Existing artifacts found, no new input | 0 → 1 → 5 → 7 (no file writes) |

---

## Step 0: Environment Detection and Product Resolution

**0.0 — Load environment detection**

Load `skills/common/environment.md`. Execute the detection check:

```
[ -d ".forge" ] && echo "forge" || echo "plain"
```

Set `env_mode = forge | plain`.

Set path variables based on `env_mode`:

- **Forge mode:** `products_root = .forge/products`, `efforts_root = .forge/efforts`, `effort_file = .forge/EFFORT`
- **Plain mode:** `products_root = .` (no `efforts_root` or `effort_file`)

**0.1 — Resolve product directory**

If a product name was provided as an argument, use it directly. Otherwise:

- **Forge mode:** Check for `<effort_file>` — if present, read it to find the active effort
  and infer the product from the effort's product association. If still unresolved, list
  all directories under `<products_root>` and ask:
  > "Which product are we running discovery for?"
- **Plain mode:** List all directories under `<products_root>` and ask directly:
  > "Which product are we running discovery for?"
  Do not reference `.forge/EFFORT` or effort IDs in plain mode.

Set `product_dir = <products_root>/<product_name>`.
Set `discovery_dir = <product_dir>/discovery`.

**Existence check:** If `<product_dir>` does not exist, stop and tell the PM:
> "No product directory found for **<product_name>**. Run `/forge:product <product_name>`
> to register it first, then re-invoke this skill."

Do not create the directory. Do not proceed.

**0.2 — Determine lifecycle position**

Check whether `<product_dir>/strategy.md` exists.

- **Absent** → `lifecycle = pre-strategy`. Note this for the handoff message in Step 8.
- **Present** → `lifecycle = ongoing`. Read the strategy.md `## Desired Outcome` section
  to confirm the current north star metric. Surface it to the PM:
  > "Running discovery against the current outcome: **<outcome>**. Is that still the right
  > target, or has it changed?"
  If changed, record the new outcome. Update `ost.md` in Step 3.

**0.3 — Check for existing discovery artifacts and determine execution path**

Check whether the following exist:
- `<discovery_dir>/ost.md`
- `<discovery_dir>/assumptions.md`
- `<discovery_dir>/interviews/` (directory)

**If none exist** → `path = first-run`. Set `has_existing = false`. Tell the PM:
> "This is the first discovery session for **<product_name>** — no existing OST or
> assumptions found. I'll gather your customer insight and define a desired outcome
> with you before writing any files."
Proceed to Step 1.

**If any exist** → `has_existing = true`. Read all existing files:
1. Read `<discovery_dir>/ost.md`
2. Read `<discovery_dir>/assumptions.md`
3. List all files in `<discovery_dir>/interviews/` and read the three most recent
   (newest by filename date).

Inform the PM:
> "I've loaded your existing OST with <N> opportunities and <M> assumptions.
> The most recent interview was <date>. What new input do you have for this session?"

If the PM has no new input, set `path = review-only`. If they provide input, set
`path = subsequent-run`.

---

## Step 1: Gather Session Input

Ask the PM what prompted this discovery session. Accept any combination of:

- **Interview notes or transcript** — paste directly or provide a file path
- **Usability session notes** — paste or file path
- **Field observation notes** — paste or file path
- **Outcome update** — a change to the north star metric
- **New solution hypothesis** — an idea the PM wants to test
- **Assumption test result** — the outcome of a prior experiment

If a file path is provided: read the file.
If a URL is provided: fetch via WebFetch.
If pasted inline: accept as text.

**Review-only path:** If the PM has no new input (confirmed in Step 0.3 or stated now):
> "Understood — I'll present a summary of the current OST and flag any assumptions
> that are overdue for testing."
Skip to Step 5. Do not execute Steps 2–4.

Ask whether there is a specific opportunity or assumption to focus on, or whether
this is an open synthesis session.

---

## Step 2: Define or Confirm the Desired Outcome

**First run — `lifecycle = pre-strategy` and no outcome in `ost.md`:**

Ask:
> "What measurable outcome is this team trying to move? Think of this as your north
> star metric for this discovery cycle — the customer behavior or business result that
> would tell you the team succeeded."

Guide toward a specific, measurable statement:
- Good: "Increase 90-day retention from 42% to 55%"
- Poor: "Improve the user experience"

If the PM gives a vague outcome, restate it in measurable terms and confirm:
> "Let me restate that as a measurable outcome: [restatement]. Does that capture it?"

Do not advance until the PM confirms the outcome statement.

**Subsequent run — outcome already exists:**

If the PM confirmed the outcome in Step 0.2, carry it forward unchanged unless the PM
explicitly changed it. If changed: note the old and new values, and update `ost.md`
in Step 3 with a rationale note on the change.

---

## Step 3: Map Opportunities

Work through the session input gathered in Step 1. For each piece of input, extract
customer problems and unmet needs that could move the desired outcome.

**3.1 — Opportunity extraction**

For each observation or quote, ask:
- What job was the customer trying to do?
- What got in their way?
- What would success look like for them?

Generate candidate opportunities from the answers. An opportunity is a customer problem
or unmet need, not a solution. Restate any solution-framed input as a problem:
- Solution-framed: "Customers want a faster checkout button"
- Opportunity-framed: "Customers abandon purchase flows when the final step is unclear"

Present each candidate opportunity to the PM:
> "I found this opportunity: **[title]** — [description].
> Does this capture the customer problem, or should we restate it?"

Confirm each opportunity before adding it to the tree.

**3.2 — Assign opportunity IDs and statuses**

For existing opportunities (subsequent run): use the existing IDs from `ost.md`.
For new opportunities: assign the next available `OPP-N` ID.

Assign a status based on evidence:
- **Emerging** — surfaced by one or two signals, not yet triangulated
- **Validated** — multiple independent sources confirm the problem exists and matters
- **Invalidated** — evidence shows the problem is not real or does not affect the outcome

**3.3 — Solution branches**

For each opportunity, ask whether the PM has any solution ideas:
> "Do you have any solution hypotheses for **OPP-<id>**? You don't need them now —
> we can always add them later."

If solutions are provided: add them as `SOL-<id><letter>` entries under the opportunity.
If none: leave the solutions list empty. Do not add solutions the PM has not confirmed.

---

## Step 4: Update the Assumption Log

For each solution added or updated in Step 3, surface the riskiest underlying assumptions.

**4.1 — Assumption elicitation**

For each solution, ask:
> "For **SOL-<id>**: what would have to be true for this to work? What are you
> most uncertain about?"

Guide the PM to identify assumptions across three types:
- **Desirability** — do customers actually want this?
- **Feasibility** — can the team build it?
- **Viability** — will it work as a business?

**4.2 — Risk assessment**

For each assumption, ask the PM to rate:
- **Risk level** (High / Medium / Low): how bad is it if this assumption is wrong?
- **Confidence** (0–100%): how confident are you this assumption is true right now?

A High-risk, Low-confidence assumption is the top priority for testing.

**4.3 — Test design**

For each new assumption, design a lightweight test:
> "How could we test this assumption in the next two weeks without building the full
> solution? What result would tell you the assumption is false?"

Record the test design as part of the assumption entry.

**4.4 — Update existing assumptions (subsequent run only)**

For any existing assumptions in `assumptions.md` that relate to new evidence:
1. Update the test status if an experiment ran.
2. Update the confidence score based on new evidence.
3. Record the result if the test is complete.
4. Change status to Invalidated if evidence disproves the assumption — never delete.

---

## Step 5: Validation Check

Scan ALL opportunities (including those on the review-only path) for handoff readiness.

An opportunity is sufficiently validated when:
- Its status is **Validated**
- All High-risk assumptions linked to it have test status **Validated** or **Invalidated**
- Confidence on remaining Desirability assumptions is ≥ 70%

For each qualifying opportunity, surface this message — on every path, including review-only:
> "OPP-<id> looks sufficiently validated. All high-risk assumptions are resolved and
> customer evidence is triangulated. Consider running `forge:product-brief` to scope
> this into an initiative."

Do not automatically invoke `forge:product-brief`. The PM decides when to act.

For the **review-only path**, also:
1. Flag assumptions that are overdue for testing: Untested, High-risk assumptions.
2. Provide a brief OST health summary — count of opportunities by status, count of
   assumptions by test status.

---

## Step 6: Write Artifacts

**Load `references/artifact-formats.md` now** — it contains the exact file structures
required for ost.md, assumptions.md, and interview snapshots.

Write all changes to disk **only after**:
1. The PM has confirmed the desired outcome (Step 2)
2. Each new opportunity has been confirmed individually (Step 3)
3. You have presented the full change summary to the PM and they have agreed

Do not write any files during Steps 0–5. This step is skipped entirely on the
review-only path — no files are modified on a review-only run under any circumstances.

**6.1 — Ensure directory structure**

Use the Write tool to create files in `<discovery_dir>` and `<discovery_dir>/interviews/`.
The Write tool creates parent directories automatically — do not instruct the PM to run
shell commands.

**6.2 — Write or update ost.md**

Write `<discovery_dir>/ost.md` using the format in `references/artifact-formats.md`.

**6.3 — Write or update assumptions.md**

Write `<discovery_dir>/assumptions.md` using the format in `references/artifact-formats.md`.

**6.4 — Create interview snapshot (if new input was provided)**

If the session included new interview or usability session input from Step 1, create
a new snapshot file using the format in `references/artifact-formats.md`.

---

## Step 7: Surface Change Summary

After writing all artifacts (or after Step 5 on a review-only run), present a concise
change summary to the PM:

> "Discovery updated:
> - <N> opportunities updated (IDs: OPP-x, OPP-y)
> - <N> new opportunities added (IDs: OPP-z)
> - <N> assumptions moved to Validated
> - <N> new assumptions logged
> - <N> interview snapshots added
> [If opportunities are sufficiently validated: listed handoff suggestions from Step 5]"

For review-only runs:
> "Discovery review complete (no changes written):
> - <N> opportunities on file (status breakdown: <N> Validated, <N> Emerging, <N> Invalidated)
> - <N> assumptions on file (<N> Untested, <N> In Progress, <N> Validated, <N> Invalidated)
> [Overdue assumptions flagged: AT-<id>, ...]"

---

## Step 8: Lifecycle Handoff

**Pre-strategy lifecycle:**

If `lifecycle = pre-strategy`:
> "Your Opportunity Solution Tree is taking shape. When you have enough signal on your
> top opportunities, consider running `forge:product-strategy` to translate this insight
> into a formal strategy with diagnosis, pillars, and a roadmap."

Do not suggest `forge:product-brief` in pre-strategy mode — a strategy must exist first.

**Ongoing lifecycle:**

If `lifecycle = ongoing` and no opportunities were flagged in Step 5:
> "Discovery artifacts updated. Re-invoke `forge:product-discover` after your next round of
> customer conversations to keep the OST current."

If opportunities were flagged in Step 5, repeat a brief reminder:
> "Reminder: OPP-<id> is ready for scoping. Run `forge:product-brief` when you're
> ready to turn it into an initiative."

---

## Boundary with forge:product-synthesis

`forge:product-discover` synthesizes qualitative insight from direct customer contact:
interviews, usability sessions, and field observations.

`forge:product-synthesis` synthesizes structured, multi-source data sets: surveys,
market reports, support ticket corpora, and analytics data.

If the PM provides a structured data artifact (CSV export, analytics report, survey
results), redirect:
> "This looks like structured research data rather than a direct customer conversation.
> Consider running `forge:product-synthesis` to analyze it — the output can feed back
> into this OST as a source reference."
