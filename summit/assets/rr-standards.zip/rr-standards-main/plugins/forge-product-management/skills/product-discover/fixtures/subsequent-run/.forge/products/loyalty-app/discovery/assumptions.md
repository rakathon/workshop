## AT-1a: Members want expiration warnings

**Related opportunity:** OPP-1
**Type:** Desirability
**Risk level:** High
**Test status:** Untested
**Confidence:** 60%
**Test design:** Survey 50 members — ask if they would opt in to expiration alerts and how far in advance they'd want them
**Result:**
