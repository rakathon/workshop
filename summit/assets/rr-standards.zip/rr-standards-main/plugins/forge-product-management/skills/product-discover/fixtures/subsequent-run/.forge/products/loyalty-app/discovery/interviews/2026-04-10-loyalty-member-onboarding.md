# Interview: 2026-04-10 — loyalty-member-onboarding

## Participant
Loyalty program member, 18 months active, mobile-primary

## Context
Member contacted support after discovering 2,400 points had expired without warning.

## Key Observations
- "I had no idea my points were going to expire — I just assumed they stayed there"
- Member checked balance weekly but never saw an expiration date displayed

## Signals of Intensity
- Strong frustration — nearly cancelled membership over the incident

## OST Implications
- OPP-1: Confirms that lack of proactive warning is the core pain, not the expiration policy itself
