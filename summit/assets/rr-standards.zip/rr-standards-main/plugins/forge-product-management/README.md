# Forge Product Management Plugin

The Forge Product Management plugin extends the Forge ecosystem with a suite of skills designed
for product managers. It covers the full PM workflow from market intelligence and discovery through
strategy, roadmapping, specification, and post-launch outcome measurement — all grounded in
structured artifacts that persist in your repository and survive team transitions. Skills are
PM-audience-first: they use plain language, reference PM frameworks (Torres CDH, Rumelt strategy,
JTBD, OST, MoSCoW), and do not assume engineering context. The plugin is independently installable
from the core Forge plugin and deploys alongside it.

---

## Prerequisites

- [Claude Code](https://claude.ai/code) with the Forge plugin installed (`forge@rr-standards`)
- [GitHub CLI](https://cli.github.com) authenticated (`gh auth login`)
- Python 3

## Installation

**1. Add the rr-standards marketplace** (skip if already added for the Forge plugin)

```
/plugin marketplace add github:rewards-guilds/rr-standards --scope project
```

**2. Install the PM plugin**

```
/plugin install forge-product-management@rr-standards --scope project
```

**3. Initialize your first product** (run once per product)

```
forge:product
```

That's it. All eleven PM skills are now available in your Claude Code session.

---

## Skill list

| Skill | Description | Trigger phrases |
|-------|-------------|-----------------|
| `forge:product` | Create a product directory and scaffold AGENTS.md — the entry point for all PM work | "create a product", "add a product", "initialize a product", "set up a product in forge" |
| `forge:product-strategy` | Build or refresh a product strategy: diagnosis → pillars → OKRs → metric hierarchy; hands off to `forge:product-roadmap` | "I need to build a product strategy", "let's do strategy", "create a strategy for my product", "quarterly strategy planning", "we need a strategy" |
| `forge:product-roadmap` | Create or update `roadmap.md` from confirmed coherent actions and OKRs; sole owner of the roadmap artifact | "build the roadmap", "update the roadmap", "add an initiative to the roadmap", "shift a horizon", "mark this initiative complete" |
| `forge:product-discover` | Run the Torres Continuous Discovery Habits loop: outcome definition → opportunity mapping → OST maintenance → assumption logging → test design | "run discovery", "let's do a discovery session", "update the opportunity tree", "log a new assumption", "I have interview notes to process" |
| `forge:prd` | Write the full PRD: `prd.md` (problem, goals, non-goals, success metrics) + `business.md` (MoSCoW requirements) + `user-stories.md` (Connextra format) | "write the PRD", "create the product requirements", "let's write requirements", "spec out this feature", "turn this brief into a PRD" |
| `forge:product-synthesis` | Synthesize structured research corpora — surveys, usability studies, support tickets, analytics — into findings, personas, and opportunity areas | "synthesize this research", "analyze these survey results", "what are the key themes?", "build personas from this data", "I have usability study notes to analyze" |
| `forge:competitive-brief` | Produce a competitive analysis: feature matrix, positioning, win/loss themes, market trends | "write a competitive brief", "analyze our competitors", "what's the competitive landscape?", "how do we compare to X?", "document win/loss themes" |
| `forge:product-scorecard` | Generate a dated North Star / L1 / L2 metrics scorecard snapshot; requires `metrics.md` from `forge:product-strategy` | "run the scorecard", "how are our metrics?", "generate a product health check", "what's our North Star trending?", "produce a metrics review" |
| `forge:product-brief` | Write a product brief: problem hypothesis + success criteria + strategic alignment; bridge between strategy and a Forge effort | "write a product brief", "I want to capture this opportunity", "brief out this initiative", "what should we build next?", "create a brief for this coherent action" |
| `forge:product-brainstorm` | PM thinking partner covering JTBD, OST, HMW, First Principles, SCAMPER, OODA, and Reverse Brainstorming | "explore this problem space", "help me think through this opportunity", "stress-test this idea", "brainstorm approaches to", "what am I missing about" |
| `forge:product-outcome` | Post-launch outcome review: measures PRD success metrics against actuals; re-invokable at 30/60/90 days | "run an outcome review", "how did this launch perform?", "measure the results against the PRD", "let's do a 60-day review", "what moved after we shipped?" |

---

## Tool dependencies

Each skill is designed to degrade gracefully when optional tools are unavailable. The table below
documents what each skill uses and how to proceed without it.

| Skill | Tools used | Fallback when unavailable |
|-------|-----------|--------------------------|
| `forge:product` | None | N/A — no external tools required |
| `forge:product-strategy` | Web search (market research, competitor data); Annalise/Snowflake (internal usage metrics) | Paste market context and metrics data directly into the chat before invoking; skill proceeds with provided text |
| `forge:product-roadmap` | Jira MCP (read-only — fetch linked epics, effort IDs) | Provide effort IDs and milestone dates manually when prompted |
| `forge:product-discover` | Atlassian MCP (read-only — fetch Confluence interview notes, linked Jira epics); Jira MCP (read-only — sprint/epic context) | Paste interview notes and Jira context directly into the chat; skill structures them into OST and assumption log |
| `forge:prd` | Atlassian MCP (read-only — fetch existing brief or epic context) | Provide brief content or problem statement when prompted; skill does not require an existing Jira ticket |
| `forge:product-synthesis` | Atlassian MCP (read-only — fetch Confluence research docs, support ticket exports); Annalise/Snowflake (quantitative data) | Paste or upload research documents directly; skill accepts raw text, CSV excerpts, and pasted survey data |
| `forge:competitive-brief` | Web search (competitor feature research, pricing, recent news) | Provide competitor data manually as pasted notes or a structured prompt; skill will guide the analysis from whatever input is available |
| `forge:product-scorecard` | Annalise/Snowflake (metric actuals); Jira MCP (read-only — sprint velocity, completion data) | Paste current metric values when prompted; skill records them with a manual-input flag in the scorecard |
| `forge:product-brief` | Atlassian MCP (read-only — fetch linked Jira epic or Confluence doc for context) | Provide the Jira/Confluence content as pasted text; brief can be written entirely from conversation |
| `forge:product-brainstorm` | None — operates entirely in-session | N/A — no external tools required |
| `forge:product-outcome` | Annalise/Snowflake (metric actuals post-launch); Jira MCP (read-only — completion data, release notes) | Paste post-launch metrics and release notes when prompted; skill records them with source annotations |

---

## Report templates and --sections workaround

PM reports are generated via `forge:report` using four starter presets shipped with this plugin.
The presets are defined at `plugins/forge-product-management/templates/report-presets/` and cover
the most common PM communication types:

| Preset name | Report type |
|-------------|------------|
| `pm-exec-briefing` | Executive / leadership status update — outcome-focused, RAG status, decisions needed |
| `pm-launch-announcement` | Feature launch announcement — customer-facing or cross-functional |
| `pm-cross-functional` | Cross-functional partner update — in-flight work, blockers, decisions, upcoming |
| `pm-weekly-status` | Weekly PM status — this week, next week, risks and flags |

### Using a preset (once TR-1 ships)

```
forge:report --report pm-exec-briefing
```

Preset files can be overridden per-team by placing a customized version at
`.forge/templates/report-presets/<preset-name>.md`. New report types can be added the same way —
no plugin modification required.

### --sections workaround (until TR-1 ships)

`forge:report` currently resolves `--report <name>` from a hardcoded table in forge core. Plugin-
contributed presets require a forge core change (TR-1) before `--report pm-*` works end-to-end.
Until TR-1 ships, use the explicit `--sections` flag:

**pm-exec-briefing**
```
forge:report --sections "Strategic Context,Status Summary,Key Risks,Decisions Needed,Next Milestone"
```

**pm-launch-announcement**
```
forge:report --sections "What We Built,Why It Matters,What's New,Who It Affects,What's Next"
```

**pm-cross-functional**
```
forge:report --sections "Progress Since Last Update,In Flight,Blockers and Dependencies,Decisions Made,Upcoming"
```

**pm-weekly-status**
```
forge:report --sections "This Week,Next Week,Risks and Flags"
```

---

## Out of scope

**Sprint rituals** — sprint planning, retrospectives, sprint reviews, and standup facilitation are
not covered by this plugin. These are team rituals that involve engineering, design, and PM together
and do not belong in a PM-only workflow plugin. A future `forge-sprint` plugin (or equivalent) will
own these skills when the time comes.

**Tool connector abstraction** — v1.0 skills use the tools available in the Forge ecosystem today
(Jira and Confluence via the Atlassian MCP, Annalise and Snowflake for internal metrics, web search
for market research). A generic connector pattern that would let teams swap out tool providers
without modifying skill files is deferred to a future cross-cutting initiative. Until that work
lands, the tool dependencies table above documents exactly what each skill uses and how to proceed
without it.

---

## Contributing

New skills and updates to existing skills must follow the naming conventions documented in
[`.forge/efforts/product-management/spec/naming-conventions.md`](.forge/efforts/product-management/spec/naming-conventions.md).
The short version: use `forge:product-*` for skills that write a specific named artifact into the
product directory, `forge:pm-*` for PM workflow activity skills, and named exceptions only for
well-understood industry terms (`forge:prd`) or entry-point commands (`forge:product`). Bare verbs
(`forge:brainstorm`, `forge:discover`, `forge:research`) are reserved and must not be claimed by
this plugin.

Each skill must have a `SKILL.md` with frontmatter, a description, trigger phrases, and step-by-step
instructions. Skills must document which tools they use and include a manual fallback path for when
those tools are unavailable.
