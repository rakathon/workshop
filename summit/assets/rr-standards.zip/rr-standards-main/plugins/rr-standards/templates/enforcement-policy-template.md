<!--
ENFORCEMENT POLICY TEMPLATE
─────────────────────────────────────────────────────────────────────────────
Before publishing:
  1. Replace every [bracketed placeholder] with real content
  2. Add one row per rule from the companion standard — no more, no fewer
  3. Delete ALL HTML comments (including this block and the checklist below)
  4. Verify the published file is under 150 lines

The enforcement policy is the evaluation contract for a standard. It defines:
  - Assertion: the binary yes/no statement a reviewer applies per rule
  - Severity: how seriously a violation is treated

Severity guidance:
  blocking      — violation prevents correct behaviour, creates a security risk,
                  or breaks a contract that other systems depend on. The PR
                  cannot merge until the finding is resolved. Any single finding
                  is sufficient to block.
  advisory      — consistency, style, or quality concern that matters at scale.
                  Individual findings do not block; the PR is blocked only when
                  the total advisory count exceeds advisory_threshold.
  informational — observation only. Never blocks, regardless of count. Use for
                  things the engineer should know but where fixing before merge
                  is genuinely optional.

advisory_threshold: integer or null (default null). Set to an integer to block
the PR when advisory findings exceed that count. null means advisory findings
are always non-blocking.

Assertion column: a binary yes/no statement derived from the rule. Phrase as a
verifiable check, not a question: "URI follows required path structure" not
"Does the URI follow the required path structure?"

Notes column: optional. One line max. Use only when the severity choice is
non-obvious — do not add notes for self-evident choices.

Rule column: copy the identifier and name exactly from the companion standard.
─────────────────────────────────────────────────────────────────────────────
-->

# Enforcement Policy — [Standard Name]

Standard: [standards/category/standard.md]@[standard-version]
Policy version: 1.0.0
advisory_threshold: null
Authors: [IC codeowner names or team]
Reviewed: [YYYY-MM-DD]

| Rule | Assertion | Severity | Notes |
|------|-----------|----------|-------|
| R-1: [Exact rule name from companion standard] | [Binary yes/no assertion for R-1] | blocking | |
| R-2: [Exact rule name from companion standard] | [Binary yes/no assertion for R-2] | advisory | [Optional: one-line rationale for non-obvious choices] |
| R-3: [Exact rule name from companion standard] | [Binary yes/no assertion for R-3] | informational | |

<!-- Add one row per rule from the companion standard.
     Rules must appear in the same order as in the standard.
     When the standard is updated:
       - Patch update: verify rule names unchanged; update the version reference
       - Minor update (rules added): add rows for new rules; existing rows remain valid; update version reference
       - Major update (rules removed or changed in meaning): review every row; remove stale rows; re-version this policy -->

<!--
QUALITY CHECKLIST — self-check before submitting; delete this comment before publishing

- [ ] Standard reference path resolves to an existing file
- [ ] Standard version matches the current version of the companion standard
- [ ] Every rule in the companion standard has exactly one row in this table
- [ ] No row references a rule that does not exist in the companion standard (no stale entries)
- [ ] Every row has a non-empty Assertion column
- [ ] All severity values are exactly "blocking", "advisory", or "informational" — no other values
- [ ] advisory_threshold is an integer or null
- [ ] Notes column entries are one line or empty
- [ ] Published file (HTML comments removed) is under 150 lines
-->
