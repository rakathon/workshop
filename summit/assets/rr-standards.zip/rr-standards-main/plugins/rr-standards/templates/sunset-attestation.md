## API Version Removal

This PR removes one or more versioned API endpoints. All of the following must be
confirmed before this PR may be approved. Unchecked items will cause the automated
review to block.

- [ ] `Deprecation`, `Sunset`, and `Link` response headers were present in all responses
      for the removed version throughout the sunset period
- [ ] Usage was monitored by version and by client; no active traffic above the agreed
      threshold remains on the removed version
- [ ] All affected clients were identified, notified, and confirmed a migration timeline
- [ ] Traffic to the removed version fell below the agreed threshold before this PR was opened

**Removed version(s):** <!-- list each removed path prefix, e.g. /store/v1 -->
**Sunset period end date:** <!-- YYYY-MM-DD -->
**Evidence / approval link:** <!-- link to the sunset tracking issue or approval record -->
