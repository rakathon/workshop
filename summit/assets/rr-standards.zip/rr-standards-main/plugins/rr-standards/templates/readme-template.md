# Skill Name

One sentence description.

## Purpose

What this skill does and why it exists - 2-3 sentences.

## When to Use

Use this skill when:
- Scenario 1
- Scenario 2
- Scenario 3
- Scenario 4

## Usage

```
Use skill-name to [task description]
```

Or with specific parameters:
```
Use skill-name to [task] with [parameters]
```

## Examples

### Example 1: Use Case

```
You: "Use skill-name to [specific task]"

Claude will:
1. Step 1
2. Step 2
3. Step 3
4. Step 4

Result: What gets produced
```

### Example 2: Another Use Case

```
You: "[Another usage example]"

Claude will:
1. Step 1
2. Step 2

Result: What gets produced
```

## What Gets Generated

- Output item 1
- Output item 2
- Output item 3
- Output item 4

## See Also

- [Related Standard](../../standards/category/standard.md)
- [Related Guide](../../languages/lang/guides/guide.md)
- [Getting Started](../../standards/skills/skill-getting-started.md)