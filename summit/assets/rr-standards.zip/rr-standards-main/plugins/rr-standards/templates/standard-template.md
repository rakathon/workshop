<!--
STANDARD TEMPLATE
─────────────────────────────────────────────────────────────────────────────
Before publishing:
  1. Replace every [bracketed placeholder] with real content
  2. Delete ALL HTML comments (including this block and the checklist below)
  3. Verify the published file is under 300 lines
  4. Author a companion <slug>.policy.md using the enforcement-policy-template

Rule identifiers: assign R-1, R-2, ... in order of impact (most critical first).
Never renumber an existing rule — identifiers are stable join keys for metrics.

Voice: directive imperative — "Use X", "Return Y", "Validate Z".
Not: "You should use X" / "It is recommended to use X" / "Best practice is X".

Each rule must be usable in two modes without rewording:
  Generation: the agent reads it and produces code that satisfies it.
  Evaluation: the agent reads it and checks whether existing code satisfies it.

This document is language-agnostic. Code examples use pseudo-code or plain
description only — no language-specific syntax. Runnable, production-quality
reference code belongs in the language guides listed in the Related section.
Agents load those guides to follow when generating; they load these rules to
check against when evaluating.

There is NO Compliance Checklist section in the standard. Evaluation assertions
(what a reviewer checks per rule) belong in the companion enforcement policy.
─────────────────────────────────────────────────────────────────────────────
-->

# [Standard Name]

<!-- e.g., "REST API Design" / "Message Design" / "Database Schema" -->

Version: 1.0.0 | Category: [api | storage | testing | security | observability | deployment]

## Overview

<!-- 2–4 sentences. What this standard governs and what correct compliance produces.
     No rule content here. One sentence of context is fine; full rationale belongs in an ADR. -->

[What this standard defines and what following it produces.]

## Scope

**Applies to:** [Specific files, components, or scenarios this covers — be precise]

**Out of scope:**
- [Explicit exclusion — name the thing that is NOT covered]
- [Add further exclusions as needed]

## Rules

<!-- Priority order: highest-impact rules first.
     Each rule: single R-N identifier as heading + one directive sentence.
     Must not contain language-specific code (this is a language-agnostic standard).
     Must not restate rules from a parent standard or from linter configuration.
     If a rule needs more than one sentence, split it into two rules. -->

### R-1: [Rule name]

[Single directive sentence.]

### R-2: [Rule name]

[Single directive sentence.]

<!-- Add R-3, R-4, ... as needed. Typical standards have 5–15 rules. -->

## Examples

<!-- One example per non-obvious rule. Use pseudo-code or plain description —
     no language-specific syntax here. Each example should explain *why* the
     pattern is correct, not just assert that it is.

     Production-quality runnable examples belong in the language guides.
     Add a note here pointing to the relevant guide when one exists. -->

**R-1 — [brief label describing what this shows]**

```
// pseudo-code: [one-line explanation of what makes this correct]
[minimal pseudo-code illustrating the pattern]
```

<!-- Add further examples for rules where the right behaviour is non-obvious.
     Skip examples where the rule is self-evident from its directive sentence. -->

## Related

<!-- Standards this one depends on or complements. -->

- [Related standard name](../category/standard.md) — [one-line relationship]

<!-- Language guides — each guide implements this standard in a specific language
     and contains the production-quality reference code agents follow when generating.
     Link each guide as it is written; leave others commented until they exist. -->

**Language guides:**
<!-- - [Go](../../languages/go/guides/[area]/[guide].md) -->
<!-- - [Java](../../languages/java/guides/[area]/[guide].md) -->
<!-- - [TypeScript](../../languages/typescript/guides/[area]/[guide].md) -->
<!-- - [Swift](../../languages/swift/guides/[area]/[guide].md) -->
<!-- - [Kotlin](../../languages/kotlin/guides/[area]/[guide].md) -->
<!-- - [Python](../../languages/python/guides/[area]/[guide].md) -->

<!--
QUALITY CHECKLIST — self-check before submitting; delete this comment before publishing

Structural completeness:
- [ ] All five sections present: Overview, Scope, Rules, Examples, Related
- [ ] No section contains only placeholder text
- [ ] All links resolve to existing files
- [ ] Companion enforcement policy file authored alongside this standard

Rule quality:
- [ ] Every rule has a unique R-N identifier
- [ ] Every rule uses imperative directive voice
- [ ] Every rule is evaluable as pass/fail (no subjective language)
- [ ] No rule contains language-specific code
- [ ] No rule duplicates linter configuration or a rule from a parent standard

Examples:
- [ ] Examples present for all non-obvious rules
- [ ] All examples use pseudo-code or plain description — no language-specific syntax
- [ ] Each example explains why the pattern is correct, not just that it is

Related:
- [ ] Language guides section present; at least one guide linked or all commented with paths filled in
- [ ] Every linked guide implements this standard (not just related to the same topic)

Token efficiency:
- [ ] Rules use imperative voice — no "should", "recommended", "best practice"
- [ ] Published file (HTML comments removed) is under 300 lines
-->
