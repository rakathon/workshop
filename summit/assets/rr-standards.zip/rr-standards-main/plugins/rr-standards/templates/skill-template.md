---
name: skill-name
description: Brief description (max 1024 chars) including what it does and when to use it
---

# Skill Name

One paragraph overview of what this skill does.

## Locating Referenced Files

Files referenced in this skill can be found in one of two locations: first check `./plugins/rr-standards/path/`, and if not found, fall back to `~/.claude/plugins/rr-standards/path/`.
If neither exists, inform user rr-standards not properly set up.

## Your Mission

Clear statement of the skill's purpose and goals.

This skill should:
- Key responsibility 1
- Key responsibility 2
- Key responsibility 3

## Required Reading

Before [doing task], you MUST read:

1. **`path/to/standard.md`** (estimated lines)
   - What this file contains
   - Why it's important

2. **`path/to/example.md`** (estimated lines)
   - What this file contains
   - Why it's important

[List all files the skill needs to reference]

## Process

### Step 1: First Step Name

Detailed instructions for Claude.

**Actions:**
- Specific action 1
- Specific action 2

**Validation:**
- ✅ Check 1
- ✅ Check 2

### Step 2: Second Step Name

Detailed instructions.

[Continue with all necessary steps...]

## Output Format

Generate the following:

```format
Template of expected output
```

**Sections:**
1. Section 1 name
   - What goes here

2. Section 2 name
   - What goes here

[Continue for all output sections...]

## Validation

After generating output, verify:

- ✅ Validation criterion 1
- ✅ Validation criterion 2
- ✅ Validation criterion 3

## Examples

### Example 1: Use Case Name

```
You: "Use skill-name to [task]"

I'll [what the skill does]:

[Shows step-by-step execution]

[Shows generated output]
```

### Example 2: Another Use Case

```
You: "Use skill-name with [parameters]"

[Shows execution and output]
```

## Troubleshooting

**Issue:** Common problem
**Solution:** How to fix it

**Issue:** Another problem
**Solution:** How to fix it

## Important Reminders

- Critical requirement 1
- Critical requirement 2
- Critical requirement 3