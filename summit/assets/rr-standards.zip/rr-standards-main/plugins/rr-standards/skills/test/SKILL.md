---
name: rr-standards:test
description: >
  Tests whether a standard or language guide measurably improves LLM compliance
  evaluation, using with/without-context evaluations via a Python test harness and the
  claude CLI. Use this skill whenever a user wants to test a standard, run tests on a
  guide, check if a standard is effective, validate that a standard makes a difference,
  measure standard quality, or see how well a guide works in practice. Also trigger when
  the user says "test my standard", "does my standard work?", "run behavioral tests",
  "check standard effectiveness", "test this guide", or anything asking to evaluate or
  measure the impact of a standards artifact. test-accuracy PASS requires ≥80%
  with-standard accuracy. Low lift (< 20% improvement over baseline) surfaces as an
  informational generation-lift warning, not a FAIL. Supports --ci for CI pipeline use
  (single JSON report, no viewer) and --iterations N for iterative improvement loops.
  Invoke as: /rr-standards:test <file-path-or-dir> [--ci] [--iterations N] [--clean]
---

# rr-standards:test

Worker skill — non-interactive. Measures the behavioral effectiveness of a standard or
language guide: does applying the artifact as context make an LLM more accurate at
evaluating artifact compliance?

---

## Input

Parse from the invocation:
- `<file-path>` — repo-relative path to a standard or language guide file, or a
  directory (required). If it resolves to a directory, follow **Step 9 — Directory Mode**.
- `--ci` — CI mode: suppress the test viewer and improvement loop; run the harness once;
  emit a single JSON report to stdout; exit
- `--iterations N` — number of iterative improvement cycles (default: 1; ignored with `--ci`)
- `--clean` — delete the entire workspace for this artifact before starting

If no file path is provided, emit a usage error:
```
Usage: /rr-standards:test <file-path-or-dir> [--ci] [--iterations N] [--clean]
Example: /rr-standards:test plugins/forge/standards/api/rest/contracts.md
Example: /rr-standards:test plugins/forge/standards/api/rest/contracts.md --ci
Example: /rr-standards:test plugins/forge/standards/api/rest/contracts.md --iterations 3
Example: /rr-standards:test plugins/forge/standards/api/rest/ --clean
```

---

## Step 1 — Detect Artifact Type

Read `plugins/forge/standards/TAXONOMY.md § Artifact Type Identification` and apply the
ordered rules exactly as written. The taxonomy is the authoritative source; load it at
run time so the skill stays correct as the taxonomy evolves.

If the artifact type is not **language-agnostic standard** or **language guide**, emit:
```
NOTE: rr-standards:test only supports language-agnostic standards and language guides.
      Use rr-standards:validate for structural checks on other artifact types.
```
Exit with code 0.

---

## Step 2 — Read the Artifact File

Read the artifact file at the given path. If it does not exist:
```
ERROR: File not found: <path>
```
Exit code 1.

Determine the context variable **`<ctx>`**:
- Language-agnostic standard → `<ctx>` = `standard`
- Language guide → `<ctx>` = `guide`

For language guides, also identify and read the parent standard:
- Read the `Related standard` section; extract the link to the `.md` file under `standards/`
- Read the parent standard file — needed to resolve R-N identifiers in evaluation prompts
- If the parent standard cannot be found, emit a warning and proceed without it

---

## Step 3 — Load or Generate Test File

**Locate the companion test file:**
- Standard: `<standard-path-without-extension>.test.yaml`
  e.g., `plugins/forge/standards/api/rest/contracts.md` → `contracts.test.yaml` alongside it
- Language guide: `<guide-path-without-extension>.test.yaml`

**If the test file exists:** read it. If `standard_version` does not match the version
declared in the artifact file, emit a warning (not blocking).

**Resolve `artifact_file` references:** after loading, iterate over every test. Read the
referenced fixture file — the path is relative to the directory containing the test.yaml
(e.g., `artifact_file: fixtures/compliant-api.yaml` in
`plugins/forge/standards/api/rest/contracts.test.yaml` resolves to
`plugins/forge/standards/api/rest/fixtures/compliant-api.yaml`). Substitute the file's
contents as the test's `artifact_snippet`. If the referenced file does not exist, emit a
warning for that test and skip it.

**If the test file does not exist:** auto-generate it using the principles below. Write
the fixture files to a `fixtures/` subdirectory alongside the test yaml, then write the
test yaml to `<artifact-path-without-extension>.test.yaml`. Emit:
```
NOTE: No .test.yaml found. Auto-generated N tests at <path>.
Fixtures written to <fixtures-dir>.
Review auto-generated fixtures and tests before treating results as authoritative.
Rules covered: R-N, R-N, ...
```

### Test file format

All tests must use `artifact_file` to reference a fixture file in a `fixtures/`
subdirectory alongside the test yaml. **Never embed artifact content directly in the yaml
as `artifact_snippet`.** Fixtures are separate files because:
- Large artifacts are unreadable when embedded in yaml
- Fixtures can be opened and edited independently
- The test yaml stays concise and easy to review

```yaml
standard_path: plugins/forge/standards/<category>/<standard>.md
standard_version: 1.0.0
generated_at: YYYY-MM-DD
generated_by: auto
tests:
- id: ex-c1
  name: Short descriptive name
  artifact_file: fixtures/compliant-example.yaml
  expected_verdict: compliant
  expectations:
  - The reviewer correctly identifies this artifact as compliant
  - No blocking findings are raised
  - The reviewer cites R-N as satisfied
- id: ex-nc1
  name: Short descriptive name
  artifact_file: fixtures/non-compliant-example.yaml
  expected_verdict: non_compliant
  expectations:
  - The reviewer correctly identifies this artifact as non_compliant
  - R-N and R-N are cited as violated rules
  - The reviewer identifies specific evidence in the artifact for each violation
```

Expectation strings that contain `:` must be single-quoted or use a block scalar.

For language guide tests: `guide_path` replaces `standard_path` as the primary key;
`standard_path` is retained so R-N identifiers can be resolved.

### Auto-generation principles

The purpose of tests is to measure how much the artifact improves output quality over
unaided general knowledge. Focus on rules where the standard differs from industry norm.

**Goal: minimal fixture count, maximum rule coverage per fixture.**

Design the smallest possible set of fixtures that exercises all rules. Do not create one
test per rule. Instead, pack as many rules as possible into each fixture.

**Step 1 — classify rules:**
- **Org-specific / standard-differentiating**: rules that prescribe behaviour different
  from general industry conventions, or that encode an org-specific naming scheme,
  identifier type, field shape, or constraint. High diagnostic value.
- **General best practice**: rules that restate well-known conventions a competent
  practitioner would apply without the standard. Low diagnostic value.

**Step 2 — design compliant fixture(s):**

Aim for a **single compliant fixture** that satisfies every rule in the standard. If one
fixture cannot plausibly cover all rules (e.g. mutually exclusive scenarios), use the
minimum number required. Each compliant fixture should:
- Correctly implement every org-specific rule it covers
- Include at least one "trap" pattern — something a reviewer without the standard might
  flag as wrong, but that the standard explicitly permits or requires
- Be a realistic, complete artifact (not a stripped-down fragment)

Write the fixture to `fixtures/compliant-<slug>.yaml` (or the appropriate file extension
for the artifact type).

**Step 3 — design non-compliant fixture(s):**

Aim for a **single non-compliant fixture** that violates as many rules as possible
simultaneously. A reviewer with the standard should be able to identify all violations;
a reviewer without it should miss the org-specific ones. If one fixture cannot credibly
contain all violation types (e.g. some violations are structurally incompatible), use the
minimum number of non-compliant fixtures needed. Each non-compliant fixture should:
- Violate as many distinct R-N rules as possible, especially org-specific ones
- Look plausible — it should resemble real-world work, not an obviously broken artifact
- Contain no "accidental" violations beyond the ones you intended to test

Write the fixture to `fixtures/non-compliant-<slug>.yaml` (or appropriate extension).
If multiple non-compliant fixtures are needed, name them
`fixtures/non-compliant-<slug>-<N>.yaml`.

**Step 4 — write expectations:**

For each test, write `expectations` (3–5 assertions) that describe what a correct
reviewer output should contain:
- Always include: "The reviewer correctly identifies this artifact as compliant/non_compliant"
- Non-compliant: list all R-N identifiers that should be cited as violated; describe the
  concrete evidence a reviewer should find; note what a correct implementation would look like
- Compliant (trap): state that the reviewer does *not* raise the anticipated false-positive

---

## Step 4 — Prepare Workspace

Derive the artifact slug from the file stem (e.g., `contracts.md` → `contracts`).

**If `--clean` was passed:** delete the entire workspace before proceeding:
```bash
rm -rf .rr-standards/validate/workspace/<slug>
```

Determine the next iteration number: scan for
`.rr-standards/validate/workspace/<slug>/iteration-N/` directories; use the next
available N (start at 0).

Create the workspace directory:
```bash
mkdir -p .rr-standards/validate/workspace/<slug>/iteration-N
```

**Reuse `without_<ctx>` results from the previous iteration:**
The `without_<ctx>` subprocess uses only general knowledge — its output for a given
snippet is deterministic across iterations. Never re-run it if a prior result exists.

If N > 0: for each test, check whether
`.rr-standards/validate/workspace/<slug>/iteration-M/` (M = N−1) contains a completed
`<test-id>/without_<ctx>/outputs/output.md`. If it does, mark that test's
`without_<ctx>` as **reused** (`reuse_without: true` in the manifest; `reuse_from` set
to the prior iteration path). The harness will copy those files rather than re-running.

Emit one line if any tests are being reused:
```
NOTE: Reusing without_<ctx> results from iteration M for K/total tests.
```

---

## Step 5 — Build and Write Run Manifest

Construct the run manifest and write it to:
`.rr-standards/validate/workspace/<slug>/iteration-N/run_manifest.json`

```json
{
  "ctx": "standard",
  "standard_path": "plugins/forge/standards/api/rest/contracts.md",
  "standard_name": "contracts.md",
  "standard_content": "<full text of the standard file>",
  "guide_path": null,
  "guide_content": null,
  "workspace_base": ".rr-standards/validate/workspace/<slug>/iteration-N",
  "ci_mode": false,
  "reuse_from": null,
  "tests": [
    {
      "id": "ex-c1",
      "expected_verdict": "compliant",
      "artifact_snippet": "<resolved snippet — artifact_file references already substituted>",
      "expectations": ["...", "..."],
      "reuse_without": false
    }
  ]
}
```

For language guides: set `ctx` to `"guide"`, populate `guide_path` and `guide_content`
with the guide's path and full file text, and set `standard_path`/`standard_content` to
the parent standard (for R-N resolution in evaluation prompts).

Set `ci_mode: true` when `--ci` was passed.

Set `reuse_from` to the prior iteration's workspace path (e.g.,
`.rr-standards/validate/workspace/<slug>/iteration-M`) when any test has
`reuse_without: true`; otherwise `null`.

---

## Step 6 — Invoke Python Harness

Run the test harness. The harness reads the run manifest, spawns one thread per test,
invokes the `claude` CLI as a subprocess for each evaluation (both `with_<ctx>` and
`without_<ctx>`), writes workspace files, aggregates results, and writes `benchmark.json`
and (in CI mode) `ci_report.json`. It always exits 0 on a successful run; the verdict is
in `benchmark.json` / `ci_report.json`. It exits non-zero only on system error.

```bash
python3 <skill-base-dir>/test-runner/run_tests.py \
  --manifest ".rr-standards/validate/workspace/<slug>/iteration-N/run_manifest.json"
```

Wait for the harness to complete before proceeding.

If the harness exits non-zero (system error — no benchmark written), emit:
```
ERROR: Test harness failed. Check that the `claude` CLI is available in PATH.
Details: <stderr from harness>
```
Exit code 0 (the skill ran; the error is communicated above).

A zero exit from the harness means the run completed — continue to Step 7 and read the
verdict from `benchmark.json`. Test-accuracy FAIL is not a harness error.

---

## Step 7 — Collect Results

Read `.rr-standards/validate/workspace/<slug>/iteration-N/benchmark.json`.

### CI mode (`--ci`)

Read `.rr-standards/validate/workspace/<slug>/iteration-N/ci_report.json` written by
the harness. Emit its contents to stdout as the sole output:

```json
{
  "verdict": {
    "result": "pass",
    "with_accuracy": 1.0,
    "without_accuracy": 0.75,
    "lift": 0.25,
    "generation_lift_warning": false
  },
  "tests": [
    {
      "test_id": "ex-c1",
      "expected_verdict": "compliant",
      "with_verdict_correct": true,
      "without_verdict_correct": true,
      "with_pass_rate": 1.0,
      "without_pass_rate": 0.8
    },
    {
      "test_id": "ex-nc1",
      "expected_verdict": "non_compliant",
      "with_verdict_correct": true,
      "without_verdict_correct": false,
      "with_pass_rate": 1.0,
      "without_pass_rate": 0.57
    }
  ]
}
```

- `verdict.result`: `"pass"` when `with_accuracy ≥ 0.80`; `"fail"` otherwise
- `verdict.generation_lift_warning`: `true` when `lift < 0.20` (informational; does not affect `result`)

Exit code 0. The verdict is communicated in the JSON output above. Do not proceed to Step 8.

### Interactive mode (no `--ci`)

Emit a human-readable results summary:
```
Behavioral validation complete — iteration N.

Results:
  with_<ctx> verdict accuracy:    N%
  without_<ctx> verdict accuracy: N%
  Lift: +N%
  test-accuracy: PASS | FAIL
  generation-lift: OK | WARNING (lift < 20% — standard may not improve over baseline)
```

`test-accuracy` is FAIL (blocking) when `with_accuracy < 0.80`. `generation-lift` WARNING
is informational — it does not affect the overall verdict or exit code.

Launch the test viewer in the background:
```bash
nohup python3 <skill-base-dir>/../shared/test-viewer/generate_review.py \
  ".rr-standards/validate/workspace/<slug>/iteration-N" \
  --skill-name "<artifact-path>" \
  --benchmark ".rr-standards/validate/workspace/<slug>/iteration-N/benchmark.json" \
  > /dev/null 2>&1 &
```

If N > 0, also pass `--previous-workspace`:
```bash
nohup python3 <skill-base-dir>/../shared/test-viewer/generate_review.py \
  ".rr-standards/validate/workspace/<slug>/iteration-N" \
  --skill-name "<artifact-path>" \
  --benchmark ".rr-standards/validate/workspace/<slug>/iteration-N/benchmark.json" \
  --previous-workspace ".rr-standards/validate/workspace/<slug>/iteration-M" \
  > /dev/null 2>&1 &
```

Emit to the user:
```
The test viewer is now running in your browser. Review each test's with/without
outputs side-by-side and leave feedback in the text box. When you are done,
click "Submit All Reviews" — feedback saves automatically to the workspace.

Come back here and say "done reviewing" to apply feedback and continue.
```

Wait for the user to confirm they are done reviewing before continuing.

---

## Step 8 — Iterative Improvement

*(Interactive mode only — already exited in Step 7 if `--ci`.)*

Determine the iteration limit from `--iterations N` (default: 1).

### Read feedback

Once the user confirms, read:
`.rr-standards/validate/workspace/<slug>/iteration-N/feedback.json`

If the file does not exist:
```
ERROR: No feedback found at <path>.
The review viewer was closed before feedback was submitted. Re-run to try again.
```
Exit code 1.

The `feedback.json` has free-form structure. Read all comments, ratings, and notes.
Identify:
- Which tests had incorrect verdicts according to the reviewer
- Which expectations were flagged as wrong or misleading
- Which rules or rule text the reviewer called out as unclear, missing, or wrong
- Any suggested improvements to specific rules

### Propose improvements

Group reviewer feedback by R-N rule. For each rule with actionable feedback, propose
one or more specific improvements:

```
Iteration N — Improvements from your review

R-N: [rule name]
Feedback: [paraphrase of reviewer's comment]
Current rule text:
  "[current rule text]"
Proposed change:
  "[improved rule text]"
Reason: [why this change addresses the feedback]
Apply? (yes / no / edit)
```

Wait for the author's response before writing anything:
- `yes` — apply the proposed text as written
- `no` — skip this rule
- `edit` — author provides replacement text; apply that instead

Apply all accepted changes to the artifact file.

### Re-read the updated artifact

After applying changes, re-read the artifact file to obtain the updated content — the
manifest for the next iteration must contain the modified text, not the original.
For language guides, also re-read the parent standard if any of its rules were changed.
Then proceed to Step 4 using the freshly-read content.

### Re-run

Increment the iteration counter (N+1) and proceed to Step 4.
Stop after the number of iterations specified by `--iterations` (default: 1).

### Convergence report

After each iteration, emit the full history:
```
Improvement history:
| Iteration | with_<ctx> acc | without_<ctx> acc | Lift  | Rules changed |
|-----------|----------------|-------------------|-------|---------------|
| 0         | N%             | N%                | +N%   | —             |
| 1         | N%             | N%                | +N%   | R-N, R-N      |
```

If `with_accuracy ≥ 0.80`, emit:
```
test-accuracy target reached at iteration N. Standard is behaviourally validated.
```
If additionally `lift ≥ 0.20`:
```
generation-lift target reached — standard measurably improves over baseline.
```

---

## Step 9 — Directory Mode

Activated when `<file-path>` resolves to a directory. Replaces Steps 1–8.

### Phase D1 — Enumerate artifacts

List all files in the directory (non-recursive). Apply TAXONOMY.md rules. Build a list
of **standards and language guides only** — skip all other types (emit one `SKIP:` line
per skipped file; also skip `.test.yaml` files).

If no standards or language guides are found:
```
NOTE: No standards or language guides found in <directory>. Nothing to test.
```
Exit code 0.

### Phase D2 — Prepare combined workspace

Derive the directory slug from the last non-empty path component
(e.g., `plugins/forge/standards/api/rest/` → `rest`).

**If `--clean` was passed:**
```bash
rm -rf .rr-standards/validate/workspace/<dir-slug>
```

Determine the next iteration number by scanning for
`.rr-standards/validate/workspace/<dir-slug>/iteration-N/` directories.

Create the workspace:
```bash
mkdir -p .rr-standards/validate/workspace/<dir-slug>/iteration-N
```

Test IDs are prefixed with the standard slug so the viewer can display all tests
together without ID collisions: `<standard-slug>-<test.id>` (e.g., `contracts-ex-c1`).

### Phase D3 — Load test files and build manifests

For each standard/guide: load or auto-generate its `.test.yaml` (same logic as Step 3).
Resolve all `artifact_file` references. Apply `without_<ctx>` reuse logic across all
standards (check for a prior iteration under `.rr-standards/validate/workspace/<dir-slug>/`).

Build one run manifest per standard/guide (same schema as Step 5) using workspace paths
with prefixed test IDs:
- Workspace base: `.rr-standards/validate/workspace/<dir-slug>/iteration-N`
- Test IDs in manifest: `<standard-slug>-<test.id>`

### Phase D4 — Run all harness invocations in parallel

Invoke the harness for each standard as a background process, then wait for all:

```bash
python3 <skill-base-dir>/test-runner/run_tests.py \
  --manifest ".rr-standards/validate/workspace/<dir-slug>/iteration-N/<standard-slug>-manifest.json" &
# repeat for each standard...
wait
```

Each harness writes its own per-standard benchmark file:
`.rr-standards/validate/workspace/<dir-slug>/iteration-N/<standard-slug>-benchmark.json`

### Phase D5 — Aggregate and report

Aggregate the per-standard benchmark files into a combined
`.rr-standards/validate/workspace/<dir-slug>/iteration-N/benchmark.json`.

Emit a consolidated summary:
```
Behavioral validation complete — iteration N.

Results:
  Standard             with_<ctx>   without_<ctx>  Lift   test-accuracy
  contracts.md         N%           N%             +N%    PASS|FAIL
  data.md              N%           N%             +N%    PASS|FAIL
  ─────────────────────────────────────────────────────────────────────
  Overall              N%           N%             +N%
```

**In `--ci` mode:** emit a combined JSON report using the same schema as single-file CI
mode — `verdict.result` is `"fail"` if any standard fails, with all tests from all
standards merged into the `tests` array. Exit code 0; the verdict is communicated in the
JSON output. Do not proceed to Phase D6.

**In interactive mode:** launch the viewer with the combined workspace and proceed to
Phase D6.

### Phase D6 — Interactive review and improvement

Launch the viewer with the combined workspace:
```bash
nohup python3 <skill-base-dir>/../shared/test-viewer/generate_review.py \
  ".rr-standards/validate/workspace/<dir-slug>/iteration-N" \
  --skill-name "<directory-path>" \
  --benchmark ".rr-standards/validate/workspace/<dir-slug>/iteration-N/benchmark.json" \
  > /dev/null 2>&1 &
```

Wait for the user to confirm "done reviewing". Then read
`.rr-standards/validate/workspace/<dir-slug>/iteration-N/feedback.json` and apply the
same improvement loop as Step 8 — feedback may reference findings from any standard in
the directory, so group by standard and apply rule changes to the corresponding files.

Re-run Phases D3–D5 with the incremented iteration number for each additional cycle.
Stop after `--iterations` cycles.
