# rr-standards:test

Measures the behavioral effectiveness of a standard or language guide by running
with/without-context evaluations via a Python test harness and the claude CLI.

## Purpose

`rr-standards:test` answers the question: does this standard actually make an LLM
more accurate at evaluating compliance? Structural correctness (checked by
`rr-standards:validate`) is necessary but not sufficient. A standard can be
well-formed and still fail to produce consistent, correct evaluations in practice.

The skill runs two sets of evaluations for each test case in the companion
`.test.yaml` file:
- **with_standard**: evaluator reads the standard before assessing the snippet
- **without_standard**: baseline evaluator uses only general domain knowledge

It computes verdict accuracy and lift (the accuracy gap between the two). A standard
passes behavioral validation when `with_accuracy ≥ 80%` AND `lift ≥ 20%`.

## Usage

```bash
# Measure behavioral effectiveness — opens interactive test viewer
/rr-standards:test plugins/forge/standards/api/rest/contracts.md

# CI mode — JSON report to stdout, no viewer, exit 1 on FAIL
/rr-standards:test plugins/forge/standards/api/rest/contracts.md --ci

# Run multiple improvement iterations (reads viewer feedback each time)
/rr-standards:test plugins/forge/standards/api/rest/contracts.md --iterations 3

# Start fresh — delete prior workspace before running
/rr-standards:test plugins/forge/standards/api/rest/contracts.md --clean

# Directory mode — test all standards in the directory together
/rr-standards:test plugins/forge/standards/api/rest/
```

## Flags

| Flag | Description |
|------|-------------|
| `--ci` | Machine-readable JSON output; suppresses test viewer and `--iterations`; exit 1 on FAIL |
| `--iterations N` | Number of iterative improvement cycles (default: 1; ignored with `--ci`) |
| `--clean` | Delete the workspace for this standard before starting |

## Output Modes

### Interactive (default)

After the Python harness runs all evaluations, a browser-based test viewer opens
showing each test's `with_standard` and `without_standard` outputs side-by-side.
Leave feedback in the text box for each test and click "Submit All Reviews".

Then return to Claude and say "done reviewing". The improvement loop proposes specific
rule rewording for each failing rule, waits for your approval, applies accepted changes,
and re-runs (up to `--iterations N` cycles).

```
Behavioral validation complete — iteration 0.

Results:
  with_standard verdict accuracy:    100%
  without_standard verdict accuracy: 75%
  Lift: +25%
  test-accuracy: PASS
```

### CI mode (`--ci`)

Emits a single JSON record to stdout and exits. No viewer, no improvement loop.

```json
{
  "verdict": "pass",
  "with_accuracy": 1.0,
  "without_accuracy": 0.75,
  "lift": 0.25,
  "tests": [
    {
      "test_id": "ex-c1",
      "expected_verdict": "compliant",
      "with_verdict_correct": true,
      "without_verdict_correct": true,
      "with_pass_rate": 1.0,
      "without_pass_rate": 0.8
    }
  ]
}
```

Exit code **0** on pass, **1** on FAIL, **2** on system error.

## Test Cases (`.test.yaml`)

The skill looks for a companion `<standard-path>.test.yaml` file containing compliant
and non-compliant artifact examples. If none exists, the skill auto-generates examples
targeting the standard's org-specific rules and writes the file.

Auto-generated files are marked `generated_by: auto` and should be reviewed before
treating results as authoritative. A well-curated test file has:
- ~75% non-compliant examples (they drive the lift signal)
- At least one compliant "trap" case (a correct-but-unusual pattern)
- Violations spread across at least 5 distinct R-N rules

## Supported Artifact Types

Language-agnostic standards and language guides only. For enforcement policies and
AGENTS.md, use `rr-standards:validate`.

## How it works

The skill writes a `run_manifest.json` to the workspace and invokes
`test-runner/run_tests.py` — a stdlib-only Python script that:
1. Spawns one `threading.Thread` per test
2. Each thread calls `claude -p "<prompt>"` for both `with_standard` and `without_standard`
3. Parses each JSON response and writes `outputs/output.md`, `grading.json`, `test_metadata.json`
4. Aggregates accuracy metrics and writes `benchmark.json` (and `ci_report.json` in CI mode)

`without_standard` results are reused across iterations (deterministic per snippet),
so re-runs only add the cost of the `with_standard` evaluations.

## Related

- `rr-standards:validate` — structural quality checks (run this first)
- `rr-standards:author` — guided artifact authoring (calls validate automatically)
- Skill workflow: `.forge/efforts/rr-standards-plugin/spec/skills.md § rr-standards:test`
- Test file schema: `plugins/forge/standards/TAXONOMY.md § Companion Artifacts`
