#!/usr/bin/env python3
"""
rr-standards:test harness — run_tests.py

Reads a run manifest, spawns one thread per test case, runs with_<ctx> and
without_<ctx> evaluations via the claude CLI, writes workspace files, and aggregates
benchmark results.

Usage:
    python3 run_tests.py --manifest <path-to-run_manifest.json>

Exit codes:
    0 — completed successfully (pass or fail — verdict is in benchmark.json / ci_report.json)
    1 — system error (claude CLI not found, manifest missing, etc.)

Note: low lift (< 0.20) produces a generation_lift_warning in the output but does NOT
affect the exit code. Test-accuracy FAIL is also exit 0 — the verdict is in the output.
"""

import json
import math
import os
import shutil
import subprocess
import sys
import threading
from datetime import date
from pathlib import Path


# ---------------------------------------------------------------------------
# Prompt builders
# ---------------------------------------------------------------------------

def build_with_prompt(test, ctx, standard_content, guide_content=None):
    """Build the with_<ctx> evaluation prompt — blind, no expectations."""
    if ctx == "guide":
        context_section = (
            f"Standard content:\n---\n{standard_content}\n---\n\n"
            f"Language guide content:\n---\n{guide_content}\n---"
        )
        evaluation_target = (
            "whether this code snippet correctly implements the standard as the guide describes"
        )
    else:
        context_section = f"Standard content:\n---\n{standard_content}\n---"
        evaluation_target = "compliance with the standard"

    return f"""You are evaluating an artifact snippet for {evaluation_target}.

{context_section}

Artifact snippet to evaluate:
---
{test["artifact_snippet"]}
---

Evaluate the snippet and return ONLY a JSON object — no markdown fences, no explanation, just raw JSON. Your entire response must be parseable by json.loads() with no surrounding text.
{{
  "verdict": "compliant or non_compliant",
  "confidence": 85,
  "reasoning": "detailed explanation",
  "rules_cited": [{{"rule": "R-1", "note": "how it applies"}}],
  "violations": [{{"rule": "R-1", "evidence": "specific evidence from snippet"}}]
}}"""


def build_without_prompt(test, ctx):
    """Build the without_<ctx> evaluation prompt — blind, no expectations."""
    entity = "code snippet" if ctx == "guide" else "artifact snippet"

    return f"""You are a baseline evaluator for a {entity}.

IMPORTANT — evaluate using ONLY your general knowledge of best practices for the domain.
Do NOT reference any specific standards documents, guides, or external resources.
Do NOT use the Read, Glob, Grep, Bash, WebFetch, WebSearch, or any file-reading tools.
Your evaluation must be based SOLELY on the snippet provided in this message.

{entity.capitalize()} to evaluate:
---
{test["artifact_snippet"]}
---

Evaluate the snippet using only general domain best practices and return ONLY a JSON object — no markdown fences, no explanation, just raw JSON. Your entire response must be parseable by json.loads() with no surrounding text.
{{
  "verdict": "compliant or non_compliant",
  "confidence": 85,
  "reasoning": "detailed explanation based only on general best practices",
  "principles_cited": [{{"principle": "principle name", "note": "how it applies"}}]
}}"""


def build_grading_prompt(phase1_output, expected_verdict, expectations):
    """Build the Phase 2 grading prompt — grades the reviewer's output against expectations."""
    expectations_block = "\n".join(
        f"{i + 1}. {e}" for i, e in enumerate(expectations)
    )
    total = len(expectations)

    return f"""You are grading a compliance reviewer's output against a set of expectations.

Reviewer's output:
---
{phase1_output}
---

Expected verdict: {expected_verdict}

Grade each expectation as passed or not passed based solely on what the reviewer said above.
Do NOT re-evaluate the artifact yourself. Only check whether the reviewer's output satisfies each assertion.

Expectations to grade:
{expectations_block}

Return ONLY a JSON object — no markdown fences, no explanation, just raw JSON. Your entire response must be parseable by json.loads() with no surrounding text.
{{
  "expectations": [{{"text": "expectation text", "passed": true, "evidence": "direct quote or paraphrase from reviewer output"}}],
  "passed": 3,
  "total": {total},
  "pass_rate": 1.0
}}

Set passed = number of expectations with passed=true, pass_rate = passed/{total}."""


# ---------------------------------------------------------------------------
# Claude CLI invocation
# ---------------------------------------------------------------------------

def run_claude(prompt, timeout=300):
    """Invoke claude CLI with the given prompt via stdin. Returns stdout text."""
    try:
        result = subprocess.run(
            ["claude", "--print"],
            input=prompt,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            stderr_preview = result.stderr[:500] if result.stderr else "(no stderr)"
            raise RuntimeError(f"claude exited {result.returncode}: {stderr_preview}")
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"claude timed out after {timeout}s")
    except FileNotFoundError:
        raise RuntimeError(
            "claude CLI not found. Ensure claude is installed and available in PATH."
        )


def parse_json_response(text):
    """Extract and parse JSON from claude output, tolerating surrounding prose."""
    stripped = text.strip()

    # Try direct parse
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass

    # Use raw_decode to find the first valid JSON object anywhere in the text.
    # raw_decode is string-aware (braces inside quoted strings don't confuse it)
    # and stops exactly at the end of the JSON object, ignoring any trailing text
    # (markdown fences, explanations, etc.).
    decoder = json.JSONDecoder()
    start = stripped.find("{")
    while start != -1:
        try:
            obj, _ = decoder.raw_decode(stripped, start)
            return obj
        except json.JSONDecodeError:
            start = stripped.find("{", start + 1)

    raise ValueError(f"No valid JSON found in claude response: {text[:300]!r}")


# ---------------------------------------------------------------------------
# Workspace file writers
# ---------------------------------------------------------------------------

def format_output_md(test_id, configuration, data):
    """Generate the contents of outputs/output.md from parsed response data."""
    lines = [
        f"# Test: {test_id} — {configuration}",
        "",
        "## Verdict",
        data.get("verdict", "unknown"),
        "",
        "## Confidence",
        str(data.get("confidence", 0)),
        "",
        "## Reasoning",
        data.get("reasoning", ""),
        "",
    ]

    rules_cited = data.get("rules_cited", [])
    if rules_cited:
        lines.append("## Rules cited")
        for r in rules_cited:
            lines.append(f"- {r.get('rule', '?')}: {r.get('note', '')}")
        lines.append("")

    violations = data.get("violations", [])
    if violations:
        lines.append("## Violations")
        for v in violations:
            lines.append(f"- {v.get('rule', '?')}: {v.get('evidence', '')}")
        lines.append("")

    principles = data.get("principles_cited", [])
    if principles:
        lines.append("## Principles cited")
        for p in principles:
            lines.append(f"- {p.get('principle', '?')}: {p.get('note', '')}")
        lines.append("")

    return "\n".join(lines)


def write_output_file(workspace_dir, test_id, configuration, phase1_data, artifact_snippet, full_prompt=None, test_name=None):
    """Phase 1: write outputs/output.md, test_metadata.json, and optionally prompt.txt."""
    workspace_dir = Path(workspace_dir)
    outputs_dir = workspace_dir / "outputs"
    outputs_dir.mkdir(parents=True, exist_ok=True)

    # outputs/output.md
    (outputs_dir / "output.md").write_text(
        format_output_md(test_id, configuration, phase1_data), encoding="utf-8"
    )

    # test_metadata.json
    metadata = {"test_id": test_id, "prompt": artifact_snippet}
    if test_name:
        metadata["test_name"] = test_name
    (workspace_dir / "test_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    # prompt.txt — full prompt passed to claude (used by test viewer)
    if full_prompt is not None:
        (workspace_dir / "prompt.txt").write_text(full_prompt, encoding="utf-8")


def write_grading_file(workspace_dir, test_id, configuration, grading_data, verdict_correct):
    """Phase 2: write grading.json from the grading-pass output."""
    workspace_dir = Path(workspace_dir)

    expectations = grading_data.get("expectations", [])
    passed = grading_data.get("passed", sum(1 for e in expectations if e.get("passed", False)))
    total = grading_data.get("total", len(expectations))
    pass_rate = round(passed / total, 4) if total > 0 else 0.0

    grading = {
        "test_id": test_id,
        "configuration": configuration,
        "verdict_correct": verdict_correct,
        "expectations": expectations,
        "summary": {
            "passed": passed,
            "failed": total - passed,
            "total": total,
            "pass_rate": pass_rate,
        },
    }
    (workspace_dir / "grading.json").write_text(
        json.dumps(grading, indent=2), encoding="utf-8"
    )
    return grading


# ---------------------------------------------------------------------------
# Thread worker
# ---------------------------------------------------------------------------

def _run_two_phase(test, cfg_label, phase1_prompt, workspace_dir, errors, lock):
    """Run Phase 1 (blind eval) then Phase 2 (grading) for one configuration.

    Returns a summary dict with test_id, configuration, verdict_correct, pass_rate.
    On any error returns a zero-score summary and appends to errors.
    """
    test_id = test["id"]
    artifact_snippet = test["artifact_snippet"]
    expected_verdict = test["expected_verdict"]
    expectations = test["expectations"]

    try:
        # Phase 1 — blind evaluation (no expectations in prompt)
        raw1 = run_claude(phase1_prompt)
        phase1_data = parse_json_response(raw1)
        phase1_verdict = phase1_data.get("verdict", "")

        write_output_file(
            workspace_dir, test_id, cfg_label, phase1_data, artifact_snippet,
            full_prompt=phase1_prompt, test_name=test.get("name"),
        )

        # Phase 2 — grading pass (grades phase1 output against expectations)
        grading_prompt = build_grading_prompt(
            json.dumps(phase1_data, indent=2), expected_verdict, expectations
        )
        raw2 = run_claude(grading_prompt)
        grading_data = parse_json_response(raw2)

        verdict_correct = (phase1_verdict == expected_verdict)
        grading = write_grading_file(
            workspace_dir, test_id, cfg_label, grading_data, verdict_correct
        )

        return {
            "test_id": test_id,
            "configuration": cfg_label,
            "verdict_correct": verdict_correct,
            "pass_rate": grading["summary"]["pass_rate"],
        }

    except Exception as exc:
        with lock:
            errors.append(f"{test_id}/{cfg_label}: {exc}")
        return {
            "test_id": test_id,
            "configuration": cfg_label,
            "verdict_correct": False,
            "pass_rate": 0.0,
            "error": str(exc),
        }


def evaluate_test(test, ctx, standard_content, guide_content, workspace_base,
                  results, lock, errors):
    """Thread target: run with_<ctx> and without_<ctx> for one test, two phases each."""
    test_id = test["id"]
    workspace_base = Path(workspace_base)
    with_cfg = f"with_{ctx}"
    without_cfg = f"without_{ctx}"

    # --- with_<ctx> ---
    with_prompt = build_with_prompt(test, ctx, standard_content, guide_content)
    summary = _run_two_phase(
        test, with_cfg, with_prompt,
        workspace_base / test_id / with_cfg,
        errors, lock,
    )
    with lock:
        results.append(summary)

    # --- without_<ctx>: skip if reusing from prior iteration ---
    if test.get("reuse_without", False):
        grading_path = workspace_base / test_id / without_cfg / "grading.json"
        if grading_path.exists():
            g = json.loads(grading_path.read_text(encoding="utf-8"))
            summary = {
                "test_id": test_id,
                "configuration": without_cfg,
                "verdict_correct": g.get("verdict_correct", False),
                "pass_rate": g["summary"]["pass_rate"],
            }
        else:
            summary = {
                "test_id": test_id,
                "configuration": without_cfg,
                "verdict_correct": False,
                "pass_rate": 0.0,
                "error": "reused grading file not found",
            }
            with lock:
                errors.append(f"{test_id}/{without_cfg}: reused grading file not found at {grading_path}")
        with lock:
            results.append(summary)
            print(f"  {test_id}: done (without_{ctx} reused)", flush=True)
        return

    # --- without_<ctx> ---
    without_prompt = build_without_prompt(test, ctx)
    summary = _run_two_phase(
        test, without_cfg, without_prompt,
        workspace_base / test_id / without_cfg,
        errors, lock,
    )
    with lock:
        results.append(summary)
        print(f"  {test_id}: done", flush=True)


# ---------------------------------------------------------------------------
# Aggregation helpers
# ---------------------------------------------------------------------------

def _mean(values):
    return sum(values) / len(values) if values else 0.0


def _stddev(values):
    if len(values) < 2:
        return 0.0
    m = _mean(values)
    return math.sqrt(sum((v - m) ** 2 for v in values) / len(values))


def build_benchmark(ctx, results, tests, standard_name, workspace_base):
    """Aggregate results into benchmark.json and return key metrics."""
    with_cfg = f"with_{ctx}"
    without_cfg = f"without_{ctx}"
    workspace_base = Path(workspace_base)

    with_results = [r for r in results if r["configuration"] == with_cfg]
    without_results = [r for r in results if r["configuration"] == without_cfg]

    with_accuracy = (
        sum(1 for r in with_results if r["verdict_correct"]) / len(with_results)
        if with_results else 0.0
    )
    without_accuracy = (
        sum(1 for r in without_results if r["verdict_correct"]) / len(without_results)
        if without_results else 0.0
    )
    lift = with_accuracy - without_accuracy
    verdict = "pass" if with_accuracy >= 0.80 else "fail"
    generation_lift_warning = lift < 0.20

    # Build runs array from workspace grading files (preserves expectation detail)
    runs = []
    eval_id = 0
    for test in tests:
        test_id = test["id"]
        for cfg in [with_cfg, without_cfg]:
            gp = workspace_base / test_id / cfg / "grading.json"
            if gp.exists():
                g = json.loads(gp.read_text(encoding="utf-8"))
                runs.append({
                    "eval_id": eval_id,
                    "eval_name": f"{standard_name} — {test_id}",
                    "configuration": cfg,
                    "run_number": 1,
                    "result": {
                        "pass_rate": g["summary"]["pass_rate"],
                        "passed": g["summary"]["passed"],
                        "total": g["summary"]["total"],
                        "errors": 0,
                    },
                    "expectations": g.get("expectations", []),
                })
                eval_id += 1

    with_rates = [r["pass_rate"] for r in with_results]
    without_rates = [r["pass_rate"] for r in without_results]
    w_pct = round(with_accuracy * 100)
    wo_pct = round(without_accuracy * 100)
    lift_pct = round(lift * 100, 1)
    pass_label = "PASS" if verdict == "pass" else "FAIL"
    lift_label = "WARNING" if generation_lift_warning else "OK"

    benchmark = {
        "run_summary": {
            with_cfg: {
                "pass_rate": {
                    "mean": round(_mean(with_rates), 4),
                    "stddev": round(_stddev(with_rates), 4),
                }
            },
            without_cfg: {
                "pass_rate": {
                    "mean": round(_mean(without_rates), 4),
                    "stddev": round(_stddev(without_rates), 4),
                }
            },
            "delta": {"pass_rate": f"+{lift_pct}%"},
        },
        "metadata": {
            "skill_name": "rr-standards:test",
            "timestamp": date.today().isoformat(),
            "evals_run": [standard_name],
            "runs_per_configuration": 1,
        },
        "notes": [
            f"with_{ctx} verdict accuracy: "
            f"{sum(1 for r in with_results if r['verdict_correct'])}/{len(with_results)} = {w_pct}%",
            f"without_{ctx} verdict accuracy: "
            f"{sum(1 for r in without_results if r['verdict_correct'])}/{len(without_results)} = {wo_pct}%",
            f"test-accuracy: {pass_label} "
            f"(with_acc={w_pct}% {'≥' if with_accuracy >= 0.80 else '<'} 80%)",
            f"generation-lift: {lift_label} (lift=+{lift_pct}% {'≥' if lift >= 0.20 else '<'} 20% threshold)",
        ],
        "runs": runs,
    }

    (workspace_base / "benchmark.json").write_text(
        json.dumps(benchmark, indent=2), encoding="utf-8"
    )
    return benchmark, with_accuracy, without_accuracy, lift, verdict, generation_lift_warning


def build_ci_report(ctx, results, tests, with_accuracy, without_accuracy, lift, verdict, generation_lift_warning):
    """Build the CI JSON report dict."""
    with_cfg = f"with_{ctx}"
    without_cfg = f"without_{ctx}"

    test_rows = []
    for test in tests:
        test_id = test["id"]
        wr = next(
            (r for r in results if r["test_id"] == test_id and r["configuration"] == with_cfg),
            None,
        )
        wor = next(
            (r for r in results if r["test_id"] == test_id and r["configuration"] == without_cfg),
            None,
        )
        test_rows.append({
            "test_id": test_id,
            "expected_verdict": test.get("expected_verdict", "unknown"),
            "with_verdict_correct": wr["verdict_correct"] if wr else False,
            "without_verdict_correct": wor["verdict_correct"] if wor else False,
            "with_pass_rate": wr["pass_rate"] if wr else 0.0,
            "without_pass_rate": wor["pass_rate"] if wor else 0.0,
        })

    return {
        "verdict": {
            "result": verdict,
            "with_accuracy": round(with_accuracy, 4),
            "without_accuracy": round(without_accuracy, 4),
            "lift": round(lift, 4),
            "generation_lift_warning": generation_lift_warning,
        },
        "tests": test_rows,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="rr-standards:test harness — runs behavioral evaluations via claude CLI"
    )
    parser.add_argument("--manifest", required=True, help="Path to run_manifest.json")
    args = parser.parse_args()

    manifest_path = Path(args.manifest)
    if not manifest_path.exists():
        print(f"ERROR: Manifest not found: {manifest_path}", file=sys.stderr)
        sys.exit(1)

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"ERROR: Failed to parse manifest: {exc}", file=sys.stderr)
        sys.exit(1)

    ctx = manifest["ctx"]
    standard_content = manifest["standard_content"]
    standard_name = manifest.get("standard_name", "standard")
    guide_content = manifest.get("guide_content")
    workspace_base = Path(manifest["workspace_base"])
    ci_mode = manifest.get("ci_mode", False)
    tests = manifest["tests"]
    reuse_from = manifest.get("reuse_from")

    # Copy reused without_<ctx> results from previous iteration
    if reuse_from:
        without_cfg = f"without_{ctx}"
        for test in tests:
            if test.get("reuse_without", False):
                test_id = test["id"]
                src = Path(reuse_from) / test_id / without_cfg
                dst = workspace_base / test_id / without_cfg
                if src.exists() and not dst.exists():
                    shutil.copytree(str(src), str(dst))

    # Spawn one thread per test
    results = []
    errors = []
    lock = threading.Lock()

    # In CI mode, progress output goes to stderr so stdout is reserved for clean JSON
    _out = sys.stderr if ci_mode else sys.stdout

    n_tests = len(tests)
    reused = sum(1 for t in tests if t.get("reuse_without", False))
    n_evals = n_tests * 2 - reused
    print(f"Running {n_tests} tests ({n_evals} evaluations)...", file=_out, flush=True)

    threads = [
        threading.Thread(
            target=evaluate_test,
            args=(
                test, ctx, standard_content, guide_content,
                workspace_base, results, lock, errors,
            ),
            daemon=True,
        )
        for test in tests
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    if errors:
        print(f"\n{len(errors)} evaluation error(s):", file=sys.stderr)
        for e in errors:
            print(f"  {e}", file=sys.stderr)

    # Aggregate and write benchmark.json
    try:
        benchmark, with_accuracy, without_accuracy, lift, verdict, generation_lift_warning = build_benchmark(
            ctx, results, tests, standard_name, workspace_base
        )
    except Exception as exc:
        print(f"ERROR: Failed to aggregate results: {exc}", file=sys.stderr)
        sys.exit(1)

    # Print summary (stderr in CI mode so stdout stays clean for JSON)
    print(f"\nResults:", file=_out, flush=True)
    print(f"  with_{ctx} accuracy:    {round(with_accuracy * 100)}%", file=_out, flush=True)
    print(f"  without_{ctx} accuracy: {round(without_accuracy * 100)}%", file=_out, flush=True)
    print(f"  lift:                   +{round(lift * 100, 1)}%", file=_out, flush=True)
    print(f"  test-accuracy:          {'PASS' if verdict == 'pass' else 'FAIL'}", file=_out, flush=True)
    if generation_lift_warning:
        print(f"  generation-lift:        WARNING (lift < 20% — standard may not improve over baseline)", file=_out, flush=True)
    else:
        print(f"  generation-lift:        OK", file=_out, flush=True)

    # CI report — write to file; SKILL.md reads and emits it (stdout stays clean here)
    if ci_mode:
        ci_report = build_ci_report(
            ctx, results, tests, with_accuracy, without_accuracy, lift, verdict, generation_lift_warning
        )
        ci_report_path = workspace_base / "ci_report.json"
        ci_report_path.write_text(json.dumps(ci_report, indent=2), encoding="utf-8")

    sys.exit(0)


if __name__ == "__main__":
    main()
