---
name: rr-standards:author
description: >
  Interactive orchestrator for creating and updating rr-standards artifacts — standards,
  enforcement policies, language guides, and AGENTS.md files. Guides the author through
  picking the artifact type, deriving the correct taxonomy path, copying the right template
  (create mode) or opening the existing file (update mode), optionally walking through each
  required section with authoring guidance, and running rr-standards:validate at the end to
  surface any quality gaps. Use this skill when: an engineer wants to create a new standard,
  enforcement policy, language guide, or AGENTS.md; when updating an existing artifact and
  wanting step-by-step guidance; or any time someone asks how to author or improve a
  standards artifact. Invoke as: /rr-standards:author
---

# rr-standards:author

Orchestrator skill — interactive. Guides an author through creating or updating a
standards artifact at the correct taxonomy path, then validates the result.

---

## Step 1 — Domain Scope Assessment (new standards and language guides only)

Run this step only when creating a **new standard or language guide** (file does not yet
exist). Skip for updates, enforcement policies, and AGENTS.md.

### A — Enumerate candidate rules

Ask the author to describe the domain. Work with them to produce a flat list of what
the standard needs to cover — not rule text, just rule topics. Examples: "URI structure",
"version placement", "JWT validation", "timestamp encoding". Aim for a complete list
before counting.

### B — Count and cluster

Count the candidates. Group them into natural clusters by asking: "Which of these rules
would be reviewed by the same person? Which would change together when the platform
changes?" Name each cluster (2–4 words).

### C — Apply the split signals

Read `plugins/forge/standards/TAXONOMY.md § Domain Scope Assessment` for the authoritative heuristics.
Apply them to the enumeration:

- **>10 rules** — checklist will exceed what a reviewer can apply reliably in one pass
- **3+ independent clusters** — rules have different owners or change rates
- **Any rule needs >3 sentences** — the rule is actually multiple sub-rules

If **no signals** are present: confirm single-file scope and proceed to Step 2.

If **any signal** is present: present the decomposition recommendation:

```
This domain has N candidate rules across K clusters:

  Cluster 1 — <name> (<N> rules): [list topics]
  Cluster 2 — <name> (<N> rules): [list topics]
  ...

I recommend splitting into K focused artifacts under <directory>/:
  <slug-1>.md   ← Cluster 1
  <slug-2>.md   ← Cluster 2
  ...
  AGENTS.md     ← routes to the right artifact for each scenario

Each will fit comfortably within its size limit with full rule depth and examples.
Does this decomposition look right, or would you like to adjust the clusters?
```

Get explicit author agreement on names and rule assignments before proceeding.

When creating multiple sub-artifacts, author them in sequence: create the AGENTS.md
skeleton first (fill it in last), then each sub-artifact in order. After all are
created, add cross-reference links to each artifact's Related section.

---

## Step 2 — Identify the Artifact

If the user has already specified the artifact type and name in their invocation (and
the domain scope assessment in Step 1 is complete), use that.
Otherwise, prompt for:

1. **Artifact type**: standard / language guide / enforcement policy / AGENTS.md
2. **Name and location**:
   - Standard: category + slug (e.g., category `storage`, slug `connection-pooling`)
   - Language guide: language + area + slug
   - Enforcement policy: path of the companion standard it covers (the policy path derives from this)
   - AGENTS.md: which directory it belongs to

Derive the **target file path** from the taxonomy location patterns:

| Artifact type | Path pattern |
|---|---|
| Standard | `standards/<category>/<slug>.md` |
| Enforcement policy | `standards/<category>/<slug>.policy.md` |
| Language guide | `languages/<lang>/guides/<area>/<slug>.md` |
| AGENTS.md | `<directory>/AGENTS.md` |

Read `plugins/forge/standards/TAXONOMY.md` if you need to confirm exact patterns or check an edge case.

---

## Step 3 — Create or Update Mode

Check whether the target file already exists.

**If the file does NOT exist → Create mode:**

Identify the correct template:

| Artifact type | Template path |
|---|---|
| Standard | `plugins/rr-standards/templates/standard-template.md` |
| Enforcement policy | `plugins/rr-standards/templates/enforcement-policy-template.md` |
| Language guide | `plugins/rr-standards/templates/language-guide-template.md` |
| AGENTS.md | `plugins/rr-standards/templates/agents-md-template.md` |

If the template file does not exist:
```
Template not found: <template-path>
Available templates in plugins/rr-standards/templates/: [list what's there]
I'll create the file with a heading scaffold based on the required sections from TAXONOMY.md.
```
Then create the file with the required section headings (from `plugins/forge/standards/TAXONOMY.md §
Required Sections`) as placeholders, and continue.

If the template exists: copy its contents to the target path, then tell the author:
```
Created <path> from template. Ready to begin.
```

**If the file ALREADY exists → Update mode:**

Show the author the current content (abbreviated if long). Confirm intent:
```
This file already exists. Do you want to:
  (u) update — edit the existing content
  (f) fresh — overwrite with a clean template copy (current content will be lost)
  (x) cancel
```
- If fresh: warn once more and confirm, then copy the template.
- If update: open the existing file — do NOT re-copy the template.
- If cancel: stop.

If the user invoked the skill with a path that points to an existing file but said "create",
treat it as update mode and confirm before proceeding. The file already exists — don't
silently overwrite it.

---

## Step 4 — Guided Walkthrough or Manual

Ask the author:

> "Would you like me to walk you through each required section, or would you prefer to
> edit the file yourself?
>
> (guided / manual)"

**If manual:** Tell them the required sections for their artifact type (from
`plugins/forge/standards/TAXONOMY.md § Required Sections`), then step back. Let them know they can
run `/rr-standards:validate <path>` when done, or return to continue with guidance.

**If guided:** Proceed to Step 4.

---

## Step 5 — Section-by-Section Walkthrough

Read the required sections for this artifact type from `plugins/forge/standards/TAXONOMY.md §
Required Sections` — the taxonomy is authoritative, don't rely only on the table below.

For each required section, in order:

1. Display the section heading and its authoring guidance (see below).
2. Show existing content for this section, or the template placeholder.
3. Prompt: *"What should go in this section? (or 'skip' to leave as-is)"*
4. If the author provides content: write it into the file.
5. If the author skips with no existing substantive content:
   insert `<!-- TODO: [Section Name] — not yet authored -->` and note that this will
   produce a blocking finding in validation (which is intentional — it creates a clear
   reminder to come back).

### Section guidance by artifact type

**Standard sections:**
- **Overview** — What the standard governs + what correct compliance produces. 2–4 sentences. No rule content — save rationale for an ADR.
- **Scope** — Precise list of what this covers (applies-to) and explicit out-of-scope exclusions. Being specific prevents scope creep.
- **Rules** — Directive imperative voice: "Use X", "Return Y", "Validate Z". Each rule gets a stable R-N heading. No language-specific code — this standard must work for all languages. One directive sentence per rule; if it takes more, split into two rules.
- **Examples** — Pseudo-code for non-obvious rules only. Explain *why* the pattern is correct. Skip self-evident rules. No language-specific syntax — runnable examples belong in language guides.
- **Related** — Links to related standards + commented-out placeholders for language guides. Keep guide placeholders even if no guides exist yet.

Note: standards do **not** have a Compliance Checklist section. Evaluation assertions belong
in the companion enforcement policy (authored immediately after the standard).

**Enforcement policy sections:**
- **Standard reference** — `Standard: <path>@<version>` — the path must resolve; the version must match the current standard version exactly.
- **Policy metadata** — Policy version (start at 1.0.0), `advisory_threshold` (integer or null), authors, last reviewed date.
- **Severity table** — One row per rule in the companion standard. Columns: Rule (R-N identifier + name, copied exactly), Assertion (binary yes/no statement a reviewer applies — e.g., "URI follows required path structure"), Severity (`blocking` / `advisory` / `informational`), Notes (optional, one line, only for non-obvious severity choices).

**Language guide sections:**
- **Overview** — What the guide covers; which standard it implements; both version numbers. Must include the `Guide: X.Y.Z | Implements: standards/<category>/<standard>.md@X.Y.Z` declaration.
- **Related standard** — Explicit link to the parent standard under `standards/`.
- **Prerequisites** — Tools, libraries, config needed. Do not restate the linter — it's declared once in the language-root AGENTS.md and applies globally.
- **Implementation** — Step-by-step with complete, runnable code. No `...` or ellipses in critical sections; incomplete examples are worse than no examples.
- **Verification** — Concrete command or observable behaviour the author can run right now to confirm correct implementation.

**AGENTS.md sections:**
- **Directory purpose** — One paragraph: what is in this directory, why it exists, how it fits in the larger structure.
- **File index** — Table: name · one-line purpose · when an agent should reference it. Every file and subdirectory in this directory must have an entry — missing entries are blocking.
- **Navigation** — At least one link to related content outside this directory.
- (Language-root AGENTS.md only) **Linter** — Linter name, config file path, declaration that all generated code must pass it. This is the single authoritative linter declaration for the language.

---

## Step 6 — Validate

After the guided walkthrough completes (or when the author signals they are done in manual
mode), invoke the validate skill:

```
/rr-standards:validate <file-path>
```

Tell the validate skill you are calling from `rr-standards:author` so it appends its
completion prompt rather than exiting silently.

Display the returned validation report inline.

**If there are blocking findings:**

```
There are N blocking issues to address before this artifact is ready to publish.
Would you like to work through them now? (yes / no)
```

- If yes: guide the author through each blocking finding in turn, offer to make the edits, then re-run validation.
- If no: remind them to run `/rr-standards:validate <path>` again after fixing the issues.

**If there are only informational findings (or none):**

```
Validation complete — N blocking issues (0), N informational suggestions.
The artifact is ready to publish.
```

Offer to help address any informational suggestions if the author wants to.

---

## Error Cases

- **Template missing**: Surface the path, list available templates, offer a minimal
  heading scaffold derived from TAXONOMY.md required sections.
- **Derived path conflicts with taxonomy**: Warn before creating if the path would be
  placed outside the correct taxonomy pattern.
- **Author skips required section with no content**: Insert TODO placeholder; note it
  will fail validation. This is by design — makes gaps visible.
- **Validate skill unavailable**: Instruct the author to run
  `/rr-standards:validate <path>` manually when done.
