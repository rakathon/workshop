# rr-standards:author

Interactive guided workflow for creating and updating rr-standards artifacts. Handles
path derivation, template copying, section-by-section authoring guidance, and ends with
an automated quality check.

## When to Use

- Creating a new standard from scratch
- Writing an enforcement policy for an existing standard
- Starting or updating a language guide
- Adding an AGENTS.md to a new directory
- Updating an existing artifact and wanting section-by-section guidance

## Usage

```
/rr-standards:author
```

No arguments required. The skill prompts for artifact type, name, and location.

You can also provide context upfront to skip the initial prompts:

```
/rr-standards:author I want to create a storage standard for connection pooling
/rr-standards:author update standards/api/rest.md
```

## What Happens

1. **Identify** — pick artifact type and name; the skill derives the correct taxonomy path
2. **Create or update** — new artifacts start from the appropriate template; existing files are opened without overwriting
3. **Walkthrough (optional)** — guided section-by-section authoring with hints for each section type, or manual mode if you prefer to write it yourself
4. **Validate** — runs `rr-standards:validate` when done; shows blocking gaps and informational suggestions

## Artifact Types and Paths

| Type | Path pattern |
|---|---|
| Standard | `standards/<category>/<slug>.md` |
| Enforcement policy | `standards/<category>/<slug>.policy.md` |
| Language guide | `languages/<lang>/guides/<area>/<slug>.md` |
| AGENTS.md | `<directory>/AGENTS.md` |

## Templates

| Artifact type | Template |
|---|---|
| Standard | `plugins/rr-standards/templates/standard-template.md` |
| Enforcement policy | `plugins/rr-standards/templates/enforcement-policy-template.md` |
| Language guide | `plugins/rr-standards/templates/language-guide-template.md` |
| AGENTS.md | `plugins/rr-standards/templates/agents-md-template.md` |

## Related

- [`rr-standards:validate`](../validate/README.md) — run this directly for a quality check without the guided walkthrough
- [`plugins/forge/standards/TAXONOMY.md`](../../plugins/forge/standards/TAXONOMY.md) — artifact type definitions, path patterns, and required sections
