# rr-standards:validate

Validates a single standards artifact against the quality checklist for its type.
Produces a blocking/informational gap report for authors and a machine-readable JSON
record for CI pipelines.

## Purpose

`rr-standards:validate` checks that an artifact — a standard, language guide,
enforcement policy, or AGENTS.md — meets the structural and quality requirements
defined for its type. It detects the artifact type automatically from the file path,
loads the applicable checklist, and reports blocking gaps (must fix before publishing)
and informational findings (should fix).

This skill is invoked:
- By `rr-standards:author` automatically after each authoring session
- Directly by an author who wants a quality check at any point
- By CI to gate PRs that modify standards artifacts

For **behavioral effectiveness testing** (does the standard measurably improve LLM
accuracy?), use `rr-standards:test` after structural checks pass.

## Usage

```bash
# Structural validation — human-readable report
/rr-standards:validate plugins/forge/standards/api/rest/contracts.md

# CI mode — machine-readable JSON; exit 1 on FAIL
/rr-standards:validate plugins/forge/standards/api/rest/contracts.md --ci

# Directory mode — validate all artifacts in the directory
/rr-standards:validate plugins/forge/standards/api/rest/
```

## Output Modes

### Interactive (default)

```
## Validation: plugins/forge/standards/api/rest/contracts.md
Artifact type: Language-agnostic standard

**PASS** (0 blocking, 1 informational)

### Should fix (informational)
- [metadata] No active links in Related section
  Evidence: All cross-references are commented placeholders
  Fix: Uncomment links as companion standards and guides are authored
```

### CI mode (`--ci`)

Emits a JSON record conforming to the review output schema. Used for branch protection,
metrics, and audit tooling.

- Exit code **0** — PASS
- Exit code **1** — FAIL or ERROR

## Flags

| Flag | Description |
|------|-------------|
| `--ci` | Machine-readable JSON output; exit 1 on FAIL |

## Artifact Types Validated

| Type | Detected when |
|------|--------------|
| Language-agnostic standard | Path starts with `standards/` and ends in `.md` (not `.policy.md`) |
| Language guide | Path starts with `languages/` and contains `/guides/` |
| Enforcement policy | Filename ends in `.policy.md` |
| AGENTS.md | Filename is `AGENTS.md` |

Type detection uses the ordered rules in `plugins/forge/standards/TAXONOMY.md`.
Files that don't match any type are skipped (not an error).
`--active` and `--iterations` are supported for language-agnostic standards and language guides.
For standards, `--active` evaluates design artifact compliance. For language guides, it
evaluates whether code snippets correctly implement the parent standard.

## Check IDs

Each check has a stable ID used as a join key in metrics. Checks are never renamed.

| Check | Applies to | Severity |
|-------|-----------|---------|
| `required-sections` | All types | Blocking |
| `rule-identifiers` | Standard | Blocking |
| `size-limit` | All types | Blocking |
| `compliance-checklist` | Standard | Blocking |
| `severity-values` | Policy | Blocking |
| `policy-completeness` | Policy | Blocking |
| `implements-declaration` | Language guide | Blocking |
| `related-standard-link` | Language guide | Blocking |
| `file-index-complete` | AGENTS.md | Blocking |
| `links` | All types | Blocking |
| `rule-quality` | Standard | Informational |
| `examples-quality` | Standard, language guide | Informational |
| `metadata` | Standard | Informational |
| `no-rule-text` | Policy | Blocking |
| `no-rule-restatement` | Language guide | Informational |
| `entry-length` | AGENTS.md | Informational |

## Related

- `rr-standards:test` — behavioral effectiveness testing (run after validate passes)
- `rr-standards:author` — guided artifact authoring (calls validate automatically)
- Skill workflow: `.forge/efforts/rr-standards-plugin/spec/skills.md § rr-standards:validate`
- Output schema: `.forge/efforts/forge-plugin/spec/review-output-schema.md`
