---
name: rr-standards:validate
description: >
  Validates a single rr-standards artifact (standard, language guide, enforcement policy, or
  AGENTS.md) against the quality checklist for its type. Produces a human-readable report in
  interactive mode, or machine-readable JSON conforming to the review output schema when --ci
  is passed. Use this skill when: an author wants a quality check after editing an artifact;
  rr-standards:author delegates validation after a walkthrough session; a CI pipeline calls it
  with --ci to gate merges on artifact quality.
  Invoke as: /rr-standards:validate <file-path-or-dir> [--ci]
---

# rr-standards:validate

Worker skill — non-interactive. Validates a single standards artifact against the quality
checklist for its detected type.

---

## Input

Parse from the invocation:
- `<file-path>` — repo-relative path to the artifact or directory (required).
  If the path resolves to a directory, follow **Directory Mode** (Step 5) instead of Steps 1–4.
- `--ci` — switches to machine-readable JSON output mode (optional)

If no file path is provided, emit a usage error:
```
Usage: /rr-standards:validate <file-path-or-dir> [--ci]
Example: /rr-standards:validate plugins/forge/standards/api/rest/contracts.md
Example: /rr-standards:validate plugins/forge/standards/api/rest/contracts.md --ci
Example: /rr-standards:validate plugins/forge/standards/api/rest/
```

---

## Step 1 — Detect Artifact Type

Read `plugins/forge/standards/TAXONOMY.md § Artifact Type Identification` and apply the ordered rules
exactly as written there — do not paraphrase or guess. The taxonomy is the authoritative
source; load it at validation time so the skill stays correct as the taxonomy evolves.

If the file path does not match any taxonomy rule, emit:
```
SKIP: <path> is not a recognized rr-standards artifact type. No validation performed.
```
Exit with code 0 in CI mode (no JSON output needed for non-artifacts).

---

## Step 2 — Read the File

Read the artifact file at the given path. If the file does not exist:
- Interactive: `ERROR: File not found: <path>`
- CI: emit an error record with `verdict.result: "error"`, `error.code: "invalid-input"`
Exit code 1.

---

## Step 3 — Run Quality Checks

Run all checks defined for the detected artifact type. For each check, record:
- `check_id` — stable identifier (never rename or reuse)
- `result` — `pass` · `fail` · `skipped`
- For each failing item within a check: the specific item text, the evidence (what was
  found or missing), and a concrete suggested fix

### Checks for: Language-Agnostic Standard

**`required-sections`** (blocking)
Verify all five required sections are present with substantive content (not just a heading
or placeholder text from the template):
- Overview
- Scope
- Rules
- Examples
- Related

A section is substantive if it contains at least one non-empty, non-placeholder line of
content under the heading. Template placeholder text (text inside `<!-- ... -->` comments,
or lines like `[Describe the standard here]`) does not count as substantive.

**`rule-identifiers`** (blocking)
Every rule in the Rules section must have a stable `R-N` identifier (e.g., `R-1`, `R-12`).
Check that: (a) at least one rule exists, and (b) every rule entry is prefixed with an
`R-N` pattern. A Rules section with no identifiers at all is a single blocking finding.
Individual rules missing identifiers each produce a separate finding.

**`size-limit`** (blocking)
File must not exceed 300 lines. Count total lines in the file. If over the limit, report
the actual line count and note that the standard must be split.

**`links`** (blocking)
All internal links (links pointing to files within this repository) must resolve to files
that exist. Check every `[text](path)` or `[text](path#anchor)` link in the file. For
each broken link, record the link text, the target path, and confirm the file is absent.
External links (http/https) are not checked.

**`rule-quality`** (informational)
Evaluate each rule against the dual-use criterion: can it be read as both a generation
directive and an evaluation criterion? Rules that are purely procedural ("follow the
guide") or that contain language-specific code each produce an informational finding.

**`examples-quality`** (informational)
- At least one positive (compliant) example must be present
- Code blocks must specify a language identifier (e.g., ` ```go `)
- Examples must not use obvious placeholder names (`foo`, `bar`, `test123`) in
  production-pattern code

**`metadata`** (informational)
- A semantic version number must be declared (format: `MAJOR.MINOR.PATCH`)
- Related section links must be present and resolve

---

### Checks for: Language Guide

**`required-sections`** (blocking)
Verify all five required sections are present with substantive content:
- Overview
- Related standard
- Prerequisites
- Implementation
- Verification (must include a concrete command or observable behaviour)

A language guide may optionally reference a companion standard. If the Overview
contains an `Implements:` declaration, it must be well-formed (see
`implements-declaration`). If no such declaration is present, the guide is treated
as standalone and no standard reference is required.

**`size-limit`** (blocking)
File must not exceed 500 lines per file (for single-file guides) or 500 lines per
sub-guide file (for directory guides).

**`implements-declaration`** (blocking)
This check is conditional. Scan the Overview section for an `Implements:` token:
- If an `Implements:` declaration is present, it must be well-formed:
  `Guide: X.Y.Z | Implements: standards/<category>/<standard>.md@X.Y.Z`
  A malformed declaration (present but not matching the expected form) is a blocking finding.
- If no `Implements:` declaration is present, this check passes — the guide is
  standalone and is not required to implement a specific standard.

**`related-standard-link`** (blocking)
This check is conditional. Scan the Related standard section for any link whose target
starts with `standards/`:
- If such a link is present, it must resolve to an existing file — a broken link is a
  blocking finding.
- If no link to `standards/` is present, this check passes — the guide is standalone
  and is not required to reference a standard.

**`examples-quality`** (informational)
All code examples must be complete and runnable — no `...` or ellipses in critical
sections, no incomplete function bodies. Code blocks must specify a language identifier.

**`no-rule-restatement`** (informational)
Only applies when the guide has a resolvable `Implements:` declaration pointing to an
existing standard. If so, the guide should not restate rules from that standard verbatim
— it should show how to satisfy them. If verbatim copying is detected, surface as
informational. Skip this check for standalone guides (no `Implements:` declaration or
standard not found).

**`links`** (blocking)
Same as for standards — all internal links must resolve.

---

### Checks for: Enforcement Policy

**`required-sections`** (blocking)
Verify all three required sections are present with substantive content:
- Standard reference (path and version of the companion standard or language guide)
- Policy metadata (policy version, `advisory_threshold`, authors, last reviewed date)
- Severity table (at minimum a header row and one data row; must have Rule, Assertion,
  Severity, and Notes columns)

**`severity-values`** (blocking)
Every severity value in the severity table must be exactly `blocking`, `advisory`, or
`informational`. Any other value is a blocking finding. Check each row in the table.

**`policy-completeness`** (blocking)
Derive the companion standard path from the Standard reference section of the policy
file — it must contain a repo-relative path to the companion standard or language guide
(e.g., `plugins/forge/standards/api/rest/contracts.md`). If the Standard reference
section is absent or the path is not parseable, surface as an informational finding
(cannot verify completeness without a resolvable path). If the path is parseable but
the file does not exist, that is a blocking finding (broken standard reference).

If the companion standard file exists and can be read:
- Every `R-N` identifier in the companion standard must have exactly one row in the
  severity table — missing rows are a blocking finding per missing rule
- No row in the severity table may reference an `R-N` identifier absent from the
  companion standard — stale rows are a blocking finding per stale row
- Every row must have a non-empty Assertion column — a missing assertion is a blocking
  finding per row (the assertion is the evaluation contract for that rule)

**`no-rule-text`** (blocking)
The Notes column must not contain rule text (imperative directives or significant prose
restating the rule). Assertion text in the Assertion column is expected and correct —
it is evaluation language, not rule text. Flag as blocking only when the Notes column
contains what appears to be a rule definition.

**`size-limit`** (blocking)
File must not exceed 150 lines.

**`links`** (blocking)
All internal links must resolve.

---

### Checks for: AGENTS.md

**`required-sections`** (blocking)
Verify all three required sections are present with substantive content:
- Directory purpose (one-paragraph description)
- File index (table with name, one-line purpose, and when-to-use for every file and
  subdirectory in the containing directory)

For language-version AGENTS.md files (`languages/<lang>/<version>/AGENTS.md`), also check:
- Linter section present (linter name, config file path, and declaration that all
  generated code must pass it)

Note: the Linter section is NOT required for language-root AGENTS.md files
(`languages/<lang>/AGENTS.md`) — only for versioned language AGENTS.md files.

**`file-index-complete`** (blocking)
List the actual files and subdirectories in the directory containing the AGENTS.md.
Every one of them must have an entry in the file index. Missing entries are blocking
findings.

**`size-limit`** (blocking)
File must not exceed 100 lines.

**`entry-length`** (informational)
File index entries should be one line each — paragraph-length descriptions defeat the
purpose of a navigation aid.

---

## Step 4 — Produce Output

### Stable check IDs (never rename or reuse)

| `check_id` | Applies to | Category |
|---|---|---|
| `required-sections` | all types | `quality` |
| `rule-identifiers` | standard | `quality` |
| `size-limit` | all types | `quality` |
| `severity-values` | policy | `quality` |
| `policy-completeness` | policy | `quality` |
| `implements-declaration` | language guide | `quality` |
| `related-standard-link` | language guide | `quality` |
| `file-index-complete` | AGENTS.md | `quality` |
| `links` | all types | `quality` |
| `rule-quality` | standard | `quality` |
| `examples-quality` | standard, language guide | `quality` |
| `metadata` | standard | `quality` |
| `no-rule-text` | policy | `quality` |
| `no-rule-restatement` | language guide | `quality` |
| `entry-length` | AGENTS.md | `quality` |

### Interactive mode (default — no `--ci` flag)

Run every check applicable to the detected artifact type (per the table above). Do not
skip any check. The `links` check runs for all types — never omit it.

Tally counts after all checks complete:
- `blocking_count` = total number of individual blocking findings across all checks
  (not the number of failing check IDs — one check can produce multiple findings)
- `informational_count` = total number of individual informational findings

```
## Validation: <file-path>
Artifact type: <detected type>

**PASS** (0 blocking, N informational)
  — or —
**FAIL** (N blocking, M informational)

### Must fix (blocking)
- [links] Placeholder link target does not resolve
  Evidence: [Contract Deprecation Guide](link-to-deprecation-guide) at line 185 — not a valid file path
  Fix: Replace with the actual relative path, or remove the link

### Should fix (informational)
- [examples-quality] Code block at line 47 has no language identifier
  Evidence: ``` with no language tag
  Fix: Add language identifier: ```java
```

Each finding is a separate bullet even when multiple findings share the same `check_id`.
The count in the header must equal the number of bullets in the corresponding section.

End with a closing prompt when the invocation argument string contains the literal token
`[from: rr-standards:author]` — this is how the author skill signals that it is the
caller. Example prompt: "Validation complete. Address the blocking findings above before
publishing this artifact."

Exit silently (no closing prompt) in all other cases.

### CI mode (`--ci` flag)

Emit a JSON record to stdout conforming to the review output schema at
`.forge/efforts/forge-plugin/spec/review-output-schema.md`. Use:
- `review.skill`: `"rr-standards:validate"`
- `target.type`: `"file"`, `target.path`: the validated file path (single-file mode only;
  directory mode uses its own JSON schema — see Step 5)
- `verdict.result`: `"pass"` or `"fail"` (never `"error"` unless a system failure occurred)
- `verdict.signal`: `"approve"` on pass, `"request-for-changes"` on fail
- `verdict.risk_level`: `null` (not applicable to standards reviews)
- `verdict.blocking_count`: count of findings in `findings[]` where `severity == "blocking"` —
  compute from the actual findings array, do not estimate
- `verdict.informational_count`: count of findings in `findings[]` where `severity == "informational"` —
  compute from the actual findings array, do not estimate
- `checks`: one entry per check run, with `result: "skipped"` for checks that don't apply
  to the detected artifact type
- `findings`: one entry per failing checklist item; `confidence` for standards validation
  findings defaults to 95 (these are structural checks, not heuristic judgments)

Exit code 0. The verdict is communicated in the JSON output. Exit code 1 only on system errors (file not found, unreadable artifact, etc.).

---

## Step 5 — Directory Mode

Activated when `<file-path>` resolves to a directory. Replaces Steps 1–4 entirely.

### Phase D1 — Enumerate artifacts

List all files in the directory (non-recursive). Classify each file using the TAXONOMY.md
rules. Build a list of **all recognized artifacts** — every file matching a recognized
taxonomy type.

Skip `.test.yaml` files and any other unrecognized files (emit one `SKIP:` line per
skipped file).

### Phase D2 — Structural validation (parallel)

Run Steps 1–4 for every artifact in the directory in parallel. Collect all results.

### Interactive mode (no `--ci`)

Emit a consolidated structural report:
```
## Validation: <directory-path>

### Structural Results

| Artifact | Type | Result | Blocking | Informational |
|----------|------|--------|----------|---------------|
| <standard>.md | Standard | FAIL | 1 | 0 |
| ...

**Overall: N artifacts — N passed, N failed**
```

### CI mode (`--ci`)

Emit a single JSON object to stdout and exit. `verdict.result` is `"fail"` if any
artifact has one or more blocking findings; `"pass"` if all artifacts pass.

```json
{
  "verdict": {
    "result": "pass",
    "blocking_count": 0,
    "informational_count": 1
  },
  "directory": "plugins/forge/standards/api/rest/",
  "summary": {
    "total": 4,
    "passed": 3,
    "failed": 1
  },
  "artifacts": [
    {
      "path": "plugins/forge/standards/api/rest/contracts.md",
      "type": "standard",
      "result": "pass",
      "blocking_count": 0,
      "informational_count": 1,
      "findings": [
        {
          "check_id": "metadata",
          "severity": "informational",
          "description": "No semantic version declared",
          "evidence": "No MAJOR.MINOR.PATCH string found in file",
          "suggested_action": "Add a version line to the Overview section"
        }
      ]
    },
    {
      "path": "plugins/forge/standards/api/rest/data.md",
      "type": "standard",
      "result": "fail",
      "blocking_count": 1,
      "informational_count": 0,
      "findings": [
        {
          "check_id": "rule-identifiers",
          "severity": "blocking",
          "description": "Rule at line 34 has no R-N identifier",
          "evidence": "Line starts with '- ' but no R-N prefix",
          "suggested_action": "Prefix the rule with R-N (e.g., R-5)"
        }
      ]
    }
  ]
}
```

Exit code 0. The verdict is communicated in the JSON output.

---
