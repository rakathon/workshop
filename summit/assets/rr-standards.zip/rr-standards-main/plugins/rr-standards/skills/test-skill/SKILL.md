---
name: rr-standards:test-skill
description: >
  Tests whether a skill's instructions measurably improve LLM task execution
  accuracy, using with/without-context evaluations via a Python test harness
  and the claude CLI. Use this skill whenever a user wants to test a skill,
  check if a skill's instructions make a difference, measure skill quality,
  run behavioral tests on a skill, or see whether a SKILL.md is effective.
  Also trigger when the user says "test my skill", "does my skill work?",
  "run skill evals", "check skill effectiveness", "benchmark this skill",
  or anything asking to evaluate or measure the impact of a skill definition.
  test-accuracy PASS requires ≥80% with-skill pass rate. Low lift (< 20%
  improvement over baseline) surfaces as an informational generation-lift
  warning, not a FAIL. Supports --ci for CI pipeline use and --iterations N
  for iterative improvement loops.
  Invoke as: /rr-standards:test-skill <skill-path> [--ci] [--iterations N] [--clean] [--ids id,id]
---

# rr-standards:test-skill

Worker skill — non-interactive. Measures the behavioral effectiveness of a skill:
do the skill's instructions make an LLM more likely to execute a task correctly?

---

## Input

Parse from the invocation:
- `<skill-path>` — repo-relative path to a skill directory (containing `SKILL.md`), required
- `--ci` — CI mode: suppress the viewer and improvement loop; run once; emit JSON to stdout
- `--iterations N` — number of iterative improvement cycles (default: 1; ignored with `--ci`)
- `--clean` — delete the entire workspace for this skill before starting
- `--ids id,id` — run only the listed test IDs; skip all others

If no skill path is provided, emit:
```
Usage: /rr-standards:test-skill <skill-path> [--ci] [--iterations N] [--clean] [--ids id,id]
Example: /rr-standards:test-skill plugins/forge/skills/adr
Example: /rr-standards:test-skill plugins/forge/skills/adr --ci
Example: /rr-standards:test-skill plugins/forge/skills/adr --iterations 3
Example: /rr-standards:test-skill plugins/forge/skills/adr --clean --ids conversational-trigger,gap-filling
```

---

## Step 1 — Validate Skill

Read `<skill-path>/SKILL.md`. If it does not exist:
```
ERROR: No SKILL.md found at <skill-path>/SKILL.md.
       Provide the path to a skill directory, not a file.
```
Exit.

Extract the skill name from the SKILL.md frontmatter `name:` field (e.g., `forge:adr`).
Extract the skill version from `version:` if present; use `"unknown"` if absent.

---

## Step 2 — Locate or Auto-Generate test.yaml

Look for `<skill-path>/test.yaml`.

**If it exists:** read it. If `skill_version` does not match the version from SKILL.md,
emit a warning:
```
NOTE: test.yaml skill_version (<version>) does not match SKILL.md version (<version>).
      Test results may not reflect the current skill.
```
Apply `--ids` filter: keep only tests whose `id` appears in the `--ids` list (if
`--ids` was not passed, keep all).

**If it does not exist:** auto-generate an initial test suite — see § Auto-Generation.
Write it to `<skill-path>/test.yaml` and emit:
```
NOTE: No test.yaml found. Auto-generated N tests at <skill-path>/test.yaml.
      Review the auto-generated expectations before treating results as authoritative.
```

---

## Step 3 — Prepare Workspace

Derive the slug from the skill directory name (last non-empty path component, e.g.,
`plugins/forge/skills/adr` → `adr`). Check whether
`.rr-standards/validate/workspace/<slug>/` already exists with a different
`skill_path` in its `workspace_info.json` — if so, qualify the slug (e.g.,
`forge-adr`).

**If `--clean` was passed:**
```bash
rm -rf .rr-standards/validate/workspace/<slug>
```

Determine the next iteration number: scan
`.rr-standards/validate/workspace/<slug>/iteration-N/` directories; use the next
available N (start at 0).

Create the workspace:
```bash
mkdir -p .rr-standards/validate/workspace/<slug>/iteration-N
```

Write `.rr-standards/validate/workspace/<slug>/workspace_info.json`:
```json
{"skill_path": "<skill-path>", "slug": "<slug>"}
```

**Reuse `without_skill` results from the previous iteration:**
If N > 0, check whether
`.rr-standards/validate/workspace/<slug>/iteration-M/` (M = N−1) contains completed
`<test-id>/without_skill/grading.json` files. For each test that has one, mark it for
reuse — the baseline is deterministic and does not change when SKILL.md changes.
Set `no_baseline: true` in the manifest and `reuse_from` to the prior iteration path.

Emit one line when reuse applies:
```
NOTE: Reusing without_skill results from iteration M for K/total tests.
```

---

## Step 4 — Build Manifest and Run Harness

Construct the run manifest and write it to:
`.rr-standards/validate/workspace/<slug>/iteration-N/run_manifest.json`

```json
{
  "skill_path": "<skill-path>",
  "skill_name": "<name from SKILL.md frontmatter>",
  "skill_md_content": "<full text of SKILL.md>",
  "skill_dir": "<absolute path to the skill directory>",
  "workspace_base": ".rr-standards/validate/workspace/<slug>/iteration-N",
  "ci_mode": false,
  "no_baseline": false,
  "reuse_from": null,
  "before_all_tests": "<beforeAllTests value from test.yaml, or null>",
  "after_all_tests": "<afterAllTests value from test.yaml, or null>",
  "tests": [
    {
      "id": "conversational-trigger",
      "name": "Automatic ADR creation from a conversational decision statement",
      "fixture_dir": "<absolute path to fixture directory, or null>",
      "artifact_file": "<absolute path to artifact file, or null>",
      "before_test": "<beforeTest value, or null>",
      "after_test": "<afterTest value, or null>",
      "prompt": "<prompt field from test.yaml>",
      "prompt_baseline": "<prompt_baseline field from test.yaml>",
      "expectations": ["<expectation 1>", "..."]
    }
  ]
}
```

**Path resolution rules:**
- `skill_dir`: resolve `<skill-path>` to an absolute path from the repo root
- `fixture_dir` in each test: if present in test.yaml (relative to skill directory),
  join with `skill_dir` to get an absolute path
- `artifact_file` in each test: same — join with `skill_dir` if present

**SKILL.md content:** read the entire file text and embed as `skill_md_content`.
Read it fresh even if you already read it in Step 1 — the content in the manifest must
be current for this iteration.

**camelCase normalisation:** test.yaml uses camelCase (`beforeTest`, `afterTest`,
`beforeAllTests`, `afterAllTests`). The manifest uses snake_case (`before_test`,
`after_test`, `before_all_tests`, `after_all_tests`). Normalise when building the
manifest.

Now invoke the harness:
```bash
python3 <skill-base-dir>/skill-runner/run_skill_tests.py \
  --manifest ".rr-standards/validate/workspace/<slug>/iteration-N/run_manifest.json"
```

`<skill-base-dir>` is the directory containing this SKILL.md file.

Wait for the harness to complete. If it exits non-zero:
```
ERROR: Test harness failed. Check that the `claude` CLI is available in PATH.
Details: <stderr>
```
Exit.

---

## Step 5 — Collect Results and Emit Summary

Read `.rr-standards/validate/workspace/<slug>/iteration-N/benchmark.json`.

Emit:
```
Behavioral validation complete — iteration N.

Results:
  with_skill pass rate:    N%
  without_skill pass rate: N%
  Lift: +N%
  test-accuracy: PASS | FAIL
  generation-lift: OK | WARNING (lift < 20% — skill may not improve over baseline)
```

`test-accuracy` is FAIL (blocking) when `with_skill_pass_rate < 0.80`.
`generation-lift` WARNING is informational — it does not affect the verdict or exit code.

---

## Step 6 — CI Mode Exit

*Only when `--ci` was passed.*

Read `.rr-standards/validate/workspace/<slug>/iteration-N/ci_report.json` written by
the harness. Emit its contents to stdout as the sole output and exit:

```json
{
  "verdict": {
    "result": "pass",
    "with_skill_pass_rate": 0.87,
    "without_skill_pass_rate": 0.33,
    "lift": 0.53,
    "generation_lift_warning": false
  },
  "tests": [
    {
      "test_id": "conversational-trigger",
      "test_name": "Automatic ADR creation from a conversational decision statement",
      "with_skill_pass_rate": 1.0,
      "without_skill_pass_rate": 0.20,
      "passed": true
    }
  ]
}
```

- `verdict.result`: `"pass"` when `with_skill_pass_rate ≥ 0.80`; `"fail"` otherwise
- `generation_lift_warning`: `true` when `lift < 0.20`; does not affect `result`

Exit. Do not proceed to Step 7.

---

## Step 7 — Launch Viewer (interactive mode)

```bash
nohup python3 <skill-base-dir>/../shared/test-viewer/generate_review.py \
  ".rr-standards/validate/workspace/<slug>/iteration-N" \
  --skill-name "<skill-path>" \
  --benchmark ".rr-standards/validate/workspace/<slug>/iteration-N/benchmark.json" \
  > /dev/null 2>&1 &
```

If N > 0, also pass:
```
  --previous-workspace ".rr-standards/validate/workspace/<slug>/iteration-M"
```

Emit:
```
The test viewer is now running in your browser. Review each test's with_skill and
without_skill outputs side-by-side and leave feedback in the text box. When you
are done, click "Submit All Reviews".

Come back here and say "done reviewing" to apply feedback and continue.
```

Wait for the user to confirm before proceeding.

---

## Step 8 — Iterative Improvement

*(Skipped when at the `--iterations` limit. Default limit is 1 — one run, no loop.)*

**Read feedback:**

Read `.rr-standards/validate/workspace/<slug>/iteration-N/feedback.json`. If it does
not exist:
```
ERROR: No feedback found. The viewer was closed before feedback was submitted.
       Re-run to try again, or pass --clean to start fresh.
```
Exit.

**Propose improvements:**

Read `benchmark.json` to identify which tests and expectations failed. Read the
failing runs' `outputs/transcript.md` files to understand what the executor actually
did. Then read the feedback from the viewer.

Group findings by which section of SKILL.md they implicate. For each implicated
section, propose a specific change:

```
Iteration N — Proposed improvements

Section: <step or section heading in SKILL.md>
Feedback: <paraphrase of what went wrong>
Current text:
  "<current SKILL.md text>"
Proposed change:
  "<improved text>"
Reason: <why this addresses the failure>
Apply? (yes / no / edit)
```

Do not write any changes without author acceptance. `edit` means the author provides
replacement text; apply that instead.

After applying all accepted changes, re-read `SKILL.md` from disk.

**Re-run:**

Increment N and return to Step 3. Pass `no_baseline: true` in the manifest — prior
`without_skill` results are reused and only `with_skill` variants re-run.

**Convergence report** (after each iteration):

```
Improvement history:
| Iteration | with_skill | without_skill | Lift  | Sections changed       |
|-----------|------------|---------------|-------|------------------------|
| 0         | N%         | N%            | +N%   | —                      |
| 1         | N%         | N%            | +N%   | Step 4, Error handling |
```

If `with_skill_pass_rate ≥ 0.80`:
```
test-accuracy target reached at iteration N. Skill is behaviourally validated.
```
If additionally `lift ≥ 0.20`:
```
generation-lift target reached — skill measurably improves over baseline.
```

---

## Auto-Generation

When `test.yaml` does not exist, generate a minimal initial suite by reasoning from
`SKILL.md`:

1. **Identify 2–3 primary scenarios** described in SKILL.md — the most common
   invocations an author would write a test for.

2. **Focus on skill-differentiating behaviour:** only write tests for outcomes an LLM
   would be unlikely to produce correctly without the skill's instructions.
   Do not test behaviours that are obvious from the task description alone.

3. **Determine fixture need:** if SKILL.md describes filesystem operations, create
   `fixture_dir` entries pointing to `fixtures/<test-id>/`; emit a note that the
   author must populate those directories before running. If the skill operates on
   text alone, omit `fixture_dir`.

4. **Write 3–5 expectations per test** describing observable output characteristics,
   not internal steps.

Write the generated YAML to `<skill-path>/test.yaml`. If `fixture_dir` entries were
generated, also create empty `<skill-path>/fixtures/<test-id>/` directories and emit:
```
NOTE: Fixture directories created at <skill-path>/fixtures/.
      Populate them with the initial state your tests expect before running.
```
