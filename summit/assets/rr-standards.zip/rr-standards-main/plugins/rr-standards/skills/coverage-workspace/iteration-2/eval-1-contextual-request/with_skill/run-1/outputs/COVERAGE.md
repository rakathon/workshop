# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is supplementary-only for conflicting rules until updated;
  higher priority gap than absent stubs

> **Note:** `forge/standards/TAXONOMY.md` was not found. Fallback artifact type definitions
> were used for this scan. Required sections per fallback:
> Language-agnostic standard: Overview, Scope, Rules, Compliance Checklist, Examples, Related.
> Language guide: Overview, Related standard, Prerequisites, Implementation, Verification.
> Enforcement policy: Standard reference, Policy metadata, Severity table.
> AGENTS.md: Directory purpose, File index, Navigation.

---

## Standards (`standards/`)

The `forge/standards/` directory contains only a `.gitkeep` file. No standard files have
been authored yet. All expected artifacts are listed as absent so gaps are fully visible.

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | **absent** | 0 | File does not exist; entire security category is unwritten |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/overview.md` | **absent** | 0 | File does not exist |
| `observability/logging.md` | **absent** | 0 | File does not exist |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | **absent** | 0 | File does not exist |

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | **absent** | 0 | File does not exist |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | **absent** | 0 | File does not exist |
| `storage/postgresql.md` | **absent** | 0 | File does not exist |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/strategy.md` | **absent** | 0 | File does not exist |
| `testing/unit-testing.md` | **absent** | 0 | File does not exist |
| `testing/integration-testing.md` | **absent** | 0 | File does not exist |
| `testing/e2e-testing.md` | **absent** | 0 | File does not exist |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/event-driven-architectures.md` | **absent** | 0 | File does not exist |
| `messaging/message-standards.md` | **absent** | 0 | File does not exist |
| `messaging/message-contracts.md` | **absent** | 0 | File does not exist |
| `messaging/versioning.md` | **absent** | 0 | File does not exist |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | **absent** | 0 | File does not exist |
| `extension-development/security.md` | **absent** | 0 | File does not exist |
| `extension-development/testing.md` | **absent** | 0 | File does not exist |
| `extension-development/performance.md` | **absent** | 0 | File does not exist |
| `extension-development/code-organization.md` | **absent** | 0 | File does not exist |
| `extension-development/cross-browser.md` | **absent** | 0 | File does not exist |
| `extension-development/messaging.md` | **absent** | 0 | File does not exist |

### Skills

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `skills/skill-getting-started.md` | **absent** | 0 | File does not exist |
| `skills/skill-quick-reference.md` | **absent** | 0 | File does not exist |
| `skills/skill-reference-detailed.md` | **absent** | 0 | File does not exist |
| `skills/standards-patterns.md` | **absent** | 0 | File does not exist |

---

## Language Guides (`languages/`)

The `forge/languages/` directory contains only a `.gitkeep` file. No language directories
or guides have been authored yet. All expected language entries are listed as absent.

### Go

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **absent** | — | File does not exist |
| *(no guides directory)* | **absent** | — | No guides coverage for Go |

### Java

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **absent** | — | File does not exist |
| *(no guides directory)* | **absent** | — | No guides coverage for Java |

### Python

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **absent** | — | File does not exist |
| *(no guides directory)* | **absent** | — | No guides coverage for Python |

### TypeScript

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **absent** | — | File does not exist |
| *(no guides directory)* | **absent** | — | No guides coverage for TypeScript |

### Kotlin

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **absent** | — | File does not exist |
| *(no guides directory)* | **absent** | — | No guides coverage for Kotlin |

### Swift

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **absent** | — | File does not exist |
| *(no guides directory)* | **absent** | — | No guides coverage for Swift |

---

## AGENTS.md Files (`standards/`)

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/AGENTS.md` | **absent** | 0 | File does not exist; required per TAXONOMY.md for the standards/ root |
| `standards/security/AGENTS.md` | **absent** | 0 | File does not exist |
| `standards/observability/AGENTS.md` | **absent** | 0 | File does not exist |
| `standards/deployment/AGENTS.md` | **absent** | 0 | File does not exist |
| `standards/api/AGENTS.md` | **absent** | 0 | File does not exist |
| `standards/storage/AGENTS.md` | **absent** | 0 | File does not exist |
| `standards/testing/AGENTS.md` | **absent** | 0 | File does not exist |
| `standards/messaging/AGENTS.md` | **absent** | 0 | File does not exist |
| `standards/extension-development/AGENTS.md` | **absent** | 0 | File does not exist |

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | 41 |
| Complete | 0 |
| Draft | 0 |
| Stub | 0 |
| Absent | 41 |
| Major-stale | 0 |

### Top 5 Priority Gaps

1. **`standards/security/` — entirely absent.** No security standard files exist anywhere under `forge/standards/security/`. Security is the highest-risk missing domain; every application review touching auth, secrets, or PII has nothing to cite. This is the first standard to author.

2. **`standards/observability/overview.md` and `standards/observability/logging.md` — both absent.** Zero observability standards exist. Language-level logging guides cannot be properly authored without an authoritative parent standard defining what must be observed and at what severity levels.

3. **`standards/deployment/ci-cd.md` — absent.** No CI/CD standard exists. Deployment correctness is high-risk when missing; there is no canonical reference for pipeline structure, container requirements, or release gates.

4. **`standards/api/rest.md` — absent.** The REST API standard is absent. The API category is high-traffic (blocking guide authoring for Go, Java, TypeScript, Python) and is a prerequisite for design-time validation skills (`forge:spec-api`, `forge:validate-api`).

5. **All language-root AGENTS.md files absent** (Go, Java, Python, TypeScript, Kotlin, Swift). The TAXONOMY.md mandates that each language-root AGENTS.md carry a single authoritative linter declaration. None of the six language directories exist at all — no AGENTS.md, no guides. Until at least the AGENTS.md files are created, AI-agent tooling has no language-specific navigation or linter authority to consult.
