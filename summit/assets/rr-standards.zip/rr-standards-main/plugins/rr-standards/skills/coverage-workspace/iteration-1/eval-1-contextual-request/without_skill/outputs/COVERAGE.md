# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: manual scan (without skill)

**Status definitions** (see `standards/TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required taxonomy sections missing or not conforming to current R-N/Compliance Checklist structure
- **stub** — file exists; no required sections present or content is only a title/placeholder
- **absent** — file does not exist or is 0 bytes

> **Note on pre-taxonomy files:** Files authored before the TAXONOMY.md was established use
> an older structure (FS-N/NFS-N numbering, no Compliance Checklist). These files contain
> valuable content but do not conform to the current standard template. They are marked
> **draft** — migration to the new taxonomy is a follow-on task.

---

## Standards (`standards/`)

### API

| File | Status | Notes |
|------|--------|-------|
| `api/rest.md` | draft | Large, substantive file (~1257 lines pre-taxonomy); missing Scope, Rules (R-N), and Compliance Checklist sections required by taxonomy |
| `api/secure-server-to-server-comm.md` | draft | Substantive content (~111 lines); covers JWT/JWKS server-to-server auth; pre-taxonomy structure |

### Deployment

| File | Status | Notes |
|------|--------|-------|
| `deployment/ci-cd.md` | absent | Empty file (0 bytes); no content whatsoever |

### Extension Development

| File | Status | Notes |
|------|--------|-------|
| `extension-development/architecture.md` | draft | Pre-taxonomy; substantive content |
| `extension-development/code-organization.md` | draft | Pre-taxonomy; substantive content |
| `extension-development/cross-browser.md` | draft | Pre-taxonomy; substantive content |
| `extension-development/messaging.md` | draft | Pre-taxonomy; substantive content |
| `extension-development/performance.md` | draft | Pre-taxonomy; substantive content |
| `extension-development/security.md` | draft | Pre-taxonomy; covers CSP, permissions, data handling, XSS; domain-scoped (browser extensions only) |
| `extension-development/testing.md` | draft | Pre-taxonomy; substantive content |

### Messaging

| File | Status | Notes |
|------|--------|-------|
| `messaging/api-initiated-message.md` | draft | Pre-taxonomy; substantive content |
| `messaging/event-driven-architectures.md` | draft | Pre-taxonomy; substantive content |
| `messaging/kafka/message-contracts.md` | draft | Pre-taxonomy; substantive content |
| `messaging/message-contracts.md` | draft | Pre-taxonomy; substantive content |
| `messaging/message-standards.md` | draft | Pre-taxonomy; substantive content |
| `messaging/messaging.md` | stub | Near-empty; functions as a TOC (~22 lines) with no real rules or content |
| `messaging/user-initiated-message.md` | draft | Pre-taxonomy; substantive content |
| `messaging/versioning.md` | draft | Pre-taxonomy; substantive content |

### Observability

| File | Status | Notes |
|------|--------|-------|
| `observability/overview.md` | **absent** | Empty file (0 bytes) — no observability umbrella standard exists |
| `observability/logging.md` | **absent** | Empty file (0 bytes) — no logging standard exists at this level |

**Missing topics (not even a stub file):**
- `observability/metrics.md` — no metrics standard
- `observability/tracing.md` — no tracing/distributed-tracing standard
- `observability/alerting.md` — no alerting standard

### Security

| File | Status | Notes |
|------|--------|-------|
| `security/overview.md` | **absent** | Empty file (0 bytes) — no security standard exists at top level |

**Missing topics (not even a stub file):**
- `security/authentication.md` — no auth standard (auth guidance is scattered in API and language guides only)
- `security/authorization.md` — no authz standard
- `security/secrets-management.md` — no secrets-management standard
- `security/input-validation.md` — no input-validation standard
- `security/pii-data-handling.md` — no PII/data-handling standard

### Storage

| File | Status | Notes |
|------|--------|-------|
| `storage/dynamodb.md` | draft | Pre-taxonomy; substantive content (~623 lines) |
| `storage/extension-storage.md` | draft | Pre-taxonomy; substantive content (~580 lines) |
| `storage/postgresql.md` | stub | H1 title only ("RDS PostgreSQL - Guideline"); no actual content |

### Testing

| File | Status | Notes |
|------|--------|-------|
| `testing/strategy.md` | draft | Pre-taxonomy; substantive content (~279 lines) |
| `testing/unit-testing.md` | draft | Pre-taxonomy; substantive content (~619 lines); 23 FRs but uses FR-N not R-N |
| `testing/integration-testing.md` | draft | Pre-taxonomy; substantive content (~752 lines); 14 FRs |
| `testing/e2e-testing.md` | draft | Pre-taxonomy; substantive content (~528 lines) |

---

## Language Guides (`languages/`)

Style-reference files (Swift `style-guide/`, Objective-C `style-guide/`) are excluded —
they predate the taxonomy and are not implementation guides for a parent standard.

### Go

| File | Status | Notes |
|------|--------|-------|
| `go/guides/api/rest-echo.md` | stub | ~7 lines; no substantive content |
| `go/guides/deployment/build.md` | stub | ~18 lines; placeholder |
| `go/guides/deployment/containerization.md` | stub | ~32 lines; placeholder |
| `go/guides/messaging/datacontract-setup-process.md` | draft | Pre-taxonomy; substantive content (~1106 lines) |
| `go/guides/observability/logging.md` | draft | Pre-taxonomy; covers zerolog, JSON structured logging (~337 lines) |
| `go/guides/storage/database-ent.md` | stub | ~7 lines; no substantive content |
| `go/guides/testing/folder-structure.md` | draft | Pre-taxonomy; substantive content (~585 lines) |
| `go/guides/testing/testing.md` | stub | ~32 lines; placeholder |

**Missing Go guides (no file at all):**
- `go/guides/security/` — no security implementation guide for Go
- `go/guides/api/` — rest-echo.md is a stub; no real REST guide

### Java

| File | Status | Notes |
|------|--------|-------|
| `java/guides/api/rest-spring.md` | draft | Pre-taxonomy; very substantive (~1778 lines); exceeds 500-line limit |
| `java/guides/messaging/create-register-pojo.md` | draft | Pre-taxonomy; substantive content (~482 lines) |
| `java/guides/messaging/datacontract-setup-process.md` | draft | Pre-taxonomy; substantive content (~569 lines) |
| `java/guides/observability/logging-slf4j.md` | **absent** | Empty file (0 bytes) — referenced throughout but has no content |
| `java/guides/testing/e2e-test-examples.md` | draft | Pre-taxonomy; substantive content (~561 lines) |
| `java/guides/testing/folder-structure.md` | draft | Pre-taxonomy; substantive content (~717 lines) |
| `java/guides/testing/testing.md` | draft | Pre-taxonomy; very substantive (~1468 lines); exceeds 500-line limit |

**Missing Java guides (no file at all):**
- `java/guides/security/` — no security implementation guide for Java
- `java/guides/storage/` — no storage/database guide for Java

### Python

| File | Status | Notes |
|------|--------|-------|
| `python/guides/data-science/data-science.md` | draft | Pre-taxonomy; substantive content (~698 lines) |
| `python/guides/documentation/documentation.md` | draft | Pre-taxonomy; substantive content (~722 lines) |
| `python/guides/observability/logging.md` | draft | Pre-taxonomy; covers structured logging, log levels, formatters (~740 lines) |
| `python/guides/testing/folder-structure.md` | draft | Pre-taxonomy; substantive content (~281 lines) |
| `python/guides/testing/testing.md` | draft | Pre-taxonomy; substantive content (~821 lines) |

**Missing Python guides (no file at all):**
- `python/guides/api/` — referenced in AGENTS.md as `rest-fastapi.md` but file does not exist
- `python/guides/security/` — no security implementation guide for Python

### TypeScript

| File | Status | Notes |
|------|--------|-------|
| `typescript/guides/api/rest-express.md` | draft | Pre-taxonomy; substantive content (~1072 lines) |
| `typescript/guides/best-practices/typescript-best-practices.md` | draft | Pre-taxonomy; substantive content (~1196 lines) |
| `typescript/guides/setup/project-setup.md` | draft | Pre-taxonomy; substantive content (~604 lines) |
| `typescript/guides/setup/starter-tsconfig-notes.md` | draft | Pre-taxonomy; substantive content (~394 lines) |
| `typescript/guides/testing/folder-structure.md` | draft | Pre-taxonomy; substantive content (~451 lines) |
| `typescript/guides/testing/testing-guide.md` | draft | Pre-taxonomy; substantive content (~1162 lines) |

**Missing TypeScript guides (no file at all):**
- `typescript/guides/observability/` — no logging/observability guide for TypeScript
- `typescript/guides/security/` — no security implementation guide for TypeScript

### Kotlin

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | **absent** | No implementation guides exist; `AGENTS.md` is a 3-line placeholder stub |

### Swift

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides)* | **absent** | Style-guide and testing files exist but are pre-taxonomy style references, not parent-standard implementation guides |

### SQL

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | **absent** | No implementation guides exist; `AGENTS.md` is a 3-line placeholder stub |

### Objective-C

| File | Status | Notes |
|------|--------|-------|
| *(style-guide only)* | n/a | Extensive style-guide files exist; excluded from taxonomy evaluation |

---

## AGENTS.md Navigation Files

| File | Lines | Status | Notes |
|------|-------|--------|-------|
| `standards/AGENTS.md` | ~166 | complete | Exceeds 100-line limit; refactor recommended |
| `standards/testing/AGENTS.md` | ~545 | complete | Significantly exceeds 100-line limit; refactor needed |
| `standards/extension-development/AGENTS.md` | ~113 | complete | Slightly exceeds 100-line limit |
| `languages/AGENTS.md` | ~47 | complete | Within limits |
| `languages/go/AGENTS.md` | ~118 | complete | Slightly exceeds 100-line limit |
| `languages/java/AGENTS.md` | ~503 | complete | Significantly exceeds 100-line limit; refactor needed |
| `languages/kotlin/AGENTS.md` | ~3 | stub | Placeholder only ("living document" boilerplate) |
| `languages/objective-c/AGENTS.md` | ~33 | complete | Within limits |
| `languages/python/AGENTS.md` | ~470 | complete | Significantly exceeds 100-line limit; refactor needed |
| `languages/sql/AGENTS.md` | ~3 | stub | Placeholder only |
| `languages/swift/AGENTS.md` | ~36 | complete | Within limits |
| `languages/typescript/AGENTS.md` | ~675 | complete | Significantly exceeds 100-line limit; refactor needed |

**Missing AGENTS.md files (required by taxonomy for directories with 2+ files):**
- `standards/api/AGENTS.md` — absent
- `standards/messaging/AGENTS.md` — absent
- `standards/observability/AGENTS.md` — absent
- `standards/security/AGENTS.md` — absent
- `standards/storage/AGENTS.md` — absent
- `standards/deployment/AGENTS.md` — absent

---

## Security Coverage: Detailed Gap Analysis

This section focuses on security, given that writing security standards is the immediate next task.

### What exists

| Location | Coverage | Scope limitation |
|----------|----------|-----------------|
| `standards/api/secure-server-to-server-comm.md` | Server-to-server JWT/JWKS auth | Narrow: only covers caller trust for sensitive endpoints |
| `standards/extension-development/security.md` | CSP, permissions, XSS, data handling | Scoped to browser extensions only |
| `languages/go/AGENTS.md` (Security Considerations section) | Input validation, secrets, dependency vuln scanning | Bullet list only; not a standard |
| `languages/java/AGENTS.md` (Security Considerations section) | JWT auth, input validation, SQL injection, CSRF, CORS, dependency scanning | Bullet list only; not a standard |
| `languages/python/AGENTS.md` (Security Considerations section) | JWT auth, input validation, SQL injection, secrets, dependency scanning | Bullet list only; not a standard |
| `languages/typescript/AGENTS.md` (Security Considerations section) | Input validation, XSS, secrets, HTTPS, auth | Bullet list only; not a standard |

### What is absent

- **`standards/security/overview.md`** — the umbrella standard that all other security standards hang from; 0 bytes
- No standard for authentication (what auth schemes are required, how tokens are validated)
- No standard for authorization (RBAC, scopes, resource ownership)
- No standard for secrets management (how to store, rotate, and reference secrets)
- No standard for input validation and output encoding (language-agnostic rules)
- No standard for PII and data classification (what counts as sensitive, how to handle it)
- No language-specific security guides for Go, Java, Python, TypeScript, Kotlin, Swift
- No enforcement policies (`*.policy.md`) for any security topic

---

## Observability Coverage: Detailed Gap Analysis

### What exists

| Location | Coverage | Scope limitation |
|----------|----------|-----------------|
| `standards/observability/overview.md` | Nothing | 0 bytes |
| `standards/observability/logging.md` | Nothing | 0 bytes |
| `languages/go/guides/observability/logging.md` | Zerolog setup, structured JSON logging, HTTP middleware, log levels | Draft; pre-taxonomy; covers logging only |
| `languages/python/guides/observability/logging.md` | stdlib logging, structured formatters, log levels, context, security (no PII) | Draft; pre-taxonomy; covers logging only |
| `languages/java/guides/observability/logging-slf4j.md` | Nothing | 0 bytes — absent |

### What is absent

- **`standards/observability/overview.md`** — umbrella standard; 0 bytes
- **`standards/observability/logging.md`** — logging standard; 0 bytes
- No metrics standard (what to instrument, naming conventions, cardinality rules)
- No tracing/distributed-tracing standard (trace context propagation, span naming)
- No alerting/SLO standard
- No language-specific observability guides for Java (logging-slf4j.md is empty), TypeScript, Kotlin, Swift, SQL
- No enforcement policies for any observability topic

---

## Summary Counts

| Category | Complete | Draft | Stub | Absent |
|----------|---------|-------|------|--------|
| Standards (all categories) | 0 | 21 | 2 | 4 |
| Language guides | 0 | 20 | 7 | 3 languages with zero guides |
| AGENTS.md files | 8 | 0 | 2 | 6 missing from required locations |

---

## Highest-Priority Gaps

Ordered by blocking impact:

1. **`standards/security/overview.md`** — absent (0 bytes); blocks all security review; no language guides can exist without a parent standard
2. **`standards/observability/overview.md`** — absent (0 bytes); blocks observability review; language logging guides exist without a parent standard to implement
3. **`standards/observability/logging.md`** — absent (0 bytes); logging is the most-implemented observability sub-topic but has no standard
4. **`standards/deployment/ci-cd.md`** — absent (0 bytes); CI/CD guidance is entirely missing
5. **`languages/java/guides/observability/logging-slf4j.md`** — absent (0 bytes); referenced in Java AGENTS.md but empty; Java is the most-used backend language
6. **`languages/kotlin/` guides** — absent entirely; Kotlin has no implementation guides
7. **`languages/sql/` guides** — absent entirely; SQL/migration code cannot be reviewed to standard
8. **`python/guides/api/rest-fastapi.md`** — referenced in Python AGENTS.md but file does not exist
9. **`storage/postgresql.md`** — stub (title only); PostgreSQL is a primary storage engine
10. **Missing `AGENTS.md` files** in `standards/api/`, `standards/messaging/`, `standards/observability/`, `standards/security/`, `standards/storage/`, `standards/deployment/`
