# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind by a MAJOR bump; guide is supplementary-only for conflicting rules until updated; higher priority gap than absent stubs

> **Note:** Files authored before the taxonomy was defined use earlier rule identifier
> structures (FS-N/NFS-N or no R-N/Compliance Checklist conventions) rather than R-N/Compliance
> Checklist. These are marked **draft** — the content is substantive but does not yet conform
> to the current template. This applies to the majority of existing standards and guides in
> this repository.

---

## Standards (`standards/`)

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | **absent** | 0 | Empty file — entire security standard library is missing |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/overview.md` | **absent** | 0 | Empty placeholder file |
| `observability/logging.md` | **absent** | 0 | Empty placeholder file |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | **absent** | 0 | Empty placeholder file |

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | **draft** | 1257 | Pre-taxonomy structure (no Scope/Rules(R-N)/Compliance Checklist/Examples headings); highly substantive content; exceeds 300-line size limit |
| `api/rest-example.md` | **draft** | 320 | Pre-taxonomy structure; reference example file, no standard sections |
| `api/secure-server-to-server-comm.md` | **draft** | 111 | Pre-taxonomy structure (has Overview and Out Of Scope and Implementation; missing Rules(R-N)/Compliance Checklist) |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | **draft** | 623 | Pre-taxonomy structure (Overview present; has Implementation Checklist but not "Compliance Checklist"; no Scope/Rules(R-N)/Examples sections); exceeds 300-line size limit |
| `storage/extension-storage.md` | **draft** | 580 | Pre-taxonomy structure (Overview + Related Standards present; no Scope/Rules(R-N)/Compliance Checklist); exceeds 300-line size limit |
| `storage/postgresql.md` | **stub** | 1 | Title line only (`# RDS PostgreSQL - Guideline`); no section content |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/unit-testing.md` | **draft** | 619 | Pre-taxonomy structure; highly substantive FR-based content; missing Scope/Rules(R-N)/Compliance Checklist/Examples/Related headings; exceeds 300-line size limit |
| `testing/integration-testing.md` | **draft** | 752 | Pre-taxonomy structure; substantive content; missing taxonomy section headings; exceeds 300-line size limit |
| `testing/e2e-testing.md` | **draft** | 528 | Pre-taxonomy structure; substantive content; missing taxonomy section headings; exceeds 300-line size limit |
| `testing/strategy.md` | **draft** | 279 | Pre-taxonomy structure; has Overview and Applicability; missing Rules(R-N)/Compliance Checklist/Examples/Related headings |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/event-driven-architectures.md` | **draft** | 539 | Pre-taxonomy structure; substantive; has Overview and Related Standards; no Rules(R-N)/Compliance Checklist; exceeds 300-line size limit |
| `messaging/message-standards.md` | **draft** | 398 | Pre-taxonomy structure; substantive; has Overview; no Scope/Rules(R-N)/Compliance Checklist/Examples headings; exceeds 300-line size limit |
| `messaging/message-contracts.md` | **draft** | 167 | Pre-taxonomy structure; substantive; has Overview; no Scope/Rules(R-N)/Compliance Checklist |
| `messaging/versioning.md` | **draft** | 313 | Pre-taxonomy structure; substantive; has Overview and Related Standards; no Rules(R-N)/Compliance Checklist/Examples headings; exceeds 300-line size limit |
| `messaging/api-initiated-message.md` | **draft** | 602 | Pre-taxonomy structure; substantive; has Overview; no taxonomy section headings; exceeds 300-line size limit |
| `messaging/user-initiated-message.md` | **draft** | 314 | Pre-taxonomy structure; substantive; has Overview; no taxonomy section headings; exceeds 300-line size limit |
| `messaging/kafka/message-contracts.md` | **draft** | 307 | Pre-taxonomy structure; substantive Kafka-specific contracts content; no taxonomy section headings; exceeds 300-line size limit |
| `messaging/messaging.md` | **stub** | 22 | Index/hub file with only links to sub-documents; no standard sections present under headings |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | **draft** | 777 | Pre-taxonomy structure; substantive; has Overview; no Scope/Rules(R-N)/Compliance Checklist/Related headings; exceeds 300-line size limit |
| `extension-development/code-organization.md` | **draft** | 357 | Pre-taxonomy structure; substantive; no taxonomy section headings; exceeds 300-line size limit |
| `extension-development/cross-browser.md` | **draft** | 419 | Pre-taxonomy structure; substantive; no taxonomy section headings; exceeds 300-line size limit |
| `extension-development/messaging.md` | **draft** | 393 | Pre-taxonomy structure; substantive; no taxonomy section headings; exceeds 300-line size limit |
| `extension-development/performance.md` | **draft** | 431 | Pre-taxonomy structure; substantive; no taxonomy section headings; exceeds 300-line size limit |
| `extension-development/security.md` | **draft** | 422 | Pre-taxonomy structure; substantive; no taxonomy section headings; exceeds 300-line size limit |
| `extension-development/testing.md` | **draft** | 525 | Pre-taxonomy structure; substantive; no taxonomy section headings; exceeds 300-line size limit |

### Skills

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `skills/skill-getting-started.md` | **draft** | 20 | Navigation hub; substantive but no standard taxonomy sections; skill-authoring guide, not a language-agnostic standard |
| `skills/skill-quick-reference.md` | **draft** | 424 | Pre-taxonomy structure; substantive; exceeds 300-line size limit |
| `skills/skill-reference-detailed.md` | **draft** | 732 | Pre-taxonomy structure; substantive; exceeds 300-line size limit |
| `skills/standards-patterns.md` | **draft** | 273 | Pre-taxonomy structure; substantive |

---

## Language Guides (`languages/`)

### Go

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 118 lines; substantive content (project structure, conventions); missing taxonomy-required "Directory purpose / File index / Navigation" headings; missing Linter declaration section |
| `guides/api/rest-echo.md` | **stub** | — | 7 lines; framework reference only; no required guide sections |
| `guides/deployment/build.md` | **stub** | — | 18 lines; minimal build commands; no required guide sections |
| `guides/deployment/containerization.md` | **stub** | — | 32 lines; Dockerfile snippet only; no required guide sections |
| `guides/messaging/datacontract-setup-process.md` | **draft** | — | 1106 lines; substantive; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/observability/logging.md` | **draft** | — | 337 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration |
| `guides/storage/database-ent.md` | **stub** | — | 7 lines; framework reference only; no required guide sections |
| `guides/testing/folder-structure.md` | **draft** | — | 585 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/testing/testing.md` | **stub** | — | 32 lines; has Unit Tests/Mocking sections but no Overview or required taxonomy sections |

### Java

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 503 lines; substantive; missing taxonomy-required AGENTS.md headings; missing Linter declaration section; exceeds 100-line size limit |
| `guides/api/rest-spring.md` | **draft** | — | 1778 lines; has Overview; missing Related standard/Prerequisites/Verification headings; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/messaging/create-register-pojo.md` | **draft** | — | 482 lines; substantive; has Pojo classes overview; missing full taxonomy sections; Missing Implements: declaration |
| `guides/messaging/datacontract-setup-process.md` | **draft** | — | 569 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/observability/logging-slf4j.md` | **absent** | — | Empty file |
| `guides/testing/e2e-test-examples.md` | **draft** | — | 561 lines; substantive examples content; missing required guide sections; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/testing/folder-structure.md` | **draft** | — | 717 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/testing/testing.md` | **draft** | — | 1468 lines; has Overview; references unit-testing standard inline but no formal Implements: declaration; missing Related standard/Prerequisites/Verification headings; exceeds 500-line size limit |

### Python

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 470 lines; substantive; missing taxonomy-required AGENTS.md headings; Linter (ruff) mentioned in version block but no dedicated Linter section; exceeds 100-line size limit |
| `guides/data-science/data-science.md` | **draft** | — | 698 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/documentation/documentation.md` | **draft** | — | 722 lines; substantive; missing required guide sections; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/observability/logging.md` | **draft** | — | 740 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/testing/folder-structure.md` | **draft** | — | 281 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration |
| `guides/testing/testing.md` | **draft** | — | 821 lines; has Overview; missing Related standard/Prerequisites/Verification headings and Implements: declaration; exceeds 500-line size limit |

### TypeScript

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 675 lines; substantive; missing taxonomy-required AGENTS.md headings; missing Linter section; exceeds 100-line size limit |
| `guides/api/rest-express.md` | **draft** | — | 1072 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/best-practices/typescript-best-practices.md` | **draft** | — | 1196 lines; substantive; missing required guide sections; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/setup/project-setup.md` | **draft** | — | 604 lines; has Prerequisites section; missing Overview/Related standard/Implementation/Verification headings; Missing Implements: declaration; exceeds 500-line size limit |
| `guides/setup/starter-tsconfig-notes.md` | **draft** | — | 394 lines; substantive configuration notes; missing required guide sections; Missing Implements: declaration |
| `guides/testing/folder-structure.md` | **draft** | — | 451 lines; has Overview; missing Related standard/Prerequisites/Verification; Missing Implements: declaration |
| `guides/testing/testing-guide.md` | **draft** | — | 1162 lines; substantive; no Overview section; missing required guide sections; Missing Implements: declaration; exceeds 500-line size limit |

### Kotlin

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **stub** | — | 3 lines; placeholder only ("living document" note); no substantive content |
| *(no guides directory)* | **absent** | — | No guides coverage at all for Kotlin |

### Swift

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 36 lines; has Quick Navigation and Agent Rules; missing taxonomy-required File index table and Directory purpose paragraph; missing Linter section (SwiftLint referenced in linting/ subdir) |
| *(no guides/ directory — content in architecture/, testing/, style-guide/, linting/)* | **draft** | — | Swift content exists but not under `guides/` path; not scanned as language guides per taxonomy (rule 5 requires `/guides/` in path) |

### SQL

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **stub** | — | 3 lines; placeholder only; no substantive content |
| *(no guides directory)* | **absent** | — | No guides coverage at all for SQL |

### Objective-C

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 33 lines; has Quick Navigation and Agent Rules; missing taxonomy-required File index table and Directory purpose paragraph; no Linter section |
| *(no guides/ directory — content in style-guide/)* | **draft** | — | Objective-C style content exists but not under `guides/` path; not scanned as language guides per taxonomy |

---

## AGENTS.md Files (`standards/`)

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/AGENTS.md` | **complete** | 173 | All three required sections present (Purpose, Directory Structure as file index, Navigation); oversize (limit 100 lines) |
| `standards/testing/AGENTS.md` | **complete** | 545 | All three required sections present (Purpose, Directory Contents, Navigation); oversize (limit 100 lines) |
| `standards/extension-development/AGENTS.md` | **draft** | 113 | Has Core Standards navigation content but missing taxonomy-required "Directory purpose / File index / Navigation" heading structure; oversize (limit 100 lines) |

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | 83 |
| Complete | 2 |
| Draft | 63 (63 pre-taxonomy) |
| Stub | 10 |
| Absent | 8 |
| Major-stale | 0 |

### Top 5 Priority Gaps

1. **`standards/security/overview.md` — absent** (0 bytes). The entire security standard category is a placeholder. Security is the highest-risk missing domain; every application review that touches auth, secrets, or PII has nothing to cite. Writing this standard unblocks security testing, code review, and guides for all languages.

2. **`standards/observability/overview.md` and `standards/observability/logging.md` — both absent** (0 bytes each). Zero observability standards exist. Logging guides exist for Go, Java, and Python but have no parent standard to implement, leaving them unchecked against any authoritative requirements.

3. **`standards/deployment/ci-cd.md` — absent** (0 bytes). No CI/CD standard exists. Deployment is high-risk when missing; there is no canonical reference for pipeline structure, container requirements, or release gates.

4. **`standards/storage/postgresql.md` — stub** (1 line, title only). PostgreSQL is the primary relational database in the stack (the Go Ent guide targets it directly), yet no standard exists. The DynamoDB standard is a substantive draft; PostgreSQL has nothing to match it.

5. **All language-root AGENTS.md files missing the `Linter` section** (Go, Java, Python, TypeScript, Kotlin, SQL, Swift, Objective-C). The taxonomy mandates that each language-root AGENTS.md carry a single authoritative linter declaration. None of the eight language AGENTS.md files conform. This is a widespread structural gap that affects AI-agent tooling consistency across every language.
