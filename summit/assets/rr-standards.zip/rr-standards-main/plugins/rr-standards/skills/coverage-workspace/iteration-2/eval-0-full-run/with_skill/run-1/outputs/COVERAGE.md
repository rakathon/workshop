# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is supplementary-only for conflicting rules until updated;
  higher priority gap than absent stubs

> **Note:** `forge/standards/TAXONOMY.md` was not found. Fallback taxonomy definitions were used for artifact type detection and required section rules.

---

## Standards (`standards/`)

`forge/standards/` exists but contains no `.md` content artifacts (only `.gitkeep`). No standards have been authored yet.

| Category | Status |
|----------|--------|
| api | absent — no files |
| deployment | absent — no files |
| extension-development | absent — no files |
| messaging | absent — no files |
| observability | absent — no files |
| security | absent — no files |
| skills | absent — no files |
| storage | absent — no files |
| testing | absent — no files |

---

## Language Guides (`languages/`)

`forge/languages/` exists but contains no language directories or `.md` files (only `.gitkeep`). No language guides have been authored yet.

---

## AGENTS.md Files (`standards/`)

No `AGENTS.md` files found under `forge/standards/`.

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | 0 |
| Complete | 0 |
| Draft | 0 |
| Stub | 0 |
| Absent | 0 |
| Major-stale | 0 |

> **Note:** Zero artifacts were scanned because `forge/standards/` and `forge/languages/` are both empty (contain only `.gitkeep`). All gaps below are structural — the library has not yet been populated.

### Top 5 Priority Gaps

1. `forge/standards/security/` — no security standards exist; this is the highest-risk category gap and should be populated before any production usage.
2. `forge/standards/observability/` — no observability standards exist; logging, metrics, and tracing guidance is absent.
3. `forge/standards/deployment/` — no deployment standards exist; CI/CD and container guidance is absent.
4. `forge/standards/api/` — no API standards exist; REST/GraphQL patterns are absent.
5. `forge/standards/TAXONOMY.md` — taxonomy file is missing; without it the coverage skill cannot use project-specific artifact type rules and falls back to embedded defaults.
