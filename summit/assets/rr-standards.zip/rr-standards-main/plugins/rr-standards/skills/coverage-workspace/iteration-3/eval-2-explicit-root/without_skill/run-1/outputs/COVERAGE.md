# forge/ Plugin Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (manual scan)

**Status definitions** (see `forge/standards/TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or contains only a `.gitkeep` placeholder

> **Scope:** This coverage map evaluates the `forge/` Claude plugin directory at the
> repository root. `forge/` is the assembled plugin artifact intended for distribution
> as a Claude Code plugin (see `forge/.claude-plugin/plugin.json`). It is distinct from
> `.forge/` (project workflow state) and the source `standards/`, `languages/`, `skills/`
> trees at the repository root.

---

## Standards (`forge/standards/`)

The `forge/standards/` directory contains only `COVERAGE.md` (this file's predecessor).
No language-agnostic standard files exist. The directory has a `.gitkeep` sentinel,
confirming the directory structure is scaffolded but unpopulated.

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/AGENTS.md` | absent | — | Required per taxonomy; not present |
| `standards/README.md` | absent | — | Required at standards/ root per taxonomy; not present |
| `standards/api/rest.md` | absent | — | No api category directory exists |
| `standards/deployment/ci-cd.md` | absent | — | No deployment category directory exists |
| `standards/messaging/` | absent | — | No messaging category directory exists |
| `standards/observability/` | absent | — | No observability category directory exists |
| `standards/security/` | absent | — | No security category directory exists |
| `standards/storage/` | absent | — | No storage category directory exists |
| `standards/testing/` | absent | — | No testing category directory exists |

**Standards directories present:** 0 of expected 8 categories
**Standards files present:** 0

---

## Language Guides (`forge/languages/`)

The `forge/languages/` directory contains only a `.gitkeep` sentinel. No language
sub-directories or guides have been created.

| Language | AGENTS.md | Guides | Status | Notes |
|----------|-----------|--------|--------|-------|
| Go | absent | 0 | absent | Directory not created |
| Java | absent | 0 | absent | Directory not created |
| Kotlin | absent | 0 | absent | Directory not created |
| Python | absent | 0 | absent | Directory not created |
| SQL | absent | 0 | absent | Directory not created |
| Swift | absent | 0 | absent | Directory not created |
| TypeScript | absent | 0 | absent | Directory not created |
| `languages/AGENTS.md` | absent | — | absent | Required at languages/ root per taxonomy |
| `languages/README.md` | absent | — | absent | Required at languages/ root per taxonomy |

**Language directories present:** 0 of expected 7 languages

---

## Skills (`forge/skills/`)

48 skill placeholder directories exist, each containing only a `.gitkeep` file.
No skill has a `SKILL.md` implementation file.

| Skill | SKILL.md | Status | Notes |
|-------|----------|--------|-------|
| `skills/adr` | absent | stub | `.gitkeep` only |
| `skills/build-api` | absent | stub | `.gitkeep` only |
| `skills/build-messaging` | absent | stub | `.gitkeep` only |
| `skills/build-repo` | absent | stub | `.gitkeep` only |
| `skills/check-coverage` | absent | stub | `.gitkeep` only |
| `skills/check-reqs` | absent | stub | `.gitkeep` only |
| `skills/classify` | absent | stub | `.gitkeep` only |
| `skills/commit` | absent | stub | `.gitkeep` only |
| `skills/create-stock` | absent | stub | `.gitkeep` only |
| `skills/spec-api` | absent | stub | `.gitkeep` only |
| `skills/spec-messaging` | absent | stub | `.gitkeep` only |
| `skills/spec-storage` | absent | stub | `.gitkeep` only |
| `skills/spec-tests` | absent | stub | `.gitkeep` only |
| `skills/diagnose` | absent | stub | `.gitkeep` only |
| `skills/elaborate` | absent | stub | `.gitkeep` only |
| `skills/extract` | absent | stub | `.gitkeep` only |
| `skills/help` | absent | stub | `.gitkeep` only |
| `skills/init` | absent | stub | `.gitkeep` only |
| `skills/jira-pull` | absent | stub | `.gitkeep` only |
| `skills/jira-push` | absent | stub | `.gitkeep` only |
| `skills/jira-resolve` | absent | stub | `.gitkeep` only |
| `skills/map` | absent | stub | `.gitkeep` only |
| `skills/map-defects` | absent | stub | `.gitkeep` only |
| `skills/monitor` | absent | stub | `.gitkeep` only |
| `skills/pause` | absent | stub | `.gitkeep` only |
| `skills/plan` | absent | stub | `.gitkeep` only |
| `skills/promote` | absent | stub | `.gitkeep` only |
| `skills/qa` | absent | stub | `.gitkeep` only |
| `skills/regression` | absent | stub | `.gitkeep` only |
| `skills/remediate` | absent | stub | `.gitkeep` only |
| `skills/reopen` | absent | stub | `.gitkeep` only |
| `skills/resume` | absent | stub | `.gitkeep` only |
| `skills/revert` | absent | stub | `.gitkeep` only |
| `skills/review` | absent | stub | `.gitkeep` only |
| `skills/review-privacy` | absent | stub | `.gitkeep` only |
| `skills/review-security` | absent | stub | `.gitkeep` only |
| `skills/runbook` | absent | stub | `.gitkeep` only |
| `skills/scaffold` | absent | stub | `.gitkeep` only |
| `skills/simplify` | absent | stub | `.gitkeep` only |
| `skills/status` | absent | stub | `.gitkeep` only |
| `skills/test` | absent | stub | `.gitkeep` only |
| `skills/update-plan` | absent | stub | `.gitkeep` only |
| `skills/validate` | absent | stub | `.gitkeep` only |
| `skills/validate-api` | absent | stub | `.gitkeep` only |
| `skills/validate-messaging` | absent | stub | `.gitkeep` only |
| `skills/validate-storage` | absent | stub | `.gitkeep` only |
| `skills/validate-tests` | absent | stub | `.gitkeep` only |
| `skills/verify` | absent | stub | `.gitkeep` only |

**Skills with SKILL.md:** 0 of 48
**Skills fully implemented:** 0 of 48

---

## Hooks (`forge/hooks/`)

4 hook category directories exist, each containing only a `.gitkeep` file.
No hook implementations have been authored.

| Hook Category | Status | Notes |
|---------------|--------|-------|
| `hooks/post-tool-use/` | stub | `.gitkeep` only; no hook scripts |
| `hooks/pre-tool-use/` | stub | `.gitkeep` only; no hook scripts |
| `hooks/session-start/` | stub | `.gitkeep` only; no hook scripts |
| `hooks/user-prompt-submit/` | stub | `.gitkeep` only; no hook scripts |

**Hook categories scaffolded:** 4 of 4
**Hook implementations present:** 0

---

## Plugin Metadata

| File | Status | Notes |
|------|--------|-------|
| `.claude-plugin/plugin.json` | complete | Name, version, description, author, homepage, repository, skills path, hooks path all present |

---

## Summary

| Category | Complete | Draft | Stub | Absent |
|----------|---------|-------|------|--------|
| Standards | 0 | 0 | 0 | 9 (all categories + nav files) |
| Language guides | 0 | 0 | 0 | 9 (all languages + nav files) |
| Skills | 0 | 0 | 48 | 0 |
| Hooks | 0 | 0 | 4 | 0 |
| Plugin metadata | 1 | 0 | 0 | 0 |

**Total artifacts with substantive content:** 1 (`plugin.json`)
**Total placeholder-only artifacts:** 52 (48 skills + 4 hook directories)
**Total absent artifacts:** 18 (9 standards + 9 language nav/guide gaps)

---

## Highest-Priority Gaps

1. **`forge/standards/`** — entire standards library absent; `forge:review`, `forge:validate`, `forge:review-security`, and all validation skills have no standards to enforce against; this blocks every standards-dependent skill from functioning
2. **`forge/languages/`** — entire language guide library absent; code generation and language-specific review skills have no implementation guidance to reference
3. **`forge/skills/`** — all 48 skills are stubs with no `SKILL.md`; the plugin registers no callable skills; the plugin is non-functional from a user perspective
4. **`forge/hooks/`** — all 4 hook categories are stubs; no automated injection, validation, or prompt augmentation occurs at session or tool boundaries
5. **`forge/standards/AGENTS.md` + `forge/languages/AGENTS.md`** — required navigation files per taxonomy absent; agents cannot orient themselves within the plugin's standards and language trees
