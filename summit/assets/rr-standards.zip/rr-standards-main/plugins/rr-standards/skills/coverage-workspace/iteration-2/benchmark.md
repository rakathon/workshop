# Skill Benchmark: rr-standards:coverage

**Model**: <model-name>
**Date**: 2026-03-08T23:03:49Z
**Evals**: 0, 1, 2 (3 runs each per configuration)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 100% ± 0% | 0% ± 0% | +1.00 |
| Time | 82.5s ± 24.4s | 95.5s ± 93.9s | -13.0s |
| Tokens | 28994 ± 8853 | 27950 ± 24400 | +1045 |