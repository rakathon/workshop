# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated)

> **Note:** `TAXONOMY.md` was not found at `forge/standards/TAXONOMY.md`. Using embedded fallback taxonomy definitions.

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is supplementary-only for conflicting rules until updated;
  higher priority gap than absent stubs

---

## Standards (`standards/`)

> `forge/standards/` exists but contains no markdown artifacts (only `.gitkeep`). All standard categories are absent.

### security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/` *(no files)* | absent | — | Directory contains no .md files |

### observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/` *(no files)* | absent | — | Directory contains no .md files |

### deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/` *(no files)* | absent | — | Directory contains no .md files |

### api

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/` *(no files)* | absent | — | Directory contains no .md files |

### testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/` *(no files)* | absent | — | Directory contains no .md files |

### storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/` *(no files)* | absent | — | Directory contains no .md files |

### messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/` *(no files)* | absent | — | Directory contains no .md files |

### extension-development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/` *(no files)* | absent | — | Directory contains no .md files |

### skills

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `skills/` *(no files)* | absent | — | Directory contains no .md files |

---

## Language Guides (`languages/`)

> `forge/languages/` exists but contains no language subdirectories with markdown content (only `.gitkeep`). No language coverage available.

*(No language guides found.)*

---

## AGENTS.md Files (`standards/`)

> No AGENTS.md files found under `forge/standards/`.

*(No AGENTS.md files found.)*

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | 0 |
| Complete | 0 |
| Draft | 0 |
| Stub | 0 |
| Absent | 0 |
| Major-stale | 0 |

> **Note:** Zero artifacts were scanned because `forge/standards/` and `forge/languages/` contain no markdown files. The counts above reflect discovered content files only; the absent categories listed in the Standards section represent structural gaps, not counted file entries.

### Top 5 Priority Gaps

1. `forge/standards/security/` — No security standards exist; security is highest-risk category and blocks auth, secrets, and validation guidance.
2. `forge/standards/observability/` — No observability standards exist; logging, metrics, and tracing patterns are absent.
3. `forge/standards/deployment/` — No deployment standards exist; CI/CD and container patterns are absent.
4. `forge/standards/api/` — No API standards exist; REST/GraphQL patterns are absent, blocking api-related language guides.
5. `forge/standards/testing/` — No testing standards exist; test strategy patterns are absent, blocking quality assurance guidance.
