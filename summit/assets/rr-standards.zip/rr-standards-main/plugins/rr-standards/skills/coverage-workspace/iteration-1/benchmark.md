# Skill Benchmark: rr-standards:coverage

**Model**: <model-name>
**Date**: 2026-03-08T22:48:56Z
**Evals**: 0, 1, 2 (3 runs each per configuration)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 100% ± 0% | 100% ± 0% | +0.00 |
| Time | 346.3s ± 19.8s | 166.4s ± 21.3s | +179.8s |
| Tokens | 91729 ± 21312 | 53600 ± 12771 | +38129 |