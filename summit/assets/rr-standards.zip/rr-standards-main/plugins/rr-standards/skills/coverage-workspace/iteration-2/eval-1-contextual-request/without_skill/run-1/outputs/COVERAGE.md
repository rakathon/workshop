# Standards Library Coverage Map

Scan date: 2026-03-08 | Scanned by: manual agent scan
Source directories: `standards/` and `languages/` (repo root; `forge/standards/` and `forge/languages/` are empty stubs — content lives at repo root)

**Status definitions** (per `standards/TAXONOMY.md`):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or pre-taxonomy structure (FS-N/NFS-N instead of R-N/Compliance Checklist)
- **stub** — file exists but has no required sections or nearly empty (title-only, TOC-only, or placeholder)
- **absent** — file exists but is 0 bytes, or no file exists at all
- **major-stale** — (language guides only) guide's declared standard version is behind by a MAJOR bump

> **Pre-taxonomy note:** Files created before 2026 contain substantive content but use the
> old FS-N/NFS-N rule structure rather than the R-N / Compliance Checklist structure required
> by the current taxonomy. These are marked **draft**. Migration is a separate follow-on story.

---

## Standards (`standards/`)

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | draft | 1257 | Pre-taxonomy; no Scope/Rules/Checklist sections; exceeds 300-line limit |
| `api/rest-example.md` | draft | 320 | Pre-taxonomy; companion example file |
| `api/secure-server-to-server-comm.md` | draft | 111 | Pre-taxonomy |

**Missing from API:** GraphQL standard (no file), WebSocket standard (no file)

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | absent | 0 | Empty file; no content |

**Missing from Deployment:** Containerization standard, release management (no files)

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | draft | 777 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/code-organization.md` | draft | 357 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/cross-browser.md` | draft | 419 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/messaging.md` | draft | 393 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/performance.md` | draft | 431 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/security.md` | draft | 422 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/testing.md` | draft | 525 | Pre-taxonomy; exceeds 300-line limit |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/api-initiated-message.md` | draft | 602 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/event-driven-architectures.md` | draft | 539 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/kafka/message-contracts.md` | draft | 307 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/message-contracts.md` | draft | 167 | Pre-taxonomy |
| `messaging/message-standards.md` | draft | 398 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/messaging.md` | stub | 22 | Near-empty TOC; no substantive content |
| `messaging/user-initiated-message.md` | draft | 314 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/versioning.md` | draft | 313 | Pre-taxonomy; exceeds 300-line limit |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/logging.md` | absent | 0 | Empty file; no content |
| `observability/overview.md` | absent | 0 | Empty file; no content |

**Missing from Observability:** Metrics standard, tracing/distributed-tracing standard, alerting standard (no files)

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | absent | 0 | Empty file; no content |

**Missing from Security:** Authentication standard, authorization/RBAC standard, secrets management standard, input validation standard, PII/data classification standard (no files)

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | draft | 623 | Pre-taxonomy; exceeds 300-line limit |
| `storage/extension-storage.md` | draft | 580 | Pre-taxonomy; exceeds 300-line limit |
| `storage/postgresql.md` | stub | 0 | Empty file; no content |

**Missing from Storage:** Caching/Redis standard, data migration standard (no files)

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/e2e-testing.md` | draft | 528 | Pre-taxonomy; exceeds 300-line limit |
| `testing/integration-testing.md` | draft | 752 | Pre-taxonomy; exceeds 300-line limit |
| `testing/strategy.md` | draft | 279 | Pre-taxonomy |
| `testing/unit-testing.md` | draft | 619 | Pre-taxonomy; exceeds 300-line limit |

---

## Language Guides (`languages/`)

Style-reference files (Swift `style-guide/`, Objective-C `style-guide/`) and linting configs
are excluded — they predate the taxonomy and are not implementation guides in the taxonomy sense.

### Go

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `go/guides/api/rest-echo.md` | stub | 7 | Placeholder only |
| `go/guides/deployment/build.md` | stub | 18 | Placeholder only |
| `go/guides/deployment/containerization.md` | stub | 32 | Placeholder only |
| `go/guides/messaging/datacontract-setup-process.md` | draft | 1106 | Pre-taxonomy; exceeds 500-line limit |
| `go/guides/observability/logging.md` | draft | 337 | Pre-taxonomy |
| `go/guides/storage/database-ent.md` | stub | 7 | Placeholder only |
| `go/guides/testing/folder-structure.md` | draft | 585 | Pre-taxonomy; exceeds 500-line limit |
| `go/guides/testing/testing.md` | stub | 32 | Placeholder only |

**Missing from Go guides:** security, deployment (real content), storage (beyond stub)

### Java

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `java/guides/api/rest-spring.md` | draft | 1778 | Pre-taxonomy; far exceeds 500-line limit |
| `java/guides/messaging/create-register-pojo.md` | draft | 482 | Pre-taxonomy |
| `java/guides/messaging/datacontract-setup-process.md` | draft | 569 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/observability/logging-slf4j.md` | absent | 0 | Empty file; no content |
| `java/guides/testing/e2e-test-examples.md` | draft | 561 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/testing/folder-structure.md` | draft | 717 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/testing/testing.md` | draft | 1468 | Pre-taxonomy; far exceeds 500-line limit |

**Missing from Java guides:** security, storage, deployment (no files)

### Python

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `python/guides/data-science/data-science.md` | draft | 698 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/documentation/documentation.md` | draft | 722 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/observability/logging.md` | draft | 740 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/testing/folder-structure.md` | draft | 281 | Pre-taxonomy |
| `python/guides/testing/testing.md` | draft | 821 | Pre-taxonomy; exceeds 500-line limit |

**Missing from Python guides:** API, messaging, security, storage, deployment (no files)

### TypeScript

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `typescript/guides/api/rest-express.md` | draft | 1072 | Pre-taxonomy; far exceeds 500-line limit |
| `typescript/guides/best-practices/typescript-best-practices.md` | draft | 1196 | Pre-taxonomy; far exceeds 500-line limit |
| `typescript/guides/setup/project-setup.md` | draft | 604 | Pre-taxonomy; exceeds 500-line limit |
| `typescript/guides/setup/starter-tsconfig-notes.md` | draft | 394 | Pre-taxonomy |
| `typescript/guides/testing/folder-structure.md` | draft | 451 | Pre-taxonomy |
| `typescript/guides/testing/testing-guide.md` | draft | 1162 | Pre-taxonomy; far exceeds 500-line limit |

**Missing from TypeScript guides:** messaging, security, observability, storage, deployment (no files)

### Kotlin

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist; only a 3-line stub AGENTS.md |

### Swift

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides)* | absent | Style-guide and linting files exist; architecture/ and testing/ exist but are thin (74–185 lines each, pre-taxonomy); no standard implementation guides in the taxonomy sense |

### SQL

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist; only a 3-line stub AGENTS.md |

### Objective-C

Style-only content exists (25+ style-guide files). No implementation guides in the taxonomy sense.

---

## AGENTS.md Navigation Files

| File | Lines | Status | Notes |
|------|-------|--------|-------|
| `standards/AGENTS.md` | 173 | complete | Exceeds 100-line limit; refactor needed (was 166 at last review) |
| `standards/testing/AGENTS.md` | 545 | complete | Far exceeds 100-line limit; refactor needed |
| `standards/extension-development/AGENTS.md` | 113 | complete | Exceeds 100-line limit; refactor needed |
| `languages/AGENTS.md` | 47 | complete | Within limit |
| `languages/go/AGENTS.md` | 118 | complete | Exceeds 100-line limit; refactor needed |
| `languages/java/AGENTS.md` | 503 | complete | Far exceeds 100-line limit; refactor needed |
| `languages/kotlin/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/objective-c/AGENTS.md` | 33 | complete | Within limit |
| `languages/python/AGENTS.md` | 470 | complete | Far exceeds 100-line limit; refactor needed |
| `languages/sql/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/swift/AGENTS.md` | 36 | complete | Within limit |
| `languages/typescript/AGENTS.md` | 675 | complete | Far exceeds 100-line limit; refactor needed |

**Missing AGENTS.md files** (directories with 2+ files that lack one):
- `standards/api/` — no AGENTS.md
- `standards/deployment/` — no AGENTS.md
- `standards/messaging/` — no AGENTS.md
- `standards/observability/` — no AGENTS.md
- `standards/security/` — no AGENTS.md
- `standards/storage/` — no AGENTS.md

---

## Coverage Summary

| Category | Complete | Draft | Stub | Absent |
|----------|---------|-------|------|--------|
| Standards (by file) | 0 | 21 | 2 | 5 |
| Language guides | 0 | 20 | 7 | 3+ languages with no guides |
| AGENTS.md | 8 | — | 2 | 6 (category dirs) |

**Counts include:** `api/rest-example.md` is counted as draft. `storage/postgresql.md` now confirmed 0 bytes (was previously recorded as 1 line with H1 only — now fully absent).

---

## Priority Gap Analysis

### R1 — Completely absent; blocks named skills or review capabilities

| Gap | Impact |
|-----|--------|
| `standards/security/overview.md` | Blocks `forge:review-security`; no security rules to enforce against any language |
| `standards/observability/overview.md` | Blocks observability review; no overview rules |
| `standards/observability/logging.md` | Blocks observability review; logging is the most commonly evaluated signal |
| `standards/deployment/ci-cd.md` | Blocks CI/CD review; file is 0 bytes |
| `java/guides/observability/logging-slf4j.md` | Java observability review impossible; file is 0 bytes |
| `languages/kotlin/` (all guides) | Kotlin code cannot be reviewed to any standard |
| `languages/sql/` (all guides) | SQL/migration code cannot be reviewed to any standard |

### R2 — Stub files; content placeholder exists but no substance

| Gap | Impact |
|-----|--------|
| `go/guides/api/rest-echo.md` | Go REST API review falls back to standard only; no framework patterns |
| `go/guides/storage/database-ent.md` | Go storage review has no ORM guidance |
| `go/guides/testing/testing.md` | Go testing review incomplete |
| `go/guides/deployment/build.md` | Go build guidance absent |
| `go/guides/deployment/containerization.md` | Go containerization guidance absent |
| `messaging/messaging.md` | Near-empty TOC; messaging overview has no substance |
| `storage/postgresql.md` | PostgreSQL standard absent despite DynamoDB being covered |

### R3 — Draft (pre-taxonomy); content exists but does not conform to R-N/Checklist structure

All 21 draft standards and 20 draft language guides fall here. The content is usable but
not machine-evaluable until migrated to the R-N / Compliance Checklist taxonomy structure.

### R4 — AGENTS.md over limit or missing from category directories

Eight AGENTS.md files exceed the 100-line limit. Six `standards/<category>/` directories
have no AGENTS.md at all (api, deployment, messaging, observability, security, storage).

---

## What to Build Next (Security + Observability Focus)

Based on this scan, to unblock security and observability reviews the following files are
needed at a minimum:

**Security standards (all absent):**
1. `standards/security/overview.md` — master security standard (R-N structure, ≤300 lines)
2. `standards/security/authentication.md` — AuthN rules (absent)
3. `standards/security/authorization.md` — AuthZ/RBAC rules (absent)
4. `standards/security/secrets.md` — secrets management rules (absent)
5. `standards/security/input-validation.md` — validation/sanitization rules (absent)
6. `standards/security/AGENTS.md` — navigation for the category (absent)

**Observability standards (all absent):**
1. `standards/observability/overview.md` — observability overview standard (0 bytes)
2. `standards/observability/logging.md` — logging standard (0 bytes)
3. `standards/observability/metrics.md` — metrics standard (absent)
4. `standards/observability/tracing.md` — distributed tracing standard (absent)
5. `standards/observability/AGENTS.md` — navigation for the category (absent)

**Companion language guides needed once standards exist:**
- `go/guides/security/` — no security guidance for Go
- `java/guides/security/` — no security guidance for Java
- `java/guides/observability/logging-slf4j.md` — 0 bytes; needs full content
- `go/guides/observability/logging.md` — draft but pre-taxonomy; needs migration
- `python/guides/security/` — no security guidance for Python
- `typescript/guides/security/` — no security guidance for TypeScript
- `typescript/guides/observability/` — no observability guidance for TypeScript
