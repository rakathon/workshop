# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is supplementary-only for conflicting rules until updated;
  higher priority gap than absent stubs

> **Note:** Files authored before the taxonomy was defined use earlier rule identifier
> structures (FS-N/NFS-N) rather than R-N/Compliance Checklist. These are marked **draft** —
> the content is substantive but does not yet conform to the current template.

---

## Standards (`standards/`)

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | absent | 0 | Empty file; highest-risk gap in the repository |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/overview.md` | absent | 0 | Empty file |
| `observability/logging.md` | absent | 0 | Empty file |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | absent | 0 | Empty file |

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | draft | 1257 | Pre-taxonomy structure (FS-N style rules); has Overview, Core Principles, Key Standards, Compliance Notes but missing Scope, R-N Rules, Compliance Checklist sections |
| `api/secure-server-to-server-comm.md` | draft | 112 | Pre-taxonomy structure; has Overview, Related Standards, Implementation Details, Complete Example; missing R-N Rules, Scope, Compliance Checklist |
| `api/rest-example.md` | stub | 320 | Examples reference document; no required standard sections present |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/event-driven-architectures.md` | draft | 539 | Has Overview, Core Vocabulary, Implementation Requirements, Related Standards; missing R-N Rules, Scope, Compliance Checklist |
| `messaging/message-standards.md` | draft | 398 | Has Overview, Applicability, Core Concepts, Field Conventions, Related Standards; missing R-N Rules, Scope, Compliance Checklist |
| `messaging/api-initiated-message.md` | draft | 602 | Has Overview, Required Fields, Message Structure, Validation Checklist; not conforming to current template (no R-N Rules, no Scope) |
| `messaging/user-initiated-message.md` | draft | 313 | Has Overview, Required Fields, Message Structure, Avro Schema; missing R-N Rules, Scope, Compliance Checklist |
| `messaging/versioning.md` | draft | 313 | Has Overview, Breaking vs Non-Breaking Changes, Versioning Strategy, Deprecation Process, Related Standards; missing R-N Rules, Scope, Compliance Checklist |
| `messaging/message-contracts.md` | draft | 167 | Has Overview, Message Contract Definition, Field Naming, Testing Requirements; missing R-N Rules, Scope, Compliance Checklist |
| `messaging/kafka/message-contracts.md` | draft | 307 | Has Overview, Contract Fundamentals, Naming Conventions, Implementation Patterns, Related Standards; missing R-N Rules, Scope, Compliance Checklist |
| `messaging/messaging.md` | stub | 22 | Navigation/index document only; no required standard sections substantively covered |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | draft | 623 | Pre-taxonomy structure; has Overview, Core Principles, Key Standards, Implementation Checklist; missing R-N Rules, Scope, Compliance Checklist |
| `storage/extension-storage.md` | draft | 580 | Has Overview, Storage APIs, Quota Management; missing R-N Rules, Scope, Compliance Checklist |
| `storage/postgresql.md` | absent | 0 | Empty file (single line placeholder) |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/unit-testing.md` | draft | 619 | Pre-taxonomy structure; uses FR-N not R-N identifiers; has Overview, Coverage Requirements, Test Structure, Compliance Summary; missing canonical R-N Rules, Compliance Checklist sections |
| `testing/integration-testing.md` | draft | 752 | Pre-taxonomy structure; uses FR-N identifiers; has Overview, Core Principles, Functional Requirements; missing R-N Rules, Scope, Compliance Checklist |
| `testing/e2e-testing.md` | draft | 528 | Pre-taxonomy structure; uses FR-N/NFR-N identifiers; has Overview, Functional Requirements, Standards Compliance; missing R-N Rules, Scope sections |
| `testing/strategy.md` | draft | 279 | Has Overview, Applicability and Scope, Core Testing Principles, Testing Types, Standards Compliance; missing R-N Rules, Compliance Checklist |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | draft | 777 | Has Overview, State Management, Communication Architecture, Anti-Patterns; missing R-N Rules, Scope, Compliance Checklist |
| `extension-development/security.md` | draft | 422 | Has Overview, CSP, Permissions, Secure Storage; missing R-N Rules, Scope, Compliance Checklist |
| `extension-development/testing.md` | draft | 525 | Has Overview, Unit Testing, Integration Testing, E2E Testing; missing R-N Rules, Scope, Compliance Checklist |
| `extension-development/performance.md` | draft | 431 | Has Overview, Bundle Size Optimization, Lazy Loading; missing R-N Rules, Scope, Compliance Checklist |
| `extension-development/messaging.md` | draft | 393 | Has Overview, Message Patterns, Type-Safe Messaging; missing R-N Rules, Scope, Compliance Checklist |
| `extension-development/cross-browser.md` | draft | 419 | Has Overview, Browser Support Matrix, Feature Detection; has Compatibility Checklist but no R-N Rules, Scope |
| `extension-development/code-organization.md` | draft | 357 | Has Overview, Directory Structure, File Naming, Import Patterns; missing R-N Rules, Scope, Compliance Checklist |

### Skills

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `skills/skill-getting-started.md` | stub | 204 | Navigation/meta document; no required standard sections per taxonomy |
| `skills/skill-quick-reference.md` | stub | 424 | Reference guide; no required standard sections per taxonomy |
| `skills/skill-reference-detailed.md` | stub | 732 | Detailed reference; no required standard sections per taxonomy |
| `skills/standards-patterns.md` | stub | 273 | Patterns document; no required standard sections per taxonomy |

---

## Language Guides (`languages/`)

### Go

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | draft | — | 118 lines; has Directory purpose and Linter (golangci-lint); missing File index table, explicit Navigation section |
| `guides/api/rest-echo.md` | stub | — | 7 lines; framework version reference only; none of the 5 required sections present |
| `guides/deployment/build.md` | stub | — | 18 lines; build process notes only; no Overview, Related standard, Prerequisites, Implementation, Verification sections |
| `guides/deployment/containerization.md` | stub | — | 32 lines; Dockerfile template only; no required guide sections |
| `guides/messaging/datacontract-setup-process.md` | draft | — | 1106 lines; has Overview, Implementation steps; missing Related standard, Verification; no Implements: declaration |
| `guides/observability/logging.md` | draft | — | 337 lines; has Overview, Technology Stack, implementation detail; missing Related standard, Prerequisites, Verification; no Implements: declaration |
| `guides/storage/database-ent.md` | stub | — | 7 lines; framework version reference only; none of the 5 required sections present |
| `guides/testing/folder-structure.md` | draft | — | 585 lines; has Overview, Standard Structure, Implementation detail; missing Related standard, Verification; no Implements: declaration |
| `guides/testing/testing.md` | stub | — | 32 lines; brief testing notes; has Unit Tests and Mocking headings but no required guide sections (no Overview, Related standard, Prerequisites, Verification) |

### Java

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | draft | — | 503 lines; oversize (limit 100); has Directory purpose, extensive project structure, linter references; missing explicit File index table and Navigation section |
| `guides/api/rest-spring.md` | draft | — | 1778 lines; oversize; has Overview, Related Standards (links to rest.md), Implementation; missing explicit Verification section, no Implements: version declaration |
| `guides/messaging/create-register-pojo.md` | draft | — | 482 lines; has Overview, Implementation steps; missing Related standard link, Prerequisites, Verification; no Implements: declaration |
| `guides/messaging/datacontract-setup-process.md` | draft | — | 569 lines; has Overview, Implementation; missing Related standard, Verification; no Implements: declaration |
| `guides/observability/logging-slf4j.md` | absent | — | Empty file |
| `guides/testing/e2e-test-examples.md` | draft | — | 561 lines; has Overview, code examples; supplementary examples doc; missing Related standard, Prerequisites, Verification; no Implements: declaration |
| `guides/testing/folder-structure.md` | draft | — | 717 lines; has Overview, Standard Structure, Implementation detail; missing Related standard, Verification; no Implements: declaration |
| `guides/testing/testing.md` | draft | — | 1468 lines; oversize; has Overview (references unit-testing.md standard), Related Standard link, Implementation detail (frameworks, syntax, examples); has "Implements: Java-specific frameworks..." but not the canonical form; missing Verification section; Missing Implements: declaration in canonical form |

### Kotlin

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | stub | — | 3 lines; placeholder only; no required sections |

### Python

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | draft | — | 470 lines; oversize (limit 100); has Directory purpose, Project Structure, extensive implementation guidance; Linter declared (Ruff); missing explicit File index table and Navigation section |
| `guides/data-science/data-science.md` | draft | — | 698 lines; has Overview, Core Principles, Implementation; missing Related standard, Prerequisites, Verification; no Implements: declaration |
| `guides/documentation/documentation.md` | draft | — | 722 lines; has Overview-equivalent content, Implementation detail; missing Related standard, Prerequisites, Verification; no Implements: declaration |
| `guides/observability/logging.md` | draft | — | 740 lines; has Overview, Core Logging Principles, Implementation detail; missing Related standard (links to no standard), Verification; no Implements: declaration |
| `guides/testing/folder-structure.md` | draft | — | 281 lines; has Overview, Standard Structure; missing Related standard, Verification; no Implements: declaration |
| `guides/testing/testing.md` | draft | — | 821 lines; has Overview, Core Testing Principles, Implementation detail; missing Related standard, Verification; no Implements: declaration |

### SQL

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | stub | — | 3 lines; placeholder only; no required sections |

### Swift

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | draft | — | 36 lines; has Directory purpose, Quick Navigation, Contribution Guidelines; missing File index table (links present but no table), Linter section; no guides/ directory |

*Note: Swift has no `guides/` directory. All content (style-guide/, architecture/, testing/, linting/) is outside the language guide location pattern.*

### Objective-C

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | draft | — | 33 lines; has Directory purpose, Quick Navigation; missing File index table, Linter section; no guides/ directory |

*Note: Objective-C has no `guides/` directory. All content (style-guide/) is outside the language guide location pattern.*

### TypeScript

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | draft | — | 675 lines; oversize (limit 100); has Directory purpose, Project Structure, extensive conventions; Linter declared (ESLint + Prettier); missing explicit File index table and Navigation section |
| `guides/api/rest-express.md` | draft | — | 1072 lines; oversize; has Overview, Related Standards (links to rest.md), Core Principles, Implementation; missing Verification, no Implements: declaration |
| `guides/best-practices/typescript-best-practices.md` | draft | — | 1196 lines; oversize; has Overview-equivalent content, extensive implementation; missing Related standard, Prerequisites, Verification; no Implements: declaration |
| `guides/setup/project-setup.md` | draft | — | 604 lines; oversize; has Overview-equivalent content, Implementation detail; missing Related standard, Prerequisites, Verification; no Implements: declaration |
| `guides/setup/starter-tsconfig-notes.md` | draft | — | 394 lines; has substantive content; missing required guide sections (Overview, Related standard, Prerequisites, Verification); no Implements: declaration |
| `guides/testing/folder-structure.md` | draft | — | 451 lines; has substantive content, folder structure; missing Related standard, Verification; no Implements: declaration |
| `guides/testing/testing-guide.md` | draft | — | 1162 lines; oversize; has Overview-equivalent content, Framework comparison, Implementation; missing Related standard, Verification; no Implements: declaration |

---

## AGENTS.md Files (`standards/`)

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/AGENTS.md` | draft | 173 | Has Directory purpose and navigation links; missing formal File index table with name/purpose/when columns |
| `standards/extension-development/AGENTS.md` | draft | 114 | Has Overview (directory purpose), Core Standards (file links), Quick Reference (navigation); missing File index table |
| `standards/testing/AGENTS.md` | complete | 545 | Has Purpose, Directory Contents (file index), When to Reference, Relationship to Language Guides, Navigation; all 3 required sections present; oversize (limit 100) — content is authoritative |

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | 82 |
| Complete | 1 |
| Draft | 57 |
| Stub | 17 |
| Absent | 7 |
| Major-stale | 0 |

*Pre-taxonomy files (draft): 55 of 57 draft files use pre-taxonomy structure (FS-N/NFS-N rule identifiers, FR-N identifiers, or no R-N/Compliance Checklist sections).*

### Top 5 Priority Gaps

1. **`standards/security/overview.md` — absent**: Security is the highest-risk category; an empty file means no authoritative standard exists for authentication, secrets handling, input validation, or threat modeling. All other security-adjacent content (extension security, secure S2S comm) references a non-existent parent.

2. **`standards/observability/logging.md` and `standards/observability/overview.md` — both absent**: No logging or observability standard exists at the platform level; language guides for Go, Java, and Python implement logging conventions independently with no shared parent standard to align against.

3. **`standards/deployment/ci-cd.md` — absent**: No CI/CD standard exists; deployment pipelines are implemented without a shared quality gate or pipeline structure requirement.

4. **`languages/java/guides/observability/logging-slf4j.md` — absent** (and `languages/go/guides/api/rest-echo.md` and `languages/go/guides/storage/database-ent.md` — stubs): Java's logging guide is empty and two Go guides are 7-line stubs covering only framework version references. These are among the most-referenced categories (API and observability) for active development work.

5. **Widespread missing `Implements:` declarations across all language guides**: None of the 28 language guides in Go, Java, Python, or TypeScript contain a canonical `Implements: standards/<path>@<version>` declaration. This makes it impossible to detect major-stale guides and breaks the standard→guide traceability chain. High-traffic guides (`java/guides/api/rest-spring.md`, `typescript/guides/api/rest-express.md`, `python/guides/testing/testing.md`) all lack version declarations.
