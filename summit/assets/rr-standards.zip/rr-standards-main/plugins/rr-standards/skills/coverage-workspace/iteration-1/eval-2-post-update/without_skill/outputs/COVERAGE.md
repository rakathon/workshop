# Standards Library Coverage Map (Post REST Standard 2.0.0 Update)

Last reviewed: 2026-03-08 | Reviewed by: manual agent scan | Trigger: REST standard bumped to 2.0.0

**Status definitions** (see `standards/TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist
- **major-stale** — (language guides only) guide's declared standard version is behind by a MAJOR bump;
  guide is demoted to supplementary-only for conflicting rules until updated

> **Note on versioning scan:** The TAXONOMY.md versioning scheme requires every language guide header to
> declare `Guide: <guide-version> | Implements: standards/api/rest.md@<standard-version>`. None of the
> existing REST API language guides (Go, Java, TypeScript) carry this header — they predate the taxonomy.
> For the purpose of this coverage map, guides that reference `standards/api/rest.md` but carry **no**
> declared `Implements:` version are treated as **implicitly pre-1.x** and therefore **major-stale** against
> the new 2.0.0 standard.

---

## Standards (`standards/`)

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | draft | 1257 | **Bumped to 2.0.0.** Pre-taxonomy structure (no Scope/Rules/Checklist sections). Version not recorded in file header — version tracked via git tag/history only. |
| `api/rest-example.md` | draft | — | Companion quick-reference example; tied to rest.md |
| `api/secure-server-to-server-comm.md` | draft | 111 | Pre-taxonomy |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | absent | 0 | Empty file |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | draft | 777 | Pre-taxonomy |
| `extension-development/code-organization.md` | draft | 357 | Pre-taxonomy |
| `extension-development/cross-browser.md` | draft | 419 | Pre-taxonomy |
| `extension-development/messaging.md` | draft | 393 | Pre-taxonomy |
| `extension-development/performance.md` | draft | 431 | Pre-taxonomy |
| `extension-development/security.md` | draft | 422 | Pre-taxonomy |
| `extension-development/testing.md` | draft | 525 | Pre-taxonomy |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/api-initiated-message.md` | draft | 602 | Pre-taxonomy |
| `messaging/event-driven-architectures.md` | draft | 539 | Pre-taxonomy |
| `messaging/kafka/message-contracts.md` | draft | 307 | Pre-taxonomy |
| `messaging/message-contracts.md` | draft | 167 | Pre-taxonomy |
| `messaging/message-standards.md` | draft | 398 | Pre-taxonomy |
| `messaging/messaging.md` | stub | 22 | Near-empty TOC |
| `messaging/user-initiated-message.md` | draft | 314 | Pre-taxonomy |
| `messaging/versioning.md` | draft | 313 | Pre-taxonomy |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/logging.md` | absent | 0 | Empty file |
| `observability/overview.md` | absent | 0 | Empty file |

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | absent | 0 | Empty file |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | draft | 623 | Pre-taxonomy |
| `storage/extension-storage.md` | draft | 580 | Pre-taxonomy |
| `storage/postgresql.md` | stub | 1 | H1 title only |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/e2e-testing.md` | draft | 528 | Pre-taxonomy |
| `testing/integration-testing.md` | draft | 752 | Pre-taxonomy |
| `testing/strategy.md` | draft | 279 | Pre-taxonomy |
| `testing/unit-testing.md` | draft | 619 | Pre-taxonomy |

---

## Language Guides (`languages/`)

Style-reference files (Swift `style-guide/`, Objective-C `style-guide/`) are
excluded from this table — they predate the taxonomy and are not implementation
guides.

### Go

| File | Status | Lines | Implements rest.md@ | Staleness vs 2.0.0 |
|------|--------|-------|---------------------|--------------------|
| `go/guides/api/rest-echo.md` | stub | 7 | none declared | **major-stale** (no Implements header; stub content) |
| `go/guides/deployment/build.md` | stub | 18 | n/a | — |
| `go/guides/deployment/containerization.md` | stub | 32 | n/a | — |
| `go/guides/messaging/datacontract-setup-process.md` | draft | 1106 | n/a | — |
| `go/guides/observability/logging.md` | draft | 337 | n/a | — |
| `go/guides/storage/database-ent.md` | stub | 7 | n/a | — |
| `go/guides/testing/folder-structure.md` | draft | 585 | n/a | — |
| `go/guides/testing/testing.md` | stub | 32 | n/a | — |

### Java

| File | Status | Lines | Implements rest.md@ | Staleness vs 2.0.0 |
|------|--------|-------|---------------------|--------------------|
| `java/guides/api/rest-spring.md` | draft | 1778 | none declared | **major-stale** (references rest.md but no Implements header; pre-taxonomy) |
| `java/guides/messaging/create-register-pojo.md` | draft | 482 | n/a | — |
| `java/guides/messaging/datacontract-setup-process.md` | draft | 569 | n/a | — |
| `java/guides/observability/logging-slf4j.md` | absent | 0 | n/a | — |
| `java/guides/testing/e2e-test-examples.md` | draft | 561 | n/a | — |
| `java/guides/testing/folder-structure.md` | draft | 717 | n/a | — |
| `java/guides/testing/testing.md` | draft | 1468 | n/a | — |

### Python

| File | Status | Lines | Implements rest.md@ | Staleness vs 2.0.0 |
|------|--------|-------|---------------------|--------------------|
| `python/guides/data-science/data-science.md` | draft | 698 | n/a | — |
| `python/guides/documentation/documentation.md` | draft | 722 | n/a | — |
| `python/guides/observability/logging.md` | draft | 740 | n/a | — |
| `python/guides/testing/folder-structure.md` | draft | 281 | n/a | — |
| `python/guides/testing/testing.md` | draft | 821 | n/a | — |

> Note: `languages/python/AGENTS.md` references a `guides/api/rest-fastapi.md` guide that
> does not exist on disk. This is an absent REST API guide for Python.

### TypeScript

| File | Status | Lines | Implements rest.md@ | Staleness vs 2.0.0 |
|------|--------|-------|---------------------|--------------------|
| `typescript/guides/api/rest-express.md` | draft | 1072 | none declared | **major-stale** (explicitly links rest.md; no Implements header; pre-taxonomy) |
| `typescript/guides/best-practices/typescript-best-practices.md` | draft | 1196 | n/a | — |
| `typescript/guides/setup/project-setup.md` | draft | 604 | n/a | — |
| `typescript/guides/setup/starter-tsconfig-notes.md` | draft | 394 | n/a | — |
| `typescript/guides/testing/folder-structure.md` | draft | 451 | n/a | — |
| `typescript/guides/testing/testing-guide.md` | draft | 1162 | n/a | — |

### Kotlin

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist |

### Swift

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides)* | absent | Style-guide files exist but are pre-taxonomy style references |

### SQL

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist |

---

## REST API Guide Staleness — Focused View

This section isolates all language guides that implement or reference `standards/api/rest.md`,
evaluated against the newly published **2.0.0** version.

| Guide | Declared `Implements:` | Current Standard | Staleness Classification | Action Required |
|-------|----------------------|-----------------|--------------------------|-----------------|
| `go/guides/api/rest-echo.md` | *(none — stub file)* | 2.0.0 | **major-stale** | Add Implements header; expand from stub to full guide against 2.0.0 |
| `java/guides/api/rest-spring.md` | *(none — pre-taxonomy)* | 2.0.0 | **major-stale** | Add `Guide: <ver> | Implements: standards/api/rest.md@2.0.0` header; audit content against 2.0.0 rules |
| `typescript/guides/api/rest-express.md` | *(none — pre-taxonomy)* | 2.0.0 | **major-stale** | Add `Guide: <ver> | Implements: standards/api/rest.md@2.0.0` header; audit content against 2.0.0 rules |
| `python/guides/api/rest-fastapi.md` | *(absent — file does not exist)* | 2.0.0 | **absent** | Create guide; Python has no REST API implementation guide |

**Staleness classification rationale:** TAXONOMY.md defines a guide with no declared
`Implements:` version as implicitly pre-taxonomy. Because the standard has now received a
MAJOR bump (to 2.0.0), all undeclared guides are treated as **major-stale** under the
conflict resolution rules in TAXONOMY.md §"Conflict Resolution". A MAJOR-stale guide is
supplementary-only and must not override standard rules.

---

## AGENTS.md Navigation Files

| File | Lines | Status | Notes |
|------|-------|--------|-------|
| `standards/AGENTS.md` | 166 | complete | Exceeds 100-line limit; refactor needed |
| `standards/testing/AGENTS.md` | 545 | complete | Exceeds 100-line limit; refactor needed |
| `standards/extension-development/AGENTS.md` | 113 | complete | Exceeds 100-line limit; refactor needed |
| `languages/AGENTS.md` | 47 | complete | |
| `languages/go/AGENTS.md` | 118 | complete | Exceeds 100-line limit; refactor needed |
| `languages/java/AGENTS.md` | 503 | complete | Exceeds 100-line limit; refactor needed |
| `languages/kotlin/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/objective-c/AGENTS.md` | 33 | complete | |
| `languages/python/AGENTS.md` | 470 | complete | Exceeds 100-line limit; refactor needed |
| `languages/sql/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/swift/AGENTS.md` | 36 | complete | |
| `languages/typescript/AGENTS.md` | 675 | complete | Exceeds 100-line limit; refactor needed |

---

## Summary

| Category | Complete | Draft | Stub | Absent | Major-Stale |
|----------|----------|-------|------|--------|-------------|
| Standards | 0 | 21 | 2 | 4 | — |
| Language guides | 0 | 20 | 7 | 3 languages + 1 missing Python REST guide | 3 (Go REST, Java REST, TS REST) |
| AGENTS.md | 8 | — | 2 | — | — |

**Highest-priority gaps** (unchanged from previous scan, with REST staleness added):

1. `standards/security/overview.md` — absent; blocks `forge:review-security`
2. `standards/observability/logging.md` — absent; blocks observability review
3. `standards/deployment/ci-cd.md` — absent; blocks CI/CD review
4. **`go/guides/api/rest-echo.md`** — major-stale stub against rest.md 2.0.0; Go REST API code cannot be reviewed to current standard
5. **`java/guides/api/rest-spring.md`** — major-stale against rest.md 2.0.0; must be audited and have Implements header added
6. **`typescript/guides/api/rest-express.md`** — major-stale against rest.md 2.0.0; must be audited and have Implements header added
7. `python/guides/api/rest-fastapi.md` — absent; Python has no REST API guide at all
8. `languages/kotlin/` — no guides; Kotlin code cannot be reviewed to standard
9. `languages/sql/` — no guides; SQL/migration code cannot be reviewed to standard
