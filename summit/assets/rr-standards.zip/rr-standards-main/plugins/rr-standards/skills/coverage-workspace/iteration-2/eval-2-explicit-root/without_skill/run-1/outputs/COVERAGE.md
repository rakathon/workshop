# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: forge:coverage (manual scan)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist

> **Note:** Files authored before the taxonomy was defined (pre-2026) contain
> substantive content but use the old FS-N/NFS-N structure rather than the
> R-N/Compliance Checklist structure. These are marked **draft** — the content
> is valuable but does not conform to the current standard template. Migration
> to the new taxonomy is tracked as a follow-on story, not this epic.

> **Scope note:** `forge/standards/` and `forge/languages/` both contain only
> `.gitkeep` placeholder files — no content has been authored under the forge
> plugin root yet. All content resides in the repository-level `standards/`
> and `languages/` directories, which is what this map covers.

---

## Standards (`standards/`)

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | draft | 1257 | Pre-taxonomy; no Scope/Rules/Checklist sections |
| `api/secure-server-to-server-comm.md` | draft | 111 | Pre-taxonomy |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | absent | 0 | Empty file |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | draft | 777 | Pre-taxonomy |
| `extension-development/code-organization.md` | draft | 357 | Pre-taxonomy |
| `extension-development/cross-browser.md` | draft | 419 | Pre-taxonomy |
| `extension-development/messaging.md` | draft | 393 | Pre-taxonomy |
| `extension-development/performance.md` | draft | 431 | Pre-taxonomy |
| `extension-development/security.md` | draft | 422 | Pre-taxonomy |
| `extension-development/testing.md` | draft | 525 | Pre-taxonomy |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/api-initiated-message.md` | draft | 602 | Pre-taxonomy |
| `messaging/event-driven-architectures.md` | draft | 539 | Pre-taxonomy |
| `messaging/kafka/message-contracts.md` | draft | 307 | Pre-taxonomy |
| `messaging/message-contracts.md` | draft | 167 | Pre-taxonomy |
| `messaging/message-standards.md` | draft | 398 | Pre-taxonomy |
| `messaging/messaging.md` | stub | 22 | Near-empty TOC |
| `messaging/user-initiated-message.md` | draft | 314 | Pre-taxonomy |
| `messaging/versioning.md` | draft | 313 | Pre-taxonomy |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/logging.md` | absent | 0 | Empty file |
| `observability/overview.md` | absent | 0 | Empty file |

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | absent | 0 | Empty file |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | draft | 623 | Pre-taxonomy |
| `storage/extension-storage.md` | draft | 580 | Pre-taxonomy |
| `storage/postgresql.md` | absent | 0 | Empty file (H1 title line was removed; 0 bytes) |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/e2e-testing.md` | draft | 528 | Pre-taxonomy |
| `testing/integration-testing.md` | draft | 752 | Pre-taxonomy |
| `testing/strategy.md` | draft | 279 | Pre-taxonomy |
| `testing/unit-testing.md` | draft | 619 | Pre-taxonomy |

---

## Language Guides (`languages/`)

Style-reference files (Swift `style-guide/`, Objective-C `style-guide/`) are
excluded from this table — they predate the taxonomy and are not implementation
guides. They are not evaluated against language guide required sections.

### Go

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `go/guides/api/rest-echo.md` | stub | 7 | |
| `go/guides/deployment/build.md` | stub | 18 | |
| `go/guides/deployment/containerization.md` | stub | 32 | |
| `go/guides/messaging/datacontract-setup-process.md` | draft | 1106 | Pre-taxonomy |
| `go/guides/observability/logging.md` | draft | 337 | Pre-taxonomy |
| `go/guides/storage/database-ent.md` | stub | 7 | |
| `go/guides/testing/folder-structure.md` | draft | 585 | Pre-taxonomy |
| `go/guides/testing/testing.md` | stub | 32 | |

### Java

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `java/guides/api/rest-spring.md` | draft | 1778 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/messaging/create-register-pojo.md` | draft | 482 | Pre-taxonomy |
| `java/guides/messaging/datacontract-setup-process.md` | draft | 569 | Pre-taxonomy |
| `java/guides/observability/logging-slf4j.md` | absent | 0 | Empty file |
| `java/guides/testing/e2e-test-examples.md` | draft | 561 | Pre-taxonomy |
| `java/guides/testing/folder-structure.md` | draft | 717 | Pre-taxonomy |
| `java/guides/testing/testing.md` | draft | 1468 | Pre-taxonomy; exceeds 500-line limit |

### Python

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `python/guides/data-science/data-science.md` | draft | 698 | Pre-taxonomy |
| `python/guides/documentation/documentation.md` | draft | 722 | Pre-taxonomy |
| `python/guides/observability/logging.md` | draft | 740 | Pre-taxonomy |
| `python/guides/testing/folder-structure.md` | draft | 281 | Pre-taxonomy |
| `python/guides/testing/testing.md` | draft | 821 | Pre-taxonomy |

### TypeScript

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `typescript/guides/api/rest-express.md` | draft | 1072 | Pre-taxonomy |
| `typescript/guides/best-practices/typescript-best-practices.md` | draft | 1196 | Pre-taxonomy |
| `typescript/guides/setup/project-setup.md` | draft | 604 | Pre-taxonomy |
| `typescript/guides/setup/starter-tsconfig-notes.md` | draft | 394 | Pre-taxonomy |
| `typescript/guides/testing/folder-structure.md` | draft | 451 | Pre-taxonomy |
| `typescript/guides/testing/testing-guide.md` | draft | 1162 | Pre-taxonomy |

### Kotlin

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist |

### Swift

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides)* | absent | Style-guide files exist but are pre-taxonomy style references, not implementation guides |

### SQL

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist |

---

## AGENTS.md Navigation Files

| File | Lines | Status | Notes |
|------|-------|--------|-------|
| `standards/AGENTS.md` | 173 | complete | Exceeds 100-line limit; refactor needed |
| `standards/testing/AGENTS.md` | 545 | complete | Exceeds 100-line limit; refactor needed |
| `standards/extension-development/AGENTS.md` | 113 | complete | Exceeds 100-line limit; refactor needed |
| `languages/AGENTS.md` | 47 | complete | |
| `languages/go/AGENTS.md` | 118 | complete | Exceeds 100-line limit; refactor needed |
| `languages/java/AGENTS.md` | 503 | complete | Exceeds 100-line limit; refactor needed |
| `languages/kotlin/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/objective-c/AGENTS.md` | 33 | complete | |
| `languages/python/AGENTS.md` | 470 | complete | Exceeds 100-line limit; refactor needed |
| `languages/sql/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/swift/AGENTS.md` | 36 | complete | |
| `languages/typescript/AGENTS.md` | 675 | complete | Exceeds 100-line limit; refactor needed |

---

## forge/ Plugin Directories

| Directory | Files | Status |
|-----------|-------|--------|
| `forge/standards/` | `.gitkeep` only | No content authored yet |
| `forge/languages/` | `.gitkeep` only | No content authored yet |
| `forge/skills/` | 49 skill stub directories (`.gitkeep` only) | Skill definitions not yet authored |
| `forge/hooks/` | 4 hook directories (`.gitkeep` only) | Hook implementations not yet authored |

---

## Summary

| Category | Complete | Draft | Stub | Absent |
|----------|---------|-------|------|--------|
| Standards | 0 | 21 | 1 | 5 |
| Language guides | 0 | 20 | 4 | 3 languages with no guides |
| AGENTS.md | 8 | — | 2 | — |

**Highest-priority gaps** (no content, blocked by program requirements):
1. `standards/security/overview.md` — absent; blocks `forge:review-security`
2. `standards/observability/logging.md` — absent; blocks observability review
3. `standards/deployment/ci-cd.md` — absent; blocks CI/CD review
4. `languages/kotlin/` — no guides; Kotlin code cannot be reviewed to standard
5. `languages/sql/` — no guides; SQL/migration code cannot be reviewed to standard
6. `forge/skills/` — all 49 skill directories are stubs; forge plugin not yet functional
