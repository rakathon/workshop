# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated scan)

**Status definitions** (see `standards/TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing
- **stub** — file exists; minimal or no required sections present (title-only or link-only content)
- **absent** — file does not exist or is empty (0 lines)

> **Note:** Files authored before the taxonomy was defined (pre-2026) contain
> substantive content but use older section structures rather than the
> R-N/Compliance Checklist/Scope structure required by `TAXONOMY.md`. These are
> marked **draft** — the content is valuable but does not fully conform to the
> current standard template. Migration to the new taxonomy structure is a
> follow-on task.

---

## Standards (`standards/`)

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | draft | 1257 | Pre-taxonomy; no Scope/Rules/Checklist sections; exceeds 300-line limit |
| `api/rest-example.md` | draft | 320 | Pre-taxonomy supplementary example doc |
| `api/secure-server-to-server-comm.md` | draft | 111 | Pre-taxonomy; missing Scope/Rules/Checklist |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | absent | 0 | Empty file |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | draft | 777 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/code-organization.md` | draft | 357 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/cross-browser.md` | draft | 419 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/messaging.md` | draft | 393 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/performance.md` | draft | 431 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/security.md` | draft | 422 | Pre-taxonomy; exceeds 300-line limit |
| `extension-development/testing.md` | draft | 525 | Pre-taxonomy; exceeds 300-line limit |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/api-initiated-message.md` | draft | 602 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/event-driven-architectures.md` | draft | 539 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/kafka/message-contracts.md` | draft | 307 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/message-contracts.md` | draft | 167 | Pre-taxonomy |
| `messaging/message-standards.md` | draft | 398 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/messaging.md` | stub | 22 | Near-empty TOC/index only; no substantive content |
| `messaging/user-initiated-message.md` | draft | 314 | Pre-taxonomy; exceeds 300-line limit |
| `messaging/versioning.md` | draft | 313 | Pre-taxonomy; exceeds 300-line limit |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/logging.md` | absent | 0 | Empty file |
| `observability/overview.md` | absent | 0 | Empty file |

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | absent | 0 | Empty file |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | draft | 623 | Pre-taxonomy; exceeds 300-line limit |
| `storage/extension-storage.md` | draft | 580 | Pre-taxonomy; exceeds 300-line limit |
| `storage/postgresql.md` | absent | 0 | Empty file |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/e2e-testing.md` | draft | 528 | Pre-taxonomy; exceeds 300-line limit |
| `testing/integration-testing.md` | draft | 752 | Pre-taxonomy; exceeds 300-line limit |
| `testing/strategy.md` | draft | 279 | Pre-taxonomy |
| `testing/unit-testing.md` | draft | 619 | Pre-taxonomy; exceeds 300-line limit |

---

## Language Guides (`languages/`)

Style-reference files (Swift `style-guide/`, Objective-C `style-guide/`) are
excluded from this table — they predate the taxonomy and are not implementation
guides conforming to the language guide required sections.

### Go

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `go/guides/api/rest-echo.md` | stub | 7 | Framework/version reference only; no implementation content |
| `go/guides/deployment/build.md` | stub | 18 | Partial build notes; missing Overview/Related standard/Prerequisites/Verification |
| `go/guides/deployment/containerization.md` | stub | 32 | Partial Docker notes; missing required sections |
| `go/guides/messaging/datacontract-setup-process.md` | draft | 1106 | Pre-taxonomy; exceeds 500-line limit |
| `go/guides/observability/logging.md` | draft | 337 | Pre-taxonomy |
| `go/guides/storage/database-ent.md` | stub | 7 | Framework/version reference only; no implementation content |
| `go/guides/testing/folder-structure.md` | draft | 585 | Pre-taxonomy; exceeds 500-line limit |
| `go/guides/testing/testing.md` | stub | 32 | Partial testing notes; missing required sections |

### Java

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `java/guides/api/rest-spring.md` | draft | 1778 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/messaging/create-register-pojo.md` | draft | 482 | Pre-taxonomy |
| `java/guides/messaging/datacontract-setup-process.md` | draft | 569 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/observability/logging-slf4j.md` | absent | 0 | Empty file |
| `java/guides/testing/e2e-test-examples.md` | draft | 561 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/testing/folder-structure.md` | draft | 717 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/testing/testing.md` | draft | 1468 | Pre-taxonomy; exceeds 500-line limit |

### Python

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `python/guides/data-science/data-science.md` | draft | 698 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/documentation/documentation.md` | draft | 722 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/observability/logging.md` | draft | 740 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/testing/folder-structure.md` | draft | 281 | Pre-taxonomy |
| `python/guides/testing/testing.md` | draft | 821 | Pre-taxonomy; exceeds 500-line limit |

### TypeScript

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `typescript/guides/api/rest-express.md` | draft | 1072 | Pre-taxonomy; exceeds 500-line limit |
| `typescript/guides/best-practices/typescript-best-practices.md` | draft | 1196 | Pre-taxonomy; exceeds 500-line limit |
| `typescript/guides/setup/project-setup.md` | draft | 604 | Pre-taxonomy; exceeds 500-line limit |
| `typescript/guides/setup/starter-tsconfig-notes.md` | draft | 394 | Pre-taxonomy |
| `typescript/guides/testing/folder-structure.md` | draft | 451 | Pre-taxonomy |
| `typescript/guides/testing/testing-guide.md` | draft | 1162 | Pre-taxonomy; exceeds 500-line limit |

### Kotlin

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist; only a stub AGENTS.md (3 lines) |

### Swift

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides)* | absent | Style-guide and architecture files exist but are pre-taxonomy style references, not taxonomy-conforming implementation guides |

### SQL

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist; only a stub AGENTS.md (3 lines) |

---

## AGENTS.md Navigation Files

| File | Lines | Status | Notes |
|------|-------|--------|-------|
| `standards/AGENTS.md` | 173 | complete | Exceeds 100-line limit; refactor needed |
| `standards/testing/AGENTS.md` | 545 | complete | Exceeds 100-line limit; refactor needed |
| `standards/extension-development/AGENTS.md` | 113 | complete | Exceeds 100-line limit; refactor needed |
| `languages/AGENTS.md` | 47 | complete | Within limit |
| `languages/go/AGENTS.md` | 118 | complete | Exceeds 100-line limit; refactor needed |
| `languages/java/AGENTS.md` | 503 | complete | Exceeds 100-line limit; refactor needed |
| `languages/kotlin/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/objective-c/AGENTS.md` | 33 | complete | Within limit |
| `languages/python/AGENTS.md` | 470 | complete | Exceeds 100-line limit; refactor needed |
| `languages/sql/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/swift/AGENTS.md` | 36 | complete | Within limit |
| `languages/typescript/AGENTS.md` | 675 | complete | Exceeds 100-line limit; refactor needed |

---

## Summary

| Category | Complete | Draft | Stub | Absent |
|----------|---------|-------|------|--------|
| Standards | 0 | 22 | 1 | 5 |
| Language guides | 0 | 21 | 7 | 3 languages with no guides |
| AGENTS.md | 8 | — | 2 | — |

**Totals across standards + language guides:**
- Complete: 0
- Draft: 43
- Stub: 8
- Absent: 8 (files) + 3 languages (Kotlin, Swift guides, SQL)

---

## Highest-Priority Gaps

Gaps where no usable content exists, blocking review/validation workflows:

1. `standards/security/overview.md` — absent (empty); blocks security review
2. `standards/observability/logging.md` — absent (empty); blocks observability review
3. `standards/observability/overview.md` — absent (empty); blocks observability review
4. `standards/deployment/ci-cd.md` — absent (empty); blocks CI/CD review
5. `standards/storage/postgresql.md` — absent (empty); blocks PostgreSQL storage review
6. `java/guides/observability/logging-slf4j.md` — absent (empty); no Java logging guide
7. `languages/kotlin/` — no guides; Kotlin code cannot be reviewed against standard
8. `languages/sql/` — no guides; SQL/migration code cannot be reviewed against standard

## Taxonomy Conformance Issues

Issues across otherwise substantive (draft) content:

- **All pre-taxonomy standards** (22 files): missing Scope, R-N Rules, and Compliance Checklist sections required by `TAXONOMY.md`
- **All pre-taxonomy language guides** (21 files): missing Related Standard link with version declaration, and Verification section required by `TAXONOMY.md`
- **Line limit violations in standards** (many files exceed 300-line limit): `api/rest.md` (1257), `extension-development/architecture.md` (777), `testing/integration-testing.md` (752), `testing/unit-testing.md` (619), `storage/dynamodb.md` (623), `storage/extension-storage.md` (580), `testing/e2e-testing.md` (528), `messaging/api-initiated-message.md` (602), `messaging/event-driven-architectures.md` (539), and others
- **Line limit violations in language guides** (many files exceed 500-line limit): `java/guides/api/rest-spring.md` (1778), `java/guides/testing/testing.md` (1468), `typescript/guides/best-practices/typescript-best-practices.md` (1196), and others
- **AGENTS.md size violations** (7 of 10 substantive AGENTS.md files exceed 100-line limit)
