# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is supplementary-only for conflicting rules until updated;
  higher priority gap than absent stubs

> **Note:** `forge/standards/TAXONOMY.md` was not found. Fallback embedded taxonomy definitions were used for required sections and expected categories/languages.

---

## Standards (`standards/`)

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/security/` | absent | — | Category directory does not exist |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/observability/` | absent | — | Category directory does not exist |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/deployment/` | absent | — | Category directory does not exist |

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/api/` | absent | — | Category directory does not exist |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/testing/` | absent | — | Category directory does not exist |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/storage/` | absent | — | Category directory does not exist |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/messaging/` | absent | — | Category directory does not exist |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/extension-development/` | absent | — | Category directory does not exist |

### Skills

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/skills/` | absent | — | Category directory does not exist |

---

## Language Guides (`languages/`)

### Go

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `languages/go/AGENTS.md` | absent | — | Language directory does not exist |

### Java

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `languages/java/AGENTS.md` | absent | — | Language directory does not exist |

### Kotlin

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `languages/kotlin/AGENTS.md` | absent | — | Language directory does not exist |

### Python

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `languages/python/AGENTS.md` | absent | — | Language directory does not exist |

### SQL

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `languages/sql/AGENTS.md` | absent | — | Language directory does not exist |

### Swift

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `languages/swift/AGENTS.md` | absent | — | Language directory does not exist |

### TypeScript

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `languages/typescript/AGENTS.md` | absent | — | Language directory does not exist |

---

## AGENTS.md Files (`standards/`)

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/AGENTS.md` | absent | — | No AGENTS.md found under standards/ |

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | 17 |
| Complete | 0 |
| Draft | 0 |
| Stub | 0 |
| Absent | 17 |
| Major-stale | 0 |

### Top 5 Priority Gaps

1. `standards/security/` — entire security category absent; authentication, secrets, and validation standards missing
2. `standards/observability/` — entire observability category absent; logging, metrics, and tracing standards missing
3. `standards/deployment/` — entire deployment category absent; CI/CD and container standards missing
4. `standards/api/` — entire api category absent; REST and other API standards missing (high-traffic category)
5. `standards/testing/` — entire testing category absent; testing strategies standards missing (high-traffic category)
