# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `rr-standards:coverage` (automated)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is supplementary-only for conflicting rules until updated;
  higher priority gap than absent stubs

> **Note:** Files authored before the taxonomy was defined use earlier rule identifier
> structures (FS-N/NFS-N) rather than R-N/Compliance Checklist. These are marked **draft** —
> the content is substantive but does not yet conform to the current template.

> **REST standard version note:** `standards/api/rest.md` carries no `Version:` declaration
> in the file itself. Per task context this standard was recently bumped to **2.0.0**. All
> REST-related language guides (Go `rest-echo.md`, Java `rest-spring.md`, TypeScript
> `rest-express.md`) reference the REST standard but contain no `Implements:` declaration
> with a version pin, so formal staleness cannot be determined from file content alone.
> They are flagged with "Missing Implements: declaration" and are listed as high priority
> because the standard just had a MAJOR version bump.

---

## Standards (`standards/`)

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | **absent** | 0 | File is empty; no content |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/logging.md` | **absent** | 0 | File is empty; no content |
| `observability/overview.md` | **absent** | 0 | File is empty; no content |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | **absent** | 0 | File is empty; no content |

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | **draft** | 1257 | Has Overview; missing Scope, Rules (R-N identifiers), Compliance Checklist, Examples, Related. Pre-taxonomy structure ("Key Standards", "Core Principles"). No `Version:` declaration despite task context indicating version is now 2.0.0. Exceeds 300-line size limit. |
| `api/rest-example.md` | **stub** | 320 | No required taxonomy sections present. Supplementary example file; does not follow standard template. Exceeds 300-line size limit. |
| `api/secure-server-to-server-comm.md` | **draft** | 111 | Has Overview, Related Standards; missing Scope, Rules (R-N), Compliance Checklist, Examples. Pre-taxonomy structure. |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/messaging.md` | **draft** | 22 | Has Overview; all other required sections absent. Very thin — effectively a table of contents stub. |
| `messaging/message-standards.md` | **draft** | 398 | Has Overview, Related Standards; missing Scope, Rules (R-N), Compliance Checklist, Examples. Pre-taxonomy structure. Exceeds 300-line limit. |
| `messaging/event-driven-architectures.md` | **draft** | 539 | Has Overview, Related Standards; missing Scope, Rules (R-N), Compliance Checklist, Examples. Pre-taxonomy structure. Exceeds 300-line limit. |
| `messaging/api-initiated-message.md` | **draft** | 602 | Has Overview; missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. Exceeds 300-line limit. |
| `messaging/user-initiated-message.md` | **draft** | 314 | Has Overview; missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. Exceeds 300-line limit. |
| `messaging/versioning.md` | **draft** | 313 | Has Overview, Related Standards; missing Scope, Rules (R-N), Compliance Checklist, Examples. Pre-taxonomy structure. Exceeds 300-line limit. |
| `messaging/message-contracts.md` | **draft** | 167 | Has Overview; missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. |
| `messaging/kafka/message-contracts.md` | **draft** | 307 | Has Overview, Related Standards; missing Scope, Rules (R-N), Compliance Checklist, Examples. Pre-taxonomy structure. Exceeds 300-line limit. |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/dynamodb.md` | **draft** | 623 | Has Overview; missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. Exceeds 300-line limit. |
| `storage/extension-storage.md` | **draft** | 580 | Has Overview, Related Standards; missing Scope, Rules (R-N), Compliance Checklist, Examples. Pre-taxonomy structure. Exceeds 300-line limit. |
| `storage/postgresql.md` | **absent** | 0 | File is empty; no content |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/strategy.md` | **draft** | 279 | Has Overview (with `**Version:** 1.1.0` in body); missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. |
| `testing/unit-testing.md` | **draft** | 619 | Has Overview (with `**Version:** 1.0.0`); missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. Exceeds 300-line limit. |
| `testing/integration-testing.md` | **draft** | 752 | Has Overview (with `**Version:** 1.0.0`); missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. Exceeds 300-line limit. |
| `testing/e2e-testing.md` | **draft** | 528 | Has Overview (with `**Version:** 1.0.0`); missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. Exceeds 300-line limit. |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | **draft** | 777 | Has Overview, Related Standards; missing Scope, Rules (R-N), Compliance Checklist, Examples. Pre-taxonomy structure. Exceeds 300-line limit. |
| `extension-development/code-organization.md` | **draft** | 357 | Has Overview, "Examples from Production", Related Standards; missing Scope, Rules (R-N), Compliance Checklist. Pre-taxonomy structure. Exceeds 300-line limit. |
| `extension-development/cross-browser.md` | **draft** | 419 | Has Overview, "Examples from Production", Related Standards; missing Scope, Rules (R-N), Compliance Checklist. Pre-taxonomy structure. Exceeds 300-line limit. |
| `extension-development/performance.md` | **draft** | 431 | Has Overview, "Examples from Production", Related Standards; missing Scope, Rules (R-N), Compliance Checklist. Pre-taxonomy structure. Exceeds 300-line limit. |
| `extension-development/security.md` | **draft** | 422 | Has Overview, "Examples from Production", Related Standards; missing Scope, Rules (R-N), Compliance Checklist. Pre-taxonomy structure. Exceeds 300-line limit. |
| `extension-development/testing.md` | **draft** | 525 | Has Overview, "Examples from Production", Related Standards; missing Scope, Rules (R-N), Compliance Checklist. Pre-taxonomy structure. Exceeds 300-line limit. |
| `extension-development/messaging.md` | **draft** | 393 | Has Overview, "Examples from Production", Related Standards; missing Scope, Rules (R-N), Compliance Checklist. Pre-taxonomy structure. Exceeds 300-line limit. |

### Skills

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `skills/skill-getting-started.md` | **draft** | 204 | Has Overview; missing Scope, Rules (R-N), Compliance Checklist, Examples, Related. Pre-taxonomy structure. |
| `skills/skill-reference-detailed.md` | **draft** | 732 | Has Examples sections; missing Overview, Scope, Rules (R-N), Compliance Checklist, Related as top-level required sections. Pre-taxonomy structure. Exceeds 300-line limit. |
| `skills/skill-quick-reference.md` | **stub** | 424 | No required taxonomy sections. Reference/cheat-sheet format. Exceeds 300-line limit. |
| `skills/standards-patterns.md` | **stub** | 273 | No required taxonomy sections. Content is present but entirely non-conforming structure. |

---

## Language Guides (`languages/`)

### Go

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 118 lines (oversize; limit 100). Substantive content; sections do not match required taxonomy headings (Directory purpose / File index / Navigation / Linter). |
| `guides/api/rest-echo.md` | **stub** | — | 7 lines; lists framework and version only; no required guide sections present. Missing Implements: declaration. |
| `guides/deployment/build.md` | **stub** | — | 18 lines; has "Build Process" section only; no required guide sections. Missing Implements: declaration. |
| `guides/deployment/containerization.md` | **stub** | — | 32 lines; contains only a Dockerfile snippet under a title; no required guide sections. Missing Implements: declaration. |
| `guides/messaging/datacontract-setup-process.md` | **draft** | — | 1106 lines (oversize). Has Overview; missing Related standard, Prerequisites, Implementation, Verification as distinct conforming sections. Missing Implements: declaration. |
| `guides/observability/logging.md` | **draft** | — | 337 lines. Has Overview; missing Related standard, Prerequisites, Implementation, Verification as conforming sections. Missing Implements: declaration. |
| `guides/storage/database-ent.md` | **stub** | — | 7 lines; lists framework and version only; no required guide sections. Missing Implements: declaration. |
| `guides/testing/folder-structure.md` | **draft** | — | 585 lines (oversize). Has Overview; missing Related standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/testing/testing.md` | **stub** | — | 32 lines; has named subsections (Unit Tests, Mocking, Test Coverage) but no required guide-level sections (Overview, Related standard, Prerequisites, Implementation, Verification). Missing Implements: declaration. |

### Java

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 503 lines (oversize). Substantive content; sections do not match required taxonomy headings. |
| `guides/api/rest-spring.md` | **draft** | — | 1778 lines (oversize). Has Overview; missing Related standard (as required heading), Prerequisites, Implementation, Verification as conforming taxonomy sections. Links to REST standard in prose only. Missing Implements: declaration. |
| `guides/messaging/create-register-pojo.md` | **draft** | — | 482 lines (oversize). Has substantive content; missing all required guide sections as taxonomy-conforming headings. Missing Implements: declaration. |
| `guides/messaging/datacontract-setup-process.md` | **draft** | — | 569 lines (oversize). Has Overview; missing conforming Required standard/Prerequisites/Implementation/Verification sections. Missing Implements: declaration. |
| `guides/observability/logging-slf4j.md` | **absent** | — | File is empty (0 bytes). |
| `guides/testing/e2e-test-examples.md` | **draft** | — | 561 lines (oversize). Has substantive content; no required guide taxonomy sections present as conforming headings. Missing Implements: declaration. |
| `guides/testing/folder-structure.md` | **draft** | — | 717 lines (oversize). Has Overview; missing Related standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/testing/testing.md` | **draft** | — | 1468 lines (oversize). Has Overview; `Implements:` line present but says "Java-specific frameworks, syntax, examples" — not a standard path+version reference. Missing valid Implements: declaration. |

### Python

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 470 lines (oversize). Substantive content; sections do not match required taxonomy headings. |
| `guides/data-science/data-science.md` | **draft** | — | 698 lines (oversize). Has Overview; missing Related standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/documentation/documentation.md` | **draft** | — | 722 lines (oversize). Has Overview; missing Related standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/observability/logging.md` | **draft** | — | 740 lines (oversize). Has Overview; missing Related standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/testing/folder-structure.md` | **draft** | — | 281 lines. Has Overview; missing Related standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/testing/testing.md` | **draft** | — | 821 lines (oversize). Has Overview; missing Related standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |

### TypeScript

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 675 lines (oversize). Substantive content; sections do not match required taxonomy headings. |
| `guides/api/rest-express.md` | **draft** | — | 1072 lines (oversize). Has Overview; links to REST standard in prose but missing Required standard, Prerequisites, Implementation, Verification as conforming headings. Missing Implements: declaration. |
| `guides/best-practices/typescript-best-practices.md` | **draft** | — | 1196 lines (oversize). Has Overview; missing Required standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/setup/project-setup.md` | **draft** | — | 604 lines (oversize). Has Overview; missing Required standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/setup/starter-tsconfig-notes.md` | **draft** | — | 394 lines (oversize). Substantive content; no required guide sections. Missing Implements: declaration. |
| `guides/testing/folder-structure.md` | **draft** | — | 451 lines (oversize). Has Overview; missing Required standard, Prerequisites, Implementation, Verification. Missing Implements: declaration. |
| `guides/testing/testing-guide.md` | **draft** | — | 1162 lines (oversize). No required guide taxonomy sections. Missing Implements: declaration. |

### Kotlin

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **stub** | — | 3 lines; placeholder text only ("living document" boilerplate). No required sections. |
| (no guides directory) | — | — | No `guides/` directory found. Language has no guide coverage. |

### SQL

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **stub** | — | 3 lines; placeholder text only. No required sections. |
| (no guides directory) | — | — | No `guides/` directory found. Language has no guide coverage. |

### Swift

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 36 lines. Has substantive content (Quick Navigation, Contribution Guidelines, Agent Rules) but does not use required taxonomy headings (Directory purpose / File index / Navigation / Linter). |
| (no guides/ directory) | — | — | Content is under `architecture/`, `linting/`, `style-guide/`, `testing/` — not under a `guides/` path. None qualify as language guides per taxonomy rule 5. |

### Objective-C

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | **draft** | — | 33 lines. Has substantive content (Quick Navigation, Agent Rules) but does not use required taxonomy headings. |
| (no guides/ directory) | — | — | Content is under `style-guide/` — not under a `guides/` path. None qualify as language guides per taxonomy rule 5. |

---

## AGENTS.md Files (`standards/`)

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `standards/AGENTS.md` | **draft** | 173 | Has Purpose, Available Standards by Category, Navigation — covers required concepts but headings do not match taxonomy-required names (Directory purpose / File index / Navigation). Oversize (limit 100). |
| `standards/testing/AGENTS.md` | **draft** | 545 | Has Purpose, Directory Contents, Navigation — non-conforming headings. Severely oversize (limit 100). |
| `standards/extension-development/AGENTS.md` | **draft** | 113 | Has Overview, Core Standards, Additional Resources, Quick Reference — non-conforming headings. Oversize (limit 100). |

---

## Staleness Check Summary

The REST API standard (`standards/api/rest.md`) was bumped to version **2.0.0** (MAJOR). The
following language guides reference this standard but contain **no `Implements:` declaration**
with a version pin:

| Guide | References REST Standard? | Implements: Declaration | Staleness verdict |
|-------|--------------------------|------------------------|-------------------|
| `languages/go/guides/api/rest-echo.md` | No (stub only) | Missing | Cannot assess — stub |
| `languages/java/guides/api/rest-spring.md` | Yes (prose link) | Missing | Cannot formally assess; guide was written against pre-2.0.0 content; treat as potentially stale |
| `languages/typescript/guides/api/rest-express.md` | Yes (prose link) | Missing | Cannot formally assess; guide was written against pre-2.0.0 content; treat as potentially stale |

**Recommendation:** All three REST-related guides should add a valid `Implements:` declaration
and be reviewed against the 2.0.0 standard before being considered current.

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | 76 |
| Complete | 0 |
| Draft | 55 (all pre-taxonomy) |
| Stub | 11 |
| Absent | 10 |
| Major-stale | 0 (formal; see staleness check above) |

_Artifact breakdown: 28 language-agnostic standards + 4 skills standards files + 3 standards
AGENTS.md + 9 language AGENTS.md (including languages/ root) + 22 language guides (Go:8,
Java:7, Python:5, TypeScript:6 — all under /guides/) = 76 total_

### Top 5 Priority Gaps

1. **REST API language guides lack `Implements:` declarations against the new REST 2.0.0 standard** — `languages/java/guides/api/rest-spring.md` and `languages/typescript/guides/api/rest-express.md` both reference `standards/api/rest.md` in prose but have no version pin. With REST bumped to 2.0.0 (MAJOR), these guides cannot be verified as current and should be treated as potentially stale per the conflict resolution rules in TAXONOMY.md. Add `Guide: X.Y.Z | Implements: standards/api/rest.md@2.0.0` and review against the new version.

2. **Security standard is absent** — `standards/security/overview.md` is empty (0 bytes). A missing security standard means no authoritative rules exist for auth, PII handling, or input validation. Blocking risk for R1 work.

3. **Observability standards are absent** — Both `standards/observability/logging.md` and `standards/observability/overview.md` are empty. No authoritative logging or tracing rules are defined in the standards library.

4. **Deployment standard is absent** — `standards/deployment/ci-cd.md` is empty. CI/CD and containerisation guidance exists only in informal language guides (Go `deployment/`) with no governing standard.

5. **REST API standard itself lacks taxonomy conformance and a version declaration** — `standards/api/rest.md` (1257 lines, the most-referenced standard in the library) has no `Version:` line, no R-N rule identifiers, no Compliance Checklist, and no Scope section. It is marked draft. Given the MAJOR bump to 2.0.0, adding a version declaration is the minimum immediate action needed to enable staleness checks across all language guides.
