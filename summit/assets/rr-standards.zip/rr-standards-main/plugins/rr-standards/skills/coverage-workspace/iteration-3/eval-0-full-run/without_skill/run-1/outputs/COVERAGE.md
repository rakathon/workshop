# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: `forge:coverage` (manual scan)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is demoted to supplementary-only for conflicting rules until
  updated; higher priority gap than absent stubs

> **Note:** Files authored before the taxonomy was defined (pre-2026) contain
> substantive content but use the old FS-N/NFS-N structure rather than the
> R-N/Compliance Checklist structure. These are marked **draft** — the content
> is valuable but does not conform to the current standard template. Migration
> to the new taxonomy is tracked as a follow-on story, not this epic.

---

## Standards (`standards/`)

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | draft | 1257 | Pre-taxonomy; no Scope/Rules/Checklist sections |
| `api/rest-example.md` | draft | 321 | Quick-reference examples companion to rest.md; not a standalone standard |
| `api/rest.policy.md` | complete | 58 | Enforcement policy; all required sections present |
| `api/secure-server-to-server-comm.md` | draft | 111 | Pre-taxonomy |

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | absent | 0 | Empty file |

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | draft | 777 | Pre-taxonomy |
| `extension-development/code-organization.md` | draft | 357 | Pre-taxonomy |
| `extension-development/cross-browser.md` | draft | 419 | Pre-taxonomy |
| `extension-development/messaging.md` | draft | 393 | Pre-taxonomy |
| `extension-development/performance.md` | draft | 431 | Pre-taxonomy |
| `extension-development/security.md` | draft | 422 | Pre-taxonomy |
| `extension-development/testing.md` | draft | 525 | Pre-taxonomy |

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/api-initiated-message.md` | draft | 602 | Pre-taxonomy |
| `messaging/event-driven-architectures.md` | draft | 539 | Pre-taxonomy |
| `messaging/kafka/message-contracts.md` | draft | 307 | Pre-taxonomy |
| `messaging/message-contracts.md` | draft | 168 | Pre-taxonomy |
| `messaging/message-standards.md` | draft | 399 | Pre-taxonomy |
| `messaging/messaging.md` | stub | 22 | Near-empty TOC; no required sections |
| `messaging/user-initiated-message.md` | draft | 314 | Pre-taxonomy |
| `messaging/versioning.md` | draft | 313 | Pre-taxonomy |

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/logging.md` | absent | 0 | Empty file |
| `observability/overview.md` | absent | 0 | Empty file |

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | absent | 0 | Empty file |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/connection-pooling.md` | complete | 113 | New in this scan; all required sections present |
| `storage/dynamodb.md` | draft | 624 | Pre-taxonomy |
| `storage/extension-storage.md` | draft | 580 | Pre-taxonomy |
| `storage/postgresql.md` | stub | 1 | H1 title only |

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/e2e-testing.md` | draft | 529 | Pre-taxonomy |
| `testing/integration-testing.md` | draft | 752 | Pre-taxonomy |
| `testing/strategy.md` | draft | 279 | Pre-taxonomy |
| `testing/unit-testing.md` | draft | 619 | Pre-taxonomy |

---

## Enforcement Policies (`standards/`)

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.policy.md` | complete | 58 | 48 rules; advisory_threshold=5; all required sections present |

---

## Language Guides (`languages/`)

Style-reference files (Swift `style-guide/`, Objective-C `style-guide/`) are
excluded from this table — they predate the taxonomy and are not implementation
guides. They are not evaluated against language guide required sections.

### Go

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `go/guides/api/rest-echo.md` | stub | 8 | |
| `go/guides/deployment/build.md` | stub | 19 | |
| `go/guides/deployment/containerization.md` | stub | 33 | |
| `go/guides/messaging/datacontract-setup-process.md` | draft | 1106 | Pre-taxonomy |
| `go/guides/observability/logging.md` | draft | 337 | Pre-taxonomy |
| `go/guides/storage/database-ent.md` | stub | 8 | |
| `go/guides/testing/folder-structure.md` | draft | 585 | Pre-taxonomy |
| `go/guides/testing/testing.md` | stub | 33 | |

### Java

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `java/guides/api/rest-spring.md` | draft | 1778 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/messaging/create-register-pojo.md` | draft | 482 | Pre-taxonomy |
| `java/guides/messaging/datacontract-setup-process.md` | draft | 569 | Pre-taxonomy |
| `java/guides/observability/logging-slf4j.md` | absent | 0 | Empty file |
| `java/guides/testing/e2e-test-examples.md` | draft | 562 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/testing/folder-structure.md` | draft | 717 | Pre-taxonomy; exceeds 500-line limit |
| `java/guides/testing/testing.md` | draft | 1469 | Pre-taxonomy; exceeds 500-line limit |

### Python

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `python/guides/data-science/data-science.md` | draft | 698 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/documentation/documentation.md` | draft | 722 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/observability/logging.md` | draft | 740 | Pre-taxonomy; exceeds 500-line limit |
| `python/guides/testing/folder-structure.md` | draft | 281 | Pre-taxonomy |
| `python/guides/testing/testing.md` | draft | 821 | Pre-taxonomy; exceeds 500-line limit |

### Swift

> Note: Swift now has implementation guides in `architecture/` and `testing/` subdirectories.
> These are not under `guides/` and therefore outside the TAXONOMY.md path convention for
> language guides (`languages/<lang>/guides/<area>/`). They are treated as pre-taxonomy
> content; substantive but not yet conforming to language guide required sections.

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `swift/architecture/dependency-injection.md` | draft | 117 | Pre-taxonomy; outside `guides/` path |
| `swift/architecture/swiftui-mvvm.md` | draft | 121 | Pre-taxonomy; outside `guides/` path |
| `swift/testing/async-testing.md` | draft | 185 | Pre-taxonomy; outside `guides/` path |
| `swift/testing/dependency-injection-testing.md` | draft | 122 | Pre-taxonomy; outside `guides/` path |
| `swift/testing/swift-testing.md` | draft | 125 | Pre-taxonomy; outside `guides/` path |
| `swift/testing/test-boundaries.md` | draft | 74 | Pre-taxonomy; outside `guides/` path |

### TypeScript

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `typescript/guides/api/rest-express.md` | draft | 1072 | Pre-taxonomy; exceeds 500-line limit |
| `typescript/guides/best-practices/typescript-best-practices.md` | draft | 1196 | Pre-taxonomy; exceeds 500-line limit |
| `typescript/guides/setup/project-setup.md` | draft | 604 | Pre-taxonomy; exceeds 500-line limit |
| `typescript/guides/setup/starter-tsconfig-notes.md` | draft | 394 | Pre-taxonomy |
| `typescript/guides/testing/folder-structure.md` | draft | 451 | Pre-taxonomy |
| `typescript/guides/testing/testing-guide.md` | draft | 1162 | Pre-taxonomy; exceeds 500-line limit |

### Kotlin

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist |

### SQL

| File | Status | Notes |
|------|--------|-------|
| *(no guides)* | absent | No implementation guides exist |

---

## AGENTS.md Navigation Files

| File | Lines | Status | Notes |
|------|-------|--------|-------|
| `standards/AGENTS.md` | 174 | complete | Exceeds 100-line limit; refactor needed |
| `standards/testing/AGENTS.md` | 545 | complete | Exceeds 100-line limit; refactor needed |
| `standards/extension-development/AGENTS.md` | 113 | complete | Exceeds 100-line limit; refactor needed |
| `languages/AGENTS.md` | 48 | complete | |
| `languages/go/AGENTS.md` | 118 | complete | Exceeds 100-line limit; refactor needed |
| `languages/java/AGENTS.md` | 504 | complete | Exceeds 100-line limit; refactor needed |
| `languages/kotlin/AGENTS.md` | 4 | stub | Placeholder only |
| `languages/objective-c/AGENTS.md` | 33 | complete | |
| `languages/python/AGENTS.md` | 471 | complete | Exceeds 100-line limit; refactor needed |
| `languages/sql/AGENTS.md` | 4 | stub | Placeholder only |
| `languages/swift/AGENTS.md` | 36 | complete | |
| `languages/typescript/AGENTS.md` | 675 | complete | Exceeds 100-line limit; refactor needed |

---

## Summary

| Category | Complete | Draft | Stub | Absent |
|----------|---------|-------|------|--------|
| Standards | 1 | 22 | 2 | 4 |
| Enforcement policies | 1 | 0 | 0 | — |
| Language guides | 0 | 24 | 7 | 2 languages with no guides |
| AGENTS.md | 8 | — | 2 | — |

**Changes since 2026-03-07 scan:**
- `storage/connection-pooling.md` — **new**: complete standard; all required sections present (Overview, Scope, Rules, Compliance Checklist, Examples, Related)
- `api/rest-example.md` — **new**: companion quick-reference for rest.md; classified draft (not a standalone standard)
- `api/rest.policy.md` — **new**: complete enforcement policy for the REST API standard (48 rules)
- `standards/AGENTS.md` line count updated: 166 → 174
- `languages/AGENTS.md` line count updated: 47 → 48
- `languages/java/AGENTS.md` line count updated: 503 → 504
- Swift implementation guides discovered in `swift/architecture/` and `swift/testing/` — 6 draft files outside `guides/` path convention

**Highest-priority gaps** (no content, blocked by program requirements):
1. `standards/security/overview.md` — absent; blocks `forge:review-security`
2. `standards/observability/logging.md` — absent; blocks observability review
3. `standards/deployment/ci-cd.md` — absent; blocks CI/CD review
4. `languages/kotlin/` — no guides; Kotlin code cannot be reviewed to standard
5. `languages/sql/` — no guides; SQL/migration code cannot be reviewed to standard
6. `java/guides/observability/logging-slf4j.md` — absent; Java observability review incomplete

**Structural issues** (taxonomy conformance):
- Swift implementation guides under `swift/architecture/` and `swift/testing/` do not follow the `languages/<lang>/guides/<area>/` path convention; they should be migrated to `languages/swift/guides/` to be within scope for `forge:review`
- 9 AGENTS.md files exceed the 100-line limit and need refactoring
- Multiple language guides exceed the 500-line per-file limit; candidates for splitting
