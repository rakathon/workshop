# Standards Library Coverage Map

Last reviewed: 2026-03-08 | Reviewed by: manual scan (without_skill run)

**Status definitions** (see `standards/TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is a zero-byte/title-only file
- **major-stale** — (language guides only) guide's declared standard version is behind by a MAJOR bump

> **Note:** Files authored before the taxonomy was defined (pre-2026) contain substantive
> content but use legacy heading structures rather than the required Overview / Scope / Rules /
> Compliance Checklist / Examples / Related taxonomy. These are marked **draft** — content is
> valuable but does not conform to the current template. Migration is tracked as a follow-on
> story.

> **Scope:** This scan covers `standards/` and `languages/` at the repository root. The `forge/`
> plugin directory contains only `.gitkeep` placeholder files under `forge/standards/` and
> `forge/languages/`; no content exists there to scan.

---

## Standards (`standards/`)

Required sections for a language-agnostic standard: Overview · Scope · Rules · Compliance
Checklist · Examples · Related

### API

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `api/rest.md` | draft | 941 | Pre-taxonomy; has Overview only; no Scope/Rules/Checklist; exceeds 300-line limit |
| `api/rest.policy.md` | complete | 59 | Enforcement policy; all 3 required sections present |
| `api/secure-server-to-server-comm.md` | draft | 96 | Pre-taxonomy; Overview + Related Standards only |
| `api/rest-example.md` | draft | — | Example/companion file; not a standalone standard |

Missing AGENTS.md for `standards/api/` (3 content files → required).

### Deployment

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `deployment/ci-cd.md` | absent | 0 | Empty file (0 bytes) |

Missing AGENTS.md for `standards/deployment/` (1 file → not yet required, but gap is the content itself).

### Extension Development

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `extension-development/architecture.md` | draft | 615 | Pre-taxonomy; Overview + Related Standards; exceeds 300-line limit |
| `extension-development/code-organization.md` | draft | 283 | Pre-taxonomy; Overview + Examples + Related Standards |
| `extension-development/cross-browser.md` | draft | 326 | Pre-taxonomy; Overview + Examples + Related Standards |
| `extension-development/messaging.md` | draft | 307 | Pre-taxonomy; Overview + Examples + Related Standards |
| `extension-development/performance.md` | draft | 330 | Pre-taxonomy; Overview + Examples + Related Standards |
| `extension-development/security.md` | draft | 318 | Pre-taxonomy; Overview + Examples + Related Standards |
| `extension-development/testing.md` | draft | 405 | Pre-taxonomy; Overview + Examples + Related Standards |

AGENTS.md present (82 lines — within 100-line limit).

### Messaging

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `messaging/api-initiated-message.md` | draft | 554 | Pre-taxonomy; Overview only; exceeds 300-line limit |
| `messaging/event-driven-architectures.md` | draft | 400 | Pre-taxonomy; Overview + Related Standards; exceeds 300-line limit |
| `messaging/kafka/message-contracts.md` | draft | 234 | Pre-taxonomy; Overview + Related Standards |
| `messaging/message-contracts.md` | draft | 117 | Pre-taxonomy; Overview only |
| `messaging/message-standards.md` | draft | 291 | Pre-taxonomy; Overview + Related Standards |
| `messaging/messaging.md` | stub | 23 | Near-empty TOC/index only |
| `messaging/user-initiated-message.md` | draft | 288 | Pre-taxonomy; Overview only |
| `messaging/versioning.md` | draft | 231 | Pre-taxonomy; Overview + Related Standards |

Missing AGENTS.md for `standards/messaging/` (8 content files → required).

### Observability

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `observability/logging.md` | absent | 0 | Empty file (0 bytes) |
| `observability/overview.md` | absent | 0 | Empty file (0 bytes) |

Missing AGENTS.md for `standards/observability/` (2 files → required once content exists).

### Security

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `security/overview.md` | absent | 0 | Empty file (0 bytes); blocks `forge:review-security` |

### Storage

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `storage/connection-pooling.md` | complete | 80 | All 6 required taxonomy sections present |
| `storage/dynamodb.md` | draft | 502 | Pre-taxonomy; Overview only; exceeds 300-line limit |
| `storage/extension-storage.md` | draft | 444 | Pre-taxonomy; Overview + Related Standards; exceeds 300-line limit |
| `storage/postgresql.md` | stub | 1 | H1 title only |

Missing AGENTS.md for `standards/storage/` (4 content files → required).

### Testing

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `testing/e2e-testing.md` | draft | 399 | Pre-taxonomy; Overview only; exceeds 300-line limit |
| `testing/integration-testing.md` | draft | 627 | Pre-taxonomy; Overview only; exceeds 300-line limit |
| `testing/strategy.md` | draft | 180 | Pre-taxonomy; Overview only |
| `testing/unit-testing.md` | draft | 438 | Pre-taxonomy; Overview only; exceeds 300-line limit |

AGENTS.md present (446 lines — **exceeds** 100-line limit; refactor needed).

---

## Language Guides (`languages/`)

Required sections for a language guide: Overview · Related standard · Prerequisites ·
Implementation · Verification

Style-reference files (Swift `style-guide/`, Objective-C `style-guide/`) are excluded from
this table — they predate the taxonomy and are not implementation guides.

### Go

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `go/guides/api/rest-echo.md` | stub | 7 | Framework reference list only; no guide sections |
| `go/guides/deployment/build.md` | stub | 18 | Build notes only; no required sections |
| `go/guides/deployment/containerization.md` | stub | 32 | Dockerfile snippet only; no required sections |
| `go/guides/messaging/datacontract-setup-process.md` | draft | 818 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `go/guides/observability/logging.md` | draft | 263 | Pre-taxonomy; Overview only |
| `go/guides/storage/database-ent.md` | stub | 6 | Framework reference list only |
| `go/guides/testing/folder-structure.md` | draft | 454 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `go/guides/testing/testing.md` | stub | 32 | Notes only; no required language guide sections |

AGENTS.md present (94 lines — within 100-line limit).

### Java

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `java/guides/api/rest-spring.md` | draft | 1491 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `java/guides/messaging/create-register-pojo.md` | draft | 372 | Pre-taxonomy; Overview only |
| `java/guides/messaging/datacontract-setup-process.md` | draft | 427 | Pre-taxonomy; Overview only |
| `java/guides/observability/logging-slf4j.md` | absent | 0 | Empty file (0 bytes) |
| `java/guides/testing/e2e-test-examples.md` | draft | 451 | Pre-taxonomy; Overview only |
| `java/guides/testing/folder-structure.md` | draft | 568 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `java/guides/testing/testing.md` | draft | 1180 | Pre-taxonomy; Overview only; exceeds 500-line limit |

AGENTS.md present (418 lines — **exceeds** 100-line limit; refactor needed).

### Kotlin

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides)* | absent | No guides exist under `languages/kotlin/guides/` |

AGENTS.md present (3 lines — stub/placeholder only).

### Python

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `python/guides/data-science/data-science.md` | draft | 544 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `python/guides/documentation/documentation.md` | draft | 522 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `python/guides/observability/logging.md` | draft | 558 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `python/guides/testing/folder-structure.md` | draft | 222 | Pre-taxonomy; Overview only |
| `python/guides/testing/testing.md` | draft | 624 | Pre-taxonomy; Overview only; exceeds 500-line limit |

AGENTS.md present (358 lines — **exceeds** 100-line limit; refactor needed).

### SQL

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides)* | absent | No guides exist under `languages/sql/guides/` |

AGENTS.md present (3 lines — stub/placeholder only).

### Swift

| File | Status | Notes |
|------|--------|-------|
| *(no implementation guides in `guides/`)* | absent | Style-guide and architecture files exist but are pre-taxonomy; no implementation guides |

AGENTS.md present (25 lines — within 100-line limit).

### TypeScript

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `typescript/guides/api/rest-express.md` | draft | 834 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `typescript/guides/best-practices/typescript-best-practices.md` | draft | 948 | Pre-taxonomy; Overview only; exceeds 500-line limit |
| `typescript/guides/setup/project-setup.md` | draft | 477 | Pre-taxonomy; Overview only |
| `typescript/guides/setup/starter-tsconfig-notes.md` | draft | 288 | Pre-taxonomy; tsconfig annotation notes; Overview only |
| `typescript/guides/testing/folder-structure.md` | draft | 364 | Pre-taxonomy; Overview only |
| `typescript/guides/testing/testing-guide.md` | draft | 910 | Pre-taxonomy; no taxonomy sections detected; exceeds 500-line limit |

AGENTS.md present (551 lines — **exceeds** 100-line limit; refactor needed).

### Objective-C

Style-reference files only; excluded from evaluation per taxonomy rules.
AGENTS.md present (22 lines — within 100-line limit).

---

## AGENTS.md Navigation Files

| File | Lines | Status | Notes |
|------|-------|--------|-------|
| `standards/AGENTS.md` | 125 | complete | **Exceeds** 100-line limit; refactor needed |
| `standards/testing/AGENTS.md` | 446 | complete | **Exceeds** 100-line limit; refactor needed |
| `standards/extension-development/AGENTS.md` | 82 | complete | Within limit |
| `languages/AGENTS.md` | 28 | complete | Within limit |
| `languages/go/AGENTS.md` | 94 | complete | Within limit |
| `languages/java/AGENTS.md` | 418 | complete | **Exceeds** 100-line limit; refactor needed |
| `languages/kotlin/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/objective-c/AGENTS.md` | 22 | complete | Within limit |
| `languages/python/AGENTS.md` | 358 | complete | **Exceeds** 100-line limit; refactor needed |
| `languages/sql/AGENTS.md` | 3 | stub | Placeholder only |
| `languages/swift/AGENTS.md` | 25 | complete | Within limit |
| `languages/typescript/AGENTS.md` | 551 | complete | **Exceeds** 100-line limit; refactor needed |

**Missing AGENTS.md files** (directories with 2+ content files that lack one):
- `standards/api/` — 3 content files, no AGENTS.md
- `standards/messaging/` — 8 content files, no AGENTS.md
- `standards/observability/` — 2 files (both absent/empty), no AGENTS.md
- `standards/storage/` — 4 content files, no AGENTS.md

---

## Summary

| Category | Complete | Draft | Stub | Absent |
|----------|---------|-------|------|--------|
| Standards (content files) | 1 | 22 | 2 | 4 |
| Enforcement policies | 1 | 0 | 0 | 0 |
| Language guides | 0 | 20 | 7 | 3 languages with no guides |
| AGENTS.md files | 9 | — | 2 | 4 missing entirely |

**Newly complete since last scan:**
- `standards/storage/connection-pooling.md` — now has all 6 required taxonomy sections (was draft)
- `standards/api/rest.policy.md` — enforcement policy; all 3 required sections present

**Highest-priority gaps** (no content, blocking skill operations):
1. `standards/security/overview.md` — absent; blocks `forge:review-security`
2. `standards/observability/logging.md` — absent; blocks observability review
3. `standards/observability/overview.md` — absent; blocks observability review
4. `standards/deployment/ci-cd.md` — absent; blocks CI/CD review
5. `languages/java/guides/observability/logging-slf4j.md` — absent; Java observability gap
6. `languages/kotlin/` — no guides; Kotlin code cannot be reviewed to standard
7. `languages/sql/` — no guides; SQL/migration code cannot be reviewed to standard

**Size-limit violations** (files that exceed taxonomy maximums):
- Standards (limit 300 lines): `api/rest.md` (941), `messaging/api-initiated-message.md` (554), `messaging/event-driven-architectures.md` (400), `storage/dynamodb.md` (502), `storage/extension-storage.md` (444), `testing/integration-testing.md` (627), `testing/unit-testing.md` (438), `testing/e2e-testing.md` (399), `extension-development/architecture.md` (615)
- Language guides (limit 500 lines): `go/guides/messaging/datacontract-setup-process.md` (818), `go/guides/testing/folder-structure.md` (454 — near limit), `java/guides/api/rest-spring.md` (1491), `java/guides/testing/folder-structure.md` (568), `java/guides/testing/testing.md` (1180), `python/guides/data-science/data-science.md` (544), `python/guides/documentation/documentation.md` (522), `python/guides/observability/logging.md` (558), `python/guides/testing/testing.md` (624), `typescript/guides/api/rest-express.md` (834), `typescript/guides/best-practices/typescript-best-practices.md` (948), `typescript/guides/testing/testing-guide.md` (910)
- AGENTS.md (limit 100 lines): `standards/AGENTS.md` (125), `standards/testing/AGENTS.md` (446), `languages/java/AGENTS.md` (418), `languages/python/AGENTS.md` (358), `languages/typescript/AGENTS.md` (551)

**Missing AGENTS.md** (directories with 2+ content files):
- `standards/api/` (3 files)
- `standards/messaging/` (8 files)
- `standards/storage/` (4 files)
- `standards/observability/` (2 files — though content is absent, should be added when content lands)
