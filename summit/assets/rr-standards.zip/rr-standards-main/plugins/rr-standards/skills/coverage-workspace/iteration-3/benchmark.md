# Skill Benchmark: rr-standards:coverage

**Model**: <model-name>
**Date**: 2026-03-08T23:15:54Z
**Evals**: 0, 1, 2 (3 runs each per configuration)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 100% ± 0% | 8% ± 14% | +0.92 |
| Time | 104.4s ± 29.4s | 235.7s ± 94.2s | -131.3s |
| Tokens | 27902 ± 2666 | 56228 ± 18973 | -28326 |