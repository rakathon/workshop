# rr-standards:review

PR gate review skill. Reviews all standards artifact changes in a PR diff and produces a
structured verdict — per artifact and overall.

---

## Purpose

When a PR touches a standards artifact (a standard, enforcement policy, language guide,
or AGENTS.md), `rr-standards:review` runs the following checks on every changed artifact:

- **Quality checklist** — required sections present, rule identifiers correct, links valid
- **Version bump** — semver increment matches the change type (MAJOR/MINOR/PATCH)
- **Policy consistency** — every rule in the standard has a corresponding policy row, and
  no policy row references a removed rule
- **Guide staleness** — language guides that implement this standard are surfaced as
  minor-stale (informational) or major-stale (blocking, if the guide is the changed artifact)
- **Version removal attestation** — if any versioned API path is removed in the diff,
  verifies that the PR body contains a completed sunset attestation checklist before
  the gate can pass (see [API Version Removal](#api-version-removal) below)

PRs that touch only non-artifact files that are not security-scanned (docs, `.forge/`
config) pass automatically — the skill emits a single note and exits 0. Note: template
files (`plugins/rr-standards/templates/*.md`) are security-reviewed for prompt injection
even though they are not standards artifacts, and hook scripts (`.claude/hooks/*.sh`) are
reviewed for exfiltration and obfuscated execution.

---

## Usage

```
/rr-standards:review [--base <branch>] [--pr <number>] [--ci]
```

### Flags

| Flag | Description |
|------|-------------|
| `--base <branch>` | Diff base branch. Defaults to `origin/HEAD` (auto-detected). |
| `--pr <number>` | Review an existing GitHub PR by number (uses `gh pr diff`). |
| `--ci` | Emit machine-readable JSON to stdout; exit 0 on pass or fail (verdict is in the JSON); exit 1 only on system errors. |

`--base` and `--pr` are mutually exclusive. In CI, always pass `--base` explicitly.

---

## Interactive Mode

Running without `--ci` produces a human-readable report in the terminal:

```
## rr-standards:review — main...HEAD

Changed standards artifacts: 2

---

### standards/api/rest.md (Language-Agnostic Standard)

**Change type:** MAJOR — R-12 was removed from the Rules section
**Version bump:** FAIL — version unchanged at 1.3.0; a MAJOR bump is required

#### Quality checklist
✓ Pass

#### Version bump
- [blocking] Version unchanged at 1.3.0; a MAJOR bump is required.
  Evidence: `Version: 1.3.0` in both base and HEAD; R-12 removed from Rules.
  Fix: Increment to 2.0.0 and update the enforcement policy to remove the R-12 row.

#### Policy consistency
- [blocking] Rule R-12 row exists in standards/api/rest.policy.md but R-12 was removed
  from the standard.
  Evidence: policy table row `| R-12 | blocking | ... |` has no matching rule.
  Fix: Remove the R-12 row from the policy, or restore R-12 to the standard.

#### Guide staleness
- [informational] languages/go/guides/api/rest.md is major-stale (declared @1.1.0,
  standard now @2.0.0 after this bump). Guide owners should update before relying on it.

#### Version removal attestation
— Skipped (no versioned path removals detected)

**Artifact verdict: FAIL (2 blocking)**

---

## Overall verdict: FAIL ✗ (2 blocking findings across 1 artifact)
```

---

## CI Mode (`--ci`)

Emits a single JSON record to stdout conforming to the shared review output schema
(`.forge/efforts/forge-plugin/spec/review-output-schema.md`). Exit code 0 for pass or
fail verdicts — the verdict is communicated in the JSON. Exit code 1 only on system
errors (e.g., TAXONOMY.md unreadable, all agents errored).

### GitHub Actions setup

```yaml
# .github/workflows/rr-standards-review.yml
name: rr-standards review

on:
  pull_request:
    branches: [main]

jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0        # full history needed for git diff

      - name: Install Claude Code
        run: npm install -g @anthropic-ai/claude-code

      - name: Run rr-standards review
        run: |
          claude -p "/rr-standards:review --base ${{ github.base_ref }} --ci" \
            > review-output.json
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}

      - name: Upload review artifact
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: rr-standards-review
          path: review-output.json
```

The review output JSON can be forwarded to a metrics pipeline, stored as a build
artifact, or parsed by a downstream step to post inline PR comments.

---

## How Verdicts Work

The overall verdict is FAIL if any changed artifact has a blocking finding. Individual
artifact verdicts are independent — a PR with two changed artifacts can have one PASS
and one FAIL.

**Human approval is always a valid merge path.** The review skill is a signal, not a
veto. A branch protection rule can require the status check, but a project maintainer
can always approve and merge manually if they accept the risk.

---

## API Version Removal

Removing a versioned API path (e.g. `/store/v1`) is a production-safety gate that
cannot be verified from code alone. When the diff contains a removed versioned path,
the skill detects it and checks the PR body for a completed sunset attestation.

**What the author must do:**

Copy the contents of [`plugins/rr-standards/templates/sunset-attestation.md`](../../../plugins/rr-standards/templates/sunset-attestation.md)
into the PR description and check each item once the condition is confirmed:

```markdown
## API Version Removal

- [x] `Deprecation`, `Sunset`, and `Link` response headers were present in all responses
      for the removed version throughout the sunset period
- [x] Usage was monitored by version and by client; no active traffic above the agreed
      threshold remains on the removed version
- [x] All affected clients were identified, notified, and confirmed a migration timeline
- [x] Traffic to the removed version fell below the agreed threshold before this PR was opened

**Removed version(s):** /store/v1
**Sunset period end date:** 2026-01-15
**Evidence / approval link:** https://github.com/org/repo/issues/42
```

Each unchecked box (`- [ ]`) is a **blocking** finding. The three metadata fields
(`Removed version(s)`, `Sunset period end date`, `Evidence / approval link`) must be
filled in — placeholder HTML comments produce informational findings.

**What the reviewer must verify manually:**

The automated check confirms the checklist is present and complete, but cannot validate
the underlying facts — that traffic really did fall below threshold, that clients really
were notified. A human reviewer must assess the evidence link before approving.

---

## Confidence Suppression

Each sub-agent (artifact-reviewer, security-reviewer, hook-reviewer) assigns a
confidence score 0–100 to its own findings. Agents score their own findings because
they have full artifact context and are best positioned to judge reliability.

Findings below the confidence threshold (default: 80) are suppressed — excluded from
verdict counts and the interactive display, but retained in the JSON output so
suppression rates can be monitored.

This means a PR can pass even if there are low-confidence findings that look structurally
similar to blocking ones. Confidence scoring is independent of severity.

---

## Related

- [`rr-standards:validate`](../validate/README.md) — single-file quality check
- [`rr-standards:author`](../author/README.md) — interactive artifact authoring
- [`rr-standards:coverage`](../coverage/README.md) — library-wide coverage map
- [Review output schema](../../../../.forge/efforts/forge-plugin/spec/review-output-schema.md)
- [TAXONOMY.md](../../../plugins/forge/standards/TAXONOMY.md)
