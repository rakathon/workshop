---
name: example:skill
description: >
  An example skill used to test the G-1 README.md presence check. When paired with
  readme_exists: false in the artifact context, this fixture should trigger a blocking
  finding from Check G sub-check G-1.
  Invoke as: /example:skill [--option]
---

# example:skill

Worker skill — non-interactive. This fixture has valid frontmatter but is used in
eval contexts where readme_exists is set to false.

---

## Step 1 — Execute Task

Perform the core task.
