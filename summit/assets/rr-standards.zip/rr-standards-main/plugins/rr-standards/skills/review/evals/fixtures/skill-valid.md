---
name: example:skill
description: >
  An example skill that demonstrates correct frontmatter structure. Use this skill
  when testing structural validation, verifying that the artifact-reviewer correctly
  passes a well-formed skill definition, or when a baseline valid fixture is needed.
  Invoke as: /example:skill [--option]
---

# example:skill

Worker skill — non-interactive. Performs a sample task and returns a structured result.

---

## Input

Parse from the invocation:
- `--option` — optional flag that modifies behavior

---

## Step 1 — Validate Input

Check that required inputs are present. If missing, emit a usage error and exit 1.

---

## Step 2 — Execute Task

Perform the core task. Return the result as a structured JSON object.
