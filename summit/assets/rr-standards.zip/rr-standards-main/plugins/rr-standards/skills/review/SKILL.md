---
name: rr-standards:review
description: >
  PR gate review skill for rr-standards artifacts. Parses the diff between a base branch
  and HEAD, classifies changed files using TAXONOMY.md, and runs a full review pipeline on
  every changed standards artifact: structural validation (rr-standards:validate --ci),
  behavioral effectiveness testing (rr-standards:test --ci), artifact quality checks
  (version bump, policy consistency, guide staleness), and security review. Runs all checks
  in parallel and produces a per-artifact and overall APPROVE/DENY verdict. Use this skill
  when: a PR is opened that may touch standards artifacts or skill definitions; a standards
  author wants a pre-merge quality check; a CI pipeline runs the review gate; someone asks
  whether a PR is ready to merge given the standards it touches.
  Invoke as: /rr-standards:review [--base <branch>] [--pr <number>] [--ci] [--skip-test]
disable-model-invocation: true
---

# rr-standards:review

Worker skill — non-interactive. Reviews all standards artifact changes in a PR diff and
produces a structured verdict conforming to the shared review output schema.

Internal agents are defined in:
- `references/artifact-reviewer.md` — one agent per changed standards artifact or skill-definition (parallel)
- `references/skill-reviewer.md` — Check G sub-checks (G-1 through G-8); read by artifact-reviewer when `artifact_type == skill-definition`
- `references/ci-output-schema.md` — CI JSON field mapping; read during Step 5 when assembling `--ci` output
- `references/security-reviewer.md` — one agent per changed prompt-injection-target artifact (standards, SKILL.md, references/*.md, templates) (parallel)
- `references/hook-reviewer.md` — one agent per changed hook script (parallel)
- `rr-standards:validate --ci` — one agent per changed standards artifact (structural quality gate)
- `rr-standards:test --ci` — one agent per changed standard/language-guide with a `.test.yaml` (behavioral effectiveness gate)

Each sub-agent self-assigns confidence scores for its own findings — agents have full
artifact context and are best positioned to score their own findings.

---

## Input

Parse from the invocation:
- `--base <branch>` — diff base branch (optional; auto-detected when omitted via
  `git symbolic-ref refs/remotes/origin/HEAD`; always passed explicitly by CI)
- `--pr <number>` — review an existing PR by number using `gh pr diff` instead of
  computing the diff locally (optional; mutually exclusive with `--base`)
- `--ci` — emit machine-readable JSON to stdout conforming to the review output schema
  (optional; omit for interactive terminal output)
- `--skip-test` — skip behavioral effectiveness testing (`rr-standards:test`); useful
  for fast CI runs where test execution time is prohibitive. Structural validation
  (`rr-standards:validate`) always runs regardless of this flag.

---

## Step 1 — Compute the Diff

If both `--pr` and `--base` are supplied, emit a usage error and exit 1:
```
ERROR: --pr and --base are mutually exclusive. Use one or the other.
```

**If `--pr <number>` was supplied:**
```
gh pr diff <number>
```

**Otherwise:**
1. Resolve `--base` if not supplied:
   ```
   git symbolic-ref refs/remotes/origin/HEAD
   ```
   Extract the branch name (strip `refs/remotes/origin/` prefix). If the command fails,
   default to `main` and note the fallback in the output header.
2. Compute the diff:
   ```
   git diff <base>...HEAD --name-only
   git diff <base>...HEAD
   ```
   The three-dot form (`<base>...HEAD`) captures only changes introduced by the current
   branch since it diverged from base — not unrelated changes on base that happened later.

If the diff cannot be computed (e.g., unrecognised base, detached HEAD, git error):
- Interactive: emit `ERROR: Cannot compute diff — <reason>. Check --base is a valid branch.`
- CI: emit an error record with `verdict.result: "error"`, `error.code: "invalid-input"`,
  then exit 1.

---

## Step 2 — Classify Changed Files

Load `plugins/forge/standards/TAXONOMY.md § Artifact Type Identification`. Apply the ordered rules
exactly as written there. Do not paraphrase; load at review time so the skill stays
correct as the taxonomy evolves.

For each file in the diff:
- Apply the type detection rules in order; record the first matching type.
- **Special cases** (apply before taxonomy rules, in this order):
  - `plugins/**/skills/**/SKILL.md` → `skill-definition`
  - `plugins/**/skills/**/references/*.md` → `agent-reference`
  - `plugins/rr-standards/templates/*.md` → `template` (security-reviewer only)
  - `.claude/hooks/*.sh` → `hook-script` (hook-reviewer only)
- If no special-case or taxonomy rule matches: skip the file silently.

If TAXONOMY.md cannot be loaded:
- CI: emit error record with `error.code: "invalid-input"`, exit 1.
- Interactive: emit `ERROR: Cannot load plugins/forge/standards/TAXONOMY.md — review cannot proceed.`

**If no files classified:**
- Interactive: emit a single note and exit 0:
  ```
  No skill definitions or standards artifacts changed in this diff. PR gate: SKIPPED (no artifact checks required).
  ```
- CI: emit `{"verdict":{"result":"skipped","blocking_count":0,"advisory_count":0,"informational_count":0,"failed_gates":[]}}` and exit 0. Do not populate `pr_review_report`. The workflow treats `"skipped"` as an auto-pass with no review comment.

---

## Step 3 — Gather Context for Each Artifact

For each changed standards artifact or skill-definition, collect inputs for the agents:

**For standards artifacts only** (types: standard, language-guide, enforcement-policy,
AGENTS.md), additionally collect:

1. **File content at base** — `git show <base>:<file-path>` (empty string if file is new).
   If the file was **deleted** in this PR (present in base, absent in HEAD): mark as
   `deleted: true`, skip all review agents for this artifact (artifact-reviewer,
   security-reviewer, validate-agent, test-agent), and surface a single informational note
   in the report: "This artifact was deleted in this PR." No security review is needed
   for deletions — removed content is no longer injected into agent context.
2. **File content at HEAD** — read the current working tree file
3. **Diff slice for this artifact** — extract the relevant `diff --git a/<path>` block
   from the full diff
4. **Detected artifact type** — from Step 2
5. **Companion policy file path** (standards only):
   - Derive: replace `.md` with `.policy.md` in the file path
   - Note whether the file exists in HEAD (pass this boolean to the agent)
6. **Language guide paths** (standards only):
   - Search `languages/` recursively for `.md` files containing
     `Implements: <this-standard-path>` (any version)
   - Collect the list of matching paths (may be empty)
7. **Test file presence** (standard and language-guide only):
   - Derive: replace `.md` with `.test.yaml` in the file path
   - Note whether the file exists in HEAD (`test_file_exists: true/false`)
   - Pass this boolean to the test-agent decision in Step 4

**Version removal detection** (all enforcement-policy artifacts):

Scan the full diff for removed versioned path prefixes — lines matching the pattern
`-\s+/\S+/v\d+` or `path: /\S+/v\d+` that appear only in the `-` (removed) side of the
diff. If any are found:

- Set `version_removal_detected: true`
- Collect `removed_versions: [<list of path prefixes removed>]`
- Fetch the PR body:
  - If `--pr <number>` was supplied: `gh pr view <number> --json body -q .body`
  - Otherwise: `gh pr view --json body -q .body` (uses current branch's open PR)
  - If no open PR is found or the command fails, set `pr_body: null` and note in the
    report that attestation could not be verified
- Pass `version_removal_detected`, `removed_versions`, and `pr_body` to each
  enforcement-policy artifact-reviewer agent for this artifact

**For skill-definition artifacts, additionally collect:**

1. **`readme_exists`** — check whether `README.md` exists as a sibling of the changed
   SKILL.md in HEAD (same directory, not a subdirectory).
   Set `readme_exists: true` if it exists in HEAD, `false` otherwise.

2. **`skill_line_count`** — count the total number of lines in `head_content`.
   Pass this integer to the artifact-reviewer.

3. **`references_dir_exists`** — check whether a `references/` subdirectory exists in
   the skill directory (the parent directory of the changed SKILL.md) in HEAD.
   Set `references_dir_exists: true` if it exists, `false` otherwise.

4. **`integration_test_exists`** — check whether any file matching the pattern
   `tests/claude-code/test-<skill-name>*.sh` exists in HEAD, where `<skill-name>` is the
   directory name of the skill (e.g. for `plugins/forge/skills/init/SKILL.md`, search for
   `tests/claude-code/test-init*.sh`).
   Set `integration_test_exists: true` if any match exists, `false` otherwise.

5. **`test_yaml_exists`** — check whether a `test.yaml` file exists as a sibling of the
   changed SKILL.md in HEAD (same directory). This is the forge-plugin test convention.
   Set `test_yaml_exists: true` if it exists, `false` otherwise.

6. **`nested_skill_paths`** — scan the skill directory tree in HEAD for any `SKILL.md`
   files that are NOT the root `SKILL.md` itself (i.e. any `SKILL.md` found at depth > 1
   relative to the skill directory). Return the list of repo-relative paths found.
   Set to `[]` if none exist.

7. **`unexpected_subdirs`** — list any immediate subdirectory names in the skill directory
   (in HEAD) that are not in the allowed set: `references`, `fixtures`, `evals`, `scripts`,
   `common`. Ignore hidden directories (names starting with `.`).
   Set to `[]` if all subdirectories are from the allowed set.

---

## Step 4 — Spawn All Review Agents (Parallel)

Read `references/artifact-reviewer.md`, `references/security-reviewer.md`,
`references/hook-reviewer.md`, and `references/skill-reviewer.md` for the complete
instructions for each agent type. (`references/skill-reviewer.md` contains the Check G
sub-checks G-1 through G-8; it is read by the artifact-reviewer internally for each
skill-definition artifact — you do not need to pass it as a separate agent prompt.)

**Spawn all agents in a single batch so they run in parallel** — including the
validate-agents and test-agents described below:

**Artifact-reviewer agents** (standard, language-guide, enforcement-policy, AGENTS.md,
skill-definition):

> **Note:** `agent-reference` and `template` artifacts do NOT get an artifact-reviewer.
> They receive only a security-reviewer agent (see Security-reviewer agents below).
```
Instructions: <full contents of references/artifact-reviewer.md>

Artifact context:
- file_path: <repo-relative path>
- artifact_type: <type from Step 2>
- base_content: <file content at base, or empty string if new file>
- head_content: <file content at HEAD>
- diff_slice: <diff block for this file only>
- policy_file_path: <path> (present: true/false)
- guide_paths: [<list of language guide paths declaring Implements: for this standard>]
- version_removal_detected: <true/false — from Step 3 version removal detection>
- removed_versions: [<list of removed path prefixes — from Step 3>]
- pr_body: <PR body string or null — from Step 3>
# Populated only for skill-definition artifacts (false/0 for all other artifact types):
- readme_exists: <true/false — from Step 3>
- skill_line_count: <integer — from Step 3>
- references_dir_exists: <true/false — from Step 3>
- integration_test_exists: <true/false — from Step 3>
- test_yaml_exists: <true/false — from Step 3>
- nested_skill_paths: <list of repo-relative paths — from Step 3>
- unexpected_subdirs: <list of directory names — from Step 3>
```

**Security-reviewer agents** (standard, language-guide, enforcement-policy, AGENTS.md,
skill-definition, agent-reference, template):
```
Instructions: <full contents of references/security-reviewer.md>

Artifact context:
- file_path: <repo-relative path>
- artifact_type: <type from Step 2>
- head_content: <file content at HEAD>
- diff_slice: <diff block for this file only>
```

**Hook-reviewer agents** (hook-script type only):
```
Instructions: <full contents of references/hook-reviewer.md>

Artifact context:
- file_path: <repo-relative path>
- head_content: <file content at HEAD>
- diff_slice: <diff block for this file only>
```

**Validate-agents** (all standards artifact types: standard, language-guide,
enforcement-policy, AGENTS.md):

One agent per changed standards artifact. Invoke the `rr-standards:validate` skill in
CI mode. Pass the token `[from: rr-standards:review]` so the skill knows it is being
called programmatically.

```
Task: /rr-standards:validate <artifact-path> --ci [from: rr-standards:review]
```

The agent returns the validate CI JSON (see `rr-standards:validate` § CI mode).
A `verdict.result: "fail"` means the artifact has blocking structural findings — this
blocks the PR verdict in Step 5.

**Test-agents** (standard and language-guide only; omit if `--skip-test` was passed):

One agent per changed standard or language-guide. Decision logic:

- If `test_file_exists: true` (from Step 3): invoke `rr-standards:test --ci <path>`
  and collect the test CI JSON. A `verdict.result: "fail"` means test-accuracy FAIL and
  blocks the PR verdict.
- If `test_file_exists: false`: record a **skipped** result for this artifact —
  behavioral testing cannot run without a `.test.yaml`. Surface as informational:
  "No `.test.yaml` found — run `/rr-standards:test <path>` to generate one and
  establish a behavioral baseline."

```
Task: /rr-standards:test <artifact-path> --ci [from: rr-standards:review]
```

---

Wait for all agents to complete. Collect from each:
- `findings[]` — all findings across all checks, with `confidence` already set by the agent
- `checks[]` — one record per check_id (pass/fail/skipped)
- `per_artifact_verdict` (artifact-reviewer) or `per_artifact_security_verdict` (security/hook-reviewer)
- `validate_result` — the full CI JSON from the validate-agent for this artifact
- `test_result` — the full CI JSON from the test-agent (or `{"skipped": true}` if no test file)
- Any error that stopped the agent early

**Namespace finding IDs before merging.** Each agent returns locally-scoped IDs like
`f-001`. Before adding any agent's findings to the global list, prefix every finding ID
with a stable per-artifact + per-agent-type token to ensure global uniqueness:
- Artifact-reviewer: `ar-<artifact-slug>-<id>` (e.g., `ar-a3f2-f-001`)
- Security-reviewer: `sec-<artifact-slug>-<id>` (e.g., `sec-a3f2-f-001`)
- Hook-reviewer: `hook-<artifact-slug>-<id>` (e.g., `hook-7c91-f-001`)

The artifact slug is a **4-character lowercase hex prefix of the SHA-1 hash of the
repo-relative file path** (e.g., the first 4 hex chars of `sha1("standards/api/contracts.md")`).
Do not use the file stem alone — different files named `contracts.md` in different
directories would produce the same slug. Apply the same prefix to `finding_ids` in the
corresponding `checks[]` entries.

If an agent errors before returning findings, record an error-level finding for that
artifact with `check_id: "agent-error"` and surface it in the report.

---

## Step 5 — Assemble the Report

Read `references/ci-output-schema.md` now, before computing any counts or populating any
fields. It contains the field-by-field population instructions for the CI JSON output and
must be loaded before you start assembling the report.

### Verdict counts

After collecting all agent results, apply confidence suppression: mark
`confidence_suppressed: true` for any finding where `confidence < 80`.
Confidence-suppressed findings are excluded from verdict counts and the interactive
display, but retained in the JSON output for metrics.

Compute from three sources combined:

**1. Agent findings** (artifact-reviewer, security-reviewer, hook-reviewer) — after confidence suppression:
- `blocking_count` — findings where `severity == "blocking"` AND `confidence_suppressed == false`
- `advisory_count` — findings where `severity == "advisory"` AND `confidence_suppressed == false`
- `informational_count` — findings where `severity == "informational"` AND `confidence_suppressed == false`
- `confidence_suppressed_count` — findings where `confidence_suppressed == true`

Severity levels used by agents: `"blocking"` (must fix before merge), `"advisory"` (should fix, non-blocking),
`"informational"` (awareness only).

**2. Validate results** — for each changed standards artifact, inspect `validate_result`:
- If `validate_result.verdict.result == "fail"`: add `validate_result.verdict.blocking_count`
  to `blocking_count` and `validate_result.verdict.informational_count` to `informational_count`

**3. Test results** — for each changed standard/language-guide (when not `--skip-test`):
- If `test_result.verdict.result == "fail"`: add 1 to `blocking_count` (test-accuracy FAIL blocks the PR)
- If `test_result.skipped == true`: add 1 to `informational_count`

**Important — source split:** Validate and test result failures are added to
`verdict.blocking_count` only. They do NOT create new entries in
`pr_review_report.severity_review.findings`. The `severity_review.findings` array is
populated solely from agent findings (artifact-reviewer, security-reviewer,
hook-reviewer) — and only those with `confidence_suppressed == false`. This means
`verdict.blocking_count` may legitimately be higher than
`severity_review.findings[CRITICAL].length` (when validate/test failures add to the
count); it must never be lower.

Overall verdict:
- `result: "pass"` if `blocking_count == 0`
- `result: "fail"` if `blocking_count > 0`
- `failed_gates`: list of `check_id` values where any agent returned a failing result (e.g.,
  `"structural-validation"`, `"behavioral-effectiveness"`, `"version-bump"`,
  `"policy-consistency"`, `"guide-staleness"`, `"version-removal-attestation"`,
  `"prompt-injection"`, `"network-exfiltration"`, `"skill-structure"`)
- `signal: "approve"` on pass; `signal: "request-for-changes"` on fail

### CI output (`--ci` flag)

When `--ci` is passed, your entire response MUST be only the JSON object. Follow this
exactly before writing a single character of output:

1. Do NOT write any explanation, summary, or preamble. Phrases like "Now I have all the
   data needed...", "Let me assemble...", "Here is the result:" are all forbidden.
2. Do NOT wrap the JSON in a markdown code fence (` ```json ``` `).
3. Write `{` as the very first character of your response.
4. Write `}` as the very last character of your response.
5. Nothing else. No trailing newline text, no closing remarks.

**Forbidden (causes CI pipeline failure):**
```
Now I have all the data. Let me assemble it:
{"verdict": ...}
```

**Correct:**
```
{"verdict": ...}
```

All findings and context are encoded inside the JSON. Populate each field per the "CI
JSON field mapping" section below.

**Before emitting: verify consistency.** Check two invariants:
1. `severity_review.findings` must contain zero entries with `severity == "CRITICAL"` or
   `"HIGH"` where `confidence_suppressed == true`. If any exist, you included suppressed
   findings — remove them before emitting.
2. `verdict.blocking_count` must be ≥ the count of CRITICAL entries in
   `severity_review.findings`. If it is lower, you dropped a finding from the count that
   you included in the findings array — recount before emitting.

Exit code 0. The verdict is communicated in the JSON output. Exit code 1 only on system errors (see Error Conditions).

### Interactive output (non-`--ci`)

**Only when `--ci` was NOT passed.** Emit a structured report with this shape:

```
## rr-standards:review — <base>...HEAD

Changed artifacts: N (M standards artifacts, K skill definitions, J hook scripts)

---

### <artifact-path> (<artifact-type>)

**Change type:** <MAJOR | MINOR | PATCH> — <evidence summary>
**Version bump:** <PASS | FAIL — reason>
(omit Change type / Version bump for skill-definition, agent-reference, template, hook-script artifacts)

#### Structural validation
For standards artifacts (standard, language-guide, enforcement-policy, AGENTS.md):
Read `validate_result.verdict.blocking_count` and `validate_result.verdict.informational_count`.
List each finding from `validate_result.findings[]` grouped by check_id.
Summary line: "✓ Pass (0 blocking, N informational)" or a bulleted list of findings.
For skill-definition, hook-script: "— N/A"

#### Behavioral effectiveness
For standard and language-guide (when not --skip-test):
- If test ran and PASS: "✓ Pass — with_accuracy N%, lift +N%"
  (read N values from `test_result.verdict.with_accuracy` and `test_result.verdict.lift`)
- If test ran and FAIL: "✗ Fail — with_accuracy N% (need ≥80%), lift +N% (need ≥20%)"
  (read N values from `test_result.verdict.with_accuracy` and `test_result.verdict.lift`)
- If test skipped (no .test.yaml): "— No .test.yaml found. Run /rr-standards:test <path> to generate one."
- If --skip-test: "— Skipped (--skip-test)"
For enforcement-policy, AGENTS.md, skill-definition, hook-script: "— N/A"

#### Quality checklist
Structural findings are surfaced in the "Structural validation" section above (from validate-agent).
This section covers qualitative findings from the artifact-reviewer only:
<for standards artifacts: findings for check_id: quality-checklist from the artifact-reviewer agent, or "✓ Pass">
<for skill-definition: findings for check_id: skill-structure from the artifact-reviewer agent, or "✓ Pass">
<for hook-script: "— N/A">

#### Version bump
<findings for check_id: version-bump, or "✓ Pass", or "— N/A (skill-definition / hook-script)">

#### Policy consistency
<findings for check_id: policy-consistency, or "✓ Pass", or "— Skipped (no companion policy)">

#### Guide staleness
<findings for check_id: guide-staleness, or "✓ Pass", or "— Skipped (no language guides)">

#### Version removal attestation
<findings for check_id: version-removal-attestation, or "✓ Pass", or "— Skipped (no versioned path removals detected)">

#### Security
For standards artifacts, skill-definition, agent-reference, template:
<findings for check_ids: prompt-injection, hidden-unicode, instruction-override, obfuscation, exfiltration>
<or "✓ Pass — no security findings">

For hook-script artifacts:
<findings for check_ids: network-exfiltration, credential-access, file-exfiltration, obfuscated-execution>
<or "✓ Pass — no hook security findings">

**Artifact verdict: PASS** — or — **Artifact verdict: FAIL (N blocking)**

---

<repeat for each changed artifact>

## Overall verdict: APPROVE ✓
  — or —
## Overall verdict: DENY ✗ (N blocking findings across M artifacts)
```

Each finding in a section is its own bullet:
```
- [blocking] <description>
  Evidence: <evidence>
  Fix: <suggested_action>
```

Confidence-suppressed findings are omitted from the interactive display (they are
retained in the JSON output record for metrics).

### CI JSON field mapping

Populate every field defined in `references/ci-output-schema.md` (already loaded at the
top of Step 5) before emitting the JSON record.

Exit code 0. The verdict is communicated in the JSON output. Exit code 1 only on system errors (see Error Conditions).

---

## Production Guardrails

Apply these limits before spawning agents in Step 4.

**Artifact cap — max 20 artifacts per run.**
If the diff classifies more than 20 artifacts for review, emit an informational note:
```
INFO: This PR touches N artifacts — review is capped at 20 to limit cost and latency.
The following artifacts were skipped: <list>. Split this PR or run review in batches.
```
Review the first 20 artifacts (in diff order). If the cap was hit, set the overall
`result` to `"fail"` with a single blocking finding: `check_id: "artifact-cap-exceeded"`.

**Concurrency — max 10 agents in flight at once.**
When more than 10 agents are ready to spawn in Step 4, batch them in groups of 10,
waiting for each batch to complete before starting the next. Merge results in order.

**Per-worker timeout — 7 minutes.**
If any individual agent (artifact-reviewer, security-reviewer, hook-reviewer, validate,
or test) does not return within 7 minutes, record a timeout finding for that artifact:
- `check_id: "agent-timeout"`, `severity: "advisory"` (not blocking)
- `description: "Review agent timed out for <file_path> — manual review recommended."`

Do not fail the overall verdict solely because a non-security worker timed out. If a
security-reviewer or hook-reviewer times out, escalate to `severity: "blocking"` and
add `"agent-timeout"` to `failed_gates`.

**Cost ceiling — $5 per review run (default).**
The backbone platform enforces this via `cost-ceiling-exceeded` error (see Error
Conditions). When hit mid-run, emit partial results for completed agents plus the error
record. Set `result: "error"` with `error.code: "cost-ceiling-exceeded"`.

---

## Error Conditions

| Situation | `error.code` | Behaviour |
|-----------|-------------|-----------|
| Diff unparseable or git command fails | `invalid-input` | Emit error record; exit 1 |
| TAXONOMY.md cannot be loaded | `invalid-input` | Emit error record; exit 1 |
| All artifact agents error before returning | `ai-service-unavailable` | Emit error record; exit 1 |
| Cost ceiling exceeded mid-review | `cost-ceiling-exceeded` | Emit partial results + error; exit 1 |
| Security/hook-reviewer agent timeout | `agent-timeout` | Emit blocking finding per timed-out worker; exit 0 |
| Non-security agent timeout | `agent-timeout` | Emit advisory finding per timed-out worker; exit 0 |

These are infrastructure or input failures, not quality failures. Surface them differently
from `"fail"` results — they should not trigger "request changes" review signals.
