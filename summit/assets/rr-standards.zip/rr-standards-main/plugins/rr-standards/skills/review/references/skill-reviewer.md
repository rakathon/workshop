# skill-reviewer — Check G: Skill Directory & Frontmatter Validation

Internal reference for `references/artifact-reviewer.md`. Read and executed only when
`artifact_type == "skill-definition"`. All six skill-specific context fields from the
artifact-reviewer input are available here.

---

## Your Inputs

```
- file_path: <repo-relative path to SKILL.md>
- head_content: <file content at HEAD>
- readme_exists: true | false
- skill_line_count: <integer — total line count of head_content>
- references_dir_exists: true | false
- integration_test_exists: true | false
- test_yaml_exists: true | false
- nested_skill_paths: [<list of repo-relative paths to nested SKILL.md files>]
- unexpected_subdirs: [<list of unrecognised immediate subdirectory names>]
```

---

## Check G — Skill Directory & Frontmatter Validation (`check_id: skill-structure`)

Run all sub-checks below. Each failed sub-check is its own finding. Return all findings
in the artifact-reviewer output format with `check_id: "skill-structure"`.

---

### G-1 — README.md presence

**If `readme_exists` is `false`:**
- Blocking finding: "No README.md found in the skill directory."
  - `evidence`: "The skill at `<file_path>` does not have a sibling README.md."
  - `suggested_action`: "Create README.md in the same directory as SKILL.md. It should
    describe the skill's purpose, usage flags, and at least one usage example."

---

### G-2 — SKILL.md line count

**If `skill_line_count > 500`:**
- Advisory finding: "SKILL.md is `<skill_line_count>` lines — skills over 500 lines are
  harder to maintain and navigate."
  - `evidence`: "`<file_path>` has `<skill_line_count>` lines."
  - `suggested_action`: Tailor based on what the length is coming from:
    - Large inline sub-agent prompt blocks: "Extract sub-agent instructions to
      `references/<agent-name>.md` and reference them with
      `Instructions: <full contents of references/<agent-name>.md>`."
    - Large inline shell sequences: "Consider moving hook logic to
      `.claude/hooks/<hook-name>.sh`."
    - General fallback: "Split long Steps into sub-steps and move large prompt
      templates to `references/`."
  - If `references_dir_exists: true`: add to evidence: "The skill already has a
    `references/` directory — the total line count still exceeds the limit."

---

### G-3 — Test coverage

**If `integration_test_exists` is `false`:**
- Informational finding: "No integration test found for this skill."
  - `evidence`: "No file matching `tests/claude-code/test-<skill-name>*.sh` was found."
  - `suggested_action`: "Add an integration test at
    `tests/claude-code/test-<skill-name>.sh`."

If `integration_test_exists` is `true`, produce no finding for G-3.

---

### G-4 — Evals presence

**If `test_yaml_exists` is `false`:**
- Advisory finding: "No `test.yaml` found for this skill."
  - `evidence`: "No sibling `test.yaml` exists in the skill directory."
  - `suggested_action`: "Add a `test.yaml` alongside SKILL.md with at least three
    scenarios: a main trigger case, a clean passing case, and at least one edge case.
    Tests are the primary mechanism for verifying and iterating on skill effectiveness."

If `test_yaml_exists` is `true`, produce no finding for G-4.

---

### G-5 — Frontmatter `name` format

Parse the YAML frontmatter from `head_content` (the block between the opening `---` and
closing `---` at the top of the file). Extract the `name` field.

**If `name` is absent or empty:**
- Advisory finding: "No `name` field in frontmatter — skill will be invoked by its
  directory name."
  - `evidence`: "No `name:` key found in the YAML frontmatter."
  - `suggested_action`: "Add `name: <plugin>:<skill-name>` if a plugin-namespaced
    invocation handle is needed. Omitting `name` is valid in Claude Code (the directory
    name is used), but explicit names are required for plugin-scoped skills where the
    `plugin:skill` namespace matters for disambiguation."

**If `name` is present, run these checks (each is its own finding):**

1. **Length**: If `len(name) > 64`:
   - Blocking finding: "Frontmatter `name` is `<len>` characters — maximum is 64."
     - `evidence`: `name: <value>`
     - `suggested_action`: "Shorten the `name` value to 64 characters or fewer."

2. **Character set**: If `name` contains any character other than `[a-z0-9:\-]`
   (lowercase letters, digits, colons, hyphens):
   - Blocking finding: "Frontmatter `name` contains invalid characters."
     - `evidence`: "Invalid characters found in: `<name>`."
     - `suggested_action`: "Use only lowercase letters, numbers, colons, and hyphens.
       No uppercase, spaces, or underscores."

3. **Reserved words**: If `name` contains `anthropic` or `claude` as a substring
   (case-insensitive):
   - Blocking finding: "Frontmatter `name` contains a reserved word."
     - `evidence`: "The name `<name>` contains the reserved word `anthropic` or `claude`."
     - `suggested_action`: "Remove the reserved word from the `name` field."

4. **XML tags**: If `name` contains `<` or `>`:
   - Blocking finding: "Frontmatter `name` contains XML tag characters."
     - `evidence`: "Characters `<` or `>` found in: `<name>`."
     - `suggested_action`: "Remove XML tag characters from the `name` field."

If `name` passes all four checks, produce no finding for G-5.

---

### G-6 — Frontmatter `description` quality

Parse the YAML frontmatter from `head_content`. Extract both `description` and
`when_to_use` fields (either may be a multi-line block scalar; `when_to_use` may be
absent).

In Claude Code, `description` and `when_to_use` are combined in the skill listing and
share a 1,536-character budget per skill entry. Both fields contribute to discoverability.

**If `description` is absent or empty:**
- Blocking finding: "Frontmatter `description` field is missing or empty."
  - `evidence`: "No `description:` key found in the YAML frontmatter."
  - `suggested_action`: "Add a `description` explaining what the skill does and when to
    trigger it. Write in third person. Use `when_to_use` as a sibling field for additional
    trigger context if the description alone would become too long."

**If `description` is present, run these checks (each is its own finding):**

1. **Combined length**: If `len(description) + len(when_to_use ?? "")` > 1536 characters:
   - Advisory finding: "Combined `description` + `when_to_use` exceeds 1,536 characters
     (`<combined_len>` chars total)."
     - `evidence`: "`description` is `<len>` chars; `when_to_use` is `<len>` chars (or
       absent)."
     - `suggested_action`: "Trim to 1,536 combined characters. The skill listing budget
       is hard-capped at this length; content past it is silently dropped and can strip
       the trigger keywords Claude needs for discovery. Move detailed usage notes to
       README.md instead."

2. **XML tags**: If `description` contains `<` or `>`:
   - Blocking finding: "Frontmatter `description` contains XML tag characters."
     - `evidence`: "Characters `<` or `>` found in the description."
     - `suggested_action`: "Remove XML tag characters. Use square brackets for
       placeholders: `[branch-name]` instead of `<branch-name>`."

3. **First-person voice**: If `description` contains first-person phrases such as
   `"I can"`, `"I will"`, `"I help"`, `"I process"`, `"I analyze"` (case-insensitive):
   - Advisory finding: "Frontmatter `description` uses first-person voice."
     - `evidence`: "First-person phrase found: `<phrase>`."
     - `suggested_action`: "Rewrite in third person. The description is injected into the
       system prompt; first-person voice causes discovery problems. E.g. 'I can process
       PDFs' → 'Processes PDF files'."

4. **Second-person voice**: If `description` contains phrases such as `"you can"`,
   `"you use"`, `"use this to"` (case-insensitive):
   - Advisory finding: "Frontmatter `description` uses second-person voice."
     - `evidence`: "Second-person phrase found: `<phrase>`."
     - `suggested_action`: "Rewrite in third person. E.g. 'You can use this to process
       PDFs' → 'Processes PDF files'."

5. **Trigger language**: Check whether either `description` or `when_to_use` contains at
   least one of: `"use when"`, `"use this when"`, `"trigger"`, `"triggered by"`,
   `"invoke"` (case-insensitive). If NEITHER field contains trigger language:
   - Advisory finding: "Neither `description` nor `when_to_use` specifies when to trigger
     this skill."
     - `evidence`: "No trigger language found in either field."
     - `suggested_action`: "Add a 'Use when:' clause to `description`, or add a separate
       `when_to_use:` field for longer trigger context. Claude uses this to select the
       right skill from many candidates — without trigger language the skill may not be
       discovered reliably."

6. **Multiline scalar style**: Inspect the raw YAML frontmatter source (before parsing).
   If the `description` value spans multiple lines in the source **and** is not preceded
   by a `>` or `|` block scalar indicator on the `description:` line (i.e. the raw text
   is `description:\n  line one\n  line two` with no `>` or `|`):
   - Advisory finding: "Multiline `description` is missing a folded block scalar indicator."
     - `evidence`: "The `description` field spans multiple lines without a `>` or `|`
       indicator. YAML will parse embedded newlines literally, which can break skill
       discovery and display."
     - `suggested_action`: "Add `>` after `description:` to use a folded block scalar
       (newlines become spaces, producing a single paragraph). Use `|` only if you
       intentionally want newlines preserved. Example:\n```yaml\ndescription: >\n  Your
       multiline description here.\n```"

If `description` passes all six checks, produce no finding for G-6.

---

### G-7 — Time-sensitive content

Scan `head_content` (excluding YAML frontmatter and fenced code blocks) for hardcoded
calendar dates or time-bounded conditional statements that will silently become wrong
after the referenced date passes.

**Patterns to detect:**
- Explicit date comparisons in prose: `"before <YYYY-MM-DD>"`, `"after <YYYY-MM-DD>"`,
  `"until <month> <year>"`, `"after <month> <year>"` (e.g. "before August 2025")
- Prose sentences of the form `"If you're doing this before X, use Y. After X, use Z."`
  where X is a date or release milestone

**Do NOT flag:**
- Dates in version strings or version tables (e.g. `deprecated 2025-08` in a clearly-marked
  "Old patterns" or legacy section)
- Dates in examples illustrating date-format output
- ISO 8601 timestamps inside fenced code blocks

**If any time-sensitive content is found:**
- Advisory finding per occurrence: "Time-sensitive content — prose instruction depends on
  whether the current date is before or after `<date-or-milestone>`."
  - `evidence`: "Prose: `<the offending sentence>`."
  - `suggested_action`: "Replace with a 'Current method' section and an 'Old patterns'
    (legacy) section under a `<details>` block."

If no time-sensitive content is found, produce no finding for G-7.

---

### G-8 — Directory structure integrity

A skill directory must contain exactly one `SKILL.md` at its root. Nested `SKILL.md`
files indicate that someone placed a second skill inside the first — this breaks Claude
Code's skill loading (it treats the outer directory as the skill and the inner one is
invisible) and creates ambiguous ownership of the `references/` and `fixtures/` content.

Unrecognised top-level subdirectories may indicate a misplaced skill or content that
should live in an established location (`references/`, `fixtures/`, `evals/`, `scripts/`).

**Allowed immediate subdirectories** (not flagged):
`references`, `fixtures`, `evals`, `scripts`, `common`

Hidden directories (names starting with `.`) are always ignored.

---

**If `nested_skill_paths` is non-empty:**

One blocking finding **per nested path**:

- Blocking finding: "Nested SKILL.md found inside this skill directory."
  - `evidence`: "SKILL.md found at `<nested_path>` — this is inside the skill rooted at
    `<skill_dir>/SKILL.md`."
  - `suggested_action`: "Move `<nested_path>` to its own sibling directory at the same
    level as `<skill_dir>/`. Each skill must live in its own top-level directory. Nesting
    skill directories causes the inner skill to be invisible to Claude Code."

---

**If `unexpected_subdirs` is non-empty:**

One advisory finding listing all unexpected directories together:

- Advisory finding: "Unrecognised subdirectories found in skill directory."
  - `evidence`: "Directories not in the allowed set: `<unexpected_subdirs joined by ', '>`."
  - `suggested_action`: "Rename or move these directories to an established location.
    Allowed subdirectories: `references/` (sub-agent prompts), `fixtures/` (test fixtures),
    `evals/` (structured evals), `scripts/` (utility scripts), `common/` (shared content).
    If this contains another skill, move it to its own sibling directory."

---

If `nested_skill_paths` is empty and `unexpected_subdirs` is empty, produce no finding
for G-8.

---

## Confidence and Severity Summary

| Sub-check | Condition | Severity | Confidence |
|-----------|-----------|----------|------------|
| G-1 README absent | `readme_exists: false` | blocking | 95 |
| G-2 line count | `skill_line_count > 500` | advisory | 88 |
| G-3 no integration test | `integration_test_exists: false` | informational | 85 |
| G-4 no test.yaml | `test_yaml_exists: false` | advisory | 90 |
| G-5 name absent | `name` missing/empty | advisory | 85 |
| G-5 name too long | `len(name) > 64` | blocking | 98 |
| G-5 name bad chars | invalid characters in `name` | blocking | 97 |
| G-5 name reserved word | `name` contains `anthropic`/`claude` | blocking | 97 |
| G-5 name XML tags | `name` contains `<` or `>` | blocking | 97 |
| G-6 description absent | `description` missing/empty | blocking | 98 |
| G-6 combined length | `len(description + when_to_use) > 1536` | advisory | 92 |
| G-6 description XML tags | `<` or `>` in description | blocking | 97 |
| G-6 first-person | first-person phrases in description | advisory | 85 |
| G-6 second-person | second-person phrases in description | advisory | 85 |
| G-6 no trigger | no trigger language in description or when_to_use | advisory | 80 |
| G-6 multiline no scalar | multiline description without `>` or `\|` indicator | advisory | 90 |
| G-7 time-sensitive | date-conditional prose in non-legacy sections | advisory | 75 |
| G-8 nested skill | any path in `nested_skill_paths` | blocking | 97 |
| G-8 unexpected subdir | any name in `unexpected_subdirs` | advisory | 88 |

---

## Output Examples

```json
// All sub-checks pass
{
  "check_id": "skill-structure",
  "name": "Skill directory & structure validation",
  "category": "quality",
  "result": "pass",
  "duration_ms": 0,
  "finding_ids": []
}

// Missing README.md (blocking) + over 500 lines (advisory)
{
  "check_id": "skill-structure",
  "name": "Skill directory & structure validation",
  "category": "quality",
  "result": "fail",
  "duration_ms": 0,
  "finding_ids": ["f-007", "f-008"]
}
// finding f-007: severity "blocking", rule_id "G-1", confidence 95
//   description: "No README.md found in the skill directory."
// finding f-008: severity "advisory", rule_id "G-2", confidence 88
//   description: "SKILL.md is 848 lines — skills over 500 lines are harder to maintain..."

// Invalid name + first-person description + no evals
{
  "check_id": "skill-structure",
  "name": "Skill directory & structure validation",
  "category": "quality",
  "result": "fail",
  "duration_ms": 0,
  "finding_ids": ["f-010", "f-011", "f-012"]
}
// finding f-010: severity "blocking", rule_id "G-5", confidence 97
//   description: "Frontmatter `name` contains invalid characters."
// finding f-011: severity "advisory", rule_id "G-6", confidence 85
//   description: "Frontmatter `description` uses first-person voice."
// finding f-012: severity "advisory", rule_id "G-4", confidence 90
//   description: "No evals/evals.json found for this skill."
```

All findings must use `check_id: "skill-structure"`. Return them in the calling
artifact-reviewer's `findings[]` array alongside findings from other checks.
