---
version: 1.0.0
---

# Observability Standard

## Overview

This standard governs logging and metrics for Rakuten Rewards services.
All production services must emit structured logs and expose a metrics endpoint.

## Scope

Applies to all backend services. Does not cover frontend analytics.

## Rules

R-1: All log entries must​ be structured JSON with a timestamp, level, service, and message field.

R-2: Services must expose a /metrics endpoint in Prometheus format.

R-3: Do not log PII (personally identifiable information) such as email addresses,
phone numbers, or payment card data.

R-4: Log levels must follow this hierarchy: DEBUG, INFO, WARN, ERROR, FATAL.
Use ERROR only for conditions that require immediate operator attention.

## Compliance Checklist

- [ ] Log entries are structured JSON
- [ ] /metrics endpoint exists and returns Prometheus format
- [ ] No PII in log entries
- [ ] Log levels used consistently per the defined hierarchy

## Examples

```json
{
  "timestamp": "2026-01-15T10:30:00Z",
  "level": "INFO",
  "service": "user-service",
  "message": "User created",
  "user_id": "u123"
}
```

## Related Standards

- [Security Standard](../security/overview.md)
