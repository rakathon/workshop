---
version: 1.0.0
---

# Testing Standard

## Overview

This standard governs automated testing practices for Rakuten Rewards services.
All production code must have corresponding tests at the appropriate levels.

## Scope

Applies to unit tests, integration tests, and end-to-end tests for all services.
Does not cover manual QA processes or performance testing.

## Rules

R-1: Every public function must have at least one unit test covering the happy path.

R-2: Integration tests must use isolated test databases seeded with known fixtures.
Production databases must never be used in test environments.

R-3: End-to-end tests must cover all critical user journeys defined in the product spec.

R-4: Tests must be deterministic. Flaky tests that fail intermittently must be
fixed or removed before they are merged.

R-5: Test coverage for new code must not fall below 80% line coverage.

## Compliance Checklist

- [ ] All public functions have at least one unit test
- [ ] Integration tests use isolated databases with known fixtures
- [ ] Critical user journeys have end-to-end test coverage
- [ ] No flaky tests merged to the main branch
- [ ] New code maintains ≥ 80% line coverage

## Examples

Compliant — unit test covering the happy path:
```
test "get user returns correct name" {
  store = new InMemoryStore()
  store.set("u1", User{ id: "u1", name: "Alice" })
  result = getUser(store, "u1")
  assert result.name == "Alice"
}
```

Compliant — integration test with isolated database:
```
test "create order writes to isolated database" {
  db = testDB.create()         // creates isolated DB, torn down after test
  order = createOrder(db, { item: "book", qty: 1 })
  assert db.orders.count() == 1
  db.destroy()
}
```

## Related Standards

- [REST API Standard](../api/rest.md)
