# CI Output Schema — Field Mapping

Reference for `rr-standards:review`. Read when assembling the `--ci` JSON output in
Step 5. Populate each field exactly as specified below.

---

## `verdict`

- `result`: `"pass"` if `blocking_count == 0`, `"fail"` if `blocking_count > 0`
- `blocking_count`, `advisory_count`, `informational_count`: from Verdict counts in Step 5
- `failed_gates`: `check_id` values where any agent returned a failing result

---

## `pr_review_report.generated_at`

ISO 8601 timestamp at report generation time.

---

## `pr_review_report.branch`

From `git rev-parse --abbrev-ref HEAD`.

---

## `pr_review_report.base_branch`

Resolved base branch (from `--base`, `--pr`, or auto-detected).

---

## `pr_review_report.changed_files`

All file paths from the diff (before taxonomy filtering).

---

## `pr_review_report.commit_count`

From `git rev-list <base>...HEAD --count`.

---

## `pr_review_report.security`

Populated from security-reviewer and hook-reviewer findings.

- `overall_risk`: `"CRITICAL"` if any CRITICAL finding, `"HIGH"` if any HIGH, `"MEDIUM"`
  if any MEDIUM, else `"LOW"`
- `findings`: each security finding mapped to
  `{ severity, location: file_path, category: check_id, risk: description, fix: suggested_action }`
- `summary`: one-sentence summary of security posture

---

## `pr_review_report.performance`

Not applicable for standards artifacts. Always emit:

```json
{
  "overall_impact": "NONE",
  "findings": [],
  "summary": "No performance analysis performed for standards artifacts."
}
```

---

## `pr_review_report.style`

Populated from artifact-reviewer `quality-checklist` findings.

- `score`: 10 minus number of style violations (minimum 0)
- `violations`: from `check_id: "quality-checklist"` — each mapped to
  `{ location: file_path, issue: description, fix: suggested_action, auto_fixable: false }`
- `complexity_issues`: `[]` (not tracked by artifact-reviewer)
- `duplication`: `[]` (not tracked by artifact-reviewer)
- `positive_notes`: explicit positive observations from artifact-reviewer
- `summary`: one-sentence summary of style quality

---

## `pr_review_report.severity_review`

All non-confidence-suppressed findings from all agents.

- `mode`: `"standards-artifact-review"`
- `findings`: each finding mapped to
  `{ severity: <mapped>, location: file_path, problem: description, fix: suggested_action }`
  - severity mapping: `"blocking"` → `"CRITICAL"`, `"advisory"` → `"HIGH"`,
    `"informational"` → `"LOW"`
  - **Only include findings where `confidence_suppressed == false`.** Findings where
    `confidence_suppressed == true` must NOT appear here, regardless of their `severity`
    value. Apply the same filter used to compute `verdict.blocking_count` — these two
    must always agree.
  - **Source:** artifact-reviewer, security-reviewer, and hook-reviewer agent findings
    only. Validate-agent and test-agent result failures are NOT included here — they
    contribute to `verdict.blocking_count` only.
- `counts`: tally by mapped severity level (`nitpick` is always 0)

---

## `pr_review_report.pre_merge_checklist`

- `verdict`: `"BLOCKED"` if `blocking_count > 0`, `"APPROVED_WITH_FIXES"` if
  `advisory_count > 0`, `"APPROVED"` otherwise
- `checks.test_coverage`: `"FAIL"` if any test-agent returned failure or
  `{"skipped": true}`; findings list artifact paths with failed/missing tests
- `checks.breaking_changes`: `"FAIL"` if any artifact has `change_type: MAJOR` without a
  PASS version-bump; findings list the affected artifact paths
- `checks.debug_artifacts`, `checks.unlinked_todos`, `checks.conflict_markers`,
  `checks.unwanted_files`: scan changed file content for these patterns — `"FAIL"` if
  found, `"PASS"` if clean
- `checks.typescript_any`: always `"NA"` (standards artifacts are Markdown, not TypeScript)
- `blocking_issues`: human-readable descriptions of all blocking-severity findings

---

## `pr_review_report.pr_description`

- `summary`: one-paragraph description of the PR's purpose derived from changed artifacts
  and commit messages
- `type`: infer from artifacts — `"Docs"` for standards/guides, `"Feature"` for new
  artifacts, `"Fix"` for corrections, `"Refactor"` for structural reorganisation,
  `"Chore"` for version bumps or maintenance
- `changes`: bullet-point list of significant changes per artifact
- `testing_steps`: steps to verify the changes (e.g., run `/rr-standards:validate`, check
  `/rr-standards:test` results)
- `related_tickets`: extracted from PR body — match patterns `RR-\d+`, `JIRA-\d+`, `#\d+`

---

## `pr_review_report.language_review`

`null` if no language guides changed. If language-guide artifacts were reviewed, populate
as an object with per-guide findings from the artifact-reviewer `guide-staleness` check.

---

## `pr_review_report.overall`

- `recommendation`: `"REJECT"` if blocking security findings; `"HOLD"` if other blocking
  findings; `"MERGE_WITH_FIXES"` if advisory findings only; `"MERGE"` if clean
- `blocking_count`, `advisory_count`: same as `verdict` values
- `top_issues`: top 3–5 most important issues (highest severity, most actionable)
- `verdict_reason`: one-sentence explanation of the recommendation
