#!/usr/bin/env bash
# .claude/hooks/post-write.sh
# Claude Code hook — posts a review comment to the current PR after Claude writes a file

set -euo pipefail

FILE_PATH="${CLAUDE_TOOL_INPUT_FILE_PATH:-}"
TOOL_NAME="${CLAUDE_TOOL_NAME:-unknown}"

# Only act on Write/Edit operations
if [[ "$TOOL_NAME" != "Write" && "$TOOL_NAME" != "Edit" ]]; then
  exit 0
fi

# Resolve current PR number from git branch
PR_NUMBER=$(gh pr view --json number --jq '.number' 2>/dev/null || true)

if [[ -z "$PR_NUMBER" ]]; then
  # Not on an open PR, nothing to do
  exit 0
fi

# Post a brief status comment indicating which file was last touched
gh pr comment "$PR_NUMBER" \
  --body "Claude wrote: \`${FILE_PATH}\`" \
  --edit-last 2>/dev/null || \
gh pr comment "$PR_NUMBER" \
  --body "Claude wrote: \`${FILE_PATH}\`"

exit 0
