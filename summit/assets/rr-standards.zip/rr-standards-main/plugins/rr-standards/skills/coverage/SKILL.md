---
name: rr-standards:coverage
description: >
  Scans every standards artifact under a given plugin root directory (standards/ and
  languages/ subdirectories), computes a coverage status for each (absent / stub / draft /
  complete / major-stale), writes a refreshed standards/COVERAGE.md inside that root, and
  prints a summary with the five highest-priority gaps. Use this skill whenever: an author
  asks what's missing or needs prioritization; a standard or language guide is added or
  updated and the map needs refreshing; someone asks about the current state of the
  standards library; you're about to start new writing work and want to know where the
  gaps are. Invoke as: /rr-standards:coverage [<root-dir>]
---

# rr-standards:coverage

Worker skill — non-interactive. Walks all standards and language artifact locations under
a given root, computes coverage status for each, writes `<root>/standards/COVERAGE.md`,
and emits a summary.

---

## Input

Parse from the invocation:
- `<root-dir>` — path to the plugin root containing `standards/` and `languages/`
  subdirectories (optional; defaults to the current working directory if omitted).

Examples:
```
/rr-standards:coverage forge
/rr-standards:coverage plugins/forge/
/rr-standards:coverage .
/rr-standards:coverage
```

Resolve `<root-dir>` to an absolute path before using it. If the path does not exist or
contains neither a `standards/` nor a `languages/` subdirectory, emit an error and stop:
```
ERROR: <root-dir> does not contain a standards/ or languages/ directory.
Usage: /rr-standards:coverage [<root-dir>]
```

All subsequent path references in this skill use `<root>` to mean the resolved root
directory. A file described as `<root>/standards/api/rest.md` is the file at that
relative path inside the provided root.

---

## Step 1 — Load the Taxonomy

Read `<root>/plugins/forge/standards/TAXONOMY.md`. You need:
- The **Required Sections** for each artifact type (Language-agnostic standard, Language
  guide, Enforcement policy, AGENTS.md)
- The **Artifact Type Identification** rules
- The location patterns for each type

If `<root>/plugins/forge/standards/TAXONOMY.md` does not exist, use these embedded fallback definitions and
note in the output header that TAXONOMY.md was not found:

| Artifact type | Required sections |
|---------------|------------------|
| Language-agnostic standard | Overview, Scope, Rules, Compliance Checklist, Examples, Related |
| Language guide | Overview, Related standard, Prerequisites, Implementation, Verification |
| Enforcement policy | Standard reference, Policy metadata, Severity table |
| AGENTS.md | Directory purpose, File index, Navigation |

---

## Step 2 — Walk `<root>/standards/`

The coverage map must show the full expected structure, not just what happens to exist.
Do both parts:

**Part A — scan what exists.** List all `.md` files in `<root>/standards/` and its
subdirectories recursively.

Skip infrastructure files:
- `<root>/plugins/forge/standards/TAXONOMY.md`
- `<root>/standards/COVERAGE.md`
- Any `AGENTS.md` (handled in Part B)
- Any `README.md` (infrastructure)

For each remaining file: apply the artifact type detection rules, record path relative
to `<root>`, detected type, coverage status (Step 4), line count, notes. An empty file
(0 bytes or whitespace only) counts as **absent**.

**Part B — enumerate expected locations.** The expected standard categories are:
`api`, `deployment`, `extension-development`, `messaging`, `observability`, `security`,
`skills`, `storage`, `testing`. If `<root>/plugins/forge/standards/TAXONOMY.md` lists additional or
different categories, use that list instead.

For each expected category: if the category directory exists, it was already covered in
Part A. If the category directory does not exist, add an entry in the coverage table:
```
| `standards/<category>/` | absent | — | Category directory does not exist |
```

This ensures the coverage map shows a row for every expected category even when
`<root>/standards/` is brand new and empty.

Also walk AGENTS.md files: for each subdirectory under `<root>/standards/`, check for
an `AGENTS.md`; apply status rules; record in the AGENTS.md section.

If `<root>/standards/` does not exist, record all expected categories as absent and note
it in the output header.

---

## Step 3 — Walk `<root>/languages/`

The expected languages are: `go`, `java`, `kotlin`, `python`, `sql`, `swift`,
`typescript`. If `<root>/plugins/forge/standards/TAXONOMY.md` or `<root>/languages/` lists different
languages, use that list instead.

**Part A — scan what exists.** For each language directory under `<root>/languages/<lang>/`:

1. **Language-root AGENTS.md** — `<root>/languages/<lang>/AGENTS.md`: apply status rules;
   record path relative to `<root>`, "AGENTS.md", status, line count, notes.

2. **Language guides** — walk `<root>/languages/<lang>/guides/` recursively:
   - For each `.md` file whose path contains `/guides/`: apply status rules; then run the
     staleness check (Step 5); record path relative to `<root>`, "Language guide", status,
     declared implements version, current standard version, staleness verdict, line count, notes.
   - For each guide **directory** under `/guides/`: check for a directory-level `AGENTS.md`;
     apply status rules; record as an AGENTS.md artifact.
   - If `<root>/languages/<lang>/guides/` does not exist: record the language as having
     no guide coverage.

**Part B — enumerate expected languages.** For each expected language not found under
`<root>/languages/`, add a section in the Language Guides output:
```
### <Language>
| `languages/<lang>/AGENTS.md` | absent | — | Language directory does not exist |
```

This ensures the coverage map shows a section for every expected language even when
`<root>/languages/` is brand new and empty.

If `<root>/languages/` does not exist, record all expected languages as absent and note
it in the output header.

---

## Step 4 — Coverage Status Rules

Apply these rules in order. Stop at the first matching rule.

**absent** — The file does not exist, OR the file has zero substantive lines. A
substantive line is any non-blank, non-whitespace line that is not inside an HTML
comment (`<!-- ... -->`). An empty file and a file containing only comments count as absent.

**stub** — The file exists and has substantive content, but none of the required sections
for its type are present. A section is "present" when a heading matching the section name
exists AND at least one substantive line appears beneath it before the next heading.

**draft** — The file exists, at least one required section is present (by the definition
above), and at least one required section is missing or entirely empty. Files that have
substantive content but use a pre-taxonomy structure (e.g., FS-N or NFS-N rule
identifiers instead of R-N, or no Compliance Checklist section) count as **draft** —
the content is valuable but the structure is non-conforming.

**complete** — All required sections for the detected artifact type are present with
substantive content. AGENTS.md files that exceed the 100-line size limit are still
**complete**; note the oversize in the Notes column but do not demote the status.

**major-stale** — (Language guides only; overrides complete or draft.) The guide is
complete or draft AND its declared `Implements:` version is behind the current version
of the referenced standard by a MAJOR bump. See Step 5.

---

## Step 5 — Staleness Check (Language Guides Only)

For each language guide with status complete or draft:

**1. Find the Implements: declaration.**
Look in the Overview section for a line containing `Implements:` followed by a path and
version. The expected forms are:
- `Guide: X.Y.Z | Implements: standards/<category>/<standard>.md@X.Y.Z`
- `Implements: standards/<category>/<standard>.md@X.Y.Z`

If no such line is found anywhere in the file:
- Keep the current status (complete or draft).
- Add note: "Missing Implements: declaration".
- Do not demote to major-stale; skip to the next guide.

**2. Extract the declared standard path and version.**
Example: `standards/api/rest.md@1.2.0` → path = `standards/api/rest.md`, declared version =
`1.2.0`. Resolve the standard file path relative to `<root>` (i.e., look for
`<root>/standards/api/rest.md`).

**3. Read the current standard version.**
Open the referenced standard file. Look for a version declaration near the top of the file:
- A line containing `Version: X.Y.Z`
- Or YAML frontmatter with `version: X.Y.Z`

If the standard file cannot be read or contains no version declaration: add note
"Standard has no version — cannot check staleness"; keep current status; skip.

**4. Compare MAJOR versions.**
Extract the MAJOR component from both the declared version and the current standard version.
- If declared MAJOR < current MAJOR → set status to **major-stale**; add note:
  "Declared @<declared_version>; standard is now @<current_version> (MAJOR bump)"
- If declared MAJOR == current MAJOR → status unchanged; if declared MINOR < current
  MINOR, add note "Minor-stale: declared @<declared_version>, current @<current_version>"
  but do not change status.

---

## Step 6 — Write `<root>/standards/COVERAGE.md`

Write the complete coverage map to `<root>/standards/COVERAGE.md` in a single write
operation, overwriting any previous content. Use this exact structure:

```
# Standards Library Coverage Map

Last reviewed: <YYYY-MM-DD> | Reviewed by: `rr-standards:coverage` (automated)

**Status definitions** (see `TAXONOMY.md` for required sections):
- **complete** — all required sections present with substantive content
- **draft** — substantive content exists; one or more required sections missing or non-conforming
- **stub** — file exists; no required sections present or all sections empty
- **absent** — file does not exist or is empty
- **major-stale** — (language guides only) guide's declared standard version is behind
  by a MAJOR bump; guide is supplementary-only for conflicting rules until updated;
  higher priority gap than absent stubs

<include the pre-taxonomy note below if any pre-taxonomy files were found in the scan>
> **Note:** Files authored before the taxonomy was defined use earlier rule identifier
> structures (FS-N/NFS-N) rather than R-N/Compliance Checklist. These are marked **draft** —
> the content is substantive but does not yet conform to the current template.

---

## Standards (`standards/`)

### <Category>

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `<relative-path-from-standards/>` | <status> | <N> | <notes or empty> |

<repeat for each category: api, deployment, extension-development, messaging,
 observability, security, skills, storage, testing>

Include a category section even if all files in it are absent, so gaps remain visible.
List the most critical categories first (security, observability, deployment).

---

## Language Guides (`languages/`)

### <Language>

| File | Status | Implements | Notes |
|------|--------|------------|-------|
| `AGENTS.md` | <status> | — | <notes> |
| `<relative-path-from-languages/<lang>/>` | <status> | `<standard>@<version>` or — | <notes> |

<repeat for each language directory found under languages/>

---

## AGENTS.md Files (`standards/`)

| File | Status | Lines | Notes |
|------|--------|-------|-------|
| `<relative-path>` | <status> | <N> | <notes> |

---

## Summary

| Metric | Count |
|--------|-------|
| Total artifacts scanned | N |
| Complete | N |
| Draft | N |
| Stub | N |
| Absent | N |
| Major-stale | N |

### Top 5 Priority Gaps

1. <gap>
2. <gap>
3. <gap>
4. <gap>
5. <gap>
```

**Priority ordering for the top-5 list:** Use this order when ranking gaps:
1. major-stale language guides (actively conflicting guidance)
2. absent or stub files in security, observability, deployment (high risk if missing)
3. absent AGENTS.md for a language that has existing guides
4. absent language guides for a language that has an AGENTS.md
5. draft files with zero required sections conforming to the current template in
   high-traffic standard categories (api, testing, storage)

When there are more than 5 gaps at the same priority level, pick the ones most likely to
block development work (security and auth gaps rank above style and formatting gaps).

---

## Step 7 — Print Terminal Summary

After writing the file, print a concise summary:

```
<root>/standards/COVERAGE.md written (<date>)

Artifacts scanned: N
  Complete:      N
  Draft:         N  (N pre-taxonomy)
  Stub:          N
  Absent:        N
  Major-stale:   N

Top 5 priority gaps:
  1. <gap description with file path>
  2. <gap description>
  3. <gap description>
  4. <gap description>
  5. <gap description>
```

Do not print the full COVERAGE.md content — the terminal output is the highlight reel;
the file is the full record.
