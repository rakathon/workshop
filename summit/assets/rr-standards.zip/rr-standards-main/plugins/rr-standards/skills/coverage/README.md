# rr-standards:coverage

Scans the standards library, computes coverage status for every artifact, writes
`standards/COVERAGE.md`, and reports the five highest-priority gaps.

## Purpose

`rr-standards:coverage` gives authors a current, accurate view of the standards
library — what's complete, what's draft, what's missing, and what's dangerously stale.
It replaces manual tracking with an automated scan that any author can run before
starting work or after landing a change.

The scan classifies every artifact as:

| Status | Meaning |
|--------|---------|
| **complete** | All required sections present with substantive content |
| **draft** | Substantive content exists; one or more required sections missing or non-conforming |
| **stub** | File exists; no required sections present or all sections empty |
| **absent** | File does not exist or is empty |
| **major-stale** | (Language guides only) Guide's declared standard version is behind by a MAJOR bump — supplementary-only for conflicting rules until updated |

## When to Run

- Before starting new writing work (to know where the gaps are)
- After adding or updating a standard or language guide (to refresh the map)
- After a taxonomy change (to re-classify with the updated required sections)
- On a schedule in CI to keep `standards/COVERAGE.md` current

## Usage

```bash
# Scan a specific plugin root (e.g., the plugins/forge/ directory)
/rr-standards:coverage forge

# Scan the current working directory
/rr-standards:coverage
/rr-standards:coverage .
```

The `<root-dir>` argument points to a directory containing `standards/` and/or
`languages/` subdirectories. In this repository the content lives under `plugins/forge/`:

```bash
/rr-standards:coverage forge
```

## Output

**`<root>/standards/COVERAGE.md`** — Full coverage map organized by category (standards)
and language (language guides), with a status table for each area. Overwritten on every
run.

**Terminal summary** — Artifact counts by status and the five highest-priority gaps,
printed after the file is written.

Example terminal output:

```
standards/COVERAGE.md written (2026-03-08)

Artifacts scanned: 62
  Complete:      14
  Draft:         28  (21 pre-taxonomy)
  Stub:          6
  Absent:        12
  Major-stale:   2

Top 5 priority gaps:
  1. [major-stale] languages/java/guides/api/rest.md — declared @1.0.0, standard is @2.1.0
  2. [absent] standards/security/overview.md — security standard missing entirely
  3. [absent] standards/observability/logging.md — observability standard missing
  4. [absent] standards/deployment/ci-cd.md — deployment standard missing
  5. [stub] languages/kotlin/AGENTS.md — Kotlin language root has no content
```

## How Coverage Status Is Determined

The skill reads `plugins/forge/standards/TAXONOMY.md` to identify the required sections for each
artifact type, then checks whether those sections are present and substantive. A section
counts as present when its heading exists and at least one non-empty, non-placeholder
line appears beneath it.

Files with pre-taxonomy structure (FS-N/NFS-N rule identifiers, no Compliance Checklist)
are classified as **draft** — they have valuable content but need migration to the
current template.

Language guide staleness is detected by reading the guide's `Implements:` declaration
and comparing it to the current version in the referenced standard. A MAJOR version
gap triggers **major-stale** status.

## Design Reference

Skill workflow: `.forge/efforts/rr-standards-plugin/spec/skills.md § rr-standards:coverage`
Coverage requirements: `.forge/efforts/rr-standards-plugin/requirements/technical.md § TR-4`
