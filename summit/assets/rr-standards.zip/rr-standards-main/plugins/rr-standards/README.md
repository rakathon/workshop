# rr-standards plugin

Claude Code plugin for authoring, validating, and reviewing standards artifacts in the
rr-standards library.

## Skills

| Skill | Purpose |
|-------|---------|
| [`rr-standards:author`](skills/author/README.md) | Guided workflow for creating and updating standards artifacts |
| [`rr-standards:validate`](skills/validate/README.md) | Quality check a single artifact against its type checklist |
| [`rr-standards:review`](skills/review/README.md) | PR gate — reviews all changed standards artifacts in a diff |
| [`rr-standards:coverage`](skills/coverage/README.md) | Scans the library and writes a coverage map to `standards/COVERAGE.md` |

## Typical workflows

**Writing a new standard:**
```
/rr-standards:author
```
Prompts for artifact type and name, copies the right template, walks through each
section, and runs a quality check when done.

**Checking a file before opening a PR:**
```
/rr-standards:validate standards/api/rest.md
```

**Reviewing a PR:**
```
/rr-standards:review --base main
```
Classifies every changed file, runs checks in parallel across all changed artifacts,
and reports a PASS/FAIL verdict. Pass `--ci` to emit machine-readable JSON for branch
protection rules.

**Finding what needs work:**
```
/rr-standards:coverage
```
Writes `standards/COVERAGE.md` with per-artifact status (complete / draft / stub /
absent / major-stale) and prints the top priority gaps.
