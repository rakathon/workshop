#!/usr/bin/env python3
"""
rr-standards:test-skill harness — run_skill_tests.py

Reads a JSON run manifest (produced by the rr-standards:test-skill SKILL.md),
runs with_skill and without_skill evaluations for each test case via the claude CLI,
writes workspace files, and aggregates benchmark results.

Usage:
    python3 run_skill_tests.py --manifest <path-to-run_manifest.json>

Exit codes:
    0 — completed successfully (pass or fail — verdict is in benchmark.json / ci_report.json)
    1 — system error (claude CLI not found, manifest missing, etc.)

Manifest is produced by rr-standards:test-skill SKILL.md and looks like:
{
  "skill_path": "plugins/forge/skills/adr",
  "skill_name": "forge:adr",
  "skill_md_content": "<full SKILL.md text>",
  "skill_dir": "/absolute/path/to/skill",
  "workspace_base": ".rr-standards/validate/workspace/adr/iteration-0",
  "ci_mode": false,
  "no_baseline": false,
  "reuse_from": null,
  "before_all_tests": null,
  "after_all_tests": null,
  "tests": [
    {
      "id": "conversational-trigger",
      "name": "...",
      "fixture_dir": "/absolute/path/to/fixtures/conversational-trigger",
      "artifact_file": null,
      "before_test": "git init -q\\ngit checkout -q -b main",
      "after_test": null,
      "prompt": "...",
      "prompt_baseline": "...",
      "expectations": ["..."]
    }
  ]
}
"""

import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import date
from pathlib import Path


# ---------------------------------------------------------------------------
# Hook runner
# ---------------------------------------------------------------------------

def run_hook(script: str, cwd: str, hook_name: str) -> None:
    """Write script to a temp file and execute with bash. Raises RuntimeError on failure."""
    if not script or not script.strip():
        return
    script_path = None
    try:
        fd, script_path = tempfile.mkstemp(suffix=".sh")
        with os.fdopen(fd, "w") as f:
            f.write(script)
        result = subprocess.run(
            ["bash", script_path],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            stderr = result.stderr.strip() or "(no stderr)"
            raise RuntimeError(
                f"{hook_name} hook failed (exit {result.returncode}): {stderr}"
            )
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"{hook_name} hook timed out after 120s")
    finally:
        if script_path:
            try:
                os.unlink(script_path)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Prompt builders
# ---------------------------------------------------------------------------

def resolve_skill_references(skill_md_content: str, repo_root: str, _seen: set | None = None) -> str:
    """
    Resolve backtick-quoted relative .md file references in skill_md_content by
    embedding their content inline. This prevents the executor Claude (running in
    an isolated temp directory) from attempting to read the referenced file from
    disk — which would fail because the file doesn't exist in the temp dir.

    Runs recursively so references inside embedded <skill-fragment> blocks are
    also expanded (e.g. language guide paths listed inside an impl guide).

    Replaces patterns like:
      `plugins/forge/skills/common/effort-resolution.md`
    with:
      `plugins/forge/skills/common/effort-resolution.md` (embedded below)
      <skill-fragment path="plugins/forge/skills/common/effort-resolution.md">
      ... file content ...
      </skill-fragment>
    """
    import re
    if _seen is None:
        _seen = set()

    pattern = re.compile(r'`((?:plugins|standards|languages)/[^`]+\.md)`')

    def replace_ref(match):
        rel_path = match.group(1)
        if rel_path in _seen:
            return match.group(0)  # already embedded — avoid infinite recursion
        abs_path = os.path.join(repo_root, rel_path)
        if os.path.isfile(abs_path):
            try:
                content = Path(abs_path).read_text(encoding="utf-8")
                _seen.add(rel_path)
                # Recursively resolve references inside the embedded content
                content = resolve_skill_references(content, repo_root, _seen)
                return (
                    f'`{rel_path}` (content embedded below)\n\n'
                    f'<skill-fragment path="{rel_path}">\n{content}\n</skill-fragment>'
                )
            except OSError:
                pass
        return match.group(0)  # leave unchanged if file not found

    return pattern.sub(replace_ref, skill_md_content)


def build_executor_prompt(
    skill_name: str,
    skill_md_content: str | None,
    prompt: str,
    outputs_dir: str,
    with_skill: bool,
    repo_root: str | None = None,
) -> str:
    """Build the Phase 1 executor prompt."""
    save_instruction = (
        f"\n\nSave any files you created or modified, plus a transcript.md "
        f"describing what you did and why (including any questions asked, "
        f"decisions made, or branches taken), to: {outputs_dir}"
    )
    if with_skill and skill_md_content:
        resolved_content = skill_md_content
        if repo_root:
            resolved_content = resolve_skill_references(skill_md_content, repo_root)
        return (
            f'The following skill defines how to handle {skill_name} tasks. '
            f'Follow its instructions when executing the task below.\n\n'
            f'<skill name="{skill_name}">\n{resolved_content}\n</skill>\n\n'
            f'Task:\n\n{prompt}{save_instruction}'
        )
    return f"{prompt}{save_instruction}"


def build_grader_prompt(prompt: str, outputs_dir: str, expectations: list[str]) -> str:
    """Build the Phase 2 grader prompt, embedding output file contents."""
    outputs_path = Path(outputs_dir)
    file_sections = []
    if outputs_path.is_dir():
        for f in sorted(outputs_path.iterdir()):
            if f.is_file():
                try:
                    content = f.read_text(errors="replace")
                    file_sections.append(f"### {f.name}\n```\n{content}\n```")
                except OSError:
                    file_sections.append(f"### {f.name}\n(unreadable)")

    files_block = (
        "\n\n".join(file_sections)
        if file_sections
        else "(no output files — executor produced nothing)"
    )
    expectations_block = "\n".join(f"{i + 1}. {e}" for i, e in enumerate(expectations))
    total = len(expectations)

    return f"""You are grading a skill executor's outputs against a set of expectations.

The executor was given this task:
---
{prompt}
---

The executor produced the following outputs:

{files_block}

Grade each expectation as passed or not passed based solely on the outputs above.
Do NOT re-run or re-evaluate the task yourself. Only check whether the outputs
satisfy each assertion.

Expectations to grade:
{expectations_block}

Return ONLY a JSON object — no markdown fences, no explanation, just raw JSON.
Your entire response must be parseable by json.loads() with no surrounding text.
{{
  "expectations": [{{"text": "expectation text", "passed": true, "evidence": "direct quote or observation"}}],
  "summary": {{"passed": 3, "failed": 1, "total": {total}, "pass_rate": 0.75}}
}}

Set summary.passed = count of expectations where passed=true.
Set summary.pass_rate = passed / {total}."""


# ---------------------------------------------------------------------------
# Claude CLI invocation
# ---------------------------------------------------------------------------

def run_claude(prompt: str, cwd: str | None = None, timeout: int = 420) -> str:
    """Invoke claude CLI via stdin with --print. Returns stripped stdout."""
    try:
        result = subprocess.run(
            ["claude", "--print", "--dangerously-skip-permissions"],
            input=prompt,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
        )
        if result.returncode != 0:
            stderr_preview = result.stderr[:500] if result.stderr else "(no stderr)"
            raise RuntimeError(f"claude exited {result.returncode}: {stderr_preview}")
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"claude timed out after {timeout}s")
    except FileNotFoundError:
        raise RuntimeError(
            "claude CLI not found. Ensure claude is installed and available in PATH."
        )


def parse_json_response(text: str) -> dict:
    """Extract and parse the first JSON object from claude output."""
    stripped = text.strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass
    decoder = json.JSONDecoder()
    start = stripped.find("{")
    while start != -1:
        try:
            obj, _ = decoder.raw_decode(stripped, start)
            return obj
        except json.JSONDecodeError:
            start = stripped.find("{", start + 1)
    raise ValueError(f"No valid JSON found in response: {text[:300]!r}")


# ---------------------------------------------------------------------------
# Variant runner
# ---------------------------------------------------------------------------

def run_variant(
    test: dict,
    with_skill: bool,
    skill_name: str,
    skill_md_content: str,
    variant_dir: Path,
    errors: list,
    lock: threading.Lock,
    repo_root: str | None = None,
) -> dict:
    """
    Run one variant (with_skill or without_skill) for one test.

    Lifecycle:
      1. Create temp dir
      2. Copy fixture_dir or artifact_file (if present)
      3. Create outputs/
      4. Run beforeTest hook
      5. Phase 1 — executor (claude -p)
      6. Collect outputs/ into workspace
      7. Run afterTest hook
      8. Delete temp dir
      9. Phase 2 — grader (claude -p, operates on collected workspace outputs)

    Returns a result summary dict.
    """
    test_id = test["id"]
    variant = "with_skill" if with_skill else "without_skill"
    prompt = test["prompt"] if with_skill else test["prompt_baseline"]
    expectations = test["expectations"]

    variant_dir.mkdir(parents=True, exist_ok=True)

    # Build a unique temp dir path (not yet created)
    ts = int(time.time() * 1000)
    temp_dir = Path(tempfile.gettempdir()) / f"forge-test-{ts}-{test_id}-{variant}"

    try:
        # ── Fixture setup ─────────────────────────────────────────────────
        fixture_dir = test.get("fixture_dir")
        artifact_file = test.get("artifact_file")

        if fixture_dir and Path(fixture_dir).exists():
            shutil.copytree(fixture_dir, str(temp_dir))
        else:
            temp_dir.mkdir(parents=True)
            if fixture_dir:
                with lock:
                    errors.append(f"{test_id}/{variant}: fixture_dir not found: {fixture_dir}")

        if artifact_file:
            src = Path(artifact_file)
            if src.exists():
                shutil.copy2(str(src), str(temp_dir / src.name))
            else:
                with lock:
                    errors.append(f"{test_id}/{variant}: artifact_file not found: {artifact_file}")

        outputs_dir = temp_dir / "outputs"
        outputs_dir.mkdir(exist_ok=True)

        # ── beforeTest hook ───────────────────────────────────────────────
        before_test = test.get("before_test")
        if before_test:
            run_hook(before_test, str(temp_dir), "beforeTest")

        # ── Phase 1: executor ─────────────────────────────────────────────
        exec_prompt = build_executor_prompt(
            skill_name, skill_md_content, prompt, str(outputs_dir), with_skill,
            repo_root=repo_root,
        )
        (variant_dir / "prompt.txt").write_text(exec_prompt, encoding="utf-8")

        t0 = time.monotonic()
        executor_output = run_claude(exec_prompt, cwd=str(temp_dir))
        exec_duration = time.monotonic() - t0

        # ── Collect outputs → workspace ───────────────────────────────────
        ws_outputs = variant_dir / "outputs"
        ws_outputs.mkdir(exist_ok=True)

        if outputs_dir.is_dir() and any(outputs_dir.iterdir()):
            for item in outputs_dir.iterdir():
                dst = ws_outputs / item.name
                if item.is_file():
                    shutil.copy2(str(item), str(dst))
                elif item.is_dir():
                    shutil.copytree(str(item), str(dst))
        elif executor_output:
            # Executor produced no files — save stdout as transcript fallback
            (ws_outputs / "transcript.md").write_text(executor_output, encoding="utf-8")

        # ── afterTest hook ────────────────────────────────────────────────
        after_test = test.get("after_test")
        if after_test:
            try:
                run_hook(after_test, str(temp_dir), "afterTest")
            except RuntimeError as exc:
                with lock:
                    errors.append(f"{test_id}/{variant}: {exc}")

    except RuntimeError as exc:
        # Hook failure aborts the test — mark all expectations failed
        _write_hook_failure(variant_dir, test_id, prompt, expectations, str(exc))
        with lock:
            errors.append(f"{test_id}/{variant}: {exc}")
        return {"test_id": test_id, "configuration": variant, "pass_rate": 0.0,
                "error": str(exc)}
    finally:
        shutil.rmtree(str(temp_dir), ignore_errors=True)

    # ── Phase 2: grader ───────────────────────────────────────────────────
    try:
        t1 = time.monotonic()
        grader_prompt = build_grader_prompt(prompt, str(ws_outputs), expectations)
        grader_output = run_claude(grader_prompt)
        grade_duration = time.monotonic() - t1

        grading_data = parse_json_response(grader_output)
        grading = _normalise_grading(grading_data, expectations)

    except Exception as exc:
        grading = _failed_grading(expectations, f"grader error: {exc}")
        grade_duration = 0.0
        with lock:
            errors.append(f"{test_id}/{variant} grader: {exc}")

    # ── Write workspace files ─────────────────────────────────────────────
    (variant_dir / "grading.json").write_text(
        json.dumps(grading, indent=2), encoding="utf-8"
    )
    (variant_dir / "test_metadata.json").write_text(
        json.dumps({
            "test_id": test_id,
            "test_name": test.get("name", test_id),
            "prompt": prompt,
            "assertions": expectations,
        }, indent=2),
        encoding="utf-8",
    )
    (variant_dir / "timing.json").write_text(
        json.dumps({
            "executor_duration_seconds": round(exec_duration, 1),
            "grader_duration_seconds": round(grade_duration, 1),
            "total_duration_seconds": round(exec_duration + grade_duration, 1),
        }, indent=2),
        encoding="utf-8",
    )

    return {
        "test_id": test_id,
        "configuration": variant,
        "pass_rate": grading["summary"]["pass_rate"],
    }


def _normalise_grading(data: dict, expectations: list[str]) -> dict:
    """Normalise grader JSON output into canonical grading.json shape."""
    raw = data.get("expectations", [])
    graded = []
    for i, exp in enumerate(expectations):
        if i < len(raw):
            ge = raw[i]
            graded.append({
                "text": exp,
                "passed": bool(ge.get("passed", False)),
                "evidence": str(ge.get("evidence", "")),
            })
        else:
            graded.append({"text": exp, "passed": False, "evidence": "not graded"})

    passed = sum(1 for e in graded if e["passed"])
    total = len(graded)
    return {
        "expectations": graded,
        "summary": {
            "passed": passed,
            "failed": total - passed,
            "total": total,
            "pass_rate": round(passed / total, 4) if total else 0.0,
        },
    }


def _failed_grading(expectations: list[str], reason: str) -> dict:
    """Produce an all-failed grading object for error cases."""
    return _normalise_grading(
        {"expectations": [{"text": e, "passed": False, "evidence": reason} for e in expectations]},
        expectations,
    )


def _write_hook_failure(variant_dir: Path, test_id: str, prompt: str,
                        expectations: list[str], reason: str) -> None:
    """Write a failure grading.json when a hook aborts the test."""
    variant_dir.mkdir(parents=True, exist_ok=True)
    (variant_dir / "grading.json").write_text(
        json.dumps(_failed_grading(expectations, reason), indent=2), encoding="utf-8"
    )
    (variant_dir / "test_metadata.json").write_text(
        json.dumps({"test_id": test_id, "test_name": test_id,
                    "prompt": prompt, "assertions": expectations}, indent=2),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------------
# Thread worker
# ---------------------------------------------------------------------------

def evaluate_test(
    test: dict,
    skill_name: str,
    skill_md_content: str,
    workspace_base: Path,
    no_baseline: bool,
    results: list,
    lock: threading.Lock,
    errors: list,
    repo_root: str | None = None,
) -> None:
    """Thread target: run with_skill and (optionally) without_skill for one test."""
    test_id = test["id"]
    run_dir = workspace_base / test_id

    # with_skill
    summary = run_variant(test, True, skill_name, skill_md_content,
                          run_dir / "with_skill", errors, lock, repo_root=repo_root)
    with lock:
        results.append(summary)

    # without_skill — skip if reusing prior iteration results
    without_dir = run_dir / "without_skill"
    if no_baseline and (without_dir / "grading.json").exists():
        try:
            g = json.loads((without_dir / "grading.json").read_text())
            summary = {
                "test_id": test_id,
                "configuration": "without_skill",
                "pass_rate": g["summary"]["pass_rate"],
                "reused": True,
            }
        except Exception:
            summary = {"test_id": test_id, "configuration": "without_skill",
                       "pass_rate": 0.0, "error": "reuse read failed"}
    else:
        summary = run_variant(test, False, skill_name, skill_md_content,
                              without_dir, errors, lock, repo_root=repo_root)

    with lock:
        results.append(summary)
        reused_label = " (without_skill reused)" if summary.get("reused") else ""
        print(f"  {test_id}: done{reused_label}", flush=True)


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _stddev(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = _mean(values)
    return math.sqrt(sum((v - m) ** 2 for v in values) / len(values))


def build_benchmark(
    results: list, tests: list, skill_name: str, workspace_base: Path
) -> tuple:
    """Aggregate results into benchmark.json. Returns (benchmark, with_rate, without_rate, lift, verdict, gen_lift_warn)."""
    with_results = [r for r in results if r["configuration"] == "with_skill"]
    without_results = [r for r in results if r["configuration"] == "without_skill"]

    with_rate = _mean([r["pass_rate"] for r in with_results])
    without_rate = _mean([r["pass_rate"] for r in without_results])
    lift = with_rate - without_rate
    verdict = "pass" if with_rate >= 0.80 else "fail"
    gen_lift_warn = lift < 0.20

    runs = []
    for test in tests:
        tid = test["id"]
        for cfg in ["with_skill", "without_skill"]:
            gp = workspace_base / tid / cfg / "grading.json"
            if gp.exists():
                try:
                    g = json.loads(gp.read_text())
                    runs.append({
                        "eval_id": tid,
                        "eval_name": test.get("name", tid),
                        "configuration": cfg,
                        "run_number": 1,
                        "result": {
                            "pass_rate": g["summary"]["pass_rate"],
                            "passed": g["summary"]["passed"],
                            "total": g["summary"]["total"],
                            "errors": 0,
                        },
                        "expectations": g.get("expectations", []),
                    })
                except Exception:
                    pass

    with_rates = [r["pass_rate"] for r in with_results]
    without_rates = [r["pass_rate"] for r in without_results]
    w_pct = round(with_rate * 100)
    wo_pct = round(without_rate * 100)
    lift_pct = round(lift * 100, 1)

    benchmark = {
        "run_summary": {
            "with_skill": {
                "pass_rate": {"mean": round(_mean(with_rates), 4),
                              "stddev": round(_stddev(with_rates), 4)}
            },
            "without_skill": {
                "pass_rate": {"mean": round(_mean(without_rates), 4),
                              "stddev": round(_stddev(without_rates), 4)}
            },
            "delta": {"pass_rate": f"+{lift_pct}%"},
        },
        "metadata": {
            "skill_name": skill_name,
            "timestamp": date.today().isoformat(),
            "evals_run": [t["id"] for t in tests],
            "runs_per_configuration": 1,
        },
        "notes": [
            f"with_skill pass rate:    {w_pct}%",
            f"without_skill pass rate: {wo_pct}%",
            f"lift:                    +{lift_pct}%",
            f"test-accuracy:           {'PASS' if verdict == 'pass' else 'FAIL'} "
            f"(with_rate={w_pct}% {'≥' if with_rate >= 0.80 else '<'} 80%)",
            f"generation-lift:         {'WARNING' if gen_lift_warn else 'OK'} "
            f"(lift=+{lift_pct}% {'≥' if lift >= 0.20 else '<'} 20% threshold)",
        ],
        "runs": runs,
    }
    (workspace_base / "benchmark.json").write_text(
        json.dumps(benchmark, indent=2), encoding="utf-8"
    )
    return benchmark, with_rate, without_rate, lift, verdict, gen_lift_warn


def build_ci_report(
    results: list, tests: list,
    with_rate: float, without_rate: float, lift: float,
    verdict: str, gen_lift_warn: bool,
) -> dict:
    rows = []
    for test in tests:
        tid = test["id"]
        wr = next((r for r in results if r["test_id"] == tid and r["configuration"] == "with_skill"), None)
        wor = next((r for r in results if r["test_id"] == tid and r["configuration"] == "without_skill"), None)
        rows.append({
            "test_id": tid,
            "test_name": test.get("name", tid),
            "with_skill_pass_rate": round(wr["pass_rate"], 4) if wr else 0.0,
            "without_skill_pass_rate": round(wor["pass_rate"], 4) if wor else 0.0,
            "passed": (wr["pass_rate"] if wr else 0.0) >= 0.80,
        })
    return {
        "verdict": {
            "result": verdict,
            "with_skill_pass_rate": round(with_rate, 4),
            "without_skill_pass_rate": round(without_rate, 4),
            "lift": round(lift, 4),
            "generation_lift_warning": gen_lift_warn,
        },
        "tests": rows,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(
        description="rr-standards:test-skill harness — runs skill behavioral evaluations"
    )
    parser.add_argument("--manifest", required=True, help="Path to run_manifest.json")
    args = parser.parse_args()

    manifest_path = Path(args.manifest)
    if not manifest_path.exists():
        print(f"ERROR: Manifest not found: {manifest_path}", file=sys.stderr)
        sys.exit(1)

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"ERROR: Failed to parse manifest: {exc}", file=sys.stderr)
        sys.exit(1)

    skill_name = manifest["skill_name"]
    skill_md_content = manifest["skill_md_content"]
    skill_dir = manifest["skill_dir"]
    workspace_base = Path(manifest["workspace_base"])

    # Derive repo root from manifest path — walk up to find the repo root
    # (the directory containing .git). Fall back to cwd if not found.
    repo_root: str | None = None
    search = manifest_path.resolve().parent
    for _ in range(10):
        if (search / ".git").exists():
            repo_root = str(search)
            break
        search = search.parent
    ci_mode = manifest.get("ci_mode", False)
    no_baseline = manifest.get("no_baseline", False)
    tests = manifest["tests"]
    before_all = manifest.get("before_all_tests")
    after_all = manifest.get("after_all_tests")

    _out = sys.stderr if ci_mode else sys.stdout

    # Pre-flight: verify claude CLI
    try:
        subprocess.run(["claude", "--version"], capture_output=True, check=True, timeout=10)
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("ERROR: claude CLI not found or not working. Ensure it is installed and in PATH.",
              file=sys.stderr)
        sys.exit(1)

    # beforeAllTests hook
    if before_all:
        print("Running beforeAllTests...", file=_out, flush=True)
        try:
            run_hook(before_all, skill_dir, "beforeAllTests")
        except RuntimeError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            sys.exit(1)

    # Reuse prior without_skill: copy results from previous iteration
    reuse_from = manifest.get("reuse_from")
    if no_baseline and reuse_from:
        prev = Path(reuse_from)
        for test in tests:
            tid = test["id"]
            src = prev / tid / "without_skill"
            dst = workspace_base / tid / "without_skill"
            if src.exists() and not dst.exists():
                shutil.copytree(str(src), str(dst))

    n = len(tests)
    reused = sum(
        1 for t in tests
        if no_baseline and (workspace_base / t["id"] / "without_skill" / "grading.json").exists()
    )
    n_evals = n * 2 - reused
    print(f"Running {n} test(s) ({n_evals} evaluation(s))...", file=_out, flush=True)

    results: list = []
    errors: list = []
    lock = threading.Lock()

    threads = [
        threading.Thread(
            target=evaluate_test,
            args=(test, skill_name, skill_md_content, workspace_base,
                  no_baseline, results, lock, errors),
            kwargs={"repo_root": repo_root},
            daemon=True,
        )
        for test in tests
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    if errors:
        print(f"\n{len(errors)} error(s):", file=sys.stderr)
        for e in errors:
            print(f"  {e}", file=sys.stderr)

    # afterAllTests hook
    if after_all:
        print("Running afterAllTests...", file=_out, flush=True)
        try:
            run_hook(after_all, skill_dir, "afterAllTests")
        except RuntimeError as exc:
            # afterAllTests failure is a warning, not fatal
            print(f"WARNING: afterAllTests hook failed: {exc}", file=sys.stderr)

    # Aggregate
    try:
        _, with_rate, without_rate, lift, verdict, gen_lift_warn = build_benchmark(
            results, tests, skill_name, workspace_base
        )
    except Exception as exc:
        print(f"ERROR: Failed to aggregate results: {exc}", file=sys.stderr)
        sys.exit(1)

    # Summary (stderr in CI mode so stdout stays clean)
    print(f"\nResults:", file=_out, flush=True)
    print(f"  with_skill pass rate:    {round(with_rate * 100)}%", file=_out)
    print(f"  without_skill pass rate: {round(without_rate * 100)}%", file=_out)
    print(f"  lift:                    +{round(lift * 100, 1)}%", file=_out)
    print(f"  test-accuracy:           {'PASS' if verdict == 'pass' else 'FAIL'}", file=_out)
    if gen_lift_warn:
        print("  generation-lift:         WARNING (lift < 20%)", file=_out)
    else:
        print("  generation-lift:         OK", file=_out)

    # CI report
    if ci_mode:
        ci_report = build_ci_report(
            results, tests, with_rate, without_rate, lift, verdict, gen_lift_warn
        )
        (workspace_base / "ci_report.json").write_text(
            json.dumps(ci_report, indent=2), encoding="utf-8"
        )

    sys.exit(0)


if __name__ == "__main__":
    main()
