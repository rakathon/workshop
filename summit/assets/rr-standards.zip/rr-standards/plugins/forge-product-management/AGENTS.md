# forge-product-management Plugin — Agent Navigation Guide

Read this file before invoking any PM skill in this plugin. It is the authoritative source for answering "what skill do I need?" for any product management task.

---

## 1. Plugin Purpose and Target Audience

This plugin serves **product managers**. It provides skills for product strategy, discovery, roadmapping, competitive research, requirements authoring, and outcome measurement.

It is **not** an engineering plugin. Contrast with `plugins/forge/` (engineering-facing), which provides skills for implementation planning, code review, deployment, and architecture work.

The most important distinction for routing:

- `forge:elaborate` — engineering requirements deep-dive; **lives in `plugins/forge/`**, not here. Use it after a PRD is written and an effort is active, when engineers need to expand business requirements into technical requirements.
- `forge:prd` — PM-authored PRD; **lives in this plugin**. Use it inside a `forge:effort` to write the three-file PRD before handing off to engineering.

If a user is a product manager asking about strategy, discovery, roadmapping, or requirements, their work happens here. If they are an engineer elaborating on requirements, they use `plugins/forge/`.

---

## 2. Directory Structure

```
plugins/forge-product-management/
├── AGENTS.md                        # This file — first file Claude reads in this plugin
├── README.md                        # Human-facing docs: skill list, tool deps, workarounds
├── package.json                     # Plugin manifest (name, version, author, license)
└── skills/
    ├── common/                      # Shared environment and plugin-root resolution fragments
    ├── competitive-brief/           # forge:competitive-brief — structured competitor analysis brief
    ├── prd/                         # forge:prd — three-file PRD authoring (prd.md, business.md, user-stories.md)
    ├── product/                     # forge:product — create and manage product directories
    ├── product-brainstorm/          # forge:product-brainstorm — facilitated brainstorming with PM frameworks
    ├── product-brief/               # forge:product-brief — initiative briefs linking discovery to effort
    ├── product-discover/            # forge:product-discover — Torres CDH discovery loop (OST, assumptions, interviews)
    ├── product-outcome/             # forge:product-outcome — post-launch outcome measurement
    ├── product-roadmap/             # forge:product-roadmap — outcome-based roadmap (create + update modes)
    ├── product-scorecard/           # forge:product-scorecard — North Star / L1 / L2 scorecard and trend review
    ├── product-strategy/            # forge:product-strategy — full strategy document (Rumelt + Martin + OKRs)
    ├── product-synthesis/           # forge:product-synthesis — structured research synthesis from corpora
    └── product-vision/              # forge:product-vision — stable product vision document (vision.md)
```

---

## 3. Full Skill Catalog

| Skill | What it does | What it produces | Lifecycle stage |
|---|---|---|---|
| `forge:product` | Creates a product directory and AGENTS.md navigation guide under `.forge/products/<name>/` | `.forge/products/<name>/AGENTS.md`, `deployables.md` | Setup |
| `forge:product-vision` | Produces or rewrites `vision.md` via ingest → interview → write; detects anti-patterns (feature framing, business goals, technology framing); integrates with `forge:product-strategy` | `vision.md` | Setup / Ongoing |
| `forge:competitive-brief` | Researches competitors and writes a structured brief; uses web search when available | `competitive/<brief>.md` | Pre-strategy |
| `forge:product-synthesis` | Synthesizes research corpora into findings and personas | `research/synthesis.md` | Pre-strategy |
| `forge:product-discover` | Runs the Torres Continuous Discovery Habits loop — outcomes, opportunities, OST, assumptions, interview snapshots | `discovery/ost.md`, `discovery/assumptions.md`, `discovery/interviews/` | Pre-strategy (recurring) |
| `forge:product-strategy` | Guides strategy creation, refresh, or pivot using Rumelt + Roger Martin + Spotify DIBB + North Star + Bungay; cascades OKRs and scaffolds efforts | `strategy.md`, `okrs.md`, `metrics.md`, `references/` | Strategy |
| `forge:product-roadmap` | Creates or updates an outcome-based roadmap from a confirmed strategy | `roadmap.md` | Strategy / Ongoing |
| `forge:product-scorecard` | North Star / L1 / L2 scorecard and trend analysis; reads `metrics.md` as input contract; same-day re-runs append a timestamped section | `metrics/scorecards/YYYY-MM-DD.md` | Ongoing |
| `forge:product-brainstorm` | Facilitated ideation using PM frameworks; thinking-partner mode; no fixed artifact | Session output (not persisted unless PM requests) | Any stage |
| `forge:product-brief` | Scopes a validated initiative for handoff to engineering; one brief per coherent roadmap item | `briefs/<initiative-slug>.md` | Pre-effort |
| `forge:prd` | Writes the three-file PRD inside an active `forge:effort`; hands off to engineering via `forge:elaborate` | `requirements/prd.md`, `requirements/business.md`, `requirements/user-stories.md` | Inside effort |
| `forge:product-outcome` | Post-launch outcome measurement against PRD goals; closes the measurement loop; prompts refresh of discovery or strategy | `outcomes/<effort-id>-YYYY-MM-DD.md` | Post-launch |

---

## 4. PM Artifact Lifecycle

```mermaid
flowchart TD
    FP["forge:product"]

    subgraph disc["Discovery — optional, iterative at any stage"]
        FCB["forge:competitive-brief"]
        FPSY["forge:product-synthesis"]
        FPD["forge:product-discover"]
    end

    FPV["forge:product-vision"]
    FPST["forge:product-strategy"]
    FPR["forge:product-roadmap"]
    FPSC["forge:product-scorecard"]

    subgraph effort["Effort-level — .forge/efforts/id/"]
        FPBR["forge:product-brief"]
        FE["forge:effort"]
        FPRD["forge:prd"]
        FEL["forge:elaborate (plugins/forge/)"]
        EG(["effort graduates"])
    end

    subgraph postlaunch["Post-launch"]
        FPOU["forge:product-outcome"]
        DISC_R["forge:product-discover (refresh)"]
        STRAT_R["forge:product-strategy (refresh / pivot)"]
    end

    FP --> FPV
    FP -.->|optional| disc
    disc -.->|informs vision| FPV
    FCB -->|feeds strategy| FPST
    FPSY -->|feeds strategy| FPST
    FPD -->|feeds strategy| FPST
    FPV --> FPST
    FPST --> FPR
    FPST --> FPSC
    FPSC -.->|periodic refresh| FPST
    FPR --> FPBR
    FPBR --> FE
    FE --> FPRD
    FPRD -->|engineering handoff| FEL
    FEL --> EG
    EG --> FPOU
    FPOU --> DISC_R
    FPOU --> STRAT_R
```

---

## 5. Naming Convention Key Rules

Full rationale and decision log: `spec/naming-conventions.md` in the product-management effort.

### Primary pattern

All skills in this plugin use the **`forge:product-*`** prefix, with two named exceptions. This signals PM-audience ownership and product-level artifact scope consistently across the plugin.

| Skill | Primary output |
|---|---|
| `forge:product-strategy` | `strategy.md`, `okrs.md`, `metrics.md` |
| `forge:product-roadmap` | `roadmap.md` |
| `forge:product-brief` | `briefs/<initiative-slug>.md` |
| `forge:product-scorecard` | `metrics/scorecards/YYYY-MM-DD.md` |
| `forge:product-discover` | `discovery/ost.md`, `discovery/assumptions.md`, `discovery/interviews/` |
| `forge:product-synthesis` | `research/synthesis.md` |
| `forge:product-brainstorm` | Session output (persisted on PM request) |
| `forge:product-outcome` | `outcomes/<effort-id>-YYYY-MM-DD.md` |

### Named exceptions

| Skill | Reason |
|---|---|
| `forge:product` | Entry-point command — analogous to `forge:effort`, `forge:init`. The bare noun is intentional. |
| `forge:prd` | Industry-standard term. Universally understood by PMs. A prefix would obscure, not clarify. |
| `forge:competitive-brief` | Domain compound noun — the full term is the artifact type. |

### Reserved bare names

The following names are **not** claimed by this plugin. They are reserved as potentially cross-cutting:

- `forge:brainstorm` → use `forge:product-brainstorm`
- `forge:discover` → use `forge:product-discover`
- `forge:research` → use `forge:product-synthesis`

---

## 6. Handoff Points Between Skills

```mermaid
flowchart TD
    subgraph disc["Discovery — optional, iterative at any stage"]
        FCB["forge:competitive-brief"]
        FPSY["forge:product-synthesis"]
        FPD["forge:product-discover"]
    end

    FPV["forge:product-vision"]
    FPST["forge:product-strategy"]
    FPR["forge:product-roadmap"]
    FPSC["forge:product-scorecard"]
    FPBR["forge:product-brief"]
    FE["forge:effort"]
    FPRD["forge:prd"]
    FEL["forge:elaborate (plugins/forge/)"]
    EG(["effort graduates"])
    FPOU["forge:product-outcome"]
    DISC_R["forge:product-discover (refresh)"]
    STRAT_R["forge:product-strategy (refresh / pivot)"]

    disc -.->|informs vision| FPV
    FPV --> FPST
    FCB -->|feeds strategy| FPST
    FPSY -->|feeds strategy| FPST
    FPD -->|feeds strategy| FPST
    FPST --> FPR
    FPST --> FPSC
    FPSC -.->|periodic refresh| FPST
    FPR --> FPBR
    FPBR --> FE
    FE --> FPRD
    FPRD -->|engineering handoff| FEL
    FEL --> EG
    EG --> FPOU
    FPOU --> DISC_R
    FPOU --> STRAT_R
```

### Explicit handoff contracts

| From | To | Trigger |
|---|---|---|
| `forge:product` | `forge:product-vision` | Product directory created; vision is the recommended next step |
| `forge:product` | `forge:competitive-brief` | Optional: run before vision when market landscape is unknown |
| `forge:product` | `forge:product-synthesis` | Optional: run before vision when raw research already exists |
| `forge:product` | `forge:product-discover` | Optional: run before vision to validate whether the problem exists |
| `forge:competitive-brief` | `forge:product-vision` | Competitive context informs vision framing (iterative — can precede or follow) |
| `forge:product-synthesis` | `forge:product-vision` | Research findings inform vision framing (iterative — can precede or follow) |
| `forge:product-discover` | `forge:product-vision` | Discovery insights inform vision framing (iterative — can precede or follow) |
| `forge:product-vision` | `forge:product-strategy` | Vision written; strategy should be built to serve it |
| `forge:product-vision` | `forge:product-strategy` (pivot) | Vision updated; strategy almost certainly needs to be rebuilt |
| `forge:product-discover` | `forge:product-brief` | Opportunity validated; PM ready to scope an initiative |
| `forge:product-strategy` | `forge:product-roadmap` | OKRs confirmed; coherent actions list finalized |
| `forge:product-roadmap` | `forge:product-brief` | Roadmap item promoted to active initiative |
| `forge:product-brief` | `forge:effort` | Brief approved; ready for engineering pickup |
| `forge:prd` | `forge:elaborate` | PRD complete; engineering begins requirements deep-dive |
| `forge:product-outcome` | `forge:product-discover` | "What should change in discovery?" closing prompt |
| `forge:product-outcome` | `forge:product-strategy` | "What should change in strategy?" closing prompt |

---

## 7. Tool Dependencies Per Skill

Per ADR-005: skills name their required tools explicitly and define a manual fallback for when those tools are unavailable. There is no connector abstraction — if a tool is not present in the Claude Code session, the skill falls back to asking the PM to paste the relevant context.

| Skill | Tools | Fallback when unavailable |
|---|---|---|
| `forge:competitive-brief` | Web search | PM pastes competitor research |
| `forge:product-synthesis` | Web search | PM pastes research corpus |
| `forge:product-discover` | Web search | PM pastes interview notes |
| `forge:product-strategy` | Atlassian MCP, Annalise/Snowflake, web search | PM pastes Jira/Confluence context and metric snapshots |
| `forge:product-scorecard` | Annalise/Snowflake | PM pastes metric snapshots |
| `forge:prd` | Atlassian MCP (read epic and linked issues) | PM pastes Jira context |
| `forge:product-roadmap` | None | — |
| `forge:product-brief` | None | — |
| `forge:product-brainstorm` | None | — |
| `forge:product` | None | — |
| `forge:product-vision` | None (URL fetch via WebFetch if URL provided as input) | PM pastes the document content directly |
| `forge:product-outcome` | Annalise/Snowflake, Atlassian MCP (Jira completion status) | PM pastes actuals and completion data |
