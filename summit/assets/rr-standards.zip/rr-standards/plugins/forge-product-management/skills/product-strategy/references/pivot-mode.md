# Pivot Mode Procedure

Activated when `mode = pivot`. Wraps around the main create flow (Steps 2–8).

**PV0 — Vision check**

Check for `<product_dir>/vision.md`:

```bash
[ -f "<product_dir>/vision.md" ] && echo "present" || echo "absent"
```

If **present**, read it and extract the vision statement. Ask:
> "A strategy pivot sometimes signals a vision change too. Does the fundamental
> reason this product exists still hold — the transformation you're creating for
> [target users] — or has that changed?"

- **Vision unchanged:** proceed to PV1. `vision.md` is not touched.
- **Vision has changed:** STOP immediately.
  > "Update your vision first: run `forge:product-vision`, then re-run
  > `forge:product-strategy` in pivot mode. The new strategy needs to flow
  > from the new vision."
  End the skill. Do not archive anything.

If **absent:** proceed to PV1 with no change.

---

**PV1 — Archive prior strategy**

Before writing anything new:
1. Determine archive path: `<product_dir>/strategy-archive/strategy-<YYYY-MM-DD>.md`
2. If a file already exists at that path, append a counter: `strategy-<YYYY-MM-DD>-2.md`
3. Archive: copy `strategy.md` → archive path
4. Archive: copy `okrs.md` → `strategy-archive/okrs-<YYYY-MM-DD>.md`
5. Archive: copy `roadmap.md` → `strategy-archive/roadmap-<YYYY-MM-DD>.md` (if it exists)
6. Archive: copy `metrics.md` → `strategy-archive/metrics-<YYYY-MM-DD>.md` (if it exists)
7. Note: the `references/` directory is NOT archived — research accumulates across strategy generations

The pivot decision question for `metrics.md` is asked at Step 6.2.0 (in metrics-hierarchy.md). If the PM
answers "No" (North Star unchanged), `metrics.md` is NOT archived — it is updated in-place. If the PM
answers "Yes" (North Star changes), it is archived in Step 6.2.0 before the full metrics branch runs.
Do not archive `metrics.md` again here if it has already been archived at 6.2.0.

**PV2 — Run full create session**

Run Steps 2–8 of the main flow as for create mode. Before the diagnosis phase, brief the PM:
> "I've archived your prior strategy at `strategy-archive/strategy-<date>.md`.
> The prior strategy will inform what not to repeat, but won't constrain the new diagnosis.
> Let's start fresh."

Read the archived strategy and use it as negative context: if the diagnosis or pillars
closely resemble the prior strategy's, surface this:
> "This direction is similar to what was tried before. Is that intentional, or should
> we explore a different framing?"

**PV3 — History section**

After the new `strategy.md` is written, add a `## History` section linking to all
archived versions:
```markdown
## History
| Version | Date | Notes |
|---------|------|-------|
| [strategy-<date>.md](strategy-archive/strategy-<date>.md) | <date> | Prior strategy (pivoted) |
```
