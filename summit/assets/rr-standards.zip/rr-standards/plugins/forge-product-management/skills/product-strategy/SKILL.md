---
name: forge:product-strategy
description: >
  Guides a product manager through producing a structured product strategy document
  using an opinionated methodology (Rumelt + Roger Martin + Spotify DIBB + North Star
  + Bungay). Handles create, refresh, and pivot modes. Performs autonomous market and
  competitor research, queries internal data via Annalise/Snowflake when available,
  enforces a quality gate on the diagnosis, cascades OKRs, generates a metric hierarchy,
  and scaffolds Forge efforts for each coherent action. Roadmap creation is delegated to
  forge:product-roadmap.
when_to_use: >
  Trigger on: "I need to build a product strategy", "let's do strategy", "help me think
  through our product strategy", "create a strategy for my product", "build a strategy
  doc", "I want to define our strategic direction", "quarterly strategy planning",
  "we need a strategy", "forge:product-strategy", or any time a PM wants to produce
  a structured strategy document grounded in data and aligned to company OKRs.
argument-hint: "[product-name]"
arguments: [product_name]
agent-type: orchestrator
---

# forge:product-strategy

Guides a product manager through a structured product strategy document with three
components: diagnosis (the single most critical challenge), guiding policy (3–5
strategic pillars), and coherent actions (initiatives that translate the policy into
execution). Produces `strategy.md`, `okrs.md`, and `metrics.md` under
`<product_dir>/`, then hands off to `forge:product-roadmap`.

Sessions are interruptible. State is persisted to `strategy-session.md` at every
step and restored on re-invocation.

---

## Hard Constraints (Never Violated)

**1. Never write roadmap.md.** When the PM says to build the roadmap, direct them to
run `forge:product-roadmap`. Do not write, draft, sketch, or outline roadmap content
under any circumstances.

**2. Never advance past a failing diagnosis gate.** Do not begin Guiding Policy until
all three diagnosis quality tests pass (specificity, evidence, singularity — see Step 3.4).

**3. Never write artifacts without PM confirmation.** Present each artifact to the PM
before writing to disk.

---

## Reference Files

Reference files live in `references/` alongside this SKILL.md.
Load each file just-in-time — immediately before the phase where it is needed.

| File | Load when |
|---|---|
| `references/mode-create.md` | `mode = create`, before Step 2 |
| `references/refresh-mode.md` | `mode = refresh`, immediately after confirmed |
| `references/pivot-mode.md` | `mode = pivot`, immediately after confirmed |
| `references/interview-playbook.md` | Phase by phase: before Step 3 (Ph 0–1), Step 4 (Ph 2), Step 5 (Ph 3), Step 6.1 (Ph 4) |
| `references/diagnosis-gate.md` | Step 3.4 — full gate procedure and fallback prompts |
| `references/metrics-hierarchy.md` | Step 6.2 — full metric derivation procedure |
| `references/output-templates.md` | Step 7 — before writing strategy.md and okrs.md |
| `references/session-state.md` | Step 1.5 — before writing the initial strategy-session.md |
| `references/resume-procedure.md` | Step 1.2 — when an existing session is found |
| `references/pause-procedure.md` | On first pause trigger |
| `references/vision-context.md` | Step 1.4a — vision.md read and alignment check procedure |

---

## Step 0: Environment Detection

Load `skills/common/environment.md` and apply it now.

Set `env_mode` and `products_root` as defined in that fragment.
These variables are used throughout all subsequent steps — never hardcode `.forge/products/` or `./` paths directly.

---

## Step 1: Identify Product and Mode

**1.1 — Product name**

If a product name was provided as an argument, use it. Otherwise ask:
> "Which product are we building a strategy for?"

Set `product_name`. Set `product_dir = <products_root>/<product_name>/`.

**1.2 — Check for existing session (resume)**

Check for `<product_dir>/strategy-session.md`.

If found:
1. Read its frontmatter: `product`, `stage`, `mode`, `paused_at`, `awaiting`
2. Inform the PM:
   > "I found a paused strategy session for **<product>** paused on <paused_at date>.
   > Stage: **<stage>** | Mode: **<mode>** | Awaiting: <awaiting>.
   > Do you want to resume, or start a new session?"
3. If resume → read `references/resume-procedure.md` and follow it. **Stop here.**
4. If new session → proceed to Step 1.3.

If not found → proceed to Step 1.3.

**1.3 — Mode detection**

Check whether `<product_dir>/strategy.md` exists.

- **Absent** → `mode = create`. Inform PM: "Starting a new strategy session."
  Proceed to Step 1.4.
- **Present** → read it, extract creation date and last_refreshed date. Ask:
  > "I found an existing strategy for **<product_name>** last updated <date>.
  > Are you:
  > (1) **Refreshing** — same direction, updating for changed conditions
  > (2) **Pivoting** — conditions materially changed or prior strategy failed?"

  - `mode = refresh` → read `references/refresh-mode.md` now; follow it instead of Steps 2–9.
  - `mode = pivot` → read `references/pivot-mode.md` now; it wraps Steps 2–9.

**1.4a — Read vision.md (all modes)**

Read `references/vision-context.md` and follow it.

---

**1.4 — Verify product directory exists**

Check whether `<product_dir>` exists (set in Step 1.1 using `products_root` from Step 0).

If it does **NOT** exist, **HARD STOP**:
> "No product directory found for **<product_name>**. `forge:product-strategy` requires
> the product to be registered first.
>
> Run `/forge:product <product_name>` to create it, then re-invoke `forge:product-strategy`."

Do not create the directory. Do not proceed. End the skill.

If it **does** exist, ensure any missing subdirectories exist. In Forge mode, run:
```bash
mkdir -p <product_dir>/references
mkdir -p <product_dir>/strategy-archive
```
In plain mode (no terminal available), create directories implicitly by writing the
first file into them — the Write tool creates parent directories automatically.

**1.5 — Write initial strategy-session.md**

Read `references/session-state.md`. Write `<product_dir>/strategy-session.md` with
`stage: init`, `mode: <mode>`, `paused_at: <now>`, `awaiting: nothing`.
Update this file at the start of every step.

---

## Steps 2–9: Create Mode

Read `references/mode-create.md` and follow it from Step 2 through Step 9.

Key behaviors inlined here for fast access:

**Input gathering (Step 2):**
- Ask for company OKRs (file path, URL, or paste)
- Ask for product maturity: established (existing users/metrics) or new (pre-launch)
- Detect PLG: ask "Does your product grow through self-serve adoption — freemium,
  viral signup, or bottom-up trial?" Set `is_plg = true | false`.
  If `is_plg = true`: confirm whether GTM is bottom-up (users adopt → budget follows)
  or top-down (executive buyer); flag that a PLG lens will be applied to the diagnosis
- Check Annalise/Snowflake MCP availability; set `data_lake_available = true | false`

**Diagnosis quality gate (Step 3.4):**

Three tests must all pass before advancing to Guiding Policy:
1. **Specificity** — concrete barrier, not a goal. ❌ "grow faster" ✅ "14-day time-to-first-redemption 3× benchmark"
2. **Evidence** — at least one quantitative signal (qualitative market signal acceptable for new products).
3. **Singularity** — ONE root challenge, not a list.

On any failure, offer a concrete improved restatement grounded in gathered research.
Do not just explain what is wrong — always provide an improved version.
Read `references/diagnosis-gate.md` for the full procedure and fallback prompts.

**Metric hierarchy (Step 6.2):**

After OKRs are confirmed:
- Read confirmed OKRs and derive a North Star candidate from the key results
- Present it: "Based on your OKRs, your North Star is likely **[candidate]**..."
- Do NOT ask "What is your North Star?" as an open question — propose first, then confirm
- Read `references/metrics-hierarchy.md` for the full L1/L2 derivation procedure

**Roadmap handoff (Step 9):**

When stage = `roadmap` or PM says to build the roadmap, confirm the completed artifacts
and hand off:
> "Strategy session complete. Artifacts written:
> - `strategy.md` — diagnosis, guiding policy, strategic exclusions, coherent actions
> - `okrs.md` — product-level OKRs cascaded from company OKRs
> - `metrics.md` — North Star, L1 inputs, and L2 diagnostic metrics
>
> Run `/forge:product-roadmap` to build the roadmap."

**Do NOT write roadmap.md. Do NOT generate roadmap content.**

---

## Pause Handling

On any pause (automatic or PM-initiated):
1. Update `strategy-session.md`: set `stage` to current stage, `awaiting` to what is needed
2. Write confirmed-but-unwritten content to the `strategy-session.md` body
3. Report:
   > "Session paused. State saved to `strategy-session.md`.
   > Stage: <stage> | Awaiting: <awaiting>
   > Re-invoke `forge:product-strategy` to resume."

No partial artifacts are written to `strategy.md`, `okrs.md`, or `metrics.md` during
a pause — only `strategy-session.md` is updated.

Read `references/pause-procedure.md` for the complete pause handling procedure.
