# Vision Context Procedure

Loaded at Step 1.4a of `forge:product-strategy`. Applies in all modes (create,
refresh, pivot).

---

## Step 1.4a — Read vision.md

Check for `<product_dir>/vision.md`:

```bash
[ -f "<product_dir>/vision.md" ] && echo "present" || echo "absent"
```

If **present:**
- Read it. Extract the `## Vision Statement` section.
- Store as `vision_statement`.
- Display before the session begins:
  > "Product vision: [vision_statement]
  > The strategy we build should serve this transformation."

If **absent:**
- Ask the PM two questions to establish working vision context:
  1. "Who is the primary user this product is for?"
  2. "What changes for them — in their work or life — because this product exists?"
- Store answers as `working_vision_context`. Use in place of `vision_statement`
  throughout the session wherever vision alignment checks apply.
- Display once at session end:
  > "You don't have a `vision.md` for `<product_name>` yet. Consider running
  > `forge:product-vision` to formalise the north star we've been working from."

---

## Vision Alignment Check

Used during Step 5 (coherent actions) when `vision_statement` or
`working_vision_context` is set.

For each proposed coherent action, ask internally: does this action obviously
connect to the vision transformation? If not, surface a non-blocking check:
> "This action — [action] — doesn't obviously connect to [vision_statement].
> Is that intentional, or should we reconsider it?"

The PM can proceed regardless. This is a visible alignment check, not a gate.
