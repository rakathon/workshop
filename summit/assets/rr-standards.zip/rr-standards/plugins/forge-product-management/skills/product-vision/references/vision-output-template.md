# vision.md Output Template

Use this template when writing `<product_dir>/vision.md` in Phase 3.

Substitute all `<placeholder>` values. Do not leave placeholder text in the
output — every section must contain real content confirmed during the interview.

---

```markdown
# Vision — <product_name>

*Stable product identity. Update only when the fundamental nature of the product
changes — not when strategy, roadmap, or scope evolves.*

*Time horizon: <N> years (<start_year>–<end_year>)*

---

## Vision Statement

<1–3 sentences. Solution-free. Customer-transformation-focused. Memorable enough
to repeat from memory. No features, no business goals, no technology specifics.>

---

## Target Beneficiaries

<Who this product is for. Primary user first — describe them in context, not just
by job title. Note any distinct buyer separately if applicable. 2–4 sentences.>

---

## The Transformation

<How the target user's work or life changes because this product exists.
Human-outcome framing, not feature framing.

A "before and after" structure works well:

**Before:** [What the user struggles with today — the friction, cost, or limitation
that this product resolves.]

**After:** [What becomes true for the user when this product exists and works as
intended. What they can do, stop doing, or do differently.]>

---

## What This Is Not

<Explicit scope constraints. What this product deliberately does not do or be.
At least 2–3 items. Use this list as a decision filter — if a proposed initiative
doesn't connect to the vision and isn't excluded here, it needs justification.>

- Not [X] — [brief reason this is out of scope]
- Not [Y] — [brief reason]
- Not [Z] — [brief reason]

---

## Durability Note

<What would need to fundamentally change for this vision to no longer be the right
destination. This is not a list of risks to the strategy — it is the conditions
under which the vision itself would need to be reconsidered.

Example conditions: the underlying technology assumption fails; the target user's
role or workflow changes fundamentally; a major new insight reveals the transformation
is wrong or too narrow.>

Expected stable horizon: <N> years.

---

## Change History

| Date | What changed | Why |
|------|-------------|-----|
| <YYYY-MM-DD> | <Initial vision / specific change description> | <Session context, key decision, or reason for update. Note if solo-authored.> |
```

---

## Section Guidance

### Vision Statement
- Target: 1–3 sentences, ≤50 words
- Test: can someone repeat it from memory after one reading?
- Test: does it describe the user's transformation, not the product's features?
- Test: would it still be true if the implementation changed completely?

### Target Beneficiaries
- Primary user first — the person whose daily work changes
- Buyer only if distinct from user (e.g. manager buys, analyst uses)
- Specific enough to be useful as a decision filter: not "software engineers" but
  "software engineers at companies with established code review workflows"

### The Transformation
- Before/after structure is optional but usually the clearest
- Human-outcome language: what the user stops struggling with, or starts being
  able to do
- No features, no product capabilities, no technology specifics
- If the vision statement is already vivid, this section adds depth — it shouldn't
  just restate the vision in more words

### What This Is Not
- Minimum 2–3 items — a single exclusion is not enough to bound the scope
- Each item should be something this product could plausibly be confused with or
  expanded toward
- Phrase as "Not [X]" with a brief reason — the reason is what makes it a real
  constraint, not just a disclaimer

### Durability Note
- Distinguish vision durability from strategy durability: strategy changes frequently;
  vision should last 3–5+ years
- The note describes what would invalidate the *destination*, not what would
  require a different *route*
- Include the expected stable horizon as a concrete year range

### Change History
- Initial row: date of first write, "Initial vision", and context (session
  participants if collaborative, "solo-authored" note if applicable)
- Subsequent rows: one row per `forge:product-vision` run that produced a material
  change — not minor edits
- "What changed" should be specific enough to understand the direction of change
  without reading the full document
