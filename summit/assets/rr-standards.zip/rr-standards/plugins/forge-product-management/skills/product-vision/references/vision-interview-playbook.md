# Vision Interview Playbook

Full question set, recommended answers, anti-pattern signals, and redirect phrases
for the Phase 2 interview in `forge:product-vision`.

**Skip rule:** For every question, check first whether the input document (or prior
answers in this session) already provides a clear, well-formed answer. If it does,
do not ask the question — use the existing answer and move on. Only ask when the
content is absent, ambiguous, or misframed.

---

## Block A — Core Transformation

### Question 1: Who is this product for?

**Skip if:** The input document clearly names a specific primary user with enough
context to ground the transformation (not just a job title).

**Goal:** Identify the primary user (the person whose daily work or life changes) and
any distinct buyer if applicable.

**Recommendation rule:** If the PM has already described users in any input document
or earlier in the conversation, name them directly:
> "Based on what you've shared, the primary user appears to be [X] — someone who
> [brief description of their context]. Is that right, or is there a more specific
> segment to name?"

**Buyer distinction:** If the buyer and user are different (e.g. a manager buys,
an analyst uses), note both but keep the primary user first:
> "It sounds like [buyer] purchases this, but [user] is the person whose daily work
> changes. Is that right? The vision should be written from [user]'s perspective."

**Watch for:** Job titles as stand-ins for real user descriptions. Push toward
context: not "software engineers" but "software engineers who are blocked by manual
review cycles." The specificity matters for grounding the transformation.

---

### Question 2: What changes for them because this product exists?

**Skip if:** The input document contains a clear transformation statement that is
solution-free, customer-outcome-focused, and passes the anti-pattern check below.

**Goal:** The heart of the vision. A concrete, human-outcome statement of what the
target user stops struggling with, or starts being able to do, because this product
exists. Solution-free.

**Recommendation rule:** Propose a transformation candidate based on what is known:
> "Based on what you've described, the transformation seems to be: [candidate].
> Does that capture it, or is there a more fundamental change you're aiming for?"

**If the PM answers with features or capabilities:**
> "That describes what the product does. What I'm after is the human outcome — what
> does [user] stop struggling with, or become able to do, that they couldn't before?"

**If the PM is stuck:** Offer Moore's template as a scaffold (see SKILL.md Step 2.3).
After the template is filled in, distill it:
> "The core of that is [extracted transformation]. Can we restate the vision around
> that, without the positioning language?"

**Strong transformation examples:**
- "Every book ever printed in any language, all available in 60 seconds." (Kindle)
- "Create economic opportunity for every member of the global workforce." (LinkedIn)
- "Every person in the organization can delegate any repeatable task to an agent
  that knows exactly how the company does it." (Forge)

**Weak transformation signals to push past:**
- Any sentence starting with "We will build..." → feature framing
- Any sentence focused on the company's outcomes, not the user's → business framing
- Generic improvement language ("better", "faster", "simpler") with no concrete
  picture of what better/faster/simpler means for the user

---

### Question 3: What problem or friction exists today?

**Skip if:** The input document gives enough "before" context to make the
transformation vivid without elaboration.

**Goal:** "Before" context to sharpen the transformation. Not a full problem
statement — just enough to make the "after" vivid.

**Recommendation rule:** Propose based on what is known:
> "Right now, [user] has to [painful thing] because [root cause]. Is that the core
> friction this product resolves, or is there something more fundamental?"

Keep this brief. One or two sentences is enough. The transformation section of
`vision.md` uses this as context, but the vision statement itself should not read
like a problem description.

---

## Anti-Pattern Detection (After Block A)

Run this check after Block A before moving to Block B. Assemble a draft vision
statement from the Block A answers and check for each pattern.

### Anti-pattern table

| Pattern | Signal phrases | What to say |
|---|---|---|
| **Feature framing** | "will provide", "includes X feature", "supports Y workflow", "enables users to use Z", "has a dashboard for" | "That describes what the product does. What changes for [user] as a result?" |
| **Business metric framing** | Revenue targets, cost figures, adoption percentages, budget numbers, ROI language | "That's a business goal — it describes the return for the company, not the change for the user. A vision describes the user's transformation." |
| **Technology framing** | Specific stack names (React, Kubernetes, GPT-4), architecture patterns, platform names as the *focus* of the statement | "That describes how it's built. What does [user] experience differently because of it?" |
| **Solution specificity** | Names a specific workflow step, UI pattern, or mechanism as the core of the vision | "That's a design decision — it could change completely while the vision stays the same. What's the underlying transformation that any implementation of this would produce?" |
| **Vagueness without transformation** | "better experience", "simpler workflow", "more efficient", "improved productivity" with no concrete picture | "Better in what specific way? What does [user] stop doing, or start doing, that they couldn't before? Give me the concrete before-and-after." |

**Response pattern for any anti-pattern:**
1. Name the pattern: "That's [feature/business/technology] framing."
2. Explain briefly why it's a problem for a vision document.
3. Offer a concrete reframe: "Here's a reframe: [alternative]. Does that capture
   what you mean, or is that off?"

Never just explain what is wrong without providing the reframe. The PM should leave
each exchange with a better candidate, not just awareness of the problem.

---

## Block B — Scope and Boundaries

### Question 4: What is explicitly out of scope?

**Skip if:** The input document has a non-empty scope exclusions section with at
least 2–3 clear, specific items. Do not skip if the section exists but is vague or
contains only one item.

**Goal:** 2–3 explicit exclusions that define the product's boundaries. Required
— the "What This Is Not" section must be non-empty.

**Recommendation rule:** Propose candidates based on what is known. Common patterns:
- Adjacent product categories this could expand into but won't
- User segments that might seem like a fit but aren't the target
- Capabilities that would change the fundamental nature of the product
- Things the product might be confused with

Example recommendation:
> "Based on what you've described, I'd propose three exclusions: (1) [X] — because
> it would change the scope to [Y]; (2) [Z] — because the target user doesn't need
> it; (3) [W] — because that's a different product entirely. Does that match your
> intent, or would you add/change something?"

**Why this matters:** The exclusions section prevents scope creep in strategy and
roadmap conversations. A vision without explicit non-goals gets stretched to justify
any initiative.

---

### Question 5: When would this vision need to change?

**Skip if:** The input document contains a clear durability note that names specific
conditions under which the vision would need to change (not just generic risk
language) and includes an expected time horizon.

**Goal:** The durability note — what would have to be fundamentally true, or
fundamentally change, for this vision to no longer be the right destination.

**Recommendation rule:** Propose based on what is known. Common triggers:
- The underlying technology assumption fails or is superseded
- The target user's workflow changes fundamentally (job automation, regulatory shift)
- A major new insight reveals the transformation is wrong or too narrow
- The market moves such that the problem no longer exists

Example recommendation:
> "Based on what you've described, this vision would need to change if: (1) the
> underlying assumption about [X] turns out to be wrong, or (2) [user]'s role changes
> fundamentally such that [problem] no longer exists for them. Does that capture the
> main risk to the vision's durability?"

**Durability horizon:** Prompt the PM to name the expected stable horizon (typically
3–5 years for software products):
> "How long do you expect this vision to hold without fundamental change? 3 years?
> 5 years? This sets the time horizon shown at the top of vision.md."

---

## Block C — Provenance

### Question 6: Who was involved in shaping this vision?

**Skip if:** Never skip. Always ask — provenance is not derivable from the content
of the document itself.

**Goal:** Establish authorship context and surface the risk of solo authorship.

Ask:
> "Who was involved in defining this vision — was it a collaborative session with
> stakeholders, or is this primarily your own thinking so far?"

**If solo-authored:**
> "Vision documents authored by one person tend to have fragile buy-in — the team
> and stakeholders may not feel the same conviction, and the vision is more likely
> to be questioned when the strategy it informs becomes difficult.
> Even a short alignment session (30–60 minutes with key stakeholders) before
> finalising vision.md would strengthen it significantly. Is that something you
> can do before this vision drives strategy decisions?"

This is advisory only. Proceed regardless of the PM's answer. Record the authorship
context in the change history entry.

**If collaborative:**
> "Great — collaborative vision documents are more durable. Who should be named as
> participants? I'll note them in the change history."

---

## Misplaced Content Handling

For each piece of content identified in Step 1.2 as belonging elsewhere:

> "[Summarise the content]. This belongs in [target document], not in vision.md —
> it describes [business goals / product capabilities / success metrics] rather than
> the stable customer transformation.
>
> Should I:
> 1. Drop it from vision.md (you can add it to [target document] separately)
> 2. Note it here so you remember to move it
> 3. Keep it in vision.md anyway (not recommended)"

If the PM chooses 3, note the anti-pattern in the change history but proceed.
