---
name: forge:product-vision
description: >
  Write or rewrite a product vision document (vision.md) for any Forge product.
  Ingests an existing doc, brief, or URL; interviews for gaps; writes a structured
  vision grounded in customer transformation, not features or business goals.
when_to_use: >
  Trigger on: "write a product vision", "create a vision for this product",
  "we need a vision statement", "help me write vision.md", "our vision isn't clear",
  "rewrite our vision", "forge:product-vision", "what's our product vision",
  "I want to define our north star", "let's document why this product exists",
  "help me articulate why this product exists", or any time a PM wants to produce
  or update a stable product vision document. Also trigger when an existing vision.md
  contains feature framing, business goals, or strategy content that should be
  separated out.
argument-hint: "[product-name] [input-doc-path-or-url]"
arguments: [product_name, input_doc]
agent-type: orchestrator
---

# forge:product-vision

Produces or rewrites `vision.md` via a consistent three-phase flow:

```
Phase 1: Ingest     → read available context (argument, inference, or scratch)
Phase 2: Interview  → fill gaps, detect anti-patterns, push toward transformation framing
Phase 3: Write      → confirm draft, write vision.md
```

---

## Step 0: Environment and Product Resolution

Load `skills/common/environment.md` and apply it. Set `env_mode` and `products_root`.

**Resolve product name:**
- If `$product_name` was provided as an argument, use it directly.
- Otherwise ask: "Which product are we writing a vision for?"

Set `product_dir = <products_root>/<product_name>/`.

**Verify product directory exists:**

```bash
[ -d "<product_dir>" ] && echo "exists" || echo "missing"
```

If missing, hard stop:
> "`forge:product-vision` requires the product directory to exist first.
> Run `forge:product <product_name>` to create it, then re-invoke."

---

## Phase 1: Ingest Context

### Step 1.1 — Resolve input document

Check for an input document in this priority order. Use the first that is found.

**Priority 1 — Explicit argument:** If `$input_doc` was provided, use it immediately.
- If it looks like a URL, fetch it.
- If it looks like a file path, read it.
- If it is neither, treat it as pasted content.

**Priority 2 — Pasted content in invocation:** If no argument was given but the
invocation message contains a substantial block of text (more than 3 lines that look
like a document, not just a product name), treat it as the input document.

**Priority 3 — Existing `vision.md`:** Check for `<product_dir>/vision.md`. If
present, read it. Set `prior_vision_existed = true`.

**Priority 4 — No input:** Set `input_doc_found = false`. Proceed to interview
from scratch.

### Step 1.2 — Map to required sections

If an input document was found:

1. Read `skills/product-vision/references/vision-output-template.md` to load the
   required section structure.
2. For each section defined in the template, classify the input document's content
   as: **present and well-formed** / **present but misframed** / **absent**.
3. Flag any content in the input document that belongs elsewhere:
   - Business goals, revenue/cost figures, OKRs → `strategy.md` / `okrs.md`
   - Feature lists, UVP, differentiation statements → `strategy.md` or positioning docs
   - Success metrics, KPIs → `metrics.md`
4. Present the mapping to the PM before the interview. Say: "I've read [document
   name]. Here's what maps to each vision section:" then show a table with columns
   Section / Status / Notes, one row per template section. If misplaced content was
   found, add: "I also found content that belongs in other documents: [list]. I'll
   ask whether to move or drop it." Close with: "I'll ask about the gaps now."

If starting from scratch (no input document), skip the mapping and open the
interview directly.

---

## Phase 2: Interview

Read `skills/product-vision/references/vision-interview-playbook.md` now for the
full question set, recommended answers, anti-pattern triggers, and redirect phrases.

### Step 2.1 — Interview sequence

Work through three blocks in order. For each question, check the skip condition in
the playbook first — skip any question where the content is already present and
well-formed from the input document. Apply the recommendation rule throughout:
always propose a suggested answer with rationale, never ask an open question without
a position.

**Block A — Core transformation:** questions 1–3 (who is it for, what changes for
them, what friction exists today)

**Block B — Scope and boundaries:** questions 4–5 (what is out of scope, when
would this vision need to change)

**Block C — Provenance:** question 6 (who was involved — never skip). If the PM
describes solo authorship, output the advisory warning from the playbook in the
conversation before continuing. Do not record it silently — the PM must see it.

For misplaced content identified in Step 1.2, ask the PM to confirm whether each
item should be dropped from vision.md or moved to the correct document. See the
playbook for the full handling procedure.

### Step 2.2 — Anti-pattern check

After Block A, before Block B, check the draft vision statement assembled from the
Block A answers against the anti-pattern table in the playbook. If any pattern is
detected, name it, explain briefly why it is a problem, and offer a concrete reframe.
Never describe the problem without providing the reframe.

### Step 2.3 — Moore's template (optional scaffold)

If the PM is struggling to articulate the vision statement after Block A question 2:
> "Sometimes it helps to draft this as a positioning statement first, then distill it.
> Try: 'For [target user] who [need], [product name] is a [category] that [key
> benefit]. Unlike [alternative], our product [differentiation].' Fill that in and
> we'll strip it back to the transformation at its core."

After the PM fills in the template, extract the transformation element and push:
> "The core of that is [extracted transformation]. Can we restate the vision around
> that, without the positioning language?"

Moore's template is a drafting scaffold only. Do not write it into `vision.md`.

---

## Phase 3: Write

### Step 3.1 — Present draft

Assemble the full draft `vision.md` from the interview and any ingested content.
Load `skills/product-vision/references/vision-output-template.md` for the exact
section structure.

**Print the entire document text in the conversation** — every section heading and
its content, fully populated, as it will appear in the file. Do not summarise,
abbreviate, or refer to it as "the draft above". The PM must be able to read the
complete document in the chat before deciding to proceed.

After printing the full document, say:
> "Here's the vision document. Review it and tell me what to change, or say 'looks
> good' to write it."

**Hard gate:** Stop here. Do not write `vision.md` until the PM sends a follow-up
message confirming the draft. The original invocation, the task description, or any
prior message does not count as confirmation. A separate explicit response is required.

### Step 3.2 — Confirm and write

On PM confirmation, write `<product_dir>/vision.md` using the template structure
from `skills/product-vision/references/vision-output-template.md`.

If `prior_vision_existed = true`, overwrite the file entirely. Append a new change
history entry recording what changed and why (based on what the PM described during
the interview).

If this is a first-time write, the change history table has a single "Initial vision"
row.

### Step 3.3 — Post-write handoff prompt

If `prior_vision_existed = true` and content changed materially:
> "Vision updated. If the transformation or target beneficiaries changed
> significantly, your strategy likely needs to be rebuilt. Run
> `forge:product-strategy` in pivot mode — and be aware that `okrs.md`,
> `metrics.md`, and `roadmap.md` may be stale."

If this was a first-time write:
> "Vision written. The next step is to run `forge:product-strategy` to build the
> strategy that will take you toward this vision."

---

## Error Handling

| Condition | Action |
|---|---|
| Product directory does not exist | Hard stop — redirect to `forge:product <product_name>` |
| Input URL unreachable | Ask PM to paste the content; proceed once received |
| Input file path not found | Ask PM to confirm the path or paste the content; proceed |
| Draft confirmed but vision statement is empty | Do not write; ask for vision statement first |
| PM declines Block C (provenance) | Note solo authorship in change history; proceed |
