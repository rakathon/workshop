# forge:product-vision

Produces or rewrites `vision.md` for a Forge product via a three-phase flow:
ingest available context, interview for gaps, write the artifact. Grounds the vision
in customer transformation — not features, business goals, or technology framing —
and integrates with `forge:product-strategy` as an upstream north star constraint.

## Usage

```
forge:product-vision
forge:product-vision <product-name>
forge:product-vision <product-name> <input-doc-path-or-url>
```

Accepts an optional input document at invocation:
- A file path to an existing `vision.md`, product brief, or strategy document
- A URL (fetched automatically)
- Pasted content in the invocation message

If no input document is provided, the skill checks for an existing `vision.md` in
the product directory and uses that as context. If neither exists, the interview
starts from scratch.

## When to use

- Writing a product vision for the first time after `forge:product` has created the directory
- Rewriting an existing `vision.md` that contains strategy or feature content rather than a stable north star
- Before running `forge:product-strategy` — vision is the destination; strategy is the route
- Any time a PM says "write a product vision", "we need a vision statement", "rewrite our vision", "I want to define our north star", or "forge:product-vision"

## Prerequisites

- A product directory registered by `forge:product <product-name>` — required in both Forge and plain modes

This skill works in **Forge mode** (repository with `.forge/`) and **plain mode**
(Claude Desktop / Cowork — no git, no `.forge/`). In plain mode, `vision.md` is
written under `./<product-name>/` in the current working directory instead of
`.forge/products/<product-name>/`.

## What the skill does

**Phase 1 — Ingest:** Reads the input document (if any) and maps its content to the
six required `vision.md` sections. Flags content that belongs elsewhere (business
goals → `strategy.md`, features → positioning docs, metrics → `metrics.md`) and asks
the PM whether to drop or move it.

**Phase 2 — Interview:** Asks six questions across three blocks. Skips any question
where the input document already provides a clear, well-formed answer. Applies the
recommendation rule — always proposes a suggested answer with rationale, never asks
open-ended questions. Runs an anti-pattern check after the core transformation block
and flags: feature framing, business metric framing, technology framing, solution
specificity, and vagueness without transformation. Offers Geoffrey Moore's positioning
template as an optional scaffold when the PM is stuck.

**Phase 3 — Write:** Presents the full draft in the conversation for PM review. On
confirmation, writes `vision.md`. Appends a change history entry on every run.

## Output artifacts

| File | Purpose |
|------|---------|
| `<product_dir>/vision.md` | Stable product identity: vision statement, target beneficiaries, transformation, scope constraints, durability note, change history |

## Anti-patterns detected

The skill flags and redirects five anti-patterns in the vision statement:

| Anti-pattern | Example signal |
|---|---|
| Feature framing | "will provide real-time charts and custom filters" |
| Business metric framing | "increase productivity by 40%" or "$200k cost reduction" |
| Technology framing | "built on React and Kafka" as the focus |
| Solution specificity | "through a drag-and-drop dashboard builder" |
| Vagueness without transformation | "making analytics better and simpler" |

## Relationship to other skills

| Skill | Relationship |
|---|---|
| `forge:product` | Run `forge:product` first — it creates the product directory; `forge:product-vision` is the recommended next step |
| `forge:product-strategy` | Strategy is built to serve the vision; `forge:product-strategy` reads `vision.md` in all modes and uses it as a north star constraint; if `vision.md` is absent, strategy asks two lightweight questions to establish working context |
| `forge:product-strategy` (pivot) | Checks `vision.md` before archiving; if vision has changed, redirects to `forge:product-vision` first |
