# dishly — Test Plan

*Single reference for all test suites. Scenario details live in the linked source files; this document is the navigator.*

**Total scenarios: 176** across 10 suites and 2 features.

---

## Summary

| Suite | Type | Scenarios | Source |
|-------|------|-----------|--------|
| Wave 1 — E2E | System E2E | 16 | [source](../.forge/efforts/dishly-wave-1/spec/test/e2e-test-suite.md) |
| Wave 1 — Contract | API Contract | 25 | [source](../.forge/efforts/dishly-wave-1/spec/test/dishly-contract-test-suite.md) |
| Wave 1 — Integration | DB Integration | 24 | [source](../.forge/efforts/dishly-wave-1/spec/test/integration-test-suite.md) |
| Profile Section — E2E | System E2E | 17 | [source](../.forge/efforts/customer-profile-section/spec/test/e2e-test-suite.md) |
| Profile Section — UI E2E | Playwright | 22 | [source](../.forge/efforts/customer-profile-section/spec/test/ui-e2e-test-suite.md) |
| Profile Section — Contract | API Contract | 20 | [source](../.forge/efforts/customer-profile-section/spec/test/profile-contract-test-suite.md) |
| Profile Section — Integration | DB Integration | 16 | [source](../.forge/efforts/customer-profile-section/spec/test/integration-test-suite.md) |
| Location — E2E | System E2E | 16 | [source](../.forge/efforts/add-location-based-filtering/spec/test/e2e-test-suite.md) |
| Location — UI E2E | Playwright | 12 | [source](../.forge/efforts/add-location-based-filtering/spec/test/ui-e2e-test-suite.md) |
| Location — Integration | DB Integration | 8 | [source](../.forge/efforts/add-location-based-filtering/spec/test/integration-test-suite.md) |

---

## Wave 1 — E2E Test Suite (16 scenarios)

> Source: [.forge/efforts/dishly-wave-1/spec/test/e2e-test-suite.md](../.forge/efforts/dishly-wave-1/spec/test/e2e-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: Anonymous user browses homepage collections | BR-10 — all three discovery surfaces functional |
| SC-2: Anonymous user searches and filters restaurants | BR-10 — keyword search + cuisine/price filters |
| SC-3: Anonymous user views restaurant page with menu | BR-16 — full restaurant page layout |
| SC-4: New user registers an account | BR-9 — email/password registration |
| SC-5: Returning user signs in | BR-9 — sign-in returns JWT, preserves session |
| SC-6: Authenticated user completes full order flow | BR-1, BR-11 — discover → cart → checkout → confirmation |
| SC-7: Cart gate triggers auth on add-to-cart | BR-9 — account gate at cart, not at browse |
| SC-8: Cart conflict — items from multiple restaurants rejected | BR-11 — single-restaurant cart constraint |
| SC-9: Order confirmation shows simulated delivery ETA | BR-6 — simulated delivery status after confirmation |
| SC-10: Authenticated user views order history | BR-12 — order history lists past orders |
| SC-11: Search returns empty state for no-match query | BR-15 — friendly empty state, no crash |
| SC-12: Restaurant page with no menu items returns gracefully | BR-15 — "Menu coming soon" for empty menu |
| SC-13: Order submission failure does not create a partial order | BR-15 — cart not lost on server error |
| SC-14: 100 seeded restaurants are browsable | BR-5 — seed dataset present at launch |
| SC-15: App loads and is usable on mobile viewport | BR-4 — responsive web, mobile functional |
| SC-16: Direct URL access to any frontend route resolves correctly | TR-11 — SPA catch-all, no 404 on deep link |

---

## Wave 1 — Contract Test Suite (25 scenarios)

> Source: [.forge/efforts/dishly-wave-1/spec/test/dishly-contract-test-suite.md](../.forge/efforts/dishly-wave-1/spec/test/dishly-contract-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: POST /auth/register — 201 Created | `registerUser` 201 — BR-9 |
| SC-2: POST /auth/register — 409 Conflict | `registerUser` 409 — BR-9 |
| SC-3: POST /auth/register — 422 Validation | `registerUser` 422 |
| SC-4: POST /auth/login — 200 OK | `loginUser` 200 — BR-9 |
| SC-5: POST /auth/login — 401 Unauthorized | `loginUser` 401 |
| SC-6: GET /users/me — 200 OK | `getCurrentUser` 200 |
| SC-7: GET /users/me — 401 Unauthorized | `getCurrentUser` 401 |
| SC-8: GET /cuisines — 200 OK | `listCuisines` 200 — TR-8 |
| SC-9: GET /neighbourhoods — 200 OK | `listNeighbourhoods` 200 — TR-8 |
| SC-10: GET /collections — 200 OK | `listCollections` 200 — BR-10, TR-5 |
| SC-11: GET /collections/:id — 200 OK | `getCollection` 200 |
| SC-12: GET /collections/:id — 404 Not Found | `getCollection` 404 |
| SC-13: GET /restaurants — 200 OK (no filters) | `listRestaurants` 200 — BR-10 |
| SC-14: GET /restaurants?q=ramen — 200 OK (keyword search) | `listRestaurants` 200 with search — TR-7 |
| SC-15: GET /restaurants/:id — 200 OK | `getRestaurant` 200 — BR-16, TR-4 |
| SC-16: GET /restaurants/:id — 404 Not Found | `getRestaurant` 404 |
| SC-17: POST /orders — 201 Created | `createOrder` 201 — BR-11, TR-4 |
| SC-18: POST /orders — 401 Unauthorized | `createOrder` 401 — BR-9 |
| SC-19: POST /orders — 422 Unprocessable Entity | `createOrder` 422 — BR-11 single-restaurant cart constraint |
| SC-20: GET /orders/:id — 200 OK | `getOrder` 200 — BR-12 |
| SC-21: GET /orders/:id — 401 Unauthorized | `getOrder` 401 |
| SC-22: GET /orders/:id — 403 Forbidden | `getOrder` 403 — order isolation between users |
| SC-23: GET /orders/:id — 404 Not Found | `getOrder` 404 |
| SC-24: GET /users/me/orders — 200 OK with pagination | `listUserOrders` 200 — BR-12 |
| SC-25: GET /users/me/orders — 401 Unauthorized | `listUserOrders` 401 |

---

## Wave 1 — Integration Test Suite (24 scenarios)

> Source: [.forge/efforts/dishly-wave-1/spec/test/integration-test-suite.md](../.forge/efforts/dishly-wave-1/spec/test/integration-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: Seed script populates exactly 100 restaurants with required distribution | TR-8 — seed distribution; TR-9 — idempotent startup |
| SC-2: Restaurant read — full join returns menu sections, items, and reviews | TR-4 — RestaurantDetail data model; BR-16 |
| SC-3: Search — case-insensitive match on restaurant name | TR-7 — case-insensitive search |
| SC-4: Search — query matching a menu item name surfaces the parent restaurant | TR-7 — search matches menu item names, deduplicates |
| SC-5: Search — no-match query returns empty array, not an error | TR-7 — zero-result behaviour; BR-15 |
| SC-6: Filter by cuisine_id narrows results to matching restaurants only | BR-10 — cuisine filter |
| SC-7: Filter by price_range narrows results correctly | BR-10 — price range filter |
| SC-8: Collections loaded from data/collections.json at startup | TR-5 — static config collections; BR-10 |
| SC-9: Collection silently excludes restaurant IDs not present in the database | TR-5 — collections filter non-live restaurants |
| SC-10: User creation persists all required fields | TR-4 — USER entity; password_hash excluded from user object |
| SC-11: Duplicate email rejected with a constraint error | TR-4 — unique email constraint; BR-9 |
| SC-12: Password stored as hash; plaintext never written to database | TR-4 — password_hash field; security baseline |
| SC-13: JWT issued on registration is a valid signed token | TR-2 — JWT auth; BR-9 |
| SC-14: Order creation persists atomically with all required fields | TR-4 — ORDER + ORDER_ITEM entities; BR-11 |
| SC-15: Order item unit_price is copied at time of order (price snapshot) | TR-4 — ORDER_ITEM stores unit_price as snapshot; BR-11 |
| SC-16: Order with items from two different restaurants is rejected before any write | BR-11 — single-restaurant constraint enforced at service layer |
| SC-17: Order referencing a non-existent menu_item_id is rejected | BR-15 — invalid menu_item_id → 422, no partial order; TR-4 |
| SC-18: Order retrieval is scoped to the owning user | BR-12 — order history only visible to owning user |
| SC-19: Order history returns orders in newest-first order | BR-12 — reverse-chronological order history |
| SC-20: Cart is cleared from localStorage after successful order confirmation | TR-10 — cart cleared on successful order confirmation |
| SC-21: Stripe test-mode charge produces a charge ID (advisory) | TR-2 — Stripe test mode; BR-6 — no live payment in Wave 1 |
| SC-22: Stripe declined card returns a handled error (advisory) | BR-15 — payment failure path; service handles Stripe errors |
| SC-23: Stripe network timeout is handled gracefully (advisory) | BR-15 — order not placed on server error; timeout failure mode |
| SC-24: No real Stripe charge occurs in Wave 1 (advisory) | BR-6 — no real payment charged in Wave 1 |

---

## Profile Section — E2E Test Suite (17 scenarios)

> Source: [.forge/efforts/customer-profile-section/spec/test/e2e-test-suite.md](../.forge/efforts/customer-profile-section/spec/test/e2e-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: New customer registers with name and sees it in NavBar | BR-1 — Name collected at registration |
| SC-2: New customer registers without name and sees email-prefix fallback | BR-1 — Email-prefix fallback when name omitted |
| SC-3: Existing customer signs in and name appears in NavBar dropdown | BR-5 — Authenticated name display after sign-in |
| SC-4: Customer updates name from Account page; NavBar reflects change without reload | BR-2 — Personal info editing; BR-5 — Name display |
| SC-5: Customer sets phone number; invalid format is rejected before submission | BR-2 — Phone validation |
| SC-6: Customer adds a delivery address and it becomes default | BR-3 — Saved delivery addresses |
| SC-7: Customer adds a second address and sets it as default; first loses default | BR-3 — Default address selection |
| SC-8: Adding a third address is rejected | BR-3 — Address cap enforcement |
| SC-9: Default address pre-fills delivery field at checkout | BR-3 — Checkout pre-fill |
| SC-10: Customer can override the pre-filled address at checkout | BR-3 — Checkout address override |
| SC-11: Customer adds a mock payment method and it appears at checkout | BR-4 — Mock payment methods |
| SC-12: Adding a third payment method is rejected | BR-4 — Payment method cap enforcement |
| SC-13: Customer deletes an address; it no longer appears | BR-3 — Address deletion |
| SC-14: Customer deletes a payment method; it no longer appears | BR-4 — Payment method deletion |
| SC-15: Customer enters a dummy card at checkout and places an order | BR-6 — card fields; last 4 on confirmation; card not sent to backend |
| SC-16: Invalid dummy card entry is rejected before order submission | BR-6 — 16-digit validation before submission |
| SC-17: Quantity stepper allows adding multiple units of the same dish | BR-7 — stepper replaces button; +/− syncs NavBar badge |

---

## Profile Section — UI E2E Test Suite (22 scenarios)

> Source: [.forge/efforts/customer-profile-section/spec/test/ui-e2e-test-suite.md](../.forge/efforts/customer-profile-section/spec/test/ui-e2e-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: Account page shows profile header with name and initials | BR-5 — NavBar avatar displays initials from persisted name |
| SC-2: Account page shows email-prefix fallback when no name set | BR-1 — If omitted, display falls back to the email prefix |
| SC-3: Personal info section opens inline edit form on "Edit" click | BR-2 — Account page shows current name and phone with inline edit |
| SC-4: Invalid phone shows field-level error; form stays open | BR-2 — Invalid phone format shows inline validation error |
| SC-5: Saving valid personal info updates NavBar name without page reload | BR-2 — Updated name reflects immediately in NavBar without reload |
| SC-6: Cancel edit restores read view without saving | UX interaction — Cancel collapses form; original values restored |
| SC-7: Addresses section shows empty state when no addresses saved | BR-3 — Account page lists saved addresses (empty state CTA) |
| SC-8: Add address form appears inline; saving shows new address card | BR-3 — Account page lists saved addresses with edit/delete affordances |
| SC-9: Address card shows Default badge; "Set default" button absent on default card | BR-3 — One address can be set as default |
| SC-10: Delete confirmation appears inline; confirming removes the card | BR-3 — DELETE removes address; UX inline delete confirmation |
| SC-11: Add address button hidden when 2 addresses saved; cap note shown | BR-3 — Adding a third address is blocked; cap note replaces add button |
| SC-12: Payment section shows empty state when no payment methods saved | BR-4 — Account page lists saved payment methods (empty state) |
| SC-13: Add payment form shows card type selector and name field; saving shows card | BR-4 — Payment method fields: card_type and cardholder_name |
| SC-14: Checkout delivery field pre-filled from saved default address | BR-3 — Default pre-fills the delivery address field at checkout |
| SC-15: Checkout shows payment radio options for saved methods plus fallback | BR-4 — Checkout displays saved payment methods alongside Pay on delivery |
| SC-16: Register form includes optional Name field | BR-1 — Register form includes an optional Name field |
| SC-17: NavBar avatar shows initials after sign-in | BR-5 — NavBar avatar displays initials immediately after sign-in |
| SC-18: NavBar dropdown shows full name and email | BR-5 — Dropdown header shows full name and email |
| SC-19: "Enter a card" radio reveals card fields at checkout | BR-6 — Selecting 'Enter a card' reveals card number, expiry, CVV fields |
| SC-20: Card number auto-formats as groups of four | BR-6 — card number auto-formats (UX interaction) |
| SC-21: Invalid card number shows inline error on submit | BR-6 — Any 16-digit card accepted; lightly validated before submission |
| SC-22: "Add to cart" button replaced by stepper on first add | BR-7 — Add to cart replaced by stepper; +/− adjust quantity; 0 restores button |

---

## Profile Section — Contract Test Suite (20 scenarios)

> Source: [.forge/efforts/customer-profile-section/spec/test/profile-contract-test-suite.md](../.forge/efforts/customer-profile-section/spec/test/profile-contract-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: POST /auth/register — 201 Created | BR-1 — POST /auth/register stores name and returns it in the response |
| SC-2: POST /auth/register — 409 Conflict | BR-1 — Email already registered conflict response |
| SC-3: POST /auth/register — 422 Validation Error | BR-1 — Validation error on malformed registration input |
| SC-4: POST /auth/login — 200 OK with name in user object | BR-5 — POST /auth/login response includes name in the user object |
| SC-5: POST /auth/login — 401 Invalid Credentials | BR-5 — 401 response shape on failed authentication |
| SC-6: GET /users/me — 200 Profile Shape | BR-2 — GET /users/me returns full profile including name and phone |
| SC-7: GET /users/me — 401 Unauthenticated | TR-3 — All profile endpoints require authentication |
| SC-8: PATCH /users/me — 200 Updated Profile | BR-2 — PATCH /users/me accepts name and/or phone and persists changes |
| SC-9: PATCH /users/me — 422 Invalid Phone Format | BR-2 — Invalid phone format returns validation error; TR-5 |
| SC-10: GET /users/me/addresses — 200 Address List Shape | BR-3 — Account page lists saved addresses |
| SC-11: POST /users/me/addresses — 201 New Address | BR-3 — POST /users/me/addresses creates a new address |
| SC-12: POST /users/me/addresses — 422 Cap Exceeded | BR-3 — Adding a third address blocked; TR-6 — cap enforced server-side |
| SC-13: PATCH /users/me/addresses/:id — 200 Updated Address | BR-3 — PATCH /users/me/addresses/:id updates an existing address |
| SC-14: PATCH /users/me/addresses/:id — 404 Not Found | BR-3 — Not found response for unknown address id |
| SC-15: DELETE /users/me/addresses/:id — 204 Deleted | BR-3 — DELETE /users/me/addresses/:id removes an address |
| SC-16: GET /users/me/payment_methods — 200 Payment List Shape | BR-4 — Account page lists saved payment methods |
| SC-17: POST /users/me/payment_methods — 201 New Payment Method | BR-4 — POST /users/me/payment-methods creates a new payment method |
| SC-18: POST /users/me/payment_methods — 422 Cap Exceeded | BR-4 — Adding a third payment method blocked; TR-6 — cap enforced |
| SC-19: PATCH /users/me/payment_methods/:id — 200 Updated Method | BR-4 — PATCH /users/me/payment-methods/:id updates an existing method |
| SC-20: DELETE /users/me/payment_methods/:id — 204 Deleted | BR-4 — DELETE /users/me/payment-methods/:id removes a payment method |

---

## Profile Section — Integration Test Suite (16 scenarios)

> Source: [.forge/efforts/customer-profile-section/spec/test/integration-test-suite.md](../.forge/efforts/customer-profile-section/spec/test/integration-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: user table ALTER adds name and phone columns | TR-1 — Schema migration via additive ALTER TABLE |
| SC-2: User name and phone persist on register and are returned on login | BR-1 — Backend persists name; BR-5 — Login response includes name |
| SC-3: PATCH /users/me persists name and phone updates to the database | BR-2 — PATCH /users/me accepts name and/or phone and persists changes |
| SC-4: PATCH /users/me with null phone clears stored phone | BR-2 — Empty string treated as no phone set (stored as NULL) |
| SC-5: Auth middleware rejects request with no bearer token | TR-3 — All profile endpoints require authentication |
| SC-6: Auth middleware rejects request with invalid or expired token | TR-3 — Unauthenticated requests receive 401 UNAUTHORIZED |
| SC-7: POST /users/me/addresses persists address row with correct fields | BR-3 — Creates a new address; TR-2 — Separate table for addresses |
| SC-8: Setting is_default=true on a new address clears prior default | BR-3 — Only one address can be default at a time |
| SC-9: Address count enforced at 2 — third insert rejected at the service layer | TR-6 — Cap enforced server-side; BR-3 — third address blocked |
| SC-10: user_address rows are cascade-deleted when the user is deleted | TR-2 — user_address references user(id) ON DELETE CASCADE |
| SC-11: PATCH /users/me/addresses/:id with mismatched user returns 404 | TR-3 — Endpoints enforce ownership via user_id filter |
| SC-12: POST /users/me/payment-methods persists card_type and cardholder_name | BR-4 — Creates a new payment method; TR-2 — Separate table |
| SC-13: card_type CHECK constraint rejects invalid values at the database layer | TR-2 — card_type CHECK(card_type IN ('Visa', 'Mastercard', 'Amex')) |
| SC-14: Payment method count enforced at 2 — third insert rejected | TR-6 — Cap enforced server-side; BR-4 — third method blocked |
| SC-15: user_payment_method rows are cascade-deleted when user is deleted | TR-2 — user_payment_method references user(id) ON DELETE CASCADE |
| SC-16: Concurrent PATCH /users/me requests produce deterministic last-write result | TR-4 — SQLite serialized writes prevent partial corruption |

---

## Location — E2E Test Suite (16 scenarios)

> Source: [.forge/efforts/add-location-based-filtering/spec/test/e2e-test-suite.md](../.forge/efforts/add-location-based-filtering/spec/test/e2e-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: City selector filters restaurants to selected city | BR-2 — city selector filters restaurant list via neighbourhood_id |
| SC-2: Selecting a different city re-filters results immediately | BR-2 — city can be changed without page reload |
| SC-3: Clearing city filter restores all-city results | BR-2 — clear/reset control removes active city filter |
| SC-4: City selection persists across page reload | BR-2 — selected city stored in localStorage; restored on page refresh |
| SC-5: City cleared on sign-out | BR-2 — localStorage cleared on sign-out |
| SC-6: Near me matches user coordinates to correct city | BR-3 — coordinates matched to city bounding box |
| SC-7: Geolocation denied shows inline message | BR-3 — fallback message when permission denied |
| SC-8: Coordinates outside all bounding boxes show fallback | BR-3 — nearest centroid used when no exact match |
| SC-9: Los Angeles restaurants are browsable | BR-4 — ≥20 LA restaurants seeded |
| SC-10: Chicago restaurants are browsable | BR-4 — ≥20 Chicago restaurants seeded |
| SC-11: Boston restaurants are browsable | BR-4 — ≥20 Boston restaurants seeded |
| SC-12: Miami restaurants are browsable | BR-4 — ≥20 Miami restaurants seeded |
| SC-13: San Francisco restaurants are browsable | BR-4 — ≥20 SF restaurants seeded |
| SC-14: City filter combines with cuisine filter | BR-1 — neighbourhood_id filter works alongside existing filters |
| SC-15: City filter combines with price filter | BR-1 — neighbourhood_id filter works alongside existing filters |
| SC-16: GET /neighbourhoods returns all 10 cities | BR-1, BR-4 — flat neighbourhood table includes new cities |

---

## Location — UI E2E Test Suite (12 scenarios)

> Source: [.forge/efforts/add-location-based-filtering/spec/test/ui-e2e-test-suite.md](../.forge/efforts/add-location-based-filtering/spec/test/ui-e2e-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: City selector visible in NavBar alongside search input | UX Screen: NavBar — city selector default state |
| SC-2: City dropdown opens and shows all cities + Near me | UX Screen: City dropdown — open state |
| SC-3: Typing in city dropdown filters the list | UX Interaction: type-to-filter |
| SC-4: Selecting a city closes dropdown and shows active style | UX Interaction: city select |
| SC-5: Active city shows × clear button; clicking it resets | UX Interaction: city clear |
| SC-6: "Near me" shows loading indicator while awaiting geolocation | UX State: Near me loading |
| SC-7: Geolocation denied shows inline error message | UX State: geo denied |
| SC-8: No cities found when search matches nothing | UX State: dropdown empty state |
| SC-9: City selector visible in Home hero search bar | UX Screen: Home hero — city selector |
| SC-10: City selector visible on Search results page above cuisine/price | UX Screen: Search page — city filter row |
| SC-11: Empty state shown when city has no restaurants | UX State: Search — empty city |
| SC-12: City selector state syncs across NavBar and Search page | UX Interaction: cross-surface sync |

---

## Location — Integration Test Suite (8 scenarios)

> Source: [.forge/efforts/add-location-based-filtering/spec/test/integration-test-suite.md](../.forge/efforts/add-location-based-filtering/spec/test/integration-test-suite.md)

| Scenario | Verifies |
|----------|----------|
| SC-1: neighbourhood table contains all 10 cities after seed | BR-1, BR-4 — flat table includes old and new entries |
| SC-2: Re-running seed does not duplicate cities | TR-5 — idempotency via neighbourhood count check |
| SC-3: GET /restaurants filters correctly by new city neighbourhood_id | BR-1 — existing neighbourhood_id filter works for new entries |
| SC-4: New cities have ≥20 restaurants in the DB | BR-4 — ~20 restaurants per new city |
| SC-5: Existing NYC neighbourhoods unchanged after seed | BR-4 — existing NYC data preserved |
| SC-6: GET /restaurants with neighbourhood_id + cuisine_id returns correct intersection | BR-1 — filter combination works |
| SC-7: GET /restaurants with neighbourhood_id + price_range returns correct intersection | BR-1 — filter combination works |
| SC-8: GET /restaurants without neighbourhood_id returns all 200 restaurants | BR-1 — no city filter returns all |

---

## Running the Tests

### Backend integration tests

```bash
cd backend && npm test
```

### Playwright UI E2E

```bash
./start.sh &
cd e2e && npx playwright test --project=chromium
```

### Run a specific spec

```bash
cd e2e && npx playwright test tests/account/account-profile.spec.js --project=chromium
```
