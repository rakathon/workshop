# dishly — Product Screenshots

📄 **[Download all screenshots as PDF](screenshots/dishly-product-screenshots.pdf)**

| Surface | Preview |
|---------|---------|
| [Homepage](screenshots/01-homepage.png) | ![Homepage](screenshots/01-homepage.png) |
| [Search Results](screenshots/02-search-results.png) | ![Search](screenshots/02-search-results.png) |
| [Restaurant Page](screenshots/03-restaurant-page.png) | ![Restaurant](screenshots/03-restaurant-page.png) |
| [Cart](screenshots/04-cart.png) | ![Cart](screenshots/04-cart.png) |
| [Checkout](screenshots/05-checkout.png) | ![Checkout](screenshots/05-checkout.png) |
| [Login](screenshots/06-login.png) | ![Login](screenshots/06-login.png) |
| [Account](screenshots/07-account.png) | ![Account](screenshots/07-account.png) |
| [Order History](screenshots/08-order-history.png) | ![Order History](screenshots/08-order-history.png) |
| [Mobile Homepage](screenshots/09-homepage-mobile.png) | ![Mobile](screenshots/09-homepage-mobile.png) |
