// Hardcoded bounding boxes (centroid ±0.5°) for Near me city matching.
// Source: TR-3 — no external geocoding API; matched at runtime against browser geolocation.
export const CITY_BOUNDS = [
  { name: 'New York',       centroid: { lat: 40.7128, lng: -74.0060 }, bounds: { minLat: 40.2128, maxLat: 41.2128, minLng: -74.5060, maxLng: -73.5060 } },
  { name: 'Los Angeles',    centroid: { lat: 34.0522, lng: -118.2437 }, bounds: { minLat: 33.5522, maxLat: 34.5522, minLng: -118.7437, maxLng: -117.7437 } },
  { name: 'Chicago',        centroid: { lat: 41.8781, lng: -87.6298 }, bounds: { minLat: 41.3781, maxLat: 42.3781, minLng: -88.1298, maxLng: -87.1298 } },
  { name: 'Boston',         centroid: { lat: 42.3601, lng: -71.0589 }, bounds: { minLat: 41.8601, maxLat: 42.8601, minLng: -71.5589, maxLng: -70.5589 } },
  { name: 'Miami',          centroid: { lat: 25.7617, lng: -80.1918 }, bounds: { minLat: 25.2617, maxLat: 26.2617, minLng: -80.6918, maxLng: -79.6918 } },
  { name: 'San Francisco',  centroid: { lat: 37.7749, lng: -122.4194 }, bounds: { minLat: 37.2749, maxLat: 38.2749, minLng: -122.9194, maxLng: -121.9194 } },
];

/** Match lat/lng to nearest city. Returns city name or null. */
export function matchCity(lat, lng, cities) {
  // First try exact bounding box match
  const exact = CITY_BOUNDS.find(c =>
    lat >= c.bounds.minLat && lat <= c.bounds.maxLat &&
    lng >= c.bounds.minLng && lng <= c.bounds.maxLng
  );
  if (exact) return cities?.find(c => c.name === exact.name) ?? null;

  // Fallback: nearest centroid
  let nearest = null;
  let minDist = Infinity;
  for (const c of CITY_BOUNDS) {
    const d = Math.hypot(lat - c.centroid.lat, lng - c.centroid.lng);
    if (d < minDist) { minDist = d; nearest = c; }
  }
  return nearest ? (cities?.find(c => c.name === nearest.name) ?? null) : null;
}
