import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { api } from '../api/client';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const returnTo = location.state?.returnTo || '/';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const data = await api.post('/auth/login', { email, password });
      localStorage.setItem('dishly_token', data.token);
      localStorage.setItem('dishly_user_email', data.user.email);
      localStorage.setItem('dishly_user_name', data.user.name || data.user.email.split('@')[0]);
      localStorage.setItem('dishly_user_id', data.user.id);
      window.dispatchEvent(new Event('dishly:auth'));
      navigate(returnTo);
    } catch (err) {
      setError(err.message || 'Invalid email or password.');
      setSubmitting(false);
    }
  }

  return (
    <main className="auth-page">
      <h1 className="auth-page__title">Welcome back</h1>
      <p className="auth-page__sub">Sign in to your dishly account.</p>
      <form className="auth-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label" htmlFor="login-email">Email address</label>
          <input id="login-email" className="form-input" type="email" autoComplete="email"
            placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="login-password">Password</label>
          <input id="login-password" className="form-input" type="password" autoComplete="current-password"
            placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required />
        </div>
        {error && <div className="auth-error" role="alert">{error}</div>}
        <button type="submit" className="btn btn-primary btn-wide btn-lg" disabled={submitting}>
          {submitting ? 'Signing in…' : 'Sign In'}
        </button>
      </form>
      <p className="auth-switch">No account? <Link to="/register">Sign up</Link></p>
      <p style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginTop: '12px', textAlign: 'center' }}>
        No password reset in Wave 1 beta.
      </p>
    </main>
  );
}
