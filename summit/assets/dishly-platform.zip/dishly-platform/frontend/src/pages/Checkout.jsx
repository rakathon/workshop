import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import { api } from '../api/client';
import EmptyState from '../components/EmptyState';

const CARD_ICON_CLASS = { Visa: 'card-icon--visa', Mastercard: 'card-icon--mastercard', Amex: 'card-icon--amex' };

function formatPrice(value, scale) {
  return '$' + (value / Math.pow(10, scale)).toFixed(2);
}

const DELIVERY_FEE_VALUE = 399;

export default function Checkout() {
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();
  const [address, setAddress] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [savedAddresses, setSavedAddresses] = useState([]);
  const [savedPayments, setSavedPayments] = useState([]);
  const [selectedPayment, setSelectedPayment] = useState('delivery');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardError, setCardError] = useState('');

  // Guard: redirect to login if not authenticated
  useEffect(() => {
    const token = localStorage.getItem('dishly_token');
    if (!token) {
      navigate('/login', { state: { returnTo: '/checkout' } });
    }
  }, []);

  // Validate cart restaurant still exists in DB — clear if stale (e.g. after DB re-seed)
  useEffect(() => {
    if (!cart.restaurantId) return;
    api.get(`/restaurants/${cart.restaurantId}`)
      .catch(() => {
        clearCart();
        navigate('/');
      });
  }, [cart.restaurantId]);

  useEffect(() => {
    const token = localStorage.getItem('dishly_token');
    if (!token) return;
    api.get('/users/me/addresses')
      .then(data => {
        const list = Array.isArray(data) ? data : (data?.data ?? []);
        setSavedAddresses(list);
        const def = list.find(a => a.is_default) || list[0];
        if (def) setAddress(`${def.street}, ${def.city}, ${def.postcode}`);
      })
      .catch(() => {});
    api.get('/users/me/payment_methods')
      .then(data => {
        const list = Array.isArray(data) ? data : (data?.data ?? []);
        setSavedPayments(list);
        if (list.length > 0) setSelectedPayment(list[0].id);
      })
      .catch(() => {});
  }, []);

  if (!cart.items.length) {
    return (
      <main className="checkout-page">
        <EmptyState message="Your cart is empty." />
      </main>
    );
  }

  const subtotalValue = cart.items.reduce((sum, i) => sum + i.price.value * i.quantity, 0);
  const totalValue = subtotalValue + DELIVERY_FEE_VALUE;

  async function handleSubmit(e) {
    e.preventDefault();
    if (!address.trim() || address.trim().length < 5) {
      setError('Please enter a valid delivery address.');
      return;
    }

    const token = localStorage.getItem('dishly_token');
    if (!token) {
      navigate('/login', { state: { returnTo: '/checkout' } });
      return;
    }

    if (selectedPayment === 'new-card') {
      const digits = cardNumber.replace(/\s/g, '');
      if (!/^\d{16}$/.test(digits)) { setCardError('Enter a valid 16-digit card number'); return; }
      if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) { setCardError('Enter expiry as MM/YY'); return; }
      if (!/^\d{3,4}$/.test(cardCvv)) { setCardError('Enter a valid CVV'); return; }
      setCardError('');
    }

    setSubmitting(true);
    setError('');

    try {
      const order = await api.post('/orders', {
        restaurant_id: cart.restaurantId,
        items: cart.items.map(i => ({ menu_item_id: i.id, quantity: i.quantity })),
        delivery_address: address.trim(),
        payment_method_id: 'pm_card_visa',
      });
      clearCart();
      const last4 = selectedPayment === 'new-card'
        ? cardNumber.replace(/\s/g, '').slice(-4)
        : null;
      navigate(`/orders/${order.id}`, { state: { cardLast4: last4 } });
    } catch (err) {
      const msg = err.message || 'Order failed. Please try again.';
      // Stale cart IDs (after DB reset) produce a JSON parse error — guide the user to re-add items
      const isStale = msg.includes('<!DOCTYPE') || msg.includes('not valid JSON') || msg.includes('Menu item not found');
      setError(isStale
        ? 'Your cart has expired — the menu has been updated. Please go back and add items again.'
        : msg
      );
      if (isStale) clearCart();
      setSubmitting(false);
    }
  }

  return (
    <main className="checkout-page">
      <h1 className="checkout-page__title">Checkout</h1>

      <div className="checkout-summary">
        <h2 className="checkout-summary__heading">Order from {cart.restaurantName}</h2>
        {cart.items.map(i => (
          <div key={i.id} className="checkout-summary__item">
            <span>{i.name} × {i.quantity}</span>
            <span>{formatPrice(i.price.value * i.quantity, i.price.scale)}</span>
          </div>
        ))}
        <div className="checkout-summary__item checkout-summary__item--fee">
          <span>Delivery fee</span><span>$3.99</span>
        </div>
        <div className="checkout-summary__item checkout-summary__item--total">
          <span><strong>Total</strong></span>
          <span><strong>{formatPrice(totalValue, 2)}</strong></span>
        </div>
      </div>

      <form className="checkout-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label" htmlFor="address">Delivery address</label>
          <input
            id="address"
            className="form-input"
            type="text"
            placeholder="123 Main St, New York, NY 10001"
            value={address}
            onChange={e => setAddress(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label className="form-label">Payment</label>
          {savedPayments.map(pm => (
            <label key={pm.id} className="payment-option">
              <input type="radio" name="payment" value={pm.id}
                checked={selectedPayment === pm.id}
                onChange={() => setSelectedPayment(pm.id)} />
              <div className={`card-icon ${CARD_ICON_CLASS[pm.card_type] || ''}`} aria-hidden="true">
                {pm.card_type.slice(0, 2).toUpperCase()}
              </div>
              <span className="payment-option__label">{pm.card_type} — {pm.cardholder_name}</span>
              <span className="payment-option__sub">mock</span>
            </label>
          ))}
          <label className="payment-option">
            <input type="radio" name="payment" value="new-card"
              checked={selectedPayment === 'new-card'}
              onChange={() => setSelectedPayment('new-card')} />
            <span className="payment-option__label">Enter a card</span>
          </label>
          {selectedPayment === 'new-card' && (
            <div className="checkout-card-entry">
              <div className="form-group">
                <label className="form-label" htmlFor="card-number">Card number</label>
                <input
                  id="card-number"
                  className="form-input"
                  type="text"
                  inputMode="numeric"
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                  value={cardNumber}
                  onChange={e => {
                    const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
                    setCardNumber(raw.replace(/(.{4})/g, '$1 ').trim());
                    setCardError('');
                  }}
                />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="form-group">
                  <label className="form-label" htmlFor="card-expiry">Expiry (MM/YY)</label>
                  <input
                    id="card-expiry"
                    className="form-input"
                    type="text"
                    placeholder="MM/YY"
                    maxLength={5}
                    value={cardExpiry}
                    onChange={e => {
                      let v = e.target.value.replace(/\D/g, '').slice(0, 4);
                      if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2);
                      setCardExpiry(v);
                      setCardError('');
                    }}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="card-cvv">CVV</label>
                  <input
                    id="card-cvv"
                    className="form-input"
                    type="text"
                    inputMode="numeric"
                    placeholder="123"
                    maxLength={4}
                    value={cardCvv}
                    onChange={e => { setCardCvv(e.target.value.replace(/\D/g, '').slice(0, 4)); setCardError(''); }}
                  />
                </div>
              </div>
              {cardError && <p className="checkout-error" role="alert">{cardError}</p>}
            </div>
          )}
          <label className="payment-option">
            <input type="radio" name="payment" value="delivery"
              checked={selectedPayment === 'delivery'}
              onChange={() => setSelectedPayment('delivery')} />
            <span className="payment-option__label">Pay on delivery</span>
          </label>
          <p className="checkout-card-mock__note">Wave 1: test mode — no real charge</p>
        </div>

        {error && <p className="checkout-error" role="alert">{error}</p>}

        <button
          type="submit"
          className="btn btn-primary btn-wide"
          disabled={submitting}
        >
          {submitting ? 'Placing order…' : 'Place Order'}
        </button>
      </form>
    </main>
  );
}
