import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client';

export default function Register() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    setSubmitting(true);
    try {
      const body = { email, password };
      if (name.trim()) body.name = name.trim();
      const data = await api.post('/auth/register', body);
      localStorage.setItem('dishly_token', data.token);
      localStorage.setItem('dishly_user_email', data.user.email);
      localStorage.setItem('dishly_user_name', data.user.name || data.user.email.split('@')[0]);
      localStorage.setItem('dishly_user_id', data.user.id);
      window.dispatchEvent(new Event('dishly:auth'));
      navigate('/');
    } catch (err) {
      setError(err.message || 'Registration failed.');
      setSubmitting(false);
    }
  }

  return (
    <main className="auth-page">
      <h1 className="auth-page__title">Create account</h1>
      <p className="auth-page__sub">Join dishly to start ordering.</p>
      <form className="auth-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label" htmlFor="reg-name">
            Name <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(optional)</span>
          </label>
          <input id="reg-name" className="form-input" type="text" autoComplete="name"
            placeholder="Your display name" value={name} onChange={e => setName(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="reg-email">Email address</label>
          <input id="reg-email" className="form-input" type="email" autoComplete="email"
            placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="reg-password">
            Password <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(min. 8 characters)</span>
          </label>
          <input id="reg-password" className="form-input" type="password" autoComplete="new-password"
            placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required />
        </div>
        {error && <div className="auth-error" role="alert">{error}</div>}
        <button type="submit" className="btn btn-primary btn-wide btn-lg" disabled={submitting}>
          {submitting ? 'Creating account…' : 'Create Account'}
        </button>
      </form>
      <p className="auth-switch">Already have an account? <Link to="/login">Sign in</Link></p>
    </main>
  );
}
