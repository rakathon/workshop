import { Link, useSearchParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useRestaurants, useCuisines, useCities } from '../api/hooks';
import CitySelector, { useCityFilter } from '../components/CitySelector';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

const PRICES = ['$', '$$', '$$$'];
const RATINGS = [{ label: '★ 4.5+', value: 4.5 }, { label: '★ 4.0+', value: 4.0 }];
const SORT_OPTIONS = [
  { value: 'best', label: 'Best match' },
  { value: 'rating', label: 'Top rated' },
  { value: 'price_asc', label: 'Price: low–high' },
  { value: 'price_desc', label: 'Price: high–low' },
];

const PRICE_ORDER = { '$': 1, '$$': 2, '$$$': 3 };

const CHIP_CUISINE_MAP = {
  Ramen: 'Japanese', Soba: 'Japanese', Sushi: 'Japanese',
  Thai: 'Thai', Mexican: 'Mexican', Pizza: 'Italian', Indian: 'Indian', Brunch: 'American',
};

export default function Search() {
  const [searchParams] = useSearchParams();
  const rawQ = searchParams.get('q') || '';
  const urlNeighbourhoodId = searchParams.get('neighbourhood_id') || '';
  const [cuisineId, setCuisineId] = useState('');
  const [priceRange, setPriceRange] = useState('');
  const [minRating, setMinRating] = useState(0);
  const [sort, setSort] = useState('best');
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'list'
  const [sortOpen, setSortOpen] = useState(false);

  const chipCuisineName = CHIP_CUISINE_MAP[rawQ] || null;
  const q = chipCuisineName ? '' : rawQ;
  const { city, selectCity } = useCityFilter();

  const { data: allCities } = useCities();
  useEffect(() => {
    if (urlNeighbourhoodId && allCities?.length && (!city || city.id !== urlNeighbourhoodId)) {
      const matched = allCities.find(c => c.id === urlNeighbourhoodId);
      if (matched) selectCity(matched);
    }
  }, [urlNeighbourhoodId, allCities]);

  const [, forceUpdate] = useState(0);
  useEffect(() => {
    function onCityChange() { forceUpdate(n => n + 1); }
    window.addEventListener('dishly:city-changed', onCityChange);
    return () => window.removeEventListener('dishly:city-changed', onCityChange);
  }, []);

  const params = { q, cuisine_id: cuisineId, price_range: priceRange };
  if (city) params.neighbourhood_id = city.id;

  const { data: rawRestaurants, loading, error } = useRestaurants(params);
  const { data: cuisines } = useCuisines();

  useEffect(() => {
    if (chipCuisineName && cuisines?.length && !cuisineId) {
      const matched = cuisines.find(c => c.name === chipCuisineName);
      if (matched) setCuisineId(matched.id);
    }
  }, [chipCuisineName, cuisines]);

  // Client-side rating filter + sort
  const restaurants = (() => {
    let list = rawRestaurants || [];
    if (minRating > 0) list = list.filter(r => (r.average_rating || 0) >= minRating);
    if (sort === 'rating') list = [...list].sort((a, b) => (b.average_rating || 0) - (a.average_rating || 0));
    if (sort === 'price_asc') list = [...list].sort((a, b) => (PRICE_ORDER[a.price_range] || 0) - (PRICE_ORDER[b.price_range] || 0));
    if (sort === 'price_desc') list = [...list].sort((a, b) => (PRICE_ORDER[b.price_range] || 0) - (PRICE_ORDER[a.price_range] || 0));
    return list;
  })();

  function clearAll() {
    setCuisineId('');
    setPriceRange('');
    setMinRating(0);
    selectCity(null);
  }

  const hasActiveFilters = cuisineId || priceRange || minRating > 0 || city;
  const pageTitle = rawQ && chipCuisineName ? `${rawQ} Restaurants` : q ? `Results for "${q}"` : 'All Restaurants';
  const currentSortLabel = SORT_OPTIONS.find(o => o.value === sort)?.label;

  return (
    <div className="search-layout">

      {/* ── FILTER SIDEBAR ── */}
      <aside className="search-sidebar">
        <div className="search-sidebar__header">
          <span className="search-sidebar__title">Filters</span>
          {hasActiveFilters && (
            <button className="search-sidebar__clear" onClick={clearAll}>Clear all</button>
          )}
        </div>

        <div className="search-filter-section">
          <span className="search-filter-label">City</span>
          <CitySelector city={city} onSelect={selectCity} size="sm" />
        </div>

        <div className="search-filter-section">
          <span className="search-filter-label">Cuisine</span>
          <div className="search-filter-pills">
            <button
              className={`search-filter-pill${!cuisineId ? ' search-filter-pill--active' : ''}`}
              onClick={() => setCuisineId('')}
            >All</button>
            {cuisines?.map(c => (
              <button
                key={c.id}
                className={`search-filter-pill${cuisineId === c.id ? ' search-filter-pill--active' : ''}`}
                onClick={() => setCuisineId(cuisineId === c.id ? '' : c.id)}
              >{c.name}</button>
            ))}
          </div>
        </div>

        <div className="search-filter-section">
          <span className="search-filter-label">Price range</span>
          <div className="search-filter-pills">
            <button
              className={`search-filter-pill${!priceRange ? ' search-filter-pill--active' : ''}`}
              onClick={() => setPriceRange('')}
            >Any</button>
            {PRICES.map(p => (
              <button
                key={p}
                className={`search-filter-pill${priceRange === p ? ' search-filter-pill--active' : ''}`}
                onClick={() => setPriceRange(priceRange === p ? '' : p)}
              >{p}</button>
            ))}
          </div>
        </div>

        <div className="search-filter-section">
          <span className="search-filter-label">Rating</span>
          <div className="search-filter-pills">
            <button
              className={`search-filter-pill${minRating === 0 ? ' search-filter-pill--active' : ''}`}
              onClick={() => setMinRating(0)}
            >Any</button>
            {RATINGS.map(r => (
              <button
                key={r.value}
                className={`search-filter-pill${minRating === r.value ? ' search-filter-pill--active' : ''}`}
                onClick={() => setMinRating(minRating === r.value ? 0 : r.value)}
              >{r.label}</button>
            ))}
          </div>
        </div>
      </aside>

      {/* ── MAIN RESULTS ── */}
      <main className="search-main">

        {/* Page header */}
        <div className="search-page-header">
          <h1 className="search-page__title">{pageTitle}</h1>
          {hasActiveFilters && (
            <div className="search-active-chips">
              {cuisineId && cuisines && (
                <span className="search-active-chip">
                  {cuisines.find(c => c.id === cuisineId)?.name}
                  <button className="search-active-chip__x" onClick={() => setCuisineId('')} aria-label="Remove cuisine filter">×</button>
                </span>
              )}
              {priceRange && (
                <span className="search-active-chip">
                  {priceRange}
                  <button className="search-active-chip__x" onClick={() => setPriceRange('')} aria-label="Remove price filter">×</button>
                </span>
              )}
              {minRating > 0 && (
                <span className="search-active-chip">
                  ★ {minRating}+
                  <button className="search-active-chip__x" onClick={() => setMinRating(0)} aria-label="Remove rating filter">×</button>
                </span>
              )}
              {city && (
                <span className="search-active-chip">
                  {city.name}
                  <button className="search-active-chip__x" onClick={() => selectCity(null)} aria-label="Remove city filter">×</button>
                </span>
              )}
            </div>
          )}
        </div>

        {loading && <LoadingSpinner />}
        {error && <ErrorMessage message={error} />}

        {!loading && !error && restaurants?.length > 0 && (
          <>
            {/* Toolbar */}
            <div className="search-toolbar">
              <p className="result-count" aria-live="polite">
                {restaurants.length} restaurant{restaurants.length !== 1 ? 's' : ''}
              </p>
              <div className="search-toolbar__controls">
                {/* Sort dropdown */}
                <div className="search-sort" style={{ position: 'relative' }}>
                  <button
                    className="search-sort__btn"
                    onClick={() => setSortOpen(o => !o)}
                    aria-expanded={sortOpen}
                  >
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="15" y2="12"/><line x1="3" y1="18" x2="9" y2="18"/></svg>
                    {currentSortLabel}
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true"><polyline points="6,9 12,15 18,9"/></svg>
                  </button>
                  {sortOpen && (
                    <div className="search-sort__dropdown">
                      {SORT_OPTIONS.map(o => (
                        <button
                          key={o.value}
                          className={`search-sort__option${sort === o.value ? ' search-sort__option--active' : ''}`}
                          onClick={() => { setSort(o.value); setSortOpen(false); }}
                        >{o.label}</button>
                      ))}
                    </div>
                  )}
                </div>
                {/* View toggle */}
                <div className="search-view-toggle" role="group" aria-label="View mode">
                  <button
                    className={`search-view-btn${viewMode === 'grid' ? ' search-view-btn--active' : ''}`}
                    onClick={() => setViewMode('grid')}
                    aria-label="Grid view"
                    aria-pressed={viewMode === 'grid'}
                    title="Grid view"
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                  </button>
                  <button
                    className={`search-view-btn${viewMode === 'list' ? ' search-view-btn--active' : ''}`}
                    onClick={() => setViewMode('list')}
                    aria-label="List view"
                    aria-pressed={viewMode === 'list'}
                    title="List view"
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
                  </button>
                </div>
              </div>
            </div>

            {/* Results */}
            <div className={viewMode === 'grid' ? 'search-results-grid' : 'search-results-list'}>
              {restaurants.map(r => (
                viewMode === 'grid' ? (
                  <Link key={r.id} to={`/restaurants/${r.id}`} className="search-card">
                    <div className="search-card__img-wrap">
                      {r.cover_image_url ? (
                        <img
                          className="search-card__img"
                          src={r.cover_image_url}
                          alt={r.name}
                          onError={e => { e.currentTarget.style.display = 'none'; e.currentTarget.nextSibling?.removeAttribute('style'); }}
                        />
                      ) : null}
                      <div className="search-card__img-placeholder" style={{ display: r.cover_image_url ? 'none' : 'block' }} aria-hidden="true" />
                    </div>
                    <div className="search-card__body">
                      <div className="search-card__name">{r.name}</div>
                      <div className="search-card__meta">
                        <span className="search-card__star">★</span>
                        {r.average_rating?.toFixed(1)}
                        <span className="search-card__dot">·</span>
                        {r.cuisine?.name}
                        <span className="search-card__dot">·</span>
                        {r.price_range}
                      </div>
                      <div className="search-card__desc">{r.description || ''}</div>
                      <div className="search-card__footer">
                        <div className="search-card__tags">
                          {r.neighbourhood?.name && <span className="search-card__tag">{r.neighbourhood.name}</span>}
                          {r.price_range && <span className="search-card__tag">{r.price_range}</span>}
                        </div>
                        <span className="search-card__cta">View menu →</span>
                      </div>
                    </div>
                  </Link>
                ) : (
                  <Link key={r.id} to={`/restaurants/${r.id}`} className="result-row">
                    <div className="restaurant-card__image">
                      {r.cover_image_url ? (
                        <img src={r.cover_image_url} alt={r.name} onError={e => { e.currentTarget.style.display = 'none'; }} />
                      ) : (
                        <div className="restaurant-card__image-placeholder" aria-hidden="true" />
                      )}
                    </div>
                    <div className="result-info">
                      <div className="result-name">{r.name}</div>
                      <div className="result-meta"><span className="star">★</span> {r.average_rating?.toFixed(1)} · {r.cuisine?.name} · {r.price_range}</div>
                      <div className="result-desc">{r.description || ''}</div>
                    </div>
                  </Link>
                )
              ))}
            </div>
          </>
        )}

        {!loading && !error && restaurants?.length === 0 && (
          <div className="search-empty">
            <div className="search-empty__icon">🍽️</div>
            <div className="search-empty__title">No restaurants found</div>
            <div className="search-empty__sub">
              {q ? `No results for "${q}" — ` : ''}Try adjusting your filters or search for something else.
            </div>
            {hasActiveFilters && (
              <button className="search-empty__cta" onClick={clearAll}>Clear all filters</button>
            )}
          </div>
        )}

      </main>
    </div>
  );
}
