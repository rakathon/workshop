import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

function formatPrice(value, scale) {
  return '$' + (value / Math.pow(10, scale)).toFixed(2);
}

function formatDate(isoString) {
  const date = new Date(isoString);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  const timeStr = date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} minute${diffMins === 1 ? '' : 's'} ago`;
  if (diffHours < 24 && date.toDateString() === now.toDateString()) return `Today at ${timeStr}`;
  if (diffDays === 1) return `Yesterday at ${timeStr}`;
  if (diffDays < 7) return `${date.toLocaleDateString([], { weekday: 'long' })} at ${timeStr}`;
  return date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) + ` at ${timeStr}`;
}

export default function OrderHistory() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('dishly_token');
    if (!token) { navigate('/login'); return; }

    api.get('/users/me/orders')
      .then(data => { setOrders(data); setLoading(false); })
      .catch(err => {
        if (err.status === 401) { navigate('/login'); return; }
        setError(err.message); setLoading(false);
      });
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <main className="order-history">
      <h1 className="order-history__title">Order History</h1>
      {!orders?.length
        ? <EmptyState message="You haven't placed any orders yet." />
        : orders.map(order => (
          <div key={order.id} className="order-card">
            <div className="order-card__header">
              <span className="order-card__restaurant">{order.restaurant_name}</span>
              <span className="order-card__date" title={new Date(order.created_at).toLocaleString()}>{formatDate(order.created_at)}</span>
            </div>
            <div className="order-card__items">
              {order.items.map(i => (
                <span key={i.id} className="order-card__item">{i.item_name} × {i.quantity}</span>
              ))}
            </div>
            <div className="order-card__footer">
              <span className="order-card__total">Total: {formatPrice(order.total.value, order.total.scale)}</span>
              <Link to={`/orders/${order.id}`} className="order-card__link">View details</Link>
            </div>
          </div>
        ))
      }
    </main>
  );
}
