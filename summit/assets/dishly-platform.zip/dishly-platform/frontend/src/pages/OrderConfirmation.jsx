import { useEffect } from 'react';
import { useParams, Link, useLocation } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import { api } from '../api/client';
import { useState } from 'react';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

function formatPrice(value, scale) {
  return '$' + (value / Math.pow(10, scale)).toFixed(2);
}

export default function OrderConfirmation() {
  const { id } = useParams();
  const { clearCart } = useCart();
  const location = useLocation();
  const cardLast4 = location.state?.cardLast4 || null;
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    clearCart();
    api.get(`/orders/${id}`)
      .then(data => { setOrder(data); setLoading(false); })
      .catch(err => { setError(err.message); setLoading(false); });
  }, [id]);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;
  if (!order) return null;

  return (
    <main className="confirmation-page">
      <div className="confirmation-hero">
        <div className="confirmation-hero__icon">✓</div>
        <h1 className="confirmation-hero__title">Order Confirmed!</h1>
        <p className="confirmation-hero__status">Your order is being prepared.</p>
      </div>

      <div className="confirmation-details">
        <h2 className="confirmation-details__heading">Order #{order.id.slice(0, 8)}</h2>
        <p className="confirmation-details__restaurant">{order.restaurant_name}</p>
        <p className="confirmation-details__address">Delivering to: {order.delivery_address}</p>
        {cardLast4 && (
          <p className="confirmation-details__address">Paid with: card ending ···· {cardLast4}</p>
        )}

        <div className="eta-banner">
          <div className="eta-banner__label">Estimated arrival</div>
          <div className="eta-banner__time">30–40 minutes</div>
        </div>

        <div className="confirmation-items">
          {order.items.map(i => (
            <div key={i.id} className="confirmation-item">
              <span>{i.item_name} × {i.quantity}</span>
              <span>{formatPrice(i.unit_price.value * i.quantity, i.unit_price.scale)}</span>
            </div>
          ))}
        </div>

        <div className="confirmation-totals">
          <div className="confirmation-totals__row">
            <span>Subtotal</span><span>{formatPrice(order.subtotal.value, order.subtotal.scale)}</span>
          </div>
          <div className="confirmation-totals__row">
            <span>Delivery fee</span><span>{formatPrice(order.delivery_fee.value, order.delivery_fee.scale)}</span>
          </div>
          <div className="confirmation-totals__row confirmation-totals__row--total">
            <span><strong>Total</strong></span>
            <span><strong>{formatPrice(order.total.value, order.total.scale)}</strong></span>
          </div>
        </div>
      </div>

      <div className="confirmation-actions">
        <Link to="/" className="btn btn-primary">Back to Home</Link>
        <Link to="/account/orders" className="btn btn-ghost">View Order History</Link>
      </div>
    </main>
  );
}
