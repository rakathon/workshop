import { useEffect, useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client';

// ── helpers ──────────────────────────────────────────────────────────
function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function Toast({ message, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2200);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div className="toast" role="status" aria-live="polite">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
        <polyline points="20 6 9 17 4 12" />
      </svg>
      {message}
    </div>
  );
}

function SkeletonSection() {
  return (
    <>
      <div className="skeleton skeleton-card" />
      <div className="skeleton skeleton-card" />
    </>
  );
}

const CARD_TYPES = ['Visa', 'Mastercard', 'Amex'];
const CARD_ICON_CLASS = { Visa: 'card-icon--visa', Mastercard: 'card-icon--mastercard', Amex: 'card-icon--amex' };

// ── Personal info section ─────────────────────────────────────────────
function PersonalInfoSection({ profile, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [saving, setSaving] = useState(false);

  function openEdit() {
    setName(profile?.name || '');
    setPhone(profile?.phone || '');
    setPhoneError('');
    setEditing(true);
  }

  function cancelEdit() {
    setEditing(false);
    setPhoneError('');
  }

  async function handleSave(e) {
    e.preventDefault();
    const digits = phone.replace(/[\s\-\(\)]/g, '');
    if (digits && !/^\d{7,15}$/.test(digits)) {
      setPhoneError('Phone must contain 7–15 digits only');
      return;
    }
    setSaving(true);
    try {
      const body = { name: name.trim() || undefined };
      if (digits) body.phone = digits;
      else if (profile?.phone) body.phone = null;
      const updated = await api.patch('/users/me', body);
      localStorage.setItem('dishly_user_name', updated.name || updated.email.split('@')[0]);
      window.dispatchEvent(new Event('dishly:auth'));
      onSaved(updated, 'Personal info saved');
      setEditing(false);
    } catch (err) {
      setPhoneError(err.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  }

  const displayName = profile?.name || '';
  const displayPhone = profile?.phone || '';
  const displayEmail = profile?.email || localStorage.getItem('dishly_user_email') || '';

  return (
    <section className="account-section" aria-labelledby="personal-info-heading">
      <div className="account-section__title-row">
        <h2 className="account-section__title" id="personal-info-heading">Personal info</h2>
        {!editing && (
          <button className="edit-link" onClick={openEdit} aria-label="Edit personal info">Edit</button>
        )}
      </div>

      {editing ? (
        <form className="account-edit-form" onSubmit={handleSave} aria-label="Edit personal information">
          <div className="form-group">
            <label className="form-label" htmlFor="edit-name">Name</label>
            <input
              id="edit-name" className="form-input" type="text"
              value={name} onChange={e => setName(e.target.value)}
              autoComplete="name" required
            />
          </div>
          <div className="form-group">
            <label className="form-label" htmlFor="edit-phone">
              Phone <span className="optional">(optional)</span>
            </label>
            <input
              id="edit-phone" className={`form-input${phoneError ? ' error' : ''}`}
              type="tel" value={phone}
              onChange={e => { setPhone(e.target.value); setPhoneError(''); }}
              placeholder="Digits only, e.g. 4155551234"
              autoComplete="tel"
            />
            {phoneError && (
              <div className="form-error" role="alert">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                  <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                {phoneError}
              </div>
            )}
          </div>
          <div className="account-info-row" style={{ opacity: .6, pointerEvents: 'none' }}>
            <span className="account-info-row__label">Email</span>
            <span className="account-info-row__value">{displayEmail}</span>
          </div>
          <div className="form-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={saving}>
              {saving ? 'Saving…' : 'Save changes'}
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={cancelEdit}>Cancel</button>
          </div>
        </form>
      ) : (
        <>
          <div className="account-info-row">
            <span className="account-info-row__label">Name</span>
            <span className={`account-info-row__value${displayName ? '' : ' account-info-row__value--muted'}`}>
              {displayName || 'Not set'}
            </span>
          </div>
          <div className="account-info-row">
            <span className="account-info-row__label">Phone</span>
            <span className={`account-info-row__value${displayPhone ? '' : ' account-info-row__value--muted'}`}>
              {displayPhone || 'Not set'}
            </span>
          </div>
          <div className="account-info-row">
            <span className="account-info-row__label">Email</span>
            <span className="account-info-row__value">{displayEmail}</span>
          </div>
        </>
      )}
    </section>
  );
}

// ── Address section ───────────────────────────────────────────────────
function AddressSection({ onToast }) {
  const [addresses, setAddresses] = useState(null);
  const [adding, setAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [form, setForm] = useState({ label: '', street: '', city: '', postcode: '', is_default: false });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await api.get('/users/me/addresses');
      setAddresses(Array.isArray(data) ? data : (data?.data ?? []));
    } catch {
      setAddresses([]);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  function openAdd() {
    setForm({ label: '', street: '', city: '', postcode: '', is_default: addresses?.length === 0 });
    setErrors({});
    setEditingId(null);
    setAdding(true);
  }

  function openEdit(addr) {
    setForm({ label: addr.label || '', street: addr.street, city: addr.city, postcode: addr.postcode, is_default: addr.is_default });
    setErrors({});
    setAdding(false);
    setEditingId(addr.id);
  }

  function cancelForm() { setAdding(false); setEditingId(null); setErrors({}); }

  function validate() {
    const e = {};
    if (!form.street.trim()) e.street = 'Street is required';
    if (!form.city.trim()) e.city = 'City is required';
    if (!form.postcode.trim()) e.postcode = 'Postcode is required';
    return e;
  }

  async function handleSave(e) {
    e.preventDefault();
    const e2 = validate();
    if (Object.keys(e2).length) { setErrors(e2); return; }
    setSaving(true);
    try {
      const body = { street: form.street.trim(), city: form.city.trim(), postcode: form.postcode.trim(), is_default: form.is_default };
      if (form.label.trim()) body.label = form.label.trim();
      if (editingId) {
        await api.patch(`/users/me/addresses/${editingId}`, body);
        onToast('Address updated');
      } else {
        await api.post('/users/me/addresses', body);
        onToast('Address saved');
      }
      cancelForm();
      load();
    } catch (err) {
      setErrors({ general: err.message || 'Save failed' });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    try {
      await api.del(`/users/me/addresses/${id}`);
      setConfirmDeleteId(null);
      onToast('Address removed');
      load();
    } catch (err) {
      onToast(err.message || 'Delete failed');
    }
  }

  async function handleSetDefault(id) {
    try {
      await api.patch(`/users/me/addresses/${id}`, { is_default: true });
      onToast('Default address updated');
      load();
    } catch (err) {
      onToast(err.message || 'Update failed');
    }
  }

  const list = addresses ?? [];

  return (
    <section className="account-section" aria-labelledby="addresses-heading">
      <h2 className="account-section__title" id="addresses-heading">Delivery addresses</h2>

      {addresses === null && <SkeletonSection />}

      {addresses !== null && list.length === 0 && !adding && (
        <div className="section-empty">
          <div className="section-empty__icon">📍</div>
          <div className="section-empty__title">No addresses saved yet</div>
          <div className="section-empty__sub">Add an address to pre-fill checkout</div>
        </div>
      )}

      {list.map(addr => (
        <article key={addr.id} className="item-card" aria-label={addr.label || addr.street}>
          {editingId === addr.id ? (
            <form className="account-edit-form" style={{ margin: 0, border: 'none', padding: 0, background: 'transparent' }} onSubmit={handleSave} aria-label="Edit address">
              <AddressFormFields form={form} setForm={setForm} errors={errors} />
              {errors.general && <div className="form-error" role="alert">{errors.general}</div>}
              <div className="form-actions">
                <button type="submit" className="btn btn-primary btn-sm" disabled={saving}>{saving ? 'Saving…' : 'Save address'}</button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={cancelForm}>Cancel</button>
              </div>
            </form>
          ) : (
            <>
              <div className="item-card__row">
                <div className="item-card__icon" aria-hidden="true">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" />
                  </svg>
                </div>
                <div className="item-card__body">
                  <div className="item-card__title">{addr.label || addr.street}</div>
                  <div className="item-card__sub">{addr.street}, {addr.city}, {addr.postcode}</div>
                  {addr.is_default && <span className="item-card__badge">Default</span>}
                </div>
                <div className="item-card__actions">
                  <button onClick={() => openEdit(addr)} aria-label={`Edit ${addr.label || addr.street}`}>Edit</button>
                  {!addr.is_default && (
                    <button onClick={() => handleSetDefault(addr.id)} aria-label="Set as default">Set default</button>
                  )}
                  <button className="danger" onClick={() => setConfirmDeleteId(addr.id)} aria-label={`Delete ${addr.label || addr.street}`}>Delete</button>
                </div>
              </div>
              {confirmDeleteId === addr.id && (
                <div className="delete-confirm" role="alertdialog" aria-label="Confirm delete address">
                  <span className="delete-confirm__text">Delete "{addr.label || addr.street}"?</span>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="btn btn-danger-ghost btn-sm" onClick={() => handleDelete(addr.id)}>Delete</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setConfirmDeleteId(null)}>Keep it</button>
                  </div>
                </div>
              )}
            </>
          )}
        </article>
      ))}

      {adding && (
        <form className="account-edit-form" onSubmit={handleSave} aria-label="Add delivery address">
          <AddressFormFields form={form} setForm={setForm} errors={errors} />
          {errors.general && <div className="form-error" role="alert">{errors.general}</div>}
          <div className="form-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={saving}>{saving ? 'Saving…' : 'Save address'}</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={cancelForm}>Cancel</button>
          </div>
        </form>
      )}

      {!adding && !editingId && list.length < 2 && (
        <button className="add-btn" onClick={openAdd} aria-label="Add delivery address">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          Add address
        </button>
      )}
      {!adding && !editingId && list.length >= 2 && (
        <p className="cap-note">Maximum of 2 addresses reached.</p>
      )}
    </section>
  );
}

function AddressFormFields({ form, setForm, errors }) {
  return (
    <>
      <div className="form-group">
        <label className="form-label" htmlFor="addr-label">Label <span className="optional">(optional)</span></label>
        <input id="addr-label" className="form-input" type="text" placeholder="e.g. Home, Work"
          value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} />
      </div>
      <div className="form-group">
        <label className="form-label" htmlFor="addr-street">Street <span style={{ color: 'var(--color-error)' }}>*</span></label>
        <input id="addr-street" className={`form-input${errors.street ? ' error' : ''}`} type="text"
          value={form.street} onChange={e => setForm(f => ({ ...f, street: e.target.value }))} />
        {errors.street && <div className="form-error" role="alert">{errors.street}</div>}
      </div>
      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="addr-city">City <span style={{ color: 'var(--color-error)' }}>*</span></label>
          <input id="addr-city" className={`form-input${errors.city ? ' error' : ''}`} type="text"
            value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
          {errors.city && <div className="form-error" role="alert">{errors.city}</div>}
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="addr-postcode">Postcode <span style={{ color: 'var(--color-error)' }}>*</span></label>
          <input id="addr-postcode" className={`form-input${errors.postcode ? ' error' : ''}`} type="text"
            value={form.postcode} onChange={e => setForm(f => ({ ...f, postcode: e.target.value }))} />
          {errors.postcode && <div className="form-error" role="alert">{errors.postcode}</div>}
        </div>
      </div>
      <div className="form-group">
        <label className="form-checkbox">
          <input type="checkbox" checked={form.is_default} onChange={e => setForm(f => ({ ...f, is_default: e.target.checked }))} />
          Set as default delivery address
        </label>
      </div>
    </>
  );
}

// ── Payment methods section ───────────────────────────────────────────
function PaymentSection({ onToast }) {
  const [methods, setMethods] = useState(null);
  const [adding, setAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [form, setForm] = useState({ card_type: '', cardholder_name: '', card_number: '' });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await api.get('/users/me/payment_methods');
      setMethods(Array.isArray(data) ? data : (data?.data ?? []));
    } catch {
      setMethods([]);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  function openAdd() {
    setForm({ card_type: '', cardholder_name: '', card_number: '' });
    setErrors({});
    setEditingId(null);
    setAdding(true);
  }

  function openEdit(pm) {
    // card_number is never stored in full — leave blank for re-entry
    setForm({ card_type: pm.card_type, cardholder_name: pm.cardholder_name, card_number: '' });
    setErrors({});
    setAdding(false);
    setEditingId(pm.id);
  }

  function cancelForm() { setAdding(false); setEditingId(null); setErrors({}); }

  async function handleSave(e) {
    e.preventDefault();
    const e2 = {};
    if (!form.card_type) e2.card_type = 'Please select a card type';
    if (!form.cardholder_name.trim()) e2.cardholder_name = 'Cardholder name is required';
    const digits = (form.card_number || '').replace(/\s/g, '');
    if (!editingId && !/^\d{16}$/.test(digits)) e2.card_number = 'Enter a valid 16-digit card number';
    if (Object.keys(e2).length) { setErrors(e2); return; }
    setSaving(true);
    try {
      const body = { card_type: form.card_type, cardholder_name: form.cardholder_name.trim() };
      if (!editingId) body.card_number = digits;
      if (editingId) {
        await api.patch(`/users/me/payment_methods/${editingId}`, body);
        onToast('Payment method updated');
      } else {
        await api.post('/users/me/payment_methods', body);
        onToast('Payment method saved');
      }
      cancelForm();
      load();
    } catch (err) {
      setErrors({ general: err.message || 'Save failed' });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    try {
      await api.del(`/users/me/payment_methods/${id}`);
      setConfirmDeleteId(null);
      onToast('Payment method removed');
      load();
    } catch (err) {
      onToast(err.message || 'Delete failed');
    }
  }

  const list = methods ?? [];

  return (
    <section className="account-section" aria-labelledby="payments-heading">
      <h2 className="account-section__title" id="payments-heading">Payment methods</h2>

      {methods === null && <SkeletonSection />}

      {methods !== null && list.length === 0 && !adding && (
        <div className="section-empty">
          <div className="section-empty__icon">💳</div>
          <div className="section-empty__title">No payment methods saved</div>
          <div className="section-empty__sub">Mock cards only — no real processing</div>
        </div>
      )}

      {list.map(pm => (
        <article key={pm.id} className="item-card" aria-label={`${pm.card_type} — ${pm.cardholder_name}`}>
          {editingId === pm.id ? (
            <form className="account-edit-form" style={{ margin: 0, border: 'none', padding: 0, background: 'transparent' }} onSubmit={handleSave} aria-label="Edit payment method">
              <PaymentFormFields form={form} setForm={setForm} errors={errors} isEdit={true} />
              {errors.general && <div className="form-error" role="alert">{errors.general}</div>}
              <div className="form-actions">
                <button type="submit" className="btn btn-primary btn-sm" disabled={saving}>{saving ? 'Saving…' : 'Save card'}</button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={cancelForm}>Cancel</button>
              </div>
            </form>
          ) : (
            <>
              <div className="item-card__row">
                <div className="item-card__icon" aria-hidden="true">
                  <div className={`card-icon ${CARD_ICON_CLASS[pm.card_type] || ''}`}>
                    {pm.card_type.slice(0, 2).toUpperCase()}
                  </div>
                </div>
                <div className="item-card__body">
                  <div className="item-card__title">{pm.card_type}{pm.last_four ? ` •••• ${pm.last_four}` : ''}</div>
                  <div className="item-card__sub">{pm.cardholder_name}</div>
                </div>
                <div className="item-card__actions">
                  <button onClick={() => openEdit(pm)} aria-label={`Edit ${pm.card_type} card`}>Edit</button>
                  <button className="danger" onClick={() => setConfirmDeleteId(pm.id)} aria-label={`Delete ${pm.card_type} card`}>Delete</button>
                </div>
              </div>
              {confirmDeleteId === pm.id && (
                <div className="delete-confirm" role="alertdialog" aria-label="Confirm delete payment method">
                  <span className="delete-confirm__text">Delete {pm.card_type} card?</span>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="btn btn-danger-ghost btn-sm" onClick={() => handleDelete(pm.id)}>Delete</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setConfirmDeleteId(null)}>Keep it</button>
                  </div>
                </div>
              )}
            </>
          )}
        </article>
      ))}

      {adding && (
        <form className="account-edit-form" onSubmit={handleSave} aria-label="Add payment method">
          <PaymentFormFields form={form} setForm={setForm} errors={errors} />
          {errors.general && <div className="form-error" role="alert">{errors.general}</div>}
          <div className="form-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={saving}>{saving ? 'Saving…' : 'Save card'}</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={cancelForm}>Cancel</button>
          </div>
        </form>
      )}

      {!adding && !editingId && list.length < 2 && (
        <button className="add-btn" onClick={openAdd} aria-label="Add payment method">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          Add payment method
        </button>
      )}
      {!adding && !editingId && list.length >= 2 && (
        <p className="cap-note">Maximum of 2 payment methods reached.</p>
      )}
    </section>
  );
}

function PaymentFormFields({ form, setForm, errors, isEdit = false }) {
  return (
    <>
      <div className="form-group">
        <label className="form-label" htmlFor="pm-type">Card type <span style={{ color: 'var(--color-error)' }}>*</span></label>
        <select id="pm-type" className={`form-select${errors.card_type ? ' error' : ''}`}
          value={form.card_type} onChange={e => setForm(f => ({ ...f, card_type: e.target.value }))}>
          <option value="">Select card type</option>
          {CARD_TYPES.map(t => <option key={t}>{t}</option>)}
        </select>
        {errors.card_type && <div className="form-error" role="alert">{errors.card_type}</div>}
      </div>
      {!isEdit && (
        <div className="form-group">
          <label className="form-label" htmlFor="pm-number">Card number <span style={{ color: 'var(--color-error)' }}>*</span></label>
          <input
            id="pm-number"
            className={`form-input${errors.card_number ? ' error' : ''}`}
            type="text"
            inputMode="numeric"
            placeholder="1234 5678 9012 3456"
            maxLength={19}
            value={form.card_number || ''}
            onChange={e => {
              const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
              setForm(f => ({ ...f, card_number: raw.replace(/(.{4})/g, '$1 ').trim() }));
            }}
          />
          {errors.card_number && <div className="form-error" role="alert">{errors.card_number}</div>}
        </div>
      )}
      <div className="form-group">
        <label className="form-label" htmlFor="pm-name">Cardholder name <span style={{ color: 'var(--color-error)' }}>*</span></label>
        <input id="pm-name" className={`form-input${errors.cardholder_name ? ' error' : ''}`}
          type="text" placeholder="As on card" value={form.cardholder_name}
          onChange={e => setForm(f => ({ ...f, cardholder_name: e.target.value }))} />
        {errors.cardholder_name && <div className="form-error" role="alert">{errors.cardholder_name}</div>}
      </div>
    </>
  );
}

// ── Main Account page ─────────────────────────────────────────────────
export default function Account() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [toast, setToast] = useState(null);

  const token    = localStorage.getItem('dishly_token');
  const name     = localStorage.getItem('dishly_user_name') || '';
  const email    = localStorage.getItem('dishly_user_email') || '';

  useEffect(() => {
    if (!token) { navigate('/login'); return; }
    api.get('/users/me')
      .then(data => setProfile(data))
      .catch(() => setProfile({ email }));
  }, []);

  function handleSignOut() {
    ['dishly_token', 'dishly_user_name', 'dishly_user_email', 'dishly_user_id'].forEach(k => localStorage.removeItem(k));
    window.dispatchEvent(new Event('dishly:auth'));
    navigate('/');
  }

  function handleProfileSaved(updated, msg) {
    setProfile(updated);
    setToast(msg);
  }

  const displayName = profile?.name || name || 'dishly member';

  return (
    <main className="account-page">
      <div className="account-page__inner">

        {/* Profile header */}
        <div className="account-card">
          <div className="account-avatar" aria-hidden="true">{initials(displayName)}</div>
          <div className="account-card__info">
            <h1 className="account-card__name">{displayName}</h1>
            <p className="account-card__email">{profile?.email || email}</p>
          </div>
        </div>

        <PersonalInfoSection
          profile={profile || { name, email, phone: '' }}
          onSaved={handleProfileSaved}
        />

        <AddressSection onToast={setToast} />

        <PaymentSection onToast={setToast} />

        {/* Quick links */}
        <section className="account-section" aria-labelledby="orders-heading">
          <h2 className="account-section__title" id="orders-heading">Your orders</h2>
          <Link to="/account/orders" className="account-link-row">
            <div className="account-link-row__icon" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10,9 9,9 8,9"/></svg>
            </div>
            <div className="account-link-row__body">
              <span className="account-link-row__label">Order history</span>
              <span className="account-link-row__sub">View all your past orders</span>
            </div>
            <svg className="account-link-row__chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><polyline points="9,18 15,12 9,6"/></svg>
          </Link>
          <Link to="/cart" className="account-link-row">
            <div className="account-link-row__icon" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
            </div>
            <div className="account-link-row__body">
              <span className="account-link-row__label">Current cart</span>
              <span className="account-link-row__sub">Review items before checkout</span>
            </div>
            <svg className="account-link-row__chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><polyline points="9,18 15,12 9,6"/></svg>
          </Link>
        </section>

        <button className="btn btn-secondary account-signout" onClick={handleSignOut} style={{ width: '100%', borderRadius: 12 }}>
          Sign out
        </button>

      </div>

      {toast && <Toast message={toast} onDone={() => setToast(null)} />}
    </main>
  );
}
