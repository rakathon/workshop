import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import EmptyState from '../components/EmptyState';

function formatPrice(value, scale) {
  return '$' + (value / Math.pow(10, scale)).toFixed(2);
}

const DELIVERY_FEE = 3.99;

export default function Cart() {
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();

  if (!cart.items.length) {
    return (
      <main className="cart-page">
        <h1 className="cart-page__title">Your Cart</h1>
        <EmptyState message="Your cart is empty. Browse restaurants to add items." />
        <Link to="/" className="btn btn-primary">Browse Restaurants</Link>
      </main>
    );
  }

  const subtotal = cart.items.reduce(
    (sum, i) => sum + (i.price.value / Math.pow(10, i.price.scale)) * i.quantity, 0
  );
  const total = subtotal + DELIVERY_FEE;

  return (
    <main className="cart-page">
      <h1 className="cart-page__title">Your Cart</h1>
      <p className="cart-page__restaurant">From: <strong>{cart.restaurantName}</strong></p>

      <div className="cart-items">
        {cart.items.map(item => (
          <div key={item.id} className="cart-item">
            <span className="cart-item__name">{item.name}</span>
            <span className="cart-item__qty">× {item.quantity}</span>
            <span className="cart-item__price">
              {formatPrice(item.price.value * item.quantity, item.price.scale)}
            </span>
          </div>
        ))}
      </div>

      <div className="cart-summary">
        <div className="cart-summary__row">
          <span>Subtotal</span><span>{formatPrice(Math.round(subtotal * 100), 2)}</span>
        </div>
        <div className="cart-summary__row">
          <span>Delivery fee</span><span>$3.99</span>
        </div>
        <div className="cart-summary__row cart-summary__row--total">
          <span>Total</span><span>{formatPrice(Math.round(total * 100), 2)}</span>
        </div>
      </div>

      <div className="cart-actions">
        <button className="btn btn-primary" onClick={() => navigate('/checkout')}>
          Proceed to Checkout
        </button>
        <button className="btn btn-ghost" onClick={clearCart}>
          Clear cart
        </button>
      </div>
    </main>
  );
}
