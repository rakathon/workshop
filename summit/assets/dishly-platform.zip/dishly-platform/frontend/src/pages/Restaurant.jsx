import { useParams, useNavigate } from 'react-router-dom';
import { useRestaurant } from '../api/hooks';
import { useCart } from '../hooks/useCart';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

function formatPrice(value, scale) {
  return '$' + (value / Math.pow(10, scale)).toFixed(2);
}

function ReviewerAvatar({ name }) {
  const initials = name
    ? name.split(/[\s.]+/).filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase()
    : '?';
  return <div className="review__avatar" aria-hidden="true">{initials}</div>;
}

function StarRating({ rating, max = 5 }) {
  return (
    <span className="review__stars" aria-label={`${rating} out of ${max} stars`}>
      {Array.from({ length: max }, (_, i) => (
        <span key={i} className={i < rating ? 'star star--filled' : 'star star--empty'}>★</span>
      ))}
    </span>
  );
}

export default function Restaurant() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: restaurant, loading, error } = useRestaurant(id);
  const { cart, addItem, decrementItem } = useCart();

  function handleAddToCart(item, restaurant) {
    if (!localStorage.getItem('dishly_token')) {
      navigate('/login', { state: { returnTo: `/restaurants/${id}` } });
      return;
    }
    addItem(item, restaurant);
  }

  function getQty(itemId) {
    return cart.items.find(i => i.id === itemId)?.quantity ?? 0;
  }

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;
  if (!restaurant) return null;

  const { name, cuisine, neighbourhood, price_range, average_rating, cover_image_url, description, address, menu, reviews } = restaurant;

  const cartTotal = cart.items.reduce((sum, i) => sum + i.price.value * i.quantity, 0);
  const cartCount = cart.items.reduce((sum, i) => sum + i.quantity, 0);
  const isSameRestaurant = cart.restaurantId === id;

  return (
    <main className="restaurant-page">

      {/* ── HERO: full-bleed cover with name + meta overlaid ── */}
      <div className="restaurant-hero">
        {cover_image_url ? (
          <img
            className="restaurant-hero__img"
            src={cover_image_url}
            alt={name}
            onError={e => { e.target.style.display = 'none'; }}
          />
        ) : (
          <div className="restaurant-hero__placeholder" aria-hidden="true" />
        )}
        <div className="restaurant-hero__gradient" />
        <div className="restaurant-hero__content">
          {cuisine?.name && (
            <div className="restaurant-hero__cuisine-chip">{cuisine.name}</div>
          )}
          <h1 className="restaurant-hero__name">{name}</h1>
          <div className="restaurant-hero__pills">
            {neighbourhood?.name && (
              <span className="restaurant-hero__pill">{neighbourhood.name}</span>
            )}
            {price_range && (
              <span className="restaurant-hero__pill">{price_range}</span>
            )}
            {average_rating != null && (
              <span className="restaurant-hero__pill restaurant-hero__pill--rating">
                <span className="restaurant-hero__star">★</span>
                {average_rating.toFixed(1)}
              </span>
            )}
            <span className="restaurant-hero__pill">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
              25–35 min
            </span>
          </div>
        </div>
      </div>

      {/* ── STICKY SECTION NAV ── */}
      <nav className="restaurant-section-nav" aria-label="Page sections">
        <a className="restaurant-section-nav__tab restaurant-section-nav__tab--active" href="#menu">Menu</a>
        {reviews?.length > 0 && (
          <a className="restaurant-section-nav__tab" href="#reviews">Reviews</a>
        )}
        <a className="restaurant-section-nav__tab" href="#info">Info</a>
        <div className="restaurant-section-nav__spacer" />
        {isSameRestaurant && cartCount > 0 && (
          <div className="restaurant-section-nav__cart">
            Your order
            <span className="restaurant-section-nav__cart-badge">{cartCount}</span>
          </div>
        )}
      </nav>

      {/* ── PAGE BODY: two-column layout ── */}
      <div className="restaurant-body">

        {/* MAIN COLUMN */}
        <div className="restaurant-main">

          {/* Info strip — address + description only; cuisine/price/rating shown in hero + sidebar */}
          <div className="restaurant-info-strip" id="info">
            <div className="restaurant-info-strip__address">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              {address}
            </div>
            {description && (
              <p className="restaurant-info-strip__desc">{description}</p>
            )}
          </div>

          {/* Menu */}
          <section id="menu">
            {menu?.length ? menu.map(section => (
              <div key={section.id} className="menu-section">
                <h2 className="menu-section__name">{section.name}</h2>
                <div className="menu-items">
                  {section.items.map(item => (
                    <div key={item.id} className="menu-item">
                      {item.image_url ? (
                        <img
                          className="menu-item__img"
                          src={item.image_url}
                          alt={item.name}
                          onError={e => {
                            e.currentTarget.style.display = 'none';
                            e.currentTarget.nextSibling?.removeAttribute('style');
                          }}
                        />
                      ) : null}
                      <div
                        className="menu-item__img menu-item__img--placeholder"
                        style={{ display: item.image_url ? 'none' : 'block' }}
                        aria-hidden="true"
                      />
                      <div className="menu-item__body">
                        <h3 className="menu-item__name">{item.name}</h3>
                        <p className="menu-item__desc">{item.description}</p>
                        <div className="menu-item__footer">
                          <span className="menu-item__price">{formatPrice(item.price.value, item.price.scale)}</span>
                          {getQty(item.id) === 0 ? (
                            <button
                              className="menu-item__add"
                              onClick={() => handleAddToCart({ id: item.id, name: item.name, price: item.price }, restaurant)}
                            >
                              + Add
                            </button>
                          ) : (
                            <div className="menu-item__stepper">
                              <button
                                className="menu-item__stepper-btn"
                                aria-label="Remove one"
                                onClick={() => decrementItem(item.id)}
                              >−</button>
                              <span className="menu-item__stepper-qty">{getQty(item.id)}</span>
                              <button
                                className="menu-item__stepper-btn"
                                aria-label="Add one more"
                                onClick={() => handleAddToCart({ id: item.id, name: item.name, price: item.price }, restaurant)}
                              >+</button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )) : <p className="menu__empty">Menu coming soon.</p>}
          </section>

          {/* Reviews */}
          {reviews?.length > 0 && (
            <section className="reviews" id="reviews">
              <h2 className="reviews__heading">
                Reviews
                <span className="reviews__rating-pill">★ {average_rating?.toFixed(1)}</span>
              </h2>
              {reviews.map(r => (
                <div key={r.id} className="review">
                  <div className="review__header">
                    <ReviewerAvatar name={r.author_name} />
                    <div className="review__meta">
                      <span className="review__author">{r.author_name}</span>
                      <span className="review__date">{r.review_date}</span>
                    </div>
                    <StarRating rating={r.rating} />
                  </div>
                  <p className="review__body">{r.body}</p>
                </div>
              ))}
            </section>
          )}
        </div>

        {/* SIDEBAR: sticky info + cart */}
        <aside className="restaurant-sidebar">

          <div className="restaurant-sidebar__info">
            <div className="restaurant-sidebar__title">About</div>
            <div className="restaurant-sidebar__row">
              <span className="restaurant-sidebar__label">Cuisine</span>
              <span className="restaurant-sidebar__value">{cuisine?.name}</span>
            </div>
            <div className="restaurant-sidebar__row">
              <span className="restaurant-sidebar__label">Price</span>
              <span className="restaurant-sidebar__value">{price_range}</span>
            </div>
            {average_rating != null && (
              <div className="restaurant-sidebar__row">
                <span className="restaurant-sidebar__label">Rating</span>
                <span className="restaurant-sidebar__value restaurant-sidebar__value--star">★ {average_rating.toFixed(1)}</span>
              </div>
            )}
            <div className="restaurant-sidebar__row">
              <span className="restaurant-sidebar__label">Delivery</span>
              <span className="restaurant-sidebar__value">25–35 min</span>
            </div>
            <div className="restaurant-sidebar__row restaurant-sidebar__row--address">
              <span className="restaurant-sidebar__label">Address</span>
              <span className="restaurant-sidebar__value restaurant-sidebar__value--address">{address}</span>
            </div>
          </div>

          {isSameRestaurant && cartCount > 0 && (
            <div className="restaurant-sidebar__cart">
              <div className="restaurant-sidebar__cart-header">
                <span className="restaurant-sidebar__title">Your order</span>
                <span className="restaurant-sidebar__cart-count">{cartCount} item{cartCount !== 1 ? 's' : ''}</span>
              </div>
              {cart.items.map(i => (
                <div key={i.id} className="restaurant-sidebar__cart-item">
                  <span className="restaurant-sidebar__cart-name">{i.name}</span>
                  <span className="restaurant-sidebar__cart-qty">× {i.quantity}</span>
                  <span className="restaurant-sidebar__cart-price">{formatPrice(i.price.value * i.quantity, i.price.scale)}</span>
                </div>
              ))}
              <div className="restaurant-sidebar__cart-divider" />
              <div className="restaurant-sidebar__cart-total">
                <span>Subtotal</span>
                <span>{formatPrice(cartTotal, 2)}</span>
              </div>
              <div className="restaurant-sidebar__cart-delivery">
                <span>Delivery fee</span>
                <span>$3.99</span>
              </div>
              <button
                className="restaurant-sidebar__checkout-btn"
                onClick={() => navigate('/checkout')}
              >
                Go to checkout
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true"><polyline points="9,18 15,12 9,6"/></svg>
              </button>
            </div>
          )}

          {(!isSameRestaurant || cartCount === 0) && (
            <div className="restaurant-sidebar__cart-empty">
              <div className="restaurant-sidebar__cart-empty-icon">🛒</div>
              <div className="restaurant-sidebar__cart-empty-text">Add items to start your order</div>
            </div>
          )}

        </aside>
      </div>
    </main>
  );
}
