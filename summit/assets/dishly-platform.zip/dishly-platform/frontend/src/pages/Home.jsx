import { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCollections, useRestaurants } from '../api/hooks';
import CitySelector, { useCityFilter } from '../components/CitySelector';
import RestaurantCard from '../components/RestaurantCard';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

const CHIPS = ['All', 'Ramen', 'Thai', 'Soba', 'Mexican', 'Pizza', 'Sushi', 'Indian', 'Brunch'];

// Map chip label → cuisine name in the seed data
const CHIP_TO_CUISINE = {
  Ramen:   'Japanese',
  Soba:    'Japanese',
  Thai:    'Thai',
  Mexican: 'Mexican',
  Pizza:   'Italian',
  Sushi:   'Japanese',
  Indian:  'Indian',
  Brunch:  'American',
};

function filterCollections(collections, chip) {
  if (!chip || chip === 'All') return collections;
  const cuisine = CHIP_TO_CUISINE[chip];
  if (!cuisine) return collections;
  return collections
    .map(col => ({
      ...col,
      restaurants: col.restaurants.filter(r =>
        r.cuisine?.name?.toLowerCase() === cuisine.toLowerCase()
      ),
    }))
    .filter(col => col.restaurants.length > 0);
}

export default function Home() {
  const { city, selectCity } = useCityFilter();
  const { data: collections, loading, error } = useCollections(city?.id || null);
  const [q, setQ] = useState('');
  const [activeChip, setActiveChip] = useState('All');
  const navigate = useNavigate();

  // Re-render when city changes from NavBar
  const [, forceUpdate] = useState(0);
  useEffect(() => {
    function onCityChange() { forceUpdate(n => n + 1); }
    window.addEventListener('dishly:city-changed', onCityChange);
    return () => window.removeEventListener('dishly:city-changed', onCityChange);
  }, []);

  // Collections are already filtered by city from the API (neighbourhood_id passed to useCollections)
  const filteredCollections = useMemo(
    () => filterCollections(collections || [], activeChip),
    [collections, activeChip]
  );

  // Fallback when cuisine chip yields no collections for the selected city
  const needsFallback = filteredCollections.length === 0;

  const chipCuisine = CHIP_TO_CUISINE[activeChip] || activeChip;
  const fallbackParams = needsFallback ? {
    ...(activeChip !== 'All' ? { q: chipCuisine } : {}),
    ...(city ? { neighbourhood_id: city.id } : {}),
  } : {};
  const { data: cuisineRestaurants, loading: cuisineLoading } = useRestaurants(
    needsFallback ? fallbackParams : {}
  );

  function handleSearch(e) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (q.trim()) params.set('q', q.trim());
    if (city) params.set('neighbourhood_id', city.id);
    navigate(`/search?${params.toString()}`);
  }

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  const showFallback = needsFallback && !cuisineLoading;
  const fallbackRestaurants = cuisineRestaurants || [];

  return (
    <main className="home">
      <section className="hero">
        <h1 className="hero-headline">Find food worth eating.</h1>
        <p className="hero-sub">Every restaurant on dishly was placed here by someone who knows food — not paid placement.</p>
        <form className="hero-search" onSubmit={handleSearch}>
          <CitySelector city={city} onSelect={selectCity} />
          <div className="hero-search-divider" aria-hidden="true" />
          <input
            type="search"
            placeholder="Try 'ramen', 'Thai', 'brunch'…"
            value={q}
            onChange={e => setQ(e.target.value)}
          />
          <button type="submit" className="btn btn-primary">Search</button>
        </form>
      </section>

      <div className="filter-chips-bar">
        <div className="filter-chips">
          {CHIPS.map(chip => (
            <button
              key={chip}
              className={`filter-chip${activeChip === chip ? ' filter-chip--active' : ''}`}
              aria-pressed={activeChip === chip}
              onClick={() => {
                if (chip !== 'All') {
                  const params = new URLSearchParams({ q: chip });
                  if (city) params.set('neighbourhood_id', city.id);
                  navigate(`/search?${params.toString()}`);
                } else {
                  setActiveChip('All');
                }
              }}
            >
              {chip}
            </button>
          ))}
        </div>
      </div>

      {/* Fallback: flat grid of all restaurants for that cuisine */}
      {showFallback && (
        <div className="collections-area">
          {!fallbackRestaurants.length ? (
            <EmptyState message={city ? `No restaurants in ${city.name} yet.` : `No ${activeChip} restaurants found.`} />
          ) : (
            <section className="collection">
              <div className="collection__header">
                <div>
                  <h2 className="collection__title">
                    {city && activeChip === 'All' ? `Restaurants in ${city.name}` : `${activeChip} Restaurants${city ? ` in ${city.name}` : ''}`}
                  </h2>
                </div>
                <a
                  href="#"
                  className="collection__see-all"
                  onClick={e => {
                    e.preventDefault();
                    const p = new URLSearchParams();
                    if (city) p.set('neighbourhood_id', city.id);
                    navigate(`/search?${p.toString()}`);
                  }}
                >
                  See all →
                </a>
              </div>
              <div className="collection__grid">
                {fallbackRestaurants.slice(0, 8).map(r => (
                  <RestaurantCard key={r.id} restaurant={r} />
                ))}
              </div>
            </section>
          )}
        </div>
      )}

      {/* Normal: filtered collections */}
      {!showFallback && (
        !filteredCollections.length ? (
          <EmptyState message={`No ${activeChip} restaurants in curated collections.`} />
        ) : (
          <div className="collections-area">
            {filteredCollections.map((col, idx) => (
              <section key={col.id} className="collection">
                <div className="collection__header">
                  <div>
                    <h2 className="collection__title">{col.title}</h2>
                    {col.description && <p className="collection__desc">{col.description}</p>}
                  </div>
                  <a
                    href="#"
                    className="collection__see-all"
                    onClick={e => {
                      e.preventDefault();
                      const p = new URLSearchParams();
                      if (city) p.set('neighbourhood_id', city.id);
                      navigate(`/search?${p.toString()}`);
                    }}
                  >
                    See all →
                  </a>
                </div>
                <div className="collection__grid">
                  {col.restaurants.slice(0, 4).map(r => (
                    <RestaurantCard key={r.id} restaurant={r} />
                  ))}
                </div>

                {idx === 0 && activeChip === 'All' && (
                  <div className="curated-banner" style={{ marginTop: '32px' }}>
                    <p className="curated-banner__headline">Curated. Not sponsored.</p>
                    <p className="curated-banner__sub">Every restaurant passes an editorial review. Paid placement is permanently excluded.</p>
                  </div>
                )}
              </section>
            ))}
          </div>
        )
      )}
    </main>
  );
}
