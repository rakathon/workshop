import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useState, useRef, useEffect } from 'react';
import { useCart } from '../hooks/useCart';
import CitySelector, { useCityFilter } from './CitySelector';

function UserAvatar({ name }) {
  const initials = name
    ? name.split(/[\s@_.-]+/).filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase()
    : null;
  return (
    <div className="navbar__avatar" aria-label={name || 'Account'}>
      {initials || (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
      )}
    </div>
  );
}

export default function NavBar() {
  const navigate = useNavigate();
  const location = useLocation();
  const isHome = location.pathname === '/';
  // Pre-populate search box from URL on search page
  const searchParams = new URLSearchParams(location.search);
  const [q, setQ] = useState(searchParams.get('q') || '');
  const [menuOpen, setMenuOpen] = useState(false);
  const [authStamp, setAuthStamp] = useState(0);
  const menuRef = useRef(null);
  const { cartCount } = useCart();
  const { city, selectCity } = useCityFilter();

  useEffect(() => {
    function onAuth() { setAuthStamp(s => s + 1); }
    window.addEventListener('dishly:auth', onAuth);
    return () => window.removeEventListener('dishly:auth', onAuth);
  }, []);

  // Sync search box with URL q= param when navigating
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const urlQ = params.get('q') || '';
    setQ(urlQ);
  }, [location.search]);

  const token = localStorage.getItem('dishly_token');
  const userName = localStorage.getItem('dishly_user_name');
  const userEmail = localStorage.getItem('dishly_user_email');
  const isAuthed = !!token;
  void authStamp;

  function handleSearch(e) {
    e.preventDefault();
    if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  }

  function handleSignOut() {
    localStorage.removeItem('dishly_token');
    localStorage.removeItem('dishly_user_name');
    localStorage.removeItem('dishly_user_email');
    localStorage.removeItem('dishly_user_id');
    setMenuOpen(false);
    navigate('/');
  }

  // Close dropdown when clicking outside or pressing Escape
  useEffect(() => {
    function onClickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    }
    function onKeyDown(e) {
      if (e.key === 'Escape') {
        setMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', onClickOutside);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onClickOutside);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, []);

  return (
    <>
    <div className="announce-bar">
      Now in closed beta —<a href="#">Request early access →</a>
    </div>
    <nav className="navbar">
      <Link to="/" className="navbar__brand">
        dish<span>ly</span>
      </Link>

      {!isHome && <CitySelector city={city} onSelect={selectCity} />}

      <form className="navbar__search" onSubmit={handleSearch} style={isHome ? { display: 'none' } : {}}>
        <input
          type="search"
          className="navbar__search-input"
          placeholder="Search restaurants or cuisines…"
          value={q}
          onChange={e => setQ(e.target.value)}
          aria-label="Search"
        />
        <button type="submit" className="navbar__search-btn">Search</button>
      </form>

      <div className="navbar__actions">
        {isAuthed ? (
          <>
            <Link to="/cart" className="navbar__cart-btn">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
              Cart
              {cartCount > 0 && (
                <span className="navbar__badge">{cartCount}</span>
              )}
            </Link>

            <div className="navbar__profile" ref={menuRef}>
              <button
                className="navbar__profile-btn"
                onClick={() => setMenuOpen(o => !o)}
                aria-expanded={menuOpen}
                aria-haspopup="true"
              >
                <UserAvatar name={userName} />
              </button>

              {menuOpen && (
                <div className="navbar__dropdown" role="menu">
                  <div className="navbar__dropdown-header">
                    <div className="navbar__dropdown-name">{userName}</div>
                    {userEmail && <div className="navbar__dropdown-email">{userEmail}</div>}
                  </div>
                  <div className="navbar__dropdown-divider" />
                  <Link to="/account" className="navbar__dropdown-item" role="menuitem" onClick={() => setMenuOpen(false)}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    My account
                  </Link>
                  <Link to="/account/orders" className="navbar__dropdown-item" role="menuitem" onClick={() => setMenuOpen(false)}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>
                    Order history
                  </Link>
                  <div className="navbar__dropdown-divider" />
                  <button className="navbar__dropdown-item navbar__dropdown-item--danger" role="menuitem" onClick={handleSignOut}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <Link to="/login" className="navbar__link btn btn-ghost btn-sm">Sign in</Link>
            <Link to="/register" className="navbar__link btn btn-primary btn-sm">Join dishly</Link>
          </>
        )}
      </div>
    </nav>
    </>
  );
}
