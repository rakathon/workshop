import { useState, useEffect, useRef } from 'react';
import { useCities } from '../api/hooks';
import { matchCity } from '../config/cityBounds';

const STORAGE_KEY = 'dishly_city';

function loadStoredCity() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || null; }
  catch { return null; }
}

export function useCityFilter() {
  const [city, setCity] = useState(loadStoredCity);

  useEffect(() => {
    function onAuth() { setCity(null); localStorage.removeItem(STORAGE_KEY); }
    window.addEventListener('dishly:auth', onAuth);
    return () => window.removeEventListener('dishly:auth', onAuth);
  }, []);

  function selectCity(c) {
    setCity(c);
    if (c) localStorage.setItem(STORAGE_KEY, JSON.stringify(c));
    else localStorage.removeItem(STORAGE_KEY);
    window.dispatchEvent(new CustomEvent('dishly:city-changed', { detail: c }));
  }

  return { city, selectCity };
}

export default function CitySelector({ city, onSelect, size = 'md' }) {
  const { data: cities, loading: citiesLoading } = useCities();
  const [open, setOpen] = useState(false);
  const [geoState, setGeoState] = useState('idle'); // idle | loading | error
  const ref = useRef(null);

  useEffect(() => {
    function onClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    function onKey(e) { if (e.key === 'Escape') setOpen(false); }
    document.addEventListener('mousedown', onClickOutside);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onClickOutside); document.removeEventListener('keydown', onKey); };
  }, []);

  function toggle() {
    setOpen(o => !o);
  }

  function handleSelect(c) {
    onSelect(c);
    setOpen(false);
    setGeoState('idle');
  }

  function handleNearMe() {
    setOpen(false);
    setGeoState('loading');
    navigator.geolocation.getCurrentPosition(
      pos => {
        const matched = matchCity(pos.coords.latitude, pos.coords.longitude, cities);
        setGeoState('idle');
        if (matched) onSelect(matched);
        else setGeoState('error');
      },
      () => setGeoState('error'),
      { timeout: 8000 }
    );
  }

  const isSmall = size === 'sm';

  return (
    <div className={`city-selector${isSmall ? ' city-selector--sm' : ''}`} ref={ref}>
      <button
        className={`city-selector__btn${city ? ' city-selector__btn--active' : ''}${geoState === 'loading' ? ' city-selector__btn--loading' : ''}`}
        onClick={toggle}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Select city"
        type="button"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
          <circle cx="12" cy="10" r="3"/>
        </svg>
        <span className="city-selector__label">
          {geoState === 'loading' ? 'Detecting…' : city?.name || 'All cities'}
        </span>
        {city && geoState !== 'loading' && (
          <span
            className="city-selector__clear"
            role="button"
            tabIndex={0}
            aria-label="Clear city filter"
            onClick={e => { e.stopPropagation(); onSelect(null); setGeoState('idle'); }}
            onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.stopPropagation(); onSelect(null); setGeoState('idle'); } }}
          >×</span>
        )}
      </button>

      {geoState === 'error' && (
        <div className="city-selector__geo-error" role="alert">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          Location unavailable — please select a city manually
        </div>
      )}

      {open && (
        <div className="city-dropdown" role="listbox" aria-label="Select city">
          {/* Near me — always first */}
          <button
            className="city-dropdown__item city-dropdown__item--near-me"
            onClick={handleNearMe}
            role="option"
            type="button"
            aria-label="Use my current location to detect city"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
              <circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22"/>
              <line x1="2" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22" y2="12"/>
            </svg>
            Near me
          </button>

          {citiesLoading ? (
            <div className="city-dropdown__empty">Loading cities…</div>
          ) : (cities || []).map(c => (
            <button
              key={c.id}
              className={`city-dropdown__item${city?.id === c.id ? ' city-dropdown__item--active' : ''}`}
              onClick={() => handleSelect(c)}
              role="option"
              aria-selected={city?.id === c.id}
              type="button"
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
              </svg>
              {c.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
