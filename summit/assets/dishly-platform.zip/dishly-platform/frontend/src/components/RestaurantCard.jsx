import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function RestaurantCard({ restaurant }) {
  const { id, name, cuisine, neighbourhood, price_range, average_rating, cover_image_url } = restaurant;
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <Link to={`/restaurants/${id}`} className="restaurant-card">
      <div className="restaurant-card__image">
        {cover_image_url && !imgFailed ? (
          <img
            src={cover_image_url}
            alt={name}
            onError={() => setImgFailed(true)}
          />
        ) : (
          <div className="restaurant-card__image-placeholder" aria-hidden="true" />
        )}
      </div>
      <div className="restaurant-card__body">
        <h3 className="restaurant-card__name">{name}</h3>
        <div className="restaurant-card__meta">
          {cuisine?.name}
          {neighbourhood?.name && (
            <>
              <span className="dot-sep">·</span>
              {neighbourhood.name}
            </>
          )}
        </div>
        <div className="restaurant-card__footer">
          <span className="restaurant-card__price">{price_range}</span>
          <span className="restaurant-card__rating">{average_rating?.toFixed(1)}</span>
        </div>
      </div>
    </Link>
  );
}
