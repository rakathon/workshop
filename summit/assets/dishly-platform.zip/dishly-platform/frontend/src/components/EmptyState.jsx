export default function EmptyState({ message }) {
  return <div className="empty-state">{message || 'Nothing here yet.'}</div>;
}
