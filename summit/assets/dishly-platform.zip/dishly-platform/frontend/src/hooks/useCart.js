import { useState, useEffect } from 'react';

const CART_KEY = 'dishly_cart';
const CART_EVENT = 'dishly:cart-updated';

function loadCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || { restaurantId: null, restaurantName: '', items: [] }; }
  catch { return { restaurantId: null, restaurantName: '', items: [] }; }
}

function broadcast() {
  window.dispatchEvent(new Event(CART_EVENT));
}

export function useCart() {
  const [cart, setCart] = useState(loadCart);

  // Persist to localStorage on every cart change — no broadcast here (prevents loop)
  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  // Sync from localStorage when another instance broadcasts a change
  useEffect(() => {
    function onCartUpdated() {
      setCart(loadCart());
    }
    window.addEventListener(CART_EVENT, onCartUpdated);
    return () => window.removeEventListener(CART_EVENT, onCartUpdated);
  }, []);

  function addItem(item, restaurant) {
    setCart(prev => {
      if (prev.restaurantId && prev.restaurantId !== restaurant.id) {
        const ok = window.confirm(
          `Your cart has items from ${prev.restaurantName}. Start a new order from ${restaurant.name}?`
        );
        if (!ok) return prev;
        const next = { restaurantId: restaurant.id, restaurantName: restaurant.name, items: [{ ...item, quantity: 1 }] };
        localStorage.setItem(CART_KEY, JSON.stringify(next));
        broadcast();
        return next;
      }
      const existing = prev.items.find(i => i.id === item.id);
      const items = existing
        ? prev.items.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)
        : [...prev.items, { ...item, quantity: 1 }];
      const next = { restaurantId: restaurant.id, restaurantName: restaurant.name, items };
      localStorage.setItem(CART_KEY, JSON.stringify(next));
      broadcast();
      return next;
    });
  }

  function decrementItem(itemId) {
    setCart(prev => {
      const existing = prev.items.find(i => i.id === itemId);
      if (!existing) return prev;
      const items = existing.quantity === 1
        ? prev.items.filter(i => i.id !== itemId)
        : prev.items.map(i => i.id === itemId ? { ...i, quantity: i.quantity - 1 } : i);
      const next = { ...prev, items };
      localStorage.setItem(CART_KEY, JSON.stringify(next));
      broadcast();
      return next;
    });
  }

  function clearCart() {
    const empty = { restaurantId: null, restaurantName: '', items: [] };
    localStorage.setItem(CART_KEY, JSON.stringify(empty));
    broadcast();
    setCart(empty);
  }

  const cartCount = cart.items.reduce((sum, i) => sum + i.quantity, 0);

  return { cart, addItem, decrementItem, clearCart, cartCount };
}
