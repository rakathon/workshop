const BASE = 'http://localhost:3001/dishly/v1';

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('dishly_token');
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${BASE}${path}`, { ...options, headers });

  // Auth endpoints handle their own 401 — never redirect from login/register flows
  const isAuthEndpoint = path.startsWith('/auth/');

  // Non-JSON response (e.g. HTML error page) — treat as auth failure if 401, else generic error
  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    if (res.status === 401 && !isAuthEndpoint) {
      ['dishly_token','dishly_user_name','dishly_user_email','dishly_user_id'].forEach(k => localStorage.removeItem(k));
      window.location.href = '/login';
    }
    throw Object.assign(new Error('Request failed — please try again'), { status: res.status });
  }

  const json = await res.json();
  if (!res.ok) {
    // Expired or invalid token → redirect to login (but not on auth endpoints themselves)
    if (res.status === 401 && !isAuthEndpoint) {
      ['dishly_token','dishly_user_name','dishly_user_email','dishly_user_id'].forEach(k => localStorage.removeItem(k));
      window.location.href = '/login';
    }
    throw Object.assign(new Error(json.errors?.[0]?.message || 'Request failed'), { status: res.status, code: json.errors?.[0]?.code });
  }
  return json.data;
}

export const api = {
  get:   (path)        => apiFetch(path),
  post:  (path, body)  => apiFetch(path, { method: 'POST',   body: JSON.stringify(body) }),
  patch: (path, body)  => apiFetch(path, { method: 'PATCH',  body: JSON.stringify(body) }),
  del:   (path)        => apiFetch(path, { method: 'DELETE' }),
};
