import { useState, useEffect } from 'react';
import { api } from './client';

function useApi(fetcher, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetcher()
      .then(d => { if (!cancelled) { setData(d); setLoading(false); } })
      .catch(e => { if (!cancelled) { setError(e.message); setLoading(false); } });
    return () => { cancelled = true; };
  }, deps);

  return { data, loading, error };
}

export function useCollections(neighbourhoodId = null) {
  const qs = neighbourhoodId ? `?neighbourhood_id=${neighbourhoodId}` : '';
  return useApi(() => api.get(`/collections${qs}`), [neighbourhoodId]);
}

export function useRestaurants(params = {}) {
  const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v))).toString();
  return useApi(() => api.get(`/restaurants${qs ? '?' + qs : ''}`), [qs]);
}

export function useRestaurant(id) {
  return useApi(() => api.get(`/restaurants/${id}`), [id]);
}

export function useCuisines() {
  return useApi(() => api.get('/cuisines'), []);
}

export function useNeighbourhoods() {
  return useApi(() => api.get('/neighbourhoods'), []);
}

export function useCities() {
  return useApi(() => api.get('/neighbourhoods'), []);
}
