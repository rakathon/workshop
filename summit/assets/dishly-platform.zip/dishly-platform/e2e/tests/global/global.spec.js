// @ts-check
// Feature: Global chrome — SC-25, SC-26
const { test, expect } = require('@playwright/test');
const { createTestUser, seedAuth, getFirstRestaurantId } = require('../helpers/auth');

test.describe('Global chrome', () => {
  test('SC-25: announcement bar visible on homepage, restaurant page, and search', async ({ page }) => {
    const restaurantId = await getFirstRestaurantId();

    await page.goto('/');
    await page.waitForLoadState('load');
    await expect(page.locator('.announce-bar')).toBeVisible();
    const bg = await page.locator('.announce-bar').evaluate(el => getComputedStyle(el).backgroundColor);
    expect(bg).toMatch(/rgb\(133,\s*41,\s*205\)/);
    expect((await page.locator('.announce-bar').textContent() || '').trim().length).toBeGreaterThan(0);

    await page.goto(`/restaurants/${restaurantId}`);
    await page.waitForLoadState('load');
    await expect(page.locator('.announce-bar')).toBeVisible();

    await page.goto('/search?q=ramen');
    await page.waitForLoadState('load');
    await expect(page.locator('.announce-bar')).toBeVisible();
  });

  test('SC-26: cart badge increments as items are added', async ({ page }) => {
    const user = await createTestUser();
    const restaurantId = await getFirstRestaurantId();
    await seedAuth(page, user);
    await page.goto(`/restaurants/${restaurantId}`);
    await page.waitForLoadState('load');
    await page.waitForTimeout(1500);

    const badge = page.locator('.navbar__badge');
    const initial = (await badge.isVisible()) ? parseInt(await badge.textContent() || '0') : 0;

    await page.locator('.menu-item__add').first().click();
    await page.waitForTimeout(500);
    await expect(badge).toBeVisible({ timeout: 8000 });
    expect(parseInt(await badge.textContent() || '0')).toBe(initial + 1);

    await page.locator('.menu-item__add').first().click();
    await page.waitForTimeout(500);
    expect(parseInt(await badge.textContent() || '0')).toBe(initial + 2);
  });
});
