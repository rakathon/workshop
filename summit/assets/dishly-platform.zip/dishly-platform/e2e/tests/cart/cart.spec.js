// @ts-check
// Feature: Cart — SC-13, SC-14, SC-15, SC-16
const { test, expect } = require('@playwright/test');
const { createTestUser, seedAuth, seedAuthAndCart, getFirstRestaurantId, getFirstMenuItemId, getSecondRestaurantId } = require('../helpers/auth');

let restaurantId, menuItemId;

test.beforeAll(async () => {
  restaurantId = await getFirstRestaurantId();
  menuItemId   = await getFirstMenuItemId(restaurantId);
});

test.describe('Cart', () => {
  test('SC-13: cart shows items, totals, and Proceed to Checkout', async ({ page }) => {
    const user = await createTestUser();
    await seedAuthAndCart(page, user, restaurantId, 'Adda Indian Canteen', menuItemId, 'Samosa Chaat');
    await page.goto('/cart');
    await page.waitForLoadState('load');
    await page.waitForTimeout(600);

    await expect(page.locator('.cart-page__title')).toHaveText('Your Cart');
    await expect(page.locator('.cart-item').first()).toBeVisible();
    await expect(page.locator('.cart-summary__row').first()).toBeVisible();
    await expect(page.locator('.btn-primary', { hasText: /Proceed to Checkout/i })).toBeVisible();
  });

  test('SC-14: empty cart shows empty state message', async ({ page }) => {
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/cart');
    await page.waitForLoadState('load');

    await expect(page.locator('.empty-state')).toBeVisible();
    expect(await page.locator('.cart-item').count()).toBe(0);
  });

  test('SC-15: cart shows item quantity', async ({ page }) => {
    const user = await createTestUser();
    await seedAuthAndCart(page, user, restaurantId, 'Adda Indian Canteen', menuItemId, 'Samosa Chaat');
    await page.goto('/cart');
    await page.waitForLoadState('load');
    await page.waitForTimeout(600);

    const qty = page.locator('.cart-item__qty').first();
    await expect(qty).toBeVisible();
    await expect(qty).toContainText('1');
  });

  test('SC-16: adding item from different restaurant shows conflict prompt', async ({ page }) => {
    const user     = await createTestUser();
    const rest2Id  = await getSecondRestaurantId();
    await seedAuthAndCart(page, user, restaurantId, 'Adda Indian Canteen', menuItemId, 'Samosa Chaat');
    await page.goto(`/restaurants/${rest2Id}`);
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    page.once('dialog', async dialog => {
      expect(dialog.message()).toMatch(/start a new order/i);
      await dialog.dismiss();
    });
    await page.locator('.menu-item__add').first().click();
    await page.waitForTimeout(800);
  });
});
