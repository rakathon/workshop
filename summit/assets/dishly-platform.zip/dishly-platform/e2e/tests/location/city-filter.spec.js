// @ts-check
// Feature: Location-based City Filtering — SC-1 through SC-6
// Source: features/us/location/city-filter.feature
const { test, expect, request } = require('@playwright/test');
const { seedLocalStorage } = require('../helpers/auth');

const BASE_API = 'http://localhost:3001/dishly/v1';

// ── City Dropdown Open ────────────────────────────────────────────────

test.describe('City Dropdown', () => {
  // SC-1
  test('SC-1: city dropdown opens and shows all cities', async ({ page }) => {
    // Given — a visitor on the home page
    await page.goto('/');
    await page.waitForLoadState('load');

    // When — click the city selector button
    const selectorBtn = page.locator('.city-selector__btn').first();
    await expect(selectorBtn).toBeVisible({ timeout: 8000 });
    await selectorBtn.click();

    // Then — dropdown visible (conditionally rendered when open)
    const dropdown = page.locator('.city-dropdown').first();
    await expect(dropdown).toBeVisible({ timeout: 5000 });

    // And — button has aria-expanded=true
    await expect(selectorBtn).toHaveAttribute('aria-expanded', 'true');

    // And — all 10 city items + 1 "Near me" = 11 items total
    const items = dropdown.locator('.city-dropdown__item');
    await expect(items).toHaveCount(11, { timeout: 5000 });
    // Verifies: BR — city dropdown lists all available cities
  });

  // SC-2: dropdown shows full city list (text filter removed — click-only UX)
  test('SC-2: typing in the dropdown filters the city list', async ({ page }) => {
    // Given — dropdown open on home page
    await page.goto('/');
    await page.waitForLoadState('load');

    const selectorBtn = page.locator('.city-selector__btn').first();
    await expect(selectorBtn).toBeVisible({ timeout: 8000 });
    await selectorBtn.click();

    const dropdown = page.locator('.city-dropdown').first();
    await expect(dropdown).toBeVisible({ timeout: 5000 });

    // Dropdown shows all cities directly (no text filter input — click-to-select UX)
    const items = dropdown.locator('.city-dropdown__item');
    const count = await items.count();
    // Should have at least 6 city items (10 neighbourhoods + Near me)
    expect(count).toBeGreaterThanOrEqual(7);

    // All major cities visible
    await expect(dropdown.locator('.city-dropdown__item', { hasText: 'Manhattan' })).toBeVisible();
    await expect(dropdown.locator('.city-dropdown__item', { hasText: 'Boston' })).toBeVisible();
    // Verifies: BR — city dropdown shows all available cities for direct selection
  });

  // SC-3
  test('SC-3: selecting a city stores selection and filters restaurant results', async ({ page }) => {
    // Given — dropdown open on home page
    await page.goto('/');
    await page.waitForLoadState('load');

    const selectorBtn = page.locator('.city-selector__btn').first();
    await expect(selectorBtn).toBeVisible({ timeout: 8000 });
    await selectorBtn.click();

    const dropdown = page.locator('.city-dropdown').first();
    await expect(dropdown).toBeVisible({ timeout: 5000 });

    // When — select "Manhattan"
    const manhattanItem = dropdown.locator('.city-dropdown__item', { hasText: 'Manhattan' });
    await expect(manhattanItem).toBeVisible();
    await manhattanItem.click();

    // Then — dropdown closes (removed from DOM)
    await expect(dropdown).not.toBeVisible({ timeout: 5000 });

    // And — button shows "Manhattan" label
    await expect(selectorBtn.locator('.city-selector__label')).toHaveText('Manhattan');

    // And — button has active class
    await expect(selectorBtn).toHaveClass(/city-selector__btn--active/);

    // And — dishly_city stored in localStorage
    const storedCity = await page.evaluate(() => localStorage.getItem('dishly_city'));
    expect(storedCity).toBeTruthy();
    const parsed = JSON.parse(storedCity);
    expect(parsed.name).toBe('Manhattan');
    // Verifies: BR — city selection filters restaurants and persists to localStorage
  });

  // SC-4
  test('SC-4: clear button resets the city filter', async ({ page }) => {
    // Given — "Manhattan" pre-selected in localStorage
    await seedLocalStorage(page, {
      dishly_city: JSON.stringify({ id: '21875d5e-fbeb-4f05-b38b-6d3116073cd3', name: 'Manhattan' }),
    });

    await page.goto('/');
    await page.waitForLoadState('load');

    // Confirm active state
    const selectorBtn = page.locator('.city-selector__btn').first();
    await expect(selectorBtn).toBeVisible({ timeout: 8000 });
    await expect(selectorBtn).toHaveClass(/city-selector__btn--active/, { timeout: 5000 });
    await expect(selectorBtn.locator('.city-selector__label')).toHaveText('Manhattan');

    // When — click the inline clear button (inside the selector button)
    const clearBtn = page.locator('.city-selector__clear').first();
    await expect(clearBtn).toBeVisible({ timeout: 5000 });
    await clearBtn.click();

    // Then — active class removed from button
    await expect(selectorBtn).not.toHaveClass(/city-selector__btn--active/, { timeout: 5000 });

    // And — label returns to default "All cities"
    await expect(selectorBtn.locator('.city-selector__label')).toHaveText('All cities');

    // And — localStorage key removed
    const storedCity = await page.evaluate(() => localStorage.getItem('dishly_city'));
    expect(storedCity).toBeNull();
    // Verifies: BR — clear resets city filter to default state
  });
});

// ── NavBar Visibility ─────────────────────────────────────────────────

test.describe('City Selector Visibility', () => {
  // SC-5
  test('SC-5: city selector is visible in the NavBar', async ({ page }) => {
    // Given — a visitor on the home page
    await page.goto('/');
    await page.waitForLoadState('load');

    // Then — city selector button visible (rendered inside NavBar)
    const cityBtn = page.locator('.city-selector__btn').first();
    await expect(cityBtn).toBeVisible({ timeout: 8000 });

    // And — button shows default label "All cities"
    await expect(cityBtn.locator('.city-selector__label')).toHaveText('All cities');
    // Verifies: BR — city selector rendered in NavBar
  });

  // SC-6
  test('SC-6: city selector is visible on the Search page', async ({ page }) => {
    // Given — a visitor on the search page
    await page.goto('/search');
    await page.waitForLoadState('load');

    // Then — city selector visible on search page
    const cityBtn = page.locator('.city-selector__btn').first();
    await expect(cityBtn).toBeVisible({ timeout: 8000 });

    // And — dropdown can be opened from search page
    await cityBtn.click();
    const dropdown = page.locator('.city-dropdown').first();
    await expect(dropdown).toBeVisible({ timeout: 5000 });

    // And — button has aria-expanded=true
    await expect(cityBtn).toHaveAttribute('aria-expanded', 'true');
    // Verifies: BR — city selector accessible from search page
  });
});
