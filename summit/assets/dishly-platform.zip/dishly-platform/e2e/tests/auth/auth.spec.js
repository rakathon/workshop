// @ts-check
// Feature: Auth — SC-11, SC-12
const { test, expect } = require('@playwright/test');

test.describe('Auth', () => {
  // SC-11: Login and register are separate pages with correct headings
  test('SC-11: login page shows sign-in heading; register page shows create-account heading', async ({ page }) => {
    // Given — login page
    await page.goto('/login');
    await page.waitForLoadState('load');

    const loginH1 = await page.locator('h1.auth-page__title').textContent();
    expect(loginH1?.toLowerCase()).toMatch(/welcome/i);

    // And — "Sign up" link is present
    await expect(page.locator('a', { hasText: /sign up/i })).toBeVisible();

    // Given — register page (navigate directly to avoid SPA render race)
    await page.goto('/register');
    await page.waitForLoadState('load');

    // Then — register heading visible
    await expect(page.locator('h1.auth-page__title')).toHaveText('Create account', { timeout: 8000 });

    // And — sign-in link present on register page
    await expect(page.locator('.auth-switch a', { hasText: /sign in/i })).toBeVisible();
    // Verifies: S-04 — auth pages navigation
  });

  // SC-12: Inline error on wrong credentials
  test('SC-12: login shows inline error on wrong credentials', async ({ page }) => {
    // Given — on sign in page
    await page.goto('/login');
    await page.waitForLoadState('load');

    // When — submit bad credentials
    await page.locator('input[type="email"]').fill('nobody@example.com');
    await page.locator('input[type="password"]').fill('wrongpassword');
    await page.locator('form.auth-form button[type="submit"]').click();
    await page.waitForTimeout(1500);

    // Then — inline error visible
    await expect(page.locator('.auth-error, [role="alert"]')).toBeVisible();

    // And — still on /login
    await expect(page).toHaveURL(/\/login/);
    // Verifies: S-04 error state
  });
});
