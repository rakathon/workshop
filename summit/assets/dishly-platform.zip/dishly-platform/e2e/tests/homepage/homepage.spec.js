// @ts-check
// Feature: Homepage — editorial discovery surface
// Scenarios: SC-1, SC-2, SC-3
const { test, expect } = require('@playwright/test');

test.describe('Homepage', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);
  });

  // SC-1: Homepage renders with editorial collections
  test('SC-1: renders hero headline, collections, and restaurant cards without sign-in prompt', async ({ page }) => {
    // Then — headline
    await expect(page.locator('h1.hero-headline')).toHaveText('Find food worth eating.');

    // And — at least 3 collection sections visible
    const collections = page.locator('.collection');
    await expect(collections).toHaveCount(await collections.count());
    expect(await collections.count()).toBeGreaterThanOrEqual(3);

    // And — each collection has at least 1 restaurant card
    const firstCollection = collections.first();
    const cards = firstCollection.locator('.restaurant-card');
    expect(await cards.count()).toBeGreaterThanOrEqual(1);

    // And — first card image loaded (naturalWidth > 0)
    const firstImg = cards.first().locator('img').first();
    const naturalWidth = await firstImg.evaluate(img => img.naturalWidth);
    expect(naturalWidth).toBeGreaterThan(0);

    // And — no sign-in modal visible
    await expect(page.locator('.modal, [class*="modal"]')).toHaveCount(0);
  });

  // SC-2: Category chip click navigates to filtered search
  test('SC-2: category chip click navigates to search results for that cuisine', async ({ page }) => {
    // When — click "Ramen" chip (first occurrence)
    const ramenChip = page.locator('.filter-chip', { hasText: 'Ramen' }).first();
    await expect(ramenChip).toBeVisible();

    await ramenChip.click();
    // Then — navigates to /search?q=Ramen (chip navigates rather than filters in-place)
    await expect(page).toHaveURL(/\/search\?q=Ramen/i, { timeout: 10000 });
  });

  // SC-3: Search bar navigates to results page
  test('SC-3: hero search navigates to /search?q=Thai', async ({ page }) => {
    // When — type in hero search and press Enter
    const searchInput = page.locator('.hero-search input');
    await searchInput.fill('Thai');
    await searchInput.press('Enter');

    // Then — URL changes to /search?q=Thai
    await expect(page).toHaveURL(/\/search\?q=Thai/i, { timeout: 10000 });

    // And — search results page renders
    await expect(page.locator('.search-page, main')).toBeVisible();
  });
});
