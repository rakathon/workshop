// @ts-check
// Home page UX fixes — SC-HX-1..SC-HX-7
// Tests: no duplicate search bar, cities loaded, see all works,
//        filter preservation to search, unique images, cart/profile position
const { test, expect } = require('@playwright/test');
const { createTestUser, seedLocalStorage } = require('../helpers/auth');

const BASE_API = 'http://localhost:3001/dishly/v1';

test.describe('Home Page UX', () => {

  // SC-HX-1: No duplicate search bar on home page
  test('SC-HX-1: only one search bar visible on home page — hero only, not NavBar', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // Hero search input should be visible
    await expect(page.locator('.hero-search input[type="search"]')).toBeVisible({ timeout: 8000 });

    // NavBar search input should NOT be visible on home page
    await expect(page.locator('.navbar__search')).not.toBeVisible();
    await expect(page.locator('.navbar form.navbar__search')).not.toBeVisible();
  });

  // SC-HX-2: Cart and profile are on the right side of the NavBar
  test('SC-HX-2: cart and profile icons are pinned to the right of the NavBar', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    const navbar = page.locator('.navbar');
    const actions = page.locator('.navbar__actions');

    await expect(navbar).toBeVisible();
    await expect(actions).toBeVisible();

    // Actions should be to the right — its left edge should be > half the navbar width
    const navbarBox = await navbar.boundingBox();
    const actionsBox = await actions.boundingBox();
    expect(actionsBox.x).toBeGreaterThan(navbarBox.x + navbarBox.width / 2);
  });

  // SC-HX-3: City selector on Home page hero loads all cities
  test('SC-HX-3: city selector in home hero loads all cities in dropdown', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // Click the hero city selector
    await page.locator('.hero-search .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 8000 });

    // Should show at least 6 cities (5 new + some NYC neighbourhoods)
    const items = page.locator('.city-dropdown__item').filter({ hasText: /^(?!Near me)/ });
    await expect(items.first()).toBeVisible({ timeout: 5000 });
    expect(await items.count()).toBeGreaterThanOrEqual(6);
  });

  // SC-HX-4: "See all" button on home page navigates to search with city filter preserved
  test('SC-HX-4: see all button navigates to /search and preserves active city filter', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // Wait for collections to load
    await expect(page.locator('.collection').first()).toBeVisible({ timeout: 10000 });

    // Click "See all" on first collection
    const seeAll = page.locator('.collection__see-all').first();
    await expect(seeAll).toBeVisible();
    await seeAll.click();

    // Should navigate to /search
    await expect(page).toHaveURL(/\/search/, { timeout: 8000 });

    // Results should be visible (not empty due to a bad query)
    await page.waitForTimeout(1000);
    const resultCount = page.locator('.result-count');
    await expect(resultCount).toBeVisible({ timeout: 8000 });
    const countText = await resultCount.textContent();
    const count = Number(countText?.match(/\d+/)?.[0] ?? 0);
    expect(count).toBeGreaterThan(0);
  });

  // SC-HX-5: See all with active city preserves city on Search page
  test('SC-HX-5: see all with active city navigates to search preserving city filter', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // Select Los Angeles via hero city selector
    await page.locator('.hero-search .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 5000 });
    await page.locator('.city-dropdown__item', { hasText: 'Los Angeles' }).click();
    await page.waitForTimeout(1000);

    // Click See all
    const seeAll = page.locator('.collection__see-all, .section-see-all, a').filter({ hasText: 'See all' }).first();
    await expect(seeAll).toBeVisible({ timeout: 8000 });
    await seeAll.click();

    // Should be on /search with neighbourhood_id in URL
    await expect(page).toHaveURL(/\/search/, { timeout: 8000 });
    const url = page.url();
    expect(url).toContain('neighbourhood_id=');

    // City selector on search page should show Los Angeles
    await page.waitForTimeout(1000);
    const searchCityBtn = page.locator('.search-filters .city-selector__btn');
    await expect(searchCityBtn).toContainText('Los Angeles', { timeout: 5000 });
  });

  // SC-HX-6: Filter preservation — search from home hero navigates with city filter
  test('SC-HX-6: searching from home hero with active city passes city to search results', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // Select Chicago via hero city selector
    await page.locator('.hero-search .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 5000 });
    await page.locator('.city-dropdown__item', { hasText: 'Chicago' }).click();
    await page.waitForTimeout(600);

    // Search for "Italian" from hero
    await page.locator('.hero-search input[type="search"]').fill('Italian');
    await page.locator('.hero-search button[type="submit"]').click();

    // Should navigate to /search with both q= and neighbourhood_id=
    await expect(page).toHaveURL(/\/search/, { timeout: 8000 });
    const url = page.url();
    expect(url).toContain('neighbourhood_id=');

    // Search page shows Chicago city filter active
    await page.waitForTimeout(1000);
    await expect(page.locator('.search-filters .city-selector__btn--active')).toBeVisible({ timeout: 5000 });
  });

  // SC-HX-7: Each restaurant card has a unique image URL within its collection
  test('SC-HX-7: restaurant cards within each collection have unique image URLs', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // Wait for at least one collection
    await expect(page.locator('.collection').first()).toBeVisible({ timeout: 10000 });

    // Check the first collection — all 4 cards should have different image URLs
    const firstCollection = page.locator('.collection').first();
    const imgSrcs = await firstCollection.locator('img').evaluateAll(
      imgs => imgs.map(img => img.src).filter(s => s.includes('unsplash'))
    );

    expect(imgSrcs.length).toBeGreaterThan(0);

    // Each URL should use our crop-based unique param
    const hasUnsplash = imgSrcs.every(src => src.includes('unsplash.com'));
    expect(hasUnsplash).toBe(true);

    // Within this collection, all image URLs should be unique
    const unique = new Set(imgSrcs);
    expect(unique.size).toBe(imgSrcs.length);
  });

});
