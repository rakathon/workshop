// @ts-check
// Feature: Search Results — filter-and-land surface for intent-driven discovery
// Scenarios: SC-4..SC-6 (original), SC-13..SC-20 (search/filter extended)
const { test, expect } = require('@playwright/test');

test.describe('Search Results', () => {
  // SC-4: Search results render with filter chips
  test('SC-4: search results render with filter chips and result rows', async ({ page }) => {
    // Given — navigate to /search?q=ramen
    await page.goto('/search?q=ramen');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    // Then — result count label visible
    await expect(page.locator('.result-count, [class*="result-count"]')).toBeVisible();

    // And — cuisine filter chips visible
    const filterPills = page.locator('.filter-pill');
    expect(await filterPills.count()).toBeGreaterThan(0);

    // And — at least 1 result row visible with content
    const resultRows = page.locator('.result-row, .restaurant-card');
    expect(await resultRows.count()).toBeGreaterThanOrEqual(1);

    // And — first result row has an image
    const firstImg = resultRows.first().locator('img').first();
    await expect(firstImg).toBeVisible();
  });

  // SC-5: Cuisine filter chip narrows results
  test('SC-5: cuisine filter chip narrows results and updates count', async ({ page }) => {
    // Given — search results for "ramen"
    await page.goto('/search?q=ramen');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    const countLabel = page.locator('.result-count, [class*="result-count"]');
    const initialCount = await countLabel.textContent();

    // When — click "Japanese" cuisine chip
    const japaneseChip = page.locator('.filter-pill', { hasText: 'Japanese' }).first();
    await japaneseChip.click();
    await page.waitForTimeout(800);

    // Then — chip becomes active
    await expect(japaneseChip).toHaveClass(/filter-pill--active/);

    // And — result count may update (or remain if all are Japanese)
    await expect(countLabel).toBeVisible();
  });

  // SC-6: Search empty state renders
  test('SC-6: empty state renders when no results found', async ({ page }) => {
    // When — search for a term that matches nothing
    await page.goto('/search?q=xyzzy_no_results_dishly');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    // Then — no result rows
    const resultRows = page.locator('.result-row');
    expect(await resultRows.count()).toBe(0);

    // And — empty state message visible
    const emptyState = page.locator('.empty-state');
    await expect(emptyState).toBeVisible();
  });

  // SC-13: Keyword search from home hero navigates to /search
  test('SC-13: home hero search navigates to /search?q=', async ({ page }) => {
    // Given — on Home page
    await page.goto('/');
    await page.waitForLoadState('load');

    // When — type in hero search input and submit
    const heroInput = page.locator('.hero-search input[type="search"]');
    await expect(heroInput).toBeVisible({ timeout: 8000 });
    await heroInput.fill('ramen');
    await page.locator('.hero-search button[type="submit"]').click();

    // Then — navigates to /search with q=ramen
    await expect(page).toHaveURL(/\/search.*q=ramen/i, { timeout: 8000 });
    await page.waitForTimeout(800);
    const resultRows = page.locator('.result-row');
    expect(await resultRows.count()).toBeGreaterThanOrEqual(1);
    // Verifies: SC-13 — home hero search → /search?q=
  });

  // SC-14: Keyword search returns relevant restaurants with full result rows
  test('SC-14: keyword search returns restaurants with name, rating, cuisine, price', async ({ page }) => {
    // When — search for Japanese
    await page.goto('/search?q=Japanese');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    // Then — at least one result
    const resultRows = page.locator('.result-row');
    expect(await resultRows.count()).toBeGreaterThanOrEqual(1);

    // And — result count shows non-zero
    const countLabel = page.locator('.result-count');
    await expect(countLabel).toBeVisible();
    const countText = await countLabel.textContent();
    expect(Number(countText?.match(/\d+/)?.[0] ?? 0)).toBeGreaterThan(0);

    // And — first row has name, rating, meta visible
    const firstRow = resultRows.first();
    await expect(firstRow.locator('.result-name')).toBeVisible();
    await expect(firstRow.locator('.result-meta')).toBeVisible();
    // Verifies: SC-14 — result row renders correctly
  });

  // SC-15: City + cuisine combined filter
  test('SC-15: city filter combined with cuisine filter narrows results', async ({ page }) => {
    // Given — search page, select Los Angeles
    await page.goto('/search');
    await page.waitForLoadState('load');
    await page.locator('.search-filters .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 5000 });
    await page.locator('.city-dropdown__item', { hasText: 'Los Angeles' }).click();
    await page.waitForTimeout(800);

    const countAfterCity = await page.locator('.result-count').textContent();
    const cityCount = Number(countAfterCity?.match(/\d+/)?.[0] ?? 0);

    // When — click Japanese cuisine chip
    const japChip = page.locator('.filter-pill', { hasText: 'Japanese' }).first();
    await japChip.click();
    await page.waitForTimeout(800);

    // Then — both selectors active
    await expect(page.locator('.search-filters .city-selector__btn--active')).toBeVisible();
    await expect(japChip).toHaveClass(/filter-pill--active/);

    // And — count <= city-only count
    const countAfterBoth = await page.locator('.result-count').textContent();
    const bothCount = Number(countAfterBoth?.match(/\d+/)?.[0] ?? 0);
    expect(bothCount).toBeLessThanOrEqual(cityCount);
    // Verifies: SC-15 — city + cuisine combined filter
  });

  // SC-16: Price range filter active state
  test('SC-16: price range filter narrows results and chip shows active style', async ({ page }) => {
    // Given — search page with results
    await page.goto('/search');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1000);

    // When — click $$ price chip
    const priceChip = page.locator('.filter-pill', { hasText: '$$' }).first();
    await priceChip.click();
    await page.waitForTimeout(800);

    // Then — chip active
    await expect(priceChip).toHaveClass(/filter-pill--active/);

    // And — result count updates (visible and non-empty)
    await expect(page.locator('.result-count')).toBeVisible();
    // Verifies: SC-16 — price filter active state
  });

  // SC-17: City + price combined filter
  test('SC-17: city filter combined with price filter narrows results', async ({ page }) => {
    // Given — select San Francisco
    await page.goto('/search');
    await page.waitForLoadState('load');
    await page.locator('.search-filters .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 5000 });
    await page.locator('.city-dropdown__item', { hasText: 'San Francisco' }).click();
    await page.waitForTimeout(800);

    // When — click $$$ price chip
    const priceChip = page.locator('.filter-pill', { hasText: '$$$' }).first();
    await priceChip.click();
    await page.waitForTimeout(800);

    // Then — both active
    await expect(page.locator('.search-filters .city-selector__btn--active')).toBeVisible();
    await expect(priceChip).toHaveClass(/filter-pill--active/);
    // Verifies: SC-17 — city + price combined filter
  });

  // SC-18: Clearing city filter restores all-city results
  test('SC-18: clearing city filter on Search page restores all-city results', async ({ page }) => {
    // Given — select Chicago on search page
    await page.goto('/search');
    await page.waitForLoadState('load');
    await page.locator('.search-filters .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 5000 });
    await page.locator('.city-dropdown__item', { hasText: 'Chicago' }).click();
    await page.waitForTimeout(800);
    const cityCount = Number((await page.locator('.result-count').textContent())?.match(/\d+/)?.[0] ?? 0);

    // When — clear city filter
    await page.locator('.search-filters .city-selector__clear').click();
    await page.waitForTimeout(800);

    // Then — city selector reset
    await expect(page.locator('.search-filters .city-selector__btn')).not.toHaveClass(/city-selector__btn--active/);

    // And — result count increases
    const allCount = Number((await page.locator('.result-count').textContent())?.match(/\d+/)?.[0] ?? 0);
    expect(allCount).toBeGreaterThanOrEqual(cityCount);
    // Verifies: SC-18 — city filter cleared; all-city results restored
  });

  // SC-19: Individual cuisine chip deactivation with other filters remaining
  test('SC-19: deactivating cuisine chip leaves city and price filters active', async ({ page }) => {
    // Given — city + cuisine + price all active
    await page.goto('/search');
    await page.waitForLoadState('load');

    // Select city
    await page.locator('.search-filters .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 5000 });
    await page.locator('.city-dropdown__item', { hasText: 'Manhattan' }).click();
    await page.waitForTimeout(500);

    // Select cuisine
    const japChip = page.locator('.filter-pill', { hasText: 'Japanese' }).first();
    await japChip.click();
    await page.waitForTimeout(500);

    // Select price
    const priceChip = page.locator('.filter-pill', { hasText: '$$' }).first();
    await priceChip.click();
    await page.waitForTimeout(500);

    // When — deactivate cuisine chip
    await japChip.click();
    await page.waitForTimeout(800);

    // Then — cuisine chip inactive, city + price still active
    await expect(japChip).not.toHaveClass(/filter-pill--active/);
    await expect(page.locator('.search-filters .city-selector__btn--active')).toBeVisible();
    await expect(priceChip).toHaveClass(/filter-pill--active/);
    // Verifies: SC-19 — individual filter chip deactivation
  });

  // SC-20: Empty state when city filter + no-match keyword
  test('SC-20: empty state shown when city + keyword combination yields no results', async ({ page }) => {
    // Given — search page with a city filter active and a no-match term
    await page.goto('/search');
    await page.waitForLoadState('load');

    // Select a city via the search page filter
    await page.locator('.search-filters .city-selector__btn').click();
    await expect(page.locator('.city-dropdown')).toBeVisible({ timeout: 5000 });
    await page.locator('.city-dropdown__item', { hasText: 'Boston' }).click();
    await page.waitForTimeout(600);

    // Type a nonsense query in the NavBar search and navigate
    await page.locator('.navbar__search-input').fill('xyzzy99zz_nomatch');
    await page.locator('.navbar__search-btn').click();
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    // Then — no result rows and empty state visible
    expect(await page.locator('.result-row').count()).toBe(0);
    await expect(page.locator('.empty-state')).toBeVisible({ timeout: 5000 });
    // Verifies: SC-20 — empty state with active city + no-match keyword
  });
});
