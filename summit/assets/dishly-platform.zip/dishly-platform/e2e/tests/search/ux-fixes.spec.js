// @ts-check
// UI UX fixes — SC-21..SC-24
// Tests: search box sync, chip-to-cuisine mapping, order history timestamps, checkout auth
const { test, expect, request } = require('@playwright/test');
const { createTestUser, seedAuth, seedLocalStorage, placeTestOrder,
        getFirstRestaurantId, getFirstMenuItemId } = require('../helpers/auth');

const BASE_API = 'http://localhost:3001/dishly/v1';

test.describe('Search Box & Chip Navigation', () => {

  // SC-21: NavBar search box pre-populated from URL
  test('SC-21: NavBar search box shows keyword when landing on search page', async ({ page }) => {
    // Navigate directly to search with q=ramen (not from home, so navbar search is visible)
    await page.goto('/search?q=ramen');
    await page.waitForLoadState('load');
    await page.waitForTimeout(800);

    // NavBar search input is visible on /search (not hidden like on home page)
    const navSearch = page.locator('form.navbar__search input.navbar__search-input');
    await expect(navSearch).toBeVisible({ timeout: 8000 });
    await expect(navSearch).toHaveValue('ramen');
    // Verifies: SC-21 — search box synced to URL q= param
  });

  // SC-22: Soba chip → Japanese cuisine auto-selected
  test('SC-22: clicking Soba chip auto-selects Japanese cuisine filter on search page', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // Wait for chips to render
    await expect(page.locator('.filter-chips')).toBeVisible({ timeout: 10000 });

    // Click Soba chip
    const sobaChip = page.locator('.filter-chip', { hasText: 'Soba' });
    await expect(sobaChip).toBeVisible({ timeout: 8000 });
    await sobaChip.click();

    // Should navigate to /search?q=Soba
    await expect(page).toHaveURL(/\/search.*q=Soba/i, { timeout: 8000 });
    await page.waitForTimeout(2000); // wait for cuisines to load and auto-select

    // Page title shows "Soba Restaurants"
    const title = page.locator('.search-page__title');
    await expect(title).toContainText('Soba', { timeout: 8000 });
    await expect(title).not.toContainText('Results for');

    // Japanese cuisine chip is active
    const japChip = page.locator('.filter-pill', { hasText: 'Japanese' }).first();
    await expect(japChip).toHaveClass(/filter-pill--active/, { timeout: 8000 });

    // Results visible
    const count = page.locator('.result-count');
    await expect(count).toBeVisible({ timeout: 8000 });
    // Verifies: SC-22
  });

  test('SC-22b: Ramen chip → Japanese cuisine active on search page', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.filter-chips')).toBeVisible({ timeout: 10000 });
    await page.locator('.filter-chip', { hasText: 'Ramen' }).click();
    await expect(page).toHaveURL(/\/search.*q=Ramen/i, { timeout: 8000 });
    await page.waitForTimeout(2000);
    await expect(page.locator('.filter-pill', { hasText: 'Japanese' }).first())
      .toHaveClass(/filter-pill--active/, { timeout: 8000 });
  });

  test('SC-22c: Thai chip → Thai cuisine active on search page', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.filter-chips')).toBeVisible({ timeout: 10000 });
    await page.locator('.filter-chip', { hasText: 'Thai' }).click();
    await expect(page).toHaveURL(/\/search.*q=Thai/i, { timeout: 8000 });
    await page.waitForTimeout(2000);
    await expect(page.locator('.filter-pill', { hasText: 'Thai' }).first())
      .toHaveClass(/filter-pill--active/, { timeout: 8000 });
  });

});

test.describe('Order History Timestamps', () => {

  // SC-23: Human-readable timestamps on order history
  test('SC-23: order history shows human-readable timestamps not raw ISO dates', async ({ page }) => {
    const user = await createTestUser();
    const restaurantId = await getFirstRestaurantId();
    const menuItemId = await getFirstMenuItemId(restaurantId);
    await placeTestOrder(user.token, restaurantId, menuItemId);

    await seedAuth(page, user);
    await page.goto('/account/orders');
    await page.waitForLoadState('load');
    await expect(page.locator('.order-card').first()).toBeVisible({ timeout: 10000 });

    const dateEl = page.locator('.order-card__date').first();
    await expect(dateEl).toBeVisible();
    const dateText = await dateEl.textContent();

    // Should NOT be raw ISO e.g. "2026-06-07"
    expect(dateText).not.toMatch(/^\d{4}-\d{2}-\d{2}$/);

    // Should be readable: contains time words or month names
    const isReadable = /Today|Yesterday|Just now|ago|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Mon|Tue|Wed|Thu|Fri|Sat|Sun|at\s\d/i.test(dateText || '');
    expect(isReadable).toBe(true);
    // Verifies: SC-23
  });

});

test.describe('Checkout Auth Guard', () => {

  // SC-24: Checkout redirects to /login when no token
  test('SC-24: checkout redirects to /login when user is not signed in', async ({ page }) => {
    // Ensure no auth token — inject script before page load
    await page.addInitScript(() => {
      localStorage.clear();
    });

    await page.goto('/checkout');
    await page.waitForLoadState('load');
    await page.waitForTimeout(500);

    // Should be redirected to /login (Checkout.jsx navigates on missing token)
    await expect(page).toHaveURL(/\/login/, { timeout: 8000 });
    // Verifies: SC-24
  });

  test('SC-24b: authenticated user stays on checkout page', async ({ page }) => {
    const user = await createTestUser();
    const restaurantId = await getFirstRestaurantId();
    const menuItemId = await getFirstMenuItemId(restaurantId);

    // Fetch restaurant name and item name
    const ctx = await request.newContext();
    const rRes = await ctx.get(`${BASE_API}/restaurants/${restaurantId}`);
    const rBody = await rRes.json();
    const restaurantName = rBody.data.name;
    const itemName = rBody.data.menu[0].items[0].name;
    await ctx.dispose();

    await seedLocalStorage(page, {
      dishly_token: user.token,
      dishly_user_email: user.email,
      dishly_user_name: user.email.split('@')[0],
      dishly_user_id: user.userId,
      dishly_cart: JSON.stringify({
        restaurantId,
        restaurantName,
        items: [{ id: menuItemId, name: itemName, price: { value: 1000, scale: 2 }, quantity: 1 }],
      }),
    });

    await page.goto('/checkout');
    await page.waitForLoadState('load');
    await page.waitForTimeout(800);

    // Should stay on checkout
    await expect(page).toHaveURL(/\/checkout/, { timeout: 8000 });
    await expect(page.locator('h1')).toContainText('Checkout', { timeout: 5000 });
    // Verifies: SC-24b
  });

});
