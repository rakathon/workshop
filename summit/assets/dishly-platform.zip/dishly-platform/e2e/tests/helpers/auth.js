// @ts-check
const { request } = require('@playwright/test');

const BASE_API = 'http://localhost:3001/dishly/v1';

/** Register a fresh user and return { token, userId, email } */
async function createTestUser() {
  const email = `e2e-${Date.now()}@dishly-test.com`;
  const ctx = await request.newContext();
  const res = await ctx.post(`${BASE_API}/auth/register`, {
    data: { email, password: 'Password1!' },
  });
  const body = await res.json();
  await ctx.dispose();
  return { email, token: body.data.token, userId: body.data.user.id };
}

/**
 * Seed localStorage via addInitScript so values are present before React hydrates.
 * Must be called BEFORE page.goto().
 */
async function seedLocalStorage(page, data) {
  await page.addInitScript((data) => {
    for (const [key, value] of Object.entries(data)) {
      try { localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value)); } catch {}
    }
  }, data);
}

/** Inject auth via addInitScript — call before goto */
async function seedAuth(page, user) {
  await seedLocalStorage(page, {
    dishly_token: user.token,
    dishly_user_email: user.email,
    dishly_user_name: user.email.split('@')[0],
  });
}

/** Inject auth + cart via addInitScript — call before goto */
async function seedAuthAndCart(page, user, restaurantId, restaurantName, menuItemId, itemName) {
  await seedLocalStorage(page, {
    dishly_token: user.token,
    dishly_user_email: user.email,
    dishly_user_name: user.email.split('@')[0],
    dishly_cart: JSON.stringify({
      restaurantId,
      restaurantName,
      items: [{ id: menuItemId, name: itemName, price: { value: 1600, scale: 2 }, quantity: 1 }],
    }),
  });
}

/** Inject auth into localStorage on a live page (use only when page is already on localhost) */
async function loginPage(page, user) {
  await page.evaluate(({ token, email }) => {
    localStorage.setItem('dishly_token', token);
    localStorage.setItem('dishly_user_email', email);
    localStorage.setItem('dishly_user_name', email.split('@')[0]);
  }, { token: user.token, email: user.email });
}

/** Get first restaurant id from the API */
async function getFirstRestaurantId() {
  const ctx = await request.newContext();
  const res = await ctx.get(`${BASE_API}/restaurants`);
  const body = await res.json();
  await ctx.dispose();
  return body.data[0].id;
}

/** Get second restaurant id */
async function getSecondRestaurantId() {
  const ctx = await request.newContext();
  const res = await ctx.get(`${BASE_API}/restaurants`);
  const body = await res.json();
  await ctx.dispose();
  return body.data[1].id;
}

/** Place a real order and return the order id */
async function placeTestOrder(token, restaurantId, menuItemId) {
  const ctx = await request.newContext();
  const res = await ctx.post(`${BASE_API}/orders`, {
    headers: { Authorization: `Bearer ${token}` },
    data: {
      restaurant_id: restaurantId,
      items: [{ menu_item_id: menuItemId, quantity: 1 }],
      delivery_address: '42 Test Street, New York, NY 10001',
      payment_method_id: 'pm_card_visa',
    },
  });
  const body = await res.json();
  await ctx.dispose();
  return body.data.id;
}

/** Get first menu item id for a restaurant */
async function getFirstMenuItemId(restaurantId) {
  const ctx = await request.newContext();
  const res = await ctx.get(`${BASE_API}/restaurants/${restaurantId}`);
  const body = await res.json();
  await ctx.dispose();
  return body.data.menu[0].items[0].id;
}

module.exports = {
  createTestUser, seedAuth, seedAuthAndCart, seedLocalStorage,
  loginPage, getFirstRestaurantId, getSecondRestaurantId,
  getFirstMenuItemId, placeTestOrder,
};
