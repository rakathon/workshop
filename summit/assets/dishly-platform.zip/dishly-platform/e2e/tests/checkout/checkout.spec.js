// @ts-check
// Feature: Checkout — SC-17, SC-18, SC-19, SC-20
const { test, expect } = require('@playwright/test');
const { createTestUser, seedAuthAndCart, getFirstRestaurantId, getFirstMenuItemId } = require('../helpers/auth');

let restaurantId, menuItemId;

test.beforeAll(async () => {
  restaurantId = await getFirstRestaurantId();
  menuItemId   = await getFirstMenuItemId(restaurantId);
});

async function goToCheckout(page) {
  const user = await createTestUser();
  await seedAuthAndCart(page, user, restaurantId, 'Adda Indian Canteen', menuItemId, 'Samosa Chaat');
  await page.goto('/checkout');
  await page.waitForLoadState('networkidle');
  return user;
}

test.describe('Checkout', () => {
  test('SC-17: checkout renders address input and Place Order CTA', async ({ page }) => {
    await goToCheckout(page);
    await expect(page.locator('h1.checkout-page__title')).toHaveText('Checkout');
    await expect(page.locator('#address')).toBeVisible();
    await expect(page.locator('label[for="address"]')).toBeVisible();
    await expect(page.locator('.checkout-form button[type="submit"]')).toBeVisible();
  });

  test('SC-18: checkout shows payment options including Pay on delivery', async ({ page }) => {
    await goToCheckout(page);
    // New checkout has payment radio options (Enter a card + Pay on delivery)
    await expect(page.locator('.payment-option', { hasText: /pay on delivery/i })).toBeVisible();
    await expect(page.locator('.payment-option', { hasText: /enter a card/i })).toBeVisible();
    await expect(page.locator('.checkout-card-mock__note')).toBeVisible();
  });

  test('SC-19: checkout shows order summary with totals', async ({ page }) => {
    await goToCheckout(page);
    await expect(page.locator('.checkout-summary__heading')).toBeVisible();
    expect(await page.locator('.checkout-summary__item').count()).toBeGreaterThanOrEqual(1);
    await expect(page.locator('.checkout-summary__item--fee')).toBeVisible();
    await expect(page.locator('.checkout-summary__item--total')).toBeVisible();
  });

  test('SC-20: submitting without address stays on checkout; cart preserved', async ({ page }) => {
    await goToCheckout(page);
    await page.locator('.checkout-form button[type="submit"]').click();
    await page.waitForTimeout(600);

    // Either app-level error or browser validation — either way stays on /checkout
    await expect(page).toHaveURL(/\/checkout/);
    await expect(page.locator('.checkout-summary')).toBeVisible();
  });
});
