// @ts-check
// UI Rendering Tests — verify every key page renders correctly for humans
// Checks: no blank sections, layout intact, content visible, typography readable,
// images loading, stars/ratings visible, no broken UI states.
const { test, expect, request } = require('@playwright/test');
const path = require('path');
const { createTestUser, seedAuth, seedLocalStorage, seedAuthAndCart,
        getFirstRestaurantId, getFirstMenuItemId } = require('../helpers/auth');

const BASE_API = 'http://localhost:3001/dishly/v1';

// Helper: assert a page has meaningful rendered content (not blank)
async function assertNotBlank(page, testName) {
  const root = page.locator('#root');
  await expect(root).not.toBeEmpty({ timeout: 8000 });
  const text = await page.locator('body').textContent();
  const meaningfulText = (text || '').replace(/\s+/g, ' ').trim();
  expect(meaningfulText.length, `${testName}: page body is blank`).toBeGreaterThan(50);
}

// Helper: save a screenshot to test-results/visual/
async function saveScreenshot(page, name) {
  await page.screenshot({
    path: path.join('test-results', 'visual', `${name}.png`),
    fullPage: true,
  });
}

test.describe('UI Rendering — Home Page', () => {

  test('VR-1: Home page renders hero, chips, and restaurant collections', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Page not blank
    await assertNotBlank(page, 'VR-1 Home');

    // Brand present
    await expect(page.locator('.navbar__brand')).toBeVisible();
    await expect(page.locator('.navbar__brand')).toContainText('dishly');

    // Hero section visible
    await expect(page.locator('.hero')).toBeVisible({ timeout: 6000 });

    // Filter chips bar rendered
    await expect(page.locator('.filter-chips-bar')).toBeVisible({ timeout: 8000 });
    const chips = page.locator('.filter-chip');
    const chipCount = await chips.count();
    expect(chipCount, 'Should have at least 5 cuisine chips').toBeGreaterThanOrEqual(5);

    // At least one collection section with a heading
    await expect(page.locator('.collection-section, .collection').first()).toBeVisible({ timeout: 10000 });

    // Restaurant cards visible
    const cards = page.locator('.restaurant-card, .result-row');
    const cardCount = await cards.count();
    expect(cardCount, 'Home page should show at least 3 restaurant cards').toBeGreaterThanOrEqual(3);

    await saveScreenshot(page, 'home-page');
  });

  test('VR-2: Home page NavBar has no duplicate search bar', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('load');

    // NavBar search should be hidden on home page (hero has its own)
    const navbarSearchForm = page.locator('nav.navbar form.navbar__search');
    await expect(navbarSearchForm).toBeHidden({ timeout: 5000 });

    // Hero search should be visible
    await expect(page.locator('.hero-search, .hero .search-form, .hero input[type="search"]').first())
      .toBeVisible({ timeout: 6000 });
  });

  test('VR-3: Home page restaurant cards show ratings', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1500);

    // Rating elements on restaurant cards
    const ratings = page.locator('.restaurant-card__rating');
    const ratingCount = await ratings.count();
    expect(ratingCount, 'Should have restaurant rating elements').toBeGreaterThanOrEqual(3);

    // At least one has a numeric value
    const firstRating = await ratings.first().textContent();
    expect(firstRating?.trim()).toMatch(/\d\.\d/);

    // Stars on search page are yellow (search has .star class with explicit color)
    await page.goto('/search');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);
    const stars = page.locator('.result-row .star');
    await expect(stars.first()).toBeVisible({ timeout: 8000 });
    const color = await stars.first().evaluate(el => window.getComputedStyle(el).color);
    // Not grey — grey is rgb(~128,~128,~128)
    expect(color, 'Star should not be grey').not.toMatch(/rgb\(1[0-5]\d,\s*1[0-5]\d,\s*1[0-5]\d\)/);
  });

  test('VR-4: Home page city selector loads all 6 cities', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // City selector button visible in hero
    const cityBtn = page.locator('.city-selector__btn').first();
    await expect(cityBtn).toBeVisible({ timeout: 8000 });
    await cityBtn.click();

    // Dropdown opens with cities
    const dropdown = page.locator('.city-dropdown');
    await expect(dropdown).toBeVisible({ timeout: 5000 });

    const cityItems = page.locator('.city-dropdown .city-option, .city-dropdown li, .city-dropdown button').filter({ hasNotText: 'Near me' });
    const cityCount = await cityItems.count();
    expect(cityCount, 'Should show all 6 cities').toBeGreaterThanOrEqual(6);

    await saveScreenshot(page, 'home-city-dropdown');
  });

  test('VR-5: Restaurant card images are seeded with unique URLs (via API)', async ({ page }) => {
    // Verify via API that restaurants in a city have unique image URLs
    const ctx = await request.newContext();
    const res = await ctx.get('http://localhost:3001/dishly/v1/restaurants?limit=50');
    const body = await res.json();
    await ctx.dispose();

    const restaurants = body.data || [];
    if (restaurants.length < 10) return; // Skip if too few

    const urls = restaurants.map(r => r.cover_image_url).filter(Boolean);
    const uniqueUrls = new Set(urls);
    // Expect high uniqueness: at most 10% duplicates in the full dataset
    const dupeCount = urls.length - uniqueUrls.size;
    const dupePercent = (dupeCount / urls.length) * 100;
    expect(dupePercent, `Too many duplicate image URLs: ${dupeCount}/${urls.length} duplicates`).toBeLessThan(10);
  });

});

test.describe('UI Rendering — Search Page', () => {

  test('VR-6: Search page renders results, filters, and result count', async ({ page }) => {
    await page.goto('/search?q=ramen');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);

    await assertNotBlank(page, 'VR-6 Search');

    // NavBar search box visible and pre-populated
    await expect(page.locator('input.navbar__search-input')).toBeVisible({ timeout: 6000 });
    await expect(page.locator('input.navbar__search-input')).toHaveValue('ramen');

    // Filter pills visible
    await expect(page.locator('.search-filters')).toBeVisible({ timeout: 6000 });
    const pills = page.locator('.filter-pill');
    expect(await pills.count()).toBeGreaterThan(2);

    // Result count visible
    await expect(page.locator('.result-count')).toBeVisible({ timeout: 8000 });
    const countText = await page.locator('.result-count').textContent();
    expect(countText).toMatch(/\d+ restaurant/i);

    await saveScreenshot(page, 'search-page-ramen');
  });

  test('VR-7: Search page result rows show name, rating star, cuisine, price', async ({ page }) => {
    await page.goto('/search');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);

    const rows = page.locator('.result-row');
    await expect(rows.first()).toBeVisible({ timeout: 8000 });

    const firstRow = rows.first();

    // Restaurant name
    await expect(firstRow.locator('.result-name')).toBeVisible();
    const name = await firstRow.locator('.result-name').textContent();
    expect((name || '').trim().length).toBeGreaterThan(2);

    // Rating with star
    await expect(firstRow.locator('.star')).toBeVisible();
    await expect(firstRow.locator('.result-meta')).toContainText('★');

    // Price range shows $ symbols
    const meta = await firstRow.locator('.result-meta').textContent();
    expect(meta).toMatch(/\$/);

    await saveScreenshot(page, 'search-page-all');
  });

  test('VR-8: Search page star ratings are yellow not grey', async ({ page }) => {
    await page.goto('/search?q=japanese');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);

    const stars = page.locator('.result-row .star');
    await expect(stars.first()).toBeVisible({ timeout: 8000 });
    const color = await stars.first().evaluate(el => window.getComputedStyle(el).color);
    // Yellow star: rgb(255, 185, 0) or orange-yellow range — not grey
    expect(color, 'Star on search page should be yellow not grey').not.toMatch(/rgb\(1[0-5]\d,\s*1[0-5]\d,\s*1[0-5]\d\)/);
  });

  test('VR-9: Soba chip search shows "Soba Restaurants" title not "Results for Soba"', async ({ page }) => {
    await page.goto('/search?q=Soba');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(2000);

    const title = page.locator('.search-page__title');
    await expect(title).toBeVisible({ timeout: 6000 });
    const titleText = await title.textContent();
    expect(titleText).toContain('Soba');
    expect(titleText).not.toContain('Results for');

    await saveScreenshot(page, 'search-soba-chip');
  });

});

test.describe('UI Rendering — Restaurant Page', () => {

  test('VR-10: Restaurant detail page renders header, menu sections, and add-to-cart buttons', async ({ page }) => {
    const restaurantId = await getFirstRestaurantId();
    await page.goto(`/restaurants/${restaurantId}`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);

    await assertNotBlank(page, 'VR-10 Restaurant');

    // Restaurant name visible
    const heading = page.locator('h1, .restaurant-header__name, .restaurant-name').first();
    await expect(heading).toBeVisible({ timeout: 8000 });
    const name = await heading.textContent();
    expect((name || '').trim().length).toBeGreaterThan(2);

    // Hero image
    const heroImg = page.locator('.restaurant-hero img, .restaurant-header img').first();
    // May or may not have an img tag depending on background-image CSS; just check the section
    await expect(page.locator('.restaurant-hero, .restaurant-header').first()).toBeVisible({ timeout: 6000 });

    // Menu sections rendered
    const sections = page.locator('.menu-section, .menu-category');
    expect(await sections.count(), 'Should have at least 1 menu section').toBeGreaterThanOrEqual(1);

    // Add to cart buttons
    const addBtns = page.locator('button[class*="add"], button:has-text("Add"), .menu-item__add');
    expect(await addBtns.count(), 'Should have add-to-cart buttons').toBeGreaterThan(0);

    await saveScreenshot(page, 'restaurant-detail');
  });

  test('VR-11: Restaurant page menu items show name and price', async ({ page }) => {
    const restaurantId = await getFirstRestaurantId();
    await page.goto(`/restaurants/${restaurantId}`);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);

    const items = page.locator('.menu-item');
    await expect(items.first()).toBeVisible({ timeout: 8000 });
    const first = items.first();

    // Item name
    const itemName = await first.locator('.menu-item__name, [class*="item-name"]').first().textContent();
    expect((itemName || '').trim().length).toBeGreaterThan(1);

    // Price contains $
    const priceText = await first.locator('.menu-item__price, [class*="price"]').first().textContent();
    expect(priceText).toContain('$');
  });

});

test.describe('UI Rendering — Order History Page', () => {

  test('VR-12: Order history shows human-readable dates not raw ISO strings', async ({ page }) => {
    const user = await createTestUser();
    const restaurantId = await getFirstRestaurantId();
    const menuItemId = await getFirstMenuItemId(restaurantId);

    // Place an order via API
    const ctx = await request.newContext();
    await ctx.post(`${BASE_API}/orders`, {
      headers: { Authorization: `Bearer ${user.token}` },
      data: {
        restaurant_id: restaurantId,
        items: [{ menu_item_id: menuItemId, quantity: 1 }],
        delivery_address: '42 Test Street, New York, NY 10001',
        payment_method_id: 'pm_card_visa',
      },
    });
    await ctx.dispose();

    await seedAuth(page, user);
    await page.goto('/account/orders');
    await page.waitForLoadState('networkidle');

    await expect(page.locator('.order-card').first()).toBeVisible({ timeout: 10000 });

    const dateEl = page.locator('.order-card__date').first();
    await expect(dateEl).toBeVisible();
    const dateText = await dateEl.textContent();

    // Not raw ISO
    expect(dateText).not.toMatch(/^\d{4}-\d{2}-\d{2}$/);
    // Is human-readable
    const readable = /Today|Yesterday|Just now|ago|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|at\s+\d/i.test(dateText || '');
    expect(readable, `Date "${dateText}" should be human-readable`).toBe(true);

    await saveScreenshot(page, 'order-history');
  });

  test('VR-13: Order history page shows restaurant name and total price', async ({ page }) => {
    const user = await createTestUser();
    const restaurantId = await getFirstRestaurantId();
    const menuItemId = await getFirstMenuItemId(restaurantId);

    const ctx = await request.newContext();
    await ctx.post(`${BASE_API}/orders`, {
      headers: { Authorization: `Bearer ${user.token}` },
      data: {
        restaurant_id: restaurantId,
        items: [{ menu_item_id: menuItemId, quantity: 2 }],
        delivery_address: '42 Test Street, New York, NY 10001',
        payment_method_id: 'pm_card_visa',
      },
    });
    await ctx.dispose();

    await seedAuth(page, user);
    await page.goto('/account/orders');
    await page.waitForLoadState('networkidle');
    await expect(page.locator('.order-card').first()).toBeVisible({ timeout: 10000 });

    const card = page.locator('.order-card').first();
    await expect(card.locator('.order-card__restaurant')).toBeVisible();
    await expect(card.locator('.order-card__total')).toContainText('$');
  });

});

test.describe('UI Rendering — Checkout Page', () => {

  test('VR-14: Checkout page renders cart summary, delivery address, and payment form', async ({ page }) => {
    const user = await createTestUser();
    const restaurantId = await getFirstRestaurantId();
    const menuItemId = await getFirstMenuItemId(restaurantId);

    // Get item details
    const ctx = await request.newContext();
    const rRes = await ctx.get(`${BASE_API}/restaurants/${restaurantId}`);
    const rBody = await rRes.json();
    const restaurantName = rBody.data.name;
    const itemName = rBody.data.menu[0].items[0].name;
    await ctx.dispose();

    await seedLocalStorage(page, {
      dishly_token: user.token,
      dishly_user_email: user.email,
      dishly_user_name: user.email.split('@')[0],
      dishly_user_id: user.userId,
      dishly_cart: JSON.stringify({
        restaurantId,
        restaurantName,
        items: [{ id: menuItemId, name: itemName, price: { value: 1600, scale: 2 }, quantity: 1 }],
      }),
    });

    await page.goto('/checkout');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(800);

    await assertNotBlank(page, 'VR-14 Checkout');

    // Checkout heading
    await expect(page.locator('h1')).toContainText('Checkout', { timeout: 6000 });

    // Order summary shows restaurant and item
    await expect(page.locator('body')).toContainText(restaurantName, { timeout: 6000 });

    // Delivery address input
    await expect(page.locator('#address, input[id="address"], input.form-input').first())
      .toBeVisible({ timeout: 6000 });

    // Total visible
    await expect(page.locator('body')).toContainText('$');

    await saveScreenshot(page, 'checkout-page');
  });

  test('VR-15: Checkout redirects to /login when no session token', async ({ page }) => {
    await page.addInitScript(() => { localStorage.clear(); });
    await page.goto('/checkout');
    await page.waitForLoadState('load');
    await page.waitForTimeout(600);
    await expect(page).toHaveURL(/\/login/, { timeout: 6000 });
  });

});

test.describe('UI Rendering — Login & Register Pages', () => {

  test('VR-16: Login page renders form with email, password, and submit button', async ({ page }) => {
    await page.goto('/login');
    await page.waitForLoadState('load');

    await assertNotBlank(page, 'VR-16 Login');

    await expect(page.locator('input[type="email"]')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('input[type="password"]')).toBeVisible({ timeout: 5000 });
    // Scope to the login form submit button (not the navbar search button)
    await expect(page.locator('main button[type="submit"], form.login-form button[type="submit"], .btn-primary[type="submit"]').first())
      .toBeVisible({ timeout: 5000 });

    await saveScreenshot(page, 'login-page');
  });

  test('VR-17: Register page renders sign-up form', async ({ page }) => {
    await page.goto('/register');
    await page.waitForLoadState('load');

    await assertNotBlank(page, 'VR-17 Register');

    await expect(page.locator('input[type="email"]')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('input[type="password"]')).toBeVisible({ timeout: 5000 });

    await saveScreenshot(page, 'register-page');
  });

});

test.describe('UI Rendering — NavBar Layout', () => {

  test('VR-18: NavBar has cart and profile buttons on the right side', async ({ page }) => {
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/search');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);

    const navbar = page.locator('nav.navbar');
    await expect(navbar).toBeVisible({ timeout: 5000 });
    const navbarBox = await navbar.boundingBox();

    // Cart button should be visible
    const cartBtn = page.locator('.navbar__cart-btn');
    await expect(cartBtn).toBeVisible({ timeout: 5000 });
    const cartBox = await cartBtn.boundingBox();

    // Cart button x center should be in the right 40% of the navbar
    const cartCenter = cartBox.x + cartBox.width / 2;
    const navbarRight40Start = navbarBox.x + navbarBox.width * 0.6;
    expect(cartCenter, 'Cart button should be on the right side of navbar').toBeGreaterThan(navbarRight40Start);

    // Profile avatar visible
    await expect(page.locator('.navbar__profile-btn')).toBeVisible({ timeout: 5000 });
    const profileBox = await page.locator('.navbar__profile-btn').boundingBox();
    const profileCenter = profileBox.x + profileBox.width / 2;
    expect(profileCenter, 'Profile button should be on the right side of navbar').toBeGreaterThan(navbarRight40Start);

    await saveScreenshot(page, 'navbar-authenticated');
  });

  test('VR-19: NavBar search box is pre-populated from URL q= param', async ({ page }) => {
    await page.goto('/search?q=ramen');
    await page.waitForLoadState('load');
    await page.waitForTimeout(500);

    await expect(page.locator('input.navbar__search-input')).toBeVisible({ timeout: 6000 });
    await expect(page.locator('input.navbar__search-input')).toHaveValue('ramen');
  });

});

test.describe('UI Rendering — Account Profile Page', () => {

  test('VR-20: Account profile page renders personal info and address sections', async ({ page }) => {
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);

    await assertNotBlank(page, 'VR-20 Account');

    // Should show user email or name
    await expect(page.locator('body')).toContainText('@', { timeout: 6000 });

    // Should have account sections visible (view mode — no inputs until Edit is clicked)
    await expect(page.locator('.account-section, .account-info-row, section').first()).toBeVisible({ timeout: 8000 });

    await saveScreenshot(page, 'account-profile');
  });

});
