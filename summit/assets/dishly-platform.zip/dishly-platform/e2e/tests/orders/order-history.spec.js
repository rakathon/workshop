// @ts-check
// Feature: Order History — SC-22, SC-23, SC-24
const { test, expect } = require('@playwright/test');
const { createTestUser, seedAuth, getFirstRestaurantId, getFirstMenuItemId, placeTestOrder } = require('../helpers/auth');

test.describe('Order History', () => {
  test('SC-22: order history shows orders in reverse-chronological order', async ({ page }) => {
    const user   = await createTestUser();
    const restId = await getFirstRestaurantId();
    const itemId = await getFirstMenuItemId(restId);
    await placeTestOrder(user.token, restId, itemId);
    await placeTestOrder(user.token, restId, itemId);

    await seedAuth(page, user);
    await page.goto('/account/orders');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    const cards = page.locator('.order-card');
    expect(await cards.count()).toBeGreaterThanOrEqual(2);
    await expect(cards.first().locator('.order-card__restaurant')).toBeVisible();
    await expect(cards.first().locator('.order-card__date')).toBeVisible();
    await expect(cards.first().locator('.order-card__total')).toBeVisible();
  });

  test('SC-23: order row shows items and View details link', async ({ page }) => {
    const user   = await createTestUser();
    const restId = await getFirstRestaurantId();
    const itemId = await getFirstMenuItemId(restId);
    await placeTestOrder(user.token, restId, itemId);

    await seedAuth(page, user);
    await page.goto('/account/orders');
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    const card = page.locator('.order-card').first();
    await expect(card.locator('.order-card__item').first()).toBeVisible();
    await expect(card.locator('.order-card__link')).toBeVisible();
  });

  test('SC-24: empty state shown for new user with no orders', async ({ page }) => {
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/account/orders');
    await page.waitForLoadState('load');
    await page.waitForTimeout(800);

    await expect(page.locator('.empty-state')).toBeVisible();
    expect(await page.locator('.order-card').count()).toBe(0);
  });
});
