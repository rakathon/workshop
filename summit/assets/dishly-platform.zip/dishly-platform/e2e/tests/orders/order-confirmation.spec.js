// @ts-check
// Feature: Order Confirmation — SC-21
const { test, expect } = require('@playwright/test');
const { createTestUser, seedAuth, getFirstRestaurantId, getFirstMenuItemId, placeTestOrder } = require('../helpers/auth');

test.describe('Order Confirmation', () => {
  test('SC-21: confirmation screen shows order details, ETA, and CTAs', async ({ page }) => {
    const user       = await createTestUser();
    const restId     = await getFirstRestaurantId();
    const menuItemId = await getFirstMenuItemId(restId);
    const orderId    = await placeTestOrder(user.token, restId, menuItemId);

    await seedAuth(page, user);
    await page.goto(`/orders/${orderId}`);
    await page.waitForLoadState('load');
    await page.waitForTimeout(1200);

    await expect(page.locator('.confirmation-hero__icon')).toBeVisible();
    await expect(page.locator('.confirmation-hero__title')).toContainText('Order Confirmed');
    await expect(page.locator('.confirmation-details__heading')).toBeVisible();
    await expect(page.locator('.confirmation-details__restaurant')).toBeVisible();
    await expect(page.locator('.confirmation-details__address')).toBeVisible();
    await expect(page.locator('.eta-banner__time')).toContainText('30–40');
    await expect(page.locator('a.btn-primary, a.btn', { hasText: /back to home/i })).toBeVisible();
    await expect(page.locator('a.btn-ghost, a.btn', { hasText: /order history/i })).toBeVisible();
  });
});
