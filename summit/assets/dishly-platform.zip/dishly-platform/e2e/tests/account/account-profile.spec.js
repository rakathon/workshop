// @ts-check
// Feature: Account Profile Section — SC-1 through SC-22
// Source: features/us/account/account-profile.feature
const { test, expect, request } = require('@playwright/test');
const { createTestUser, seedAuth, seedLocalStorage } = require('../helpers/auth');

const BASE_API = 'http://localhost:3001/dishly/v1';

// ── API helpers ───────────────────────────────────────────────────────

async function createUserWithName(name) {
  const email = `profile-${Date.now()}@dishly-test.com`;
  const ctx = await request.newContext();
  const res = await ctx.post(`${BASE_API}/auth/register`, {
    data: { email, password: 'Password1!', name },
  });
  const body = await res.json();
  await ctx.dispose();
  return { email, name: body.data.user.name, token: body.data.token, userId: body.data.user.id };
}

async function addAddress(token, address) {
  const ctx = await request.newContext();
  const res = await ctx.post(`${BASE_API}/users/me/addresses`, {
    headers: { Authorization: `Bearer ${token}` },
    data: address,
  });
  const body = await res.json();
  await ctx.dispose();
  return body.data;
}

async function addPaymentMethod(token, pm) {
  const ctx = await request.newContext();
  const res = await ctx.post(`${BASE_API}/users/me/payment_methods`, {
    headers: { Authorization: `Bearer ${token}` },
    data: pm,
  });
  const body = await res.json();
  await ctx.dispose();
  return body.data;
}

async function seedAuthWithName(page, user) {
  const displayName = user.name || user.email.split('@')[0];
  await seedLocalStorage(page, {
    dishly_token: user.token,
    dishly_user_email: user.email,
    dishly_user_name: displayName,
    dishly_user_id: user.userId,
  });
}

// ── Profile Header ─────────────────────────────────────────────────────

test.describe('Profile Header', () => {
  // SC-1
  test('SC-1: account page shows profile header with name and initials', async ({ page }) => {
    // Given — a signed-in customer with name "Alex Brennan"
    const user = await createUserWithName('Alex Brennan');
    await seedAuthWithName(page, user);

    // When — navigate to /account
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Then — avatar shows initials "AB"
    await expect(page.locator('.account-avatar')).toHaveText('AB');

    // And — heading shows name
    await expect(page.locator('.account-card__name')).toHaveText('Alex Brennan');

    // And — email visible
    await expect(page.locator('.account-card__email')).toContainText(user.email);
    // Verifies: BR-5 — avatar displays initials from persisted name
  });

  // SC-2
  test('SC-2: account page shows email-prefix fallback when no name set', async ({ page }) => {
    // Given — a signed-in customer with no stored name
    const user = await createTestUser();
    await seedAuth(page, user);

    // When
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Then — avatar shows email-prefix initials (not empty)
    const avatar = page.locator('.account-avatar');
    await expect(avatar).not.toHaveText('');
    const avatarText = await avatar.textContent();
    expect(avatarText?.length).toBeGreaterThanOrEqual(1);

    // And — heading shows generic fallback (not real name)
    await expect(page.locator('.account-card__name')).toBeVisible();
    // Verifies: BR-1 — email-prefix fallback
  });
});

// ── Personal Info Edit ─────────────────────────────────────────────────

test.describe('Personal Info Edit', () => {
  // SC-3
  test('SC-3: personal info section opens inline edit form on Edit click', async ({ page }) => {
    // Given — signed-in customer on account page
    const user = await createUserWithName('Alex Brennan');
    await seedAuthWithName(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Wait for profile to load
    await expect(page.locator('.account-section__title', { hasText: /personal info/i })).toBeVisible();

    // When — click Edit
    await page.locator('.edit-link').first().click();

    // Then — inline form visible with Name and Phone fields
    await expect(page.locator('#edit-name')).toBeVisible();
    await expect(page.locator('#edit-phone')).toBeVisible();

    // And — Save and Cancel buttons visible
    await expect(page.locator('button', { hasText: 'Save changes' })).toBeVisible();
    await expect(page.locator('button', { hasText: 'Cancel' })).toBeVisible();

    // And — Email row still visible (read-only)
    await expect(page.locator('.account-info-row', { hasText: 'Email' })).toBeVisible();
    // Verifies: BR-2 — inline edit affordance
  });

  // SC-4
  test('SC-4: invalid phone shows field-level error and form stays open', async ({ page }) => {
    // Given — edit form open
    const user = await createUserWithName('Alex Brennan');
    await seedAuthWithName(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');
    await expect(page.locator('.edit-link').first()).toBeVisible();
    await page.locator('.edit-link').first().click();

    // When — enter invalid phone and save
    await page.locator('#edit-phone').fill('123abc');
    await page.locator('button', { hasText: 'Save changes' }).click();

    // Then — inline error visible
    await expect(page.locator('.form-error[role="alert"]')).toBeVisible();

    // And — form still open
    await expect(page.locator('#edit-phone')).toBeVisible();
    // Verifies: BR-2 — invalid phone shows inline error
  });

  // SC-5
  test('SC-5: saving valid info updates NavBar name without page reload', async ({ page }) => {
    // Given — edit form open
    const user = await createUserWithName('Alex Brennan');
    await seedAuthWithName(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');
    await page.locator('.edit-link').first().click();

    // When — change name and save
    await page.locator('#edit-name').fill('Jordan Smith');
    await page.locator('button', { hasText: 'Save changes' }).click();

    // Then — read view shows updated name
    await expect(page.locator('.account-info-row', { hasText: 'Name' }).locator('.account-info-row__value')).toHaveText('Jordan Smith', { timeout: 5000 });

    // And — NavBar avatar shows new initials (no page reload)
    await expect(page.locator('.navbar__avatar')).toHaveText('JS', { timeout: 5000 });

    // And — toast visible
    await expect(page.locator('.toast')).toBeVisible({ timeout: 3000 });
    // Verifies: BR-2 — name update; BR-5 — NavBar reactivity
  });

  // SC-6
  test('SC-6: cancel edit restores read view without saving', async ({ page }) => {
    // Given — edit form open with unsaved changes
    const user = await createUserWithName('Alex Brennan');
    await seedAuthWithName(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');
    await page.locator('.edit-link').first().click();
    await page.locator('#edit-name').fill('Not Saved Name');

    // When — click Cancel
    await page.locator('button', { hasText: 'Cancel' }).click();

    // Then — form closed, original values restored
    await expect(page.locator('#edit-name')).not.toBeVisible();
    await expect(page.locator('.account-info-row', { hasText: 'Name' }).locator('.account-info-row__value')).toHaveText('Alex Brennan');
    // Verifies: UX cancel interaction
  });
});

// ── Delivery Addresses ─────────────────────────────────────────────────

test.describe('Delivery Addresses', () => {
  // SC-7
  test('SC-7: addresses section shows empty state when no addresses saved', async ({ page }) => {
    // Given — no saved addresses
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Then — empty state visible
    await expect(page.locator('.section-empty__title', { hasText: /no.*address/i })).toBeVisible({ timeout: 8000 });

    // And — Add address button visible
    await expect(page.locator('button.add-btn', { hasText: /add address/i })).toBeVisible();
    // Verifies: BR-3 — empty state CTA
  });

  // SC-8
  test('SC-8: add address form appears inline and saving shows new card', async ({ page }) => {
    // Given — no saved addresses
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');
    await page.locator('button.add-btn', { hasText: /add address/i }).click();

    // Then — inline form visible
    await expect(page.locator('#addr-street')).toBeVisible();
    await expect(page.locator('#addr-city')).toBeVisible();
    await expect(page.locator('#addr-postcode')).toBeVisible();

    // When — fill and save
    await page.locator('#addr-street').fill('42 Maple St');
    await page.locator('#addr-city').fill('Springfield');
    await page.locator('#addr-postcode').fill('12345');
    await page.locator('button', { hasText: 'Save address' }).click();

    // Then — card appears (use first() to avoid strict mode on .or() matching both title and sub)
    await expect(page.locator('.item-card__sub').filter({ hasText: '42 Maple St' }).first()).toBeVisible({ timeout: 8000 });

    // And — toast visible
    await expect(page.locator('.toast')).toBeVisible({ timeout: 3000 });
    // Verifies: BR-3 — add address flow
  });

  // SC-9
  test('SC-9: default address card shows Default badge with no Set default button', async ({ page }) => {
    // Given — one address marked as default
    const user = await createTestUser();
    await addAddress(user.token, { street: '42 Maple St', city: 'Springfield', postcode: '12345', is_default: true });
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Then — Default badge visible
    await expect(page.locator('.item-card__badge', { hasText: 'Default' })).toBeVisible({ timeout: 8000 });

    // And — Set default button absent on this card
    const card = page.locator('.item-card').first();
    await expect(card.locator('button', { hasText: /set default/i })).not.toBeVisible();

    // And — Edit and Delete present
    await expect(card.locator('button', { hasText: 'Edit' })).toBeVisible();
    await expect(card.locator('button.danger', { hasText: 'Delete' })).toBeVisible();
    // Verifies: BR-3 — default address display
  });

  // SC-10
  test('SC-10: delete confirmation appears inline and confirming removes the card', async ({ page }) => {
    // Given — one saved address
    const user = await createTestUser();
    await addAddress(user.token, { street: '42 Maple St', city: 'Springfield', postcode: '12345' });
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Wait for address card
    await expect(page.locator('.item-card')).toBeVisible({ timeout: 8000 });

    // When — click Delete
    await page.locator('.item-card button.danger', { hasText: 'Delete' }).click();

    // Then — inline confirmation visible
    await expect(page.locator('.delete-confirm')).toBeVisible();
    await expect(page.locator('.delete-confirm button', { hasText: 'Delete' })).toBeVisible();
    await expect(page.locator('.delete-confirm button', { hasText: 'Keep it' })).toBeVisible();

    // When — confirm delete
    await page.locator('.delete-confirm button', { hasText: 'Delete' }).click();

    // Then — addresses section shows empty state (card gone)
    await expect(page.locator('#addresses-content .item-card')).toHaveCount(0, { timeout: 5000 });

    // And — empty state or toast (use first() to avoid strict mode when both render simultaneously)
    await expect(
      page.locator('.toast').or(page.locator('.section-empty__title')).first()
    ).toBeVisible({ timeout: 5000 });
    // Verifies: BR-3 — delete address
  });

  // SC-11
  test('SC-11: add address button hidden when 2 addresses saved', async ({ page }) => {
    // Given — 2 saved addresses
    const user = await createTestUser();
    await addAddress(user.token, { street: '42 Maple St', city: 'Springfield', postcode: '12345', is_default: true });
    await addAddress(user.token, { street: '10 Work Ave', city: 'Springfield', postcode: '12345' });
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Wait for both cards
    await expect(page.locator('.item-card')).toHaveCount(2, { timeout: 8000 });

    // Then — Add address button not visible
    await expect(page.locator('button.add-btn', { hasText: /add address/i })).not.toBeVisible();

    // And — cap note shown
    await expect(page.locator('.cap-note')).toBeVisible();
    // Verifies: BR-3 — cap enforcement UI
  });
});

// ── Payment Methods ────────────────────────────────────────────────────

test.describe('Payment Methods', () => {
  // SC-12
  test('SC-12: payment section shows empty state when no methods saved', async ({ page }) => {
    // Given — no saved payment methods
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Then — empty state visible
    await expect(page.locator('.section-empty__title', { hasText: /no.*payment/i })).toBeVisible({ timeout: 8000 });

    // And — Add payment method button visible
    await expect(page.locator('button.add-btn', { hasText: /add payment/i })).toBeVisible();
    // Verifies: BR-4 — empty state
  });

  // SC-13
  test('SC-13: add payment form shows card type selector and saving shows card', async ({ page }) => {
    // Given — no saved payment methods
    const user = await createTestUser();
    await seedAuth(page, user);
    await page.goto('/account');
    await page.waitForLoadState('load');

    // When — click Add payment method
    await page.locator('button.add-btn', { hasText: /add payment/i }).click();

    // Then — form visible with card type selector and name field
    await expect(page.locator('#pm-type')).toBeVisible();
    await expect(page.locator('#pm-name')).toBeVisible();

    // When — fill and save (card number now required)
    await page.locator('#pm-type').selectOption('Visa');
    await page.locator('#pm-number').fill('4111 1111 1111 1111');
    await page.locator('#pm-name').fill('Alex Brennan');
    await page.locator('button', { hasText: 'Save card' }).click();

    // Then — Visa card appears with last four (wait for API response + re-render)
    await expect(page.locator('.item-card__title').filter({ hasText: 'Visa' })).toBeVisible({ timeout: 10000 });
    await expect(page.locator('.item-card__sub').filter({ hasText: 'Alex Brennan' })).toBeVisible();

    // And — toast
    await expect(page.locator('.toast')).toBeVisible({ timeout: 3000 });
    // Verifies: BR-4 — add payment method
  });
});

// ── Checkout Pre-fill ──────────────────────────────────────────────────

test.describe('Checkout Pre-fill', () => {
  async function getFirstRestaurantAndItem() {
    const ctx = await request.newContext();
    const res = await ctx.get(`${BASE_API}/restaurants`);
    const body = await res.json();
    const restaurant = body.data[0];
    const resRes = await ctx.get(`${BASE_API}/restaurants/${restaurant.id}`);
    const resBody = await resRes.json();
    await ctx.dispose();
    const item = resBody.data.menu[0].items[0];
    return { restaurantId: restaurant.id, restaurantName: restaurant.name, itemId: item.id, itemName: item.name };
  }

  // SC-14
  test('SC-14: checkout delivery field pre-filled from saved default address', async ({ page }) => {
    // Given — customer with default address and non-empty cart
    const user = await createTestUser();
    await addAddress(user.token, { street: '42 Maple St', city: 'Springfield', postcode: '12345', is_default: true });
    const { restaurantId, restaurantName, itemId, itemName } = await getFirstRestaurantAndItem();
    await seedLocalStorage(page, {
      dishly_token: user.token,
      dishly_user_email: user.email,
      dishly_user_name: user.email.split('@')[0],
      dishly_user_id: user.userId,
      dishly_cart: JSON.stringify({
        restaurantId,
        restaurantName,
        items: [{ id: itemId, name: itemName, price: { value: 1600, scale: 2 }, quantity: 1 }],
      }),
    });

    // When — navigate to checkout
    await page.goto('/checkout');
    await page.waitForLoadState('load');

    // Then — delivery address field pre-populated (wait for async load)
    const addressInput = page.locator('#address, input[id="address"]');
    await expect(addressInput).toHaveValue(/42 Maple St/, { timeout: 8000 });
    // Verifies: BR-3 — default address pre-fills checkout
  });

  // SC-15
  test('SC-15: checkout shows payment radio options for saved methods plus fallback', async ({ page }) => {
    // Given — customer with one saved payment method and non-empty cart
    const user = await createTestUser();
    await addPaymentMethod(user.token, { card_type: 'Visa', cardholder_name: 'Alex Brennan', card_number: '4111111111111111' });
    const { restaurantId, restaurantName, itemId, itemName } = await getFirstRestaurantAndItem();
    await seedLocalStorage(page, {
      dishly_token: user.token,
      dishly_user_email: user.email,
      dishly_user_name: user.email.split('@')[0],
      dishly_user_id: user.userId,
      dishly_cart: JSON.stringify({
        restaurantId,
        restaurantName,
        items: [{ id: itemId, name: itemName, price: { value: 1600, scale: 2 }, quantity: 1 }],
      }),
    });

    // When
    await page.goto('/checkout');
    await page.waitForLoadState('load');

    // Then — Visa option visible (async load from /users/me/payment_methods)
    await expect(page.locator('.payment-option').filter({ hasText: /Visa/i })).toBeVisible({ timeout: 10000 });

    // And — Pay on delivery option also visible
    await expect(page.locator('.payment-option').filter({ hasText: /pay on delivery/i })).toBeVisible();
    // Verifies: BR-4 — payment options at checkout
  });
});

// ── Register Name Field ────────────────────────────────────────────────

test.describe('Register Name Field', () => {
  // SC-16
  test('SC-16: register form includes optional Name field', async ({ page }) => {
    // Given — on register page
    await page.goto('/register');
    await page.waitForLoadState('load');

    // Then — optional Name field visible
    await expect(page.locator('#reg-name')).toBeVisible();
    const nameLabel = page.locator('label[for="reg-name"]');
    await expect(nameLabel).toContainText('optional', { ignoreCase: true });

    // When — submit without name
    const email = `no-name-${Date.now()}@dishly-test.com`;
    await page.locator('#reg-email').fill(email);
    await page.locator('#reg-password').fill('Password1!');
    await page.locator('form.auth-form button[type="submit"]').click();

    // Then — registration succeeds (redirected away from /register)
    await expect(page).not.toHaveURL(/\/register/, { timeout: 8000 });
    // Verifies: BR-1 — optional name field
  });
});

// ── NavBar ─────────────────────────────────────────────────────────────

test.describe('NavBar Auth State', () => {
  // SC-17
  test('SC-17: NavBar avatar shows initials after sign-in', async ({ page }) => {
    // Given — registered customer with name "Sam Rivera"
    const user = await createUserWithName('Sam Rivera');
    await seedAuthWithName(page, user);

    // When — any page load (use /account to avoid redirect)
    await page.goto('/account');
    await page.waitForLoadState('load');

    // Then — NavBar avatar shows "SR"
    await expect(page.locator('.navbar__avatar')).toHaveText('SR', { timeout: 5000 });
    // Verifies: BR-5 — initials in NavBar avatar
  });

  // SC-18
  test('SC-18: NavBar dropdown shows full name and email', async ({ page }) => {
    // Given — signed-in customer with name "Sam Rivera"
    const user = await createUserWithName('Sam Rivera');
    await seedLocalStorage(page, {
      dishly_token: user.token,
      dishly_user_email: user.email,
      dishly_user_name: 'Sam Rivera',
      dishly_user_id: user.userId,
    });

    // When — navigate and click avatar
    await page.goto('/');
    await page.waitForLoadState('load');
    await page.locator('.navbar__profile-btn').click();

    // Then — dropdown shows full name
    await expect(page.locator('.navbar__dropdown-name')).toHaveText('Sam Rivera');

    // And — dropdown shows email
    await expect(page.locator('.navbar__dropdown-email')).toContainText(user.email);

    // And — My account and Sign out visible
    await expect(page.locator('.navbar__dropdown-item', { hasText: /my account/i })).toBeVisible();
    await expect(page.locator('.navbar__dropdown-item--danger', { hasText: /sign out/i })).toBeVisible();
    // Verifies: BR-5 — dropdown shows full name and email
  });
});

// ── Checkout — Dummy Card Entry (BR-6) ─────────────────────────────────

test.describe('Checkout — Dummy Card Entry', () => {
  async function getFirstRestaurantAndItem() {
    const ctx = await request.newContext();
    const res = await ctx.get(`${BASE_API}/restaurants`);
    const body = await res.json();
    const restaurant = body.data[0];
    const resRes = await ctx.get(`${BASE_API}/restaurants/${restaurant.id}`);
    const resBody = await resRes.json();
    await ctx.dispose();
    const item = resBody.data.menu[0].items[0];
    return { restaurantId: restaurant.id, restaurantName: restaurant.name, itemId: item.id, itemName: item.name };
  }

  async function seedCheckoutCart(page) {
    const user = await createTestUser();
    const { restaurantId, restaurantName, itemId, itemName } = await getFirstRestaurantAndItem();
    await seedLocalStorage(page, {
      dishly_token: user.token,
      dishly_user_email: user.email,
      dishly_user_name: user.email.split('@')[0],
      dishly_user_id: user.userId,
      dishly_cart: JSON.stringify({
        restaurantId,
        restaurantName,
        items: [{ id: itemId, name: itemName, price: { value: 1600, scale: 2 }, quantity: 1 }],
      }),
    });
    return user;
  }

  // SC-19
  test('SC-19: "Enter a card" radio reveals card fields at checkout', async ({ page }) => {
    // Given — signed-in customer on /checkout
    await seedCheckoutCart(page);
    await page.goto('/checkout');
    await page.waitForLoadState('load');

    // Confirm card fields not yet visible
    await expect(page.locator('#card-number')).not.toBeVisible();

    // When — click "Enter a card" radio
    await page.locator('.payment-option').filter({ hasText: /enter a card/i }).locator('input[type="radio"]').click();

    // Then — card fields revealed
    await expect(page.locator('#card-number')).toBeVisible();
    await expect(page.locator('#card-expiry')).toBeVisible();
    await expect(page.locator('#card-cvv')).toBeVisible();
    // Verifies: BR-6 — "Enter a card" reveals card number, expiry, CVV fields
  });

  // SC-20
  test('SC-20: card number auto-formats as groups of four', async ({ page }) => {
    // Given — "Enter a card" selected
    await seedCheckoutCart(page);
    await page.goto('/checkout');
    await page.waitForLoadState('load');
    await page.locator('.payment-option').filter({ hasText: /enter a card/i }).locator('input[type="radio"]').click();
    await expect(page.locator('#card-number')).toBeVisible();

    // When — type 16 digits
    await page.locator('#card-number').fill('4111111111111111');

    // Then — formatted as XXXX XXXX XXXX XXXX
    const value = await page.locator('#card-number').inputValue();
    expect(value).toMatch(/^\d{4} \d{4} \d{4} \d{4}$/);
    // Verifies: BR-6 — card number auto-formats
  });

  // SC-21
  test('SC-21: invalid card number shows inline error on submit', async ({ page }) => {
    // Given — "Enter a card" selected
    await seedCheckoutCart(page);
    await page.goto('/checkout');
    await page.waitForLoadState('load');
    await page.locator('.payment-option').filter({ hasText: /enter a card/i }).locator('input[type="radio"]').click();
    await expect(page.locator('#card-number')).toBeVisible();

    // Fill address so address validation doesn't fire first
    await page.locator('#address').fill('42 Test St, Springfield, 12345');

    // When — enter invalid card number (< 16 digits) and submit
    await page.locator('#card-number').fill('1234');
    await page.locator('button.btn-primary.btn-wide[type="submit"]').click();

    // Then — card error visible (inside card-entry div), no redirect
    await expect(page.locator('.checkout-card-entry .checkout-error')).toBeVisible({ timeout: 5000 });
    await expect(page).toHaveURL(/\/checkout/);
    // Verifies: BR-6 — 16-digit validation before submission
  });
});

// ── Restaurant Menu — Quantity Stepper (BR-7) ──────────────────────────

test.describe('Restaurant Menu — Quantity Stepper', () => {
  async function getFirstRestaurantId() {
    const ctx = await request.newContext();
    const res = await ctx.get(`${BASE_API}/restaurants`);
    const body = await res.json();
    await ctx.dispose();
    return body.data[0].id;
  }

  // SC-22
  test('SC-22: "Add to cart" replaced by stepper; +/− adjust quantity; 0 restores button', async ({ page }) => {
    // Given — signed-in customer on a restaurant page
    const user = await createTestUser();
    await seedAuth(page, user);
    const restaurantId = await getFirstRestaurantId();
    await page.goto(`/restaurants/${restaurantId}`);
    await page.waitForLoadState('load');

    // Confirm "Add to cart" button present
    const addBtn = page.locator('.menu-item__add').first();
    await expect(addBtn).toBeVisible({ timeout: 8000 });

    // When — click "Add to cart"
    await addBtn.click();

    // Then — stepper replaces button showing quantity 1
    await expect(page.locator('.menu-item__stepper').first()).toBeVisible({ timeout: 5000 });
    await expect(page.locator('.menu-item__stepper-qty').first()).toHaveText('1');

    // When — click "+" twice
    await page.locator('.menu-item__stepper-btn').last().click();
    await page.locator('.menu-item__stepper-btn').last().click();

    // Then — quantity shows 3 and NavBar badge reflects count
    await expect(page.locator('.menu-item__stepper-qty').first()).toHaveText('3');
    await expect(page.locator('.navbar__badge')).toHaveText('3');

    // When — click "−" three times (back to 0)
    const decrementBtn = page.locator('.menu-item__stepper').first().locator('.menu-item__stepper-btn').first();
    await decrementBtn.click();
    await decrementBtn.click();
    await decrementBtn.click();

    // Then — "Add to cart" button restored
    await expect(page.locator('.menu-item__add').first()).toBeVisible({ timeout: 5000 });
    await expect(page.locator('.menu-item__stepper').first()).not.toBeVisible();
    // Verifies: BR-7 — stepper lifecycle; NavBar badge sync
  });
});
