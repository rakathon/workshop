#!/usr/bin/env bash
set -e

# Load NVM if available so we use the project's Node version
export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

# ── Kill any processes already using ports 3000, 3001, and 7477 ─────────
echo "[start] Releasing ports 3000, 3001, and 7477..."
lsof -ti:3001 | xargs kill -9 2>/dev/null || true
lsof -ti:3000 | xargs kill -9 2>/dev/null || true
lsof -ti:7477 | xargs kill -9 2>/dev/null || true
sleep 0.5

# Install dependencies if node_modules absent
if [ ! -d "backend/node_modules" ]; then
  echo "[start] Installing backend dependencies..."
  npm install --prefix backend --no-fund --loglevel=error
fi

if [ ! -d "frontend/node_modules" ]; then
  echo "[start] Installing frontend dependencies..."
  npm install --prefix frontend --no-fund --loglevel=error
fi

if [ ! -d "node_modules" ]; then
  echo "[start] Installing root dependencies..."
  npm install --no-fund --loglevel=error
fi

# Apply migrations (idempotent — safe to run on every start)
echo "[start] Applying database migrations..."
node -e "require('./backend/src/db/migrate').migrate()"

# Seed database on first run
echo "[start] Checking database seed..."
node backend/src/db/seed.js

# Start forge:docs server in background
FORGE_DOCS_SKILL=$(find ~/.claude/plugins/cache/rr-standards/forge -name "generate.py" -path "*/docs/scripts/*" 2>/dev/null | sort -V | tail -1)
if [ -n "$FORGE_DOCS_SKILL" ]; then
  echo "[start] Starting forge:docs at http://localhost:7477/.forge/site/ ..."
  python3 "$FORGE_DOCS_SKILL" --serve --repo-root "$(pwd)" > /dev/null 2>&1 &
fi

# Open app in browser after a short delay to allow frontend to start
(sleep 5 && open http://localhost:3000) &

# Start backend and frontend concurrently
echo "[start] Starting dishly..."
npx concurrently \
  --names "backend,frontend" \
  --prefix-colors "cyan,magenta" \
  "npm run dev --prefix backend" \
  "npm run dev --prefix frontend"
