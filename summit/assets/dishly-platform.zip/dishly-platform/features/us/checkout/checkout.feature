Feature: Checkout — 3-step linear flow with no new friction

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data
    And an authenticated user has items in the cart
    And the user has navigated to "/checkout"

  @SC-17 @non-production
  Scenario: Checkout step 1 — address form renders correctly
    When the page loads at step 1
    Then the step indicator shows step 1 as active and steps 2 and 3 as inactive
    And address input fields are visible with associated labels
    And a "Continue to payment" button is visible
    # Verifies: S-07 — checkout step 1

  @SC-18 @non-production
  Scenario: Checkout step 2 — payment form renders correctly
    Given the user is at checkout step 2
    When the step 2 panel is active
    Then card number, expiry, and CVC fields are visible with associated labels
    And a security note about Stripe is visible
    And a "Review order" button is visible
    And a back link to step 1 is visible
    # Verifies: S-08 — checkout step 2

  @SC-19 @non-production
  Scenario: Checkout step 3 — order summary renders correctly
    Given the user is at checkout step 3
    When the summary panel is active
    Then an itemised list of ordered items with prices is visible
    And subtotal, delivery fee, and total are visible
    And the delivery address entered in step 1 is shown
    And a "Place order" primary CTA button showing the total amount is visible
    # Verifies: S-09 — checkout step 3

  @SC-20 @non-production
  Scenario: Checkout inline error state renders and preserves cart
    Given the user is at checkout step 3
    And the order submission will return an error response
    When the error response is received after clicking "Place order"
    Then an inline error banner is visible on the step 3 panel
    And the error message references the failed submission in plain language
    And the order summary items are still visible
    And the "Place order" button is re-enabled for retry
    # Verifies: S-09 error state — BR-15
