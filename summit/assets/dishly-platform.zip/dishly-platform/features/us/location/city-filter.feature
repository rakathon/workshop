Feature: Location-based City Filtering

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend API is running at "http://localhost:3001"
    And the /dishly/v1/neighbourhoods endpoint returns 10 cities

  # ── Dropdown Open ────────────────────────────────────────────────────

  @SC-1 @non-production
  Scenario: City dropdown opens and shows all cities
    Given a visitor on the home page
    When the visitor clicks the city selector button
    Then the city dropdown opens
    And all 10 cities are listed in the dropdown

  # ── Type-to-filter ───────────────────────────────────────────────────

  @SC-2 @non-production
  Scenario: Typing in the dropdown filters the city list
    Given a visitor on the home page
    And the city dropdown is open
    When the visitor types "man" in the filter input
    Then only cities matching "man" are shown
    And non-matching cities are hidden

  # ── Select city ──────────────────────────────────────────────────────

  @SC-3 @non-production
  Scenario: Selecting a city stores the selection and filters restaurant results
    Given a visitor on the home page
    And the city dropdown is open
    When the visitor selects "Manhattan" from the dropdown
    Then the dropdown closes
    And the city selector button shows "Manhattan"
    And "dishly_city" is stored in localStorage
    And the restaurant list is filtered to show only Manhattan restaurants

  # ── Clear filter ─────────────────────────────────────────────────────

  @SC-4 @non-production
  Scenario: Clear button resets the city filter
    Given a visitor on the home page
    And "Manhattan" is the active city selection
    When the visitor opens the city dropdown and clears the selection
    Then the active city selection is removed
    And the city selector button returns to its default state
    And all restaurants are shown

  # ── NavBar visibility ────────────────────────────────────────────────

  @SC-5 @non-production
  Scenario: City selector is visible in the NavBar
    Given a visitor on the home page
    When the page loads
    Then the city selector button is visible in the NavBar

  # ── Search page visibility ───────────────────────────────────────────

  @SC-6 @non-production
  Scenario: City selector is visible on the Search page
    Given a visitor on the search page
    When the page loads
    Then the city selector button is visible on the search page
    And the city dropdown can be opened from the search page
