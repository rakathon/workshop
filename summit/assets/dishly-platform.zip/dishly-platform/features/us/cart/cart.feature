Feature: Cart — no-surprise order review before checkout

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data

  @SC-13 @non-production
  Scenario: Cart drawer opens and shows items with totals
    Given an authenticated user has added items to the cart on a restaurant page
    When they click the cart icon in the header
    Then the cart drawer slides in from the right
    And each cart item row shows a thumbnail image, item name, price, and quantity controls
    And a subtotal, delivery fee, and estimated total are visible
    And a "Proceed to Checkout" button is visible
    # Verifies: S-05 — cart drawer with items

  @SC-14 @non-production
  Scenario: Cart empty state renders when cart is empty
    Given an authenticated user with an empty cart
    When they navigate to "/cart"
    Then an empty state message is visible
    And no item rows or total rows are visible
    # Verifies: S-05 empty state

  @SC-15 @non-production
  Scenario: Quantity controls in cart update item count
    Given the cart drawer is open with at least one item at quantity 1
    When the user clicks the "+" quantity button
    Then the quantity display increments to 2
    When the user clicks the "−" button at quantity 1
    Then the item row is removed from the cart
    # Verifies: S-05 — quantity controls

  @SC-16 @non-production
  Scenario: Cart conflict modal appears when switching restaurants
    Given an authenticated user has items from "Restaurant A" in their cart
    When they navigate to a different restaurant and tap an Add button
    Then a conflict modal appears naming "Restaurant A"
    And two action buttons are visible: one to keep the current cart and one to start a new order
    When they click "Keep current cart"
    Then the modal closes without clearing the cart
    # Verifies: S-06 — BR-11 cart conflict modal
