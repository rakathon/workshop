Feature: Search Results — filter-and-land surface for intent-driven discovery

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data

  @SC-4 @non-production
  Scenario: Search results render with filter chips
    When the user navigates to "/search?q=ramen"
    Then a result count label is visible
    And cuisine filter chips are visible above the results
    And price range filter chips are visible
    And at least 1 result row is visible with a thumbnail image, name, and metadata
    # Verifies: S-02 — search results default state

  @SC-5 @non-production
  Scenario: Cuisine filter chip narrows results and updates count
    Given the search results page is showing results for "ramen"
    When the user clicks the "Japanese" cuisine filter chip
    Then the chip becomes active with purple fill
    And the result count label updates
    And only result rows consistent with Japanese cuisine remain visible
    # Verifies: S-02 — filter active state, count update

  @SC-6 @non-production
  Scenario: Search empty state renders correctly
    Given the user is on the search results page
    When they search for "xyzzy_no_results"
    Then no restaurant result rows are visible
    And an empty state message is visible containing the text "xyzzy_no_results"
    And a "Browse collections" call-to-action button is visible
    # Verifies: S-02 empty state — BR-15

  @SC-13 @non-production
  Scenario: Keyword search from home hero navigates to search results
    Given the user is on the Home page
    When the user types "ramen" in the hero search input and submits the form
    Then the page navigates to /search with q=ramen in the URL
    And at least one restaurant result row is visible
    # Verifies: Home hero search → /search?q=

  @SC-14 @non-production
  Scenario: Keyword search returns relevant restaurants with full result row
    Given the user is on the search results page
    When the user searches for "Japanese"
    Then at least one restaurant result row is visible
    And the result count label shows a non-zero count
    And each result row shows a restaurant name, rating, cuisine, and price range
    # Verifies: Search results default state — result rows render correctly

  @SC-15 @non-production
  Scenario: City filter combined with cuisine filter narrows results
    Given the user is on the search results page
    And the user selects "Los Angeles" from the city selector
    When the user clicks the "Japanese" cuisine filter chip
    Then only restaurants from Los Angeles with Japanese cuisine are visible
    And the result count decreases compared to unfiltered results
    And both the city selector and cuisine chip show active state simultaneously
    # Verifies: BR-1 — city + cuisine combined filter

  @SC-16 @non-production
  Scenario: Price range filter narrows search results
    Given the user is on the search results page with results showing
    When the user clicks the "$$" price filter chip
    Then only restaurants with $$ price range appear in results
    And the "$$" chip shows an active selected style
    And the result count updates to reflect the applied filter
    # Verifies: Price filter active state and result update

  @SC-17 @non-production
  Scenario: City filter combined with price filter narrows results
    Given the user is on the search results page
    And the user selects "San Francisco" from the city selector
    When the user clicks the "$$$" price filter chip
    Then only San Francisco restaurants with $$$ price range are visible
    And both the city selector and $$$ chip show active state
    # Verifies: BR-1 — city + price combined filter

  @SC-18 @non-production
  Scenario: Clearing city filter on Search page restores all-city results
    Given the user is on the search results page with "Chicago" as the active city
    When the user clicks the × clear button on the city selector
    Then the city selector resets to "All cities"
    And restaurants from all cities are visible in the results
    And the result count increases back to the unfiltered count
    # Verifies: BR-2 — city filter cleared; all-city results restored

  @SC-19 @non-production
  Scenario: Individual cuisine filter chip can be deactivated while other filters remain
    Given the user is on the search results page with city, cuisine, and price filters all active
    When the user clicks the active cuisine chip to deactivate it
    Then the cuisine chip returns to its inactive style
    And the city and price filters remain active
    And the results update to show all cuisines matching the active city and price filters
    # Verifies: Independent filter reset — individual chip deactivation

  @SC-20 @non-production
  Scenario: Search with no results shows empty state when city filter is active
    Given the user is on the search results page with "Boston" selected as the active city
    When the user searches for "xyzzy123" (a term with no results)
    Then no restaurant result rows are visible
    And an empty state message is visible
    And the message suggests trying a different search or browsing all cities
    # Verifies: Empty state with active city filter — combined no-results state

  @SC-21 @non-production
  Scenario: NavBar search box pre-populated from URL keyword
    When the user navigates to "/search?q=ramen"
    Then the NavBar search input shows "ramen" pre-filled

  @SC-22 @non-production
  Scenario: Soba chip auto-selects Japanese cuisine filter
    Given the user is on the Home page
    When the user clicks the "Soba" chip
    Then the search results page loads at /search?q=Soba
    And the "Japanese" cuisine chip is active
    And the page title shows "Soba Restaurants"
