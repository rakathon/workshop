Feature: Restaurant Page — full trust-building layout from hero to reviews

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data
    And a valid restaurant id exists as "firstRestaurantId"

  @SC-7 @smoke-test @non-production
  Scenario: Restaurant page renders full layout top-to-bottom
    When the user navigates to "/restaurants/{firstRestaurantId}"
    Then a full-width hero image is visible and loaded with naturalWidth greater than 0
    And the restaurant h1 name is visible
    And a star rating and price range badge are visible
    And the restaurant description is visible
    And at least one menu section heading is visible
    And at least one menu item with a photo, name, description, price, and Add button is visible
    And at least 3 review snippets with author name, star rating, and text are visible
    # Verifies: S-03 — BR-16 full restaurant page layout

  @SC-8 @non-production
  Scenario: Menu section accordion collapses and expands on mobile
    Given the restaurant page at a 390px viewport width
    When the user taps a menu section header
    Then the section aria-expanded attribute is "false"
    And the section items are not visible
    When they tap the menu section header again
    Then the section aria-expanded attribute is "true"
    And the section items are visible
    # Verifies: S-03 — mobile section accordion, BR-16

  @SC-9 @non-production
  Scenario: Add-to-cart button flashes confirmation feedback
    Given an authenticated user on a restaurant page
    When they click an Add button on a menu item
    Then the button text changes to "Added ✓" within 200ms
    And the cart badge count in the header increments by 1
    And the button text reverts to "Add" within 1500ms
    # Verifies: S-03 — add-to-cart micro-animation (Norman feedback)

  @SC-10 @non-production
  Scenario: Auth modal opens when unauthenticated user taps Add
    Given an unauthenticated user on a restaurant page
    When they click an Add button on a menu item
    Then an auth modal appears with heading "Welcome to dishly"
    And both "Sign in" and "Create account" tab buttons are visible
    And no sign-in was requested before the user attempted to add to cart
    # Verifies: S-04 — BR-9 gate triggers at cart, not at browse
    # Cross-references: auth-modal.feature SC-11, SC-12
