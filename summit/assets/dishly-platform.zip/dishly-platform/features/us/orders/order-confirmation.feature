Feature: Order Confirmation — clear "done" moment with delivery expectation setting

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data
    And a confirmed order exists with id "confirmedOrderId"

  @SC-21 @smoke-test @non-production
  Scenario: Order confirmation screen renders with all required elements
    Given the user has successfully placed an order
    When the confirmation screen at "/orders/{confirmedOrderId}" renders
    Then a success icon and "Order confirmed!" heading are visible
    And the order number, restaurant name, delivery address, and estimated ETA are shown
    And the ETA text contains "30–40 minutes"
    And two CTAs are visible: "Back to home" and "View order history"
    # Verifies: S-10 — BR-6 confirmation screen; peak-end rule investment
