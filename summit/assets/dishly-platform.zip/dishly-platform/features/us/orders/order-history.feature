Feature: Order History — reverse-chronological order list with shareable restaurant links

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data

  @SC-22 @non-production
  Scenario: Order history list renders in reverse-chronological order
    Given an authenticated user with at least 2 past orders
    When they navigate to "/account/orders"
    Then at least 2 order rows are visible
    And each row shows restaurant name, order date, and total
    And the most recent order appears first
    # Verifies: S-11 — BR-12 order history page

  @SC-23 @non-production
  Scenario: Order history row expands itemised detail
    Given the order history page with at least 1 order row visible
    When the user clicks an order row header
    Then the itemised detail section for that order becomes visible
    And individual item names, quantities, and prices are listed
    When they click the row header again
    Then the itemised detail section collapses
    # Verifies: S-11 — BR-12 expand/collapse per order

  @SC-24 @non-production
  Scenario: Order history empty state renders for new users
    Given an authenticated user with no past orders
    When they navigate to "/account/orders"
    Then the empty state message "You haven't placed any orders yet." is visible
    And an "Explore restaurants" call-to-action links back to the homepage
    # Verifies: S-11 empty state
