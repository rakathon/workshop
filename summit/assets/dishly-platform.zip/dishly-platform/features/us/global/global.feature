Feature: Global chrome — persistent header and announcement bar across all screens

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data

  @SC-25 @non-production
  Scenario: Announcement bar is present on all primary screens
    When the user navigates to the homepage "/"
    Then the announcement bar is visible at the top of the screen
    And it has the brand purple background
    And it contains at least one word of copy
    When they navigate to a restaurant page
    Then the announcement bar is still visible at the top of the screen
    When they navigate to "/search?q=ramen"
    Then the announcement bar is still visible at the top of the screen
    # Verifies: Global — announcement bar spec (DESIGN.md component)

  @SC-26 @non-production
  Scenario: Cart badge in header updates after add-to-cart
    Given an authenticated user on a restaurant page with cart badge showing 0
    When they add one menu item to the cart
    Then the cart badge updates to show "1"
    And the cart button aria-label reflects "Cart, 1 item"
    When they add a second item
    Then the badge updates to "2"
    # Verifies: Global header — cart visibility (Darius persona: item count at a glance)
