Feature: Homepage — editorial discovery surface that earns trust within 10 seconds

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data

  @SC-1 @smoke-test @non-production
  Scenario: Homepage renders with editorial collections
    When a user navigates to "/"
    Then the page h1 reads "Find food worth eating."
    And at least 3 collection section elements are visible
    And each visible collection contains at least 1 restaurant card
    And each restaurant card image is loaded with naturalWidth greater than 0
    And no sign-in modal or prompt is visible
    # Verifies: S-01 — homepage default state

  @SC-2 @non-production
  Scenario: Category chip toggles filter active state
    Given the user is on the homepage
    When they click the "Ramen" cuisine chip
    Then the chip has aria-pressed equal to "true"
    And the chip has the active visual style with purple fill
    When they click the "Ramen" chip again
    Then the chip has aria-pressed equal to "false"
    And the chip returns to the inactive style
    # Verifies: S-01 — chip active/inactive interaction

  @SC-3 @smoke-test @non-production
  Scenario: Search bar navigates to results page
    Given the user is on the homepage
    When they type "Thai" in the hero search input and press Enter
    Then the URL changes to "/search?q=Thai"
    And the search results page renders
    And the header search bar contains "Thai"
    # Verifies: S-01 → S-02 — search navigation
