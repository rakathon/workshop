Feature: Account Profile Section — personal info, addresses, payment methods

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend API is running at "http://localhost:3001"

  # ── Profile Header ──────────────────────────────────────────────────

  @SC-1 @non-production
  Scenario: Account page shows profile header with name and initials
    Given a signed-in customer with name "Alex Brennan"
    When the customer navigates to /account
    Then the profile card avatar shows initials "AB"
    And the profile heading shows "Alex Brennan"
    And the account email is visible below the name

  @SC-2 @non-production
  Scenario: Account page shows email-prefix fallback when no name set
    Given a signed-in customer with no stored name
    When the customer navigates to /account
    Then the profile heading shows a generic fallback label
    And the avatar shows initials derived from the email prefix

  # ── Personal Info Edit ──────────────────────────────────────────────

  @SC-3 @non-production
  Scenario: Personal info section opens inline edit form on Edit click
    Given a signed-in customer on the account page in read view
    When the customer clicks the "Edit" button in the Personal info section
    Then an inline form appears with Name and Phone fields
    And "Save changes" and "Cancel" buttons are visible
    And the Email row is visible in read-only state below the form

  @SC-4 @non-production
  Scenario: Invalid phone shows field-level error and form stays open
    Given a signed-in customer with the personal info edit form open
    When the customer enters "123abc" in the Phone field and clicks "Save changes"
    Then an inline error message appears below the Phone field
    And the form remains open with the invalid input preserved

  @SC-5 @non-production
  Scenario: Saving valid personal info updates NavBar name without page reload
    Given a signed-in customer with the personal info edit form open
    When the customer changes Name to "Jordan Smith" and clicks "Save changes"
    Then the form closes and the read view shows "Jordan Smith"
    And the NavBar avatar updates to initials "JS"
    And a success toast notification appears

  @SC-6 @non-production
  Scenario: Cancel edit restores read view without saving
    Given a signed-in customer with the personal info edit form open with unsaved changes
    When the customer clicks "Cancel"
    Then the form closes and the read view shows the original values

  # ── Delivery Addresses ──────────────────────────────────────────────

  @SC-7 @non-production
  Scenario: Addresses section shows empty state when no addresses saved
    Given a signed-in customer with no saved addresses
    When the customer views the account page
    Then the Delivery addresses section shows an empty state message
    And an "Add address" button is visible

  @SC-8 @non-production
  Scenario: Add address form appears inline and saving shows new address card
    Given a signed-in customer with no saved addresses on the account page
    When the customer clicks "Add address"
    Then an inline form appears with Label, Street, City, Postcode fields and a default checkbox
    When the customer fills Street, City, Postcode and clicks "Save address"
    Then the form closes and a new address card appears
    And a success toast notification appears

  @SC-9 @non-production
  Scenario: Address card shows Default badge and no Set default button on default card
    Given a signed-in customer with one address marked as default
    When the customer views the Delivery addresses section
    Then the address card displays a "Default" badge
    And the "Set default" action is not present on that card
    And "Edit" and "Delete" actions are present

  @SC-10 @non-production
  Scenario: Delete confirmation appears inline and confirming removes the card
    Given a signed-in customer with at least one saved address
    When the customer clicks "Delete" on an address card
    Then an inline confirmation prompt appears with "Delete" and "Keep it" buttons
    When the customer clicks the "Delete" confirmation button
    Then the address card disappears from the list
    And a success toast notification appears

  @SC-11 @non-production
  Scenario: Add address button is hidden when 2 addresses saved and cap note shown
    Given a signed-in customer with 2 saved addresses
    When the customer views the Delivery addresses section
    Then the "Add address" button is not visible
    And a note indicating the 2-address limit is displayed

  # ── Payment Methods ──────────────────────────────────────────────────

  @SC-12 @non-production
  Scenario: Payment section shows empty state when no payment methods saved
    Given a signed-in customer with no saved payment methods
    When the customer views the account page
    Then the Payment methods section shows an empty state message
    And an "Add payment method" button is visible

  @SC-13 @non-production
  Scenario: Add payment form shows card type selector and saving shows card
    Given a signed-in customer with no saved payment methods
    When the customer clicks "Add payment method"
    Then an inline form appears with a card type selector and Cardholder name field
    When the customer selects "Visa" and enters "Alex Brennan" and clicks "Save card"
    Then the form closes and a Visa payment card appears with "Alex Brennan"
    And a success toast notification appears

  # ── Checkout Pre-fill ───────────────────────────────────────────────

  @SC-14 @non-production
  Scenario: Checkout delivery field pre-filled from saved default address
    Given a signed-in customer with a default address "42 Maple St, Springfield, 12345"
    And a non-empty cart
    When the customer navigates to /checkout
    Then the delivery address field is pre-populated with "42 Maple St, Springfield, 12345"

  @SC-15 @non-production
  Scenario: Checkout shows payment radio options for saved methods plus fallback
    Given a signed-in customer with one saved payment method "Visa" for "Alex Brennan"
    And a non-empty cart
    When the customer navigates to /checkout
    Then a "Visa" radio option is visible
    And "Pay on delivery" radio option is also visible

  # ── Register Name Field ──────────────────────────────────────────────

  @SC-16 @non-production
  Scenario: Register form includes optional Name field
    Given a visitor on the /register page
    When the page loads
    Then an optional Name field is visible on the registration form
    When the visitor submits the form without filling in Name
    Then registration succeeds without a name-related error

  # ── NavBar ──────────────────────────────────────────────────────────

  @SC-17 @non-production
  Scenario: NavBar avatar shows initials after sign-in
    Given a registered customer with name "Sam Rivera"
    When the customer signs in via the login page
    Then the NavBar avatar shows initials "SR"

  @SC-18 @non-production
  Scenario: NavBar dropdown shows full name and email
    Given a signed-in customer with name "Sam Rivera" and email "sam@dishly-test.com"
    When the customer clicks the NavBar avatar button
    Then the dropdown shows "Sam Rivera"
    And the dropdown shows "sam@dishly-test.com"
    And "My account" and "Sign out" items are visible

  # ── Checkout — dummy card entry (BR-6) ──────────────────────────────

  @SC-19 @non-production
  Scenario: "Enter a card" radio reveals card fields at checkout
    Given a signed-in customer on /checkout
    When the customer clicks the "Enter a card" radio option
    Then card number, expiry, and CVV fields are visible
    And the card fields were not visible before clicking the radio

  @SC-20 @non-production
  Scenario: Card number auto-formats as groups of four
    Given a signed-in customer on /checkout with "Enter a card" selected
    When the customer types 16 digits into the card number field
    Then the field displays the number formatted as XXXX XXXX XXXX XXXX

  @SC-21 @non-production
  Scenario: Invalid card number shows inline error on submit
    Given a signed-in customer on /checkout with "Enter a card" selected
    When the customer enters "1234" in the card number field and clicks "Place Order"
    Then an inline error message appears below the card number field
    And no order is created

  # ── Restaurant menu — quantity stepper (BR-7) ──────────────────────

  @SC-22 @non-production
  Scenario: "Add to cart" button replaced by stepper on first add
    Given a signed-in customer on a restaurant page
    When the customer clicks "Add to cart" for a menu item
    Then the button is replaced by a stepper control showing "1"
    When the customer clicks "+" on the stepper
    Then the stepper shows "2"
    When the customer clicks "−" twice
    Then the "Add to cart" button is visible again
