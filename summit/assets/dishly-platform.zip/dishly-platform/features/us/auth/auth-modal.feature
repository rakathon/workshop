Feature: Auth Modal — friction-minimised gate at cart, not at browse

  Background:
    Given the app is running at "http://localhost:3000"
    And the backend is seeded with restaurant data
    And the auth modal is open
    # Modal opens when an unauthenticated user taps Add — see restaurant-page.feature SC-10

  @SC-11 @non-production
  Scenario: Auth modal tabs switch between Sign In and Sign Up panels
    Given the auth modal is open on the "Sign in" tab
    When the user clicks "Create account"
    Then the "Create account" panel becomes visible
    And the "Sign in" panel is hidden
    And aria-selected is "true" on the "Create account" tab button
    # Verifies: S-04 — tab state

  @SC-12 @non-production
  Scenario: Auth modal shows inline error on wrong credentials
    Given the auth modal is open on the "Sign in" tab
    When the user submits email "wrong@example.com" and password "wrongpassword"
    Then an inline error message is visible within the modal
    And the error text references incorrect credentials
    And the modal remains open with no redirect
    # Verifies: S-04 error state
