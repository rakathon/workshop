---
version: alpha
name: Rakuten Rewards
description: >
  Visual identity for Rakuten Rewards consumer-facing surfaces — cashback
  discovery, store browsing, and member account. Derived from rakuten.com
  brand assets and UI patterns observed across the homepage, store pages,
  category navigation, and join flow.

colors:
  # Primary brand
  primary: "#8529CD"
  primary-dark: "#6B1FAD"
  primary-light: "#A855F7"
  on-primary: "#FFFFFF"
  primary-container: "#F3E8FF"
  on-primary-container: "#5B16A1"

  # Cashback / promotional accent
  accent: "#FF0044"
  accent-orange: "#FF6B00"
  on-accent: "#FFFFFF"

  # Success / cashback earned
  success: "#1A7F3C"
  success-bg: "#E6F4EC"
  on-success: "#FFFFFF"

  # Neutrals
  neutral-900: "#1A1A1A"
  neutral-700: "#4A4A4A"
  neutral-500: "#767676"
  neutral-300: "#CCCCCC"
  neutral-100: "#F5F5F5"
  neutral-50: "#FAFAFA"

  # Surface
  surface: "#FFFFFF"
  surface-raised: "#F8F4FC"
  surface-sunken: "#F5F5F5"
  on-surface: "#1A1A1A"
  on-surface-secondary: "#4A4A4A"
  on-surface-muted: "#767676"

  # Borders
  border: "#E0E0E0"
  border-strong: "#CCCCCC"

  # Semantic
  error: "#CC0000"
  error-bg: "#FFF0F0"
  warning: "#E9C46A"
  info: "#0066CC"
  info-bg: "#E8F0FE"

  # Background
  background: "#FFFFFF"
  background-alt: "#F8F4FC"

  # Cashback badge
  cashback-bg: "#FFF0F0"
  cashback-text: "#CC0000"
  cashback-pill-bg: "#CC0000"
  cashback-pill-text: "#FFFFFF"

typography:
  display-lg:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 48px
    fontWeight: "700"
    lineHeight: 1.1
    letterSpacing: -0.02em

  display-md:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 36px
    fontWeight: "700"
    lineHeight: 1.15
    letterSpacing: -0.015em

  h1:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 28px
    fontWeight: "700"
    lineHeight: 1.2
    letterSpacing: -0.01em

  h2:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 22px
    fontWeight: "700"
    lineHeight: 1.25

  h3:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 18px
    fontWeight: "600"
    lineHeight: 1.35

  body-lg:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 16px
    fontWeight: "400"
    lineHeight: 1.6

  body-md:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 14px
    fontWeight: "400"
    lineHeight: 1.55

  body-sm:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 13px
    fontWeight: "400"
    lineHeight: 1.5

  label-lg:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 14px
    fontWeight: "600"
    lineHeight: 1.4

  label-md:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 12px
    fontWeight: "600"
    lineHeight: 1.35
    letterSpacing: 0.02em

  label-caps:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 11px
    fontWeight: "700"
    lineHeight: 1.2
    letterSpacing: 0.06em

  cashback-display:
    fontFamily: "Proxima Nova, proxima-nova, Helvetica Neue, Arial, sans-serif"
    fontSize: 20px
    fontWeight: "800"
    lineHeight: 1.1

rounded:
  xs: 2px
  sm: 4px
  DEFAULT: 6px
  md: 8px
  lg: 12px
  xl: 20px
  full: 9999px

spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  container: 1200px
  container-padding: 24px
  card-gap: 16px
  section-gap: 40px

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.full}"
    height: 44px
    padding: 0 24px

  button-primary-hover:
    backgroundColor: "{colors.primary-dark}"

  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.primary}"
    rounded: "{rounded.full}"
    height: 44px
    padding: 0 24px

  button-cashback:
    backgroundColor: "{colors.accent}"
    textColor: "{colors.on-accent}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.full}"
    height: 44px
    padding: 0 24px

  button-ghost:
    backgroundColor: transparent
    textColor: "{colors.primary}"
    typography: "{typography.label-lg}"
    rounded: "{rounded.full}"
    height: 44px
    padding: 0 16px

  cashback-badge-pill:
    backgroundColor: "{colors.cashback-pill-bg}"
    textColor: "{colors.cashback-pill-text}"
    typography: "{typography.cashback-display}"
    rounded: "{rounded.sm}"
    padding: 4px 10px

  cashback-badge-subtle:
    backgroundColor: "{colors.cashback-bg}"
    textColor: "{colors.cashback-text}"
    typography: "{typography.label-md}"
    rounded: "{rounded.sm}"
    padding: 3px 8px

  store-card:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-surface}"
    rounded: "{rounded.lg}"
    padding: 16px

  store-card-hover:
    backgroundColor: "{colors.surface}"

  category-chip:
    backgroundColor: "{colors.surface-sunken}"
    textColor: "{colors.on-surface-secondary}"
    typography: "{typography.label-md}"
    rounded: "{rounded.full}"
    height: 36px
    padding: 0 16px

  category-chip-active:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"

  announcement-bar:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.body-sm}"

  input-field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-surface}"
    typography: "{typography.body-lg}"
    rounded: "{rounded.full}"
    height: 48px
    padding: 0 20px

  nav-header:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.on-surface}"
    height: 64px

  promo-banner:
    backgroundColor: "{colors.primary-container}"
    textColor: "{colors.on-primary-container}"
    rounded: "{rounded.lg}"
    padding: 20px 24px
---

## Overview

Rakuten Rewards is one of the largest cashback and affiliate marketing platforms
in North America, operating since 1999 (originally as Ebates). The brand serves
two distinct audiences: members who shop to earn cashback, and merchant partners
who pay commissions for driven sales.

The visual identity is anchored in a signature purple — `#8529CD` — that was
adopted after Rakuten's 2019 rebrand from Ebates. It signals trust, premium
quality, and a slight premium feel relative to the red-dominant competitors in the
cashback space. The palette is intentionally restrained: purple is used for brand
moments, navigation, and primary actions; a red-orange accent fires only for
cashback rates and promotional callouts; clean white and light grey fill the
negative space.

**Personality:** Trustworthy, rewarding, accessible. The UI communicates the
value of cashback clearly without visual noise. Every surface returns attention to
the core question — "how much cash back will I earn?"

**Do not:** Use the brand purple decoratively. It should mark interactive
elements, cashback highlights, and brand identity — not fill backgrounds or be
used as decoration.

## Colors

The Rakuten palette has three active layers:

- **Brand purple (`#8529CD`):** The Rakuten signature. Used for the wordmark,
  primary action buttons, active states, links, and key navigation elements.
  Confirmed directly from `rak-logo-brand-v1.svg` fill value.

- **Cashback red (`#CC0000` / `#FF0044`):** The "money color." Applied
  exclusively to cashback rate display, promotional badges, savings callouts,
  and "hot deal" indicators. Never used for navigation or chrome. The contrast
  with the purple brand creates immediate visual hierarchy — when you see red,
  it means money.

- **Neutral foundation:** White `#FFFFFF` surfaces with `#F5F5F5` for sunken
  panels and `#F8F4FC` (a purple-tinted off-white) for brand-adjacent backgrounds.
  Body text is `#1A1A1A` near-black; secondary text `#4A4A4A`; muted metadata
  `#767676`.

- **Success green (`#1A7F3C`):** Used only when cashback has been confirmed or
  a payment has been processed. Signals completion and real-world money.

Color that never appears in the Rakuten UI: blues (except informational states),
warm yellows, teals. The palette is deliberately cool and restrained.

## Typography

Rakuten uses **Proxima Nova** (via Adobe Fonts / proxima-nova) as its primary
typeface. It is a geometric humanist sans-serif — approachable but precise,
suitable for both marketing headlines and dense UI data.

- **Display and headlines:** Proxima Nova 700–800 weight. Tight letter-spacing
  (`-0.01em` to `-0.02em`) at large sizes for editorial authority.
- **Body text:** Proxima Nova 400 at 14–16px, comfortable line-height (1.55–1.6).
  Not compressed — readability is a priority.
- **Cashback display:** The cashback percentage (e.g., "8% Cash Back") is the
  single most important piece of information on any store card. It uses a
  dedicated bold weight (800) and slightly larger size to ensure it reads
  instantly at a glance.
- **Labels and metadata:** 11–12px, 600–700 weight, slight letter-spacing
  (`0.02em`–`0.06em`). All-caps treatment only for category labels and legal
  copy — never for body or UI action text.

Fallback stack: `Helvetica Neue, Arial, sans-serif`. The design never relies on
system serif fonts for any consumer-facing UI surface.

## Layout & Spacing

Rakuten uses a **4px base grid**. All spacing values are multiples of 4.

The homepage and store listing pages follow a responsive grid:
- **Desktop (≥1200px):** Fixed 1200px max-width container, 24px horizontal
  padding. Store cards in a 4-column grid with 16px gaps.
- **Tablet (768–1199px):** 3-column card grid, same 16px gaps.
- **Mobile (<768px):** 2-column card grid (or single column for full-bleed
  feature cards). Navigation collapses to icon-only + hamburger menu.

Key layout patterns:
- **Announcement bar:** Full-width, 40px tall, brand purple background. Pinned
  to the top viewport edge.
- **Primary nav:** White surface, 64px tall. Logo left, search center, account
  and cart right. Category navigation below as a horizontal scrollable row.
- **Section headers:** Section titles (`h2`) are left-aligned with 40px top
  margin. A "See all →" link right-aligned in the same row.
- **Store cards:** 180–200px tall with 16px internal padding. Logo centered in
  top 60% of card, cashback badge in lower section. Hover state: subtle shadow
  lift, no color change.
- **Cashback callout strip:** A purple-tinted `#F8F4FC` band used between
  sections to reinforce the cashback message without a hard section break.

## Elevation & Depth

Rakuten's depth model is minimal and functional — no glassmorphism, no gradients
on chrome. Elevation is used only to establish hierarchy in interactive surfaces.

- **Level 0 (Flat):** Page background `#FFFFFF`. No shadow. Used for content
  panels and navigation.
- **Level 1 (Card):** `box-shadow: 0 2px 8px rgba(0,0,0,0.08)`. Standard
  store cards, informational panels.
- **Level 2 (Card hover / raised panel):**
  `box-shadow: 0 4px 16px rgba(0,0,0,0.12)`. Applied on hover for interactive
  cards; also for modals and drawers.
- **Level 3 (Modal / overlay):**
  `box-shadow: 0 8px 32px rgba(0,0,0,0.18)` with a `rgba(0,0,0,0.5)` backdrop
  overlay.

Shadows use black at low opacity — never colored shadows. The brand never uses
inner shadows or inset depth effects.

## Shapes

Rakuten's shape vocabulary is friendly and rounded — consistent with its
accessible, consumer-facing positioning.

- **Primary actions (buttons, search bars, pills):** `border-radius: 9999px`
  (fully rounded). This includes the main "Shop" CTA buttons, the global search
  input, and cashback pill badges.
- **Cards:** `border-radius: 12px`. Store cards, deal cards, category cards.
- **Small UI elements (chips, tags, inline badges):** `border-radius: 4px`–`8px`.
- **Modals and panels:** `border-radius: 12px`–`20px`.
- **Never:** Sharp (0px) corners on interactive elements. The brand does not use
  a hard geometric or flat design language — all corners are softened.

## Components

### Announcement Bar
Full-width purple (`#8529CD`) strip at the very top of every page. White text,
14px body weight. Used for: referral CTAs ("Refer & Earn $50"), seasonal
promotions, and new member offers ("New members: get a $10 bonus"). Single line
of text with an optional inline link. Never used for warnings or negative
messages.

### Primary Navigation
White background, 64px tall. Three zones:
1. **Left:** Rakuten wordmark SVG in brand purple `#8529CD`.
2. **Center:** Rounded search input, full-width on mobile, max 480px on desktop.
3. **Right:** Account avatar/name + cart icon + cashback balance chip.

Below the main nav: a horizontally scrollable category strip with icon + label
pairs (Travel, Clothing, Beauty, Food, Banking, Home, Tech, Shoes). Active
category uses purple underline or purple pill treatment.

### Store Card
The core UI unit of the discovery surface. Fixed aspect ratio, white surface,
12px radius.

Structure (top to bottom):
1. Merchant logo (centered, max 120×60px, contained within 60% of card height)
2. Cashback rate badge — the most prominent text element:
   - Format: `"8% Cash Back"` in Proxima Nova 800, cashback red `#CC0000`
   - Elevated rate: `"was 2%"` strikethrough in muted grey below
3. Optional deal snippet (1 line, truncated, `#4A4A4A`, 13px)
4. Shop button (ghost or filled, full-radius pill)

Hover: box-shadow lift to Level 2. No color change on the card body.

### Cashback Rate Display
The single most important design element across the platform. Rules:
- Always in Proxima Nova Extra-Bold (800 weight)
- Red (`#CC0000`) for the primary rate number
- Never use purple for cashback rates — the color separation is intentional and
  critical for scent
- "Cash Back" label in the same red at reduced size (14px vs 20px for the number)
- "Up to" prefix in muted grey when rate varies by item

### Primary Button
Fully rounded pill shape (`border-radius: 9999px`). Brand purple `#8529CD`
fill, white text. 44px minimum height. Hover: `#6B1FAD`. Focus: 2px purple
outline with 2px offset. Never use cashback red for primary navigation actions.

### Search Input
Full-radius pill input. White fill with `1.5px #E0E0E0` border. Purple focus
ring. 48px tall. Search icon (magnifying glass) as suffix button in purple.
Placeholder text `#767676`.

### Category Chip / Filter Pill
36px tall, fully rounded, `#F5F5F5` background, `#4A4A4A` text. Active state:
purple fill, white text. Used in the category navigation strip and on filter rows
on search/store pages.

## Do's and Don'ts

**Do:**
- Use `#8529CD` as the single brand color for all primary interactive elements
- Display cashback rates in red (`#CC0000`) at high prominence — it is the
  platform's core value signal
- Keep cards white on white-background pages; use `#F8F4FC` bands between
  sections for rhythm without visual noise
- Use fully-rounded pills for all CTAs; the rounded shape is a brand identifier
- Maintain strong type hierarchy between cashback rate (800 weight, 20px+) and
  supporting metadata (400 weight, 13px)
- Apply success green only after a cashback transaction is confirmed

**Don't:**
- Use cashback red (`#CC0000`) for primary navigation or chrome elements — it
  must be reserved for money-related signals
- Use the brand purple as a decorative fill — apply it only to interactive
  surfaces and brand moments
- Use colored backgrounds inside store cards — logo + white + rate is the
  pattern; decorating cards breaks scannability across a 4-column grid
- Apply text in purple inside body copy — links only, never prose
- Use gradients or glassmorphism effects on any consumer-facing surface — the
  platform's trust signal relies on clean, flat surfaces
- Use any font other than Proxima Nova (or its system fallbacks) for consumer
  product surfaces
