# Implementation Plan: Core Backend APIs + Search Infrastructure

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

```mermaid
gantt
    title  Core Backend APIs — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Schema + Seed
    Full SQLite schema migration        :task1, 1, 2
    100-restaurant seed data            :task2, 2, 3
    Collections config file             :task3, 1, 2

    section Read APIs
    GET /cuisines + /neighbourhoods     :task4, 2, 3
    GET /collections + /:id             :task5, 2, 3
    GET /restaurants (search+filter)    :task6, 2, 3
    GET /restaurants/:id                :task7, 2, 3

    section Wiring
    Mount all routes in index.js        :task8, 3, 4
    APIs observable end-to-end          :milestone, m1, 4, 0
```

---

## Wave 1 — Schema + Collections Config

### TASK-001 `[auto]` `[wave:1]`

Extend `backend/src/db/migrate.js` with `CREATE TABLE IF NOT EXISTS` for all remaining tables: `cuisine`, `neighbourhood`, `restaurant`, `menu_section`, `menu_item`, `review`. All foreign key columns reference their parent tables.

**Satisfies:** TR-1
**Standards:** none
**Required tests:** none (migration task)

**Completed:** no-vcs
---

### TASK-002 `[auto]` `[wave:1]`

Create `data/collections.json` with 6 curated collections (Best Ramen, Hidden Gems, Under $15, New American, Best Pizza, Around the World) each referencing restaurant UUIDs from the seed. Collections are loaded at server startup.

**Satisfies:** TR-3, BR-3
**Standards:** none
**Required tests:** none (config task)

**Completed:** no-vcs
---

## Wave 2 — Seed Data + Route Handlers

### TASK-003 `[auto]` `[wave:2]`

Write `backend/src/db/seed.js` — insert 100 NYC restaurants transactionally covering 10 cuisine types, ≥5 neighbourhoods, even price spread, ratings 3.5–5.0; each restaurant has 3 menu sections, ≥8 items with price_value/price_scale tuples, 3 seeded reviews. Sentinel check: skip if restaurant rows already exist.

**Satisfies:** TR-2, BR-5
**Depends on:** TASK-001
**Standards:** none
**Required tests:** none (seed task)

**Completed:** no-vcs
---

### TASK-004 `[tdd]` `[wave:2]`

Implement `backend/src/routes/cuisines.js` (`GET /cuisines` → alphabetical list) and `backend/src/routes/neighbourhoods.js` (`GET /neighbourhoods` → alphabetical list). Both return `{data: [...], meta}`.

**Satisfies:** BR-4, TR-6
**Depends on:** TASK-001
**Standards:** none
**Required tests:**
- `test('GET /cuisines returns all cuisines alphabetically')` — array sorted, correct shape
- `test('GET /neighbourhoods returns all neighbourhoods alphabetically')` — array sorted, correct shape

**Completed:** no-vcs
---

### TASK-005 `[tdd]` `[wave:2]`

Implement `backend/src/routes/collections.js` — `GET /collections` returns all collections from config with embedded RestaurantSummary objects (skip collections with 0 live restaurants); `GET /collections/:id` returns single collection or 404.

**Satisfies:** BR-3, TR-3, TR-6
**Depends on:** TASK-001, TASK-002
**Standards:** none
**Required tests:**
- `test('GET /collections returns collections with embedded restaurants')` — correct shape
- `test('GET /collections/:id returns single collection')` — 200 with restaurants
- `test('GET /collections/:id returns 404 for unknown id')` — error envelope

**Completed:** no-vcs
---

### TASK-006 `[tdd]` `[wave:2]`

Implement `backend/src/routes/restaurants.js` `GET /restaurants` — keyword search via LIKE on restaurant name and menu item names, filters for cuisine_id/neighbourhood_id/price_range, cursor pagination, returns array of RestaurantSummary.

**Satisfies:** BR-1, TR-4, TR-5, TR-6
**Depends on:** TASK-001
**Standards:** none
**Required tests:**
- `test('GET /restaurants returns all restaurants when no params')` — 100 results
- `test('GET /restaurants?q=ramen filters by name match')` — subset returned
- `test('GET /restaurants?price_range=$$ filters by price')` — only $$ restaurants

**Completed:** no-vcs
---

### TASK-007 `[tdd]` `[wave:2]`

Implement `GET /restaurants/:id` — returns full RestaurantDetail with nested menu sections, items (price as value/scale tuple), and up to 5 reviews. Returns 404 for unknown ID.

**Satisfies:** BR-2, TR-5, TR-6
**Depends on:** TASK-001
**Standards:** none
**Required tests:**
- `test('GET /restaurants/:id returns full detail with menu and reviews')` — nested shape correct
- `test('GET /restaurants/:id returns 404 for unknown id')` — error envelope

**Completed:** no-vcs
---

## Wave 3 — Route Wiring

### TASK-008 `[auto]` `[wave:3]`

Mount all new route files in `backend/src/routes/index.js`: `/cuisines`, `/neighbourhoods`, `/collections`, `/restaurants`.

**Satisfies:** BR-1, BR-2, BR-3, BR-4
**Depends on:** TASK-004, TASK-005, TASK-006, TASK-007
**Standards:** none
**Required tests:** none (wiring task)
