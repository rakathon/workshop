# PRD: Core Backend APIs + Search Infrastructure

*Product / Effort: core-backend-apis*
*Last updated: 2026-06-07*

---

## Problem Statement

The consumer web app and ordering flow require a backend API that serves restaurant data, supports keyword and filtered search, and exposes curated collections — but no such API exists at the start of Wave 1. Without these endpoints, the React frontend has nothing to render and the ordering flow has no items to add to cart. All other Wave 1 epics (consumer-web-discovery, native-ordering-checkout) are blocked until a working, seeded API is in place.

This effort builds the full read-side data layer for dishly Wave 1: a SQLite schema with 100 seeded NYC restaurants, REST endpoints for restaurant search/browse/detail/collections/cuisines/neighbourhoods, and the supporting seed data infrastructure. The API is designed to be discoverable and explorable by the frontend with no authentication required on read operations. Write operations (orders, auth) are out of scope — those belong to `native-ordering-checkout` and `user-auth`.

---

## Goals

1. All discovery endpoints functional and returning correctly shaped data — measured by `GET /restaurants`, `GET /restaurants/:id`, `GET /collections`, `GET /cuisines`, `GET /neighbourhoods` all return 200 with `{data, meta}` envelope and correct shapes
2. 100 seeded restaurants live at launch — measured by 100 restaurants present in the DB, each with ≥3 menu sections, ≥8 menu items with photo URLs, ≥3 seeded reviews, covering ≥5 NYC neighbourhoods and ≥8 cuisine types
3. Keyword search returns relevant results — measured by `GET /restaurants?q=ramen` returns only restaurants whose name or menu item names contain "ramen" (case-insensitive)
4. Filters compose correctly — measured by `?cuisine_id=&price_range=$$` returns only restaurants matching both conditions simultaneously
5. All discovery endpoints are open to anonymous access — measured by 0 endpoints in the read-side API return 401 without an Authorization header

---

## Non-Goals

- We are not building write endpoints for restaurants or menus — no restaurant creation, update, or deletion API in Wave 1
- We are not building a real-time search index — SQL LIKE queries are sufficient for 100 restaurants; no Elasticsearch, Algolia, or search service
- We are not building a CMS for collections — collections are defined in `data/collections.json`; no admin interface
- We are not building user-submitted reviews — reviews are seeded data only; no `POST /reviews` endpoint
- We are not building order or auth endpoints — those are owned by `user-auth` and `native-ordering-checkout`
- We are not building pagination beyond a hard cap — results are capped at 100 for Wave 1; no cursor-based pagination required

---

## Success Metrics

### Leading Indicators (early signal)

- Endpoint availability: all 5 discovery endpoints return 200 on localhost from a fresh clone and seed (target: 100%)
- Search relevance: `GET /restaurants?q=<cuisine>` returns ≥1 relevant result for all 10 seeded cuisine types
- Data completeness: ≥95% of seeded restaurant cover image URLs resolve with `naturalWidth > 0` in the browser

### Lagging Indicators (final outcome)

- Zero API-caused rendering failures on any discovery surface during the 4-week closed beta
- Collections API returns ≥5 non-empty collections — confirmed by integration test or manual QA at beta launch
- Seed script is idempotent: running `./start.sh` twice never corrupts or duplicates data

---

## Open Questions

None identified at this time. Schema, search implementation, price encoding, and API response envelope are all specified in TR-1 through TR-6. Image hosting strategy (Unsplash CDN URLs) is resolved and implemented.

---

## Timeline / Dependencies

- **Target:** Wave 1 closed beta launch
- **Dependencies:**
  - `project-scaffold-local-dev-infra` — SQLite connection, Express router setup, and `start.sh` must exist before schema and seed can be implemented
- **Blocks:**
  - `consumer-web-discovery` — frontend cannot render any discovery surface without these endpoints
  - `native-ordering-checkout` — cart and checkout depend on `GET /restaurants/:id` returning full menu data

---

## Requirements

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.
