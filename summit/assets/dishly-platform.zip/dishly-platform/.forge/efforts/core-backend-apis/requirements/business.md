# Business Requirements: Core Backend APIs + Search Infrastructure

*Product / Effort: core-backend-apis*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Restaurant search and browsing API

**Priority:** P0

The business must provide consumers with the ability to search and filter restaurants by keyword, cuisine type, neighbourhood, and price range — so that consumers can discover relevant options without friction.

**Acceptance Criteria:**
- [ ] Consumers can retrieve a list of restaurant summaries suitable for card display
- [ ] Keyword search matches against restaurant name and menu item names, case-insensitively
- [ ] Results can be filtered by cuisine type, neighbourhood, and price range, individually or in combination
- [ ] A restaurant appears once in results regardless of how many of its menu items matched the keyword
- [ ] Result sets are capped at 100 restaurants for Wave 1

---

## BR-2: Restaurant detail API

**Priority:** P0

The business must provide consumers with access to the full detail of any restaurant — including its menu and reviews — so that consumers can make an informed decision before ordering.

**Acceptance Criteria:**
- [ ] Consumers can retrieve full restaurant detail including name, cuisine, neighbourhood, price range, rating, description, address, and cover image
- [ ] The menu is presented grouped by sections, with each item showing name, description, price, and a photo
- [ ] Up to 5 seeded reviews are included, each showing author name, rating, text, and date
- [ ] Requesting detail for a restaurant that does not exist returns a clear not-found response

---

## BR-3: Curated collections API

**Priority:** P0

The business must expose curated restaurant collections defined by editorial staff — so that the homepage can surface themed groupings that drive discovery and engagement.

**Acceptance Criteria:**
- [ ] All collections are available to the frontend in the order defined by the editorial config
- [ ] Collections with zero matching live restaurants are excluded from the response
- [ ] A single collection and its embedded restaurants can be retrieved by collection identifier
- [ ] Requesting a collection that does not exist returns a clear not-found response

---

## BR-4: Cuisine and neighbourhood lookup APIs

**Priority:** P0

The business must provide consumers with discoverable lists of all available cuisine types and neighbourhoods — so that filter options can be populated accurately and kept in sync with the live catalogue.

**Acceptance Criteria:**
- [ ] The full list of cuisine types available in the catalogue is accessible, returned in alphabetical order
- [ ] The full list of neighbourhoods available in the catalogue is accessible, returned in alphabetical order

---

## BR-5: Seeded restaurant supply

**Priority:** P0

The business must launch Wave 1 with 100 seeded NYC restaurants that represent authentic variety in cuisine, neighbourhood, and price — so that the platform appears credible and well-stocked from day one.

**Acceptance Criteria:**
- [ ] 100 restaurants are present in the catalogue after a fresh environment setup, spanning ≥5 NYC neighbourhoods, ≥8 cuisine types, and a spread of $/$$/$$$ price ranges
- [ ] Every restaurant has ≥3 menu sections, ≥8 menu items each with a photo, and ≥3 reviews
- [ ] All restaurant ratings are ≥3.5 — no low-rated restaurants appear in the curated seed data
- [ ] No ranking weight or paid placement field exists in the catalogue schema

---

## BR-6: No user-submitted reviews

**Priority:** P0

The business must ensure that reviews in Wave 1 are curated seed data only — no consumer-submitted reviews are accepted — to maintain quality and trust during the closed beta.

**Acceptance Criteria:**
- [ ] No review submission capability is available to consumers in Wave 1 — neither via the API nor any UI surface
