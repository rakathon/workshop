# Functional Requirements — Core Backend APIs + Search Infrastructure

*Effort: core-backend-apis*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Return paginated restaurant summaries for browse and search

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api)*

The system must return a list of restaurant summaries in response to a browse or search request, including at minimum the restaurant name, cuisine, neighbourhood, price range, rating, and cover image URL. The list must be hard-capped at 100 results for Wave 1.

---

## FR-2: Filter restaurant results by keyword

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api)*

When a keyword query parameter is provided, the system must return only restaurants whose name or any menu item name contains the keyword, case-insensitively. Each matching restaurant must appear exactly once in the result set regardless of how many menu items matched.

---

## FR-3: Filter restaurant results by cuisine, neighbourhood, and price range

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api)*

The system must support filtering restaurant results by cuisine type, neighbourhood, and price range. Filters must be composable — when multiple filter parameters are provided, only restaurants satisfying all conditions simultaneously must be returned.

---

## FR-4: Return full restaurant detail including menu and reviews

*Traces to: [BR-2](business.md#br-2-restaurant-detail-api)*

When a valid restaurant identifier is provided, the system must return the complete restaurant record: name, cuisine, neighbourhood, price range, average rating, description, address, cover image URL, all menu sections with their items (name, description, price, image URL), and up to 5 seeded reviews (author name, rating, text, date).

---

## FR-5: Return a not-found response for unknown restaurant identifiers

*Traces to: [BR-2](business.md#br-2-restaurant-detail-api)*

When a restaurant detail request is made with an identifier that does not correspond to any existing restaurant, the system must return a structured not-found error response rather than an empty or malformed result.

---

## FR-6: Return all curated collections in editorial order

*Traces to: [BR-3](business.md#br-3-curated-collections-api)*

The system must return all curated collections defined in the editorial config file, in the order they are defined. Each collection must include its embedded restaurant summaries. Collections with zero matching live restaurants must be excluded from the response.

---

## FR-7: Return a single collection by identifier

*Traces to: [BR-3](business.md#br-3-curated-collections-api)*

The system must return a single collection record with its embedded restaurant summaries when a valid collection identifier is provided. When the identifier is unknown, the system must return a structured not-found error response.

---

## FR-8: Return all cuisine types in alphabetical order

*Traces to: [BR-4](business.md#br-4-cuisine-and-neighbourhood-lookup-apis)*

The system must return the complete list of cuisine types present in the restaurant catalogue, sorted alphabetically.

---

## FR-9: Return all neighbourhoods in alphabetical order

*Traces to: [BR-4](business.md#br-4-cuisine-and-neighbourhood-lookup-apis)*

The system must return the complete list of neighbourhoods present in the restaurant catalogue, sorted alphabetically.

---

## FR-10: Seed the database with 100 NYC restaurants on first run

*Traces to: [BR-5](business.md#br-5-seeded-restaurant-supply)*

The system must populate the database with 100 NYC restaurants when the environment is set up from a fresh clone. The seed data must span at least 5 NYC neighbourhoods, at least 8 cuisine types, and a spread of $/$$/$$$ price ranges. Every restaurant must have at least 3 menu sections, at least 8 menu items each with a photo URL, and at least 3 reviews. No seeded restaurant may have a rating below 3.5.

---

## FR-11: Seed script must be idempotent

*Traces to: [BR-5](business.md#br-5-seeded-restaurant-supply)*

The system must detect whether restaurant seed data already exists before inserting. If restaurants are already present, the seed step must be skipped so that running the setup script multiple times produces exactly 100 restaurants — never duplicates. Seed errors must be surfaced explicitly and not silently swallowed.

---

## FR-12: Wrap all API responses in a consistent envelope

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api), [BR-2](business.md#br-2-restaurant-detail-api), [BR-3](business.md#br-3-curated-collections-api), [BR-4](business.md#br-4-cuisine-and-neighbourhood-lookup-apis)*

All successful API responses must use a `{data, meta}` envelope structure. All error responses must use a `{errors, meta}` envelope structure. No endpoint may return a raw array or plain object outside the envelope.

---

## FR-13: All read endpoints accessible without authentication

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api), [BR-2](business.md#br-2-restaurant-detail-api), [BR-3](business.md#br-3-curated-collections-api), [BR-4](business.md#br-4-cuisine-and-neighbourhood-lookup-apis)*

The system must not require an authorization credential to access any read-side discovery endpoint. Requests without an Authorization header must receive normal data responses, not authentication errors.

---

## FR-14: No review submission endpoint exposed

*Traces to: [BR-6](business.md#br-6-no-user-submitted-reviews)*

The system must not expose any endpoint that accepts review creation, update, or deletion requests. Review data is read-only and seeded only.
