# User Stories: Core Backend APIs + Search Infrastructure

*Product / Effort: core-backend-apis*
*Last updated: 2026-06-07*

---

## Anonymous Visitor (discovery consumer)

**US-1:** As an anonymous visitor, I want to browse curated restaurant collections via the API so that the homepage can render editorial content without requiring me to sign in.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/collections` returns all collections in config-file order with embedded restaurant summaries
- [ ] Collections with zero matching restaurants are omitted from the response
- [ ] No `Authorization` header is required

---

**US-2:** As an anonymous visitor, I want to search for restaurants by keyword so that I can find a specific cuisine or restaurant by name.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/restaurants?q=ramen` returns restaurants whose name or menu item names contain "ramen" (case-insensitive)
- [ ] A restaurant appears once in results regardless of how many menu items matched
- [ ] Results are capped at 100

---

**US-3:** As an anonymous visitor, I want to filter restaurants by cuisine type and price range so that I can narrow search results to what I'm looking for.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/restaurants?cuisine_id=<id>` returns only restaurants of that cuisine
- [ ] `GET /dishly/v1/restaurants?price_range=$$` returns only restaurants with that price range
- [ ] Filters are composable: `?cuisine_id=<id>&price_range=$$` applies both simultaneously
- [ ] `GET /dishly/v1/cuisines` returns all cuisine types alphabetically for filter chip population
- [ ] `GET /dishly/v1/neighbourhoods` returns all neighbourhoods alphabetically

---

**US-4:** As an anonymous visitor, I want to view a restaurant's full detail including menu and reviews so that I can evaluate whether to order from it.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/restaurants/:id` returns full restaurant detail: name, cuisine, neighbourhood, price range, average rating, description, address, cover image URL
- [ ] Response includes nested menu: menu sections with items (name, description, price, image URL)
- [ ] Response includes up to 5 seeded reviews: author name, rating, text, date
- [ ] Returns 404 JSON for unknown restaurant IDs

---

## Beta User (seeded data consumer)

**US-5:** As a beta user, I want to browse 100 NYC restaurants with realistic variety so that the platform feels well-stocked and credible from day one.

**Acceptance Criteria:**
- [ ] 100 restaurants exist in the database after `./start.sh` on a fresh clone
- [ ] Restaurants span ≥5 NYC neighbourhoods, ≥8 cuisine types, and a spread of $/$$/$$$ price ranges
- [ ] Each restaurant has ≥3 menu sections, ≥8 menu items with photo URLs, and ≥3 reviews
- [ ] All ratings are ≥3.5 (curation quality signal — no low-rated restaurants)

---

## Internal / Engineering

**US-6:** As an engineer, I want all API responses to use a consistent `{data, meta}` envelope so that the frontend can handle all responses with a single client utility.

**Acceptance Criteria:**
- [ ] All successful responses return `{data: ..., meta: {status: {code}, operation: {request_id}}}`
- [ ] All error responses return `{errors: [{code, message}], meta: ...}`
- [ ] No endpoint returns a raw array or plain object outside the envelope

---

**US-7:** As an engineer, I want the seed script to be idempotent so that running `./start.sh` multiple times never duplicates or corrupts data.

**Acceptance Criteria:**
- [ ] The seed script checks for existing data before inserting — skips if restaurants already exist
- [ ] Running `./start.sh` twice produces exactly 100 restaurants, not 200
- [ ] Seed errors are surfaced clearly — not silently swallowed

---
