# Technical Requirements — Core Backend APIs + Search Infrastructure

*Effort: core-backend-apis*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-05*

---

## TR-1: Full SQLite schema

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api), [BR-2](business.md#br-2-restaurant-detail-api), [BR-5](business.md#br-5-seeded-restaurant-supply)*

All entities from the initiative logical schema implemented in `backend/src/db/migrate.js` using `CREATE TABLE IF NOT EXISTS`.

Tables required:
- `cuisine (id, name)`
- `neighbourhood (id, name)`
- `restaurant (id, name, cuisine_id, neighbourhood_id, description, address, price_range, cover_image_url, average_rating, delivery_radius_km)`
- `menu_section (id, restaurant_id, name, sort_order)`
- `menu_item (id, section_id, name, description, price_value, price_scale, image_url)`
- `review (id, restaurant_id, author_name, rating, body, review_date)`

**Constraints:**
- All foreign keys enforced (`PRAGMA foreign_keys = ON` already set in connection.js)
- `average_rating` on restaurant is a stored float derived from seeded reviews (not computed at query time)
- `price_value` and `price_scale` store the value/scale tuple matching the API Price schema

---

## TR-2: Seed script

*Traces to: [BR-5](business.md#br-5-seeded-restaurant-supply)*

`backend/src/db/seed.js` inserts all seed data transactionally. Sentinel: checks for existence of `restaurant` table rows before seeding (skip if count > 0).

**Seed distribution (100 restaurants):**
- Neighbourhoods: Manhattan, Brooklyn, Queens, Williamsburg, Astoria (≥5)
- Cuisine types: Japanese, Italian, Mexican, Indian, Thai, American, Chinese, Mediterranean, Korean, French (10)
- Price spread: ~33 each of $, $$, $$$
- Ratings: 3.5–5.0; realistic spread
- Each restaurant: 3 menu sections, ≥8 items, 3 reviews

All image URLs use publicly accessible sources (Unsplash CDN format).

---

## TR-3: Collections config

*Traces to: [BR-3](business.md#br-3-curated-collections-api)*

`data/collections.json` — array of collection objects loaded at server startup.

Shape:
```json
[
  {
    "id": "best-ramen",
    "title": "Best Ramen in the City",
    "description": "Hand-picked noodle shops worth the trip",
    "restaurant_ids": ["uuid-1", "uuid-2"]
  }
]
```

Minimum 5 collections covering different cuisine types and themes.

---

## TR-4: Search implementation

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api)*

SQL LIKE query — sufficient for 100-restaurant dataset. No Elasticsearch required for Wave 1.

```sql
SELECT DISTINCT r.* FROM restaurant r
LEFT JOIN menu_item mi ON mi.section_id IN (
  SELECT id FROM menu_section WHERE restaurant_id = r.id
)
WHERE (r.name LIKE ? OR mi.name LIKE ?)
AND (? IS NULL OR r.cuisine_id = ?)
AND (? IS NULL OR r.neighbourhood_id = ?)
AND (? IS NULL OR r.price_range = ?)
```

Neighbourhood name free-text is NOT matched via `?q=` — only `neighbourhood_id` UUID filter.

---

## TR-5: Price encoding

*Traces to: [BR-2](business.md#br-2-restaurant-detail-api)*

All prices returned as `{value: integer, scale: integer}` tuples. `value=1499, scale=2` → $14.99. Stored as `price_value INTEGER, price_scale INTEGER` in `menu_item`.

---

## TR-6: API response envelope

*Traces to: [BR-1](business.md#br-1-restaurant-search-and-browsing-api), [BR-2](business.md#br-2-restaurant-detail-api), [BR-3](business.md#br-3-curated-collections-api), [BR-4](business.md#br-4-cuisine-and-neighbourhood-lookup-apis)*

All responses use `{data: ..., meta: {status: {code}, operation: {request_id}}}`. Errors use `{errors: [{code, message}], meta: ...}`. Matches initiative OpenAPI spec exactly.
