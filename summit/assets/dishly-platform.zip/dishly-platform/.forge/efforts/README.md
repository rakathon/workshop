# Active Efforts

This file is the canonical index of all efforts in this repository. It is maintained
by `forge:effort` and updated by `forge:graduate` and `forge:close`.

| Effort ID | Title | Type | Tier | Risk | Parent | Phase | Status |
|-----------|-------|------|------|------|--------|-------|--------|
