# Implementation Plan: Customer Profile Section

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

```mermaid
gantt
    title  Customer Profile Section — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Auth + Name (BR-1, BR-5)
    DB migration: name + phone columns          :task1, 1, 2
    Register + login return name                :crit, task2, 1, 2
    Auth cluster observable                     :milestone, m1, 2, 0

    section Personal Info Edit (BR-2)
    PATCH /users/me handler                     :task3, 2, 3
    Personal info cluster observable            :milestone, m2, 3, 0

    section Delivery Addresses (BR-3)
    user_address migration + indexes            :task4, 2, 3
    Address CRUD routes                         :task5, 3, 4
    Address cluster observable                  :milestone, m3, 4, 0

    section Payment Methods (BR-4)
    user_payment_method migration               :task6, 2, 3
    Payment method CRUD routes                  :task7, 3, 4
    Payment cluster observable                  :milestone, m4, 4, 0

    section Dummy Card Entry (BR-6)
    Checkout card entry form + validation       :task12, 3, 4
    Dummy card cluster observable               :milestone, m5, 4, 0

    section Cart Quantity Stepper (BR-7)
    useCart decrementItem + Restaurant stepper  :task13, 3, 4
    Stepper cluster observable                  :milestone, m6, 4, 0

    section Tests
    Contract tests                              :task8, 4, 5
    Integration tests                           :task9, 4, 5
    E2E tests                                   :task10, 5, 6
    UI E2E tests                                :task11, 5, 6
```

---

## Wave 1 — Auth + Name Foundation

### TASK-001 [auto][wave:1]

Apply SQLite schema migration: `ALTER TABLE user ADD COLUMN name TEXT` and `ALTER TABLE user ADD COLUMN phone TEXT` in `backend/src/db/migrate.js`.

**Satisfies:** TR-1 — schema migration via additive ALTER TABLE; BR-1, BR-2, BR-5
**Standards:** standards/storage/
**Required tests:** none (migration task — schema change only, no handler logic)

---

### TASK-002 [tdd][wave:1]

Extend `POST /auth/register` to accept optional `name`, persist it to the `user` table, and include `name` and `phone` in the response user object; extend `POST /auth/login` to return `name` and `phone` in the response user object.

**Satisfies:** BR-1 — name collected at registration; BR-5 — authenticated name display; TR-1
**Standards:** standards/api/rest/contracts.md, standards/api/rest/protocol.md, standards/api/rest/security.md
**Required tests:**
- `POST /auth/register` with name persists and returns it in response (SC-1 from e2e-test-suite)
- `POST /auth/register` without name falls back to email-prefix display (SC-2)
- `POST /auth/login` response includes `name` field (SC-3, SC-4 from e2e-test-suite)
- `POST /auth/register 201` response matches AuthResponse schema (SC-1 from contract suite)
- `POST /auth/login 200` response includes `user.name` (SC-4 from contract suite)

---

## Wave 2 — Profile Edit + New Tables

### TASK-003 [tdd][wave:2]

Implement `GET /users/me` to return `id`, `email`, `name`, `phone`, `created_at` and `PATCH /users/me` to accept and persist `name` and/or `phone` with phone validation (digits-only, 7–15 chars). Add to `backend/src/routes/users.js`.

**Satisfies:** BR-2 — personal info editing; TR-3 — requireAuth; TR-4 — client-side state update; TR-5 — phone validation
**Standards:** standards/api/rest/contracts.md, standards/api/rest/protocol.md, standards/api/rest/security.md
**Required tests:**
- `GET /users/me 200` returns full profile shape (SC-6 contract)
- `GET /users/me 401` without token (SC-7 contract, SC-5 integration)
- `PATCH /users/me 200` persists name and phone to DB (SC-8 contract, SC-3 integration)
- `PATCH /users/me 422` rejects invalid phone format (SC-9 contract)
- `PATCH /users/me` with null phone clears phone (SC-4 integration)

---

### TASK-004 [auto][wave:2]

Apply SQLite schema migration: `CREATE TABLE IF NOT EXISTS user_address` and `CREATE INDEX idx_user_address_user_id` in `backend/src/db/migrate.js`.

**Satisfies:** TR-2 — separate table for addresses; BR-3
**Standards:** standards/storage/
**Required tests:** none (migration task)

---

### TASK-005 [auto][wave:2]

Apply SQLite schema migration: `CREATE TABLE IF NOT EXISTS user_payment_method` and `CREATE INDEX idx_user_payment_method_user_id` in `backend/src/db/migrate.js`.

**Satisfies:** TR-2 — separate table for payment methods; BR-4
**Standards:** standards/storage/
**Required tests:** none (migration task)

---

## Wave 3 — Address and Payment CRUD Routes

### TASK-006 [tdd][wave:3]

Implement address CRUD routes in `backend/src/routes/users.js` (or a new `addresses.js` route file): `GET /users/me/addresses`, `POST /users/me/addresses`, `PATCH /users/me/addresses/:id`, `DELETE /users/me/addresses/:id`. Enforce: max 2 per user (server-side COUNT check), ownership filter (`user_id = req.user.id`), default address logic (clear prior default on set-default), requireAuth on all routes.

**Satisfies:** BR-3 — saved delivery addresses; TR-2 — address table; TR-3 — requireAuth; TR-6 — cap enforced server-side
**Standards:** standards/api/rest/contracts.md, standards/api/rest/protocol.md, standards/api/rest/security.md
**Required tests:**
- `POST /users/me/addresses 201` persists row with correct fields (SC-11 contract, SC-7 integration)
- `POST /users/me/addresses` sets is_default=1 and clears prior default (SC-8 integration)
- `POST /users/me/addresses 422` when count ≥ 2 (SC-12 contract, SC-9 integration)
- `PATCH /users/me/addresses/:id 200` updates address (SC-13 contract)
- `PATCH /users/me/addresses/:id 404` for mismatched user (SC-14 contract, SC-11 integration)
- `DELETE /users/me/addresses/:id 204` removes address (SC-15 contract, SC-13 e2e)
- `GET /users/me/addresses 200` returns address list (SC-10 contract)

---

### TASK-007 [tdd][wave:3]

Implement payment method CRUD routes in `backend/src/routes/users.js` (or a new `payment_methods.js` route file): `GET /users/me/payment_methods`, `POST /users/me/payment_methods`, `PATCH /users/me/payment_methods/:id`, `DELETE /users/me/payment_methods/:id`. Enforce: max 2 per user, ownership filter, card_type CHECK passes through SQLite constraint, requireAuth on all routes.

**Satisfies:** BR-4 — mock payment methods; TR-2 — payment method table; TR-3 — requireAuth; TR-6 — cap enforced server-side
**Standards:** standards/api/rest/contracts.md, standards/api/rest/protocol.md, standards/api/rest/security.md
**Required tests:**
- `POST /users/me/payment_methods 201` persists card_type and cardholder_name (SC-17 contract, SC-12 integration)
- `POST /users/me/payment_methods 422` when count ≥ 2 (SC-18 contract, SC-14 integration)
- `PATCH /users/me/payment_methods/:id 200` updates method (SC-19 contract)
- `DELETE /users/me/payment_methods/:id 204` removes method (SC-20 contract, SC-14 e2e)
- `GET /users/me/payment_methods 200` returns payment list (SC-16 contract)
- card_type CHECK constraint rejects invalid values (SC-13 integration)

---

### TASK-008 [auto][wave:3]

Register new address and payment-method routes in `backend/src/routes/index.js` (or `server.js`) so they are mounted under `/dishly/v1`.

**Satisfies:** BR-3, BR-4 — routes must be reachable
**Standards:** none
**Required tests:** none (wiring task — covered by route-level tests in TASK-006/007)

---

## Wave 3 (additions) — Checkout Card Entry + Cart Stepper

### TASK-013 [tdd][wave:3]

Add "Enter a card" option to the Checkout payment section: radio option that reveals card number (16-digit, auto-formats as groups of 4), expiry (MM/YY, auto-inserts `/`), and CVV (3–4 digits) fields. Client-side validation before order submission. Card details are never sent to the backend — cosmetic only. Implemented in `frontend/src/pages/Checkout.jsx` and `frontend/src/index.css`.

**Satisfies:** BR-6 — dummy card entry at checkout
**Standards:** none
**Required tests:**
- "Enter a card" radio option visible on checkout page
- Selecting it reveals card number, expiry, CVV fields
- Submitting with invalid card number (not 16 digits) shows inline error
- Submitting with invalid expiry (not MM/YY) shows inline error
- Valid card entry allows order submission

---

### TASK-014 [tdd][wave:3]

Implement quantity stepper on the restaurant menu page: replace the static "Add to cart" button with a `− qty +` stepper once an item is in the cart. Add `decrementItem(itemId)` to `useCart` hook that decrements quantity and removes the item at 0. Stepper derives quantity from hook state, not local component state. Implemented in `frontend/src/hooks/useCart.js`, `frontend/src/pages/Restaurant.jsx`, and `frontend/src/index.css`.

**Satisfies:** BR-7 — quantity stepper on menu page; TR-7 — cart reactive state
**Standards:** none
**Required tests:**
- "Add to cart" button shown when item not in cart
- After click, stepper replaces button showing quantity 1
- `+` increments quantity; stepper label updates
- `−` decrements; at 0 restores "Add to cart" button
- NavBar cart badge stays in sync with stepper quantity

---

## Wave 4 — Test Suites

### TASK-009 [contract-test][wave:4]

Implement contract test suite from `spec/test/profile-contract-test-suite.md`.

**type:** contract-test
**target:** .forge/efforts/customer-profile-section/spec/test/profile-contract-test-suite.md
**language:** javascript
**depends_on:** TASK-002, TASK-003, TASK-006, TASK-007
**Required tests:**
- SC-1: POST /auth/register — 201 with user and token
- SC-2: POST /auth/register — 409 email conflict
- SC-3: POST /auth/register — 422 validation error
- SC-4: POST /auth/login — 200 with user (including name) and token
- SC-5: POST /auth/login — 401 invalid credentials
- SC-6: GET /users/me — 200 profile shape
- SC-7: GET /users/me — 401 unauthenticated
- SC-8: PATCH /users/me — 200 updated profile
- SC-9: PATCH /users/me — 422 invalid phone
- SC-10: GET /users/me/addresses — 200 address list
- SC-11: POST /users/me/addresses — 201 new address
- SC-12: POST /users/me/addresses — 422 cap exceeded
- SC-13: PATCH /users/me/addresses/:id — 200 updated address
- SC-14: PATCH /users/me/addresses/:id — 404 not found
- SC-15: DELETE /users/me/addresses/:id — 204 deleted
- SC-16: GET /users/me/payment_methods — 200 payment list
- SC-17: POST /users/me/payment_methods — 201 new payment method
- SC-18: POST /users/me/payment_methods — 422 cap exceeded
- SC-19: PATCH /users/me/payment_methods/:id — 200 updated method
- SC-20: DELETE /users/me/payment_methods/:id — 204 deleted

---

### TASK-010 [storage-integration-tests][wave:4]

Implement integration test suite from `spec/test/integration-test-suite.md`.

**type:** storage-integration-tests
**target:** .forge/efforts/customer-profile-section/spec/test/integration-test-suite.md
**language:** javascript
**depends_on:** TASK-001, TASK-002, TASK-003, TASK-004, TASK-005, TASK-006, TASK-007
**Required tests:**
- SC-1: user table ALTER adds name and phone columns
- SC-2: User name and phone persist on register and are returned on login
- SC-3: PATCH /users/me persists name and phone updates
- SC-4: PATCH /users/me with null phone clears stored phone
- SC-5: Auth middleware rejects request with no bearer token
- SC-6: Auth middleware rejects request with expired/invalid token
- SC-7: POST /users/me/addresses persists address row with correct fields
- SC-8: Setting is_default=true on a new address clears prior default
- SC-9: Address count enforced at 2 — third insert rejected
- SC-10: user_address rows cascade-delete when user is deleted
- SC-11: PATCH /users/me/addresses/:id with mismatched user returns 404
- SC-12: POST /users/me/payment-methods persists card_type and cardholder_name
- SC-13: card_type CHECK constraint rejects invalid values
- SC-14: Payment method count enforced at 2 — third insert rejected
- SC-15: user_payment_method rows cascade-delete when user is deleted
- SC-16: Concurrent PATCH /users/me requests produce deterministic last-write result

---

## Wave 5 — E2E and UI Tests

### TASK-011 [e2e-test][wave:5]

Implement system E2E test suite from `spec/test/e2e-test-suite.md`.

**type:** e2e-test
**target:** .forge/efforts/customer-profile-section/spec/test/e2e-test-suite.md
**language:** javascript
**depends_on:** TASK-009, TASK-010
**Required tests:**
- SC-1: New customer registers with name and sees it in NavBar
- SC-2: New customer registers without name and sees email fallback
- SC-3: Existing customer signs in and name appears in NavBar dropdown
- SC-4: Customer updates name; NavBar reflects change without reload
- SC-5: Customer sets phone; invalid format is rejected
- SC-6: Customer adds a delivery address and it becomes default
- SC-7: Customer adds a second address and sets it as default
- SC-8: Adding a third address is rejected with a clear error
- SC-9: Default address pre-fills the delivery field at checkout
- SC-10: Customer can override pre-filled address at checkout
- SC-11: Customer adds a mock payment method and it appears at checkout
- SC-12: Adding a third payment method is rejected
- SC-13: Customer deletes an address; it no longer appears
- SC-14: Customer deletes a payment method; it no longer appears

---

### TASK-012 [e2e-test][wave:5]

Implement UI E2E test suite from `spec/test/ui-e2e-test-suite.md` using Playwright.

**type:** e2e-test
**target:** .forge/efforts/customer-profile-section/spec/test/ui-e2e-test-suite.md
**language:** javascript
**depends_on:** TASK-009, TASK-010
**Required tests:**
- SC-1: Account page shows profile header with name and initials
- SC-2: Account page shows email-prefix fallback when no name set
- SC-3: Personal info section opens inline edit on "Edit" click
- SC-4: Invalid phone shows field-level error; form stays open
- SC-5: Saving valid personal info updates NavBar name without reload
- SC-6: Cancel edit restores read view without saving
- SC-7: Addresses section shows empty state when no addresses saved
- SC-8: Add address form appears inline; saving shows new address card
- SC-9: Address card shows Default badge; "Set default" button absent on default
- SC-10: Delete confirmation appears inline; confirming removes card
- SC-11: Add address button hidden when 2 addresses saved; cap note shown
- SC-12: Payment section shows empty state when no methods saved
- SC-13: Add payment form shows card type selector and name field
- SC-14: Checkout delivery field pre-filled from saved default address
- SC-15: Checkout shows payment radio options for saved methods
- SC-16: Register form includes optional Name field
- SC-17: NavBar avatar shows initials after sign-in
- SC-18: NavBar dropdown shows name and email
