# PRD: Customer Profile Section

*Product / Effort: customer-profile-section*
*Last updated: 2026-06-07*

---

## Problem Statement

Registered dishly customers currently have no way to view or manage their personal information, saved delivery addresses, or payment preferences from a single place. After signing in, the app shows no personalization — the customer's name isn't displayed, nothing is pre-filled at checkout, and there is no profile hub to return to. User feedback from Wave 1 beta has surfaced this gap directly.

Competitors like DoorDash and Uber Eats treat profile completeness as table-stakes — a frictionless repeat-order experience depends on a customer's identity and preferences being remembered. Without this, every checkout feels like a first-time interaction regardless of account history.

---

## Goals

1. Customers can view and edit name, phone, addresses, and payment methods from `/account` — measured by all four data types editable and persisted end-to-end
2. Logged-in customers see their name in the NavBar immediately after sign-in — measured by name rendered in avatar/dropdown on first post-login render, zero page reload required
3. Saved default address pre-fills the delivery field at checkout — measured by delivery address field auto-populated when a default address exists
4. Saved payment methods appear as selectable options at checkout — measured by payment method options rendered at checkout when at least one is saved

---

## Non-Goals

- We are not building password reset — already noted as out of scope for Wave 1 beta; contact support workaround is documented.
- We are not validating addresses against a map API — plain text storage only; no geocoding or address verification.
- We are not processing real payments — mock card storage is cosmetic only; no payment gateway integration.
- We are not supporting multiple users on one account — single-customer profile only; no shared/family accounts.
- We are not sending email or SMS notifications when profile is updated — no comms layer in scope for this effort.

---

## Success Metrics

### Leading Indicators (early signal)

- % of logged-in customers who visit `/account` within first week of release
- % of new registrations that include a name (vs. falling back to email prefix)
- % of checkout sessions where the delivery address field is pre-filled from a saved address

### Lagging Indicators (final outcome)

- Repeat order rate among customers with a complete profile (name + address saved) vs. those without
- Checkout completion rate — expected improvement as pre-fill reduces abandonment friction
- Support tickets related to "can't find my info" or "have to re-enter address" trending toward zero

---

## Open Questions

- Should existing registered users (who have no name stored) be prompted to complete their profile on next login? [owner: product] [due: before implementation starts]
- Does the checkout pre-fill need to handle an override flow when a saved address exists but the customer wants to deliver somewhere else? [owner: eng] [due: planning phase]

---

## Timeline / Dependencies

- **Target:** 2026-06-07 (1 day)
- **Dependencies:** None — self-contained within the existing dishly frontend/backend stack; no external integrations required.

---

## Requirements

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See `user-stories.md` for Connextra-format stories grouped by persona.
