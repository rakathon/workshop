# Functional Requirements — Customer Profile Section

*Effort: customer-profile-section*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Accept optional name at registration

*Traces to: [BR-1](business.md#br-1-name-collected-at-registration)*

The system must accept an optional name field during customer registration and persist it on the customer record. When no name is provided, the system must fall back to the customer's email prefix for display purposes.

---

## FR-2: Return name in authenticated session response

*Traces to: [BR-1](business.md#br-1-name-collected-at-registration)*

The system must include the customer's persisted name in the response returned on successful login and registration, so that the client can display it immediately without a subsequent request.

---

## FR-3: Display customer name in navigation after sign-in

*Traces to: [BR-5](business.md#br-5-authenticated-name-display-after-sign-in)*

The system must render the customer's initials (derived from the persisted name, or the email prefix if no name is set) in the navigation avatar immediately after sign-in or registration — without requiring a page reload. Expanding the avatar must display the customer's full name and email address.

---

## FR-4: Expose account management area for personal info

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

The system must provide an authenticated account area where the customer can view and update their name and phone number. The name field must be required when saving (cannot be cleared to empty once set). The phone field must be optional and validated as digits only, between 7 and 15 characters.

---

## FR-5: Reject invalid phone format before save

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

When a customer submits an invalid phone number format, the system must surface an inline validation error and prevent the save from proceeding until the value is corrected.

---

## FR-6: Reflect updated name in navigation without reload

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

After a customer successfully updates their name on the account page, the system must update the name displayed in the navigation avatar and dropdown without requiring a page reload.

---

## FR-7: Add, edit, and delete delivery addresses

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses)*

The system must allow a logged-in customer to create, update, and delete delivery addresses from their account area. Each address must capture an optional label, street, city, and postcode as plain text.

---

## FR-8: Enforce maximum of two saved addresses

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses)*

The system must prevent a customer from saving more than two delivery addresses. When the limit is reached, any attempt to add a further address must be rejected with a clear message.

---

## FR-9: Pre-fill checkout delivery field with default address

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses)*

When a logged-in customer with a saved default address reaches checkout, the system must pre-populate the delivery destination field with that address. When no default address exists, the field must be left empty. The customer must be able to override the pre-filled value before placing the order.

---

## FR-10: Add, edit, and delete mock payment methods

*Traces to: [BR-4](business.md#br-4-mock-payment-methods)*

The system must allow a logged-in customer to create, update, and delete mock payment methods from their account area. Each method must capture a card type (Visa, Mastercard, or Amex) and a cardholder name.

---

## FR-11: Enforce maximum of two saved payment methods

*Traces to: [BR-4](business.md#br-4-mock-payment-methods)*

The system must prevent a customer from saving more than two payment methods. When the limit is reached, any attempt to add a further payment method must be rejected with a clear message.

---

## FR-12: Display saved payment methods as options at checkout

*Traces to: [BR-4](business.md#br-4-mock-payment-methods)*

The system must render a logged-in customer's saved payment methods as selectable options at checkout, alongside a "Pay on delivery" fallback. No real payment processing must occur when a saved method is selected.

---

## FR-13: Accept dummy card entry at checkout

*Traces to: [BR-6](business.md#br-6-dummy-card-entry-at-checkout)*

The system must offer an option for the customer to enter a card directly at checkout without having previously saved a payment method. The system must accept any plausible card number, expiry, and CVV values. Card details entered at checkout must not be transmitted to or stored by any payment backend.

---

## FR-14: Show card acknowledgement on order confirmation

*Traces to: [BR-6](business.md#br-6-dummy-card-entry-at-checkout)*

When a customer completes checkout using a directly entered card, the order confirmation must acknowledge the card used (e.g. last four digits of the entered number) without performing real payment processing.

---

## FR-15: Inline quantity stepper on menu page

*Traces to: [BR-7](business.md#br-7-quantity-stepper-on-restaurant-menu-page)*

The system must display an add-to-cart affordance for each dish on the restaurant menu page. After the first add, the system must replace the affordance with an inline quantity control allowing the customer to increment or decrement the item quantity. Decrementing to zero must remove the item from the cart and restore the original add affordance.

---

## FR-16: Sync navigation cart count with inline quantity changes

*Traces to: [BR-7](business.md#br-7-quantity-stepper-on-restaurant-menu-page)*

When a customer adjusts item quantity using the inline stepper on the menu page, the system must update the cart item count displayed in the navigation in real time — without requiring a page reload.
