# User Stories: Customer Profile Section

*Product / Effort: customer-profile-section*
*Last updated: 2026-06-07*

---

## Registered Customer — Identity & Sign-in

**US-1:** As a registered customer, I want to provide my name when signing up, so that the app personalizes my experience from the first login.

**Acceptance Criteria:**
- [ ] Name field is present and optional on the Register form
- [ ] Submitted name is stored and returned in the login response
- [ ] NavBar shows my initials in the avatar immediately after registration

---

**US-2:** As a registered customer, I want to see my name in the NavBar after signing in, so that I know I'm logged in as myself.

**Acceptance Criteria:**
- [ ] NavBar avatar displays my initials (or email prefix if no name set) upon sign-in
- [ ] Clicking the avatar opens a dropdown showing my full name and email
- [ ] No page reload required for the name to appear

---

## Registered Customer — Profile Management

**US-3:** As a registered customer, I want to edit my name and phone number from my Account page, so that my profile stays accurate over time.

**Acceptance Criteria:**
- [ ] Account page shows current name and phone with an edit affordance
- [ ] I can update name (required) and phone (optional, digits-only 7–15 chars)
- [ ] Invalid phone format shows an inline error before I can submit
- [ ] After saving, my updated name is reflected in the NavBar without a page reload

---

**US-4:** As a registered customer, I want to save up to 2 delivery addresses on my profile, so that I don't have to retype them at every checkout.

**Acceptance Criteria:**
- [ ] I can add, edit, and delete addresses from the Account page
- [ ] Each address has optional label, street, city, and postcode fields
- [ ] I can mark one address as default
- [ ] I cannot add a third address — the UI disables the add affordance and the server rejects it with a clear error
- [ ] My default address pre-fills the delivery field when I reach checkout

---

**US-5:** As a registered customer, I want to save up to 2 mock payment methods on my profile, so that I can simulate a preferred payment at checkout.

**Acceptance Criteria:**
- [ ] I can add, edit, and delete payment methods from the Account page
- [ ] Each method requires a card type (Visa, Mastercard, Amex) and cardholder name
- [ ] I cannot add a third payment method — the UI disables the add affordance and the server rejects it
- [ ] My saved payment methods appear as selectable options at checkout alongside "Pay on delivery"

---

## Registered Customer — Checkout Experience

**US-6:** As a registered customer, I want my saved default delivery address pre-filled at checkout, so that I can complete an order faster without retyping my address.

**Acceptance Criteria:**
- [ ] Checkout delivery address field is pre-populated with my default saved address
- [ ] I can override the pre-filled address with a different value before placing the order
- [ ] If no default address is saved, the field is empty as before

---

**US-7:** As a registered customer, I want to select a saved payment method at checkout, so that I can simulate a preferred payment experience.

**Acceptance Criteria:**
- [ ] Checkout shows my saved payment methods as selectable radio options
- [ ] "Pay on delivery" is always available as a fallback option
- [ ] Selecting a saved method is cosmetic only — no real payment processing occurs

---
