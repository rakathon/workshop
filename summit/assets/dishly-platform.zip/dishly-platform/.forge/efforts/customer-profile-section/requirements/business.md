# Business Requirements: Customer Profile Section

*Product / Effort: customer-profile-section*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Name collected at registration

**Priority:** P0

The business must ensure that customers can provide their name when creating an account. Providing a name must be optional; if omitted, the displayed identity falls back to the email prefix. The customer's name must be available for personalised display immediately after sign-in.

**Acceptance Criteria:**
- [ ] Registration accepts an optional customer name
- [ ] A customer who provides a name at registration sees that name displayed in the navigation after sign-in — no fallback to email prefix
- [ ] A customer who does not provide a name at registration sees their email prefix displayed in the navigation after sign-in
- [ ] The name persisted at registration is returned as part of the authenticated session

---

## BR-2: Personal info editing

**Priority:** P0

The business must provide customers with a dedicated account management area where they can view and update their name and phone number. This ensures profile data remains accurate over time without requiring customer support intervention.

**Acceptance Criteria:**
- [ ] A logged-in customer can view their current name and phone number in the account area
- [ ] A customer can update their name; the name field is required when saving (cannot be cleared to empty once set)
- [ ] A customer can update their phone number; the phone field is optional and accepts only digit characters between 7 and 15 characters long
- [ ] An invalid phone format is flagged before the save is accepted
- [ ] An updated name is reflected in the navigation display without requiring the customer to reload or re-navigate

---

## BR-3: Saved delivery addresses

**Priority:** P0

The business must allow each customer to save up to two delivery addresses on their profile — including the ability to add, edit, remove, and designate a default address. The default address must pre-fill the delivery destination at checkout to reduce re-entry friction.

**Acceptance Criteria:**
- [ ] A customer can add, edit, and delete delivery addresses from their account area
- [ ] Each address captures an optional label, street, city, and postcode as plain text (no address verification required)
- [ ] A customer cannot save more than two addresses; attempting to add a third results in a clear rejection
- [ ] A customer can designate one address as their default
- [ ] The default address is pre-populated as the delivery destination when the customer reaches checkout

---

## BR-4: Mock payment methods

**Priority:** P1

Customers can save up to two mock payment methods on their profile for local/demo use. No real card numbers or payment processing — card type and cardholder name only.

**Acceptance Criteria:**
- [ ] A customer can add, edit, and delete mock payment methods from their account area
- [ ] Each payment method requires a card type (Visa, Mastercard, or Amex) and a cardholder name
- [ ] A customer cannot save more than two payment methods; attempting to add a third results in a clear rejection
- [ ] Saved payment methods appear as selectable options at checkout alongside a "Pay on delivery" fallback — no real payment processing occurs

---

## BR-6: Dummy card entry at checkout

**Priority:** P0

The business must allow customers to enter a dummy card at checkout without first saving a payment method in their profile. The card is accepted for any plausible input and displayed for confirmation — no real charge is made.

**Acceptance Criteria:**
- [ ] A customer can choose to enter a card directly at checkout in addition to selecting a saved method or paying on delivery
- [ ] Entering a card requires a card number, expiry, and CVV; any plausible values are accepted
- [ ] The order confirmation acknowledges the card used (e.g. last four digits) without processing a real payment
- [ ] Card details entered at checkout are never transmitted to or stored by the payment backend

---

## BR-7: Quantity stepper on restaurant menu page

**Priority:** P0

The business must allow customers to add multiple units of the same dish directly from the restaurant menu page and see the current cart quantity reflected inline — without navigating away from the menu. The first selection adds the item; subsequent interactions adjust the quantity up or down.

**Acceptance Criteria:**
- [ ] A customer can add an item to their cart directly from the menu page
- [ ] After an item is added, the customer can increase or decrease the item quantity inline on the menu page
- [ ] Reducing quantity to zero removes the item from the cart and restores the original add affordance
- [ ] The cart item count visible in the navigation stays in sync with inline quantity changes without a page reload
- [ ] Behaviour is consistent whether the customer adds one or many units of the same dish

---

## BR-5: Authenticated name display after sign-in

**Priority:** P0

After signing in, the customer's name must be visible in the navigation to confirm their logged-in state. The avatar shows initials derived from the name; expanding it shows the full name and email.

**Acceptance Criteria:**
- [ ] A customer who has set a name sees initials derived from that name in the navigation avatar immediately after sign-in — no page reload required
- [ ] Expanding the avatar reveals the customer's full name and email address
- [ ] Name and email are visible without a page reload immediately after sign-in or registration
