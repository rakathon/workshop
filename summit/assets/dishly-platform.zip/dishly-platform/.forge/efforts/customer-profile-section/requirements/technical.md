# Technical Requirements — Customer Profile Section

*Effort: customer-profile-section*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-06*

---

## TR-1: Schema migration via additive ALTER TABLE

*Traces to: [BR-1](business.md#br-1-name-collected-at-registration), [BR-2](business.md#br-2-personal-info-editing), [BR-5](business.md#br-5-authenticated-name-display-after-sign-in)*

The `user` table must be extended with `name TEXT` and `phone TEXT` columns via `ALTER TABLE` statements appended to the existing `migrate.js` file. Both columns are nullable to preserve compatibility with existing seed data and registered users. No data migration required — existing rows default to NULL.

## TR-2: Separate tables for addresses and payment methods

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses), [BR-4](business.md#br-4-mock-payment-methods)*

Saved addresses and mock payment methods must each live in their own table (`user_address`, `user_payment_method`) rather than as JSON blobs on the `user` row. This keeps queries simple and makes the per-user caps (2 addresses, 2 payment methods) enforceable with a COUNT check server-side.

## TR-3: All profile endpoints require authentication

*Traces to: [BR-2](business.md#br-2-personal-info-editing), [BR-3](business.md#br-3-saved-delivery-addresses), [BR-4](business.md#br-4-mock-payment-methods)*

`PATCH /users/me`, `POST|PATCH|DELETE /users/me/addresses/:id`, and `POST|PATCH|DELETE /users/me/payment_methods/:id` must all use the existing `requireAuth` middleware. Unauthenticated requests receive `401 UNAUTHORIZED`.

## TR-4: Client-side state update without page reload

*Traces to: [BR-2](business.md#br-2-personal-info-editing), [BR-5](business.md#br-5-authenticated-name-display-after-sign-in)*

After a successful `PATCH /users/me`, the frontend must update `dishly_user_name` in `localStorage` and re-render the NavBar avatar and dropdown without a full page navigation. The NavBar reads from `localStorage` on render; a forced re-render (e.g. via a shared auth context or a custom event) is acceptable for Wave 1.

## TR-5: Phone validation bounds

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

Phone numbers are validated client-side and server-side as digits-only (stripping spaces/dashes before storage), minimum 7 digits, maximum 15 digits. No E.164 formatting or country-code enforcement. Empty string is treated as "no phone set" (stored as NULL).

## TR-7: Cart stepper uses reactive client-side state

*Traces to: [BR-7](business.md#br-7-quantity-stepper-on-restaurant-menu-page)*

The quantity stepper on the restaurant menu page must derive its displayed value directly from the `useCart` hook's in-memory cart state — not from a separate local component state. `useCart` must expose a `decrementItem(itemId)` function that mirrors the existing `addItem` semantics: updates the in-memory state, persists to `localStorage`, and broadcasts the `dishly:cart-updated` event so all consumers (NavBar badge, Cart page) stay in sync. The stepper renders conditionally: quantity 0 → "Add to cart" button; quantity ≥ 1 → stepper control.

## TR-6: Address and payment method cap enforced server-side

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses), [BR-4](business.md#br-4-mock-payment-methods)*

Before inserting a new address or payment method, the backend must COUNT existing rows for the user. If the count is already at the maximum (2), respond with `422 UNPROCESSABLE_ENTITY` and a clear message. The frontend also enforces the cap to disable the "Add" affordance, but server-side is the authoritative check.
