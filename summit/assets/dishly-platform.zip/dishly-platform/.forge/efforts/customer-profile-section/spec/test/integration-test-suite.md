# Integration Test Suite — Customer Profile Section

*Capability/Effort:* `.forge/efforts/customer-profile-section/spec/test/`
*Authored:* 2026-06-06
*Effort:* customer-profile-section

## Why Test This

The profile capability introduces schema migrations and new tables (`user_address`, `user_payment_method`) on top of the existing SQLite `user` table. Integration tests verify that the service layer correctly persists data against the real database schema, enforces constraints (cap limits, NOT NULL, CHECK on card_type), and that auth middleware rejects unauthenticated requests before handlers are reached. These behaviors cannot be reliably verified by contract tests (which test shape) or E2E tests (which test journeys) — they require the real DB layer running with the actual migration applied.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: user table ALTER adds name and phone columns | [TR-1](../../requirements/technical.md#tr-1-schema-migration-via-additive-alter-table): schema migration |
| SC-2: user name and phone persist on register and are returned on login | [BR-1](../../requirements/business.md#br-1-name-collected-at-registration), [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) |
| SC-3: PATCH /users/me persists name and phone updates | [BR-2](../../requirements/business.md#br-2-personal-info-editing) |
| SC-4: PATCH /users/me with null phone clears stored phone | [BR-2](../../requirements/business.md#br-2-personal-info-editing) |
| SC-5: Auth middleware rejects request with no bearer token | [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication) |
| SC-6: Auth middleware rejects request with expired/invalid token | [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication) |
| SC-7: POST /users/me/addresses persists address with correct fields | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) |
| SC-8: Setting is_default=true clears prior default on same user | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) |
| SC-9: Address count enforced at 2 — third insert returns 422 | [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side), [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) |
| SC-10: user_address rows cascade-delete when user is deleted | [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) |
| SC-11: PATCH /users/me/addresses/:id with wrong user_id returns 404 | [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication) |
| SC-12: POST /users/me/payment-methods persists card_type and cardholder_name | [BR-4](../../requirements/business.md#br-4-mock-payment-methods) |
| SC-13: card_type CHECK constraint rejects invalid values | [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) |
| SC-14: Payment method count enforced at 2 — third insert returns 422 | [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side), [BR-4](../../requirements/business.md#br-4-mock-payment-methods) |
| SC-15: user_payment_method rows cascade-delete when user is deleted | [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) |
| SC-16: Concurrent PATCH /users/me requests produce deterministic last-write result | [TR-4](../../requirements/technical.md#tr-4-client-side-state-update-without-page-reload) |

## Scenarios

### SC-1: user table ALTER adds name and phone columns

**Type:** integration
**Given** a fresh SQLite database with the migrate script applied
**When** the schema is inspected
**Then** the `user` table has a `name TEXT` column (nullable)
**And** the `user` table has a `phone TEXT` column (nullable)
**And** existing rows (if any) have `name = NULL` and `phone = NULL`
**Verifies:** [TR-1](../../requirements/technical.md#tr-1-schema-migration-via-additive-alter-table) — "Schema migration via additive ALTER TABLE; both columns nullable"

---

### SC-2: User name and phone persist on register and are returned on login

**Type:** integration
**Given** a real SQLite database with migrations applied
**When** POST /auth/register is called with `{ email, password, name: "Alex Brennan" }`
**Then** a row is inserted in the `user` table with `name = "Alex Brennan"` and `phone = NULL`
**When** POST /auth/login is called with the same email and password
**Then** the response `data.user.name` equals "Alex Brennan"
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "Backend persists name; login response includes name"; [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "Login response includes name"

---

### SC-3: PATCH /users/me persists name and phone updates to the database

**Type:** integration
**Given** a signed-in user with no name or phone stored
**When** PATCH /users/me is called with `{ "name": "Jordan Smith", "phone": "4155551234" }`
**Then** the `user` row in the database has `name = "Jordan Smith"` and `phone = "4155551234"`
**And** a subsequent GET /users/me returns the updated values
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "PATCH /users/me endpoint accepts name and/or phone and persists changes"

---

### SC-4: PATCH /users/me with null phone clears stored phone

**Type:** integration
**Given** a signed-in user with `phone = "4155551234"` stored
**When** PATCH /users/me is called with `{ "phone": null }`
**Then** the `user` row has `phone = NULL`
**And** a subsequent GET /users/me returns `phone = null`
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "Empty string treated as no phone set (stored as NULL)"

---

### SC-5: Auth middleware rejects request with no bearer token

**Type:** integration
**Given** no Authorization header is provided
**When** GET /users/me is called
**Then** the `requireAuth` middleware intercepts the request before the handler
**And** the response status is 401 with error code UNAUTHORIZED
**And** no database query is executed
**Verifies:** [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication) — "All profile endpoints require authentication"

---

### SC-6: Auth middleware rejects request with invalid or expired token

**Type:** integration
**Given** an Authorization header with an invalid JWT string
**When** GET /users/me is called
**Then** the `requireAuth` middleware rejects the request
**And** the response status is 401 with error code UNAUTHORIZED
**Verifies:** [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication) — "Unauthenticated requests receive 401 UNAUTHORIZED"

---

### SC-7: POST /users/me/addresses persists address row with correct fields

**Type:** integration
**Given** a signed-in user with no saved addresses
**When** POST /users/me/addresses is called with `{ street: "42 Maple St", city: "Springfield", postcode: "12345", is_default: true, label: "Home" }`
**Then** a row is inserted in `user_address` with all fields correctly stored
**And** `is_default = 1` in the database
**And** the `user_id` foreign key matches the authenticated user's id
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "POST /users/me/addresses creates a new address"; [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) — "Separate table for addresses"

---

### SC-8: Setting is_default=true on a new address clears prior default

**Type:** integration
**Given** a signed-in user with one address where `is_default = 1`
**When** POST /users/me/addresses is called with a second address and `is_default: true`
**Then** the new address row has `is_default = 1`
**And** the first address row now has `is_default = 0`
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Only one address can be default at a time; clearing old default is a two-step UPDATE"

---

### SC-9: Address count enforced at 2 — third insert rejected at the service layer

**Type:** integration
**Given** a signed-in user who already has 2 saved addresses
**When** POST /users/me/addresses is called
**Then** the service performs a COUNT query that returns 2
**And** the response is 422 with an error indicating the limit is reached
**And** no new row is inserted in `user_address`
**Verifies:** [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side) — "Cap enforced server-side before insert"; [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Adding a third address is blocked"

---

### SC-10: user_address rows are cascade-deleted when the user is deleted

**Type:** integration
**Given** a user with 2 saved addresses in `user_address`
**When** the user row is deleted from the `user` table
**Then** both `user_address` rows are also deleted (ON DELETE CASCADE)
**And** no orphaned address rows remain
**Verifies:** [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) — "user_address references user(id) ON DELETE CASCADE"

---

### SC-11: PATCH /users/me/addresses/:id with mismatched user returns 404

**Type:** integration
**Given** user-A has address addr-1 and user-B is signed in
**When** user-B calls PATCH /users/me/addresses/addr-1
**Then** the query includes `WHERE id = addr-1 AND user_id = user-B-id`
**And** no row is found and the response is 404
**And** addr-1 is unchanged in the database
**Verifies:** [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication) — "Endpoints enforce ownership via user_id filter"

---

### SC-12: POST /users/me/payment-methods persists card_type and cardholder_name

**Type:** integration
**Given** a signed-in user with no saved payment methods
**When** POST /users/me/payment-methods is called with `{ card_type: "Visa", cardholder_name: "Alex Brennan" }`
**Then** a row is inserted in `user_payment_method` with `card_type = "Visa"` and `cardholder_name = "Alex Brennan"`
**And** the `user_id` foreign key matches the authenticated user's id
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "POST /users/me/payment-methods creates a new payment method"; [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) — "Separate table for payment methods"

---

### SC-13: card_type CHECK constraint rejects invalid values at the database layer

**Type:** integration
**Given** a direct insert attempt into `user_payment_method` with `card_type = "Discover"`
**When** the INSERT is executed against the real SQLite database
**Then** the database raises a CHECK constraint violation
**And** no row is inserted
**Verifies:** [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) — "card_type CHECK(card_type IN ('Visa', 'Mastercard', 'Amex'))"

---

### SC-14: Payment method count enforced at 2 — third insert rejected

**Type:** integration
**Given** a signed-in user who already has 2 saved payment methods
**When** POST /users/me/payment-methods is called
**Then** the service performs a COUNT that returns 2
**And** the response is 422 with an error indicating the limit
**And** no new row is inserted in `user_payment_method`
**Verifies:** [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side) — "Cap enforced server-side"; [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Adding a third payment method is blocked"

---

### SC-15: user_payment_method rows are cascade-deleted when user is deleted

**Type:** integration
**Given** a user with 2 saved payment methods in `user_payment_method`
**When** the user row is deleted from the `user` table
**Then** both `user_payment_method` rows are deleted (ON DELETE CASCADE)
**And** no orphaned payment method rows remain
**Verifies:** [TR-2](../../requirements/technical.md#tr-2-separate-tables-for-addresses-and-payment-methods) — "user_payment_method references user(id) ON DELETE CASCADE"

---

### SC-16: Concurrent PATCH /users/me requests produce deterministic last-write result

**Type:** integration
**Given** a signed-in user whose profile is being updated by two simultaneous PATCH requests
**When** both requests reach the handler at nearly the same time
**Then** SQLite's serialized write model ensures exactly one write wins
**And** the final database row reflects one of the two writes completely (no partial or mixed state)
**And** both responses return 200 (no 500 errors)
**Verifies:** [TR-4](../../requirements/technical.md#tr-4-client-side-state-update-without-page-reload) — "Client-side state update; SQLite serialized writes prevent partial corruption"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
