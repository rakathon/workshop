# Query Patterns

*Effort: customer-profile-section*  *Authored: 2026-06-06*

---

| Pattern | Entity | Filters | Sort | Source | Notes |
|---------|--------|---------|------|--------|-------|
| Look up user by ID (profile fetch) | USER | `id = ?` | — | BR-2, `GET /users/me` | PK lookup |
| Update user name/phone | USER | `id = ?` | — | BR-2, `PATCH /users/me` | PK lookup |
| Look up user by email (login) | USER | `email = ?` | — | existing `POST /auth/login` | Existing UNIQUE index |
| List addresses for user | USER_ADDRESS | `user_id = ?` | `created_at ASC` | BR-3, Account page | Needs idx on user_id |
| Fetch single address by ID | USER_ADDRESS | `id = ? AND user_id = ?` | — | BR-3, `PATCH /addresses/:id` | PK + user_id filter |
| Count addresses for user (cap check) | USER_ADDRESS | `user_id = ?` | — | TR-6, BR-3 | Served by user_id index |
| Get default address for user | USER_ADDRESS | `user_id = ? AND is_default = 1` | — | BR-3, checkout pre-fill | Served by user_id index |
| Clear default, set new default | USER_ADDRESS | `user_id = ?` then `id = ?` | — | BR-3 | Two-step UPDATE |
| Delete address by ID | USER_ADDRESS | `id = ? AND user_id = ?` | — | BR-3 | PK + user_id filter |
| List payment methods for user | USER_PAYMENT_METHOD | `user_id = ?` | `created_at ASC` | BR-4, Account page | Needs idx on user_id |
| Fetch single payment method by ID | USER_PAYMENT_METHOD | `id = ? AND user_id = ?` | — | BR-4, `PATCH /payment-methods/:id` | PK + user_id filter |
| Count payment methods for user (cap check) | USER_PAYMENT_METHOD | `user_id = ?` | — | TR-6, BR-4 | Served by user_id index |
| Delete payment method by ID | USER_PAYMENT_METHOD | `id = ? AND user_id = ?` | — | BR-4 | PK + user_id filter |
