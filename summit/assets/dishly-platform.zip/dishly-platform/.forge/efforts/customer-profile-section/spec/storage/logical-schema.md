# Logical Schema

*Effort: customer-profile-section*  *Authored: 2026-06-06*

---

## Entity-Relationship Diagram

```mermaid
erDiagram
    USER ||--o{ USER_ADDRESS : "saves"
    USER ||--o{ USER_PAYMENT_METHOD : "saves"
    USER ||--o{ ORDER : "places"
    USER_ADDRESS ||--o{ ORDER : "pre-fills"
```

## Entities

| Entity | Description |
|--------|-------------|
| USER | Registered customer — extended with `name` and `phone` fields |
| USER_ADDRESS | A saved delivery address belonging to a user (max 2 per user); one may be marked as default to pre-fill checkout |
| USER_PAYMENT_METHOD | A mock saved payment method belonging to a user (max 2 per user); card type and cardholder name only |
| ORDER | Existing entity — a purchase placed by a user; delivery address pre-filled from USER_ADDRESS at checkout (runtime logic, no schema change) |
