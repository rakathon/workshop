-- Physical Schema — SQLite
-- Effort: customer-profile-section  Authored: 2026-06-06

-- ============================================================
-- Extend USER table
-- Supports: "Look up user by ID", "Update user name/phone", "Look up user by email"
-- ============================================================

-- PII: name and phone are personal data. Retain while account is active.
-- Delete or anonymise on account closure.
ALTER TABLE user ADD COLUMN name TEXT;
ALTER TABLE user ADD COLUMN phone TEXT;

-- ============================================================
-- USER_ADDRESS
-- Supports: list by user, fetch by id+user, count for cap, get default,
--           set/clear default, delete by id+user
-- ============================================================

-- PII: street, city, postcode are delivery address data.
CREATE TABLE IF NOT EXISTS user_address (
  id         TEXT PRIMARY KEY,
  user_id    TEXT    NOT NULL REFERENCES user(id) ON DELETE CASCADE,
  label      TEXT,                          -- optional, e.g. "Home"
  street     TEXT    NOT NULL,
  city       TEXT    NOT NULL,
  postcode   TEXT    NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,    -- 1 = default; at most one per user
  created_at TEXT    NOT NULL
);

-- Supports: list, count, get-default, set/clear default (all filter on user_id)
CREATE INDEX IF NOT EXISTS idx_user_address_user_id ON user_address(user_id);

-- ============================================================
-- USER_PAYMENT_METHOD
-- Supports: list by user, fetch by id+user, count for cap, delete by id+user
-- ============================================================

-- PII: cardholder_name is personal data.
CREATE TABLE IF NOT EXISTS user_payment_method (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL REFERENCES user(id) ON DELETE CASCADE,
  card_type       TEXT NOT NULL CHECK(card_type IN ('Visa', 'Mastercard', 'Amex')),
  cardholder_name TEXT NOT NULL,
  created_at      TEXT NOT NULL
);

-- Supports: list, count (all filter on user_id)
CREATE INDEX IF NOT EXISTS idx_user_payment_method_user_id ON user_payment_method(user_id);
