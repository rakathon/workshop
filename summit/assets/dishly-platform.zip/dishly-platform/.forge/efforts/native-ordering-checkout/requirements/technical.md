# Technical Requirements — Native Ordering + Checkout

*Effort: native-ordering-checkout*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-06*

---

## TR-1: Order and OrderItem schema

*Traces to: [BR-1](business.md#br-1-single-restaurant-linear-checkout), [BR-6](business.md#br-6-order-confirmation-screen-with-simulated-eta)*

The `order` and `order_item` tables are created idempotently in `backend/src/db/migrate.js`.

| Table | Column | Type | Notes |
|-------|--------|------|-------|
| order | id | TEXT PK | UUID v4 |
| order | user_id | TEXT FK | → user.id |
| order | restaurant_id | TEXT FK | → restaurant.id |
| order | delivery_address | TEXT | Entered at checkout |
| order | subtotal_value | INTEGER | Integer cents |
| order | subtotal_scale | INTEGER | Always 2 |
| order | delivery_fee_value | INTEGER | Always 399 |
| order | delivery_fee_scale | INTEGER | Always 2 |
| order | total_value | INTEGER | subtotal + delivery_fee |
| order | total_scale | INTEGER | Always 2 |
| order | status | TEXT | 'confirmed' / 'delivering' / 'delivered' |
| order | created_at | TEXT | ISO datetime |
| order | deleted_at | TEXT | Soft delete; null = active |
| order_item | id | TEXT PK | UUID v4 |
| order_item | order_id | TEXT FK | → order.id ON DELETE CASCADE |
| order_item | menu_item_id | TEXT FK | → menu_item.id |
| order_item | item_name | TEXT | Snapshot of name at order time |
| order_item | quantity | INTEGER | ≥ 1 |
| order_item | unit_price_value | INTEGER | Snapshot of price at order time |
| order_item | unit_price_scale | INTEGER | Always 2 |

**Constraints:**
- `"order"` is a reserved SQL word — always quoted in queries
- `item_name` and `unit_price_value` are snapshots — never updated after creation; changes to `menu_item` do not affect historic orders
- Migration is idempotent (`CREATE TABLE IF NOT EXISTS`)

---

## TR-2: POST /orders endpoint

*Traces to: [BR-1](business.md#br-1-single-restaurant-linear-checkout), [BR-5](business.md#br-5-test-mode-payment-in-wave-1)*

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/dishly/v1/orders` | bearer | Create order, call Stripe test-mode, return 201 |

**Request body:**
```json
{
  "restaurant_id": "uuid",
  "items": [{ "menu_item_id": "uuid", "quantity": 1 }],
  "delivery_address": "42 Main St, New York, NY",
  "payment_method_id": "pm_card_visa"
}
```

**Constraints:**
- All items must belong to the same `restaurant_id` — returns 422 if any item's `menu_section.restaurant_id` differs
- `payment_method_id` is passed to `stripe.paymentIntents.create()` in test mode before inserting the order
- Order and order_item rows are inserted in a single SQLite transaction — no partial writes
- Returns 201 `{data: Order, meta}` on success; `Location: /dishly/v1/orders/:id` header set
- Returns 401 if no bearer token; returns 422 for validation errors; returns 400 for missing fields

---

## TR-3: GET /orders/:id endpoint

*Traces to: [BR-6](business.md#br-6-order-confirmation-screen-with-simulated-eta), [BR-7](business.md#br-7-order-history-for-authenticated-users)*

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/dishly/v1/orders/:id` | bearer | Return order with nested order_items |

**Constraints:**
- Returns 404 JSON if order does not exist or is soft-deleted
- Returns 403 JSON if `order.user_id !== req.user.id`
- Response includes nested `items` array with `item_name`, `quantity`, `unit_price {value, scale}`
- Response includes `subtotal`, `delivery_fee`, `total` as `{value, scale}` tuples

---

## TR-4: GET /users/me/orders endpoint

*Traces to: [BR-7](business.md#br-7-order-history-for-authenticated-users)*

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/dishly/v1/users/me/orders` | bearer | Return all orders for authenticated user, newest first |

**Constraints:**
- Returns 401 if no bearer token
- Orders sorted by `created_at DESC`
- Each order includes: `id`, `restaurant_name` (joined from restaurant table), `items` array, `subtotal`, `delivery_fee`, `total`, `status`, `created_at`
- Soft-deleted orders (`deleted_at IS NOT NULL`) excluded
- Response envelope: `{data: [...], pagination: {next: null}, meta}`

---

## TR-5: Cart state in localStorage

*Traces to: [BR-1](business.md#br-1-single-restaurant-linear-checkout), [BR-2](business.md#br-2-cart-persistence-across-navigation), [BR-3](business.md#br-3-cart-conflict-resolution)*

Cart state is managed entirely in the browser via `localStorage`. No backend cart storage. The `useCart` React hook provides the cart interface to all components.

**Cart schema (localStorage key: `dishly_cart`):**
```json
{
  "restaurantId": "uuid | null",
  "restaurantName": "string",
  "items": [
    { "id": "menu_item_id", "name": "string", "price": {"value": 1600, "scale": 2}, "quantity": 1 }
  ]
}
```

**Constraints:**
- `useCart` emits a custom `dishly:cart-updated` window event after every state change so all mounted hook instances re-sync (navbar badge and checkout page stay in sync)
- Cart is cleared (`{restaurantId: null, restaurantName: '', items: []}`) on successful order confirmation
- Adding an item from a different `restaurantId` triggers `window.confirm()` before clearing
- Cart serialisation/deserialisation is wrapped in try/catch — malformed localStorage does not crash the app

---

## TR-6: Checkout page and order submission

*Traces to: [BR-1](business.md#br-1-single-restaurant-linear-checkout), [BR-5](business.md#br-5-test-mode-payment-in-wave-1), [BR-8](business.md#br-8-failed-order-preserves-cart-and-shows-inline-error)*

`frontend/src/pages/Checkout.jsx` — linear single-page checkout (not multi-step in Wave 1).

**Constraints:**
- Reads cart from `useCart`; redirects to homepage if cart is empty
- Address input (`<input id="address">`) is required; minimum 5 characters enforced client-side before submission
- `payment_method_id` is hardcoded to `'pm_card_visa'` in Wave 1 (Stripe test card)
- On submit: checks for `dishly_token` in localStorage; if absent, navigates to `/login` with `returnTo: '/checkout'` state
- On success: calls `clearCart()` then navigates to `/orders/:id`
- On error: sets inline error state; re-enables submit button; does not clear cart
- No partial order in DB on failed submission — `POST /orders` returns an error before any DB write if validation fails

---

## TR-7: Order confirmation page

*Traces to: [BR-6](business.md#br-6-order-confirmation-screen-with-simulated-eta)*

`frontend/src/pages/OrderConfirmation.jsx` — renders at `/orders/:id`.

**Constraints:**
- Calls `clearCart()` on component mount (belt-and-suspenders clear in case Checkout page didn't)
- Fetches `GET /orders/:id` with bearer token from localStorage
- Renders: success icon, "Order Confirmed!" heading, order number (first 8 chars of UUID), restaurant name, delivery address, itemised items, subtotal/delivery fee/total, and ETA banner ("30–40 minutes")
- Shows `<LoadingSpinner>` while fetching; `<ErrorMessage>` on API error
- Two CTAs: "Back to home" (`/`) and "View order history" (`/account/orders`)

---

## TR-8: Order history page

*Traces to: [BR-7](business.md#br-7-order-history-for-authenticated-users)*

`frontend/src/pages/OrderHistory.jsx` — renders at `/account/orders`.

**Constraints:**
- Redirects to `/login` on mount if no `dishly_token` in localStorage
- Fetches `GET /users/me/orders` with bearer token
- On 401 response: redirects to `/login`
- Renders orders newest-first; each row shows: restaurant name, order date (ISO date slice), item chips, total, and "View details" link to `/orders/:id`
- Shows `<EmptyState>` with friendly message when no orders exist

---

## TR-9: Stripe SDK configuration

*Traces to: [BR-5](business.md#br-5-test-mode-payment-in-wave-1)*

**Constraints:**
- Backend uses `stripe` npm package initialised with `process.env.STRIPE_SECRET_KEY` (must be a `sk_test_` key)
- `stripe.paymentIntents.create({ amount: totalValue, currency: 'usd', payment_method: payment_method_id, confirm: true })` called inside `POST /orders` before the DB transaction
- No Stripe live-mode key (`sk_live_`) may exist anywhere in the codebase or `.env` files
- Frontend does not use Stripe.js directly — payment field is a static mock UI in Wave 1; only the backend calls the Stripe API
