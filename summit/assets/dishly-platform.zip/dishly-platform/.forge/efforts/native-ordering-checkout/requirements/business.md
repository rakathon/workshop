# Business Requirements: Native Ordering + Checkout

*Product / Effort: native-ordering-checkout*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Single-restaurant linear checkout

**Priority:** P0

The business must ensure the end-to-end ordering flow is single-restaurant and linear — from restaurant selection through menu, cart review, delivery address, order summary, and confirmation. No multi-restaurant orders, no order scheduling, and no saved addresses are supported in Wave 1.

**Acceptance Criteria:**
- [ ] A cart contains items from one restaurant only; adding an item from a second restaurant requires the customer to confirm before any cart contents change
- [ ] Delivery address is entered manually at checkout on every order — no saved address book
- [ ] Delivery now only — no scheduled or future orders
- [ ] Payment by card only via test-mode processing — no alternative payment wallets
- [ ] Order summary shows itemised breakdown, delivery address, and estimated delivery time before the customer confirms

---

## BR-2: Cart persistence across navigation

**Priority:** P0

The business must ensure that a customer's in-progress cart is not lost due to page navigation, tab closure, or refresh — so that customers do not need to rebuild their order after accidental navigation.

**Acceptance Criteria:**
- [ ] Cart contents survive a full page reload and tab close/reopen
- [ ] Cart is cleared on successful order confirmation
- [ ] Cart is cleared (after customer confirmation) when the customer starts a new restaurant's order
- [ ] Cart is private to the browser session and not tied to a user account or synced across devices

---

## BR-3: Cart conflict resolution

**Priority:** P0

The business must ensure that a customer is explicitly warned before their in-progress cart is replaced by items from a different restaurant — so that no items are silently lost.

**Acceptance Criteria:**
- [ ] A confirmation prompt names the current cart's restaurant before any cart contents are cleared
- [ ] The customer can choose to keep the existing cart, leaving it unchanged
- [ ] The customer can choose to start a new order, which clears the cart and adds the new item
- [ ] No items are silently removed from the cart without the customer explicitly confirming

---

## BR-4: Auth gate at cart/checkout, not at browse

**Priority:** P0

The business must ensure that discovery and browsing are open to anonymous visitors, and that an account is required only at the point of ordering — so that the discovery experience is uninterrupted and the auth barrier is as low as possible.

**Acceptance Criteria:**
- [ ] Any visitor can browse the homepage, collections, search, restaurant pages, and menus without signing in
- [ ] An auth prompt appears only when an unauthenticated visitor attempts to add to cart or proceed to checkout
- [ ] After successful sign-in at the checkout gate, the customer's cart is intact and checkout resumes from the correct step
- [ ] No auth prompt appears on any discovery surface (homepage, search results, restaurant page)

---

## BR-5: Test-mode payment in Wave 1

**Priority:** P0

The business must ensure that Wave 1 payment processing operates exclusively in test mode — no real payment is charged to any customer during the closed beta.

**Acceptance Criteria:**
- [ ] Checkout accepts a payment method and processes it without charging a real card
- [ ] Every submitted order is persisted with a confirmed status after test-mode payment processing
- [ ] No real payment is charged to any card at any point in Wave 1
- [ ] No live payment processing credentials are present in any environment used during Wave 1

---

## BR-6: Order confirmation screen with simulated ETA

**Priority:** P0

The business must ensure that after a successful order submission, the customer receives a clear confirmation showing their order was received and providing a simulated delivery estimate — so that the customer has confidence the order is placed even though live courier dispatch is not yet operational.

**Acceptance Criteria:**
- [ ] A confirmation screen is shown after a successful order submission
- [ ] The screen shows: order number, restaurant name, delivery address, itemised order summary, subtotal, delivery fee, and total
- [ ] A simulated delivery estimate is displayed — e.g. "Your order is on its way — estimated 30–40 min"
- [ ] The customer's cart is cleared upon reaching the confirmation screen
- [ ] No real courier dispatch occurs at any point in Wave 1

---

## BR-7: Order history for authenticated users

**Priority:** P1

The business must ensure that authenticated customers can view a complete history of their past orders with sufficient detail to identify what was ordered and when.

**Acceptance Criteria:**
- [ ] A signed-in customer can access their order history and see all past orders newest-first
- [ ] Each order shows: restaurant name, order date, itemised list of items with quantities, and order total
- [ ] Unauthenticated access to the order history page redirects to sign-in
- [ ] Order history is private — a customer cannot access another customer's orders
- [ ] No reorder shortcut in Wave 1

---

## BR-8: Failed order preserves cart and shows inline error

**Priority:** P0

The business must ensure that if an order submission fails, the customer's cart is preserved and a clear, human-readable error is presented — so that the customer can retry without rebuilding their order.

**Acceptance Criteria:**
- [ ] A failed order submission does not clear the customer's cart
- [ ] An inline error message is displayed on the checkout page — not a full-page error
- [ ] The submit action is re-enabled after a failure so the customer can retry
- [ ] No partial order is recorded on a failed submission
- [ ] The error message is human-readable — not a raw status code or technical trace
