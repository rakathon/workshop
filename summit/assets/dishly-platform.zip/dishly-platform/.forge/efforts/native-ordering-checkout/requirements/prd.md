# PRD: Native Ordering + Checkout

*Product / Effort: native-ordering-checkout*
*Last updated: 2026-06-07*

---

## Problem Statement

Quality-conscious urban consumers who order food delivery 2–4× per week have no trustworthy surface that connects restaurant discovery to native ordering in a single flow. Incumbent platforms (DoorDash, Uber Eats) rank results by paid placement rather than food quality, forcing users across 2–3 apps to complete a single meal decision — discover on Yelp or Instagram, order on DoorDash — with no continuity between the two.

dishly solves the full loop: editorial curation feeds directly into a native ordering and checkout experience with no app-switching and no paid placement. This effort — Native Ordering + Checkout — closes the loop between the discovery UX (consumer-web-discovery) and a confirmed, tracked order. Wave 1 is a closed beta with simulated delivery and Stripe test-mode payment, validating the complete discover → cart → checkout → confirmation journey before investing in live courier dispatch or real payment processing.

---

## Goals

1. Full discover-to-order loop functional — measured by a user can complete restaurant → menu → cart → checkout → confirmation without errors in 100% of test runs
2. Order success rate ≥90% — measured by fewer than 10% of order submission attempts fail or surface an error during closed beta
3. Cart conflict handled cleanly — measured by 100% of attempts to add items from a second restaurant trigger a confirmation prompt before clearing the cart
4. Order history accessible to authenticated users — measured by all past orders for the signed-in user are returned with correct restaurant name, date, items, and total
5. Auth gate fires at cart/checkout, not at browse — measured by 0 auth prompts occur on homepage, search, or restaurant pages; gate fires only when the user attempts to add to cart or proceed to checkout

---

## Non-Goals

- We are not building live courier dispatch — delivery is fully simulated in Wave 1; no DoorDash Drive or Uber Direct API integration is built or designed
- We are not processing real payments — Stripe is used in test mode only; no live charges, no PCI compliance scope for Wave 1
- We are not building a saved delivery address book — delivery address is entered manually per order; no persistence of addresses to a user profile
- We are not supporting multi-restaurant carts — a cart holds items from exactly one restaurant; starting a new restaurant's order clears the existing cart (with a prompt)
- We are not building password reset or email infrastructure — beta users who lose access re-register; no SMTP, no transactional email, no reset tokens
- We are not scheduling or tracking live delivery — the post-confirmation screen shows a static simulated ETA ("estimated 30–40 min"); no real-time courier location or status stream

---

## Success Metrics

### Leading Indicators (early signal)

- Order attempt rate: users who reach the checkout page ÷ users who add at least one item to cart (target: ≥70%)
- Cart abandonment rate: users who view the cart but do not proceed to checkout (target: <30%)
- Auth modal conversion rate: users who complete sign-up/sign-in at the checkout gate ÷ users who see the auth gate (target: ≥60%)
- Checkout completion rate: users who submit the Place Order form ÷ users who reach the checkout page (target: ≥75%)

### Lagging Indicators (final outcome)

- Order completion rate at 4 weeks post-beta launch: ≥90% of order submissions result in a confirmed order
- Zero P0 bugs (data loss, broken checkout, auth failures) open for more than 24 hours at any point in the beta
- Beta users place at least 1 successful order per session (target: ≥50% of beta sessions with cart activity end in a confirmed order)

---

## Open Questions

None identified at this time. All engineering decisions are resolved in the existing technical requirements (TR-1 through TR-11 in dishly-wave-1) and ADRs (ADR-001 user URI structure, ADR-002 normalized order items table).

---

## Timeline / Dependencies

- **Target:** Wave 1 closed beta launch — all 8 implementation tasks (TASK-001 through TASK-008) complete
- **Dependencies:**
  - `user-auth` effort — JWT auth middleware must be in place before order endpoints can enforce authentication
  - `core-backend-apis` effort — restaurant and menu data APIs must be live before cart and checkout can function end-to-end
  - `consumer-web-discovery` effort — cart state (localStorage), restaurant page, and frontend routing must exist before checkout pages can be built

---

## Requirements

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.
