# Functional Requirements — Native Ordering + Checkout

*Effort: native-ordering-checkout*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Enforce single-restaurant cart constraint

*Traces to: [BR-1](business.md#br-1-single-restaurant-linear-checkout)*

The system must prevent a cart from holding items from more than one restaurant at any time. When a customer attempts to add an item from a restaurant that differs from the restaurant of items already in the cart, the system must present a conflict resolution prompt before making any cart mutation.

---

## FR-2: Linear checkout flow with required address and order summary

*Traces to: [BR-1](business.md#br-1-single-restaurant-linear-checkout)*

The system must enforce a sequential checkout flow — cart review, delivery address entry, order summary, and confirmation — where each step must be completed before advancing. The delivery address field must be required, and an itemised order summary (items, delivery fee, total, estimated delivery time) must be presented before the customer can confirm the order.

---

## FR-3: Persist cart state across page navigation and tab closure

*Traces to: [BR-2](business.md#br-2-cart-persistence-across-navigation)*

The system must persist cart contents across page reloads, tab closures, and in-app navigation so that a customer's in-progress order is not lost. The cart must be cleared automatically upon successful order confirmation.

---

## FR-4: Clear cart on new-restaurant selection after customer confirmation

*Traces to: [BR-2](business.md#br-2-cart-persistence-across-navigation), [BR-3](business.md#br-3-cart-conflict-resolution)*

The system must clear the cart and apply the new item only after the customer has explicitly confirmed they wish to start a new order. Prior to confirmation, the existing cart must remain unchanged.

---

## FR-5: Cart conflict modal naming the current restaurant

*Traces to: [BR-3](business.md#br-3-cart-conflict-resolution)*

The system must display a conflict prompt that names the restaurant associated with the current cart when the customer attempts to add an item from a different restaurant. The prompt must present two explicit choices: keep the existing cart (no mutation) or start a new order (clear and add new item).

---

## FR-6: Allow unauthenticated browsing of all discovery surfaces

*Traces to: [BR-4](business.md#br-4-auth-gate-at-cartcheckout-not-at-browse)*

The system must serve the homepage, search results, restaurant pages, and menu pages to unauthenticated visitors without triggering any authentication requirement.

---

## FR-7: Trigger auth gate on add-to-cart or checkout for unauthenticated visitors

*Traces to: [BR-4](business.md#br-4-auth-gate-at-cartcheckout-not-at-browse)*

The system must require authentication when an unauthenticated visitor attempts to add an item to the cart or proceed to checkout. After successful authentication, the system must restore the customer's cart state and resume checkout without requiring the customer to repeat completed steps.

---

## FR-8: Process payment in test mode and persist confirmed order

*Traces to: [BR-5](business.md#br-5-test-mode-payment-in-wave-1)*

The system must process all Wave 1 payments using test-mode payment processing only. Upon successful test-mode payment processing, the system must persist the order with a confirmed status. The system must not issue any live payment charges.

---

## FR-9: Render order confirmation screen with simulated ETA

*Traces to: [BR-6](business.md#br-6-order-confirmation-screen-with-simulated-eta)*

After a successful order submission, the system must render a confirmation screen displaying the order number, restaurant name, delivery address, itemised order summary (items, quantities, prices), subtotal, delivery fee, total, and a static simulated delivery estimate. The system must clear the customer's cart upon rendering the confirmation screen.

---

## FR-10: Serve authenticated order history newest-first

*Traces to: [BR-7](business.md#br-7-order-history-for-authenticated-users)*

The system must provide an order history view that is accessible only to authenticated customers. The view must list all orders belonging to the authenticated customer in reverse chronological order, showing restaurant name, order date, itemised items with quantities, and order total. Unauthenticated access must redirect to sign-in. Requests for another customer's orders must be denied.

---

## FR-11: Preserve cart and surface inline error on failed order submission

*Traces to: [BR-8](business.md#br-8-failed-order-preserves-cart-and-shows-inline-error)*

When an order submission fails for any reason (validation error, server error, or network failure), the system must preserve the customer's cart unchanged, display a human-readable inline error message on the checkout page, and re-enable the submit action so the customer can retry. The system must not persist any partial order record on a failed submission.
