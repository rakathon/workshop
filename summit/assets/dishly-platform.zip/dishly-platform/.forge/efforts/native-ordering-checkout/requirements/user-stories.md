# User Stories: Native Ordering + Checkout

*Product / Effort: native-ordering-checkout*
*Last updated: 2026-06-07*

---

## Anonymous Visitor (pre-auth discovery)

**US-1:** As an anonymous visitor, I want to browse restaurant menus and see prices and photos without signing in, so that I can decide what I want to order before committing to creating an account.

**Acceptance Criteria:**
- [ ] Any visitor can view any restaurant page, menu sections, and item details without a sign-in prompt
- [ ] No auth gate appears anywhere on the discovery surface (homepage, search, restaurant page, menu)

---

**US-2:** As an anonymous visitor, I want to be prompted to sign in only when I try to add an item to my cart, so that my browsing experience is uninterrupted until I'm ready to order.

**Acceptance Criteria:**
- [ ] Clicking "Add to cart" while unauthenticated shows an auth prompt (modal or redirect to /login)
- [ ] No auth prompt appears before the user attempts to add to cart
- [ ] After signing in, the item the user tried to add is added to the cart automatically (or the user is returned to the restaurant page to add it)

---

## New User (first-time orderer)

**US-3:** As a new user, I want to create an account with my email and password at the checkout gate, so that I can place my first order without having to register separately before browsing.

**Acceptance Criteria:**
- [ ] Sign-up is available inline at the checkout gate — the user does not need to visit `/register` separately
- [ ] Registration requires email and password (minimum 8 characters)
- [ ] After successful registration, the user's cart is preserved and checkout continues
- [ ] A duplicate email returns a clear error message without clearing the form

---

**US-4:** As a new user, I want to enter my delivery address at checkout, so that I can specify where my order should be delivered without having saved addresses set up.

**Acceptance Criteria:**
- [ ] A free-text delivery address field is present on the checkout page
- [ ] The address field is required before the order can be submitted
- [ ] The entered address appears on the order confirmation screen and is stored with the order record

---

## Authenticated Orderer (placing an order)

**US-5:** As an authenticated user, I want to add multiple items from one restaurant to my cart and review them before checking out, so that I can build my full order before committing.

**Acceptance Criteria:**
- [ ] Items from the same restaurant accumulate in the cart with correct quantities and line totals
- [ ] The cart page shows restaurant name, all items with quantities and prices, delivery fee, and order total
- [ ] A "Proceed to Checkout" button navigates to the checkout page

---

**US-6:** As an authenticated user, I want to be warned before I accidentally clear my cart by starting a new restaurant's order, so that I don't lose items I already selected.

**Acceptance Criteria:**
- [ ] Adding an item from a different restaurant than the current cart's restaurant shows a confirmation modal
- [ ] The modal names the current cart's restaurant explicitly
- [ ] "Keep current cart" dismisses the modal with no changes
- [ ] "Start new order" clears the cart and adds the new item

---

**US-7:** As an authenticated user, I want to see a full order summary before I confirm payment, so that I can verify items, address, and total before committing.

**Acceptance Criteria:**
- [ ] Checkout shows: itemised list with quantities and prices, delivery address, subtotal, delivery fee ($3.99), and total
- [ ] The "Place Order" button is not shown until the address field is filled
- [ ] No surprise fees appear between the cart view and the final confirmation

---

**US-8:** As an authenticated user, I want to receive a confirmation screen with a simulated delivery estimate after placing my order, so that I know my order was received and what to expect.

**Acceptance Criteria:**
- [ ] A confirmation screen at `/orders/:id` renders after a successful order submission
- [ ] The screen shows order number, restaurant name, delivery address, itemised summary, and total
- [ ] A simulated ETA is displayed — e.g. "Estimated 30–40 minutes"
- [ ] Cart is cleared in localStorage when the confirmation screen loads
- [ ] Two CTAs are visible: "Back to home" and "View order history"

---

**US-9:** As an authenticated user, I want my cart to be preserved if my order submission fails, so that I don't have to rebuild my order after a network or server error.

**Acceptance Criteria:**
- [ ] A failed order submission does not clear the cart
- [ ] An inline error message is shown on the checkout page with a human-readable explanation
- [ ] The "Place Order" button is re-enabled so the user can retry immediately
- [ ] No partial order is created in the database on failure

---

## Returning User (order history)

**US-10:** As a returning authenticated user, I want to view my past orders with itemised detail, so that I can track what I've ordered and find restaurants I've enjoyed.

**Acceptance Criteria:**
- [ ] `/account/orders` shows all past orders newest-first
- [ ] Each order shows: restaurant name, order date, itemised items with quantities, and total
- [ ] Unauthenticated access redirects to `/login`

---

**US-11:** As a returning authenticated user, I want my order history to be private, so that other users cannot see what I've ordered.

**Acceptance Criteria:**
- [ ] A user's orders are only visible when authenticated as that user
- [ ] Attempting to fetch another user's order via `GET /orders/:id` returns a 403 response
- [ ] `GET /users/me/orders` returns only orders belonging to the authenticated user

---

## Internal / Beta Operations

**US-12:** As an internal team member, I want order and order-item records to snapshot item names and prices at time of order, so that historical order history remains accurate even if menu prices change after the order is placed.

**Acceptance Criteria:**
- [ ] `order_item` rows store `item_name` and `unit_price` as snapshots, not foreign-key lookups
- [ ] Changing a menu item's price or name after an order is placed does not alter the order history display
- [ ] The order confirmation and history pages render from the snapshotted values

---
