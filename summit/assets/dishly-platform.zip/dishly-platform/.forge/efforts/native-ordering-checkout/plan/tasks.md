# Implementation Plan: Native Ordering + Checkout

Tasks within the same wave are independent and can run in parallel.
Tasks in wave N+1 require all wave N tasks complete.

```mermaid
gantt
    title  Native Ordering + Checkout — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Backend
    Order + OrderItem schema migration  :task1, 1, 2
    POST /orders handler                :crit, task2, 2, 3
    GET /orders/:id handler             :task3, 2, 3
    GET /users/me/orders handler        :task4, 2, 3

    section Frontend
    Cart page                           :task5, 1, 2
    Checkout page + Stripe              :crit, task6, 2, 3
    Order confirmation page             :task7, 3, 4
    Order history page                  :task8, 3, 4
    Full loop observable                :milestone, m1, 4, 0
```

---

## Wave 1 — Schema + Cart Page

### TASK-001 `[auto]` `[wave:1]`

Extend `backend/src/db/migrate.js` with `CREATE TABLE IF NOT EXISTS` for `order` and `order_item` tables.

**Satisfies:** TR-4
**Standards:** none
**Required tests:** none (migration task)
**Completed:** no-vcs

---

### TASK-005 `[auto]` `[wave:1]`

Build `frontend/src/pages/Cart.jsx` — reads cart from `useCart`, displays itemised list with quantities and line totals, shows delivery fee ($3.99), order total, a "Proceed to Checkout" button (links to `/checkout`), and a "Clear cart" button. Shows empty state when cart is empty.

**Satisfies:** BR-2, TR-3
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

## Wave 2 — Order API + Checkout Page

### TASK-002 `[tdd]` `[wave:2]`

Implement `POST /dishly/v1/orders` — validate all items belong to one restaurant, snapshot item names and prices into `order_item` rows, call Stripe PaymentIntents in test mode, persist order with status `confirmed`, return 201 `{data: Order, meta}`.

**Satisfies:** BR-1, BR-3, TR-4, TR-5
**Depends on:** TASK-001
**Standards:** none
**Required tests:**
- `test('POST /orders creates order and returns 201')` — valid payload, correct shape
- `test('POST /orders returns 422 for items from multiple restaurants')` — validation
- `test('POST /orders returns 401 without auth token')` — auth guard
**Completed:** no-vcs

---

### TASK-003 `[tdd]` `[wave:2]`

Implement `GET /dishly/v1/orders/:id` — returns order with nested `order_item` rows; 403 if order belongs to a different user; 404 if not found.

**Satisfies:** BR-4, TR-4
**Depends on:** TASK-001
**Standards:** none
**Required tests:**
- `test('GET /orders/:id returns order for its owner')` — 200 correct shape
- `test('GET /orders/:id returns 403 for different user')` — ownership check
- `test('GET /orders/:id returns 404 for unknown id')` — not found
**Completed:** no-vcs

---

### TASK-004 `[tdd]` `[wave:2]`

Implement `GET /dishly/v1/users/me/orders` — returns paginated order history for the authenticated user, newest first.

**Satisfies:** BR-4, TR-4
**Depends on:** TASK-001
**Standards:** none
**Required tests:**
- `test('GET /users/me/orders returns orders for authenticated user')` — array, newest first
- `test('GET /users/me/orders returns 401 without token')` — auth guard
**Completed:** no-vcs

---

### TASK-006 `[auto]` `[wave:2]`

Build `frontend/src/pages/Checkout.jsx` — delivery address input, Stripe card element (test mode via `@stripe/stripe-js`), order summary, "Place Order" button that calls `POST /orders` with `payment_method_id`; on success navigates to `/orders/:id`; on error shows message and preserves cart.

**Satisfies:** BR-1, BR-2, BR-3, TR-5
**Depends on:** TASK-005
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

## Wave 3 — Confirmation + History

### TASK-007 `[auto]` `[wave:3]`

Build `frontend/src/pages/OrderConfirmation.jsx` — fetches `/orders/:id`, displays order summary with simulated delivery status ("Your order is confirmed — estimated 30–40 min"), clears cart on mount.

**Satisfies:** BR-1, BR-5
**Depends on:** TASK-002, TASK-003
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

### TASK-008 `[auto]` `[wave:3]`

Build `frontend/src/pages/OrderHistory.jsx` — fetches `/users/me/orders`, displays list of past orders (restaurant name, date, items, total); redirects unauthenticated users to `/login`.

**Satisfies:** BR-4
**Depends on:** TASK-004
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs
