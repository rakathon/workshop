# Verification Report

**Result:** FAIL
**Effort:** native-ordering-checkout
**Date:** 2026-06-06T04:00:00Z

## Summary

The core ordering and checkout flow is substantially implemented: the schema migration creates correct normalized tables, `POST /orders` validates single-restaurant membership and persists order + order_item rows in a transaction, `GET /orders/:id` enforces ownership, `GET /users/me/orders` returns newest-first paginated history, and all three TDD test suites cover the required scenarios. Frontend pages (Cart, Checkout, OrderConfirmation, OrderHistory) are complete and wired to the correct API endpoints via the shared `api/client.js`. Two gaps prevent a PASS: (1) BR-4's acceptance criterion that an auth prompt appears when an unauthenticated user *adds to cart* is not met — `Restaurant.jsx` calls `addItem()` with no auth check; the gate only fires at checkout submission in `Checkout.jsx`. (2) BR-5 / TASK-002 specify that `POST /orders` calls the Stripe PaymentIntents API in test mode; the actual implementation accepts `payment_method_id` but makes no Stripe API call, leaving the stated AC unimplemented.

## Requirement Coverage

### Business Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| [BR-1](../requirements/business.md#br-1-single-restaurant-linear-checkout) | Single-restaurant linear checkout | PASS | `POST /orders` validates all items belong to stated `restaurant_id` (orders.js:62-67); flow: Cart → Checkout → `/orders/:id`. |
| [BR-2](../requirements/business.md#br-2-cart-persistence-across-navigation) | Cart persistence in localStorage | PASS | `useCart.js` persists to `dishly_cart` key; `Checkout.jsx` calls `clearCart()` on success; `OrderConfirmation.jsx` also calls `clearCart()` on mount. |
| [BR-3](../requirements/business.md#br-3-cart-conflict-resolution) | Cart conflict modal | PASS | `useCart.js:35-40` — `window.confirm()` fires when `addItem()` is called with a different restaurant; cart only cleared if user confirms. |
| [BR-4](../requirements/business.md#br-4-auth-gate-at-cartcheckout-not-at-browse) | Auth gate at cart/checkout, not at browse | FAIL | `Restaurant.jsx:71` calls `addItem()` with no auth check — unauthenticated users can add items freely. Gate only fires in `Checkout.jsx:38-41` at form submission. See Gap G-1. |
| [BR-5](../requirements/business.md#br-5-test-mode-payment-in-wave-1) | Stripe test-mode payment | FAIL | `Checkout.jsx` sends `payment_method_id: 'pm_card_visa'`; `orders.js` accepts the field but makes no Stripe API call. TASK-002 explicitly required a Stripe PaymentIntents call. See Gap G-2. |
| [BR-6](../requirements/business.md#br-6-order-confirmation-screen-with-simulated-eta) | Order confirmation screen with simulated ETA | PASS | `OrderConfirmation.jsx` displays order number (id.slice(0,8)), restaurant name, delivery address, itemised items, subtotal, delivery fee, total, and ETA banner "30-40 minutes". Cart cleared on mount (line 22). |
| [BR-7](../requirements/business.md#br-7-order-history-for-authenticated-users) | Order history for authenticated users | PASS | `OrderHistory.jsx` fetches `/users/me/orders`; redirects to `/login` if no token; displays restaurant name, date, items, total; 403 enforced at API level. |
| [BR-8](../requirements/business.md#br-8-failed-order-preserves-cart-and-shows-inline-error) | Failed order preserves cart, shows inline error | PASS | `Checkout.jsx:56-59` — on error, `setError()` called and `setSubmitting(false)` re-enables button; `clearCart()` only called inside `try` block on success path. Error message is human-readable. |

### Technical Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| [TR-1](../requirements/technical.md#tr-1-order-and-orderitem-schema) | Local-only infrastructure | PASS | SQLite in-process; no Docker, no cloud calls at runtime. |
| [TR-2](../requirements/technical.md#tr-2-post-orders-endpoint) | Technology stack | PASS | React, Node.js/Express, SQLite (better-sqlite3), JWT auth. |
| [TR-4](../requirements/technical.md#tr-4-get-usersmeorders-endpoint) | Core data model — order + order_item tables | PASS | `migrate.js:61-85` creates `"order"` and `order_item` with correct columns: `item_name` snapshot, `unit_price_value/scale`, `delivery_fee_value`, `deleted_at` soft-delete, correct foreign keys. |
| [TR-10](../../dishly-wave-1/requirements/technical.md#tr-10-cart-persistence) | Cart persistence | PASS | `useCart.js` — localStorage key `dishly_cart`; survives reload; cleared on confirm; conflict prompt on restaurant switch. |
| [TR-11](../../dishly-wave-1/requirements/technical.md#tr-11-client-side-routing) | Client-side routing for ordering routes | PASS | `OrderConfirmation.jsx` uses `useParams` for `/orders/:id`; `OrderHistory.jsx` renders at `/account/orders`; all routes registered in the router. |

## ADR Compliance

| ADR | Decision (short) | Status | Notes |
|-----|-----------------|--------|-------|
| ADR-001 | Use `/users/me` not regional member URI for Wave 1 | PASS | `users.js:13` — `router.get('/me/orders', ...)` and `router.get('/me', ...)`; registered at `/dishly/v1/users` in `routes/index.js:8`. Frontend calls `/users/me/orders` correctly. |
| ADR-002 | Normalized `order_item` table, not JSON column on `order` | PASS | `migrate.js:77-85` — separate `order_item` table with `item_name TEXT NOT NULL` snapshot. `orders.js:88` writes `item_name` from `menu_item.name` at creation time. No JSON column on `"order"`. |

## Gaps

### G-1 — BR-4: Auth gate missing at "Add to cart" action

**Requirement:** [BR-4](../requirements/business.md#br-4-auth-gate-at-cartcheckout-not-at-browse) AC — "An auth prompt appears when an unauthenticated user attempts to add to cart."

**Location:** `/Users/paras.patel/Workspace/food-delivery-1/frontend/src/pages/Restaurant.jsx:71`

```jsx
onClick={() => addItem({ id: item.id, name: item.name, price: item.price }, restaurant)}
```

`addItem()` in `useCart.js` contains no authentication check. An unauthenticated user can add items to the cart freely. The only auth gate is in `Checkout.jsx:38-41`, which fires at form submission. The requirement specifies the gate must fire at the *add to cart* action.

**Fix required:** Check for `localStorage.getItem('dishly_token')` before calling `addItem()` in `Restaurant.jsx` (or inside `useCart.addItem()`), and redirect to `/login` with `returnTo: '/checkout'` state if no token is present.

---

### G-2 — BR-5 / TASK-002: Stripe PaymentIntents API call absent

**Requirement:** [BR-5](../requirements/business.md#br-5-test-mode-payment-in-wave-1) AC — "Checkout UI accepts a card number and calls the Stripe PaymentIntents API in test mode." TASK-002 — "call Stripe PaymentIntents in test mode."

**Location:** `/Users/paras.patel/Workspace/food-delivery-1/backend/src/routes/orders.js:33`

```js
const { restaurant_id, items, delivery_address, payment_method_id } = req.body || {};
```

`payment_method_id` is destructured but never passed to Stripe. No Stripe SDK import exists in `orders.js` and no PaymentIntent is created. The field is silently ignored. No real charge occurs (satisfying that AC bullet), but the AC and TASK-002 explicitly require a Stripe test-mode API call.

**Fix required:** Add `stripe` npm package to the backend, initialize with `STRIPE_SECRET_KEY=sk_test_...`, and call `stripe.paymentIntents.create({ amount: totalValue, currency: 'usd', payment_method: payment_method_id, confirm: true })` inside `POST /orders` before inserting the order record.
