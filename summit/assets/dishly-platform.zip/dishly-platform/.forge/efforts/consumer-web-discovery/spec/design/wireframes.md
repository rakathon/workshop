# dishly — Wireframes

*Effort: consumer-web-discovery*
*Authored: 2026-06-05*
*Traces to: [BR-10](../../../dishly-wave-1/requirements/business.md#br-10-discovery-ux-surfaces), [BR-11](../../../dishly-wave-1/requirements/business.md#br-11-ordering-flow), [BR-12](../../../dishly-wave-1/requirements/business.md#br-12-order-history), [BR-15](../../../dishly-wave-1/requirements/business.md#br-15-error-states), [BR-16](../../../dishly-wave-1/requirements/business.md#br-16-restaurant-page-layout)*
*Screens: S-01 through S-11 (see [user-flows.md](user-flows.md))*

Notation: `[ ]` = container/section, `< >` = interactive element, `---` = divider

All wireframes shown at desktop width (1280px), with mobile notes per screen.

---

## S-01 — Homepage

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER                                                                     │
│  [ dishly logo ]                             < Sign In >   < Sign Up >     │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  HERO / SEARCH                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │   Find food worth eating.                                           │   │
│  │                                                                     │   │
│  │   ┌────────────────────────────────────────────┐ < Search >        │   │
│  │   │  Search restaurants or cuisines...         │                   │   │
│  │   └────────────────────────────────────────────┘                   │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│  (full-width background: editorial food photography or gradient)            │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  COLLECTION: "Best Ramen in the City"                  < See all >         │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐               │
│  │ [img]     │  │ [img]     │  │ [img]     │  │ [img]     │               │
│  │           │  │           │  │           │  │           │               │
│  │ Name      │  │ Name      │  │ Name      │  │ Name      │               │
│  │ Japanese  │  │ Japanese  │  │ Japanese  │  │ Japanese  │               │
│  │ $$  ★4.8  │  │ $$  ★4.7  │  │ $$$  ★4.6 │  │ $$  ★4.9  │               │
│  └───────────┘  └───────────┘  └───────────┘  └───────────┘               │
│  (horizontal scroll on mobile; 4-up grid on desktop)                       │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  COLLECTION: "New Openings"                            < See all >         │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐               │
│  │ [img]     │  │ [img]     │  │ [img]     │  │ [img]     │               │
│  │ Name      │  │ Name      │  │ Name      │  │ Name      │               │
│  │ Italian   │  │ Mexican   │  │ Thai      │  │ Korean    │               │
│  │ $  ★4.5   │  │ $$  ★4.3  │  │ $$  ★4.8  │  │ $$$  ★4.7 │               │
│  └───────────┘  └───────────┘  └───────────┘  └───────────┘               │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  COLLECTION: "Under $15"                               < See all >         │
│  [ ...same card pattern... ]                                                │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│  FOOTER  [ About ]  [ For restaurants ]  [ © dishly 2026 ]                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Header: logo left, auth CTAs right. No nav links for Wave 1 (collections are on homepage).
- Hero search bar is the primary action above the fold. No background video.
- Collections are content-managed (JSON/config). At least 3 collections on homepage.
- Restaurant cards: cover image (4:3 ratio), restaurant name (bold), cuisine type, price range ($–$$$), star rating + number.
- Card image broken URL → grey placeholder with fork icon.
- Mobile (< 768px): hero search bar full-width, collections become horizontal scroll rows (2.5 cards visible to indicate scroll), "See all" collapses.

---

## S-02 — Search Results

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER (same as S-01, auth-aware)                                          │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  SEARCH BAR (sticky on scroll)                                              │
│  ┌──────────────────────────────────────┐ < Search >                        │
│  │  "Thai"                              │                                   │
│  └──────────────────────────────────────┘                                   │
│                                                                             │
│  FILTERS (inline chips — no modal)                                          │
│  Cuisine: < All > < Japanese > < Thai > < Italian > < Mexican > < Korean > │
│           < Indian > < Chinese > ... (scrollable)                           │
│  Price:   < All > < $ > < $$ > < $$$ >                                     │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  RESULTS  "12 restaurants for Thai"                                         │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [img 120×90]  Name of Restaurant                    $$  ★4.7        │   │
│  │                Thai  ·  Delivery available                           │   │
│  │                Short one-line description of the restaurant          │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [img 120×90]  Name of Restaurant                    $   ★4.5        │   │
│  │                Thai  ·  Delivery available                           │   │
│  │                Short one-line description                            │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  [ ... repeat rows ... ]                                                    │
│                                                                             │
│  ── EMPTY STATE (when no results) ─────────────────────────────────────────│
│                                                                             │
│      No restaurants found for "xyz"                                         │
│      Try a different search or browse our collections.                      │
│      < Browse collections >                                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Search bar pre-filled with active query. Editing it re-runs search.
- Filter chips: tapping a cuisine type or price narrows results inline (no page reload).
- Result rows: image left (thumbnail), metadata right. Entire row is clickable.
- Result count shown above results ("12 restaurants").
- Mobile: filter chips scroll horizontally; result rows go full-width.

---

## S-03 — Restaurant Page

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER (with cart icon showing item count if cart has items)               │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  HERO IMAGE (full-width, 480px tall desktop / 240px mobile)                 │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │                    [cover_image_url]                                │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  RESTAURANT METADATA                                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Matsuri Ramen                                                      │   │
│  │  Japanese  ·  $$  ·  ★4.8  (124 reviews)                           │   │
│  │                                                                     │   │
│  │  Crafting tonkotsu broth for 18 hours, in the tradition of         │   │
│  │  Hakata ramen houses. Everything made in-house.                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  MENU                                                                       │
│  ▼ Starters                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [item img]  Gyoza (6pc)                                  $9.00      │   │
│  │              Pan-fried pork dumplings, citrus ponzu                  │   │
│  │                                                  < Add to cart >    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [item img]  Karaage                                      $11.00     │   │
│  │              Japanese fried chicken, kewpie mayo                    │   │
│  │                                                  < Add to cart >    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ▼ Ramen                                                                    │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [item img]  Tonkotsu Ramen                               $18.00     │   │
│  │              18-hour pork broth, chashu, soft egg, nori             │   │
│  │                                                  < Add to cart >    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  [ ...more items... ]                                                       │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  REVIEWS                                                                    │
│  ★4.8  Based on 124 reviews                                                 │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  ★★★★★  Alex M.  ·  March 2026                                       │   │
│  │  "Best tonkotsu I've had outside of Japan. The broth is legit."     │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  ★★★★★  Sasha K.  ·  February 2026                                   │   │
│  │  "The gyoza are criminally underrated."                             │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  [ 3–5 reviews total — no pagination ]                                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Header cart icon shows badge count. Clicking it opens cart drawer.
- Menu sections are collapsible on mobile (tapping section header toggles open/closed).
- Each menu item: image left (80×80 square), name + description middle, price + "Add to cart" right.
- "Add to cart" triggers auth gate if user is not signed in (see Flow 3).
- Broken cover image → full-width grey placeholder with restaurant name text overlay.
- Reviews are seeded; no submission UI.

---

## S-04 — Auth Modal (Sign In / Sign Up)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  (Page dimmed behind modal)                                                 │
│                                                                             │
│             ┌───────────────────────────────────────┐                      │
│             │                              < × >    │                      │
│             │   [ Sign In ]  [ Sign Up ]             │  (tab switcher)     │
│             │   ──────────────────────────           │                      │
│             │                                        │                      │
│             │   Email address                        │                      │
│             │   ┌──────────────────────────────┐     │                      │
│             │   │                              │     │                      │
│             │   └──────────────────────────────┘     │                      │
│             │                                        │                      │
│             │   Password                             │                      │
│             │   ┌──────────────────────────────┐     │                      │
│             │   │                              │     │                      │
│             │   └──────────────────────────────┘     │                      │
│             │                                        │                      │
│             │   [inline error — if any]              │                      │
│             │                                        │                      │
│             │   < Sign In > (primary button)         │                      │
│             │                                        │                      │
│             │   ── No "Forgot password" link ────    │                      │
│             │      (out of scope — BR-14)            │                      │
│             └───────────────────────────────────────┘                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Triggered modally — does not navigate away from the page that triggered it.
- Sign In / Sign Up are tabs in the same modal (not separate pages).
- Inline errors appear below the form, above the submit button.
- Sign Up: same layout, adds a "Confirm password" field.
- No "Forgot password" — per BR-14.
- After success: modal closes, original action (add to cart) proceeds automatically.
- Mobile: modal is a bottom sheet occupying 80% of screen height.

---

## S-05 — Cart (Drawer)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  (Page content at left; cart drawer slides in from right)                   │
│                                                                             │
│                              ┌──────────────────────────────────────────┐  │
│                              │  Your Cart              < × close >      │  │
│                              │  Matsuri Ramen                           │  │
│                              │  ──────────────────────────────────────  │  │
│                              │                                          │  │
│                              │  Tonkotsu Ramen                $18.00    │  │
│                              │  < – >  1  < + >               < 🗑 >    │  │
│                              │                                          │  │
│                              │  Gyoza (6pc)                   $9.00     │  │
│                              │  < – >  1  < + >               < 🗑 >    │  │
│                              │                                          │  │
│                              │  ──────────────────────────────────────  │  │
│                              │  Subtotal                      $27.00    │  │
│                              │  Estimated delivery fee         $3.99    │  │
│                              │  Estimated total               $30.99    │  │
│                              │                                          │  │
│                              │  < Proceed to Checkout >                 │  │
│                              │         (full-width primary button)      │  │
│                              │                                          │  │
│                              │  ── EMPTY STATE ──────────────────────── │  │
│                              │  Your cart is empty.                     │  │
│                              │  < Explore restaurants >                 │  │
│                              └──────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Drawer slides from right on desktop; full-screen modal on mobile.
- Restaurant name shown at top of cart — contextual anchor.
- Quantity controls: minus, count, plus; minimum quantity is 1 (minus at 1 shows remove icon instead).
- Delivery fee is an estimate ("Estimated") — final shown at checkout Step 3.
- Proceed to Checkout navigates to S-07 (checkout Step 1).

---

## S-06 — Cart Conflict Modal

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│             ┌─────────────────────────────────────────────┐                │
│             │                                             │                │
│             │  Start a new cart?                          │                │
│             │                                             │                │
│             │  You have items from Matsuri Ramen in your  │                │
│             │  cart. Starting an order from Lotus Thai    │                │
│             │  Kitchen will remove them.                  │                │
│             │                                             │                │
│             │  < Start new cart >  < Keep current cart >  │                │
│             │    (destructive)       (default / safe)     │                │
│             │                                             │                │
│             └─────────────────────────────────────────────┘                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Triggered when authenticated user taps "Add to cart" on a different restaurant while cart has items.
- "Keep current cart" is the visually default (safe) option — right-aligned.
- "Start new cart" is secondary (destructive) — left-aligned or visually de-emphasised.

---

## S-07/08/09 — Checkout (3-step linear)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER (simplified — logo only, no nav)                                    │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  PROGRESS INDICATOR                                                         │
│  ● Delivery  ──  ○ Payment  ──  ○ Review                                   │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  STEP 1 — Delivery Address                                                  │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │  Street address                                                    │    │
│  │  ┌──────────────────────────────────────────────────────────────┐  │    │
│  │  │                                                              │  │    │
│  │  └──────────────────────────────────────────────────────────────┘  │    │
│  │                                                                    │    │
│  │  City                           State    ZIP                       │    │
│  │  ┌──────────────────────┐       ┌────┐   ┌──────────┐             │    │
│  │  │                      │       │    │   │          │             │    │
│  │  └──────────────────────┘       └────┘   └──────────┘             │    │
│  │                                                                    │    │
│  │  Delivery instructions (optional)                                  │    │
│  │  ┌──────────────────────────────────────────────────────────────┐  │    │
│  │  │                                                              │  │    │
│  │  └──────────────────────────────────────────────────────────────┘  │    │
│  │                                                                    │    │
│  │  < Continue to Payment >                                           │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ── STEP 2 — Payment (same layout) ─────────────────────────────────────── │
│  Stripe card element embedded                                               │
│  Card number / Expiry / CVC fields (Stripe Elements)                        │
│  < Continue to Review >                                                     │
│                                                                             │
│  ── STEP 3 — Order Summary + Confirm ───────────────────────────────────── │
│                                                                             │
│  ORDER SUMMARY                                                              │
│  Restaurant: Matsuri Ramen                   < Edit address >               │
│  Deliver to: 123 Main St, Brooklyn, NY 11201                                │
│                                                                             │
│  Tonkotsu Ramen × 1                                          $18.00         │
│  Gyoza × 1                                                    $9.00         │
│  ─────────────────────────────────────────────────────────────────          │
│  Subtotal                                                    $27.00         │
│  Delivery fee                                                 $3.99         │
│  Total                                                       $30.99         │
│                                                                             │
│  [error message area — hidden unless submission fails]                      │
│                                                                             │
│  < Place Order >                                                            │
│  (primary button — full-width on mobile)                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Progress indicator shows current step (filled dot) and remaining steps (empty dot).
- Step 1 → Step 2 → Step 3 with back navigation allowed at each step.
- Checkout header is simplified (no nav, no cart link) — reduces distraction.
- Step 3 shows final totals (no estimates — delivery fee confirmed here).
- Error state on "Place Order": inline error above button, cart preserved, user can retry.
- Mobile: each step is full-screen; progress indicator is at top.

---

## S-10 — Order Confirmation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER (simplified — logo only)                                            │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │         ✓   Order confirmed!                                        │   │
│  │                                                                     │   │
│  │         Order #DIS-20260605-8821                                    │   │
│  │         Matsuri Ramen                                               │   │
│  │         Deliver to: 123 Main St, Brooklyn, NY 11201                │   │
│  │                                                                     │   │
│  │         Your order is on its way —                                  │   │
│  │         estimated 30–40 minutes.                                    │   │
│  │                                                                     │   │
│  │         Total charged: $30.99                                       │   │
│  │                                                                     │   │
│  │         < View order history >      < Back to home >               │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Confirmation check icon (✓) is prominent — green or brand colour.
- Order number format: `DIS-YYYYMMDD-NNNN`.
- ETA is static: "30–40 minutes" (no tracking in Wave 1).
- No real receipt email (BR-14 — no email infrastructure).
- Two secondary actions: order history (authenticated) and back to home.

---

## S-11 — Order History

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER (full — authenticated state)                                        │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  Order History                                                              │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │  Matsuri Ramen                        June 5, 2026         $30.99   │    │
│  │  2 items  ↓ expand                                                  │    │
│  │  ── expanded ─────────────────────────────────────────────────────  │    │
│  │     Tonkotsu Ramen × 1                                    $18.00    │    │
│  │     Gyoza × 1                                              $9.00    │    │
│  │     Delivery fee                                           $3.99    │    │
│  │     Total                                                 $30.99    │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │  Lotus Thai Kitchen                   May 22, 2026        $24.50    │    │
│  │  3 items  ↓ expand                                                  │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ── EMPTY STATE ─────────────────────────────────────────────────────────  │
│                                                                             │
│     No orders yet.                                                          │
│     < Explore restaurants >                                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Orders listed in reverse-chronological order.
- Each row: restaurant name (link to restaurant page), date, total, item count, expand toggle.
- Expanded row shows: itemised list with prices, delivery fee, total.
- Restaurant name in the row header is a link to the restaurant page (S-03).
- No reorder button in Wave 1.
- Empty state with CTA back to homepage discovery.

---

## Wireframe Summary

| Screen | Key layout decisions |
|--------|---------------------|
| S-01 Homepage | Hero search full-width, collections below in rows of 4, editorial naming |
| S-02 Search Results | Inline filter chips, list layout (not grid), full-row clickable |
| S-03 Restaurant Page | Full-width hero, metadata block, per-item menu rows, review snippets |
| S-04 Auth Modal | Tabbed modal (Sign In / Sign Up), bottom sheet on mobile |
| S-05 Cart Drawer | Right-side drawer, fee transparency, empty state |
| S-06 Cart Conflict | Minimal 2-button modal, safe action is default |
| S-07/08/09 Checkout | 3-step linear with progress indicator, simplified header |
| S-10 Order Confirmation | Centred confirmation, static ETA, two CTAs |
| S-11 Order History | Expandable list rows, restaurant name links |
