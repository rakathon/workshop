# dishly — User Personas

*Effort: consumer-web-discovery*
*Authored: 2026-06-05*
*Traces to: [BR-2](../../requirements/business.md#br-2-cuisine-filter-chips-on-homepage)*

---

## Persona 1 — Maya, The Intentional Orderer

**Age:** 29  
**Location:** Brooklyn, NY  
**Occupation:** UX designer at a fintech startup  
**Income:** $85K  
**Devices:** MacBook Pro (primary), iPhone 14 (ordering on the go)  
**Order frequency:** 3–4× per week

### About Maya

Maya has been in NYC for four years. She spends a lot of time thinking about food — she follows chefs on Instagram, reads Eater religiously, and has strong opinions about what constitutes a good bowl of ramen. She's frustrated by DoorDash: she knows a great tonkotsu spot two neighbourhoods over but DoorDash ranks it below a chain restaurant because the chain pays for placement. She uses Yelp to discover, DoorDash to order, and considers this a broken workflow.

### Goals
- Find restaurants she hasn't heard of that meet her quality bar
- Trust the discovery surface — know that what's ranked highly is actually good
- Browse menus thoroughly before committing (photos and descriptions matter)
- Complete an order in under 4 minutes once she's decided

### Pain Points
- Paid placement on incumbent platforms destroys signal-to-noise
- Inconsistent menu photos (or none) make it impossible to evaluate dishes
- Having to context-switch across apps (Yelp → DoorDash) creates drop-off and frustration
- Mismatched delivery estimates → orders arriving cold or too late

### Behaviours
- Browses discovery surfaces like editorial content, not a utility
- Reads 2–3 review snippets before deciding; skips long review lists
- Will abandon a restaurant page if there are no menu item photos
- Saves restaurants mentally ("I'll try that next week") — no wishlist feature needed for MVP

### Key Quote
> "I just want one place that actually knows what good food is and lets me order it."

---

## Persona 2 — Darius, The Efficient Professional

**Age:** 34  
**Location:** Chicago, IL (Lincoln Park)  
**Occupation:** Senior software engineer at a SaaS company  
**Income:** $130K  
**Devices:** Windows desktop (work), Samsung Galaxy S24 (ordering)  
**Order frequency:** 2–3× per week (lunch and late dinners)

### About Darius

Darius orders food because cooking takes time he doesn't have on weeknights. He's not a foodie in the Maya sense — he doesn't read food media — but he has consistent standards: he wants something fresh, not from a chain, and under $25 for himself. He discovers restaurants once and reorders from the same 5–6 places. The discovery phase matters to him only when he's bored of his rotation.

### Goals
- Get a reliable, non-chain meal without spending too much cognitive energy on the decision
- Filter quickly by cuisine type and price range to narrow options
- Trust reviews to be real — he's cynical about fake reviews on Yelp
- Checkout fast: minimal form fields, no friction after he's decided

### Pain Points
- Discovery surfaces that require too much exploration (too much scrolling before he sees something relevant)
- Checkout friction: saved cards he can't trust, confusing address forms
- Surprise fees revealed only at checkout
- Platforms where 4-star restaurants turn out to be mediocre

### Behaviours
- Uses search first, collections second
- Filters by cuisine type and price; rarely reads editorial content
- Orders from the first satisfying result rather than comparing many options
- Expects the checkout to be 3 steps maximum
- Doesn't review or rate after ordering

### Key Quote
> "I don't need it to be amazing, I need it to not waste my time."

---

## Persona 3 — Priya, The Explorer

**Age:** 24  
**Location:** Austin, TX  
**Occupation:** Graduate student (architecture program)  
**Income:** $28K (student stipend)  
**Devices:** MacBook Air (primary, large-screen browsing), iPhone 13  
**Order frequency:** 1–2× per week (treats, not routine)

### About Priya

Priya orders delivery occasionally — it's a treat, not a habit. When she does order, she wants to feel like she discovered something. She's the person who will spend 20 minutes looking at a platform if it feels like curated browsing, and she often ends up ordering from a restaurant she'd never heard of before. She's price-conscious: she won't order from a place where the delivery fee tips the total over $30.

### Goals
- Feel like she's discovered something worth telling her friends about
- Trust that the platform has taste — not everything is on here, just the good stuff
- See beautiful food photography that makes her want to order
- Keep total cost predictable before she gets to checkout

### Pain Points
- Generic homepage feeds with no editorial point of view
- Restaurant pages with no photos or sparse descriptions
- Hidden fees that appear only at checkout (delivery fee, service fee, tip)
- Checkout flows that require creating an account before she can even browse the menu

### Behaviours
- Starts on the homepage and browses collections before searching
- Spends significant time on the restaurant page — reads the full description
- Makes her decision based on food photography quality as much as reviews
- Abandons if the account gate appears before checkout (BR-9 handles this correctly for her)
- Likely to share a restaurant with friends if she has a good experience

### Key Quote
> "If the homepage looks like every other food app, I'm not staying."

---

## Persona Summary

| | Maya | Darius | Priya |
|---|---|---|---|
| Primary entry | Collections → restaurant | Search → filter | Homepage browse |
| Decision driver | Curation quality + reviews | Efficiency + price range | Photography + editorial feel |
| Auth tolerance | Accepts gate at checkout | Expects gate at checkout | Abandons if gate appears early |
| Price sensitivity | Moderate | Moderate-high | High |
| Repeat ordering | Occasional new discovery | High loyalty to rotation | Low — always exploring |
| Primary device | Desktop + mobile | Mobile | Desktop (large screen) |

---

## Design Implications

1. **Homepage must feel editorial, not utilitarian.** Collections with strong naming and cover imagery matter most for Priya and Maya.
2. **Search + filter must be fast for Darius.** Cuisine type and price range filters are the critical path — not an afterthought.
3. **Restaurant page photography is a decision gate.** All three personas will abandon a page with poor or missing photos.
4. **The auth gate at checkout (not at browse) is validated by all three personas.** Never interrupt discovery with an account prompt.
5. **Checkout must be minimal.** Darius's tolerance is the binding constraint: 3 steps maximum, no surprise fees.
6. **Desktop is as important as mobile.** Priya uses a large laptop screen. The responsive layout must be excellent at desktop widths, not just tolerable.
