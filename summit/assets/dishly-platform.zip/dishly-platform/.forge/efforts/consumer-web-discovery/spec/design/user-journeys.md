# dishly — User Journeys

*Effort: consumer-web-discovery*
*Authored: 2026-06-05*
*Personas: [personas.md](personas.md)*
*Traces to: [BR-10](../../../dishly-wave-1/requirements/business.md#br-10-discovery-ux-surfaces), [BR-11](../../../dishly-wave-1/requirements/business.md#br-11-ordering-flow), [BR-12](../../../dishly-wave-1/requirements/business.md#br-12-order-history)*

---

## Journey 1 — Anonymous Discovery to Restaurant Page (Maya)

**Goal:** Discover a restaurant worth ordering from without knowing what she wants  
**Entry:** Direct URL or bookmark — homepage  
**Exit:** Restaurant page, ready to order  
**Device:** Desktop browser  

---

### Stage 1: Landing

| | |
|---|---|
| **Action** | Opens dishly homepage for the first time |
| **Touchpoints** | Hero section, curated collections |
| **Thought** | "Does this actually have good taste, or is it DoorDash with a nicer font?" |
| **Emotion** | Skeptical → curious |

**What the UI must do:**
- Lead with editorial collection names that signal curation ("Best Ramen in the City" — not "Top Restaurants")
- Hero imagery must be food photography quality, not stock
- No interstitial sign-up prompts

---

### Stage 2: Collection Browsing

| | |
|---|---|
| **Action** | Scans curated collections; clicks "Best Ramen in the City" |
| **Touchpoints** | Collection row, restaurant cards within collection |
| **Thought** | "Are these all different from each other, or is it just ranked by revenue?" |
| **Emotion** | Curious — evaluating |

**What the UI must do:**
- Collection restaurants show: name, cuisine type, price range, average rating, cover photo
- Cards feel distinct — each restaurant has a visible personality through its cover image
- No "sponsored" or "ad" badges visible anywhere

---

### Stage 3: Restaurant Card Evaluation

| | |
|---|---|
| **Action** | Pauses on one card; reads name, rating, price range before clicking |
| **Touchpoints** | Restaurant card (name, rating, cuisine, $$) |
| **Thought** | "$$, 4.7 stars, Japanese — that's a promising signal. Let me see the page." |
| **Emotion** | Interested |

**What the UI must do:**
- Rating must be visually prominent (not buried)
- Price range uses $ / $$ / $$$ notation
- Card hover state is clear without being heavy

---

### Stage 4: Restaurant Page — First Impression

| | |
|---|---|
| **Action** | Clicks card → restaurant page loads |
| **Touchpoints** | Hero image, restaurant name, metadata, description |
| **Thought** | "Okay, the cover photo is real food photography. Reading the description…" |
| **Emotion** | Engaged |

**What the UI must do:**
- Hero image fills the top of the page — large, high-quality
- Restaurant name, cuisine, price range, rating visible immediately below hero
- Short description (2–4 sentences) visible without scrolling on desktop

---

### Stage 5: Menu Scanning

| | |
|---|---|
| **Action** | Scrolls through menu sections; examines item photos and descriptions |
| **Touchpoints** | Menu section headers, item rows (photo, name, description, price) |
| **Thought** | "The tonkotsu has a photo and an actual description — not just 'pork broth'. This place knows what it's doing." |
| **Emotion** | Confident — deciding |

**What the UI must do:**
- Every menu item has a photo; items without photos show a tasteful placeholder
- Item descriptions are 1–3 sentences, focused on what makes the dish
- Sections are scannable (clear headers, appropriate whitespace)
- "Add to cart" is visible inline per item — no drilling into a detail page

---

### Stage 6: Reviews Glance

| | |
|---|---|
| **Action** | Scrolls to reviews section; reads 2 snippets |
| **Touchpoints** | Average rating, review snippets |
| **Thought** | "4.7 and the reviews mention the broth specifically. That's a real signal." |
| **Emotion** | Convinced |

**What the UI must do:**
- 3–5 seeded review snippets, each with star rating, author name, date, and 1–3 sentence text
- Average rating shown as a number + stars, with review count
- No fake "Verified Purchase" badges — seeded data shouldn't pretend to be real UGC

---

### Journey 1 — Outcome

Maya has formed a confident opinion about a restaurant she'd never heard of. She is ready to order. **Journey 1 exits into Journey 2.**

**Emotion arc:** Skeptical → Curious → Engaged → Confident

---

---

## Journey 2 — Adding to Cart Through Checkout (Darius — new user placing first order)

**Goal:** Order dinner efficiently from a restaurant he found via search  
**Entry:** Search bar from homepage  
**Exit:** Order confirmation screen  
**Device:** Mobile browser (Samsung Galaxy)  

---

### Stage 1: Search

| | |
|---|---|
| **Action** | Types "Thai" in search bar from homepage |
| **Touchpoints** | Search bar, search results page |
| **Thought** | "I want something different tonight. Thai, under $25." |
| **Emotion** | Task-focused |

**What the UI must do:**
- Search bar is prominent on homepage — not buried
- Results appear on a dedicated search results page (not a dropdown overlay)
- Results show: name, cuisine, price range, rating, distance/delivery note

---

### Stage 2: Filter + Select

| | |
|---|---|
| **Action** | Applies "$" + "$$" price filter; scans 3–4 results; picks one |
| **Touchpoints** | Filter chips, restaurant cards |
| **Thought** | "This one has a 4.5 and $$. That works." |
| **Emotion** | Efficient — not browsing, evaluating |

**What the UI must do:**
- Filter chips are inline, above results — not hidden in a modal
- Cuisine type and price range are the only filters needed for MVP
- Filtering is instant (client-side on 100 seeded restaurants)

---

### Stage 3: Menu — Add to Cart

| | |
|---|---|
| **Action** | Opens restaurant page; scrolls to Mains; taps "Add" on Pad Thai |
| **Touchpoints** | Restaurant page, menu item, "Add to cart" button |
| **Thought** | "I need to sign in to add to cart. Fine — I'll register." |
| **Emotion** | Slight friction → accepting |

**What the UI must do:**
- Auth gate triggers on first "Add to cart" tap — not before
- Auth gate is a modal or inline bottom sheet (not a full page redirect)
- After sign-up/sign-in, the attempted item is added to cart automatically — user doesn't re-tap
- Cart icon appears in the header with item count

---

### Stage 4: Cart Review

| | |
|---|---|
| **Action** | Opens cart; reviews items and total |
| **Touchpoints** | Cart drawer or cart page |
| **Thought** | "One Pad Thai, one Spring Roll. $22. Delivery fee is showing — no surprise at checkout." |
| **Emotion** | In control |

**What the UI must do:**
- Cart shows itemised list with prices
- Subtotal, estimated delivery fee, and estimated total shown in cart — before checkout
- "Proceed to checkout" CTA is the only primary action

---

### Stage 5: Checkout

| | |
|---|---|
| **Action** | Enters delivery address; enters Stripe test card; reviews order summary |
| **Touchpoints** | Address form, payment form, order summary |
| **Thought** | "Address, card, summary — three steps. That's fine." |
| **Emotion** | Neutral — proceeding |

**What the UI must do:**
- Checkout is 3 logical steps: (1) delivery address, (2) payment, (3) order summary + confirm
- Order summary shows: restaurant name, items, subtotal, delivery fee, total — no new fees
- "Place Order" button is the final CTA — prominent, single action

---

### Stage 6: Confirmation

| | |
|---|---|
| **Action** | Taps "Place Order"; sees confirmation screen |
| **Touchpoints** | Order confirmation page |
| **Thought** | "Order confirmed. 30–40 minutes. That's it." |
| **Emotion** | Satisfied — task complete |

**What the UI must do:**
- Confirmation screen shows: order number, restaurant name, delivery address, simulated ETA
- Simulated ETA is fixed: "Your order is on its way — estimated 30–40 minutes"
- No tracking map (Wave 1 scope)
- Link to order history for future reference

---

### Journey 2 — Outcome

Darius completed his first order in under 5 minutes from search to confirmation. Auth gate was the only friction point — and was handled gracefully.

**Emotion arc:** Task-focused → Efficient → Slight friction → In control → Satisfied

---

---

## Journey 3 — Returning User: Order History Review (Priya — two weeks after first order)

**Goal:** Find the restaurant she ordered from two weeks ago so she can recommend it to a friend  
**Entry:** Signs in → account menu → order history  
**Device:** Desktop (MacBook Air)  

---

### Stage 1: Sign In

| | |
|---|---|
| **Action** | Clicks sign-in from header nav; enters email + password |
| **Touchpoints** | Sign-in modal or page |
| **Thought** | "I had an account from last time. Let me log back in." |
| **Emotion** | Routine |

**What the UI must do:**
- Sign-in accessible from persistent header nav
- Email + password only (no OAuth for Wave 1)
- Successful sign-in returns to the page she was on (not a dashboard)

---

### Stage 2: Navigate to Order History

| | |
|---|---|
| **Action** | Clicks her avatar/name in the header → "Order history" |
| **Touchpoints** | User menu dropdown, order history page |
| **Thought** | "I can see my orders here. The one from two weeks ago should be in here." |
| **Emotion** | Purposeful |

**What the UI must do:**
- User menu in header (post-auth) has "Order history" as a first-class link
- Order history page lists orders in reverse-chronological order
- Each order row shows: restaurant name, date, item count, total

---

### Stage 3: Finding the Order

| | |
|---|---|
| **Action** | Scans 2 orders; finds the right one; expands to see the itemised list |
| **Touchpoints** | Order history list, order detail expansion |
| **Thought** | "Two weeks ago, Lotus Thai Kitchen. That's the one." |
| **Emotion** | Satisfied |

**What the UI must do:**
- Each order is a row that expands to show the itemised breakdown
- Itemised view shows: each item name, quantity, price, order total
- Restaurant name in the history row is a link to the restaurant page (so Priya can share it)

---

### Journey 3 — Outcome

Priya found what she needed in two clicks from the header. The restaurant page link from order history gives her something shareable.

**Emotion arc:** Routine → Purposeful → Satisfied

---

---

## Journey Touchpoint Summary

| Screen | Journeys | Key moments |
|--------|----------|-------------|
| Homepage | J1, J2 (search) | Editorial feel, collection names, search bar prominence |
| Search Results | J2 | Filter chips, fast results, card scanability |
| Restaurant Page | J1, J2 | Hero photo, menu photos, auth gate timing |
| Auth modal (sign-in/up) | J2 | Post-sign-in cart preservation |
| Cart | J2 | Fee transparency before checkout |
| Checkout | J2 | 3-step linear flow, no surprise fees |
| Order Confirmation | J2 | Simulated ETA, order number |
| Order History | J3 | Reverse-chron list, expandable detail, restaurant link |
