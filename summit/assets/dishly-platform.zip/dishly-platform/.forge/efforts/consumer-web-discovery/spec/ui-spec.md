# dishly — Consumer Web App UI Spec

*Effort: consumer-web-discovery*
*Mode: production*
*Authored: 2026-06-05*
*Design source: [wireframes.md](design/wireframes.md), [personas.md](design/personas.md)*
*Figma file: https://www.figma.com/design/6sg8vnglQNp3o9EAM4Y6s5*
*Traces to: [BR-4](../requirements/business.md#br-4-restaurant-page-full-layout-with-hero-menu-and-reviews), [BR-9](../../dishly-wave-1/requirements/business.md#br-9-authentication-model), [BR-10](../../dishly-wave-1/requirements/business.md#br-10-discovery-ux-surfaces), [BR-11](../../dishly-wave-1/requirements/business.md#br-11-ordering-flow), [BR-12](../../dishly-wave-1/requirements/business.md#br-12-order-history), [BR-15](../../dishly-wave-1/requirements/business.md#br-15-error-states), [BR-16](../../dishly-wave-1/requirements/business.md#br-16-restaurant-page-layout)*

---

## Goal

A responsive web application that enables anonymous discovery of curated restaurants and authenticated ordering. The product's credibility rests entirely on a single signal: that every restaurant shown was placed there by someone with taste, not paid placement. Every design decision reinforces or undermines that signal.

---

## Scope

Full consumer-facing web application: 11 screens, responsive (mobile-first, desktop-optimised). No iOS/Android native app (BR-4).

---

## Design Language

dishly is not a utility. It is an editorial product. Visual decisions should reinforce that:

- **Typography:** Editorial. Large display headings for collection names and restaurant names. Body text is readable and unhurried.
- **Photography:** Food photography is the hero of every screen. The design recedes to let it lead.
- **Whitespace:** Generous. Cramped layouts signal a marketplace optimised for volume. dishly is the opposite.
- **Colour:** Dark primary (near-black), warm off-white backgrounds, one accent colour used sparingly. No bright aggressive brand colours.
- **Iconography:** Minimal. Use text labels rather than icon-only buttons wherever space permits.

### Token reference (implementation)

> **Note to implementors:** This spec uses semantic names. Map to the design system token vocabulary defined in `standards/frontend/design-tokens.md` during implementation. Tokens used here are illustrative — use the nearest semantic equivalent from the design system.

| Role | Token hint | Notes |
|------|-----------|-------|
| Page background | `background.page` | Off-white or white |
| Primary text | `text.primary` | Near-black |
| Secondary/meta text | `text.secondary` | Muted grey |
| Accent / CTA | `fill.ctaPrimary` | Brand primary, used on primary buttons |
| Border | `border.subtle` | Light dividers between sections |
| Card background | `background.card` | White or slight elevation |
| Success / confirmation | `feedback.success` | Green family |
| Destructive action | `feedback.error` | Red family |
| Hero overlay | semi-transparent dark gradient | For text readability over hero images |

### Spacing scale

Use named tokens throughout. Common values:
- `xsmall` — between inline elements (e.g. icon + label)
- `small` — between tightly related items (e.g. label + field)
- `medium` — standard component internal padding
- `large` — between content sections within a screen
- `xlarge` — between major page sections
- `xxlarge` — hero and page-level padding at tablet+

### Breakpoints

| Key | Width | Layout behaviour |
|-----|-------|-----------------|
| `base` | 0px+ | Single-column, full-width |
| `sm` | 480px+ | Slight padding increase |
| `md` | 768px+ | Two-column where applicable |
| `lg` | 1024px+ | Three-column for restaurant grids |
| `xl` | 1280px+ | Four-column for restaurant grids, max content width |

Max content width: `1200px`, centred. Full-bleed sections (hero images) extend to viewport edge.

---

## Component Reference

All components use `@rakuten-rewards/uikit` (see `standards/frontend/component-selection.md`). The components below are the primary ones used per screen — see individual screen specs for detail.

| Component | Used for |
|-----------|----------|
| `RestaurantCard` / card primitive | Restaurant cards in collections, search results |
| `HeroTopic` or equivalent | Homepage hero with search bar |
| `TextBlockTopic` | Collection section headers |
| `SimpleGrid` | Restaurant card grids |
| `MenuItemRow` | Each menu item in the restaurant page |
| `Modal` | Auth modal, cart conflict modal |
| `Drawer` | Cart drawer (right side) |
| `FormControl`, `Input` | All form fields |
| `Button` | Primary and secondary CTAs throughout |
| `StarRating` | Review stars, restaurant metadata |
| `Tabs` | Auth modal Sign In / Sign Up switch |
| `Progress` or step indicators | Checkout step indicator |
| `Skeleton` | Loading states for all data-driven sections |

---

## Screen Specifications

---

### S-01 — Homepage

**Route:** `/`  
**Auth required:** No  
**Title:** `dishly — Find food worth eating`

#### Layout

```
┌─ Header ──────────────────────────────────────────────────────────────────┐
├─ Hero (full-bleed) ────────────────────────────────────────────────────── │
├─ Collection: "Best Ramen in the City" ─────────────────────────────────── │
├─ Collection: "New Openings" ───────────────────────────────────────────── │
├─ Collection: [3rd collection] ─────────────────────────────────────────── │
└─ Footer ───────────────────────────────────────────────────────────────── │
```

#### Header

- Logo: `dishly` wordmark, left-aligned.
- Right: `Sign In` (ghost button), `Sign Up` (primary button).
- When authenticated: replace auth buttons with user avatar + name (truncated to first name) + chevron → opens user menu.
- User menu items: `Order history`, `Sign out`.
- Cart icon with badge count (0 = hidden, 1+ = shown with count).
- Header is `sticky`, stays visible on scroll. Background: `background.page` with bottom border `border.subtle`.

#### Hero Section

- Full-bleed, dark overlay gradient from bottom (for text readability).
- Background: high-quality food photography (configurable image URL in content config).
- Height: `320px` (base) → `480px` (md+).
- Content centred vertically and horizontally:
  - Display heading: `"Find food worth eating."` — `heading-display` or largest type token.
  - Subheading: `"Curated restaurants, not sponsored results."` — `text.secondary` colour, `body-lg` size.
  - Search bar: full-width on base (with horizontal padding), max-width `540px` on md+. Placeholder: `"Search restaurants or cuisines…"`. Submit button: `"Search"`.

#### Collection Section (repeated per collection)

- Section heading: Collection name (e.g. `"Best Ramen in the City"`), `heading-md` weight, left-aligned.
- `"See all"` link right-aligned on same row as heading (navigates to search pre-filtered to collection).
- Restaurant card grid:
  - `base`: 2-up horizontal scroll (cards peek to indicate scroll)
  - `md`: 3-up grid
  - `xl`: 4-up grid
- Each **RestaurantCard**:
  - Cover image: 4:3 aspect ratio. Broken URL → branded placeholder (fork icon, `background.muted`).
  - Restaurant name: `body-md-bold` or equivalent, 1 line max (truncate with ellipsis).
  - Cuisine type: `body-sm`, `text.secondary`.
  - Price range: `body-sm`, `text.secondary` (use `$` / `$$` / `$$$`).
  - Star rating: icon + rating number (e.g. `★4.8`), `body-sm`.
  - Entire card is clickable → navigates to `/restaurant/:id`.
  - Card hover: slight elevation change (shadow increase), cursor pointer.

#### States Required

| State | Behaviour |
|-------|-----------|
| Default loaded | Collections populated from config/API |
| Collections loading | Skeleton cards in collection rows |
| Collection empty (0 restaurants pass curation) | Collection row hidden entirely — not shown with 0 cards |

#### Footer

- Minimal: `About` (placeholder link), `For restaurants` (placeholder link), `© dishly 2026`.
- `text.secondary`, `body-sm`.

---

### S-02 — Search Results

**Route:** `/search?q={query}&cuisine={cuisine}&price={price}`  
**Auth required:** No  
**Title:** `"{query}" — dishly`

#### Layout

- Sticky header (same as S-01).
- Sticky search bar below header (travels with page until it hits the header, then sticks below it).
- Filter chips inline below search bar.
- Result count + result list below filters.

#### Search Bar

- Pre-filled with `q` param from URL.
- Editing and submitting updates `q` param, re-runs search.

#### Filter Chips

- **Cuisine type:** rendered as horizontal scrollable chip row. Options derived from available cuisine types in the dataset. One chip is active (filled) at a time, or "All" is the default active state.
- **Price range:** `All` (default), `$`, `$$`, `$$$`. Single-select, inline chips.
- Filtering is client-side (100 restaurants → instant). Chips update URL params.
- Active chip: `fill.ctaPrimary` background, white text. Inactive: border, transparent background.

#### Result List

- Result count: `"12 restaurants for Thai"` (or `"All restaurants"` if no query).
- Each result row:
  - Thumbnail image (4:3, `120px` wide at md+, full-width at base).
  - Restaurant name: `body-md-bold`, 1 line.
  - Cuisine type + `"Delivery available"` badge.
  - Price range + star rating inline.
  - 1-line description (truncated with ellipsis at 80 chars).
  - Entire row clickable → `/restaurant/:id`.
- At base: image above, text below (stacked card layout).
- At md+: image left (`120px`), text right (horizontal row layout).

#### Empty State

- Shown when 0 results after filtering.
- Icon + message: `"No restaurants found for "{query}" — try a different search."`
- CTA: `"Browse collections"` → navigates to `/` (homepage).

#### States Required

| State | Behaviour |
|-------|-----------|
| Loading results | Skeleton rows (3) |
| Results present | List rendered |
| Empty (no results) | Empty state component |

---

### S-03 — Restaurant Page

**Route:** `/restaurant/:id`  
**Auth required:** No (anonymous browse). Auth required for "Add to cart".  
**Title:** `"{restaurant name}" — dishly`

#### Layout (top to bottom)

1. Hero image (full-bleed)
2. Restaurant metadata block
3. Menu (sections + items)
4. Reviews

#### Hero Image

- Full-bleed, `240px` (base) → `480px` (md+) height.
- `cover_image_url` from restaurant record.
- Broken URL → grey placeholder (`background.muted`) full-width, restaurant name centred as text overlay.
- No overlay gradient on restaurant page hero (the metadata block is below, not overlaid).

#### Restaurant Metadata Block

- Restaurant name: `heading-lg` or `heading-display` — the single most prominent text on the page.
- Inline meta row: cuisine type · price range · star rating (average + review count).
- Description: `body-md`, up to 4 sentences. Not truncated.
- All within a container with `py: large` (base) → `py: xlarge` (md+) padding.

#### Menu

- Section heading `"Menu"` — `heading-md`, top border separator above.
- Menu sections (e.g. "Starters", "Ramen", "Sides", "Desserts"):
  - Section header: `body-md-bold` or `heading-sm`, with a toggle chevron.
  - All sections expanded by default at md+ (desktop).
  - On mobile (`base`): sections are collapsible. First section open by default, rest collapsed.
- Each **Menu Item Row**:
  - Image: `80×80` square, rounded corners (`border-radius.md`). Broken URL → placeholder.
  - Name: `body-md-bold`, 1 line (no truncation).
  - Description: `body-sm`, `text.secondary`, 2 lines max.
  - Price: `body-md`, `text.primary`, right-aligned.
  - `"Add to cart"` button: secondary button style, right-aligned. At base (mobile): below item text, full-width.
  - Layout: image left, text middle, price + button right. At base: stacked.

#### "Add to Cart" Auth Gate

- If user is **not** authenticated: clicking "Add to cart" opens Auth Modal (S-04). After sign-in/up, the add-to-cart action is retried automatically.
- If user **is** authenticated and cart has items **from the same restaurant**: item is added silently, cart icon count updates.
- If user is authenticated and cart has items **from a different restaurant**: Cart Conflict Modal (S-06) is shown.

#### Cart Icon Header Behaviour

- After any item is added: header cart icon shows badge count.
- Clicking cart icon at any point opens Cart Drawer (S-05) without navigating away.

#### "Menu coming soon" state

- If `menu_sections` array is empty or null: show placeholder in the menu section.
- Message: `"Menu coming soon"`, `body-sm`, `text.secondary`, centred.
- No empty `<ul>` or broken layout.

#### Reviews Section

- Section heading `"Reviews"` with top border separator.
- Average rating: large star cluster + numeric average (e.g. `★4.8`) + review count (`124 reviews`).
- 3–5 review snippets, each:
  - Star rating (filled stars).
  - Author name (`body-sm-bold`) + date (`body-sm`, `text.secondary`).
  - Review text (`body-md`), 1–3 sentences. Not truncated.
- No "See all reviews" — no pagination (BR-13).
- No review submission UI.

#### States Required

| State | Behaviour |
|-------|-----------|
| Loading | Skeleton for hero, metadata block, and first menu section |
| Loaded — full | Default as specced |
| Cover image broken | Full-width grey placeholder with restaurant name text |
| Menu item image broken | 80×80 square placeholder |
| Menu empty | "Menu coming soon" placeholder |
| Restaurant not found (404) | Generic 404 page |

---

### S-04 — Auth Modal (Sign In / Sign Up)

**Trigger:** "Add to cart" when unauthenticated; header "Sign In" / "Sign Up" buttons  
**Presentation:** Modal on desktop, bottom sheet on mobile

#### Layout

- Two tabs: `Sign In` | `Sign Up`. Default tab: Sign In.
- Switching tabs preserves email field content.

#### Sign In Tab

Fields:
- `Email address` — text input, `type="email"`, `autocomplete="email"`
- `Password` — `type="password"`, `autocomplete="current-password"`

Validation / errors (inline, below the form):
- Empty fields → `"Please fill in all fields"`
- Invalid credentials → `"Incorrect email or password"`
- Network/server error → `"Something went wrong — please try again"`

Primary CTA: `"Sign In"` (full-width primary button)

No "Forgot password" link (BR-14 — explicitly out of scope).

#### Sign Up Tab

Fields:
- `Email address` — `type="email"`, `autocomplete="email"`
- `Password` — `type="password"`, `autocomplete="new-password"`. Requirement hint below field: `"At least 8 characters"`
- `Confirm password` — `type="password"`, `autocomplete="new-password"`

Validation / errors:
- Passwords don't match → `"Passwords do not match"`
- Password too short → `"Password must be at least 8 characters"`
- Email already exists → `"An account with this email already exists — try signing in"`
- Network/server error → `"Something went wrong — please try again"`

Primary CTA: `"Create account"` (full-width primary button)

#### Post-auth behaviour

- Modal closes.
- If triggered by "Add to cart": the item is added to cart automatically.
- If triggered by header Sign In: user returns to whatever page triggered it.

#### States Required

| State | Behaviour |
|-------|-----------|
| Default | Empty fields |
| Submitting | Button in loading state (`isLoading`), fields disabled |
| Error | Inline error below form |
| Success | Modal closes, action proceeds |

---

### S-05 — Cart Drawer

**Trigger:** Cart icon in header (when cart has items); auto-opens after first item added  
**Presentation:** Right-side drawer on desktop; full-screen bottom sheet on mobile

#### Layout

- Header: `"Your Cart"` title + `×` close button.
- Restaurant name subtitle (e.g. `"From Matsuri Ramen"`).
- Item list: each item row has name, `–` / quantity / `+` controls, and `×` remove.
- Quantity `–` at 1: button is disabled but item is shown (user must tap `×` to remove).
- Fee summary:
  - `Subtotal` — sum of item prices
  - `Estimated delivery fee` — static `$3.99` for Wave 1
  - `Estimated total`
- `"Proceed to Checkout"` — full-width primary button → navigates to `/checkout`.
- Note: `"Fees are estimates and will be confirmed at checkout"` — `body-xs`, `text.secondary`.

#### Empty state

- Shown when cart has 0 items.
- Message: `"Your cart is empty."` + `"Explore restaurants"` link → `/`.

#### States Required

| State | Behaviour |
|-------|-----------|
| Empty | Empty state message + explore link |
| Has items | Item list + fee summary + checkout CTA |
| Item being added | Brief optimistic update (item appears immediately) |

---

### S-06 — Cart Conflict Modal

**Trigger:** Authenticated user adds to cart, but cart has items from a different restaurant

#### Layout

- Heading: `"Start a new order?"`
- Body: `"You have items from [Restaurant A] in your cart. Starting an order from [Restaurant B] will remove them."`
- Two buttons:
  - `"Keep current cart"` — default (primary button or right-aligned). Closes modal. Cart unchanged.
  - `"Start new order"` — secondary/ghost, destructive variant. Clears cart, adds new item, closes modal.

---

### S-07/08/09 — Checkout (3-step linear)

**Route:** `/checkout`  
**Auth required:** Yes (redirect to auth if unauthenticated)

#### Layout wrapper

- Simplified header: logo only (no nav, no cart icon).
- Step progress indicator: 3 steps — `Delivery` · `Payment` · `Review`. Current step is active/filled; completed steps show check. Future steps are inactive.
- Max content width `640px`, centred.

#### Step 1 — Delivery Address

Fields:
- `Street address` — text input
- `Apt / Suite` (optional) — text input
- `City` — text input
- `State` — select (US states)
- `ZIP code` — text input, `type="tel"`, pattern `[0-9]{5}`
- `Delivery instructions` (optional) — textarea, placeholder `"Leave at door, gate code, etc."`

CTA: `"Continue to Payment"` → advances to Step 2

Validation:
- Street address, City, State, ZIP required.
- ZIP must be 5 digits.

#### Step 2 — Payment

- Stripe Elements card input (embedded, handles card number / expiry / CVC natively).
- Note: `"This is a test environment — use card 4242 4242 4242 4242 with any future expiry"` (Wave 1, dev/beta).

CTA: `"Continue to Review"` → advances to Step 3

#### Step 3 — Order Summary + Confirm

- Read-only summary:
  - Restaurant name
  - Delivery address (with `"Edit"` link → returns to Step 1)
  - Itemised order (item name, qty, price)
  - Subtotal, delivery fee, total
- No new information appears here — final total matches what was shown in the cart.
- Error area: hidden by default. Shown on submission failure: `"Something went wrong — your order was not placed. Please try again."` Cart is preserved.

CTA: `"Place Order"` (primary, full-width on mobile) → submits order

#### Back navigation

- Step indicator links are clickable for backward navigation only (not skipping forward).
- Browser back button works between steps.

#### States Required

| State | Behaviour |
|-------|-----------|
| Loading (initial) | Skeleton for order summary |
| Form validation error | Inline error on the offending field |
| Submission in progress | "Place Order" button shows loading state, disabled |
| Submission error | Inline error above button; cart preserved |
| Success | Navigate to S-10 (order confirmation) |

---

### S-10 — Order Confirmation

**Route:** `/orders/:orderId/confirmation`  
**Auth required:** Yes

#### Layout

- Centred card layout, `max-width: 560px`.
- Success icon (✓, large, `feedback.success` colour).
- Heading: `"Order confirmed!"`
- Order number: `"Order #DIS-YYYYMMDD-NNNN"`, `body-sm`, `text.secondary`.
- Restaurant name.
- Delivery address.
- Simulated ETA: `"Your order is on its way — estimated 30–40 minutes."` — `body-md`, prominent.
- Total charged.
- Two secondary CTAs:
  - `"View order history"` → `/account/orders`
  - `"Back to home"` → `/`

No tracking map, no live status (Wave 1 scope — BR-6).

---

### S-11 — Order History

**Route:** `/account/orders`  
**Auth required:** Yes (redirect unauthenticated users to sign-in, with return URL)

#### Layout

- Page heading: `"Order History"`.
- Reverse-chronological list of orders.
- Each order row:
  - Restaurant name (link → `/restaurant/:id`).
  - Order date (formatted `"June 5, 2026"`).
  - Item count (`"2 items"`).
  - Order total.
  - Expand toggle `↓` / `↑`.
- Expanded state (inline, no separate page):
  - Itemised list: item name, qty, price per line.
  - Delivery fee.
  - Total.
- No reorder button (Wave 1 scope — BR-12).

#### Empty State

- `"No orders yet."` + `"Start exploring"` link → `/`.

#### States Required

| State | Behaviour |
|-------|-----------|
| Loading | Skeleton rows |
| Has orders | List with expand/collapse |
| Empty | Empty state + explore CTA |

---

## Global / Cross-Screen Requirements

### Error handling (BR-15)

| Scenario | Behaviour |
|----------|-----------|
| Order submission server error | Inline error on checkout Step 3; cart preserved; no partial order |
| Restaurant 404 | Generic 404 page: `"Restaurant not found"` + back to home |
| Network offline | Deferred — no offline mode in Wave 1 |

### Auth redirect

- Any route requiring auth, if unauthenticated: redirect to `/sign-in?return={encoded_path}`. After sign-in, return to the original URL.
- Exception: Cart Drawer and Auth Modal are inline and do not navigate away.

### Responsive behaviour

- All screens mobile-first. Desktop is an enhancement, not the base case.
- Minimum supported width: `320px`.
- Touch targets: minimum `44×44px` (WCAG 2.5.5 — partially applied even though WCAG compliance is deferred for Wave 1).

### Loading states

Every data-driven section must have a skeleton loading state. No spinners or blank screens. Skeletons match the shape of the loaded content (card skeletons, row skeletons).

### Image fallbacks

- Restaurant cover image: full-width grey placeholder, restaurant name text centred.
- Menu item image: `80×80` grey square placeholder.
- Never render a broken `<img>` tag.

### Accessibility (Wave 1 scope)

WCAG 2.1 AA is deferred. The following baseline still applies:
- All interactive elements are keyboard-reachable.
- All form fields have associated `<label>` elements.
- Images have `alt` text (restaurant name for cover images; item name for menu item images).
- Modal and drawer have focus trap and `Escape` dismissal.

---

## Out of Scope (UI)

- Password reset / forgot password flow (BR-14)
- Social sharing or social features
- Personalised recommendations or algorithmic ranking signals
- Reorder shortcut on order history
- Real-time delivery tracking map
- Saved addresses or payment methods
- Apple Pay / Google Pay (Wave 1 card-only)
- Review submission
- Restaurant search by distance or map view
- Wishlist / saved restaurants
