# Implementation Plan: Consumer Web App — Discovery UX

Tasks within the same wave are independent and can run in parallel.
Tasks in wave N+1 require all wave N tasks complete.

```mermaid
gantt
    title  Consumer Web App — Discovery UX Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Foundation
    API client + shared hooks       :task1, 1, 2
    Shared UI components            :task2, 1, 2

    section Homepage
    Homepage layout + collections   :task3, 2, 3
    Search bar + navigation         :task4, 2, 3
    Homepage observable             :milestone, m1, 3, 0

    section Search
    Search results page             :task5, 3, 4
    Cuisine/price filters           :task6, 3, 4
    Search observable               :milestone, m2, 4, 0

    section Restaurant Page
    Restaurant page layout          :task7, 4, 5
    Menu sections + add to cart     :task8, 4, 5
    Cart localStorage hook          :task9, 4, 5
    Restaurant page observable      :milestone, m3, 5, 0
```

---

## Wave 1 — Foundation

### TASK-001 `[auto]` `[wave:1]`

Create `frontend/src/api/client.js` — thin fetch wrapper that prepends `http://localhost:3001/dishly/v1`, attaches `Authorization: Bearer <token>` from localStorage when present, and returns parsed JSON; plus custom hooks: `useCollections()`, `useRestaurants(params)`, `useRestaurant(id)`, `useCuisines()`, `useNeighbourhoods()`.

**Satisfies:** TR-1, TR-2
**Standards:** none
**Required tests:** none (scaffolding task)
**Completed:** no-vcs

---

### TASK-002 `[auto]` `[wave:1]`

Create shared UI components in `frontend/src/components/`: `RestaurantCard.jsx` (cover image, name, cuisine, neighbourhood, price range, avg rating), `LoadingSpinner.jsx`, `ErrorMessage.jsx`, `EmptyState.jsx`.

**Satisfies:** BR-1, BR-2
**Standards:** none
**Required tests:** none (scaffolding task)
**Completed:** no-vcs

---

## Wave 2 — Homepage

### TASK-003 `[auto]` `[wave:2]`

Build `frontend/src/pages/Home.jsx` — fetches and renders curated collections as horizontal scrollable rows of `RestaurantCard`s; handles loading and empty states.

**Satisfies:** BR-1, BR-3
**Depends on:** TASK-001, TASK-002
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

### TASK-004 `[auto]` `[wave:2]`

Build `frontend/src/components/NavBar.jsx` with the dishly wordmark, a search input that navigates to `/search?q=` on submit, and a sign-in link; render it in `App.jsx` above all routes.

**Satisfies:** BR-2, BR-4
**Depends on:** TASK-001
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

## Wave 3 — Search Results

### TASK-005 `[auto]` `[wave:3]`

Build `frontend/src/pages/Search.jsx` — reads `?q=` from URL, calls `GET /restaurants?q=`, renders results as `RestaurantCard` grid, shows friendly empty state when no results.

**Satisfies:** BR-2, BR-5
**Depends on:** TASK-001, TASK-002
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

### TASK-006 `[auto]` `[wave:3]`

Add cuisine-type and price-range filter controls to `Search.jsx` — fetches `/cuisines` on mount, renders filter pills, updates query params and re-fetches on change.

**Satisfies:** BR-2
**Depends on:** TASK-005
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

## Wave 4 — Restaurant Page + Cart

### TASK-007 `[auto]` `[wave:4]`

Build `frontend/src/pages/Restaurant.jsx` — fetches `/restaurants/:id`, renders hero image, name, cuisine, neighbourhood, price, rating, description, and review snippets (up to 5).

**Satisfies:** BR-3, BR-6
**Depends on:** TASK-001, TASK-002
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

### TASK-008 `[auto]` `[wave:4]`

Add menu section rendering to `Restaurant.jsx` — groups items by section, shows item name, description, price (formatted from value/scale), photo, and inline "Add to cart" button.

**Satisfies:** BR-3, BR-7
**Depends on:** TASK-007, TASK-009
**Standards:** none
**Required tests:** none (UI task)
**Completed:** no-vcs

---

### TASK-009 `[auto]` `[wave:4]`

Create `frontend/src/hooks/useCart.js` — localStorage-backed cart hook: `cart`, `addItem(item, restaurant)`, `clearCart()`, `cartCount`; enforces single-restaurant rule (prompts then clears on restaurant switch).

**Satisfies:** BR-7, TR-3
**Depends on:** TASK-001
**Standards:** none
**Required tests:** none (scaffolding task)
**Completed:** no-vcs
