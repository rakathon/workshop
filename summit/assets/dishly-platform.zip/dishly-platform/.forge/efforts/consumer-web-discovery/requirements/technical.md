# Technical Requirements — Consumer Web App — Discovery UX

*Effort: consumer-web-discovery*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-06*

---

## TR-1: React + Vite frontend stack

*Traces to: [BR-1](business.md#br-1-homepage-with-curated-collections-and-search-bar), [BR-6](business.md#br-6-responsive-web-desktop-and-mobile)*

The consumer web app is a React single-page application built with Vite.

| Layer | Technology | Version constraint |
|-------|-----------|-------------------|
| UI framework | React | 18+ |
| Build tool | Vite | 5+ |
| Routing | React Router v6 | client-side only |
| HTTP client | native `fetch` via shared `api/client.js` | no axios |
| State | React `useState` / `useEffect` hooks | no Redux |

**Constraints:**
- No server-side rendering — Vite dev server serves a SPA
- All API calls go through `frontend/src/api/client.js` which prepends `http://localhost:3001/dishly/v1` and attaches `Authorization: Bearer <token>` from `localStorage.dishly_token` when present
- Express backend serves `index.html` catch-all for all non-`/dishly/v1/` routes so direct URL navigation works

---

## TR-2: Client-side routing

*Traces to: [BR-1](business.md#br-1-homepage-with-curated-collections-and-search-bar), [BR-3](business.md#br-3-search-results-page-with-keyword-search-and-filters), [BR-4](business.md#br-4-restaurant-page-full-layout-with-hero-menu-and-reviews), [BR-5](business.md#br-5-anonymous-discovery-no-auth-gate-on-browse)*

React Router v6 defines all routes in `frontend/src/App.jsx`.

| Route | Component | Auth required |
|-------|-----------|--------------|
| `/` | `Home` | No |
| `/search` | `Search` | No |
| `/restaurants/:id` | `Restaurant` | No |
| `/cart` | `Cart` | No (shows empty state) |
| `/checkout` | `Checkout` | Checked at submit |
| `/orders/:id` | `OrderConfirmation` | Yes |
| `/account/orders` | `OrderHistory` | Yes (redirect to /login) |
| `/account` | `Account` | Yes (redirect to /login) |
| `/login` | `Login` | No |
| `/register` | `Register` | No |

**Constraints:**
- No auth redirect on the discovery routes (homepage, search, restaurant) — those are fully anonymous
- Unauthenticated access to `/account/orders` and `/account` redirects to `/login`
- React Router `<BrowserRouter>` used (not hash router); direct URL access works via Express catch-all

---

## TR-3: Shared API hooks

*Traces to: [BR-1](business.md#br-1-homepage-with-curated-collections-and-search-bar), [BR-3](business.md#br-3-search-results-page-with-keyword-search-and-filters), [BR-4](business.md#br-4-restaurant-page-full-layout-with-hero-menu-and-reviews)*

Custom React hooks in `frontend/src/api/hooks.js` encapsulate all data fetching.

| Hook | Endpoint | Used by |
|------|----------|---------|
| `useCollections()` | `GET /collections` | Home |
| `useRestaurants(params)` | `GET /restaurants[?q=&cuisine_id=&price_range=]` | Search, Home (chip fallback) |
| `useRestaurant(id)` | `GET /restaurants/:id` | Restaurant |
| `useCuisines()` | `GET /cuisines` | Search filters |
| `useNeighbourhoods()` | `GET /neighbourhoods` | Search filters |

**Constraints:**
- All hooks follow the pattern `{ data, loading, error }` returned from a shared `useApi(fetcher, deps)` base hook
- `loading = true` on initial fetch and on deps change; `error` holds the message string on failure
- Cancelled fetches (component unmount during in-flight request) set `cancelled = true` and skip state updates

---

## TR-4: Shared UI components

*Traces to: [BR-1](business.md#br-1-homepage-with-curated-collections-and-search-bar), [BR-4](business.md#br-4-restaurant-page-full-layout-with-hero-menu-and-reviews), [BR-7](business.md#br-7-error-states-for-discovery-surfaces)*

Shared presentational components in `frontend/src/components/`.

| Component | Props | Notes |
|-----------|-------|-------|
| `RestaurantCard` | `{ restaurant }` | Cover image with `onError` placeholder; links to `/restaurants/:id` |
| `LoadingSpinner` | none | Centered spinner, used by all data-loading pages |
| `ErrorMessage` | `{ message }` | Red-toned error block |
| `EmptyState` | `{ message }` | Centred empty-state with optional CTA |
| `NavBar` | none | Reads auth state from localStorage; shows avatar+dropdown when authed, Sign in/Join when not |

**Constraints:**
- `RestaurantCard` image uses `onError` handler to hide broken `<img>` and show a styled CSS placeholder div — no broken img icon shown to users
- `NavBar` is rendered once in `App.jsx` above all routes; it is not re-mounted on navigation
- Cart badge in `NavBar` subscribes to the `dishly:cart-updated` window event for real-time updates

---

## TR-5: Homepage collection filtering

*Traces to: [BR-2](business.md#br-2-cuisine-filter-chips-on-homepage)*

Cuisine chip state is managed in `Home.jsx` with `useState`. Filtering is client-side — no additional API call for chips that have matching collection results.

**Constraints:**
- `CHIPS` array maps display label (e.g. "Thai") to cuisine name in seed data (e.g. `'Thai'`) via `CHIP_TO_CUISINE` map
- If filtering collections in-place yields 0 results for a chip, `useRestaurants({ q: chipCuisine })` is called as a fallback and results rendered as a flat grid under a `"<Cuisine> Restaurants"` heading
- Active chip state is `string` (chip label); defaults to `'All'`
- Chip click does NOT navigate — URL stays at `/`
- `aria-pressed` attribute reflects active state for accessibility

---

## TR-6: Search page

*Traces to: [BR-3](business.md#br-3-search-results-page-with-keyword-search-and-filters)*

`frontend/src/pages/Search.jsx` — renders at `/search`.

**Constraints:**
- Query string `?q=` read via `useSearchParams()` on mount and on change
- Filter state (selected cuisine ID, price range) held in `useState`; applied as params to `useRestaurants()`
- Filter chips sourced from `useCuisines()` and hard-coded price range options (`['$', '$$', '$$$']`)
- Result count rendered as `"{n} restaurants"` above the result list
- Empty state shown when `data.length === 0` with "Browse collections" link to `/`
- Search input in navbar is pre-populated with `?q=` value on the search page

---

## TR-7: Restaurant page

*Traces to: [BR-4](business.md#br-4-restaurant-page-full-layout-with-hero-menu-and-reviews), [BR-8](business.md#br-8-cart-state-initiated-from-restaurant-page)*

`frontend/src/pages/Restaurant.jsx` — renders at `/restaurants/:id`.

**Constraints:**
- Hero image: `<img className="restaurant-hero__img">` — `onError` falls back to a placeholder
- Menu item images: rendered only when `item.image_url` is truthy; shows `.menu-item__img--placeholder` div otherwise
- `addItem()` from `useCart` is called on "Add to cart" click — no auth check at this layer (auth gate is at checkout submit per BR-4 and the verification report gap G-1 fix)
- Menu sections not collapsed by default on desktop; mobile collapse is CSS-driven (`@media` breakpoint) — no JS toggle required for Wave 1
- `formatPrice(value, scale)` utility converts integer price tuple to display string (e.g. `1600, 2` → `"$16.00"`)

---

## TR-8: Responsive layout and design tokens

*Traces to: [BR-6](business.md#br-6-responsive-web-desktop-and-mobile)*

CSS custom properties defined in `frontend/src/index.css` implement the dishly design token system.

**Key tokens:**
| Token | Value | Usage |
|-------|-------|-------|
| `--color-primary` | `#8529CD` | Brand purple; nav, CTAs, active chips |
| `--color-accent` | `#FF0044` | Red; badges, "new" labels |
| `--color-surface` | `#FFFFFF` | Card backgrounds |
| `--color-bg` | `#FFFFFF` | Page background |
| `--color-border` | `#E0E0E0` | Dividers |

**Breakpoints:**
| Name | Width | Grid columns (restaurant cards) |
|------|-------|--------------------------------|
| mobile | < 768px | 2 |
| tablet | 768–1099px | 3 |
| desktop | 1100px+ | 4 |

**Constraints:**
- All buttons use `border-radius: 9999px` (pill shape) per design spec
- Card `border-radius: 12px`
- Touch targets ≥ 44×44px on all interactive elements
- No horizontal scroll at 390px viewport — verified by Playwright E2E tests (SC-10)
