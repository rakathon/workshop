# PRD: Consumer Web App — Discovery UX

*Product / Effort: consumer-web-discovery*
*Last updated: 2026-06-07*

---

## Problem Statement

Quality-conscious urban consumers who order food delivery 2–4× per week cannot discover restaurants worth ordering from on a single trusted surface. Incumbent platforms bury quality restaurants behind paid placements, forcing users to context-switch across Yelp, Instagram, and DoorDash just to decide where to eat. Three distinct personas experience this differently: Maya (the intentional orderer) wants editorial curation she can trust; Darius (the efficient professional) wants search-and-filter that respects his time; Priya (the explorer) wants a platform with genuine taste that doesn't look like every other food app.

dishly's consumer web app is the front door to all three journeys. This effort delivers the full discovery UX — homepage with curated collections, keyword search with cuisine/price filters, and restaurant pages with full menus — as a responsive web application that works on desktop and mobile browsers without a native app. The discovery surface must earn trust within 10 seconds through editorial naming, food photography quality, and the explicit absence of "sponsored" signals. This effort stops at the order entry point; the checkout and order flow are owned by the `native-ordering-checkout` epic.

---

## Goals

1. All three discovery surfaces functional at launch — measured by homepage (curated collections + search bar), search results (keyword + filters), and restaurant page (hero, menu, reviews) all render correctly against seeded data with no JS errors
2. Anonymous browsing with no auth gate — measured by 0 auth prompts on any discovery surface; account gate fires only at cart/checkout as confirmed by end-to-end test
3. Responsive and usable on desktop and mobile — measured by all screens functional on Chrome desktop (1440px), Chrome mobile (390px), and Safari mobile (390px) without layout breakage
4. Restaurant page earns a decision in under 4 minutes — measured by hero image, name, cuisine, price, rating, description, ≥1 menu section with item photos, and ≥3 review snippets all render above the fold or within one scroll on desktop
5. Search returns relevant results in under 2 seconds — measured by `GET /restaurants?q=` response + React render completes in <2s against the 100-restaurant seed dataset on localhost

---

## Non-Goals

- We are not building a native iOS or Android app — web-only; no app store submission
- We are not building personalisation or algorithmic ranking — curation is editorial only; no recommendation engine, no user behaviour signals
- We are not building a review submission UI — reviews are seeded data only; no user-generated content in Wave 1
- We are not building an admin or CMS for collections — collections are edited via `data/collections.json`; no web interface
- We are not building the checkout or order flow — that is owned by `native-ordering-checkout`; this effort ends at "Add to cart"
- We are not building performance SLAs or WCAG compliance — deferred to Wave 2; local dev performance is sufficient for closed beta

---

## Success Metrics

### Leading Indicators (early signal)

- Homepage engagement rate: % of sessions that click into at least one restaurant page (target: ≥60%)
- Search usage rate: % of sessions that use the search bar or cuisine filter chips (target: ≥30%)
- Restaurant page depth: % of restaurant page sessions that scroll past the menu section (target: ≥50%)
- Image load success rate: % of restaurant card and menu item images that render with naturalWidth > 0 (target: ≥95%)

### Lagging Indicators (final outcome)

- Add-to-cart rate at 4 weeks: ≥30% of restaurant page sessions result in at least one item added to cart
- Zero broken discovery surfaces: no homepage, search, or restaurant page renders a blank screen or unhandled error during the beta window
- Beta user trust signal: at 4 weeks, beta users report (qualitatively) that the discovery surface feels editorially curated, not like a generic delivery app

---

## Open Questions

None identified at this time. Persona definitions, UX strategy, wireframes, user flows, and the UI spec are all documented in `spec/design/` and `spec/ui-spec.md`. Engineering decisions are resolved in the parent initiative's TRs (TR-1 through TR-11).

---

## Timeline / Dependencies

- **Target:** Wave 1 closed beta launch
- **Dependencies:**
  - `project-scaffold-local-dev-infra` — React dev server, SQLite, start.sh must exist before any frontend can be built
  - `core-backend-apis` — `GET /collections`, `GET /restaurants`, `GET /restaurants/:id`, `GET /cuisines`, `GET /neighbourhoods` must be live before discovery surfaces can render real data

---

## Requirements

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.
