# Business Requirements: Consumer Web App — Discovery UX

*Product / Effort: consumer-web-discovery*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Homepage with curated collections and search bar

**Priority:** P0

The homepage is the primary editorial entry point. It renders curated restaurant collections (e.g. "Best Ramen in the City", "New Openings", "Under $15") with a prominent search bar. Collections are loaded from the backend and each contains restaurant cards with cover photo, name, cuisine, neighbourhood, price range, and average rating.

**Acceptance Criteria:**
- [ ] Homepage renders ≥1 curated collection with restaurant cards on page load with no auth required
- [ ] Each restaurant card shows: cover image, name, cuisine type, neighbourhood, price range, and star rating
- [ ] A prominent search bar is visible above or within the hero section
- [ ] Clicking a restaurant card navigates to the restaurant page
- [ ] Empty or zero-restaurant collections are not rendered

---

## BR-2: Cuisine filter chips on homepage

**Priority:** P0

The homepage provides cuisine-type filter chips (e.g. All, Ramen, Thai, Pizza, Indian) that filter the displayed collections in-place without navigating away. Selecting a chip narrows the visible restaurants to those matching that cuisine; selecting "All" resets the view.

**Acceptance Criteria:**
- [ ] Cuisine chips are visible below the hero search bar on the homepage
- [ ] Clicking a chip filters the collections grid to matching restaurants without a page navigation
- [ ] The active chip has a visually distinct state (e.g. filled background)
- [ ] Selecting "All" restores the full unfiltered collections view
- [ ] URL does not change when a chip is selected

---

## BR-3: Search results page with keyword search and filters

**Priority:** P0

The search results page (`/search?q=`) displays restaurants matching a keyword query. Inline filter chips for cuisine type and price range allow narrowing results. Results show as a list with thumbnail image, name, cuisine, neighbourhood, rating, and price range.

**Acceptance Criteria:**
- [ ] Typing in the search bar and submitting navigates to `/search?q=<query>`
- [ ] Results show restaurants whose name or menu item names match the query (case-insensitive)
- [ ] Cuisine type and price range filter chips are visible and functional above the result list
- [ ] Each result row shows: thumbnail image, name, cuisine, neighbourhood, rating, and price range
- [ ] An empty state message is shown when no results match: "No restaurants found for '[query]'"
- [ ] A result count label is visible above the result list

---

## BR-4: Restaurant page — full layout with hero, menu, and reviews

**Priority:** P0

The restaurant page is the primary decision surface. It renders: full-width hero image, restaurant name/cuisine/price/rating/description, a full menu grouped by section with item photos and "Add to cart" buttons, and 3–5 seeded review snippets.

**Acceptance Criteria:**
- [ ] Hero image renders full-width at the top of the page; broken URL shows a placeholder
- [ ] Restaurant name, cuisine type, price range, and average star rating are visible below the hero
- [ ] Short restaurant description and address are displayed
- [ ] Menu is grouped by named sections (e.g. Starters, Mains, Desserts)
- [ ] Each menu item shows: name, description, price, photo (or placeholder), and an "Add to cart" button
- [ ] 3–5 seeded review snippets are displayed with author name, star rating, text, and date
- [ ] Menu sections are collapsible on mobile viewport widths

---

## BR-5: Anonymous discovery — no auth gate on browse

**Priority:** P0

Any visitor can browse the full discovery surface without signing in. No account prompt, modal, or gate appears on the homepage, search results, or restaurant page. The auth gate fires only when a user attempts to add an item to cart or proceed to checkout.

**Acceptance Criteria:**
- [ ] Homepage, search results, and restaurant pages load fully for unauthenticated users
- [ ] No sign-in modal, banner, or redirect appears on any discovery surface
- [ ] Authenticated and unauthenticated users see identical discovery content
- [ ] The only surface that requires auth is the add-to-cart / checkout action

---

## BR-6: Responsive web — desktop and mobile

**Priority:** P0

The consumer web app is a responsive web application accessible from any modern browser. It must be fully functional and visually correct on both desktop and mobile browser widths.

**Acceptance Criteria:**
- [ ] All three discovery surfaces (homepage, search, restaurant page) are usable at 1440px desktop and 390px mobile viewport widths
- [ ] Restaurant card grids reflow correctly: 4-column on desktop, 2-column on tablet, 1-column on mobile
- [ ] No horizontal scroll or layout overflow at any tested viewport width
- [ ] Touch targets are ≥44×44px on mobile for all interactive elements

---

## BR-7: Error states for discovery surfaces

**Priority:** P0

Discovery surfaces handle error and empty states gracefully. No blank page, unhandled JS error, or broken layout is shown to users when data is unavailable or a query returns no results.

**Acceptance Criteria:**
- [ ] Search with no matching results shows a friendly empty state with a "Browse collections" CTA
- [ ] A restaurant page with no menu items shows "Menu coming soon" placeholder — not a blank section
- [ ] A broken restaurant cover image URL shows a placeholder graphic — not a broken img icon
- [ ] API errors (failed fetch) show a human-readable error message, not a raw status code

---

## BR-8: Cart state initiated from restaurant page

**Priority:** P0

The business must ensure that a visitor can initiate a cart from the restaurant page and carry that cart into the checkout flow — so that order intent captured during discovery is not lost. Unauthenticated users who express intent to order must be prompted to sign in, after which their selected items are preserved.

**Acceptance Criteria:**
- [ ] Each menu item's "Add to cart" button adds the item to a persistent cart that survives page navigation
- [ ] Adding an item from a different restaurant than the current cart prompts a conflict confirmation
- [ ] The cart item count is visible in the navigation and updates when items are added
- [ ] Unauthenticated users who attempt to add to cart are prompted to sign in; their selected items are preserved after authentication
