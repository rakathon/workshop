# User Stories: Consumer Web App — Discovery UX

*Product / Effort: consumer-web-discovery*
*Last updated: 2026-06-07*

---

## Maya — The Intentional Orderer (editorial browsing)

**US-1:** As Maya, I want to browse curated restaurant collections on the homepage so that I can discover somewhere new without knowing exactly what I'm looking for.

**Acceptance Criteria:**
- [ ] Homepage renders ≥1 named collection (e.g. "Best Ramen in the City") with restaurant cards on load
- [ ] Each card shows a food photo, restaurant name, cuisine, and price range
- [ ] No sign-in prompt appears while browsing

---

**US-2:** As Maya, I want to view a restaurant page with a full-width hero photo, description, and review snippets so that I can decide whether a restaurant is worth ordering from before committing.

**Acceptance Criteria:**
- [ ] Hero image renders full-width at the top of the restaurant page
- [ ] Restaurant name, cuisine, price range, and star rating are visible
- [ ] 3–5 review snippets with author, rating, and text are displayed
- [ ] The page loads without requiring a sign-in

---

**US-3:** As Maya, I want to see a complete menu with item photos, descriptions, and prices so that I can evaluate dishes visually before adding to cart.

**Acceptance Criteria:**
- [ ] Menu is grouped into named sections (e.g. Starters, Mains)
- [ ] Each item shows: photo (or placeholder), name, description, and price
- [ ] An "Add to cart" button is present inline on each item
- [ ] No separate item detail page is required — all info is visible on the restaurant page

---

## Darius — The Efficient Professional (search-first)

**US-4:** As Darius, I want to search for a cuisine type and get a filtered list of results so that I can find a restaurant quickly without browsing collections.

**Acceptance Criteria:**
- [ ] Typing in the search bar and pressing Enter navigates to `/search?q=<query>`
- [ ] Results show within 2 seconds on localhost against the seed dataset
- [ ] Each result shows restaurant name, cuisine, neighbourhood, rating, and price range
- [ ] A result count label is visible above the list

---

**US-5:** As Darius, I want to filter search results by cuisine type and price range so that I can narrow options to exactly what I want without scrolling through irrelevant results.

**Acceptance Criteria:**
- [ ] Cuisine type and price range filter chips are visible above the search results list
- [ ] Clicking a filter chip narrows the result list in real-time
- [ ] Active filter chips have a visually distinct state
- [ ] Removing a filter restores the unfiltered result set

---

**US-6:** As Darius, I want a clear empty state when my search returns no results so that I know to try a different query rather than assuming the page is broken.

**Acceptance Criteria:**
- [ ] A friendly message is shown: "No restaurants found for '[query]'"
- [ ] A "Browse collections" CTA links back to the homepage
- [ ] No blank page, spinner, or error toast is shown for zero results

---

## Priya — The Explorer (homepage discovery)

**US-7:** As Priya, I want the homepage to feel editorial — with strong collection names and beautiful food photography — so that I trust the platform has genuine taste and want to keep browsing.

**Acceptance Criteria:**
- [ ] Collection titles are editorial and specific (e.g. "Under $15 a Dish", not "Affordable Food")
- [ ] Restaurant card cover images are displayed prominently; broken images show a styled placeholder — not a broken icon
- [ ] No "Sponsored" labels, paid-placement badges, or ranking-weight indicators appear anywhere on the page

---

**US-8:** As Priya, I want to filter the homepage by cuisine type without leaving the page so that I can narrow the collections to what I'm in the mood for while still feeling like I'm browsing.

**Acceptance Criteria:**
- [ ] Cuisine filter chips are visible on the homepage below the hero
- [ ] Clicking a chip filters the collections grid in-place (no page navigation)
- [ ] The URL does not change when a chip is selected
- [ ] The active chip is visually highlighted

---

## Anonymous Visitor (cross-persona)

**US-9:** As an anonymous visitor, I want to browse restaurants and menus without being asked to sign in so that I can make a decision about what I want before I commit to creating an account.

**Acceptance Criteria:**
- [ ] Homepage, search results, and restaurant pages all load for unauthenticated users
- [ ] No sign-in modal, banner, or redirect appears on any discovery surface
- [ ] The auth prompt appears only when the user attempts to add an item to cart

---

**US-10:** As an anonymous visitor on mobile, I want the discovery surfaces to be fully usable on my phone so that I can discover and evaluate restaurants on the go.

**Acceptance Criteria:**
- [ ] Homepage, search, and restaurant pages render correctly at 390px viewport width
- [ ] All touch targets (buttons, links, cards) are ≥44×44px
- [ ] Menu sections on the restaurant page are collapsible on mobile
- [ ] No horizontal scroll or layout overflow at 390px

---
