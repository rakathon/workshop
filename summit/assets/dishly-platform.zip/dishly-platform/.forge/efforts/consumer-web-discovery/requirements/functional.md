# Functional Requirements — Consumer Web App — Discovery UX

*Effort: consumer-web-discovery*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Render curated collections with restaurant cards on homepage

*Traces to: [BR-1](business.md#br-1-homepage-with-curated-collections-and-search-bar)*

The system must load curated restaurant collections from the backend and render each collection as a named group of restaurant cards on the homepage. Collections containing zero restaurants must not be displayed. Each card must include cover image, name, cuisine type, neighbourhood, price range, and star rating.

---

## FR-2: Render search bar on homepage

*Traces to: [BR-1](business.md#br-1-homepage-with-curated-collections-and-search-bar)*

The system must render a search bar in the hero area of the homepage. Submitting the search bar must navigate to the search results page with the query reflected in the URL.

---

## FR-3: Filter homepage collections by cuisine type in-place

*Traces to: [BR-2](business.md#br-2-cuisine-filter-chips-on-homepage)*

The system must render cuisine filter chips on the homepage and, when a chip is selected, filter the visible restaurant cards to those matching that cuisine type without performing a page navigation. Selecting the "All" chip must restore the full unfiltered view.

---

## FR-4: Display search results page for keyword queries

*Traces to: [BR-3](business.md#br-3-search-results-page-with-keyword-search-and-filters)*

The system must render a search results page at `/search?q=<query>` that lists restaurants whose name or menu item names match the query (case-insensitive). Each result must include thumbnail image, name, cuisine, neighbourhood, rating, and price range. A result count must be displayed above the list.

---

## FR-5: Filter search results by cuisine type and price range

*Traces to: [BR-3](business.md#br-3-search-results-page-with-keyword-search-and-filters)*

The system must render cuisine type and price range filter controls above the search result list. Applying a filter must narrow the displayed results in real-time without a full page reload.

---

## FR-6: Display empty state for zero search results

*Traces to: [BR-3](business.md#br-3-search-results-page-with-keyword-search-and-filters)*

When a search query returns no matching restaurants, the system must display the message "No restaurants found for '[query]'" rather than a blank list or error state.

---

## FR-7: Render restaurant page with hero, details, menu, and reviews

*Traces to: [BR-4](business.md#br-4-restaurant-page--full-layout-with-hero-menu-and-reviews)*

The system must render a restaurant page that includes: a full-width hero image, restaurant name, cuisine type, price range, average star rating, short description, and address. Menu items must be grouped into named sections, and each item must display name, description, price, and photo. When no cover image URL is valid, a placeholder graphic must be shown.

---

## FR-8: Display seeded review snippets on restaurant page

*Traces to: [BR-4](business.md#br-4-restaurant-page--full-layout-with-hero-menu-and-reviews)*

The system must display 3–5 seeded review snippets on each restaurant page. Each snippet must include author name, star rating, review text, and date.

---

## FR-9: Allow unauthenticated access to all discovery surfaces

*Traces to: [BR-5](business.md#br-5-anonymous-discovery--no-auth-gate-on-browse)*

The system must serve the homepage, search results page, and restaurant page to unauthenticated users without triggering a sign-in prompt, modal, redirect, or any auth gate. Authentication must only be required when a user attempts to add an item to cart.

---

## FR-10: Render discovery surfaces at desktop and mobile viewport widths

*Traces to: [BR-6](business.md#br-6-responsive-web--desktop-and-mobile)*

The system must render all three discovery surfaces (homepage, search results, restaurant page) correctly at both 1440px (desktop) and 390px (mobile) viewport widths. Restaurant card grids must reflow to 4-column on desktop, 2-column on tablet, and 1-column on mobile. Menu sections on the restaurant page must be collapsible on mobile viewports.

---

## FR-11: Handle error and empty states on discovery surfaces

*Traces to: [BR-7](business.md#br-7-error-states-for-discovery-surfaces)*

When a data fetch fails, the system must display a human-readable error message rather than a raw HTTP status code or blank page. A restaurant page with no menu items must show a "Menu coming soon" placeholder. A broken image URL must render a placeholder graphic rather than a broken image indicator.

---

## FR-12: Add items to cart from restaurant page

*Traces to: [BR-8](business.md#br-8-cart-state-initiated-from-restaurant-page)*

The system must allow a user to add a menu item to their cart from the restaurant page. The cart must persist across page navigations within the session. The navigation bar must reflect the current cart item count and update immediately when an item is added.

---

## FR-13: Prompt sign-in for unauthenticated cart actions

*Traces to: [BR-8](business.md#br-8-cart-state-initiated-from-restaurant-page)*

When an unauthenticated user attempts to add an item to cart, the system must prompt them to sign in. After successful authentication, the system must preserve the item the user intended to add and allow them to proceed without repeating the add-to-cart action.

---

## FR-14: Confirm cart conflict when switching restaurants

*Traces to: [BR-8](business.md#br-8-cart-state-initiated-from-restaurant-page)*

When a user attempts to add an item from a different restaurant than the one already in their cart, the system must present a conflict confirmation before replacing the existing cart contents.
