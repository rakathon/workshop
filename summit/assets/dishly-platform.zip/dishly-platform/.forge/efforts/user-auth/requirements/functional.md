# Functional Requirements — User Accounts + Auth

*Effort: user-auth*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Discovery routes accessible without authentication

*Traces to: [BR-1](business.md#br-1-anonymous-discovery-account-required-at-checkout)*

The system must allow unauthenticated requests to all discovery routes (homepage, search, restaurant listing, restaurant detail, and menu endpoints) without requiring any credential.

---

## FR-2: Auth gate triggered at cart and checkout

*Traces to: [BR-1](business.md#br-1-anonymous-discovery-account-required-at-checkout)*

When an unauthenticated user attempts to add an item to cart or proceed to checkout, the system must interrupt the action and present an authentication prompt. After successful sign-in, the system must resume the interrupted action without loss of cart state.

---

## FR-3: User registration with email and password

*Traces to: [BR-2](business.md#br-2-emailpassword-registration-and-login)*

The system must accept a registration request with an email address and password, validate that the email is not already registered and the password meets minimum length, persist the new account, and return a session credential on success.

---

## FR-4: Duplicate email registration rejected

*Traces to: [BR-2](business.md#br-2-emailpassword-registration-and-login)*

When a registration request is submitted with an email address that already exists in the system, the system must reject the request and return a conflict error with a human-readable message.

---

## FR-5: User sign-in with email and password

*Traces to: [BR-2](business.md#br-2-emailpassword-registration-and-login)*

The system must accept a sign-in request with an email and password, verify the credentials, and return a session credential on success. On failure, the system must return an authentication error that does not indicate whether the email or password was incorrect.

---

## FR-6: Order endpoints protected by authentication

*Traces to: [BR-4](business.md#br-4-order-history-visible-to-authenticated-user-only)*

The system must reject requests to order creation and order retrieval endpoints that do not include a valid session credential, returning an unauthorized error.

---

## FR-7: Order history scoped to the authenticated user

*Traces to: [BR-4](business.md#br-4-order-history-visible-to-authenticated-user-only)*

When an authenticated user requests order history, the system must return only orders belonging to that user. Requests attempting to access another user's orders must be denied.
