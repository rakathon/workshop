# PRD: User Accounts + Auth

*Product / Effort: user-auth*
*Last updated: 2026-06-07*

---

## Problem Statement

dishly's ordering flow requires authenticated users, but the discovery surface must remain fully open to anonymous visitors. Without an auth layer, any user who tries to add to cart or check out has no account to place the order under, and order history is impossible to scope to an individual. At the same time, placing the auth gate too early — at browse time rather than at checkout — would directly contradict the product's core value proposition of frictionless discovery.

This effort delivers the minimum auth layer needed for Wave 1: email/password registration and login that returns a JWT, a `requireAuth` Express middleware that protects order endpoints, and a frontend auth gate that fires at cart/checkout only. No external auth provider, no OAuth, no email infrastructure, no password reset. The goal is a simple, correct, locally-runnable auth system that can be extended in Wave 2 without a rebuild.

---

## Goals

1. Register and login work end-to-end — measured by `POST /auth/register` returns 201 with `{user, token}` and `POST /auth/login` returns 200 with `{user, token}` for valid credentials
2. Discovery routes remain open to anonymous users — measured by `GET /restaurants`, `GET /collections`, `GET /restaurants/:id` return 200 with no `Authorization` header
3. Order endpoints are protected — measured by `POST /orders`, `GET /orders/:id`, `GET /users/me/orders` all return 401 with no or invalid token
4. JWT is the only credential — measured by no session cookies, no third-party auth SDK, no OAuth callback routes exist anywhere in the codebase
5. Duplicate email registration returns a clear error — measured by re-registering a known email returns 409 with a human-readable error message

---

## Non-Goals

- We are not building password reset or "forgot password" — no email infrastructure, no SMTP, no reset tokens in Wave 1
- We are not integrating a third-party auth provider — no Auth0, Firebase Auth, Cognito, or OAuth in Wave 1
- We are not building email verification — accounts are usable immediately after registration with no confirmation step
- We are not building social login (Google, Apple) — email/password only
- We are not building session management beyond JWT expiry — no refresh tokens, no server-side session store
- We are not building an account settings UI — users cannot change their email or password in Wave 1

---

## Success Metrics

### Leading Indicators (early signal)

- Registration success rate: % of `POST /auth/register` calls that return 201 (target: 100% for valid payloads)
- Login success rate: % of `POST /auth/login` calls with correct credentials that return 200 (target: 100%)
- Auth gate conversion: % of unauthenticated users who encounter the checkout auth gate and complete sign-up or sign-in (target: ≥60%)

### Lagging Indicators (final outcome)

- Zero P0 auth bugs (auth failures allowing unauthorized access, token leakage, or session confusion) during the 4-week beta
- All order endpoints correctly return 401 for unauthenticated requests — confirmed by automated test suite (8/8 auth tests passing)

---

## Open Questions

None identified at this time. All auth decisions are resolved in TR-1 through TR-6 (JWT, bcrypt, localStorage, no external provider). Password reset is explicitly deferred and not a blocker.

---

## Timeline / Dependencies

- **Target:** Wave 1 closed beta launch
- **Dependencies:**
  - `project-scaffold-local-dev-infra` — SQLite DB and Express server must exist before auth routes and middleware can be implemented
- **Blocks:**
  - `native-ordering-checkout` — order endpoints require `requireAuth` middleware from this effort
  - `consumer-web-discovery` — frontend auth gate at cart/checkout depends on this effort's login/register endpoints

---

## Requirements

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.
