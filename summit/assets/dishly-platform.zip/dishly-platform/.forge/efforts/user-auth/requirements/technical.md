# Technical Requirements — User Accounts + Auth

*Effort: user-auth*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-05*

---

## TR-1: JWT stored in localStorage, no external auth provider

*Traces to: [BR-2](business.md#br-2-emailpassword-registration-and-login)*

Auth is stateless JWT. No Auth0, Firebase Auth, Cognito, or any third-party auth service.

**Constraints:**
- JWT signed with `process.env.JWT_SECRET || 'dishly-dev-secret'`
- Token expiry: 7 days (`expiresIn: '7d'`)
- Frontend stores token in `localStorage` under key `dishly_token`
- All authenticated API calls send `Authorization: Bearer <token>` header

---

## TR-2: Password hashing with bcrypt

*Traces to: [BR-2](business.md#br-2-emailpassword-registration-and-login)*

Passwords are hashed before storage. Raw passwords are never persisted.

**Constraints:**
- Use `bcrypt` npm package, salt rounds: 10
- `password_hash` column stores the bcrypt hash
- Login compares submitted password against stored hash via `bcrypt.compare`

---

## TR-3: User data model

*Traces to: [BR-2](business.md#br-2-emailpassword-registration-and-login), [BR-4](business.md#br-4-order-history-visible-to-authenticated-user-only)*

Matches the initiative spec TR-4 User entity exactly.

| Field | Type | Notes |
|-------|------|-------|
| id | TEXT | UUID v4 |
| email | TEXT | Unique, case-insensitive |
| password_hash | TEXT | bcrypt hash |
| created_at | TEXT | ISO datetime |

**Constraints:**
- Email stored and compared case-insensitively (lowercase on write)
- `id` generated with `uuid` package
- SQLite table: `user`

---

## TR-4: Auth API endpoints

*Traces to: [BR-2](business.md#br-2-emailpassword-registration-and-login)*

Two endpoints matching the initiative OpenAPI spec exactly:

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/dishly/v1/auth/register` | none | Register new user, return `{user, token}` |
| POST | `/dishly/v1/auth/login` | none | Authenticate, return `{user, token}` |
| GET | `/dishly/v1/users/me` | bearer | Return current user profile |

Response envelope: `{data: ..., meta: {status: {code}, operation: {request_id}}}`.
Error envelope: `{errors: [{code, message}], meta: ...}`.

---

## TR-5: JWT auth middleware

*Traces to: [BR-1](business.md#br-1-anonymous-discovery-account-required-at-checkout), [BR-4](business.md#br-4-order-history-visible-to-authenticated-user-only)*

Express middleware that validates the bearer token and attaches `req.user` for
downstream handlers.

**Constraints:**
- Reads `Authorization: Bearer <token>` header
- Verifies signature and expiry using `jsonwebtoken`
- On invalid/missing token: returns 401 JSON error
- Attached as named export `requireAuth` from `backend/src/middleware/auth.js`
- Discovery routes (`GET /restaurants*`, `GET /collections*`, `GET /cuisines`, `GET /neighbourhoods`) do NOT use this middleware

---

## TR-6: SQLite schema migration for user table

*Traces to: [TR-3](#tr-3-user-data-model)*

The `user` table is created via `backend/src/db/migrate.js`, run on server startup
before any requests are served.

**Constraints:**
- Migration is idempotent (`CREATE TABLE IF NOT EXISTS`)
- `migrate.js` is called at the top of `server.js` before `app.listen`
- No external migration framework required for Wave 1
