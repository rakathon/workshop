# User Stories: User Accounts + Auth

*Product / Effort: user-auth*
*Last updated: 2026-06-07*

---

## New User (registration)

**US-1:** As a new user, I want to create an account with my email and password so that I can place orders and access my order history.

**Acceptance Criteria:**
- [ ] `POST /auth/register` with a valid email and password (≥8 characters) returns 201 with `{user, token}`
- [ ] The returned JWT is valid and can be used immediately on authenticated endpoints
- [ ] Registering with an already-used email returns a 409 error with a human-readable message
- [ ] Registering with a password shorter than 8 characters returns a 422 validation error

---

**US-2:** As a new user, I want to be taken directly into the app after registering so that I don't have to log in separately after creating my account.

**Acceptance Criteria:**
- [ ] Successful registration stores the JWT in `localStorage` under `dishly_token`
- [ ] The user is redirected to the homepage (or the page they came from) immediately after registration
- [ ] No email verification step is required before the account is usable

---

## Returning User (login)

**US-3:** As a returning user, I want to sign in with my email and password so that I can access my account, place orders, and see my order history.

**Acceptance Criteria:**
- [ ] `POST /auth/login` with correct credentials returns 200 with `{user, token}`
- [ ] `POST /auth/login` with incorrect credentials returns 401 with an error message that does not reveal which field (email or password) was wrong
- [ ] Successful login stores the JWT in `localStorage` under `dishly_token`

---

**US-4:** As a returning user, I want my session to persist across browser sessions so that I don't have to log in again every time I open the app.

**Acceptance Criteria:**
- [ ] JWT stored in `localStorage` persists across tab closes and browser restarts (for up to 7 days)
- [ ] Authenticated API calls use the stored token automatically via the `Authorization: Bearer` header
- [ ] An expired or invalid token results in a 401 response and the user is redirected to `/login`

---

## Anonymous Visitor (discovery access)

**US-5:** As an anonymous visitor, I want to browse restaurants and menus without signing in so that I can discover what's available before committing to creating an account.

**Acceptance Criteria:**
- [ ] `GET /restaurants`, `GET /collections`, `GET /restaurants/:id` all return 200 with no `Authorization` header
- [ ] The `requireAuth` middleware is not applied to any discovery route
- [ ] No redirect to `/login` occurs when browsing homepage, search, or restaurant pages

---

## Internal / Engineering

**US-6:** As an engineer, I want a `requireAuth` middleware that protects order endpoints so that unauthenticated users cannot place orders or view order history.

**Acceptance Criteria:**
- [ ] `requireAuth` middleware reads `Authorization: Bearer <token>`, verifies the JWT, and attaches `req.user.id` for downstream handlers
- [ ] Requests with no token return 401 with `{errors: [{code: "UNAUTHORIZED", message: "Authentication required"}]}`
- [ ] Requests with an expired or invalid token return 401 with a clear error message
- [ ] All order endpoints (`POST /orders`, `GET /orders/:id`, `GET /users/me/orders`) apply `requireAuth`

---

**US-7:** As an engineer, I want password hashing with bcrypt so that raw passwords are never stored in the database.

**Acceptance Criteria:**
- [ ] `password_hash` column stores the bcrypt hash (10 salt rounds), never the raw password
- [ ] Login uses `bcrypt.compare` to validate the submitted password against the stored hash
- [ ] No plain-text password appears in any log, error message, or database record

---
