# Business Requirements: User Accounts + Auth

*Product / Effort: user-auth*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Anonymous discovery, account required at checkout

**Priority:** P0

Discovery and browsing are open to any visitor — no account required to explore
restaurants, view menus, or use search. An account is required only when a user
attempts to add an item to cart or proceed to checkout.

**Acceptance Criteria:**
- [ ] Any visitor can access homepage, search, restaurant pages, and menus without signing in
- [ ] An account gate appears when a user attempts to add to cart or proceed to checkout
- [ ] After signing in at the checkout gate, the user's cart is preserved and checkout continues without restarting

---

## BR-2: Email/password registration and login

**Priority:** P0

The business must provide a secure account creation and sign-in mechanism using email and password — so that users can authenticate and access order functionality without requiring a third-party identity provider.

**Acceptance Criteria:**
- [ ] Registration with a valid email and password of sufficient length creates an account and issues a session credential
- [ ] Registration with an already-registered email is rejected with a clear conflict message
- [ ] Sign-in with correct credentials grants access and issues a session credential
- [ ] Sign-in with incorrect credentials is rejected with an error that does not reveal which field (email or password) was wrong

---

## BR-3: No password reset

**Priority:** P0

Password reset is explicitly out of scope for Wave 1. No "forgot password" flow,
no email sending, no reset tokens.

**Acceptance Criteria:**
- [ ] No "forgot password" link or UI exists anywhere in the product
- [ ] No email infrastructure (SMTP, transactional email) is built or configured

---

## BR-4: Order history visible to authenticated user only

**Priority:** P1

The business must ensure that a signed-in user can view their own past orders, and that order history is private — no user can access another user's orders.

**Acceptance Criteria:**
- [ ] Order history is accessible only to signed-in users; unauthenticated visitors are redirected to sign in
- [ ] A user can only retrieve orders they placed — attempts to access another user's orders are denied
