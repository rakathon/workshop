# Implementation Plan: User Accounts + Auth

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

```mermaid
gantt
    title  User Accounts + Auth — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Foundation
    SQLite migration + user table     :task1, 1, 2
    bcrypt + jwt helpers              :task2, 1, 2

    section Auth API
    POST /auth/register handler       :crit, task3, 2, 3
    POST /auth/login handler          :crit, task4, 2, 3
    GET /users/me handler             :task5, 2, 3

    section Middleware + Wiring
    requireAuth middleware            :task6, 3, 4
    Wire auth router into server      :task7, 3, 4
    Auth observable end-to-end        :milestone, m1, 4, 0
```

---

## Wave 1 — Foundation

### TASK-001 `[auto]` `[wave:1]`

Create `backend/src/db/migrate.js` — runs `CREATE TABLE IF NOT EXISTS user (...)` for the user table using the connection singleton, and is called at server startup before `app.listen`.

**Satisfies:** TR-3, TR-6
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

### TASK-002 `[auto]` `[wave:1]`

Create `backend/src/middleware/auth.js` with two exports: `hashPassword(plain)` (bcrypt, 10 rounds) and `comparePassword(plain, hash)` (bcrypt compare); and a `signToken(userId)` / `verifyToken(token)` pair using jsonwebtoken with `JWT_SECRET` and `expiresIn: '7d'`.

**Satisfies:** TR-1, TR-2
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

## Wave 2 — Auth Handlers

### TASK-003 `[tdd]` `[wave:2]`

Implement `POST /dishly/v1/auth/register` — validate email format and password length (≥8), check for duplicate email (409), hash password, insert user row, return 201 `{data: {user, token}, meta}`.

**Satisfies:** BR-2, TR-4
**Depends on:** TASK-001, TASK-002
**Standards:** none
**Required tests:**
- `test('POST /auth/register creates user and returns token')` — 201 with user + token
- `test('POST /auth/register rejects duplicate email with 409')` — conflict response
- `test('POST /auth/register rejects short password with 422')` — validation error

**Completed:** no-vcs
---

### TASK-004 `[tdd]` `[wave:2]`

Implement `POST /dishly/v1/auth/login` — look up user by email, compare password hash, return 200 `{data: {user, token}, meta}` on success; 401 on bad credentials (no field-level hint).

**Satisfies:** BR-2, TR-4
**Depends on:** TASK-001, TASK-002
**Standards:** none
**Required tests:**
- `test('POST /auth/login returns token for valid credentials')` — 200 with token
- `test('POST /auth/login returns 401 for wrong password')` — no field hint
- `test('POST /auth/login returns 401 for unknown email')` — same 401 shape

**Completed:** no-vcs
---

### TASK-005 `[tdd]` `[wave:2]`

Implement `GET /dishly/v1/users/me` — verify bearer token, look up user by ID from token payload, return 200 `{data: user, meta}`; 401 if token missing or invalid.

**Satisfies:** BR-2, TR-4, TR-5
**Depends on:** TASK-001, TASK-002
**Standards:** none
**Required tests:**
- `test('GET /users/me returns user for valid token')` — 200 with user object
- `test('GET /users/me returns 401 with no token')` — missing auth
- `test('GET /users/me returns 401 with invalid token')` — bad signature

**Completed:** no-vcs
---

## Wave 3 — Middleware + Wiring

### TASK-006 `[tdd]` `[wave:3]`

Add `requireAuth` named export to `backend/src/middleware/auth.js` — Express middleware that reads the `Authorization: Bearer` header, calls `verifyToken`, attaches `req.user = {id, email}`, and calls `next()`; on failure returns 401 JSON error.

**Satisfies:** TR-5
**Depends on:** TASK-002
**Standards:** none
**Required tests:**
- `test('requireAuth calls next() for valid bearer token')` — middleware passes through
- `test('requireAuth returns 401 for missing Authorization header')` — blocked
- `test('requireAuth returns 401 for expired/invalid token')` — blocked

**Completed:** no-vcs
---

### TASK-007 `[auto]` `[wave:3]`

Mount the auth router at `/dishly/v1` in `backend/src/routes/index.js`; call `migrate()` from `migrate.js` at top of `server.js` before `app.listen`; install `bcrypt` npm package in backend.

**Satisfies:** TR-4, TR-6
**Depends on:** TASK-003, TASK-004, TASK-005, TASK-006
**Standards:** none
**Required tests:** none (wiring task)
