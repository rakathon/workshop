# Verification Report

**Result:** FAIL
**Effort:** dishly-wave-1
**Date:** 2026-06-06T00:00:00Z

## Summary

The dishly Wave 1 implementation is substantially complete across five of its six planned epics. The core consumer loop — discover, browse, cart, checkout, order confirmation — is fully wired end-to-end with 100 seeded restaurants, JWT auth, localStorage cart, and simulated delivery. All data model entities match the spec. All key API endpoints and frontend routes are implemented. The BR-14 no-password-reset constraint is respected. No paid-placement mechanism exists in the codebase.

One epic is missing: **EPIC-006 (Analytics Instrumentation + Ops Dashboard)** has no implementation. No client-side event tracking (`pageview`, `add_to_cart`, `order_confirmed`, `search_performed`) exists in the frontend, and no internal ops dashboard route (`/internal/ops`) is present anywhere in the codebase. This causes BR-8 (wave 1 success signal observability) and BR-10/BR-11 (event capture for discovery and order conversion) to be unmet.

Additionally, the `curated_collection` DB table defined in the DDL spec is not created in `migrate.js` — collections are served entirely from the JSON file at runtime, bypassing the relational schema. This is a minor structural deviation from the spec (TR-5, sqlite.sql) but does not break functionality.

---

## Requirement Coverage

### Business Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| [BR-1](../requirements/business.md#br-1-unified-discovery-to-delivery-experience) | Unified discovery-to-delivery experience | PASS | Full flow: homepage → search → restaurant page → cart → checkout → confirmation, all in-app |
| [BR-2](../requirements/business.md#br-2-target-user) | Target user (quality-conscious 22–40) | PASS | "Curated. Not sponsored." messaging; no paid-placement mechanism exists in code or data |
| [BR-3](../requirements/business.md#br-3-earned-curation-standard) | Earned curation standard; no paid placement | PASS | No `payment`, `placement`, or `ranking_weight` columns in restaurant schema or seed data |
| [BR-4](../requirements/business.md#br-4-web-only-consumer-surface) | Web-only consumer surface (responsive) | PASS | React SPA with React Router; no native app code; responsive CSS present |
| [BR-5](../requirements/business.md#br-5-seeded-restaurant-supply-for-wave-1) | 100 seeded restaurants | PASS | 100 restaurants, 10 cuisine types, 5 NYC neighbourhoods, 300 sections, 1000 items, 300 reviews |
| [BR-6](../requirements/business.md#br-6-simulated-delivery-for-wave-1) | Simulated delivery for Wave 1 | PASS | No real courier dispatch; Stripe `payment_method_id` accepted but no live Stripe SDK call in backend; `pm_card_visa` hardcoded; simulated "30–40 min" ETA on confirmation screen |
| [BR-7](../requirements/business.md#br-7-explicit-scope-exclusions) | Explicit scope exclusions | PASS | No iOS/Android app, no live delivery integration, no reservations, loyalty, or social layer code found |
| [BR-8](../requirements/business.md#br-8-wave-1-success-criteria-mvp) | Wave 1 success criteria observable | FAIL | No analytics instrumentation; no event capture to observe "time-to-first-discovery" or order completion rate (EPIC-006 not built) |
| [BR-9](../requirements/business.md#br-9-authentication-model) | Auth model: anonymous browse, gate at cart | PASS | Discovery routes unauthenticated; `handleAddToCart` redirects to `/login` when `dishly_token` absent; checkout checks token |
| [BR-10](../requirements/business.md#br-10-discovery-ux-surfaces) | Three discovery surfaces | PASS | Homepage (collections + search bar), Search page (keyword + cuisine/price filters), Restaurant page (hero, menu, reviews) all implemented; event capture absent (see BR-8) |
| [BR-11](../requirements/business.md#br-11-ordering-flow) | Ordering flow (single-restaurant, linear) | PASS | Cart enforces single-restaurant (confirmation prompt on new restaurant); manual address entry; delivery-now only; card payment via dummy form; order summary before confirm; simulated ETA; event capture absent (see BR-8) |
| [BR-12](../requirements/business.md#br-12-order-history) | Order history | PASS | `/account/orders` page implemented; shows restaurant name, date, itemised items, total; no reorder shortcut; auth-gated (redirects to `/login`) |
| [BR-13](../requirements/business.md#br-13-reviews-display) | Reviews display (seeded, no submission) | PASS | Restaurant page shows up to 5 seeded reviews (author, rating, body, date); no submit UI |
| [BR-14](../requirements/business.md#br-14-no-password-reset) | No password reset | PASS | Login page explicitly notes "No password reset in Wave 1 beta"; no reset flow or email code found |
| [BR-15](../requirements/business.md#br-15-error-states) | Error states | PASS | Empty search state rendered; broken cover image falls back to `/placeholder.jpg`; `menu__empty` placeholder for no items; checkout error preserved on failure |
| [BR-16](../requirements/business.md#br-16-restaurant-page-layout) | Restaurant page layout | PASS | Hero image, name/cuisine/price/rating meta, description, address, menu sections with inline Add-to-cart buttons, reviews; broken image `onError` handler present |

### Technical Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| [TR-1](../requirements/technical.md#tr-1-local-only-infrastructure-no-cloud-no-docker) | Local-only infrastructure; no cloud/Docker | PASS | All processes run locally; `start.sh` manages backend + frontend; no cloud config found |
| [TR-2](../requirements/technical.md#tr-2-technology-stack) | Tech stack: React, Node/Express, SQLite, JWT, Stripe test | PASS | Stack confirmed; no live Stripe SDK call in backend (payments are mock `pm_card_visa`); JWT via `middleware/auth.js`; SQLite via `better-sqlite3` |
| [TR-3](../requirements/technical.md#tr-3-image-handling-url-references-only) | Image handling — URL references only | PASS | All `cover_image_url` and `image_url` fields are URL strings; no file upload endpoints exist |
| [TR-4](../requirements/technical.md#tr-4-core-data-model) | Core data model | PASS | All tables present in `migrate.js`: `user`, `restaurant`, `menu_section`, `menu_item`, `review`, `order`, `order_item`, `cuisine`, `neighbourhood`. Price stored as `value/scale` tuple per spec. `order_item` snapshots `item_name` and `unit_price`. `deleted_at` soft-delete on `user` and `order`. |
| [TR-5](../requirements/technical.md#tr-5-curated-collections-static-config) | Curated collections — static config (`data/collections.json`) | PARTIAL | Collections served from JSON file as required; however the `curated_collection` DB table defined in `sqlite.sql` is not created in `migrate.js` — the relational schema is not implemented, only the JSON-file path |
| [TR-6](../requirements/technical.md#tr-6-api-style-restjson) | API style — REST/JSON with `{data, meta}` envelope | PASS | All endpoints return `{data, meta}` or `{errors, meta}`; correct HTTP verbs; JWT bearer auth on order endpoints |
| [TR-7](../requirements/technical.md#tr-7-search-scope) | Search: case-insensitive LIKE on `restaurant.name` and `menu_item.name` | PASS | `restaurants.js` performs LIKE query on both fields; cuisine/price/neighbourhood filter params wired |
| [TR-8](../requirements/technical.md#tr-8-seed-data-geography-and-distribution) | Seed distribution: ≥5 NYC neighbourhoods, 8–10 cuisines, $/$$/$$$ spread, ratings ≥3.5 | PASS | 5 neighbourhoods (Astoria, Brooklyn, Manhattan, Queens, Williamsburg); 10 cuisines; price spread 23/$:50/$$:27/$$$; ratings min 4.1, max 5.0 (above 3.5 threshold) |
| [TR-9](../requirements/technical.md#tr-9-local-dev-startup) | Single-command startup (`./start.sh`) | PASS | `start.sh` installs deps if absent, applies migrations, seeds DB on first run, starts backend (3001) + frontend (3000) concurrently; idempotent |
| [TR-10](../requirements/technical.md#tr-10-cart-persistence) | Cart persistence in `localStorage` | PASS | `useCart.js` persists to `localStorage` on every change; survives refresh; single-restaurant enforcement with confirm prompt; cleared on successful order |
| [TR-11](../requirements/technical.md#tr-11-client-side-routing) | Client-side routing via React Router | PASS | All 9 required routes defined in `App.jsx`; backend catch-all serves `index.html` for non-API routes |

---

## Gaps

### GAP-1 (FAIL): EPIC-006 — Analytics Instrumentation + Ops Dashboard not implemented

**Traces to:** [BR-8](../requirements/business.md#br-8-wave-1-success-criteria-mvp), [BR-10](../requirements/business.md#br-10-discovery-ux-surfaces) (event capture), [BR-11](../requirements/business.md#br-11-ordering-flow) (event capture)

No client-side analytics instrumentation exists in the frontend. The following events defined in EPIC-006 are absent:
- `pageview` on route change
- `add_to_cart` on menu item add
- `order_confirmed` on successful order
- `search_performed` on search submission

No internal ops dashboard page (`/internal/ops` or equivalent) is present in the frontend or backend.

Without event capture, Wave 1 cannot observe whether beta users can find a restaurant within a single session, or whether orders complete without errors at the ≥90% rate — the stated success criteria for BR-8.

**Remediation:** Implement a lightweight `analytics.js` module (console/local log output as per the epic spec) and wire `track()` calls into the four event points. Add a minimal `/internal/ops` route returning restaurant count, neighbourhood breakdown, and menu completeness metrics.

---

### GAP-2 (MINOR): `curated_collection` DB table not created in migrations

**Traces to:** [TR-5](../requirements/technical.md#tr-5-curated-collections-static-config), `spec/storage/sqlite.sql`

The SQLite DDL spec defines a `curated_collection` table and a `collection_restaurant` junction table. The actual `migrate.js` does not create these tables. Collections work at runtime via the JSON file, but the relational schema is incomplete relative to the spec. This is a spec deviation, not a functional regression, because the JSON-file path (TR-5) is the primary implementation mechanism.

**Remediation:** Add `curated_collection` and `collection_restaurant` table creation to `migrate.js` to match the spec DDL, or document the deviation in an ADR.
