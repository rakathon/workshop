**Result:** PASS WITH CONCERNS

## Requirements Traceability

All BRs and TRs are covered. No uncovered requirements.

Previous REQUIRED findings resolved by the 8 fixes applied before this run:

- TR-4 `Review.text` → `Review.body` naming inconsistency: resolved — TR-4 updated to use `body`, matching the API schema and DDL.
- TR-4 `Order.items JSON` vs normalized `order_item` table: resolved — TR-4 updated to reference the `ORDER_ITEM` sub-entity, consistent with the storage and API specs.

---

## Standards Compliance

### API: `spec/api/dishly.yaml`

**Policy:** plugin default (contracts, protocol, security)

All previously REQUIRED API findings have been resolved:

- `info.version` semver: resolved — changed to `"1.0.0"`.
- R-10 member URI deviation: resolved — ADR-001 formally records the Wave 1 deviation, documents the rationale (local-only single-region MVP, no production infra), lists alternatives considered, and commits to the compliant URI migration in Wave 2. The spec carries `# NON-STANDARD` annotations on both affected endpoints. The deviation is accepted and documented.
- `POST /orders` missing `payment_method_id`: resolved — field added to the request body schema with a description of the Stripe.js token flow.

Remaining advisory findings:

**SUGGESTION** — R-7 (protocol): `POST /auth/register`, `POST /auth/login`, and `POST /orders` do not declare a `400` response. Protocol R-7 distinguishes 400 (malformed or unparseable request) from 422 (well-formed request failing semantic validation). All three endpoints accept a structured request body; a malformed body should return 400. Add a `400` response definition to each of these three endpoints.

**SUGGESTION** — R-1 (protocol, advisory): No endpoint declares a `Client-Agent` request header requirement. Protocol R-1 requires `Client-Agent` on all API calls; `User-Agent` is not a substitute. For a local-only MVP this is low risk, but the declaration should be added to shared parameters or noted as an explicit Wave 1 exception.

### Storage: `spec/storage/sqlite.sql`

**Technology:** SQLite. No organizational SQLite storage standard exists in the plugin — common checks (C1–C4) and PII checks (P1–P2) applied; technology-specific checks skipped.

All previously REQUIRED storage findings have been resolved:

- `order` table `deleted_at` column: resolved — `deleted_at TEXT` column added with soft-delete comment matching the header convention.
- `user.email` PII retention: resolved — comment updated with `Retention: retain while account active + 1 year post-closure.`
- `user.email` PII deletion: resolved — comment updated with `Deletion: anonymise (set to '<deleted>@dishly.invalid') on account closure request.`
- `order.delivery_address` PII retention and deletion: resolved — comment updated with `Retention: retain for 2 years with order record (legal/financial obligation).` and `Deletion: nullify (set to NULL, make nullable) on account closure request after retention period.`

Remaining advisory findings:

**SUGGESTION** — C3 (soft-delete policy): `order_item` table has no explicit deletion policy statement. The header convention documents soft deletes on `user` and `order` only, and `order_item` rows are removed via `ON DELETE CASCADE` from the `order` table. This is correct behaviour, but the intent is not stated on the table itself. Add a comment to `order_item` such as `-- Deletion: CASCADE from parent order; no independent soft delete.`

**SUGGESTION** — P1/P2 (PII annotation): The `address` column in the `restaurant` table matches the default PII detection field name (`address`). This appears to be a false positive — restaurant addresses are publicly listed business addresses, not personal data. No action required, but a clarifying comment (e.g., `-- Public business address; not PII`) would suppress this warning in future validation runs and make intent explicit.

---

## Cross-Spec Consistency

All previously REQUIRED cross-spec findings have been resolved:

- `POST /orders` missing `payment_method_id`: resolved — field now present in the request body schema.
- `Order` schema missing `delivery_fee` and `subtotal`: resolved — both fields added to the `Order` schema as `Price` value/scale objects. OQ2 resolved in the UX spec (`delivery_fee` always $3.99 in Wave 1).

Remaining advisory findings:

**SUGGESTION** — `requirements/technical.md` TR-7 vs `spec/api/dishly.yaml` and `spec/storage/query-patterns.md`: TR-7 and the `GET /restaurants` description state that the keyword parameter `q` matches "restaurant name, any menu item name, city/neighbourhood." The query patterns support `restaurant.name LIKE ?` (pattern 3) and `neighbourhood_id = ?` (pattern 4), but there is no query pattern or index for a free-text `neighbourhood.name LIKE ?` join. A user typing "Brooklyn" in `q` would not be matched unless a cross-table join and LIKE on `neighbourhood.name` is implemented. Either add a query pattern (pattern 21) for neighbourhood name keyword search with a supporting index on `neighbourhood(name)`, or clarify in TR-7 and the `GET /restaurants` description that neighbourhood matching via `q` is only available through the `neighbourhood_id` UUID filter parameter.

**SUGGESTION** — `spec/ux/ux-strategy.md` (assumption A2) vs `spec/storage/sqlite.sql` and `spec/api/dishly.yaml` (`Review` schema): The UX spec notes that seeded reviews with no UGC provenance may be perceived as fake and suggests "From our editorial team" attribution. The `review` table and `Review` API schema have no `source` or `attribution` field. If this attribution is added before launch, both the DDL and API schema will require updates. Add a nullable `source TEXT` column to `review` and a `source` field to the `Review` schema, or explicitly close assumption A2 in the UX spec as "not implemented for Wave 1."

**SUGGESTION** — `spec/arch-decisions/ADR-002-normalized-order-items-table.md` vs `spec/storage/sqlite.sql`: ADR-002 describes `unit_price` as `INTEGER` (stored as integer cents) in its DDL example. The physical schema in `sqlite.sql` defines `unit_price REAL NOT NULL`. Update the ADR-002 DDL example to reflect `REAL`, or update `sqlite.sql` to use `INTEGER` (cents, consistent with the Price value/scale pattern used in the API schema).

**SUGGESTION** — `spec/api/dishly.yaml` (`Order` schema) vs `spec/storage/sqlite.sql` (`order` table): The `Order` API response includes `restaurant_name` as a required string field, but the `order` table does not store `restaurant_name`. This field is derived at query time via a JOIN to `restaurant.name`. This is a valid and intentional design choice for a Wave 1 seed environment, but should be documented. Add a comment to the `order` table noting that `restaurant_name` is joined at read time and not persisted, to prevent implementors from incorrectly adding a denormalized column.

---

## ADR Quality

All ADRs have required sections.

**ADR-001** (`ADR-001-user-uri-structure.md`): Context ✓, Decision ✓, Alternatives Considered ✓, Consequences ✓.

**ADR-002** (`ADR-002-normalized-order-items-table.md`): Context ✓, Decision ✓, Alternatives Considered ✓, Consequences ✓.
