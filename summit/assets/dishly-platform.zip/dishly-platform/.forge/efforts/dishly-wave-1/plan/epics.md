# Initiative Plan: dishly Wave 1 — Restaurant Discovery and Food Delivery

This plan breaks the initiative into child epics. Each epic maps to a deployable
that will be built in this repository. Epics are listed in recommended delivery
order based on dependencies — foundational data and auth must exist before any
consumer-facing surface can be exercised end-to-end.

All Wave 1 infrastructure runs locally (TR-1). No cloud, Docker, or remote services.
Stack: React frontend, Node.js/Express backend, SQLite database. Delivery is
simulated (BR-6). Payment uses Stripe test mode (TR-2, BR-6).

---

## EPIC-001: Project Scaffold + Local Dev Infrastructure

**Deployable:** dishly-web

### High-Level Output

A runnable monorepo is in place. `./start.sh` from the repo root installs
dependencies, seeds the SQLite database on first run, and boots the backend
(port 3001) and React dev server (port 3000) as concurrent processes. The
backend serves the React bundle as a catch-all for non-API routes. All
subsequent epics build on top of this scaffold — no epic can start coding
until this one is complete.

### Relevant Requirements

- **TR-1** — Local-only infrastructure; entire stack runs as local processes, no
  Docker, no cloud; starts with a single command
- **TR-2** — Tech stack: React frontend, Node.js/Express backend, SQLite database,
  JWT auth, Stripe test mode
- **TR-9** — `./start.sh` installs deps if absent, seeds DB on first run, starts
  backend and frontend concurrently; idempotent
- **TR-11** — Client-side routing via React Router; backend serves `index.html`
  catch-all for all non-API routes; all key routes defined

### Success Criteria

- [ ] `./start.sh` completes from a clean clone with only Node.js LTS installed
- [ ] Backend responds at `http://localhost:3001/dishly/v1/` and returns a 404 JSON
  response (not an HTML error) for unknown API routes
- [ ] React dev server responds at `http://localhost:3000/` with the app shell
- [ ] Direct navigation to `/restaurants/some-id` in the browser does not 404
- [ ] Running `./start.sh` twice does not corrupt or re-seed the database

---

## EPIC-002: Restaurant Data Platform — Seed + Core APIs

**Deployable:** dishly-web

### High-Level Output

A SQLite database is fully seeded with 100 NYC restaurants covering all entities
in the logical schema: cuisines, neighbourhoods, restaurants, menu sections, menu
items, and seeded reviews. The backend exposes the full read-side API surface —
`GET /cuisines`, `GET /neighbourhoods`, `GET /collections`, `GET /restaurants`,
`GET /restaurants/:id` — conforming to the OpenAPI contract in `spec/api/dishly.yaml`.
All endpoints return correctly structured `{data, meta}` responses. Search (`?q=`)
and filter parameters (cuisine, neighbourhood, price range) work against the seed
data using SQL LIKE queries.

### Relevant Requirements

- **BR-3** — Earned curation; every seeded restaurant has complete menus, photos,
  and covers the delivery radius check; no paid-placement mechanism exists in code
- **BR-5** — 100 seeded restaurants; each has name, cuisine, description, location,
  delivery radius, and a complete menu with item photos; realistic spread of NYC
  neighbourhoods and cuisine types
- **BR-13** — 3–5 seeded reviews per restaurant; average star rating derived from
  seeded reviews; no review submission UI
- **TR-3** — Images are URL references only; seed data uses publicly accessible URLs
- **TR-4** — Full data model: Restaurant, MenuSection, MenuItem, Review, Cuisine,
  Neighbourhood, CuratedCollection
- **TR-5** — Curated collections defined in `data/collections.json`; loaded at
  server start; collections with zero live restaurants are not rendered
- **TR-7** — Search: case-insensitive LIKE on `restaurant.name` and `menu_item.name`;
  neighbourhood filtering via `neighbourhood_id` UUID param (not free-text)
- **TR-8** — Seed distribution: ≥5 NYC neighbourhoods, 8–10 cuisine types, spread
  of $/$$/$$$ price ranges, ratings 3.5–5.0; min 3 sections, 8 items, 3 reviews
  per restaurant

### Success Criteria

- [ ] `GET /dishly/v1/restaurants` returns 100 restaurants with correct
  `RestaurantSummary` shape (id, name, cuisine, neighbourhood, price_range,
  cover_image_url, average_rating)
- [ ] `GET /dishly/v1/restaurants/:id` returns full `RestaurantDetail` including
  nested menu sections, items, and up to 5 reviews
- [ ] `GET /dishly/v1/restaurants?q=ramen` returns only restaurants matching "ramen"
  in name or menu item names (case-insensitive); neighbourhood name free-text does
  not match (consistent with TR-7 and the validation report suggestion)
- [ ] `GET /dishly/v1/collections` returns collections in `data/collections.json`
  order; empty collections are omitted
- [ ] Seed covers ≥5 NYC neighbourhoods, ≥8 cuisine types, even $/$$/$$$ spread,
  all ratings ≥3.5; every restaurant has ≥3 menu sections, ≥8 items, ≥3 reviews
- [ ] No `payment` field, placement flag, or ranking weight exists anywhere in the
  restaurant schema or seed data

### Dependencies

- Depends on: EPIC-001 (scaffold and SQLite DB must exist before seeding or running
  the backend)

---

## EPIC-003: User Accounts + Auth

**Deployable:** dishly-web

### High-Level Output

`POST /auth/register` and `POST /auth/login` are implemented and return a JWT.
`GET /users/me` is secured with JWT bearer auth middleware. The middleware is
wired into the Express router so all order endpoints inherit it automatically.
Anonymous access to discovery routes works without a token. Auth bugs are
explicitly guarded against — this epic's test coverage is thorough before
any ordering work begins.

### Relevant Requirements

- **BR-9** — Discovery and browsing open to anonymous users; account required at
  checkout only; cart preserved after sign-in at checkout
- **BR-14** — No password reset, no "forgot password" flow, no email infrastructure
- **TR-2** — JWT stored in localStorage; no external auth provider (no Auth0,
  Firebase, Cognito)
- **TR-4** — User entity: id (UUID), email (unique), password_hash, created_at
- **TR-11** — `/login` and `/register` routes defined in client-side router

### Success Criteria

- [ ] `POST /auth/register` with a valid email/password returns 201 with `{user, token}`
- [ ] `POST /auth/register` with an already-registered email returns 409
- [ ] `POST /auth/login` with correct credentials returns 200 with `{user, token}`
- [ ] `POST /auth/login` with wrong credentials returns 401
- [ ] `GET /users/me` with a valid JWT returns the user; with no token returns 401
- [ ] Discovery endpoints (`GET /restaurants`, `GET /collections`) return 200 with
  no Authorization header
- [ ] No "forgot password" link, reset flow, or email send code exists anywhere

### Dependencies

- Depends on: EPIC-001 (scaffold)
- Parallel with: EPIC-002 (no data dependency; can be developed concurrently
  once the scaffold is in place)

---

## EPIC-004: Consumer Web App — Discovery UX

**Deployable:** dishly-web

### High-Level Output

The React frontend is fully built and wired to the live backend APIs. All three
discovery surfaces are functional in a browser: (1) Homepage with curated
collections and a search bar, (2) Search results page with keyword search and
cuisine/price-range filters, (3) Restaurant page with hero image, metadata,
full menu with inline "Add to cart" buttons, and seeded review snippets. The
app is usable on Chrome and Safari on desktop and mobile viewport widths.
Error states (empty search, broken image, "menu coming soon") are handled.

### Relevant Requirements

- **BR-1** — Unified discovery-to-delivery; all discovery entry points lead to a
  restaurant page with a native order entry point
- **BR-4** — Web-only; responsive web app on desktop and mobile browsers; no
  native app
- **BR-10** — Three discovery surfaces: homepage (curated collections + search),
  search results (keyword + filters), restaurant page (photos, description,
  reviews, full menu + order entry)
- **BR-15** — Error states: no results, broken image placeholder, failed order
  (cart preserved)
- **BR-16** — Restaurant page layout: hero, metadata, menu grouped by section with
  inline Add to Cart, reviews summary (3–5 snippets); menu sections collapsible
  on mobile
- **TR-10** — Cart state in `localStorage`; survives tab close/refresh; single
  restaurant per cart; cleared on successful order; cleared (with prompt) when
  starting a new restaurant's order
- **TR-11** — All frontend routes functional; direct URL access works

### Success Criteria

- [ ] Homepage loads and renders ≥1 curated collection with restaurant cards on
  Chrome desktop and Safari mobile without JS errors
- [ ] Search for "ramen" navigates to `/search?q=ramen` and returns matching
  restaurant cards
- [ ] Cuisine and price-range filters narrow results correctly
- [ ] Restaurant page at `/restaurants/:id` renders hero, menu sections, and 3–5
  review snippets; "Add to cart" appends to localStorage cart
- [ ] Starting a new restaurant's order while cart is non-empty shows a confirmation
  prompt and clears the cart on confirmation
- [ ] Searching for a non-existent term shows a friendly empty state (not a blank
  page)
- [ ] Restaurant page with a broken cover image URL shows a placeholder image
- [ ] All pages are usable at 390px viewport width (iPhone SE) in Chrome and Safari

### Dependencies

- Depends on: EPIC-002 (restaurant data APIs must be live to render any discovery
  surface)
- Depends on: EPIC-003 (auth wiring needed for the cart-to-checkout gate)

---

## EPIC-005: Native Ordering + Checkout

**Deployable:** dishly-web

### High-Level Output

The complete order flow is functional end-to-end: cart review → delivery address
entry → Stripe payment (test mode, via Stripe.js) → `POST /orders` → order
confirmation screen with simulated delivery status. The backend `POST /orders`
handler validates items belong to a single restaurant, snapshots item prices into
`order_item` rows, calls Stripe PaymentIntents API in test mode, and persists the
order. `GET /orders/:id` and `GET /users/me/orders` return correct order history.
A signed-in user can view past orders at `/account/orders`.

### Relevant Requirements

- **BR-6** — Simulated delivery; full order journey works but no real courier
  dispatched; Stripe in test mode only; no real payment charged; simulated
  delivery status on confirmation screen
- **BR-11** — Single-restaurant linear checkout; delivery address entered per order
  (no saved addresses); delivery now only; card payment via Stripe test mode;
  order summary before confirm; confirmed order screen with simulated ETA
- **BR-12** — Authenticated users can view order history; each order shows
  restaurant name, date, itemised list, total; no reorder shortcut
- **TR-4** — Order entity: id, user_id, restaurant_id, delivery_address, subtotal,
  delivery_fee ($3.99 flat), total, status (confirmed/delivering/delivered),
  created_at, deleted_at; OrderItem: id, order_id, menu_item_id, item_name
  (snapshot), quantity, unit_price (snapshot)
- **TR-6** — REST/JSON API; all order endpoints return `{data, meta}` envelope
- **TR-10** — Cart cleared on successful order confirmation

### Success Criteria

- [ ] A user can complete the full flow — discover → restaurant → add items →
  cart → checkout → enter address → Stripe test card → order confirmed — without
  errors
- [ ] `POST /orders` with items from two different restaurants returns 422
- [ ] `POST /orders` with a valid `payment_method_id` (Stripe test token) returns
  201; the order is persisted with correct `order_item` rows including price
  snapshots
- [ ] `GET /orders/:id` returns the order for its owner; returns 403 for a
  different authenticated user
- [ ] `/account/orders` shows all past orders for the signed-in user; unauthenticated
  access redirects to `/login`
- [ ] Cart is cleared in localStorage after a successful order confirmation
- [ ] A failed order submission (mocked server error) preserves the cart and shows
  an error message; no partial order is created
- [ ] No real courier dispatch API call is made at any point in the flow

### Dependencies

- Depends on: EPIC-003 (JWT auth required to place an order; order endpoints
  are bearer-gated)
- Depends on: EPIC-004 (cart is built in the discovery frontend; checkout begins
  from the cart page built there)

---

## EPIC-006: Analytics Instrumentation + Ops Dashboard

**Deployable:** dishly-web

### High-Level Output

Client-side event tracking is instrumented across all three discovery surfaces
and the order flow, covering the North Star metric and all L1/L2 diagnostics
defined in `products/dishly/metrics.md`. A lightweight internal ops dashboard
(accessible locally, not exposed to consumers) surfaces the key supply-health
metrics: restaurant count per neighbourhood, menu completeness score, and
delivery coverage rate. Events are emitted to the browser console or a local
log file in Wave 1 — no external analytics vendor required.

### Relevant Requirements

- **BR-8** — Wave 1 success signal: beta users can find a restaurant within one
  session; orders complete without critical errors ≥90% of attempts; no P0 bugs
  open >24 hours — instrumentation must be in place to observe these
- **BR-10** — Discovery surfaces (homepage, search, restaurant page) must have
  session-level event capture to calculate "time-to-first-discovery"
- **BR-11** — Order flow events must capture conversion rate (discovery → order
  confirmed) and cart abandonment rate

### Success Criteria

- [ ] A pageview event fires on every route change and is visible in the browser
  console (or local log) with the route name and a session ID
- [ ] An `add_to_cart` event fires when a user clicks "Add to cart" on a menu item
- [ ] An `order_confirmed` event fires on successful order confirmation with
  order ID and total
- [ ] A `search_performed` event fires on every search with the query string and
  result count
- [ ] The ops dashboard page (local-only, e.g. `/internal/ops`) shows: total
  restaurant count, count per neighbourhood, % of restaurants with all menu
  items having photos, % of restaurants with delivery enabled
- [ ] No analytics event payload contains raw PII (email, full address, card data)

### Dependencies

- Depends on: EPIC-004 (discovery surfaces must exist before they can be
  instrumented)
- Depends on: EPIC-005 (order flow must exist before order conversion events
  can be added)
