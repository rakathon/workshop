# User Stories: dishly Wave 1 — Restaurant Discovery and Food Delivery

*Product / Effort: dishly-wave-1*
*Last updated: 2026-06-07*

---

## Discovery

**US-1:** As an anonymous visitor, I want to browse curated restaurant collections on the homepage so that I can find somewhere worth eating without knowing what I'm looking for.

**Acceptance Criteria:**
- [ ] The homepage displays at least one curated collection of restaurants
- [ ] Each collection has a title and shows restaurant cards with enough detail to decide whether to click through
- [ ] No sign-in is required to view the homepage or any collection

---

**US-2:** As an anonymous visitor, I want to search for restaurants by name or cuisine type so that I can find a specific type of food quickly.

**Acceptance Criteria:**
- [ ] A search bar is accessible from the homepage
- [ ] Entering a restaurant name or cuisine type returns a filtered list of matching restaurants
- [ ] A "no results" message is shown when no restaurants match the query

---

**US-3:** As an anonymous visitor, I want to view a restaurant page with photos, description, price range, and reviews so that I can decide whether it's worth ordering from.

**Acceptance Criteria:**
- [ ] The restaurant page shows a cover photo, name, cuisine type, price range, average star rating, short description, and review snippets
- [ ] The page is accessible without signing in
- [ ] If the cover photo cannot be loaded, a placeholder is displayed

---

**US-4:** As an anonymous visitor, I want to browse a restaurant's full menu with item photos, descriptions, and prices so that I can see what's available before committing to order.

**Acceptance Criteria:**
- [ ] The restaurant page shows the full menu grouped by section (e.g. Starters, Mains, Desserts)
- [ ] Each menu item displays a name, description, price, and photo
- [ ] The menu is browsable without signing in

---

## Ordering

**US-5:** As an authenticated user, I want to add menu items to a cart from a restaurant page so that I can build my order before checking out.

**Acceptance Criteria:**
- [ ] An add-to-cart action is available inline on each menu item
- [ ] Adding an item updates the cart and reflects the correct item count and total
- [ ] The cart persists within the session

---

**US-6:** As an authenticated user, I want to be prompted to sign in when I try to add to cart so that the account gate doesn't interrupt my discovery experience.

**Acceptance Criteria:**
- [ ] Attempting to add to cart while signed out triggers an account gate (sign-in or sign-up prompt)
- [ ] After successful sign-in, the user is returned to the restaurant page and the cart action proceeds
- [ ] Discovery and browsing (before the cart action) require no account

---

**US-7:** As an authenticated user, I want to enter a delivery address at checkout so that I can specify where my order is delivered.

**Acceptance Criteria:**
- [ ] The checkout flow includes a step for entering a delivery address manually
- [ ] No saved address book is required or offered in Wave 1
- [ ] The entered address is shown on the order summary before confirmation

---

**US-8:** As an authenticated user, I want to see an order summary — itemised list, delivery address, and total — before confirming so that I can review before committing.

**Acceptance Criteria:**
- [ ] An order summary screen is shown before the final confirm action, listing all items, the delivery address, and the order total
- [ ] The user can return to the cart from the summary to make changes
- [ ] The confirm action is not available until the address has been entered

---

**US-9:** As an authenticated user, I want to see a confirmation screen with a simulated delivery estimate after placing an order so that I know my order was received.

**Acceptance Criteria:**
- [ ] After confirming an order, a confirmation screen is shown
- [ ] The confirmation screen displays a simulated delivery estimate (e.g. "estimated 30–40 min")
- [ ] The confirmed order is recorded and appears in order history

---

**US-10:** As an authenticated user, I want to be warned before starting a new restaurant's order if I already have items in my cart so that I don't accidentally lose my existing order.

**Acceptance Criteria:**
- [ ] If the user adds an item from a different restaurant than the one already in their cart, a confirmation prompt is shown
- [ ] The cart is only cleared after the user explicitly confirms they want to start a new order
- [ ] Dismissing the prompt leaves the existing cart intact

---

## Account and Order History

**US-11:** As a new user, I want to create an account with email and password so that I can place and track orders.

**Acceptance Criteria:**
- [ ] A sign-up flow is available at the account gate (triggered at checkout) and from any sign-in entry point
- [ ] Sign-up requires at minimum an email address and password
- [ ] After sign-up, the user is authenticated and can proceed with their order

---

**US-12:** As a returning user, I want to sign in to my account so that I can access my order history and place new orders.

**Acceptance Criteria:**
- [ ] A sign-in flow is available at the account gate and from any sign-in entry point
- [ ] After sign-in, the user's cart is preserved and checkout continues without restarting
- [ ] Incorrect credentials result in a clear error message

---

**US-13:** As an authenticated user, I want to view my past orders — restaurant, date, items, and total — so that I can track what I've ordered.

**Acceptance Criteria:**
- [ ] A signed-in user can access an order history page
- [ ] Each past order shows the restaurant name, order date, itemised list of items, and order total
- [ ] Order history is only visible to the authenticated user who placed the orders
- [ ] No reorder shortcut is available in Wave 1

---

## Seed Data and Content

**US-14:** As a beta user, I want to browse 100 curated restaurants across multiple cuisine types and price ranges so that the platform feels well-stocked from day one.

**Acceptance Criteria:**
- [ ] At least 100 restaurants are available at beta launch, spanning multiple cuisine types and price points
- [ ] Each restaurant has a complete menu with item photos and descriptions
- [ ] The restaurant catalogue is browsable via homepage collections and search

---

**US-15:** As an internal team member, I want to update curated collections by editing a config file so that the homepage content can be refreshed without a code change.

**Acceptance Criteria:**
- [ ] Curated collections (title, included restaurants) are defined in a configuration file separate from application code
- [ ] Updating the configuration file and redeploying is sufficient to change homepage collections
- [ ] No direct database edit or code change is required to update collection content

---
