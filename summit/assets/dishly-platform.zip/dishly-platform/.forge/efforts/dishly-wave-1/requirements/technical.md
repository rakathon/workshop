# Technical Requirements — dishly Wave 1 — Restaurant Discovery and Food Delivery

*Effort: dishly-wave-1*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-05*

---

## TR-1: Local-only infrastructure — no cloud, no Docker

*Traces to: [BR-8](business.md#br-8-wave-1-success-criteria-mvp), [BR-11](business.md#br-11-ordering-flow)*

The entire Wave 1 stack runs locally on a developer's machine. No cloud infrastructure (AWS, GCP, Azure), no containerisation (Docker, Kubernetes), and no remote services are used or required to run the application.

**Constraints:**
- All services (web server, database, background workers) run as local processes
- Data is persisted to the local filesystem
- The application must start with a single command (e.g. a run script or `make dev`)
- No network calls to remote infrastructure at runtime — all external API calls (Stripe, delivery) use local mocks or test-mode credentials only
- No Docker Compose, no container runtime dependency

---

## TR-2: Technology stack

*Traces to: [BR-1](business.md#br-1-unified-discovery-to-delivery-experience), [BR-4](business.md#br-4-web-only-consumer-surface)*

| Layer | Technology | Notes |
|-------|-----------|-------|
| Frontend | React | Responsive web app; no native mobile |
| Backend | Node.js | REST API server (Express or Fastify) |
| Database | SQLite or local JSON files | SQLite preferred for relational data (orders, users, restaurants); JSON files acceptable for seed/static data. No separate DB process required. |
| Auth | JWT stored in-memory / localStorage | Standard stateless auth; no external auth provider |
| Payment | Stripe test mode | No live payment processing in Wave 1 |

**Constraints:**
- No external databases (no Postgres, MySQL, MongoDB, Redis)
- No third-party auth services (no Auth0, Firebase Auth, Cognito)
- Frontend and backend must run as separate local processes started by a single dev command
- SQLite file and any JSON data files are local to the repository and gitignored for user-generated data; seed data is committed

---

## TR-3: Image handling — URL references only

*Traces to: [BR-5](business.md#br-5-seeded-restaurant-supply-for-wave-1)*

All images (restaurant cover photos, menu item photos) are stored as publicly accessible URLs pointing to existing images on the web. No image uploads, no file hosting, no CDN, and no binary assets are stored in the application.

**Constraints:**
- Restaurant and menu item records store an `image_url` string field — the frontend renders it directly via `<img src="..."/>`
- No image upload functionality in Wave 1
- Seed data uses publicly available image URLs (e.g. Unsplash, Wikimedia Commons, or similar)
- No local file storage for media

---

## TR-4: Core data model

*Traces to: [BR-5](business.md#br-5-seeded-restaurant-supply-for-wave-1), [BR-10](business.md#br-10-discovery-ux-surfaces), [BR-11](business.md#br-11-ordering-flow), [BR-12](business.md#br-12-order-history)*

**Restaurant**
| Field | Type | Notes |
|-------|------|-------|
| id | string | UUID |
| name | string | |
| cuisine_type | string | e.g. "Japanese", "Italian" |
| description | string | |
| address | string | |
| city | string | |
| price_range | string | "$" / "$$" / "$$$" |
| cover_image_url | string | Public URL |
| average_rating | float | Derived from seeded reviews |
| delivery_radius_km | float | |

**Menu Section**
| Field | Type | Notes |
|-------|------|-------|
| id | string | UUID |
| restaurant_id | string | FK |
| name | string | e.g. "Starters", "Mains" |
| sort_order | integer | |

**Menu Item**
| Field | Type | Notes |
|-------|------|-------|
| id | string | UUID |
| section_id | string | FK |
| name | string | |
| description | string | |
| price | float | |
| image_url | string | Public URL |

**Review** (seeded, not user-submitted)
| Field | Type | Notes |
|-------|------|-------|
| id | string | UUID |
| restaurant_id | string | FK |
| author_name | string | Seeded fictitious name |
| rating | integer | 1–5 |
| body | string | Review text (renamed from `text` to match API spec and DDL — ADR-002) |
| review_date | string | ISO date (renamed from `date` to match DDL column name) |

**User**
| Field | Type | Notes |
|-------|------|-------|
| id | string | UUID |
| email | string | Unique |
| password_hash | string | |
| created_at | string | ISO datetime |

**Order**
| Field | Type | Notes |
|-------|------|-------|
| id | string | UUID |
| user_id | string | FK |
| restaurant_id | string | FK |
| delivery_address | string | Entered at checkout; nullable post-retention anonymisation |
| subtotal | float | Sum of (unit_price × quantity) for all items |
| delivery_fee | float | Flat fee; Wave 1 always $3.99 |
| total | float | subtotal + delivery_fee |
| status | string | "confirmed" / "delivering" / "delivered" (simulated) |
| created_at | string | ISO datetime |
| deleted_at | string | Soft delete; null = active |

*Note: `items` is not a JSON column on the Order record. Line items are stored in the separate **ORDER_ITEM** entity below. See ADR-002.*

**Order Item** (normalized — see ADR-002)
| Field | Type | Notes |
|-------|------|-------|
| id | string | UUID |
| order_id | string | FK → Order |
| menu_item_id | string | FK → Menu Item |
| item_name | string | Snapshot of menu item name at time of order |
| quantity | integer | ≥ 1 |
| unit_price | float | Snapshot of price at time of order |

---

## TR-5: Curated collections — static config

*Traces to: [BR-10](business.md#br-10-discovery-ux-surfaces)*

Curated collections are defined in a committed JSON config file. No admin UI or CMS. An engineer edits the file and restarts the server to update collections.

**File:** `data/collections.json`

**Shape:**
```json
[
  {
    "id": "best-ramen",
    "title": "Best Ramen in the City",
    "description": "Hand-picked noodle shops worth the trip",
    "restaurant_ids": ["uuid-1", "uuid-2", "..."]
  }
]
```

**Constraints:**
- Collections are loaded at server startup; no hot-reload required
- A restaurant can appear in multiple collections
- Collections with zero matching live restaurants are not rendered on the homepage
- Sort order of collections on the homepage is determined by their order in the config file

---

## TR-6: API style — REST/JSON

*Traces to: [BR-1](business.md#br-1-unified-discovery-to-delivery-experience), [BR-11](business.md#br-11-ordering-flow)*

The backend exposes a REST API over HTTP. All request and response bodies are JSON. No GraphQL, no WebSockets, no server-sent events.

**Constraints:**
- Standard HTTP verbs: GET (read), POST (create), PUT/PATCH (update)
- JSON responses for all endpoints including errors
- Auth via JWT bearer token in the Authorization header
- No real-time push — simulated delivery status is a static value returned on order confirmation, not a live stream

---

## TR-7: Search scope

*Traces to: [BR-10](business.md#br-10-discovery-ux-surfaces)*

Search matches against restaurant name and menu item names. Results return restaurants (not individual menu items) — a match on a menu item surfaces the parent restaurant in results.

**Constraints:**
- Search is case-insensitive
- Matches against: `restaurant.name` and `menu_item.name` (LIKE query)
- Neighbourhood filtering is via the `neighbourhood_id` UUID parameter — free-text neighbourhood name search is out of scope for Wave 1
- A restaurant appears once in results regardless of how many menu items matched
- Implementation: SQL LIKE query is sufficient for 100-restaurant seed dataset — no search index required for Wave 1
- Results page supports filtering by cuisine type and price range on top of the keyword search

---

## TR-8: Seed data geography and distribution

*Traces to: [BR-5](business.md#br-5-seeded-restaurant-supply-for-wave-1)*

All 100 seeded restaurants are located in New York City. The dataset covers realistic neighbourhood variety and a spread of cuisine types and price ranges.

**Required distribution:**
- Neighbourhoods: at least 5 distinct NYC neighbourhoods (e.g. Manhattan, Brooklyn, Queens, Williamsburg, Astoria)
- Cuisine types: 8–10 distinct types (e.g. Japanese, Italian, Mexican, Indian, Thai, American, Chinese, Mediterranean, Korean, French)
- Price ranges: roughly even spread across $, $$, $$$
- Ratings: spread from 3.5 to 5.0 — no restaurant below 3.5 (curation quality signal)
- Each restaurant has: minimum 3 menu sections, minimum 8 menu items, minimum 3 seeded reviews

---

## TR-9: Local dev startup

*Traces to: [TR-1](#tr-1-local-only-infrastructure-no-cloud-no-docker)*

The application starts with a single command from the repo root. No manual setup steps after a fresh clone beyond having Node.js installed.

**Startup script:** `./start.sh`

**What it does:**
1. Installs backend and frontend dependencies if `node_modules` is absent
2. Seeds the SQLite database with 100 restaurants on first run (skips if already seeded)
3. Starts the backend (Node.js) and frontend (React dev server) as concurrent processes in the same terminal

**Constraints:**
- Only runtime dependency is Node.js (LTS) — no other installs required
- Backend and frontend ports are configurable via environment variables with sensible defaults (e.g. backend: 3001, frontend: 3000)
- `start.sh` is idempotent — safe to run multiple times without corrupting data

---

## TR-10: Cart persistence

*Traces to: [BR-11](business.md#br-11-ordering-flow)*

Cart state is persisted in browser `localStorage`. No backend cart storage required.

**Constraints:**
- Cart survives tab closes, refreshes, and navigation away from the page
- Cart is browser-local — not tied to a user account, not synced across devices
- Cart is cleared on successful order confirmation
- Cart is cleared with a confirmation prompt when the user starts a new restaurant's order

---

## TR-11: Client-side routing

*Traces to: [BR-4](business.md#br-4-web-only-consumer-surface), [BR-10](business.md#br-10-discovery-ux-surfaces)*

The frontend uses React Router for client-side routing. No full page reloads on navigation.

**Key routes:**
| Route | Page |
|-------|------|
| `/` | Homepage — curated collections + search bar |
| `/search` | Search results (query via `?q=` param) |
| `/restaurants/:id` | Restaurant page |
| `/cart` | Cart review |
| `/checkout` | Checkout — address + payment |
| `/orders/:id` | Order confirmation |
| `/account/orders` | Order history |
| `/login` | Sign in |
| `/register` | Sign up |

**Constraints:**
- The Node.js backend serves the React bundle for all non-API routes (catch-all to `index.html`)
- All API routes are prefixed with `/api/`
- Direct URL access to any frontend route works without a 404
