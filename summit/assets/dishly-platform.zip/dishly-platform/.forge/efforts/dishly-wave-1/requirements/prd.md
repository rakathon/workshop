# PRD: dishly Wave 1 — Restaurant Discovery and Food Delivery

*Product / Effort: dishly-wave-1*
*Last updated: 2026-06-07*

---

## Problem Statement

Quality-conscious urban consumers who order food delivery 2–4× per week have no trustworthy surface that combines restaurant discovery with native ordering. Incumbent platforms (DoorDash, Uber Eats) rank results by paid placement and margin rather than food quality, forcing users across 2–3 apps to complete a single meal decision — discover on Yelp or Instagram, order on DoorDash — with no continuity between the two. The result is a fragmented experience that erodes trust and disadvantages quality-first restaurants that cannot afford placement fees.

dishly Wave 1 is a closed beta that proves the core thesis: a single, continuous surface can connect editorial curation with native ordering, with no paid placement and no app-switching. Wave 1 uses 100 seeded NYC restaurants, simulated delivery, and Stripe test-mode payment to validate the full discover → browse → order loop before investing in live restaurant onboarding, real courier dispatch, or native mobile clients. The target user is a quality-conscious urban consumer aged 22–40 who orders food delivery multiple times per week and is dissatisfied with surfaces that treat a neighbourhood ramen shop identically to a fast food chain.

---

## Goals

1. Full discover-to-order loop functional — measured by a user can complete homepage → restaurant → menu → cart → checkout → confirmation without errors in 100% of test runs against seeded data
2. 100 curated restaurants live at beta launch — measured by 100 seeded NYC restaurants browsable and searchable, each with complete menu (≥8 items, ≥3 sections), photos, and ≥3 reviews
3. Order success rate ≥90% in beta — measured by fewer than 10% of order submission attempts fail or error during the 4-week closed beta
4. Core loop usable on Chrome and Safari (desktop + mobile) — measured by all three discovery surfaces and the order flow functional on Chrome desktop, Chrome mobile, and Safari mobile with no JS errors
5. Wave 1 closed beta launched with zero P0 bugs open >24h — measured by no data-loss, broken checkout, or auth failure incidents remain open longer than 24 hours after discovery

---

## Non-Goals

- We are not building native iOS or Android apps — the consumer surface is web-only; no app store submission in Wave 1
- We are not onboarding real restaurants — Wave 1 launches with seeded data only; live curation ops and real restaurant partnerships are deferred to Wave 2
- We are not integrating a live delivery partner — delivery is fully simulated; no DoorDash Drive, Uber Direct, or real courier dispatch in Wave 1
- We are not processing real payments — Stripe is used in test mode only; no live charges, no PCI compliance scope for Wave 1
- We are not building a social discovery layer — no friend activity, curated lists, influencer feeds, or personalisation; curation is editorial only
- We are not building table reservations, loyalty programs, or grocery delivery — out of product scope permanently
- We are not targeting performance SLAs or WCAG compliance — deferred to Wave 2; local dev performance is sufficient for a closed beta of this scale

---

## Success Metrics

### Leading Indicators (early signal)

- Restaurant page engagement rate: % of homepage sessions that click into at least one restaurant page (target: ≥60%)
- Add-to-cart rate: % of restaurant page sessions that add at least one item to cart (target: ≥30%)
- Checkout funnel conversion: % of cart sessions that reach the Place Order screen (target: ≥70%)
- Auth gate conversion: % of users who complete sign-up/sign-in at the checkout gate (target: ≥60%)

### Lagging Indicators (final outcome)

- Full-loop completion rate at 4 weeks: ≥90% of order submissions result in a confirmed order with no critical error
- Beta user discovery quality signal: at 4 weeks, beta users report (qualitatively) that the discovery surface feels editorially curated, not algorithmic
- Zero P0 bugs open >24h across the full 4-week beta window
- Second order rate: >30% of beta users who place one order place a second within 2 weeks (qualitative signal only for Wave 1)

---

## Open Questions

None identified at this time. All engineering decisions are resolved in the technical requirements (TR-1 through TR-11) and architecture decision records (ADR-001, ADR-002). Real restaurant partnerships, live delivery integration, and performance benchmarks are explicitly deferred and not blocking Wave 1.

---

## Timeline / Dependencies

- **Target:** Wave 1 closed beta launch — all child epics complete and integrated
- **Dependencies (epic delivery order):**
  1. `project-scaffold-local-dev-infra` — monorepo, SQLite, start.sh; all other epics depend on this
  2. `core-backend-apis` — restaurant/menu/search APIs; consumer-web-discovery depends on this
  3. `user-auth` — JWT auth, register/login; native-ordering-checkout depends on this
  4. `consumer-web-discovery` — React frontend, discovery UX; depends on epics 1–3
  5. `native-ordering-checkout` — cart, checkout, order flow; depends on epics 1–4
  6. `restaurant-data-platform` — seed data completeness; parallel with above
  7. `analytics-instrumentation` — event tracking, ops dashboard; depends on epics 4–5
  8. `ops-onboarding-tool` — deferred to Wave 2
  9. `delivery-partner-integration` — deferred to Wave 2

---

## Requirements

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.
