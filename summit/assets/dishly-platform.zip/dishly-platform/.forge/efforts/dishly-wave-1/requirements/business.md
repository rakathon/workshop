# Business Requirements: dishly Wave 1 — Restaurant Discovery and Food Delivery

*Product / Effort: dishly-wave-1*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Unified discovery-to-delivery experience

**Priority:** P0

Quality-conscious consumers who order food delivery 2–4× per week have no trustworthy discovery surface. Incumbent platforms (DoorDash, Uber Eats) rank results by paid placement and margin, not food quality — forcing consumers to use 2–3 apps to complete a single meal decision (discover on Yelp or Instagram, order on DoorDash), with no continuity between the two. dishly must solve this as a single, continuous experience.

**Acceptance criteria:**
- A user can open dishly, discover a restaurant through curated content or search, and complete a food delivery order without leaving the app
- At no point in the flow is the user redirected to a third-party ordering interface
- Discovery entry points (curated collections, search results, editorial content) all lead directly to a restaurant page with a native order flow

---

## BR-2: Target user

**Priority:** P0

The primary user is a quality-conscious urban consumer aged 22–40 who orders food delivery multiple times per week. They currently stitch together multiple apps for a single meal decision and are dissatisfied with discovery surfaces that treat a neighbourhood ramen shop the same as a fast food chain. They expect the platform to surface food worth eating — not just food that is available.

**Acceptance criteria:**
- Product decisions (information architecture, curation bar, collection design) are evaluated against whether they serve this user's expectation of quality and discovery, not maximising order volume
- The onboarding flow and app store presence are tuned for this demographic

---

## BR-3: Earned curation standard

**Priority:** P0

Every restaurant listed on dishly must pass an internal curation review before appearing to consumers. The curation bar covers: food quality signal (reviews, press, reputation), menu completeness (photos and descriptions for all items), and delivery coverage (restaurant is within the delivery radius for at least one Wave 1 metro). A restaurant that fails any criterion is not listed — there is no tiered or degraded listing. Paid placement is permanently excluded as a ranking or listing mechanism.

**Acceptance criteria:**
- No restaurant appears on any consumer-facing surface before passing a curation review
- Curation pass rate is tracked and must remain at 100% of listed restaurants
- The internal ops onboarding process enforces completeness checks (photos, descriptions, delivery coverage) before a restaurant can be marked as live
- There is no mechanism in the product to accept payment for placement or ranking

---

## BR-4: Web-only consumer surface

**Priority:** P0

dishly is a web product. There is no iOS or Android app. The consumer-facing experience is a responsive web application accessible from any modern browser — no installation, no app store, no download required.

**Acceptance criteria:**
- The consumer-facing product works on both desktop and mobile browsers
- No native iOS or Android app is built or submitted as part of Wave 1
- The web experience is fully functional on mobile browsers at common phone screen sizes

---

## BR-5: Seeded restaurant supply for Wave 1

**Priority:** P0

Wave 1 launches with a mock data seed of 100 restaurants. Real restaurant onboarding (live curation ops, actual restaurant partnerships) is deferred to a future phase. The seed dataset must be realistic enough to validate the discovery UX and ordering flow end-to-end.

**Acceptance criteria:**
- 100 seeded restaurants are available in the system at launch, each with: name, cuisine type, description, location, delivery radius, and a complete menu (items with photos and descriptions)
- The seed data covers a realistic spread of cuisine types and price points representative of an urban metro
- The ordering and delivery flow works end-to-end against seeded restaurants
- The data model and APIs are designed to support real restaurant data in a future phase — the seed is content, not a structural shortcut

**Out of scope for Wave 1:**
- Real restaurant partnerships or live onboarding pipeline
- Internal ops onboarding tool (deferred — not needed until real restaurant onboarding begins)
- Restaurant supply ops team coordination

---

## BR-6: Simulated delivery for Wave 1

**Priority:** P0

Wave 1 uses simulated delivery. Orders flow through the full consumer experience — browse, cart, checkout, payment — but no real courier is dispatched. After order confirmation, the product displays a mocked delivery tracking state. This validates the end-to-end ordering experience without requiring a live delivery partner contract.

**Acceptance criteria:**
- A user can complete the full order journey: restaurant page → menu → cart → checkout → order confirmed
- A post-confirmation screen shows a simulated delivery status (e.g. "Order confirmed — estimated delivery 30–40 min")
- No real payment is charged in Wave 1 (payment flow uses test-mode processing)
- No real courier is dispatched for any Wave 1 order
- The delivery integration is designed so the simulated layer can be replaced with a live partner integration in Wave 2 without a full rebuild

**Out of scope for Wave 1:**
- Live delivery partner contract or production API integration
- Real-time courier tracking
- Live payment processing

---

## BR-7: Explicit scope exclusions

**Priority:** P0

The following are explicitly out of scope for Wave 1 and must not be designed, built, or partially implemented.

| Exclusion | Deferred to |
|-----------|-------------|
| Native iOS or Android app | Wave 2 (if needed) |
| Real restaurant onboarding and live curation ops | Wave 2 |
| Live delivery partner integration and real courier dispatch | Wave 2 |
| Table reservations or dine-in booking | Out of product scope permanently |
| Loyalty, rewards, cashback, or points | Out of product scope permanently |
| Social discovery layer (friend activity, curated lists, influencer feeds) | Wave 2 |
| Consumer acquisition program | Post Wave 1 launch |
| Restaurant-side CRM, guest management, or operator tooling | Out of product scope permanently |
| Grocery or non-restaurant food delivery | Out of product scope permanently |

**Acceptance criteria:**
- No Wave 1 implementation work begins on any item in this list
- Architecture and design decisions do not structurally foreclose Wave 2 additions (social layer, live delivery integration) but do not pre-build them

---

## BR-8: Wave 1 success criteria (MVP)

**Priority:** P0

Wave 1 is a closed beta. Success means the core loop works reliably for a small group of real users — not that all metrics are hit.

**Launch gates (must all be true before inviting beta users):**
- 100 seeded restaurants are live, browsable, and searchable
- A user can complete the full flow — discover → restaurant page → add to cart → checkout → order confirmed — without errors
- The app is accessible and usable on Chrome and Safari (desktop and mobile browser)
- No data loss on order submission

**Beta success signal (evaluate at 4 weeks post-launch):**
- Beta users can find a restaurant worth ordering from within a single session
- Orders complete without critical errors for ≥90% of attempts
- No P0 bugs (data loss, broken checkout, auth failures) open for more than 24 hours

**Explicitly not required for Wave 1:**
- Performance benchmarks (p95 latency targets deferred to Wave 2)
- WCAG accessibility compliance (deferred)
- Multi-browser compatibility beyond Chrome and Safari
- Uptime SLAs

---

## BR-9: Authentication model

**Priority:** P0

Discovery and browsing are open to anonymous users — no account required to explore restaurants, view menus, or use search. An account is required at checkout only.

**Acceptance criteria:**
- Any user can browse the full discovery surface (homepage, collections, search, restaurant pages, menus) without signing in
- An account gate appears when a user attempts to add an item to cart or proceed to checkout
- Sign-up and sign-in are available via email/password at minimum
- After sign-in at checkout, the user's cart is preserved and checkout continues without restarting

---

## BR-10: Discovery UX surfaces

**Priority:** P0

Wave 1 has three consumer-facing discovery surfaces. No personalisation, algorithmic ranking, or recommendation engine.

| Surface | Description |
|---------|-------------|
| Homepage | Curated collections (e.g. "Best Ramen in the City", "New Openings", "Under $15") with a prominent search bar |
| Search results | Keyword search with cuisine-type and basic filters (e.g. price range) |
| Restaurant page | Photos, description, reviews snippet, full menu with item photos and descriptions, and the order entry point |

**Acceptance criteria:**
- All three surfaces are functional at launch
- Curated collections are editable by the internal team without requiring a code deployment
- Search returns relevant results against the 100-restaurant seed dataset
- Restaurant page is the single entry point to the order flow — there is no shortcut that bypasses it

---

## BR-11: Ordering flow

**Priority:** P0

The order flow is a single-restaurant, linear checkout. No multi-restaurant carts, no order scheduling, no saved addresses for MVP.

**Flow:** Restaurant page → menu items → cart → delivery address (entered per order) → order summary → confirm → simulated delivery confirmation

**Acceptance criteria:**
- A cart contains items from one restaurant only — starting a new restaurant's order clears the existing cart (with a confirmation prompt)
- Delivery address is entered manually at checkout; no saved address book for Wave 1
- Delivery now only — no scheduled or future orders
- Payment by card only (test-mode payment for Wave 1); no digital wallets
- Order summary shows itemised breakdown, delivery address, and simulated delivery estimate before the user confirms
- A confirmed order screen is shown with a simulated status (e.g. "Your order is on its way — estimated 30–40 min")

---

## BR-12: Order history

**Priority:** P1

Authenticated users can view their past orders in an account section.

**Acceptance criteria:**
- A signed-in user can access an order history page listing all past orders
- Each order shows: restaurant name, order date, itemised list of items, and order total
- No reorder shortcut for Wave 1
- Order history is only visible to the authenticated user who placed the orders

---

## BR-13: Reviews display

**Priority:** P1

Restaurant pages show seeded reviews as a quality signal. No user-submitted reviews in Wave 1.

**Acceptance criteria:**
- Each restaurant page shows the average star rating (1–5) derived from seeded reviews
- 3–5 seeded review snippets are displayed inline on the restaurant page (author name, rating, text, date)
- No "see all reviews" link, no pagination, no sorting for Wave 1
- No review submission UI — users cannot write or submit reviews

---

## BR-14: No password reset

**Priority:** P1

Password reset is out of scope for Wave 1. If a beta user forgets their password, they re-register or an admin resets it manually.

**Acceptance criteria:**
- No "forgot password" link or reset flow is built
- No transactional email capability is required for Wave 1

---

## BR-15: Error states

**Priority:** P0

| Scenario | Behaviour |
|----------|-----------|
| Order submission fails (server error) | Clear error message on checkout page; cart preserved; user can retry; no partial order created |
| Restaurant page has no menu items | "Menu coming soon" placeholder — no broken or empty page |
| Search returns no results | Friendly empty state: "No restaurants found for [query] — try a different search" |

**Acceptance criteria:**
- None of the above scenarios result in an unhandled error or a blank page presented to the user
- Cart state is never lost due to a failed order submission

---

## BR-16: Restaurant page layout

**Priority:** P1

The restaurant page is the primary decision and order-entry surface.

**Layout (top to bottom):**
1. Hero image (cover photo)
2. Restaurant name, cuisine type, price range, average star rating
3. Short description
4. Menu — grouped by section (e.g. Starters, Mains, Desserts); each item shows name, description, price, photo, and an inline add-to-cart action
5. Reviews — average rating summary + 3–5 review snippets (author, rating, text, date)

**Acceptance criteria:**
- Add-to-cart is inline on each menu item — no separate menu item detail page
- If the restaurant's cover image cannot be loaded, a placeholder is shown instead
- Menu sections are collapsible at mobile screen sizes
- The page is fully usable without requiring complex client-side interactions — no infinite scroll, no modal-heavy flows
