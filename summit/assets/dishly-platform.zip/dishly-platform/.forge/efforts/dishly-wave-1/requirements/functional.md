# Functional Requirements — dishly Wave 1 — Restaurant Discovery and Food Delivery

*Effort: dishly-wave-1*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Anonymous browsing of discovery surfaces

*Traces to: [BR-9](business.md#br-9-authentication-model)*

The system must allow any unauthenticated user to access the homepage, curated collections, search, restaurant pages, and menus in full without requiring sign-in.

---

## FR-2: Account gate at cart action

*Traces to: [BR-9](business.md#br-9-authentication-model)*

When an unauthenticated user attempts to add an item to the cart or proceed to checkout, the system must present a sign-in or sign-up prompt. After successful authentication, the system must resume the cart action without requiring the user to restart.

---

## FR-3: Email/password registration and sign-in

*Traces to: [BR-9](business.md#br-9-authentication-model)*

The system must support account creation and sign-in using email address and password. After sign-in, the system must restore the user's in-session cart state.

---

## FR-4: Homepage curated collections

*Traces to: [BR-10](business.md#br-10-discovery-ux-surfaces)*

The system must render a homepage displaying one or more named curated restaurant collections. Each collection must show restaurant cards with sufficient detail to support a click-through decision. Collection content must be driven by a configuration source that can be updated without a code deployment.

---

## FR-5: Keyword search with cuisine filter

*Traces to: [BR-10](business.md#br-10-discovery-ux-surfaces)*

The system must provide a keyword search that matches restaurants by name or cuisine type. Search results must support filtering by cuisine type and price range. When a search returns no results, the system must display an explicit empty-state message.

---

## FR-6: Restaurant page with full menu

*Traces to: [BR-10](business.md#br-10-discovery-ux-surfaces), [BR-16](business.md#br-16-restaurant-page-layout)*

The system must render a restaurant page containing: cover photo (with placeholder fallback on load failure), restaurant name, cuisine type, price range, average star rating, short description, a full menu grouped by section, and review snippets. Each menu item must show name, description, price, photo, and an inline add-to-cart action.

---

## FR-7: Single-restaurant cart with conflict prompt

*Traces to: [BR-11](business.md#br-11-ordering-flow)*

The system must enforce a single-restaurant cart. When a user adds an item from a restaurant different from the one currently in the cart, the system must display a confirmation prompt before clearing the existing cart. The cart must not be cleared unless the user explicitly confirms.

---

## FR-8: Linear checkout flow with manual address entry

*Traces to: [BR-11](business.md#br-11-ordering-flow)*

The system must provide a checkout flow in the sequence: cart → manual delivery address entry → order summary → confirm. The order summary must display an itemised breakdown, the entered delivery address, and a simulated delivery estimate. The confirm action must not be available until a delivery address has been entered.

---

## FR-9: Test-mode card payment at checkout

*Traces to: [BR-11](business.md#br-11-ordering-flow)*

The system must accept card payment at checkout using a test-mode payment processor. No live charges must be made during Wave 1. Digital wallet payment methods must not be offered.

---

## FR-10: Simulated delivery confirmation screen

*Traces to: [BR-6](business.md#br-6-simulated-delivery-for-wave-1)*

After an order is confirmed, the system must display a confirmation screen showing a simulated delivery status message (e.g. "Your order is on its way — estimated 30–40 min"). No real courier dispatch must occur for any Wave 1 order.

---

## FR-11: Order history for authenticated users

*Traces to: [BR-12](business.md#br-12-order-history)*

The system must provide an order history page accessible to authenticated users. Each entry must show restaurant name, order date, itemised list of items, and order total. Order history must only be visible to the user who placed the orders.

---

## FR-12: Seeded reviews display on restaurant page

*Traces to: [BR-13](business.md#br-13-reviews-display)*

The system must display on each restaurant page an average star rating (1–5) and 3–5 seeded review snippets (author name, rating, text, date). No review submission interface must be offered to users in Wave 1.

---

## FR-13: Error handling for order submission failure

*Traces to: [BR-15](business.md#br-15-error-states)*

When an order submission fails due to a server error, the system must display a clear error message on the checkout page, preserve the user's cart in its current state, and allow the user to retry. The system must not create a partial order record on failure.

---

## FR-14: Graceful empty states for menu and search

*Traces to: [BR-15](business.md#br-15-error-states)*

When a restaurant page has no menu items, the system must display a placeholder message (e.g. "Menu coming soon") rather than a blank or broken section. When a search returns no results, the system must display a friendly empty-state message identifying the query and prompting the user to try a different search.

---

## FR-15: 100-restaurant seed data available at launch

*Traces to: [BR-5](business.md#br-5-seeded-restaurant-supply-for-wave-1)*

The system must make available at launch a seed dataset of 100 restaurants, each containing: name, cuisine type, description, location, delivery radius, and a complete menu with item photos and descriptions. The seed data must span multiple cuisine types and price points.

---
