# dishly — UX Strategy & Spec

*Effort: dishly-wave-1*  
*Mode: exploration → production (greenfield; Mode B tokens)*  
*Date: 2026-06-05*  
*Personas source: consumer-web-discovery/spec/design/personas.md*  
*Flows source: consumer-web-discovery/spec/design/user-flows.md*  
*Wireframes source: consumer-web-discovery/spec/design/wireframes.md*

---

## 1. Problem & framing

**Problem statement:**  
How might we help quality-conscious urban consumers (22–40) discover restaurants worth eating at, given that incumbent platforms poison signal with paid placements and force app-switching, so that they can find food they're proud to order in a single trusted surface?

**What success looks like:**
- *For the user:* They land on dishly and within one session find a restaurant they hadn't heard of, feel confident it's actually good, and complete an order without friction or surprises.
- *For the business:* Wave 1 closed beta users complete the full discover → order loop with ≥90% order success rate. At 4 weeks, beta users say the discovery surface feels editorially curated, not algorithmic.

**The one thing this must get right:**  
The homepage must earn trust in under 10 seconds. If it looks like DoorDash with better fonts, Maya leaves. The curation signal — editorial collection names, food photography quality, absence of "sponsored" — is the product's entire value proposition.

---

## 2. Users & jobs

### Persona 1 — Maya, The Intentional Orderer
- **Goal:** Discover restaurants she hasn't heard of that meet her quality bar; trust the surface without verification on another app.
- **Context of use:** Desktop browser at work (10am coffee slot); decision in under 4 minutes once she's decided.
- **Mental model:** Discovery is editorial browsing — closer to reading Eater than using a vending machine.
- **Key anxieties:** Platform has paid placements she can't see; photos won't be present; platform looks the same as every other food app.

**Primary job story:**  
*When I'm deciding where to order lunch and I don't know what I want, I want a curated starting point I can trust, so I can discover somewhere new without spending 20 minutes across three apps.*

---

### Persona 2 — Darius, The Efficient Professional
- **Goal:** Get a reliable non-chain meal without cognitive overhead; fast checkout.
- **Context of use:** Mobile, evening, after a long day; first satisfying result wins.
- **Mental model:** Discovery is a search/filter utility — a map between a constraint (Thai, under $25) and a result set.
- **Key anxieties:** Too much scrolling; hidden fees at checkout; checkout with too many steps.

**Secondary job story:**  
*When I know what cuisine I want and I need to order quickly, I want search + filter that gives me trustworthy results fast, so I can commit to a restaurant and be done in 3 minutes.*

---

### Persona 3 — Priya, The Explorer
- **Goal:** Feel like she discovered something worth sharing; beautiful food photography; predictable cost.
- **Context of use:** Desktop (large screen), evening, treat occasion; willing to spend 20 minutes if the platform earns it.
- **Mental model:** The homepage is a magazine cover; if it doesn't have editorial taste, she stops reading.
- **Key anxieties:** Generic feed with no point of view; surprise fees at checkout; account gate appearing before checkout.

**Tertiary job story:**  
*When I'm treating myself to delivery and I want to discover something new, I want a platform with visible taste and beautiful food photography, so I find somewhere I'll want to tell my friends about.*

---

## 3. Success signals

Using Google's HEART framework, scoped to Wave 1 beta:

| Signal | Metric | Target |
|--------|--------|--------|
| **Task success** | % of sessions that complete discover → order (with zero errors) | ≥90% order success rate |
| **Engagement** | % of sessions that click into at least one restaurant page from the homepage | ≥60% (discovery is working if over half of visitors engage with a restaurant) |
| **Retention** | Beta users who place a second order within 2 weeks | >30% (qualitative signal only for Wave 1) |

Note: no performance, WCAG, or uptime SLAs for Wave 1 (BR-8). Discovery engagement is the leading indicator.

---

## 4. Information architecture

### Sitemap

```
dishly
├── Homepage (/)
│   └── Curated collections (each: title, restaurant cards → Restaurant Page)
│   └── Search bar → Search Results
├── Search Results (/search?q=)
│   └── Filter: cuisine type, price range
│   └── Restaurant cards → Restaurant Page
├── Restaurant Page (/restaurants/:id)
│   ├── Hero + metadata
│   ├── Menu (sections + items + Add to Cart)
│   └── Reviews
├── Auth
│   ├── Sign In (/login or modal)
│   └── Sign Up (/register or modal)
├── Cart (/cart — drawer or page)
├── Checkout
│   ├── Step 1: Address (/checkout)
│   ├── Step 2: Payment
│   └── Step 3: Review + Confirm
├── Order Confirmation (/orders/:id)
└── Account
    └── Order History (/account/orders)
```

### Navigation model

| Layer | Pattern | Rationale |
|-------|---------|-----------|
| **Global** | Persistent header: logo (→ home), search bar (desktop), auth CTAs (unauthenticated) / user menu (authenticated), cart icon | Follows Jakob's law — users expect logo top-left, cart top-right. Auth secondary until needed. |
| **Local** | None for Wave 1 — collections are on homepage, not a separate nav | Simplicity. A nav with one destination (Home) is noise. |
| **Utility** | Cart icon with badge count; user menu dropdown post-auth | Cart visibility is critical — Darius wants to know his item count at a glance. |
| **Contextual** | Back arrow on restaurant pages; progress indicator in checkout | Supports Nielsen heuristic 3 (user control and freedom). |

**Rationale for flat IA:**  
100 seeded restaurants across 8–10 cuisines don't need deep hierarchy. The collections on the homepage act as curated entry points (for Maya and Priya); search handles intent-driven entry (Darius). Nesting or categories would add Hick's law overhead with no discovery benefit at this scale.

---

## 5. Key flows

### Flow A — Editorial discovery (Maya's path)
1. Homepage → sees "Best Ramen in the City" collection
2. Scans 4 restaurant cards (photo, name, rating, price)
3. Clicks a card → Restaurant Page
4. Scrolls hero → metadata → menu (evaluating photos + descriptions)
5. Scans reviews
6. Taps "Add to cart" → Auth modal (first order)
7. Signs up → item auto-added
8. Cart drawer → Proceed to Checkout
9. Address → Payment → Review → Place Order
10. Confirmation screen

**Key branching:**  
- If she already has items from a different restaurant: Cart Conflict Modal → Start new cart / Keep current cart.
- If hero image broken: full-width placeholder (no broken img icon).

**Exit point:** Confirmation, or back to homepage at any point via logo.

---

### Flow B — Search + filter (Darius's path)
1. Homepage → types "Thai" in search bar
2. Search Results page — filter chips visible above results
3. Applies "$" + "$$" price filter (client-side, instant)
4. Clicks a result row → Restaurant Page
5. Taps "Add to cart" → Auth modal → Signs up
6. Cart + Checkout (same as Flow A from step 8)

**Key branching:**  
- No results for query: empty state with "Browse collections" CTA.

---

### Flow C — Order history (Priya's return path)
1. Any page → header user menu → "Order history"
2. Order History page — reverse-chron list
3. Expands an order row → sees itemised detail
4. Clicks restaurant name → Restaurant Page (shareable)

---

### Failure paths

| Scenario | Response | Rationale |
|----------|----------|-----------|
| Order submission error | Inline error on Step 3; cart preserved; retry allowed | Norman feedback + Nielsen error recovery |
| Search no results | Empty state + "Browse collections" CTA | Empty states teach and redirect (microcopy) |
| Restaurant no menu | "Menu coming soon" placeholder | Prevents blank-page confusion (BR-15) |
| Broken image URL | Tasteful placeholder (fork icon / gradient) | Prevents broken-img icon eroding trust |

---

## 6. Page / screen intent

### S-01 — Homepage
**Single job:** Give Maya and Priya an editorial reason to trust dishly within 10 seconds.  
**Content priority order:**
1. Hero search bar + headline ("Find food worth eating")
2. First curated collection (name + 4 restaurant cards with photos)
3. Second and third collections
4. Footer

**Primary action:** Click a restaurant card (or use the search bar).  
**States:** Default (collections loaded); empty collection suppressed (per TR-5); no loading state needed for Wave 1 (server-rendered / fast-enough local API).

---

### S-02 — Search Results
**Single job:** Help Darius eliminate options fast via filter and land on a restaurant.  
**Content priority order:**
1. Pre-filled search bar (editable)
2. Filter chips: cuisine type + price range (inline, not modal)
3. Result count ("12 restaurants for Thai")
4. Result rows (photo, name, cuisine, rating, price, one-line description)

**Primary action:** Click a result row.  
**States:** Results present; empty state ("No restaurants found for '{query}'"); loading state optional for Wave 1.

---

### S-03 — Restaurant Page
**Single job:** Help Maya form a confident decision about this restaurant.  
**Content priority order:**
1. Hero image (full-width — the strongest trust signal)
2. Name, cuisine, price, rating
3. Short description
4. Menu (sections + items with photos, descriptions, prices, "Add to cart")
5. Reviews (3–5 snippets)

**Primary action:** "Add to cart" on a menu item.  
**States:** Default; no-menu ("Menu coming soon"); broken hero (placeholder); authenticated vs. unauthenticated (cart button triggers auth gate if unauthenticated).

---

### S-04 — Auth Modal
**Single job:** Gate checkout, not discovery; minimize friction; auto-resume on success.  
**Content priority:** Sign In / Sign Up tabs → email + password → submit.  
**Primary action:** Submit form.  
**States:** Sign In tab; Sign Up tab; inline error (invalid credentials / duplicate email / weak password); submitting (button disabled).  
**Note:** No "Forgot password" (BR-14). This is the single place to call out that explicitly — absence of a reset link is intentional, not a gap.

---

### S-05 — Cart Drawer
**Single job:** Show Darius exactly what he's ordered and what it'll cost (no surprises at checkout).  
**Content priority:**
1. Restaurant name (anchor)
2. Item list (name, quantity controls, price)
3. Subtotal + estimated delivery fee + estimated total
4. "Proceed to Checkout" CTA

**Primary action:** "Proceed to Checkout."  
**States:** Items present; empty ("Your cart is empty — explore restaurants").

---

### S-06 — Cart Conflict Modal
**Single job:** Prevent accidental cart destruction.  
**Content priority:** Clear statement of consequence ("Starting a new order will remove items from [Restaurant A]") → two clear choices.  
**Primary action:** "Keep current cart" (safe default, visually dominant).  
**Microcopy note:** Name both restaurants explicitly — "items from Matsuri Ramen" not "your current cart." Specificity prevents anxiety.

---

### S-07/08/09 — Checkout (3-step linear)
**Single job:** Get Darius through checkout in 3 steps with no new friction.  
**Content priority per step:**  
- Step 1: Address fields → Continue
- Step 2: Stripe card element → Continue
- Step 3: Full order summary (restaurant, address, items, fees, total) → Place Order

**Primary action:** "Place Order" on Step 3.  
**States:** Each step (with back navigation); error on Step 3 (inline, cart preserved); submitting ("Placing order…" button state).  
**Note:** Checkout header is simplified (logo only, no nav distractions) — conversion-centered design.

---

### S-10 — Order Confirmation
**Single job:** Give Darius a clear "done" moment; set expectations about delivery.  
**Content priority:**
1. Check icon + "Order confirmed!" heading (peak-end rule — invest in the finish)
2. Order number, restaurant name, delivery address
3. Simulated ETA ("Your order is on its way — estimated 30–40 minutes")
4. Total charged
5. Two CTAs: "View order history" + "Back to home"

**Primary action:** "Back to home" (most users' next action).  
**States:** Confirmed (only state).

---

### S-11 — Order History
**Single job:** Let Priya find the restaurant she ordered from so she can share it.  
**Content priority:**
1. Page heading "Order History"
2. Order rows (restaurant name → link, date, total, item count, expand toggle)
3. Expanded row: itemised items + delivery fee + total

**Primary action:** Click restaurant name link (navigates to restaurant page).  
**States:** Orders present; empty ("No orders yet — start exploring").

---

## 7. Interaction & content notes

### Presentation-level interactions
- **Collection rows** scroll horizontally on mobile (2.5 cards visible to signal scrollability — closure principle).
- **Menu sections** on mobile: tapping a section header collapses/expands that section. Default: all open on desktop, first section open on mobile.
- **Cart drawer** slides from right on desktop; full-screen bottom sheet on mobile.
- **Auth modal:** center modal on desktop; bottom sheet on mobile (80% screen height, rounded top corners).
- **Cart Conflict modal:** centered modal on both breakpoints.
- **Filter chips** on Search Results: single-select within price range; multi-select for cuisine (but in practice users pick one). No modal — inline chips only.
- **"Add to cart":** optimistic micro-animation (button briefly shows "Added ✓" for ~1s, then resets) — Norman feedback, Doherty threshold.
- **Quantity controls** in cart: minus at 1 shows a trash icon instead; pressing it removes the item (with no confirmation — low-stakes action).

### Microcopy direction
- **Brand voice:** Confident and discerning, not chirpy. dishly knows food. It doesn't say "Yum!" — it says "Best Ramen in the City" and means it.
- **Collection names:** editorial verbs and specificity ("Best Ramen in the City", "New Openings", "Under $15") — not generic utility labels ("Japanese Food", "Nearby").
- **Error messages:** human and blameless. "Something went wrong — your order wasn't placed. Please try again." Not "Error 500."
- **Empty states:** teach and invite. "No orders yet — start exploring" (not just "No results").
- **CTA labels:** outcome-describing verbs. "Proceed to Checkout" (not "Next"), "Place Order" (not "Submit"), "Start exploring" (not "Continue").
- **ETA language:** "estimated 30–40 minutes" — use "estimated" explicitly to set expectation that this is a simulation, not a tracked promise.

---

## 8. Accessibility notes

Commitments for this design (beyond WCAG 2.1 AA baseline, which Wave 1 defers officially per BR-8 — but the hi-fi mock will meet it):

- Heading hierarchy: `<h1>` once per page (site title/page name), `<h2>` for collection titles / restaurant name, `<h3>` for menu section headers.
- All "Add to cart" buttons include an accessible name: `aria-label="Add Tonkotsu Ramen to cart"` — prevents a page full of identical "Add" buttons from being indistinguishable to screen readers.
- Cart icon: `aria-label="Cart, 2 items"` (count reflected in accessible name, not just the badge).
- Auth modal: focus trapped within modal while open; returned to triggering element on close.
- Form fields in checkout: all have associated `<label>` elements; errors are associated via `aria-describedby`.
- Color: the design token set specifies contrast ratios; never use color alone to convey meaning (e.g. error states get both a red color and an icon + text).
- Touch targets: all interactive elements ≥ 44×44px, especially the quantity +/– controls and filter chips.
- Reduced motion: cart drawer slide and modal fade are gated on `prefers-reduced-motion: no-preference`.

---

## 9. Assumptions & open questions

| # | Assumption | Risk | Validation |
|---|-----------|------|-----------|
| A1 | Users will trust a curated discovery surface they haven't heard of if the visual design signals quality | High — if they don't trust the curation, the core value prop fails | Beta feedback at week 1: "did you feel the discovery results were trustworthy?" |
| A2 | Seeded reviews with no UGC provenance are acceptable for Wave 1 — users won't flag them as fake | Medium — Darius specifically said he's cynical about fake reviews | **CLOSED — not implemented for Wave 1.** Editorial attribution (`review.source` field) deferred to Wave 2. Beta users are informed participants; review provenance risk accepted for closed beta scope. |
| A3 | The auth gate at "Add to cart" is the right moment — users won't abandon at this point | Medium — Priya is a flight risk at any gate | Measure gate abandonment in beta: % of users who close the auth modal without signing in |
| A4 | Desktop is as important as mobile for the discovery phase | Supported by Priya persona — large-screen browsing is explicit | Both breakpoints are first-class in the mockup |
| A5 | A simulated "30–40 min" ETA is acceptable for a beta that explicitly sets expectations | Low — beta users are opted in; the UI labels it as simulated | N/A for Wave 1 |
| A6 | Three curated collections on the homepage is the right depth for 100 seeded restaurants | Low — more collections with fewer restaurants each risks diluting the signal | Can be tuned via `data/collections.json` without a code change |
| OQ1 | Should the search bar be in the persistent header on all pages, or only the homepage hero? | — | Recommend: persistent header search on all pages post-homepage (Darius will want to re-search from the restaurant page if a result isn't right) |
| OQ2 | ~~Delivery fee amount — is it a flat fee, distance-based, or a constant for Wave 1?~~ **RESOLVED:** Flat $3.99 for Wave 1 (simulated). The `Order` API schema now exposes `subtotal`, `delivery_fee` (always 399/scale=2), and `total`. Show as "Estimated delivery fee: $3.99" in cart (S-05) and confirmed as "Delivery fee: $3.99" at checkout Step 3 (S-09). | — | Resolved 2026-06-05 |
