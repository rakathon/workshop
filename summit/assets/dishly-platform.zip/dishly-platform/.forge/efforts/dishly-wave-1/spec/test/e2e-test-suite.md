# E2E Test Suite — dishly Wave 1

*Output dir:* `.forge/efforts/dishly-wave-1/spec/test/`
*Authored:* 2026-06-05
*Effort:* `dishly-wave-1`

## Why Test This

dishly Wave 1 delivers the complete discover-to-order loop — the single piece of functionality that defines whether the product is viable. A user must be able to open the app, find a restaurant they haven't heard of, trust the curation, and complete an order without leaving the surface. If any link in that chain breaks — authentication, search, menu loading, cart, checkout, order persistence — the product has failed its core promise. These E2E tests verify each critical path end-to-end against the running stack with a real SQLite database and Stripe test mode. They are the acceptance gate for Wave 1 beta launch ([BR-8](../../requirements/business.md#br-8-wave-1-success-criteria-mvp)).

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: Anonymous user browses homepage collections | [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces): all three discovery surfaces functional |
| SC-2: Anonymous user searches and filters restaurants | [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces): keyword search + cuisine/price filters |
| SC-3: Anonymous user views restaurant page with menu | [BR-16](../../requirements/business.md#br-16-restaurant-page-layout): full restaurant page layout |
| SC-4: New user registers an account | [BR-9](../../requirements/business.md#br-9-authentication-model): email/password registration |
| SC-5: Returning user signs in | [BR-9](../../requirements/business.md#br-9-authentication-model): sign-in returns JWT, preserves session |
| SC-6: Authenticated user completes full order flow | [BR-1](../../requirements/business.md#br-1-unified-discovery-to-delivery-experience), [BR-11](../../requirements/business.md#br-11-ordering-flow): discover → cart → checkout → confirmation |
| SC-7: Cart gate triggers auth on add-to-cart | [BR-9](../../requirements/business.md#br-9-authentication-model): account gate at cart, not at browse |
| SC-8: Cart conflict modal on restaurant switch | [BR-11](../../requirements/business.md#br-11-ordering-flow): single-restaurant cart constraint |
| SC-9: Order confirmation shows simulated delivery ETA | [BR-6](../../requirements/business.md#br-6-simulated-delivery-for-wave-1): simulated delivery status after confirmation |
| SC-10: Authenticated user views order history | [BR-12](../../requirements/business.md#br-12-order-history): order history lists past orders |
| SC-11: Search returns empty state for no-match query | [BR-15](../../requirements/business.md#br-15-error-states): friendly empty state, no crash |
| SC-12: Restaurant page with no menu shows placeholder | [BR-15](../../requirements/business.md#br-15-error-states): "Menu coming soon" for empty menu |
| SC-13: Order submission failure preserves cart | [BR-15](../../requirements/business.md#br-15-error-states): cart not lost on server error |
| SC-14: 100 seeded restaurants are browsable | [BR-5](../../requirements/business.md#br-5-seeded-restaurant-supply-for-wave-1): seed dataset present at launch |
| SC-15: App loads on mobile viewport (Chrome/Safari) | [BR-4](../../requirements/business.md#br-4-web-only-consumer-surface): responsive web, mobile functional |
| SC-16: Direct URL access to any route resolves | [TR-11](../../requirements/technical.md#tr-11-client-side-routing): SPA catch-all, no 404 on deep link |

## Scenarios

### SC-1: Anonymous user browses homepage collections

**Type:** e2e · `smoke-test` · `non-production`
**Given** the app is running with the 100-restaurant seed dataset
**When** an anonymous user navigates to `/`
**Then** at least 3 curated collections are visible, each with a non-empty title and at least 1 restaurant card
**And** no sign-in prompt appears on page load
**And** each restaurant card shows name, cover image, rating, price range, and cuisine type
**Verifies:** [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces) — "All three surfaces are functional at launch; curated collections with content"

---

### SC-2: Anonymous user searches and filters restaurants

**Type:** e2e · `smoke-test` · `non-production`
**Given** an anonymous user is on the homepage
**When** they submit the search query "ramen"
**Then** the `/search?q=ramen` page renders with at least 1 restaurant result
**And** each result row shows name, cuisine, price range, and rating
**When** they apply the "$$" price filter
**Then** only restaurants with `price_range = "$$"` are shown
**And** the result count label updates to reflect the filtered set
**Verifies:** [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces) — "Search returns results; filter by cuisine type and price range"

---

### SC-3: Anonymous user views restaurant page with menu

**Type:** e2e · `smoke-test` · `non-production`
**Given** an anonymous user clicks a restaurant card from any collection or search result
**When** the restaurant page loads at `/restaurants/:id`
**Then** the hero cover image is visible and non-broken
**And** the restaurant name, cuisine, price range, and average star rating appear
**And** the menu renders at least one section containing at least one item with name, description, price, and photo
**And** 3–5 seeded review snippets appear with author name, rating, and text
**Verifies:** [BR-16](../../requirements/business.md#br-16-restaurant-page-layout) — "Full restaurant page layout top-to-bottom"

---

### SC-4: New user registers an account

**Type:** e2e · `non-production`
**Given** a unique test email address and a password of 10+ characters
**When** the user submits `POST /api/auth/register` with those credentials
**Then** the response is `201 Created` containing a `data.user.id`, `data.user.email`, and `data.token`
**And** the JWT in `data.token` is valid and authorises subsequent requests
**And** a second registration with the same email returns `409 Conflict`
**Verifies:** [BR-9](../../requirements/business.md#br-9-authentication-model) — "Sign-up available via email/password"

---

### SC-5: Returning user signs in

**Type:** e2e · `smoke-test` · `non-production`
**Given** a registered user account in the database
**When** `POST /api/auth/login` is called with correct credentials
**Then** the response is `200 OK` with a fresh JWT
**When** `POST /api/auth/login` is called with the wrong password
**Then** the response is `401 Unauthorized` with an error code of `INVALID_CREDENTIALS`
**Verifies:** [BR-9](../../requirements/business.md#br-9-authentication-model) — "Sign-in available; account gate at checkout"

---

### SC-6: Authenticated user completes full order flow

**Type:** e2e · `smoke-test` · `non-production`
**Given** a registered and authenticated user
**And** a seeded restaurant with at least 2 menu items
**When** the user posts `POST /api/orders` with `restaurant_id`, 2 items, and a delivery address
**Then** the response is `201 Created`
**And** `data.status` is `"confirmed"`
**And** `data.items` contains the submitted items with correct `item_name`, `quantity`, and `unit_price`
**And** `data.total` equals the sum of (unit_price × quantity) for all items plus the delivery fee
**And** `data.delivery_address` matches the submitted address
**And** `GET /api/orders/:id` returns the same order for the same user
**Verifies:** [BR-1](../../requirements/business.md#br-1-unified-discovery-to-delivery-experience) — "User can complete discover → order without leaving the app"; [BR-11](../../requirements/business.md#br-11-ordering-flow) — "Full order flow functional"

---

### SC-7: Cart gate triggers auth on add-to-cart

**Type:** e2e · `non-production`
**Given** an anonymous user on a restaurant page
**When** they attempt to place an order without a JWT (`POST /api/orders` with no Authorization header)
**Then** the response is `401 Unauthorized`
**And** the response body contains `errors[0].code = "UNAUTHENTICATED"`
**Verifies:** [BR-9](../../requirements/business.md#br-9-authentication-model) — "Account gate appears when user attempts to add to cart or proceed to checkout"

---

### SC-8: Cart conflict — items from multiple restaurants rejected

**Type:** e2e · `non-production`
**Given** an authenticated user
**And** a valid order body containing items from two different restaurants
**When** `POST /api/orders` is submitted
**Then** the response is `422 Unprocessable Entity`
**And** `errors[0].code` indicates a cross-restaurant cart violation
**Verifies:** [BR-11](../../requirements/business.md#br-11-ordering-flow) — "A cart contains items from one restaurant only"

---

### SC-9: Order confirmation shows simulated delivery ETA

**Type:** e2e · `non-production`
**Given** an authenticated user who successfully places an order (SC-6)
**When** `GET /api/orders/:id` is called for that order
**Then** `data.status` is `"confirmed"` or `"delivering"`
**And** the status is one of the documented enum values: `confirmed`, `delivering`, `delivered`
**And** no real courier dispatch endpoint is called (no outbound HTTP to a delivery partner)
**Verifies:** [BR-6](../../requirements/business.md#br-6-simulated-delivery-for-wave-1) — "Simulated delivery — order confirmed screen with ETA; no real dispatch"

---

### SC-10: Authenticated user views order history

**Type:** e2e · `non-production`
**Given** an authenticated user with 2 previously placed orders
**When** `GET /api/users/me/orders` is called
**Then** the response is `200 OK` with both orders in the `data` array
**And** each order contains `restaurant_name`, `created_at`, `total`, and a non-empty `items` array
**And** orders are sorted newest-first by `created_at`
**Verifies:** [BR-12](../../requirements/business.md#br-12-order-history) — "Signed-in user can access order history listing all past orders"

---

### SC-11: Search returns empty state for no-match query

**Type:** e2e · `non-production`
**Given** the app is running with the 100-restaurant seed dataset
**When** `GET /api/restaurants?q=xyzzy_no_match_12345` is called
**Then** the response is `200 OK` with an empty `data` array
**And** the response does not return a 500 error or malformed JSON
**Verifies:** [BR-15](../../requirements/business.md#br-15-error-states) — "Search no results → friendly empty state, no crash"

---

### SC-12: Restaurant page with no menu items returns gracefully

**Type:** e2e · `non-production`
**Given** a restaurant record in the database with no menu sections or items
**When** `GET /api/restaurants/:id` is called for that restaurant
**Then** the response is `200 OK`
**And** `data.menu` is an empty array
**And** the response contains all required RestaurantDetail fields
**Verifies:** [BR-15](../../requirements/business.md#br-15-error-states) — "Restaurant page with no menu items → 'Menu coming soon' placeholder, not a broken page"

---

### SC-13: Order submission failure does not create a partial order

**Type:** e2e · `non-production`
**Given** an authenticated user submits an order with an `items` array that references a non-existent `menu_item_id`
**When** `POST /api/orders` is called
**Then** the response is `422 Unprocessable Entity`
**And** no order record is created in the database for this request
**And** the response body contains a human-readable error message
**Verifies:** [BR-15](../../requirements/business.md#br-15-error-states) — "Order submission fails → clear error message; cart preserved; no partial order created"

---

### SC-14: 100 seeded restaurants are browsable

**Type:** e2e · `smoke-test` · `non-production`
**Given** the database has been seeded by the startup script
**When** `GET /api/restaurants?limit=100` is called
**Then** the response contains exactly 100 restaurants
**And** each restaurant has a non-null `name`, `cuisine`, `price_range`, `cover_image_url`, and `average_rating`
**And** at least 8 distinct cuisine types are present across the 100 restaurants
**And** all three price ranges (`$`, `$$`, `$$$`) are represented
**Verifies:** [BR-5](../../requirements/business.md#br-5-seeded-restaurant-supply-for-wave-1) — "100 seeded restaurants browsable and searchable at launch"

---

### SC-15: App loads and is usable on mobile viewport

**Type:** e2e · `smoke-test` · `non-production`
**Given** the frontend is running
**When** it is rendered at 390×844 viewport (iPhone-equivalent)
**Then** the homepage renders without horizontal scroll overflow
**And** the search bar is visible and interactive
**And** at least one restaurant collection is visible without scrolling
**And** navigation elements are reachable via touch targets ≥ 44px
**Verifies:** [BR-4](../../requirements/business.md#br-4-web-only-consumer-surface) — "Web experience fully functional on mobile browsers at common phone screen sizes"

---

### SC-16: Direct URL access to any frontend route resolves correctly

**Type:** e2e · `non-production`
**Given** the backend serves the React bundle
**When** a browser navigates directly to `/restaurants/some-uuid`, `/account/orders`, or `/checkout`
**Then** the server responds with `200 OK` and the React `index.html`
**And** the React app renders without a 404 error page
**Verifies:** [TR-11](../../requirements/technical.md#tr-11-client-side-routing) — "Direct URL access to any frontend route works without a 404"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
