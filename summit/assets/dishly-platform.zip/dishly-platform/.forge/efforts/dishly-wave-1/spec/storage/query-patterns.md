# Query Patterns

*Effort: dishly-wave-1*  *Authored: 2026-06-05*

---

| # | Pattern | Entity | Filters | Sort | Source | Notes |
|---|---------|--------|---------|------|--------|-------|
| 1 | List all curated collections | CURATED_COLLECTION | — | sort_order ASC | BR-10, TR-5 | Homepage render |
| 2 | List restaurants in a collection | RESTAURANT | collection_id = ? | sort_order ASC | BR-10 | Via junction table |
| 3 | Search restaurants by name | RESTAURANT | name LIKE ? | — | TR-7 | Case-insensitive |
| 4 | Search restaurants by neighbourhood | RESTAURANT | neighbourhood_id = ? | — | TR-7 | City filter |
| 5 | Search restaurants by menu item name | MENU_ITEM → RESTAURANT | item name LIKE ? | — | TR-7 | Cross-table join; returns parent restaurant |
| 6 | Filter restaurants by cuisine | RESTAURANT | cuisine_id = ? | — | BR-10 | Cuisine filter on search results |
| 7 | Filter restaurants by price range | RESTAURANT | price_range = ? | — | BR-10 | Price filter on search results |
| 8 | Get restaurant by ID | RESTAURANT | id = ? | — | BR-10, BR-16 | Restaurant page |
| 9 | List menu sections for a restaurant | MENU_SECTION | restaurant_id = ? | sort_order ASC | BR-16 | Restaurant page menu |
| 10 | List menu items for a section | MENU_ITEM | section_id = ? | sort_order ASC | BR-16 | Restaurant page menu |
| 11 | List reviews for a restaurant | REVIEW | restaurant_id = ? | date DESC | BR-13 | 3–5 shown on restaurant page |
| 12 | Find user by email | USER | email = ? | — | BR-9 | Login |
| 13 | Get user by ID | USER | id = ? | — | BR-9 | JWT auth middleware |
| 14 | Create order | ORDER | — | — | BR-11 | Checkout submission |
| 15 | Get order by ID | ORDER | id = ? | — | BR-11 | Order confirmation screen |
| 16 | List orders by user | ORDER | user_id = ? | created_at DESC | BR-12 | Order history page |
| 17 | List order items for an order | ORDER_ITEM | order_id = ? | — | BR-12 | Order history detail |
| 18 | Get menu item by ID | MENU_ITEM | id = ? | — | BR-11 | Cart validation at checkout |
| 19 | List all cuisines | CUISINE | — | name ASC | BR-10 | Cuisine filter dropdown |
| 20 | List all neighbourhoods | NEIGHBOURHOOD | — | name ASC | TR-8 | Neighbourhood filter dropdown |
