# Logical Schema

*Effort: dishly-wave-1*  *Authored: 2026-06-05*

---

## Entity-Relationship Diagram

```mermaid
erDiagram
    USER ||--o{ ORDER : places

    RESTAURANT }o--|| CUISINE : "categorised as"
    RESTAURANT }o--|| NEIGHBOURHOOD : "located in"
    RESTAURANT ||--|{ MENU_SECTION : has
    RESTAURANT ||--o{ REVIEW : "reviewed by"
    RESTAURANT }o--o{ CURATED_COLLECTION : "featured in"

    MENU_SECTION ||--|{ MENU_ITEM : contains

    ORDER }o--|| RESTAURANT : "placed at"
    ORDER ||--|{ ORDER_ITEM : contains

    ORDER_ITEM }o--|| MENU_ITEM : references
```

## Entities

| Entity | Description |
|--------|-------------|
| USER | A registered consumer account; required to place an order |
| RESTAURANT | A curated restaurant in the NYC seed dataset |
| CUISINE | Normalised cuisine type (e.g. Japanese, Italian, Mexican) — shared across restaurants |
| NEIGHBOURHOOD | Named NYC neighbourhood (e.g. Brooklyn, Astoria) — shared across restaurants |
| MENU_SECTION | A named grouping of items on a restaurant menu (e.g. Starters, Mains, Desserts) |
| MENU_ITEM | An individual dish with name, description, price, and photo URL |
| REVIEW | A seeded review on a restaurant — not user-submitted in Wave 1 |
| CURATED_COLLECTION | A named editorial collection (e.g. "Best Ramen in the City") linking to a set of restaurants |
| ORDER | A completed order placed by a user at a single restaurant |
| ORDER_ITEM | A single menu item line within an order, capturing quantity and price at time of order |
