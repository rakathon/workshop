# Integration Test Suite — dishly Wave 1

*Output dir:* `.forge/efforts/dishly-wave-1/spec/test/`
*Authored:* 2026-06-05
*Effort:* `dishly-wave-1`
*Storage spec:* `spec/storage/logical-schema.md`, `spec/storage/sqlite.sql`

## Why Test This

dishly's correctness rests on its data layer: orders must be persisted atomically, users must be unique by email, order items must price-lock at time of order, and the cross-restaurant cart constraint must be enforced at persistence — not just at the API boundary. These integration tests run the Node.js service layer against a real in-process SQLite database (seeded and torn down per test suite run), verifying that the ORM/query layer respects schema constraints, correctly reads joined data structures, and handles failure modes. They sit between the contract tests (which verify shape) and the E2E tests (which verify journeys) — and they are the only tier that catches constraint violations, FK enforcement, and query-level edge cases.

**Integration subtypes active:**
- `database` — SQLite via the service's ORM/query layer
- `external-api` (Stripe test mode) — scoped to the payment processing path (advisory; see SC-21–SC-24)

**Messaging subtype:** not applicable (no Kafka or broker in Wave 1 — [TR-2](../../requirements/technical.md#tr-2-technology-stack), TR-6)

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: Seed script populates 100 restaurants | [TR-8](../../requirements/technical.md#tr-8-seed-data-geography-and-distribution), [BR-5](../../requirements/business.md#br-5-seeded-restaurant-supply-for-wave-1) — seed data integrity |
| SC-2: Restaurant read — full join with menu and reviews | [TR-4](../../requirements/technical.md#tr-4-core-data-model) — getRestaurant query shape |
| SC-3: Restaurant search — case-insensitive name match | [TR-7](../../requirements/technical.md#tr-7-search-scope) — search against name field |
| SC-4: Restaurant search — matches via menu item name | [TR-7](../../requirements/technical.md#tr-7-search-scope) — search propagates to items |
| SC-5: Restaurant search — no match returns empty result | [TR-7](../../requirements/technical.md#tr-7-search-scope) — zero-result behaviour |
| SC-6: Restaurant filter — cuisine_id narrows results | [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces) — cuisine filter |
| SC-7: Restaurant filter — price_range narrows results | [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces) — price filter |
| SC-8: Collections loaded from config at startup | [TR-5](../../requirements/technical.md#tr-5-curated-collections-static-config) — config-driven collections |
| SC-9: Collection excludes restaurants not in seed | [TR-5](../../requirements/technical.md#tr-5-curated-collections-static-config) — collections filter non-live restaurants |
| SC-10: User creation persists all required fields | [TR-4](../../requirements/technical.md#tr-4-core-data-model) — USER entity |
| SC-11: Duplicate email rejected at DB constraint | [BR-9](../../requirements/business.md#br-9-authentication-model), [TR-4](../../requirements/technical.md#tr-4-core-data-model) — unique email constraint |
| SC-12: Password hash stored, plaintext never persisted | [TR-4](../../requirements/technical.md#tr-4-core-data-model) — security: password storage |
| SC-13: JWT issued on registration is valid | [BR-9](../../requirements/business.md#br-9-authentication-model) — auth token lifecycle |
| SC-14: Order creation persists with correct price snapshot | [TR-4](../../requirements/technical.md#tr-4-core-data-model), [BR-11](../../requirements/business.md#br-11-ordering-flow) — ORDER + ORDER_ITEM |
| SC-15: Order items price-lock at time of order | [BR-11](../../requirements/business.md#br-11-ordering-flow) — unit_price copied, not referenced |
| SC-16: Cross-restaurant order rejected before persist | [BR-11](../../requirements/business.md#br-11-ordering-flow) — single-restaurant constraint |
| SC-17: Order with unknown menu_item_id rejected | [BR-11](../../requirements/business.md#br-11-ordering-flow), [BR-15](../../requirements/business.md#br-15-error-states) — FK integrity |
| SC-18: Order retrieval scoped to owning user | [BR-12](../../requirements/business.md#br-12-order-history) — user isolation |
| SC-19: Order history returns newest-first | [BR-12](../../requirements/business.md#br-12-order-history) — sort order |
| SC-20: Cart cleared from localStorage on confirm | [TR-10](../../requirements/technical.md#tr-10-cart-persistence) — cart cleared post-order |
| SC-21: Stripe test-mode charge attempt (advisory) | [BR-6](../../requirements/business.md#br-6-simulated-delivery-for-wave-1), [TR-2](../../requirements/technical.md#tr-2-technology-stack) — Stripe integration |
| SC-22: Stripe declined card handled gracefully (advisory) | [BR-15](../../requirements/business.md#br-15-error-states) — payment failure path |
| SC-23: Stripe network timeout handled gracefully (advisory) | [BR-15](../../requirements/business.md#br-15-error-states) — timeout failure path |
| SC-24: No real Stripe charge in Wave 1 (advisory) | [BR-6](../../requirements/business.md#br-6-simulated-delivery-for-wave-1) — Stripe test mode only |

## Scenarios

### SC-1: Seed script populates exactly 100 restaurants with required distribution

**Type:** integration · database
**Given** a fresh SQLite database
**When** the seed script runs to completion
**Then** the `restaurants` table contains exactly 100 rows
**And** at least 8 distinct `cuisine_id` values are present
**And** all three `price_range` values (`$`, `$$`, `$$$`) appear in the dataset
**And** all `average_rating` values are between 3.5 and 5.0
**And** every restaurant has at least 3 menu sections (via `menu_sections` join)
**And** every restaurant has at least 8 menu items (via `menu_items` join)
**And** every restaurant has at least 3 reviews (via `reviews` join)
**And** running the seed script a second time produces no duplicate rows (idempotent)
**Verifies:** [TR-8](../../requirements/technical.md#tr-8-seed-data-geography-and-distribution) — required seed distribution; [TR-9](../../requirements/technical.md#tr-9-local-dev-startup) — idempotent startup

---

### SC-2: Restaurant read — full join returns menu sections, items, and reviews

**Type:** integration · database
**Given** a seeded restaurant with known ID, 2 menu sections, 5 menu items, and 4 reviews
**When** the restaurant repository `findById(id)` is called
**Then** the returned object contains `id`, `name`, `cuisine`, `neighbourhood`, `price_range`, `cover_image_url`, `average_rating`, `description`, `address`, `delivery_radius_km`
**And** `menu` contains 2 sections, each with the correct `name` and `sort_order`
**And** the items nested within each section contain `id`, `name`, `description`, `price.value`, `price.scale`, `image_url`
**And** `reviews` contains up to 5 entries, each with `id`, `author_name`, `rating`, `body`, `review_date`
**Verifies:** [TR-4](../../requirements/technical.md#tr-4-core-data-model) — RestaurantDetail data model; [BR-16](../../requirements/business.md#br-16-restaurant-page-layout) — restaurant page data completeness

---

### SC-3: Search — case-insensitive match on restaurant name

**Type:** integration · database
**Given** a restaurant named "Matsuri Ramen" in the database
**When** `restaurantRepository.search({ q: "matsuri" })` is called
**Then** "Matsuri Ramen" is included in the results
**When** `restaurantRepository.search({ q: "MATSURI" })` is called
**Then** "Matsuri Ramen" is still included in the results
**Verifies:** [TR-7](../../requirements/technical.md#tr-7-search-scope) — case-insensitive search

---

### SC-4: Search — query matching a menu item name surfaces the parent restaurant

**Type:** integration · database
**Given** a restaurant "Lotus Thai Kitchen" with a menu item "Pad See Ew"
**When** `restaurantRepository.search({ q: "pad see ew" })` is called
**Then** "Lotus Thai Kitchen" is included in the results
**And** "Lotus Thai Kitchen" appears only once regardless of how many items matched
**Verifies:** [TR-7](../../requirements/technical.md#tr-7-search-scope) — search matches menu item names, returns parent restaurant deduplicated

---

### SC-5: Search — no-match query returns empty array, not an error

**Type:** integration · database
**Given** the seeded database
**When** `restaurantRepository.search({ q: "xyzzy_no_match_99999" })` is called
**Then** the result is an empty array
**And** no exception is thrown
**Verifies:** [TR-7](../../requirements/technical.md#tr-7-search-scope) — zero-result behaviour; [BR-15](../../requirements/business.md#br-15-error-states) — no crash on empty search

---

### SC-6: Filter by cuisine_id narrows results to matching restaurants only

**Type:** integration · database
**Given** the seeded database contains restaurants across multiple cuisines
**And** the UUID for the "Japanese" cuisine type is known
**When** `restaurantRepository.list({ cuisine_id: japaneseId })` is called
**Then** every restaurant in the result has `cuisine.id == japaneseId`
**And** no restaurant of a different cuisine appears in the result
**Verifies:** [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces) — cuisine filter

---

### SC-7: Filter by price_range narrows results correctly

**Type:** integration · database
**Given** the seeded database
**When** `restaurantRepository.list({ price_range: "$$" })` is called
**Then** every restaurant in the result has `price_range == "$$"`
**And** restaurants with `"$"` or `"$$$"` are absent from the result
**Verifies:** [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces) — price range filter

---

### SC-8: Collections loaded from data/collections.json at startup

**Type:** integration · database
**Given** `data/collections.json` defines 3 collections with known restaurant IDs
**When** the server starts and the collection repository is queried
**Then** 3 collections are returned in the order defined in the JSON file
**And** each collection's `restaurants` array contains only restaurants present in the seed database
**Verifies:** [TR-5](../../requirements/technical.md#tr-5-curated-collections-static-config) — static config collections; [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces) — collections editable by internal team

---

### SC-9: Collection silently excludes restaurant IDs not present in the database

**Type:** integration · database
**Given** `data/collections.json` references a restaurant UUID that does not exist in the database
**When** `collectionRepository.findAll()` is called
**Then** the response does not include the missing restaurant
**And** no error is thrown — the collection renders with the remaining valid restaurants
**Verifies:** [TR-5](../../requirements/technical.md#tr-5-curated-collections-static-config) — "collections with zero matching live restaurants are not rendered"

---

### SC-10: User creation persists all required fields

**Type:** integration · database
**Given** a unique email and a raw password
**When** `userRepository.create({ email, password })` is called
**Then** a user row is inserted with a generated UUID `id`, the provided `email`, a non-null `password_hash`, and a valid ISO 8601 `created_at`
**And** the returned user object contains `id`, `email`, `created_at` but NOT `password_hash`
**Verifies:** [TR-4](../../requirements/technical.md#tr-4-core-data-model) — USER entity; security: password_hash excluded from public user object

---

### SC-11: Duplicate email rejected with a constraint error

**Type:** integration · database
**Given** a user already exists with email "maya@example.com"
**When** `userRepository.create({ email: "maya@example.com", password: "..." })` is called
**Then** the call throws a constraint violation error (not an unhandled exception)
**And** the error is translatable to a `409 Conflict` response by the service layer
**And** no second user row exists for that email in the database
**Verifies:** [TR-4](../../requirements/technical.md#tr-4-core-data-model) — unique email constraint; [BR-9](../../requirements/business.md#br-9-authentication-model) — 409 on duplicate registration

---

### SC-12: Password stored as hash; plaintext never written to database

**Type:** integration · database
**Given** a user is created with password "MySecretPass99"
**When** the raw `users` table row is read directly
**Then** the `password_hash` column does not contain "MySecretPass99"
**And** the hash verifies correctly against "MySecretPass99" using the same hashing library
**Verifies:** [TR-4](../../requirements/technical.md#tr-4-core-data-model) — password_hash field; security baseline

---

### SC-13: JWT issued on registration is a valid signed token

**Type:** integration · database
**Given** a new user is registered via `authService.register(email, password)`
**When** the returned `token` is decoded and verified with the server's JWT secret
**Then** the payload contains `sub` (user UUID) and `iat` (issued-at timestamp)
**And** the token is not expired
**And** the same token authorises a call to `GET /dishly/v1/users/me` returning the correct user
**Verifies:** [TR-2](../../requirements/technical.md#tr-2-technology-stack) — JWT auth; [BR-9](../../requirements/business.md#br-9-authentication-model) — session created on registration

---

### SC-14: Order creation persists atomically with all required fields

**Type:** integration · database
**Given** an authenticated user and a seeded restaurant with 2 menu items (item A: $14.99, item B: $9.00)
**When** `orderRepository.create({ user_id, restaurant_id, items: [{menu_item_id: A, quantity: 2}, {menu_item_id: B, quantity: 1}], delivery_address })` is called
**Then** one order row is inserted with a UUID `id`, `user_id`, `restaurant_id`, `delivery_address`, `status = "confirmed"`, and valid `created_at`
**And** two order_item rows are inserted referencing the order
**And** `total` equals (14.99 × 2) + 9.00 = $38.98
**And** the order and its items are retrievable via `orderRepository.findById(id)`
**Verifies:** [TR-4](../../requirements/technical.md#tr-4-core-data-model) — ORDER + ORDER_ITEM entities; [BR-11](../../requirements/business.md#br-11-ordering-flow) — full order flow

---

### SC-15: Order item unit_price is copied at time of order (price snapshot)

**Type:** integration · database
**Given** a menu item priced at $15.00
**And** an order is placed referencing that item
**When** the menu item price is subsequently changed to $18.00 in the database
**Then** `orderRepository.findById(orderId).items[0].unit_price` still returns $15.00
**And** the original order total is unchanged
**Verifies:** [TR-4](../../requirements/technical.md#tr-4-core-data-model) — ORDER_ITEM stores `unit_price` as snapshot; [BR-11](../../requirements/business.md#br-11-ordering-flow) — no surprise fees

---

### SC-16: Order with items from two different restaurants is rejected before any write

**Type:** integration · database
**Given** menu items from two distinct restaurants: item X (restaurant A) and item Y (restaurant B)
**When** `orderRepository.create({ items: [X, Y], restaurant_id: A, ... })` is called
**Then** the call throws a validation error before any DB write
**And** no order row exists in the database for this attempt
**Verifies:** [BR-11](../../requirements/business.md#br-11-ordering-flow) — single-restaurant cart constraint enforced at service layer

---

### SC-17: Order referencing a non-existent menu_item_id is rejected

**Type:** integration · database
**Given** a UUID that does not correspond to any menu item in the database
**When** `orderRepository.create({ items: [{ menu_item_id: unknownId, quantity: 1 }], ... })` is called
**Then** the call throws a not-found or FK validation error
**And** no order row is created
**Verifies:** [BR-15](../../requirements/business.md#br-15-error-states) — invalid menu_item_id → 422, no partial order; [TR-4](../../requirements/technical.md#tr-4-core-data-model) — FK integrity

---

### SC-18: Order retrieval is scoped to the owning user

**Type:** integration · database
**Given** user A has placed order X and user B is a distinct user
**When** `orderRepository.findById(orderId, userId: userB.id)` is called
**Then** the call returns null or throws an authorisation error
**And** the order is NOT returned
**When** `orderRepository.findById(orderId, userId: userA.id)` is called
**Then** the full order is returned
**Verifies:** [BR-12](../../requirements/business.md#br-12-order-history) — "Order history is only visible to the authenticated user who placed the orders"

---

### SC-19: Order history returns orders in newest-first order

**Type:** integration · database
**Given** user A has placed 3 orders with `created_at` timestamps T1 < T2 < T3
**When** `orderRepository.listForUser(userId: userA.id)` is called
**Then** the result contains all 3 orders
**And** they are ordered T3, T2, T1 (newest first)
**Verifies:** [BR-12](../../requirements/business.md#br-12-order-history) — "reverse-chronological order history"

---

### SC-20: Cart is cleared from localStorage after successful order confirmation

**Type:** integration · database
**Given** an authenticated user with 2 items in their localStorage cart
**When** the order is successfully placed and the confirmation screen renders
**Then** `localStorage.getItem('dishly_cart')` is null or an empty structure
**And** the cart badge in the header shows 0
**Verifies:** [TR-10](../../requirements/technical.md#tr-10-cart-persistence) — "cart cleared on successful order confirmation"

---

### SC-21: Stripe test-mode charge produces a charge ID (advisory)

**Type:** integration · external-api (Stripe)
⚠️ *Advisory: no Stripe OpenAPI spec provided. Scenario derived from Stripe test-mode documentation. Validate against the Stripe SDK version in use before building.*
**Given** Stripe is configured in test mode (`STRIPE_SECRET_KEY=sk_test_...`)
**And** a Stripe test card number `4242 4242 4242 4242` with a future expiry
**When** the payment service calls `stripe.paymentIntents.create(...)` with a valid amount
**Then** the call returns a `PaymentIntent` object with `status == "succeeded"` or `"requires_confirmation"`
**And** `id` is a non-null string prefixed `pi_`
**And** no real charge is made (test mode assertion)
**Verifies:** [TR-2](../../requirements/technical.md#tr-2-technology-stack) — Stripe test mode; [BR-6](../../requirements/business.md#br-6-simulated-delivery-for-wave-1) — Wave 1 uses Stripe test mode, no live payment

---

### SC-22: Stripe declined card returns a handled error (advisory)

**Type:** integration · external-api (Stripe)
⚠️ *Advisory: see SC-21 note.*
**Given** Stripe is in test mode
**And** the test card `4000 0000 0000 0002` (always declined)
**When** the payment service calls `stripe.paymentIntents.create(...)` with this card
**Then** Stripe returns a `card_declined` error code
**And** the payment service translates this to a structured error (not an unhandled exception)
**And** the error is returned to the caller as a payment failure (not a 500 server error)
**And** no order record is created in the database
**Verifies:** [BR-15](../../requirements/business.md#br-15-error-states) — payment failure path; service handles Stripe errors gracefully

---

### SC-23: Stripe network timeout is handled gracefully (advisory)

**Type:** integration · external-api (Stripe)
⚠️ *Advisory: see SC-21 note. Simulate with a WireMock stub that delays beyond the SDK timeout.*
**Given** the Stripe SDK is configured with a request timeout of N seconds
**And** the Stripe endpoint is simulated to respond after N+1 seconds
**When** the payment service calls the Stripe charge endpoint
**Then** the SDK throws a timeout error
**And** the payment service catches it and returns a structured service error (not a 500 crash)
**And** no order record is committed to the database
**Verifies:** [BR-15](../../requirements/business.md#br-15-error-states) — order not placed on server error; integration standard R-6 — timeout failure mode

---

### SC-24: No real Stripe charge occurs in Wave 1 (advisory)

**Type:** integration · external-api (Stripe)
⚠️ *Advisory: see SC-21 note.*
**Given** the application is running with `STRIPE_SECRET_KEY=sk_test_...`
**When** the full checkout flow completes successfully
**Then** the Stripe dashboard shows only test-mode charges (charge IDs prefixed `ch_test_` or environment is `livemode: false`)
**And** no real bank account is debited
**Verifies:** [BR-6](../../requirements/business.md#br-6-simulated-delivery-for-wave-1) — "no real payment is charged in Wave 1"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
