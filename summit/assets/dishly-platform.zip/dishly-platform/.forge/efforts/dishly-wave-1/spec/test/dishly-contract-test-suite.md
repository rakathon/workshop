# Contract Test Suite — dishly API

*Output dir:* `.forge/efforts/dishly-wave-1/spec/test/`
*Authored:* 2026-06-05
*Effort:* `dishly-wave-1`
*Spec source:* `spec/api/dishly.yaml`

## Why Test This

The dishly REST API is the single integration boundary between the React frontend and the Node.js backend. Every field the frontend renders — restaurant name, menu item price, order status, JWT token — flows across this contract. If the backend drifts from the OpenAPI spec (a field renamed, a required property dropped, a status code changed), the frontend breaks silently at runtime. These contract tests load `dishly.yaml` at test execution time and assert that every documented endpoint returns the exact shape and status code defined there. They run in CI on every backend PR and catch interface drift before it reaches development.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: POST /auth/register — 201 Created | registerUser happy path shape |
| SC-2: POST /auth/register — 409 Conflict | duplicate email response shape |
| SC-3: POST /auth/register — 422 Validation | invalid input response shape |
| SC-4: POST /auth/login — 200 OK | loginUser happy path shape |
| SC-5: POST /auth/login — 401 Unauthorized | invalid credentials response shape |
| SC-6: GET /users/me — 200 OK | getCurrentUser shape |
| SC-7: GET /users/me — 401 Unauthorized | missing/invalid JWT shape |
| SC-8: GET /cuisines — 200 OK | listCuisines shape |
| SC-9: GET /neighbourhoods — 200 OK | listNeighbourhoods shape |
| SC-10: GET /collections — 200 OK | listCollections shape |
| SC-11: GET /collections/:id — 200 OK | getCollection shape |
| SC-12: GET /collections/:id — 404 Not Found | missing collection shape |
| SC-13: GET /restaurants — 200 OK (no filters) | listRestaurants shape |
| SC-14: GET /restaurants?q=ramen — 200 OK | search response shape |
| SC-15: GET /restaurants/:id — 200 OK | getRestaurant detail shape |
| SC-16: GET /restaurants/:id — 404 Not Found | missing restaurant shape |
| SC-17: POST /orders — 201 Created | createOrder happy path shape |
| SC-18: POST /orders — 401 Unauthorized | unauthenticated order attempt shape |
| SC-19: POST /orders — 422 Unprocessable | cross-restaurant / invalid items shape |
| SC-20: GET /orders/:id — 200 OK | getOrder shape |
| SC-21: GET /orders/:id — 401 Unauthorized | unauthenticated order fetch shape |
| SC-22: GET /orders/:id — 403 Forbidden | wrong user order fetch shape |
| SC-23: GET /orders/:id — 404 Not Found | missing order shape |
| SC-24: GET /users/me/orders — 200 OK | listUserOrders shape + pagination |
| SC-25: GET /users/me/orders — 401 Unauthorized | unauthenticated history fetch shape |

## Scenarios

### SC-1: POST /auth/register — 201 Created

**Type:** contract
**Given** a request body with a unique valid email and a password of 8+ characters
**When** `POST /dishly/v1/auth/register` is called
**Then** the response status is `201`
**And** the body matches `registerUser` 201 schema from `dishly.yaml`:
  - `data.user.id` is a UUID string
  - `data.user.email` matches the submitted email
  - `data.user.created_at` is an ISO 8601 datetime
  - `data.token` is a non-empty string
  - `meta.status.code` is present
  - `meta.operation.request_id` is a UUID
**And** the `Location` header is present and matches `/dishly/v1/users/me`
**Verifies:** `registerUser` 201 — [BR-9](../../requirements/business.md#br-9-authentication-model)

---

### SC-2: POST /auth/register — 409 Conflict

**Type:** contract
**Given** an email address already registered in the database
**When** `POST /dishly/v1/auth/register` is called with that email
**Then** the response status is `409`
**And** the body matches the 409 schema:
  - `errors` is a non-empty array
  - `errors[0].code` is a non-empty string
  - `errors[0].message` is a non-empty string
  - `meta.operation.request_id` is a UUID
**Verifies:** `registerUser` 409 — [BR-9](../../requirements/business.md#br-9-authentication-model)

---

### SC-3: POST /auth/register — 422 Validation

**Type:** contract
**Given** a request body with an invalid email format (e.g. "not-an-email") or password shorter than 8 characters
**When** `POST /dishly/v1/auth/register` is called
**Then** the response status is `422`
**And** the body matches the 422 schema:
  - `errors` is a non-empty array
  - `errors[0].code` is present
  - `errors[0].message` is present
  - `errors[0].details.field` identifies the failing field
**Verifies:** `registerUser` 422

---

### SC-4: POST /auth/login — 200 OK

**Type:** contract
**Given** a registered user's valid email and password
**When** `POST /dishly/v1/auth/login` is called
**Then** the response status is `200`
**And** the body matches `loginUser` 200 schema:
  - `data.user.id` is a UUID
  - `data.user.email` matches the input
  - `data.token` is a non-empty string
  - `meta.operation.request_id` is a UUID
**Verifies:** `loginUser` 200 — [BR-9](../../requirements/business.md#br-9-authentication-model)

---

### SC-5: POST /auth/login — 401 Unauthorized

**Type:** contract
**Given** a valid email but incorrect password
**When** `POST /dishly/v1/auth/login` is called
**Then** the response status is `401`
**And** `errors[0].code` is a non-empty string
**And** `meta` is present
**Verifies:** `loginUser` 401

---

### SC-6: GET /users/me — 200 OK

**Type:** contract
**Given** a valid JWT in the `Authorization: Bearer <token>` header
**When** `GET /dishly/v1/users/me` is called
**Then** the response status is `200`
**And** `data.id` is a UUID
**And** `data.email` is a non-empty email string
**And** `data.created_at` is an ISO 8601 datetime
**Verifies:** `getCurrentUser` 200

---

### SC-7: GET /users/me — 401 Unauthorized

**Type:** contract
**Given** no Authorization header (or an expired/malformed token)
**When** `GET /dishly/v1/users/me` is called
**Then** the response status is `401`
**And** `errors` is a non-empty array with `code` and `message` present
**Verifies:** `getCurrentUser` 401

---

### SC-8: GET /cuisines — 200 OK

**Type:** contract
**Given** the seed database is loaded
**When** `GET /dishly/v1/cuisines` is called
**Then** the response status is `200`
**And** `data` is an array of objects each with `id` (UUID) and `name` (string)
**And** at least 8 distinct cuisine names are present
**Verifies:** `listCuisines` 200 — [TR-8](../../requirements/technical.md#tr-8-seed-data-geography-and-distribution)

---

### SC-9: GET /neighbourhoods — 200 OK

**Type:** contract
**Given** the seed database is loaded
**When** `GET /dishly/v1/neighbourhoods` is called
**Then** the response status is `200`
**And** `data` is an array of objects each with `id` (UUID) and `name` (string)
**And** at least 5 distinct neighbourhood names are present
**Verifies:** `listNeighbourhoods` 200 — [TR-8](../../requirements/technical.md#tr-8-seed-data-geography-and-distribution)

---

### SC-10: GET /collections — 200 OK

**Type:** contract
**Given** `data/collections.json` is loaded at startup
**When** `GET /dishly/v1/collections` is called
**Then** the response status is `200`
**And** `data` is an array of Collection objects each with `id`, `title`, `description`, and `restaurants`
**And** each restaurant in `restaurants` matches the `RestaurantSummary` schema
**And** all required `RestaurantSummary` fields are non-null: `id`, `name`, `cuisine`, `neighbourhood`, `price_range`, `cover_image_url`, `average_rating`
**Verifies:** `listCollections` 200 — [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces), [TR-5](../../requirements/technical.md#tr-5-curated-collections-static-config)

---

### SC-11: GET /collections/:id — 200 OK

**Type:** contract
**Given** a valid collection ID from `data/collections.json`
**When** `GET /dishly/v1/collections/:id` is called
**Then** the response status is `200`
**And** `data` matches the `Collection` schema with the correct `id` and `title`
**Verifies:** `getCollection` 200

---

### SC-12: GET /collections/:id — 404 Not Found

**Type:** contract
**Given** a collection ID that does not exist in `data/collections.json`
**When** `GET /dishly/v1/collections/:id` is called
**Then** the response status is `404`
**And** `errors[0].code` is present (e.g. `NOT_FOUND`)
**Verifies:** `getCollection` 404

---

### SC-13: GET /restaurants — 200 OK (no filters)

**Type:** contract
**Given** the seed database is loaded
**When** `GET /dishly/v1/restaurants` is called with no query parameters
**Then** the response status is `200`
**And** `data` is an array of `RestaurantSummary` objects
**And** each object has all required fields: `id`, `name`, `cuisine.id`, `cuisine.name`, `neighbourhood.id`, `neighbourhood.name`, `price_range`, `cover_image_url`, `average_rating`
**And** `average_rating` is a float between 1.0 and 5.0
**And** `price_range` is one of `"$"`, `"$$"`, `"$$$"`
**And** `pagination` is present in the response body
**Verifies:** `listRestaurants` 200 — [BR-10](../../requirements/business.md#br-10-discovery-ux-surfaces)

---

### SC-14: GET /restaurants?q=ramen — 200 OK (keyword search)

**Type:** contract
**Given** the seed database contains restaurants with "ramen" in their name or menu items
**When** `GET /dishly/v1/restaurants?q=ramen` is called
**Then** the response status is `200`
**And** all items in `data` conform to the `RestaurantSummary` schema
**And** the search is case-insensitive (query "RAMEN" returns the same set as "ramen")
**Verifies:** `listRestaurants` 200 with search — [TR-7](../../requirements/technical.md#tr-7-search-scope)

---

### SC-15: GET /restaurants/:id — 200 OK

**Type:** contract
**Given** a valid restaurant UUID from the seed database
**When** `GET /dishly/v1/restaurants/:id` is called
**Then** the response status is `200`
**And** `data` matches the `RestaurantDetail` schema:
  - All `RestaurantSummary` fields are present
  - `description` is a non-empty string
  - `address` is a non-empty string
  - `delivery_radius_km` is a positive float
  - `menu` is an array of `MenuSection` objects each containing `items`
  - Each `MenuItem` has `id`, `name`, `description`, `price.value`, `price.scale`, `image_url`
  - `reviews` is an array of up to 5 `Review` objects
  - Each `Review` has `id`, `author_name`, `rating` (1–5), `body`, `review_date`
**Verifies:** `getRestaurant` 200 — [BR-16](../../requirements/business.md#br-16-restaurant-page-layout), [TR-4](../../requirements/technical.md#tr-4-core-data-model)

---

### SC-16: GET /restaurants/:id — 404 Not Found

**Type:** contract
**Given** a UUID that does not correspond to any restaurant in the database
**When** `GET /dishly/v1/restaurants/:id` is called
**Then** the response status is `404`
**And** `errors[0].code` equals `NOT_FOUND`
**Verifies:** `getRestaurant` 404

---

### SC-17: POST /orders — 201 Created

**Type:** contract
**Given** an authenticated user (valid JWT) and a request body with a valid `restaurant_id`, at least 1 item with valid `menu_item_id` and `quantity ≥ 1`, and a `delivery_address` of 5+ characters
**When** `POST /dishly/v1/orders` is called
**Then** the response status is `201`
**And** the `Location` header is present
**And** `data` matches the `Order` schema:
  - `id` is a UUID
  - `restaurant_id` matches the submitted value
  - `restaurant_name` is a non-empty string
  - `items` is a non-empty array matching `OrderItemResponse` schema
  - Each item has `id`, `menu_item_id`, `item_name`, `quantity`, `unit_price.value`, `unit_price.scale`
  - `delivery_address` matches the submitted value
  - `total.value` and `total.scale` are integers
  - `status` is one of `confirmed`, `delivering`, `delivered`
  - `created_at` is an ISO 8601 datetime
**Verifies:** `createOrder` 201 — [BR-11](../../requirements/business.md#br-11-ordering-flow), [TR-4](../../requirements/technical.md#tr-4-core-data-model)

---

### SC-18: POST /orders — 401 Unauthorized

**Type:** contract
**Given** a valid order request body but no `Authorization` header
**When** `POST /dishly/v1/orders` is called
**Then** the response status is `401`
**And** `errors[0].code` is present
**Verifies:** `createOrder` 401 — [BR-9](../../requirements/business.md#br-9-authentication-model)

---

### SC-19: POST /orders — 422 Unprocessable Entity

**Type:** contract
**Given** an authenticated user and an order request body where `items` reference menu items from two different restaurants
**When** `POST /dishly/v1/orders` is called
**Then** the response status is `422`
**And** `errors` is a non-empty array with `code` and `message`
**And** no order record is created
**Verifies:** `createOrder` 422 — [BR-11](../../requirements/business.md#br-11-ordering-flow) single-restaurant cart constraint

---

### SC-20: GET /orders/:id — 200 OK

**Type:** contract
**Given** an authenticated user and an order ID belonging to that user
**When** `GET /dishly/v1/orders/:id` is called
**Then** the response status is `200`
**And** `data` matches the `Order` schema with all required fields
**Verifies:** `getOrder` 200 — [BR-12](../../requirements/business.md#br-12-order-history)

---

### SC-21: GET /orders/:id — 401 Unauthorized

**Type:** contract
**Given** a valid order ID but no `Authorization` header
**When** `GET /dishly/v1/orders/:id` is called
**Then** the response status is `401`
**Verifies:** `getOrder` 401

---

### SC-22: GET /orders/:id — 403 Forbidden

**Type:** contract
**Given** user A's order ID and user B's valid JWT
**When** `GET /dishly/v1/orders/:id` is called with user B's token
**Then** the response status is `403`
**And** `errors[0].code` is present
**Verifies:** `getOrder` 403 — order isolation between users

---

### SC-23: GET /orders/:id — 404 Not Found

**Type:** contract
**Given** a UUID that does not correspond to any order
**When** `GET /dishly/v1/orders/:id` is called with a valid JWT
**Then** the response status is `404`
**And** `errors[0].code` equals `NOT_FOUND`
**Verifies:** `getOrder` 404

---

### SC-24: GET /users/me/orders — 200 OK with pagination

**Type:** contract
**Given** an authenticated user with at least 2 placed orders
**When** `GET /dishly/v1/users/me/orders` is called
**Then** the response status is `200`
**And** `data` is an array of `Order` objects (newest first)
**And** each order contains all required `Order` schema fields
**And** `pagination` is present in the response body (with `next` field, nullable)
**Verifies:** `listUserOrders` 200 — [BR-12](../../requirements/business.md#br-12-order-history)

---

### SC-25: GET /users/me/orders — 401 Unauthorized

**Type:** contract
**Given** no Authorization header
**When** `GET /dishly/v1/users/me/orders` is called
**Then** the response status is `401`
**Verifies:** `listUserOrders` 401

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
