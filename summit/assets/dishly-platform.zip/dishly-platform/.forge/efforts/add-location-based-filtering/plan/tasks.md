# Implementation Plan: add-location-based-filtering

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

```mermaid
gantt
    title  add-location-based-filtering — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Seed Expansion (BR-4)
    Expand seed.js with 5 cities + ~100 restaurants   :task1, 1, 2
    Seed cluster observable                           :milestone, m1, 2, 0

    section City Selector Component (BR-2, BR-3)
    cityBounds.js — hardcoded bounding boxes          :task2, 1, 2
    CitySelector.jsx — combobox + Near me             :task3, 1, 2
    City selector CSS                                 :task4, 1, 2
    City selector cluster observable                  :milestone, m2, 2, 0

    section Surface Wiring (BR-1)
    NavBar — CitySelector + useCityFilter hook        :task5, 2, 3
    Home hero — CitySelector in search bar            :task6, 2, 3
    Search page — city filter row + neighbourhood_id  :task7, 2, 3
    Surface wiring cluster observable                 :milestone, m3, 3, 0

    section Tests
    Integration tests — seed verification             :task8, 3, 4
    E2E + UI E2E test suites                          :task9, 3, 4
```

---

## Wave 1 — Seed Expansion + Component Foundation

### TASK-001 [auto][wave:1]

Expand `backend/src/db/seed.js` with 5 new US cities (Los Angeles, Chicago, Boston, Miami, San Francisco) and ~20 restaurants each (~100 new restaurants). Update idempotency check from restaurant count to neighbourhood count (≥10). Assign realistic Unsplash cover image URLs per cuisine type.

**Satisfies:** BR-4 — 5 new cities, ~20 restaurants each, idempotent re-run
**Standards:** none (seed script — no handler logic)
**Required tests:** none (migration/seed task; verified by integration suite SC-1..SC-5)

---

### TASK-002 [auto][wave:1]

Create `frontend/src/config/cityBounds.js` with hardcoded ±0.5° lat/lng bounding boxes for all 6 cities (NYC, LA, Chicago, Boston, Miami, SF) and a `matchCity(lat, lng, cities)` function that returns the closest matching city.

**Satisfies:** TR-3 — city bounding boxes hardcoded in frontend config
**Standards:** none
**Required tests:** none (config file — tested via Near me E2E scenarios)

---

### TASK-003 [tdd][wave:1]

Create `frontend/src/components/CitySelector.jsx` — a combobox component with: city list from `GET /neighbourhoods`, type-to-filter dropdown, "Near me" geolocation trigger, localStorage persistence via `useCityFilter` hook, clear button, and geolocation error state. Exports both `CitySelector` (component) and `useCityFilter` (hook).

**Satisfies:** BR-2 — city selector combobox; BR-3 — Near me geolocation; TR-2, TR-3, TR-4
**Standards:** none
**Required tests:**
- City dropdown opens and shows all cities (SC-2 ui-e2e)
- Type-to-filter narrows the list (SC-3 ui-e2e)
- Selecting a city closes dropdown and shows active style (SC-4 ui-e2e)
- Clear button resets to "All cities" (SC-5 ui-e2e)
- Near me loading state visible (SC-6 ui-e2e)
- Geolocation denied shows inline error (SC-7 ui-e2e)

---

### TASK-004 [auto][wave:1]

Add city selector CSS to `frontend/src/index.css`: `.city-selector`, `.city-selector__btn`, `.city-selector__btn--active`, `.city-selector__clear`, `.city-dropdown`, `.city-dropdown__item`, `.city-dropdown__item--near-me`, `.city-dropdown__empty`, `.city-selector__geo-error`, and hero search divider styles.

**Satisfies:** BR-2 — city selector visual design (dishly tokens only)
**Standards:** none
**Required tests:** none (styling — covered by UI E2E visual assertions)

---

## Wave 2 — Surface Wiring

### TASK-005 [tdd][wave:2]

Update `frontend/src/components/NavBar.jsx` to import `CitySelector` and `useCityFilter`, mount the city selector left of the keyword search input, and listen for `dishly:auth` to clear city on sign-out.

**Satisfies:** BR-2 — city selector visible in NavBar; BR-1 — filter label "City"
**Standards:** none
**Required tests:**
- City selector visible in NavBar (SC-1 ui-e2e)
- City cleared on sign-out (SC-5 e2e)

---

### TASK-006 [tdd][wave:2]

Update `frontend/src/pages/Home.jsx` to import `CitySelector` and `useCityFilter`, add city selector inside hero search bar with a visual divider, and apply city filter to both home page collections and fallback restaurant fetch via `neighbourhood_id`.

**Satisfies:** BR-2 — city selector in home hero; BR-1 — city filters home results
**Standards:** none
**Required tests:**
- City selector visible in Home hero (SC-9 ui-e2e)
- Home collections filter to selected city (SC-1 e2e)

---

### TASK-007 [tdd][wave:2]

Update `frontend/src/pages/Search.jsx` to import `CitySelector` and `useCityFilter`, add a "City" filter row above cuisine and price filters, pass `neighbourhood_id` to `GET /restaurants` when a city is active, and sync city changes from NavBar via `dishly:city-changed` event.

**Satisfies:** BR-2 — city selector on Search page; BR-1 — neighbourhood_id filter wired
**Standards:** standards/api/rest/contracts.md (query param naming)
**Required tests:**
- City filter row visible on Search page (SC-10 ui-e2e)
- City filter applied to restaurant results (SC-1 e2e)
- City combines with cuisine filter (SC-14 e2e)
- City combines with price filter (SC-15 e2e)
- Empty state shown for city with no restaurants (SC-11 ui-e2e)
- City state syncs between NavBar and Search page (SC-12 ui-e2e)

---

## Wave 3 — Test Suites

### TASK-008 [storage-integration-tests][wave:3]

Implement integration test suite from `spec/test/integration-test-suite.md`.

**type:** storage-integration-tests
**target:** .forge/efforts/add-location-based-filtering/spec/test/integration-test-suite.md
**language:** javascript
**depends_on:** TASK-001
**Required tests:**
- SC-1: neighbourhood table contains all 10 cities after seed
- SC-2: re-running seed does not duplicate cities
- SC-3: GET /restaurants filters correctly by new city neighbourhood_id
- SC-4: new cities have ≥20 restaurants each in the DB
- SC-5: existing NYC neighbourhoods unchanged after seed expansion
- SC-6: GET /restaurants returns correct intersection of neighbourhood_id and cuisine_id
- SC-7: GET /restaurants returns correct intersection of neighbourhood_id and price_range
- SC-8: GET /restaurants without neighbourhood_id returns all 200 restaurants

---

### TASK-009 [e2e-test][wave:3]

Implement E2E and UI E2E test suites from `spec/test/e2e-test-suite.md` and `spec/test/ui-e2e-test-suite.md` using Playwright.

**type:** e2e-test
**target:** .forge/efforts/add-location-based-filtering/spec/test/ui-e2e-test-suite.md
**language:** javascript
**depends_on:** TASK-005, TASK-006, TASK-007, TASK-008
**Required tests:**
- SC-1..SC-16 from e2e-test-suite.md
- SC-1..SC-12 from ui-e2e-test-suite.md
