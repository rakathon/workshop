# Business Requirements: Add Location-Based Filtering

*Product / Effort: add-location-based-filtering*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Location-relevant restaurant catalogue without schema change

**Priority:** P0

dishly must serve each customer a restaurant catalogue scoped to their location using the existing data model — so that non-NYC customers see relevant results and the business can expand to new cities without a database migration.

**Acceptance Criteria:**
- [ ] A customer in any supported city sees only restaurants associated with that city when they apply a location filter
- [ ] Existing NYC customers experience no change to their current browsing results
- [ ] New city entries are available in the location catalogue alongside existing neighbourhoods

---

## BR-2: Customer-controlled location filtering on every search surface

**Priority:** P0

Customers must be able to select or change their city at any point during a search session — so that location filtering is always accessible and city preference is not lost between visits.

**Acceptance Criteria:**
- [ ] A customer can select a city from any search surface and immediately receive location-filtered restaurant results
- [ ] A customer can clear their city selection and return to all-city results
- [ ] A customer's city preference is available when they return to the app in a new session, and is removed when they sign out

---

## BR-3: Automatic city detection as an alternative to manual selection

**Priority:** P0

Customers must be able to have their city identified automatically based on their physical location — so that they do not need to know which city to select and can begin browsing relevant results immediately.

**Acceptance Criteria:**
- [ ] A customer who consents to share their location has their city identified and applied as a filter without manual input
- [ ] A customer whose location cannot be determined receives a clear prompt to select their city manually
- [ ] Automatic city detection covers all six supported cities

---

## BR-4: Multi-city restaurant catalogue with authentic local coverage

**Priority:** P0

dishly must offer a credible, locally relevant restaurant catalogue in at least 5 new US cities — so that the app is useful to customers outside New York and the business can acquire users in those markets.

**Acceptance Criteria:**
- [ ] At least 20 restaurants are available per new city at launch
- [ ] Restaurant names, cuisine types, and descriptions reflect the local food culture of each city
- [ ] The expanded catalogue does not affect or overwrite existing NYC restaurant data
