# Technical Requirements — add-location-based-filtering

*Effort: add-location-based-filtering*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-06*

---

## TR-1: No schema migration required — neighbourhood table reused as city list

*Traces to: [BR-1](business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change)*

The `neighbourhood` table schema is unchanged. New city entries are inserted as additional rows via the seed script only. No `ALTER TABLE` or new table creation is needed. The `neighbourhood_id` query parameter on `GET /restaurants` already supports filtering — no backend route changes required beyond confirming the existing filter works for new entries.

## TR-2: City selector is a client-side combobox — no new API endpoint

*Traces to: [BR-2](business.md#br-2-customer-controlled-location-filtering-on-every-search-surface)*

The city selector fetches the full city list from the existing `GET /neighbourhoods` endpoint (already implemented). Client-side filtering of the dropdown as the user types is performed in React state — no server-side autocomplete endpoint is needed. The selected city's `neighbourhood_id` is passed as a query parameter to `GET /restaurants`.

## TR-3: City bounding boxes hardcoded in frontend config

*Traces to: [BR-3](business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection)*

Each city's lat/lng bounding box is defined as a static constant in the frontend (e.g. `src/config/cityBounds.js`). The structure: `{ id: <neighbourhood_id_placeholder>, name, bounds: { minLat, maxLat, minLng, maxLng }, centroid: { lat, lng } }`. Neighbourhood IDs are resolved at runtime by matching city name against the `/neighbourhoods` response — not hardcoded UUIDs, since UUIDs are generated fresh on each seed.

## TR-4: Geolocation uses browser Permissions API with graceful fallback

*Traces to: [BR-3](business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection)*

`navigator.geolocation.getCurrentPosition()` is called only when the user explicitly clicks "Near me". If the browser denies permission (`PERMISSION_DENIED`) or position is unavailable (`POSITION_UNAVAILABLE` / `TIMEOUT`), an inline error message is shown without crashing the filter state. The city selector returns to its "All cities" default on failure.

## TR-5: Seed script idempotency preserved via name-based existence check

*Traces to: [BR-4](business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)*

The seed script checks for existing neighbourhood rows by name before inserting. New city insertions are guarded: `SELECT id FROM neighbourhood WHERE name = ?` — insert only if absent. This prevents duplicate cities on re-run while keeping the script append-safe for new cities added in future efforts.
