# PRD: Add Location-Based Filtering

*Product / Effort: add-location-based-filtering*
*Last updated: 2026-06-07*

---

## Problem Statement

dishly customers currently have no way to filter restaurants by location. The app launched with 100 NYC-only restaurants, making it irrelevant to users outside New York and frustrating for NYC users who want neighbourhood-specific results. This gap was identified at Wave 1 launch — no city or geolocation filtering exists anywhere in the codebase, and multi-city expansion is a stated Wave 1 product goal.

Registered and anonymous customers alike are affected: they see restaurants from all locations mixed together, with no way to narrow results to where they can actually order from.

---

## Goals

1. Customers in at least 6 cities (NYC + 5 new) can browse and filter restaurants relevant to their location — measured by 5 new cities seeded with ≥20 restaurants each and city filter returning correct results
2. Customers actively use the city selector — measured by ≥30% of search sessions including a city filter selection within 2 weeks of launch
3. Geolocation correctly identifies the user's city — measured by correct city matched for ≥90% of test locations within known bounding boxes
4. Existing NYC browsing and ordering flow is unaffected — measured by all existing E2E tests passing after changes

---

## Non-Goals

- We are not adding a `city` table or changing the database schema — the `neighbourhood` table is reused as-is; no migration required.
- We are not building real-time geolocation tracking — location is only requested once on "Near me" click and not persisted beyond the session.
- We are not integrating a reverse geocoding API — city matching uses hardcoded bounding boxes only.
- We are not adding international cities — scope is US cities only for Wave 1.
- We are not building a restaurant onboarding flow for new cities — all data is seeded manually.

---

## Success Metrics

### Leading Indicators (early signal)

- % of sessions on Search/Home page where a city is selected (within first week of release)
- % of "Near me" clicks that successfully auto-select a city vs. fallback to manual selection
- Search result page load after city filter applied — confirms filter is wired end-to-end

### Lagging Indicators (final outcome)

- % of non-NYC registered users who complete a full order at 30 days post-launch (baseline: 0%)
- Repeat visit rate for users who used the city filter vs. those who did not (30-day retention)
- Total restaurant coverage by city — at least 20 per new city sustained at 30 days

---

## Open Questions

- Bounding boxes resolved: ±0.5° centroid per city [owner: eng] [due: resolved at planning]
- City persistence resolved: store in `localStorage`, cleared on sign-out [owner: product] [due: resolved]
- Selector placement resolved: Home hero search bar AND Search results page [owner: design] [due: resolved]

---

## Timeline / Dependencies

- **Target:** Same day (next few hours)
- **Dependencies:** None — self-contained. `neighbourhood` table and `GET /restaurants?neighbourhood_id=` filter already exist. No external APIs required.

---

## Requirements

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See `user-stories.md` for Connextra-format stories grouped by persona.
