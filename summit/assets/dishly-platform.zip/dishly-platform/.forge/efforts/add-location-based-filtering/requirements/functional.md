# Functional Requirements — Add Location-Based Filtering

*Effort: add-location-based-filtering*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Filter restaurant results by selected city

*Traces to: [BR-1](business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change)*

When a city is selected, the system must return only restaurants associated with that city. When no city is selected, the system must return restaurants across all cities.

---

## FR-2: City selector present on Home and Search pages

*Traces to: [BR-2](business.md#br-2-customer-controlled-location-filtering-on-every-search-surface)*

The system must render a city selection control on the Home page and the Search results page. The control must allow the customer to select a city, switch to a different city, or clear the active city filter during a session.

---

## FR-3: City preference persisted across sessions and cleared on sign-out

*Traces to: [BR-2](business.md#br-2-customer-controlled-location-filtering-on-every-search-surface)*

The system must restore a customer's last selected city when they return to the app in a new session. The system must remove the persisted preference when the customer signs out.

---

## FR-4: "Near me" option triggers automatic city detection

*Traces to: [BR-3](business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection)*

The system must offer an automatic location detection option in the city selector. When activated, the system must determine the customer's current city from their device location and apply it as the active city filter without requiring manual input.

---

## FR-5: Graceful fallback when location detection fails

*Traces to: [BR-3](business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection)*

When automatic city detection fails or the customer denies location access, the system must display an inline message indicating that location detection was unsuccessful and prompt the customer to select a city manually. The existing filter state must not be disrupted.

---

## FR-6: Seed data provides full restaurant records for each new city

*Traces to: [BR-4](business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)*

The system must include at least 20 restaurants per newly added city in the seed data. Each restaurant record must contain: name, cuisine type, description, address, price range, cover image, rating, and delivery radius.
