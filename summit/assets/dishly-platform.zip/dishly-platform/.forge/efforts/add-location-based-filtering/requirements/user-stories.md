# User Stories: Add Location-Based Filtering

*Product / Effort: add-location-based-filtering*
*Last updated: 2026-06-07*

---

## Customer — City Discovery

**US-1:** As a customer browsing dishly from a new city, I want to select my city from a search bar dropdown, so that I only see restaurants relevant to where I am.

**Acceptance Criteria:**
- [ ] City selector visible on Home and Search pages alongside the main search input
- [ ] Typing partial city names narrows the dropdown to matching results
- [ ] Selecting a city filters the restaurant list immediately
- [ ] Clearing the selection restores all-city results

---

**US-2:** As a customer who just opened the app, I want to tap "Near me" and have the app detect my city automatically, so that I don't have to type or scroll to find my location.

**Acceptance Criteria:**
- [ ] "Near me" is the first option in the city dropdown
- [ ] App requests location permission when "Near me" is tapped
- [ ] Correct city is auto-selected if coordinates fall within a known bounding box
- [ ] If location is denied or unavailable, a friendly inline message guides me to select manually

---

## Returning Customer — Persistent City Preference

**US-3:** As a returning customer, I want my last selected city to be remembered when I come back to the app, so that I don't have to re-select it every session.

**Acceptance Criteria:**
- [ ] Selected city persists in localStorage across page refreshes
- [ ] City preference is cleared when I sign out
- [ ] If a stored city no longer exists in the city list, the selector resets to "All cities"

---

## Traveller — Multi-City Browsing

**US-4:** As a customer travelling between cities, I want to switch cities in the search bar, so that I can explore restaurants in my destination before I arrive.

**Acceptance Criteria:**
- [ ] Changing city selection immediately re-filters results without a page reload
- [ ] Previously applied cuisine and price filters remain active when city changes
- [ ] The selected city name is visible in the search bar so I know which city I'm browsing

---

## Non-NYC Customer — Relevant Restaurant Catalogue

**US-5:** As a customer in Los Angeles, Chicago, Boston, Miami, or San Francisco, I want to see restaurants with real local names and cuisine types relevant to my city, so that the app feels relevant to me.

**Acceptance Criteria:**
- [ ] At least 20 restaurants available per new city
- [ ] Restaurant names, cuisine types, and descriptions reflect local food culture
- [ ] Filtering by a new city returns results with correct neighbourhood association
