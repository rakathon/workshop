# E2E Test Suite — add-location-based-filtering

*Capability/Effort:* `.forge/efforts/add-location-based-filtering/spec/test/`
*Authored:* 2026-06-06
*Effort:* add-location-based-filtering

## Why Test This

Location-based filtering is the primary discovery lever for non-NYC users — without it, the app shows 200 restaurants with no relevance to where the user is. The highest-risk behaviors are: (1) city selection correctly filtering `GET /restaurants` via `neighbourhood_id`, (2) Near me geolocation matching to the correct city bounding box, (3) the new seed cities returning real restaurant data, and (4) city persistence surviving page refresh without corrupting subsequent filters.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: City selector filters restaurants to selected city | [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface): city selector filters restaurant list via neighbourhood_id |
| SC-2: Selecting a different city re-filters results immediately | [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface): clear/reset returns all-city results |
| SC-3: Clearing city filter restores all-city results | [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface): clear/reset control removes active city filter |
| SC-4: City selection persists across page reload | [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface): selected city stored in localStorage; restored on page refresh |
| SC-5: City cleared on sign-out | [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface): localStorage cleared on sign-out |
| SC-6: Near me matches user coordinates to correct city | [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection): coordinates matched to city bounding box |
| SC-7: Geolocation denied shows inline message | [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection): fallback message when permission denied |
| SC-8: Coordinates outside all bounding boxes show fallback | [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection): nearest centroid used when no exact match |
| SC-9: Los Angeles restaurants are browsable | [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): ≥20 LA restaurants seeded |
| SC-10: Chicago restaurants are browsable | [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): ≥20 Chicago restaurants seeded |
| SC-11: Boston restaurants are browsable | [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): ≥20 Boston restaurants seeded |
| SC-12: Miami restaurants are browsable | [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): ≥20 Miami restaurants seeded |
| SC-13: San Francisco restaurants are browsable | [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): ≥20 SF restaurants seeded |
| SC-14: City filter combines with cuisine filter | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): neighbourhood_id filter works alongside existing filters |
| SC-15: City filter combines with price filter | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): neighbourhood_id filter works alongside existing filters |
| SC-16: GET /neighbourhoods returns all 10 cities | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change), [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): flat neighbourhood table includes new cities |

## Scenarios

### SC-1: City selector filters restaurants to selected city

**Type:** e2e
**Tags:** smoke-test, non-production
**Given** a customer on the Search page with all cities visible
**When** the customer selects "Los Angeles" from the city selector
**Then** GET /restaurants is called with neighbourhood_id matching Los Angeles
**And** only Los Angeles restaurants appear in the results
**And** the city selector shows "Los Angeles" with an active style
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "Selecting a city filters the restaurant list to that city's neighbourhood_id"

---

### SC-2: Selecting a different city re-filters results immediately

**Type:** e2e
**Tags:** non-production
**Given** a customer with Los Angeles selected as the active city
**When** the customer selects "Chicago" from the city selector
**Then** the restaurant list updates to show only Chicago restaurants
**And** the city selector label changes to "Chicago"
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — city can be changed without page reload

---

### SC-3: Clearing city filter restores all-city results

**Type:** e2e
**Tags:** non-production
**Given** a customer with "San Francisco" selected as the active city
**When** the customer clicks the × clear button on the city selector
**Then** GET /restaurants is called without a neighbourhood_id parameter
**And** restaurants from all cities appear in the results
**And** the city selector shows "All cities" placeholder
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "A clear/reset control removes the active city filter and returns all-city results"

---

### SC-4: City selection persists across page reload

**Type:** e2e
**Tags:** non-production
**Given** a customer selects "Miami" from the city selector
**When** the customer reloads the page
**Then** the city selector still shows "Miami"
**And** the restaurant list is filtered to Miami restaurants
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "Selected city is stored in localStorage and restored on page refresh"

---

### SC-5: City cleared on sign-out

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with "Boston" selected as the active city
**When** the customer signs out
**Then** the city selector resets to "All cities"
**And** the localStorage entry for dishly_city is removed
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "localStorage cleared on sign-out"

---

### SC-6: Near me matches user coordinates to correct city

**Type:** e2e
**Tags:** non-production
**Given** a customer's browser reports coordinates within the San Francisco bounding box (lat 37.77, lng -122.42)
**When** the customer clicks "Near me" in the city dropdown
**Then** the city selector shows "San Francisco"
**And** the restaurant list is filtered to San Francisco restaurants
**Verifies:** [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection) — "User's coordinates matched to city bounding box; matched city applied as active filter"

---

### SC-7: Geolocation permission denied shows inline fallback message

**Type:** e2e
**Tags:** non-production
**Given** a customer whose browser denies geolocation permission
**When** the customer clicks "Near me" in the city dropdown
**Then** an inline message appears: "Location unavailable — please select a city manually"
**And** the city selector remains at "All cities" (no city auto-selected)
**Verifies:** [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection) — "If geolocation permission denied, inline message shown"

---

### SC-8: Coordinates outside all bounding boxes use nearest centroid fallback

**Type:** e2e
**Tags:** non-production
**Given** a customer's browser reports coordinates not within any city's bounding box (e.g. lat 36.0, lng -95.0)
**When** the customer clicks "Near me"
**Then** the nearest city centroid is used for matching
**And** a city is selected (no "no match" crash)
**Verifies:** [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection) — "Nearest centroid used if no exact bounding box match"

---

### SC-9: Los Angeles restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<los-angeles-id> is called
**Then** the response returns at least 20 restaurants
**And** each restaurant has a name, cuisine, rating, and price_range
**Verifies:** [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "~20 restaurants seeded per new city"

---

### SC-10: Chicago restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<chicago-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "~20 restaurants seeded per new city"

---

### SC-11: Boston restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<boston-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "~20 restaurants seeded per new city"

---

### SC-12: Miami restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<miami-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "~20 restaurants seeded per new city"

---

### SC-13: San Francisco restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<san-francisco-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "~20 restaurants seeded per new city"

---

### SC-14: City filter combines correctly with cuisine filter

**Type:** e2e
**Tags:** non-production
**Given** a customer selects "Los Angeles" as city and "Japanese" as cuisine
**When** GET /restaurants is called with both neighbourhood_id and cuisine_id
**Then** only LA Japanese restaurants are returned
**And** no restaurants from other cities appear
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — "Existing neighbourhood_id filter works alongside existing cuisine filter"

---

### SC-15: City filter combines correctly with price filter

**Type:** e2e
**Tags:** non-production
**Given** a customer selects "San Francisco" as city and "$$" as price
**When** GET /restaurants is called with neighbourhood_id and price_range
**Then** only SF restaurants with price_range $$ are returned
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — "Existing neighbourhood_id filter works alongside existing price filter"

---

### SC-16: GET /neighbourhoods returns all 10 cities

**Type:** e2e
**Tags:** smoke-test, non-production
**Given** the seed database has been initialized
**When** GET /dishly/v1/neighbourhoods is called
**Then** the response contains exactly 10 entries
**And** the list includes: Manhattan, Brooklyn, Queens, Williamsburg, Astoria, Los Angeles, Chicago, Boston, Miami, San Francisco
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change), [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "neighbourhood table includes 5 new cities alongside 5 existing NYC neighbourhoods"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
