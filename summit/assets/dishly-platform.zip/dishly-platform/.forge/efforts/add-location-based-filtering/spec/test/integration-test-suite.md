# Integration Test Suite — add-location-based-filtering

*Capability/Effort:* `.forge/efforts/add-location-based-filtering/spec/test/`
*Authored:* 2026-06-06
*Effort:* add-location-based-filtering

## Why Test This

The neighbourhood table is reused as the city list — no schema change, but seed data integrity is critical. If the idempotency check is wrong, re-running seed.js could skip new cities on an existing database, leaving the filter with no data to show. These integration tests verify that seeding is correct, idempotency works, and the API filter behaves correctly at the DB layer for both old and new entries.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: neighbourhood table contains all 10 cities after seed | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change), [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): flat table includes old and new entries |
| SC-2: Re-running seed does not duplicate cities | [TR-5](../../requirements/technical.md#tr-5-seed-script-idempotency-preserved-via-name-based-existence-check): idempotency via neighbourhood count check |
| SC-3: GET /restaurants filters correctly by new city neighbourhood_id | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): existing neighbourhood_id filter works for new entries |
| SC-4: New cities have ≥20 restaurants in the DB | [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): ~20 restaurants per new city |
| SC-5: Existing NYC neighbourhoods unchanged after seed | [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage): existing NYC data preserved |
| SC-6: GET /restaurants with neighbourhood_id + cuisine_id returns correct intersection | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): filter combination works |
| SC-7: GET /restaurants with neighbourhood_id + price_range returns correct intersection | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): filter combination works |
| SC-8: GET /restaurants without neighbourhood_id returns all 200 restaurants | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): no city filter returns all |

## Scenarios

### SC-1: neighbourhood table contains all 10 cities after seed

**Type:** integration
**Given** a fresh database with migrations applied and seed.js executed
**When** SELECT COUNT(*) FROM neighbourhood is run
**Then** the count equals 10
**And** the rows include: Manhattan, Brooklyn, Queens, Williamsburg, Astoria, Los Angeles, Chicago, Boston, Miami, San Francisco
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — "neighbourhood table includes 5 new cities"; [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "5 new neighbourhood rows added"

---

### SC-2: Re-running seed does not duplicate cities

**Type:** integration
**Given** a database that has already been seeded (neighbourhood count = 10)
**When** seed.js is executed a second time
**Then** the neighbourhood count remains exactly 10
**And** the restaurant count does not increase
**And** the seed script logs a skip message
**Verifies:** [TR-5](../../requirements/technical.md#tr-5-seed-script-idempotency-preserved-via-name-based-existence-check) — "Seed script idempotency preserved via neighbourhood count check"

---

### SC-3: GET /restaurants filters correctly by new city neighbourhood_id

**Type:** integration
**Given** a seeded database with Los Angeles restaurants
**When** GET /restaurants?neighbourhood_id=<los-angeles-id> is called
**Then** all returned restaurants have neighbourhood_id matching Los Angeles
**And** no restaurants from other cities are included
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — "Existing neighbourhood_id filter on GET /restaurants works for new entries"

---

### SC-4: New cities have ≥20 restaurants each in the database

**Type:** integration
**Given** a seeded database
**When** SELECT COUNT(*) FROM restaurant WHERE neighbourhood_id = ? is run for each new city
**Then** Los Angeles has ≥20 restaurants
**And** Chicago has ≥20 restaurants
**And** Boston has ≥20 restaurants
**And** Miami has ≥20 restaurants
**And** San Francisco has ≥20 restaurants
**Verifies:** [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "~20 restaurants seeded per new city"

---

### SC-5: Existing NYC neighbourhoods unchanged after seed expansion

**Type:** integration
**Given** a database seeded with the expanded seed script
**When** SELECT COUNT(*) FROM restaurant WHERE neighbourhood_id IN (<nyc-ids>) is run
**Then** the NYC restaurant count is ≥100 (original seed data preserved)
**And** all 5 original NYC neighbourhoods still exist
**Verifies:** [BR-4](../../requirements/business.md#br-4-multi-city-restaurant-catalogue-with-authentic-local-coverage) — "Existing NYC seed data preserved unchanged"

---

### SC-6: GET /restaurants returns correct intersection of neighbourhood_id and cuisine_id

**Type:** integration
**Given** a seeded database with LA restaurants across multiple cuisines
**When** GET /restaurants?neighbourhood_id=<la-id>&cuisine_id=<japanese-id> is called
**Then** only LA Japanese restaurants are returned
**And** the response contains no restaurants from other cities
**And** the response contains no non-Japanese LA restaurants
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — "neighbourhood_id filter works alongside existing cuisine_id filter"

---

### SC-7: GET /restaurants returns correct intersection of neighbourhood_id and price_range

**Type:** integration
**Given** a seeded database with SF restaurants across multiple price ranges
**When** GET /restaurants?neighbourhood_id=<sf-id>&price_range=$$ is called
**Then** only SF restaurants with price_range $$ are returned
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — "neighbourhood_id filter works alongside existing price_range filter"

---

### SC-8: GET /restaurants without neighbourhood_id returns all cities

**Type:** integration
**Given** a seeded database with 200 restaurants across 10 cities
**When** GET /restaurants is called without a neighbourhood_id parameter
**Then** the response pagination yields a total of 200 restaurants (across all pages)
**And** restaurants from all 10 cities are included
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — "No city filter returns all-city results"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
