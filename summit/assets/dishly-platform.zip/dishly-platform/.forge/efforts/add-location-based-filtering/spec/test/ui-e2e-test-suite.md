# UI E2E Test Suite — add-location-based-filtering

*Capability/Effort:* `.forge/efforts/add-location-based-filtering/spec/test/`
*Authored:* 2026-06-06
*Effort:* add-location-based-filtering

## Why Test This

The city selector is a new interactive component appearing in three surfaces (NavBar, Home hero, Search page). Each surface has distinct states (default, dropdown open, city selected, near me loading, geo denied, empty results). These UI scenarios verify what the user sees and can interact with — complementing the system E2E tests that verify API outcomes.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: City selector visible in NavBar alongside search input | UX Screen: NavBar — city selector default state |
| SC-2: City dropdown opens and shows all cities + Near me | UX Screen: City dropdown — open state |
| SC-3: Typing in city dropdown filters the list | UX Interaction: type-to-filter |
| SC-4: Selecting a city closes dropdown and shows active style | UX Interaction: city select |
| SC-5: Active city shows × clear button; clicking it resets | UX Interaction: city clear |
| SC-6: "Near me" shows loading indicator while awaiting geolocation | UX State: Near me loading |
| SC-7: Geolocation denied shows inline error message | UX State: geo denied |
| SC-8: No cities found when search matches nothing | UX State: dropdown empty state |
| SC-9: City selector visible in Home hero search bar | UX Screen: Home hero — city selector |
| SC-10: City selector visible on Search results page above cuisine/price | UX Screen: Search page — city filter row |
| SC-11: Empty state shown when city has no restaurants | UX State: Search — empty city |
| SC-12: City selector state syncs across NavBar and Search page | UX Interaction: cross-surface sync |
| SC-13: Keyword search from home hero navigates to search results | Home search → /search?q= |
| SC-14: Keyword search returns relevant restaurants | Search results default state |
| SC-15: City filter combined with cuisine filter narrows results | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): multi-filter city+cuisine |
| SC-16: Price range filter narrows search results | Price filter active state |
| SC-17: City filter combined with price filter narrows results | [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change): multi-filter city+price |
| SC-18: Clearing city filter restores all-city results on Search page | [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface): city filter cleared |
| SC-19: All filter chips can be active simultaneously and individually reset | Independent filter reset |
| SC-20: Search with no results shows actionable empty state | Empty state with active city filter |
| SC-21: NavBar search box pre-populated from URL q= param | Search box synced to URL on navigation |
| SC-22: Soba chip auto-selects Japanese cuisine filter | Chip-to-cuisine mapping: Soba→Japanese |
| SC-23: Order history shows human-readable timestamps | Human-readable date format (Today at...) |
| SC-24: Checkout redirects to /login when no session token | Checkout auth guard |

## Scenarios

### SC-1: City selector visible in NavBar alongside search input

**Type:** e2e
**Given** a customer on any page
**When** the page loads
**Then** a city selector button is visible in the NavBar, left of the search input
**And** the selector shows "All cities" when no city is selected
**And** the selector has a location pin icon
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "City selector visible on both home and search results page"; UX NavBar default state

---

### SC-2: City dropdown opens and shows all cities plus Near me option

**Type:** e2e
**Given** a customer with no city selected
**When** the customer clicks the city selector button
**Then** a dropdown opens below the selector
**And** "Near me" appears as the first item with a distinct style
**And** all available cities are listed below (at least 6 entries)
**And** a text input for filtering is visible at the top of the dropdown
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "Dropdown shows city list; Near me first"; [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection) — "Near me appears as first option"

---

### SC-3: Typing in city dropdown filters the list

**Type:** e2e
**Given** the city dropdown is open
**When** the customer types "Los" in the filter input
**Then** only "Los Angeles" appears in the dropdown list
**And** "Near me" is hidden while filtering
**When** the customer clears the filter input
**Then** all cities reappear along with "Near me"
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "Typing narrows dropdown to matching city names (client-side filter)"

---

### SC-4: Selecting a city closes dropdown and shows active style

**Type:** e2e
**Given** the city dropdown is open
**When** the customer clicks "Chicago"
**Then** the dropdown closes
**And** the city selector button shows "Chicago" with a purple/primary highlighted style
**And** a × clear button appears on the selector
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "City selected: active style, city name shown, clear button present"

---

### SC-5: Active city shows clear button; clicking it resets selector

**Type:** e2e
**Given** "Miami" is the active city in the selector
**When** the customer clicks the × clear button
**Then** the city selector resets to "All cities" placeholder
**And** the active/highlighted style is removed
**And** the × clear button disappears
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "Clear/reset control removes active city filter"

---

### SC-6: Near me shows loading indicator while awaiting geolocation

**Type:** e2e
**Given** the city dropdown is open
**When** the customer clicks "Near me" (geolocation takes >200ms)
**Then** the dropdown closes
**And** the city selector shows a loading indicator ("Detecting…" or spinner)
**And** no city is selected yet
**Verifies:** [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection) — "Near me loading state shown while awaiting geolocation"

---

### SC-7: Geolocation denied shows inline error below selector

**Type:** e2e
**Given** the browser will deny geolocation permission
**When** the customer clicks "Near me"
**Then** an inline error message appears near the city selector
**And** the message contains text about selecting a city manually
**And** the city selector remains at "All cities" (no city auto-selected)
**Verifies:** [BR-3](../../requirements/business.md#br-3-automatic-city-detection-as-an-alternative-to-manual-selection) — "If geolocation permission denied, inline message shown"

---

### SC-8: No cities found empty state in dropdown

**Type:** e2e
**Given** the city dropdown is open
**When** the customer types "zzz" (no matching cities)
**Then** the dropdown shows a "No cities found" message
**And** no city items are listed
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "City selector handles no-match state gracefully"

---

### SC-9: City selector visible in Home page hero search bar

**Type:** e2e
**Given** a customer on the Home page
**When** the page loads
**Then** the hero search bar contains a city selector left of the keyword input
**And** the city selector is functional (clicking opens dropdown)
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "City selector visible on home page"; UX Home hero state

---

### SC-10: City selector row visible on Search page above cuisine and price filters

**Type:** e2e
**Given** a customer on the /search page
**When** the page loads
**Then** a "City" filter row is visible above the "Cuisine" and "Price" filter rows
**And** the city selector in the filter row is functional
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "City selector visible on search results page"; UX Search page state

---

### SC-11: Empty state shown when selected city has no restaurants

**Type:** e2e
**Given** a customer selects a city that has no seeded restaurants
**When** the restaurant list loads
**Then** an empty state message is displayed indicating no restaurants in that city
**And** a link or button to browse all cities is visible
**Verifies:** UX Spec — "Empty state: no restaurants in city → friendly message + clear filter CTA"

---

### SC-12: City selector state syncs between NavBar and Search page

**Type:** e2e
**Given** a customer selects "Boston" using the NavBar city selector
**When** the customer navigates to the Search page
**Then** the Search page city selector also shows "Boston" as active
**And** the restaurant results are filtered to Boston
**When** the customer clears the city on the Search page
**Then** the NavBar city selector also resets to "All cities"
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — "Selected city persists in localStorage; consistent across page surfaces"

---

---

*Extended: 2026-06-06 — search and filter scenarios added per forge:spec-ui-e2e*

### SC-13: Keyword search from home hero navigates to search results

**Type:** e2e
**Given** a customer on the Home page
**When** the customer types "ramen" in the hero search input and submits
**Then** the page navigates to /search with q=ramen in the URL
**And** search results for ramen are visible
**Verifies:** Home page search flow — keyword search navigates to /search?q=

---

### SC-14: Keyword search returns relevant restaurants

**Type:** e2e
**Given** a customer on the /search page
**When** the customer searches for "Japanese"
**Then** at least one restaurant result is visible
**And** the result count label shows a non-zero count
**And** each result row shows restaurant name, rating, cuisine, and price range
**Verifies:** Search results default state — results render correctly

---

### SC-15: City filter combined with cuisine filter narrows results correctly

**Type:** e2e
**Given** a customer on the /search page with "Los Angeles" selected as city
**When** the customer clicks the "Japanese" cuisine filter chip
**Then** only LA Japanese restaurants appear in the results
**And** the result count decreases compared to LA-only results
**And** both the city selector and cuisine chip show active state simultaneously
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — city + cuisine combined filter; multi-filter state

---

### SC-16: Price range filter narrows search results

**Type:** e2e
**Given** a customer on the /search page with results showing
**When** the customer clicks the "$$" price filter chip
**Then** only restaurants with $$ price range appear
**And** the "$$" chip shows an active/selected style
**And** the result count updates to reflect the filter
**Verifies:** Price filter active state and result update

---

### SC-17: City filter combined with price filter narrows results

**Type:** e2e
**Given** a customer on the /search page with "San Francisco" selected as city
**When** the customer clicks the "$$$" price filter chip
**Then** only SF restaurants with $$$ price range appear
**And** both city selector and $$$ chip show active state
**Verifies:** [BR-1](../../requirements/business.md#br-1-location-relevant-restaurant-catalogue-without-schema-change) — city + price combined filter

---

### SC-18: Clearing city filter restores all-city results on Search page

**Type:** e2e
**Given** a customer on the /search page with "Chicago" selected as the active city
**When** the customer clicks the × clear button on the city selector
**Then** the city selector resets to "All cities"
**And** restaurants from all cities are visible in the results
**And** the result count increases back to the unfiltered total
**Verifies:** [BR-2](../../requirements/business.md#br-2-customer-controlled-location-filtering-on-every-search-surface) — city filter cleared; all-city results restored

---

### SC-19: All filter chips can be active simultaneously and individually reset

**Type:** e2e
**Given** a customer on the /search page with city, cuisine, and price filters all active
**When** the customer clicks the active cuisine chip to deactivate it
**Then** the cuisine chip returns to its inactive style
**And** the city and price filters remain active
**And** results update to show all cuisines for that city and price
**Verifies:** Independent filter reset — individual chip deactivation

---

### SC-20: Search with no results shows actionable empty state

**Type:** e2e
**Given** a customer on the /search page with "Boston" selected as city
**When** the customer searches for a term that yields no results (e.g. "xyzzy123")
**Then** no restaurant result rows are visible
**And** an empty state message is visible
**And** the empty state contains the search term or a "try a different search" suggestion
**Verifies:** Empty state with active city filter — combined no-results state

---

---

*Extended: 2026-06-07 — scenarios for search box sync, chip-to-cuisine mapping, order history timestamps, checkout auth redirect*

### SC-21: NavBar search box is pre-populated when landing on search page from a keyword search

**Type:** e2e
**Given** a customer on the Home page who types "ramen" in the hero search and submits
**When** the search results page loads
**Then** the NavBar search input shows "ramen" pre-filled
**Verifies:** UX — search term visible in navbar input after navigation

---

### SC-22: Chip label "Soba" auto-selects Japanese cuisine filter on search page

**Type:** e2e
**Given** a customer who clicks the "Soba" chip on the Home page
**When** the search results page loads at /search?q=Soba
**Then** the "Japanese" cuisine filter chip is active
**And** the page title shows "Soba Restaurants" (not "Results for Soba")
**And** Japanese restaurants appear in the results
**Verifies:** Chip-to-cuisine mapping — Soba→Japanese

---

### SC-23: Order history shows human-readable timestamps

**Type:** e2e
**Given** a signed-in customer with at least one past order
**When** the customer navigates to /account/orders
**Then** each order row shows a human-readable date (e.g. "Today at 2:34 PM" or "Jun 7, 2026 at...")
**And** the raw ISO date format "2026-06-07" is not visible
**Verifies:** Order history timestamp format

---

### SC-24: Checkout redirects to /login when session token is missing

**Type:** e2e
**Given** a customer with items in their cart but no active session (no token in localStorage)
**When** the customer navigates to /checkout and attempts to place an order
**Then** the page redirects to /login
**Verifies:** Checkout auth guard — redirect on missing token

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
