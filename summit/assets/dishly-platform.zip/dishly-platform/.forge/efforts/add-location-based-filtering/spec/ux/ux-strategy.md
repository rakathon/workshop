# add-location-based-filtering — UX Strategy & Spec

*Effort: add-location-based-filtering*
*Mode: data-first*
*Written: 2026-06-06*

---

## Problem Framing

**Problem statement:** How might we help dishly customers outside New York City (and NYC customers who want neighbourhood-level results) filter restaurants to their location, given that the app currently shows all restaurants with no location awareness, so that browsing feels relevant and ordering is possible?

**Users affected:** All dishly customers — the app is currently only useful to NYC users. Non-NYC users see 100 irrelevant restaurants with no way to filter. NYC users can't narrow to their neighbourhood.

**Current workaround / failure mode:** Users must scroll through all restaurants regardless of location. No city or neighbourhood filter exists anywhere in the current UI.

---

## Users & Jobs-to-be-Done

### Persona: The Out-of-City Customer (proto-persona)

**Job story:** When I open dishly in my city, I want to instantly see only restaurants that can deliver to me, so I can find something to order without wading through irrelevant results.

**Key constraints / context:** First-time or returning user; may or may not grant location permission. Expects the app to "just know" their city like every major food delivery app does.

### Persona: The NYC Regular (proto-persona)

**Job story:** When I search for food on dishly, I want to filter to my neighbourhood (e.g. Brooklyn vs. Queens), so I see restaurants relevant to where I actually am.

---

## Success Signals

| Signal | Metric | Target |
|--------|--------|--------|
| Adoption | % of search sessions with city filter applied | ≥ 30% within 2 weeks |
| Near me accuracy | Correct city matched for test coordinates in each bounding box | ≥ 90% |
| Non-NYC orders | % of non-NYC registered users who complete an order at 30 days | measurable lift from 0% |

---

## Information Architecture

```
NavBar (persistent)
  └── Search bar
        ├── [City selector combobox] ← NEW — left of keyword input
        └── [Keyword input] (existing)

Home page
  └── Hero search bar
        ├── [City selector combobox] ← NEW — left of keyword input
        └── [Keyword input + Search button] (existing)

/search (Search results page)
  └── Filters row
        ├── City filter pills OR city selector ← NEW — above existing cuisine/price
        ├── Cuisine filter pills (existing)
        └── Price filter pills (existing)
```

**Navigation model:** City selection is a persistent filter — set once in the NavBar/hero combobox, carried through to search results and home collections. Selecting a city on the Search page also updates the combobox state.

**Rationale:** The city selector lives at the search bar level, not deep in filters — users should set their city before they search, not after seeing irrelevant results. This matches the mental model of every major delivery app (set location first, then browse).

---

## Key User Flows

### Flow 1: Manual city selection

**Trigger:** User visits dishly from a new city or wants to change location.

**Steps:**
1. User clicks the city selector (shows placeholder "All cities" or current city)
2. Dropdown opens showing all available cities; "Near me" at top
3. User types to narrow — dropdown filters client-side
4. User clicks a city name
5. City selector shows selected city; restaurant results re-filter immediately
6. City stored in localStorage for next visit

**Success state:** Restaurant list shows only the selected city's restaurants.

**Failure / edge cases:** No restaurants in selected city → empty state with clear message and a "Clear city filter" CTA.

---

### Flow 2: Near me auto-detection

**Trigger:** User clicks "Near me" in the city dropdown.

**Steps:**
1. Browser requests geolocation permission
2. If granted: coordinates matched to nearest city bounding box
3. Matched city auto-selected; dropdown closes; results filter
4. If denied: inline error "Location unavailable — please select a city manually"; dropdown stays open

**Success state:** Correct city auto-selected; user lands on filtered results without typing.

**Failure / edge cases:** 
- Permission denied → inline message, manual selection remains available
- Coordinates outside all bounding boxes → "Couldn't detect your city" message, prompt manual selection
- Geolocation timeout → same as permission denied

---

### Flow 3: Clear city filter

**Trigger:** User wants to see all restaurants again.

**Steps:**
1. City selector shows active city with an × clear button
2. User clicks × 
3. City cleared from state and localStorage; all-city results returned

---

## Screen Inventory

### Component: City Selector Combobox (shared — NavBar + Home hero + Search page)

**Route / location:** NavBar (all routes), Home hero, Search page filters

**Purpose:** Let users set their location context before or during browsing.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default (no city) | Page load, no localStorage | Placeholder text "All cities" with location pin icon |
| Dropdown open | Click on selector | Dropdown with "📍 Near me" + list of all cities |
| Filtering | User types | Dropdown narrows to matching city names |
| City selected | User clicks a city | Selector shows city name with × clear button; purple active style |
| Near me loading | "Near me" clicked, awaiting geolocation | "Detecting location…" spinner inline in selector |
| Geolocation denied | Permission denied or timeout | Inline message under selector; dropdown reopens for manual selection |
| No match | Typed text matches no city | "No cities found" empty state in dropdown |

**Primary action:** Select a city.

**Out of scope:** Server-side city autocomplete, international cities, city creation/management UI.

---

### Screen: Search Results Page (`/search`) — city filter added

**Route / location:** `/search`

**Purpose:** Extended to show city filter above cuisine and price filters.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default — no city | No city in params | "All cities" selector; full restaurant list |
| City active | City selected | City selector shows active city; results filtered to that city |
| No results for city | City has no restaurants | Empty state: "No restaurants in [City] yet" |
| Loading | Filter change | Skeleton cards while results load |
| Error | API failure | Error message with retry |

---

## Interaction Notes

- **City selector placement in NavBar:** Left of the keyword search input. On mobile, collapses to a compact location-pin button that opens a full-width dropdown. Does not push cart/account actions off screen.
- **Combobox pattern:** `<input>` with a `<datalist>` or custom dropdown — not a plain `<select>` (allows type-to-filter). Keyboard navigable (arrow keys, Enter to select, Escape to close).
- **City persists across navigation:** `localStorage` key `dishly_city` stores `{ id, name }`. Cleared on sign-out. If the stored city no longer exists in the API response, selector resets to "All cities" silently.
- **Near me button:** Always first in the dropdown, visually distinct (location pin icon + "Near me" label). Not just a city name — it's a special action.
- **Active city indicator:** When a city is selected, the selector uses the primary brand colour (purple) border and shows an × to clear. This makes the active filter state unmistakable (Von Restorff effect).
- **Empty state for no-results city:** Includes a "Browse all cities" link — never leaves the user in a dead end.

---

## Accessibility Notes

- City selector `<input>` has `aria-label="Select city"` and `role="combobox"` with `aria-expanded` state
- Dropdown list uses `role="listbox"` with `role="option"` per item
- "Near me" option has descriptive `aria-label="Use my current location to detect city"`
- Keyboard: arrow keys navigate options, Enter selects, Escape closes without selecting
- Location error messages use `role="alert"` for screen reader announcement
- City selector touch target ≥ 44px height on mobile
- Active city × clear button has `aria-label="Clear city filter"`

---

## Assumptions & Open Questions

**Assumptions:**
- `GET /neighbourhoods` returns all cities; no pagination needed (≤ 10 cities for Wave 1)
- City filter persists in URL query param (`?neighbourhood_id=`) for shareability
- The NavBar search bar and Home hero search bar can both host the city combobox without layout regression on mobile
- Bounding box matching (±0.5° centroid) is sufficient accuracy for a food delivery app at this scale

**Open questions:**
- Should the Home page collections also filter by selected city, or only the `/search` page? Recommend yes — collections should respect city context so users don't see NYC collections when browsing LA. [owner: product — recommend yes, implement together]
