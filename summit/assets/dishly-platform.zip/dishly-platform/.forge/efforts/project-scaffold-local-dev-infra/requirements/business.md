# Business Requirements: Project Scaffold + Local Dev Infrastructure

*Product / Effort: project-scaffold-local-dev-infra*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Single-command local startup

**Priority:** P0

The business must ensure that any engineer with Node.js LTS installed can clone the
repository and have the full application running locally without manual setup, additional
installs, or configuration steps beyond having Node.js — so that onboarding friction is
eliminated and engineers can begin development immediately.

**Acceptance Criteria:**
- [ ] An engineer with only Node.js LTS installed can go from a fresh clone to a fully running local application using a single command
- [ ] Both the backend and frontend are accessible in a browser after the startup command completes
- [ ] Running the startup command multiple times does not corrupt data or result in duplicate or inconsistent state

---

## BR-2: Backend and frontend run as concurrent processes

**Priority:** P0

The business must ensure that the backend API service and the React frontend development
service run simultaneously from a single launch point, with output from each service
clearly attributed — so that engineers can monitor both services in a single terminal
session without additional tooling.

**Acceptance Criteria:**
- [ ] Both services become available from a single startup command with no manual steps required between them
- [ ] Output from each service is visually distinguishable by a label or prefix identifying the source service
- [ ] Stopping the launcher terminates both services cleanly without leaving residual background processes

---

## BR-3: Database seeded on first run

**Priority:** P0

The business must ensure that the local development database is automatically populated
with seed data on first run and that subsequent runs do not overwrite or duplicate that
data — so that engineers have a ready-to-use dataset without manual migration or seed
commands.

**Acceptance Criteria:**
- [ ] On first run, the database is created and seed data is loaded automatically
- [ ] On subsequent runs, the seed step is skipped without error and existing data is preserved
- [ ] The location of the database file is configurable without modifying source code
