# Technical Requirements — Project Scaffold + Local Dev Infrastructure

*Effort: project-scaffold-local-dev-infra*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-05*

---

## TR-1: Local-only infrastructure

*Traces to: [BR-1](business.md#br-1-single-command-local-startup)*

The entire stack runs as local processes on a developer's machine. No cloud
infrastructure, no Docker, no container runtime, no remote services.

**Constraints:**
- All services run as local OS processes
- Data is persisted to the local filesystem
- No network calls to remote infrastructure at runtime

---

## TR-2: Technology stack

*Traces to: [BR-1](business.md#br-1-single-command-local-startup), [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes)*

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite |
| Backend | Node.js + Express |
| Database | SQLite via better-sqlite3 |
| Auth | JWT (jsonwebtoken) |
| Payment | Stripe test mode (stripe npm package) |
| IDs | uuid |
| CORS | cors |

**Constraints:**
- No external databases (Postgres, MySQL, MongoDB, Redis)
- No third-party auth services (Auth0, Firebase, Cognito)
- Frontend and backend run as separate local processes

---

## TR-3: Concurrent process launcher uses `concurrently`

*Traces to: [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes)*

`start.sh` uses the `concurrently` npm package (installed as a root-level dev
dependency) to run backend and frontend in parallel in the same terminal.

**Rationale:** `concurrently` handles labeled output, graceful Ctrl-C shutdown of
both processes, and non-zero exit propagation — more reliable than backgrounding
with `&` and a signal trap.

**Constraints:**
- Root `package.json` declares `concurrently` as a dev dependency
- Output prefixes: `[backend]` and `[frontend]`
- Both processes terminate when the launcher is stopped

---

## TR-4: Backend server entry point and port

*Traces to: [BR-1](business.md#br-1-single-command-local-startup), [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes)*

**Constraints:**
- Entry point: `backend/src/server.js`
- Port: `process.env.PORT || 3001`
- Directory structure: `backend/src/{routes,middleware,db}/`
- API routes mounted under `/dishly/v1/`
- Unmatched `/dishly/v1/*` routes return JSON 404, not HTML

---

## TR-5: Frontend entry point and port

*Traces to: [BR-1](business.md#br-1-single-command-local-startup), [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes)*

**Constraints:**
- Scaffolded with Vite + React template
- Port: `process.env.VITE_PORT || 3000` (via Vite config)
- React Router v6 for client-side routing
- All 9 routes from the initiative spec defined as stub components
- Express backend serves `index.html` catch-all for all non-API routes so
  direct URL navigation works in production builds

---

## TR-6: SQLite database location and seed behaviour

*Traces to: [BR-3](business.md#br-3-database-seeded-on-first-run)*

**Constraints:**
- DB file path: `process.env.DB_PATH || './data/dishly.db'`
- Seed detection: check for existence of the DB file or a sentinel row before seeding
- Seed is skipped (not re-run) if already seeded — idempotent
- Seed data committed to repository under `data/seed/`

---

## TR-7: Root package.json and start script

*Traces to: [BR-1](business.md#br-1-single-command-local-startup), [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes), [BR-3](business.md#br-3-database-seeded-on-first-run)*

**Constraints:**
- Root `package.json` with `concurrently` dev dependency
- `start.sh` at repo root performs in order:
  1. Install `backend/node_modules` if absent (`npm install --prefix backend`)
  2. Install `frontend/node_modules` if absent (`npm install --prefix frontend`)
  3. Install root `node_modules` if absent (`npm install`)
  4. Seed database if not already seeded (`node backend/src/db/seed.js`)
  5. Launch both processes via `npx concurrently`
- Script is executable (`chmod +x start.sh`)
- Only runtime dependency on the host is Node.js LTS
