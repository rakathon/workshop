# PRD: Project Scaffold + Local Dev Infrastructure

*Product / Effort: project-scaffold-local-dev-infra*
*Last updated: 2026-06-07*

---

## Problem Statement

Every Wave 1 epic — restaurant APIs, auth, discovery frontend, ordering flow — depends on a runnable local development environment. Without a working scaffold, no engineer can start building: there is no Express server to add routes to, no SQLite database to query, no React dev server to render components in, and no way to run the full stack from a single command. The absence of this foundation blocks all downstream development.

This effort creates the minimal runnable monorepo for dishly Wave 1: a `./start.sh` that goes from a fresh Node.js installation to a running backend (port 3001) and React frontend (port 3000) with a seeded SQLite database — in a single command, with no Docker, no cloud infrastructure, and no manual setup steps. The scaffold defines the project's directory structure, technology stack, and startup contract that all subsequent epics build on top of.

---

## Goals

1. Single-command startup works from a fresh clone — measured by `./start.sh` completes without error on a machine with only Node.js LTS installed and no prior dependencies
2. Both services reachable after startup — measured by backend responds at `http://localhost:3001/dishly/v1/` and frontend responds at `http://localhost:3000/` after `./start.sh`
3. Database seeded on first run, skipped on subsequent runs — measured by 100 restaurants present after first `./start.sh`; running it a second time does not duplicate or corrupt data
4. API routing convention established — measured by all API routes are under `/dishly/v1/`; any unmatched API route returns JSON 404 (not HTML); any non-API route serves `index.html` for client-side routing
5. Startup script is idempotent — measured by running `./start.sh` 3 times in a row produces the same result as running it once

---

## Non-Goals

- We are not building CI/CD, Docker, or cloud deployment — the scaffold is local-only; no containerisation, no remote environment
- We are not building the actual API endpoints or frontend screens — stub routes and components only; real implementation belongs to downstream epics
- We are not building hot-reload or watch mode beyond what Vite and `node` provide by default
- We are not building a production build pipeline — `npm run build` for the frontend is outside the scope of Wave 1 local dev
- We are not building environment-specific configuration management — a single `.env.example` is sufficient; no multi-environment config system

---

## Success Metrics

### Leading Indicators (early signal)

- `./start.sh` completes in under 3 minutes on a clean machine with only Node.js LTS (target: 100% of test runs)
- Both `localhost:3001` and `localhost:3000` respond with HTTP 200 after startup (target: 100%)
- Seed script logs "[seed] Already seeded — skipping." on the second run (target: 100%)

### Lagging Indicators (final outcome)

- Zero blocked engineers due to scaffold setup issues during the Wave 1 development period
- All downstream epics (`core-backend-apis`, `user-auth`, `consumer-web-discovery`, `native-ordering-checkout`) build successfully on top of the scaffold without modifying `start.sh` or the root directory structure

---

## Open Questions

None identified at this time. Technology stack, directory structure, port assignments, and startup script behaviour are all specified in TR-1 through TR-7.

---

## Timeline / Dependencies

- **Target:** Must be complete before any other Wave 1 epic can begin implementation
- **Dependencies:** None — this is the foundation; it has no upstream blockers
- **Blocks:** All other Wave 1 epics depend on this effort being complete

---

## Requirements

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.
