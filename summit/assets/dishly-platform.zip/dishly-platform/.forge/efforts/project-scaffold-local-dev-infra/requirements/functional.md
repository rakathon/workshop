# Functional Requirements — Project Scaffold + Local Dev Infrastructure

*Effort: project-scaffold-local-dev-infra*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Single startup command installs dependencies and starts all services

*Traces to: [BR-1](business.md#br-1-single-command-local-startup)*

The system must provide a single executable entry point at the repository root that, when invoked, installs all required dependencies and starts both the backend and frontend services without any additional manual steps.

---

## FR-2: Startup command is idempotent

*Traces to: [BR-1](business.md#br-1-single-command-local-startup)*

The system must allow the startup command to be invoked multiple times in succession without corrupting data, creating duplicate records, or failing due to previously installed dependencies or an already-initialised database.

---

## FR-3: Backend and frontend launched as concurrent processes from a single command

*Traces to: [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes)*

The system must start the backend API service and the frontend development server as concurrent processes from a single invocation, without requiring the operator to open separate terminal sessions or run additional commands.

---

## FR-4: Service output labeled by source in the shared terminal

*Traces to: [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes)*

The system must prefix each line of log output with a label identifying whether it originates from the backend or the frontend service, so that interleaved output remains distinguishable.

---

## FR-5: Launcher termination stops both services cleanly

*Traces to: [BR-2](business.md#br-2-backend-and-frontend-run-as-concurrent-processes)*

When the launcher process receives a termination signal, the system must propagate that signal to both the backend and frontend processes and wait for them to exit before the launcher itself exits, leaving no orphaned processes.

---

## FR-6: Database initialised and seeded on first run

*Traces to: [BR-3](business.md#br-3-database-seeded-on-first-run)*

On first invocation, the system must create the database file, apply the schema, and load the seed dataset automatically as part of the startup sequence — before the backend service begins accepting requests.

---

## FR-7: Seed step skipped when database already exists

*Traces to: [BR-3](business.md#br-3-database-seeded-on-first-run)*

On subsequent invocations, the system must detect that the database has already been initialised and skip the seed step without error, preserving any existing data unchanged.

---

## FR-8: Database file location configurable via environment variable

*Traces to: [BR-3](business.md#br-3-database-seeded-on-first-run)*

The system must read the database file path from an environment variable at startup. When the variable is not set, the system must use a documented default path within the repository.

---
