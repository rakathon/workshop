# User Stories: Project Scaffold + Local Dev Infrastructure

*Product / Effort: project-scaffold-local-dev-infra*
*Last updated: 2026-06-07*

---

## Local Dev Onboarding

**US-1:** As an engineer joining the project, I want to run a single command after cloning the repo so that I have the full app running locally without reading setup docs.

**Acceptance Criteria:**
- [ ] Running the single startup command from a fresh clone results in both backend and frontend services being accessible in a browser
- [ ] No additional manual steps, installs, or configuration are required beyond having Node.js LTS installed

---

**US-2:** As an engineer, I want both backend and frontend output labeled in the same terminal so that I can quickly identify which service produced a log line.

**Acceptance Criteria:**
- [ ] Log output from the backend service is prefixed or labeled to distinguish it from frontend output
- [ ] Log output from the frontend service is prefixed or labeled to distinguish it from backend output

---

**US-3:** As an engineer, I want pressing Ctrl-C to stop both processes cleanly so that I don't leave orphaned Node processes running on my machine.

**Acceptance Criteria:**
- [ ] Sending a stop signal to the launcher causes both services to terminate
- [ ] No background processes remain running after the launcher is stopped

---

## First-Run Database Setup

**US-4:** As an engineer running the app for the first time, I want the database to be created and seeded automatically so that I don't need to run any manual migration or seed commands.

**Acceptance Criteria:**
- [ ] On first run, the database is created and populated with seed data without any manual command
- [ ] The application is immediately usable with seed data after the startup command completes

---

**US-5:** As an engineer re-running the startup command, I want the seed step to be skipped if the database already exists so that my existing data is not overwritten.

**Acceptance Criteria:**
- [ ] Running the startup command a second time does not alter or duplicate existing seed data
- [ ] The startup command completes successfully on subsequent runs without errors related to the seed step

---
