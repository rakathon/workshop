# Implementation Plan: Project Scaffold + Local Dev Infrastructure

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

```mermaid
gantt
    title  Project Scaffold + Local Dev Infrastructure — Delivery Sequence
    dateFormat X
    axisFormat Wave %s

    section Backend Stream
    Initialize backend project structure   :task1, 1, 2
    SQLite connection module               :task3, 2, 3
    API prefix + 404 handler               :task4, 2, 3

    section Frontend Stream
    Initialize frontend React project      :task2, 1, 2
    React Router shell routes              :task5, 2, 3

    section Integration
    Express catch-all for frontend         :task6, 3, 4
    Root package.json + start.sh           :task7, 3, 4
    App boots end-to-end                   :milestone, m1, 4, 0
```

---

## Wave 1 — Parallel Project Init

### TASK-001 `[auto]` `[wave:1]`

Initialize the backend Node.js project — create `backend/` directory with `package.json` (dependencies: express, better-sqlite3, jsonwebtoken, uuid, cors, stripe) and `src/` directory structure (`routes/`, `middleware/`, `db/`) with a minimal `src/server.js` that starts Express on `process.env.PORT || 3001`.

**Satisfies:** TR-1, TR-2, TR-4
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

### TASK-002 `[auto]` `[wave:1]`

Initialize the frontend React project — scaffold `frontend/` with Vite + React template (`npm create vite@latest frontend -- --template react`), install `react-router-dom` v6, and verify `npm run dev` starts the dev server on port 3000.

**Satisfies:** TR-1, TR-2, TR-5
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

## Wave 2 — Project Configuration

### TASK-003 `[auto]` `[wave:2]`

Create the SQLite database connection module at `backend/src/db/connection.js` — opens or creates the SQLite file at `process.env.DB_PATH || './data/dishly.db'` using better-sqlite3 and exports the connection as a singleton.

**Satisfies:** TR-1, TR-6
**Depends on:** TASK-001
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

### TASK-004 `[auto]` `[wave:2]`

Configure the Express API prefix and JSON 404 handler — mount all routes under `/dishly/v1/` and add a catch-all middleware that returns a JSON 404 response with `{errors, meta}` envelope for any unmatched `/dishly/v1/*` path.

**Satisfies:** TR-4
**Depends on:** TASK-001
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

### TASK-005 `[auto]` `[wave:2]`

Define all 9 React Router shell routes from TR-5 (`/`, `/search`, `/restaurants/:id`, `/cart`, `/checkout`, `/orders/:id`, `/account/orders`, `/login`, `/register`) as stub page components rendering a `<div>TODO: [route name]</div>` placeholder; wire them into a `<Routes>` block in `App.jsx`.

**Satisfies:** TR-5
**Depends on:** TASK-002
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

## Wave 3 — Integration + Dev Launcher

### TASK-006 `[auto]` `[wave:3]`

Wire the Express server to serve `frontend/dist/index.html` as a catch-all for all non-API routes — ensures direct navigation to any frontend route (e.g. `/restaurants/abc`) returns the React app shell rather than a 404. Use `express.static` for `frontend/dist` in production; in dev the Vite server handles its own routes.

**Satisfies:** TR-4, TR-5
**Depends on:** TASK-004, TASK-002
**Standards:** none
**Required tests:** none (scaffolding task)

**Completed:** no-vcs
---

### TASK-007 `[auto]` `[wave:3]`

Create root `package.json` with `concurrently` as a dev dependency and write `./start.sh` — the script installs `backend/`, `frontend/`, and root `node_modules` if absent, runs the DB seed if not already seeded (`node backend/src/db/seed.js`), then starts both services via `npx concurrently` with `[backend]`/`[frontend]` output prefixes. Mark the script executable.

**Satisfies:** BR-1, BR-2, BR-3, TR-3, TR-7
**Depends on:** TASK-001, TASK-002, TASK-003
**Standards:** none
**Required tests:** none (scaffolding task)
