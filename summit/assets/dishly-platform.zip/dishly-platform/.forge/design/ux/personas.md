# Dishly — User Personas

## Overview

Three primary personas drive the Dishly discovery and ordering experience. A fourth (restaurant operator) is out of scope for the consumer-facing MVP but informs content and data design.

---

## Persona 1 — The Urban Lunch Seeker

**Name:** Maya Chen  
**Age:** 28  
**Role:** Marketing manager, works hybrid 3 days in office  
**Location:** Downtown core, 5-min walk from dozens of restaurants  

### Context
Maya orders lunch 3–4x per week. She's time-boxed to 45 minutes, so she values speed above almost everything else. She uses DoorDash and Yelp but finds Yelp reviews unreliable and DoorDash's discovery experience too product-forward (ads, sponsored placements). She craves a "what's actually good around me right now" answer.

### Goals
- Find something new without analysis paralysis
- Know estimated wait/delivery time before committing
- Avoid paying high delivery fees for short distances
- Reorder from places she already trusts in one tap

### Pain Points
- Sponsored results pollute discovery; she can't trust the top of the feed
- Reviews are unhelpfully aggregated ("4.2 stars, 1,400 reviews" tells her nothing)
- Estimated times are inaccurate — she's been burned

### Behaviors
- Browses on mobile during her 10am coffee
- Decision made in under 2 minutes or she picks something familiar
- Filters by cuisine first, then price
- Shares good finds with her team Slack channel

### Key Quote
> "I don't want to scroll past 20 'Promoted' results. Just show me what's nearby and actually good."

---

## Persona 2 — The Family Dinner Organizer

**Name:** David Torres  
**Age:** 41  
**Role:** Software engineer, fully remote, suburban  
**Location:** Suburbs, 20–30 min from city center  

### Context
David orders family dinners 2–3x per week, often coordinating for 4 people with different preferences (2 kids, partner with a dairy allergy). He's willing to spend more for quality and reliability. He builds a small repertoire of trusted restaurants and reorders from them regularly.

### Goals
- Find family-friendly places with broad menu variety
- See clear allergen and dietary info
- Group ordering without friction (add multiple items from different categories)
- Predictable arrival time so dinner lands on time

### Pain Points
- Can't filter by dietary requirement at the menu item level
- No way to set delivery address for a later time
- Kids want different things; building a cart from a single restaurant is clunky
- Tip prompts at checkout feel aggressive on large orders

### Behaviors
- Browses on tablet or laptop at ~5pm
- Reads recent reviews with photos
- Checks restaurant rating trend (is it going up or down?) not just current score
- Saves favorites to a household list

### Key Quote
> "I need to feed four people, two of whom are picky. I want a restaurant I can trust, not a surprise."

---

## Persona 3 — The Spontaneous Explorer

**Name:** Aisha Patel  
**Age:** 24  
**Role:** Graduate student  
**Location:** Dense urban, university district  

### Context
Aisha has a tight budget and uses food delivery as a treat, not a routine. When she does order, she wants to discover something new — different cuisine, trending spot, something her friends are talking about. She's influenced by social proof (recent reviews, photos, "trending now") and is willing to try a place with few reviews if it looks promising.

### Goals
- Discover genuinely new restaurants, not just the same chains
- Find good food under a specific price point ($20 all-in)
- Make an adventurous choice she can share on social

### Pain Points
- Discovery is dominated by popular chains with big ad budgets
- Hard to tell if a place is actually good for a specific dish vs. overall
- Delivery fees eat into her budget

### Behaviors
- Primarily mobile, often late evening (9–11pm)
- Drawn to editorial content: "Best ramen in the city", "Hidden gems"
- Reads photo-heavy reviews
- Shares restaurants with friends via links

### Key Quote
> "Show me something I haven't tried yet. Something my friends haven't heard of."

---

## Persona Comparison Matrix

| Attribute | Maya (Urban Lunch) | David (Family Dinner) | Aisha (Explorer) |
|-----------|-------------------|----------------------|-----------------|
| Primary device | Mobile | Tablet/Desktop | Mobile |
| Order frequency | 3–4x/week | 2–3x/week | 1–2x/month |
| Decision speed | Fast (<2 min) | Deliberate (5–10 min) | Exploratory |
| Price sensitivity | Medium | Low | High |
| Filter priority | Speed, proximity | Dietary, variety | Novelty, price |
| Trust signal | Delivery time accuracy | Consistent quality | Social proof, photos |
| Reorder behavior | High | Very high | Low |
