# dishly — Consumer Web App UI Spec

<!-- graduated-from: consumer-web-discovery at 2026-06-08T03:44:50Z -->

*Effort: consumer-web-discovery*
*Mode: production*
*Authored: 2026-06-05*
*Design source: [wireframes.md](design/wireframes.md), [personas.md](design/personas.md)*
*Figma file: https://www.figma.com/design/6sg8vnglQNp3o9EAM4Y6s5*
*Traces to: BR-CWD-1 through BR-CWD-8*

---

## Goal

A responsive web application that enables anonymous discovery of curated restaurants and authenticated ordering. The product's credibility rests entirely on a single signal: that every restaurant shown was placed there by someone with taste, not paid placement. Every design decision reinforces or undermines that signal.

---

## Scope

Full consumer-facing web application: 11 screens, responsive (mobile-first, desktop-optimised). No iOS/Android native app.

---

## Design Language

dishly is not a utility. It is an editorial product. Visual decisions should reinforce that:

- **Typography:** Editorial. Large display headings for collection names and restaurant names. Body text is readable and unhurried.
- **Photography:** Food photography is the hero of every screen. The design recedes to let it lead.
- **Whitespace:** Generous. Cramped layouts signal a marketplace optimised for volume. dishly is the opposite.
- **Colour:** Dark primary (near-black), warm off-white backgrounds, one accent colour used sparingly. No bright aggressive brand colours.
- **Iconography:** Minimal. Use text labels rather than icon-only buttons wherever space permits.

### Token reference (implementation)

| Role | Token hint | Notes |
|------|-----------|-------|
| Page background | `background.page` | Off-white or white |
| Primary text | `text.primary` | Near-black |
| Secondary/meta text | `text.secondary` | Muted grey |
| Accent / CTA | `fill.ctaPrimary` | Brand primary, used on primary buttons |
| Border | `border.subtle` | Light dividers between sections |
| Card background | `background.card` | White or slight elevation |
| Success / confirmation | `feedback.success` | Green family |
| Destructive action | `feedback.error` | Red family |
| Hero overlay | semi-transparent dark gradient | For text readability over hero images |

### Spacing scale

- `xsmall` — between inline elements (e.g. icon + label)
- `small` — between tightly related items (e.g. label + field)
- `medium` — standard component internal padding
- `large` — between content sections within a screen
- `xlarge` — between major page sections
- `xxlarge` — hero and page-level padding at tablet+

### Breakpoints

| Key | Width | Layout behaviour |
|-----|-------|-----------------|
| `base` | 0px+ | Single-column, full-width |
| `sm` | 480px+ | Slight padding increase |
| `md` | 768px+ | Two-column where applicable |
| `lg` | 1024px+ | Three-column for restaurant grids |
| `xl` | 1280px+ | Four-column for restaurant grids, max content width |

Max content width: `1200px`, centred. Full-bleed sections (hero images) extend to viewport edge.

---

## Component Reference

| Component | Used for |
|-----------|----------|
| `RestaurantCard` / card primitive | Restaurant cards in collections, search results |
| `HeroTopic` or equivalent | Homepage hero with search bar |
| `TextBlockTopic` | Collection section headers |
| `SimpleGrid` | Restaurant card grids |
| `MenuItemRow` | Each menu item in the restaurant page |
| `Modal` | Auth modal, cart conflict modal |
| `Drawer` | Cart drawer (right side) |
| `FormControl`, `Input` | All form fields |
| `Button` | Primary and secondary CTAs throughout |
| `StarRating` | Review stars, restaurant metadata |
| `Tabs` | Auth modal Sign In / Sign Up switch |
| `Skeleton` | Loading states for all data-driven sections |

---

## Screen Specifications

---

### S-01 — Homepage

**Route:** `/`
**Auth required:** No
**Title:** `dishly — Find food worth eating`

#### Layout

```
┌─ Header ──────────────────────────────────────────────────────────────────┐
├─ Hero (full-bleed) ────────────────────────────────────────────────────── │
├─ Collection: "Best Ramen in the City" ─────────────────────────────────── │
├─ Collection: "New Openings" ───────────────────────────────────────────── │
├─ Collection: [3rd collection] ─────────────────────────────────────────── │
└─ Footer ───────────────────────────────────────────────────────────────── │
```

#### Header

- Logo: `dishly` wordmark, left-aligned.
- Right: `Sign In` (ghost button), `Sign Up` (primary button).
- When authenticated: replace auth buttons with user avatar + name + chevron → opens user menu.
- Cart icon with badge count (0 = hidden, 1+ = shown with count).
- Header is `sticky`, stays visible on scroll.

#### Hero Section

- Full-bleed, dark overlay gradient from bottom.
- Height: `320px` (base) → `480px` (md+).
- Display heading: `"Find food worth eating."` — largest type token.
- Subheading: `"Curated restaurants, not sponsored results."` — `text.secondary` colour.
- Search bar: full-width on base, max-width `540px` on md+. Placeholder: `"Search restaurants or cuisines…"`.

#### Collection Section (repeated per collection)

- Section heading: Collection name, `heading-md` weight, left-aligned.
- `"See all"` link right-aligned on same row as heading.
- Restaurant card grid: `base`: 2-up horizontal scroll; `md`: 3-up grid; `xl`: 4-up grid.
- Each **RestaurantCard**: Cover image (4:3 aspect ratio), restaurant name (bold, 1 line), cuisine type, price range, star rating.
- Broken URL → branded placeholder.

#### States Required

| State | Behaviour |
|-------|-----------|
| Default loaded | Collections populated from config/API |
| Collections loading | Skeleton cards in collection rows |
| Collection empty | Collection row hidden entirely |

---

### S-02 — Search Results

**Route:** `/search?q={query}&cuisine={cuisine}&price={price}`
**Auth required:** No
**Title:** `"{query}" — dishly`

#### Filter Chips

- Cuisine type: horizontal scrollable chip row. One chip is active at a time.
- Price range: `All` (default), `$`, `$$`, `$$$`. Single-select.
- Active chip: `fill.ctaPrimary` background, white text.

#### Result List

- Result count: `"12 restaurants for Thai"`.
- Each result row: thumbnail image, name, cuisine, price range, star rating, 1-line description.
- At `md+`: image left (120px), text right.

#### Empty State

- `"No restaurants found for "{query}" — try a different search."`
- CTA: `"Browse collections"` → `/`.

---

### S-03 — Restaurant Page

**Route:** `/restaurant/:id`
**Auth required:** No (anonymous browse). Auth required for "Add to cart".

#### Hero Image

- Full-bleed, `240px` (base) → `480px` (md+) height.
- Broken URL → grey placeholder with restaurant name text overlay.

#### Restaurant Metadata Block

- Restaurant name: `heading-lg` or `heading-display`.
- Inline meta row: cuisine type · price range · star rating (average + review count).
- Description: `body-md`, up to 4 sentences.

#### Menu

- Menu sections with toggle chevron.
- All sections expanded by default at `md+` (desktop).
- On mobile: sections are collapsible. First section open by default.
- Each **Menu Item Row**: Image 80×80, name (bold), description (2 lines max), price, "Add to cart" button.

#### "Add to Cart" Auth Gate

- If unauthenticated: clicking opens Auth Modal (S-04). After sign-in/up, add-to-cart retried automatically.
- If authenticated, same restaurant: item added silently.
- If authenticated, different restaurant: Cart Conflict Modal (S-06).

#### Reviews Section

- Average rating + review count.
- 3–5 review snippets: star rating, author name, date, review text.
- No review submission UI.

#### States Required

| State | Behaviour |
|-------|-----------|
| Loading | Skeleton for hero, metadata block, first menu section |
| Loaded | Default as specced |
| Cover image broken | Full-width grey placeholder with restaurant name |
| Menu item image broken | 80×80 square placeholder |
| Menu empty | "Menu coming soon" placeholder |
| Restaurant not found | Generic 404 page |

---

### S-04 — Auth Modal (Sign In / Sign Up)

**Trigger:** "Add to cart" when unauthenticated; header "Sign In" / "Sign Up" buttons
**Presentation:** Modal on desktop, bottom sheet on mobile

- Two tabs: `Sign In` | `Sign Up`. Default tab: Sign In.
- Sign In: Email + Password fields. Primary CTA: "Sign In".
- Sign Up: Email + Password + Confirm password. Primary CTA: "Create account".
- No "Forgot password" link (out of scope).
- Post-auth: modal closes; if triggered by add-to-cart, item is added automatically.

---

### S-05 — Cart Drawer

**Trigger:** Cart icon in header
**Presentation:** Right-side drawer on desktop; full-screen bottom sheet on mobile

- Header: `"Your Cart"` + `×` close.
- Restaurant name subtitle.
- Item list: name, `–` / quantity / `+` controls, `×` remove.
- Fee summary: Subtotal, Estimated delivery fee ($3.99), Estimated total.
- `"Proceed to Checkout"` — full-width primary button.
- Empty state: `"Your cart is empty."` + `"Explore restaurants"` link.

---

### S-06 — Cart Conflict Modal

**Trigger:** Authenticated user adds to cart from different restaurant

- Heading: `"Start a new order?"`
- Body: `"You have items from [Restaurant A] in your cart. Starting an order from [Restaurant B] will remove them."`
- `"Keep current cart"` (default, safe) — right-aligned.
- `"Start new order"` (destructive) — left-aligned.

---

### S-07/08/09 — Checkout (3-step linear)

**Route:** `/checkout`
**Auth required:** Yes

- Simplified header: logo only.
- Step progress indicator: `Delivery` · `Payment` · `Review`.
- Step 1: Delivery address (street, apt, city, state, ZIP, instructions).
- Step 2: Stripe Elements card input (test mode).
- Step 3: Read-only order summary + `"Place Order"` CTA.

---

### S-10 — Order Confirmation

**Route:** `/orders/:orderId/confirmation`
**Auth required:** Yes

- Centred card, max-width 560px.
- Success icon (✓).
- Heading: `"Order confirmed!"`
- Order number, restaurant name, delivery address, simulated ETA (30–40 minutes), total.
- Two CTAs: `"View order history"`, `"Back to home"`.

---

### S-11 — Order History

**Route:** `/account/orders`
**Auth required:** Yes

- `"Order History"` heading.
- Reverse-chronological list of orders (expandable rows).
- Each row: restaurant name (link), date, item count, total, expand toggle.
- Expanded: itemised list, delivery fee, total.
- Empty state: `"No orders yet."` + `"Start exploring"` link.

---

## Global / Cross-Screen Requirements

### Error handling

| Scenario | Behaviour |
|----------|-----------|
| Order submission server error | Inline error on checkout Step 3; cart preserved |
| Restaurant 404 | Generic 404 page: `"Restaurant not found"` + back to home |

### Responsive behaviour

- All screens mobile-first. Minimum supported width: `320px`.
- Touch targets: minimum `44×44px`.

### Loading states

Every data-driven section must have a skeleton loading state. No spinners or blank screens.

### Image fallbacks

- Restaurant cover image: full-width grey placeholder, restaurant name text centred.
- Menu item image: `80×80` grey square placeholder.
- Never render a broken `<img>` tag.

### Accessibility (Wave 1 scope)

- All interactive elements keyboard-reachable.
- All form fields have associated `<label>` elements.
- Images have `alt` text.
- Modal and drawer have focus trap and `Escape` dismissal.

---

## Out of Scope (UI)

- Password reset / forgot password flow
- Social sharing or social features
- Personalised recommendations or algorithmic ranking signals
- Reorder shortcut on order history
- Real-time delivery tracking map
- Saved addresses or payment methods
- Apple Pay / Google Pay
- Review submission
- Restaurant search by distance or map view
- Wishlist / saved restaurants
