# Acceptance Test Suite — dishly Wave 1 Beta

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Authored:* 2026-06-05
*Effort:* `dishly-wave-1`

## Why Test This

BR-8 defines explicit launch gates that must all be true before dishly Wave 1 invites beta users. These acceptance tests are the direct digital record of those gates — each scenario corresponds to a named launch criterion from the business requirements and is verified manually (or via the smoke suite) by the person signing off the beta. Passing all scenarios here is the Go/No-Go decision.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| AC-1: 100 seeded restaurants are live and searchable | BR-W1-8 launch gate 1 |
| AC-2: Full discover → order flow completes without errors | BR-W1-8 launch gate 2 |
| AC-3: App loads and is usable on Chrome desktop | BR-W1-8 launch gate 3 |
| AC-4: App loads and is usable on Safari mobile | BR-W1-8 launch gate 3 |
| AC-5: No data loss on order submission | BR-W1-8 launch gate 4 |
| AC-6: No P0 bugs open at launch | BR-W1-8 — P0 definition |
| AC-7: Paid placement mechanism does not exist in codebase | BR-W1-3 — curation integrity |
| AC-8: No restaurant below 3.5 average rating | BR-W1-3, TR-W1-6 — curation quality floor |
| AC-9: Anonymous browse requires no account | BR-W1-1 — account gate position |
| AC-10: Simulated delivery status displayed post-order | BR-W1-5 — no real dispatch |

## Scenarios

### AC-1: 100 seeded restaurants are live, browsable, and searchable

**Given** the application has been started with `./start.sh` on a clean machine
**When** the homepage is loaded
**Then** at least 3 curated collections are visible, each containing restaurant cards
**And** `GET /api/restaurants?limit=100` returns exactly 100 results
**And** searching "ramen" returns at least 1 result
**And** no restaurant card shows a broken image, missing name, or missing rating
**Acceptance gate:** BR-W1-8 — "100 seeded restaurants are live, browsable, and searchable"

---

### AC-2: Full discover → order flow completes without errors end-to-end

**Given** a new test user account created via `/register`
**When** the user browses the homepage → clicks a restaurant → views a menu → adds an item to cart → proceeds to checkout → enters a delivery address → enters a Stripe test card → confirms the order
**Then** the order confirmation screen displays with an order number, restaurant name, delivery address, and simulated ETA
**And** `GET /api/users/me/orders` returns the placed order
**And** no error screen, JavaScript exception, or broken UI state occurs at any step
**Acceptance gate:** BR-W1-8 — "A user can complete the full flow without errors"

---

### AC-3: App loads and is fully usable on Chrome (desktop)

**Given** the app is running locally
**When** it is opened in Google Chrome (latest stable) on a desktop machine at 1280×900
**Then** the homepage renders completely within 10 seconds
**And** search, restaurant browse, and the order flow are fully operable
**And** no console errors of severity Error or above appear during normal navigation
**Acceptance gate:** BR-W1-8 — "app loads and is usable on Chrome"

---

### AC-4: App loads and is fully usable on Safari (mobile)

**Given** the app is running locally or on a shared dev URL
**When** it is opened in Safari on an iPhone (iOS 16+) at 390px viewport width
**Then** the homepage renders without horizontal overflow
**And** all tap targets are reachable without zooming
**And** the search bar, restaurant pages, and checkout flow are operable
**Acceptance gate:** BR-W1-8 — "app loads and is usable on Safari (mobile browser)"

---

### AC-5: No data loss on order submission

**Given** a user with items in their cart proceeds through checkout and places an order
**When** the order is submitted
**Then** the order is durably written to the SQLite database before the confirmation screen is shown
**And** if the browser is closed immediately after the confirmation screen appears, `GET /api/users/me/orders` still returns the order
**And** no partial order (missing items, zero total, null delivery address) exists in the database
**Acceptance gate:** BR-W1-8 — "No data loss on order submission"

---

### AC-6: No P0 bugs are open at launch

**Given** the full test suite (E2E smoke, contract, integration) has been executed against the launch build
**When** all results are reviewed
**Then** zero P0 bugs (data loss, broken checkout, auth failures, unhandled 500s on critical paths) are open
**And** any known issues are triaged to P1 or lower with documented workarounds
**Acceptance gate:** BR-W1-8 — "No P0 bugs open for more than 24 hours"

---

### AC-7: No paid placement mechanism exists in the codebase or data model

**Given** the backend codebase and database schema
**When** the code is reviewed for any column, field, query modifier, or config that could influence restaurant ranking based on payment
**Then** no such mechanism exists: no `is_sponsored`, `boost_score`, `placement_fee`, or equivalent field in any schema or config
**And** `data/collections.json` contains only restaurant IDs — no payment or weight fields
**Acceptance gate:** BR-W1-3 — "no mechanism to accept payment for placement or ranking"

---

### AC-8: No restaurant in the seed dataset has an average rating below 3.5

**Given** the seeded database
**When** `SELECT min(average_rating) FROM restaurant` is executed
**Then** the minimum value is ≥ 3.5
**And** all 100 seeded restaurants have at least 3 reviews contributing to their rating
**Acceptance gate:** BR-W1-3, TR-W1-6 — curation quality floor

---

### AC-9: Anonymous users can browse all discovery surfaces without an account prompt

**Given** a browser with no session cookie or localStorage auth token
**When** the user navigates to `/`, `/search?q=Thai`, and `/restaurants/:id`
**Then** no sign-in modal, prompt, or redirect appears on any of these pages
**And** all content (collections, search results, restaurant page, menu, reviews) is visible
**And** the account gate appears only when the user attempts to add an item to cart
**Acceptance gate:** BR-W1-1 — "discovery and browsing are open to anonymous users"

---

### AC-10: Simulated delivery status is shown after order; no real courier is dispatched

**Given** an order has been successfully placed
**When** the order confirmation screen is displayed
**Then** a simulated ETA message is visible (e.g. "Your order is on its way — estimated 30–40 minutes")
**And** no outbound HTTP call to a delivery partner API is made during the order flow
**And** the `status` field in the order record is `"confirmed"` or `"delivering"` — a static value
**Acceptance gate:** BR-W1-5 — "simulated delivery — no real courier dispatch in Wave 1"
