# Query Patterns

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Authored: 2026-06-05 (dishly-wave-1); extended 2026-06-06 (customer-profile-section)*

---

## Discovery and Restaurant Patterns

| # | Pattern | Entity | Filters | Sort | Source | Notes |
|---|---------|--------|---------|------|--------|-------|
| 1 | List all curated collections | CURATED_COLLECTION | — | sort_order ASC | BR-10, TR-5 | Homepage render |
| 2 | List restaurants in a collection | RESTAURANT | collection_id = ? | sort_order ASC | BR-10 | Via junction table |
| 3 | Search restaurants by name | RESTAURANT | name LIKE ? | — | TR-7 | Case-insensitive |
| 4 | Search restaurants by neighbourhood | RESTAURANT | neighbourhood_id = ? | — | TR-7 | City filter |
| 5 | Search restaurants by menu item name | MENU_ITEM → RESTAURANT | item name LIKE ? | — | TR-7 | Cross-table join; returns parent restaurant |
| 6 | Filter restaurants by cuisine | RESTAURANT | cuisine_id = ? | — | BR-10 | Cuisine filter on search results |
| 7 | Filter restaurants by price range | RESTAURANT | price_range = ? | — | BR-10 | Price filter on search results |
| 8 | Get restaurant by ID | RESTAURANT | id = ? | — | BR-10, BR-16 | Restaurant page |
| 9 | List menu sections for a restaurant | MENU_SECTION | restaurant_id = ? | sort_order ASC | BR-16 | Restaurant page menu |
| 10 | List menu items for a section | MENU_ITEM | section_id = ? | sort_order ASC | BR-16 | Restaurant page menu |
| 11 | List reviews for a restaurant | REVIEW | restaurant_id = ? | date DESC | BR-13 | 3–5 shown on restaurant page |
| 12 | Find user by email | USER | email = ? | — | BR-9 | Login |
| 13 | Get user by ID | USER | id = ? | — | BR-9 | JWT auth middleware |
| 14 | Create order | ORDER | — | — | BR-11 | Checkout submission |
| 15 | Get order by ID | ORDER | id = ? | — | BR-11 | Order confirmation screen |
| 16 | List orders by user | ORDER | user_id = ? | created_at DESC | BR-12 | Order history page |
| 17 | List order items for an order | ORDER_ITEM | order_id = ? | — | BR-12 | Order history detail |
| 18 | Get menu item by ID | MENU_ITEM | id = ? | — | BR-11 | Cart validation at checkout |
| 19 | List all cuisines | CUISINE | — | name ASC | BR-10 | Cuisine filter dropdown |
| 20 | List all neighbourhoods | NEIGHBOURHOOD | — | name ASC | TR-8 | Neighbourhood filter dropdown |

---

## Customer Profile Patterns

*Extended from: customer-profile-section (2026-06-06)*

| Pattern | Entity | Filters | Sort | Source | Notes |
|---------|--------|---------|------|--------|-------|
| Look up user by ID (profile fetch) | USER | `id = ?` | — | BR-2, `GET /users/me` | PK lookup |
| Update user name/phone | USER | `id = ?` | — | BR-2, `PATCH /users/me` | PK lookup |
| Look up user by email (login) | USER | `email = ?` | — | existing `POST /auth/login` | Existing UNIQUE index |
| List addresses for user | USER_ADDRESS | `user_id = ?` | `created_at ASC` | BR-3, Account page | Needs idx on user_id |
| Fetch single address by ID | USER_ADDRESS | `id = ? AND user_id = ?` | — | BR-3, `PATCH /addresses/:id` | PK + user_id filter |
| Count addresses for user (cap check) | USER_ADDRESS | `user_id = ?` | — | TR-6, BR-3 | Served by user_id index |
| Get default address for user | USER_ADDRESS | `user_id = ? AND is_default = 1` | — | BR-3, checkout pre-fill | Served by user_id index |
| Clear default, set new default | USER_ADDRESS | `user_id = ?` then `id = ?` | — | BR-3 | Two-step UPDATE |
| Delete address by ID | USER_ADDRESS | `id = ? AND user_id = ?` | — | BR-3 | PK + user_id filter |
| List payment methods for user | USER_PAYMENT_METHOD | `user_id = ?` | `created_at ASC` | BR-4, Account page | Needs idx on user_id |
| Fetch single payment method by ID | USER_PAYMENT_METHOD | `id = ? AND user_id = ?` | — | BR-4, `PATCH /payment-methods/:id` | PK + user_id filter |
| Count payment methods for user (cap check) | USER_PAYMENT_METHOD | `user_id = ?` | — | TR-6, BR-4 | Served by user_id index |
| Delete payment method by ID | USER_PAYMENT_METHOD | `id = ? AND user_id = ?` | — | BR-4 | PK + user_id filter |
