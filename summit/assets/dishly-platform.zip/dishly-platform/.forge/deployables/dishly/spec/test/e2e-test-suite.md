# E2E Test Suite — Customer Profile Section

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Capability/Effort:* `.forge/efforts/customer-profile-section/spec/test/`
*Authored:* 2026-06-06
*Effort:* customer-profile-section

## Why Test This

The Customer Profile Section is the primary identity and preference hub for dishly customers. It introduces persistent user data (name, phone, delivery addresses, mock payment methods) across registration, sign-in, account management, and checkout flows. If this capability breaks, customers can't personalize their experience, saved addresses stop pre-filling at checkout, and the NavBar shows stale or missing names — eroding trust and increasing checkout friction. The highest-risk behaviors are: (1) name persisting across auth flows, (2) address cap enforcement and default pre-fill at checkout, and (3) profile edits reflecting immediately in the NavBar without a page reload.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: New customer registers with name and sees it in NavBar | [BR-1](../../requirements/business.md#br-1-name-collected-at-registration): Name collected at registration |
| SC-2: New customer registers without name and sees email fallback | [BR-1](../../requirements/business.md#br-1-name-collected-at-registration): Email-prefix fallback when name omitted |
| SC-3: Existing customer signs in and name appears in NavBar dropdown | [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in): Authenticated name display after sign-in |
| SC-4: Customer updates name from Account page, NavBar reflects change immediately | [BR-2](../../requirements/business.md#br-2-personal-info-editing): Personal info editing, [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in): Name display |
| SC-5: Customer sets phone number; invalid format is rejected | [BR-2](../../requirements/business.md#br-2-personal-info-editing): Phone validation |
| SC-6: Customer adds a delivery address and it becomes default | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): Saved delivery addresses |
| SC-7: Customer adds a second address and sets it as default | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): Default address selection |
| SC-8: Adding a third address is rejected with a clear error | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): Address cap enforcement |
| SC-9: Default address pre-fills the delivery field at checkout | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): Checkout pre-fill |
| SC-10: Customer can override pre-filled address at checkout | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): Checkout address override |
| SC-11: Customer adds a mock payment method and it appears at checkout | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): Mock payment methods |
| SC-12: Adding a third payment method is rejected | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): Payment method cap enforcement |
| SC-13: Customer deletes an address; it no longer appears | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): Address deletion |
| SC-14: Customer deletes a payment method; it no longer appears | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): Payment method deletion |
| SC-15: Customer enters a dummy card at checkout and places an order | [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout): card fields; last 4 on confirmation; card not sent to backend |
| SC-16: Invalid dummy card entry is rejected before order submission | [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout): 16-digit validation before submission |
| SC-17: Quantity stepper allows adding multiple units of the same dish | [BR-7](../../requirements/business.md#br-7-quantity-stepper-on-restaurant-menu-page): stepper replaces button; +/− syncs NavBar badge |

## Scenarios

### SC-1: New customer registers with name and sees it in NavBar

**Type:** e2e
**Tags:** smoke-test, non-production
**Given** a new unique email and password
**When** the customer registers with name "Alex Brennan"
**Then** the response includes `user.name = "Alex Brennan"`
**And** the NavBar avatar shows initials "AB"
**And** the NavBar dropdown header shows "Alex Brennan" and the registered email
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "Register form includes an optional Name field; POST /auth/register stores it; NavBar displays name after sign-in"

---

### SC-2: New customer registers without name and sees email-prefix fallback

**Type:** e2e
**Tags:** non-production
**Given** a new unique email `testuser@example.com` and password
**When** the customer registers without providing a name
**Then** the response includes `user.name = null` or `user.name` absent
**And** the NavBar avatar shows initials derived from "testuser" (email prefix)
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "If omitted, display falls back to the email prefix"

---

### SC-3: Existing customer signs in and name appears in NavBar dropdown

**Type:** e2e
**Tags:** smoke-test, non-production
**Given** a registered account with name "Jordan Lee"
**When** the customer signs in via POST /auth/login
**Then** the response includes `user.name = "Jordan Lee"`
**And** the NavBar dropdown header shows "Jordan Lee" and the account email
**And** the NavBar avatar shows initials "JL"
**Verifies:** [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "POST /auth/login response includes name; NavBar displays it immediately after sign-in"

---

### SC-4: Customer updates name from Account page; NavBar reflects change without reload

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with name "Jordan Lee"
**When** the customer submits PATCH /users/me with `{ "name": "Jordan Smith" }`
**Then** the response returns the updated profile with `name = "Jordan Smith"`
**And** the NavBar avatar shows initials "JS" without a page reload
**And** the NavBar dropdown header shows "Jordan Smith"
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "Updated name reflects immediately in NavBar without page reload"; [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "Name visible in dropdown after sign-in"

---

### SC-5: Customer sets phone number; invalid format is rejected before submission

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer on the Account page
**When** the customer submits PATCH /users/me with `{ "phone": "123abc" }`
**Then** the response returns 422 with error code VALIDATION_ERROR
**And** the error message describes the phone format requirement
**When** the customer submits PATCH /users/me with `{ "phone": "4155551234" }`
**Then** the response returns 200 with `phone = "4155551234"`
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "Phone validated as digits-only, 7–15 characters; invalid format shows error"

---

### SC-6: Customer adds a delivery address and it becomes default

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with no saved addresses
**When** the customer posts to POST /users/me/addresses with `{ street: "42 Maple St", city: "Springfield", postcode: "12345", is_default: true }`
**Then** the response returns 201 with the new address and `is_default = true`
**And** GET /users/me/addresses returns the address with `is_default = true`
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Account page lists saved addresses; one address can be set as default"

---

### SC-7: Customer adds a second address and sets it as default; first loses default

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with one default address
**When** the customer posts POST /users/me/addresses with a second address and `is_default: true`
**Then** the response returns 201 with `is_default = true` for the new address
**And** GET /users/me/addresses returns the first address with `is_default = false`
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Only one address can be default at a time"

---

### SC-8: Adding a third address is rejected

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer who already has 2 saved addresses
**When** the customer posts POST /users/me/addresses with a third address
**Then** the response returns 422 with error message containing "Maximum of 2 addresses"
**And** GET /users/me/addresses still returns exactly 2 addresses
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Adding a third address is blocked with a clear error"; [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side) — "Cap enforced server-side"

---

### SC-9: Default address pre-fills delivery field at checkout

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with a default address `{ street: "42 Maple St", city: "Springfield", postcode: "12345" }`
**When** the customer navigates to the Checkout page
**Then** the delivery address field is pre-populated with "42 Maple St, Springfield, 12345"
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Default address pre-fills the delivery address field at checkout"

---

### SC-10: Customer can override the pre-filled address at checkout

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer whose delivery field is pre-filled from saved default
**When** the customer clears the delivery field and types "99 Other St, Shelbyville, 99999"
**And** the customer submits the order
**Then** the order is placed with delivery_address "99 Other St, Shelbyville, 99999"
**And** the saved default address remains unchanged in the customer's profile
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Customer can override the pre-filled address at checkout"

---

### SC-11: Customer adds a mock payment method and it appears at checkout

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with no saved payment methods
**When** the customer posts POST /users/me/payment-methods with `{ card_type: "Visa", cardholder_name: "Alex Brennan" }`
**Then** the response returns 201 with the saved payment method
**And** the Checkout page shows "Visa — Alex Brennan" as a selectable payment option
**And** "Pay on delivery" also appears as a fallback option
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Checkout displays saved payment method(s) as selectable options alongside Pay on delivery"

---

### SC-12: Adding a third payment method is rejected

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer who already has 2 saved payment methods
**When** the customer posts POST /users/me/payment-methods with a third method
**Then** the response returns 422 with error message containing "Maximum of 2 payment methods"
**And** GET /users/me/payment-methods returns exactly 2 methods
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Adding a third payment method is blocked"; [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side) — "Cap enforced server-side"

---

### SC-13: Customer deletes an address; it no longer appears

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with a saved address (id: addr-1)
**When** the customer sends DELETE /users/me/addresses/addr-1
**Then** the response returns 204
**And** GET /users/me/addresses does not contain addr-1
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "DELETE /users/me/addresses/:id removes an address"

---

### SC-14: Customer deletes a payment method; it no longer appears

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with a saved payment method (id: pm-1)
**When** the customer sends DELETE /users/me/payment-methods/pm-1
**Then** the response returns 204
**And** GET /users/me/payment-methods does not contain pm-1
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "DELETE /users/me/payment-methods/:id removes a payment method"

---

---

*Extended: 2026-06-06 — scenarios added from effort customer-profile-section (BR-6, BR-7)*

### SC-15: Customer enters a dummy card at checkout and places an order

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with a non-empty cart and no saved payment methods
**When** the customer navigates to /checkout
**And** selects "Enter a card" and fills in a 16-digit card number, MM/YY expiry, and CVV
**And** clicks "Place Order"
**Then** the order is placed successfully (200 response from POST /orders)
**And** the confirmation page shows "Paid with: card ending ···· XXXX" with the last 4 digits of the entered card
**And** the card details are not present in the order record returned by GET /orders/:id
**Verifies:** [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout) — "Selecting 'Enter a card' reveals card fields; order confirmation shows last 4 digits; card details never sent to backend"

---

### SC-16: Invalid dummy card entry is rejected before order submission

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer on /checkout who has selected "Enter a card"
**When** the customer enters fewer than 16 digits in the card number field and clicks "Place Order"
**Then** an inline validation error appears before submission
**And** no order is created (POST /orders is not called)
**When** the customer corrects the card number to a valid 16-digit format
**Then** the validation error clears and order submission proceeds
**Verifies:** [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout) — "Any 16-digit card number is accepted; expiry and CVV are lightly validated"

---

### SC-17: Quantity stepper allows adding multiple units of the same dish

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer on a restaurant page
**When** the customer clicks "Add to cart" for a dish
**Then** the button is replaced by a stepper showing quantity 1
**When** the customer clicks "+" twice
**Then** the stepper shows quantity 3
**And** the NavBar cart badge shows 3
**And** GET /users/me/... is not called — cart state is client-side only
**When** the customer clicks "−" until quantity reaches 0
**Then** the stepper is replaced by "Add to cart" button
**And** the NavBar cart badge reflects the reduced count
**Verifies:** [BR-7](../../requirements/business.md#br-7-quantity-stepper-on-restaurant-menu-page) — "Add to cart button replaced by stepper; +/− adjust quantity; stepper and NavBar badge stay in sync"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*

---

*Extended: 2026-06-08 — location-based filtering E2E scenarios graduated from add-location-based-filtering*

### SC-LOC-1: City selector filters restaurants to selected city

**Type:** e2e
**Tags:** smoke-test, non-production
**Given** a customer on the Search page with all cities visible
**When** the customer selects "Los Angeles" from the city selector
**Then** GET /restaurants is called with neighbourhood_id matching Los Angeles
**And** only Los Angeles restaurants appear in the results
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-2: Selecting a different city re-filters results immediately

**Type:** e2e
**Tags:** non-production
**Given** a customer with Los Angeles selected as the active city
**When** the customer selects "Chicago" from the city selector
**Then** the restaurant list updates to show only Chicago restaurants
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-3: Clearing city filter restores all-city results

**Type:** e2e
**Tags:** non-production
**Given** a customer with "San Francisco" selected as the active city
**When** the customer clicks the × clear button on the city selector
**Then** GET /restaurants is called without a neighbourhood_id parameter
**And** restaurants from all cities appear in the results
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-4: City selection persists across page reload

**Type:** e2e
**Tags:** non-production
**Given** a customer selects "Miami" from the city selector
**When** the customer reloads the page
**Then** the city selector still shows "Miami"
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-5: City cleared on sign-out

**Type:** e2e
**Tags:** non-production
**Given** a signed-in customer with "Boston" selected as the active city
**When** the customer signs out
**Then** the city selector resets to "All cities"
**And** the localStorage entry for dishly_city is removed
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-6: Near me matches user coordinates to correct city

**Type:** e2e
**Tags:** non-production
**Given** a customer's browser reports coordinates within the San Francisco bounding box (lat 37.77, lng -122.42)
**When** the customer clicks "Near me" in the city dropdown
**Then** the city selector shows "San Francisco"
**Verifies:** [BR-LOC-3](../../requirements/business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)

---

### SC-LOC-7: Geolocation permission denied shows inline fallback message

**Type:** e2e
**Tags:** non-production
**Given** a customer whose browser denies geolocation permission
**When** the customer clicks "Near me" in the city dropdown
**Then** an inline message appears: "Location unavailable — please select a city manually"
**And** the city selector remains at "All cities"
**Verifies:** [BR-LOC-3](../../requirements/business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)

---

### SC-LOC-8: Coordinates outside all bounding boxes use nearest centroid fallback

**Type:** e2e
**Tags:** non-production
**Given** a customer's browser reports coordinates not within any city's bounding box
**When** the customer clicks "Near me"
**Then** the nearest city centroid is used for matching and a city is selected
**Verifies:** [BR-LOC-3](../../requirements/business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)

---

### SC-LOC-9: Los Angeles restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<los-angeles-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-LOC-4](../../requirements/business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)

---

### SC-LOC-10: Chicago restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<chicago-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-LOC-4](../../requirements/business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)

---

### SC-LOC-11: Boston restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<boston-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-LOC-4](../../requirements/business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)

---

### SC-LOC-12: Miami restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<miami-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-LOC-4](../../requirements/business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)

---

### SC-LOC-13: San Francisco restaurants are browsable

**Type:** e2e
**Tags:** non-production
**Given** the seed database has been initialized
**When** GET /restaurants?neighbourhood_id=<san-francisco-id> is called
**Then** the response returns at least 20 restaurants
**Verifies:** [BR-LOC-4](../../requirements/business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)

---

### SC-LOC-14: City filter combines correctly with cuisine filter

**Type:** e2e
**Tags:** non-production
**Given** a customer selects "Los Angeles" as city and "Japanese" as cuisine
**When** GET /restaurants is called with both neighbourhood_id and cuisine_id
**Then** only LA Japanese restaurants are returned
**Verifies:** [BR-LOC-1](../../requirements/business.md#br-loc-1-location-relevant-restaurant-catalogue-without-schema-change)

---

### SC-LOC-15: City filter combines correctly with price filter

**Type:** e2e
**Tags:** non-production
**Given** a customer selects "San Francisco" as city and "$$" as price
**When** GET /restaurants is called with neighbourhood_id and price_range
**Then** only SF restaurants with price_range $$ are returned
**Verifies:** [BR-LOC-1](../../requirements/business.md#br-loc-1-location-relevant-restaurant-catalogue-without-schema-change)

---

### SC-LOC-16: GET /neighbourhoods returns all 10 cities

**Type:** e2e
**Tags:** smoke-test, non-production
**Given** the seed database has been initialized
**When** GET /dishly/v1/neighbourhoods is called
**Then** the response contains exactly 10 entries
**And** the list includes: Manhattan, Brooklyn, Queens, Williamsburg, Astoria, Los Angeles, Chicago, Boston, Miami, San Francisco
**Verifies:** [BR-LOC-1](../../requirements/business.md#br-loc-1-location-relevant-restaurant-catalogue-without-schema-change), [BR-LOC-4](../../requirements/business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)
