# Logical Schema

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Authored: 2026-06-05 (dishly-wave-1); extended 2026-06-06 (customer-profile-section)*

---

## Entity-Relationship Diagram

```mermaid
erDiagram
    USER ||--o{ ORDER : places
    USER ||--o{ USER_ADDRESS : "saves"
    USER ||--o{ USER_PAYMENT_METHOD : "saves"
    USER_ADDRESS ||--o{ ORDER : "pre-fills"

    RESTAURANT }o--|| CUISINE : "categorised as"
    RESTAURANT }o--|| NEIGHBOURHOOD : "located in"
    RESTAURANT ||--|{ MENU_SECTION : has
    RESTAURANT ||--o{ REVIEW : "reviewed by"
    RESTAURANT }o--o{ CURATED_COLLECTION : "featured in"

    MENU_SECTION ||--|{ MENU_ITEM : contains

    ORDER }o--|| RESTAURANT : "placed at"
    ORDER ||--|{ ORDER_ITEM : contains

    ORDER_ITEM }o--|| MENU_ITEM : references
```

## Entities

| Entity | Description |
|--------|-------------|
| USER | A registered consumer account; required to place an order — extended with `name` and `phone` fields (customer-profile-section) |
| USER_ADDRESS | A saved delivery address belonging to a user (max 2 per user); one may be marked as default to pre-fill checkout |
| USER_PAYMENT_METHOD | A mock saved payment method belonging to a user (max 2 per user); card type and cardholder name only |
| RESTAURANT | A curated restaurant in the NYC seed dataset |
| CUISINE | Normalised cuisine type (e.g. Japanese, Italian, Mexican) — shared across restaurants |
| NEIGHBOURHOOD | Named NYC neighbourhood (e.g. Brooklyn, Astoria) — shared across restaurants |
| MENU_SECTION | A named grouping of items on a restaurant menu (e.g. Starters, Mains, Desserts) |
| MENU_ITEM | An individual dish with name, description, price, and photo URL |
| REVIEW | A seeded review on a restaurant — not user-submitted in Wave 1 |
| CURATED_COLLECTION | A named editorial collection (e.g. "Best Ramen in the City") linking to a set of restaurants |
| ORDER | A completed order placed by a user at a single restaurant |
| ORDER_ITEM | A single menu item line within an order, capturing quantity and price at time of order |
