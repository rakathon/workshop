# Customer Profile Section — UX Strategy & Spec

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Effort: customer-profile-section*
*Mode: data-first*
*Written: 2026-06-06*

---

## Problem Framing

**Problem statement:** How might we help registered dishly customers manage their personal information and saved preferences from a single place, given that the existing Account page is read-only and stores no persistent profile data, so that repeat ordering feels personal and frictionless?

**Users affected:** Registered dishly customers who have signed up and placed (or intend to place) orders. Wave 1 closed beta cohort — early adopters comfortable with trying a new product.

**Current workaround / failure mode:** After sign-in, the NavBar shows initials derived from the email prefix (not a real name) because no name is ever stored. The Account page is a static display of email and password placeholder. Every checkout requires manually typing a delivery address. There are no saved payment preferences. The app feels anonymous even when logged in.

---

## Users & Jobs-to-be-Done

### Persona: The Repeat Orderer (proto-persona)

**Job story:** When I open dishly to reorder from a favourite restaurant, I want the app to remember who I am and where I deliver to, so I can get to checkout in as few steps as possible.

**Key constraints / context:** Uses dishly on web (Wave 1 is web-only). Signs in once and stays signed in. Primary frustration is re-entering the same address at every checkout. Would like to feel "at home" in the app — personalised, not anonymous.

### Persona: The New Registrant (proto-persona)

**Job story:** When I sign up for a new food delivery service, I want to provide my name and see it reflected immediately, so I can confirm the account is set up correctly and feel the product knows me.

**Key constraints / context:** Just registered; first impression matters. Expects the sign-up to produce a usable account, not an anonymous shell.

---

## Success Signals

| Signal | Metric | Target |
|--------|--------|--------|
| Adoption | % of logged-in customers who visit `/account` within 7 days of release | ≥ 40% |
| Task success | % of new registrations that include a name | ≥ 60% |
| Checkout efficiency | % of checkout sessions where delivery address is pre-filled | ≥ 50% within 30 days |
| Retention signal | Repeat order rate for customers with saved address vs. without | measurable lift at 30 days |

---

## Information Architecture

```
/account  (Profile hub — single page, tabbed or scrolled sections)
  ├── Profile card (avatar initials, name, email)
  ├── Personal info  (name + phone — inline edit)
  ├── Delivery addresses  (up to 2 — add / edit / delete / set default)
  ├── Payment methods  (up to 2 mock — add / edit / delete)
  ├── Your orders  (link to /account/orders)
  └── Sign out
```

**Navigation model:** Single-page scroll with section anchors. No sub-routes for editing — all edits are inline within the Account page. This minimises navigation depth (Jakob's law) and keeps the user in context while editing.

**Rationale:** Users think of their account as one thing, not five separate destinations. Grouping all profile management on one page reduces cognitive overhead and matches the mental model of every major e-commerce and food delivery app they already use (Jakob's law).

---

## Key User Flows

### Flow 1: Edit personal information

**Trigger:** Customer lands on `/account` and taps "Edit" on the Personal info section.

**Steps:**
1. Personal info section reveals inline form fields (name pre-filled, phone pre-filled or empty)
2. Customer edits name and/or phone
3. Customer taps "Save" — optimistic update shown immediately; API call fires
4. On success: fields return to read view; name updates in NavBar avatar/dropdown
5. On error: inline error message; fields remain editable; no data lost

**Success state:** Read view shows updated name and phone. NavBar initials reflect new name.

**Failure / edge cases:** Invalid phone (non-digits, too short/long) → inline error before submission. Name cleared to empty → blocked with "Name is required" error. API failure → toast or inline error; no data change visible.

---

### Flow 2: Add a delivery address

**Trigger:** Customer taps "Add address" in the Delivery addresses section (visible when < 2 addresses saved).

**Steps:**
1. Inline form appears below existing addresses (label optional, street/city/postcode required)
2. Customer fills fields; can toggle "Set as default"
3. Customer taps "Save address"
4. On success: new address card appears; form collapses; if marked default, checkout pre-fill activates
5. On error: inline field validation or API error shown; form stays open

**Success state:** New address card visible. If default, a "Default" badge shown. "Add address" button hidden if count reaches 2.

**Failure / edge cases:** Attempt to add 3rd address → "Add address" button disabled (not shown); server rejects with 422. Missing required fields → inline errors on submit.

---

### Flow 3: Save a mock payment method

**Trigger:** Customer taps "Add payment method" in the Payment methods section (visible when < 2 saved).

**Steps:**
1. Inline form: card type selector (Visa / Mastercard / Amex) + cardholder name field
2. Customer fills and taps "Save card"
3. On success: payment method card appears with card type icon and masked "cardholder name"
4. On error: inline error shown

**Success state:** Payment method card visible. "Add payment method" hidden at cap of 2.

---

### Flow 4: Sign in and see name in NavBar

**Trigger:** Customer signs in via `/login`.

**Steps:**
1. Customer submits email + password
2. Backend returns `{ user: { name, email, ... }, token }`
3. Frontend stores name in localStorage; NavBar re-renders with initials + name in dropdown
4. Customer is redirected to returnTo URL (default: `/`)

**Success state:** NavBar avatar shows initials from persisted name. Dropdown header shows full name and email. No page reload required.

---

## Screen Inventory

### Screen: Account Page (`/account`)

**Route / location:** `/account`

**Purpose:** The single hub for a customer to view and manage their profile, saved preferences, and access order history.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default (loaded) | Authenticated, data available | Profile card, all four sections populated with current data |
| Loading / skeleton | Initial fetch of profile/addresses/payment methods | Skeleton cards for each section; no layout shift on load |
| Empty — no addresses | Authenticated, no addresses saved | Delivery addresses section shows "No addresses saved yet" with an "Add address" CTA |
| Empty — no payment methods | Authenticated, no payment methods saved | Payment section shows "No payment methods saved" with "Add payment method" CTA |
| Editing — personal info | User taps Edit on Personal info | Inline form replaces read view for name and phone fields |
| Editing — address (add) | User taps "Add address" | Inline form appended below address list |
| Editing — address (edit) | User taps edit icon on an address card | That card flips to inline form; other cards remain in read view |
| Editing — payment method (add) | User taps "Add payment method" | Inline form appended below payment list |
| Editing — payment method (edit) | User taps edit icon on a payment card | That card flips to inline form |
| Save success | Successful PATCH/POST | Inline success feedback (brief); section returns to read view |
| Save error | API failure or validation error | Inline error message below the relevant field; no data lost |
| Cap reached — addresses | 2 addresses saved | "Add address" button absent; section shows both cards |
| Cap reached — payment methods | 2 payment methods saved | "Add payment method" button absent; section shows both cards |

**Primary action:** Edit personal info (most frequent repeat action)

**Out of scope for this screen:** Password reset (Wave 1 beta), email change, account deletion, notification preferences, order tracking.

---

### Screen: NavBar (authenticated state)

**Route / location:** Persistent — all routes

**Purpose:** Signal authenticated identity and provide quick access to account, orders, cart, and sign-out.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Authenticated with name | Name stored in localStorage | Avatar shows initials (up to 2 chars); dropdown shows full name + email |
| Authenticated without name | No name stored (legacy or skipped registration) | Avatar shows email-prefix initials; dropdown shows email only |
| Unauthenticated | No token | "Sign in" and "Join dishly" links |

**Primary action:** Open avatar dropdown to access account or sign out.

---

### Screen: Register page (`/register`)

**Route / location:** `/register`

**Purpose:** Create a new account. Extended to capture an optional name.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default | Fresh form | Email, Password, Name (optional) fields |
| Submitting | Form submitted | Button disabled, "Creating account…" label |
| Error | Validation failure or email conflict | Inline error per field or form-level error |
| Success | Account created | Redirect to returnTo; NavBar shows name |

**Primary action:** Submit the registration form.

---

### Screen: Checkout (`/checkout`) — address pre-fill

**Route / location:** `/checkout`

**Purpose:** Place an order. Extended to pre-fill delivery address and show saved payment options.

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default address pre-filled | Default address saved | Delivery field pre-populated; customer can override |
| No saved address | No address on profile | Delivery field empty; customer types manually (unchanged) |
| Payment method options | ≥1 payment method saved | Radio group: saved card(s) + "Pay on delivery" |
| No payment methods | No methods saved | "Pay on delivery" only (unchanged) |

**Primary action:** Place order.

---

## Interaction Notes

- **Inline editing — no modals:** All edits happen in place within the section. Clicking Edit reveals a form in the same card; clicking Cancel or Save returns to read view. Modals add navigation overhead and are not needed for simple field edits (Tesler's law — absorb the complexity into the pattern, not onto the user).
- **Optimistic updates:** Name and phone changes update the UI immediately on submit. If the API call fails, the change is rolled back and an inline error shown (Doherty threshold — keep perceived latency below 400ms).
- **Default address toggle:** Only one address can be default at a time. Setting a new default automatically clears the previous one server-side and updates the UI without requiring a separate save.
- **Cap enforcement — "Add" button hidden at limit:** The "Add address" and "Add payment method" buttons are removed from the DOM (not just disabled) when the cap is reached. This avoids a confusing disabled state and removes the temptation to try. A short note ("Maximum 2 addresses") is shown instead.
- **Delete confirmation:** Destructive actions (delete address, delete payment method) show an inline confirmation ("Delete this address? Yes / Cancel") rather than a modal or immediate deletion. Prevents accidents; honours user control (Nielsen #3).
- **NavBar reactivity:** After saving a name change, the NavBar re-renders without a full page reload. Implementation uses a `storage` event or a shared React context to notify the NavBar of the updated localStorage value.
- **Phone formatting:** Input accepts digits only; spaces, dashes, and parens are stripped on save (Postel's law — be liberal in what you accept). Displayed as stored (plain digits).

---

## Microcopy Direction

- Section labels: uppercase, 11px, muted — consistent with existing `.account-section__title` pattern
- Edit trigger: "Edit" text link (not a full button) — low visual weight, secondary affordance
- Save button: "Save changes" (personal info), "Save address", "Save card" — verb + object, never just "Submit"
- Cancel: plain "Cancel" — no icon, no color, keyboard accessible
- Empty states: inviting, not apologetic — "Add your first delivery address" not "No addresses found"
- Cap note: "You've reached the 2-address limit" — matter-of-fact, no apology
- Delete confirm: "Delete this address?" with "Delete" (danger color) and "Keep it" — friendly, clear
- Error messages: specific and actionable — "Phone must be 7–15 digits" not "Invalid input"

---

## Accessibility Notes

- All inline edit forms use `<label>` elements associated with inputs by `for`/`id`
- Edit/Delete/Save/Cancel controls are `<button>` elements — keyboard operable
- Error messages use `role="alert"` so screen readers announce them on appearance
- Delete confirmation inline — no focus trap needed (not a modal); focus moves to "Delete" button on reveal
- Address and payment method cards use `<article>` with an accessible name (address label or card type + name)
- NavBar dropdown: `aria-expanded` on trigger button, `role="menu"` on dropdown (already implemented)
- Reduced motion: optimistic UI transitions respect `prefers-reduced-motion` — no animation if preference is set
- Contrast: all text on `--color-surface` backgrounds passes 4.5:1 against `--color-text` (#1A1A1A on #FFFFFF = 16.1:1); muted text (`--color-text-muted` #767676) passes 4.6:1

---

## Assumptions & Open Questions

**Assumptions:**
- Customer is authenticated before reaching `/account`; unauthenticated access redirects to `/login`
- The NavBar is re-rendered reactively when localStorage changes (or a shared auth context exists)
- Skeleton loading is shown for < 300ms typical API responses; full loading state for slower connections
- The existing `Account.jsx` CSS classes (`.account-section`, `.account-card`, `.account-info-row`, etc.) are extended, not replaced
- Existing registered users with no stored name will see email-prefix initials until they set a name via the edit flow

**Open questions:**
- Should existing users without a name be prompted to complete their profile on next login? (owner: product, due: before implementation)
- Does checkout pre-fill need an explicit override flow, or is editing the pre-filled field sufficient? (owner: eng, due: planning phase)
- Should deleting the default address automatically promote the remaining address to default? (owner: product — recommend: yes)

---

# add-location-based-filtering — UX Strategy & Spec

*Effort: add-location-based-filtering*
*Mode: data-first*
*Written: 2026-06-06*

---

## Problem Framing (Location-Based Filtering)

**Problem statement:** How might we help dishly customers outside New York City (and NYC customers who want neighbourhood-level results) filter restaurants to their location, given that the app currently shows all restaurants with no location awareness, so that browsing feels relevant and ordering is possible?

**Users affected:** All dishly customers — the app is currently only useful to NYC users. Non-NYC users see 100 irrelevant restaurants with no way to filter. NYC users can't narrow to their neighbourhood.

**Current workaround / failure mode:** Users must scroll through all restaurants regardless of location. No city or neighbourhood filter exists anywhere in the current UI.

---

## Users & Jobs-to-be-Done (Location-Based Filtering)

### Persona: The Out-of-City Customer (proto-persona)

**Job story:** When I open dishly in my city, I want to instantly see only restaurants that can deliver to me, so I can find something to order without wading through irrelevant results.

**Key constraints / context:** First-time or returning user; may or may not grant location permission. Expects the app to "just know" their city like every major food delivery app does.

### Persona: The NYC Regular (proto-persona)

**Job story:** When I search for food on dishly, I want to filter to my neighbourhood (e.g. Brooklyn vs. Queens), so I see restaurants relevant to where I actually am.

---

## Success Signals (Location-Based Filtering)

| Signal | Metric | Target |
|--------|--------|--------|
| Adoption | % of search sessions with city filter applied | ≥ 30% within 2 weeks |
| Near me accuracy | Correct city matched for test coordinates in each bounding box | ≥ 90% |
| Non-NYC orders | % of non-NYC registered users who complete an order at 30 days | measurable lift from 0% |

---

## Information Architecture (Location-Based Filtering)

```
NavBar (persistent)
  └── Search bar
        ├── [City selector combobox] ← NEW — left of keyword input
        └── [Keyword input] (existing)

Home page
  └── Hero search bar
        ├── [City selector combobox] ← NEW — left of keyword input
        └── [Keyword input + Search button] (existing)

/search (Search results page)
  └── Filters row
        ├── City filter pills OR city selector ← NEW — above existing cuisine/price
        ├── Cuisine filter pills (existing)
        └── Price filter pills (existing)
```

**Navigation model:** City selection is a persistent filter — set once in the NavBar/hero combobox, carried through to search results and home collections.

---

## Key User Flows (Location-Based Filtering)

### Flow 1: Manual city selection

**Trigger:** User visits dishly from a new city or wants to change location.

**Steps:**
1. User clicks the city selector (shows placeholder "All cities" or current city)
2. Dropdown opens showing all available cities; "Near me" at top
3. User types to narrow — dropdown filters client-side
4. User clicks a city name
5. City selector shows selected city; restaurant results re-filter immediately
6. City stored in localStorage for next visit

**Success state:** Restaurant list shows only the selected city's restaurants.

---

### Flow 2: Near me auto-detection

**Trigger:** User clicks "Near me" in the city dropdown.

**Steps:**
1. Browser requests geolocation permission
2. If granted: coordinates matched to nearest city bounding box
3. Matched city auto-selected; dropdown closes; results filter
4. If denied: inline error "Location unavailable — please select a city manually"; dropdown stays open

**Success state:** Correct city auto-selected; user lands on filtered results without typing.

---

### Flow 3: Clear city filter

**Trigger:** User wants to see all restaurants again.

**Steps:**
1. City selector shows active city with an × clear button
2. User clicks ×
3. City cleared from state and localStorage; all-city results returned

---

## Screen Inventory (Location-Based Filtering)

### Component: City Selector Combobox

**Route / location:** NavBar (all routes), Home hero, Search page filters

**Required states:**

| State | Trigger | What the user sees |
|-------|---------|-------------------|
| Default (no city) | Page load, no localStorage | Placeholder text "All cities" with location pin icon |
| Dropdown open | Click on selector | Dropdown with "📍 Near me" + list of all cities |
| Filtering | User types | Dropdown narrows to matching city names |
| City selected | User clicks a city | Selector shows city name with × clear button; purple active style |
| Near me loading | "Near me" clicked, awaiting geolocation | "Detecting location…" spinner inline in selector |
| Geolocation denied | Permission denied or timeout | Inline message under selector; dropdown reopens for manual selection |
| No match | Typed text matches no city | "No cities found" empty state in dropdown |

---

## Interaction Notes (Location-Based Filtering)

- **City selector placement in NavBar:** Left of the keyword search input.
- **Combobox pattern:** `<input>` with custom dropdown — allows type-to-filter. Keyboard navigable.
- **City persists across navigation:** `localStorage` key `dishly_city` stores `{ id, name }`. Cleared on sign-out.
- **Near me button:** Always first in the dropdown, visually distinct.
- **Active city indicator:** Purple border and × to clear when city is selected.
- **Empty state for no-results city:** Includes a "Browse all cities" link.

---

## Accessibility Notes (Location-Based Filtering)

- City selector `<input>` has `aria-label="Select city"` and `role="combobox"` with `aria-expanded` state
- Dropdown list uses `role="listbox"` with `role="option"` per item
- "Near me" option has descriptive `aria-label="Use my current location to detect city"`
- Keyboard: arrow keys navigate options, Enter selects, Escape closes
- Location error messages use `role="alert"` for screen reader announcement
- City selector touch target ≥ 44px height on mobile

---

## Assumptions & Open Questions (Location-Based Filtering)

**Assumptions:**
- `GET /neighbourhoods` returns all cities; no pagination needed (≤ 10 cities for Wave 1)
- City filter persists in URL query param (`?neighbourhood_id=`) for shareability
- Bounding box matching (±0.5° centroid) is sufficient accuracy for a food delivery app at this scale

**Open questions:**
- Should the Home page collections also filter by selected city, or only the `/search` page? Recommend yes — collections should respect city context so users don't see NYC collections when browsing LA.

---

# dishly Wave 1 — UX Strategy & Spec

*Graduated from: dishly-wave-1 at 2026-06-08T03:44:50Z*
*Mode: exploration → production (greenfield; Mode B tokens)*
*Date: 2026-06-05*

---

## 1. Problem & framing (dishly Wave 1)

**Problem statement:**
How might we help quality-conscious urban consumers (22–40) discover restaurants worth eating at, given that incumbent platforms poison signal with paid placements and force app-switching, so that they can find food they're proud to order in a single trusted surface?

**What success looks like:**
- *For the user:* They land on dishly and within one session find a restaurant they hadn't heard of, feel confident it's actually good, and complete an order without friction or surprises.
- *For the business:* Wave 1 closed beta users complete the full discover → order loop with ≥90% order success rate.

**The one thing this must get right:**
The homepage must earn trust in under 10 seconds. If it looks like DoorDash with better fonts, Maya leaves. The curation signal — editorial collection names, food photography quality, absence of "sponsored" — is the product's entire value proposition.

---

## 2. Users & jobs (dishly Wave 1)

### Persona 1 — Maya, The Intentional Orderer
- **Goal:** Discover restaurants she hasn't heard of that meet her quality bar; trust the surface without verification on another app.
- **Mental model:** Discovery is editorial browsing — closer to reading Eater than using a vending machine.
- **Primary job story:** When I'm deciding where to order lunch and I don't know what I want, I want a curated starting point I can trust, so I can discover somewhere new without spending 20 minutes across three apps.

### Persona 2 — Darius, The Efficient Professional
- **Goal:** Get a reliable non-chain meal without cognitive overhead; fast checkout.
- **Mental model:** Discovery is a search/filter utility.
- **Secondary job story:** When I know what cuisine I want and I need to order quickly, I want search + filter that gives me trustworthy results fast.

### Persona 3 — Priya, The Explorer
- **Goal:** Feel like she discovered something worth sharing; beautiful food photography.
- **Mental model:** The homepage is a magazine cover; if it doesn't have editorial taste, she stops reading.

---

## 3. Success signals (dishly Wave 1)

| Signal | Metric | Target |
|--------|--------|--------|
| **Task success** | % of sessions completing discover → order with zero errors | ≥90% order success rate |
| **Engagement** | % of sessions clicking into at least one restaurant page from the homepage | ≥60% |
| **Retention** | Beta users placing a second order within 2 weeks | >30% |

---

## 4. Information architecture (dishly Wave 1)

### Sitemap
```
dishly
├── Homepage (/)
│   └── Curated collections → Restaurant Page
│   └── Search bar → Search Results
├── Search Results (/search?q=)
│   └── Filter: cuisine type, price range
├── Restaurant Page (/restaurants/:id)
│   ├── Hero + metadata
│   ├── Menu (sections + items + Add to Cart)
│   └── Reviews
├── Auth — Sign In (/login), Sign Up (/register)
├── Cart (/cart — drawer or page)
├── Checkout (3-step: Address → Payment → Review)
├── Order Confirmation (/orders/:id)
└── Account → Order History (/account/orders)
```

---

## 5. Key flows (dishly Wave 1)

### Flow A — Editorial discovery (Maya's path)
Homepage → collection → restaurant page → menu → add to cart → auth gate (first order) → sign up → checkout (address → payment → review) → confirmation

### Flow B — Search + filter (Darius's path)
Homepage → search → filter chips → restaurant page → add to cart → checkout

### Flow C — Order history (Priya's return path)
Header user menu → order history → expand order → click restaurant name

---

## 6. Page intent (dishly Wave 1)

**S-01 Homepage:** Give Maya and Priya an editorial reason to trust dishly within 10 seconds. Content priority: hero search bar + headline → first curated collection → subsequent collections.

**S-02 Search Results:** Help Darius eliminate options fast via filter. Content priority: search bar → filter chips → result count → result rows.

**S-03 Restaurant Page:** Help Maya form a confident decision. Content priority: hero image → name/cuisine/price/rating → description → menu → reviews.

**S-10 Order Confirmation:** Give Darius a clear "done" moment. Content priority: check icon → "Order confirmed!" → order number → simulated ETA "30–40 minutes" → total.

---

## 7. Interaction & content notes (dishly Wave 1)

- "Add to cart" button: optimistic micro-animation (briefly shows "Added ✓")
- Cart drawer: slides from right on desktop; full-screen bottom sheet on mobile
- Auth modal: center modal on desktop; bottom sheet on mobile
- Collection rows: scroll horizontally on mobile (2.5 cards visible)
- Brand voice: confident and discerning. "Best Ramen in the City" — not "Yum!"
- ETA language: "estimated 30–40 minutes" — use "estimated" to set expectation that this is a simulation
