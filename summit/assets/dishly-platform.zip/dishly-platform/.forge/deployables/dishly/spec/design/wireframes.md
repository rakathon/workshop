# dishly — Wireframes

<!-- graduated-from: consumer-web-discovery at 2026-06-08T03:44:50Z -->

*Effort: consumer-web-discovery*
*Authored: 2026-06-05*
*Traces to: BR-CWD-1, BR-CWD-3, BR-CWD-4, BR-CWD-6, BR-CWD-7*
*Screens: S-01 through S-11 (see [user-flows.md](user-flows.md))*

Notation: `[ ]` = container/section, `< >` = interactive element, `---` = divider

All wireframes shown at desktop width (1280px), with mobile notes per screen.

---

## S-01 — Homepage

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER                                                                     │
│  [ dishly logo ]                             < Sign In >   < Sign Up >     │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  HERO / SEARCH                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │   Find food worth eating.                                           │   │
│  │                                                                     │   │
│  │   ┌────────────────────────────────────────────┐ < Search >        │   │
│  │   │  Search restaurants or cuisines...         │                   │   │
│  │   └────────────────────────────────────────────┘                   │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│  (full-width background: editorial food photography or gradient)            │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  COLLECTION: "Best Ramen in the City"                  < See all >         │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐               │
│  │ [img]     │  │ [img]     │  │ [img]     │  │ [img]     │               │
│  │           │  │           │  │           │  │           │               │
│  │ Name      │  │ Name      │  │ Name      │  │ Name      │               │
│  │ Japanese  │  │ Japanese  │  │ Japanese  │  │ Japanese  │               │
│  │ $$  ★4.8  │  │ $$  ★4.7  │  │ $$$  ★4.6 │  │ $$  ★4.9  │               │
│  └───────────┘  └───────────┘  └───────────┘  └───────────┘               │
│  (horizontal scroll on mobile; 4-up grid on desktop)                       │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  COLLECTION: "New Openings"                            < See all >         │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐               │
│  │ [img]     │  │ [img]     │  │ [img]     │  │ [img]     │               │
│  │ Name      │  │ Name      │  │ Name      │  │ Name      │               │
│  │ Italian   │  │ Mexican   │  │ Thai      │  │ Korean    │               │
│  │ $  ★4.5   │  │ $$  ★4.3  │  │ $$  ★4.8  │  │ $$$  ★4.7 │               │
│  └───────────┘  └───────────┘  └───────────┘  └───────────┘               │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  COLLECTION: "Under $15"                               < See all >         │
│  [ ...same card pattern... ]                                                │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│  FOOTER  [ About ]  [ For restaurants ]  [ © dishly 2026 ]                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Header: logo left, auth CTAs right. No nav links for Wave 1 (collections are on homepage).
- Hero search bar is the primary action above the fold. No background video.
- Collections are content-managed (JSON/config). At least 3 collections on homepage.
- Restaurant cards: cover image (4:3 ratio), restaurant name (bold), cuisine type, price range ($–$$$), star rating + number.
- Card image broken URL → grey placeholder with fork icon.
- Mobile (< 768px): hero search bar full-width, collections become horizontal scroll rows (2.5 cards visible to indicate scroll), "See all" collapses.

---

## S-02 — Search Results

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER (same as S-01, auth-aware)                                          │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  SEARCH BAR (sticky on scroll)                                              │
│  ┌──────────────────────────────────────┐ < Search >                        │
│  │  "Thai"                              │                                   │
│  └──────────────────────────────────────┘                                   │
│                                                                             │
│  FILTERS (inline chips — no modal)                                          │
│  Cuisine: < All > < Japanese > < Thai > < Italian > < Mexican > < Korean > │
│           < Indian > < Chinese > ... (scrollable)                           │
│  Price:   < All > < $ > < $$ > < $$$ >                                     │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  RESULTS  "12 restaurants for Thai"                                         │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [img 120×90]  Name of Restaurant                    $$  ★4.7        │   │
│  │                Thai  ·  Delivery available                           │   │
│  │                Short one-line description of the restaurant          │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [img 120×90]  Name of Restaurant                    $   ★4.5        │   │
│  │                Thai  ·  Delivery available                           │   │
│  │                Short one-line description                            │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  [ ... repeat rows ... ]                                                    │
│                                                                             │
│  ── EMPTY STATE (when no results) ─────────────────────────────────────────│
│                                                                             │
│      No restaurants found for "xyz"                                         │
│      Try a different search or browse our collections.                      │
│      < Browse collections >                                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Search bar pre-filled with active query. Editing it re-runs search.
- Filter chips: tapping a cuisine type or price narrows results inline (no page reload).
- Result rows: image left (thumbnail), metadata right. Entire row is clickable.
- Result count shown above results ("12 restaurants").
- Mobile: filter chips scroll horizontally; result rows go full-width.

---

## S-03 — Restaurant Page

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  HEADER (with cart icon showing item count if cart has items)               │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  HERO IMAGE (full-width, 480px tall desktop / 240px mobile)                 │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │                    [cover_image_url]                                │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  RESTAURANT METADATA                                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Matsuri Ramen                                                      │   │
│  │  Japanese  ·  $$  ·  ★4.8  (124 reviews)                           │   │
│  │                                                                     │   │
│  │  Crafting tonkotsu broth for 18 hours, in the tradition of         │   │
│  │  Hakata ramen houses. Everything made in-house.                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  MENU                                                                       │
│  ▼ Starters                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [item img]  Gyoza (6pc)                                  $9.00      │   │
│  │              Pan-fried pork dumplings, citrus ponzu                  │   │
│  │                                                  < Add to cart >    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ▼ Ramen                                                                    │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  [item img]  Tonkotsu Ramen                               $18.00     │   │
│  │              18-hour pork broth, chashu, soft egg, nori             │   │
│  │                                                  < Add to cart >    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ──────────────────────────────────────────────────────────────────────────│
│                                                                             │
│  REVIEWS                                                                    │
│  ★4.8  Based on 124 reviews                                                 │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  ★★★★★  Alex M.  ·  March 2026                                       │   │
│  │  "Best tonkotsu I've had outside of Japan. The broth is legit."     │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│  [ 3–5 reviews total — no pagination ]                                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Annotations:**
- Header cart icon shows badge count. Clicking it opens cart drawer.
- Menu sections are collapsible on mobile (tapping section header toggles open/closed).
- Each menu item: image left (80×80 square), name + description middle, price + "Add to cart" right.
- "Add to cart" triggers auth gate if user is not signed in (see Flow 3).
- Broken cover image → full-width grey placeholder with restaurant name text overlay.
- Reviews are seeded; no submission UI.

---

## Wireframe Summary

| Screen | Key layout decisions |
|--------|---------------------|
| S-01 Homepage | Hero search full-width, collections below in rows of 4, editorial naming |
| S-02 Search Results | Inline filter chips, list layout (not grid), full-row clickable |
| S-03 Restaurant Page | Full-width hero, metadata block, per-item menu rows, review snippets |
| S-04 Auth Modal | Tabbed modal (Sign In / Sign Up), bottom sheet on mobile |
| S-05 Cart Drawer | Right-side drawer, fee transparency, empty state |
| S-06 Cart Conflict | Minimal 2-button modal, safe action is default |
| S-07/08/09 Checkout | 3-step linear with progress indicator, simplified header |
| S-10 Order Confirmation | Centred confirmation, static ETA, two CTAs |
| S-11 Order History | Expandable list rows, restaurant name links |
