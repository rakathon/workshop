# Contract Test Suite — dishly API

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Authored:* 2026-06-05
*Effort:* `dishly-wave-1`
*Spec source:* `spec/api/dishly.yaml`

## Why Test This

The dishly REST API is the single integration boundary between the React frontend and the Node.js backend. Every field the frontend renders — restaurant name, menu item price, order status, JWT token — flows across this contract. If the backend drifts from the OpenAPI spec, the frontend breaks silently at runtime. These contract tests load `dishly.yaml` at test execution time and assert that every documented endpoint returns the exact shape and status code defined there.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: POST /auth/register — 201 Created | registerUser happy path shape |
| SC-2: POST /auth/register — 409 Conflict | duplicate email response shape |
| SC-3: POST /auth/register — 422 Validation | invalid input response shape |
| SC-4: POST /auth/login — 200 OK | loginUser happy path shape |
| SC-5: POST /auth/login — 401 Unauthorized | invalid credentials response shape |
| SC-6: GET /users/me — 200 OK | getCurrentUser shape |
| SC-7: GET /users/me — 401 Unauthorized | missing/invalid JWT shape |
| SC-8: GET /cuisines — 200 OK | listCuisines shape |
| SC-9: GET /neighbourhoods — 200 OK | listNeighbourhoods shape |
| SC-10: GET /collections — 200 OK | listCollections shape |
| SC-11: GET /collections/:id — 200 OK | getCollection shape |
| SC-12: GET /collections/:id — 404 Not Found | missing collection shape |
| SC-13: GET /restaurants — 200 OK (no filters) | listRestaurants shape |
| SC-14: GET /restaurants?q=ramen — 200 OK | search response shape |
| SC-15: GET /restaurants/:id — 200 OK | getRestaurant detail shape |
| SC-16: GET /restaurants/:id — 404 Not Found | missing restaurant shape |
| SC-17: POST /orders — 201 Created | createOrder happy path shape |
| SC-18: POST /orders — 401 Unauthorized | unauthenticated order attempt shape |
| SC-19: POST /orders — 422 Unprocessable | cross-restaurant / invalid items shape |
| SC-20: GET /orders/:id — 200 OK | getOrder shape |
| SC-21: GET /orders/:id — 401 Unauthorized | unauthenticated order fetch shape |
| SC-22: GET /orders/:id — 403 Forbidden | wrong user order fetch shape |
| SC-23: GET /orders/:id — 404 Not Found | missing order shape |
| SC-24: GET /users/me/orders — 200 OK | listUserOrders shape + pagination |
| SC-25: GET /users/me/orders — 401 Unauthorized | unauthenticated history fetch shape |

## Scenarios

### SC-1: POST /auth/register — 201 Created

**Type:** contract
**Given** a request body with a unique valid email and a password of 8+ characters
**When** `POST /dishly/v1/auth/register` is called
**Then** the response status is `201`
**And** the body matches `registerUser` 201 schema from `dishly.yaml`:
  - `data.user.id` is a UUID string
  - `data.user.email` matches the submitted email
  - `data.user.created_at` is an ISO 8601 datetime
  - `data.token` is a non-empty string
  - `meta.status.code` is present
  - `meta.operation.request_id` is a UUID
**And** the `Location` header is present and matches `/dishly/v1/users/me`

---

### SC-2: POST /auth/register — 409 Conflict

**Type:** contract
**Given** an email address already registered in the database
**When** `POST /dishly/v1/auth/register` is called with that email
**Then** the response status is `409`
**And** the body has `errors` as a non-empty array with `code` and `message`

---

### SC-3: POST /auth/register — 422 Validation

**Type:** contract
**Given** a request body with an invalid email format or password shorter than 8 characters
**When** `POST /dishly/v1/auth/register` is called
**Then** the response status is `422`
**And** `errors[0].details.field` identifies the failing field

---

### SC-4: POST /auth/login — 200 OK

**Type:** contract
**Given** a registered user's valid email and password
**When** `POST /dishly/v1/auth/login` is called
**Then** the response status is `200`
**And** `data.user.id` is a UUID, `data.token` is a non-empty string

---

### SC-5: POST /auth/login — 401 Unauthorized

**Type:** contract
**Given** a valid email but incorrect password
**When** `POST /dishly/v1/auth/login` is called
**Then** the response status is `401`
**And** `errors[0].code` is a non-empty string

---

### SC-6: GET /users/me — 200 OK

**Type:** contract
**Given** a valid JWT in the `Authorization: Bearer <token>` header
**When** `GET /dishly/v1/users/me` is called
**Then** the response status is `200`
**And** `data.id` is a UUID, `data.email` is a non-empty email string

---

### SC-7: GET /users/me — 401 Unauthorized

**Type:** contract
**Given** no Authorization header (or an expired/malformed token)
**When** `GET /dishly/v1/users/me` is called
**Then** the response status is `401`

---

### SC-8: GET /cuisines — 200 OK

**Type:** contract
**Given** the seed database is loaded
**When** `GET /dishly/v1/cuisines` is called
**Then** the response status is `200`
**And** `data` is an array of objects each with `id` (UUID) and `name` (string)
**And** at least 8 distinct cuisine names are present

---

### SC-9: GET /neighbourhoods — 200 OK

**Type:** contract
**Given** the seed database is loaded
**When** `GET /dishly/v1/neighbourhoods` is called
**Then** the response status is `200`
**And** `data` is an array of objects each with `id` (UUID) and `name` (string)
**And** at least 5 distinct neighbourhood names are present

---

### SC-10: GET /collections — 200 OK

**Type:** contract
**Given** `data/collections.json` is loaded at startup
**When** `GET /dishly/v1/collections` is called
**Then** the response status is `200`
**And** `data` is an array of Collection objects each with `id`, `title`, `description`, and `restaurants`

---

### SC-11: GET /collections/:id — 200 OK

**Type:** contract
**Given** a valid collection ID from `data/collections.json`
**When** `GET /dishly/v1/collections/:id` is called
**Then** the response status is `200`
**And** `data` matches the `Collection` schema with the correct `id` and `title`

---

### SC-12: GET /collections/:id — 404 Not Found

**Type:** contract
**Given** a collection ID that does not exist
**When** `GET /dishly/v1/collections/:id` is called
**Then** the response status is `404`

---

### SC-13: GET /restaurants — 200 OK (no filters)

**Type:** contract
**Given** the seed database is loaded
**When** `GET /dishly/v1/restaurants` is called with no query parameters
**Then** the response status is `200`
**And** `data` is an array of `RestaurantSummary` objects with all required fields
**And** `pagination` is present in the response body

---

### SC-14: GET /restaurants?q=ramen — 200 OK (keyword search)

**Type:** contract
**Given** the seed database contains restaurants with "ramen" in their name or menu items
**When** `GET /dishly/v1/restaurants?q=ramen` is called
**Then** the response status is `200`
**And** all items in `data` conform to the `RestaurantSummary` schema
**And** the search is case-insensitive

---

### SC-15: GET /restaurants/:id — 200 OK

**Type:** contract
**Given** a valid restaurant UUID from the seed database
**When** `GET /dishly/v1/restaurants/:id` is called
**Then** the response status is `200`
**And** `data` matches the `RestaurantDetail` schema with all required fields including `menu` and `reviews`

---

### SC-16: GET /restaurants/:id — 404 Not Found

**Type:** contract
**Given** a UUID that does not correspond to any restaurant
**When** `GET /dishly/v1/restaurants/:id` is called
**Then** the response status is `404`
**And** `errors[0].code` equals `NOT_FOUND`

---

### SC-17: POST /orders — 201 Created

**Type:** contract
**Given** an authenticated user (valid JWT) and a valid order body
**When** `POST /dishly/v1/orders` is called
**Then** the response status is `201`
**And** the `Location` header is present
**And** `data` matches the `Order` schema with all required fields

---

### SC-18: POST /orders — 401 Unauthorized

**Type:** contract
**Given** a valid order request body but no `Authorization` header
**When** `POST /dishly/v1/orders` is called
**Then** the response status is `401`

---

### SC-19: POST /orders — 422 Unprocessable Entity

**Type:** contract
**Given** an authenticated user and an order request body with items from two different restaurants
**When** `POST /dishly/v1/orders` is called
**Then** the response status is `422`
**And** no order record is created

---

### SC-20: GET /orders/:id — 200 OK

**Type:** contract
**Given** an authenticated user and an order ID belonging to that user
**When** `GET /dishly/v1/orders/:id` is called
**Then** the response status is `200`
**And** `data` matches the `Order` schema with all required fields

---

### SC-21: GET /orders/:id — 401 Unauthorized

**Type:** contract
**Given** a valid order ID but no `Authorization` header
**When** `GET /dishly/v1/orders/:id` is called
**Then** the response status is `401`

---

### SC-22: GET /orders/:id — 403 Forbidden

**Type:** contract
**Given** user A's order ID and user B's valid JWT
**When** `GET /dishly/v1/orders/:id` is called with user B's token
**Then** the response status is `403`

---

### SC-23: GET /orders/:id — 404 Not Found

**Type:** contract
**Given** a UUID that does not correspond to any order
**When** `GET /dishly/v1/orders/:id` is called with a valid JWT
**Then** the response status is `404`

---

### SC-24: GET /users/me/orders — 200 OK with pagination

**Type:** contract
**Given** an authenticated user with at least 2 placed orders
**When** `GET /dishly/v1/users/me/orders` is called
**Then** the response status is `200`
**And** `data` is an array of `Order` objects (newest first)
**And** `pagination` is present in the response body

---

### SC-25: GET /users/me/orders — 401 Unauthorized

**Type:** contract
**Given** no Authorization header
**When** `GET /dishly/v1/users/me/orders` is called
**Then** the response status is `401`
