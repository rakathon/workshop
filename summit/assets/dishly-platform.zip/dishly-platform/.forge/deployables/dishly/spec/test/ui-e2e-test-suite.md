# UI E2E Test Suite — Customer Profile Section

<!-- graduated-from: add-location-based-filtering at 2026-06-08T03:44:50Z -->

*Capability/Effort:* `.forge/efforts/customer-profile-section/spec/test/`
*Authored:* 2026-06-06
*Effort:* customer-profile-section

## Why Test This

The Account page is the only surface where customers manage their identity and preferences. It introduces multiple inline edit flows, conditional rendering (empty states, cap states, delete confirmations), and reactive NavBar updates — all driven by client-side state. A regression in any of these UI states breaks customer trust and prevents profile setup. These scenarios verify what the user sees and can interact with at the browser level, complementing the system E2E scenarios that verify API outcomes.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: Account page shows profile header with name and initials | UX Screen: Account Page — Default state |
| SC-2: Account page shows email-prefix fallback when no name set | UX Screen: Account Page — Fallback state |
| SC-3: Personal info section opens inline edit on "Edit" click | UX Interaction: inline edit open |
| SC-4: Invalid phone shows field-level error; form stays open | UX State: Save error — personal info |
| SC-5: Saving valid personal info updates NavBar name without reload | UX Interaction: save success + NavBar reactivity |
| SC-6: Cancel edit restores read view without saving | UX Interaction: cancel edit |
| SC-7: Addresses section shows empty state when no addresses exist | UX Screen: Account Page — Empty addresses |
| SC-8: Add address form appears inline; saving shows new address card | UX Interaction: add address |
| SC-9: Address card shows Default badge; "Set default" button absent | UX State: default address display |
| SC-10: Delete confirmation appears inline; confirming removes card | UX Interaction: delete address |
| SC-11: Add address button hidden when 2 addresses saved; cap note shown | UX State: cap reached — addresses |
| SC-12: Payment section shows empty state when no methods exist | UX Screen: Account Page — Empty payments |
| SC-13: Add payment form shows card type selector and name field | UX Interaction: add payment method |
| SC-14: Checkout delivery field pre-filled from saved default address | UX Screen: Checkout — address pre-fill |
| SC-15: Checkout shows payment radio options for saved methods | UX Screen: Checkout — payment selection |
| SC-16: Register form includes optional Name field | UX Screen: Register — Name field |
| SC-17: NavBar avatar shows initials after sign-in | UX Screen: NavBar — authenticated state |
| SC-18: NavBar dropdown shows name and email | UX Screen: NavBar — dropdown |
| SC-19: "Enter a card" radio reveals card fields at checkout | [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout): card fields visible on selection |
| SC-20: Card number auto-formats as groups of four | [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout): auto-format UX interaction |
| SC-21: Invalid card number shows inline error on submit | [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout): validation before submission |
| SC-22: "Add to cart" button replaced by stepper on first add | [BR-7](../../requirements/business.md#br-7-quantity-stepper-on-restaurant-menu-page): stepper renders; +/− work; 0 restores button |

## Scenarios

### SC-1: Account page shows profile header with name and initials

**Type:** e2e
**Given** a signed-in customer with name "Alex Brennan"
**When** the customer navigates to /account
**Then** the profile header displays the avatar with initials "AB"
**And** the heading shows "Alex Brennan"
**And** the email address is shown below the name
**Verifies:** [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "NavBar avatar displays initials from persisted name"

---

### SC-2: Account page shows email-prefix fallback when no name set

**Type:** e2e
**Given** a signed-in customer with no stored name and email "alex@example.com"
**When** the customer navigates to /account
**Then** the profile header shows a generic fallback label (e.g. "dishly member")
**And** the avatar shows initials derived from the email prefix
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "If omitted, display falls back to the email prefix"

---

### SC-3: Personal info section opens inline edit form on "Edit" click

**Type:** e2e
**Given** a signed-in customer on /account in the default read view
**When** the customer clicks the "Edit" button in the Personal info section
**Then** an inline form appears with Name and Phone fields pre-filled with current values
**And** "Save changes" and "Cancel" buttons are visible
**And** the Email row remains visible below the form in read-only state
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "Account page shows current name and phone with an inline edit affordance"

---

### SC-4: Invalid phone shows field-level error; form stays open

**Type:** e2e
**Given** a signed-in customer with the personal info edit form open
**When** the customer enters "123abc" in the Phone field and clicks "Save changes"
**Then** an inline error message appears below the Phone field describing the format requirement
**And** the form remains open with the invalid input preserved
**And** no changes are saved
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "Invalid phone format shows an inline validation error before submission"

---

### SC-5: Saving valid personal info updates NavBar name without page reload

**Type:** e2e
**Given** a signed-in customer with the personal info edit form open
**When** the customer changes Name to "Jordan Smith" and clicks "Save changes"
**Then** the form closes and the read view shows "Jordan Smith"
**And** the NavBar avatar updates to initials "JS" without a page reload
**And** the NavBar dropdown header shows "Jordan Smith"
**And** a success toast notification appears
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "Updated name reflects immediately in NavBar without page reload"

---

### SC-6: Cancel edit restores read view without saving

**Type:** e2e
**Given** a signed-in customer with the personal info edit form open with unsaved changes
**When** the customer clicks "Cancel"
**Then** the form closes and the read view shows the original values
**And** no API call is made
**Verifies:** UX interaction notes — "Cancel collapses form; original values restored"

---

### SC-7: Addresses section shows empty state when no addresses saved

**Type:** e2e
**Given** a signed-in customer with no saved addresses
**When** the customer views /account
**Then** the Delivery addresses section shows an empty state message
**And** an "Add address" button is visible
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Account page lists saved addresses (empty state CTA)"

---

### SC-8: Add address form appears inline; saving shows new address card

**Type:** e2e
**Given** a signed-in customer with no saved addresses on /account
**When** the customer clicks "Add address"
**Then** an inline form appears with Label (optional), Street, City, Postcode fields and a default checkbox
**When** the customer fills Street, City, Postcode and clicks "Save address"
**Then** the form closes and the new address card appears
**And** a success toast notification appears
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Account page lists saved addresses with edit and delete affordances per entry"

---

### SC-9: Address card shows Default badge; "Set default" button absent on default card

**Type:** e2e
**Given** a signed-in customer with one address marked as default
**When** the customer views the Delivery addresses section
**Then** the address card displays a "Default" badge
**And** the "Set default" action is not present on that card
**And** the "Edit" and "Delete" actions are present
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "One address can be set as default"

---

### SC-10: Delete confirmation appears inline; confirming removes the card

**Type:** e2e
**Given** a signed-in customer with at least one saved address
**When** the customer clicks "Delete" on an address card
**Then** an inline confirmation prompt appears below the card with "Delete" and "Keep it" buttons
**When** the customer clicks the "Delete" confirmation button
**Then** the address card disappears from the list
**And** a success toast notification appears
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "DELETE /users/me/addresses/:id removes an address"; UX — inline delete confirmation

---

### SC-11: Add address button hidden when 2 addresses saved; cap note shown

**Type:** e2e
**Given** a signed-in customer with 2 saved addresses
**When** the customer views the Delivery addresses section
**Then** the "Add address" button is not visible
**And** a note indicating the 2-address limit is displayed
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Adding a third address is blocked"; UX — cap note replaces add button

---

### SC-12: Payment section shows empty state when no payment methods saved

**Type:** e2e
**Given** a signed-in customer with no saved payment methods
**When** the customer views /account
**Then** the Payment methods section shows an empty state message
**And** an "Add payment method" button is visible
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Account page lists saved payment methods (empty state)"

---

### SC-13: Add payment form shows card type selector and name field; saving shows card

**Type:** e2e
**Given** a signed-in customer with no saved payment methods
**When** the customer clicks "Add payment method"
**Then** an inline form appears with a card type selector (Visa, Mastercard, Amex) and Cardholder name field
**When** the customer selects "Visa", enters "Alex Brennan", and clicks "Save card"
**Then** the form closes and a Visa payment card appears with "Alex Brennan"
**And** a success toast notification appears
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Payment method fields: card_type and cardholder_name"

---

### SC-14: Checkout delivery field pre-filled from saved default address

**Type:** e2e
**Given** a signed-in customer with a default address "42 Maple St, Springfield, 12345"
**And** a non-empty cart
**When** the customer navigates to /checkout
**Then** the delivery address field is pre-populated with "42 Maple St, Springfield, 12345"
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Default pre-fills the delivery address field at checkout"

---

### SC-15: Checkout shows payment radio options for saved methods plus fallback

**Type:** e2e
**Given** a signed-in customer with one saved payment method (Visa, Alex Brennan)
**And** a non-empty cart
**When** the customer navigates to /checkout
**Then** a "Visa — Alex Brennan" radio option is visible and selected by default
**And** "Pay on delivery" radio option is also visible
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Checkout displays saved payment methods alongside Pay on delivery fallback"

---

### SC-16: Register form includes optional Name field

**Type:** e2e
**Given** a visitor on the /register page
**When** the page loads
**Then** an optional "Name" field is visible above the Email field
**And** the field has a placeholder indicating it is optional
**When** the visitor submits the form without filling in Name
**Then** registration succeeds without error
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "Register form includes an optional Name field"

---

### SC-17: NavBar avatar shows initials after sign-in

**Type:** e2e
**Tags:** smoke-test, non-production
**Given** a registered customer with name "Sam Rivera"
**When** the customer signs in via /login
**Then** the NavBar avatar immediately shows initials "SR"
**And** no page reload is required
**Verifies:** [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "NavBar avatar displays initials from persisted name immediately after sign-in"

---

### SC-18: NavBar dropdown shows full name and email

**Type:** e2e
**Given** a signed-in customer with name "Sam Rivera" and email "sam@example.com"
**When** the customer clicks the NavBar avatar button
**Then** the dropdown opens showing "Sam Rivera" in bold
**And** "sam@example.com" appears below the name
**And** "My account", "Order history", and "Sign out" items are visible
**Verifies:** [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "Dropdown header shows full name and email"

---

---

*Extended: 2026-06-06 — scenarios added from effort customer-profile-section (BR-6, BR-7)*

### SC-19: "Enter a card" radio reveals card fields at checkout

**Type:** e2e
**Given** a signed-in customer on /checkout
**When** the customer clicks the "Enter a card" radio option
**Then** card number, expiry (MM/YY), and CVV fields are visible
**And** the card fields were not visible before clicking the radio
**Verifies:** [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout) — "Selecting 'Enter a card' reveals card number, expiry, CVV fields"

---

### SC-20: Card number auto-formats as groups of four

**Type:** e2e
**Given** a signed-in customer on /checkout with "Enter a card" selected
**When** the customer types 16 digits into the card number field
**Then** the field displays the number formatted as XXXX XXXX XXXX XXXX
**Verifies:** [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout) — card number auto-formats (UX interaction)

---

### SC-21: Invalid card number shows inline error on submit

**Type:** e2e
**Given** a signed-in customer on /checkout with "Enter a card" selected
**When** the customer enters "1234" (fewer than 16 digits) and clicks "Place Order"
**Then** an inline error message appears below the card number field
**And** the form does not submit
**Verifies:** [BR-6](../../requirements/business.md#br-6-dummy-card-entry-at-checkout) — "Any 16-digit card number is accepted; lightly validated before submission"

---

### SC-22: "Add to cart" button replaced by stepper on first add

**Type:** e2e
**Given** a signed-in customer on a restaurant page
**When** the customer clicks "Add to cart" for a menu item
**Then** the button is replaced by a stepper control showing "−", the quantity "1", and "+"
**When** the customer clicks "+" on the stepper
**Then** the quantity label shows "2"
**When** the customer clicks "−" twice
**Then** the stepper is replaced by the "Add to cart" button
**Verifies:** [BR-7](../../requirements/business.md#br-7-quantity-stepper-on-restaurant-menu-page) — "Add to cart replaced by stepper; +/− adjust quantity; at 0 restores button"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*

---

*Extended: 2026-06-08 — location-based filtering UI E2E scenarios graduated from add-location-based-filtering*

### SC-LOC-1: City selector visible in NavBar alongside search input

**Type:** e2e
**Given** a customer on any page
**When** the page loads
**Then** a city selector button is visible in the NavBar, left of the search input
**And** the selector shows "All cities" when no city is selected
**And** the selector has a location pin icon
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface) — city selector visible on both home and search results page

---

### SC-LOC-2: City dropdown opens and shows all cities plus Near me option

**Type:** e2e
**Given** a customer with no city selected
**When** the customer clicks the city selector button
**Then** a dropdown opens below the selector
**And** "Near me" appears as the first item with a distinct style
**And** all available cities are listed below (at least 6 entries)
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface), [BR-LOC-3](../../requirements/business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)

---

### SC-LOC-3: Typing in city dropdown filters the list

**Type:** e2e
**Given** the city dropdown is open
**When** the customer types "Los" in the filter input
**Then** only "Los Angeles" appears in the dropdown list
**And** "Near me" is hidden while filtering
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface) — type-to-filter

---

### SC-LOC-4: Selecting a city closes dropdown and shows active style

**Type:** e2e
**Given** the city dropdown is open
**When** the customer clicks "Chicago"
**Then** the dropdown closes and the city selector button shows "Chicago" with a purple/primary highlighted style
**And** a × clear button appears on the selector
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-5: Active city shows clear button; clicking it resets selector

**Type:** e2e
**Given** "Miami" is the active city in the selector
**When** the customer clicks the × clear button
**Then** the city selector resets to "All cities" placeholder
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-6: Near me shows loading indicator while awaiting geolocation

**Type:** e2e
**Given** the city dropdown is open
**When** the customer clicks "Near me" (geolocation takes >200ms)
**Then** the city selector shows a loading indicator ("Detecting…" or spinner)
**Verifies:** [BR-LOC-3](../../requirements/business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)

---

### SC-LOC-7: Geolocation denied shows inline error below selector

**Type:** e2e
**Given** the browser will deny geolocation permission
**When** the customer clicks "Near me"
**Then** an inline error message appears near the city selector
**And** the city selector remains at "All cities"
**Verifies:** [BR-LOC-3](../../requirements/business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)

---

### SC-LOC-8: No cities found empty state in dropdown

**Type:** e2e
**Given** the city dropdown is open
**When** the customer types "zzz" (no matching cities)
**Then** the dropdown shows a "No cities found" message
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-9: City selector visible in Home page hero search bar

**Type:** e2e
**Given** a customer on the Home page
**When** the page loads
**Then** the hero search bar contains a city selector left of the keyword input
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-10: City selector row visible on Search page above cuisine and price filters

**Type:** e2e
**Given** a customer on the /search page
**When** the page loads
**Then** a "City" filter row is visible above the "Cuisine" and "Price" filter rows
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)

---

### SC-LOC-11: Empty state shown when selected city has no restaurants

**Type:** e2e
**Given** a customer selects a city that has no seeded restaurants
**When** the restaurant list loads
**Then** an empty state message is displayed indicating no restaurants in that city
**And** a link or button to browse all cities is visible
**Verifies:** UX Spec — empty state for no-results city

---

### SC-LOC-12: City selector state syncs between NavBar and Search page

**Type:** e2e
**Given** a customer selects "Boston" using the NavBar city selector
**When** the customer navigates to the Search page
**Then** the Search page city selector also shows "Boston" as active
**Verifies:** [BR-LOC-2](../../requirements/business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)
