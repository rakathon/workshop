-- Physical Schema — SQLite
-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z
-- Base schema: dishly-wave-1 (Authored: 2026-06-05)
-- Extended: customer-profile-section (Authored: 2026-06-06)
--
-- Conventions:
--   - All IDs are TEXT UUIDs (generated in application layer)
--   - Timestamps are TEXT in ISO-8601 format (YYYY-MM-DDTHH:MM:SSZ)
--   - Soft deletes on USER and ORDER (deleted_at TEXT, NULL = active); seed data tables are immutable
--   - PII fields annotated inline
--   - Foreign keys enabled at connection time: PRAGMA foreign_keys = ON;

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- CUISINE
-- Normalised cuisine types shared across restaurants.
-- Seed data: loaded once at startup from data/seed/cuisines.json
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cuisine (
  id   TEXT PRIMARY KEY,           -- UUID
  name TEXT NOT NULL UNIQUE        -- e.g. "Japanese", "Italian", "Mexican"
);

-- Supports: pattern 19 (list all cuisines)
CREATE INDEX IF NOT EXISTS idx_cuisine_name ON cuisine(name ASC);


-- ---------------------------------------------------------------------------
-- NEIGHBOURHOOD
-- Named NYC neighbourhoods shared across restaurants.
-- Seed data: loaded once at startup from data/seed/neighbourhoods.json
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS neighbourhood (
  id   TEXT PRIMARY KEY,           -- UUID
  name TEXT NOT NULL UNIQUE        -- e.g. "Brooklyn", "Astoria", "Manhattan"
);

-- Supports: pattern 20 (list all neighbourhoods)
CREATE INDEX IF NOT EXISTS idx_neighbourhood_name ON neighbourhood(name ASC);


-- ---------------------------------------------------------------------------
-- RESTAURANT
-- Core restaurant entity. All rows are seeded; no live onboarding in Wave 1.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS restaurant (
  id                  TEXT    PRIMARY KEY,   -- UUID
  name                TEXT    NOT NULL,
  cuisine_id          TEXT    NOT NULL REFERENCES cuisine(id),
  neighbourhood_id    TEXT    NOT NULL REFERENCES neighbourhood(id),
  description         TEXT    NOT NULL,
  address             TEXT    NOT NULL,      -- Public business address; not PII
  price_range         TEXT    NOT NULL CHECK(price_range IN ('$', '$$', '$$$')),
  cover_image_url     TEXT    NOT NULL,      -- public URL; no local file storage (TR-3)
  average_rating      REAL    NOT NULL CHECK(average_rating BETWEEN 1.0 AND 5.0),
  delivery_radius_km  REAL    NOT NULL DEFAULT 5.0
);

-- Supports: pattern 3 (search by name), 6 (filter by cuisine), 7 (filter by price),
--           4 (filter by neighbourhood), 8 (get by ID via PK)
CREATE INDEX IF NOT EXISTS idx_restaurant_name        ON restaurant(name);
CREATE INDEX IF NOT EXISTS idx_restaurant_cuisine     ON restaurant(cuisine_id);
CREATE INDEX IF NOT EXISTS idx_restaurant_neighbourhood ON restaurant(neighbourhood_id);
CREATE INDEX IF NOT EXISTS idx_restaurant_price_range ON restaurant(price_range);


-- ---------------------------------------------------------------------------
-- CURATED_COLLECTION
-- Editorial collections shown on the homepage (e.g. "Best Ramen in the City").
-- Loaded from data/collections.json at startup (TR-5).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS curated_collection (
  id          TEXT    PRIMARY KEY,   -- UUID; matches slug in collections.json
  title       TEXT    NOT NULL,
  description TEXT    NOT NULL,
  sort_order  INTEGER NOT NULL DEFAULT 0
);

-- Supports: pattern 1 (list all collections ordered)
CREATE INDEX IF NOT EXISTS idx_collection_sort ON curated_collection(sort_order ASC);


-- ---------------------------------------------------------------------------
-- COLLECTION_RESTAURANT  (junction)
-- Many-to-many: a restaurant can appear in multiple collections.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS collection_restaurant (
  collection_id TEXT    NOT NULL REFERENCES curated_collection(id) ON DELETE CASCADE,
  restaurant_id TEXT    NOT NULL REFERENCES restaurant(id) ON DELETE CASCADE,
  sort_order    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (collection_id, restaurant_id)
);

-- Supports: pattern 2 (list restaurants in a collection)
CREATE INDEX IF NOT EXISTS idx_cr_collection ON collection_restaurant(collection_id, sort_order ASC);


-- ---------------------------------------------------------------------------
-- MENU_SECTION
-- Named grouping of items on a restaurant menu (e.g. Starters, Mains).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_section (
  id            TEXT    PRIMARY KEY,   -- UUID
  restaurant_id TEXT    NOT NULL REFERENCES restaurant(id) ON DELETE CASCADE,
  name          TEXT    NOT NULL,
  sort_order    INTEGER NOT NULL DEFAULT 0
);

-- Supports: pattern 9 (list sections for a restaurant)
CREATE INDEX IF NOT EXISTS idx_section_restaurant ON menu_section(restaurant_id, sort_order ASC);


-- ---------------------------------------------------------------------------
-- MENU_ITEM
-- Individual dish within a menu section.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_item (
  id          TEXT    PRIMARY KEY,   -- UUID
  section_id  TEXT    NOT NULL REFERENCES menu_section(id) ON DELETE CASCADE,
  name        TEXT    NOT NULL,
  description TEXT    NOT NULL,
  price       REAL    NOT NULL CHECK(price >= 0),
  image_url   TEXT    NOT NULL,      -- public URL (TR-3)
  sort_order  INTEGER NOT NULL DEFAULT 0
);

-- Supports: pattern 10 (list items for a section), 18 (get by ID), 5 (search by item name)
CREATE INDEX IF NOT EXISTS idx_item_section ON menu_item(section_id, sort_order ASC);
CREATE INDEX IF NOT EXISTS idx_item_name    ON menu_item(name);


-- ---------------------------------------------------------------------------
-- REVIEW
-- Seeded reviews. Not user-submitted in Wave 1 (BR-13, BR-14).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS review (
  id            TEXT    PRIMARY KEY,   -- UUID
  restaurant_id TEXT    NOT NULL REFERENCES restaurant(id) ON DELETE CASCADE,
  author_name   TEXT    NOT NULL,      -- seeded fictitious name
  rating        INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
  body          TEXT    NOT NULL,
  review_date   TEXT    NOT NULL       -- ISO-8601 date string
);

-- Supports: pattern 11 (list reviews for a restaurant, newest first)
CREATE INDEX IF NOT EXISTS idx_review_restaurant ON review(restaurant_id, review_date DESC);


-- ---------------------------------------------------------------------------
-- USER
-- Registered consumer account. Required only to place an order (BR-9).
-- Extended with name, phone (customer-profile-section).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user (
  id            TEXT PRIMARY KEY,              -- UUID
  -- PII: email address. Do not log.
  -- Retention: retain while account active + 1 year post-closure.
  -- Deletion: anonymise (set to '<deleted>@dishly.invalid') on account closure request.
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,                 -- bcrypt hash; never store plaintext
  created_at    TEXT NOT NULL,                 -- ISO-8601
  deleted_at    TEXT                           -- soft delete; NULL = active
);

-- Supports: pattern 12 (find by email — login), 13 (get by ID — JWT middleware)
CREATE INDEX IF NOT EXISTS idx_user_email ON user(email);


-- ---------------------------------------------------------------------------
-- ORDER
-- A completed order placed by a user at a single restaurant (BR-11).
-- status transitions: 'confirmed' → 'delivering' → 'delivered' (all simulated, BR-6)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "order" (
  id               TEXT  PRIMARY KEY,   -- UUID
  user_id          TEXT  NOT NULL REFERENCES user(id),
  restaurant_id    TEXT  NOT NULL REFERENCES restaurant(id),
  -- PII: delivery address.
  -- Retention: retain for 2 years with order record (legal/financial obligation).
  -- Deletion: nullify (set to NULL, make nullable) on account closure request after retention period.
  delivery_address TEXT,                -- nullable to support post-retention anonymisation
  subtotal         REAL  NOT NULL CHECK(subtotal >= 0),    -- sum of items before delivery fee
  delivery_fee     REAL  NOT NULL DEFAULT 3.99,            -- flat fee (Wave 1: always $3.99)
  total            REAL  NOT NULL CHECK(total >= 0),       -- subtotal + delivery_fee
  status           TEXT  NOT NULL DEFAULT 'confirmed'
                         CHECK(status IN ('confirmed', 'delivering', 'delivered')),
  created_at       TEXT  NOT NULL,      -- ISO-8601
  deleted_at       TEXT                 -- soft delete; NULL = active
);

-- Supports: pattern 15 (get by ID), 16 (list orders by user newest first)
CREATE INDEX IF NOT EXISTS idx_order_user ON "order"(user_id, created_at DESC);


-- ---------------------------------------------------------------------------
-- ORDER_ITEM
-- Line items within an order. Captures name and price at time of order —
-- denormalised intentionally so order history is stable if seed data changes.
-- Deletion: CASCADE from parent order (ON DELETE CASCADE). No independent soft delete.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_item (
  id           TEXT    PRIMARY KEY,   -- UUID
  order_id     TEXT    NOT NULL REFERENCES "order"(id) ON DELETE CASCADE,
  menu_item_id TEXT    NOT NULL REFERENCES menu_item(id),
  item_name    TEXT    NOT NULL,      -- denormalised snapshot at order time
  quantity     INTEGER NOT NULL CHECK(quantity > 0),
  unit_price   REAL    NOT NULL CHECK(unit_price >= 0)
);

-- Supports: pattern 17 (list items for an order)
CREATE INDEX IF NOT EXISTS idx_order_item_order ON order_item(order_id);


-- ============================================================
-- CUSTOMER PROFILE EXTENSIONS (customer-profile-section)
-- Extend USER table with name and phone
-- ============================================================

-- PII: name and phone are personal data. Retain while account is active.
-- Delete or anonymise on account closure.
ALTER TABLE user ADD COLUMN name TEXT;
ALTER TABLE user ADD COLUMN phone TEXT;

-- ============================================================
-- USER_ADDRESS
-- Supports: list by user, fetch by id+user, count for cap, get default,
--           set/clear default, delete by id+user
-- ============================================================

-- PII: street, city, postcode are delivery address data.
CREATE TABLE IF NOT EXISTS user_address (
  id         TEXT PRIMARY KEY,
  user_id    TEXT    NOT NULL REFERENCES user(id) ON DELETE CASCADE,
  label      TEXT,                          -- optional, e.g. "Home"
  street     TEXT    NOT NULL,
  city       TEXT    NOT NULL,
  postcode   TEXT    NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,    -- 1 = default; at most one per user
  created_at TEXT    NOT NULL
);

-- Supports: list, count, get-default, set/clear default (all filter on user_id)
CREATE INDEX IF NOT EXISTS idx_user_address_user_id ON user_address(user_id);

-- ============================================================
-- USER_PAYMENT_METHOD
-- Supports: list by user, fetch by id+user, count for cap, delete by id+user
-- ============================================================

-- PII: cardholder_name is personal data.
CREATE TABLE IF NOT EXISTS user_payment_method (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL REFERENCES user(id) ON DELETE CASCADE,
  card_type       TEXT NOT NULL CHECK(card_type IN ('Visa', 'Mastercard', 'Amex')),
  cardholder_name TEXT NOT NULL,
  created_at      TEXT NOT NULL
);

-- Supports: list, count (all filter on user_id)
CREATE INDEX IF NOT EXISTS idx_user_payment_method_user_id ON user_payment_method(user_id);
