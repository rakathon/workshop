# dishly — User Flows

<!-- graduated-from: consumer-web-discovery at 2026-06-08T03:44:50Z -->

*Effort: consumer-web-discovery*
*Authored: 2026-06-05*
*Traces to: BR-CWD-1, BR-CWD-3, BR-CWD-4, BR-CWD-5, BR-CWD-8*

Legend: `[ Screen ]` `< Decision >` `( Action )` `→` flow direction `⊕` merge point

---

## Flow 1 — Homepage Discovery

```
START — Anonymous user opens dishly

[ Homepage ]
  ├─(clicks collection tile)────────────────────────────────→ [ Search Results — Collection filtered ]
  ├─(clicks restaurant card in collection)──────────────────→ [ Restaurant Page ]
  ├─(types in search bar + submits)─────────────────────────→ [ Search Results ]
  └─(no action)─────────────────────────────────────────────→ (stays on Homepage)
```

---

## Flow 2 — Search and Filter

```
[ Search Results ]
  ├─ results present
  │    ├─(applies cuisine filter)──────────────→ [ Search Results — filtered ] (client-side, no reload)
  │    ├─(applies price filter)────────────────→ [ Search Results — filtered ]
  │    ├─(clears filters)──────────────────────→ [ Search Results — unfiltered ]
  │    ├─(clicks restaurant card)──────────────→ [ Restaurant Page ]
  │    └─(modifies search query)───────────────→ [ Search Results — new query ]
  │
  └─ no results
       └─(shown friendly empty state)──────────→ < does user modify search? >
              ├─ Yes → (modifies query)──────────→ [ Search Results ]
              └─ No  → (navigates back)───────────→ [ Homepage ]
```

---

## Flow 3 — Restaurant Page

```
[ Restaurant Page ]
  │
  ├─(scrolls through menu)
  │    └─(taps "Add to cart" on item)
  │           └─ < Is user authenticated? >
  │                  ├─ Yes ──────────────────────────────→ [ Cart updated — item added ]
  │                  │                                           └─ < Cart is from same restaurant? >
  │                  │                                                  ├─ Yes → item added silently
  │                  │                                                  └─ No  → [ Cart Conflict Modal ]
  │                  │                                                               ├─(start new cart)→ old cart cleared → item added
  │                  │                                                               └─(cancel)────────→ returns to Restaurant Page, cart unchanged
  │                  │
  │                  └─ No ───────────────────────────────→ [ Auth Modal ]
  │                                                              ├─(Sign In)────→ [ Sign In Form ]
  │                                                              │                    ├─ success → ⊕ auto-adds item → Cart updated
  │                                                              │                    └─ failure → inline error → stays on Sign In Form
  │                                                              └─(Sign Up)────→ [ Sign Up Form ]
  │                                                                                   ├─ success → ⊕ auto-adds item → Cart updated
  │                                                                                   └─ failure → inline error → stays on Sign Up Form
  │
  └─(clicks cart icon in header — cart has items)──────────→ [ Cart Drawer / Cart Page ]
```

---

## Flow 4 — Cart to Checkout

```
[ Cart Drawer / Cart Page ]
  │
  ├─(modifies item quantity)───────────────→ cart totals recalculate inline
  ├─(removes item)─────────────────────────→ cart updates; if empty → Cart Empty state shown
  │
  └─(taps "Proceed to Checkout")───────────→ [ Checkout — Step 1: Delivery Address ]
         │
         └─(enters address + taps Next)────→ [ Checkout — Step 2: Payment ]
                │
                └─(enters card + taps Next)→ [ Checkout — Step 3: Order Summary ]
                       │
                       ├─(taps "Edit" on address or items)──→ returns to relevant step
                       │
                       └─(taps "Place Order")
                              └─ < Order submission result >
                                     ├─ success ──────────────→ [ Order Confirmation ]
                                     └─ error (server/network)→ [ Checkout — Step 3 ]
                                                                     inline error: "Something went wrong — your order was not placed. Please try again."
                                                                     Cart preserved. User can retry.
```

---

## Flow 5 — Order Confirmation

```
[ Order Confirmation ]
  │
  ├─(taps "View order history")────────────→ [ Order History ]
  ├─(taps restaurant name link)────────────→ [ Restaurant Page ] (returns to browse)
  └─(taps dishly logo / home)──────────────→ [ Homepage ]
```

---

## Flow 6 — Order History (Authenticated)

```
[ Homepage ] or any page
  └─(taps user menu → "Order history")─────→ [ Order History ]
         │
         ├─(no past orders)────────────────→ empty state: "No orders yet — start exploring"
         │                                        └─(taps "Explore restaurants")──→ [ Homepage ]
         │
         └─(past orders present)
                ├─(taps order row to expand)→ inline expanded: itemised detail, total
                └─(taps restaurant name)─────→ [ Restaurant Page ]
```

---

## Flow 7 — Authentication (standalone: sign in / sign up)

```
Entry points:
  - Auth Modal triggered by "Add to cart" (Flow 3)
  - "Sign in" in header nav (direct)
  - "Sign up" in header nav (direct)

[ Auth Modal or Sign In Page ]
  ├─(Sign In tab)
  │    ├─(submits valid credentials)──────→ session created → returns to origin page
  │    ├─(submits invalid credentials)───→ inline error "Incorrect email or password"
  │    └─(taps "Sign up instead")─────────→ switches to Sign Up tab
  │
  └─(Sign Up tab)
       ├─(submits valid email + password)→ account created → session created → returns to origin page
       ├─(duplicate email)──────────────→ inline error "An account with this email already exists"
       ├─(weak password)────────────────→ inline error on field
       └─(taps "Sign in instead")────────→ switches to Sign In tab

Note: "Forgot password" is out of scope. No link is shown.
```

---

## Error State Flows

```
Search — no results:
  [ Search Results ] → empty state: "No restaurants found for '{query}' — try a different search"

Restaurant page — no menu items:
  [ Restaurant Page ] → menu section shows: "Menu coming soon"

Order submission failure:
  [ Checkout Step 3 ] → inline error retained → cart preserved → user retries or navigates away

Hero image broken URL:
  [ Restaurant Page hero ] → placeholder image shown (no broken <img> icon)

Menu item broken image URL:
  [ Menu Item ] → placeholder food image shown
```

---

## Screen Inventory (from flows)

| Screen ID | Screen Name | Auth Required |
|-----------|-------------|---------------|
| S-01 | Homepage | No |
| S-02 | Search Results | No |
| S-03 | Restaurant Page | No |
| S-04 | Auth Modal (Sign In / Sign Up) | N/A — is the gate |
| S-05 | Cart Drawer / Cart Page | Yes (cart requires auth) |
| S-06 | Cart Conflict Modal | Yes |
| S-07 | Checkout — Step 1 (Address) | Yes |
| S-08 | Checkout — Step 2 (Payment) | Yes |
| S-09 | Checkout — Step 3 (Summary) | Yes |
| S-10 | Order Confirmation | Yes |
| S-11 | Order History | Yes |

Total: 11 screens (4 checkout steps collapsed to 3 for simplicity; cart may be drawer or page — wireframe decides).
