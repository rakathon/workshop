# Contract Test Suite — profile

<!-- graduated-from: customer-profile-section at 2026-06-08T03:24:27Z -->

*Capability/Effort:* `.forge/efforts/customer-profile-section/spec/test/`
*Authored:* 2026-06-06
*Effort:* customer-profile-section

## Why Test This

The Profile API contract (`profile.yaml`) defines the interface boundary between the dishly frontend and backend for all profile-related operations: auth, personal info, addresses, and payment methods. Contract tests ensure the backend's actual responses match the documented schemas — field names, types, status codes, and the response envelope shape. A contract regression here would silently break the frontend without any functional test catching it until a real user hits the broken endpoint.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: POST /auth/register — 201 with user and token | [BR-1](../../requirements/business.md#br-1-name-collected-at-registration): name in register response |
| SC-2: POST /auth/register — 409 email conflict | [BR-1](../../requirements/business.md#br-1-name-collected-at-registration): conflict response shape |
| SC-3: POST /auth/register — 422 validation error | [BR-1](../../requirements/business.md#br-1-name-collected-at-registration): validation error response |
| SC-4: POST /auth/login — 200 with user (including name) and token | [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in): name in login response |
| SC-5: POST /auth/login — 401 invalid credentials | [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in): auth error shape |
| SC-6: GET /users/me — 200 profile shape | [BR-2](../../requirements/business.md#br-2-personal-info-editing): profile response |
| SC-7: GET /users/me — 401 unauthenticated | [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication): auth required |
| SC-8: PATCH /users/me — 200 updated profile | [BR-2](../../requirements/business.md#br-2-personal-info-editing): update response shape |
| SC-9: PATCH /users/me — 422 invalid phone | [BR-2](../../requirements/business.md#br-2-personal-info-editing): phone validation error shape |
| SC-10: GET /users/me/addresses — 200 address list | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): address list shape |
| SC-11: POST /users/me/addresses — 201 new address | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): address create response |
| SC-12: POST /users/me/addresses — 422 cap exceeded | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): cap error shape |
| SC-13: PATCH /users/me/addresses/:id — 200 updated address | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): address update response |
| SC-14: PATCH /users/me/addresses/:id — 404 not found | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): not found response |
| SC-15: DELETE /users/me/addresses/:id — 204 deleted | [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses): delete response |
| SC-16: GET /users/me/payment_methods — 200 payment list | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): payment list shape |
| SC-17: POST /users/me/payment_methods — 201 new payment method | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): payment create response |
| SC-18: POST /users/me/payment_methods — 422 cap exceeded | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): cap error shape |
| SC-19: PATCH /users/me/payment_methods/:id — 200 updated method | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): payment update response |
| SC-20: DELETE /users/me/payment_methods/:id — 204 deleted | [BR-4](../../requirements/business.md#br-4-mock-payment-methods): payment delete response |

## Scenarios

### SC-1: POST /auth/register — 201 Created

**Type:** contract
**Given** a valid register request body with email, password, and name
**When** POST /dishly/v1/auth/register is called
**Then** the response status is 201
**And** the response body matches AuthResponse schema: `data.user` contains id, email, name, created_at; `data.token` is a non-empty string; `meta.status.code` is present; `meta.operation.request_id` is a UUID
**And** the Location header is present
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "POST /auth/register stores name and returns it in the response"

---

### SC-2: POST /auth/register — 409 Conflict

**Type:** contract
**Given** a register request with an email already registered
**When** POST /dishly/v1/auth/register is called
**Then** the response status is 409
**And** the response body matches ErrorEnvelope schema: `errors` array has at least one entry with `code` (string) and `message` (string); `meta` is present
**And** `data` is absent from the response body
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "Email already registered conflict response"

---

### SC-3: POST /auth/register — 422 Validation Error

**Type:** contract
**Given** a register request with an invalid email format
**When** POST /dishly/v1/auth/register is called
**Then** the response status is 422
**And** the response body matches ErrorEnvelope schema with a non-empty `errors` array
**Verifies:** [BR-1](../../requirements/business.md#br-1-name-collected-at-registration) — "Validation error on malformed registration input"

---

### SC-4: POST /auth/login — 200 OK with name in user object

**Type:** contract
**Given** a valid login request for an account with a stored name
**When** POST /dishly/v1/auth/login is called
**Then** the response status is 200
**And** the response body matches AuthResponse schema: `data.user.name` is a string (or null); `data.token` is a non-empty string; `meta.status.code` and `meta.operation.request_id` are present
**Verifies:** [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "POST /auth/login response includes name in the user object"

---

### SC-5: POST /auth/login — 401 Invalid Credentials

**Type:** contract
**Given** a login request with an incorrect password
**When** POST /dishly/v1/auth/login is called
**Then** the response status is 401
**And** the response body matches ErrorEnvelope schema
**Verifies:** [BR-5](../../requirements/business.md#br-5-authenticated-name-display-after-sign-in) — "401 response shape on failed authentication"

---

### SC-6: GET /users/me — 200 Profile Shape

**Type:** contract
**Given** a valid bearer token in the Authorization header
**When** GET /dishly/v1/users/me is called
**Then** the response status is 200
**And** the response body matches ProfileResponse schema: `data` contains id (uuid), email (string), name (string|null), phone (string|null), created_at (ISO 8601); `meta` is present
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "GET /users/me returns full profile including name and phone"

---

### SC-7: GET /users/me — 401 Unauthenticated

**Type:** contract
**Given** no Authorization header is provided
**When** GET /dishly/v1/users/me is called
**Then** the response status is 401
**And** the response body matches ErrorEnvelope schema
**Verifies:** [TR-3](../../requirements/technical.md#tr-3-all-profile-endpoints-require-authentication) — "All profile endpoints require authentication"

---

### SC-8: PATCH /users/me — 200 Updated Profile

**Type:** contract
**Given** a valid bearer token and body `{ "name": "Jordan Smith", "phone": "4155551234" }`
**When** PATCH /dishly/v1/users/me is called
**Then** the response status is 200
**And** the response body matches ProfileResponse schema with `data.name = "Jordan Smith"` and `data.phone = "4155551234"`
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "PATCH /users/me accepts name and/or phone and persists changes"

---

### SC-9: PATCH /users/me — 422 Invalid Phone Format

**Type:** contract
**Given** a valid bearer token and body `{ "phone": "not-digits" }`
**When** PATCH /dishly/v1/users/me is called
**Then** the response status is 422
**And** the response body matches ErrorEnvelope schema with a descriptive error message
**Verifies:** [BR-2](../../requirements/business.md#br-2-personal-info-editing) — "Invalid phone format returns validation error"; [TR-5](../../requirements/technical.md#tr-5-phone-validation-bounds) — "Phone validated as digits-only, 7–15 chars"

---

### SC-10: GET /users/me/addresses — 200 Address List Shape

**Type:** contract
**Given** a valid bearer token for a customer with saved addresses
**When** GET /dishly/v1/users/me/addresses is called
**Then** the response status is 200
**And** the response body matches AddressListResponse schema: `data` is an array of Address objects each with id, street, city, postcode, is_default, created_at; `pagination` is present; `meta` is present
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Account page lists saved addresses"

---

### SC-11: POST /users/me/addresses — 201 New Address

**Type:** contract
**Given** a valid bearer token and body `{ "street": "42 Maple St", "city": "Springfield", "postcode": "12345", "is_default": true }`
**When** POST /dishly/v1/users/me/addresses is called
**Then** the response status is 201
**And** the response body matches AddressResponse schema: `data` contains id, street, city, postcode, is_default (true), created_at
**And** the Location header is present
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "POST /users/me/addresses creates a new address"

---

### SC-12: POST /users/me/addresses — 422 Cap Exceeded

**Type:** contract
**Given** a valid bearer token for a customer who already has 2 saved addresses
**When** POST /dishly/v1/users/me/addresses is called
**Then** the response status is 422
**And** the response body matches ErrorEnvelope schema with a message indicating the 2-address limit
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Adding a third address blocked with clear error"; [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side) — "Cap enforced server-side"

---

### SC-13: PATCH /users/me/addresses/:id — 200 Updated Address

**Type:** contract
**Given** a valid bearer token and an existing address id
**When** PATCH /dishly/v1/users/me/addresses/{address_id} is called with `{ "city": "Shelbyville" }`
**Then** the response status is 200
**And** the response body matches AddressResponse schema with `data.city = "Shelbyville"`
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "PATCH /users/me/addresses/:id updates an existing address"

---

### SC-14: PATCH /users/me/addresses/:id — 404 Not Found

**Type:** contract
**Given** a valid bearer token and a non-existent address id
**When** PATCH /dishly/v1/users/me/addresses/{address_id} is called
**Then** the response status is 404
**And** the response body matches ErrorEnvelope schema
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "Not found response for unknown address id"

---

### SC-15: DELETE /users/me/addresses/:id — 204 Deleted

**Type:** contract
**Given** a valid bearer token and an existing address id
**When** DELETE /dishly/v1/users/me/addresses/{address_id} is called
**Then** the response status is 204
**And** the response body is empty
**Verifies:** [BR-3](../../requirements/business.md#br-3-saved-delivery-addresses) — "DELETE /users/me/addresses/:id removes an address"

---

### SC-16: GET /users/me/payment_methods — 200 Payment List Shape

**Type:** contract
**Given** a valid bearer token for a customer with saved payment methods
**When** GET /dishly/v1/users/me/payment_methods is called
**Then** the response status is 200
**And** the response body matches PaymentMethodListResponse schema: `data` is an array of PaymentMethod objects each with id, card_type (Visa|Mastercard|Amex), cardholder_name, created_at; `pagination` and `meta` present
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Account page lists saved payment methods"

---

### SC-17: POST /users/me/payment_methods — 201 New Payment Method

**Type:** contract
**Given** a valid bearer token and body `{ "card_type": "Visa", "cardholder_name": "Alex Brennan" }`
**When** POST /dishly/v1/users/me/payment_methods is called
**Then** the response status is 201
**And** the response body matches PaymentMethodResponse schema with `data.card_type = "Visa"` and `data.cardholder_name = "Alex Brennan"`
**And** the Location header is present
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "POST /users/me/payment-methods creates a new payment method"

---

### SC-18: POST /users/me/payment_methods — 422 Cap Exceeded

**Type:** contract
**Given** a valid bearer token for a customer who already has 2 saved payment methods
**When** POST /dishly/v1/users/me/payment_methods is called
**Then** the response status is 422
**And** the response body matches ErrorEnvelope schema with a message indicating the 2-method limit
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "Adding a third payment method blocked"; [TR-6](../../requirements/technical.md#tr-6-address-and-payment-method-cap-enforced-server-side) — "Cap enforced server-side"

---

### SC-19: PATCH /users/me/payment_methods/:id — 200 Updated Method

**Type:** contract
**Given** a valid bearer token and an existing payment method id
**When** PATCH /dishly/v1/users/me/payment_methods/{payment_method_id} with `{ "cardholder_name": "Alex B" }`
**Then** the response status is 200
**And** the response body matches PaymentMethodResponse schema with `data.cardholder_name = "Alex B"`
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "PATCH /users/me/payment-methods/:id updates an existing payment method"

---

### SC-20: DELETE /users/me/payment_methods/:id — 204 Deleted

**Type:** contract
**Given** a valid bearer token and an existing payment method id
**When** DELETE /dishly/v1/users/me/payment_methods/{payment_method_id} is called
**Then** the response status is 204
**And** the response body is empty
**Verifies:** [BR-4](../../requirements/business.md#br-4-mock-payment-methods) — "DELETE /users/me/payment-methods/:id removes a payment method"

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
