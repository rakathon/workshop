# PRD: Customer Profile Section

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Product / Effort: customer-profile-section*
*Last updated: 2026-06-07*

---

## Problem Statement

dishly's ordering flow requires authenticated users, but the discovery surface must remain fully open to anonymous visitors. Without an auth layer, any user who tries to add to cart or check out has no account to place the order under, and order history is impossible to scope to an individual. At the same time, placing the auth gate too early — at browse time rather than at checkout — would directly contradict the product's core value proposition of frictionless discovery.

This effort delivers the minimum auth layer needed for Wave 1: email/password registration and login that returns a JWT, a `requireAuth` Express middleware that protects order endpoints, and a frontend auth gate that fires at cart/checkout only. No external auth provider, no OAuth, no email infrastructure, no password reset. The goal is a simple, correct, locally-runnable auth system that can be extended in Wave 2 without a rebuild.

## Goals

1. Register and login work end-to-end — measured by `POST /auth/register` returns 201 with `{user, token}` and `POST /auth/login` returns 200 with `{user, token}` for valid credentials
2. Discovery routes remain open to anonymous users — measured by `GET /restaurants`, `GET /collections`, `GET /restaurants/:id` return 200 with no `Authorization` header
3. Order endpoints are protected — measured by `POST /orders`, `GET /orders/:id`, `GET /users/me/orders` all return 401 with no or invalid token
4. JWT is the only credential — measured by no session cookies, no third-party auth SDK, no OAuth callback routes exist anywhere in the codebase
5. Duplicate email registration returns a clear error — measured by re-registering a known email returns 409 with a human-readable error message

## Non-Goals

- We are not building password reset or "forgot password" — no email infrastructure, no SMTP, no reset tokens in Wave 1
- We are not integrating a third-party auth provider — no Auth0, Firebase Auth, Cognito, or OAuth in Wave 1
- We are not building email verification — accounts are usable immediately after registration with no confirmation step
- We are not building social login (Google, Apple) — email/password only
- We are not building session management beyond JWT expiry — no refresh tokens, no server-side session store
- We are not building an account settings UI — users cannot change their email or password in Wave 1

## Success Metrics

### Leading Indicators (early signal)

- Registration success rate: % of `POST /auth/register` calls that return 201 (target: 100% for valid payloads)
- Login success rate: % of `POST /auth/login` calls with correct credentials that return 200 (target: 100%)
- Auth gate conversion: % of unauthenticated users who encounter the checkout auth gate and complete sign-up or sign-in (target: ≥60%)

### Lagging Indicators (final outcome)

- Zero P0 auth bugs (auth failures allowing unauthorized access, token leakage, or session confusion) during the 4-week beta
- All order endpoints correctly return 401 for unauthenticated requests — confirmed by automated test suite (8/8 auth tests passing)

## Open Questions

None identified at this time. All auth decisions are resolved in TR-1 through TR-6 (JWT, bcrypt, localStorage, no external provider). Password reset is explicitly deferred and not a blocker.

## Timeline / Dependencies

- **Target:** Wave 1 closed beta launch
- **Dependencies:**
  - `project-scaffold-local-dev-infra` — SQLite DB and Express server must exist before auth routes and middleware can be implemented
- **Blocks:**
  - `native-ordering-checkout` — order endpoints require `requireAuth` middleware from this effort
  - `consumer-web-discovery` — frontend auth gate at cart/checkout depends on this effort's login/register endpoints

## Requirements

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See `user-stories.md` for Connextra-format stories grouped by persona.

---

# PRD: Consumer Web App — Discovery UX

*Product / Effort: consumer-web-discovery*
*Last updated: 2026-06-07*

---

## Problem Statement (Discovery UX)

Quality-conscious urban consumers who order food delivery 2–4× per week cannot discover restaurants worth ordering from on a single trusted surface. Incumbent platforms bury quality restaurants behind paid placements, forcing users to context-switch across Yelp, Instagram, and DoorDash just to decide where to eat. Three distinct personas experience this differently: Maya (the intentional orderer) wants editorial curation she can trust; Darius (the efficient professional) wants search-and-filter that respects his time; Priya (the explorer) wants a platform with genuine taste that doesn't look like every other food app.

dishly's consumer web app is the front door to all three journeys. This effort delivers the full discovery UX — homepage with curated collections, keyword search with cuisine/price filters, and restaurant pages with full menus — as a responsive web application that works on desktop and mobile browsers without a native app. The discovery surface must earn trust within 10 seconds through editorial naming, food photography quality, and the explicit absence of "sponsored" signals. This effort stops at the order entry point; the checkout and order flow are owned by the `native-ordering-checkout` epic.

---

## Goals (Discovery UX)

1. All three discovery surfaces functional at launch — measured by homepage (curated collections + search bar), search results (keyword + filters), and restaurant page (hero, menu, reviews) all render correctly against seeded data with no JS errors
2. Anonymous browsing with no auth gate — measured by 0 auth prompts on any discovery surface; account gate fires only at cart/checkout as confirmed by end-to-end test
3. Responsive and usable on desktop and mobile — measured by all screens functional on Chrome desktop (1440px), Chrome mobile (390px), and Safari mobile (390px) without layout breakage
4. Restaurant page earns a decision in under 4 minutes — measured by hero image, name, cuisine, price, rating, description, ≥1 menu section with item photos, and ≥3 review snippets all render above the fold or within one scroll on desktop
5. Search returns relevant results in under 2 seconds — measured by `GET /restaurants?q=` response + React render completes in <2s against the 100-restaurant seed dataset on localhost

---

## Non-Goals (Discovery UX)

- We are not building a native iOS or Android app — web-only; no app store submission
- We are not building personalisation or algorithmic ranking — curation is editorial only; no recommendation engine, no user behaviour signals
- We are not building a review submission UI — reviews are seeded data only; no user-generated content in Wave 1
- We are not building an admin or CMS for collections — collections are edited via `data/collections.json`; no web interface
- We are not building the checkout or order flow — that is owned by `native-ordering-checkout`; this effort ends at "Add to cart"
- We are not building performance SLAs or WCAG compliance — deferred to Wave 2; local dev performance is sufficient for closed beta

---

## Success Metrics (Discovery UX)

### Leading Indicators (early signal)

- Homepage engagement rate: % of sessions that click into at least one restaurant page (target: ≥60%)
- Search usage rate: % of sessions that use the search bar or cuisine filter chips (target: ≥30%)
- Restaurant page depth: % of restaurant page sessions that scroll past the menu section (target: ≥50%)
- Image load success rate: % of restaurant card and menu item images that render with naturalWidth > 0 (target: ≥95%)

### Lagging Indicators (final outcome)

- Add-to-cart rate at 4 weeks: ≥30% of restaurant page sessions result in at least one item added to cart
- Zero broken discovery surfaces: no homepage, search, or restaurant page renders a blank screen or unhandled error during the beta window
- Beta user trust signal: at 4 weeks, beta users report (qualitatively) that the discovery surface feels editorially curated, not like a generic delivery app

---

## Open Questions (Discovery UX)

None identified at this time. Persona definitions, UX strategy, wireframes, user flows, and the UI spec are all documented in `spec/design/` and `spec/ui-spec.md`. Engineering decisions are resolved in the parent initiative's TRs (TR-1 through TR-11).

---

## Timeline / Dependencies (Discovery UX)

- **Target:** Wave 1 closed beta launch
- **Dependencies:**
  - `project-scaffold-local-dev-infra` — React dev server, SQLite, start.sh must exist before any frontend can be built
  - `core-backend-apis` — `GET /collections`, `GET /restaurants`, `GET /restaurants/:id`, `GET /cuisines`, `GET /neighbourhoods` must be live before discovery surfaces can render real data

---

## Requirements (Discovery UX)

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories (Discovery UX)

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.

---

# PRD: Add Location-Based Filtering

*Product / Effort: add-location-based-filtering*
*Last updated: 2026-06-07*

---

## Problem Statement (Location-Based Filtering)

dishly customers currently have no way to filter restaurants by location. The app launched with 100 NYC-only restaurants, making it irrelevant to users outside New York and frustrating for NYC users who want neighbourhood-specific results. This gap was identified at Wave 1 launch — no city or geolocation filtering exists anywhere in the codebase, and multi-city expansion is a stated Wave 1 product goal.

Registered and anonymous customers alike are affected: they see restaurants from all locations mixed together, with no way to narrow results to where they can actually order from.

---

## Goals (Location-Based Filtering)

1. Customers in at least 6 cities (NYC + 5 new) can browse and filter restaurants relevant to their location — measured by 5 new cities seeded with ≥20 restaurants each and city filter returning correct results
2. Customers actively use the city selector — measured by ≥30% of search sessions including a city filter selection within 2 weeks of launch
3. Geolocation correctly identifies the user's city — measured by correct city matched for ≥90% of test locations within known bounding boxes
4. Existing NYC browsing and ordering flow is unaffected — measured by all existing E2E tests passing after changes

---

## Non-Goals (Location-Based Filtering)

- We are not adding a `city` table or changing the database schema — the `neighbourhood` table is reused as-is; no migration required.
- We are not building real-time geolocation tracking — location is only requested once on "Near me" click and not persisted beyond the session.
- We are not integrating a reverse geocoding API — city matching uses hardcoded bounding boxes only.
- We are not adding international cities — scope is US cities only for Wave 1.
- We are not building a restaurant onboarding flow for new cities — all data is seeded manually.

---

## Success Metrics (Location-Based Filtering)

### Leading Indicators (early signal)

- % of sessions on Search/Home page where a city is selected (within first week of release)
- % of "Near me" clicks that successfully auto-select a city vs. fallback to manual selection
- Search result page load after city filter applied — confirms filter is wired end-to-end

### Lagging Indicators (final outcome)

- % of non-NYC registered users who complete a full order at 30 days post-launch (baseline: 0%)
- Repeat visit rate for users who used the city filter vs. those who did not (30-day retention)
- Total restaurant coverage by city — at least 20 per new city sustained at 30 days

---

## Open Questions (Location-Based Filtering)

- Bounding boxes resolved: ±0.5° centroid per city [owner: eng] [due: resolved at planning]
- City persistence resolved: store in `localStorage`, cleared on sign-out [owner: product] [due: resolved]
- Selector placement resolved: Home hero search bar AND Search results page [owner: design] [due: resolved]

---

## Timeline / Dependencies (Location-Based Filtering)

- **Target:** Same day (next few hours)
- **Dependencies:** None — self-contained. `neighbourhood` table and `GET /restaurants?neighbourhood_id=` filter already exist. No external APIs required.

---

## Requirements (Location-Based Filtering)

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories (Location-Based Filtering)

See `user-stories.md` for Connextra-format stories grouped by persona.

---

# PRD: Project Scaffold + Local Dev Infrastructure

*Product / Effort: project-scaffold-local-dev-infra*
*Last updated: 2026-06-07*

---

## Problem Statement (Project Scaffold)

Every Wave 1 epic — restaurant APIs, auth, discovery frontend, ordering flow — depends on a runnable local development environment. Without a working scaffold, no engineer can start building: there is no Express server to add routes to, no SQLite database to query, no React dev server to render components in, and no way to run the full stack from a single command. The absence of this foundation blocks all downstream development.

This effort creates the minimal runnable monorepo for dishly Wave 1: a `./start.sh` that goes from a fresh Node.js installation to a running backend (port 3001) and React frontend (port 3000) with a seeded SQLite database — in a single command, with no Docker, no cloud infrastructure, and no manual setup steps. The scaffold defines the project's directory structure, technology stack, and startup contract that all subsequent epics build on top of.

---

## Goals (Project Scaffold)

1. Single-command startup works from a fresh clone — measured by `./start.sh` completes without error on a machine with only Node.js LTS installed and no prior dependencies
2. Both services reachable after startup — measured by backend responds at `http://localhost:3001/dishly/v1/` and frontend responds at `http://localhost:3000/` after `./start.sh`
3. Database seeded on first run, skipped on subsequent runs — measured by 100 restaurants present after first `./start.sh`; running it a second time does not duplicate or corrupt data
4. API routing convention established — measured by all API routes are under `/dishly/v1/`; any unmatched API route returns JSON 404 (not HTML); any non-API route serves `index.html` for client-side routing
5. Startup script is idempotent — measured by running `./start.sh` 3 times in a row produces the same result as running it once

---

## Non-Goals (Project Scaffold)

- We are not building CI/CD, Docker, or cloud deployment — the scaffold is local-only; no containerisation, no remote environment
- We are not building the actual API endpoints or frontend screens — stub routes and components only; real implementation belongs to downstream epics
- We are not building hot-reload or watch mode beyond what Vite and `node` provide by default
- We are not building a production build pipeline — `npm run build` for the frontend is outside the scope of Wave 1 local dev
- We are not building environment-specific configuration management — a single `.env.example` is sufficient; no multi-environment config system

---

## Success Metrics (Project Scaffold)

### Leading Indicators (early signal)

- `./start.sh` completes in under 3 minutes on a clean machine with only Node.js LTS (target: 100% of test runs)
- Both `localhost:3001` and `localhost:3000` respond with HTTP 200 after startup (target: 100%)
- Seed script logs "[seed] Already seeded — skipping." on the second run (target: 100%)

### Lagging Indicators (final outcome)

- Zero blocked engineers due to scaffold setup issues during the Wave 1 development period
- All downstream epics (`core-backend-apis`, `user-auth`, `consumer-web-discovery`, `native-ordering-checkout`) build successfully on top of the scaffold without modifying `start.sh` or the root directory structure

---

## Open Questions (Project Scaffold)

None identified at this time. Technology stack, directory structure, port assignments, and startup script behaviour are all specified in TR-8 through TR-14.

---

## Timeline / Dependencies (Project Scaffold)

- **Target:** Must be complete before any other Wave 1 epic can begin implementation
- **Dependencies:** None — this is the foundation; it has no upstream blockers
- **Blocks:** All other Wave 1 epics depend on this effort being complete

---

## Requirements (Project Scaffold)

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories (Project Scaffold)

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.

---

# PRD: Native Ordering + Checkout

*Product / Effort: native-ordering-checkout*
*Last updated: 2026-06-07*

---

## Problem Statement (Native Ordering + Checkout)

Quality-conscious urban consumers who order food delivery 2–4× per week have no trustworthy surface that connects restaurant discovery to native ordering in a single flow. Incumbent platforms (DoorDash, Uber Eats) rank results by paid placement rather than food quality, forcing users across 2–3 apps to complete a single meal decision — discover on Yelp or Instagram, order on DoorDash — with no continuity between the two.

dishly solves the full loop: editorial curation feeds directly into a native ordering and checkout experience with no app-switching and no paid placement. This effort — Native Ordering + Checkout — closes the loop between the discovery UX (consumer-web-discovery) and a confirmed, tracked order. Wave 1 is a closed beta with simulated delivery and Stripe test-mode payment, validating the complete discover → cart → checkout → confirmation journey before investing in live courier dispatch or real payment processing.

---

## Goals (Native Ordering + Checkout)

1. Full discover-to-order loop functional — measured by a user can complete restaurant → menu → cart → checkout → confirmation without errors in 100% of test runs
2. Order success rate ≥90% — measured by fewer than 10% of order submission attempts fail or surface an error during closed beta
3. Cart conflict handled cleanly — measured by 100% of attempts to add items from a second restaurant trigger a confirmation prompt before clearing the cart
4. Order history accessible to authenticated users — measured by all past orders for the signed-in user are returned with correct restaurant name, date, items, and total
5. Auth gate fires at cart/checkout, not at browse — measured by 0 auth prompts occur on homepage, search, or restaurant pages; gate fires only when the user attempts to add to cart or proceed to checkout

---

## Non-Goals (Native Ordering + Checkout)

- We are not building live courier dispatch — delivery is fully simulated in Wave 1; no DoorDash Drive or Uber Direct API integration is built or designed
- We are not processing real payments — Stripe is used in test mode only; no live charges, no PCI compliance scope for Wave 1
- We are not building a saved delivery address book — delivery address is entered manually per order; no persistence of addresses to a user profile
- We are not supporting multi-restaurant carts — a cart holds items from exactly one restaurant; starting a new restaurant's order clears the existing cart (with a prompt)
- We are not building password reset or email infrastructure — beta users who lose access re-register; no SMTP, no transactional email, no reset tokens
- We are not scheduling or tracking live delivery — the post-confirmation screen shows a static simulated ETA ("estimated 30–40 min"); no real-time courier location or status stream

---

## Success Metrics (Native Ordering + Checkout)

### Leading Indicators (early signal)

- Order attempt rate: users who reach the checkout page ÷ users who add at least one item to cart (target: ≥70%)
- Cart abandonment rate: users who view the cart but do not proceed to checkout (target: <30%)
- Auth modal conversion rate: users who complete sign-up/sign-in at the checkout gate ÷ users who see the auth gate (target: ≥60%)
- Checkout completion rate: users who submit the Place Order form ÷ users who reach the checkout page (target: ≥75%)

### Lagging Indicators (final outcome)

- Order completion rate at 4 weeks post-beta launch: ≥90% of order submissions result in a confirmed order
- Zero P0 bugs (data loss, broken checkout, auth failures) open for more than 24 hours at any point in the beta
- Beta users place at least 1 successful order per session (target: ≥50% of beta sessions with cart activity end in a confirmed order)

---

## Open Questions (Native Ordering + Checkout)

None identified at this time. All engineering decisions are resolved in the existing technical requirements (TR-1 through TR-11 in dishly-wave-1) and ADRs (ADR-001 user URI structure, ADR-002 normalized order items table).

---

## Timeline / Dependencies (Native Ordering + Checkout)

- **Target:** Wave 1 closed beta launch — all 8 implementation tasks (TASK-001 through TASK-008) complete
- **Dependencies:**
  - `user-auth` effort — JWT auth middleware must be in place before order endpoints can enforce authentication
  - `core-backend-apis` effort — restaurant and menu data APIs must be live before cart and checkout can function end-to-end
  - `consumer-web-discovery` effort — cart state (localStorage), restaurant page, and frontend routing must exist before checkout pages can be built

---

## Requirements (Native Ordering + Checkout)

See [`business.md`](business.md) for the full requirement list with MoSCoW priority tiers.

---

## User Stories (Native Ordering + Checkout)

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.

---

## Problem Statement (Core Backend APIs)

The consumer web app and ordering flow require a backend API that serves restaurant data, supports keyword and filtered search, and exposes curated collections — but no such API exists at the start of Wave 1. Without these endpoints, the React frontend has nothing to render and the ordering flow has no items to add to cart. All other Wave 1 epics (consumer-web-discovery, native-ordering-checkout) are blocked until a working, seeded API is in place.

This effort builds the full read-side data layer for dishly Wave 1: a SQLite schema with 100 seeded NYC restaurants, REST endpoints for restaurant search/browse/detail/collections/cuisines/neighbourhoods, and the supporting seed data infrastructure. The API is designed to be discoverable and explorable by the frontend with no authentication required on read operations. Write operations (orders, auth) are out of scope — those belong to `native-ordering-checkout` and `user-auth`.

---

## Goals (Core Backend APIs)

1. All discovery endpoints functional and returning correctly shaped data — measured by `GET /restaurants`, `GET /restaurants/:id`, `GET /collections`, `GET /cuisines`, `GET /neighbourhoods` all return 200 with `{data, meta}` envelope and correct shapes
2. 100 seeded restaurants live at launch — measured by 100 restaurants present in the DB, each with >=3 menu sections, >=8 menu items with photo URLs, >=3 seeded reviews, covering >=5 NYC neighbourhoods and >=8 cuisine types
3. Keyword search returns relevant results — measured by `GET /restaurants?q=ramen` returns only restaurants whose name or menu item names contain "ramen" (case-insensitive)
4. Filters compose correctly — measured by `?cuisine_id=&price_range=$$` returns only restaurants matching both conditions simultaneously
5. All discovery endpoints are open to anonymous access — measured by 0 endpoints in the read-side API return 401 without an Authorization header

---

## Non-Goals (Core Backend APIs)

- We are not building write endpoints for restaurants or menus — no restaurant creation, update, or deletion API in Wave 1
- We are not building a real-time search index — SQL LIKE queries are sufficient for 100 restaurants; no Elasticsearch, Algolia, or search service
- We are not building a CMS for collections — collections are defined in `data/collections.json`; no admin interface
- We are not building user-submitted reviews — reviews are seeded data only; no `POST /reviews` endpoint
- We are not building order or auth endpoints — those are owned by `user-auth` and `native-ordering-checkout`
- We are not building pagination beyond a hard cap — results are capped at 100 for Wave 1; no cursor-based pagination required

---

## Success Metrics (Core Backend APIs)

### Leading Indicators (early signal)

- Endpoint availability: all 5 discovery endpoints return 200 on localhost from a fresh clone and seed (target: 100%)
- Search relevance: `GET /restaurants?q=<cuisine>` returns >=1 relevant result for all 10 seeded cuisine types
- Data completeness: >=95% of seeded restaurant cover image URLs resolve with `naturalWidth > 0` in the browser

### Lagging Indicators (final outcome)

- Zero API-caused rendering failures on any discovery surface during the 4-week closed beta
- Collections API returns >=5 non-empty collections — confirmed by integration test or manual QA at beta launch
- Seed script is idempotent: running `./start.sh` twice never corrupts or duplicates data

---

## Open Questions (Core Backend APIs)

None identified at this time. Schema, search implementation, price encoding, and API response envelope are all specified in TR-CBA-1 through TR-CBA-6. Image hosting strategy (Unsplash CDN URLs) is resolved and implemented.

---

## Timeline / Dependencies (Core Backend APIs)

- **Target:** Wave 1 closed beta launch
- **Dependencies:**
  - `project-scaffold-local-dev-infra` — SQLite connection, Express router setup, and `start.sh` must exist before schema and seed can be implemented
- **Blocks:**
  - `consumer-web-discovery` — frontend cannot render any discovery surface without these endpoints
  - `native-ordering-checkout` — cart and checkout depend on `GET /restaurants/:id` returning full menu data

---

## Requirements (Core Backend APIs)

See `business.md` for the full requirement list with MoSCoW priority tiers (BR-CBA-1 through BR-CBA-6).

---

## User Stories (Core Backend APIs)

See `user-stories.md` for Connextra-format stories grouped by persona (US-CBA-1 through US-CBA-7).

---

# PRD: dishly Wave 1 — Restaurant Discovery and Food Delivery

*Graduated from: dishly-wave-1*
*Last updated: 2026-06-07*

---

## Problem Statement (dishly Wave 1)

Quality-conscious urban consumers who order food delivery 2–4× per week have no trustworthy surface combining restaurant discovery with native ordering. Incumbent platforms rank results by paid placement and margin, forcing users across 2–3 apps to complete a single meal decision. dishly Wave 1 is a closed beta proving the core thesis: a single, continuous surface connecting editorial curation with native ordering, with no paid placement.

---

## Goals (dishly Wave 1)

1. Full discover-to-order loop functional — user can complete homepage → restaurant → menu → cart → checkout → confirmation without errors
2. 100 curated restaurants live at beta launch — browsable and searchable, each with complete menu (≥8 items, ≥3 sections), photos, and ≥3 reviews
3. Order success rate ≥90% in beta
4. Core loop usable on Chrome and Safari (desktop + mobile) with no JS errors

---

## Non-Goals (dishly Wave 1)

- We are not building native iOS or Android apps — web-only
- We are not onboarding real restaurants — seeded data only
- We are not integrating a live delivery partner — fully simulated
- We are not processing real payments — Stripe test mode only
- We are not building a social discovery layer or personalisation

---

## Success Metrics (dishly Wave 1)

- Restaurant page engagement rate: ≥60% of homepage sessions click into a restaurant page
- Checkout funnel conversion: ≥70% of cart sessions reach the Place Order screen
- Full-loop completion rate at 4 weeks: ≥90% of order submissions confirmed with no critical error
- Zero P0 bugs open >24h across the full 4-week beta window

---

## Timeline / Dependencies (dishly Wave 1)

- **Target:** Wave 1 closed beta launch
- **Dependencies:** project-scaffold-local-dev-infra → core-backend-apis → user-auth → consumer-web-discovery → native-ordering-checkout

---

## Requirements (dishly Wave 1)

See [`business.md`](business.md) for the full requirement list (BR-W1-* series).

---

## User Stories (dishly Wave 1)

See [`user-stories.md`](user-stories.md) for Connextra-format stories grouped by persona.
