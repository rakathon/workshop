# User Stories: Customer Profile Section

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Product / Effort: customer-profile-section*
*Last updated: 2026-06-07*

---

## Registered Customer — Identity & Sign-in

**US-1:** As a registered customer, I want to provide my name when signing up, so that the app personalizes my experience from the first login.

**Acceptance Criteria:**
- [ ] Name field is present and optional on the Register form
- [ ] Submitted name is stored and returned in the login response
- [ ] NavBar shows my initials in the avatar immediately after registration

---

**US-2:** As a registered customer, I want to see my name in the NavBar after signing in, so that I know I'm logged in as myself.

**Acceptance Criteria:**
- [ ] NavBar avatar displays my initials (or email prefix if no name set) upon sign-in
- [ ] Clicking the avatar opens a dropdown showing my full name and email
- [ ] No page reload required for the name to appear

---

## Registered Customer — Profile Management

**US-3:** As a registered customer, I want to edit my name and phone number from my Account page, so that my profile stays accurate over time.

**Acceptance Criteria:**
- [ ] Account page shows current name and phone with an edit affordance
- [ ] I can update name (required) and phone (optional, digits-only 7–15 chars)
- [ ] Invalid phone format shows an inline error before I can submit
- [ ] After saving, my updated name is reflected in the NavBar without a page reload

---

**US-4:** As a registered customer, I want to save up to 2 delivery addresses on my profile, so that I don't have to retype them at every checkout.

**Acceptance Criteria:**
- [ ] I can add, edit, and delete addresses from the Account page
- [ ] Each address has optional label, street, city, and postcode fields
- [ ] I can mark one address as default
- [ ] I cannot add a third address — the UI disables the add affordance and the server rejects it with a clear error
- [ ] My default address pre-fills the delivery field when I reach checkout

---

**US-5:** As a registered customer, I want to save up to 2 mock payment methods on my profile, so that I can simulate a preferred payment at checkout.

**Acceptance Criteria:**
- [ ] I can add, edit, and delete payment methods from the Account page
- [ ] Each method requires a card type (Visa, Mastercard, Amex) and cardholder name
- [ ] I cannot add a third payment method — the UI disables the add affordance and the server rejects it
- [ ] My saved payment methods appear as selectable options at checkout alongside "Pay on delivery"

---

## Registered Customer — Checkout Experience

**US-6:** As a registered customer, I want my saved default delivery address pre-filled at checkout, so that I can complete an order faster without retyping my address.

**Acceptance Criteria:**
- [ ] Checkout delivery address field is pre-populated with my default saved address
- [ ] I can override the pre-filled address with a different value before placing the order
- [ ] If no default address is saved, the field is empty as before

---

**US-7:** As a registered customer, I want to select a saved payment method at checkout, so that I can simulate a preferred payment experience.

**Acceptance Criteria:**
- [ ] Checkout shows my saved payment methods as selectable radio options
- [ ] "Pay on delivery" is always available as a fallback option
- [ ] Selecting a saved method is cosmetic only — no real payment processing occurs

---


## Engineer — Local Dev Onboarding

**US-8:** As an engineer joining the project, I want to run a single command after cloning the repo so that I have the full app running locally without reading setup docs.

**Acceptance Criteria:**
- [ ] Running the single startup command from a fresh clone results in both backend and frontend services being accessible in a browser
- [ ] No additional manual steps, installs, or configuration are required beyond having Node.js LTS installed

---

**US-9:** As an engineer, I want both backend and frontend output labeled in the same terminal so that I can quickly identify which service produced a log line.

**Acceptance Criteria:**
- [ ] Log output from the backend service is prefixed or labeled to distinguish it from frontend output
- [ ] Log output from the frontend service is prefixed or labeled to distinguish it from backend output

---

**US-10:** As an engineer, I want pressing Ctrl-C to stop both processes cleanly so that I don't leave orphaned Node processes running on my machine.

**Acceptance Criteria:**
- [ ] Sending a stop signal to the launcher causes both services to terminate
- [ ] No background processes remain running after the launcher is stopped

---

## Engineer — First-Run Database Setup

**US-11:** As an engineer running the app for the first time, I want the database to be created and seeded automatically so that I don't need to run any manual migration or seed commands.

**Acceptance Criteria:**
- [ ] On first run, the database is created and populated with seed data without any manual command
- [ ] The application is immediately usable with seed data after the startup command completes

---

**US-12:** As an engineer re-running the startup command, I want the seed step to be skipped if the database already exists so that my existing data is not overwritten.

**Acceptance Criteria:**
- [ ] Running the startup command a second time does not alter or duplicate existing seed data
- [ ] The startup command completes successfully on subsequent runs without errors related to the seed step

---

---

## New User (registration)

**US-1:** As a new user, I want to create an account with my email and password so that I can place orders and access my order history.

**Acceptance Criteria:**
- [ ] `POST /auth/register` with a valid email and password (≥8 characters) returns 201 with `{user, token}`
- [ ] The returned JWT is valid and can be used immediately on authenticated endpoints
- [ ] Registering with an already-used email returns a 409 error with a human-readable message
- [ ] Registering with a password shorter than 8 characters returns a 422 validation error

---

**US-2:** As a new user, I want to be taken directly into the app after registering so that I don't have to log in separately after creating my account.

**Acceptance Criteria:**
- [ ] Successful registration stores the JWT in `localStorage` under `dishly_token`
- [ ] The user is redirected to the homepage (or the page they came from) immediately after registration
- [ ] No email verification step is required before the account is usable

---

## Returning User (login)

**US-3:** As a returning user, I want to sign in with my email and password so that I can access my account, place orders, and see my order history.

**Acceptance Criteria:**
- [ ] `POST /auth/login` with correct credentials returns 200 with `{user, token}`
- [ ] `POST /auth/login` with incorrect credentials returns 401 with an error message that does not reveal which field (email or password) was wrong
- [ ] Successful login stores the JWT in `localStorage` under `dishly_token`

---

**US-4:** As a returning user, I want my session to persist across browser sessions so that I don't have to log in again every time I open the app.

**Acceptance Criteria:**
- [ ] JWT stored in `localStorage` persists across tab closes and browser restarts (for up to 7 days)
- [ ] Authenticated API calls use the stored token automatically via the `Authorization: Bearer` header
- [ ] An expired or invalid token results in a 401 response and the user is redirected to `/login`

---

## Anonymous Visitor (discovery access)

**US-5:** As an anonymous visitor, I want to browse restaurants and menus without signing in so that I can discover what's available before committing to creating an account.

**Acceptance Criteria:**
- [ ] `GET /restaurants`, `GET /collections`, `GET /restaurants/:id` all return 200 with no `Authorization` header
- [ ] The `requireAuth` middleware is not applied to any discovery route
- [ ] No redirect to `/login` occurs when browsing homepage, search, or restaurant pages

---

## Internal / Engineering

**US-6:** As an engineer, I want a `requireAuth` middleware that protects order endpoints so that unauthenticated users cannot place orders or view order history.

**Acceptance Criteria:**
- [ ] `requireAuth` middleware reads `Authorization: Bearer <token>`, verifies the JWT, and attaches `req.user.id` for downstream handlers
- [ ] Requests with no token return 401 with `{errors: [{code: "UNAUTHORIZED", message: "Authentication required"}]}`
- [ ] Requests with an expired or invalid token return 401 with a clear error message
- [ ] All order endpoints (`POST /orders`, `GET /orders/:id`, `GET /users/me/orders`) apply `requireAuth`

---

**US-7:** As an engineer, I want password hashing with bcrypt so that raw passwords are never stored in the database.

**Acceptance Criteria:**
- [ ] `password_hash` column stores the bcrypt hash (10 salt rounds), never the raw password
- [ ] Login uses `bcrypt.compare` to validate the submitted password against the stored hash
- [ ] No plain-text password appears in any log, error message, or database record

---

## Customer — City Discovery (add-location-based-filtering)

**US-LOC-1:** As a customer browsing dishly from a new city, I want to select my city from a search bar dropdown, so that I only see restaurants relevant to where I am.

**Acceptance Criteria:**
- [ ] City selector visible on Home and Search pages alongside the main search input
- [ ] Typing partial city names narrows the dropdown to matching results
- [ ] Selecting a city filters the restaurant list immediately
- [ ] Clearing the selection restores all-city results

---

**US-LOC-2:** As a customer who just opened the app, I want to tap "Near me" and have the app detect my city automatically, so that I don't have to type or scroll to find my location.

**Acceptance Criteria:**
- [ ] "Near me" is the first option in the city dropdown
- [ ] App requests location permission when "Near me" is tapped
- [ ] Correct city is auto-selected if coordinates fall within a known bounding box
- [ ] If location is denied or unavailable, a friendly inline message guides me to select manually

---

## Returning Customer — Persistent City Preference (add-location-based-filtering)

**US-LOC-3:** As a returning customer, I want my last selected city to be remembered when I come back to the app, so that I don't have to re-select it every session.

**Acceptance Criteria:**
- [ ] Selected city persists in localStorage across page refreshes
- [ ] City preference is cleared when I sign out
- [ ] If a stored city no longer exists in the city list, the selector resets to "All cities"

---

## Traveller — Multi-City Browsing (add-location-based-filtering)

**US-LOC-4:** As a customer travelling between cities, I want to switch cities in the search bar, so that I can explore restaurants in my destination before I arrive.

**Acceptance Criteria:**
- [ ] Changing city selection immediately re-filters results without a page reload
- [ ] Previously applied cuisine and price filters remain active when city changes
- [ ] The selected city name is visible in the search bar so I know which city I'm browsing

---

## Non-NYC Customer — Relevant Restaurant Catalogue (add-location-based-filtering)

**US-LOC-5:** As a customer in Los Angeles, Chicago, Boston, Miami, or San Francisco, I want to see restaurants with real local names and cuisine types relevant to my city, so that the app feels relevant to me.

**Acceptance Criteria:**
- [ ] At least 20 restaurants available per new city
- [ ] Restaurant names, cuisine types, and descriptions reflect local food culture
- [ ] Filtering by a new city returns results with correct neighbourhood association

---

## Anonymous Visitor — Core Backend APIs (Discovery Consumer)

**US-CBA-1:** As an anonymous visitor, I want to browse curated restaurant collections via the API so that the homepage can render editorial content without requiring me to sign in.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/collections` returns all collections in config-file order with embedded restaurant summaries
- [ ] Collections with zero matching restaurants are omitted from the response
- [ ] No `Authorization` header is required

---

**US-CBA-2:** As an anonymous visitor, I want to search for restaurants by keyword so that I can find a specific cuisine or restaurant by name.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/restaurants?q=ramen` returns restaurants whose name or menu item names contain "ramen" (case-insensitive)
- [ ] A restaurant appears once in results regardless of how many menu items matched
- [ ] Results are capped at 100

---

**US-CBA-3:** As an anonymous visitor, I want to filter restaurants by cuisine type and price range so that I can narrow search results to what I'm looking for.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/restaurants?cuisine_id=<id>` returns only restaurants of that cuisine
- [ ] `GET /dishly/v1/restaurants?price_range=$$` returns only restaurants with that price range
- [ ] Filters are composable: `?cuisine_id=<id>&price_range=$$` applies both simultaneously
- [ ] `GET /dishly/v1/cuisines` returns all cuisine types alphabetically for filter chip population
- [ ] `GET /dishly/v1/neighbourhoods` returns all neighbourhoods alphabetically

---

**US-CBA-4:** As an anonymous visitor, I want to view a restaurant's full detail including menu and reviews so that I can evaluate whether to order from it.

**Acceptance Criteria:**
- [ ] `GET /dishly/v1/restaurants/:id` returns full restaurant detail: name, cuisine, neighbourhood, price range, average rating, description, address, cover image URL
- [ ] Response includes nested menu: menu sections with items (name, description, price, image URL)
- [ ] Response includes up to 5 seeded reviews: author name, rating, text, date
- [ ] Returns 404 JSON for unknown restaurant IDs

---

## Beta User — Seeded Data Consumer

**US-CBA-5:** As a beta user, I want to browse 100 NYC restaurants with realistic variety so that the platform feels well-stocked and credible from day one.

**Acceptance Criteria:**
- [ ] 100 restaurants exist in the database after `./start.sh` on a fresh clone
- [ ] Restaurants span >=5 NYC neighbourhoods, >=8 cuisine types, and a spread of $/$$/$$$ price ranges
- [ ] Each restaurant has >=3 menu sections, >=8 menu items with photo URLs, and >=3 reviews
- [ ] All ratings are >=3.5 (curation quality signal — no low-rated restaurants)

---

## Internal / Engineering — Core Backend APIs

**US-CBA-6:** As an engineer, I want all API responses to use a consistent `{data, meta}` envelope so that the frontend can handle all responses with a single client utility.

**Acceptance Criteria:**
- [ ] All successful responses return `{data: ..., meta: {status: {code}, operation: {request_id}}}`
- [ ] All error responses return `{errors: [{code, message}], meta: ...}`
- [ ] No endpoint returns a raw array or plain object outside the envelope

---

**US-CBA-7:** As an engineer, I want the seed script to be idempotent so that running `./start.sh` multiple times never duplicates or corrupts data.

**Acceptance Criteria:**
- [ ] The seed script checks for existing data before inserting — skips if restaurants already exist
- [ ] Running `./start.sh` twice produces exactly 100 restaurants, not 200
- [ ] Seed errors are surfaced clearly — not silently swallowed

---

## Anonymous Visitor — Ordering (native-ordering-checkout)

**US-NOC-1:** As an anonymous visitor, I want to browse restaurant menus and see prices and photos without signing in, so that I can decide what I want to order before committing to creating an account.

**Acceptance Criteria:**
- [ ] Any visitor can view any restaurant page, menu sections, and item details without a sign-in prompt
- [ ] No auth gate appears anywhere on the discovery surface (homepage, search, restaurant page, menu)

---

**US-NOC-2:** As an anonymous visitor, I want to be prompted to sign in only when I try to add an item to my cart, so that my browsing experience is uninterrupted until I'm ready to order.

**Acceptance Criteria:**
- [ ] Clicking "Add to cart" while unauthenticated shows an auth prompt (modal or redirect to /login)
- [ ] No auth prompt appears before the user attempts to add to cart
- [ ] After signing in, the item the user tried to add is added to the cart automatically (or the user is returned to the restaurant page to add it)

---

## New User — First-time Orderer (native-ordering-checkout)

**US-NOC-3:** As a new user, I want to create an account with my email and password at the checkout gate, so that I can place my first order without having to register separately before browsing.

**Acceptance Criteria:**
- [ ] Sign-up is available inline at the checkout gate — the user does not need to visit `/register` separately
- [ ] Registration requires email and password (minimum 8 characters)
- [ ] After successful registration, the user's cart is preserved and checkout continues
- [ ] A duplicate email returns a clear error message without clearing the form

---

**US-NOC-4:** As a new user, I want to enter my delivery address at checkout, so that I can specify where my order should be delivered without having saved addresses set up.

**Acceptance Criteria:**
- [ ] A free-text delivery address field is present on the checkout page
- [ ] The address field is required before the order can be submitted
- [ ] The entered address appears on the order confirmation screen and is stored with the order record

---

## Authenticated Orderer (native-ordering-checkout)

**US-NOC-5:** As an authenticated user, I want to add multiple items from one restaurant to my cart and review them before checking out, so that I can build my full order before committing.

**Acceptance Criteria:**
- [ ] Items from the same restaurant accumulate in the cart with correct quantities and line totals
- [ ] The cart page shows restaurant name, all items with quantities and prices, delivery fee, and order total
- [ ] A "Proceed to Checkout" button navigates to the checkout page

---

**US-NOC-6:** As an authenticated user, I want to be warned before I accidentally clear my cart by starting a new restaurant's order, so that I don't lose items I already selected.

**Acceptance Criteria:**
- [ ] Adding an item from a different restaurant than the current cart's restaurant shows a confirmation modal
- [ ] The modal names the current cart's restaurant explicitly
- [ ] "Keep current cart" dismisses the modal with no changes
- [ ] "Start new order" clears the cart and adds the new item

---

**US-NOC-7:** As an authenticated user, I want to see a full order summary before I confirm payment, so that I can verify items, address, and total before committing.

**Acceptance Criteria:**
- [ ] Checkout shows: itemised list with quantities and prices, delivery address, subtotal, delivery fee ($3.99), and total
- [ ] The "Place Order" button is not shown until the address field is filled
- [ ] No surprise fees appear between the cart view and the final confirmation

---

**US-NOC-8:** As an authenticated user, I want to receive a confirmation screen with a simulated delivery estimate after placing my order, so that I know my order was received and what to expect.

**Acceptance Criteria:**
- [ ] A confirmation screen at `/orders/:id` renders after a successful order submission
- [ ] The screen shows order number, restaurant name, delivery address, itemised summary, and total
- [ ] A simulated ETA is displayed — e.g. "Estimated 30–40 minutes"
- [ ] Cart is cleared in localStorage when the confirmation screen loads
- [ ] Two CTAs are visible: "Back to home" and "View order history"

---

**US-NOC-9:** As an authenticated user, I want my cart to be preserved if my order submission fails, so that I don't have to rebuild my order after a network or server error.

**Acceptance Criteria:**
- [ ] A failed order submission does not clear the cart
- [ ] An inline error message is shown on the checkout page with a human-readable explanation
- [ ] The "Place Order" button is re-enabled so the user can retry immediately
- [ ] No partial order is created in the database on failure

---

## Returning User — Order History (native-ordering-checkout)

**US-NOC-10:** As a returning authenticated user, I want to view my past orders with itemised detail, so that I can track what I've ordered and find restaurants I've enjoyed.

**Acceptance Criteria:**
- [ ] `/account/orders` shows all past orders newest-first
- [ ] Each order shows: restaurant name, order date, itemised items with quantities, and total
- [ ] Unauthenticated access redirects to `/login`

---

**US-NOC-11:** As a returning authenticated user, I want my order history to be private, so that other users cannot see what I've ordered.

**Acceptance Criteria:**
- [ ] A user's orders are only visible when authenticated as that user
- [ ] Attempting to fetch another user's order via `GET /orders/:id` returns a 403 response
- [ ] `GET /users/me/orders` returns only orders belonging to the authenticated user

---

## Internal / Beta Operations (native-ordering-checkout)

**US-NOC-12:** As an internal team member, I want order and order-item records to snapshot item names and prices at time of order, so that historical order history remains accurate even if menu prices change after the order is placed.

**Acceptance Criteria:**
- [ ] `order_item` rows store `item_name` and `unit_price` as snapshots, not foreign-key lookups
- [ ] Changing a menu item's price or name after an order is placed does not alter the order history display
- [ ] The order confirmation and history pages render from the snapshotted values

---

---

## Maya — The Intentional Orderer (consumer-web-discovery)

*Graduated from: consumer-web-discovery*

**US-CWD-1:** As Maya, I want to browse curated restaurant collections on the homepage so that I can discover somewhere new without knowing exactly what I'm looking for.

**Acceptance Criteria:**
- [ ] Homepage renders ≥1 named collection (e.g. "Best Ramen in the City") with restaurant cards on load
- [ ] Each card shows a food photo, restaurant name, cuisine, and price range
- [ ] No sign-in prompt appears while browsing

---

**US-CWD-2:** As Maya, I want to view a restaurant page with a full-width hero photo, description, and review snippets so that I can decide whether a restaurant is worth ordering from before committing.

**Acceptance Criteria:**
- [ ] Hero image renders full-width at the top of the restaurant page
- [ ] Restaurant name, cuisine, price range, and star rating are visible
- [ ] 3–5 review snippets with author, rating, and text are displayed
- [ ] The page loads without requiring a sign-in

---

**US-CWD-3:** As Maya, I want to see a complete menu with item photos, descriptions, and prices so that I can evaluate dishes visually before adding to cart.

**Acceptance Criteria:**
- [ ] Menu is grouped into named sections (e.g. Starters, Mains)
- [ ] Each item shows: photo (or placeholder), name, description, and price
- [ ] An "Add to cart" button is present inline on each item
- [ ] No separate item detail page is required — all info is visible on the restaurant page

---

## Darius — The Efficient Professional (consumer-web-discovery)

*Graduated from: consumer-web-discovery*

**US-CWD-4:** As Darius, I want to search for a cuisine type and get a filtered list of results so that I can find a restaurant quickly without browsing collections.

**Acceptance Criteria:**
- [ ] Typing in the search bar and pressing Enter navigates to `/search?q=<query>`
- [ ] Results show within 2 seconds on localhost against the seed dataset
- [ ] Each result shows restaurant name, cuisine, neighbourhood, rating, and price range
- [ ] A result count label is visible above the list

---

**US-CWD-5:** As Darius, I want to filter search results by cuisine type and price range so that I can narrow options to exactly what I want without scrolling through irrelevant results.

**Acceptance Criteria:**
- [ ] Cuisine type and price range filter chips are visible above the search results list
- [ ] Clicking a filter chip narrows the result list in real-time
- [ ] Active filter chips have a visually distinct state
- [ ] Removing a filter restores the unfiltered result set

---

**US-CWD-6:** As Darius, I want a clear empty state when my search returns no results so that I know to try a different query rather than assuming the page is broken.

**Acceptance Criteria:**
- [ ] A friendly message is shown: "No restaurants found for '[query]'"
- [ ] A "Browse collections" CTA links back to the homepage
- [ ] No blank page, spinner, or error toast is shown for zero results

---

## Priya — The Explorer (consumer-web-discovery)

*Graduated from: consumer-web-discovery*

**US-CWD-7:** As Priya, I want the homepage to feel editorial — with strong collection names and beautiful food photography — so that I trust the platform has genuine taste and want to keep browsing.

**Acceptance Criteria:**
- [ ] Collection titles are editorial and specific (e.g. "Under $15 a Dish", not "Affordable Food")
- [ ] Restaurant card cover images are displayed prominently; broken images show a styled placeholder — not a broken icon
- [ ] No "Sponsored" labels, paid-placement badges, or ranking-weight indicators appear anywhere on the page

---

**US-CWD-8:** As Priya, I want to filter the homepage by cuisine type without leaving the page so that I can narrow the collections to what I'm in the mood for while still feeling like I'm browsing.

**Acceptance Criteria:**
- [ ] Cuisine filter chips are visible on the homepage below the hero
- [ ] Clicking a chip filters the collections grid in-place (no page navigation)
- [ ] The URL does not change when a chip is selected
- [ ] The active chip is visually highlighted

---

## Anonymous Visitor — Discovery (consumer-web-discovery)

*Graduated from: consumer-web-discovery*

**US-CWD-9:** As an anonymous visitor, I want to browse restaurants and menus without being asked to sign in so that I can make a decision about what I want before I commit to creating an account.

**Acceptance Criteria:**
- [ ] Homepage, search results, and restaurant pages all load for unauthenticated users
- [ ] No sign-in modal, banner, or redirect appears on any discovery surface
- [ ] The auth prompt appears only when the user attempts to add an item to cart

---

**US-CWD-10:** As an anonymous visitor on mobile, I want the discovery surfaces to be fully usable on my phone so that I can discover and evaluate restaurants on the go.

**Acceptance Criteria:**
- [ ] Homepage, search, and restaurant pages render correctly at 390px viewport width
- [ ] All touch targets (buttons, links, cards) are ≥44×44px
- [ ] Menu sections on the restaurant page are collapsible on mobile
- [ ] No horizontal scroll or layout overflow at 390px

---

## dishly Wave 1 — Discovery

*Graduated from: dishly-wave-1*

**US-W1-1:** As an anonymous visitor, I want to browse curated restaurant collections on the homepage so that I can find somewhere worth eating without knowing what I'm looking for.

**Acceptance Criteria:**
- [ ] The homepage displays at least one curated collection of restaurants
- [ ] Each collection has a title and shows restaurant cards with enough detail to decide whether to click through
- [ ] No sign-in is required to view the homepage or any collection

---

**US-W1-2:** As an anonymous visitor, I want to search for restaurants by name or cuisine type so that I can find a specific type of food quickly.

**Acceptance Criteria:**
- [ ] A search bar is accessible from the homepage
- [ ] Entering a restaurant name or cuisine type returns a filtered list of matching restaurants
- [ ] A "no results" message is shown when no restaurants match the query

---

**US-W1-3:** As an anonymous visitor, I want to view a restaurant page with photos, description, price range, and reviews so that I can decide whether it's worth ordering from.

**Acceptance Criteria:**
- [ ] The restaurant page shows a cover photo, name, cuisine type, price range, average star rating, short description, and review snippets
- [ ] The page is accessible without signing in
- [ ] If the cover photo cannot be loaded, a placeholder is displayed

---

**US-W1-4:** As an anonymous visitor, I want to browse a restaurant's full menu with item photos, descriptions, and prices so that I can see what's available before committing to order.

**Acceptance Criteria:**
- [ ] The restaurant page shows the full menu grouped by section
- [ ] Each menu item displays a name, description, price, and photo
- [ ] The menu is browsable without signing in

---

## dishly Wave 1 — Ordering

*Graduated from: dishly-wave-1*

**US-W1-5:** As an authenticated user, I want to add menu items to a cart from a restaurant page so that I can build my order before checking out.

**Acceptance Criteria:**
- [ ] An add-to-cart action is available inline on each menu item
- [ ] Adding an item updates the cart and reflects the correct item count and total
- [ ] The cart persists within the session

---

**US-W1-6:** As an authenticated user, I want to see a confirmation screen with a simulated delivery estimate after placing an order so that I know my order was received.

**Acceptance Criteria:**
- [ ] After confirming an order, a confirmation screen is shown
- [ ] The confirmation screen displays a simulated delivery estimate
- [ ] The confirmed order is recorded and appears in order history

---

**US-W1-7:** As an authenticated user, I want to see an order summary — itemised list, delivery address, and total — before confirming so that I can review before committing.

**Acceptance Criteria:**
- [ ] An order summary screen is shown before the final confirm action
- [ ] The user can return to the cart from the summary to make changes
- [ ] The confirm action is not available until the address has been entered

---

## dishly Wave 1 — Seed Data and Content

*Graduated from: dishly-wave-1*

**US-W1-8:** As a beta user, I want to browse 100 curated restaurants across multiple cuisine types and price ranges so that the platform feels well-stocked from day one.

**Acceptance Criteria:**
- [ ] At least 100 restaurants are available at beta launch, spanning multiple cuisine types and price points
- [ ] Each restaurant has a complete menu with item photos and descriptions
- [ ] The restaurant catalogue is browsable via homepage collections and search

---

**US-W1-9:** As an internal team member, I want to update curated collections by editing a config file so that the homepage content can be refreshed without a code change.

**Acceptance Criteria:**
- [ ] Curated collections are defined in a configuration file separate from application code
- [ ] Updating the configuration file and redeploying is sufficient to change homepage collections
- [ ] No direct database edit or code change is required to update collection content
