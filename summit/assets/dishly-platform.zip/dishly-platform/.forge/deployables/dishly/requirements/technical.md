# Technical Requirements — Customer Profile Section

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Effort: customer-profile-section*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-06-06*

---

## TR-1: Schema migration via additive ALTER TABLE

*Traces to: [BR-1](business.md#br-1-name-collected-at-registration), [BR-2](business.md#br-2-personal-info-editing), [BR-5](business.md#br-5-authenticated-name-display-after-sign-in)*

The `user` table must be extended with `name TEXT` and `phone TEXT` columns via `ALTER TABLE` statements appended to the existing `migrate.js` file. Both columns are nullable to preserve compatibility with existing seed data and registered users. No data migration required — existing rows default to NULL.

## TR-2: Separate tables for addresses and payment methods

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses), [BR-4](business.md#br-4-mock-payment-methods)*

Saved addresses and mock payment methods must each live in their own table (`user_address`, `user_payment_method`) rather than as JSON blobs on the `user` row. This keeps queries simple and makes the per-user caps (2 addresses, 2 payment methods) enforceable with a COUNT check server-side.

## TR-3: All profile endpoints require authentication

*Traces to: [BR-2](business.md#br-2-personal-info-editing), [BR-3](business.md#br-3-saved-delivery-addresses), [BR-4](business.md#br-4-mock-payment-methods)*

`PATCH /users/me`, `POST|PATCH|DELETE /users/me/addresses/:id`, and `POST|PATCH|DELETE /users/me/payment_methods/:id` must all use the existing `requireAuth` middleware. Unauthenticated requests receive `401 UNAUTHORIZED`.

## TR-4: Client-side state update without page reload

*Traces to: [BR-2](business.md#br-2-personal-info-editing), [BR-5](business.md#br-5-authenticated-name-display-after-sign-in)*

After a successful `PATCH /users/me`, the frontend must update `dishly_user_name` in `localStorage` and re-render the NavBar avatar and dropdown without a full page navigation. The NavBar reads from `localStorage` on render; a forced re-render (e.g. via a shared auth context or a custom event) is acceptable for Wave 1.

## TR-5: Phone validation bounds

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

Phone numbers are validated client-side and server-side as digits-only (stripping spaces/dashes before storage), minimum 7 digits, maximum 15 digits. No E.164 formatting or country-code enforcement. Empty string is treated as "no phone set" (stored as NULL).

## TR-7: Cart stepper uses reactive client-side state

*Traces to: [BR-7](business.md#br-7-quantity-stepper-on-restaurant-menu-page)*

The quantity stepper on the restaurant menu page must derive its displayed value directly from the `useCart` hook's in-memory cart state — not from a separate local component state. `useCart` must expose a `decrementItem(itemId)` function that mirrors the existing `addItem` semantics: updates the in-memory state, persists to `localStorage`, and broadcasts the `dishly:cart-updated` event so all consumers (NavBar badge, Cart page) stay in sync. The stepper renders conditionally: quantity 0 → "Add to cart" button; quantity ≥ 1 → stepper control.

## TR-6: Address and payment method cap enforced server-side

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses), [BR-4](business.md#br-4-mock-payment-methods)*

Before inserting a new address or payment method, the backend must COUNT existing rows for the user. If the count is already at the maximum (2), respond with `422 UNPROCESSABLE_ENTITY` and a clear message. The frontend also enforces the cap to disable the "Add" affordance, but server-side is the authoritative check.


---

## TR-8: Local-only infrastructure

*Traces to: [BR-8](business.md#br-8-single-command-local-startup)*

The entire stack runs as local processes on a developer's machine. No cloud
infrastructure, no Docker, no container runtime, no remote services.

**Constraints:**
- All services run as local OS processes
- Data is persisted to the local filesystem
- No network calls to remote infrastructure at runtime

---

## TR-9: Technology stack

*Traces to: [BR-8](business.md#br-8-single-command-local-startup), [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes)*

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite |
| Backend | Node.js + Express |
| Database | SQLite via better-sqlite3 |
| Auth | JWT (jsonwebtoken) |
| Payment | Stripe test mode (stripe npm package) |
| IDs | uuid |
| CORS | cors |

**Constraints:**
- No external databases (Postgres, MySQL, MongoDB, Redis)
- No third-party auth services (Auth0, Firebase, Cognito)
- Frontend and backend run as separate local processes

---

## TR-10: Concurrent process launcher uses `concurrently`

*Traces to: [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes)*

`start.sh` uses the `concurrently` npm package (installed as a root-level dev
dependency) to run backend and frontend in parallel in the same terminal.

**Rationale:** `concurrently` handles labeled output, graceful Ctrl-C shutdown of
both processes, and non-zero exit propagation — more reliable than backgrounding
with `&` and a signal trap.

**Constraints:**
- Root `package.json` declares `concurrently` as a dev dependency
- Output prefixes: `[backend]` and `[frontend]`
- Both processes terminate when the launcher is stopped

---

## TR-11: Backend server entry point and port

*Traces to: [BR-8](business.md#br-8-single-command-local-startup), [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes)*

**Constraints:**
- Entry point: `backend/src/server.js`
- Port: `process.env.PORT || 3001`
- Directory structure: `backend/src/{routes,middleware,db}/`
- API routes mounted under `/dishly/v1/`
- Unmatched `/dishly/v1/*` routes return JSON 404, not HTML

---

## TR-12: Frontend entry point and port

*Traces to: [BR-8](business.md#br-8-single-command-local-startup), [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes)*

**Constraints:**
- Scaffolded with Vite + React template
- Port: `process.env.VITE_PORT || 3000` (via Vite config)
- React Router v6 for client-side routing
- All 9 routes from the initiative spec defined as stub components
- Express backend serves `index.html` catch-all for all non-API routes so
  direct URL navigation works in production builds

---

## TR-13: SQLite database location and seed behaviour

*Traces to: [BR-10](business.md#br-10-database-seeded-on-first-run)*

**Constraints:**
- DB file path: `process.env.DB_PATH || './data/dishly.db'`
- Seed detection: check for existence of the DB file or a sentinel row before seeding
- Seed is skipped (not re-run) if already seeded — idempotent
- Seed data committed to repository under `data/seed/`

---

## TR-14: Root package.json and start script

*Traces to: [BR-8](business.md#br-8-single-command-local-startup), [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes), [BR-10](business.md#br-10-database-seeded-on-first-run)*

**Constraints:**
- Root `package.json` with `concurrently` dev dependency
- `start.sh` at repo root performs in order:
  1. Install `backend/node_modules` if absent (`npm install --prefix backend`)
  2. Install `frontend/node_modules` if absent (`npm install --prefix frontend`)
  3. Install root `node_modules` if absent (`npm install`)
  4. Seed database if not already seeded (`node backend/src/db/seed.js`)
  5. Launch both processes via `npx concurrently`
- Script is executable (`chmod +x start.sh`)
- Only runtime dependency on the host is Node.js LTS

---

## TR-1: JWT stored in localStorage, no external auth provider

*Traces to: BR-2 (Email/password registration and login)*

Auth is stateless JWT. No Auth0, Firebase Auth, Cognito, or any third-party auth service.

**Constraints:**
- JWT signed with `process.env.JWT_SECRET || 'dishly-dev-secret'`
- Token expiry: 7 days (`expiresIn: '7d'`)
- Frontend stores token in `localStorage` under key `dishly_token`
- All authenticated API calls send `Authorization: Bearer <token>` header

---

## TR-2: Password hashing with bcrypt

*Traces to: BR-2 (Email/password registration and login)*

Passwords are hashed before storage. Raw passwords are never persisted.

**Constraints:**
- Use `bcrypt` npm package, salt rounds: 10
- `password_hash` column stores the bcrypt hash
- Login compares submitted password against stored hash via `bcrypt.compare`

---

## TR-3: User data model

*Traces to: BR-2 (Email/password registration and login), BR-4 (Order history visible to authenticated user only)*

Matches the initiative spec TR-4 User entity exactly.

| Field | Type | Notes |
|-------|------|-------|
| id | TEXT | UUID v4 |
| email | TEXT | Unique, case-insensitive |
| password_hash | TEXT | bcrypt hash |
| created_at | TEXT | ISO datetime |

**Constraints:**
- Email stored and compared case-insensitively (lowercase on write)
- `id` generated with `uuid` package
- SQLite table: `user`

---

## TR-4: Auth API endpoints

*Traces to: BR-2 (Email/password registration and login)*

Two endpoints matching the initiative OpenAPI spec exactly:

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/dishly/v1/auth/register` | none | Register new user, return `{user, token}` |
| POST | `/dishly/v1/auth/login` | none | Authenticate, return `{user, token}` |
| GET | `/dishly/v1/users/me` | bearer | Return current user profile |

Response envelope: `{data: ..., meta: {status: {code}, operation: {request_id}}}`.
Error envelope: `{errors: [{code, message}], meta: ...}`.

---

## TR-5: JWT auth middleware

*Traces to: BR-1 (Anonymous discovery, account required at checkout), BR-4 (Order history visible to authenticated user only)*

Express middleware that validates the bearer token and attaches `req.user` for
downstream handlers.

**Constraints:**
- Reads `Authorization: Bearer <token>` header
- Verifies signature and expiry using `jsonwebtoken`
- On invalid/missing token: returns 401 JSON error
- Attached as named export `requireAuth` from `backend/src/middleware/auth.js`
- Discovery routes (`GET /restaurants*`, `GET /collections*`, `GET /cuisines`, `GET /neighbourhoods`) do NOT use this middleware

---

## TR-6: SQLite schema migration for user table

*Traces to: TR-3 (User data model)*

The `user` table is created via `backend/src/db/migrate.js`, run on server startup
before any requests are served.

**Constraints:**
- Migration is idempotent (`CREATE TABLE IF NOT EXISTS`)
- `migrate.js` is called at the top of `server.js` before `app.listen`
- No external migration framework required for Wave 1

---

## TR-CBA-1: Full SQLite schema for restaurant catalogue

*Traces to: BR-CBA-1, BR-CBA-2, BR-CBA-5*

All entities from the initiative logical schema implemented in `backend/src/db/migrate.js` using `CREATE TABLE IF NOT EXISTS`.

Tables required:
- `cuisine (id, name)`
- `neighbourhood (id, name)`
- `restaurant (id, name, cuisine_id, neighbourhood_id, description, address, price_range, cover_image_url, average_rating, delivery_radius_km)`
- `menu_section (id, restaurant_id, name, sort_order)`
- `menu_item (id, section_id, name, description, price_value, price_scale, image_url)`
- `review (id, restaurant_id, author_name, rating, body, review_date)`

**Constraints:**
- All foreign keys enforced (`PRAGMA foreign_keys = ON` already set in connection.js)
- `average_rating` on restaurant is a stored float derived from seeded reviews (not computed at query time)
- `price_value` and `price_scale` store the value/scale tuple matching the API Price schema

---

## TR-CBA-2: Restaurant seed script

*Traces to: BR-CBA-5*

`backend/src/db/seed.js` inserts all seed data transactionally. Sentinel: checks for existence of `restaurant` table rows before seeding (skip if count > 0).

**Seed distribution (100 restaurants):**
- Neighbourhoods: Manhattan, Brooklyn, Queens, Williamsburg, Astoria (>=5)
- Cuisine types: Japanese, Italian, Mexican, Indian, Thai, American, Chinese, Mediterranean, Korean, French (10)
- Price spread: ~33 each of $, $$, $$$
- Ratings: 3.5-5.0; realistic spread
- Each restaurant: 3 menu sections, >=8 items, 3 reviews

All image URLs use publicly accessible sources (Unsplash CDN format).

---

## TR-CBA-3: Collections config

*Traces to: BR-CBA-3*

`data/collections.json` — array of collection objects loaded at server startup.

Shape:
```json
[
  {
    "id": "best-ramen",
    "title": "Best Ramen in the City",
    "description": "Hand-picked noodle shops worth the trip",
    "restaurant_ids": ["uuid-1", "uuid-2"]
  }
]
```

Minimum 5 collections covering different cuisine types and themes.

---

## TR-CBA-4: Search implementation

*Traces to: BR-CBA-1*

SQL LIKE query — sufficient for 100-restaurant dataset. No Elasticsearch required for Wave 1.



Neighbourhood name free-text is NOT matched via `?q=` — only `neighbourhood_id` UUID filter.

---

## TR-CBA-5: Price encoding

*Traces to: BR-CBA-2*

All prices returned as `{value: integer, scale: integer}` tuples. `value=1499, scale=2` -> $14.99. Stored as `price_value INTEGER, price_scale INTEGER` in `menu_item`.

---

## TR-CBA-6: API response envelope for discovery endpoints

*Traces to: BR-CBA-1, BR-CBA-2, BR-CBA-3, BR-CBA-4*

All responses use `{data: ..., meta: {status: {code}, operation: {request_id}}}`. Errors use `{errors: [{code, message}], meta: ...}`. Matches initiative OpenAPI spec exactly.

---

## TR-LOC-1: No schema migration required — neighbourhood table reused as city list

*Traces to: [BR-LOC-1](business.md#br-loc-1-location-relevant-restaurant-catalogue-without-schema-change)*
*Graduated from: add-location-based-filtering*

The `neighbourhood` table schema is unchanged. New city entries are inserted as additional rows via the seed script only. No `ALTER TABLE` or new table creation is needed. The `neighbourhood_id` query parameter on `GET /restaurants` already supports filtering — no backend route changes required beyond confirming the existing filter works for new entries.

---

## TR-LOC-2: City selector is a client-side combobox — no new API endpoint

*Traces to: [BR-LOC-2](business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)*
*Graduated from: add-location-based-filtering*

The city selector fetches the full city list from the existing `GET /neighbourhoods` endpoint (already implemented). Client-side filtering of the dropdown as the user types is performed in React state — no server-side autocomplete endpoint is needed. The selected city's `neighbourhood_id` is passed as a query parameter to `GET /restaurants`.

---

## TR-LOC-3: City bounding boxes hardcoded in frontend config

*Traces to: [BR-LOC-3](business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)*
*Graduated from: add-location-based-filtering*

Each city's lat/lng bounding box is defined as a static constant in the frontend (e.g. `src/config/cityBounds.js`). The structure: `{ id: <neighbourhood_id_placeholder>, name, bounds: { minLat, maxLat, minLng, maxLng }, centroid: { lat, lng } }`. Neighbourhood IDs are resolved at runtime by matching city name against the `/neighbourhoods` response — not hardcoded UUIDs, since UUIDs are generated fresh on each seed.

---

## TR-LOC-4: Geolocation uses browser Permissions API with graceful fallback

*Traces to: [BR-LOC-3](business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)*
*Graduated from: add-location-based-filtering*

`navigator.geolocation.getCurrentPosition()` is called only when the user explicitly clicks "Near me". If the browser denies permission (`PERMISSION_DENIED`) or position is unavailable (`POSITION_UNAVAILABLE` / `TIMEOUT`), an inline error message is shown without crashing the filter state. The city selector returns to its "All cities" default on failure.

---

## TR-LOC-5: Seed script idempotency preserved via name-based existence check

*Traces to: [BR-LOC-4](business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)*
*Graduated from: add-location-based-filtering*

The seed script checks for existing neighbourhood rows by name before inserting. New city insertions are guarded: `SELECT id FROM neighbourhood WHERE name = ?` — insert only if absent. This prevents duplicate cities on re-run while keeping the script append-safe for new cities added in future efforts.

---

## TR-NOC-1: Order and OrderItem schema

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-1](business.md#br-noc-1-single-restaurant-linear-checkout), [BR-NOC-6](business.md#br-noc-6-order-confirmation-screen-with-simulated-eta)*

The `order` and `order_item` tables are created idempotently in `backend/src/db/migrate.js`.

| Table | Column | Type | Notes |
|-------|--------|------|-------|
| order | id | TEXT PK | UUID v4 |
| order | user_id | TEXT FK | → user.id |
| order | restaurant_id | TEXT FK | → restaurant.id |
| order | delivery_address | TEXT | Entered at checkout |
| order | subtotal_value | INTEGER | Integer cents |
| order | subtotal_scale | INTEGER | Always 2 |
| order | delivery_fee_value | INTEGER | Always 399 |
| order | delivery_fee_scale | INTEGER | Always 2 |
| order | total_value | INTEGER | subtotal + delivery_fee |
| order | total_scale | INTEGER | Always 2 |
| order | status | TEXT | 'confirmed' / 'delivering' / 'delivered' |
| order | created_at | TEXT | ISO datetime |
| order | deleted_at | TEXT | Soft delete; null = active |
| order_item | id | TEXT PK | UUID v4 |
| order_item | order_id | TEXT FK | → order.id ON DELETE CASCADE |
| order_item | menu_item_id | TEXT FK | → menu_item.id |
| order_item | item_name | TEXT | Snapshot of name at order time |
| order_item | quantity | INTEGER | ≥ 1 |
| order_item | unit_price_value | INTEGER | Snapshot of price at order time |
| order_item | unit_price_scale | INTEGER | Always 2 |

**Constraints:**
- `"order"` is a reserved SQL word — always quoted in queries
- `item_name` and `unit_price_value` are snapshots — never updated after creation; changes to `menu_item` do not affect historic orders
- Migration is idempotent (`CREATE TABLE IF NOT EXISTS`)

---

## TR-NOC-2: POST /orders endpoint

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-1](business.md#br-noc-1-single-restaurant-linear-checkout), [BR-NOC-5](business.md#br-noc-5-test-mode-payment-in-wave-1)*

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/dishly/v1/orders` | bearer | Create order, call Stripe test-mode, return 201 |

**Request body:**
```json
{
  "restaurant_id": "uuid",
  "items": [{ "menu_item_id": "uuid", "quantity": 1 }],
  "delivery_address": "42 Main St, New York, NY",
  "payment_method_id": "pm_card_visa"
}
```

**Constraints:**
- All items must belong to the same `restaurant_id` — returns 422 if any item's `menu_section.restaurant_id` differs
- `payment_method_id` is passed to `stripe.paymentIntents.create()` in test mode before inserting the order
- Order and order_item rows are inserted in a single SQLite transaction — no partial writes
- Returns 201 `{data: Order, meta}` on success; `Location: /dishly/v1/orders/:id` header set
- Returns 401 if no bearer token; returns 422 for validation errors; returns 400 for missing fields

---

## TR-NOC-3: GET /orders/:id endpoint

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-6](business.md#br-noc-6-order-confirmation-screen-with-simulated-eta), [BR-NOC-7](business.md#br-noc-7-order-history-for-authenticated-users)*

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/dishly/v1/orders/:id` | bearer | Return order with nested order_items |

**Constraints:**
- Returns 404 JSON if order does not exist or is soft-deleted
- Returns 403 JSON if `order.user_id !== req.user.id`
- Response includes nested `items` array with `item_name`, `quantity`, `unit_price {value, scale}`
- Response includes `subtotal`, `delivery_fee`, `total` as `{value, scale}` tuples

---

## TR-NOC-4: GET /users/me/orders endpoint

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-7](business.md#br-noc-7-order-history-for-authenticated-users)*

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/dishly/v1/users/me/orders` | bearer | Return all orders for authenticated user, newest first |

**Constraints:**
- Returns 401 if no bearer token
- Orders sorted by `created_at DESC`
- Each order includes: `id`, `restaurant_name` (joined from restaurant table), `items` array, `subtotal`, `delivery_fee`, `total`, `status`, `created_at`
- Soft-deleted orders (`deleted_at IS NOT NULL`) excluded
- Response envelope: `{data: [...], pagination: {next: null}, meta}`

---

## TR-NOC-5: Cart state in localStorage

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-1](business.md#br-noc-1-single-restaurant-linear-checkout), [BR-NOC-2](business.md#br-noc-2-cart-persistence-across-navigation), [BR-NOC-3](business.md#br-noc-3-cart-conflict-resolution)*

Cart state is managed entirely in the browser via `localStorage`. No backend cart storage. The `useCart` React hook provides the cart interface to all components.

**Cart schema (localStorage key: `dishly_cart`):**
```json
{
  "restaurantId": "uuid | null",
  "restaurantName": "string",
  "items": [
    { "id": "menu_item_id", "name": "string", "price": {"value": 1600, "scale": 2}, "quantity": 1 }
  ]
}
```

**Constraints:**
- `useCart` emits a custom `dishly:cart-updated` window event after every state change so all mounted hook instances re-sync (navbar badge and checkout page stay in sync)
- Cart is cleared (`{restaurantId: null, restaurantName: '', items: []}`) on successful order confirmation
- Adding an item from a different `restaurantId` triggers `window.confirm()` before clearing
- Cart serialisation/deserialisation is wrapped in try/catch — malformed localStorage does not crash the app

---

## TR-NOC-6: Checkout page and order submission

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-1](business.md#br-noc-1-single-restaurant-linear-checkout), [BR-NOC-5](business.md#br-noc-5-test-mode-payment-in-wave-1), [BR-NOC-8](business.md#br-noc-8-failed-order-preserves-cart-and-shows-inline-error)*

`frontend/src/pages/Checkout.jsx` — linear single-page checkout (not multi-step in Wave 1).

**Constraints:**
- Reads cart from `useCart`; redirects to homepage if cart is empty
- Address input (`<input id="address">`) is required; minimum 5 characters enforced client-side before submission
- `payment_method_id` is hardcoded to `'pm_card_visa'` in Wave 1 (Stripe test card)
- On submit: checks for `dishly_token` in localStorage; if absent, navigates to `/login` with `returnTo: '/checkout'` state
- On success: calls `clearCart()` then navigates to `/orders/:id`
- On error: sets inline error state; re-enables submit button; does not clear cart
- No partial order in DB on failed submission — `POST /orders` returns an error before any DB write if validation fails

---

## TR-NOC-7: Order confirmation page

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-6](business.md#br-noc-6-order-confirmation-screen-with-simulated-eta)*

`frontend/src/pages/OrderConfirmation.jsx` — renders at `/orders/:id`.

**Constraints:**
- Calls `clearCart()` on component mount (belt-and-suspenders clear in case Checkout page didn't)
- Fetches `GET /orders/:id` with bearer token from localStorage
- Renders: success icon, "Order Confirmed!" heading, order number (first 8 chars of UUID), restaurant name, delivery address, itemised items, subtotal/delivery fee/total, and ETA banner ("30–40 minutes")
- Shows `<LoadingSpinner>` while fetching; `<ErrorMessage>` on API error
- Two CTAs: "Back to home" (`/`) and "View order history" (`/account/orders`)

---

## TR-NOC-8: Order history page

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-7](business.md#br-noc-7-order-history-for-authenticated-users)*

`frontend/src/pages/OrderHistory.jsx` — renders at `/account/orders`.

**Constraints:**
- Redirects to `/login` on mount if no `dishly_token` in localStorage
- Fetches `GET /users/me/orders` with bearer token
- On 401 response: redirects to `/login`
- Renders orders newest-first; each row shows: restaurant name, order date (ISO date slice), item chips, total, and "View details" link to `/orders/:id`
- Shows `<EmptyState>` with friendly message when no orders exist

---

## TR-NOC-9: Stripe SDK configuration

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-5](business.md#br-noc-5-test-mode-payment-in-wave-1)*

**Constraints:**
- Backend uses `stripe` npm package initialised with `process.env.STRIPE_SECRET_KEY` (must be a `sk_test_` key)
- `stripe.paymentIntents.create({ amount: totalValue, currency: 'usd', payment_method: payment_method_id, confirm: true })` called inside `POST /orders` before the DB transaction
- No Stripe live-mode key (`sk_live_`) may exist anywhere in the codebase or `.env` files
- Frontend does not use Stripe.js directly — payment field is a static mock UI in Wave 1; only the backend calls the Stripe API

---

## TR-CWD-1: React + Vite frontend stack

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-1, BR-CWD-6*

The consumer web app is a React single-page application built with Vite.

| Layer | Technology | Version constraint |
|-------|-----------|-------------------|
| UI framework | React | 18+ |
| Build tool | Vite | 5+ |
| Routing | React Router v6 | client-side only |
| HTTP client | native `fetch` via shared `api/client.js` | no axios |
| State | React `useState` / `useEffect` hooks | no Redux |

Constraints: No server-side rendering. All API calls go through `frontend/src/api/client.js`. Express backend serves `index.html` catch-all for all non-`/dishly/v1/` routes.

---

## TR-CWD-2: Client-side routing

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-1, BR-CWD-3, BR-CWD-4, BR-CWD-5*

React Router v6 defines all routes in `frontend/src/App.jsx`. Discovery routes (`/`, `/search`, `/restaurants/:id`) require no auth. Auth is checked only at `/checkout` submit and `/orders/:id`, `/account` routes.

---

## TR-CWD-3: Shared API hooks

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-1, BR-CWD-3, BR-CWD-4*

Custom React hooks in `frontend/src/api/hooks.js` encapsulate all data fetching: `useCollections()`, `useRestaurants(params)`, `useRestaurant(id)`, `useCuisines()`, `useNeighbourhoods()`. All hooks follow the `{ data, loading, error }` pattern from a shared `useApi(fetcher, deps)` base hook.

---

## TR-CWD-4: Shared UI components

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-1, BR-CWD-4, BR-CWD-7*

Shared presentational components in `frontend/src/components/`: `RestaurantCard`, `LoadingSpinner`, `ErrorMessage`, `EmptyState`, `NavBar`. `RestaurantCard` uses `onError` handler to show CSS placeholder on broken images.

---

## TR-CWD-5: Homepage collection filtering (client-side)

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-2*

Cuisine chip state managed in `Home.jsx` with `useState`. Filtering is client-side. Active chip state defaults to `'All'`. Chip click does NOT navigate — URL stays at `/`. `aria-pressed` reflects active state.

---

## TR-CWD-6: Search page

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-3*

`frontend/src/pages/Search.jsx` renders at `/search`. Query string `?q=` read via `useSearchParams()`. Filter state held in `useState`, applied as params to `useRestaurants()`. Empty state shown when `data.length === 0`.

---

## TR-CWD-7: Restaurant page

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-4, BR-CWD-8*

`frontend/src/pages/Restaurant.jsx` renders at `/restaurants/:id`. Hero uses `onError` fallback. Menu sections not collapsed by default on desktop; mobile collapse is CSS-driven. `formatPrice(value, scale)` converts integer price tuple to display string.

---

## TR-CWD-8: Responsive layout and design tokens

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-6*

CSS custom properties in `frontend/src/index.css`. Key tokens: `--color-primary: #8529CD`, `--color-accent: #FF0044`. Breakpoints: mobile < 768px (2-col), tablet 768–1099px (3-col), desktop 1100px+ (4-col). All buttons use `border-radius: 9999px`.

---

## TR-W1-1: Local-only infrastructure — no cloud, no Docker

*Graduated from: dishly-wave-1*

The entire Wave 1 stack runs locally. No cloud infrastructure, no containerisation, no remote services. All external API calls (Stripe, delivery) use test-mode credentials only.

---

## TR-W1-2: Technology stack

*Graduated from: dishly-wave-1*

| Layer | Technology | Notes |
|-------|-----------|-------|
| Frontend | React | Responsive web app |
| Backend | Node.js + Express/Fastify | REST API server |
| Database | SQLite | No separate DB process required |
| Auth | JWT in localStorage | No external auth provider |
| Payment | Stripe test mode | No live payment processing |

---

## TR-W1-3: Core data model (dishly-wave-1)

*Graduated from: dishly-wave-1*

**Restaurant**: id (UUID), name, cuisine_id (FK), neighbourhood_id (FK), description, address, price_range, cover_image_url, average_rating, delivery_radius_km

**Menu Section**: id, restaurant_id (FK), name, sort_order

**Menu Item**: id, section_id (FK), name, description, price (float), image_url, sort_order

**Review** (seeded, not user-submitted): id, restaurant_id (FK), author_name, rating (1–5), body, review_date

**Order**: id, user_id (FK), restaurant_id (FK), delivery_address (nullable), subtotal, delivery_fee ($3.99 flat), total, status ("confirmed"/"delivering"/"delivered"), created_at, deleted_at (soft delete)

**Order Item** (normalized — see ADR-002): id, order_id (FK), menu_item_id (FK), item_name (snapshot at order time), quantity, unit_price (snapshot at order time)

---

## TR-W1-4: Curated collections — static config

*Graduated from: dishly-wave-1*

Curated collections defined in `data/collections.json`. Loaded at server startup. Collections with zero matching live restaurants are not rendered on the homepage. Sort order determined by config file order.

---

## TR-W1-5: Search scope

*Graduated from: dishly-wave-1*

Search matches against `restaurant.name` and `menu_item.name` (LIKE query, case-insensitive). Results return restaurants only — a match on a menu item surfaces the parent restaurant. A restaurant appears once regardless of how many items matched. Neighbourhood filtering via `neighbourhood_id` UUID parameter.

---

## TR-W1-6: Seed data geography and distribution

*Graduated from: dishly-wave-1*

All 100 seeded restaurants are in New York City. Required: at least 5 distinct NYC neighbourhoods, 8–10 distinct cuisine types, roughly even spread across price ranges, ratings 3.5–5.0, minimum 3 menu sections per restaurant, 8 menu items per restaurant, 3 seeded reviews per restaurant.

---

## TR-W1-7: Cart persistence

*Graduated from: dishly-wave-1*

Cart state persisted in browser `localStorage`. Cart survives tab closes and refreshes. Cart is browser-local — not tied to a user account, not synced across devices. Cart cleared on successful order confirmation and when user starts a new restaurant's order (with confirmation prompt).

---

## TR-W1-8: Client-side routing (dishly-wave-1)

*Graduated from: dishly-wave-1*

Key routes: `/` (Homepage), `/search` (Search results with `?q=`), `/restaurants/:id` (Restaurant page), `/cart`, `/checkout`, `/orders/:id` (Order confirmation), `/account/orders` (Order history), `/login`, `/register`. Backend serves React bundle catch-all to `index.html` for all non-`/api/` routes.
