# Business Requirements: dishly

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Product / Effort: customer-profile-section*
*Last updated: 2026-06-07*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: Name collected at registration

**Priority:** P0

The business must ensure that customers can provide their name when creating an account. Providing a name must be optional; if omitted, the displayed identity falls back to the email prefix. The customer's name must be available for personalised display immediately after sign-in.

**Acceptance Criteria:**
- [ ] Registration accepts an optional customer name
- [ ] A customer who provides a name at registration sees that name displayed in the navigation after sign-in — no fallback to email prefix
- [ ] A customer who does not provide a name at registration sees their email prefix displayed in the navigation after sign-in
- [ ] The name persisted at registration is returned as part of the authenticated session

---

## BR-2: Personal info editing

**Priority:** P0

The business must provide customers with a dedicated account management area where they can view and update their name and phone number. This ensures profile data remains accurate over time without requiring customer support intervention.

**Acceptance Criteria:**
- [ ] A logged-in customer can view their current name and phone number in the account area
- [ ] A customer can update their name; the name field is required when saving (cannot be cleared to empty once set)
- [ ] A customer can update their phone number; the phone field is optional and accepts only digit characters between 7 and 15 characters long
- [ ] An invalid phone format is flagged before the save is accepted
- [ ] An updated name is reflected in the navigation display without requiring the customer to reload or re-navigate

---

## BR-3: Saved delivery addresses

**Priority:** P0

The business must allow each customer to save up to two delivery addresses on their profile — including the ability to add, edit, remove, and designate a default address. The default address must pre-fill the delivery destination at checkout to reduce re-entry friction.

**Acceptance Criteria:**
- [ ] A customer can add, edit, and delete delivery addresses from their account area
- [ ] Each address captures an optional label, street, city, and postcode as plain text (no address verification required)
- [ ] A customer cannot save more than two addresses; attempting to add a third results in a clear rejection
- [ ] A customer can designate one address as their default
- [ ] The default address is pre-populated as the delivery destination when the customer reaches checkout

---

## BR-4: Mock payment methods

**Priority:** P1

Customers can save up to two mock payment methods on their profile for local/demo use. No real card numbers or payment processing — card type and cardholder name only.

**Acceptance Criteria:**
- [ ] A customer can add, edit, and delete mock payment methods from their account area
- [ ] Each payment method requires a card type (Visa, Mastercard, or Amex) and a cardholder name
- [ ] A customer cannot save more than two payment methods; attempting to add a third results in a clear rejection
- [ ] Saved payment methods appear as selectable options at checkout alongside a "Pay on delivery" fallback — no real payment processing occurs

---

## BR-6: Dummy card entry at checkout

**Priority:** P0

The business must allow customers to enter a dummy card at checkout without first saving a payment method in their profile. The card is accepted for any plausible input and displayed for confirmation — no real charge is made.

**Acceptance Criteria:**
- [ ] A customer can choose to enter a card directly at checkout in addition to selecting a saved method or paying on delivery
- [ ] Entering a card requires a card number, expiry, and CVV; any plausible values are accepted
- [ ] The order confirmation acknowledges the card used (e.g. last four digits) without processing a real payment
- [ ] Card details entered at checkout are never transmitted to or stored by the payment backend

---

## BR-7: Quantity stepper on restaurant menu page

**Priority:** P0

The business must allow customers to add multiple units of the same dish directly from the restaurant menu page and see the current cart quantity reflected inline — without navigating away from the menu. The first selection adds the item; subsequent interactions adjust the quantity up or down.

**Acceptance Criteria:**
- [ ] A customer can add an item to their cart directly from the menu page
- [ ] After an item is added, the customer can increase or decrease the item quantity inline on the menu page
- [ ] Reducing quantity to zero removes the item from the cart and restores the original add affordance
- [ ] The cart item count visible in the navigation stays in sync with inline quantity changes without a page reload
- [ ] Behaviour is consistent whether the customer adds one or many units of the same dish

---

## BR-5: Authenticated name display after sign-in

**Priority:** P0

After signing in, the customer's name must be visible in the navigation to confirm their logged-in state. The avatar shows initials derived from the name; expanding it shows the full name and email.

**Acceptance Criteria:**
- [ ] A customer who has set a name sees initials derived from that name in the navigation avatar immediately after sign-in — no page reload required
- [ ] Expanding the avatar reveals the customer's full name and email address
- [ ] Name and email are visible without a page reload immediately after sign-in or registration

---

## BR-NOC-1: Single-restaurant linear checkout

*Graduated from: native-ordering-checkout*

**Priority:** P0

The business must ensure the end-to-end ordering flow is single-restaurant and linear — from restaurant selection through menu, cart review, delivery address, order summary, and confirmation. No multi-restaurant orders, no order scheduling, and no saved addresses are supported in Wave 1.

**Acceptance Criteria:**
- [ ] A cart contains items from one restaurant only; adding an item from a second restaurant requires the customer to confirm before any cart contents change
- [ ] Delivery address is entered manually at checkout on every order — no saved address book
- [ ] Delivery now only — no scheduled or future orders
- [ ] Payment by card only via test-mode processing — no alternative payment wallets
- [ ] Order summary shows itemised breakdown, delivery address, and estimated delivery time before the customer confirms

---

## BR-NOC-2: Cart persistence across navigation

*Graduated from: native-ordering-checkout*

**Priority:** P0

The business must ensure that a customer's in-progress cart is not lost due to page navigation, tab closure, or refresh — so that customers do not need to rebuild their order after accidental navigation.

**Acceptance Criteria:**
- [ ] Cart contents survive a full page reload and tab close/reopen
- [ ] Cart is cleared on successful order confirmation
- [ ] Cart is cleared (after customer confirmation) when the customer starts a new restaurant's order
- [ ] Cart is private to the browser session and not tied to a user account or synced across devices

---

## BR-NOC-3: Cart conflict resolution

*Graduated from: native-ordering-checkout*

**Priority:** P0

The business must ensure that a customer is explicitly warned before their in-progress cart is replaced by items from a different restaurant — so that no items are silently lost.

**Acceptance Criteria:**
- [ ] A confirmation prompt names the current cart's restaurant before any cart contents are cleared
- [ ] The customer can choose to keep the existing cart, leaving it unchanged
- [ ] The customer can choose to start a new order, which clears the cart and adds the new item
- [ ] No items are silently removed from the cart without the customer explicitly confirming

---

## BR-NOC-4: Auth gate at cart/checkout, not at browse

*Graduated from: native-ordering-checkout*

**Priority:** P0

The business must ensure that discovery and browsing are open to anonymous visitors, and that an account is required only at the point of ordering — so that the discovery experience is uninterrupted and the auth barrier is as low as possible.

**Acceptance Criteria:**
- [ ] Any visitor can browse the homepage, collections, search, restaurant pages, and menus without signing in
- [ ] An auth prompt appears only when an unauthenticated visitor attempts to add to cart or proceed to checkout
- [ ] After successful sign-in at the checkout gate, the customer's cart is intact and checkout resumes from the correct step
- [ ] No auth prompt appears on any discovery surface (homepage, search results, restaurant page)

---

## BR-NOC-5: Test-mode payment in Wave 1

*Graduated from: native-ordering-checkout*

**Priority:** P0

The business must ensure that Wave 1 payment processing operates exclusively in test mode — no real payment is charged to any customer during the closed beta.

**Acceptance Criteria:**
- [ ] Checkout accepts a payment method and processes it without charging a real card
- [ ] Every submitted order is persisted with a confirmed status after test-mode payment processing
- [ ] No real payment is charged to any card at any point in Wave 1
- [ ] No live payment processing credentials are present in any environment used during Wave 1

---

## BR-NOC-6: Order confirmation screen with simulated ETA

*Graduated from: native-ordering-checkout*

**Priority:** P0

The business must ensure that after a successful order submission, the customer receives a clear confirmation showing their order was received and providing a simulated delivery estimate — so that the customer has confidence the order is placed even though live courier dispatch is not yet operational.

**Acceptance Criteria:**
- [ ] A confirmation screen is shown after a successful order submission
- [ ] The screen shows: order number, restaurant name, delivery address, itemised order summary, subtotal, delivery fee, and total
- [ ] A simulated delivery estimate is displayed — e.g. "Your order is on its way — estimated 30–40 min"
- [ ] The customer's cart is cleared upon reaching the confirmation screen
- [ ] No real courier dispatch occurs at any point in Wave 1

---

## BR-NOC-7: Order history for authenticated users

*Graduated from: native-ordering-checkout*

**Priority:** P1

The business must ensure that authenticated customers can view a complete history of their past orders with sufficient detail to identify what was ordered and when.

**Acceptance Criteria:**
- [ ] A signed-in customer can access their order history and see all past orders newest-first
- [ ] Each order shows: restaurant name, order date, itemised list of items with quantities, and order total
- [ ] Unauthenticated access to the order history page redirects to sign-in
- [ ] Order history is private — a customer cannot access another customer's orders
- [ ] No reorder shortcut in Wave 1

---

## BR-NOC-8: Failed order preserves cart and shows inline error

*Graduated from: native-ordering-checkout*

**Priority:** P0

The business must ensure that if an order submission fails, the customer's cart is preserved and a clear, human-readable error is presented — so that the customer can retry without rebuilding their order.

**Acceptance Criteria:**
- [ ] A failed order submission does not clear the customer's cart
- [ ] An inline error message is displayed on the checkout page — not a full-page error
- [ ] The submit action is re-enabled after a failure so the customer can retry
- [ ] No partial order is recorded on a failed submission
- [ ] The error message is human-readable — not a raw status code or technical trace

---

## BR-8: Single-command local startup

**Priority:** P0

The business must ensure that any engineer with Node.js LTS installed can clone the
repository and have the full application running locally without manual setup, additional
installs, or configuration steps beyond having Node.js — so that onboarding friction is
eliminated and engineers can begin development immediately.

**Acceptance Criteria:**
- [ ] An engineer with only Node.js LTS installed can go from a fresh clone to a fully running local application using a single command
- [ ] Both the backend and frontend are accessible in a browser after the startup command completes
- [ ] Running the startup command multiple times does not corrupt data or result in duplicate or inconsistent state

---

## BR-9: Backend and frontend run as concurrent processes

**Priority:** P0

The business must ensure that the backend API service and the React frontend development
service run simultaneously from a single launch point, with output from each service
clearly attributed — so that engineers can monitor both services in a single terminal
session without additional tooling.

**Acceptance Criteria:**
- [ ] Both services become available from a single startup command with no manual steps required between them
- [ ] Output from each service is visually distinguishable by a label or prefix identifying the source service
- [ ] Stopping the launcher terminates both services cleanly without leaving residual background processes

---

## BR-10: Database seeded on first run

**Priority:** P0

The business must ensure that the local development database is automatically populated
with seed data on first run and that subsequent runs do not overwrite or duplicate that
data — so that engineers have a ready-to-use dataset without manual migration or seed
commands.

**Acceptance Criteria:**
- [ ] On first run, the database is created and seed data is loaded automatically
- [ ] On subsequent runs, the seed step is skipped without error and existing data is preserved
- [ ] The location of the database file is configurable without modifying source code

---

## BR-1: Anonymous discovery, account required at checkout

**Priority:** P0

Discovery and browsing are open to any visitor — no account required to explore
restaurants, view menus, or use search. An account is required only when a user
attempts to add an item to cart or proceed to checkout.

**Acceptance Criteria:**
- [ ] Any visitor can access homepage, search, restaurant pages, and menus without signing in
- [ ] An account gate appears when a user attempts to add to cart or proceed to checkout
- [ ] After signing in at the checkout gate, the user's cart is preserved and checkout continues without restarting

---

## BR-2: Email/password registration and login

**Priority:** P0

The business must provide a secure account creation and sign-in mechanism using email and password — so that users can authenticate and access order functionality without requiring a third-party identity provider.

**Acceptance Criteria:**
- [ ] Registration with a valid email and password of sufficient length creates an account and issues a session credential
- [ ] Registration with an already-registered email is rejected with a clear conflict message
- [ ] Sign-in with correct credentials grants access and issues a session credential
- [ ] Sign-in with incorrect credentials is rejected with an error that does not reveal which field (email or password) was wrong

---

## BR-3: No password reset

**Priority:** P0

Password reset is explicitly out of scope for Wave 1. No "forgot password" flow,
no email sending, no reset tokens.

**Acceptance Criteria:**
- [ ] No "forgot password" link or UI exists anywhere in the product
- [ ] No email infrastructure (SMTP, transactional email) is built or configured

---

## BR-4: Order history visible to authenticated user only

**Priority:** P1

The business must ensure that a signed-in user can view their own past orders, and that order history is private — no user can access another user's orders.

**Acceptance Criteria:**
- [ ] Order history is accessible only to signed-in users; unauthenticated visitors are redirected to sign in
- [ ] A user can only retrieve orders they placed — attempts to access another user's orders are denied

---

## BR-CBA-1: Restaurant search and browsing API

**Priority:** P0

The business must provide consumers with the ability to search and filter restaurants by keyword, cuisine type, neighbourhood, and price range — so that consumers can discover relevant options without friction.

**Acceptance Criteria:**
- [ ] Consumers can retrieve a list of restaurant summaries suitable for card display
- [ ] Keyword search matches against restaurant name and menu item names, case-insensitively
- [ ] Results can be filtered by cuisine type, neighbourhood, and price range, individually or in combination
- [ ] A restaurant appears once in results regardless of how many of its menu items matched the keyword
- [ ] Result sets are capped at 100 restaurants for Wave 1

---

## BR-CBA-2: Restaurant detail API

**Priority:** P0

The business must provide consumers with access to the full detail of any restaurant — including its menu and reviews — so that consumers can make an informed decision before ordering.

**Acceptance Criteria:**
- [ ] Consumers can retrieve full restaurant detail including name, cuisine, neighbourhood, price range, rating, description, address, and cover image
- [ ] The menu is presented grouped by sections, with each item showing name, description, price, and a photo
- [ ] Up to 5 seeded reviews are included, each showing author name, rating, text, and date
- [ ] Requesting detail for a restaurant that does not exist returns a clear not-found response

---

## BR-CBA-3: Curated collections API

**Priority:** P0

The business must expose curated restaurant collections defined by editorial staff — so that the homepage can surface themed groupings that drive discovery and engagement.

**Acceptance Criteria:**
- [ ] All collections are available to the frontend in the order defined by the editorial config
- [ ] Collections with zero matching live restaurants are excluded from the response
- [ ] A single collection and its embedded restaurants can be retrieved by collection identifier
- [ ] Requesting a collection that does not exist returns a clear not-found response

---

## BR-CBA-4: Cuisine and neighbourhood lookup APIs

**Priority:** P0

The business must provide consumers with discoverable lists of all available cuisine types and neighbourhoods — so that filter options can be populated accurately and kept in sync with the live catalogue.

**Acceptance Criteria:**
- [ ] The full list of cuisine types available in the catalogue is accessible, returned in alphabetical order
- [ ] The full list of neighbourhoods available in the catalogue is accessible, returned in alphabetical order

---

## BR-CBA-5: Seeded restaurant supply

**Priority:** P0

The business must launch Wave 1 with 100 seeded NYC restaurants that represent authentic variety in cuisine, neighbourhood, and price — so that the platform appears credible and well-stocked from day one.

**Acceptance Criteria:**
- [ ] 100 restaurants are present in the catalogue after a fresh environment setup, spanning >=5 NYC neighbourhoods, >=8 cuisine types, and a spread of $\/$$\/$$$ price ranges
- [ ] Every restaurant has >=3 menu sections, >=8 menu items each with a photo, and >=3 reviews
- [ ] All restaurant ratings are >=3.5 — no low-rated restaurants appear in the curated seed data
- [ ] No ranking weight or paid placement field exists in the catalogue schema

---

## BR-CBA-6: No user-submitted reviews

**Priority:** P0

The business must ensure that reviews in Wave 1 are curated seed data only — no consumer-submitted reviews are accepted — to maintain quality and trust during the closed beta.

**Acceptance Criteria:**
- [ ] No review submission capability is available to consumers in Wave 1 — neither via the API nor any UI surface

---

## BR-LOC-1: Location-relevant restaurant catalogue without schema change

*Graduated from: add-location-based-filtering*

**Priority:** P0

dishly must serve each customer a restaurant catalogue scoped to their location using the existing data model — so that non-NYC customers see relevant results and the business can expand to new cities without a database migration.

**Acceptance Criteria:**
- [ ] A customer in any supported city sees only restaurants associated with that city when they apply a location filter
- [ ] Existing NYC customers experience no change to their current browsing results
- [ ] New city entries are available in the location catalogue alongside existing neighbourhoods

---

## BR-LOC-2: Customer-controlled location filtering on every search surface

*Graduated from: add-location-based-filtering*

**Priority:** P0

Customers must be able to select or change their city at any point during a search session — so that location filtering is always accessible and city preference is not lost between visits.

**Acceptance Criteria:**
- [ ] A customer can select a city from any search surface and immediately receive location-filtered restaurant results
- [ ] A customer can clear their city selection and return to all-city results
- [ ] A customer's city preference is available when they return to the app in a new session, and is removed when they sign out

---

## BR-LOC-3: Automatic city detection as an alternative to manual selection

*Graduated from: add-location-based-filtering*

**Priority:** P0

Customers must be able to have their city identified automatically based on their physical location — so that they do not need to know which city to select and can begin browsing relevant results immediately.

**Acceptance Criteria:**
- [ ] A customer who consents to share their location has their city identified and applied as a filter without manual input
- [ ] A customer whose location cannot be determined receives a clear prompt to select their city manually
- [ ] Automatic city detection covers all six supported cities

---

## BR-LOC-4: Multi-city restaurant catalogue with authentic local coverage

*Graduated from: add-location-based-filtering*

**Priority:** P0

dishly must offer a credible, locally relevant restaurant catalogue in at least 5 new US cities — so that the app is useful to customers outside New York and the business can acquire users in those markets.

**Acceptance Criteria:**
- [ ] At least 20 restaurants are available per new city at launch
- [ ] Restaurant names, cuisine types, and descriptions reflect the local food culture of each city
- [ ] The expanded catalogue does not affect or overwrite existing NYC restaurant data

---

## BR-W1-1: Unified discovery-to-delivery experience

*Graduated from: dishly-wave-1*

**Priority:** P0

Quality-conscious consumers who order food delivery 2–4× per week have no trustworthy discovery surface. Incumbent platforms rank results by paid placement and margin, not food quality — forcing consumers to use 2–3 apps to complete a single meal decision. dishly solves this as a single, continuous experience.

**Acceptance criteria:**
- A user can open dishly, discover a restaurant through curated content or search, and complete a food delivery order without leaving the app
- At no point in the flow is the user redirected to a third-party ordering interface
- Discovery entry points (curated collections, search results, editorial content) all lead directly to a restaurant page with a native order flow

---

## BR-W1-2: Target user

*Graduated from: dishly-wave-1*

**Priority:** P0

The primary user is a quality-conscious urban consumer aged 22–40 who orders food delivery multiple times per week.

**Acceptance criteria:**
- Product decisions are evaluated against whether they serve this user's expectation of quality and discovery, not maximising order volume
- The onboarding flow is tuned for this demographic

---

## BR-W1-3: Earned curation standard

*Graduated from: dishly-wave-1*

**Priority:** P0

Every restaurant listed on dishly must pass an internal curation review before appearing to consumers. Paid placement is permanently excluded as a ranking or listing mechanism.

**Acceptance criteria:**
- No restaurant appears on any consumer-facing surface before passing a curation review
- There is no mechanism in the product to accept payment for placement or ranking

---

## BR-W1-4: Seeded restaurant supply for Wave 1

*Graduated from: dishly-wave-1*

**Priority:** P0

Wave 1 launches with a mock data seed of 100 restaurants covering a realistic spread of cuisine types and price points.

**Acceptance criteria:**
- 100 seeded restaurants are available at launch with complete menus (items with photos and descriptions)
- The ordering and delivery flow works end-to-end against seeded restaurants

---

## BR-W1-5: Simulated delivery for Wave 1

*Graduated from: dishly-wave-1*

**Priority:** P0

Wave 1 uses simulated delivery — no real courier is dispatched. After order confirmation, the product displays a mocked delivery tracking state.

**Acceptance criteria:**
- After order confirmation, a simulated delivery status is shown (e.g. "estimated delivery 30–40 min")
- No real courier is dispatched for any Wave 1 order
- The delivery integration layer can be replaced with a live partner integration in Wave 2 without a full rebuild

---

## BR-W1-6: Wave 1 success criteria (MVP)

*Graduated from: dishly-wave-1*

**Priority:** P0

Wave 1 is a closed beta. Launch gates: 100 seeded restaurants live; full discover→order flow functional; app usable on Chrome and Safari; no data loss on order submission.

---

## BR-W1-7: Reviews display

*Graduated from: dishly-wave-1*

**Priority:** P1

Restaurant pages show seeded reviews (3–5 snippets, average rating). No user-submitted reviews in Wave 1.

---

## BR-W1-8: Restaurant page layout

*Graduated from: dishly-wave-1*

**Priority:** P1

The restaurant page shows: hero image, name/cuisine/price/rating, description, full menu grouped by section with inline add-to-cart, and review snippets.

---

## BR-CWD-1: Homepage with curated collections and search bar

*Graduated from: consumer-web-discovery*

**Priority:** P0

The homepage is the primary editorial entry point. It renders curated restaurant collections (e.g. "Best Ramen in the City", "New Openings", "Under $15") with a prominent search bar. Collections are loaded from the backend and each contains restaurant cards with cover photo, name, cuisine, neighbourhood, price range, and average rating.

**Acceptance Criteria:**
- [ ] Homepage renders ≥1 curated collection with restaurant cards on page load with no auth required
- [ ] Each restaurant card shows: cover image, name, cuisine type, neighbourhood, price range, and star rating
- [ ] A prominent search bar is visible above or within the hero section
- [ ] Clicking a restaurant card navigates to the restaurant page
- [ ] Empty or zero-restaurant collections are not rendered

---

## BR-CWD-2: Cuisine filter chips on homepage

*Graduated from: consumer-web-discovery*

**Priority:** P0

The homepage provides cuisine-type filter chips (e.g. All, Ramen, Thai, Pizza, Indian) that filter the displayed collections in-place without navigating away. Selecting a chip narrows the visible restaurants to those matching that cuisine; selecting "All" resets the view.

**Acceptance Criteria:**
- [ ] Cuisine chips are visible below the hero search bar on the homepage
- [ ] Clicking a chip filters the collections grid to matching restaurants without a page navigation
- [ ] The active chip has a visually distinct state (e.g. filled background)
- [ ] Selecting "All" restores the full unfiltered collections view
- [ ] URL does not change when a chip is selected

---

## BR-CWD-3: Search results page with keyword search and filters

*Graduated from: consumer-web-discovery*

**Priority:** P0

The search results page (`/search?q=`) displays restaurants matching a keyword query. Inline filter chips for cuisine type and price range allow narrowing results. Results show as a list with thumbnail image, name, cuisine, neighbourhood, rating, and price range.

**Acceptance Criteria:**
- [ ] Typing in the search bar and submitting navigates to `/search?q=<query>`
- [ ] Results show restaurants whose name or menu item names match the query (case-insensitive)
- [ ] Cuisine type and price range filter chips are visible and functional above the result list
- [ ] Each result row shows: thumbnail image, name, cuisine, neighbourhood, rating, and price range
- [ ] An empty state message is shown when no results match: "No restaurants found for '[query]'"
- [ ] A result count label is visible above the result list

---

## BR-CWD-4: Restaurant page — full layout with hero, menu, and reviews

*Graduated from: consumer-web-discovery*

**Priority:** P0

The restaurant page is the primary decision surface. It renders: full-width hero image, restaurant name/cuisine/price/rating/description, a full menu grouped by section with item photos and "Add to cart" buttons, and 3–5 seeded review snippets.

**Acceptance Criteria:**
- [ ] Hero image renders full-width at the top of the page; broken URL shows a placeholder
- [ ] Restaurant name, cuisine type, price range, and average star rating are visible below the hero
- [ ] Short restaurant description and address are displayed
- [ ] Menu is grouped by named sections (e.g. Starters, Mains, Desserts)
- [ ] Each menu item shows: name, description, price, photo (or placeholder), and an "Add to cart" button
- [ ] 3–5 seeded review snippets are displayed with author name, star rating, text, and date
- [ ] Menu sections are collapsible on mobile viewport widths

---

## BR-CWD-5: Anonymous discovery — no auth gate on browse

*Graduated from: consumer-web-discovery*

**Priority:** P0

Any visitor can browse the full discovery surface without signing in. No account prompt, modal, or gate appears on the homepage, search results, or restaurant page. The auth gate fires only when a user attempts to add an item to cart or proceed to checkout.

**Acceptance Criteria:**
- [ ] Homepage, search results, and restaurant pages load fully for unauthenticated users
- [ ] No sign-in modal, banner, or redirect appears on any discovery surface
- [ ] Authenticated and unauthenticated users see identical discovery content
- [ ] The only surface that requires auth is the add-to-cart / checkout action

---

## BR-CWD-6: Responsive web — desktop and mobile

*Graduated from: consumer-web-discovery*

**Priority:** P0

The consumer web app is a responsive web application accessible from any modern browser. It must be fully functional and visually correct on both desktop and mobile browser widths.

**Acceptance Criteria:**
- [ ] All three discovery surfaces (homepage, search, restaurant page) are usable at 1440px desktop and 390px mobile viewport widths
- [ ] Restaurant card grids reflow correctly: 4-column on desktop, 2-column on tablet, 1-column on mobile
- [ ] No horizontal scroll or layout overflow at any tested viewport width
- [ ] Touch targets are ≥44×44px on mobile for all interactive elements

---

## BR-CWD-7: Error states for discovery surfaces

*Graduated from: consumer-web-discovery*

**Priority:** P0

Discovery surfaces handle error and empty states gracefully. No blank page, unhandled JS error, or broken layout is shown to users when data is unavailable or a query returns no results.

**Acceptance Criteria:**
- [ ] Search with no matching results shows a friendly empty state with a "Browse collections" CTA
- [ ] A restaurant page with no menu items shows "Menu coming soon" placeholder — not a blank section
- [ ] A broken restaurant cover image URL shows a placeholder graphic — not a broken img icon
- [ ] API errors (failed fetch) show a human-readable error message, not a raw status code

---

## BR-CWD-8: Cart state initiated from restaurant page

*Graduated from: consumer-web-discovery*

**Priority:** P0

The business must ensure that a visitor can initiate a cart from the restaurant page and carry that cart into the checkout flow — so that order intent captured during discovery is not lost. Unauthenticated users who express intent to order must be prompted to sign in, after which their selected items are preserved.

**Acceptance Criteria:**
- [ ] Each menu item's "Add to cart" button adds the item to a persistent cart that survives page navigation
- [ ] Adding an item from a different restaurant than the current cart prompts a conflict confirmation
- [ ] The cart item count is visible in the navigation and updates when items are added
- [ ] Unauthenticated users who attempt to add to cart are prompted to sign in; their selected items are preserved after authentication
