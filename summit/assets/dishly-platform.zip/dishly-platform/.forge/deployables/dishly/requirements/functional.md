# Functional Requirements — Customer Profile Section

<!-- graduated-from: dishly-wave-1 at 2026-06-08T03:44:50Z -->

*Effort: customer-profile-section*
*Elaborated from: [business.md](business.md)*
*Created: 2026-06-07*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: Accept optional name at registration

*Traces to: [BR-1](business.md#br-1-name-collected-at-registration)*

The system must accept an optional name field during customer registration and persist it on the customer record. When no name is provided, the system must fall back to the customer's email prefix for display purposes.

---

## FR-2: Return name in authenticated session response

*Traces to: [BR-1](business.md#br-1-name-collected-at-registration)*

The system must include the customer's persisted name in the response returned on successful login and registration, so that the client can display it immediately without a subsequent request.

---

## FR-3: Display customer name in navigation after sign-in

*Traces to: [BR-5](business.md#br-5-authenticated-name-display-after-sign-in)*

The system must render the customer's initials (derived from the persisted name, or the email prefix if no name is set) in the navigation avatar immediately after sign-in or registration — without requiring a page reload. Expanding the avatar must display the customer's full name and email address.

---

## FR-4: Expose account management area for personal info

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

The system must provide an authenticated account area where the customer can view and update their name and phone number. The name field must be required when saving (cannot be cleared to empty once set). The phone field must be optional and validated as digits only, between 7 and 15 characters.

---

## FR-5: Reject invalid phone format before save

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

When a customer submits an invalid phone number format, the system must surface an inline validation error and prevent the save from proceeding until the value is corrected.

---

## FR-6: Reflect updated name in navigation without reload

*Traces to: [BR-2](business.md#br-2-personal-info-editing)*

After a customer successfully updates their name on the account page, the system must update the name displayed in the navigation avatar and dropdown without requiring a page reload.

---

## FR-7: Add, edit, and delete delivery addresses

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses)*

The system must allow a logged-in customer to create, update, and delete delivery addresses from their account area. Each address must capture an optional label, street, city, and postcode as plain text.

---

## FR-8: Enforce maximum of two saved addresses

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses)*

The system must prevent a customer from saving more than two delivery addresses. When the limit is reached, any attempt to add a further address must be rejected with a clear message.

---

## FR-9: Pre-fill checkout delivery field with default address

*Traces to: [BR-3](business.md#br-3-saved-delivery-addresses)*

When a logged-in customer with a saved default address reaches checkout, the system must pre-populate the delivery destination field with that address. When no default address exists, the field must be left empty. The customer must be able to override the pre-filled value before placing the order.

---

## FR-10: Add, edit, and delete mock payment methods

*Traces to: [BR-4](business.md#br-4-mock-payment-methods)*

The system must allow a logged-in customer to create, update, and delete mock payment methods from their account area. Each method must capture a card type (Visa, Mastercard, or Amex) and a cardholder name.

---

## FR-11: Enforce maximum of two saved payment methods

*Traces to: [BR-4](business.md#br-4-mock-payment-methods)*

The system must prevent a customer from saving more than two payment methods. When the limit is reached, any attempt to add a further payment method must be rejected with a clear message.

---

## FR-12: Display saved payment methods as options at checkout

*Traces to: [BR-4](business.md#br-4-mock-payment-methods)*

The system must render a logged-in customer's saved payment methods as selectable options at checkout, alongside a "Pay on delivery" fallback. No real payment processing must occur when a saved method is selected.

---

## FR-13: Accept dummy card entry at checkout

*Traces to: [BR-6](business.md#br-6-dummy-card-entry-at-checkout)*

The system must offer an option for the customer to enter a card directly at checkout without having previously saved a payment method. The system must accept any plausible card number, expiry, and CVV values. Card details entered at checkout must not be transmitted to or stored by any payment backend.

---

## FR-14: Show card acknowledgement on order confirmation

*Traces to: [BR-6](business.md#br-6-dummy-card-entry-at-checkout)*

When a customer completes checkout using a directly entered card, the order confirmation must acknowledge the card used (e.g. last four digits of the entered number) without performing real payment processing.

---

## FR-15: Inline quantity stepper on menu page

*Traces to: [BR-7](business.md#br-7-quantity-stepper-on-restaurant-menu-page)*

The system must display an add-to-cart affordance for each dish on the restaurant menu page. After the first add, the system must replace the affordance with an inline quantity control allowing the customer to increment or decrement the item quantity. Decrementing to zero must remove the item from the cart and restore the original add affordance.

---

## FR-16: Sync navigation cart count with inline quantity changes

*Traces to: [BR-7](business.md#br-7-quantity-stepper-on-restaurant-menu-page)*

When a customer adjusts item quantity using the inline stepper on the menu page, the system must update the cart item count displayed in the navigation in real time — without requiring a page reload.

---

## FR-17: Single startup command installs dependencies and starts all services

*Traces to: [BR-8](business.md#br-8-single-command-local-startup)*

The system must provide a single executable entry point at the repository root that, when invoked, installs all required dependencies and starts both the backend and frontend services without any additional manual steps.

---

## FR-18: Startup command is idempotent

*Traces to: [BR-8](business.md#br-8-single-command-local-startup)*

The system must allow the startup command to be invoked multiple times in succession without corrupting data, creating duplicate records, or failing due to previously installed dependencies or an already-initialised database.

---

## FR-19: Backend and frontend launched as concurrent processes from a single command

*Traces to: [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes)*

The system must start the backend API service and the frontend development server as concurrent processes from a single invocation, without requiring the operator to open separate terminal sessions or run additional commands.

---

## FR-20: Service output labeled by source in the shared terminal

*Traces to: [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes)*

The system must prefix each line of log output with a label identifying whether it originates from the backend or the frontend service, so that interleaved output remains distinguishable.

---

## FR-21: Launcher termination stops both services cleanly

*Traces to: [BR-9](business.md#br-9-backend-and-frontend-run-as-concurrent-processes)*

When the launcher process receives a termination signal, the system must propagate that signal to both the backend and frontend processes and wait for them to exit before the launcher itself exits, leaving no orphaned processes.

---

## FR-22: Database initialised and seeded on first run

*Traces to: [BR-10](business.md#br-10-database-seeded-on-first-run)*

On first invocation, the system must create the database file, apply the schema, and load the seed dataset automatically as part of the startup sequence — before the backend service begins accepting requests.

---

## FR-23: Seed step skipped when database already exists

*Traces to: [BR-10](business.md#br-10-database-seeded-on-first-run)*

On subsequent invocations, the system must detect that the database has already been initialised and skip the seed step without error, preserving any existing data unchanged.

---

## FR-24: Database file location configurable via environment variable

*Traces to: [BR-10](business.md#br-10-database-seeded-on-first-run)*

The system must read the database file path from an environment variable at startup. When the variable is not set, the system must use a documented default path within the repository.

---

## FR-NOC-1: Enforce single-restaurant cart constraint

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-1](business.md#br-noc-1-single-restaurant-linear-checkout)*

The system must prevent a cart from holding items from more than one restaurant at any time. When a customer attempts to add an item from a restaurant that differs from the restaurant of items already in the cart, the system must present a conflict resolution prompt before making any cart mutation.

---

## FR-NOC-2: Linear checkout flow with required address and order summary

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-1](business.md#br-noc-1-single-restaurant-linear-checkout)*

The system must enforce a sequential checkout flow — cart review, delivery address entry, order summary, and confirmation — where each step must be completed before advancing. The delivery address field must be required, and an itemised order summary (items, delivery fee, total, estimated delivery time) must be presented before the customer can confirm the order.

---

## FR-NOC-3: Persist cart state across page navigation and tab closure

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-2](business.md#br-noc-2-cart-persistence-across-navigation)*

The system must persist cart contents across page reloads, tab closures, and in-app navigation so that a customer's in-progress order is not lost. The cart must be cleared automatically upon successful order confirmation.

---

## FR-NOC-4: Clear cart on new-restaurant selection after customer confirmation

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-2](business.md#br-noc-2-cart-persistence-across-navigation), [BR-NOC-3](business.md#br-noc-3-cart-conflict-resolution)*

The system must clear the cart and apply the new item only after the customer has explicitly confirmed they wish to start a new order. Prior to confirmation, the existing cart must remain unchanged.

---

## FR-NOC-5: Cart conflict modal naming the current restaurant

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-3](business.md#br-noc-3-cart-conflict-resolution)*

The system must display a conflict prompt that names the restaurant associated with the current cart when the customer attempts to add an item from a different restaurant. The prompt must present two explicit choices: keep the existing cart (no mutation) or start a new order (clear and add new item).

---

## FR-NOC-6: Allow unauthenticated browsing of all discovery surfaces

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-4](business.md#br-noc-4-auth-gate-at-cartcheckout-not-at-browse)*

The system must serve the homepage, search results, restaurant pages, and menu pages to unauthenticated visitors without triggering any authentication requirement.

---

## FR-NOC-7: Trigger auth gate on add-to-cart or checkout for unauthenticated visitors

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-4](business.md#br-noc-4-auth-gate-at-cartcheckout-not-at-browse)*

The system must require authentication when an unauthenticated visitor attempts to add an item to the cart or proceed to checkout. After successful authentication, the system must restore the customer's cart state and resume checkout without requiring the customer to repeat completed steps.

---

## FR-NOC-8: Process payment in test mode and persist confirmed order

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-5](business.md#br-noc-5-test-mode-payment-in-wave-1)*

The system must process all Wave 1 payments using test-mode payment processing only. Upon successful test-mode payment processing, the system must persist the order with a confirmed status. The system must not issue any live payment charges.

---

## FR-NOC-9: Render order confirmation screen with simulated ETA

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-6](business.md#br-noc-6-order-confirmation-screen-with-simulated-eta)*

After a successful order submission, the system must render a confirmation screen displaying the order number, restaurant name, delivery address, itemised order summary (items, quantities, prices), subtotal, delivery fee, total, and a static simulated delivery estimate. The system must clear the customer's cart upon rendering the confirmation screen.

---

## FR-NOC-10: Serve authenticated order history newest-first

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-7](business.md#br-noc-7-order-history-for-authenticated-users)*

The system must provide an order history view that is accessible only to authenticated customers. The view must list all orders belonging to the authenticated customer in reverse chronological order, showing restaurant name, order date, itemised items with quantities, and order total. Unauthenticated access must redirect to sign-in. Requests for another customer's orders must be denied.

---

## FR-NOC-11: Preserve cart and surface inline error on failed order submission

*Graduated from: native-ordering-checkout*
*Traces to: [BR-NOC-8](business.md#br-noc-8-failed-order-preserves-cart-and-shows-inline-error)*

When an order submission fails for any reason (validation error, server error, or network failure), the system must preserve the customer's cart unchanged, display a human-readable inline error message on the checkout page, and re-enable the submit action so the customer can retry. The system must not persist any partial order record on a failed submission.

---

## FR-1: Discovery routes accessible without authentication

*Traces to: BR-1 (Anonymous discovery, account required at checkout)*

The system must allow unauthenticated requests to all discovery routes (homepage, search, restaurant listing, restaurant detail, and menu endpoints) without requiring any credential.

---

## FR-2: Auth gate triggered at cart and checkout

*Traces to: BR-1 (Anonymous discovery, account required at checkout)*

When an unauthenticated user attempts to add an item to cart or proceed to checkout, the system must interrupt the action and present an authentication prompt. After successful sign-in, the system must resume the interrupted action without loss of cart state.

---

## FR-3: User registration with email and password

*Traces to: BR-2 (Email/password registration and login)*

The system must accept a registration request with an email address and password, validate that the email is not already registered and the password meets minimum length, persist the new account, and return a session credential on success.

---

## FR-4: Duplicate email registration rejected

*Traces to: BR-2 (Email/password registration and login)*

When a registration request is submitted with an email address that already exists in the system, the system must reject the request and return a conflict error with a human-readable message.

---

## FR-5: User sign-in with email and password

*Traces to: BR-2 (Email/password registration and login)*

The system must accept a sign-in request with an email and password, verify the credentials, and return a session credential on success. On failure, the system must return an authentication error that does not indicate whether the email or password was incorrect.

---

## FR-6: Order endpoints protected by authentication

*Traces to: BR-4 (Order history visible to authenticated user only)*

The system must reject requests to order creation and order retrieval endpoints that do not include a valid session credential, returning an unauthorized error.

---

## FR-7: Order history scoped to the authenticated user

*Traces to: BR-4 (Order history visible to authenticated user only)*

When an authenticated user requests order history, the system must return only orders belonging to that user. Requests attempting to access another user's orders must be denied.

---

## FR-CBA-1: Return paginated restaurant summaries for browse and search

*Traces to: BR-CBA-1*

The system must return a list of restaurant summaries in response to a browse or search request, including at minimum the restaurant name, cuisine, neighbourhood, price range, rating, and cover image URL. The list must be hard-capped at 100 results for Wave 1.

---

## FR-CBA-2: Filter restaurant results by keyword

*Traces to: BR-CBA-1*

When a keyword query parameter is provided, the system must return only restaurants whose name or any menu item name contains the keyword, case-insensitively. Each matching restaurant must appear exactly once in the result set regardless of how many menu items matched.

---

## FR-CBA-3: Filter restaurant results by cuisine, neighbourhood, and price range

*Traces to: BR-CBA-1*

The system must support filtering restaurant results by cuisine type, neighbourhood, and price range. Filters must be composable — when multiple filter parameters are provided, only restaurants satisfying all conditions simultaneously must be returned.

---

## FR-CBA-4: Return full restaurant detail including menu and reviews

*Traces to: BR-CBA-2*

When a valid restaurant identifier is provided, the system must return the complete restaurant record: name, cuisine, neighbourhood, price range, average rating, description, address, cover image URL, all menu sections with their items (name, description, price, image URL), and up to 5 seeded reviews (author name, rating, text, date).

---

## FR-CBA-5: Return a not-found response for unknown restaurant identifiers

*Traces to: BR-CBA-2*

When a restaurant detail request is made with an identifier that does not correspond to any existing restaurant, the system must return a structured not-found error response rather than an empty or malformed result.

---

## FR-CBA-6: Return all curated collections in editorial order

*Traces to: BR-CBA-3*

The system must return all curated collections defined in the editorial config file, in the order they are defined. Each collection must include its embedded restaurant summaries. Collections with zero matching live restaurants must be excluded from the response.

---

## FR-CBA-7: Return a single collection by identifier

*Traces to: BR-CBA-3*

The system must return a single collection record with its embedded restaurant summaries when a valid collection identifier is provided. When the identifier is unknown, the system must return a structured not-found error response.

---

## FR-CBA-8: Return all cuisine types in alphabetical order

*Traces to: BR-CBA-4*

The system must return the complete list of cuisine types present in the restaurant catalogue, sorted alphabetically.

---

## FR-CBA-9: Return all neighbourhoods in alphabetical order

*Traces to: BR-CBA-4*

The system must return the complete list of neighbourhoods present in the restaurant catalogue, sorted alphabetically.

---

## FR-CBA-10: Seed the database with 100 NYC restaurants on first run

*Traces to: BR-CBA-5*

The system must populate the database with 100 NYC restaurants when the environment is set up from a fresh clone. The seed data must span at least 5 NYC neighbourhoods, at least 8 cuisine types, and a spread of $/$$/$$$ price ranges. Every restaurant must have at least 3 menu sections, at least 8 menu items each with a photo URL, and at least 3 reviews. No seeded restaurant may have a rating below 3.5.

---

## FR-CBA-11: Seed script must be idempotent

*Traces to: BR-CBA-5*

The system must detect whether restaurant seed data already exists before inserting. If restaurants are already present, the seed step must be skipped so that running the setup script multiple times produces exactly 100 restaurants — never duplicates. Seed errors must be surfaced explicitly and not silently swallowed.

---

## FR-CBA-12: Wrap all API responses in a consistent envelope

*Traces to: BR-CBA-1, BR-CBA-2, BR-CBA-3, BR-CBA-4*

All successful API responses must use a `{data, meta}` envelope structure. All error responses must use a `{errors, meta}` envelope structure. No endpoint may return a raw array or plain object outside the envelope.

---

## FR-CBA-13: All read endpoints accessible without authentication

*Traces to: BR-CBA-1, BR-CBA-2, BR-CBA-3, BR-CBA-4*

The system must not require an authorization credential to access any read-side discovery endpoint. Requests without an Authorization header must receive normal data responses, not authentication errors.

---

## FR-CBA-14: No review submission endpoint exposed

*Traces to: BR-CBA-6*

The system must not expose any endpoint that accepts review creation, update, or deletion requests. Review data is read-only and seeded only.

---

## FR-W1-1: Anonymous browsing of discovery surfaces

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-1*

The system must allow any unauthenticated user to access the homepage, curated collections, search, restaurant pages, and menus in full without requiring sign-in.

---

## FR-W1-2: Account gate at cart action

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-1*

When an unauthenticated user attempts to add an item to the cart or proceed to checkout, the system must present a sign-in or sign-up prompt. After successful authentication, the system must resume the cart action without requiring the user to restart.

---

## FR-W1-3: Homepage curated collections

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-9 (discovery surfaces)*

The system must render a homepage displaying one or more named curated restaurant collections. Collection content must be driven by a configuration source that can be updated without a code deployment.

---

## FR-W1-4: Keyword search with cuisine filter

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-9 (discovery surfaces)*

The system must provide a keyword search that matches restaurants by name or cuisine type. Search results must support filtering by cuisine type and price range. When a search returns no results, the system must display an explicit empty-state message.

---

## FR-W1-5: Restaurant page with full menu

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-13 (restaurant page layout)*

The system must render a restaurant page containing: cover photo (with placeholder fallback on load failure), restaurant name, cuisine type, price range, average star rating, short description, a full menu grouped by section, and review snippets. Each menu item must show name, description, price, photo, and an inline add-to-cart action.

---

## FR-W1-6: Single-restaurant cart with conflict prompt

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-10 (ordering flow)*

The system must enforce a single-restaurant cart. When a user adds an item from a restaurant different from the one currently in the cart, the system must display a confirmation prompt before clearing the existing cart.

---

## FR-W1-7: Linear checkout flow with manual address entry

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-10 (ordering flow)*

The system must provide a checkout flow in the sequence: cart → manual delivery address entry → order summary → confirm. The order summary must display an itemised breakdown, the entered delivery address, and a simulated delivery estimate.

---

## FR-W1-8: Test-mode card payment at checkout

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-5 (simulated delivery)*

The system must accept card payment at checkout using a test-mode payment processor. No live charges must be made during Wave 1.

---

## FR-W1-9: Simulated delivery confirmation screen

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-5 (simulated delivery)*

After an order is confirmed, the system must display a confirmation screen showing a simulated delivery status message. No real courier dispatch must occur for any Wave 1 order.

---

## FR-W1-10: Seeded reviews display on restaurant page

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-7 (reviews display)*

The system must display on each restaurant page an average star rating (1–5) and 3–5 seeded review snippets (author name, rating, text, date). No review submission interface must be offered to users in Wave 1.

---

## FR-W1-11: Error handling for order submission failure

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-12 (error states)*

When an order submission fails due to a server error, the system must display a clear error message on the checkout page, preserve the user's cart in its current state, and allow the user to retry. The system must not create a partial order record on failure.

---

## FR-W1-12: Graceful empty states for menu and search

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-12 (error states)*

When a restaurant page has no menu items, the system must display a placeholder message (e.g. "Menu coming soon"). When a search returns no results, the system must display a friendly empty-state message.

---

## FR-W1-13: 100-restaurant seed data available at launch

*Graduated from: dishly-wave-1*
*Traces to: BR-W1-4 (seeded restaurant supply)*

The system must make available at launch a seed dataset of 100 restaurants, each containing: name, cuisine type, description, location, delivery radius, and a complete menu with item photos and descriptions. The seed data must span multiple cuisine types and price points.

---

## FR-LOC-1: Filter restaurant results by selected city

*Traces to: [BR-LOC-1](business.md#br-loc-1-location-relevant-restaurant-catalogue-without-schema-change)*
*Graduated from: add-location-based-filtering*

When a city is selected, the system must return only restaurants associated with that city. When no city is selected, the system must return restaurants across all cities.

---

## FR-LOC-2: City selector present on Home and Search pages

*Traces to: [BR-LOC-2](business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)*
*Graduated from: add-location-based-filtering*

The system must render a city selection control on the Home page and the Search results page. The control must allow the customer to select a city, switch to a different city, or clear the active city filter during a session.

---

## FR-LOC-3: City preference persisted across sessions and cleared on sign-out

*Traces to: [BR-LOC-2](business.md#br-loc-2-customer-controlled-location-filtering-on-every-search-surface)*
*Graduated from: add-location-based-filtering*

The system must restore a customer's last selected city when they return to the app in a new session. The system must remove the persisted preference when the customer signs out.

---

## FR-LOC-4: "Near me" option triggers automatic city detection

*Traces to: [BR-LOC-3](business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)*
*Graduated from: add-location-based-filtering*

The system must offer an automatic location detection option in the city selector. When activated, the system must determine the customer's current city from their device location and apply it as the active city filter without requiring manual input.

---

## FR-LOC-5: Graceful fallback when location detection fails

*Traces to: [BR-LOC-3](business.md#br-loc-3-automatic-city-detection-as-an-alternative-to-manual-selection)*
*Graduated from: add-location-based-filtering*

When automatic city detection fails or the customer denies location access, the system must display an inline message indicating that location detection was unsuccessful and prompt the customer to select a city manually. The existing filter state must not be disrupted.

---

## FR-LOC-6: Seed data provides full restaurant records for each new city

*Traces to: [BR-LOC-4](business.md#br-loc-4-multi-city-restaurant-catalogue-with-authentic-local-coverage)*
*Graduated from: add-location-based-filtering*

The system must include at least 20 restaurants per newly added city in the seed data. Each restaurant record must contain: name, cuisine type, description, address, price range, cover image, rating, and delivery radius.

---

## FR-CWD-1: Render curated collections with restaurant cards on homepage

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-1*

The system must load curated restaurant collections from the backend and render each collection as a named group of restaurant cards on the homepage. Collections containing zero restaurants must not be displayed. Each card must include cover image, name, cuisine type, neighbourhood, price range, and star rating.

---

## FR-CWD-2: Render search bar on homepage

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-1*

The system must render a search bar in the hero area of the homepage. Submitting the search bar must navigate to the search results page with the query reflected in the URL.

---

## FR-CWD-3: Filter homepage collections by cuisine type in-place

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-2*

The system must render cuisine filter chips on the homepage and, when a chip is selected, filter the visible restaurant cards to those matching that cuisine type without performing a page navigation. Selecting the "All" chip must restore the full unfiltered view.

---

## FR-CWD-4: Display search results page for keyword queries

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-3*

The system must render a search results page at `/search?q=<query>` that lists restaurants whose name or menu item names match the query (case-insensitive). Each result must include thumbnail image, name, cuisine, neighbourhood, rating, and price range. A result count must be displayed above the list.

---

## FR-CWD-5: Filter search results by cuisine type and price range

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-3*

The system must render cuisine type and price range filter controls above the search result list. Applying a filter must narrow the displayed results in real-time without a full page reload.

---

## FR-CWD-6: Display empty state for zero search results

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-3*

When a search query returns no matching restaurants, the system must display the message "No restaurants found for '[query]'" rather than a blank list or error state.

---

## FR-CWD-7: Render restaurant page with hero, details, menu, and reviews

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-4*

The system must render a restaurant page that includes: a full-width hero image, restaurant name, cuisine type, price range, average star rating, short description, and address. Menu items must be grouped into named sections, and each item must display name, description, price, and photo. When no cover image URL is valid, a placeholder graphic must be shown.

---

## FR-CWD-8: Display seeded review snippets on restaurant page

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-4*

The system must display 3–5 seeded review snippets on each restaurant page. Each snippet must include author name, star rating, review text, and date.

---

## FR-CWD-9: Allow unauthenticated access to all discovery surfaces

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-5*

The system must serve the homepage, search results page, and restaurant page to unauthenticated users without triggering a sign-in prompt, modal, redirect, or any auth gate. Authentication must only be required when a user attempts to add an item to cart.

---

## FR-CWD-10: Render discovery surfaces at desktop and mobile viewport widths

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-6*

The system must render all three discovery surfaces (homepage, search results, restaurant page) correctly at both 1440px (desktop) and 390px (mobile) viewport widths. Restaurant card grids must reflow to 4-column on desktop, 2-column on tablet, and 1-column on mobile. Menu sections on the restaurant page must be collapsible on mobile viewports.

---

## FR-CWD-11: Handle error and empty states on discovery surfaces

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-7*

When a data fetch fails, the system must display a human-readable error message rather than a raw HTTP status code or blank page. A restaurant page with no menu items must show a "Menu coming soon" placeholder. A broken image URL must render a placeholder graphic rather than a broken image indicator.

---

## FR-CWD-12: Add items to cart from restaurant page

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-8*

The system must allow a user to add a menu item to their cart from the restaurant page. The cart must persist across page navigations within the session. The navigation bar must reflect the current cart item count and update immediately when an item is added.

---

## FR-CWD-13: Prompt sign-in for unauthenticated cart actions

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-8*

When an unauthenticated user attempts to add an item to cart, the system must prompt them to sign in. After successful authentication, the system must preserve the item the user intended to add and allow them to proceed without repeating the add-to-cart action.

---

## FR-CWD-14: Confirm cart conflict when switching restaurants

*Graduated from: consumer-web-discovery*
*Traces to: BR-CWD-8*

When a user attempts to add an item from a different restaurant than the one already in their cart, the system must present a conflict confirmation before replacing the existing cart contents.
