# ADR-002: Normalize order items into a separate table instead of a JSON column

<!-- graduated-from: core-backend-apis at 2026-06-08T03:44:50Z -->

*Effort:* dishly-wave-1
*Date:* 2026-06-05
*Status:* Accepted

---

## Context

TR-4 (technical requirements) originally specified the `Order` entity with an
`items` field of type `JSON` — an embedded array of `{menu_item_id, quantity,
unit_price}` stored as a single column.

During storage spec design, the physical schema deviated from this: `order_item`
was implemented as a normalized table with a foreign key to `order` and a
denormalized `item_name` snapshot. The API spec (`OrderItemResponse`) was
designed against the normalized table, not TR-4.

TR-4 was not updated to reflect this decision, creating a conflict between the
requirement, the storage spec, and the API spec that was caught during validation.

---

## Decision

Implement order line items as a normalized `order_item` table (not an embedded
JSON column) with the following columns:

```sql
order_item (
  id           TEXT    PRIMARY KEY,
  order_id     TEXT    NOT NULL REFERENCES "order"(id) ON DELETE CASCADE,
  menu_item_id TEXT    NOT NULL REFERENCES menu_item(id),
  item_name    TEXT    NOT NULL,             -- snapshot at time of order
  quantity     INTEGER NOT NULL CHECK (quantity >= 1),
  unit_price   REAL    NOT NULL CHECK (unit_price >= 0)  -- stored as decimal dollars (e.g. 14.99)
)
```

`item_name` is denormalized: it captures the menu item name at the time the order
was placed so that order history displays correctly even if the restaurant later
renames or removes the item.

---

## Alternatives Considered

**1. Embedded JSON column (TR-4 as written)**
`order.items TEXT` storing `[{menu_item_id, quantity, unit_price}]` as a JSON
blob. Simple to implement; no join required to read an order.

Rejected for three reasons:
- SQLite JSON column support is workable but foreign key constraints cannot be
  enforced on JSON field values — a corrupted `menu_item_id` inside the JSON
  is invisible to the DB.
- Per-item queries (e.g., "how many times was item X ordered?") require JSON
  extraction functions, complicating future analytics.
- The API contract (`OrderItemResponse`) already requires each item to have its
  own `id` field, which is unnatural for a JSON blob and necessitates client-side
  ID generation.

**2. Normalized table without item_name snapshot**
Use only `menu_item_id` as the reference, join to `menu_item.name` at read time.

Rejected because order history must remain stable after menu changes. If a
restaurant renames "Tonkotsu Ramen" to "Premium Tonkotsu" or deletes the item
entirely, past order history would reflect the new name or break on a missing
join — both are wrong.

---

## Consequences

- TR-4 must be updated to replace `Order.items: JSON` with a reference to the
  `ORDER_ITEM` sub-entity (this ADR serves as the record of that decision).
- The `order_item` table is the authoritative source for order line items.
- `item_name` must be written at order-creation time from the current
  `menu_item.name` value — the backend must not rely on a later join for
  display purposes.
- Future analytics queries against individual ordered items are straightforward
  SQL joins rather than JSON extraction.
