# ADR-001: Use /users/me in place of member URI structure for Wave 1

<!-- graduated-from: core-backend-apis at 2026-06-08T03:44:50Z -->

*Effort:* dishly-wave-1
*Date:* 2026-06-05
*Status:* Accepted

---

## Context

The organizational REST API standard (contracts.md R-10) requires member-scoped
resources to use the URI structure:

```
/regions/<region_id>/members/<member_id>/<collection>
```

This structure supports multi-region deployments, member isolation by region, and
cross-service consistency in the Rakuten API surface.

dishly Wave 1 is a local-only MVP (TR-1): no cloud infrastructure, no regional
deployment, a single in-process SQLite database, and a developer machine as the
sole execution environment. There is no concept of a region, no multi-tenancy
requirement, and no production infrastructure on which the compliant URI structure
would be meaningful.

The two affected endpoints in `spec/api/dishly.yaml` are:
- `GET /dishly/v1/users/me` — authenticated user profile
- `GET /dishly/v1/users/me/orders` — authenticated user's order history

Both are annotated with a `# NON-STANDARD` comment referencing this deviation.

---

## Decision

For Wave 1, use `/users/me` for the authenticated-user resource and
`/users/me/orders` for the order history collection.

These paths are scoped to the authenticated user via JWT, which provides the
member isolation that the compliant path would otherwise achieve through URI
structure. The deviation is intentional and bounded to Wave 1.

---

## Alternatives Considered

**1. Implement the compliant URI structure now**
`/regions/<region_id>/members/<member_id>/` would require fabricating a region
identifier that has no real meaning in a local, single-region MVP. This would
add frontend complexity (managing a placeholder region ID), complicate seed data,
and produce a URI surface that misrepresents the system's actual topology.
Rejected — the cost is real and the benefit is zero until production infra exists.

**2. Use a simplified regional prefix (e.g. `/regions/nyc/members/me/`)**
A hardcoded placeholder prefix would superficially satisfy the structural
requirement without supporting it semantically. Rejected — a fake region ID is
worse than an acknowledged deviation because it creates a false sense of compliance
and would need to be unwound in Wave 2 anyway.

**3. Defer the user profile endpoint entirely**
Not viable — user authentication and order history are Wave 1 requirements (BR-9,
BR-12). The endpoints must exist.

---

## Consequences

**Accepted trade-offs:**
- This spec is non-compliant with R-10 for the duration of Wave 1.
- Consumer code (frontend React app) will be written against the non-compliant URI.
  Wave 2 migration will require frontend path updates.

**Wave 2 commitment:**
When Wave 2 introduces production infrastructure and a defined region model, the
following migration will be required:
- Rename `GET /dishly/v1/users/me` → `GET /dishly/v1/regions/<region_id>/members/<member_id>`
- Rename `GET /dishly/v1/users/me/orders` → `GET /dishly/v1/regions/<region_id>/members/<member_id>/orders`
- Update the React frontend routing constants to use the compliant paths
- Update the OpenAPI spec and remove the `# NON-STANDARD` annotations

This migration should be planned as a discrete task within the Wave 2 effort to
avoid it being deferred indefinitely.
