# Product Strategy: dishly

*Created: 2026-06-05*
*Mode: create*

---

## Diagnosis

**Data:** DoorDash holds 67% of the US food delivery market via paid placement and
margin-optimised ranking. No US platform combines curated restaurant discovery with
delivery in a single consumer experience. Quality-conscious consumers use an average
of 2–3 apps to complete one dining decision (Yelp or social to discover, DoorDash
or Uber Eats to order).

**Observations:** Incumbent delivery platforms' revenue model — paid placement and
delivery margin — is in direct structural conflict with discovery quality. This is
not a product gap they can close incrementally; fixing it requires dismantling their
core monetisation. The discovery-to-order journey is fragmented by design, not by
accident.

**Beliefs:** Incumbent platforms are built for order volume and frequency, not
quality signal. Their curation is bought, not earned. A consumer who wants to find
something new and genuinely worth eating has no trustworthy starting point in a
delivery context — they either default to known restaurants or accept an
algorithmically degraded result.

**Bet:** Quality-conscious consumers have no trustworthy discovery surface within a
delivery context — forced to choose between convenient-but-algorithmically-degraded
(DoorDash) and good-but-fragmented (Yelp + social + multiple apps). Dishly must
establish itself as the quality signal consumers trust before a DoorDash or Uber Eats
can bolt on a discovery layer, or before AI-native search makes standalone discovery
obsolete.

*Evidence: competitive/initial-landscape-2026-06-05.md*

---

## Guiding Policy

**Where we play:** Quality-conscious urban consumers aged 22–40, ordering food
delivery 2–4× per week, across 10 US metro markets. Dense urban markets where
restaurant supply concentration is highest and food culture drives discovery
behaviour.

**How we win:** The quality signal is earned, not bought. Every restaurant on dishly
clears a curation bar — not a paid placement. This is structurally impossible for
DoorDash or Uber Eats to replicate without dismantling their own revenue models.

### Strategic Pillars

| # | Pillar | Direction | OKR | Success Indicator |
|---|--------|-----------|-----|-------------------|
| 1 | Earned discovery | Build a curation layer consumers trust — quality signal comes from editorial standards and curated onboarding, not paid ranking | OKR-2026-2 | ≥30% of discovery sessions engage a curated signal; D7 retention higher for curated vs. search-only users |
| 2 | Supply depth before consumer launch | Pre-onboard a critical mass of quality restaurants with menus, photos, and delivery coverage before the first consumer downloads the app | OKR-2026-1 | 150+ quality restaurants per metro live before consumer launch |
| 3 | Seamless discovery-to-delivery | The transition from discovery to order is native and frictionless — no redirect mid-journey | OKR-2026-3 | ≤3 taps from restaurant page to order confirmed; 25%+ discovery-to-order conversion |
| 4 | Social-native discovery surface | Discovery mechanics reflect how under-35 consumers find restaurants today — friend activity, curated lists, contextual recommendations | OKR-2026-2 | ≥30% of discovery sessions engage a social or curated signal |
| 5 | Launch market depth over breadth | Win 10 metros deeply across two waves before expanding; gate second wave on first-wave depth metrics | OKR-2026-4 | NPS ≥45 and repeat order rate ≥35% in first wave before opening second wave |

### Strategic Exclusions

| Exclusion | Rationale |
|-----------|-----------|
| Table reservations | Dine-in occasion is out of scope; dishly is built for delivery and ordering, not table management |
| Loyalty / rewards / cashback | Retention comes from discovery quality, not incentive mechanics; rewards add complexity without solving the core problem |
| National launch | Thin national coverage loses to DoorDash; depth in 10 metros builds a defensible quality reputation |
| Restaurant-side SaaS / CRM tools | Dishly's relationship is with the diner, not the operator; B2B tooling is a different product entirely |
| Grocery or non-restaurant food delivery | Restaurant-focused scope only; grocery is a different supply chain, different consumer need |
| User-generated review destination | Reviews surface as a quality signal within discovery; writing and reading reviews is not dishly's core user behaviour |

---

## Coherent Actions

| Initiative | Strategic Pillar | Horizon | Success Metric | OKR | Effort ID |
|------------|-----------------|---------|----------------|-----|-----------|
| Define curation standards and quality bar for restaurant onboarding | Earned discovery | Now | Curation criteria documented; 0 restaurants listed that don't meet bar | OKR-2026-1 | |
| Pre-launch restaurant onboarding in 10 US metros | Supply depth before launch | Now | 150+ quality restaurants per metro with menus, photos, and delivery coverage live before consumer launch | OKR-2026-1 | |
| Build core discovery UX — search, browse, curated collections | Earned discovery + Social-native discovery | Now | Median time-to-first-discovery ≤5 min on first session | OKR-2026-2 | |
| Build native ordering and delivery flow | Seamless discovery-to-delivery | Now | End-to-end order placed without leaving dishly; ≤3 taps from restaurant page to order confirmed | OKR-2026-3 | |
| Launch in first 3–4 metros; gate expansion to remaining 6–7 on depth metrics | Launch market depth over breadth | Next | NPS ≥45 and repeat order rate ≥35% in first wave before opening second wave | OKR-2026-4 | |
| Social discovery layer — friend activity, curated lists, contextual recommendations | Social-native discovery | Next | ≥30% of discovery sessions engage a social or curated signal | OKR-2026-2 | |
| Consumer acquisition program across 10 launch metros | All pillars | Next | 10,000 MAU per metro within 90 days of wave launch | OKR-2026-4 | |

---

## OKRs

*See [okrs.md](okrs.md) for full product-level OKRs.*

---

## Roadmap

*See [roadmap.md](roadmap.md) for the outcome-based roadmap.*
