# Metric Hierarchy: dishly

*Last updated: 2026-06-05*
*Strategy version: 2026-06-05*

---

## North Star

| Metric | Definition | Data source | Cadence | Baseline | Healthy range |
|--------|-----------|-------------|---------|----------|---------------|
| Monthly discovery-led orders completed | Orders placed by users who entered the session via dishly's discovery surface (curated collections, search, social feed) and completed an order that month. Captures both discovery quality and delivery frictionlessness simultaneously. | Product analytics (event tracking) | Monthly | — (pre-launch) | TBD at 90-day review |

---

## L1 Inputs

| Metric | Drives | Definition | Data source | Cadence | Baseline | Healthy range |
|--------|--------|-----------|-------------|---------|----------|---------------|
| Discovery engagement rate | North Star | % of sessions where the user engages a curated or social signal beyond keyword search | Product analytics | Weekly | — | ≥30% |
| Discovery-to-order conversion rate | North Star | % of discovery sessions that result in a completed order | Product analytics | Weekly | — | ≥25% |
| 30-day repeat order rate | North Star | % of users who place 2+ orders within 30 days of first order | Product analytics | Monthly | — | ≥35% |
| Live supply depth per metro | North Star | Quality restaurants live with complete menus and delivery coverage, per metro | Internal ops dashboard | Weekly | 0 | ≥150 per metro |

---

## L2 Diagnostics

| Metric | Explains | Definition | Data source | Cadence | Baseline | Healthy range |
|--------|---------|-----------|-------------|---------|----------|---------------|
| Curated collection scroll depth | Discovery engagement rate | % of homepage sessions that scroll past position 5 in curated collections | Product analytics | Weekly | — | ≥50% |
| Search-to-collection pivot rate | Discovery engagement rate | % of sessions where user searches then switches to browsing a curated collection | Product analytics | Weekly | — | ≥20% |
| Return visit rate to same collection | Discovery engagement rate | % of users who return to the same curated collection within 7 days | Product analytics | Weekly | — | ≥15% |
| Restaurant page drop-off rate | Discovery-to-order conversion | % of users who view a restaurant page but do not start an order | Product analytics | Weekly | — | ≤60% |
| Cart abandonment rate | Discovery-to-order conversion | % of orders started but not confirmed | Product analytics | Weekly | — | ≤20% |
| Median taps to order | Discovery-to-order conversion | Median tap count from restaurant page to order confirmed | Product analytics | Weekly | — | ≤3 |
| D7 retention by acquisition source | 30-day repeat order rate | D7 retention split by organic / paid / referral | Product analytics | Weekly | — | Organic ≥40% |
| Second-order rate within 7 days | 30-day repeat order rate | % of users who complete a second order within 7 days of first | Product analytics | Weekly | — | ≥25% |
| Same-restaurant reorder rate | 30-day repeat order rate | % of repeat orders placed at a previously ordered restaurant (habit signal) | Product analytics | Monthly | — | 30–50% |
| Curation pass rate | Live supply depth per metro | % of restaurants passing the curation quality bar at onboarding | Internal ops dashboard | Weekly | — | 100% |
| Menu completeness score | Live supply depth per metro | % of menu items with both photo and description | Internal ops dashboard | Weekly | — | ≥80% |
| Delivery coverage rate | Live supply depth per metro | % of listed restaurants with delivery enabled | Internal ops dashboard | Weekly | — | ≥90% |
