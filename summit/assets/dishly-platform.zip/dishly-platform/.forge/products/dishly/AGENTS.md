# dishly — Navigation Guide

This directory is the Forge home for all product management artifacts for **dishly**.
Read this file before looking for or placing any artifact related to this product.

---

## Root-Level Files

| File | Purpose | Produced by | Lifecycle stage |
|------|---------|-------------|----------------|
| `AGENTS.md` | This file — directory navigation guide | `forge:product` | initialization |
| `vision.md` | Stable product identity: the customer transformation this product exists to create. Solution-free north star. Stable for 3–5+ years. | `forge:product-vision` | vision |
| `strategy.md` | Rumelt diagnosis + Roger Martin guiding policy (pillars + exclusions) + coherent actions table | `forge:product-strategy` | strategy |
| `okrs.md` | Product-level OKRs cascaded from company OKRs; cross-referenced in `strategy.md` | `forge:product-strategy` | strategy |
| `metrics.md` | North Star / L1 / L2 metric hierarchy with measurement wiring; stable across strategy cycles; input contract for `forge:product-scorecard` | `forge:product-strategy` | strategy |
| `roadmap.md` | Outcome-based now/next/later or quarterly roadmap; each row maps to a coherent action and OKR | `forge:product-roadmap` | strategy |
| `deployables.md` | Registry of the deployable units (services, apps, libraries) that collectively implement this product, with cross-repo references | `forge:product` (stub), maintained by team | ongoing |

---

## Subdirectories

| Directory | Produced by | Contents |
|-----------|-------------|---------|
| `discovery/` | `forge:product-discover` | OST, assumption log, interview snapshots — written before or during `forge:product-strategy` |
| `competitive/` | `forge:competitive-brief` | One file per competitor analysis brief |
| `research/` | `forge:product-synthesis` | Structured research synthesis documents |
| `research/raw/` | PM (manual) | Raw source artifacts committed for traceability — survey exports, transcripts, support ticket exports; not processed by skills |
| `metrics/scorecards/` | `forge:product-scorecard` | Dated scorecard snapshots (`YYYY-MM-DD.md`) |
| `briefs/` | `forge:product-brief` | One brief per coherent action ready for implementation |
| `outcomes/` | `forge:product-outcome` | Post-launch outcome reviews, keyed by effort ID and review date |
| `references/` | `forge:product-strategy` | Date-stamped raw inputs used during strategy sessions |
| `strategy-archive/` | `forge:product-strategy` | Archived strategy documents from pivot mode |

---

## deployables.md

`deployables.md` is the registry of technical deployable units (services, apps, libraries)
that collectively implement this product. A PM product is a cross-cutting concern — it spans
multiple deployables, which may live in different repositories. This file is the single place
to find them all (ADR-029).

**Format:**

```markdown
# Deployables — dishly

| Deployable | Repository | Role | Capability path | Notes |
|------------|------------|------|-----------------|-------|
| rewards-api | github.com/org/rewards-api | primary backend | .forge/deployables/rewards-api/capabilities/... | |
| mobile-app  | github.com/org/mobile      | iOS/Android client | .forge/deployables/mobile-app/capabilities/... | |
| web-app     | (this repo)                | web frontend | .forge/deployables/web-app/capabilities/...    | |
```

**Fields:**
- **Deployable** — the canonical deployable name used in `.forge/deployables/<name>/`
- **Repository** — GitHub/VCS URL; use `(this repo)` for deployables in the current repository
- **Role** — what this deployable contributes to the product (primary backend, client, data pipeline, etc.)
- **Capability path** — path to the relevant capability directory within that deployable's
  `.forge/deployables/<name>/capabilities/` tree (link for same-repo; prose reference for cross-repo)
- **Notes** — any relevant constraints, ownership notes, or deprecation status

`forge:product` writes a stub `deployables.md` at creation time. The team maintains it as
deployables are added or removed from the product's implementation footprint.

---

### `discovery/`

OST, assumption log, and interview snapshots produced by `forge:product-discover`. Written before
or during `forge:product-strategy` to inform the diagnosis.

```
discovery/
├── ost.md                              # Opportunity Solution Tree (updated in place)
├── assumptions.md                      # Assumption log with test status and confidence (updated in place)
└── interviews/
    └── YYYY-MM-DD-<description>.md    # One file per interview/usability session (never modified after creation)
```

Produced by: `forge:product-discover`

### `competitive/`

One file per competitor analysis brief. Written before or during `forge:product-strategy`
to inform the diagnosis.

File naming: `<competitor-slug>.md` or `<topic>-YYYY-MM-DD.md`

Produced by: `forge:competitive-brief`

### `research/`

Structured research synthesis documents that feed the strategy diagnosis. Written before
or during `forge:product-strategy`.

```
research/
├── <topic>-synthesis.md        # Output of forge:product-synthesis — one file per synthesis run
└── raw/
    ├── <YYYY-MM-DD>-<description>.csv   # e.g., survey export
    ├── <YYYY-MM-DD>-<description>.md    # e.g., support ticket analysis, transcript
    └── ...                              # Any format — committed as-is for traceability
```

`research/raw/` is not processed by any skill. PMs commit source material here so that
synthesis outputs are traceable to their inputs.

`forge:product-synthesis` reads from `research/raw/` if files are present, but does not
write to it.

Produced by: `forge:product-synthesis` (synthesis files); PM manually (raw/)

### `metrics/scorecards/`

Dated scorecard snapshots. If `forge:product-scorecard` is run more than once on the same
day, subsequent runs append a new `## Run: HH:MM` section to the existing day's file rather
than overwriting it or creating a new file.

```
metrics/scorecards/
├── 2026-01-15.md    # Single run that day — one snapshot
├── 2026-02-01.md    # Two runs that day — two timestamped sections within the file
└── ...
```

Produced by: `forge:product-scorecard`

### `briefs/`

One PM brief per coherent action from `strategy.md`. A brief is the PM-owned handoff
artifact that links a strategic initiative to a Forge effort (`forge:effort`). Lighter
than a PRD; heavier than a roadmap bullet.

File naming: `<initiative-slug>.md`

| Section | Contents |
|---------|---------|
| Problem | The specific customer or business problem this initiative addresses |
| Proposed solution | The approach at PM level (not engineering spec) |
| Success metrics | Measurable outcomes that define done |
| Constraints | Known time, scope, or technical constraints |
| Effort link | The `forge:effort` ID for this initiative (back-filled after effort creation) |

Produced by: `forge:product-brief`

### `outcomes/`

Post-launch outcome reviews written after an initiative ships. Feed back into the next
`forge:product-strategy` refresh cycle.

File naming: `<effort-id>-YYYY-MM-DD.md`

| Section | Contents |
|---------|---------|
| Metric actuals vs. projections | How outcomes compared to the success metrics in the brief |
| What worked | Decisions and approaches worth repeating |
| What did not work | Surprises, failures, false assumptions |
| Next bets | Follow-on opportunities surfaced by this launch |

Produced by: `forge:product-outcome`

### `references/`

Raw research inputs gathered during strategy sessions: market research, competitor
analysis sheets, data warehouse query results, PM-supplied documents (roadmaps, board
decks, Confluence exports). Written by `forge:product-strategy` during session execution.

Files use date-stamped names: `competitor-analysis-YYYY-MM-DD.md`,
`market-research-YYYY-MM-DD.md`, `data-analysis-<metric>-YYYY-MM-DD.md`.

Do not write output artifacts here — `references/` is inputs only.

### `strategy-archive/`

Archived versions of `strategy.md`, `okrs.md`, and `roadmap.md` from pivot mode.
Written automatically by `forge:product-strategy` when a pivot is initiated.

File naming: `strategy-YYYY-MM-DD.md`, `okrs-YYYY-MM-DD.md`, `roadmap-YYYY-MM-DD.md`.
If multiple pivots occur on the same date, a counter suffix is appended: `strategy-YYYY-MM-DD-2.md`.

Do not write to this directory manually — it is managed exclusively by `forge:product-strategy`.

---

## Lifecycle Order

For a new product, artifacts are typically created in this order:

```
1.  forge:product            → AGENTS.md, deployables.md
2.  forge:product-vision     → vision.md
3.  forge:competitive-brief  → competitive/<brief>.md          ─┐
4.  forge:product-synthesis  → research/<synthesis>.md         ├── feed strategy diagnosis
5.  forge:product-discover   → discovery/ost.md, etc.          ─┘
6.  forge:product-strategy   → strategy.md, okrs.md, metrics.md, references/
7.  forge:product-roadmap    → roadmap.md
8.  forge:product-brief      → briefs/<initiative>.md (one per coherent action)
9.  forge:effort             → effort created, linked from brief
10. forge:prd                → requirements/prd.md, business.md, user-stories.md
11. [effort graduates]
12. forge:product-outcome    → outcomes/<effort-id>-YYYY-MM-DD.md
```

Steps 3–5 may be run in any order or re-run on a recurring cadence. They are not
prerequisites for each other; all three feed a high-quality `forge:product-strategy`.

Steps 7–9 repeat for each coherent action that progresses to implementation.

---

## Navigation Notes

| Task | Start here |
|------|-----------|
| Understanding current strategy | `strategy.md`, then `okrs.md` |
| Understanding what's in flight | `roadmap.md`, then `briefs/` |
| Understanding customer problems | `discovery/ost.md`, then `research/` |
| Understanding outcomes | `outcomes/` |
