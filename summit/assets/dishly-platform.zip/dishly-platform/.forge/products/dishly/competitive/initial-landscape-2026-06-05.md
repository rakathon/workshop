---
product: dishly
brief: initial-landscape
date: 2026-06-05
competitors: [OpenTable, Resy, Yelp, Zomato]
strategic_implication: true
---

# Competitive Brief — Initial Landscape

*Product: dishly | Date: 2026-06-05*

---

## Executive Summary

The US restaurant discovery and dining space is structurally fragmented: reservation platforms (OpenTable, Resy) dominate table booking but ignore delivery; review/discovery platforms (Yelp) have broad reach but abandoned delivery and lack meaningful loyalty; and food delivery platforms (DoorDash, Uber Eats) own ordering but have weak curated discovery. No single US player owns the full consumer journey from "where should I eat?" through booking or ordering to post-meal rewards. Zomato, the most instructive global analog, has proven the super-app model — combining discovery, delivery, dining reservations, and a subscription loyalty program — but exited all Western markets. Dishly's most significant opportunity is to occupy this unclaimed territory in the US: a unified dining product with genuine loyalty mechanics. The most important threat is that OpenTable and Resy, backed by Booking Holdings and American Express respectively, could each extend toward a more integrated model before dishly achieves scale.

---

## Feature Matrix

*Key: ✓ supported · ~ partial/limited · ✗ absent · ? unknown*

| Feature / Capability           | dishly | OpenTable | Resy | Yelp | Zomato |
|-------------------------------|:------:|:---------:|:----:|:----:|:------:|
| **Restaurant Discovery**       |        |           |      |      |        |
| Restaurant search & browse     | ?      | ✓         | ✓    | ✓    | ✓      |
| Filters (cuisine, price, time) | ?      | ✓         | ✓    | ✓    | ✓      |
| Editorial curation / lists     | ?      | ~         | ✓    | ~    | ~      |
| Menu browsing                  | ?      | ~         | ~    | ✓    | ✓      |
| User reviews & ratings         | ?      | ✓         | ~    | ✓    | ✓      |
| Photo galleries                | ?      | ✓         | ✓    | ✓    | ✓      |
| AI-powered recommendations     | ?      | ~         | ✗    | ~    | ~      |
| Social/influencer discovery    | ?      | ✗         | ✗    | ✗    | ✗      |
| **Reservations**               |        |           |      |      |        |
| Real-time table booking        | ?      | ✓         | ✓    | ~    | ✓      |
| Waitlist management            | ?      | ✓         | ✓    | ~    | ~      |
| Ticketed experiences/events    | ?      | ✓         | ✓    | ✗    | ✓      |
| No-show protection/deposits    | ?      | ✓         | ✓    | ✗    | ~      |
| **Food Delivery / Ordering**   |        |           |      |      |        |
| In-app food ordering           | ?      | ✗         | ✗    | ✗    | ✓      |
| First-party delivery fleet     | ?      | ✗         | ✗    | ✗    | ✓      |
| Delivery to consumer           | ?      | ✗         | ✗    | ✗    | ✓      |
| Pickup / takeout ordering      | ?      | ✗         | ✗    | ✗    | ✓      |
| **Loyalty & Rewards**          |        |           |      |      |        |
| Points / cashback program      | ?      | ~         | ✗    | ✗    | ✓      |
| Paid membership tier           | ?      | ✗         | ✗    | ✗    | ✓      |
| Card-linked benefits           | ?      | ~         | ✓    | ✗    | ✗      |
| Dining perks (free dishes etc) | ?      | ✗         | ~    | ✗    | ✓      |
| **Restaurant-Side Tools**      |        |           |      |      |        |
| Guest CRM / profiles           | ?      | ✓         | ✓    | ~    | ~      |
| Marketing campaigns            | ?      | ✓         | ~    | ✓    | ~      |
| POS integration                | ?      | ✓         | ✓    | ✗    | ~      |
| Analytics & reporting          | ?      | ~         | ~    | ~    | ~      |
| Delivery management tools      | ?      | ✗         | ✗    | ✗    | ✓      |

### Where we lead
- No conclusions yet — dishly has no deployed product; the matrix flags where incumbents have invested least heavily as the most available territory.

### Where we lag
- All incumbents have real-time reservations; this is table stakes
- OpenTable has the deepest restaurant-side CRM and the largest network (55K+ restaurants)
- Yelp has unmatched review volume (308M reviews) and consumer reach (76M monthly visitors)
- Zomato has the most complete loyalty product (Gold membership) and delivery integration — the proven template for the unified model, even if it's India-only

---

## Positioning Analysis

### Competitive positioning summaries

**dishly**
No deployed positioning yet. The gap in the market — a US product that combines curated discovery, delivery or ordering, and a meaningful rewards program — is currently unoccupied. Dishly should avoid positioning as "another reservations app" or "another delivery app" and instead own the full dining journey as a distinct category.

**OpenTable**
OpenTable positions itself as the world's most trusted restaurant reservation platform, targeting both diners seeking convenience and restaurants seeking guest management and marketing reach. They emphasise scale ("seats over 1 billion diners/year"), POS integration breadth, and their Booking Holdings distribution advantage. Their brand tone is utilitarian and established — they are the default choice, not the exciting one. The 2024 Visa partnership for premium reservation access signals a quiet move toward premium card-linked experiences without overhauling the core product.

**Resy**
Resy positions as the premium, culturally-credible reservation app for serious food people — the insider's tool for booking sought-after restaurants. AmEx ownership is central to their identity: Resy perks are woven into AmEx card benefits, making the product functionally a loyalty extension for premium cardholders. Their brand is editorial and New York-centric in feel, with strong curation credentials from co-founder Ben Leventhal (Eater.com). They compete less on scale and more on cachet — winning the NYC market by 2023 is their signature achievement. UK exit in August 2024 signals that premium positioning doesn't travel as easily outside flagship cities.

**Yelp**
Yelp positions as the trusted local-discovery platform for any business, not just restaurants — which is both its breadth advantage and its focus problem. With $1.46B revenue and 76M monthly visitors, it has the largest consumer audience of any player here, yet restaurants consistently find the ad model extractive and the review algorithm opaque. Yelp sold its delivery business (Eat24) in 2017 and has not re-entered that space, leaving it as a pure discovery/advertising play. Their 2024 launch of AI-powered "Review Insights" and Yelp Assistant signals awareness of AI-era discovery shifts, but the core monetization model hasn't changed. Tone is mass-market and trustworthy; brand equity is strong with consumers, weak with restaurant operators.

**Zomato**
Zomato positions as India's definitive food super-app — where you discover restaurants, order delivery, book a table, and buy event tickets, all in one place. They exited all Western markets by 2024 and are now explicitly India-focused. Their Gold membership (paid subscription with dining discounts and delivery perks) is the most sophisticated loyalty product in this category globally. The November 2024 launch of District (dining reservations + movies + live events) signals an aggressive push into the "going out" occasion beyond food, which is the most instructive strategic move in the space. Zomato is not a direct US competitor today, but represents what the end-state super-app looks like.

### Positioning map

**Crowded territory:** Reservation-only, urban fine dining (OpenTable and Resy directly compete here; both have invested heavily in the same restaurant relationships).

**Claimed but weakly executed:** Broad restaurant discovery via reviews (Yelp owns this by volume but restaurant operators dislike the platform and consumers under-35 are shifting to social discovery via TikTok and Instagram).

**Vacant territory — US market:**
1. **Unified discovery + ordering** — no US platform owns both curated restaurant discovery and direct food ordering in a single consumer experience
2. **Meaningful dining loyalty** — OpenTable's points are low-value; Resy's perks are card-gated; no independent dining rewards product exists for the mass market
3. **Social-native discovery** — no established platform has credibly integrated user-generated social content (TikTok-style video, influencer lists) into a transactional dining product
4. **Discovery-to-delivery for quality-conscious consumers** — DoorDash and Uber Eats serve utility delivery; no player serves the consumer who wants chef-quality food delivered with the same curation layer they'd apply when booking a table

Dishly's positioning should claim the intersection of quality discovery and full-journey rewards — the category that Zomato proved works globally, applied to the US market.

---

## Win / Loss Signals

*Note: dishly has no live product; this section reflects where incumbents win and lose, which maps directly to the whitespace dishly can target.*

### Where incumbents win (and we must match)

| Customer type / use case | Incumbent | Reason | Confidence |
|--------------------------|-----------|--------|-----------|
| Urban fine-dining booking | OpenTable | Scale, POS integration, real-time availability across 55K+ restaurants | High |
| Premium cardholders seeking restaurant perks | Resy | AmEx integration; reservation perks tied to card membership | High |
| First-time restaurant search / local discovery | Yelp | 308M reviews, high SEO authority, 76M monthly visitors | High |
| Restaurant operators seeking full-funnel management | OpenTable | Guest CRM, campaign tools, POS sync, deposit management | High |

### Where incumbents lose (dishly's entry points)

| Competitor | Customer type / use case | Reason they lose | Confidence |
|------------|--------------------------|-----------------|-----------|
| OpenTable | Cost-sensitive restaurant operators | Per-cover fees cited as "cost prohibitive" — most common complaint | High |
| OpenTable | Consumers wanting food delivered | No delivery product exists | High |
| Resy | Consumers outside NYC/major food cities | Coverage drops sharply outside premium urban markets; UK exit confirmed this | High |
| Resy | Consumers without an AmEx card | Loyalty benefits are card-gated — non-AmEx holders get a worse product | Medium |
| Yelp | Restaurant operators at any price point | Aggressive sales tactics, opaque review algorithm, competitor ads on your page | High |
| Yelp | Consumers wanting to book or order | No reservations (Yelp Guest Manager is nascent), no delivery | High |
| All four | Consumers wanting a unified dining loyalty program | No US player has a compelling, platform-native rewards product for diners | High |
| All four | Social-native discovery (under-35 consumers) | None have credibly integrated short-form video / influencer-led discovery | Medium |

### Where data is thin

- Win rates between OpenTable and Resy for mid-market (non-premium) restaurants — limited public data
- Consumer NPS and retention rates for any platform's loyalty features
- Whether dishly's Rakuten Rewards infrastructure creates a credible cashback differentiation vs. card-linked competitor perks
- *Recommended: run 10–15 consumer interviews on how they currently decide where to eat and order from; document churn reasons from restaurants that left OpenTable or Resy*

---

## Market Trends

### 1. Super-app convergence — discovery, booking, delivery, and loyalty consolidating

**What is happening:** Consumers increasingly expect a single app to handle the full dining occasion: find a restaurant, book a table or order delivery, earn rewards, and repeat. Zomato's District launch (Nov 2024) — adding movies and live events to food — is the clearest signal that "dining out" is expanding to "going out." In the US, no platform has executed this consolidation; the closest analog is DoorDash's quiet push into reservations and Uber Eats' experimentation with dining experiences.

**Who is moving on it:** Zomato (most aggressively, India-only). DoorDash and Uber Eats (early, delivery-first). OpenTable (not moving — Booking Holdings has kept it reservations-only).

**Implication for us:** This is dishly's founding thesis. First-mover advantage in the US is real but narrow — DoorDash or Uber Eats could credibly acquire a reservation platform (OpenTable or Resy) within the next 2–3 years.

**Time horizon:** Medium-term (1–3 years)

---

### 2. AI-powered personalization raising the discovery bar

**What is happening:** Restaurant discovery is moving from keyword search (find "Italian, under $50, open now") toward intent-based and behavioral personalization ("show me where my friends are going," "based on what I ordered last Tuesday"). Yelp launched AI-powered Review Insights and a conversational Yelp Assistant in 2024. OpenTable has signaled AI features but public details are limited. Google and Apple Maps, not listed as direct competitors here, have deployed AI-driven restaurant recommendations at massive scale and represent the ambient competitive pressure on discovery.

**Who is moving on it:** Yelp (Review Insights, Yelp Assistant). Google Maps (AI overviews, restaurant recommendations). OpenTable (signals only).

**Implication for us:** Discovery quality is a commodity race. Dishly needs a differentiated angle — social proof from within the platform's loyalty community, Rakuten-powered purchase history signals, or curated editorial — not just better search.

**Time horizon:** Near-term (0–12 months)

---

### 3. Dining loyalty is broken and up for grabs

**What is happening:** Consumers accumulate credit card points and airline miles but have no equivalent for dining. OpenTable's points program is widely considered low-value (points take many reservations to redeem for anything meaningful). Resy's perks are gated behind an AmEx card. No US platform has launched a standalone dining loyalty product competitive with what retail cashback (including Rakuten) delivers in its own category. Restaurant operators are independently building their own loyalty programs (Toast, Olo) but these are fragmented by restaurant, not portable across the dining network.

**Who is moving on it:** Zomato Gold (the model, not a US competitor). Toast and Olo are building per-restaurant loyalty infrastructure. No platform player is building a network-level dining rewards product.

**Implication for us:** Rakuten's cashback infrastructure and member network is a structural asset no dining-native competitor can quickly replicate. A Rakuten-powered dining rewards product — earn cashback at partner restaurants, redeemable across the Rakuten ecosystem — would be genuinely differentiated and defensible.

**Time horizon:** Near-term (0–12 months) — window exists before a well-funded incumbent fills it

---

### 4. Restaurant operators are price-sensitive and platform-fatigued

**What is happening:** The most consistent signal in OpenTable G2 reviews is that per-cover fees are "cost prohibitive" and operators are actively looking for alternatives. Yelp's B2B reviews show similar frustration — aggressive sales tactics and opaque ROI make operators distrust the platform. Mid-market and independent restaurant operators are increasingly looking for a platform that charges predictably, integrates with their existing POS (Toast, Square), and doesn't run competitor ads on their listing.

**Who is moving on it:** Toast and Olo are expanding from POS into reservations and ordering as platform plays. Resy's AmEx backing means they can charge restaurants less (subsidized by card revenue), which is a structural pricing advantage.

**Implication for us:** A pricing model that doesn't charge per-cover fees — subscription-based, or commission on delivery only — combined with clean POS integration, would resonate strongly with the mid-market restaurant segment that OpenTable and Yelp are actively alienating.

**Time horizon:** Near-term (0–12 months)

---

### 5. Social-native discovery is structurally replacing review platforms for under-35 diners

**What is happening:** TikTok and Instagram have become primary restaurant discovery surfaces for younger consumers — "TikTok made me try it" is now a documented dining behavior. Yelp's audience has strong household income skew but no credible social-native discovery layer. None of the four platforms reviewed have integrated short-form video, influencer restaurant lists, or friend-activity feeds in a meaningful way. The vacuum is currently being filled by third-party apps (Beli, Canopy) with no delivery or reservation integration.

**Who is moving on it:** Nobody in the core competitive set. Beli and similar niche apps have traction with under-35 food enthusiasts but no transaction layer.

**Implication for us:** Integrating social proof — friend activity, curated influencer lists, UGC video — into a transactional dining product is a durable differentiation that would be hard for OpenTable or Yelp to bolt on without brand incongruity.

**Time horizon:** Medium-term (1–3 years) to win the under-35 cohort as a founding audience

---

## Research Notes

*Sources consulted:*
- Wikipedia: OpenTable, Resy, Yelp, Zomato (company overviews, scale, business model)
- G2 review analysis: OpenTable for Restaurants, Yelp for Business
- Yelp business.yelp.com (advertising products and pricing)
- OpenTable restaurant solutions pages (features, restaurant-side capabilities)
- Zomato Wikipedia entry (geographic focus, District app launch, Gold program, revenue)
- Resy Wikipedia entry (AmEx acquisition, scale, NYC market position, UK exit)

*Data gaps:*
- OpenTable's exact per-cover fee rates (not publicly published)
- Resy's current US restaurant count (16K figure is 2023, global)
- OpenTable's 2024–2025 AI feature details (blog inaccessible during research)
- No first-party win/loss data from restaurant operator interviews or consumer NPS
- Zomato Gold exact pricing in INR/USD and member count not retrieved

*Last updated: 2026-06-05*
