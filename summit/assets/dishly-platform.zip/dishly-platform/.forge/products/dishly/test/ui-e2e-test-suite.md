# UI E2E Test Suite — dishly

*Output dir:* `.forge/products/dishly/test/`
*Authored:* 2026-06-05
*Effort:* `dishly-wave-1`

## Why Test This

The dishly UI is the product. The business case rests on the claim that a user can discover a restaurant worth ordering from within a single session — which means every screen state along that path must render correctly and respond to user input. These UI E2E tests use Playwright to drive a real browser against the running app, asserting what the user sees and can interact with on each screen. They cover all 11 screens from the UX spec plus every non-default state (loading, error, empty, conflict). They do not duplicate API-level assertions — those live in the system E2E suite.

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-1: Homepage renders with editorial collections | S-01: collections visible, no sign-in prompt |
| SC-2: Category chip toggles filter active state | S-01: chip interaction |
| SC-3: Search navigates to results page | S-01 → S-02: hero search bar navigates |
| SC-4: Search results render with filter chips | S-02: results list + inline filters |
| SC-5: Cuisine filter chip narrows results | S-02: filter active state, result count updates |
| SC-6: Search empty state renders | S-02 empty: no-match message + CTA |
| SC-7: Restaurant page renders full layout | S-03: hero, metadata, menu, reviews |
| SC-8: Menu section accordion collapses and expands | S-03: mobile section toggle |
| SC-9: Add-to-cart flashes confirmation on button | S-03: micro-animation feedback |
| SC-10: Auth modal opens on add-to-cart (unauthenticated) | S-04: gate triggers at correct moment |
| SC-11: Auth modal Sign In / Sign Up tab switching | S-04: tab state |
| SC-12: Auth modal inline error on wrong credentials | S-04 error: error state renders |
| SC-13: Cart drawer opens and shows items | S-05: drawer with items + totals |
| SC-14: Cart empty state renders | S-05 empty: empty cart message |
| SC-15: Quantity controls update item count | S-05: +/- controls |
| SC-16: Cart conflict modal appears on restaurant switch | S-06: conflict warning before clearing cart |
| SC-17: Checkout step 1 — address form renders | S-07: address fields + Continue button |
| SC-18: Checkout step 2 — payment form renders | S-08: card fields, security note |
| SC-19: Checkout step 3 — order summary renders | S-09: itemised summary, Place Order CTA |
| SC-20: Checkout inline error state renders | S-09 error: error banner, cart preserved |
| SC-21: Order confirmation screen renders | S-10: confirmed state, ETA, CTAs |
| SC-22: Order history list renders | S-11: orders in reverse-chron |
| SC-23: Order history row expands itemised detail | S-11: expand/collapse |
| SC-24: Order history empty state renders | S-11 empty: no orders yet message |
| SC-25: Announcement bar renders on all screens | Global: announcement bar present |
| SC-26: Header cart badge updates after add | Global: cart badge count |

## Scenarios

### SC-1: Homepage renders with editorial collections

**Type:** e2e (UI) · `smoke-test` · `non-production`
**Given** the app is running with seed data
**When** a user navigates to `/`
**Then** the page `<h1>` reads "Find food worth eating."
**And** at least 3 `<section>` elements with collection titles are visible
**And** each collection contains at least 1 restaurant card with a loaded `<img>` (naturalWidth > 0)
**And** no sign-in modal or prompt is visible
**Verifies:** S-01 — homepage default state

---

### SC-2: Category chip toggles filter active state

**Type:** e2e (UI) · `non-production`
**Given** the user is on the homepage
**When** they click the "Ramen" cuisine chip
**Then** the chip's `aria-pressed` is `true` and it has the active visual style (purple fill)
**When** they click it again
**Then** the chip's `aria-pressed` is `false` and it returns to the inactive style
**Verifies:** S-01 — chip active/inactive interaction

---

### SC-3: Search bar navigates to results page

**Type:** e2e (UI) · `smoke-test` · `non-production`
**Given** the user is on the homepage
**When** they type "Thai" in the hero search input and press Enter
**Then** the URL changes to `/search?q=Thai`
**And** the search results page renders with the query pre-filled in the header search bar
**Verifies:** S-01 → S-02 — search navigation

---

### SC-4: Search results render with filter chips

**Type:** e2e (UI) · `non-production`
**Given** the user navigates to `/search?q=ramen`
**When** the page loads
**Then** a result count label is visible (e.g. "N restaurants")
**And** cuisine filter chips are visible above the results
**And** price range filter chips are visible
**And** at least 1 result row is visible with a thumbnail image, name, and metadata
**Verifies:** S-02 — search results default state

---

### SC-5: Cuisine filter chip narrows results and updates count

**Type:** e2e (UI) · `non-production`
**Given** the search results page is showing results for "ramen"
**When** the user clicks the "Japanese" cuisine chip
**Then** the chip becomes active (purple fill)
**And** the result count label updates
**And** only result rows consistent with the filter remain visible
**Verifies:** S-02 — filter active state, count update

---

### SC-6: Search empty state renders correctly

**Type:** e2e (UI) · `non-production`
**Given** the search results page
**When** the user searches for a query that matches no restaurants (e.g. "xyzzy_no_results")
**Then** no restaurant result rows are visible
**And** an empty state message is visible containing the query text
**And** a "Browse collections" call-to-action button is visible
**Verifies:** S-02 empty state — BR-15

---

### SC-7: Restaurant page renders full layout top-to-bottom

**Type:** e2e (UI) · `smoke-test` · `non-production`
**Given** the user navigates to a valid restaurant page `/restaurants/:id`
**When** the page loads
**Then** a full-width hero `<img>` is visible and loaded (naturalWidth > 0)
**And** the restaurant `<h1>` name is visible
**And** a star rating and price range badge are visible
**And** the restaurant description is visible
**And** at least one menu section heading is visible
**And** at least one menu item with a photo, name, description, price, and "Add" button is visible
**And** at least 3 review snippets with author name, star rating, and text are visible
**Verifies:** S-03 — BR-16 full restaurant page layout

---

### SC-8: Menu section accordion collapses and expands on mobile

**Type:** e2e (UI) · `non-production`
**Given** the restaurant page at a 390px viewport width
**When** the user taps a menu section header
**Then** the section's `aria-expanded` attribute becomes `"false"` and the items are hidden
**When** they tap the header again
**Then** `aria-expanded` becomes `"true"` and the items are visible
**Verifies:** S-03 — mobile section accordion, BR-16

---

### SC-9: Add-to-cart button flashes confirmation feedback

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user on a restaurant page
**When** they click an "Add" button on a menu item
**Then** the button text changes to "Added ✓" within 200ms
**And** the cart badge count in the header increments by 1
**And** the button text reverts to "Add" within 1500ms
**Verifies:** S-03 — add-to-cart micro-animation (Norman feedback)

---

### SC-10: Auth modal opens when unauthenticated user taps Add

**Type:** e2e (UI) · `non-production`
**Given** an unauthenticated user on a restaurant page
**When** they click an "Add" button
**Then** an auth modal appears with heading "Welcome to dishly"
**And** both "Sign in" and "Create account" tab buttons are visible
**And** no sign-in was requested before the user attempted to add to cart
**Verifies:** S-04 — BR-9 gate triggers at cart, not at browse

---

### SC-11: Auth modal tabs switch between Sign In and Sign Up panels

**Type:** e2e (UI) · `non-production`
**Given** the auth modal is open on the "Sign in" tab
**When** the user clicks "Create account"
**Then** the "Create account" panel becomes visible
**And** the "Sign in" panel is hidden
**And** `aria-selected="true"` is on the "Create account" tab button
**Verifies:** S-04 — tab state

---

### SC-12: Auth modal shows inline error on wrong credentials

**Type:** e2e (UI) · `non-production`
**Given** the auth modal is open on the "Sign in" tab
**When** the user submits an email and password that do not match a registered account
**Then** an inline error message is visible within the modal
**And** the error text references incorrect credentials
**And** the modal remains open (no redirect)
**Verifies:** S-04 error state

---

### SC-13: Cart drawer opens and shows items with totals

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user has added items to the cart on a restaurant page
**When** they click the cart icon in the header
**Then** the cart drawer slides in from the right
**And** each cart item row shows a thumbnail image, item name, price, and quantity controls
**And** a subtotal, delivery fee, and estimated total are visible
**And** a "Proceed to Checkout" button is visible
**Verifies:** S-05 — cart drawer with items

---

### SC-14: Cart empty state renders when cart is empty

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user with an empty cart
**When** they navigate to `/cart`
**Then** an empty-state message is visible
**And** no item rows or total rows are visible
**Verifies:** S-05 empty state

---

### SC-15: Quantity controls in cart update item count

**Type:** e2e (UI) · `non-production`
**Given** the cart drawer is open with at least one item at quantity 1
**When** the user clicks the "+" quantity button
**Then** the quantity display increments to 2
**When** the user clicks the "−" / trash button at quantity 1
**Then** the item row is removed from the cart
**Verifies:** S-05 — quantity controls

---

### SC-16: Cart conflict modal appears when switching restaurants

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user has items from Restaurant A in their cart
**When** they navigate to Restaurant B and tap an "Add" button
**Then** a conflict modal appears naming Restaurant A
**And** two clear action buttons are visible: one to keep the current cart and one to start a new order
**And** clicking "Keep current cart" closes the modal without clearing the cart
**Verifies:** S-06 — BR-11 cart conflict modal

---

### SC-17: Checkout step 1 — address form renders correctly

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user with items in the cart navigates to `/checkout`
**When** the page loads at step 1
**Then** the step indicator shows step 1 as active and steps 2–3 as inactive
**And** address fields (street, city, ZIP, notes) are visible with associated labels
**And** a "Continue to payment" button is visible
**Verifies:** S-07 — checkout step 1

---

### SC-18: Checkout step 2 — payment form renders correctly

**Type:** e2e (UI) · `non-production`
**Given** the user is at checkout step 2
**When** the step 2 panel is active
**Then** card number, expiry, and CVC fields are visible with associated labels
**And** a security note about Stripe is visible
**And** a "Review order" button is visible
**And** a back link to step 1 is visible
**Verifies:** S-08 — checkout step 2

---

### SC-19: Checkout step 3 — order summary renders correctly

**Type:** e2e (UI) · `non-production`
**Given** the user is at checkout step 3
**When** the summary panel is active
**Then** an itemised list of ordered items with prices is visible
**And** subtotal, delivery fee, and total are visible
**And** the delivery address entered in step 1 is shown
**And** a "Place order — $X.XX" primary CTA button is visible
**Verifies:** S-09 — checkout step 3

---

### SC-20: Checkout inline error state renders and preserves cart

**Type:** e2e (UI) · `non-production`
**Given** the user is at checkout step 3 and the order submission returns an error
**When** the error response is received
**Then** an inline error banner is visible on the step 3 panel
**And** the error message references the failed submission in plain language
**And** the order summary items are still visible (cart not cleared)
**And** the "Place order" button is re-enabled for retry
**Verifies:** S-09 error state — BR-15

---

### SC-21: Order confirmation screen renders with all required elements

**Type:** e2e (UI) · `smoke-test` · `non-production`
**Given** the user has successfully placed an order
**When** the confirmation screen at `/orders/:id` renders
**Then** a success icon and "Order confirmed!" heading are visible
**And** the order number, restaurant name, delivery address, and estimated ETA are shown
**And** the ETA text contains "30–40 minutes"
**And** two CTAs are visible: "Back to home" and "View order history"
**Verifies:** S-10 — BR-6 confirmation screen; peak-end rule investment

---

### SC-22: Order history list renders in reverse-chronological order

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user with at least 2 past orders
**When** they navigate to `/account/orders`
**Then** at least 2 order rows are visible
**And** each row shows restaurant name, order date, and total
**And** the most recent order appears first
**Verifies:** S-11 — BR-12 order history page

---

### SC-23: Order history row expands itemised detail

**Type:** e2e (UI) · `non-production`
**Given** the order history page with at least 1 order row
**When** the user clicks an order row header
**Then** the itemised detail section for that order becomes visible
**And** individual item names, quantities, and prices are listed
**And** clicking the row header again collapses the detail
**Verifies:** S-11 — BR-12 expand/collapse per order

---

### SC-24: Order history empty state renders for new users

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user with no past orders
**When** they navigate to `/account/orders`
**Then** the empty state message "No orders yet" is visible
**And** an "Explore restaurants" CTA links back to the homepage
**Verifies:** S-11 empty state

---

### SC-25: Announcement bar is present on all primary screens

**Type:** e2e (UI) · `non-production`
**Given** the app is running
**When** the user navigates to the homepage, a restaurant page, and the search results page
**Then** the announcement bar is visible at the top of each screen
**And** it has the brand purple background
**And** it contains at least one word of copy
**Verifies:** Global — announcement bar spec (DESIGN.md component)

---

### SC-26: Cart badge in header updates after add-to-cart

**Type:** e2e (UI) · `non-production`
**Given** an authenticated user on a restaurant page with cart badge showing 0
**When** they add one menu item to the cart
**Then** the cart badge updates to show "1"
**And** the cart button's `aria-label` reflects "Cart, 1 item"
**When** they add a second item
**Then** the badge updates to "2"
**Verifies:** Global header — cart visibility (Darius persona: item count at a glance)

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to extend this suite with load scenarios.*
