# Product OKRs: dishly

*Quarter: Q3 2026*
*Cascaded from: No company OKRs available — back-fill alignment when OKRs are set*
*Linked from: [strategy.md](strategy.md)*

---

## Objective 1: Launch with a supply base consumers can trust

*Supports: Supply depth before launch, Earned discovery*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Quality restaurants onboarded per metro with menus, photos, and delivery coverage | 0 | 150 | 200 |
| % of listed restaurants passing curation quality bar | 0% | 100% | 100% |
| Metros with full supply coverage at consumer launch | 0 | 3 | 5 |

---

## Objective 2: Prove the quality discovery signal on first consumer session

*Supports: Earned discovery, Social-native discovery surface*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Median time-to-first-discovery (user finds a restaurant worth ordering from) | — | ≤5 min | ≤3 min |
| % of discovery sessions engaging a curated or social signal | 0% | 30% | 45% |
| D7 retention lift for curated-discovery users vs. search-only users | — | +20% | +35% |

---

## Objective 3: Make discovery-to-delivery frictionless

*Supports: Seamless discovery-to-delivery*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| Discovery-to-order conversion rate | — | 25% | 35% |
| Average taps from restaurant page to order confirmed | — | ≤3 | ≤2 |
| Order completion rate (orders started, not abandoned) | — | 80% | 88% |

---

## Objective 4: Build a repeating consumer base in launch markets

*Supports: Launch market depth over breadth, Consumer acquisition*

| Key Result | Baseline | Target | Stretch |
|------------|---------|--------|---------|
| MAU per launch metro within 90 days of wave launch | 0 | 10,000 | 15,000 |
| 30-day repeat order rate | — | 35% | 50% |
| NPS in launch metros | — | ≥45 | ≥60 |
