# Deployables — dishly

Registry of the technical deployable units that collectively implement this product.
A deployable is an independently shippable unit (service, app, library, pipeline).
Update this table as deployables are added to or removed from the product's implementation.

| Deployable | Repository | Role | Capability path | Notes |
|------------|------------|------|-----------------|-------|
| | | | | |

<!-- Role examples: primary backend, iOS/Android client, web frontend, data pipeline, ML model -->
<!-- Capability path: .forge/deployables/<name>/capabilities/<capability>/ (use "(this repo)" for local deployables) -->
