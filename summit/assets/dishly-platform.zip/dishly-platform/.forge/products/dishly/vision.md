# Vision — dishly

*Stable product identity. Update only when the fundamental nature of the product
changes — not when strategy, roadmap, or scope evolves.*

*Time horizon: 5 years (2026–2031)*

---

## Vision Statement

Every meal decision starts with genuine discovery. Dishly closes the gap between "I want to eat somewhere worth eating" and food at your door — without the compromises that come from platforms built for order volume over food quality.

---

## Target Beneficiaries

Consumers who care about where their food comes from and what ends up in front of them. People who are dissatisfied with delivery app grids that treat a neighborhood ramen shop the same as a fast food chain, and who currently stitch together multiple apps — one to discover, one to order — with no continuity between them. The primary user is quality-conscious, curious about food, and expects the platform to do the work of finding something worth eating, not just something available.

---

## The Transformation

**Before:** Delivery apps are optimized for order volume and margin, not for helping consumers find food worth eating. Restaurant discovery and food delivery are separate problems solved by separate apps, and neither does the other job well. A consumer who wants to eat something good starts on Yelp, bounces to Instagram, settles on DoorDash, and orders from whatever ranks first — not whatever is best.

**After:** Discovery and ordering are a single, continuous act. A consumer opens dishly to find somewhere worth eating and the decision carries directly through to delivery — with a quality signal they can trust at every step.

---

## What This Is Not

- **Not a reservation platform** — the dine-in occasion is out of scope; dishly is built for the delivery and ordering journey, not table management or bookings
- **Not a rewards or loyalty product** — no points, cashback, or membership tiers; dishly earns retention through discovery quality, not incentive mechanics
- **Not a review destination** — reviews surface on restaurant pages as a quality signal within discovery, but writing and reading reviews is not the core user behavior; dishly does not compete with Yelp's review-platform value proposition
- **Not a restaurant management tool** — no B2B operator CRM, guest management, or restaurant marketing suite; dishly's relationship is with the diner

---

## Durability Note

This vision holds as long as dominant delivery platforms remain discovery-poor and optimize for margin over food quality, and as long as consumers expect a dedicated surface to find food worth eating rather than delegating that judgment to ambient AI search. It would need to be reconsidered if a major delivery platform (DoorDash, Uber Eats) credibly solves the discovery quality problem at scale, or if AI-native search (Google, ChatGPT) makes standalone restaurant discovery surfaces obsolete for the average consumer.

Expected stable horizon: 5 years.

---

## Change History

| Date | What changed | Why |
|------|-------------|-----|
| 2026-06-05 | Initial vision | Collaborative session; scope established as discovery + delivery only, explicitly excluding reservations, loyalty/rewards, and restaurant-side tooling |
