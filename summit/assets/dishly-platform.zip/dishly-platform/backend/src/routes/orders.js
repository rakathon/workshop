const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const meta = (code = 'OK') => ({ status: { code }, operation: { request_id: uuidv4() } });

function buildOrderResponse(order, items) {
  return {
    id: order.id,
    restaurant_id: order.restaurant_id,
    restaurant_name: db.prepare('SELECT name FROM restaurant WHERE id = ?').get(order.restaurant_id)?.name || '',
    items: items.map(i => ({
      id: i.id,
      menu_item_id: i.menu_item_id,
      item_name: i.item_name,
      quantity: i.quantity,
      unit_price: { value: i.unit_price_value, scale: i.unit_price_scale },
    })),
    delivery_address: order.delivery_address,
    subtotal: { value: order.subtotal_value, scale: order.subtotal_scale },
    delivery_fee: { value: order.delivery_fee_value, scale: order.delivery_fee_scale },
    total: { value: order.total_value, scale: order.total_scale },
    status: order.status,
    created_at: order.created_at,
  };
}

// POST /orders
router.post('/', requireAuth, (req, res) => {
  const { restaurant_id, items, delivery_address, payment_method_id } = req.body || {};

  if (!restaurant_id || !items?.length || !delivery_address || !payment_method_id) {
    return res.status(400).json({
      errors: [{ code: 'BAD_REQUEST', message: 'Missing required fields' }],
      meta: meta('BAD_REQUEST'),
    });
  }

  // Validate all items belong to the given restaurant
  const itemStmt = db.prepare('SELECT id, section_id, name, price_value, price_scale FROM menu_item WHERE id = ?');
  const sectionStmt = db.prepare('SELECT restaurant_id FROM menu_section WHERE id = ?');

  const resolvedItems = [];
  for (const reqItem of items) {
    if (!reqItem.menu_item_id || reqItem.quantity < 1) {
      return res.status(422).json({
        errors: [{ code: 'VALIDATION_ERROR', message: 'Invalid item' }],
        meta: meta('VALIDATION_ERROR'),
      });
    }
    const menuItem = itemStmt.get(reqItem.menu_item_id);
    if (!menuItem) {
      return res.status(422).json({
        errors: [{ code: 'VALIDATION_ERROR', message: `Menu item not found: ${reqItem.menu_item_id}` }],
        meta: meta('VALIDATION_ERROR'),
      });
    }
    const section = sectionStmt.get(menuItem.section_id);
    if (section.restaurant_id !== restaurant_id) {
      return res.status(422).json({
        errors: [{ code: 'VALIDATION_ERROR', message: 'All items must belong to the same restaurant' }],
        meta: meta('VALIDATION_ERROR'),
      });
    }
    resolvedItems.push({ ...menuItem, quantity: reqItem.quantity });
  }

  // Compute totals (integer arithmetic)
  const subtotalValue = resolvedItems.reduce((sum, i) => sum + i.price_value * i.quantity, 0);
  const deliveryFeeValue = 399;
  const totalValue = subtotalValue + deliveryFeeValue;

  const orderId = uuidv4();
  const createdAt = new Date().toISOString();

  const createOrder = db.transaction(() => {
    db.prepare(
      `INSERT INTO "order" (id, user_id, restaurant_id, delivery_address, subtotal_value, subtotal_scale, delivery_fee_value, delivery_fee_scale, total_value, total_scale, status, created_at)
       VALUES (?, ?, ?, ?, ?, 2, 399, 2, ?, 2, 'confirmed', ?)`
    ).run(orderId, req.user.id, restaurant_id, delivery_address, subtotalValue, totalValue, createdAt);

    const insertItem = db.prepare(
      'INSERT INTO order_item (id, order_id, menu_item_id, item_name, quantity, unit_price_value, unit_price_scale) VALUES (?, ?, ?, ?, ?, ?, 2)'
    );
    resolvedItems.forEach(i => insertItem.run(uuidv4(), orderId, i.id, i.name, i.quantity, i.price_value));
  });

  createOrder();

  const order = db.prepare('SELECT * FROM "order" WHERE id = ?').get(orderId);
  const orderItems = db.prepare('SELECT * FROM order_item WHERE order_id = ?').all(orderId);

  return res.status(201)
    .location(`/dishly/v1/orders/${orderId}`)
    .json({ data: buildOrderResponse(order, orderItems), meta: meta('CREATED') });
});

// GET /orders/:id
router.get('/:id', requireAuth, (req, res) => {
  const order = db.prepare('SELECT * FROM "order" WHERE id = ? AND deleted_at IS NULL').get(req.params.id);

  if (!order) {
    return res.status(404).json({
      errors: [{ code: 'NOT_FOUND', message: 'Order not found' }],
      meta: meta('NOT_FOUND'),
    });
  }
  if (order.user_id !== req.user.id) {
    return res.status(403).json({
      errors: [{ code: 'FORBIDDEN', message: 'Access denied' }],
      meta: meta('FORBIDDEN'),
    });
  }

  const items = db.prepare('SELECT * FROM order_item WHERE order_id = ?').all(order.id);
  return res.json({ data: buildOrderResponse(order, items), meta: meta() });
});

module.exports = router;
