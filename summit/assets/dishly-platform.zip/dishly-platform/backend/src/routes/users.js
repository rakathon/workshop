const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const meta = (code) => ({
  status: { code },
  operation: { request_id: uuidv4() },
});

router.get('/me/orders', requireAuth, (req, res) => {
  const orders = db.prepare(
    'SELECT * FROM "order" WHERE user_id = ? AND deleted_at IS NULL ORDER BY created_at DESC'
  ).all(req.user.id);

  const restaurantStmt = db.prepare('SELECT name FROM restaurant WHERE id = ?');
  const itemsStmt = db.prepare('SELECT * FROM order_item WHERE order_id = ?');

  const data = orders.map(order => {
    const items = itemsStmt.all(order.id);
    return {
      id: order.id,
      restaurant_id: order.restaurant_id,
      restaurant_name: restaurantStmt.get(order.restaurant_id)?.name || '',
      items: items.map(i => ({
        id: i.id,
        menu_item_id: i.menu_item_id,
        item_name: i.item_name,
        quantity: i.quantity,
        unit_price: { value: i.unit_price_value, scale: i.unit_price_scale },
      })),
      delivery_address: order.delivery_address,
      subtotal: { value: order.subtotal_value, scale: order.subtotal_scale },
      delivery_fee: { value: order.delivery_fee_value, scale: order.delivery_fee_scale },
      total: { value: order.total_value, scale: order.total_scale },
      status: order.status,
      created_at: order.created_at,
    };
  });

  return res.status(200).json({ data, pagination: { next: null }, meta: meta('OK') });
});

router.get('/me', requireAuth, (req, res) => {
  const row = db.prepare('SELECT id, email, name, phone, created_at FROM user WHERE id = ?').get(req.user.id);

  if (!row) {
    return res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'User not found' }],
      meta: meta('UNAUTHORIZED'),
    });
  }

  return res.status(200).json({ data: row, meta: meta('OK') });
});

router.patch('/me', requireAuth, (req, res) => {
  const { name, phone } = req.body || {};
  const sets = [];
  const params = [];

  if (name !== undefined) {
    if (typeof name === 'string' && name.trim().length === 0) {
      return res.status(422).json({
        errors: [{ code: 'VALIDATION_ERROR', message: 'Name cannot be empty' }],
        meta: meta('VALIDATION_ERROR'),
      });
    }
    sets.push('name = ?');
    params.push(name === null ? null : name.trim());
  }

  if (phone !== undefined) {
    if (phone === null || phone === '') {
      sets.push('phone = ?');
      params.push(null);
    } else {
      const digits = String(phone).replace(/[\s\-\(\)]/g, '');
      if (!/^\d{7,15}$/.test(digits)) {
        return res.status(422).json({
          errors: [{ code: 'VALIDATION_ERROR', message: 'Phone must contain 7-15 digits only' }],
          meta: meta('VALIDATION_ERROR'),
        });
      }
      sets.push('phone = ?');
      params.push(digits);
    }
  }

  if (sets.length === 0) {
    const row = db.prepare('SELECT id, email, name, phone, created_at FROM user WHERE id = ?').get(req.user.id);
    return res.status(200).json({ data: row, meta: meta('OK') });
  }

  params.push(req.user.id);
  db.prepare('UPDATE user SET ' + sets.join(', ') + ' WHERE id = ?').run(...params);
  const row = db.prepare('SELECT id, email, name, phone, created_at FROM user WHERE id = ?').get(req.user.id);
  return res.status(200).json({ data: row, meta: meta('OK') });
});

module.exports = router;
