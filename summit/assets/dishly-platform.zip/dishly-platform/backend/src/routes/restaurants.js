const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const router = express.Router();

const meta = (code = 'OK') => ({ status: { code }, operation: { request_id: uuidv4() } });

function toSummary(row) {
  return {
    id: row.id, name: row.name, price_range: row.price_range,
    cover_image_url: row.cover_image_url, average_rating: row.average_rating,
    cuisine: { id: row.cuisine_id, name: row.cuisine_name },
    neighbourhood: { id: row.neighbourhood_id, name: row.neighbourhood_name },
  };
}

router.get('/', (req, res) => {
  const { q, cuisine_id, neighbourhood_id, price_range, limit = 20, cursor } = req.query;
  const cap = Math.min(parseInt(limit) || 20, 100);

  let sql = `
    SELECT DISTINCT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
           c.id as cuisine_id, c.name as cuisine_name,
           n.id as neighbourhood_id, n.name as neighbourhood_name
    FROM restaurant r
    JOIN cuisine c ON c.id = r.cuisine_id
    JOIN neighbourhood n ON n.id = r.neighbourhood_id
  `;
  const conditions = [];
  const params = [];

  if (q) {
    sql += ' LEFT JOIN menu_section ms ON ms.restaurant_id = r.id LEFT JOIN menu_item mi ON mi.section_id = ms.id';
    conditions.push('(r.name LIKE ? OR mi.name LIKE ?)');
    params.push(`%${q}%`, `%${q}%`);
  }
  if (cuisine_id) { conditions.push('r.cuisine_id = ?'); params.push(cuisine_id); }
  if (neighbourhood_id) { conditions.push('r.neighbourhood_id = ?'); params.push(neighbourhood_id); }
  if (price_range) { conditions.push('r.price_range = ?'); params.push(price_range); }
  if (cursor) { conditions.push('r.id > ?'); params.push(cursor); }

  if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
  sql += ' ORDER BY r.name ASC LIMIT ?';
  params.push(cap + 1);

  const rows = db.prepare(sql).all(...params);
  const hasMore = rows.length > cap;
  const data = rows.slice(0, cap).map(toSummary);

  res.json({
    data,
    pagination: { next: hasMore ? data[data.length - 1].id : null },
    meta: meta(),
  });
});

router.get('/:id', (req, res) => {
  const row = db.prepare(`
    SELECT r.*, c.id as cuisine_id, c.name as cuisine_name,
           n.id as neighbourhood_id, n.name as neighbourhood_name
    FROM restaurant r
    JOIN cuisine c ON c.id = r.cuisine_id
    JOIN neighbourhood n ON n.id = r.neighbourhood_id
    WHERE r.id = ?
  `).get(req.params.id);

  if (!row) {
    return res.status(404).json({
      errors: [{ code: 'NOT_FOUND', message: 'Restaurant not found' }],
      meta: meta('NOT_FOUND'),
    });
  }

  const sections = db.prepare('SELECT id, name, sort_order FROM menu_section WHERE restaurant_id = ? ORDER BY sort_order ASC').all(row.id);
  const itemStmt = db.prepare('SELECT id, name, description, price_value, price_scale, image_url FROM menu_item WHERE section_id = ?');
  const reviews = db.prepare('SELECT id, author_name, rating, body, review_date FROM review WHERE restaurant_id = ? ORDER BY review_date DESC LIMIT 5').all(row.id);

  const menu = sections.map(s => ({
    id: s.id, name: s.name,
    items: itemStmt.all(s.id).map(i => ({
      id: i.id, name: i.name, description: i.description,
      price: { value: i.price_value, scale: i.price_scale },
      image_url: i.image_url,
    })),
  }));

  res.json({
    data: {
      id: row.id, name: row.name, price_range: row.price_range,
      cover_image_url: row.cover_image_url, average_rating: row.average_rating,
      description: row.description, address: row.address,
      delivery_radius_km: row.delivery_radius_km,
      cuisine: { id: row.cuisine_id, name: row.cuisine_name },
      neighbourhood: { id: row.neighbourhood_id, name: row.neighbourhood_name },
      menu,
      reviews: reviews.map(r => ({
        id: r.id, author_name: r.author_name, rating: r.rating,
        body: r.body, review_date: r.review_date,
      })),
    },
    meta: meta(),
  });
});

module.exports = router;
