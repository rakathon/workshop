const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const router = express.Router();

// Collection templates — each defines a rule that queries the DB at runtime.
// No hardcoded restaurant IDs: collections are always fresh after a re-seed.
const COLLECTION_TEMPLATES = [
  {
    id: 'date-night',
    title: 'Date Night Favourites',
    description: 'Atmosphere and great food — the perfect evening out',
    sql: `
      SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
             c.id as cuisine_id, c.name as cuisine_name,
             n.id as neighbourhood_id, n.name as neighbourhood_name
      FROM restaurant r
      JOIN cuisine c ON c.id = r.cuisine_id
      JOIN neighbourhood n ON n.id = r.neighbourhood_id
      WHERE r.neighbourhood_id = ?
        AND r.price_range IN ('$$', '$$$')
        AND r.average_rating >= 4.5
        AND c.name IN ('Italian', 'French', 'Japanese', 'Mediterranean', 'Korean')
      ORDER BY r.average_rating DESC
      LIMIT 6
    `,
  },
  {
    id: 'neighbourhood-gems',
    title: 'Neighbourhood Gems',
    description: 'Local spots the regulars keep to themselves',
    sql: `
      SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
             c.id as cuisine_id, c.name as cuisine_name,
             n.id as neighbourhood_id, n.name as neighbourhood_name
      FROM restaurant r
      JOIN cuisine c ON c.id = r.cuisine_id
      JOIN neighbourhood n ON n.id = r.neighbourhood_id
      WHERE r.neighbourhood_id = ?
        AND r.price_range IN ('$', '$$')
        AND r.average_rating >= 4.3
      ORDER BY r.average_rating DESC, r.name ASC
      LIMIT 6
    `,
  },
  {
    id: 'quick-lunch',
    title: 'Quick Lunch Spots',
    description: 'Fast, good, and worth stepping out for',
    sql: `
      SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
             c.id as cuisine_id, c.name as cuisine_name,
             n.id as neighbourhood_id, n.name as neighbourhood_name
      FROM restaurant r
      JOIN cuisine c ON c.id = r.cuisine_id
      JOIN neighbourhood n ON n.id = r.neighbourhood_id
      WHERE r.neighbourhood_id = ?
        AND r.price_range = '$'
        AND c.name IN ('American', 'Mexican', 'Chinese', 'Indian', 'Thai', 'Japanese', 'Korean')
      ORDER BY r.average_rating DESC
      LIMIT 6
    `,
  },
  {
    id: 'worth-the-splurge',
    title: 'Worth the Splurge',
    description: 'Special occasion restaurants that justify the bill',
    sql: `
      SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
             c.id as cuisine_id, c.name as cuisine_name,
             n.id as neighbourhood_id, n.name as neighbourhood_name
      FROM restaurant r
      JOIN cuisine c ON c.id = r.cuisine_id
      JOIN neighbourhood n ON n.id = r.neighbourhood_id
      WHERE r.neighbourhood_id = ?
        AND r.price_range = '$$$'
        AND r.average_rating >= 4.5
      ORDER BY r.average_rating DESC
      LIMIT 6
    `,
  },
  {
    id: 'plant-forward',
    title: 'Plant-Forward Picks',
    description: 'Vegetable-driven and vegetarian-friendly menus worth exploring',
    sql: `
      SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
             c.id as cuisine_id, c.name as cuisine_name,
             n.id as neighbourhood_id, n.name as neighbourhood_name
      FROM restaurant r
      JOIN cuisine c ON c.id = r.cuisine_id
      JOIN neighbourhood n ON n.id = r.neighbourhood_id
      WHERE r.neighbourhood_id = ?
        AND c.name IN ('Mediterranean', 'Indian', 'Thai', 'Mexican', 'Chinese')
        AND r.average_rating >= 4.2
      ORDER BY r.average_rating DESC
      LIMIT 6
    `,
  },
  {
    id: 'best-ramen',
    title: 'Best Ramen & Noodles',
    description: 'Hand-picked noodle shops worth the trip',
    sql: `
      SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
             c.id as cuisine_id, c.name as cuisine_name,
             n.id as neighbourhood_id, n.name as neighbourhood_name
      FROM restaurant r
      JOIN cuisine c ON c.id = r.cuisine_id
      JOIN neighbourhood n ON n.id = r.neighbourhood_id
      WHERE r.neighbourhood_id = ?
        AND c.name IN ('Japanese', 'Chinese', 'Korean', 'Thai')
        AND r.average_rating >= 4.2
      ORDER BY r.average_rating DESC
      LIMIT 6
    `,
  },
];

function toSummary(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    price_range: row.price_range,
    cover_image_url: row.cover_image_url,
    average_rating: row.average_rating,
    cuisine: { id: row.cuisine_id, name: row.cuisine_name },
    neighbourhood: { id: row.neighbourhood_id, name: row.neighbourhood_name },
  };
}

const meta = () => ({ status: { code: 'OK' }, operation: { request_id: uuidv4() } });

// Relaxed templates for smaller neighbourhoods (< 15 restaurants)
const RELAXED_TEMPLATES = [
  {
    id: 'date-night',
    title: 'Date Night Favourites',
    description: 'Atmosphere and great food — the perfect evening out',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.neighbourhood_id = ? AND r.average_rating >= 4.3
            AND c.name IN ('Italian','French','Japanese','Mediterranean','Korean')
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
  {
    id: 'neighbourhood-gems',
    title: 'Neighbourhood Gems',
    description: 'Local spots the regulars keep to themselves',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.neighbourhood_id = ? AND r.average_rating >= 4.0
          ORDER BY r.average_rating DESC, r.name ASC LIMIT 6`,
  },
  {
    id: 'quick-lunch',
    title: 'Quick Lunch Spots',
    description: 'Fast, good, and worth stepping out for',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.neighbourhood_id = ?
            AND c.name IN ('American','Mexican','Chinese','Indian','Thai','Korean')
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
  {
    id: 'worth-the-splurge',
    title: 'Worth the Splurge',
    description: 'Special occasion restaurants that justify the bill',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.neighbourhood_id = ? AND r.price_range IN ('$$$','$$') AND r.average_rating >= 4.2
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
  {
    id: 'plant-forward',
    title: 'Plant-Forward Picks',
    description: 'Vegetable-driven and vegetarian-friendly menus worth exploring',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.neighbourhood_id = ?
            AND c.name IN ('Mediterranean','Indian','Thai','Mexican','Chinese','Korean','Japanese')
            AND r.average_rating >= 4.0
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
  {
    id: 'best-ramen',
    title: 'Best Ramen & Noodles',
    description: 'Hand-picked noodle shops worth the trip',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.neighbourhood_id = ?
            AND c.name IN ('Japanese','Chinese','Korean','Thai')
            AND r.average_rating >= 4.0
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
];

// Global collection templates — no neighbourhood filter, picks best across all cities
const GLOBAL_TEMPLATES = [
  {
    id: 'date-night',
    title: 'Date Night Favourites',
    description: 'Atmosphere and great food — the perfect evening out',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.price_range IN ('$$','$$$') AND r.average_rating >= 4.7
            AND c.name IN ('Italian','French','Japanese','Mediterranean','Korean')
          ORDER BY r.average_rating DESC, r.name ASC LIMIT 6`,
  },
  {
    id: 'neighbourhood-gems',
    title: 'Neighbourhood Gems',
    description: 'Local spots the regulars keep to themselves',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.price_range IN ('$','$$') AND r.average_rating >= 4.5
          ORDER BY r.average_rating DESC, r.name ASC LIMIT 6`,
  },
  {
    id: 'quick-lunch',
    title: 'Quick Lunch Spots',
    description: 'Fast, good, and worth stepping out for',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.price_range = '$' AND r.average_rating >= 4.5
            AND c.name IN ('American','Mexican','Chinese','Indian','Thai','Japanese','Korean')
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
  {
    id: 'worth-the-splurge',
    title: 'Worth the Splurge',
    description: 'Special occasion restaurants that justify the bill',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE r.price_range = '$$$' AND r.average_rating >= 4.7
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
  {
    id: 'plant-forward',
    title: 'Plant-Forward Picks',
    description: 'Vegetable-driven and vegetarian-friendly menus worth exploring',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE c.name IN ('Mediterranean','Indian','Thai','Mexican','Chinese','Korean','Japanese')
            AND r.average_rating >= 4.6
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
  {
    id: 'best-ramen',
    title: 'Best Ramen & Noodles',
    description: 'Hand-picked noodle shops worth the trip',
    sql: `SELECT r.id, r.name, r.price_range, r.cover_image_url, r.average_rating,
                 c.id as cuisine_id, c.name as cuisine_name,
                 n.id as neighbourhood_id, n.name as neighbourhood_name
          FROM restaurant r JOIN cuisine c ON c.id = r.cuisine_id JOIN neighbourhood n ON n.id = r.neighbourhood_id
          WHERE c.name IN ('Japanese','Chinese','Korean','Thai') AND r.average_rating >= 4.6
          ORDER BY r.average_rating DESC LIMIT 6`,
  },
];

router.get('/', (req, res) => {
  const { neighbourhood_id } = req.query;

  if (!neighbourhood_id) {
    // No city selected: show best restaurants across ALL cities
    const result = GLOBAL_TEMPLATES.map(tpl => {
      const rows = db.prepare(tpl.sql).all();
      const restaurants = rows.map(toSummary).filter(Boolean);
      return restaurants.length >= 3
        ? { id: tpl.id, title: tpl.title, description: tpl.description, restaurants }
        : null;
    }).filter(Boolean);

    return res.json({ data: result, meta: meta() });
  }

  // Check neighbourhood size to decide template strictness
  const count = db.prepare('SELECT COUNT(*) as cnt FROM restaurant WHERE neighbourhood_id = ?').get(neighbourhood_id);
  const templates = (count?.cnt || 0) < 15 ? RELAXED_TEMPLATES : COLLECTION_TEMPLATES;

  // City selected: run each template filtered to this neighbourhood
  const result = templates.map(tpl => {
    const rows = db.prepare(tpl.sql).all(neighbourhood_id);
    const restaurants = rows.map(toSummary).filter(Boolean);
    return restaurants.length >= 3
      ? { id: `${tpl.id}-${neighbourhood_id}`, title: tpl.title, description: tpl.description, restaurants }
      : null;
  }).filter(Boolean);

  res.json({ data: result, meta: meta() });
});

router.get('/:id', (req, res) => {
  // For direct collection lookup by template id, return global (no city filter)
  const tplId = req.params.id.split('-').slice(0, -1).join('-') || req.params.id;
  const tpl = COLLECTION_TEMPLATES.find(t => t.id === tplId) ||
              COLLECTION_TEMPLATES.find(t => req.params.id.startsWith(t.id));

  if (!tpl) {
    return res.status(404).json({
      errors: [{ code: 'NOT_FOUND', message: 'Collection not found' }],
      meta: { status: { code: 'NOT_FOUND' }, operation: { request_id: uuidv4() } },
    });
  }

  // Use the first neighbourhood as fallback for direct lookups
  const firstNeigh = db.prepare('SELECT id FROM neighbourhood ORDER BY name LIMIT 1').get();
  const rows = db.prepare(tpl.sql).all(firstNeigh?.id || '');
  const restaurants = rows.map(toSummary).filter(Boolean);
  res.json({ data: { id: tpl.id, title: tpl.title, description: tpl.description, restaurants }, meta: meta() });
});

module.exports = router;
