const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
const VALID = ['Visa', 'Mastercard', 'Amex'];
const meta = (code) => ({ status: { code }, operation: { request_id: uuidv4() } });

function toPM(row) {
  return { id: row.id, card_type: row.card_type, cardholder_name: row.cardholder_name, last_four: row.last_four || null, created_at: row.created_at };
}

router.get('/me/payment_methods', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM user_payment_method WHERE user_id = ? ORDER BY created_at ASC').all(req.user.id);
  return res.status(200).json({ data: rows.map(toPM), pagination: { next: null }, meta: meta('OK') });
});

router.post('/me/payment_methods', requireAuth, (req, res) => {
  const { card_type, cardholder_name, card_number } = req.body || {};
  if (!card_type || !VALID.includes(card_type)) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'card_type must be Visa, Mastercard, or Amex' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  if (!cardholder_name || !String(cardholder_name).trim()) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'cardholder_name is required' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  if (!card_number) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'card_number is required' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  const digits = String(card_number).replace(/\s/g, '');
  if (!/^\d{16}$/.test(digits)) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'card_number must be 16 digits' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  const count = db.prepare('SELECT COUNT(*) as n FROM user_payment_method WHERE user_id = ?').get(req.user.id).n;
  if (count >= 2) {
    return res.status(422).json({
      errors: [{ code: 'CAP_EXCEEDED', message: 'Maximum of 2 payment methods reached' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  const id = uuidv4();
  const created_at = new Date().toISOString();
  const last_four = digits.slice(-4);
  db.prepare('INSERT INTO user_payment_method (id, user_id, card_type, cardholder_name, last_four, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    id, req.user.id, card_type, String(cardholder_name).trim(), last_four, created_at
  );
  const row = db.prepare('SELECT * FROM user_payment_method WHERE id = ?').get(id);
  return res.status(201).location('/dishly/v1/users/me/payment_methods/' + id).json({ data: toPM(row), meta: meta('CREATED') });
});

router.patch('/me/payment_methods/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM user_payment_method WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ errors: [{ code: 'NOT_FOUND', message: 'Payment method not found' }], meta: meta('NOT_FOUND') });
  const { card_type, cardholder_name } = req.body || {};
  if (card_type && !VALID.includes(card_type)) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'card_type must be Visa, Mastercard, or Amex' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  db.prepare('UPDATE user_payment_method SET card_type = ?, cardholder_name = ? WHERE id = ?').run(
    card_type || row.card_type,
    cardholder_name ? String(cardholder_name).trim() : row.cardholder_name,
    req.params.id
  );
  const updated = db.prepare('SELECT * FROM user_payment_method WHERE id = ?').get(req.params.id);
  return res.status(200).json({ data: toPM(updated), meta: meta('OK') });
});

router.delete('/me/payment_methods/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT id FROM user_payment_method WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ errors: [{ code: 'NOT_FOUND', message: 'Payment method not found' }], meta: meta('NOT_FOUND') });
  db.prepare('DELETE FROM user_payment_method WHERE id = ?').run(req.params.id);
  return res.status(204).send();
});

module.exports = router;
