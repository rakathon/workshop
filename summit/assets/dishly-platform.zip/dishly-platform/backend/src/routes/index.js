const express = require('express');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

router.use('/auth', require('./auth'));
router.use('/users', require('./users'));
router.use('/users', require('./addresses'));
router.use('/users', require('./payment_methods'));
router.use('/cuisines', require('./cuisines'));
router.use('/neighbourhoods', require('./neighbourhoods'));
router.use('/collections', require('./collections'));
router.use('/restaurants', require('./restaurants'));
router.use('/orders', require('./orders'));

router.use((req, res) => {
  res.status(404).json({
    errors: [{ code: 'NOT_FOUND', message: 'Not found' }],
    meta: {
      status: { code: 'NOT_FOUND' },
      operation: { request_id: uuidv4() },
    },
  });
});

module.exports = router;
