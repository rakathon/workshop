const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const { hashPassword, comparePassword, signToken } = require('../middleware/auth');

const router = express.Router();

const meta = (code) => ({
  status: { code },
  operation: { request_id: uuidv4() },
});

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body || {};

  if (!email || typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'Invalid email format' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  if (!password || password.length < 8) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'Password must be at least 8 characters' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }

  const existing = db.prepare('SELECT id FROM user WHERE email = ?').get(email.toLowerCase());
  if (existing) {
    return res.status(409).json({
      errors: [{ code: 'CONFLICT', message: 'Email already registered' }],
      meta: meta('CONFLICT'),
    });
  }

  const id = uuidv4();
  const password_hash = await hashPassword(password);
  const created_at = new Date().toISOString();

  try {
    db.prepare('INSERT INTO user (id, email, password_hash, name, created_at) VALUES (?, ?, ?, ?, ?)')
      .run(id, email.toLowerCase(), password_hash, name ? name.trim() : null, created_at);
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return res.status(409).json({
        errors: [{ code: 'CONFLICT', message: 'Email already registered' }],
        meta: meta('CONFLICT'),
      });
    }
    throw err;
  }

  const user = { id, email: email.toLowerCase(), name: name ? name.trim() : null, phone: null, created_at };
  const token = signToken(id);

  return res.status(201)
    .location(`/dishly/v1/users/me`)
    .json({ data: { user, token }, meta: meta('CREATED') });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};

  const row = email
    ? db.prepare('SELECT id, email, password_hash, name, phone, created_at FROM user WHERE email = ?').get(email.toLowerCase())
    : null;

  const valid = row && password ? await comparePassword(password, row.password_hash) : false;

  if (!valid) {
    return res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'Invalid email or password' }],
      meta: meta('UNAUTHORIZED'),
    });
  }

  const user = { id: row.id, email: row.email, name: row.name || null, phone: row.phone || null, created_at: row.created_at };
  const token = signToken(row.id);

  return res.status(200).json({ data: { user, token }, meta: meta('OK') });
});

module.exports = router;
