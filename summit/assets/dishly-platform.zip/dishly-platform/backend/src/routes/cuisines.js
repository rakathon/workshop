const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const router = express.Router();

router.get('/', (req, res) => {
  const cuisines = db.prepare('SELECT id, name FROM cuisine ORDER BY name ASC').all();
  res.json({
    data: cuisines,
    meta: { status: { code: 'OK' }, operation: { request_id: uuidv4() } },
  });
});

module.exports = router;
