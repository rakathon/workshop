const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/connection');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
const meta = (code) => ({ status: { code }, operation: { request_id: uuidv4() } });

function toAddress(row) {
  return {
    id: row.id,
    label: row.label || null,
    street: row.street,
    city: row.city,
    postcode: row.postcode,
    is_default: row.is_default === 1,
    created_at: row.created_at,
  };
}

router.get('/me/addresses', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM user_address WHERE user_id = ? ORDER BY created_at ASC').all(req.user.id);
  return res.status(200).json({ data: rows.map(toAddress), pagination: { next: null }, meta: meta('OK') });
});

router.post('/me/addresses', requireAuth, (req, res) => {
  const { label, street, city, postcode, is_default } = req.body || {};
  if (!street || !city || !postcode) {
    return res.status(422).json({
      errors: [{ code: 'VALIDATION_ERROR', message: 'street, city, and postcode are required' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  const count = db.prepare('SELECT COUNT(*) as n FROM user_address WHERE user_id = ?').get(req.user.id).n;
  if (count >= 2) {
    return res.status(422).json({
      errors: [{ code: 'CAP_EXCEEDED', message: 'Maximum of 2 addresses reached' }],
      meta: meta('VALIDATION_ERROR'),
    });
  }
  const id = uuidv4();
  const created_at = new Date().toISOString();
  const setDef = is_default ? 1 : (count === 0 ? 1 : 0);
  if (setDef) db.prepare('UPDATE user_address SET is_default = 0 WHERE user_id = ?').run(req.user.id);
  db.prepare(
    'INSERT INTO user_address (id, user_id, label, street, city, postcode, is_default, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(id, req.user.id, label || null, street.trim(), city.trim(), postcode.trim(), setDef, created_at);
  const row = db.prepare('SELECT * FROM user_address WHERE id = ?').get(id);
  return res.status(201).location('/dishly/v1/users/me/addresses/' + id).json({ data: toAddress(row), meta: meta('CREATED') });
});

router.patch('/me/addresses/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM user_address WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ errors: [{ code: 'NOT_FOUND', message: 'Address not found' }], meta: meta('NOT_FOUND') });
  const { label, street, city, postcode, is_default } = req.body || {};
  if (is_default) db.prepare('UPDATE user_address SET is_default = 0 WHERE user_id = ?').run(req.user.id);
  db.prepare('UPDATE user_address SET label = ?, street = ?, city = ?, postcode = ?, is_default = ? WHERE id = ?').run(
    label !== undefined ? label : row.label,
    street ? street.trim() : row.street,
    city ? city.trim() : row.city,
    postcode ? postcode.trim() : row.postcode,
    is_default !== undefined ? (is_default ? 1 : 0) : row.is_default,
    req.params.id
  );
  const updated = db.prepare('SELECT * FROM user_address WHERE id = ?').get(req.params.id);
  return res.status(200).json({ data: toAddress(updated), meta: meta('OK') });
});

router.delete('/me/addresses/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT id FROM user_address WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ errors: [{ code: 'NOT_FOUND', message: 'Address not found' }], meta: meta('NOT_FOUND') });
  db.prepare('DELETE FROM user_address WHERE id = ?').run(req.params.id);
  return res.status(204).send();
});

module.exports = router;
