const db = require('./connection');
const { v4: uuidv4 } = require('uuid');

function seed() {
  const existingNeighbourhoods = db.prepare('SELECT COUNT(*) as count FROM neighbourhood').get();
  if (existingNeighbourhoods.count >= 10) {
    console.log('[seed] Already seeded — skipping.');
    return;
  }

  console.log('[seed] Seeding restaurants...');

  const cuisineNames = ['Japanese', 'Italian', 'Mexican', 'Indian', 'Thai', 'American', 'Chinese', 'Mediterranean', 'Korean', 'French'];
  const cuisines = cuisineNames.map(name => ({ id: uuidv4(), name }));
  const cuisineMap = Object.fromEntries(cuisines.map(c => [c.name, c.id]));

  const neighbourhoodNames = ['Manhattan', 'Brooklyn', 'Queens', 'Williamsburg', 'Astoria', 'Los Angeles', 'Chicago', 'Boston', 'Miami', 'San Francisco'];
  const neighbourhoods = neighbourhoodNames.map(name => ({ id: uuidv4(), name }));
  const neighMap = Object.fromEntries(neighbourhoods.map(n => [n.name, n.id]));

  const photos = [
    '1555396273-367ea4eb4db5', '1414235077428-338989a2e8c0', '1568901346375-23c9450c58cd',
    '1504674900247-0877df9cc836', '1565299585323-38d6b0865b47', '1547592180-85f173990554',
    '1567620905732-2d1ec7ab7445', '1546069901-ba9599a7e63c', '1512621776951-a57141f2eefd',
    '1555939594-58d7cb561ad1', '1432139555190-58524dae6a55', '1482049016688-2d3e1b311543',
    '1490645935967-10de6ba17061', '1473093295043-cdd812d0e601', '1484723091739-30a097e8f929',
    '1498837167922-ddd27525d352', '1559847844-5315695dadae', '1565958011703-44f9829ba187',
    '1504754017168-9d1f09ca8e18', '1519984388953-d2406bc725e1',
  ];
  const photoUrl = (i) => `https://images.unsplash.com/photo-${photos[i % photos.length]}?w=800&q=80&sig=${i}`;

  // 200-slot photo pool: 35 unique Unsplash food photos × 6 crops = 210 slots (use first 200)
  const PHOTO_IDS = [
    '1555396273-367ea4eb4db5', '1414235077428-338989a2e8c0', '1568901346375-23c9450c58cd',
    '1504674900247-0877df9cc836', '1565299585323-38d6b0865b47', '1547592180-85f173990554',
    '1567620905732-2d1ec7ab7445', '1512621776951-a57141f2eefd', '1555939594-58d7cb561ad1',
    '1432139555190-58524dae6a55', '1482049016688-2d3e1b311543', '1490645935967-10de6ba17061',
    '1473093295043-cdd812d0e601', '1484723091739-30a097e8f929', '1513104890138-7c749659a591',
    '1541745537411-b8046dc6d66c', '1569718212165-3a8278d5f624', '1565299624946-b28f40a0ae38',
    '1544025162-d76694265947',    '1585937421612-70a008356fbe', '1563379926898-05f4575a45d8',
    '1529193591184-b1d58069ecdd', '1571091718767-18b5b1457add', '1519984388953-d2406bc725e1',
    '1498837167922-ddd27525d352', '1559847844-5315695dadae',    '1565958011703-44f9829ba187',
    '1546069901-ba9599a7e63c',    '1512058564366-18510be2db19', '1493770348161-369560ae357d',
    '1534482421-64566f976cfa',    '1607532941433-304659e8198a', '1608835291093-394b0c943a75',
    '1467003909585-2f8a72700288', '1414235077428-338989a2e8c0',
  ];
  const CROPS = ['entropy', 'center', 'top', 'bottom', 'left', 'right'];
  // Each restaurant gets a globally unique slot (fallback only — named restaurants use RESTAURANT_COVER_PHOTOS)
  const indexedPhotoUrl = (idx) => {
    const photoId = PHOTO_IDS[idx % PHOTO_IDS.length];
    const crop = CROPS[Math.floor(idx / PHOTO_IDS.length) % CROPS.length];
    return `https://images.unsplash.com/photo-${photoId}?w=800&h=600&fit=crop&crop=${crop}&auto=format`;
  };

  // Curated per-restaurant cover photos — verified Unsplash IDs matched to each restaurant's name/cuisine
  const RESTAURANT_COVER_PHOTOS = {
    'Adda Indian Canteen': '1536305030588-45dc07a2a372',
    'Agora': '1583354608715-177553a4035e',
    'Alinea': '1663530761401-15eefb544889',
    'Atla': '1517248135467-4c7edcad34c4',
    'Atoboy': '1608816042754-d69cb2271bea',
    'Atomix': '1560053608-13721e0d69e8',
    'Au Cheval': '1564019709518-6182bdabe251',
    'Avec': '1636654931290-418d20865e03',
    'Ayada Thai': '1569050467447-ce54b3bbc37d',
    'Aziza': '1541518763669-27fef04b14ea',
    'Babu Ji': '1682862279256-b2a9e4f3d22c',
    'Bahari Estiatorio': '1577956991923-570f15fa49e0',
    'Balthazar': '1777714958871-1fe7255c5a87',
    'Bar Marseille': '1748355734689-6fc3aa65bb75',
    "Bavette's Bar & Boeuf": '1575844939619-2ab8aaeb9c9b',
    'Bestia': '1733956637568-b5924de9a943',
    'Bhatti Indian Grills': '1563310761-f8d8ed164063',
    'Boia De': '1709548145082-04d0cde481d4',
    'Buvette': '1765099271897-88318df3e76a',
    'Cafe Mogador': '1771344146422-efa774187282',
    'Café Sushi': '1504416285472-eccf03dd31eb',
    'Carbone': '1779898570499-2d02764833b3',
    'Casa Enrique': '1590846406792-0adc7f938f1d',
    'Cava': '1620041328526-d0cf044a0739',
    'China Live': '1596273250041-2c685b30041b',
    "Chug's Diner": '1563373011-d9b2e9af4167',
    "Coni'Seafood": '1613585178110-865f36420442',
    'Coppa': '1578474846511-04ba529f0b88',
    'Cosme': '1483648969698-5e7dcaa3444f',
    'Cote Korean Steakhouse': '1663530761401-15eefb544889',
    'Coyo Taco': '1683062332605-4e1209d75346',
    'Cvi.che 105': '1535399831218-d5bd36d1a6b3',
    "Daisy's": '1548696060-8fae845c6452',
    'Dhaba': '1559561724-732dbca7be1e',
    'Dhamaka': '1738291422837-85761f82a10e',
    'Diner': '1555992336-fb0d29498b13',
    'Dolo Restaurant & Bar': '1716177489813-ee2fd5b25355',
    'Don Angie': '1683117568939-875cf45b3f8b',
    'Dumpling House': '1762418967889-10abec43c325',
    'EN Japanese Brasserie': '1602273660127-a0000560a4c1',
    'Eastern Standard': '1549800076-831d7a97afac',
    'El Cielo': '1578474846511-04ba529f0b88',
    'El Parador Cafe': '1636405188904-bc706f07aa37',
    'Emily': '1594394206255-2a595c03448a',
    'Empellón': '1552332386-f8dd00dc2f85',
    'Fiola Mare': '1559339352-11d035aa65de',
    'Fish Cheeks': '1559314809-0d155014e29e',
    'Flushing Seafood': '1607095097076-bf0221751ed6',
    'Foreign Cinema': '1769184617504-be7e08f3a8b3',
    'Frank': '1688683035224-28a2d702383a',
    "Giacomo's": '1595007163136-82fb6da20c05',
    'Girl & the Goat': '1712026063351-61d52c2e4abb',
    'Gjusta': '1617333907797-1bac8b33af12',
    'Green Street Smoked Meats': '1708388464878-5df2d66b758e',
    'Guelaguetza': '1700625916627-16ad4fb0553c',
    'Guerrilla Tacos': '1627564803215-ad55bad5c5ea',
    'Hakata Tonton': '1569718212165-3a8278d5f624',
    'Hakkasan': '1725781747036-8071bd5497fb',
    'Hanon': '1769558688746-7ac36d8ce999',
    'Hometown Bar-B-Que': '1709433420601-6e473136571b',
    'Ilili': '1511690656952-34342bb7c2f2',
    'Insa': '1745646019056-bd23c2e580a9',
    'Ippudo Ramen': '1591814468924-caf88d1232e1',
    'Ippudo SF': '1572302920907-288481a7835e',
    'Island Creek Oyster Bar': '1578882422378-9ed72be08b5e',
    'J.G. Melon': '1693501424028-033518786ed7',
    'Jackson Diner': '1617692855027-33b14f061079',
    'Jaguar Sun': '1654630011491-b8aeea110a13',
    'Jitlada': '1548943487-a2e4e43b4853',
    "Joe's Shanghai": '1624067046879-cca70a7cf79c',
    "Jon & Vinny's": '1560053608-13721e0d69e8',
    'Jongro BBQ': '1677029969065-c9f4003a9ad5',
    'Ju-Ni': '1568018508399-e53bc8babdde',
    'Junoon': '1670058124043-4f55e08d0f8f',
    'KYU': '1628497622880-896ed64d6034',
    'Kang Ho-dong Baekjeong': '1628610698415-81371ab387e9',
    'Kiki on the River': '1727522793234-2e108fc0460b',
    'Kimchi Grill': '1498654896293-37aacf113fd9',
    'Kokkari Estiatorio': '1470497409162-889ff0ac5726',
    'Kon Chau': '1600757755361-8eb3d6d7b384',
    'Krasi': '1669036723270-5534b164e3e1',
    'Kyma': '1536514072410-5019a3c69182',
    "L'Artusi": '1658848541818-6cd64f678cba',
    "L'Express": '1614822180018-0620b4250ed1',
    'La Taqueria': '1551504734-5ee1c4a1479b',
    'Lai Hong Lounge': '1713616818666-738c7a597881',
    'Lan Sheng': '1716535232835-6d56282dfe8a',
    "Langer's Deli": '1647962307497-22a0218d72fa',
    'Le Bernardin': '1776993298453-b4d53a7a040f',
    'Le Coucou': '1758537697972-80ac6a32fa22',
    'Le Gigot': '1775124270427-dd7503c0b264',
    'Legal Sea Foods': '1717251752308-2ef72f07484e',
    'Liholiho Yacht Club': '1493278125710-29e0d5195764',
    'Lilia': '1636405189493-181ecf851006',
    'Loi Estiatorio': '1601581875039-e899893d520c',
    'Longman & Eagle': '1543007630-9710e4a00a20',
    'Los Tacos No. 1': '1565299585323-38d6b0865b47',
    "Lou Malnati's": '1734730594447-9ae47bcb255f',
    'Lucien': '1671510113581-734a8f2ce5ad',
    'Macchialina': '1720694924759-2a2daaa98987',
    'Maison Premiere': '1777274124928-2978d23e46ce',
    'Majordomo': '1551632436-cbf8dd35adfa',
    'Mamma Maria': '1617079114138-9cf245e006c4',
    'Mandolin Aegean Bistro': '1638469546636-bc626ae59438',
    'Mariscos Jalisco': '1613585432844-8bad91a4722e',
    'Marlowe': '1622192308862-8032a315dd16',
    'Mignonette': '1633321094192-388268512e0f',
    'Miss Korea BBQ': '1602945072881-75915b0f641f',
    'Mission Chinese Food': '1658713064058-9ed13ce542e6',
    "Mister Jiu's": '1693732252871-993d5aecd144',
    'Momofuku Noodle Bar': '1563612116625-3012372fccce',
    'Myers + Chang': '1608339760666-9f9c77745fb0',
    'NIU Kitchen': '1653983194833-7a10838b12f4',
    'Namu Gaji': '1761303506087-9788d0a98e87',
    'Naoe': '1629684782790-385ed5adb497',
    'Neptune Oyster': '1627898292764-6733087b55ac',
    'Night + Market': '1573821663912-569905455b1c',
    'Nobu Malibu': '1519984388953-d2406bc725e1',
    'Nom Wah Tea Parlor': '1556820524-9aca1796459e',
    'Nopa': '1636734993397-fb9826cdcdd4',
    'O Ya': '1621871908119-295c8ce5cee4',
    'Omakase': '1615361200141-f45040f367be',
    'Omakase Yume': '1617196034796-73dfa7b1fd56',
    'Oriole': '1713375094006-5a0d705a2c8a',
    'Otium': '1666819476544-38ea4e57a3d0',
    'Ovelia Psistaria': '1598395926928-0aaf9fce9160',
    'Oxomoco': '1636405189493-181ecf851006',
    'Palette Korean Cuisine': '1689672235501-6dc1e56d454c',
    "Pammy's": '1531973968078-9bb02785f13d',
    'Papalote Mexican Grill': '1629793980446-192d630f0dbe',
    "Park's BBQ": '1612179343574-31b219a3915c',
    'Pecking Duck House': '1559948271-7d5c98d2e951',
    "Pequod's Pizza": '1767065604070-574bb62ce4fc',
    'Petit Trois': '1765045038226-43d7cd5cfd29',
    'Pizza Roma': '1579751626657-72bc17010498',
    'Plearn Thai': '1618160702438-9b02ab6515c9',
    'Pocha 32': '1531973968078-9bb02785f13d',
    'Pok Pok NY': '1603894584373-5ac82b2ae398',
    "Portillo's": '1729482436140-8190b963379d',
    'Pubbelly Sushi': '1560569203-a7120e77abd5',
    'Publican': '1659328573598-3d0b0850e89c',
    'Rahi': '1582228096960-7f5d2ec4aa8e',
    'Ramen Dojo': '1583623025817-d180a2221d0a',
    'Ramen Lab': '1607247098731-5bf6416d2e8c',
    'Ramen Misoya': '1684866907269-2248f7334a09',
    'Red Hook Tavern': '1706966303788-d8311b4dbc26',
    'Republique': '1702677413541-ffc41d8c08b3',
    "Roberta's": '1709576744904-fc055105a5e0',
    "Roberta's BBQ": '1640859856457-f619953777f4',
    'Row 34': '1616977782967-a1859e09b014',
    'Rubirosa': '1643845258159-5c4bc4f38182',
    'Sake Bar Decibel': '1571762450239-f0f047321444',
    'Sarma': '1549407978-5b995866b1e0',
    'Seaspice': '1719750488953-0baec22d7411',
    'Shake Shack': '1600713080871-116c252a520e',
    'Shojo': '1685904899685-058c71a8f4e3',
    'Smoque BBQ': '1646656352194-7db15ee021bf',
    'Somtum Der': '1648421331147-9fcfab29536e',
    'Spiaggia': '1744904998059-42485e16d688',
    'Spice Symphony': '1703565426315-4209c2e88eea',
    'Spicy Village': '1670518045382-b68878eebecc',
    'SriPraPhai': '1565299624946-b28f40a0ae38',
    'Strings Ramen': '1563612116891-9b03e4bb9318',
    'Sugarfish': '1597290282695-edc43d0e7129',
    'Sunday In Brooklyn': '1515668236457-83c3b8764839',
    'Superiority Burger': '1661529515567-dcb300f41da5',
    'Sushi Gen': '1543007630-9710e4a00a20',
    'Sushi Nakazawa': '1567568134550-0938419b458b',
    'Tacombi': '1615870216519-2f9fa575fa5c',
    'Tamarind': '1606471191009-63994c53433b',
    'Tanoreen': '1542528180-1c2803fa048c',
    'Tanoshi Sushi': '1572116469696-31de0f17cc34',
    'Taqueria Cancun': '1602232037779-30b01ac3c457',
    'Taqueria Ramirez': '1664992915025-e5e4bbd67fe1',
    'Tasty Burger': '1679344600900-87a98b85c01f',
    'Thai Villa': '1580822184713-fc5400e7fe10',
    'The Mermaid Inn': '1657485990998-4b6fca3ca696',
    'The Purple Pig': '1491333078588-55b6733c7de6',
    'The Spotted Pig': '1687723547516-308ac9cefba9',
    'Tigre': '1533658266890-8bd362930725',
    'Tim Ho Wan': '1495899686424-be6ded54191a',
    'Tong Kiang': '1632239701331-f2d67d13fb7a',
    'Toro': '1649082236294-94468ba45741',
    'Torrisi Bar & Restaurant': '1731156690336-24fa18ab6c8b',
    'Totto Ramen': '1562158074-d49fbeffcc91',
    'Tre Kronor': '1525184776124-adcb9d6bae73',
    'Tulcingo del Valle': '1681394421550-83cc9341b9f8',
    'Ugly Baby': '1565557623262-b51c2513a641',
    'Uncle Boons': '1553361371-9b22f78e8b1d',
    'Uni': '1592466741848-20145fe5d6d7',
    'Versailles Restaurant': '1549488344-1f9b8d2bd1f3',
    'Via Carota': '1579027989536-b7b1f875659b',
    'Waypoint': '1717269943220-963b7e6ae8b7',
    "Xi'an Famous Foods": '1707886114235-4080ed0dc82f',
    'Zaab Zaab': '1624726175512-19b9baf9fbd1',
    'Zak the Baker': '1745611454038-abff4edd9f82',
    'Zaytinya': '1570131775695-6c74e80fa386',
    'Zuni Café': '1590759723450-1cd421d8fdb9',
    'Zutto': '1476055439777-977cdf3a5699',
    'n/naka': '1502364271109-0a9a75a2a9df',
  };

  // Menu item images — TheMealDB (verified correct) + verified Unsplash photo IDs
  const MDB = (fn) => `https://www.themealdb.com/images/media/meals/${fn}`;
  const UNS = (id) => `https://images.unsplash.com/photo-${id}?w=400&h=300&fit=crop&crop=entropy&auto=format`;
  const MENU_ITEM_PHOTOS = {
    // ── Japanese ──────────────────────────────────────────────────────────
    'Edamame':                   UNS('1575262599410-837a72005862'),
    'Gyoza':                     UNS('1496116218417-1a781b1c416c'),
    'Karaage':                   MDB('tyywsw1505930373.jpg'),
    'Tonkotsu Ramen':            UNS('1614563637806-1d0e645e0940'),
    'Shoyu Ramen':               UNS('1591325418441-ff678baf78ef'),
    'Salmon Sashimi':            UNS('1567620815168-8afeeb18de17'),
    'Spicy Tuna Roll':           UNS('1579584425555-c3ce17fd4351'),
    'Miso Black Cod':            UNS('1534476429-dc25f72aa33b'),
    'Matcha Ice Cream':          UNS('1534706936160-d5ee67737249'),
    'Mochi':                     UNS('1604498149220-bfb7c7cfd19b'),
    // ── Italian ───────────────────────────────────────────────────────────
    'Burrata':                   UNS('1555072930-714bba1d24e2'),
    'Arancini':                  UNS('1688458296759-91020b4ff2ba'),
    'Cacio e Pepe':              UNS('1588013273468-315fd88ea34c'),
    "Rigatoni all'Amatriciana":  UNS('1760390952355-a6b9cf50a7a2'),
    'Margherita Pizza':          UNS('1565299624946-b28f40a0ae38'),
    'Chicken Piccata':           UNS('1627858034922-72a657d6b3c2'),
    'Branzino al Forno':         UNS('1644784643137-b9073dd262f6'),
    'Tiramisu':                  MDB('UUUUUU1511180009.jpg'),
    'Panna Cotta':               UNS('1488477181946-6428a0291777'),
    'Cannoli':                   UNS('1611292984550-6dd8def2e668'),
    // ── Mexican ───────────────────────────────────────────────────────────
    'Guacamole':                 UNS('1595016111459-799a195e7452'),
    'Elotes':                    UNS('1570716774271-ab30ad4924a8'),
    'Tacos al Pastor':           UNS('1599974579688-8dbdd335c77f'),
    'Carnitas Tacos':            UNS('1599974579688-8dbdd335c77f'),
    'Birria de Res':             UNS('1606350383072-4b031d6bd834'),
    'Enchiladas Verdes':         UNS('1679605097294-ad339b020c0f'),
    'Chiles en Nogada':          UNS('1708536892634-18ccb18cd513'),
    'Mole Negro':                UNS('1613520422094-290a378bbc11'),
    'Churros':                   MDB('nxnny61763250596.jpg'),
    'Tres Leches':               UNS('1559620192-032c4bc4674e'),
    // ── Indian ────────────────────────────────────────────────────────────
    'Samosa Chaat':              UNS('1601050690597-df0568f70950'),
    'Tandoori Chicken':          MDB('qptpvt1487339892.jpg'),
    'Seekh Kebab':               UNS('1532636875304-0c89119d9b4d'),
    'Butter Chicken':            UNS('1585937421612-70a008356fbe'),
    'Dal Makhani':               UNS('1546069901-ba9599a7e63c'),
    'Palak Paneer':              UNS('1589647363585-f4a7d3877b10'),
    'Lamb Rogan Josh':           MDB('vvstvq1487342592.jpg'),
    'Garlic Naan':               UNS('1697155406014-04dc649b0953'),
    'Biryani':                   MDB('xrttsx1487339558.jpg'),
    'Gulab Jamun':               UNS('1595608010652-d8bf1103a1c5'),
    // ── Thai ──────────────────────────────────────────────────────────────
    'Tom Yum Soup':              MDB('l50vz41763422681.jpg'),
    'Som Tum':                   UNS('1648421331147-9fcfab29536e'),
    'Fish Sauce Wings':          UNS('1624726175512-19b9baf9fbd1'),
    'Pad Thai':                  MDB('rg9ze01763479093.jpg'),
    'Khao Soi':                  UNS('1646850148817-c3a5e8a35fd9'),
    'Green Curry':               MDB('sstssx1487349585.jpg'),
    'Pad See Ew':                UNS('1704969722370-6cf3b314619b'),
    'Massaman Curry':            UNS('1672933036331-e27ffae157bd'),
    'Mango Sticky Rice':         UNS('1705234384751-84081009588e'),
    'Fried Banana':              UNS('1540714605746-4f474eefc6d4'),
    // ── American ──────────────────────────────────────────────────────────
    'Onion Rings':               UNS('1639024471283-03518883512d'),
    'Caesar Salad':              UNS('1607532941433-304659e8198a'),
    'Chicken Wings':             MDB('4hzyvq1763792564.jpg'),
    'Classic Burger':            MDB('lgmnff1763789847.jpg'),
    'BBQ Brisket':               UNS('1529692236671-f1f6cf9683ba'),
    'Fried Chicken Sandwich':    MDB('40r49m1763197022.jpg'),
    'Lobster Roll':              UNS('1666380510734-c81855f0afdb'),
    'Mac and Cheese':            MDB('qrqywr1503066605.jpg'),
    'Chocolate Cake':            MDB('qxutws1486978099.jpg'),
    'Apple Pie':                 MDB('zy4fs51777540384.jpg'),
    // ── Chinese ───────────────────────────────────────────────────────────
    'Steamed Dumplings':         MDB('jbw8m11780155348.jpg'),
    'Scallion Pancake':          UNS('1704383682314-92dd38542a0f'),
    'Kung Pao Chicken':          MDB('1525872624.jpg'),
    'Mapo Tofu':                 UNS('1769065647078-f067eb768035'),
    'Peking Duck':               UNS('1765743691388-6a5608004b9c'),
    'Dan Dan Noodles':           UNS('1612929633738-8fe44f7ec841'),
    'Beef Chow Fun':             UNS('1705088294364-05f713d9f0d5'),
    'Salt and Pepper Shrimp':    MDB('1529445434.jpg'),
    'Soup Dumplings':            UNS('1694834589398-27b369c6f7a6'),
    'Sesame Balls':              UNS('1614235183711-7a4f4f339265'),
    // ── Mediterranean ─────────────────────────────────────────────────────
    'Hummus':                    MDB('gpon5u1763801180.jpg'),
    'Spanakopita':               UNS('1650915850274-f5014ce6e6b7'),
    'Baba Ganoush':              UNS('1700481947515-7a162cbe4df7'),
    'Grilled Octopus':           UNS('1626232441076-a2a5ada2256a'),
    'Falafel Plate':             MDB('u5e9qq1763795441.jpg'),
    'Lamb Kebab':                UNS('1633321702518-7feccafb94d5'),
    'Branzino':                  UNS('1551014700-0ca41391f312'),
    'Moussaka':                  MDB('ctg8jd1585563097.jpg'),
    'Baklava':                   MDB('ytme8t1764111401.jpg'),
    'Loukoumades':               UNS('1711919432544-ba04b9b18169'),
    // ── Korean ────────────────────────────────────────────────────────────
    'Japchae':                   UNS('1583032015879-e5022cb87c3b'),
    'Pajeon':                    UNS('1605490636645-05a5bb8a02ca'),
    'Tteokbokki':                UNS('1679581083578-94eae6e8d7a4'),
    'Bibimbap':                  UNS('1590301157890-4810ed352733'),
    'Galbi':                     UNS('1677029969065-c9f4003a9ad5'),
    'Samgyeopsal':               UNS('1709433420574-7e8b97952eed'),
    'Sundubu Jjigae':            UNS('1560435726-6480fd46446b'),
    'Kimchi Fried Rice':         UNS('1600688654899-379ec76aca42'),
    'Bingsu':                    UNS('1595275320712-24b6f2b0a984'),
    'Hotteok':                   UNS('1620108092667-dd0d0d61df2c'),
    // ── French ────────────────────────────────────────────────────────────
    "Soupe à l'Oignon":          MDB('xvrrux1511783685.jpg'),
    'Escargot':                  UNS('1563662185892-fe39abf9ba9e'),
    'Steak Tartare':             UNS('1571513062809-2ac71eab2656'),
    'Steak Frites':              UNS('1600891964092-4316c288032e'),
    'Duck Confit':               MDB('wvpvsu1511786158.jpg'),
    'Bouillabaisse':             UNS('1621174438159-6a9a82405498'),
    'Croque Monsieur':           UNS('1531664412848-9610afed156c'),
    'Sole Meunière':             UNS('1665401015549-712c0dc5ef85'),
    'Crème Brûlée':              MDB('uryqru1511798039.jpg'),
    'Tarte Tatin':               MDB('qtqwwu1511792650.jpg'),
    // Fallback
    '__fallback__':              UNS('1546069901-ba9599a7e63c'),
  };

  const prices = ['$', '$$', '$$$'];
  const streetNames = ['Broadway', 'Park Ave', 'Lexington Ave', 'Bedford Ave', 'Steinway St', 'Astoria Blvd', 'Atlantic Ave', 'Flatbush Ave', 'Queens Blvd', 'Amsterdam Ave'];

  // 100 NYC restaurants: 10 per cuisine
  const restaurantDefs = [
    // Japanese (10)
    { name: 'Ippudo Ramen', cuisine: 'Japanese', neigh: 'Manhattan', price: '$$', rating: 4.7, desc: 'Authentic Hakata-style tonkotsu ramen with rich pork broth, thin noodles, and house-made tare.' },
    { name: 'Sushi Nakazawa', cuisine: 'Japanese', neigh: 'Manhattan', price: '$$$', rating: 5.0, desc: 'Omakase sushi counter helmed by master chef Daisuke Nakazawa, with pristine seasonal fish.' },
    { name: 'Totto Ramen', cuisine: 'Japanese', neigh: 'Brooklyn', price: '$$', rating: 4.6, desc: 'Chicken paitan ramen made from a milky white broth simmered for hours with free-range chicken.' },
    { name: 'Sake Bar Decibel', cuisine: 'Japanese', neigh: 'Manhattan', price: '$$', rating: 4.4, desc: 'Underground izakaya with an extensive sake list and Japanese small plates.' },
    { name: 'Momofuku Noodle Bar', cuisine: 'Japanese', neigh: 'Manhattan', price: '$$', rating: 4.5, desc: 'David Chang\'s flagship ramen shop reimagining Japanese noodle culture with bold American ingredients.' },
    { name: 'Zutto', cuisine: 'Japanese', neigh: 'Williamsburg', price: '$$', rating: 4.3, desc: 'Casual Japanese gastropub with izakaya bites, ramen, and craft cocktails.' },
    { name: 'Hakata Tonton', cuisine: 'Japanese', neigh: 'Manhattan', price: '$$', rating: 4.4, desc: 'Trotters-focused Japanese hot pot and small plates in the West Village.' },
    { name: 'Ramen Lab', cuisine: 'Japanese', neigh: 'Brooklyn', price: '$', rating: 4.2, desc: 'Rotating ramen concepts from top Japanese noodle masters in a minimalist counter setting.' },
    { name: 'EN Japanese Brasserie', cuisine: 'Japanese', neigh: 'Manhattan', price: '$$$', rating: 4.6, desc: 'Modern Japanese cuisine with seasonal tofu, handmade soba, and fine sake.' },
    { name: 'Tanoshi Sushi', cuisine: 'Japanese', neigh: 'Astoria', price: '$$', rating: 4.5, desc: 'Neighborhood sushi counter with fresh fish flown in daily and house-cured toppings.' },

    // Italian (10)
    { name: 'Lilia', cuisine: 'Italian', neigh: 'Williamsburg', price: '$$$', rating: 4.8, desc: 'Missy Robbins\'s celebrated pasta restaurant in a converted auto shop, famous for sheep\'s milk cheese cavatelli.' },
    { name: 'Carbone', cuisine: 'Italian', neigh: 'Manhattan', price: '$$$', rating: 4.7, desc: 'Retro red-sauce Italian-American classics in a theatrically vintage dining room.' },
    { name: 'Via Carota', cuisine: 'Italian', neigh: 'Manhattan', price: '$$', rating: 4.6, desc: 'Rustic Italian trattoria with market-driven vegetables, hand-rolled pastas, and a legendary insalata verde.' },
    { name: 'L\'Artusi', cuisine: 'Italian', neigh: 'Manhattan', price: '$$$', rating: 4.5, desc: 'Modern Italian wine bar with antipasti and house-made pastas in a warm West Village townhouse.' },
    { name: 'Rubirosa', cuisine: 'Italian', neigh: 'Manhattan', price: '$$', rating: 4.4, desc: 'Family-run Nolita spot beloved for its thin-crust vodka pizza and fresh pastas.' },
    { name: 'Roberta\'s', cuisine: 'Italian', neigh: 'Williamsburg', price: '$$', rating: 4.5, desc: 'Brooklyn institution with wood-fired pizzas, a rooftop herb garden, and rotating seasonal toppings.' },
    { name: 'Don Angie', cuisine: 'Italian', neigh: 'Manhattan', price: '$$$', rating: 4.9, desc: 'Scott Tacinella and Angela Rito\'s inventive Italian-American tasting menu with pinwheel lasagna.' },
    { name: 'Pizza Roma', cuisine: 'Italian', neigh: 'Astoria', price: '$', rating: 4.1, desc: 'Old-school slice shop with daily-made dough, San Marzano tomatoes, and fior di latte.' },
    { name: 'Torrisi Bar & Restaurant', cuisine: 'Italian', neigh: 'Manhattan', price: '$$$', rating: 4.7, desc: 'Rich Torrisi\'s avant-garde Italian with unexpected flavor combinations and produce-forward courses.' },
    { name: 'Frank', cuisine: 'Italian', neigh: 'Brooklyn', price: '$$', rating: 4.3, desc: 'East Village neighborhood Italian with honest pastas, grilled meats, and a convivial vibe.' },

    // Mexican (10)
    { name: 'Cosme', cuisine: 'Mexican', neigh: 'Manhattan', price: '$$$', rating: 4.8, desc: 'Enrique Olvera\'s acclaimed contemporary Mexican with corn husk meringue and duck carnitas.' },
    { name: 'Atla', cuisine: 'Mexican', neigh: 'Manhattan', price: '$$', rating: 4.5, desc: 'Daytime Mexican cafe with bright ceviches, masa dishes, and natural wines in Noho.' },
    { name: 'Los Tacos No. 1', cuisine: 'Mexican', neigh: 'Manhattan', price: '$', rating: 4.7, desc: 'Beloved taco stand with hand-pressed tortillas and adobada pork carved off a trompo.' },
    { name: 'Tulcingo del Valle', cuisine: 'Mexican', neigh: 'Queens', price: '$', rating: 4.4, desc: 'Authentic Pueblan cooking with mole negro, cemitas, and tacos de barbacoa.' },
    { name: 'Oxomoco', cuisine: 'Mexican', neigh: 'Williamsburg', price: '$$$', rating: 4.6, desc: 'Wood-fired modern Mexican with ember-roasted vegetables and mezcal cocktails.' },
    { name: 'El Parador Cafe', cuisine: 'Mexican', neigh: 'Manhattan', price: '$$', rating: 4.2, desc: 'Classic Midtown Mexican institution since 1959, famous for its margaritas and enchiladas.' },
    { name: 'Tacombi', cuisine: 'Mexican', neigh: 'Brooklyn', price: '$', rating: 4.3, desc: 'Yucatan-inspired tacos and aguas frescas in a relaxed beach-shack setting.' },
    { name: 'Empellón', cuisine: 'Mexican', neigh: 'Manhattan', price: '$$$', rating: 4.5, desc: 'Alex Stupak\'s creative reinterpretation of Mexican food with stunning moles and masa.' },
    { name: 'Casa Enrique', cuisine: 'Mexican', neigh: 'Astoria', price: '$$', rating: 4.6, desc: 'Michelin-starred Chiapas cuisine with rich black bean soup, cochinita pibil, and house-made chocolate.' },
    { name: 'Taqueria Ramirez', cuisine: 'Mexican', neigh: 'Brooklyn', price: '$', rating: 4.8, desc: 'Legendary street-style taco stand with some of NYC\'s best birria and carne asada.' },

    // Indian (10)
    { name: 'Junoon', cuisine: 'Indian', neigh: 'Manhattan', price: '$$$', rating: 4.6, desc: 'Michelin-starred modern Indian with refined curries, tandoor specialties, and an impressive spice pantry.' },
    { name: 'Dhamaka', cuisine: 'Indian', neigh: 'Manhattan', price: '$$', rating: 4.8, desc: 'Unapologetic regional Indian cooking with dishes rarely seen outside their home states.' },
    { name: 'Adda Indian Canteen', cuisine: 'Indian', neigh: 'Queens', price: '$$', rating: 4.7, desc: 'Nostalgic North Indian street food and home-style cooking from Michelin-starred chef Chintan Pandya.' },
    { name: 'Rahi', cuisine: 'Indian', neigh: 'Manhattan', price: '$$$', rating: 4.5, desc: 'Progressive Indian cuisine blending French technique with the spice traditions of the subcontinent.' },
    { name: 'Bhatti Indian Grills', cuisine: 'Indian', neigh: 'Manhattan', price: '$$', rating: 4.3, desc: 'Tandoor-focused Punjabi restaurant with clay oven-roasted meats and fluffy naan.' },
    { name: 'Jackson Diner', cuisine: 'Indian', neigh: 'Queens', price: '$', rating: 4.2, desc: 'Jackson Heights institution serving generous portions of North Indian classics since 1976.' },
    { name: 'Tamarind', cuisine: 'Indian', neigh: 'Manhattan', price: '$$$', rating: 4.4, desc: 'Elegant Flatiron Indian with contemporary presentations of dishes from across the country.' },
    { name: 'Dhaba', cuisine: 'Indian', neigh: 'Astoria', price: '$', rating: 4.1, desc: 'Roadside-canteen-style Indian with hearty dals, biryanis, and fresh-baked paratha.' },
    { name: 'Babu Ji', cuisine: 'Indian', neigh: 'Brooklyn', price: '$$', rating: 4.4, desc: 'Modern Indian small plates with an irreverent spin — pani puri cocktails and smoked lamb seekh.' },
    { name: 'Spice Symphony', cuisine: 'Indian', neigh: 'Manhattan', price: '$$', rating: 4.3, desc: 'Vibrant Midtown Indian with a broad menu of curries, kebabs, and vegetarian specialties.' },

    // Thai (10)
    { name: 'Uncle Boons', cuisine: 'Thai', neigh: 'Manhattan', price: '$$', rating: 4.7, desc: 'Michelin-starred Thai with retro decor and dishes rooted in traditional Central Thai cooking.' },
    { name: 'Pok Pok NY', cuisine: 'Thai', neigh: 'Brooklyn', price: '$$', rating: 4.6, desc: 'Northern Thai street food legend transplanted from Portland — fish sauce wings, khao soi, and drinking vinegars.' },
    { name: 'SriPraPhai', cuisine: 'Thai', neigh: 'Queens', price: '$', rating: 4.8, desc: 'Queens institution widely considered NYC\'s best Thai, with an exhaustive menu of regional dishes.' },
    { name: 'Somtum Der', cuisine: 'Thai', neigh: 'Manhattan', price: '$$', rating: 4.5, desc: 'Isaan Thai specialist with papaya salads, grilled meats, and sticky rice in the East Village.' },
    { name: 'Ugly Baby', cuisine: 'Thai', neigh: 'Brooklyn', price: '$$', rating: 4.6, desc: 'Intensely spiced Southern Thai cooking with relentlessly fiery curries and funky fermented flavors.' },
    { name: 'Ayada Thai', cuisine: 'Thai', neigh: 'Queens', price: '$', rating: 4.5, desc: 'Family-run Woodside Thai with homestyle regional dishes and one of the city\'s best pad Thai.' },
    { name: 'Fish Cheeks', cuisine: 'Thai', neigh: 'Manhattan', price: '$$$', rating: 4.4, desc: 'Coastal Thai seafood with crab curry, chargrilled squid, and cocktails made with Thai spirits.' },
    { name: 'Zaab Zaab', cuisine: 'Thai', neigh: 'Queens', price: '$', rating: 4.3, desc: 'Isaan-style Thai with flame-roasted meats, fermented sausages, and nuclear-level larb.' },
    { name: 'Plearn Thai', cuisine: 'Thai', neigh: 'Williamsburg', price: '$$', rating: 4.2, desc: 'Neighborhood Thai with house-made curry pastes and a market-fresh approach to seasonal produce.' },
    { name: 'Thai Villa', cuisine: 'Thai', neigh: 'Manhattan', price: '$$', rating: 4.1, desc: 'Classic midtown Thai with a comprehensive menu spanning Bangkok street food to royal Thai cuisine.' },

    // American (10)
    { name: 'J.G. Melon', cuisine: 'American', neigh: 'Manhattan', price: '$$', rating: 4.5, desc: 'Upper East Side pub institution famous for its burger and cottage fries since 1972.' },
    { name: 'Shake Shack', cuisine: 'American', neigh: 'Manhattan', price: '$', rating: 4.3, desc: 'Danny Meyer\'s modernized roadside stand with ShackBurgers, crinkle-cut fries, and custard.' },
    { name: 'Roberta\'s BBQ', cuisine: 'American', neigh: 'Williamsburg', price: '$$', rating: 4.4, desc: 'Smoked meats, house-made sausages, and classic sides in a no-frills backyard smokehouse.' },
    { name: 'Red Hook Tavern', cuisine: 'American', neigh: 'Brooklyn', price: '$$', rating: 4.7, desc: 'Beloved Brooklyn saloon with wood-fired burgers, dry-aged beef, and craft beer on tap.' },
    { name: 'The Spotted Pig', cuisine: 'American', neigh: 'Manhattan', price: '$$', rating: 4.4, desc: 'April Bloomfield\'s West Village gastro-pub with gnudi, chargrilled burger, and strong cocktails.' },
    { name: 'Diner', cuisine: 'American', neigh: 'Williamsburg', price: '$$', rating: 4.3, desc: 'Classic American diner in a 1920s dining car with a chalkboard menu of fresh seasonal cooking.' },
    { name: 'Emily', cuisine: 'American', neigh: 'Brooklyn', price: '$$', rating: 4.6, desc: 'Wood-fired pizza and cheeseburgers from a Clinton Hill neighborhood spot with craft cocktails.' },
    { name: 'Superiority Burger', cuisine: 'American', neigh: 'Manhattan', price: '$', rating: 4.5, desc: 'Brooks Headley\'s East Village spot redefining vegetable-forward fast food with ingenious veggie burgers.' },
    { name: 'Hometown Bar-B-Que', cuisine: 'American', neigh: 'Brooklyn', price: '$$', rating: 4.7, desc: 'Texas-style BBQ with whole-hog pits, smoked brisket, and Jamaican jerk ribs.' },
    { name: 'Daisy\'s', cuisine: 'American', neigh: 'Astoria', price: '$', rating: 4.2, desc: 'Neighborhood lunch counter with classic egg sandwiches, griddle burgers, and house-made pie.' },

    // Chinese (10)
    { name: 'Nom Wah Tea Parlor', cuisine: 'Chinese', neigh: 'Manhattan', price: '$', rating: 4.5, desc: 'NYC\'s oldest dim sum parlor, open since 1920, with handmade dumplings and vintage Chinatown charm.' },
    { name: 'Mission Chinese Food', cuisine: 'Chinese', neigh: 'Manhattan', price: '$$', rating: 4.5, desc: 'Danny Bowien\'s Sichuan-inflected Chinese with thrice-cooked bacon, kung pao pastrami, and mapo tofu.' },
    { name: 'Xi\'an Famous Foods', cuisine: 'Chinese', neigh: 'Queens', price: '$', rating: 4.7, desc: 'Hand-ripped noodles, lamb burgers, and spicy cumin lamb from a Xi\'an street-food dynasty.' },
    { name: 'Hakkasan', cuisine: 'Chinese', neigh: 'Manhattan', price: '$$$', rating: 4.4, desc: 'Upscale Cantonese with Peking duck, dim sum, and dramatic Midtown interiors.' },
    { name: 'Joe\'s Shanghai', cuisine: 'Chinese', neigh: 'Manhattan', price: '$', rating: 4.3, desc: 'Legendary Chinatown dumpling house famous for soup dumplings filled with pork and crab.' },
    { name: 'Spicy Village', cuisine: 'Chinese', neigh: 'Manhattan', price: '$', rating: 4.6, desc: 'Casual Henan noodle shop beloved for its big tray chicken and hand-torn belt noodles.' },
    { name: 'Pecking Duck House', cuisine: 'Chinese', neigh: 'Manhattan', price: '$$$', rating: 4.5, desc: 'Traditional Peking duck served with ceremony — thin pancakes, hoisin, and cucumber.' },
    { name: 'Lan Sheng', cuisine: 'Chinese', neigh: 'Queens', price: '$$', rating: 4.4, desc: 'Sichuan specialist in Midtown with ma po tofu, dan dan noodles, and fiery cold dishes.' },
    { name: 'Tim Ho Wan', cuisine: 'Chinese', neigh: 'Manhattan', price: '$', rating: 4.3, desc: 'World\'s most affordable Michelin-starred dim sum with baked BBQ pork buns and cheung fun.' },
    { name: 'Flushing Seafood', cuisine: 'Chinese', neigh: 'Queens', price: '$$', rating: 4.2, desc: 'Cantonese seafood palace in Flushing with live tanks, whole fish, and Hong Kong-style lobster.' },

    // Mediterranean (10)
    { name: 'Zaytinya', cuisine: 'Mediterranean', neigh: 'Manhattan', price: '$$$', rating: 4.6, desc: 'José Andrés\'s mezze-focused celebration of Turkish, Greek, and Lebanese small plates.' },
    { name: 'Ilili', cuisine: 'Mediterranean', neigh: 'Manhattan', price: '$$$', rating: 4.5, desc: 'Lebanese-focused Mediterranean with whole-roasted cauliflower, shawarma, and wood-fired flatbreads.' },
    { name: 'Agora', cuisine: 'Mediterranean', neigh: 'Astoria', price: '$$', rating: 4.4, desc: 'Greek taverna in Astoria with grilled octopus, spanakopita, and whole fish by the pound.' },
    { name: 'Loi Estiatorio', cuisine: 'Mediterranean', neigh: 'Manhattan', price: '$$$', rating: 4.3, desc: 'Modern Greek cooking by Maria Loi with pristine seafood, mezedes, and Santorinian fava.' },
    { name: 'The Mermaid Inn', cuisine: 'Mediterranean', neigh: 'Manhattan', price: '$$', rating: 4.4, desc: 'Coastal New England seafood meets Mediterranean influences in a clam-shack-inspired dining room.' },
    { name: 'Tanoreen', cuisine: 'Mediterranean', neigh: 'Brooklyn', price: '$$', rating: 4.7, desc: 'Palestinian-Arab home cooking in Bay Ridge with lamb stuffed with pine nuts and extraordinary hummus.' },
    { name: 'Cava', cuisine: 'Mediterranean', neigh: 'Williamsburg', price: '$', rating: 4.1, desc: 'Fast-casual Mediterranean grain bowls with house-made spreads, falafel, and harissa chicken.' },
    { name: 'Kyma', cuisine: 'Mediterranean', neigh: 'Manhattan', price: '$$$', rating: 4.4, desc: 'Upscale Greek seafood with imported fish, saganaki, and an Aegean wine list.' },
    { name: 'Bahari Estiatorio', cuisine: 'Mediterranean', neigh: 'Astoria', price: '$$', rating: 4.5, desc: 'Greek seafood restaurant in the heart of Astoria\'s Greek community, beloved for its freshness.' },
    { name: 'Ovelia Psistaria', cuisine: 'Mediterranean', neigh: 'Astoria', price: '$$', rating: 4.3, desc: 'Modern Greek taverna with outdoor seating, excellent spreads, and grilled meats.' },

    // Korean (10)
    { name: 'Atoboy', cuisine: 'Korean', neigh: 'Manhattan', price: '$$', rating: 4.7, desc: 'Michelin-starred prix-fixe banchan restaurant from chef Junghyun Park reimagining Korean sharing plates.' },
    { name: 'Atomix', cuisine: 'Korean', neigh: 'Manhattan', price: '$$$', rating: 5.0, desc: 'Two-Michelin-starred omakase showcasing the pinnacle of contemporary Korean cuisine with exquisite technique.' },
    { name: 'Cote Korean Steakhouse', cuisine: 'Korean', neigh: 'Manhattan', price: '$$$', rating: 4.8, desc: 'Korean BBQ meets American steakhouse: butcher\'s feast, USDA prime cuts, and banchan in a sleek setting.' },
    { name: 'Jongro BBQ', cuisine: 'Korean', neigh: 'Manhattan', price: '$$', rating: 4.5, desc: 'Korean BBQ on the 2nd floor of Koreatown with ventilated grills, pork belly, and soju bombs.' },
    { name: 'Insa', cuisine: 'Korean', neigh: 'Brooklyn', price: '$$', rating: 4.4, desc: 'Korean BBQ and karaoke in Gowanus with galbi, kimchi pancakes, and a curated soju selection.' },
    { name: 'Pocha 32', cuisine: 'Korean', neigh: 'Manhattan', price: '$', rating: 4.3, desc: 'Korean street food and fried chicken in a pojangmacha-style tent atmosphere open until 4am.' },
    { name: 'Hanon', cuisine: 'Korean', neigh: 'Queens', price: '$', rating: 4.2, desc: 'Flushing Korean canteen with homestyle doenjang jjigae, bibimbap, and affordable set lunches.' },
    { name: 'Sunday In Brooklyn', cuisine: 'Korean', neigh: 'Williamsburg', price: '$$', rating: 4.4, desc: 'Korean-inflected brunch and dinner with perilla oil everything, fried chicken, and natural wines.' },
    { name: 'Miss Korea BBQ', cuisine: 'Korean', neigh: 'Manhattan', price: '$$', rating: 4.3, desc: 'Koreatown KBBQ stalwart with prime galbi, seafood pajeon, and cold naengmyeon noodles.' },
    { name: 'Kimchi Grill', cuisine: 'Korean', neigh: 'Brooklyn', price: '$', rating: 4.1, desc: 'Prospect Heights Korean-American fusion with kimchi quesadillas, bibimbap bowls, and bulgogi tacos.' },

    // French (10)
    { name: 'Le Bernardin', cuisine: 'French', neigh: 'Manhattan', price: '$$$', rating: 5.0, desc: 'Eric Ripert\'s legendary three-Michelin-star seafood temple with transcendent French technique.' },
    { name: 'Balthazar', cuisine: 'French', neigh: 'Manhattan', price: '$$$', rating: 4.7, desc: 'Keith McNally\'s perennially packed French brasserie with steak frites, plateau de fruits de mer, and impeccable escargot.' },
    { name: 'Buvette', cuisine: 'French', neigh: 'Manhattan', price: '$$', rating: 4.6, desc: 'Jody Williams\'s intimate West Village gastrothèque with croque monsieur, wine, and Parisian vibes.' },
    { name: 'Le Coucou', cuisine: 'French', neigh: 'Manhattan', price: '$$$', rating: 4.8, desc: 'Daniel Rose\'s ravishing French restaurant with classical technique and show-stopping presentation.' },
    { name: 'Cafe Mogador', cuisine: 'French', neigh: 'Williamsburg', price: '$$', rating: 4.3, desc: 'Moroccan-French bistro beloved since 1983 for shakshuka, tagines, and outdoor garden dining.' },
    { name: 'L\'Express', cuisine: 'French', neigh: 'Manhattan', price: '$$', rating: 4.2, desc: 'Classic French brasserie open 24 hours with onion soup, steak frites, and moules marinières.' },
    { name: 'Maison Premiere', cuisine: 'French', neigh: 'Williamsburg', price: '$$$', rating: 4.7, desc: 'New Orleans-influenced French with raw bar, absinthe service, and a spectacular oyster program.' },
    { name: 'Le Gigot', cuisine: 'French', neigh: 'Manhattan', price: '$$$', rating: 4.5, desc: 'Intimate Village bistro with classic French fare — duck confit, bouillabaisse, and tarte tatin.' },
    { name: 'Lucien', cuisine: 'French', neigh: 'Manhattan', price: '$$', rating: 4.4, desc: 'East Village French bistro with zinc bar, steak au poivre, and a devoted neighborhood following.' },
    { name: 'Bar Marseille', cuisine: 'French', neigh: 'Brooklyn', price: '$$', rating: 4.3, desc: 'Southern French and Provençal cooking in Gowanus with bouillabaisse, pissaladière, and rosé.' },

    // ── Los Angeles (~20) ──────────────────────────────────────────────────────
    { name: 'Nobu Malibu', cuisine: 'Japanese', neigh: 'Los Angeles', price: '$$$', rating: 4.8, desc: 'Nobu Matsuhisa\'s iconic oceanfront outpost with black cod miso, yellowtail jalapeño, and sweeping Pacific views.' },
    { name: 'Sugarfish', cuisine: 'Japanese', neigh: 'Los Angeles', price: '$$', rating: 4.6, desc: 'Streamlined trust-me omakase with pristine sushi from Kazunori Nozawa, served on warm rice.' },
    { name: 'n/naka', cuisine: 'Japanese', neigh: 'Los Angeles', price: '$$$', rating: 5.0, desc: 'Niki Nakayama\'s deeply personal kaiseki experience weaving Japanese tradition with California ingredients.' },
    { name: 'Guerrilla Tacos', cuisine: 'Mexican', neigh: 'Los Angeles', price: '$', rating: 4.7, desc: 'Wes Avila\'s inventive street tacos combining Mexican tradition with LA\'s farmers market bounty.' },
    { name: 'Guelaguetza', cuisine: 'Mexican', neigh: 'Los Angeles', price: '$$', rating: 4.6, desc: 'Beloved Oaxacan institution in Koreatown serving mezcal cocktails, mole negro, and tlayudas.' },
    { name: 'Coni\'Seafood', cuisine: 'Mexican', neigh: 'Los Angeles', price: '$$', rating: 4.7, desc: 'Nayarit-style coastal Mexican with whole grilled snook, aguachile, and house-made salsas.' },
    { name: 'Kang Ho-dong Baekjeong', cuisine: 'Korean', neigh: 'Los Angeles', price: '$$', rating: 4.5, desc: 'Lively Koreatown KBBQ chain from a Korean celebrity chef, with premium cuts and bottomless banchan.' },
    { name: 'Park\'s BBQ', cuisine: 'Korean', neigh: 'Los Angeles', price: '$$$', rating: 4.8, desc: 'Koreatown institution regarded as LA\'s finest Korean BBQ, with USDA prime short rib and impeccable service.' },
    { name: 'Majordomo', cuisine: 'Korean', neigh: 'Los Angeles', price: '$$$', rating: 4.7, desc: 'David Chang\'s LA flagship with whole smoked meats, Korean-inflected noodles, and live-fire cooking.' },
    { name: 'Bestia', cuisine: 'Italian', neigh: 'Los Angeles', price: '$$$', rating: 4.8, desc: 'Ori Menashe\'s Arts District Italian powerhouse with house-cured salumi, wood-fired pizzas, and handmade pasta.' },
    { name: 'Gjusta', cuisine: 'American', neigh: 'Los Angeles', price: '$$', rating: 4.7, desc: 'Venice all-day bakery and deli with wood-smoked fish, house-cured meats, and exceptional pastries.' },
    { name: 'Republique', cuisine: 'French', neigh: 'Los Angeles', price: '$$$', rating: 4.7, desc: 'Walter and Margarita Manzke\'s grand Hancock Park brasserie with exceptional pastries and French-leaning mains.' },
    { name: 'Otium', cuisine: 'Mediterranean', neigh: 'Los Angeles', price: '$$$', rating: 4.6, desc: 'Timothy Hollingsworth\'s contemporary restaurant beside the Broad with wood-fire cooking and produce-driven plates.' },
    { name: 'Petit Trois', cuisine: 'French', neigh: 'Los Angeles', price: '$$', rating: 4.6, desc: 'Ludo Lefebvre\'s tiny French bistro with a no-reservations policy, perfect omelets, and a magnificent burger.' },
    { name: 'Mariscos Jalisco', cuisine: 'Mexican', neigh: 'Los Angeles', price: '$', rating: 4.8, desc: 'East LA legend serving crispy tacos de camarón and shrimp tostadas from a bright orange truck.' },
    { name: 'Sushi Gen', cuisine: 'Japanese', neigh: 'Los Angeles', price: '$$', rating: 4.7, desc: 'Little Tokyo institution with an always-packed lunch sashimi special and market-fresh nigiri.' },
    { name: 'Jitlada', cuisine: 'Thai', neigh: 'Los Angeles', price: '$$', rating: 4.6, desc: 'Hollywood Thai landmark specializing in ferociously spiced Southern Thai curries and rare regional dishes.' },
    { name: 'Night + Market', cuisine: 'Thai', neigh: 'Los Angeles', price: '$$', rating: 4.7, desc: 'Kris Yenbamroong\'s Thai party restaurant with funky, fermented, and fiery dishes from Northern Thailand.' },
    { name: 'Langer\'s Deli', cuisine: 'American', neigh: 'Los Angeles', price: '$', rating: 4.7, desc: 'MacArthur Park institution since 1947, home to what many consider America\'s best pastrami sandwich.' },
    { name: 'Jon & Vinny\'s', cuisine: 'Italian', neigh: 'Los Angeles', price: '$$', rating: 4.6, desc: 'Fairfax neighborhood Italian with thin-crust pizza, handmade pasta, and natural wines in a buzzy setting.' },

    // ── Chicago (~20) ─────────────────────────────────────────────────────────
    { name: 'Lou Malnati\'s', cuisine: 'Italian', neigh: 'Chicago', price: '$$', rating: 4.8, desc: 'Chicago deep-dish royalty since 1971, with butter-crust pies loaded with chunky tomato sauce and premium sausage.' },
    { name: 'Pequod\'s Pizza', cuisine: 'Italian', neigh: 'Chicago', price: '$$', rating: 4.9, desc: 'Lincoln Park deep-dish with a legendary caramelized cheese crust that sets it apart from all others.' },
    { name: 'Au Cheval', cuisine: 'American', neigh: 'Chicago', price: '$$', rating: 4.8, desc: 'West Loop diner made famous by its double cheeseburger — widely considered one of America\'s best.' },
    { name: 'Smoque BBQ', cuisine: 'American', neigh: 'Chicago', price: '$', rating: 4.7, desc: 'Irving Park BBQ joint with Texas-inspired brisket, St. Louis ribs, and house-made sides.' },
    { name: 'The Purple Pig', cuisine: 'Mediterranean', neigh: 'Chicago', price: '$$', rating: 4.6, desc: 'Magnificent Mile wine-and-swine bar with a Mediterranean small-plates menu built around pork.' },
    { name: 'Alinea', cuisine: 'American', neigh: 'Chicago', price: '$$$', rating: 5.0, desc: 'Grant Achatz\'s three-Michelin-star temple of avant-garde cuisine — a theatrical, multi-sensory experience.' },
    { name: 'Girl & the Goat', cuisine: 'American', neigh: 'Chicago', price: '$$$', rating: 4.7, desc: 'Stephanie Izard\'s West Loop flagship with bold, globally-inflected shared plates and signature goat dishes.' },
    { name: 'Green Street Smoked Meats', cuisine: 'American', neigh: 'Chicago', price: '$$', rating: 4.6, desc: 'Fulton Market smokehouse with central Texas-style brisket, jalapeño cheddar sausage, and craft cocktails.' },
    { name: 'Avec', cuisine: 'Mediterranean', neigh: 'Chicago', price: '$$', rating: 4.7, desc: 'West Loop Mediterranean stalwart with wood-oven cooking, chorizo-stuffed dates, and an exceptional wine list.' },
    { name: 'Publican', cuisine: 'American', neigh: 'Chicago', price: '$$$', rating: 4.6, desc: 'Paul Kahan\'s beer hall and farmhouse restaurant with charcuterie, whole-animal dishes, and rustic grains.' },
    { name: 'Longman & Eagle', cuisine: 'American', neigh: 'Chicago', price: '$$', rating: 4.5, desc: 'Logan Square gastro-pub with Michelin recognition, an inventive whiskey list, and elevated bar food.' },
    { name: 'Portillo\'s', cuisine: 'American', neigh: 'Chicago', price: '$', rating: 4.5, desc: 'Chicago fast-food icon known for Italian beef sandwiches, Chicago-style hot dogs, and chocolate cake shake.' },
    { name: 'Oriole', cuisine: 'French', neigh: 'Chicago', price: '$$$', rating: 5.0, desc: 'West Loop two-Michelin-star tasting menu with French technique, global ingredients, and impeccable service.' },
    { name: 'Spiaggia', cuisine: 'Italian', neigh: 'Chicago', price: '$$$', rating: 4.6, desc: 'Gold Coast fine-dining Italian with a panoramic view of Lake Michigan and refined regional Italian cuisine.' },
    { name: 'Tre Kronor', cuisine: 'American', neigh: 'Chicago', price: '$', rating: 4.4, desc: 'Scandinavian-American diner in Albany Park serving Swedish pancakes, gravlax, and open-faced smorgasbord sandwiches.' },
    { name: 'Omakase Yume', cuisine: 'Japanese', neigh: 'Chicago', price: '$$$', rating: 4.8, desc: 'Intimate River North omakase counter with a curated 16-course nigiri experience using fish flown from Japan.' },
    { name: 'Ramen Misoya', cuisine: 'Japanese', neigh: 'Chicago', price: '$$', rating: 4.5, desc: 'River North ramen specialist with three distinct miso-base broths and handmade noodles.' },
    { name: 'Dolo Restaurant & Bar', cuisine: 'Chinese', neigh: 'Chicago', price: '$$', rating: 4.4, desc: 'Bridgeport Cantonese restaurant with Hong Kong-style barbecue, dim sum, and late-night congee.' },
    { name: 'Strings Ramen', cuisine: 'Japanese', neigh: 'Chicago', price: '$', rating: 4.5, desc: 'Wicker Park ramen shop with house-made noodles and a rich, deeply-seasoned chicken shoyu broth.' },
    { name: 'Bavette\'s Bar & Boeuf', cuisine: 'American', neigh: 'Chicago', price: '$$$', rating: 4.7, desc: 'Fulton Market steakhouse with a romantic, jazz-age atmosphere, prime dry-aged beef, and exceptional cocktails.' },

    // ── Boston (~20) ──────────────────────────────────────────────────────────
    { name: 'Legal Sea Foods', cuisine: 'American', neigh: 'Boston', price: '$$', rating: 4.4, desc: 'Boston institution since 1950 serving impeccably fresh New England seafood, chowder, and classic lobster.' },
    { name: 'Row 34', cuisine: 'American', neigh: 'Boston', price: '$$$', rating: 4.7, desc: 'Fort Point oyster bar and craft beer destination with expertly-sourced shellfish and whole-fish specials.' },
    { name: 'Island Creek Oyster Bar', cuisine: 'American', neigh: 'Boston', price: '$$$', rating: 4.8, desc: 'Kenmore Square seafood showstopper with a raw bar program built around its own Duxbury oyster farm.' },
    { name: 'Toro', cuisine: 'Mediterranean', neigh: 'Boston', price: '$$$', rating: 4.7, desc: 'Ken Oringer and Jamie Bissonette\'s South End tapas bar with wood-fired pintxos and a legendary sangria program.' },
    { name: 'Neptune Oyster', cuisine: 'American', neigh: 'Boston', price: '$$$', rating: 4.8, desc: 'North End jewel box with the city\'s best lobster roll — hot with drawn butter, long and overflowing.' },
    { name: 'Mamma Maria', cuisine: 'Italian', neigh: 'Boston', price: '$$$', rating: 4.7, desc: 'North End romantic Italian landmark in a historic townhouse with refined pasta and outstanding wine.' },
    { name: 'Giacomo\'s', cuisine: 'Italian', neigh: 'Boston', price: '$$', rating: 4.6, desc: 'Cash-only North End trattoria with communal tables, honest Italian-American cooking, and legendary portions.' },
    { name: 'O Ya', cuisine: 'Japanese', neigh: 'Boston', price: '$$$', rating: 4.9, desc: 'Tim Cushman\'s omakase restaurant consistently ranked among America\'s best, with creative Japanese-American fusion nigiri.' },
    { name: 'Uni', cuisine: 'Japanese', neigh: 'Boston', price: '$$$', rating: 4.7, desc: 'Ken Oringer\'s Back Bay sashimi bar with an izakaya menu of inventive crudo and Japanese whisky.' },
    { name: 'Myers + Chang', cuisine: 'Chinese', neigh: 'Boston', price: '$$', rating: 4.5, desc: 'South End Asian-American diner with pan-Asian dumplings, noodles, and inventive cocktails by Joanne Chang.' },
    { name: 'Sarma', cuisine: 'Mediterranean', neigh: 'Boston', price: '$$', rating: 4.7, desc: 'Somerville mezze restaurant with rotating Middle Eastern small plates and a vibrant cocktail program.' },
    { name: 'Eastern Standard', cuisine: 'American', neigh: 'Boston', price: '$$', rating: 4.5, desc: 'Kenmore Square grand brasserie with a classic raw bar, weekend brunch, and superb cocktails.' },
    { name: 'Coppa', cuisine: 'Italian', neigh: 'Boston', price: '$$', rating: 4.6, desc: 'South End enoteca with rustic Italian small plates, wood-grilled items, and a deep Amaro selection.' },
    { name: 'Pammy\'s', cuisine: 'Italian', neigh: 'Boston', price: '$$$', rating: 4.8, desc: 'Cambridge neighborhood Italian with silky pastas, inventive ingredients, and a cozy candlelit dining room.' },
    { name: 'Tasty Burger', cuisine: 'American', neigh: 'Boston', price: '$', rating: 4.3, desc: 'Fenway Park-adjacent burger joint with smash burgers, onion rings, and craft shakes at late hours.' },
    { name: 'Waypoint', cuisine: 'American', neigh: 'Boston', price: '$$$', rating: 4.6, desc: 'Cambridge modern American with lobster rolls, rotisserie meats, and a thoughtful natural-wine program.' },
    { name: 'Krasi', cuisine: 'Mediterranean', neigh: 'Boston', price: '$$$', rating: 4.6, desc: 'Back Bay Greek restaurant with a 100-label Greek wine list and mezze made from premium Hellenic ingredients.' },
    { name: 'Dumpling House', cuisine: 'Chinese', neigh: 'Boston', price: '$', rating: 4.6, desc: 'Cambridge Chinese restaurant with extraordinary hand-folded soup dumplings and scallion pancakes.' },
    { name: 'Shojo', cuisine: 'Chinese', neigh: 'Boston', price: '$$', rating: 4.4, desc: 'Chinatown cocktail bar and restaurant blending pan-Asian street food with creative Japanese-inspired drinks.' },
    { name: 'Café Sushi', cuisine: 'Japanese', neigh: 'Boston', price: '$$', rating: 4.5, desc: 'Cambridge neighborhood sushi gem with pristine fish, reliable omakase options, and a devoted local following.' },

    // ── Miami (~20) ───────────────────────────────────────────────────────────
    { name: 'Versailles Restaurant', cuisine: 'Mexican', neigh: 'Miami', price: '$', rating: 4.5, desc: 'Miami\'s most famous Cuban café — a Little Havana institution for ropa vieja, pressed sandwiches, and café cubano.' },
    { name: 'Cvi.che 105', cuisine: 'Mexican', neigh: 'Miami', price: '$$', rating: 4.6, desc: 'Downtown Peruvian-Latin gem with a dozen varieties of ceviche, tiraditos, and causa in vibrant preparations.' },
    { name: 'KYU', cuisine: 'American', neigh: 'Miami', price: '$$$', rating: 4.7, desc: 'Wynwood Asian-inspired wood-fire grill with smoked meats, tableside sauces, and a lively cocktail program.' },
    { name: 'Macchialina', cuisine: 'Italian', neigh: 'Miami', price: '$$', rating: 4.7, desc: 'South Beach neighborhood Italian with handmade pasta, small-batch wines, and a welcoming Venetian atmosphere.' },
    { name: 'Pubbelly Sushi', cuisine: 'Japanese', neigh: 'Miami', price: '$$', rating: 4.6, desc: 'South Beach izakaya fusion with creative sushi rolls, Japanese small plates, and sake cocktails.' },
    { name: 'Jaguar Sun', cuisine: 'American', neigh: 'Miami', price: '$$', rating: 4.7, desc: 'Downtown Miami wine bar and kitchen with snappy bar bites, natural wines, and Florida-sourced ingredients.' },
    { name: 'Coyo Taco', cuisine: 'Mexican', neigh: 'Miami', price: '$', rating: 4.5, desc: 'Wynwood taqueria with masa tortillas ground daily, wood-fired proteins, and a mezcal-heavy back bar.' },
    { name: 'Boia De', cuisine: 'Italian', neigh: 'Miami', price: '$$$', rating: 4.8, desc: 'Little River trattoria with a focused menu of handmade pastas and natural wines in a converted strip mall.' },
    { name: 'Mandolin Aegean Bistro', cuisine: 'Mediterranean', neigh: 'Miami', price: '$$', rating: 4.7, desc: 'Design District Mediterranean oasis with Greek and Turkish mezze served in a garden courtyard setting.' },
    { name: 'Zak the Baker', cuisine: 'American', neigh: 'Miami', price: '$', rating: 4.6, desc: 'Wynwood artisan bakery with sourdough, bagels, and hearty sandwiches built on naturally-leavened bread.' },
    { name: 'El Cielo', cuisine: 'Mexican', neigh: 'Miami', price: '$$$', rating: 4.6, desc: 'Brickell Colombian tasting menu taking diners on a journey through regional Colombian ingredients and technique.' },
    { name: 'Kiki on the River', cuisine: 'Mediterranean', neigh: 'Miami', price: '$$$', rating: 4.5, desc: 'Greek waterfront restaurant on the Miami River with whole fish, mezze, and bottle service at sundown.' },
    { name: 'Fiola Mare', cuisine: 'Italian', neigh: 'Miami', price: '$$$', rating: 4.6, desc: 'Brickell Bay Italian seafood restaurant with fresh pasta, Adriatic-style fish, and a stunning waterfront terrace.' },
    { name: 'Naoe', cuisine: 'Japanese', neigh: 'Miami', price: '$$$', rating: 4.9, desc: 'Brickell Key kaiseki-inspired omakase with four seats and a single tasting menu that changes daily.' },
    { name: 'Mignonette', cuisine: 'American', neigh: 'Miami', price: '$$', rating: 4.7, desc: 'Edgewater upscale seafood diner with a packed raw bar, superb lobster bisque, and daily fish specials.' },
    { name: 'Chug\'s Diner', cuisine: 'American', neigh: 'Miami', price: '$', rating: 4.5, desc: 'Coconut Grove diner from the Pubbelly team with Cuban-American breakfast plates and memorable pressed sandwiches.' },
    { name: 'Tigre', cuisine: 'Mexican', neigh: 'Miami', price: '$$', rating: 4.5, desc: 'Wynwood Mexican with aguachile, wood-roasted meats, and a mezcal program that rivals the best in the country.' },
    { name: 'NIU Kitchen', cuisine: 'Mediterranean', neigh: 'Miami', price: '$$', rating: 4.6, desc: 'Downtown Miami Catalan pintxos bar with Iberian charcuterie, vermouth service, and creative small plates.' },
    { name: 'Seaspice', cuisine: 'Mediterranean', neigh: 'Miami', price: '$$$', rating: 4.4, desc: 'Miami River waterfront Mediterranean with whole-roasted fish, mezze, and spectacular sunset views of the skyline.' },
    { name: 'Kon Chau', cuisine: 'Chinese', neigh: 'Miami', price: '$', rating: 4.4, desc: 'Richmond Heights dim sum institution with an extensive Hong Kong-style cart service every weekend morning.' },

    // ── San Francisco (~20) ────────────────────────────────────────────────────
    { name: 'Mister Jiu\'s', cuisine: 'Chinese', neigh: 'San Francisco', price: '$$$', rating: 4.8, desc: 'Brandon Jew\'s Michelin-starred Chinatown restaurant reimagining Cantonese banquet cooking with California ingredients.' },
    { name: 'Lai Hong Lounge', cuisine: 'Chinese', neigh: 'San Francisco', price: '$', rating: 4.7, desc: 'Richmond District dim sum institution with the city\'s most sought-after weekend har gow and siu mai.' },
    { name: 'China Live', cuisine: 'Chinese', neigh: 'San Francisco', price: '$$', rating: 4.5, desc: 'Chinatown multi-concept food hall with elevated regional Chinese dishes from across every province.' },
    { name: 'Ippudo SF', cuisine: 'Japanese', neigh: 'San Francisco', price: '$$', rating: 4.5, desc: 'Union Square outpost of the Hakata ramen chain with signature tonkotsu broth and house-made noodles.' },
    { name: 'Omakase', cuisine: 'Japanese', neigh: 'San Francisco', price: '$$$', rating: 4.9, desc: 'SOMA intimate counter offering a choreographed 17-course nigiri omakase with fish from the Tsukiji network.' },
    { name: 'Nopa', cuisine: 'American', neigh: 'San Francisco', price: '$$', rating: 4.7, desc: 'NOPA neighborhood anchor open until 1am with wood-fired whole-animal cooking and California-grown produce.' },
    { name: 'Zuni Café', cuisine: 'American', neigh: 'San Francisco', price: '$$$', rating: 4.8, desc: 'Hayes Valley landmark since 1979 famous for its brick-oven roasted chicken, Caesar salad, and oysters.' },
    { name: 'La Taqueria', cuisine: 'Mexican', neigh: 'San Francisco', price: '$', rating: 4.8, desc: 'Mission District taqueria awarded America\'s best burrito — beans, meat, and salsa in a tight, no-rice package.' },
    { name: 'Taqueria Cancun', cuisine: 'Mexican', neigh: 'San Francisco', price: '$', rating: 4.6, desc: 'Mission staple with carne asada super burritos, al pastor tacos, and an always-packed counter at all hours.' },
    { name: 'Papalote Mexican Grill', cuisine: 'Mexican', neigh: 'San Francisco', price: '$', rating: 4.5, desc: 'Inner Mission beloved for its award-winning salsa verde, grilled carnitas, and super burritos.' },
    { name: 'Kokkari Estiatorio', cuisine: 'Mediterranean', neigh: 'San Francisco', price: '$$$', rating: 4.7, desc: 'Financial District Greek taverna with wood-fire roasted lamb, grilled whole fish, and an extensive Hellenic wine list.' },
    { name: 'Aziza', cuisine: 'Mediterranean', neigh: 'San Francisco', price: '$$$', rating: 4.6, desc: 'Inner Richmond Moroccan restaurant with refined tagines, bastilla, and ras el hanout-spiced seasonal produce.' },
    { name: 'Ju-Ni', cuisine: 'Japanese', neigh: 'San Francisco', price: '$$$', rating: 4.8, desc: 'Hayes Valley 12-seat omakase with a singular focus on nigiri, each piece a study in restraint and precision.' },
    { name: 'Ramen Dojo', cuisine: 'Japanese', neigh: 'San Francisco', price: '$', rating: 4.6, desc: 'San Mateo ramen cult classic with intensely garlicky tonkotsu broth and handmade thick noodles.' },
    { name: 'Tong Kiang', cuisine: 'Chinese', neigh: 'San Francisco', price: '$', rating: 4.5, desc: 'Richmond District Hakka and dim sum restaurant with Hakka-style braised pork, salt-baked chicken, and steamed rice rolls.' },
    { name: 'Palette Korean Cuisine', cuisine: 'Korean', neigh: 'San Francisco', price: '$$', rating: 4.5, desc: 'Japantown contemporary Korean restaurant with refined banchan, bulgogi hot pot, and Korean craft cocktails.' },
    { name: 'Namu Gaji', cuisine: 'Korean', neigh: 'San Francisco', price: '$$', rating: 4.6, desc: 'Mission District Korean-Californian with a farmers market menu, kimchi fried rice, and Korean-inspired tacos.' },
    { name: 'Liholiho Yacht Club', cuisine: 'American', neigh: 'San Francisco', price: '$$$', rating: 4.7, desc: 'Tenderloin Hawaiian-inflected American with poke tostadas, brisket fried rice, and tropical cocktails.' },
    { name: 'Foreign Cinema', cuisine: 'French', neigh: 'San Francisco', price: '$$$', rating: 4.6, desc: 'Mission outdoor courtyard cinema and French-Californian restaurant with weekend brunch and classic films projected.' },
    { name: 'Marlowe', cuisine: 'American', neigh: 'San Francisco', price: '$$$', rating: 4.6, desc: 'SOMA gastropub with a celebrated Marlowe burger, dry-aged steaks, and an ambitious American-French bistro menu.' },
  ];

  const sectionsByType = {
    Japanese: ['Starters', 'Mains', 'Desserts'],
    Italian: ['Antipasti', 'Primi', 'Secondi'],
    Mexican: ['Antojitos', 'Tacos & Mains', 'Sides & Drinks'],
    Indian: ['Starters', 'Curries & Mains', 'Breads & Rice'],
    Thai: ['Soups & Salads', 'Mains', 'Noodles & Rice'],
    American: ['Starters', 'Mains', 'Sides'],
    Chinese: ['Dim Sum & Starters', 'Mains', 'Noodles & Rice'],
    Mediterranean: ['Mezze', 'Mains', 'Sweets'],
    Korean: ['Banchan & Starters', 'Mains', 'BBQ'],
    French: ['Entrées', 'Plats', 'Desserts'],
  };

  const itemsByCuisine = {
    Japanese: [
      ['Edamame', 'Steamed salted soybeans, served warm', 600],
      ['Gyoza', 'Pan-fried pork and cabbage dumplings with ponzu', 1200],
      ['Karaage', 'Japanese fried chicken with kewpie mayo and lemon', 1400],
      ['Tonkotsu Ramen', 'Rich pork broth, thin noodles, chashu, soft egg', 1800],
      ['Shoyu Ramen', 'Soy-seasoned clear chicken broth with wavy noodles', 1700],
      ['Salmon Sashimi', 'Six slices of Atlantic salmon with wasabi and ginger', 1900],
      ['Spicy Tuna Roll', 'Fresh tuna, sriracha mayo, cucumber, sesame', 1500],
      ['Miso Black Cod', 'Nobu-style sake-marinated black cod broiled to perfection', 2800],
      ['Matcha Ice Cream', 'House-made ceremonial grade matcha gelato', 900],
      ['Mochi', 'Two pieces of mochi ice cream — mango and strawberry', 800],
    ],
    Italian: [
      ['Burrata', 'Creamy burrata with heirloom tomatoes, basil oil, and sea salt', 1600],
      ['Arancini', 'Crispy saffron risotto balls with fontina and marinara', 1400],
      ['Cacio e Pepe', 'Hand-rolled tonnarelli with Pecorino Romano and black pepper', 2200],
      ['Rigatoni all\'Amatriciana', 'Guanciale, San Marzano tomato, Pecorino, chili', 2300],
      ['Margherita Pizza', 'San Marzano tomato, fior di latte, fresh basil', 1900],
      ['Chicken Piccata', 'Pan-seared chicken breast, lemon-caper butter sauce', 2600],
      ['Branzino al Forno', 'Whole roasted European seabass with herbs and olive oil', 3200],
      ['Tiramisu', 'Classic espresso-soaked ladyfingers with mascarpone cream', 1100],
      ['Panna Cotta', 'Vanilla bean panna cotta with macerated berries', 1000],
      ['Cannoli', 'Crispy shells filled with sweet ricotta and pistachios', 900],
    ],
    Mexican: [
      ['Guacamole', 'Table-side guacamole with chips, jalapeño, and cotija', 1400],
      ['Elotes', 'Mexican street corn with crema, cotija, chili, and lime', 1100],
      ['Tacos al Pastor', 'Three tacos with adobada pork, pineapple, and cilantro', 1500],
      ['Carnitas Tacos', 'Slow-cooked pork shoulder with onion, salsa verde', 1500],
      ['Birria de Res', 'Braised beef birria with consomé for dipping, three tacos', 1900],
      ['Enchiladas Verdes', 'Chicken enchiladas with tomatillo sauce and crema', 2100],
      ['Chiles en Nogada', 'Roasted poblano stuffed with picadillo and walnut cream', 2800],
      ['Mole Negro', 'Oaxacan black mole with chicken, served with rice and tortillas', 2600],
      ['Churros', 'Fried dough with cinnamon sugar and chocolate dipping sauce', 900],
      ['Tres Leches', 'Classic soaked sponge cake with whipped cream topping', 1000],
    ],
    Indian: [
      ['Samosa Chaat', 'Crispy samosas topped with chickpeas, tamarind, and yogurt', 1200],
      ['Tandoori Chicken', 'Half chicken marinated in yogurt and spices, clay oven roasted', 2200],
      ['Seekh Kebab', 'Minced lamb with ginger, garlic, and herbs on a skewer', 1800],
      ['Butter Chicken', 'Slow-cooked tomato-cream curry with tender chicken pieces', 2400],
      ['Dal Makhani', 'Slow-simmered black lentils with butter and cream', 1900],
      ['Palak Paneer', 'Cottage cheese in spiced spinach gravy', 1900],
      ['Lamb Rogan Josh', 'Kashmiri braised lamb with whole spices and Kashmiri chili', 2600],
      ['Garlic Naan', 'Tandoor-baked flatbread with garlic and butter', 500],
      ['Biryani', 'Fragrant basmati rice with saffron, lamb, and caramelized onions', 2800],
      ['Gulab Jamun', 'Milk-solid dumplings in rose syrup, two pieces', 800],
    ],
    Thai: [
      ['Tom Yum Soup', 'Spicy-sour lemongrass broth with shrimp, mushrooms, galangal', 1500],
      ['Som Tum', 'Green papaya salad with peanuts, dried shrimp, lime, and fish sauce', 1400],
      ['Fish Sauce Wings', 'Crispy fried wings with fish sauce caramel and fresh herbs', 1600],
      ['Pad Thai', 'Rice noodles with shrimp, egg, bean sprouts, peanuts, and tamarind', 1900],
      ['Khao Soi', 'Northern Thai coconut curry noodle soup with crispy noodles', 2100],
      ['Green Curry', 'Coconut milk green curry with chicken, Thai basil, and eggplant', 2200],
      ['Pad See Ew', 'Wide rice noodles stir-fried with egg, broccolini, and soy', 1900],
      ['Massaman Curry', 'Southern Thai peanut curry with beef and potatoes', 2300],
      ['Mango Sticky Rice', 'Sweet glutinous rice with fresh mango and coconut cream', 900],
      ['Fried Banana', 'Tempura-battered banana with honey and sesame seeds', 800],
    ],
    American: [
      ['Onion Rings', 'Beer-battered rings with chipotle ranch dipping sauce', 1000],
      ['Caesar Salad', 'Romaine, house dressing, Parmigiano, garlic croutons', 1600],
      ['Chicken Wings', 'Crispy wings with choice of buffalo, BBQ, or honey garlic', 1700],
      ['Classic Burger', '8oz dry-aged beef patty with cheddar, lettuce, tomato, pickles', 1800],
      ['BBQ Brisket', 'Twelve-hour smoked beef brisket with house pickles and white bread', 2800],
      ['Fried Chicken Sandwich', 'Crispy thigh with coleslaw and hot honey on a brioche bun', 1900],
      ['Lobster Roll', 'Cold Connecticut-style with lemon mayo on a toasted split-top bun', 3200],
      ['Mac and Cheese', 'Baked five-cheese with breadcrumb topping', 1500],
      ['Chocolate Cake', 'Three-layer devil\'s food with fudge frosting and sea salt', 1100],
      ['Apple Pie', 'Lattice-top pie with cinnamon, served warm with vanilla ice cream', 1000],
    ],
    Chinese: [
      ['Steamed Dumplings', 'Six pork and shrimp dumplings with ginger soy dipping sauce', 1100],
      ['Scallion Pancake', 'Flaky layered pancake with hoisin and chili oil', 900],
      ['Kung Pao Chicken', 'Sichuan classic with dried chilies, peanuts, and Shaoxing wine', 2100],
      ['Mapo Tofu', 'Silken tofu in numbing Sichuan peppercorn and doubanjiang sauce', 1900],
      ['Peking Duck', 'Half duck with pancakes, hoisin, cucumber, and scallion', 4500],
      ['Dan Dan Noodles', 'Sesame-chili noodles with ground pork and preserved vegetables', 1700],
      ['Beef Chow Fun', 'Wok-fried wide rice noodles with tender beef and bean sprouts', 1900],
      ['Salt and Pepper Shrimp', 'Crispy shell-on shrimp with garlic, ginger, and chili', 2200],
      ['Soup Dumplings', 'Six xiaolongbao filled with pork and hot broth', 1400],
      ['Sesame Balls', 'Three fried glutinous rice balls filled with red bean paste', 800],
    ],
    Mediterranean: [
      ['Hummus', 'Silky chickpea hummus with olive oil, paprika, and warm pita', 1200],
      ['Spanakopita', 'Crispy phyllo triangles filled with spinach and feta', 1300],
      ['Baba Ganoush', 'Smoky roasted eggplant dip with pomegranate seeds', 1200],
      ['Grilled Octopus', 'Charred octopus with lemon, olive oil, and capers', 2200],
      ['Falafel Plate', 'Crispy chickpea falafel with tzatziki, tabbouleh, and pita', 1800],
      ['Lamb Kebab', 'Spiced ground lamb skewer with cucumber yogurt and flatbread', 2400],
      ['Branzino', 'Whole grilled Mediterranean seabass with herbs and lemon', 3200],
      ['Moussaka', 'Baked eggplant and lamb casserole with béchamel topping', 2500],
      ['Baklava', 'Flaky phyllo with pistachio and honey, three pieces', 900],
      ['Loukoumades', 'Honey-soaked Greek donut holes with cinnamon and sesame', 800],
    ],
    Korean: [
      ['Japchae', 'Glass noodles stir-fried with vegetables and sesame', 1600],
      ['Pajeon', 'Crispy seafood and scallion pancake with soy dipping sauce', 1500],
      ['Tteokbokki', 'Spicy rice cakes with fish cake in gochujang sauce', 1400],
      ['Bibimbap', 'Mixed rice bowl with seasonal vegetables, beef, and gochujang', 2000],
      ['Galbi', 'Grilled short ribs marinated in soy, pear, and sesame', 3200],
      ['Samgyeopsal', 'Thick-cut pork belly for tabletop grilling with ssam and kimchi', 2800],
      ['Sundubu Jjigae', 'Silken tofu stew with pork, clams, and spicy broth', 1900],
      ['Kimchi Fried Rice', 'Wok-fried rice with aged kimchi, pork, and a fried egg', 1700],
      ['Bingsu', 'Shaved milk ice with red bean, condensed milk, and mochi', 1100],
      ['Hotteok', 'Sweet filled Korean pancake with brown sugar and peanuts', 700],
    ],
    French: [
      ['Soupe à l\'Oignon', 'Classic French onion soup with Gruyère crouton', 1400],
      ['Escargot', 'Six snails in garlic-parsley butter with toasted baguette', 1800],
      ['Steak Tartare', 'Hand-cut beef with capers, cornichons, Dijon, and egg yolk', 2200],
      ['Steak Frites', 'Bavette steak with house frites and béarnaise sauce', 2800],
      ['Duck Confit', 'Slow-cooked duck leg with lentils du Puy and mustard jus', 2900],
      ['Bouillabaisse', 'Provençal seafood stew with rouille and crusty bread', 3400],
      ['Croque Monsieur', 'Grilled ham and Gruyère sandwich with béchamel', 1600],
      ['Sole Meunière', 'Dover sole in brown butter with capers and lemon', 3200],
      ['Crème Brûlée', 'Vanilla custard with caramelized sugar crust', 1100],
      ['Tarte Tatin', 'Upside-down caramelized apple tart with crème fraîche', 1200],
    ],
  };

  const reviewAuthors = ['Alex R.', 'Jordan M.', 'Casey L.', 'Morgan T.', 'Riley S.', 'Sam W.', 'Taylor B.', 'Quinn H.', 'Avery P.', 'Drew K.'];
  const reviewDates = ['2025-09-15', '2025-10-22', '2025-11-08', '2025-12-01', '2026-01-14', '2026-02-28', '2026-03-10', '2026-04-05', '2026-05-20', '2026-06-01'];
  const reviewTemplates = [
    ['Absolutely incredible. Best {cuisine} in NYC by a wide margin.', 5],
    ['Came here on a date night and left completely blown away. Will be back.', 5],
    ['The flavors are so authentic and the service was warm and attentive.', 5],
    ['One of my favorite spots in the city. Never disappoints.', 5],
    ['Really solid {cuisine}. Fresh ingredients and generous portions.', 4],
    ['Great neighborhood spot — always packed for a reason. Highly recommend.', 4],
    ['The food was excellent but parking nearby was a bit tricky.', 4],
    ['Wonderful meal from start to finish. The {cuisine} here is unmatched.', 5],
  ];

  const cityStreetNames = {
    'Los Angeles':    ['Sunset Blvd', 'Melrose Ave', 'La Brea Ave', 'Abbot Kinney Blvd', 'Wilshire Blvd', 'Figueroa St', 'Vermont Ave', 'Western Ave'],
    'Chicago':        ['Michigan Ave', 'Wacker Dr', 'Clark St', 'Halsted St', 'Milwaukee Ave', 'Division St', 'Armitage Ave', 'Diversey Pkwy'],
    'Boston':         ['Boylston St', 'Newbury St', 'Tremont St', 'Commonwealth Ave', 'Hanover St', 'Congress St', 'Charles St', 'Cambridge St'],
    'Miami':          ['Ocean Dr', 'Collins Ave', 'Brickell Ave', 'NW 2nd Ave', 'Miracle Mile', 'Calle Ocho', 'Wynwood Walls Dr', 'Biscayne Blvd'],
    'San Francisco':  ['Mission St', 'Valencia St', 'Fillmore St', 'Hayes St', 'Geary Blvd', 'Divisadero St', 'Columbus Ave', 'Market St'],
  };
  const defaultStreetNames = ['Broadway', 'Park Ave', 'Lexington Ave', 'Bedford Ave', 'Steinway St', 'Astoria Blvd', 'Atlantic Ave', 'Flatbush Ave', 'Queens Blvd', 'Amsterdam Ave'];

  const restaurants = [];
  const menuSections = [];
  const menuItems = [];
  const reviews = [];

  restaurantDefs.forEach((def, idx) => {
    const rid = uuidv4();
    const streetNum = 100 + (idx * 7 % 900);
    const streets = cityStreetNames[def.neigh] || defaultStreetNames;
    const street = streets[idx % streets.length];
    const cityLabel = cityStreetNames[def.neigh] ? def.neigh : `${def.neigh}, New York, NY`;
    const addressCity = cityStreetNames[def.neigh] ? `${def.neigh}, CA` : `${def.neigh}, New York, NY`;
    const fullAddress = cityStreetNames[def.neigh]
      ? `${streetNum} ${street}, ${def.neigh}`
      : `${streetNum} ${street}, ${def.neigh}, New York, NY`;

    const deliveryRadii = [3.0, 4.5, 5.0, 6.5, 7.0, 8.5, 9.0, 10.5, 11.0, 12.0];
    const coverPhotoId = RESTAURANT_COVER_PHOTOS[def.name];
    const coverUrl = coverPhotoId
      ? `https://images.unsplash.com/photo-${coverPhotoId}?w=800&h=600&fit=crop&crop=entropy&auto=format`
      : indexedPhotoUrl(idx);

    restaurants.push({
      id: rid,
      name: def.name,
      cuisine_id: cuisineMap[def.cuisine],
      neighbourhood_id: neighMap[def.neigh],
      description: def.desc,
      address: fullAddress,
      price_range: def.price,
      cover_image_url: coverUrl,
      average_rating: def.rating,
      delivery_radius_km: deliveryRadii[idx % deliveryRadii.length],
    });

    const sections = sectionsByType[def.cuisine];
    const sectionIds = sections.map((sname, si) => {
      const sid = uuidv4();
      menuSections.push({ id: sid, restaurant_id: rid, name: sname, sort_order: si });
      return sid;
    });

    const items = itemsByCuisine[def.cuisine];
    items.forEach((item, ii) => {
      const sectionId = sectionIds[ii < 3 ? 0 : ii < 7 ? 1 : 2];
      const imgUrl = MENU_ITEM_PHOTOS[item[0]] || MENU_ITEM_PHOTOS['__fallback__'];
      menuItems.push({
        id: uuidv4(),
        section_id: sectionId,
        name: item[0],
        description: item[1],
        price_value: item[2],
        price_scale: 2,
        image_url: imgUrl,
      });
    });

    for (let r = 0; r < 3; r++) {
      const [tmpl, rating] = reviewTemplates[(idx + r) % reviewTemplates.length];
      reviews.push({
        id: uuidv4(),
        restaurant_id: rid,
        author_name: reviewAuthors[(idx + r) % reviewAuthors.length],
        rating,
        body: tmpl.replace('{cuisine}', def.cuisine.toLowerCase()),
        review_date: reviewDates[(idx + r) % reviewDates.length],
      });
    }
  });

  const insertAll = db.transaction(() => {
    const insertCuisine = db.prepare('INSERT INTO cuisine (id, name) VALUES (?, ?)');
    cuisines.forEach(c => insertCuisine.run(c.id, c.name));

    const insertNeighbourhood = db.prepare('INSERT INTO neighbourhood (id, name) VALUES (?, ?)');
    neighbourhoods.forEach(n => insertNeighbourhood.run(n.id, n.name));

    const insertRestaurant = db.prepare(
      'INSERT INTO restaurant (id, name, cuisine_id, neighbourhood_id, description, address, price_range, cover_image_url, average_rating, delivery_radius_km) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    restaurants.forEach(r => insertRestaurant.run(r.id, r.name, r.cuisine_id, r.neighbourhood_id, r.description, r.address, r.price_range, r.cover_image_url, r.average_rating, r.delivery_radius_km));

    const insertSection = db.prepare('INSERT INTO menu_section (id, restaurant_id, name, sort_order) VALUES (?, ?, ?, ?)');
    menuSections.forEach(s => insertSection.run(s.id, s.restaurant_id, s.name, s.sort_order));

    const insertItem = db.prepare('INSERT INTO menu_item (id, section_id, name, description, price_value, price_scale, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)');
    menuItems.forEach(i => insertItem.run(i.id, i.section_id, i.name, i.description, i.price_value, i.price_scale, i.image_url));

    const insertReview = db.prepare('INSERT INTO review (id, restaurant_id, author_name, rating, body, review_date) VALUES (?, ?, ?, ?, ?, ?)');
    reviews.forEach(r => insertReview.run(r.id, r.restaurant_id, r.author_name, r.rating, r.body, r.review_date));
  });

  insertAll();
  console.log(`[seed] Done. Inserted ${restaurants.length} restaurants, ${menuItems.length} menu items, ${reviews.length} reviews.`);
}

seed();
