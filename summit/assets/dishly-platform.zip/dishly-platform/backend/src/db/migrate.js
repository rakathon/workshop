const db = require('./connection');

function migrate() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS user (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cuisine (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS neighbourhood (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS restaurant (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      cuisine_id TEXT NOT NULL REFERENCES cuisine(id),
      neighbourhood_id TEXT NOT NULL REFERENCES neighbourhood(id),
      description TEXT NOT NULL,
      address TEXT NOT NULL,
      price_range TEXT NOT NULL CHECK(price_range IN ('$', '$$', '$$$')),
      cover_image_url TEXT NOT NULL,
      average_rating REAL NOT NULL,
      delivery_radius_km REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS menu_section (
      id TEXT PRIMARY KEY,
      restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
      name TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS menu_item (
      id TEXT PRIMARY KEY,
      section_id TEXT NOT NULL REFERENCES menu_section(id),
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      price_value INTEGER NOT NULL,
      price_scale INTEGER NOT NULL DEFAULT 2,
      image_url TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS review (
      id TEXT PRIMARY KEY,
      restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
      author_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
      body TEXT NOT NULL,
      review_date TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS "order" (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES user(id),
      restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
      delivery_address TEXT,
      subtotal_value INTEGER NOT NULL,
      subtotal_scale INTEGER NOT NULL DEFAULT 2,
      delivery_fee_value INTEGER NOT NULL DEFAULT 399,
      delivery_fee_scale INTEGER NOT NULL DEFAULT 2,
      total_value INTEGER NOT NULL,
      total_scale INTEGER NOT NULL DEFAULT 2,
      status TEXT NOT NULL DEFAULT 'confirmed',
      created_at TEXT NOT NULL,
      deleted_at TEXT
    );

    CREATE TABLE IF NOT EXISTS order_item (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES "order"(id) ON DELETE CASCADE,
      menu_item_id TEXT NOT NULL REFERENCES menu_item(id),
      item_name TEXT NOT NULL,
      quantity INTEGER NOT NULL CHECK(quantity >= 1),
      unit_price_value INTEGER NOT NULL,
      unit_price_scale INTEGER NOT NULL DEFAULT 2
    );
  `);
  try { db.exec('ALTER TABLE user ADD COLUMN name TEXT'); } catch (_) {}
  try { db.exec('ALTER TABLE user ADD COLUMN phone TEXT'); } catch (_) {}

  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS user_address (
        id         TEXT PRIMARY KEY,
        user_id    TEXT    NOT NULL REFERENCES user(id) ON DELETE CASCADE,
        label      TEXT,
        street     TEXT    NOT NULL,
        city       TEXT    NOT NULL,
        postcode   TEXT    NOT NULL,
        is_default INTEGER NOT NULL DEFAULT 0,
        created_at TEXT    NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_user_address_user_id ON user_address(user_id);
      CREATE TABLE IF NOT EXISTS user_payment_method (
        id              TEXT PRIMARY KEY,
        user_id         TEXT NOT NULL REFERENCES user(id) ON DELETE CASCADE,
        card_type       TEXT NOT NULL CHECK(card_type IN ('Visa', 'Mastercard', 'Amex')),
        cardholder_name TEXT NOT NULL,
        last_four       TEXT,
        created_at      TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_user_payment_method_user_id ON user_payment_method(user_id);
    `);
  } catch (_) {}
  // Add last_four column to existing DBs that were created before this migration
  try { db.exec('ALTER TABLE user_payment_method ADD COLUMN last_four TEXT'); } catch (_) {}
}

module.exports = { migrate };
