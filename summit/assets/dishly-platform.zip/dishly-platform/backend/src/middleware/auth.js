const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const SALT_ROUNDS = 10;
const JWT_SECRET = process.env.JWT_SECRET || 'dishly-dev-secret';

function hashPassword(plain) {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

function comparePassword(plain, hash) {
  return bcrypt.compare(plain, hash);
}

function signToken(userId) {
  return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: '7d' });
}

function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'Authentication required' }],
      meta: { status: { code: 'UNAUTHORIZED' }, operation: { request_id: uuidv4() } },
    });
  }

  try {
    const payload = verifyToken(token);
    req.user = { id: payload.sub };
    next();
  } catch {
    return res.status(401).json({
      errors: [{ code: 'UNAUTHORIZED', message: 'Invalid or expired token' }],
      meta: { status: { code: 'UNAUTHORIZED' }, operation: { request_id: uuidv4() } },
    });
  }
}

module.exports = { hashPassword, comparePassword, signToken, verifyToken, requireAuth };
