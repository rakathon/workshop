const express = require('express');
const cors = require('cors');
const path = require('path');
const { migrate } = require('./db/migrate');

// Prevent unhandled promise rejections from crashing the server
process.on('unhandledRejection', (reason) => {
  console.error('[server] Unhandled rejection:', reason);
});

const app = express();
const PORT = process.env.PORT || 3001;

migrate();

app.use(cors());
app.use(express.json());

app.use('/dishly/v1', require('./routes'));

// Serve React app for all non-API routes
const frontendDist = path.join(__dirname, '../../frontend/dist');
app.use(express.static(frontendDist));
app.get('*', (req, res) => {
  res.sendFile(path.join(frontendDist, 'index.html'));
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`dishly backend running on http://localhost:${PORT}`);
  });
}

module.exports = app;
