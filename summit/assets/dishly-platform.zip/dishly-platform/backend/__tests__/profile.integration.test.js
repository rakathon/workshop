// Integration tests — Customer Profile Section (TASK-010)
// Source: .forge/efforts/customer-profile-section/spec/test/integration-test-suite.md
// Covers: SC-1..SC-16  (BR-1..BR-5, TR-1..TR-7)

// Must be first — before any require that touches the DB
process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'dishly-dev-secret';

jest.setTimeout(15000);

const request = require('supertest');
const { v4: uuidv4 } = require('uuid');
const { runMigrations, createUser } = require('./helpers/testDb');

let app;
let db;

beforeAll(() => {
  jest.isolateModules(() => {
    db = require('../src/db/connection');
    app = require('../src/server');
  });
  runMigrations(db);
});

beforeEach(() => {
  db.prepare('DELETE FROM user_payment_method').run();
  db.prepare('DELETE FROM user_address').run();
  db.prepare('DELETE FROM order_item').run();
  db.prepare('DELETE FROM "order"').run();
  db.prepare('DELETE FROM user').run();
});

// ── helpers ────────────────────────────────────────────────────────────

function auth(token) {
  return { Authorization: `Bearer ${token}` };
}

function insertAddress(userId, overrides = {}) {
  const id = uuidv4();
  db.prepare(
    'INSERT INTO user_address (id, user_id, label, street, city, postcode, is_default, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(
    id, userId,
    overrides.label ?? 'Home',
    overrides.street ?? '42 Maple St',
    overrides.city ?? 'Springfield',
    overrides.postcode ?? '12345',
    overrides.is_default ? 1 : 0,
    new Date().toISOString()
  );
  return id;
}

function insertPayment(userId, overrides = {}) {
  const id = uuidv4();
  db.prepare(
    'INSERT INTO user_payment_method (id, user_id, card_type, cardholder_name, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run(
    id, userId,
    overrides.card_type ?? 'Visa',
    overrides.cardholder_name ?? 'Alex Brennan',
    new Date().toISOString()
  );
  return id;
}

// ── SC-1: Migration adds name + phone columns ──────────────────────────

test('SC-1: user table has name and phone columns after migration', () => {
  // Verifies: TR-1
  const cols = db.prepare("PRAGMA table_info('user')").all().map(c => c.name);
  expect(cols).toContain('name');
  expect(cols).toContain('phone');

  const nameCol = db.prepare("PRAGMA table_info('user')").all().find(c => c.name === 'name');
  expect(nameCol.notnull).toBe(0); // nullable
});

// ── SC-2: Name and phone persist on register, returned on login ─────────

test('SC-2: register persists name; login returns name', async () => {
  // Verifies: BR-1, BR-5
  const email = `sc2-${uuidv4()}@test.com`;

  const regRes = await request(app)
    .post('/dishly/v1/auth/register')
    .send({ email, password: 'Password1!', name: 'Alex Brennan' });

  expect(regRes.status).toBe(201);
  expect(regRes.body.data.user.name).toBe('Alex Brennan');

  const loginRes = await request(app)
    .post('/dishly/v1/auth/login')
    .send({ email, password: 'Password1!' });

  expect(loginRes.status).toBe(200);
  expect(loginRes.body.data.user.name).toBe('Alex Brennan');

  const row = db.prepare('SELECT name, phone FROM user WHERE email = ?').get(email.toLowerCase());
  expect(row.name).toBe('Alex Brennan');
  expect(row.phone).toBeNull();
});

// ── SC-3: PATCH /users/me persists name and phone ──────────────────────

test('SC-3: PATCH /users/me persists name and phone to DB', async () => {
  // Verifies: BR-2
  const { id, token } = createUser(db, `sc3-${uuidv4()}@test.com`);

  const res = await request(app)
    .patch('/dishly/v1/users/me')
    .set(auth(token))
    .send({ name: 'Jordan Smith', phone: '4155551234' });

  expect(res.status).toBe(200);
  expect(res.body.data.name).toBe('Jordan Smith');
  expect(res.body.data.phone).toBe('4155551234');

  const row = db.prepare('SELECT name, phone FROM user WHERE id = ?').get(id);
  expect(row.name).toBe('Jordan Smith');
  expect(row.phone).toBe('4155551234');
});

// ── SC-4: PATCH /users/me with null phone clears phone ─────────────────

test('SC-4: PATCH /users/me with null phone clears stored phone', async () => {
  // Verifies: BR-2, TR-5
  const { id, token } = createUser(db, `sc4-${uuidv4()}@test.com`);
  db.prepare('UPDATE user SET phone = ? WHERE id = ?').run('4155551234', id);

  const res = await request(app)
    .patch('/dishly/v1/users/me')
    .set(auth(token))
    .send({ phone: null });

  expect(res.status).toBe(200);
  expect(res.body.data.phone).toBeNull();

  const row = db.prepare('SELECT phone FROM user WHERE id = ?').get(id);
  expect(row.phone).toBeNull();
});

// ── SC-5: Auth middleware rejects no bearer token ──────────────────────

test('SC-5: GET /users/me without token returns 401', async () => {
  // Verifies: TR-3
  const res = await request(app).get('/dishly/v1/users/me');
  expect(res.status).toBe(401);
  expect(res.body.errors[0].code).toBe('UNAUTHORIZED');
});

// ── SC-6: Auth middleware rejects invalid token ────────────────────────

test('SC-6: GET /users/me with invalid token returns 401', async () => {
  // Verifies: TR-3
  const res = await request(app)
    .get('/dishly/v1/users/me')
    .set({ Authorization: 'Bearer this.is.not.valid' });
  expect(res.status).toBe(401);
  expect(res.body.errors[0].code).toBe('UNAUTHORIZED');
});

// ── SC-7: Address insert persists correct fields ───────────────────────

test('SC-7: POST /users/me/addresses inserts row with correct fields', async () => {
  // Verifies: BR-3, TR-2
  const { id: userId, token } = createUser(db, `sc7-${uuidv4()}@test.com`);

  const res = await request(app)
    .post('/dishly/v1/users/me/addresses')
    .set(auth(token))
    .send({ label: 'Home', street: '42 Maple St', city: 'Springfield', postcode: '12345' });

  expect(res.status).toBe(201);
  expect(res.body.data.street).toBe('42 Maple St');
  expect(res.body.data.is_default).toBe(true);

  const row = db.prepare('SELECT * FROM user_address WHERE user_id = ?').get(userId);
  expect(row).not.toBeNull();
  expect(row.street).toBe('42 Maple St');
  expect(row.is_default).toBe(1);
});

// ── SC-8: Setting is_default clears prior default ─────────────────────

test('SC-8: second address with is_default=true clears first default', async () => {
  // Verifies: BR-3
  const { id: userId, token } = createUser(db, `sc8-${uuidv4()}@test.com`);
  const addr1Id = insertAddress(userId, { is_default: true });

  await request(app)
    .post('/dishly/v1/users/me/addresses')
    .set(auth(token))
    .send({ street: '10 Work Ave', city: 'Springfield', postcode: '12345', is_default: true });

  const addr1 = db.prepare('SELECT is_default FROM user_address WHERE id = ?').get(addr1Id);
  const defaults = db.prepare('SELECT * FROM user_address WHERE user_id = ? AND is_default = 1').all(userId);

  expect(addr1.is_default).toBe(0);
  expect(defaults).toHaveLength(1);
  expect(defaults[0].street).toBe('10 Work Ave');
});

// ── SC-9: Address cap enforced at 2 ───────────────────────────────────

test('SC-9: third address rejected with 422 CAP_EXCEEDED', async () => {
  // Verifies: BR-3, TR-6
  const { id: userId, token } = createUser(db, `sc9-${uuidv4()}@test.com`);
  insertAddress(userId, { street: '1st St' });
  insertAddress(userId, { street: '2nd St' });

  const res = await request(app)
    .post('/dishly/v1/users/me/addresses')
    .set(auth(token))
    .send({ street: '3rd St', city: 'Springfield', postcode: '12345' });

  expect(res.status).toBe(422);
  expect(res.body.errors[0].code).toBe('CAP_EXCEEDED');

  const count = db.prepare('SELECT COUNT(*) as n FROM user_address WHERE user_id = ?').get(userId).n;
  expect(count).toBe(2);
});

// ── SC-10: user_address cascade-deletes with user ─────────────────────

test('SC-10: user_address rows cascade-delete when user is deleted', () => {
  // Verifies: TR-2 — ON DELETE CASCADE
  const { id: userId } = createUser(db, `sc10-${uuidv4()}@test.com`);
  insertAddress(userId);
  insertAddress(userId, { street: '2nd St' });

  db.prepare('DELETE FROM user WHERE id = ?').run(userId);

  const count = db.prepare('SELECT COUNT(*) as n FROM user_address WHERE user_id = ?').get(userId).n;
  expect(count).toBe(0);
});

// ── SC-11: Address PATCH with wrong user returns 404 ──────────────────

test('SC-11: PATCH address with mismatched user_id returns 404', async () => {
  // Verifies: TR-3 — ownership filter
  const { id: userAId } = createUser(db, `sc11a-${uuidv4()}@test.com`);
  const { token: tokenB } = createUser(db, `sc11b-${uuidv4()}@test.com`);
  const addrId = insertAddress(userAId);

  const res = await request(app)
    .patch(`/dishly/v1/users/me/addresses/${addrId}`)
    .set(auth(tokenB))
    .send({ city: 'Shelbyville' });

  expect(res.status).toBe(404);

  const row = db.prepare('SELECT city FROM user_address WHERE id = ?').get(addrId);
  expect(row.city).toBe('Springfield');
});

// ── SC-12: Payment method insert persists row ─────────────────────────

test('SC-12: POST /users/me/payment_methods inserts row with correct fields', async () => {
  // Verifies: BR-4, TR-2
  const { id: userId, token } = createUser(db, `sc12-${uuidv4()}@test.com`);

  const res = await request(app)
    .post('/dishly/v1/users/me/payment_methods')
    .set(auth(token))
    .send({ card_type: 'Visa', cardholder_name: 'Alex Brennan', card_number: '4111111111111111' });

  expect(res.status).toBe(201);
  expect(res.body.data.card_type).toBe('Visa');

  const row = db.prepare('SELECT * FROM user_payment_method WHERE user_id = ?').get(userId);
  expect(row.card_type).toBe('Visa');
  expect(row.cardholder_name).toBe('Alex Brennan');
});

// ── SC-13: card_type CHECK constraint ────────────────────────────────

test('SC-13: card_type CHECK constraint rejects invalid type at DB layer', () => {
  // Verifies: TR-2
  const { id: userId } = createUser(db, `sc13-${uuidv4()}@test.com`);
  expect(() => {
    db.prepare(
      'INSERT INTO user_payment_method (id, user_id, card_type, cardholder_name, created_at) VALUES (?, ?, ?, ?, ?)'
    ).run(uuidv4(), userId, 'Discover', 'Test User', new Date().toISOString());
  }).toThrow();
});

// ── SC-14: Payment method cap enforced at 2 ───────────────────────────

test('SC-14: third payment method rejected with 422 CAP_EXCEEDED', async () => {
  // Verifies: BR-4, TR-6
  const { id: userId, token } = createUser(db, `sc14-${uuidv4()}@test.com`);
  insertPayment(userId, { card_type: 'Visa' });
  insertPayment(userId, { card_type: 'Mastercard' });

  const res = await request(app)
    .post('/dishly/v1/users/me/payment_methods')
    .set(auth(token))
    .send({ card_type: 'Amex', cardholder_name: 'Alex B', card_number: '3714496353984311' });

  expect(res.status).toBe(422);
  expect(res.body.errors[0].code).toBe('CAP_EXCEEDED');

  const count = db.prepare('SELECT COUNT(*) as n FROM user_payment_method WHERE user_id = ?').get(userId).n;
  expect(count).toBe(2);
});

// ── SC-15: user_payment_method cascade-delete ─────────────────────────

test('SC-15: user_payment_method rows cascade-delete when user is deleted', () => {
  // Verifies: TR-2 — ON DELETE CASCADE
  const { id: userId } = createUser(db, `sc15-${uuidv4()}@test.com`);
  insertPayment(userId);
  insertPayment(userId, { card_type: 'Mastercard' });

  db.prepare('DELETE FROM user WHERE id = ?').run(userId);

  const count = db.prepare('SELECT COUNT(*) as n FROM user_payment_method WHERE user_id = ?').get(userId).n;
  expect(count).toBe(0);
});

// ── SC-16: Concurrent PATCH /users/me — deterministic result ──────────

test('SC-16: concurrent PATCH /users/me produces deterministic last-write result', async () => {
  // Verifies: TR-4 — SQLite serialised writes
  const { token } = createUser(db, `sc16-${uuidv4()}@test.com`);

  const [res1, res2] = await Promise.all([
    request(app).patch('/dishly/v1/users/me').set(auth(token)).send({ name: 'Name A' }),
    request(app).patch('/dishly/v1/users/me').set(auth(token)).send({ name: 'Name B' }),
  ]);

  expect(res1.status).toBe(200);
  expect(res2.status).toBe(200);

  const finalRes = await request(app).get('/dishly/v1/users/me').set(auth(token));
  expect(['Name A', 'Name B']).toContain(finalRes.body.data.name);
});
