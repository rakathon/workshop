// Must be first — before any require that touches the DB
process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'dishly-dev-secret';

jest.setTimeout(15000);

const request = require('supertest');
const { runMigrations, seedReferenceData, createUser } = require('./helpers/testDb');

let app;
let db;
let seeds;
let user;

beforeAll(() => {
  jest.isolateModules(() => {
    // Grab the shared db connection (already pointing at :memory: because DB_PATH was set above)
    db = require('../src/db/connection');
    app = require('../src/server');
  });

  runMigrations(db);
  seeds = seedReferenceData(db);
  user = createUser(db, 'post-order-user@example.com');
});

beforeEach(() => {
  // Clean orders between tests so state doesn't bleed
  db.prepare('DELETE FROM order_item').run();
  db.prepare('DELETE FROM "order"').run();
});

test('POST /orders creates order and returns 201', async () => {
  const { restaurantId, menuItemIds } = seeds;

  const res = await request(app)
    .post('/dishly/v1/orders')
    .set('Authorization', `Bearer ${user.token}`)
    .send({
      restaurant_id: restaurantId,
      items: [{ menu_item_id: menuItemIds[0], quantity: 2 }],
      delivery_address: '123 Main St',
      payment_method_id: 'pm_test_123',
    });

  expect(res.status).toBe(201);
  expect(res.headers.location).toMatch(/\/dishly\/v1\/orders\//);
  const { data } = res.body;
  expect(data).toMatchObject({
    restaurant_id: restaurantId,
    delivery_address: '123 Main St',
    status: 'confirmed',
  });
  expect(data.id).toBeTruthy();
  expect(Array.isArray(data.items)).toBe(true);
  expect(data.items).toHaveLength(1);
  expect(data.items[0]).toMatchObject({
    menu_item_id: menuItemIds[0],
    quantity: 2,
  });
  expect(data.subtotal).toMatchObject({ scale: 2 });
  expect(data.delivery_fee).toMatchObject({ value: 399, scale: 2 });
  expect(data.total).toMatchObject({ scale: 2 });
  expect(res.body.meta.status.code).toBe('CREATED');
});

test('POST /orders returns 422 for items from multiple restaurants', async () => {
  const { restaurantId, menuItemIds, menuItemR2Id } = seeds;

  const res = await request(app)
    .post('/dishly/v1/orders')
    .set('Authorization', `Bearer ${user.token}`)
    .send({
      restaurant_id: restaurantId,
      items: [
        { menu_item_id: menuItemIds[0], quantity: 1 },
        { menu_item_id: menuItemR2Id, quantity: 1 }, // belongs to restaurant2
      ],
      delivery_address: '123 Main St',
      payment_method_id: 'pm_test_123',
    });

  expect(res.status).toBe(422);
  expect(res.body.errors[0].code).toBe('VALIDATION_ERROR');
});

test('POST /orders returns 401 without auth token', async () => {
  const { restaurantId, menuItemIds } = seeds;

  const res = await request(app)
    .post('/dishly/v1/orders')
    .send({
      restaurant_id: restaurantId,
      items: [{ menu_item_id: menuItemIds[0], quantity: 1 }],
      delivery_address: '123 Main St',
      payment_method_id: 'pm_test_123',
    });

  expect(res.status).toBe(401);
  expect(res.body.errors[0].code).toBe('UNAUTHORIZED');
});
