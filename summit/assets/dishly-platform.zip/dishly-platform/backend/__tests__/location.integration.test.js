// Must be first — before any require that touches the DB
process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'dishly-dev-secret';

jest.setTimeout(15000);

const request = require('supertest');
const { v4: uuidv4 } = require('uuid');
const { runMigrations } = require('./helpers/testDb');

let app;
let db;

// Track IDs for filtering assertions
const neighbourhoodIds = {};
const restaurantIds = {};
const cuisineId = uuidv4();

beforeAll(() => {
  jest.isolateModules(() => {
    db = require('../src/db/connection');
    app = require('../src/server');
  });

  runMigrations(db);

  // Insert a shared cuisine
  db.prepare('INSERT INTO cuisine (id, name) VALUES (?, ?)').run(cuisineId, 'American');

  // Insert 10 neighbourhoods
  const neighbourhoodNames = [
    'Manhattan', 'Brooklyn', 'Queens', 'Williamsburg', 'Astoria',
    'Los Angeles', 'Chicago', 'Boston', 'Miami', 'San Francisco',
  ];
  for (const name of neighbourhoodNames) {
    const id = uuidv4();
    neighbourhoodIds[name] = id;
    db.prepare('INSERT INTO neighbourhood (id, name) VALUES (?, ?)').run(id, name);
  }

  // Insert restaurants for Manhattan (2), Chicago (3), Miami (1)
  const insertRestaurant = db.prepare(
    'INSERT INTO restaurant (id, name, cuisine_id, neighbourhood_id, description, address, price_range, cover_image_url, average_rating, delivery_radius_km) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );

  const manhattanR1 = uuidv4();
  const manhattanR2 = uuidv4();
  restaurantIds['Manhattan'] = [manhattanR1, manhattanR2];
  insertRestaurant.run(manhattanR1, 'Manhattan Diner', cuisineId, neighbourhoodIds['Manhattan'], 'Classic diner', '1 Broadway', '$$', 'http://img.test/m1.jpg', 4.2, 5.0);
  insertRestaurant.run(manhattanR2, 'Uptown Grill', cuisineId, neighbourhoodIds['Manhattan'], 'Uptown grill', '100 5th Ave', '$$$', 'http://img.test/m2.jpg', 4.7, 8.0);

  const chicagoR1 = uuidv4();
  const chicagoR2 = uuidv4();
  const chicagoR3 = uuidv4();
  restaurantIds['Chicago'] = [chicagoR1, chicagoR2, chicagoR3];
  insertRestaurant.run(chicagoR1, 'Chicago Deep Dish', cuisineId, neighbourhoodIds['Chicago'], 'Deep dish pizza', '200 N Michigan', '$$', 'http://img.test/c1.jpg', 4.5, 6.0);
  insertRestaurant.run(chicagoR2, 'Windy City Burgers', cuisineId, neighbourhoodIds['Chicago'], 'Gourmet burgers', '300 W Lake', '$', 'http://img.test/c2.jpg', 4.1, 4.0);
  insertRestaurant.run(chicagoR3, 'Lake Shore Steakhouse', cuisineId, neighbourhoodIds['Chicago'], 'Premium steaks', '400 Lake Shore Dr', '$$$', 'http://img.test/c3.jpg', 4.8, 10.0);

  const miamiR1 = uuidv4();
  restaurantIds['Miami'] = [miamiR1];
  insertRestaurant.run(miamiR1, 'South Beach Bites', cuisineId, neighbourhoodIds['Miami'], 'Fresh seafood', '1 Ocean Dr', '$$', 'http://img.test/mi1.jpg', 4.3, 7.0);
});

// ── Neighbourhoods endpoint ──────────────────────────────────────────────────

describe('GET /dishly/v1/neighbourhoods', () => {
  test('returns 200 with all 10 neighbourhoods', async () => {
    const res = await request(app).get('/dishly/v1/neighbourhoods');

    expect(res.status).toBe(200);
    expect(res.body.meta.status.code).toBe('OK');
    expect(Array.isArray(res.body.data)).toBe(true);
    expect(res.body.data.length).toBe(10);
  });

  test('response includes expected neighbourhood names', async () => {
    const res = await request(app).get('/dishly/v1/neighbourhoods');

    const names = res.body.data.map(n => n.name);
    expect(names).toContain('Manhattan');
    expect(names).toContain('Brooklyn');
    expect(names).toContain('Queens');
    expect(names).toContain('Williamsburg');
    expect(names).toContain('Astoria');
    expect(names).toContain('Los Angeles');
    expect(names).toContain('Chicago');
    expect(names).toContain('Boston');
    expect(names).toContain('Miami');
    expect(names).toContain('San Francisco');
  });

  test('each neighbourhood entry has id and name', async () => {
    const res = await request(app).get('/dishly/v1/neighbourhoods');

    for (const neighbourhood of res.body.data) {
      expect(neighbourhood).toHaveProperty('id');
      expect(neighbourhood).toHaveProperty('name');
      expect(typeof neighbourhood.id).toBe('string');
      expect(typeof neighbourhood.name).toBe('string');
    }
  });

  test('results are returned in alphabetical order by name', async () => {
    const res = await request(app).get('/dishly/v1/neighbourhoods');

    const names = res.body.data.map(n => n.name);
    const sorted = [...names].sort();
    expect(names).toEqual(sorted);
  });
});

// ── Restaurants neighbourhood_id filter ─────────────────────────────────────

describe('GET /dishly/v1/restaurants?neighbourhood_id=', () => {
  test('returns only Manhattan restaurants when filtering by Manhattan', async () => {
    const id = neighbourhoodIds['Manhattan'];
    const res = await request(app).get(`/dishly/v1/restaurants?neighbourhood_id=${id}`);

    expect(res.status).toBe(200);
    expect(res.body.meta.status.code).toBe('OK');
    expect(Array.isArray(res.body.data)).toBe(true);
    expect(res.body.data.length).toBe(2);

    for (const r of res.body.data) {
      expect(r.neighbourhood.id).toBe(id);
      expect(r.neighbourhood.name).toBe('Manhattan');
    }
  });

  test('returns only Chicago restaurants when filtering by Chicago', async () => {
    const id = neighbourhoodIds['Chicago'];
    const res = await request(app).get(`/dishly/v1/restaurants?neighbourhood_id=${id}`);

    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(3);

    for (const r of res.body.data) {
      expect(r.neighbourhood.id).toBe(id);
      expect(r.neighbourhood.name).toBe('Chicago');
    }
  });

  test('returns only Miami restaurant when filtering by Miami', async () => {
    const id = neighbourhoodIds['Miami'];
    const res = await request(app).get(`/dishly/v1/restaurants?neighbourhood_id=${id}`);

    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(1);
    expect(res.body.data[0].neighbourhood.id).toBe(id);
    expect(res.body.data[0].neighbourhood.name).toBe('Miami');
    expect(res.body.data[0].name).toBe('South Beach Bites');
  });

  test('returns empty array for a neighbourhood with no restaurants', async () => {
    const id = neighbourhoodIds['Boston'];
    const res = await request(app).get(`/dishly/v1/restaurants?neighbourhood_id=${id}`);

    expect(res.status).toBe(200);
    expect(res.body.data).toEqual([]);
    expect(res.body.pagination.next).toBeNull();
  });

  test('returns all 6 seeded restaurants when no filter is applied', async () => {
    const res = await request(app).get('/dishly/v1/restaurants');

    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(6);
  });

  test('each restaurant in filtered result has correct shape', async () => {
    const id = neighbourhoodIds['Chicago'];
    const res = await request(app).get(`/dishly/v1/restaurants?neighbourhood_id=${id}`);

    const restaurant = res.body.data[0];
    expect(restaurant).toHaveProperty('id');
    expect(restaurant).toHaveProperty('name');
    expect(restaurant).toHaveProperty('price_range');
    expect(restaurant).toHaveProperty('cover_image_url');
    expect(restaurant).toHaveProperty('average_rating');
    expect(restaurant).toHaveProperty('cuisine');
    expect(restaurant.cuisine).toHaveProperty('id');
    expect(restaurant.cuisine).toHaveProperty('name');
    expect(restaurant).toHaveProperty('neighbourhood');
    expect(restaurant.neighbourhood).toHaveProperty('id');
    expect(restaurant.neighbourhood).toHaveProperty('name');
  });

  test('unknown neighbourhood_id returns empty array', async () => {
    const res = await request(app).get(`/dishly/v1/restaurants?neighbourhood_id=${uuidv4()}`);

    expect(res.status).toBe(200);
    expect(res.body.data).toEqual([]);
  });
});
