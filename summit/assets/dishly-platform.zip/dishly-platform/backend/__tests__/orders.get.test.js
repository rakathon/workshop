// Must be first — before any require that touches the DB
process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'dishly-dev-secret';

jest.setTimeout(15000);

const request = require('supertest');
const { v4: uuidv4 } = require('uuid');
const { runMigrations, seedReferenceData, createUser } = require('./helpers/testDb');

let app;
let db;
let seeds;
let owner;
let otherUser;

beforeAll(() => {
  jest.isolateModules(() => {
    db = require('../src/db/connection');
    app = require('../src/server');
  });

  runMigrations(db);
  seeds = seedReferenceData(db);
  owner = createUser(db, 'order-owner@example.com');
  otherUser = createUser(db, 'other-user@example.com');
});

/**
 * Helper: insert an order directly into the in-memory DB and return its id.
 */
function createOrderInDb(userId, restaurantId, menuItemId) {
  const orderId = uuidv4();
  const createdAt = new Date().toISOString();
  db.prepare(
    `INSERT INTO "order" (id, user_id, restaurant_id, delivery_address, subtotal_value, subtotal_scale, delivery_fee_value, delivery_fee_scale, total_value, total_scale, status, created_at)
     VALUES (?, ?, ?, ?, 1200, 2, 399, 2, 1599, 2, 'confirmed', ?)`
  ).run(orderId, userId, restaurantId, '456 Test Ave', createdAt);

  db.prepare(
    'INSERT INTO order_item (id, order_id, menu_item_id, item_name, quantity, unit_price_value, unit_price_scale) VALUES (?, ?, ?, ?, ?, ?, 2)'
  ).run(uuidv4(), orderId, menuItemId, 'Pasta', 1, 1200);

  return orderId;
}

beforeEach(() => {
  db.prepare('DELETE FROM order_item').run();
  db.prepare('DELETE FROM "order"').run();
});

test('GET /orders/:id returns order for its owner', async () => {
  const { restaurantId, menuItemIds } = seeds;
  const orderId = createOrderInDb(owner.id, restaurantId, menuItemIds[0]);

  const res = await request(app)
    .get(`/dishly/v1/orders/${orderId}`)
    .set('Authorization', `Bearer ${owner.token}`);

  expect(res.status).toBe(200);
  const { data } = res.body;
  expect(data.id).toBe(orderId);
  expect(data.restaurant_id).toBe(restaurantId);
  expect(data.delivery_address).toBe('456 Test Ave');
  expect(data.status).toBe('confirmed');
  expect(Array.isArray(data.items)).toBe(true);
  expect(data.items).toHaveLength(1);
  expect(data.subtotal).toMatchObject({ scale: 2 });
  expect(data.delivery_fee).toMatchObject({ value: 399, scale: 2 });
  expect(data.total).toMatchObject({ scale: 2 });
  expect(res.body.meta.status.code).toBe('OK');
});

test('GET /orders/:id returns 403 for different user', async () => {
  const { restaurantId, menuItemIds } = seeds;
  const orderId = createOrderInDb(owner.id, restaurantId, menuItemIds[0]);

  const res = await request(app)
    .get(`/dishly/v1/orders/${orderId}`)
    .set('Authorization', `Bearer ${otherUser.token}`);

  expect(res.status).toBe(403);
  expect(res.body.errors[0].code).toBe('FORBIDDEN');
});

test('GET /orders/:id returns 404 for unknown id', async () => {
  const res = await request(app)
    .get(`/dishly/v1/orders/${uuidv4()}`)
    .set('Authorization', `Bearer ${owner.token}`);

  expect(res.status).toBe(404);
  expect(res.body.errors[0].code).toBe('NOT_FOUND');
});
