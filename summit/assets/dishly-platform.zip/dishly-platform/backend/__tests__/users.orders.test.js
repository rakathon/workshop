// Must be first — before any require that touches the DB
process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'dishly-dev-secret';

jest.setTimeout(15000);

const request = require('supertest');
const { v4: uuidv4 } = require('uuid');
const { runMigrations, seedReferenceData, createUser } = require('./helpers/testDb');

let app;
let db;
let seeds;
let user;

beforeAll(() => {
  jest.isolateModules(() => {
    db = require('../src/db/connection');
    app = require('../src/server');
  });

  runMigrations(db);
  seeds = seedReferenceData(db);
  user = createUser(db, 'me-orders-user@example.com');
});

/**
 * Insert an order directly into db; createdAt allows controlling ORDER BY created_at DESC.
 */
function insertOrder(userId, restaurantId, menuItemId, createdAt) {
  const orderId = uuidv4();
  db.prepare(
    `INSERT INTO "order" (id, user_id, restaurant_id, delivery_address, subtotal_value, subtotal_scale, delivery_fee_value, delivery_fee_scale, total_value, total_scale, status, created_at)
     VALUES (?, ?, ?, ?, 1200, 2, 399, 2, 1599, 2, 'confirmed', ?)`
  ).run(orderId, userId, restaurantId, '789 Order Rd', createdAt);

  db.prepare(
    'INSERT INTO order_item (id, order_id, menu_item_id, item_name, quantity, unit_price_value, unit_price_scale) VALUES (?, ?, ?, ?, ?, ?, 2)'
  ).run(uuidv4(), orderId, menuItemId, 'Pasta', 1, 1200);

  return orderId;
}

beforeEach(() => {
  db.prepare('DELETE FROM order_item').run();
  db.prepare('DELETE FROM "order"').run();
});

test('GET /users/me/orders returns orders for authenticated user', async () => {
  const { restaurantId, menuItemIds } = seeds;

  // Insert two orders with different timestamps; newest should come first
  const oldId = insertOrder(user.id, restaurantId, menuItemIds[0], '2024-01-01T10:00:00.000Z');
  const newId = insertOrder(user.id, restaurantId, menuItemIds[1], '2024-06-01T10:00:00.000Z');

  const res = await request(app)
    .get('/dishly/v1/users/me/orders')
    .set('Authorization', `Bearer ${user.token}`);

  expect(res.status).toBe(200);
  const { data } = res.body;
  expect(Array.isArray(data)).toBe(true);
  expect(data).toHaveLength(2);

  // Newest first
  expect(data[0].id).toBe(newId);
  expect(data[1].id).toBe(oldId);

  // Check shape of each order
  data.forEach(order => {
    expect(order).toHaveProperty('id');
    expect(order).toHaveProperty('restaurant_id');
    expect(order).toHaveProperty('restaurant_name');
    expect(order).toHaveProperty('items');
    expect(order).toHaveProperty('delivery_address');
    expect(order.subtotal).toMatchObject({ scale: 2 });
    expect(order.delivery_fee).toMatchObject({ value: 399, scale: 2 });
    expect(order.total).toMatchObject({ scale: 2 });
    expect(order).toHaveProperty('status');
    expect(order).toHaveProperty('created_at');
  });

  expect(res.body).toHaveProperty('pagination');
  expect(res.body.meta.status.code).toBe('OK');
});

test('GET /users/me/orders returns 401 without token', async () => {
  const res = await request(app).get('/dishly/v1/users/me/orders');

  expect(res.status).toBe(401);
  expect(res.body.errors[0].code).toBe('UNAUTHORIZED');
});
