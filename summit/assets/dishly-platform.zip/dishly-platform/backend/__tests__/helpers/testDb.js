// Must be set before any module that touches the DB is loaded
process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'dishly-dev-secret';

const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');

const JWT_SECRET = 'dishly-dev-secret';

/**
 * Run schema migrations on the provided db instance.
 * We inline the migration SQL so we don't pull in the app's connection module.
 */
function runMigrations(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS user (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cuisine (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS neighbourhood (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS restaurant (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      cuisine_id TEXT NOT NULL REFERENCES cuisine(id),
      neighbourhood_id TEXT NOT NULL REFERENCES neighbourhood(id),
      description TEXT NOT NULL,
      address TEXT NOT NULL,
      price_range TEXT NOT NULL CHECK(price_range IN ('$', '$$', '$$$')),
      cover_image_url TEXT NOT NULL,
      average_rating REAL NOT NULL,
      delivery_radius_km REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS menu_section (
      id TEXT PRIMARY KEY,
      restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
      name TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS menu_item (
      id TEXT PRIMARY KEY,
      section_id TEXT NOT NULL REFERENCES menu_section(id),
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      price_value INTEGER NOT NULL,
      price_scale INTEGER NOT NULL DEFAULT 2,
      image_url TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS review (
      id TEXT PRIMARY KEY,
      restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
      author_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
      body TEXT NOT NULL,
      review_date TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS "order" (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES user(id),
      restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
      delivery_address TEXT,
      subtotal_value INTEGER NOT NULL,
      subtotal_scale INTEGER NOT NULL DEFAULT 2,
      delivery_fee_value INTEGER NOT NULL DEFAULT 399,
      delivery_fee_scale INTEGER NOT NULL DEFAULT 2,
      total_value INTEGER NOT NULL,
      total_scale INTEGER NOT NULL DEFAULT 2,
      status TEXT NOT NULL DEFAULT 'confirmed',
      created_at TEXT NOT NULL,
      deleted_at TEXT
    );

    CREATE TABLE IF NOT EXISTS order_item (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES "order"(id) ON DELETE CASCADE,
      menu_item_id TEXT NOT NULL REFERENCES menu_item(id),
      item_name TEXT NOT NULL,
      quantity INTEGER NOT NULL CHECK(quantity >= 1),
      unit_price_value INTEGER NOT NULL,
      unit_price_scale INTEGER NOT NULL DEFAULT 2
    );
  `);

  // Profile schema — applied via try/catch to mirror real migration behaviour
  try { db.exec('ALTER TABLE user ADD COLUMN name TEXT'); } catch (_) {}
  try { db.exec('ALTER TABLE user ADD COLUMN phone TEXT'); } catch (_) {}

  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS user_address (
        id         TEXT PRIMARY KEY,
        user_id    TEXT    NOT NULL REFERENCES user(id) ON DELETE CASCADE,
        label      TEXT,
        street     TEXT    NOT NULL,
        city       TEXT    NOT NULL,
        postcode   TEXT    NOT NULL,
        is_default INTEGER NOT NULL DEFAULT 0,
        created_at TEXT    NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_user_address_user_id ON user_address(user_id);
      CREATE TABLE IF NOT EXISTS user_payment_method (
        id              TEXT PRIMARY KEY,
        user_id         TEXT NOT NULL REFERENCES user(id) ON DELETE CASCADE,
        card_type       TEXT NOT NULL CHECK(card_type IN ('Visa', 'Mastercard', 'Amex')),
        cardholder_name TEXT NOT NULL,
        created_at      TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_user_payment_method_user_id ON user_payment_method(user_id);
    `);
  } catch (_) {}
}

/**
 * Seed reference data into a db instance.
 * Returns { restaurantId, restaurant2Id, menuItemIds: [id1, id2], menuItemR2Id }
 */
function seedReferenceData(db) {
  const cuisineId = uuidv4();
  const neighbourhoodId = uuidv4();
  const restaurantId = uuidv4();
  const restaurant2Id = uuidv4();
  const section1Id = uuidv4();
  const section2Id = uuidv4();
  const menuItemId1 = uuidv4();
  const menuItemId2 = uuidv4();
  const menuItemR2Id = uuidv4();

  db.prepare('INSERT INTO cuisine (id, name) VALUES (?, ?)').run(cuisineId, 'Italian');
  db.prepare('INSERT INTO neighbourhood (id, name) VALUES (?, ?)').run(neighbourhoodId, 'Downtown');

  db.prepare(
    'INSERT INTO restaurant (id, name, cuisine_id, neighbourhood_id, description, address, price_range, cover_image_url, average_rating, delivery_radius_km) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(restaurantId, 'Test Restaurant', cuisineId, neighbourhoodId, 'A test restaurant', '1 Test St', '$$', 'http://img.test/1.jpg', 4.5, 10.0);

  db.prepare(
    'INSERT INTO restaurant (id, name, cuisine_id, neighbourhood_id, description, address, price_range, cover_image_url, average_rating, delivery_radius_km) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(restaurant2Id, 'Other Restaurant', cuisineId, neighbourhoodId, 'Another test restaurant', '2 Test St', '$', 'http://img.test/2.jpg', 4.0, 5.0);

  // Menu sections
  db.prepare('INSERT INTO menu_section (id, restaurant_id, name, sort_order) VALUES (?, ?, ?, ?)').run(section1Id, restaurantId, 'Mains', 0);
  db.prepare('INSERT INTO menu_section (id, restaurant_id, name, sort_order) VALUES (?, ?, ?, ?)').run(section2Id, restaurant2Id, 'Starters', 0);

  // Menu items for restaurant 1
  db.prepare(
    'INSERT INTO menu_item (id, section_id, name, description, price_value, price_scale, image_url) VALUES (?, ?, ?, ?, ?, 2, ?)'
  ).run(menuItemId1, section1Id, 'Pasta', 'Tasty pasta', 1200, 'http://img.test/pasta.jpg');
  db.prepare(
    'INSERT INTO menu_item (id, section_id, name, description, price_value, price_scale, image_url) VALUES (?, ?, ?, ?, ?, 2, ?)'
  ).run(menuItemId2, section1Id, 'Pizza', 'Cheesy pizza', 1500, 'http://img.test/pizza.jpg');

  // Menu item for restaurant 2
  db.prepare(
    'INSERT INTO menu_item (id, section_id, name, description, price_value, price_scale, image_url) VALUES (?, ?, ?, ?, ?, 2, ?)'
  ).run(menuItemR2Id, section2Id, 'Bruschetta', 'Crispy bruschetta', 800, 'http://img.test/bruch.jpg');

  return { restaurantId, restaurant2Id, menuItemIds: [menuItemId1, menuItemId2], menuItemR2Id };
}

/**
 * Insert a user into the db and return their id + JWT token.
 */
function createUser(db, email, name = null) {
  const id = uuidv4();
  const password_hash = bcrypt.hashSync('Password1!', 1);
  const created_at = new Date().toISOString();
  db.prepare('INSERT INTO user (id, email, password_hash, name, created_at) VALUES (?, ?, ?, ?, ?)').run(
    id,
    email.toLowerCase(),
    password_hash,
    name,
    created_at
  );
  const token = jwt.sign({ sub: id }, JWT_SECRET, { expiresIn: '7d' });
  return { id, token };
}

module.exports = { runMigrations, seedReferenceData, createUser };
