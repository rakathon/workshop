# Implementation Plan: [Effort Title]

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Foundation

### TASK-001 [auto][wave:1]

[One-sentence description of what this task produces or changes.]

**Satisfies:** n/a
**Standards:** [plugin-root-relative paths, or none]
**Required tests:** none (scaffolding task)

---

## Wave 2 — Core Implementation

### TASK-002 [tdd][wave:2]

[One-sentence description.]

**Satisfies:** [BR-001](../requirements/business.md#br-001-heading-title-as-slug), [TR-002](../requirements/technical.md#tr-002-heading-title-as-slug)
**Standards:** [plugin-root-relative paths]
**Required tests:**
- Unit: `[TestName]` — [what it verifies]
- Integration: `[TestName]` — [what it verifies]

---

## Wave 3 — Integration

### TASK-003 [checkpoint][wave:3]

[One-sentence description] — confirm [specific thing] before proceeding.

**Satisfies:** [BR-003](../requirements/business.md#br-003-heading-title-as-slug)
**Standards:** [plugin-root-relative paths, or none]
**Required tests:** none (checkpoint — no code written until confirmed)
