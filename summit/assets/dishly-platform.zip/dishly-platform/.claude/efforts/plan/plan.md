# Coordination Plan: [Effort Title]

This plan is structured by deployable. Each section lists the acceptance criteria
that deployable is responsible for delivering, and any cross-deployable dependencies.

`forge:project` uses this plan to materialize local sub-efforts in each deployable
repository.

---

## [Deployable Name] ([repo-name])

### Acceptance Criteria

- [criterion 1] — [how completion will be assessed]
- [criterion 2] — [how completion will be assessed]

### Cross-Deployable Dependencies

- Depends on: [other-deployable] delivering [interface/contract] before [wave:N]

---

## [Deployable Name] ([repo-name])

### Acceptance Criteria

- [criterion 1] — [how completion will be assessed]
- [criterion 2] — [how completion will be assessed]
