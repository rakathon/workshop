# Initiative Plan: [Effort Title]

This plan breaks the initiative into child epics. Each epic maps to a deployable
repository and will be materialized there by `forge:project`. Epics are listed in
recommended delivery order based on dependencies.

---

## EPIC-001: [Epic Name]

**Deployable:** [deployable-name]
**Repo:** [repo-name] (optional — omit if the deployable lives in this repository)

### High-Level Output

[One paragraph describing the concrete deliverable when this epic is complete: what
exists, what works, what a user or system can do.]

### Relevant Requirements

- [BR-001](../requirements/business.md#br-001-heading-title-as-slug) — [brief quote of requirement text]
- [TR-003](../requirements/technical.md#tr-003-heading-title-as-slug) — [brief quote of requirement text]

### Success Criteria

- [ ] [Measurable condition — confirmable by automated check, demo, or defined process]
- [ ] [Measurable condition]
- [ ] [Measurable condition]

### Dependencies

- Depends on: EPIC-NNN ([reason — what specifically must exist first])

---

## EPIC-002: [Epic Name]

**Deployable:** [deployable-name]
**Repo:** [repo-name] (optional — omit if the deployable lives in this repository)

### High-Level Output

[One paragraph describing the concrete deliverable when this epic is complete.]

### Relevant Requirements

- [BR-002](../requirements/business.md#br-002-heading-title-as-slug) — [brief quote of requirement text]

### Success Criteria

- [ ] [Measurable condition]
- [ ] [Measurable condition]
