# Functional Requirements — {{effort_title}}

*Effort: {{effort_id}}*
*Elaborated from: [business.md](business.md)*
*Created: {{date}}*

<!-- Functional Requirement framing guide:
  An FR states a specific system behavior required to satisfy one or more BRs.
  It answers "what must the system do?" — not why (that is the BR) and not how
  (that is the spec and ADRs).

  ✅ Correct: "The system must deduct points from the member's balance atomically
              with the purchase confirmation — no partial state may be observable."
  ❌ Wrong:   "Members need to be able to use points at checkout."  (that is a BR)
  ❌ Wrong:   "Use a database transaction scoped to the checkout saga."  (that is a spec decision / ADR)

  Every FR must trace to at least one BR. TRs express measurable quality attributes
  on top of FRs (latency, availability, etc.) — they are not FRs.
-->

---

## FR-1: {{title}}

*Traces to: [BR-{{n}}](business.md#br-{{n}}-{{title-slug}})*
<!-- If this FR is satisfied by existing code, add: *Implemented by: path/to/File.java* -->

{{behavior}}
