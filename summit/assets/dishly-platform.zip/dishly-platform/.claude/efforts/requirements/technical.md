# Technical Requirements — {{effort_title}}

*Effort: {{effort_id}}*
*Elaborated from: [requirements/business.md](business.md)*
*Created: {{date}}*

---

## TR-1: {{title}}

*Traces to: [BR-{{n}}](business.md#br-{{n}}-{{title-slug}})*

{{constraint}}
