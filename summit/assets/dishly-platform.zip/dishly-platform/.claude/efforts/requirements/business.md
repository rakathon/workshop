# Business Requirements — {{effort_title}}

*Effort: {{effort_id}}*
*Created: {{date}}*

---

## BR-1: {{title}}

{{description}}

**Acceptance criteria:**
- {{criterion}}
