---
name: forge:spec-tests
description: Design a test suite for the active effort. The engineer declares what kind of test suite they need (e2e, contract, integration, or full); `integration` has three subtypes — database, messaging, and external-api-integration — inferred automatically from user input and requirement artifacts. The skill checks whether available spec artifacts are sufficient, surfaces gaps with actionable next steps when they are not, and produces BDD test suites only for achievable types. Defaults to 'full' when no type is specified. Use when asked to "design tests", "write a test strategy", "what should we test?", "plan integration tests", "design E2E tests", "design contract tests", "design external API integration tests", "write WireMock test scenarios", "plan integration tests for outbound calls", "design database integration tests", "design Kafka integration tests", or "design API integration tests". Also invoke when spec or discovery artifacts have just been produced and the engineer has not yet designed tests. Output target is determined by --capability if provided (any type), otherwise inferred from --type and effort type.
agent-type: inline
argument-hint: "[effort-id] [--type e2e|contract|integration|full] [--capability <deployable>/<capability>]"
arguments:
  - effort_id
---

# forge:spec-tests

Authors a test suite for the active effort. The engineer declares what kind of test
suite they need; the skill validates whether the available spec artifacts can support it,
surfaces any gaps with actionable next steps, and generates BDD scenarios only for the
types that are achievable. This skill is re-invokable — calling it on an existing test
suite extends it rather than replacing it.

---

## Preconditions

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

Set `<effort_dir> = .forge/efforts/<effort_id>/` once resolved.

If no efforts exist in this repository at all, fall back to default Claude behavior
without invoking this skill.

No phase gate is enforced — this skill is intentionally re-invokable from any effort
phase (discovery, planning, or implementation). It appends new scenarios to existing
suite files without replacing prior work.

---

## Step 1: Determine Test Suite Type

Check whether `--type <type>` was provided. Valid values: `e2e`, `contract`,
`integration`, `full`.

- If absent → use `full` as the default.
- If `external-api-integration` or `external-api-integration-tests` is provided → stop:
  "`external-api-integration` is a subtype of `integration`, not a standalone type. Use
  `--type integration` instead — the skill will automatically include external API
  integration scenarios when outbound HTTP clients are found."
- If any other unrecognized value is provided → stop and list valid types.

Print:
```
Test suite type: <type>
```

---

## Step 1A: Infer Integration Subtypes (only when `--type` is `integration` or `full`)

Skip this step for `e2e` and `contract`.

Read `guides/integration-subtype-inference.md` (relative to this skill file) and follow
the inference rules defined there to determine `<integration_subtypes>`.

Store the active subtypes as `<integration_subtypes>` — used in Steps 3, 5, 8, and 9.

---

## Step 2: Determine Output Target

**If `--capability <deployable>/<capability>` was provided:**
Set `<output_dir> = .forge/deployables/<deployable>/capabilities/<capability>/test/`.
This applies to any test suite type. Continue to Step 3.

**If `--capability` was not provided:**

**First, detect the repository type:**

Check whether `.forge/products/` contains any product directories:
```bash
find .forge/products -mindepth 1 -maxdepth 1 -type d 2>/dev/null
```
- **Coordination repo** — one or more product directories found
- **Deployable repo** — no product directories

---

**E2E output routing:**

For `--type e2e` (or the e2e component of `full`):

- **`--capability` provided:** Set `<output_dir>` to `.forge/deployables/<deployable>/capabilities/<capability>/test/`.
  Scenarios describe the deployed capability's behavior with no mocking.
  Print `Output dir: <output_dir>` and continue to Step 3.

- **`--capability` not provided — coordination repo:** E2E plans belong to a product, not an effort.
  Check whether `--product <product-name>` was provided. If absent, prompt:
  ```
  E2E tests belong to a product directory.
  Which product does this E2E test suite cover?
  Check .forge/products/ for registered products.
  Example: rewards-platform
  ```
  Set `<output_dir>` to `.forge/products/<product-name>/test/`.

- **`--capability` not provided — deployable repo:** Set `<output_dir>` to `<effort_dir>/spec/test/`. No prompt needed.

Print `Output dir: <output_dir>` and continue to Step 3.

---

**Capability output routing (for contract, integration, and the capability components of full):**

Read the `type` field at the root of `<effort_dir>/.state.json`:

**Initiative or project efforts** — prompt:
```
<type> tests belong to a specific capability.
Which capability does this test suite cover?
Check .forge/deployables/ for registered deployables and their capabilities.
Example: rewards-api/favorites
```
Set `<output_dir>` to `.forge/deployables/<deployable>/capabilities/<capability>/test/`.

**Story or task efforts** — same prompt as above.

**Epic efforts** — prompt:
```
Does this epic scope to a single capability, or does it span several?
  [1] Single capability — provide --capability <deployable>/<capability>
  [2] Cross-cutting    — writes to <effort_dir>/spec/test/

Choose 1 or 2:
```
If 1, prompt for `--capability` and set the capability test directory. If 2,
set `<output_dir>` to `<effort_dir>/spec/test/`.

**Unknown or absent effort type:** treat as epic (conservative — prompt rather than assume).

**`--type full` routing note:** Apply routing rules separately for each component type.
E2E follows the e2e routing above; contract and integration follow the capability routing
above. The output directories for different types in a `full` run may therefore differ —
e2e may write to `<effort_dir>/spec/test/` while contract/integration write to a
capability `test/` directory. This is expected and correct.

**Requirement link path:** Once `<output_dir>` is finalised for a given test type,
compute `<req_rel_path>` — the relative path from `<output_dir>` to
`<effort_dir>/requirements/`. Use this variable wherever a link to
`business.md` or `technical.md` is written so the link resolves correctly
regardless of where the test file lives.

| `<output_dir>` | `<req_rel_path>` |
|---|---|
| `<effort_dir>/spec/test/` | `../../requirements/` |
| `.forge/deployables/<dep>/capabilities/<cap>/test/` | `../../../../../efforts/<effort_id>/requirements/` |
| `.forge/products/<product>/test/` | `../../../efforts/<effort_id>/requirements/` |

For any other path, compute the relative traversal by counting directory levels from
`<output_dir>` up to the repo root, then appending `<effort_dir>/requirements/`.

---

## Step 3: Read Effort Artifacts

Check for `<effort_dir>/requirements/business.md`. If absent, stop:
```
requirements/business.md not found.
Run discovery first to produce business requirements before designing tests.
```

Read all available artifacts:
- `<effort_dir>/requirements/business.md` — extract each requirement entry and its
  acceptance criteria. Derive the identifier prefix and pattern (e.g. `BR-N`, `REQ-N`)
  by reading the actual headings rather than assuming a fixed prefix. Record as
  `<br_prefix>`.
- `<effort_dir>/requirements/functional.md` — if present, extract each FR entry and
  its `Traces to: BR-N` line. Derive its identifier prefix from the actual headings
  (`<fr_prefix>`). FRs are valid `Verifies:` targets — scenarios that test a specific
  system behavior may trace directly to an FR rather than a BR.
- `<effort_dir>/requirements/technical.md` — if present, extract each requirement
  entry. Derive its identifier prefix from the actual headings (`<tr_prefix>`).
  Note any entries that name external services or describe error-handling for outbound
  HTTP calls (feeds Step 1A `external-api-integration` subtype inference).
- `<effort_dir>/spec/api/*.yaml` — if present, extract endpoint definitions
  (method, path, request/response schemas, status codes)
- `<effort_dir>/spec/storage/*.md` — if present, extract entity definitions and
  field constraints
- `<effort_dir>/spec/messaging/*.md` — if present, extract event schemas and
  contracts
- `<effort_dir>/spec/ux/ux-strategy.md` — if present, extract screens, states,
  interactions, and user flows from the Screen Inventory section

Record presence flags: `has_api_spec`, `has_storage_spec`, `has_messaging_spec`,
`has_ui_spec` (true when `spec/ux/ux-strategy.md` is present).

**For `integration` type (or the integration component of `full`), when `external-api-integration`
is in `<integration_subtypes>`:**

Load `guides/external-api-integration-tests-design-guide.md` (relative to this skill file) now,
then run guide Steps A and B before Step 5 so per-service status can appear in the
feasibility summary:

- **Guide Step A (discovery):** Scan source code for outbound HTTP clients using the
  language-specific patterns in the guide. Record as `has_outbound_http` if any client
  found. Build `<external_services>` list.
- **Guide Step B (spec collection):** For each discovered service, ask the engineer for
  an OpenAPI spec (file path, URL, or inline). Assign HAS_SPEC or SKIPPED per service.
  Record spec-provided services as `<scoped_services>`.

These two steps must complete before Step 5 so the feasibility summary can show
per-service status (✓ / ⚠ / ✗). Scenario generation (guide Steps C–E) runs later in
Step 8.

---

## Step 4: Load the Testing Standards

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

Record: `plugin_root`.

If the manifest cannot be read, stop with:
> "The Forge plugin does not appear to be installed or the manifest is missing.
> Try reinstalling the plugin."


Read the following files as the authoritative source for test type classification
and scenario rules:

- `<plugin_root>/standards/testing/strategy.md` — type selection from spec inventory
- `<plugin_root>/standards/testing/contract.md` — contract scenario rules (if `--type` includes contract)
- `<plugin_root>/standards/testing/integration.md` — integration scenario rules (if `--type` includes integration)
- `<plugin_root>/standards/testing/e2e.md` — E2E scenario rules (if `--type` includes e2e)

If `--type` includes `integration` (or `full`) and `<integration_subtypes>` is non-empty, also load:
- `guides/integration-scenario-generation.md` (relative to this skill file) —
  per-subtype scenario generation rules for database, messaging, and external-api-integration.

Note: `guides/external-api-integration-tests-design-guide.md` was already loaded in Step 3
if `external-api-integration` is in `<integration_subtypes>` — do not reload it here.

If a file is absent, warn and continue with the built-in classification rules in Step 8:
```
Warning: <file> not found. Using built-in rules.
```

---

## Step 5: Feasibility Check

For each component of the requested test suite type, check whether required spec
is present.

**Feasibility rules:**

| Type component | Achievable when |
|----------------|----------------|
| E2E (system) | `requirements/business.md` exists — always true at this point |
| E2E (UI) | `has_ui_spec = true` |
| Contract (API) | `has_api_spec = true` |
| Contract (messaging) | `has_messaging_spec = true` |
| Integration (database subtype) | `has_storage_spec = true` OR TRs explicitly describe persistence behavior |
| Integration (messaging subtype) | `has_messaging_spec = true` OR TRs explicitly describe event production/consumption |
| Integration (external-api-integration subtype) | `has_outbound_http = true` OR TRs name an external service — discovery (guide Step A) determines actual achievability; never hard-blocked before discovery |

The `external-api-integration` subtype is never hard-blocked before discovery. If discovery
(guide Step A–B) finds no services or all are skipped, the subtype is removed from the
achievable set at that point and the summary reports it as skipped rather than blocked.
Other active subtypes proceed unaffected.

Build:
- **achievable** — components for which required spec is present
- **blocked** — components for which required spec is absent, with what is missing

**Suggested skills for missing artifacts:**

| Missing artifact  | Suggested skill                    |
|-------------------|------------------------------------|
| `spec/api/`       | `forge:spec-api <effort-id>`       |
| `spec/storage/`   | `forge:spec-storage <effort-id>`   |
| `spec/messaging/` | `forge:spec-messaging <effort-id>` |
| `spec/ux/`        | `forge:ux-design`                  |

**If all requested types are blocked**, stop:
```
Cannot produce <type> test suite — required spec is missing:
  ✗ <component>: <what is absent>
    → <suggested skill>

Run the suggested skill(s) first, then re-invoke forge:spec-tests.

Next steps:
  <suggested skill(s)>
  forge:spec-tests <effort-id> --type <type>   — re-invoke after spec is ready
```

**If some types are blocked**, print a gap report and prompt:
```
Test suite feasibility:
  ✓ E2E (system) scenarios — <N> business requirements found
  ✓ E2E (UI) scenarios     — spec/ux/ux-strategy.md found
  ✓ Contract scenarios     — spec/api/<file>.yaml found
  ✗ Integration scenarios  — no storage spec found
    → forge:spec-storage <effort-id>

Achievable: e2e (system), e2e (ui), contract
Blocked:    integration

Continue with achievable types, or stop to fill the gap first? [continue/stop]
```
Wait for the engineer's response. If `stop`, exit cleanly. If `continue`, proceed
with achievable types only.

**If all requested types are achievable**, print the summary and continue without
prompting:
```
Test suite feasibility:
  ✓ E2E (system) scenarios — <N> business requirements found
  ✓ E2E (UI) scenarios     — spec/ux/ux-strategy.md found
  ✓ Contract scenarios     — spec/api/<file>.yaml found
  ✓ Integration scenarios  — spec/storage/<file>.md found

All requested types achievable. Proceeding.
```

---

## Step 6: Ensure Output Directory Exists

**If `<output_dir>` is inside a capability directory** and the capability directory
does not exist, create the standard structure:
- `requirements/`
- `spec/`
- `spec/arch-decisions/`
- `runbook/`
- `security/`
- `test/`

Print:
```
Created capability directory:
.forge/deployables/<deployable>/capabilities/<capability>/
```

**In all cases**, create `<output_dir>` if it does not already exist — whether it is
a capability `test/` directory, a product `test/` directory, or
`<effort_dir>/spec/test/`.

---

## Step 7: Check for Existing Test Suite Files

For each output file that will be written (see Step 9 for filenames), check whether
the file already exists in `<output_dir>`.

**If a file exists (re-invocation):**
- Read it and extract existing scenario identifiers (SC-N)
- Print: `Extending <filename> — <N> scenarios already present.`
- Identify which requirement identifiers are already covered in that file (using
  `<br_prefix>` and `<tr_prefix>` derived in Step 3)
- In Step 8, generate only scenarios for behaviors not yet covered in that file

**If absent:** first authoring — cover all identified behaviors for that type.

---

## Step 8: Propose Scenarios

For each achievable type, generate scenarios from the available artifacts. Draft
the complete set before presenting — do not propose one scenario at a time.

### E2E scenarios

#### E2E (system)

Source: BRs (required), TRs if they describe observable outcomes.

Each scenario describes a user-visible or system-visible outcome against the deployed
service with no mocking. The scenario must be understandable without reading the
service code.

- **Without `--capability`** (cross-service): scenarios span multiple services and
  describe end-to-end user journeys observable from the outside.
- **With `--capability`** (single capability): scenarios target the deployed capability
  directly — real network calls, real storage, no test doubles.

#### E2E (UI)

Source: `spec/ux/ux-strategy.md` — screens and states from the Screen Inventory section.

Only generated when `has_ui_spec = true`. Each scenario exercises a UI surface from
a user action through to a final visible state. Scenarios must be implementable with
Playwright and must not assume internal API or service knowledge.

Generate one scenario per:
- Each screen or major view listed in the UI spec
- Each non-default UI state (loading, error, empty, feature-specific states like
  "saved" or "offer expired")
- Each user interaction declared in the spec (search, filter, sort, pagination,
  form submission)

Do not duplicate system-level assertions already covered by E2E (system) scenarios.
UI scenarios assert what the user sees and can interact with — not API response codes
or database state.

UI E2E scenarios are written to `ui-e2e-test-suite.md` in the same markdown
format as all other suite types. `forge:build-playwright-tests` reads that file
and converts it to Gherkin `.feature` files as its first step.

### Contract scenarios

Source: API spec endpoints and messaging spec schemas.

**API contract scenarios:**
- One scenario per documented response code in the spec — covering request shape,
  response shape, and status code for each entry

**Messaging contract scenarios:**
- One scenario per event schema verifying the producer emits the specified fields
  and types

### Integration scenarios

Generate scenarios only for the subtypes in `<integration_subtypes>`. Follow
`guides/integration-scenario-generation.md` (already loaded in Step 4) for per-subtype
rules, scenario examples, auth/middleware TR classification guidance, and scenario format.

Use `<external_services>` and `<scoped_services>` from Step 3 when generating
`external-api-integration` subtype scenarios (guide Steps C–E from
`external-api-integration-tests-design-guide.md`).

### Scenario format

For `e2e` and `contract` scenarios:

```
### SC-N: <Short scenario title>

**Type:** e2e | contract
**Given** <precondition / starting state>
**And** <additional precondition> (if needed)
**When** <action / trigger>
**Then** <primary expected outcome>
**And** <additional outcome> (if needed)
**Verifies:** [<br_prefix>-N](<req_rel_path>business.md#<br_prefix>-n-<heading-slug>) — "<acceptance criterion text>"
**Verifies:** [<fr_prefix>-N](<req_rel_path>functional.md#<fr_prefix>-n-<heading-slug>) — "<behavior text>"
```

The `Verifies:` link uses the identifier prefix observed in Step 3 (`<br_prefix>`,
`<fr_prefix>`, or `<tr_prefix>`). The fragment anchor is derived from the actual
heading text in the requirements file: lowercase the full heading, remove all
characters except letters, digits, and hyphens, replace spaces with hyphens. Do not
guess — always read the heading.

- BRs link to `business.md`
- FRs link to `functional.md`
- TRs link to `technical.md`

Prefer linking to an FR when the scenario tests a specific system behavior; link to a
BR when the scenario validates a user-visible outcome without a more specific FR. A
scenario may trace to multiple requirements — list each as a separate link:
`[<br_prefix>-N](<req_rel_path>business.md#<br_prefix>-n-<heading-slug>), [<fr_prefix>-M](<req_rel_path>functional.md#<fr_prefix>-m-<heading-slug>)`.

For `integration` scenarios, use the format defined in
`guides/integration-scenario-generation.md`.

Use a single `Then` when only one outcome exists. Add `And` lines when the scenario
produces side effects beyond the direct response — a DB write, a published event, an
audit log entry, a downstream service call. Each observable assertion gets its own
`Then`/`And` line so nothing is buried in prose.

If the engineer proposes a unit test scenario, respond:
> Unit tests are out of scope for this test suite. They are
> implementation decisions for the writing engineer. This suite covers
> observable behaviors only.

---

## Step 9: Write Test Suite Files

Write one file per achievable type to `<output_dir>`. Filenames and titles per type:

| Type | Filename | Title |
|------|----------|-------|
| `e2e` (system) | `e2e-test-suite.md` | `# E2E Test Suite — <Capability or Effort Name>` |
| `e2e` (UI) | `ui-e2e-test-suite.md` | `# UI E2E Test Suite — <Capability or Effort Name>` |
| `contract` | `<spec-name>-contract-test-suite.md` | `# Contract Test Suite — <spec-name>` |
| `integration` (database + messaging subtypes) | `integration-test-suite.md` | `# Integration Test Suite — <Capability Name>` |
| `integration` / external-api-integration subtype | `<service>-ext-api-test-suite.md` per service | `# External API Integration Test Suite — <service>` |

For `contract`, derive `<spec-name>` from the spec filename without extension:
`spec/api/favorites.yaml` → `favorites-contract-test-suite.md`
`spec/messaging/order-events.md` → `order-events-contract-test-suite.md`

For the `external-api-integration` subtype, derive `<service>` from the discovered external service name:
`points-service` → `points-service-ext-api-test-suite.md`

For `full`, write all achievable type files (e2e-system + ui-e2e (if `has_ui_spec`) + per-contract + integration + per-service external-api-integration subtype).

**New file format:**

```markdown
# <Title>

*Capability/Effort:* `<output_dir>`
*Authored:* <YYYY-MM-DD>
*Effort:* <effort-id>

## Why Test This

<One paragraph synthesized from the top-priority BRs and highest-risk acceptance
criteria. What does this capability or initiative deliver? What breaks if it breaks?
What are the highest-risk behaviors? Written for an engineer unfamiliar with the
effort's history.>

## Test Coverage Map

| Scenario | Verifies |
|----------|----------|
| SC-N: <title> | [<br_prefix>-N](<req_rel_path>business.md#<br_prefix>-n-<heading-slug>): <criterion summary> |

## Scenarios

<SC-N entries in numbered order>

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to
extend this suite with load scenarios.*
```

**Extending existing file (re-invocation):**

Preserve the existing file exactly — do not rewrite the header, `## Why Test This`,
or existing scenarios. Make only two targeted edits:

1. Update the `## Test Coverage Map` table — append a row for each new scenario.
2. Append new scenarios after the last existing SC-N entry (before the Load Test section):

```markdown
---

*Extended:* <YYYY-MM-DD> — scenarios added from effort <effort-id>

<new SC-N entries, numbered sequentially from the last existing SC-N>
```

Do not modify or renumber existing scenarios.

---

## Step 10: Commit

Stage all files written to `<output_dir>` in this invocation using `forge:commit`.
Use a conventional commit message matching the target:

**Capability target:**
```
forge:commit  →  docs(<capability>): author <type> test suite (<effort-id>)
Stage: .forge/deployables/<deployable>/capabilities/<capability>/test/
```

**Product target (E2E in coordination repo):**
```
forge:commit  →  docs(<product-name>): author e2e test suite (<effort-id>)
Stage: .forge/products/<product-name>/test/
```

**Effort spec target:**
```
forge:commit  →  docs(<effort-id>): author <type> test suite
Stage: <effort_dir>/spec/test/
```

Do not stage other effort artifacts. Do not update `.state.json`.

---

## Step 11: Print Summary

```
forge:spec-tests complete
Suite type:        <type>
Files written:
  <output_dir>/e2e-test-suite.md                          (<N> scenarios)
  <output_dir>/ui-e2e-test-suite.md                       (<N> scenarios)
  <output_dir>/favorites-contract-test-suite.md           (<N> scenarios)
  <output_dir>/integration-test-suite.md                  (<N> scenarios)
  <output_dir>/points-service-ext-api-test-suite.md       (<N> scenarios)
Coverage:          <requirement identifiers covered — BR-N, FR-N, and/or TR-N using the prefix observed in Step 3>

Coverage gaps (run these to unlock remaining test types):
  integration: forge:spec-storage <effort-id>

External API advisory (no requirement traceability — review before building):
  <service-name>

External API skipped (no spec provided):
  <service-name>

Next steps:
  forge:build-tests <effort-id> --type external-api-integration-tests
      — generates WireMock mappings and test classes from external-api-integration subtype scenarios
  forge:validate-tests <effort-id>   — validate test suite coverage
  forge:promote <effort-id>          — advance to next phase when ready
```

List only files actually written. Omit the Coverage gaps, Advisory, and Skipped sections if there are none.

---

## Error Handling

| Condition | Action |
|-----------|--------|
| `--type external-api-integration` or `--type external-api-integration-tests` provided | Stop; explain it is a subtype of `integration`; direct to `--type integration` |
| `--type` value unrecognized | Stop; list valid types: e2e, contract, integration, full |
| `requirements/business.md` absent | Stop; direct to run discovery to produce business requirements |
| All requested types blocked by missing spec | Stop; list gaps and suggested skills |
| Some types blocked | Print gap report; prompt continue/stop |
| `integration` / external-api-integration subtype: no outbound HTTP found | Skip subtype silently; standard integration test suite still produced |
| `integration` / external-api-integration subtype: all services skipped by engineer | Drop subtype from achievable set; continue with remaining integration scenarios |
| `integration` / external-api-integration subtype: OpenAPI spec invalid | Warn per service; skip that service; continue with remaining |
| `--capability` absent when type requires it | Prompt for `--capability` before continuing |
| Capability directory absent | Create with standard structure; inform engineer; continue |
| `standards/testing/strategy.md` absent | Warn; continue with built-in rules |
| `guides/external-api-integration-tests-design-guide.md` absent | Warn; apply built-in scenario generation rules; continue |
| Engineer proposes a unit test scenario | Explain out of scope; decline to include |
| Engineer asks to update `.state.json` | Decline; test suite is tracked in capability or effort spec, not work item state |
