# External API Integration Tests — Design Guide

Reference for `forge:spec-tests` when the `external-api-integration` subtype is active.
Covers discovering outbound HTTP dependencies, collecting specs, generating BDD scenarios,
and writing `<service>-ext-api-test-suite.md` output files.

The scenarios produced here describe observable behavior — what the calling service does
when the external service returns a given response. How stubs are configured is the
concern of `forge:build-tests`.

**Sequencing within `forge:spec-tests`:**
Steps A and B of this guide are invoked from the host skill's Step 3 — before the
feasibility summary is printed in Step 5 — so the summary can show per-service status
(✓ / ⚠ / ✗). Steps C through F run during the host skill's Step 8 (Propose Scenarios).

---

## What this type tests

| Scenario class | What it tests |
|----------------|---------------|
| Successful call | Service sends well-formed request; external API returns 200; service processes response correctly |
| Invalid / expired token | Service passes invalid bearer token; external API returns 401; service propagates the correct error |
| Forbidden access | Token has insufficient scope; external API returns 403; service returns correct error |
| Server error | External API returns 500; service handles degraded path without crashing |
| Request shape | Required headers, body fields, path params, and query params match the external API spec |

**Do not use this type for:**
- Internal business logic — use `unit-test` tasks
- Database / cache / queue interactions — use `--type integration`
- Full user journeys — use `--type e2e`

---

## Feasibility rule

`external-api-integration` is achievable when:
- At least one outbound HTTP client is found in source code, **OR**
- At least one TR names an external service or describes error-handling for outbound calls

No feasibility check blocks this type before discovery (Step A) — discovery itself
determines whether there is anything to test.

---

## Step A: Discover External API Dependencies

Scan both requirements artifacts and source code.

**From requirements:**
- TRs that name external services, auth requirements, or error-handling contracts for
  outbound HTTP calls
- BRs that imply cross-service HTTP integration (e.g., "must fetch member balance from
  the points service")

**From source code — use patterns for the detected language:**

```
Java/Kotlin:  grep -r "RestTemplate\|WebClient\|HttpClient\|FeignClient\|@FeignClient\|HttpURLConnection" --include="*.java" --include="*.kt" -l
Go:           grep -r "http\.Get\|http\.Post\|http\.NewRequest\|resty\|go-resty" --include="*.go" -l
TypeScript:   grep -r "fetch\|axios\|got\|node-fetch\|HttpClient" --include="*.ts" -l
```

For each HTTP call site found, record:
- **External service name** (e.g., `points-service`, `loyalty-gateway`)
- **HTTP method and URL pattern** (e.g., `GET /v1/members/{memberId}/balance`)
- **Routing / auth headers** used (e.g., `Authorization`, `X-Service-Token`)
- **Response fields consumed** — from the call site or any response-mapping class

Build list: `<external_services>`.

**If no external HTTP dependencies are found in requirements or source:**
```
No outbound HTTP calls found in requirements or source code.

External API integration tests apply when this service calls another service over HTTP.
If the outbound calls are not yet implemented, describe them here:
  Service name and URL pattern (or type "none" to skip this type):
```

Wait for input. If "none", skip `external-api-integration` from the achievable set and
continue with other requested types. Do not stop the whole skill invocation.

---

## Step B: Check for OpenAPI Specs

For each service in `<external_services>`:

1. Check `<effort_dir>/spec/api/` for YAML files that describe the **external** service
   (not the service's own API — look for filenames matching the service name).
2. Check `rr-mock-server/mappings/` for existing WireMock mappings that imply a prior
   spec was used.
3. Ask the engineer:
   ```
   External services discovered:
     [1] <service-name> — <METHOD> <url-pattern>
     [2] <service-name> — <METHOD> <url-pattern>

   For each service, provide an OpenAPI spec (file path, URL, or paste inline),
   or type "skip" to exclude it from this suite:
     Service [1] <service-name> spec:
     Service [2] <service-name> spec:
   ```

Assign status per service:
- **HAS_SPEC** — spec provided or located automatically
- **SKIPPED** — engineer typed "skip"

If all services are SKIPPED:
```
All external services skipped — removing external-api-integration from the achievable set.
Continuing with remaining integration subtypes (database, messaging) if present.
To include external-api-integration later, re-run forge:spec-tests --type integration
and provide at least one OpenAPI spec when prompted.
```
Remove `external-api-integration` from the achievable set and continue with other
requested types. Do not stop the invocation.

Record spec-provided services as `<scoped_services>`.

---

## Step C: Feasibility Tier Assignment

For each service in `<scoped_services>`, verify:
1. At least one HTTP endpoint with a documented response schema in the spec
2. At least one BR or TR references this service's integration

Assign per service:
- **achievable** — spec coverage + requirement traceability
- **advisory** — spec found but no BR/TR references this service (scenarios generated
  but flagged as not directly traced to requirements)

Print in the main feasibility summary:
```
  ✓ <service-name> — <N> endpoints found, <M> BRs/TRs reference this service
  ⚠ <service-name> — spec found but no BRs/TRs reference this service (advisory)
  ✗ <service-name> — no spec provided (skipped)
```

Continue with achievable + advisory. Do not stop for advisory-only services.

---

## Step D: Check for Existing Suite Files

For each service in `<scoped_services>`, the output filename is:
```
<output_dir>/<service-name>-ext-api-test-suite.md
```

- **File exists (re-invocation):** read it, extract existing SC-N identifiers and
  covered BR-*/TR-* entries. Generate only scenarios for behaviors not yet covered.
  Print: `Extending <filename> — <N> scenarios already present.`
- **File absent:** first authoring — cover all identified behaviors.

---

## Step E: Generate Scenarios

For each service in `<scoped_services>`, generate from:
1. The OpenAPI spec — one scenario per documented response code per relevant endpoint
2. TRs describing error-handling for this service's outbound calls
3. BRs describing observable outcomes that require this integration

Only generate scenarios for status codes the external API spec actually documents.

### Request-shape scenarios

Where the spec defines required headers, mandatory body fields, path parameters,
or query parameters, add:
- A scenario that verifies the service sends a well-formed request
- A scenario that verifies the service handles a malformed/missing response field
  gracefully

### Scenario format

```
### SC-N: <Short scenario title>

**Type:** integration
**Subtype:** external-api-integration
**External service:** <service-name>
**Endpoint:** <METHOD> <path>
**Given** <precondition — state of the calling service and any test data>
**When** <the calling service's own endpoint is invoked — real HTTP call>
**And** the external service responds with status <N> and body <description>
**Then** <expected response from the calling service>
**And** <secondary assertion — e.g., error message propagated, header forwarded> (if applicable)
**Verifies:** <BR-N or TR-N> — "<acceptance criterion text>" (omit if advisory)
```

Draft all scenarios for all services before presenting. Do not propose one at a time.

---

## Step F: Write Suite Files

One file per service. Write during Step 9 of the main skill.

**New file format:**

```markdown
# External API Integration Test Suite — <service-name>

*Capability:* `<output_dir>`
*Authored:* <YYYY-MM-DD>
*Effort:* <effort-id>
*External service:* `<service-name>`
*Spec source:* `<spec file path or URL>`

## Why Test This

<One paragraph synthesized from TRs and BRs referencing this service. What does
this integration deliver? What breaks if the external service returns an unexpected
response? What are the highest-risk behaviors? Written for an engineer unfamiliar
with the effort.>

## Test Coverage Map

| Scenario | Endpoint | External service response | Verifies |
|----------|----------|--------------------------|----------|
| SC-N: <title> | <METHOD> <path> | <status> | <BR-N or TR-N> |

## Scenarios

<SC-N entries in numbered order>

---

## Load Test Scenarios (v2)

*Load test design is deferred. When ready, run `forge:spec-tests --load-tests` to
extend this suite with load scenarios.*
```

**Extending (re-invocation):**

Preserve the existing file exactly — do not rewrite the header, `## Why Test This`,
or existing scenarios. Make only two targeted edits:

1. Update the `## Test Coverage Map` table — append a row for each new scenario.
2. Append new scenarios after the last existing SC-N entry (before the Load Test section):

```markdown
---

*Extended:* <YYYY-MM-DD> — scenarios added from effort <effort-id>

<new SC-N entries, numbered sequentially from the last existing SC-N>
```

Do not modify or renumber existing scenarios.

---

## Error Handling

| Condition | Action |
|-----------|--------|
| No outbound HTTP calls found; engineer types "none" | Remove type from achievable set; continue with other types |
| All external services skipped (no spec provided) | Remove type from achievable set; continue with other types |
| OpenAPI spec invalid or unparseable | Warn per service; skip that service; continue with remaining |
| Source code scan finds no HTTP clients | Ask engineer to confirm or describe outbound calls manually |
