# Integration Scenario Generation — Design Guide

Reference for `forge:spec-tests` Step 8. Applies only when generating integration
scenarios. Load this guide when `<integration_subtypes>` is non-empty. Generate
scenarios only for the subtypes present in `<integration_subtypes>`.

---

## Database subtype

Source: `spec/storage/*.md` entities and TRs that describe persistence behavior.

Scenarios describe in-process interactions with real database components (not mocked):

- "The service persists a new record with the correct fields when creation succeeds"
- "A query for a non-existent record returns the expected empty/null result without error"
- "A duplicate key violation from the DB layer is translated to the expected service error"
- "Auth middleware rejects a request with no bearer token before the handler is reached"

---

## Messaging subtype

Source: `spec/messaging/*.md` schemas and TRs that describe event production/consumption.

Scenarios describe in-process interactions with the real Kafka/broker client:

- "The service publishes a well-formed event to the expected topic when the action completes"
- "The service consumes a message and processes it correctly, committing the offset"
- "A malformed message on the consumer is dead-lettered with the expected error code"
- "Publishing fails gracefully and propagates the expected service error when the broker is unavailable"

---

## External-API-Integration subtype

Source: Outbound HTTP clients discovered in source code and TRs naming external services.
Discovery (guide Step A) and spec collection (guide Step B) already ran in Step 3 of the
host skill — use `<external_services>` and `<scoped_services>` from those results.

Follow `guides/external-api-integration-tests-design-guide.md` (Steps C–E) to generate
WireMock-annotated scenarios for each service in `<scoped_services>`.

Scenarios describe the service's behavior when calling external HTTP services, stubbed
by WireMock — **not** the external service itself. Key generation rules:

- One scenario per documented response code per endpoint (200, 401, 403, 500); only
  generate for status codes the external API spec actually documents.
- Output one `<service>-ext-api-test-suite.md` per external service (guide Step F),
  alongside the standard `integration-test-suite.md`.
- If no outbound HTTP services were found or all were skipped in Step 3, the
  `external-api-integration` subtype is already removed from `<integration_subtypes>`;
  continue with remaining subtypes.

---

## Classifying auth/middleware TRs

A TR like "all endpoints require a valid bearer token" describes in-process middleware
behavior → integration/database scenario (the middleware intercepts and rejects the
request). A TR like "unauthenticated requests receive a 401 response" describes the
observable API shape → contract scenario. When a TR supports both readings, produce an
integration scenario for the behavior and a contract scenario for the response shape.

---

## Scenario format

```
### SC-N: <Short scenario title>

**Type:** integration
**Given** <precondition / starting state>
**And** <additional precondition> (if needed)
**When** <action / trigger>
**Then** <primary expected outcome>
**And** <additional outcome> (if needed)
**Verifies:** <BR-N or TR-N> — "<acceptance criterion text>"
```

For `external-api-integration` subtype scenarios:

```
### SC-N: <Short scenario title>

**Type:** integration
**Subtype:** external-api-integration
**External service:** <service-name>
**Endpoint:** <METHOD> <path>
**Given** <precondition — state of calling service and test data>
**When** <calling service's own endpoint invoked — real HTTP call>
**And** the external service responds with status <N> and body <description>
**Then** <expected response from the calling service>
**And** <secondary assertion> (if applicable)
**Verifies:** <BR-N or TR-N> — "<acceptance criterion text>"
```

Use a single `Then` when only one outcome exists. Add `And` lines when the scenario
produces side effects beyond the direct response — a DB write, a published event, an
audit log entry, a downstream service call. Each observable assertion gets its own
`Then`/`And` line so nothing is buried in prose.
