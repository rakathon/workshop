# Integration Subtype Inference — Design Guide

Reference for `forge:spec-tests` Step 1A. Applies only when `--type` is `integration`
or `full`. Defines how the skill infers which integration subtypes are active without
requiring an extra flag from the engineer.

---

## Subtypes

| Subtype | What it tests |
|---------|--------------|
| `database` | Service persists, retrieves, and deletes data via real DB; entity constraints; error propagation |
| `messaging` | Service publishes/consumes Kafka (or broker) messages; schema conformance; offset handling |
| `external-api-integration` | Service calls external HTTP services; responses stubbed by WireMock |

When multiple subtypes are inferred, all are included in the same `--type integration` run.
Database and messaging scenarios go into `integration-test-suite.md`; each
`external-api-integration` service gets its own `<service>-ext-api-test-suite.md`.

---

## Inference priority order

Apply in order; stop at the first level that produces a result.

### 1. Explicit user input (highest priority)

If the engineer's request names a specific subtype — e.g., "database integration tests",
"Kafka integration tests", "external API tests" — activate that subtype only.

If they say "all integration tests" or give no subtype guidance, continue to artifact
inference below.

### 2. Requirement artifacts

Scan `requirements/technical.md` and `requirements/business.md` (whichever are present)
for the following keyword patterns:

| Keyword pattern | Activates subtype |
|-----------------|-------------------|
| `persist`, `store`, `database`, `DB`, `repository`, `table`, `record`, `row` | `database` |
| `publish`, `emit`, `consume`, `Kafka`, `event`, `topic`, `message`, `broker`, `queue` | `messaging` |
| `call`, `integrate`, `external API`, `third-party`, `HTTP client`, `outbound`, `WireMock`, or any named external service | `external-api-integration` |

### 3. Spec artifacts

- `spec/storage/*.md` exists → activate `database`
- `spec/messaging/*.md` exists → activate `messaging`
- Outbound HTTP scan (guide Step A from `external-api-integration-tests-design-guide.md`) finds a client → activate `external-api-integration`

**Note:** Source-code discovery for the `external-api-integration` subtype (guide Step A)
runs in the host skill's Step 3, not here. This inference uses requirement keyword patterns
only as a pre-check. The source scan in Step 3 may confirm, refine, or override the
inferred subtype list.

---

## Output

Print the inferred subtypes before continuing:

```
Integration subtypes detected: database, external-api-integration
  database              — inferred from spec/storage/favorites.md
  external-api-integration — inferred from FavoritesClient.java (outbound HTTP)
```

If no subtypes can be inferred, prompt:

```
No integration subtype could be inferred automatically.
Which integration scenarios do you need?
  [1] database              — service → DB interactions
  [2] messaging             — service → Kafka/broker interactions
  [3] external-api-integration — outbound HTTP calls to external services (WireMock)
  [4] all of the above

Choose one or more (comma-separated):
```

Wait for the engineer's response and activate the chosen subtypes.

Store the active subtypes as `<integration_subtypes>` — used in Steps 5, 8, and 10 of
the host skill.
