# Business Requirements — Merchant Onboarding

## BR-1: Merchants Can Complete Onboarding and Go Live

A new merchant must be able to register, complete identity verification, and accept
terms through a self-serve flow. Upon completion, their account must be active and
their offers visible to users.

**Acceptance criteria:**
- A merchant who completes all onboarding steps is set to "active" status
- Active merchants' offers appear in the discovery service within 5 minutes

## BR-2: Merchants Receive a Welcome Email After Registration

Once a merchant registers successfully, they must receive a welcome email with
onboarding instructions.

**Acceptance criteria:**
- Welcome email is sent within 60 seconds of successful registration
- Email contains a link to the merchant portal

## BR-3: Duplicate Merchant Registrations Are Rejected

A business identity (tax ID) that already has an active account must not be able to
register again.

**Acceptance criteria:**
- A registration attempt with an existing tax ID returns an error
- No duplicate account is created
