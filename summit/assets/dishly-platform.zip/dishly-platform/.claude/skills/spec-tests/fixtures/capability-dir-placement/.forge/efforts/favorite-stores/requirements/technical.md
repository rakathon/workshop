# Technical Requirements — Favorite Stores

## TR-1: Favorites Persistence Must Survive Session Boundaries

*Traces to: BR-1*

The favorites data must be stored in a persistent database, not session storage or
in-memory. A favorite created in one session must be retrievable in a subsequent
session.

**Acceptance criteria:**
- Favorites survive server restarts
- Favorites survive client session expiry

## TR-2: All Favorites Endpoints Must Require Authentication

*Traces to: BR-2*

Every favorites API endpoint must require a valid bearer token. Unauthenticated
requests must receive a 401 response before any favorites logic executes.

**Acceptance criteria:**
- Requests without Authorization header receive 401
- Requests with an invalid or expired token receive 401
- No favorites data is returned in 401 responses
