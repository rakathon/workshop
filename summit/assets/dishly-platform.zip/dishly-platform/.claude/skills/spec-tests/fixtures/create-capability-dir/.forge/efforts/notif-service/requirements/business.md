# Business Requirements — Push Notifications

## BR-1: Users Receive Timely Push Notifications for Key Events

The system must send push notifications to users when key events occur (e.g., a
reward is credited, a promotional offer expires soon).

**Acceptance criteria:**
- Notification is delivered within 30 seconds of the triggering event
- Notification body includes the event description and a deep link

## BR-2: Users Can Opt Out of Notifications

Users must be able to disable push notifications entirely or by notification type.

**Acceptance criteria:**
- A user who has opted out receives no push notifications
- Opt-out preference persists across app reinstalls via the backend
