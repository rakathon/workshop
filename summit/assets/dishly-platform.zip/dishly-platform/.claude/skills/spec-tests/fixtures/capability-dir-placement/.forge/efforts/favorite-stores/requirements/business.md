# Business Requirements — Favorite Stores

## BR-1: Users Can Save Stores for Quick Access

Users need to bookmark merchant stores so they can return to them easily. The system
must allow an authenticated user to mark a store as a favorite and retrieve the list
of favorited stores.

**Acceptance criteria:**
- A user can favorite a store by providing the store ID
- Favorited stores are retrievable after the session that created them ends
- A user can remove a store from their favorites

## BR-2: Favorites Are Private to Each User

One user's favorites must not be visible to or modifiable by another user. The system
must enforce user-level isolation.

**Acceptance criteria:**
- GET /v1/favorites returns only the favorites of the authenticated user
- DELETE /v1/favorites/{storeId} can only remove favorites belonging to the authenticated user
