# forge:spec-tests

Authors a BDD test suite for the active effort. The engineer declares what kind of
test suite they need; the skill checks whether available spec artifacts can support
it, surfaces gaps with actionable next steps, and generates scenarios only for
achievable types.

## Purpose

Translates effort requirements and spec artifacts into a concrete, file-backed test
suite before implementation begins. Scenarios are traceable to BR-* and TR-*
identifiers so there is a clear record of what each test verifies.

The skill is re-invokable — calling it on an existing suite extends it rather than
replacing it.

## When to Use

- After `forge:spec-api`, `forge:spec-storage`, or `forge:spec-messaging` completes
- When asked to "design tests", "plan integration tests", or "write a test strategy"
- When asked to "design E2E tests", "write WireMock test scenarios", or "design database/Kafka integration tests"
- To extend an existing test suite with new scenario types

## Usage

```
forge:spec-tests [effort-id] [--type <type>] [--capability <deployable>/<capability>] [--product <product-name>]
```

### Arguments

| Argument | Description |
|----------|-------------|
| `effort-id` | Optional. Defaults to the active effort. |
| `--type` | `e2e`, `contract`, `integration`, or `full` (default). |
| `--capability` | Routes output to a specific capability's `test/` directory. |
| `--product` | E2E in a coordination repo — routes output to a product's `test/` directory. |

### Test Suite Types

| Type | What it covers | Required spec |
|------|---------------|---------------|
| `e2e` | End-to-end user journeys against deployed services | `requirements/business.md` |
| `contract` | API and messaging schema contracts | `spec/api/` or `spec/messaging/` |
| `integration` | Database, messaging, and external-API integration | `spec/storage/`, `spec/messaging/`, or outbound HTTP clients |
| `full` | All achievable types | As above, per type |

`integration` has three auto-inferred subtypes: `database`, `messaging`, and
`external-api-integration`. Subtypes are determined from spec artifacts and source
code — no flag needed.

## Examples

```
forge:spec-tests                                          # full suite, active effort
forge:spec-tests PPE-1234 --type contract --capability rewards-api/favorites
forge:spec-tests PPE-1234 --type e2e --product rewards-platform
forge:spec-tests PPE-1234 --type integration --capability rewards-api/favorites
```

## Output Files

| Type | Filename |
|------|----------|
| `e2e` (system) | `e2e-test-suite.md` |
| `e2e` (UI) | `ui-e2e-test-suite.md` |
| `contract` | `<spec-name>-contract-test-suite.md` |
| `integration` (database + messaging) | `integration-test-suite.md` |
| `integration` (external-api) | `<service>-ext-api-test-suite.md` |

## Feasibility Check

Before generating scenarios the skill checks whether required artifacts exist. If
some types are blocked, it prints a gap report and offers to continue with achievable
types or stop to fill the gap first.

| Missing artifact | Suggested skill |
|-----------------|----------------|
| `spec/api/` | `forge:spec-api` |
| `spec/storage/` | `forge:spec-storage` |
| `spec/messaging/` | `forge:spec-messaging` |
| `spec/ux/ux-strategy.md` | `forge:ux-design` |

## Related Skills

- `forge:elaborate` — produce business requirements before designing tests
- `forge:spec-api` — author API spec needed for contract tests
- `forge:spec-storage` — author storage spec needed for integration tests
- `forge:spec-messaging` — author messaging spec needed for integration/contract tests
- `forge:build-tests` — convert BDD scenarios from this skill into executable test code
