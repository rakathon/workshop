# forge:verify

## Purpose

`forge:verify` checks that the completed implementation actually delivers the effort's
stated requirements. It reads every BR, TR, and ADR from the discovery artifacts, maps
them to the tasks in the implementation plan, and reads the source files changed by
each task to confirm real, wired, non-stub implementation evidence exists for each
requirement.

The result is `verification/report.md` — a machine-readable report with a PASS or FAIL
per requirement and exact code locations for any gaps.

## When to Use

Run `forge:verify` when:
- All tasks in `plan/tasks.md` are marked complete with commit SHAs
- You are about to open a PR and want to confirm the implementation is complete
- `forge:promote` prompts you to run verify before advancing to the verification phase

## Usage

```
forge:verify <effort-id>
```

The orchestrator confirms preconditions (all tasks done, discovery artifacts present,
no unresolved escalation), spawns the worker sub-agent with the effort directory as
input, and presents the resulting report.

## What It Checks

For each business requirement (BR) and technical requirement (TR):
- **Implementation evidence** — is there real code that delivers this requirement?
- **Stub detection** — is the code a placeholder (`return null`, `TODO`, etc.)?
- **Integration wiring** — are all components connected end-to-end?
- **Spec contract compliance** (TRs only) — does the implementation match the
  API/storage/event schema defined in the spec?

For each ADR:
- Does the implementation follow the prescribed approach?
- Does the implementation contradict the decision?

## Output

`verification/report.md` in the effort directory:

```
# Verification Report

**Effort:** my-effort
**Date:** 2026-03-27T14:32:00Z
**Result:** PASS

## Summary

All 5 business requirements and 3 technical requirements verified...
```

- **PASS** — every requirement has real implementation evidence; no stubs; no missing
  wiring; all ADRs complied with. Ready for `forge:promote`.
- **FAIL** — one or more requirements have gaps. The report lists each gap with the
  file path and function where the problem was found (or `(missing)` if the code does
  not exist at all). Implementation must resume before the effort can be promoted.

## Examples

```
forge:verify favorites-feature
```

Verifies the `favorites-feature` effort. Reads
`.forge/efforts/favorites-feature/requirements/`, `spec/`, and `plan/tasks.md`.
Writes `.forge/efforts/favorites-feature/verification/report.md`.

## Notes

- `forge:verify` does not run tests or the linter — those run per-task during
  implementation via the quality loop.
- `forge:verify` does not modify implementation code. It reads and reports only.
- `forge:promote` requires `verification/report.md` to be present with `Result: PASS`
  before advancing from the implementation phase.
