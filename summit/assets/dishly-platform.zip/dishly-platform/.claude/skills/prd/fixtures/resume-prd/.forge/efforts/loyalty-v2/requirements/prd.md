# PRD: Loyalty Program v2

*Effort ID: loyalty-v2*
*Last updated: 2026-05-01*

---

## Problem Statement

Existing loyalty members cannot redeem points at partner merchants online, limiting
program value and driving churn. Only 12% of active members have ever made a
partner redemption, despite strong intent signals in exit surveys.

---

## Goals

1. Increase partner redemption rate from 12% to 25% — measured by % of active members
   completing at least one partner redemption within 90 days of launch.
2. Reduce redemption support tickets by 30% — measured by ticket volume month-over-month.
3. Achieve 80% coverage of top-10 partner merchants — measured by merchant integrations live.

---

## Non-Goals

- We are not redesigning the points accrual engine — it is stable and out of scope.
- We are not building a mobile-native redemption flow — web-only for v2.
- We are not supporting international merchant partners — domestic only for v2.

---

## Success Metrics

### Leading Indicators (early signal)

- Weekly partner redemption attempts per active member
- Checkout funnel drop-off rate at the point linking step

### Lagging Indicators (final outcome)

- 90-day partner redemption rate (target: 25% of active members)
- Monthly support ticket volume for redemption issues (target: -30%)

---

## Open Questions

- Do partner APIs support real-time balance checks? [owner: eng] [due: 2026-06-01]

---

## Timeline / Dependencies

- **Target:** Q3 2026
- **Dependencies:** Partner API credentials from BD team (by 2026-06-15)

---

## Requirements

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See `user-stories.md` for Connextra-format stories grouped by persona.
