# Business Requirements: Loyalty Program v2

*Effort ID: loyalty-v2*
*Last updated: 2026-05-01*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained
-->

---

## BR-1: Partner Merchant Redemption at Checkout

**Priority:** P0

Members must be able to use their loyalty points as payment at participating partner
merchants — closing the redemption gap that is driving member churn and limiting
program value.

**Acceptance Criteria:**
- [ ] A member who shops at a participating partner merchant can complete a purchase
      using loyalty points without leaving the merchant's checkout experience
- [ ] The member receives confirmation of the redemption before the session ends
- [ ] The points deducted are accurately reflected in the member's account

---

## BR-2: Member Visibility into Redemption Activity

**Priority:** P1

Members must have access to a complete, accurate record of their partner redemptions —
so they can verify transactions and resolve disputes without contacting support.

**Acceptance Criteria:**
- [ ] A member can independently review all past partner redemptions
- [ ] Each redemption record includes enough detail to identify the transaction
      (merchant, amount, date) without requiring a support call
