# User Stories: <Effort Title>

*Product / Effort: <product_name_or_effort_id>*
*Last updated: <YYYY-MM-DD>*

---

## <Persona or Theme>

**US-1:** As a <persona>, I want <action>, so that <outcome>.

**Acceptance Criteria:**
- [ ] <testable criterion>
- [ ] <testable criterion>

---

**US-2:** As a <persona>, I want <action>, so that <outcome>.

**Acceptance Criteria:**
- [ ] <testable criterion>
- [ ] <testable criterion>

---

## <Second Persona or Theme>

**US-3:** As a <persona>, I want <action>, so that <outcome>.

**Acceptance Criteria:**
- [ ] <testable criterion>
- [ ] <testable criterion>
