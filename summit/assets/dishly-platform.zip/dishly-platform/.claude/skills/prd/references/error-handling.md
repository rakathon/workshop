# forge:prd — Error Handling

## No active effort — Forge mode

If no effort ID can be resolved (`.forge/EFFORT` is absent and no efforts exist under
`.forge/efforts/`), stop immediately:

> "There is no active effort set. Please run `forge:effort` to create or select an
> effort, then re-run `forge:prd`."

Stop immediately.

---

## No product directory — Plain mode

If the product directory `<products_root>/<product_name>/` does not exist, stop
immediately:

> "No product directory found for **<product_name>**. Run `/forge:product <product_name>`
> to register it first, then re-invoke this skill."

Stop immediately. Do not create the directory.

---

## Fewer than 3 goals

Do not proceed past Step 3. Explain:

> "We need at least 3 measurable goals. Fewer than 3 goals makes it hard to declare
> success. Can you add one more?"

---

## Fewer than 3 non-goals confirmed

Do not proceed past Step 4. Explain:

> "The non-goals section requires at least 3 entries. Non-goals are a core alignment
> tool — without them, teams frequently disagree on scope mid-delivery. Please confirm
> at least 3."

---

## File write conflict (business.md has existing PM-authored BRs)

Never overwrite existing BR-N entries. Append only. Log the highest existing BR-N
number and continue numbering from there.

---

## PM interrupts mid-session

If the PM ends the session before all three files are written, write only the files
whose sections have been fully confirmed. Inform the PM:

> "Session paused. Files written so far: <list>. Re-invoke `forge:prd` to continue
> from where we left off — I will detect existing files and skip confirmed sections."
