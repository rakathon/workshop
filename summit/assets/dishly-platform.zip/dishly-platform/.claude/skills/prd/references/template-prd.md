# PRD: <Effort Title>

*Product / Effort: <product_name_or_effort_id>*
*Last updated: <YYYY-MM-DD>*

---

## Problem Statement

<1–2 paragraph synthesis from the problem statement interview>

---

## Goals

1. <Goal> — measured by <metric/threshold>
2. <Goal> — measured by <metric/threshold>
3. <Goal> — measured by <metric/threshold>
<!-- Add more as needed, up to 5 -->

---

## Non-Goals

- We are not doing <X> because <Y>.
- We are not doing <X> because <Y>.
- We are not doing <X> because <Y>.
<!-- Minimum 3. Add more as needed. -->

---

## Success Metrics

### Leading Indicators (early signal)

- <metric>

### Lagging Indicators (final outcome)

- <metric>

---

## Open Questions

- <Question text> [owner: <eng/design/legal/data>] [due: <date or milestone>]
<!-- If none confirmed, write: None identified at this time. -->

---

## Timeline / Dependencies

- **Target:** <date or milestone>
- **Dependencies:** <list or "None identified">

---

## Requirements

See `business.md` for the full requirement list with MoSCoW priority tiers.

---

## User Stories

See `user-stories.md` for Connextra-format stories grouped by persona.
