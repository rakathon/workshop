# Business Requirements: <Effort Title>

*Product / Effort: <product_name_or_effort_id>*
*Last updated: <YYYY-MM-DD>*

<!-- MoSCoW Tier Reference:
  P0 = Must Have  — Required for v1.0 launch; blocking
  P1 = Should Have — High value; include if capacity allows
  P2 = Could Have  — Nice to have; defer if time-constrained

  Business Requirement framing guide:
  A BR describes a business outcome, obligation, or rule — not how a system achieves it.

  ✅ Correct: "Members must be able to use loyalty points as payment at partner merchant
              checkouts — to close the redemption gap driving member churn."
  ❌ Wrong:   "The system must allow members to select Pay with Points at checkout and
              deduct the balance in real time."

  The correct form names what the business must ensure or provide, and optionally why.
  It does NOT reference the system, UI element names, or technical mechanisms.
  Functional and technical details (how) belong in engineering's elaboration phase.

  Acceptance criteria should be observable business outcomes — what a stakeholder can
  verify without knowing the implementation. Avoid referencing system internals, UI
  element names, or SLAs (those belong in technical requirements).
-->

---

## BR-1: <Short Title>

**Priority:** P0

<Requirement statement — one or two sentences describing a business outcome, obligation,
or rule. State what the business must ensure or provide, and optionally why. Do not
reference the system, UI element names, or technical mechanisms.>

**Acceptance Criteria:**
- [ ] <observable business outcome a stakeholder can verify>
- [ ] <observable business outcome a stakeholder can verify>

---

## BR-2: <Short Title>

**Priority:** P1

<Requirement statement — one or two sentences describing a business outcome, obligation,
or rule. State what the business must ensure or provide, and optionally why. Do not
reference the system, UI element names, or technical mechanisms.>

**Acceptance Criteria:**
- [ ] <observable business outcome a stakeholder can verify>
- [ ] <observable business outcome a stakeholder can verify>
