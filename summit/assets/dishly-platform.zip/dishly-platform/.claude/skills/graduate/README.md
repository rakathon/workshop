# forge:graduate

Promotes a completed effort's artifacts into the canonical documentation for its
associated deployable(s) or product(s).

## Purpose

When an effort completes — all tasks done, verification passed, QA signed off — its
artifacts live in `.forge/efforts/<id>/`. That location is ephemeral working space.
Canonical documentation lives in `.forge/deployables/<name>/` (or `.forge/products/<name>/`
for coordination efforts). Graduation is the act of merging effort artifacts into the
canonical location so that the deployable's documentation reflects the current state of
the system.

After graduation, the effort directory remains as a permanent historical record but the
effort is removed from the active registry.

## When to Use

Run `forge:graduate` when:

- All implementation tasks are complete
- Verification has passed
- QA has signed off in a pre-production environment
- No blocking issues remain

Do not graduate an effort that is still in progress. The orchestrator verifies phase
completion before launching the graduation worker.

## What Gets Promoted

| Effort artifact | Canonical destination |
|----------------|-----------------------|
| `requirements/business.md` | `.forge/deployables/<name>/requirements/business.md` |
| `requirements/technical.md` | `.forge/deployables/<name>/requirements/technical.md` |
| `spec/api/` | `.forge/deployables/<name>/spec/api/` |
| `spec/storage/` | `.forge/deployables/<name>/spec/storage/` |
| `spec/messaging/` | `.forge/deployables/<name>/spec/messaging/` |
| `capabilities/<cap>/` | `.forge/deployables/<name>/capabilities/<cap>/` |

For coordination efforts targeting products, the destination is `.forge/products/<name>/`.

**Not promoted:** implementation plans, validation reports, verification reports,
arch-review output. These are effort-internal artifacts.

**ADRs:** ADRs are written to `.forge/spec/arch-decisions/` during the discovery phase,
not at graduation. Graduation verifies ADR provenance (that each ADR references the
effort ID) but does not move or copy ADR files.

## The Merge-Not-Append Guarantee

Graduation applies an update algorithm, not an append algorithm. Each canonical document
remains a single coherent document after graduation.

**What this means in practice:**

- If the effort's `requirements/business.md` contains a `## BR-1` section, that section
  replaces the existing `## BR-1` in the canonical document
- If the effort adds a new `## BR-5` section that did not exist before, it is appended
  in the appropriate location
- Sections in the canonical document that the effort does not address are preserved
  unchanged

**What is prohibited:** Adding a "Requirements added by effort-XYZ" block alongside the
existing requirements section. After graduation, a reader should see a single, current
requirements section — not a layered record of successive efforts.

## Provenance Tracking

Every canonical document updated by graduation receives a provenance comment placed
immediately after the H1 heading:

```markdown
# Document Title
<!-- graduated-from: <effort-id> at 2026-03-27T14:30:00Z -->
```

This comment is not visible in rendered Markdown but is present in the source. It enables
engineers to trace which effort last updated a canonical document. Subsequent graduations
replace the comment to reflect the most recent graduating effort.

## Graduation Commit

All changes are committed in a single, isolated commit:

```
docs(graduation): graduate effort-<id> to <deployable-name>
```

The commit contains only canonical documentation updates, the effort's `.state.json`
graduation fields, and the registry row removal. No source code, no test changes.

## Usage

The orchestrator launches graduation as an isolated sub-agent after confirming all
preconditions:

```
forge:graduate <effort-id>
```

The worker receives the effort ID, reads all required state and artifacts, performs
the merge, commits the result, and returns a graduation report to the main session.

## Graduation Report

The graduation report includes:

- List of every canonical file created or updated, with its destination path
- ADR verification status for each ADR produced by the effort
- Post-approval modifications that were reconciled (if any)
- Confirmation that the effort has been removed from the active registry

If any ADRs are missing from the canonical directory, the report flags them for engineer
attention. The skill does not create missing ADRs — their absence requires an explicit
engineering decision.
