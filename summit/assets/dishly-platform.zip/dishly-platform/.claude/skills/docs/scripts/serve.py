#!/usr/bin/env python3
"""serve.py — forge:docs dynamic HTTP server with /_api/* endpoints."""

import html as _html
import json
import os
import pathlib
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

REPO_ROOT: Path = Path(".")
FORGE_DIR: Path = Path(".forge")
SITE_DIR:  Path = Path(".forge/site")

_IGNORED = {".server.pid", ".DS_Store", "__pycache__", "site"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_heading(p: Path):
    try:
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            s = line.strip()
            if s.startswith("# "):
                return s[2:].strip()
    except OSError:
        pass
    return None


def _file_type(p: Path) -> str:
    s = p.suffix.lower()
    if s == ".md":
        return "md"
    if s in (".yaml", ".yml"):
        return "yaml"
    if s == ".html":
        return "html"
    return "ignore"


def _has_content(p: Path) -> bool:
    if not p.is_dir():
        return False
    for e in p.rglob("*"):
        if e.is_file() and e.name not in _IGNORED and _file_type(e) in ("md", "yaml", "html"):
            return True
    return False


def _read_html_title(p: Path):
    """Return the text content of the first <title> tag, or None."""
    try:
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            s = line.strip()
            start = s.lower().find("<title>")
            end = s.lower().find("</title>")
            if start != -1 and end != -1:
                return s[start + 7:end].strip()
    except OSError:
        pass
    return None


def _read_state(p: Path) -> dict:
    f = p / ".state.json"
    if not f.exists():
        return {}
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _repo_rel(p: Path) -> str:
    return str(p.relative_to(REPO_ROOT)).replace(os.sep, "/")


# ---------------------------------------------------------------------------
# Directory listing
# ---------------------------------------------------------------------------

def _ls_node(path: Path, depth: int = 0) -> dict:
    """Return {dirs, files} for *path*, recursing up to *depth* extra levels."""
    dirs, files = [], []
    try:
        entries = sorted(path.iterdir(), key=lambda p: p.name.lower())
    except PermissionError:
        return {"dirs": [], "files": []}

    for e in entries:
        if e.name in _IGNORED or e.name.startswith("."):
            continue
        if e.is_dir():
            if not _has_content(e):
                continue
            s = _read_state(e)
            s.setdefault("id", e.name)
            s.setdefault("title", e.name)
            child: dict = {
                "name":  e.name,
                "path":  _repo_rel(e),
                "state": s,
            }
            if depth > 0:
                nested = _ls_node(e, depth - 1)
                child["dirs"]  = nested["dirs"]
                child["files"] = nested["files"]
            dirs.append(child)
        elif e.is_file():
            ft = _file_type(e)
            if ft == "ignore":
                continue
            if ft == "md":
                title = _read_heading(e) or e.stem
            elif ft == "html":
                title = _read_html_title(e) or e.stem
            else:
                title = e.stem
            files.append({
                "name":  e.name,
                "path":  _repo_rel(e),
                "type":  ft,
                "title": title,
            })

    return {"dirs": dirs, "files": files}


def _detect_type(path: Path) -> str:
    try:
        parts = path.relative_to(FORGE_DIR).parts
    except ValueError:
        return "generic"
    p = parts
    if not p:                                                         return "root"
    if p == ("efforts",):                                             return "efforts"
    if len(p) == 2 and p[0] == "efforts":                            return "effort"
    if p == ("deployables",):                                         return "deployables"
    if len(p) == 2 and p[0] == "deployables":                        return "deployable"
    if len(p) == 3 and p[0] == "deployables" and p[2] == "capabilities": return "capabilities"
    if len(p) == 4 and p[0] == "deployables" and p[2] == "capabilities": return "capability"
    if p == ("products",):                                            return "products"
    if len(p) == 2 and p[0] == "products":                           return "product"
    return "generic"


# ---------------------------------------------------------------------------
# API handlers
# ---------------------------------------------------------------------------

def api_ls(forge_rel: str, depth: int = 0) -> dict:
    path = (FORGE_DIR / forge_rel).resolve() if forge_rel else FORGE_DIR.resolve()
    try:
        path.relative_to(FORGE_DIR.resolve())
    except ValueError:
        return {"error": "path outside .forge/"}
    if not path.is_dir():
        return {"error": f"not a directory: {forge_rel!r}"}

    state = _read_state(path)
    state.setdefault("id", path.name)
    state.setdefault("title", path.name)
    node = _ls_node(path, min(depth, 5))

    return {
        "path":  _repo_rel(path),
        "name":  path.name,
        "type":  _detect_type(path),
        "state": state,
        "dirs":  node["dirs"],
        "files": node["files"],
    }


def api_home() -> dict:
    ed = FORGE_DIR / "efforts"
    dd = FORGE_DIR / "deployables"
    pd = FORGE_DIR / "products"

    active = closed = 0
    if ed.is_dir():
        for d in ed.iterdir():
            if not d.is_dir():
                continue
            s = _read_state(d)
            if s.get("graduation", {}).get("graduated") or s.get("currentPhase") == "closed":
                closed += 1
            else:
                active += 1

    deps = caps = 0
    if dd.is_dir():
        for d in dd.iterdir():
            if not d.is_dir():
                continue
            deps += 1
            c = d / "capabilities"
            if c.is_dir():
                caps += sum(1 for x in c.iterdir() if x.is_dir())

    prods = sum(1 for d in pd.iterdir() if d.is_dir()) if pd.is_dir() else 0

    return {
        "repoName":      REPO_ROOT.name,
        "activeEfforts": active,
        "closedEfforts": closed,
        "deployables":   deps,
        "capabilities":  caps,
        "products":      prods,
        "hasProducts":   pd.is_dir(),
    }


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------

_MIME = {
    ".html": "text/html; charset=utf-8",
    ".css":  "text/css",
    ".js":   "application/javascript",
    ".json": "application/json",
    ".md":   "text/plain; charset=utf-8",
    ".yaml": "text/plain; charset=utf-8",
    ".yml":  "text/plain; charset=utf-8",
    ".png":  "image/png",
    ".jpg":  "image/jpeg",
    ".svg":  "image/svg+xml",
    ".ico":  "image/x-icon",
}


class ForgeDocsHandler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass  # suppress per-request logs

    def do_GET(self):
        parsed = urlparse(self.path)
        p  = parsed.path
        qs = parse_qs(parsed.query)

        # /_api/home
        if p == "/_api/home":
            return self._json(api_home())

        # /_api/ls?path=<forge-rel>&depth=<int>
        if p == "/_api/ls":
            raw = qs.get("path", [""])[0]
            # Strip leading ".forge/" so callers can pass either form
            raw = raw.removeprefix(".forge/").removeprefix(".forge")
            try:
                depth = min(int(qs.get("depth", ["0"])[0]), 5)
            except (ValueError, TypeError):
                return self._err(400, "depth must be an integer")
            return self._json(api_ls(raw, depth))

        # On-the-fly swagger pages — /.forge/site/.../<stem>-swagger.html
        # The corresponding yaml lives at .forge/.../<stem>.yaml
        if p.startswith("/.forge/site/") and p.endswith("-swagger.html"):
            stem = p[len("/.forge/site/"):-len("-swagger.html")]  # e.g. efforts/forge-init/spec/api/auth
            yaml_path = FORGE_DIR / (stem + ".yaml")
            if not yaml_path.is_file():
                yaml_path = FORGE_DIR / (stem + ".yml")
            if yaml_path.is_file():
                depth = len(Path(stem).parent.parts)  # directory levels deep from site root
                yaml_url = _html.escape("/" + str(yaml_path.relative_to(REPO_ROOT)))
                title = _html.escape(yaml_path.name)
                css_prefix = "../" * depth
                # Breadcrumbs: stem = "efforts/forge-init/spec/api/auth"
                crumb_parts = stem.split("/")
                crumbs = '<span class="sep">/</span><a href="/.forge/site/">home</a>'
                built = ""
                for part in crumb_parts[:-1]:
                    built = (built + "/" + part) if built else part
                    label = _html.escape(part.replace("-", "‑"))
                    crumbs += f'<span class="sep">/</span><a href="/.forge/site/{built}/">{label}</a>'
                crumbs += f'<span class="sep">/</span><span class="crumb-current">{title}</span>'
                body = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{title} — forge:docs</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,400;0,8..60,600;1,8..60,300&family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css" />
  <link rel="stylesheet" href="{css_prefix}forge-docs.css">
  <style>
    /* blend Swagger UI into the site theme */
    body {{ background: var(--bg); }}
    .swagger-ui {{ font-family: 'Source Serif 4', Georgia, serif; }}
    .swagger-ui .topbar {{ display: none; }}
    .swagger-ui .info .title {{ font-family: 'Playfair Display', Georgia, serif; color: var(--text); }}
    .swagger-ui .opblock-tag {{ font-family: 'IBM Plex Mono', monospace; color: var(--text); }}
    #swagger-ui {{ max-width: 960px; margin: 0 auto; padding: 2rem; }}
  </style>
</head>
<body>
  <nav>
    <a class="nav-brand" href="/.forge/site/">forge:docs</a>
    <div class="nav-breadcrumbs">{crumbs}</div>
  </nav>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    window.onload = function () {{
      SwaggerUIBundle({{
        url: "{yaml_url}",
        dom_id: "#swagger-ui",
        presets: [SwaggerUIBundle.presets.apis, SwaggerUIBundle.SwaggerUIStandalonePreset],
        layout: "BaseLayout"
      }});
    }};
  </script>
</body>
</html>"""
                return self._respond(200, "text/html; charset=utf-8", body.encode())

        # Dynamic index pages — serve the shell for any navigation URL under .forge/site/
        # Matches: trailing slash, /index.html, or bare directory path (no extension)
        is_site_index = p.startswith("/.forge/site/") and (
            p.endswith("/")
            or p.endswith("/index.html")
            or p == "/.forge/site"
            or "." not in p.split("/")[-1]  # no extension = directory path
        )
        if is_site_index:
            return self._file(SITE_DIR / "index.html", "text/html; charset=utf-8")

        # Static files — serve from repo root
        fp = (REPO_ROOT / p.lstrip("/")).resolve()
        try:
            fp.relative_to(REPO_ROOT.resolve())
        except ValueError:
            return self._err(403, "Forbidden")

        if not fp.is_file():
            return self._err(404, f"Not found: {p}")

        ct = _MIME.get(fp.suffix.lower(), "application/octet-stream")
        self._file(fp, ct)

    def _json(self, data: dict):
        body = json.dumps(data, ensure_ascii=False).encode()
        self._respond(200, "application/json", body)

    def _file(self, fp: Path, ct: str):
        try:
            data = fp.read_bytes()
        except OSError:
            return self._err(500, "Read error")
        self._respond(200, ct, data)

    def _err(self, code: int, msg: str):
        self._respond(code, "text/plain", msg.encode())

    def _respond(self, code: int, ct: str, body: bytes):
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run(port: int, repo_root: Path) -> None:
    global REPO_ROOT, FORGE_DIR, SITE_DIR
    REPO_ROOT = repo_root.resolve()
    FORGE_DIR = REPO_ROOT / ".forge"
    SITE_DIR  = FORGE_DIR / "site"
    print(f"forge:docs server: http://localhost:{port}/.forge/site/", flush=True)
    HTTPServer(("127.0.0.1", port), ForgeDocsHandler).serve_forever()


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=7477)
    ap.add_argument("--repo-root", type=pathlib.Path, required=True)
    args = ap.parse_args()
    run(args.port, args.repo_root)
