#!/usr/bin/env python3
"""generate.py — forge:docs site generator. See SKILL.md for usage."""

import argparse
import html
import os
import pathlib
import shutil
import signal
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Design tokens — identical to forge:arch-review
# ---------------------------------------------------------------------------

FORGE_DOCS_CSS_FILENAME = "forge-docs.css"

DESIGN_TOKENS_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,400;0,8..60,600;1,8..60,300&family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&display=swap');

:root {
  --brand:          #8529cd;
  --brand-alpha12:  rgba(133, 41, 205, 0.12);
  --brand-alpha06:  rgba(133, 41, 205, 0.06);
  --bg:             #f9f6fe;
  --bg-alt:         #ffffff;
  --border-soft:    #e0d7f3;
  --border-faint:   #d5c8f0;
  --text:           #1a1a2e;
  --muted:          #6b6b8a;
  --green:          #009470; --green-bg:  #e6f6f2; --green-border:  #b3e8da;
  --red:            #b83232; --red-bg:    #fdf0f0; --red-border:    #f5c0c0;
  --yellow:         #b08000; --yellow-bg: #fdf8e6; --yellow-border: #eedda0;
  --blue:           #1d4ed8; --blue-bg:   #eff4ff; --blue-border:   #bfcfff;
  --shadow-sm:      0 1px 3px rgba(0,0,0,0.06);
  --shadow-md:      0 2px 10px rgba(133,41,205,0.10);
  --shadow-lg:      0 4px 20px rgba(133,41,205,0.16);
  --ease:           cubic-bezier(0.2, 0, 0, 1);
  --dur-fast:       120ms;
  --dur-base:       200ms;
  --font-display:   'Playfair Display', Georgia, serif;
  --font-body:      'Source Serif 4', Georgia, serif;
  --font-mono:      'IBM Plex Mono', monospace;
  --text-xs:        0.7rem;
  --text-sm:        0.85rem;
  --text-base:      1rem;
  --text-lg:        1.15rem;
  --text-xl:        1.4rem;
  --text-2xl:       1.75rem;
  --text-3xl:       2.2rem;
  --radius-sm:      4px;
  --radius-md:      6px;
  --radius-lg:      8px;
  --radius-xl:      12px;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'Source Serif 4', Georgia, serif;
  font-size: 16px;
  line-height: 1.6;
  color: var(--text);
  background: var(--bg);
}

nav {
  background: var(--bg);
  border-bottom: 2px solid var(--brand);
  padding: 0 2rem;
  height: 44px;
  display: flex;
  align-items: center;
  gap: 1.5rem;
}

.nav-brand {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--brand);
  text-decoration: none;
  flex-shrink: 0;
}

.site-header {
  position: sticky;
  top: 0;
  z-index: 100;
}

.topnav {
  background: var(--text);
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 8px 16px;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.7rem;
}

.topnav-link {
  padding: 4px 12px;
  color: #aaa;
  text-decoration: none;
  border-radius: var(--radius-sm);
  border: 1px solid transparent;
  transition: color var(--dur-fast) var(--ease);
  white-space: nowrap;
}

.topnav-link:hover { color: #fff; }

.topnav-link-active {
  color: var(--bg);
  background: var(--brand);
  border-color: var(--brand);
}

.nav-breadcrumbs {
  display: flex;
  align-items: center;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.72rem;
  color: var(--muted);
  min-width: 0;
  overflow: hidden;
  border: none;
  padding: 0;
  background: transparent;
  position: static;
}

.nav-breadcrumbs a {
  color: var(--brand);
  text-decoration: none;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.nav-breadcrumbs a:hover { text-decoration: underline; }

.nav-breadcrumbs .sep {
  margin: 0 0.35em;
  opacity: 0.45;
  flex-shrink: 0;
}

.nav-breadcrumbs .crumb-current {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  color: var(--text);
  font-weight: 600;
}

h1, h2.section-title {
  font-family: 'Playfair Display', Georgia, serif;
}

code, pre, .mono {
  font-family: 'IBM Plex Mono', monospace;
}

.container {
  max-width: 960px;
  margin: 0 auto;
  padding: 2rem;
}

.stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 1rem;
  margin: 2rem 0;
}

.stat-card {
  background: var(--bg-alt);
  border: 1px solid var(--brand);
  border-radius: 8px;
  padding: 1.25rem 1.5rem;
  text-align: center;
  transition: box-shadow var(--dur-base) var(--ease);
}

.stat-card:hover { box-shadow: var(--shadow-md); }

.stat-card .stat-value {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 2.5rem;
  font-weight: 700;
  color: var(--brand);
  line-height: 1;
}

.stat-card .stat-label {
  font-size: 0.7rem;
  color: var(--muted);
  margin-top: 0.4rem;
  text-transform: uppercase;
  letter-spacing: 0.07em;
}

.section-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.25rem;
  margin-top: 0.5rem;
}

.section-card {
  background: var(--bg-alt);
  border: 1px solid var(--border-faint);
  border-radius: 8px;
  padding: 1.5rem;
  text-decoration: none;
  color: var(--text);
  transition: border-color var(--dur-base) var(--ease), box-shadow var(--dur-base) var(--ease), transform var(--dur-base) var(--ease);
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.section-card:hover {
  border-color: var(--brand);
  box-shadow: var(--shadow-md);
  transform: translateY(-1px);
}

.section-card:focus-visible {
  outline: 2px solid var(--brand);
  outline-offset: 2px;
}

.section-card h2 {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 1.15rem;
  color: var(--brand);
}

.section-card p {
  font-size: 0.9rem;
  color: var(--muted);
  flex: 1;
}

.page-title {
  font-size: 2.2rem;
  margin: 2rem 0 0.5rem;
}

.page-subtitle {
  font-size: 1rem;
  color: var(--muted);
  margin-bottom: 1rem;
}

h2.section-title {
  font-size: 1.4rem;
  margin: 2rem 0 1rem;
  padding-bottom: 0.4rem;
  border-bottom: 1px solid #d5c8f0;
}

/* --- generic index --- */

ul.listing {
  list-style: none;
  border: 1px solid var(--blue-border);
  border-radius: 6px;
  background: var(--bg-alt);
}
ul.listing li { border-bottom: 1px solid var(--blue-border); }
ul.listing li:last-child { border-bottom: none; }
ul.listing li a {
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
  padding: 0.65rem 1rem;
  color: var(--text);
  text-decoration: none;
}
ul.listing li a:hover { background: var(--blue-bg); }
ul.listing .icon { font-size: 0.9em; color: var(--muted); flex-shrink: 0; }
ul.listing .title { color: var(--brand); flex: 1; }
ul.listing .filename {
  font-size: 0.8rem;
  color: var(--muted);
  font-family: 'IBM Plex Mono', monospace;
  margin-left: auto;
  white-space: nowrap;
}

/* --- efforts index --- */

.effort-card {
  background: var(--bg-alt);
  border: 1px solid var(--border-soft);
  border-radius: 6px;
  padding: 14px 18px;
  margin-bottom: 10px;
  display: flex;
  align-items: center;
  gap: 14px;
  text-decoration: none;
  color: var(--text);
  transition: box-shadow var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease), transform var(--dur-fast) var(--ease);
}
.effort-card:hover { box-shadow: var(--shadow-md); border-color: var(--brand); transform: translateX(2px); }
.effort-card-id {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.78rem;
  color: var(--muted);
  min-width: 130px;
  flex-shrink: 0;
}
.effort-card-title { font-weight: 600; flex: 1; }
.badge {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.7rem;
  padding: 2px 8px;
  border-radius: 3px;
  white-space: nowrap;
  flex-shrink: 0;
}
.badge-phase { background: var(--blue-bg); color: var(--blue); border: 1px solid var(--blue-border); }
.badge-risk  { background: var(--yellow-bg); color: var(--yellow); border: 1px solid var(--yellow-border); }
.badge-type  { background: var(--bg); color: var(--muted); border: 1px solid #d0c8e8; }
/* --- closed efforts group (collapsible) --- */
.closed-group > summary {
  cursor: pointer;
  display: flex;
  align-items: baseline;
  gap: 0.75rem;
  list-style: none;
  user-select: none;
  padding: 0.75rem 0;
  border-top: 1px solid var(--border-faint);
  color: var(--muted);
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 1rem;
  font-weight: 700;
  transition: color var(--dur-fast);
}
.closed-group > summary:hover { color: var(--brand); }
.closed-group > summary::marker,
.closed-group > summary::-webkit-details-marker { display: none; }
.closed-group > summary .chevron {
  font-size: 0.7rem;
  opacity: 0.5;
  display: inline-block;
  transition: transform var(--dur-fast);
}
.closed-group[open] > summary .chevron { transform: rotate(90deg); }
.closed-group[open] > summary { margin-bottom: 0.75rem; }
.empty-state { color: var(--muted); font-style: italic; font-size: 0.93rem; padding: 8px 0; }

/* --- effort page --- */

.meta-card {
  background: var(--bg-alt);
  border: 1px solid #e0d7f3;
  border-radius: 6px;
  padding: 18px 22px;
  margin-bottom: 2rem;
}
.meta-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 14px;
}
.meta-item label {
  display: block;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.68rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--muted);
  margin-bottom: 3px;
}
.meta-item .meta-value { font-size: 0.95rem; font-weight: 600; color: var(--text); }
.meta-item a { color: var(--brand); text-decoration: none; }
.meta-item a:hover { text-decoration: underline; }
.group-section {
  background: var(--bg-alt);
  border: 1px solid #e0d7f3;
  border-radius: 6px;
  padding: 14px 18px;
  margin-bottom: 14px;
}
.group-section h3 {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.78rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--muted);
  margin: 0 0 10px 0;
}
.group-subdir {
  margin-top: 10px;
  padding-left: 14px;
  border-left: 2px solid #e0d7f3;
}
.group-subdir-label {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--muted);
  margin: 0 0 6px 0;
  font-weight: normal;
}
.file-list { list-style: none; padding: 0; margin: 0; }
.file-list li { padding: 5px 0; border-bottom: 1px solid #ede8f8; }
.file-list li:last-child { border-bottom: none; }
.file-list a { color: var(--brand); text-decoration: none; font-size: 0.93rem; }
.file-list a:hover { text-decoration: underline; }
.file-ext {
  font-family: 'IBM Plex Mono', monospace;
  font-size: 0.7rem;
  color: var(--muted);
  margin-left: 8px;
}

/* --- deployables / capabilities --- */

.index-section { margin-bottom: 2rem; }
.index-section h2 {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 1.15rem;
  color: var(--muted);
  border-bottom: 1px solid #d5c8f0;
  padding-bottom: 0.25rem;
  margin-bottom: 0.75rem;
}
.link-list { list-style: none; padding: 0; margin: 0; }
.link-list li { margin-bottom: 0.4rem; }
.link-list a { color: var(--brand); text-decoration: none; font-size: 1rem; }
.link-list a:hover { text-decoration: underline; }

/* --- section card icons and detail line (homepage) --- */
.section-card { display: flex; flex-direction: column; gap: 0.75rem; }
.section-card-head { display: flex; align-items: center; gap: 0.75rem; }
.section-icon {
  width: 36px; height: 36px;
  background: rgba(133,41,205,0.06); border: 1px solid #e0d7f3;
  border-radius: 6px; display: flex; align-items: center;
  justify-content: center; font-size: 1rem; flex-shrink: 0;
}
.section-detail {
  font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem;
  color: var(--brand); background: var(--brand-alpha06);
  border: 1px solid var(--border-faint); border-radius: 4px;
  padding: 4px 12px; display: inline-block; align-self: flex-start;
  letter-spacing: 0.04em;
}

/* --- phase groups (efforts index) --- */
.phase-group { margin-bottom: 2.5rem; }
.phase-header {
  display: flex; align-items: baseline; gap: 0.75rem;
  margin-bottom: 1rem; padding-bottom: 0.5rem;
  border-bottom: 1px solid #d5c8f0;
}
.phase-header h2 {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 1.15rem; font-weight: 700; color: var(--text);
}

/* --- effort card layout and risk accents --- */
.effort-card.risk-hi { border-left: 3px solid var(--red); }
.effort-card.risk-r2 { border-left: 3px solid var(--yellow); }
.effort-id {
  font-family: 'IBM Plex Mono', monospace; font-size: 0.75rem;
  color: var(--muted); min-width: 180px; flex-shrink: 0;
}
.effort-title { font-size: 0.9rem; font-weight: 600; flex: 1; color: var(--text); }
.effort-badges { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }

/* --- badge variants --- */
.badge-risk-hi  { background: var(--red-bg);    color: var(--red);    border: 1px solid var(--red-border); }
.badge-risk-med { background: var(--yellow-bg); color: var(--yellow); border: 1px solid var(--yellow-border); }
.badge-risk-lo  { background: var(--bg);        color: var(--muted);  border: 1px solid #d0c8e8; }
.badge-count    { background: rgba(133,41,205,0.06); color: var(--brand); border: 1px solid #e0d7f3; font-weight: 600; }
.badge-phase-closed { background: var(--green-bg); color: var(--green); border: 1px solid var(--green-border); }

/* --- deployable / product cards --- */
.card-grid-2 {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
  gap: 1.25rem; margin-top: 1rem;
}
.deployable-card {
  background: var(--bg-alt); border: 1px solid var(--border-soft);
  border-radius: 8px; padding: 1.5rem;
  display: flex; flex-direction: column; gap: 0.75rem;
  transition: box-shadow var(--dur-base) var(--ease), border-color var(--dur-base) var(--ease), transform var(--dur-base) var(--ease);
}
.deployable-card:hover {
  box-shadow: var(--shadow-md);
  border-color: var(--brand); transform: translateY(-2px);
}
.deployable-name {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 1.15rem; font-weight: 700;
}
.deployable-name a { color: var(--brand); text-decoration: none; }
.deployable-name a:hover { text-decoration: underline; }
.deployable-name a:focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }
.deployable-meta { display: flex; align-items: center; gap: 0.75rem; }
.deployable-desc { font-size: 0.88rem; color: var(--muted); line-height: 1.55; }
.quick-links {
  display: flex; flex-wrap: wrap; gap: 6px;
  padding-top: 0.75rem; border-top: 1px solid var(--border-faint); margin-top: auto;
}
.quick-link {
  font-family: 'IBM Plex Mono', monospace; font-size: 0.68rem;
  color: var(--brand); text-decoration: none;
  padding: 3px 12px; border: 1px solid var(--border-faint); border-radius: 4px;
  background: var(--bg); transition: background var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease);
  white-space: nowrap;
}
.quick-link:hover { background: var(--brand-alpha06); border-color: var(--brand); }
.quick-link:focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }

/* --- deployable / capability section card grid --- */
.dep-section-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 0.75rem; margin-top: 0.5rem;
}
.dep-section-card {
  background: var(--bg-alt); border: 1px solid #e0d7f3;
  border-radius: 8px; padding: 1.25rem 1rem;
  text-decoration: none; color: var(--text);
  display: flex; flex-direction: column; align-items: center;
  gap: 0.5rem; text-align: center;
  transition: border-color 0.15s, box-shadow 0.15s, transform 0.12s;
}
.dep-section-card:hover {
  border-color: var(--brand);
  box-shadow: 0 2px 10px rgba(133,41,205,0.10);
  transform: translateY(-2px);
}
.dep-section-card:focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }
.dep-section-icon { font-size: 1.4rem; line-height: 1; }
.dep-section-label {
  font-family: 'IBM Plex Mono', monospace; font-size: 0.72rem;
  font-weight: 600; color: var(--brand);
  letter-spacing: 0.04em; text-transform: uppercase;
}

/* --- document file cards (generic index) --- */
.doc-card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 0.75rem; margin-top: 1rem;
}
.doc-card {
  background: var(--bg-alt); border: 1px solid #e0d7f3;
  border-radius: 8px; padding: 1rem 1.25rem;
  text-decoration: none; color: var(--text);
  display: flex; flex-direction: column; gap: 0.3rem;
  transition: border-color 0.15s, box-shadow 0.15s, transform 0.12s;
}
.doc-card:hover {
  border-color: var(--brand);
  box-shadow: 0 2px 10px rgba(133,41,205,0.10);
  transform: translateY(-2px);
}
.doc-card:focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }
.doc-card-title { font-size: 0.93rem; font-weight: 600; color: var(--brand); }
.doc-card-filename {
  font-family: 'IBM Plex Mono', monospace; font-size: 0.68rem;
  color: var(--muted);
}

/* --- capabilities card grid --- */
.card-grid-3 {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 1rem; margin-top: 1rem;
}
.capability-card {
  background: var(--bg-alt); border: 1px solid #e0d7f3;
  border-radius: 8px; padding: 1.25rem;
  display: flex; flex-direction: column; gap: 0.6rem;
  transition: box-shadow 0.15s, border-color 0.15s, transform 0.12s;
}
.capability-card:hover {
  box-shadow: 0 2px 10px rgba(133,41,205,0.10);
  border-color: var(--brand); transform: translateY(-2px);
}
.capability-name {
  font-family: 'IBM Plex Mono', monospace; font-size: 0.85rem;
  font-weight: 600; color: var(--brand); text-decoration: none;
}
.capability-name:hover { text-decoration: underline; }
.capability-name:focus-visible { outline: 2px solid var(--brand); outline-offset: 2px; }
.capability-card .quick-links { margin-top: auto; }

/* --- site footer --- */
.site-footer {
  margin-top: 3rem; padding: 1.25rem 0;
  border-top: 1px solid #d5c8f0;
  font-family: 'IBM Plex Mono', monospace; font-size: 0.7rem; color: var(--muted);
}

/* --- responsive --- */
@media (max-width: 680px) {
  .container { padding: 1.25rem 1rem; }
  .effort-id { display: none; }
  .effort-card { flex-wrap: wrap; }
  .card-grid-2 { grid-template-columns: 1fr; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { transition-duration: 0.01ms !important; }
}
"""


# ---------------------------------------------------------------------------
# Swagger UI wrapper page generation
# ---------------------------------------------------------------------------

def generate_swagger_page(yaml_path: Path, output_dir: Path, repo_root: Path) -> None:
    """Generate a Swagger UI wrapper HTML page for a YAML OpenAPI contract.

    yaml_path  — absolute Path to the .yaml file (must be inside .forge/)
    output_dir — absolute Path to .forge/site/
    repo_root  — absolute Path to the repository root

    Output path mirrors the .forge/ tree under .forge/site/:
      .forge/efforts/web-docs/spec/api/contract.yaml
        → .forge/site/efforts/web-docs/spec/api/contract-swagger.html
    """
    forge_dir = repo_root / ".forge"

    relative_to_forge = yaml_path.parent.relative_to(forge_dir)
    output_path = output_dir / relative_to_forge / (yaml_path.stem + "-swagger.html")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    swagger_depth = len(output_path.relative_to(output_dir).parts) - 1

    # The YAML url must be relative to the HTTP server root (repo_root),
    # because the server is started from the repo root.
    yaml_url = str(yaml_path.relative_to(repo_root))

    page_title_escaped = html.escape(yaml_path.name)
    yaml_url_escaped = html.escape(yaml_url)

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{page_title_escaped} — forge:docs</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,400;0,8..60,600;1,8..60,300&family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css" />
  {_css_link(swagger_depth)}
  <style>
    body {{ background: var(--bg); }}
    .swagger-ui {{ font-family: 'Source Serif 4', Georgia, serif; }}
    .swagger-ui .topbar {{ display: none; }}
    .swagger-ui .info .title {{ font-family: 'Playfair Display', Georgia, serif; color: var(--text); }}
    .swagger-ui .opblock-tag {{ font-family: 'IBM Plex Mono', monospace; color: var(--text); }}
    #swagger-ui {{ max-width: 960px; margin: 0 auto; padding: 2rem; }}
  </style>
</head>
<body>
  <nav>
    <a class="nav-brand" href="/.forge/site/">forge:docs</a>
    <span class="nav-breadcrumbs" style="margin-left:1rem;color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:0.72rem">{page_title_escaped}</span>
  </nav>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    window.onload = function () {{
      SwaggerUIBundle({{
        url: "{yaml_url_escaped}",
        dom_id: "#swagger-ui",
        presets: [
          SwaggerUIBundle.presets.apis,
          SwaggerUIBundle.SwaggerUIStandalonePreset
        ],
        layout: "BaseLayout"
      }});
    }};
  </script>
</body>
</html>
"""
    output_path.write_text(html_content, encoding="utf-8")


# ---------------------------------------------------------------------------
# File type classification constants (used by traversal)
# ---------------------------------------------------------------------------

FILE_TYPE_MD = "md"
FILE_TYPE_YAML = "yaml"
FILE_TYPE_HTML = "html"
FILE_TYPE_STATE_JSON = "state_json"
FILE_TYPE_IGNORE = "ignore"


def classify_file(p: Path) -> str:
    """Classify a file into one of the known node types."""
    name = p.name
    suffix = p.suffix.lower()
    if name == ".state.json":
        return FILE_TYPE_STATE_JSON
    if suffix == ".md":
        return FILE_TYPE_MD
    if suffix in (".yaml", ".yml"):
        return FILE_TYPE_YAML
    if suffix == ".html":
        return FILE_TYPE_HTML
    return FILE_TYPE_IGNORE


# ---------------------------------------------------------------------------
# Auto-detect repo root
# ---------------------------------------------------------------------------

def find_repo_root(start: Path) -> Optional[Path]:
    """Walk parent directories looking for a .forge/ directory."""
    current = start.resolve()
    while True:
        if (current / ".forge").is_dir():
            return current
        parent = current.parent
        if parent == current:
            return None
        current = parent


# ---------------------------------------------------------------------------
# Single-pass traversal
# ---------------------------------------------------------------------------

def traverse(forge_dir: Path) -> dict:
    """
    Perform a single os.walk() pass over forge_dir, skipping forge_dir/site/.

    Returns a tree dict:
    {
        "path":  Path,        # absolute path to this directory
        "rel":   str,         # path relative to forge_dir (empty str for root)
        "dirs":  [<node>],    # child directory nodes (same structure)
        "files": [
            {
                "path": Path,
                "name": str,
                "type": str,  # FILE_TYPE_* constant
            }
        ],
    }
    """
    site_dir = forge_dir / "site"

    # Index: absolute path → node dict
    dir_nodes: dict[Path, dict] = {}

    root_node: dict = {
        "path": forge_dir,
        "rel": "",
        "dirs": [],
        "files": [],
    }
    dir_nodes[forge_dir] = root_node

    for dirpath_str, dirnames, filenames in os.walk(forge_dir, topdown=True):
        dirpath = Path(dirpath_str)

        # Skip .forge/site/ and everything under it
        if dirpath == site_dir:
            dirnames.clear()
            continue
        try:
            dirpath.relative_to(site_dir)
            dirnames.clear()
            continue
        except ValueError:
            pass

        # Remove "site" from dirnames when at the forge root so os.walk
        # never descends into it (belt-and-suspenders alongside above check)
        if dirpath == forge_dir and "site" in dirnames:
            dirnames.remove("site")

        # Ensure current dir node exists
        if dirpath not in dir_nodes:
            rel = str(dirpath.relative_to(forge_dir))
            node: dict = {
                "path": dirpath,
                "rel": rel,
                "dirs": [],
                "files": [],
            }
            dir_nodes[dirpath] = node
            parent_node = dir_nodes.get(dirpath.parent)
            if parent_node is not None:
                parent_node["dirs"].append(node)

        current_node = dir_nodes[dirpath]

        # Pre-register child dir nodes so they are linkable even before
        # os.walk visits them (maintains sorted order)
        for dname in sorted(dirnames):
            child_path = dirpath / dname
            if child_path not in dir_nodes:
                child_rel = str(child_path.relative_to(forge_dir))
                child_node: dict = {
                    "path": child_path,
                    "rel": child_rel,
                    "dirs": [],
                    "files": [],
                }
                dir_nodes[child_path] = child_node
                current_node["dirs"].append(child_node)

        # Classify and attach files (sorted for determinism)
        for fname in sorted(filenames):
            fpath = dirpath / fname
            ftype = classify_file(fpath)
            current_node["files"].append({
                "path": fpath,
                "name": fname,
                "type": ftype,
            })

    return root_node


# ---------------------------------------------------------------------------
# .gitignore check
# ---------------------------------------------------------------------------

def ensure_server_pid_gitignored(repo_root: Path) -> None:
    """Ensure .forge/site/.server.pid is in .gitignore. Appends if absent."""
    gitignore_path = repo_root / ".gitignore"
    pid_entry = ".forge/site/.server.pid"

    existing_lines: list[str] = []
    if gitignore_path.exists():
        existing_lines = gitignore_path.read_text(encoding="utf-8").splitlines()

    for line in existing_lines:
        if line.strip() == pid_entry:
            return  # Already present

    with gitignore_path.open("a", encoding="utf-8") as fh:
        if existing_lines and existing_lines[-1].strip() != "":
            fh.write("\n")
        fh.write(f"{pid_entry}\n")

    print(f"Added '{pid_entry}' to .gitignore")


# ---------------------------------------------------------------------------
# CSS helpers
# ---------------------------------------------------------------------------

def write_css(output_dir: Path) -> None:
    """Write the consolidated forge-docs.css to output_dir."""
    (output_dir / FORGE_DOCS_CSS_FILENAME).write_text(DESIGN_TOKENS_CSS, encoding="utf-8")


def _css_link(depth: int) -> str:
    """Return a <link> tag pointing to forge-docs.css at the given directory depth.

    depth=0 → href="forge-docs.css"  (site root page)
    depth=1 → href="../forge-docs.css"
    depth=2 → href="../../forge-docs.css"
    """
    prefix = "../" * depth
    return f'<link rel="stylesheet" href="{prefix}{FORGE_DOCS_CSS_FILENAME}">'


# ---------------------------------------------------------------------------
# Copy dynamic shells into site output
# ---------------------------------------------------------------------------

def copy_viewer(skill_dir: Path, output_dir: Path) -> None:
    """Copy viewer.html and index.html from skill_dir/references/ to output_dir."""
    output_dir.mkdir(parents=True, exist_ok=True)
    for name in ("viewer.html", "index.html"):
        src = skill_dir / "references" / name
        if not src.is_file():
            print(
                f"Error: bundled asset '{name}' not found in skill directory "
                f"({skill_dir / 'references'}).\n"
                "The forge:docs skill installation may be incomplete.",
                file=sys.stderr,
            )
            sys.exit(1)
        dst = output_dir / name
        shutil.copy2(str(src), str(dst))


# ---------------------------------------------------------------------------
# Swagger page generation (recursive tree walk)
# ---------------------------------------------------------------------------

def _generate_all_swagger_pages(node: dict, output_dir: Path, repo_root: Path) -> None:
    """Recursively walk tree and call generate_swagger_page for all YAML files."""
    for f in node["files"]:
        if f["type"] == FILE_TYPE_YAML:
            generate_swagger_page(f["path"], output_dir, repo_root)
    for child in node["dirs"]:
        _generate_all_swagger_pages(child, output_dir, repo_root)


# ---------------------------------------------------------------------------
# Main generate() orchestrator
# ---------------------------------------------------------------------------

def generate(repo_root: Path, output_dir: Path, skill_dir: Path) -> None:
    """
    Site generation pass — dynamic mode.

    Copies the dynamic index.html shell, viewer.html, and forge-docs.css into
    output_dir. All per-directory index pages are served dynamically by serve.py
    via the /_api/* endpoints; no static per-directory HTML is generated.
    Swagger UI wrapper pages are still generated for OpenAPI YAML files.
    """
    forge_dir = repo_root / ".forge"
    if not forge_dir.is_dir():
        print(f"Error: .forge/ directory not found under {repo_root}", file=sys.stderr)
        sys.exit(1)

    ensure_server_pid_gitignored(repo_root)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Copy dynamic shells and shared CSS
    copy_viewer(skill_dir, output_dir)
    write_css(output_dir)

    # Swagger pages for all YAML files (still static — Swagger UI needs a wrapper)
    tree = traverse(forge_dir)
    _generate_all_swagger_pages(tree, output_dir, repo_root)

    page_count = sum(1 for _ in output_dir.rglob("*.html"))
    print(f"Site generated: {output_dir}/index.html  ({page_count} pages written)")


# ---------------------------------------------------------------------------
# Server management
# ---------------------------------------------------------------------------

SERVER_PORT = 7477
SERVER_URL = f"http://localhost:{SERVER_PORT}/.forge/site/"


def check_port_available(port: int) -> bool:
    """Return True if port is available to bind, False if already in use."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def start_server(output_dir: Path, repo_root: Path, pid_file: Path) -> bool:
    """Start the HTTP server in the background, write PID file, open browser.

    Returns True on success, False if port is already in use.
    """
    if not check_port_available(SERVER_PORT):
        print(
            f"Error: port {SERVER_PORT} is already in use. "
            "Another server may already be running.",
            file=sys.stderr,
        )
        return False

    # Use the dynamic serve.py which adds /_api/* endpoints
    serve_script = Path(__file__).parent / "serve.py"
    proc = subprocess.Popen(
        ["python3", str(serve_script), "--port", str(SERVER_PORT),
         "--repo-root", str(repo_root)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    pid_file.write_text(str(proc.pid), encoding="utf-8")

    print(f"Site served at: {SERVER_URL}")
    print("To stop: forge:docs --stop")

    webbrowser.open(SERVER_URL)
    return True


def stop_server(pid_file: Path) -> None:
    """Stop the server recorded in pid_file. Silently handle stale PID."""
    if not pid_file.exists():
        print("No server running (no PID file found)")
        return

    pid_text = pid_file.read_text(encoding="utf-8").strip()
    try:
        pid = int(pid_text)
    except ValueError:
        print(f"Invalid PID in {pid_file} — removing file.", file=sys.stderr)
        pid_file.unlink(missing_ok=True)
        return

    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        # Stale PID — process no longer exists; silently clean up
        pass
    except PermissionError as exc:
        print(f"Could not stop server: {exc}", file=sys.stderr)
        return

    pid_file.unlink(missing_ok=True)
    print("Server stopped.")


def is_server_running(pid_file: Path) -> bool:
    """Return True if the server recorded in pid_file is still alive."""
    if not pid_file.exists():
        return False
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
        os.kill(pid, 0)  # signal 0 = existence check only
        return True
    except (ValueError, ProcessLookupError, OSError):
        return False


def find_file(pattern: str, forge_dir: Path) -> list[Path]:
    """Find .md and .yaml/.yml files in forge_dir matching pattern.

    Matching priority:
    1. Exact filename match (e.g. "business.md")
    2. Case-insensitive filename match
    3. Any path fragment match (substring of the repo-relative path)

    Returns a deduplicated, sorted list of matching Paths.
    """
    site_dir = forge_dir / "site"
    pattern_lower = pattern.lower()

    exact: list[Path] = []
    icase: list[Path] = []
    substr: list[Path] = []

    for p in sorted(forge_dir.rglob("*")):
        if not p.is_file():
            continue
        # Skip .forge/site/
        try:
            p.relative_to(site_dir)
            continue
        except ValueError:
            pass
        if classify_file(p) not in (FILE_TYPE_MD, FILE_TYPE_YAML, FILE_TYPE_HTML):
            continue

        name = p.name
        rel_lower = str(p.relative_to(forge_dir)).lower().replace("\\", "/")

        if name == pattern:
            exact.append(p)
        elif name.lower() == pattern_lower:
            icase.append(p)
        elif pattern_lower in rel_lower:
            substr.append(p)

    return exact + icase + substr


def open_file(
    pattern: str,
    repo_root: Path,
    output_dir: Path,
    skill_dir: Path,
    pid_file: Path,
) -> None:
    """Find a file matching pattern and open it in the browser viewer.

    Starts the server first if it is not already running.
    """
    forge_dir = repo_root / ".forge"
    matches = find_file(pattern, forge_dir)

    if not matches:
        print(f"Error: no file matching {pattern!r} found under .forge/", file=sys.stderr)
        sys.exit(1)

    if len(matches) > 1:
        print(f"Multiple files match {pattern!r}:")
        for i, m in enumerate(matches[:5], 1):
            print(f"  {i}. {m.relative_to(repo_root)}")
        if len(matches) > 5:
            print(f"  ... and {len(matches) - 5} more")
        print(f"Opening the first match.")

    target = matches[0]

    # Ensure server is running — start it if not
    if not is_server_running(pid_file):
        print("Docs server is not running — starting it...")
        generate(repo_root, output_dir, skill_dir)
        if not start_server(output_dir, repo_root, pid_file):
            sys.exit(1)
        time.sleep(0.5)  # give the server a moment to bind

    # Build the URL for the target file
    file_param = str(target.relative_to(repo_root)).replace("\\", "/")
    suffix = target.suffix.lower()

    if suffix == ".md":
        url = f"http://localhost:{SERVER_PORT}/.forge/site/viewer.html?file={file_param}"
    elif suffix == ".html":
        # Serve directly — the file is already HTML
        url = f"http://localhost:{SERVER_PORT}/{file_param}"
    else:
        # YAML — open the static Swagger wrapper page
        rel_to_forge = target.parent.relative_to(forge_dir)
        url = f"http://localhost:{SERVER_PORT}/.forge/site/{rel_to_forge}/{target.stem}-swagger.html"

    print(f"Opening: {target.relative_to(repo_root)}")
    webbrowser.open(url)


def handle_serve_prompt(output_dir: Path, repo_root: Path, pid_file: Path) -> None:
    """Prompt the engineer to start a local server; start if they agree."""
    print("Start a local server and open the site? [Y/n]: ", end="", flush=True)
    try:
        answer = input().strip()
    except (EOFError, KeyboardInterrupt):
        answer = "n"

    if answer in ("n", "N"):
        return

    start_server(output_dir, repo_root, pid_file)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="generate.py",
        description="forge:docs — generate a navigable HTML site from .forge/",
    )
    parser.add_argument(
        "--serve",
        action="store_true",
        help="Generate site, start local server on port 7477, and open browser (no prompt).",
    )
    parser.add_argument(
        "--stop",
        action="store_true",
        help="Stop a previously started server (no site generation).",
    )
    parser.add_argument(
        "--repo-root",
        type=pathlib.Path,
        default=None,
        help=(
            "Path to repository root "
            "(default: auto-detect by walking up from cwd to find .forge/)."
        ),
    )
    parser.add_argument(
        "--output",
        type=pathlib.Path,
        default=None,
        help="Output directory (default: <repo-root>/.forge/site).",
    )
    parser.add_argument(
        "--open",
        metavar="PATTERN",
        default=None,
        help=(
            "Open a file in the browser viewer. PATTERN is matched against "
            "filenames and paths under .forge/ (e.g. 'business.md', "
            "'requirements/business.md'). Starts the server automatically "
            "if it is not already running."
        ),
    )

    args = parser.parse_args()

    # Resolve repo root
    if args.repo_root is not None:
        repo_root = args.repo_root.resolve()
        if not (repo_root / ".forge").is_dir():
            print(
                f"Error: no .forge/ directory found at {repo_root}",
                file=sys.stderr,
            )
            sys.exit(1)
    else:
        repo_root = find_repo_root(Path.cwd())
        if repo_root is None:
            print(
                "Error: could not locate a .forge/ directory by walking up "
                "from the current directory.",
                file=sys.stderr,
            )
            sys.exit(1)

    # Resolve output directory
    output_dir: Path = (
        args.output.resolve()
        if args.output is not None
        else repo_root / ".forge" / "site"
    )

    # PID file location
    pid_file = output_dir / ".server.pid"

    # Skill dir (directory containing this script)
    skill_dir = Path(__file__).parent.parent.resolve()

    # --stop: stop only, no generation
    if args.stop:
        stop_server(pid_file)
        return

    # --open: find file and open in browser (starts server if needed)
    if args.open:
        open_file(args.open, repo_root, output_dir, skill_dir, pid_file)
        return

    # Generate site
    generate(repo_root, output_dir, skill_dir)

    # --serve: start server immediately without prompting
    if args.serve:
        start_server(output_dir, repo_root, pid_file)
        return

    # Default (no flags): prompt
    handle_serve_prompt(output_dir, repo_root, pid_file)


if __name__ == "__main__":
    main()
