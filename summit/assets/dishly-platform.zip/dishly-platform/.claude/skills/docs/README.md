# forge:docs

Generates a navigable HTML site from the `.forge/` directory structure.

## Usage

```
forge:docs             # Generate site, then prompt to start local server
forge:docs --serve     # Generate site, start server on port 7477, open browser
forge:docs --stop      # Stop a previously started server
```

## Output

All files are written to `.forge/site/` and committed to version control. The site mirrors the `.forge/` tree with per-type index pages (homepage, efforts, deployables, capabilities, generic directories) and Swagger UI wrappers for OpenAPI YAML files. Markdown files are never duplicated — links open in the bundled `viewer.html` renderer.

## Files

| File | Purpose |
|------|---------|
| `SKILL.md` | Orchestrator instructions for Claude |
| `generate.py` | Python 3.9+ site-generation script (no external dependencies) |
| `viewer.html` | Single-page Markdown renderer (copied into `.forge/site/` on each run) |
