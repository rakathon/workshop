---
name: forge:docs
description: >
  Generate a navigable HTML documentation site from the .forge/ directory, open
  a specific file in the browser, or start and stop the local server. Trigger on:
  "generate the docs site", "build the docs", "show me the requirements", 
  "open the docs for this effort in the viewer", "start the docs server", 
  "stop the docs server", "is the docs server running", "kill the docs server", 
  "open the spec", "show me the ADRs", "forge:docs".
argument-hint: "[--serve] [--stop] [--open <pattern>] [--output <dir>]"
agent-type: orchestrator
---

# forge:docs

Generates a navigable, human-readable HTML site from `.forge/` and serves it
locally. The site is dynamically rendered — navigation pages are built on demand
by a local Python server (`serve.py`) that exposes `/_api/*` endpoints. Markdown
content is rendered in a bundled `viewer.html` via a `?file=` query parameter.
OpenAPI YAML files get static Swagger UI wrapper pages.

---

## Invocation

Four invocation modes are supported:

```
forge:docs                       # Generate site, then prompt to start local server
forge:docs --serve               # Generate site, start server on port 7477, open browser
forge:docs --stop                # Stop a previously started server (no regeneration)
forge:docs --open <pattern>      # Open a specific file in the browser viewer
```

Examples:

- "generate the docs site" → `forge:docs`
- "build the docs and open them" → `forge:docs --serve`
- "stop the docs server" → `forge:docs --stop`
- "open business.md" → `forge:docs --open business.md`
- "show me the requirements for this effort" → `forge:docs --open requirements/business.md`
- "open the API spec" → `forge:docs --open contract.yaml`

---

## Prerequisites

- **Python 3.9+** must be available as `python3`. The script uses only standard
  library modules — no `pip install` is required.
- **HTTP server required for browsing.** The viewer fetches MD files via `fetch()`
  and cannot run from a `file://` URL due to browser CORS restrictions. Always
  serve the site via the local HTTP server started by `--serve` or at the prompt.
- **CDN required for rendering.** The viewer loads `marked.js` and `mermaid.js`
  from a CDN to render Markdown and Mermaid diagrams. An internet connection is
  required for full rendering; the nav pages work offline.

---

## What it generates

`generate.py` copies three files into `.forge/site/` and generates static Swagger
pages for any OpenAPI YAML files found in the `.forge/` tree. All navigation index
pages are served dynamically by `serve.py` — they are not written to disk.

| File | How it's produced |
|------|-------------------|
| `index.html` | Copied from `references/index.html` — a JS shell that fetches `/_api/home` and `/_api/ls` to render each page |
| `viewer.html` | Copied from `references/viewer.html` — a Markdown renderer; opened via `?file=<repo-root-relative-path>` |
| `forge-docs.css` | Written inline — shared design tokens used by all pages |
| `<path>/<name>-swagger.html` | Generated for each OpenAPI YAML file found in `.forge/` |

The dynamic server (`serve.py`) handles:
- `/_api/home` — returns repository summary counts (efforts, deployables, products)
- `/_api/ls?path=<forge-rel>&depth=N` — returns directory listing for any `.forge/` path
- All other requests — static file serving from the repo root

---

## Design tokens

All generated pages use the same CSS variables, fonts, and colour palette as
`forge:arch-review`:

- **Fonts:** Playfair Display (headings), Source Serif 4 (body), IBM Plex Mono (code/mono)
- **Brand colour:** `#8529cd`
- **Background:** `#f9f6fe` (page), `#ffffff` (cards)
- **Status palette:** green `#009470`, red `#b83232`, yellow `#b08000`, blue `#1d4ed8`

All fonts are loaded from Google Fonts CDN; all colours are defined as CSS
variables under `:root` so they cascade consistently.

---

## Implementation steps

### Step 1: Check preconditions

Verify that `python3` is available:

```bash
python3 --version
```

If Python is not found or the version is below 3.9, report the error and stop:

```
Error: forge:docs requires Python 3.9 or later. Found: <version>.
```

Verify that a `.forge/` directory exists by looking for it from the current
working directory upward. If none is found, report:

```
Error: could not locate a .forge/ directory by walking up from the current directory.
```

Verify that the bundled viewer assets exist:

```bash
test -f "$CLAUDE_SKILL_DIR/references/viewer.html" && test -f "$CLAUDE_SKILL_DIR/references/index.html"
```

If either file is missing, report and stop:

```
Error: bundled asset missing from forge:docs skill directory.
The forge:docs installation may be incomplete. Try reinstalling the plugin.
```

### Step 2: Dispatch on invocation mode

The four invocation modes are **mutually exclusive**. Dispatch to exactly one
branch based on the flags present, then stop after that branch completes.

---

#### Mode A — `--stop`

Stop a previously started server. Do not regenerate the site.

```bash
python3 "$CLAUDE_SKILL_DIR/scripts/generate.py" --stop [--repo-root <path>] [--output <dir>]
```

The script reads `<output-dir>/.server.pid` (default: `.forge/site/.server.pid`),
sends SIGTERM, removes the PID file, and prints `Server stopped.` (or
`No server running (no PID file found)` if no PID file exists). If the server
was started with `--output <dir>`, pass the same `--output <dir>` here so the
script finds the correct PID file. Relay the output to the engineer. **Stop here.**

---

#### Mode B — `--open <pattern>`

Open a specific file in the browser. The script handles site generation and
server start automatically if needed — do not invoke `generate.py` separately
first.

Extract a search pattern from the user's message — typically a filename
(`business.md`), a partial path (`requirements/business.md`), or a descriptive
phrase that maps to a filename (e.g. "the API spec" → `contract.yaml`).

```bash
python3 "$CLAUDE_SKILL_DIR/scripts/generate.py" --open "<pattern>" [--repo-root <path>]
```

The script:
1. Searches all `.md` and `.yaml/.yml` files under `.forge/` for the pattern,
   matching first by exact filename, then case-insensitively, then by path substring.
2. If the server is not running, generates the site and starts it automatically.
3. Opens the matched file — `.md` files open in `viewer.html?file=<path>`,
   OpenAPI YAML files open in their pre-generated Swagger UI wrapper page.
4. If multiple files match, opens the first match and lists the others.
5. If no files match, exits with an error.

**Stop here** after the script exits.

---

#### Mode C — `--serve`

Generate the site, start the server on port 7477, and open the browser
immediately without prompting.

```bash
python3 "$CLAUDE_SKILL_DIR/scripts/generate.py" --serve [--repo-root <path>] [--output <dir>]
```

Proceed to Step 3 to relay output.

---

#### Mode D — default (no flags)

Generate the site, then prompt the engineer before starting the server.

```bash
python3 "$CLAUDE_SKILL_DIR/scripts/generate.py" [--repo-root <path>] [--output <dir>]
```

After generation, the script prints:

```
Start a local server and open the site? [Y/n]:
```

Pass the engineer's answer through to the script via standard input. Proceed to
Step 3 to relay output.

---

### Step 3: Report output

After `generate.py` exits successfully, it prints:

```
Site generated: .forge/site/index.html  (<N> pages written)
```

If the server was started, it also prints:

```
Site served at: http://localhost:7477/.forge/site/
To stop: forge:docs --stop
```

Relay these lines to the engineer. If the server was not started, remind them
that a local HTTP server is required to browse the site (CORS prevents
`file://` access).

---

## Flags reference

| Flag | Description |
|------|-------------|
| `--serve` | Generate site, start server on port 7477, open browser (no prompt) |
| `--stop` | Stop a running server; no site generation |
| `--open <pattern>` | Open a file by name/path pattern; starts server automatically if needed |
| `--output <dir>` | Override the output directory (default: `<repo-root>/.forge/site`) |
| `--repo-root <path>` | Override repo root detection (default: walk up from cwd to find `.forge/`) |

---

## Postconditions

| Mode | Expected state after completion |
|------|--------------------------------|
| Default / `--serve` | `.forge/site/` contains `index.html`, `viewer.html`, `forge-docs.css`, and Swagger wrapper pages for any OpenAPI YAML files; server running on port 7477 if started |
| `--open` | As above (site generated if it wasn't already); browser open to the matched file |
| `--stop` | Server process terminated; `.forge/site/.server.pid` removed |

---

## Output

Files written to `.forge/site/` on each run:

```
.forge/site/
├── index.html          # Dynamic JS shell (copied from references/)
├── viewer.html         # Markdown renderer (copied from references/)
├── forge-docs.css      # Shared design token stylesheet
└── <mirrored path>/
    └── <name>-swagger.html   # One per OpenAPI YAML found in .forge/
```

The `.forge/site/.server.pid` file is written by the server at runtime and is
gitignored. On first run, `generate.py` automatically appends
`.forge/site/.server.pid` to `.gitignore` if the entry is not already present.
