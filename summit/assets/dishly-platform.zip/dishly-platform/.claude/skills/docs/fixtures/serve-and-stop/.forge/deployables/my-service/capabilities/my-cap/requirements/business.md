# Business Requirements — my-cap

## BR-1: Capability requirement

A test capability requirement.
