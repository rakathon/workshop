# Business Requirements — my-effort

## BR-1: Test requirement

This is a test business requirement.

**Acceptance criteria:**
- Something works
