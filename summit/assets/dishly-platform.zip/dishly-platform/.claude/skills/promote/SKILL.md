---
name: forge:promote
description: Mark the current phase as approved and advance the effort to the next phase. Use when discovery is complete and ready to move to planning, when a plan is ready to start implementation, or when implementation is done and ready for review. Trigger on: "promote this effort", "approve discovery", "advance to the next phase", "mark discovery approved", "move to planning", "move to implementation", "approve the plan", "we're ready to move on", "I'm done with discovery". Accepts an optional --target <phase> argument to advance multiple phases at once. Only meaningful in the context of a formal Forge effort — if there is no active effort, this is a no-op.
agent-type: orchestrator
argument-hint: "[effort-id] [--target <phase>]"
arguments: [effort_id]
---

# forge:promote

Records that the current phase is approved and advances `currentPhase` to the next
phase in the sequence (or to a specified target phase). This is a tracking and
checkpoint tool — it does not lock artifacts or prevent future edits. Requirements,
specs, and plans remain editable at any point regardless of phase status.

**Phase sequence:** discovery → planning → implementation → verification → review → qa → deployment

**Arguments:**
- `forge:promote [<effort-id>]` — advance one step (current → next), same as before
- `forge:promote [<effort-id>] --target <phase>` — advance to the named target,
  approving all intermediate phases in one operation

Other skills call `forge:promote --target <phase>` at natural workflow transition
points (e.g., forge:plan, forge:commit, forge:verify). This keeps all promotion
logic in one place.

---

## Step 1: Identify the Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-required

If no active effort is found, stop with:
> "No active effort found. forge:promote is only useful in the context of a formal Forge effort."

---

## Step 2: Compute Advancement Target

Read `<effort_dir>/.state.json`. Extract `currentPhase`.

```
PHASE_SEQUENCE = [discovery, planning, implementation, verification, review, qa, deployment]
```

If `--target` was provided:
- `targetPhase` = the provided value
- If `targetPhase` is not in `PHASE_SEQUENCE`: stop — "Unknown phase '<targetPhase>'. Valid phases: discovery, planning, implementation, verification, review, qa, deployment."
- If `targetPhase` is at or before `currentPhase` in the sequence: **exit silently — no-op**
  (The effort is already at or past the target. This is the expected outcome when other skills
  call `forge:promote --target X` and the effort has already advanced past X.)

If `--target` was not provided:
- `targetPhase` = the next phase after `currentPhase` in `PHASE_SEQUENCE`
- If `currentPhase` is already `deployment`: stop — "This effort is already at the final phase."

Build the **gap** — the ordered list of phases to approve:
- All phases from `currentPhase` up to (but not including) `targetPhase`
- Example: currentPhase=discovery, targetPhase=implementation → gap=[discovery, planning]

If gap is empty: exit silently — no changes, no output.

---

## Step 3: Advisory Readiness Checks

For each phase in the gap, show advisory artifact status. These are informational only —
the engineer can proceed regardless.

**discovery in gap:**
- `requirements/business.md` — present or absent
- `requirements/functional.md` — present or absent (advisory; `forge:elaborate` produces this file — absence is noted by `forge:validate` as SUGGESTION)
- `requirements/technical.md` — present or absent
- `spec/` artifacts — which types are present (api, storage, messaging)
- **Validation gate:** if `validation/report.md` is absent:
  > "No validation report found. Run forge:validate before advancing out of
  > discovery? (yes/no/skip)"
  - **yes**: invoke `forge:validate` inline and wait for its report, then continue
  - **no/skip**: note the absence and continue without blocking

**planning in gap:**
- `plan/tasks.md` — present or absent; task count if present

**implementation in gap:**
- Completed vs. remaining task count from `plan/tasks.md` (advisory — does not block)

**All other phases in gap:** no checks needed.

---

## Step 4: Confirm

If the gap contains more than one phase, show the full advancement chain:
```
Advance <phase1> → <phase2> → ... → <targetPhase> for <effort-id>?
<advisory summary from Step 3>
Proceed? (yes/no)
```

If the gap contains exactly one phase (single-step, original behavior):
```
Ready to mark <currentPhase> as approved and advance to <nextPhase>? (yes/no)
```

If the engineer says no: stop, make no changes.
If yes: proceed to Step 5.

---

## Step 5: Apply Promotions

For each phase in the gap (in order), apply the promotion:

1. Read the current `.state.json`
2. Apply:
   ```json
   "phases.<phase>.status": "approved",
   "phases.<phase>.approvedAt": "<ISO-8601 timestamp>",
   "phases.<phase>.approvedBy": "<engineer name if known, else null>",
   "currentPhase": "<nextPhase>",
   "phases.<nextPhase>.status": "in_progress"
   ```
3. Write `.state.json`
4. Update `.forge/efforts/README.md` — phase and status columns for this effort
5. Check the current branch (Step 6 logic) before the first commit only
6. Commit: `chore(<effort-id>): approve <phase> phase`

One commit per phase approved — preserves a clear audit trail when multiple phases
are advanced in a single operation.

Do not modify any other fields. Do not reset or clear artifact fields.

---

## Step 6: Check Branch Before First Commit

Run:
```bash
git branch --show-current
```

If the current branch is the default branch (`main`, `master`, or the repository's
configured default):

1. Warn the engineer:
   > "You are on `<branch>` (the default branch). The promotion checkpoint commit
   > should land on an effort branch, not directly on `<branch>`."
2. Propose an appropriate branch name based on `.forge/branching.md` and `
3. Ask:
   > "Create and switch to `effort/<effort-id>` before committing, or proceed on
   > `<branch>` anyway?"
4. If the engineer chooses to create the branch:
   ```bash
   git checkout -b effort/<effort-id>
   ```
5. If the engineer chooses to proceed on the default branch: continue without switching.

If already on an effort or feature branch: proceed without prompting.

---

## Output

After all promotions are applied:

```
Promoted: <effort-id>
  <phase1>  → approved  (<ISO-8601>)
  <phase2>  → approved  (<ISO-8601>)   [if multi-step]
Now in:   <targetPhase>

Note: approved artifacts remain editable — promotion does not lock them.

Next steps:
  forge:plan <effort-id>        — generate implementation task list  (if now in planning)
  forge:build-api <effort-id>   — begin implementation               (if now in implementation)
  forge:verify <effort-id>      — run implementation verification     (if now in verification)
```

---

## Error Handling

| Condition | Action |
|-----------|--------|
| No active effort found | Stop: "forge:promote is only useful in the context of a formal Forge effort." |
| `--target` is before or equal to `currentPhase` | Stop with clear message |
| Already at `deployment` (no `--target`) | Stop with informational message |
| gap is empty (already at or past target) | Exit silently — no-op |
| `.state.json` write fails | Surface error; do not commit |
