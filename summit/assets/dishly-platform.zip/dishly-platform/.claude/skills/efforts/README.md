# forge:effort

Create a new work effort and scaffold its directory structure under `.forge/efforts/`.

---

## What It Does

`forge:effort` is the entry point for any new piece of development work in a
Forge-managed repository. It:

1. Prompts for title, type, tier, and risk level (or accepts them as arguments)
2. Derives a kebab-case effort ID from the title
3. Creates the effort directory under `.forge/efforts/<id>/` with subdirectories
   appropriate to the effort's tier and subtype
4. Writes `.state.json` with all required fields set
5. Adds a row to the `.forge/efforts/README.md` registry
6. If a parent ID is provided, updates the parent's `childIds` in its `.state.json`
7. Commits all created files atomically

---

## When to Use

Use `forge:effort` whenever you are starting a new unit of tracked development work:

- A new epic, initiative, or program being scoped
- A story or task being pulled into active development
- A spike or PoC to investigate an approach before committing
- A lightweight patch, refactor, or extension to existing functionality

The conversational trigger is any scoping statement: "we need to build X", "I want to
start work on Y", or "create a new effort for Z".

---

## Usage

### Explicit invocation

```
/forge:effort
```

Claude will prompt for the required information interactively.

### Conversational invocation

Claude recognizes scope-setting statements and automatically invokes `forge:effort`:

```
"We need to build a payments API"
"Let's start a spike on Redis caching"
"Create a task for fixing the NPE in PaymentProcessor"
```

### Arguments (all optional — Claude prompts for any that are missing)

| Argument | Description |
|----------|-------------|
| `<title>` | Human-readable effort title |
| `--type` | `program` / `initiative` / `epic` / `story` / `task` / `spike` |
| `--subtype` | `patch` / `refactor` / `extension` / `poc` (lightweight only) |
| `--parent` | ID of the parent effort (e.g., `forge-plugin` or `repo:org/repo/id`) |
| `--risk` | `R1` / `R2` / `R3` / `R4` |
| `--timebox` | Target completion date in ISO-8601 format (e.g., `2026-04-30`) |

---

## What It Creates

### Full-tier effort (program, initiative, epic, or full-tier story/task)

```
.forge/efforts/<id>/
├── .state.json
├── requirements/
│   └── .gitkeep
├── spec/
│   ├── arch-decisions/
│   │   └── .gitkeep
│   ├── api/
│   │   └── .gitkeep
│   ├── messaging/
│   │   └── .gitkeep
│   └── storage/
│       └── .gitkeep
├── plan/
│   └── .gitkeep
├── validation/
│   └── .gitkeep
└── meetings/
    └── .gitkeep
```

Meeting records are organized by month under `meetings/`. Add a subdirectory for
each month as it occurs (e.g., `meetings/2026-03/`). Each meeting produces two files
named with the date, time, and a short description of the meeting type or purpose:

```
meetings/
└── YYYY-MM/
    ├── YYYY-MM-DD-HHMM-<description>-transcript.md
    └── YYYY-MM-DD-HHMM-<description>-summary.md
```

Examples: `2026-03-15-1400-stand-up-transcript.md`, `2026-03-15-1400-stand-up-summary.md`,
`2026-03-18-1000-discuss-auth-flow-summary.md`. The summary is generated from the transcript.

### Spike (full-tier, type = spike)

```
.forge/efforts/<id>/
├── .state.json
└── findings/
    └── .gitkeep
```

### Lightweight extension

```
.forge/efforts/<id>/
├── .state.json
├── requirements/
│   └── .gitkeep
├── spec/
│   ├── arch-decisions/
│   │   └── .gitkeep
│   ├── api/
│   │   └── .gitkeep
│   ├── messaging/
│   │   └── .gitkeep
│   └── storage/
│       └── .gitkeep
└── meetings/
    └── .gitkeep
```

### Lightweight patch, refactor, or poc

```
.forge/efforts/<id>/
└── .state.json
```

---

## Effort Types and Tiers

### Types

| Type | Typical Scope | Default Tier |
|------|--------------|--------------|
| `program` | Cross-team strategic initiative | full |
| `initiative` | Multi-epic project within a program | full |
| `epic` | Significant feature set (weeks to months) | full |
| `story` | Single feature or user-facing behavior | prompted |
| `task` | Technical work item, no direct user story | prompted |
| `spike` | Time-boxed research or investigation | prompted |

### Lightweight subtypes

| Subtype | When to use | Default risk | Default phase |
|---------|-------------|--------------|---------------|
| `patch` | Narrow bug fix or config change | R4 | implementation |
| `refactor` | Internal restructuring, no behavior change | R4 | implementation |
| `extension` | New capability added to an existing feature | prompted | discovery or implementation |
| `poc` | Proof of concept; non-production-bound | R4 | implementation |

---

## Examples

### Create a full-tier epic

```
/forge:effort "Payments API" --type epic --risk R1
```

### Create a lightweight patch from conversation

```
Fix the null pointer exception in PaymentProcessor
```

Claude recognizes the scope, prompts to confirm type = task, suggests lightweight
subtype = patch, defaults risk to R4.

### Create a child story under an existing epic

```
/forge:effort "Implement /v2/payments endpoint" --type story --parent payments-api
```

The new story is added beneath `payments-api` in `.forge/efforts/README.md` and
`payments-api/.state.json` is updated with the new child ID.

### Create a spike with a timebox

```
/forge:effort "Redis caching spike" --type spike --timebox 2026-04-15
```

---

## Prerequisites

- Repository must be initialized: `.forge/README.md` must exist
  (run `forge:init` if it does not)
- If `--parent` is provided, the parent effort should exist in `.forge/efforts/`
  (a missing parent is a warning, not a blocker)

---

## Related Skills

| Skill | When to use after forge:effort |
|-------|-------------------------------|
| `forge:status` | Check the effort's current phase and artifact inventory |
| `forge:promote` | Advance the effort to the next phase |
| `forge:adr` | Record an architecture decision during discovery |
| `forge:plan` | Generate the implementation task plan during planning phase |
| `forge:pause` | Persist mid-session state before stopping work |
