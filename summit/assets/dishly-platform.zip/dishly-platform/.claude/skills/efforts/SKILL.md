---
name: forge:effort
description: Create a new work effort and scaffold the directory structure. Also selects or activates an existing effort as the session-local active effort. Use when starting any new piece of development work — from a small bug fix to a multi-repo initiative. Prompts for title, type (epic/story/task/spike or lightweight subtype), and optional parent effort ID. Trigger on: "I want to start working on a project", "I want to start a new initiative", "I want to create a new epic", "I want to create a new story", "I want to start a new task", "I need to create an effort", "let's kick off a new project", "start a new feature", "create a work item", "I'm starting a new piece of work", "let's begin a new effort", or any intent to begin scoped development work. Also trigger when the engineer selects an effort by number or ID from a list, or says "switch to effort", "activate effort", "set active effort", or "work on effort <id>".
argument-hint: "[--select <effort-id>] [--parent <parent-id>] [--risk <R1|R2|R3|R4>] [--timebox <value>]"
---

# forge:effort

Creates a new work effort under `.forge/efforts/`, writes `.state.json` with all
required fields, and registers the effort in `.forge/efforts/README.md`. The conversational
equivalent is Claude recognizing a scope statement ("we need to build X") and taking
these actions automatically.

Also used to activate an existing effort as the session-local active effort via
`--select <effort-id>` — see [Select Mode](#select-mode) below.

---

## Select Mode

When invoked with `--select <effort-id>` (or when the engineer responds to a numbered
effort list with a number or ID):

1. If the argument is a number N, resolve it to the Nth effort ID from the list that
   was just presented in context. If no list is in context, treat it as an effort ID.
2. Verify `.forge/efforts/<id>/` exists. If not, stop with:
   > "Effort `<id>` not found. Check `.forge/efforts/README.md` for valid effort IDs."
3. Write the effort ID to `.forge/EFFORT`:
   ```bash
   echo "<id>" > .forge/EFFORT
   ```
4. Print: `"Active effort set to: <id>"`
5. Run `forge:status` to show the full effort context.

Do not run any other steps from this skill. Stop after Step 5.

---

## Preconditions

**PC-1: Forge is initialized**

```bash
[ -f ".forge/README.md" ] && echo "ok" || echo "missing"
```

If missing, stop with:
> "This repository has not been initialized for Forge. Run `forge:init` first."

**PC-2: Parent effort exists (if --parent provided)**

If a parent ID is given, check `.forge/efforts/<parent-id>/.state.json` exists.
If missing, warn the engineer:
> "Parent effort '<parent-id>' was not found in .forge/efforts/. The effort will be
> created with a dangling parent reference. Proceed? (yes/no)"
If the engineer answers no, stop. If yes, continue.

**PC-3: No existing effort with the same ID**

After deriving the effort ID (Step 1.2), check:

```bash
[ -d ".forge/efforts/<id>" ] && echo "collision" || echo "ok"
```

If collision, show the existing `.state.json` title and stop with:
> "An effort with ID '<id>' already exists: '<existing-title>'. Use a different
> title or add a disambiguating suffix."

---

## Step 1: Gather Effort Identity

### 1.1 — Prompt for title (if not provided)

If no title was given as an argument, ask:

```
What is the effort title?
```

Wait for the engineer's response.

### 1.2 — Derive the effort ID

Transform the title to a kebab-case ID:

- Lowercase all characters
- Replace spaces and underscores with hyphens
- Strip all characters that are not alphanumeric or hyphens
- Collapse consecutive hyphens to one
- Trim leading and trailing hyphens
- Truncate to 40 characters, trimming at a hyphen boundary if possible

Examples:
- `"Favorites Feature — Backend"` → `"favorites-feature-backend"`
- `"Add /v2/members/:id endpoint"` → `"add-v2-members-id-endpoint"`
- `"Fix: NPE in PaymentProcessor.process()"` → `"fix-npe-in-paymentprocessor-process"`

Record the derived ID. Check PC-3 before continuing.

---

## Step 2: Determine Effort Classification

### 2.1 — Prompt for type (if not provided)

If no type was given, ask:

```
What type of work item is this?

  program       — cross-team strategic initiative (largest scope)
  initiative    — multi-epic project within a program
  epic          — significant feature set (weeks to months)
  story         — single feature or user-facing behavior change
  task          — technical work item, no direct user story
  spike         — time-boxed research or technical investigation

Enter type:
```

Wait for the engineer's response. If invalid, re-prompt once, then stop with an error.

### 2.2 — Determine tier

- `program`, `initiative`, `epic` → `tier = "full"` (no prompt needed)
- `story`, `task`, `spike` → ask:

  ```
  Is this a full-tier effort (complete discovery/planning/verification cycle) or
  lightweight (reduced process for contained work)?

    full        — story/task requires discovery, arch review, planning, verification
    lightweight — reduced process for patches, refactors, extensions, or PoCs

  Enter full or lightweight:
  ```

### 2.3 — Prompt for subtype (lightweight only)

If `tier = "lightweight"`, ask:

```
What is the lightweight subtype?

  patch       — narrow bug fix or config change; no discovery, no planning, no QA
  refactor    — internal restructuring with no behaviour change; planning optional
  extension   — adds new capability to existing feature; discovery optional
  poc         — proof of concept; non-production-bound, no QA required

Enter subtype:
```

Record `subtype`. For `tier = "full"`, set `subtype = null`.

### 2.4 — Determine productionBound

- `subtype = "poc"` → `productionBound = false`
- All other types and subtypes → `productionBound = true`

---

## Step 3: Determine Risk Classification

### 3.1 — Apply defaults or prompt

- `tier = "full"`: prompt the engineer:

  ```
  What is the risk level?

    R1 — Critical: authentication, payments, data migrations, PII
    R2 — High: core features, external integrations
    R3 — Moderate: new features, UI updates
    R4 — Low: logging, minor changes, documentation

  Enter R1, R2, R3, or R4:
  ```

- `subtype = "patch"` or `subtype = "poc"`: default to `R4` without prompting.
  Print: "Risk defaulted to R4 for <subtype> efforts."

- `subtype = "refactor"`: default to `R4` without prompting.
  Print: "Risk defaulted to R4 for refactor efforts."

- `subtype = "extension"`: prompt as above (scope may vary from R1 to R4).

If `--risk` was passed as an argument, use it directly without prompting.

---

## Step 3.5: Associate Jira Ticket [orchestrator-only]

This step links the effort to a Jira ticket. The Atlassian MCP
(`mcp__plugin_forge_atlassian__*`) is installed as part of the Forge plugin and is
always available — but may require authentication before its tools work.

### 3.5.0 — Ensure Atlassian authentication

Call `mcp__atlassian__atlassianUserInfo` to check whether the session is already
authenticated:

- **If the call succeeds** (returns a user object): authentication is active.
  Print: `Atlassian: authenticated as <displayName>` and proceed to 3.5.1.

- **If the call fails or returns an auth error**: the session needs to authenticate.
  Do NOT skip — guide the engineer through the OAuth flow:

  **Step 1 — Start the flow:**
  ```
  mcp__plugin_forge_atlassian__authenticate()
  ```
  This returns an authorization URL. Present it to the engineer:
  ```
  Atlassian authentication required.

  Open this URL in your browser to authorize Forge:
    <authorization_url>

  After authorizing, your browser will redirect to a localhost callback URL
  that fails to load — that's expected. Copy the full URL from the address bar
  and paste it here:
  ```

  Wait for the engineer to paste the callback URL.

  **Step 2 — Complete the flow:**
  ```
  mcp__plugin_forge_atlassian__complete_authentication({ callback_url: "<pasted-url>" })
  ```

  If this succeeds: print `Atlassian: authenticated successfully` and proceed to 3.5.1.

  If this fails (bad callback URL, expired code, etc.): show the error and offer:
  ```
  Authentication failed. Would you like to try again, or skip Jira association for now?
  [retry/skip]:
  ```
  - `retry` → repeat from Step 1
  - `skip` → set `jiraKey = null`, `jiraUrl = null`, print a warning, and jump to Step 4

### 3.5.1 — Determine whether to prompt

| Condition | Action |
|-----------|--------|
| `subtype = "poc"` | Skip — PoCs are non-production; skip silently, set `jiraKey = null` |
| All other types and subtypes | Prompt as below |

### 3.5.2 — Present Jira options

```
Do you have a Jira ticket for this effort?

  1. Yes — I have an existing ticket
  2. No  — Create one now
  3. Skip — No Jira association (not recommended)

Enter 1, 2, or 3 [1]:
```

Wait for the engineer's response.

---

#### Option 1 — Engineer provides an existing ticket

Ask:
```
Enter the Jira ticket URL or key (e.g. REWD-1234 or https://...):
```

Accept either a bare key (`PROJ-123`) or a full URL. If a URL is provided, extract
the key from the last path segment (the part matching `[A-Z]+-[0-9]+`).

Fetch the ticket to confirm it exists and is accessible:

```
mcp__plugin_forge_atlassian__getJiraIssue({ issueIdOrKey: "<key>" })
```

If the call succeeds: record `jiraKey = "<key>"`, `jiraUrl = "<url>"`, and print:
```
Linked: <key> — <issue summary>
```

If the call fails (not found or no access): warn the engineer:
```
⚠️  Could not fetch <key>. Ticket may not exist or you may not have access.
Proceed with this key anyway, or enter a different one? [proceed/retry]:
```
On "proceed": store the key as-is. On "retry": re-prompt once.

---

#### Option 2 — Create a new Jira ticket

**2a. Determine ticket type from effort type:**

| Effort type / subtype | Jira issue type |
|-----------------------|-----------------|
| `program` | Epic |
| `initiative` | Epic |
| `epic` | Epic |
| `story` (full tier) | Story |
| `task` (full tier) | Task |
| `spike` (full tier) | Task |
| `extension` (lightweight) | Task |
| `refactor` (lightweight) | Task |
| `patch` (lightweight) | Task |

**2b. Determine the parent ticket (Epic or Initiative link):**

For **Epic** type: no parent required. Skip to 2c.

For **Story** or **Task**: ask:
```
Enter the parent Epic or Initiative URL/key to create this ticket under
(or press Enter to create without a parent):
```

If provided, fetch it to validate:
```
mcp__plugin_forge_atlassian__getJiraIssue({ issueIdOrKey: "<parent-key>" })
```

If the parent is found, record `parentJiraKey`. If not found, warn and offer to
proceed without a parent.

**2c. Determine the Jira project:**

If a parent was provided, use its project key (the prefix before `-`).

If no parent: ask:
```
Enter the Jira project key (e.g. REWD, PLAT):
```

**2d. Confirm ticket details before creating:**

Show a preview and ask for confirmation:
```
Creating Jira <issue-type>:
  Project: <project-key>
  Summary: <effort title>
  Type:    <issue-type>
  Parent:  <parent-key or "none">

Create this ticket? [Y/n]:
```

**2e. Create the ticket:**

```
mcp__plugin_forge_atlassian__createJiraIssue({
  projectKey: "<project-key>",
  summary: "<effort title>",
  issueType: "<issue-type>",
  parentKey: "<parent-key or omit>"
})
```

On success: record `jiraKey`, `jiraUrl` from the response, and print:
```
Created: <key> — <effort title>
  URL: <url>
```

On failure: warn the engineer, set `jiraKey = null`, and continue.

---

#### Option 3 — Skip

Set `jiraKey = null`, `jiraUrl = null`. Print:
```
⚠️  No Jira ticket associated. Link one later by updating .state.json manually.
```

### 3.5.3 — Record the result

Store `jiraKey` and `jiraUrl` for use in:
- Step 6.3 (`.state.json` fields)
- Step 9 (branch name derivation — `.forge/branching.md` prose may use the Jira key)

---

## Step 4: Determine Phase Starting Point

Set `currentPhase` based on tier and subtype:

| Condition | `currentPhase` |
|-----------|----------------|
| Full-tier (program/initiative/epic/story/task) | `"discovery"` |
| Full-tier spike | `"investigation"` |
| Lightweight `patch` | `"implementation"` |
| Lightweight `refactor` | `"implementation"` |
| Lightweight `extension` | ask the engineer: "Is the scope of this extension non-trivial enough to warrant a discovery phase? (yes/no)". If yes → `"discovery"`, if no → `"implementation"` |
| Lightweight `poc` | `"implementation"` |

---

## Step 5: Scaffold the Effort Directory [orchestrator-only]

Create only the base directory. Subdirectories are created on demand by the skills
that write to them (`forge:elaborate`, `forge:spec-*`, `forge:plan`, etc.).

```bash
mkdir -p .forge/efforts/<id>
```

---

## Step 6: Write .state.json [orchestrator-only]

Construct the `.state.json` object. All keys must be sorted alphabetically at every
nesting level. Arrays use one-item-per-line formatting. Use 2-space indentation.
No trailing commas.

### 6.1 — Obtain current timestamp

```bash
created_at=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
```

### 6.2 — Build the phases object

Include only phases appropriate for this effort's tier and subtype:

**Full-tier (not spike):**
```json
"phases": {
  "discovery": {
    "approvedAt": null,
    "approvedBy": null,
    "artifacts": {
      "adrsCreated": [],
      "requirements": {
        "business": "absent",
        "technical": "absent"
      },
      "spec": {
        "api": "absent",
        "messaging": "absent",
        "storage": "absent"
      }
    },
    "postApprovalModifications": [],
    "status": "not_started"
  },
  "implementation": {
    "checkpoint": {
      "activeSkill": null,
      "lastCompletedStep": null,
      "updatedAt": null
    },
    "completedTasks": [],
    "postApprovalModifications": [],
    "remainingTasks": [],
    "status": "not_started"
  },
  "planning": {
    "artifacts": [],
    "postApprovalModifications": [],
    "status": "not_started"
  },
  "qa": {
    "postApprovalModifications": [],
    "status": "not_started"
  },
  "review": {
    "postApprovalModifications": [],
    "status": "not_started"
  },
  "validation": {
    "artifacts": [],
    "status": "not_started"
  },
  "verification": {
    "artifacts": {
      "report": "absent"
    },
    "postApprovalModifications": [],
    "status": "not_started"
  }
}
```

**Full-tier spike:**
```json
"phases": {
  "findings": {
    "status": "not_started"
  },
  "investigation": {
    "status": "not_started"
  }
}
```

**Lightweight patch or poc:**
```json
"phases": {
  "implementation": {
    "checkpoint": {
      "activeSkill": null,
      "lastCompletedStep": null,
      "updatedAt": null
    },
    "completedTasks": [],
    "postApprovalModifications": [],
    "remainingTasks": [],
    "status": "not_started"
  }
}
```

**Lightweight refactor:**
```json
"phases": {
  "implementation": {
    "checkpoint": {
      "activeSkill": null,
      "lastCompletedStep": null,
      "updatedAt": null
    },
    "completedTasks": [],
    "postApprovalModifications": [],
    "remainingTasks": [],
    "status": "not_started"
  },
  "planning": {
    "artifacts": [],
    "postApprovalModifications": [],
    "status": "not_started"
  }
}
```

**Lightweight extension:**
```json
"phases": {
  "discovery": {
    "approvedAt": null,
    "approvedBy": null,
    "artifacts": {
      "adrsCreated": [],
      "requirements": {
        "business": "absent",
        "technical": "absent"
      },
      "spec": {
        "api": "absent",
        "messaging": "absent",
        "storage": "absent"
      }
    },
    "postApprovalModifications": [],
    "status": "not_started"
  },
  "implementation": {
    "checkpoint": {
      "activeSkill": null,
      "lastCompletedStep": null,
      "updatedAt": null
    },
    "completedTasks": [],
    "postApprovalModifications": [],
    "remainingTasks": [],
    "status": "not_started"
  },
  "planning": {
    "artifacts": [],
    "postApprovalModifications": [],
    "status": "not_started"
  }
}
```

### 6.3 — Write the file

Write `.forge/efforts/<id>/.state.json` with this structure (keys alphabetical):

```json
{
  "childIds": [],
  "coordinationRef": null,
  "currentPhase": "<currentPhase>",
  "deployables": [],
  "graduation": {
    "graduated": false,
    "graduatedAt": null,
    "graduatedTo": []
  },
  "id": "<id>",
  "jiraKey": <jiraKey or null>,
  "jiraUrl": <jiraUrl or null>,
  "openDecisions": [],
  "parentId": <parentId or null>,
  "phases": { ... },
  "productionBound": <true or false>,
  "risk": "<risk>",
  "spawnedWorkItems": [],
  "subtype": <subtype or null>,
  "tier": "<tier>",
  "timebox": <timebox or null>,
  "title": "<title>",
  "type": "<type>",
  "upstreamProposals": []
}
```

Substitute all `<placeholder>` values with the actual values determined in Steps 1–4.
For `parentId`: use the value from `--parent` if provided, otherwise `null`.
For `timebox`: use the value from `--timebox` if provided, otherwise `null`.
For `jiraKey` and `jiraUrl`: use the values from Step 3.5, or `null` if skipped.

---

## Step 7: Update .forge/efforts/README.md [orchestrator-only]

Read `.forge/efforts/README.md` and append a new row to the efforts table.

### 7.1 — Determine row indentation

- If no parent: add the row at the end of the table with no indentation.
- If parent provided:
  - Find the parent's row in the table.
  - Determine the parent's indentation level (count leading `→ ` tokens).
  - Add one more `→ ` level to the new row.
  - Insert the new row immediately after the parent's last existing child row
    (or immediately after the parent's own row if no children exist yet).

### 7.2 — Row format

```
| <indent><id> | <title> | <type> | <tier> | <risk> | <parent-id or blank> | <currentPhase> | not_started |
```

Where `<indent>` is zero or more `→ ` prefixes (one per hierarchy level) and
`<parent-id>` is the ID of the parent effort (blank for root-level efforts).

Example rows:
```
| forge-plugin | Forge Framework | program | full | R2 |  | discovery | not_started |
| → forge-workflow | Forge Workflow | initiative | full | R2 | forge-plugin | discovery | not_started |
| → → payments-api | Payments API | epic | full | R1 | forge-workflow | discovery | not_started |
```

Use the Edit tool to insert the new row — do not rewrite the entire file.

---

## Step 8: Update Parent .state.json (if parent provided) [orchestrator-only]

If a parent ID was provided and the parent effort was found:

1. Read `.forge/efforts/<parent-id>/.state.json`
2. Add the new effort's ID to the `childIds` array (one item per line)
3. Write the updated `.state.json` back to disk

If the parent ID uses the `repo:` cross-repo prefix format, skip this step and note:
> "Cross-repo parent detected — childIds in the remote repository cannot be updated
> automatically. Update the parent effort's .state.json manually."

---

## Step 9: Create and Checkout the Working Branch [orchestrator-only]

After the scaffold commit completes, create (or resume) the working branch for this effort.

### 9.0.1 — Derive the branch name

Check whether `.forge/branching.md` exists:

```bash
[ -f ".forge/branching.md" ] && echo "present" || echo "absent"
```

**If present:**
Read the full file (both frontmatter and prose body) using the Read tool.
Derive an appropriate branch name by interpreting the prose body. Inputs available:
- Effort title (from Step 1.1)
- Effort type (from Step 2.1)
- Effort ID (from Step 1.2)
- Jira key from `.forge/efforts/<id>/.state.json` field `jiraKey` (if present and non-null)

Apply the naming convention as described in the prose body. The derived branch name
must satisfy the `branch_regex` frontmatter field if one is present.

**If absent:**
Run again `forge:init` to define `.forge/branching.md`

### 9.0.2 — Create the branch

```bash
git checkout -b <branch_name>
```

Replace `<branch_name>` with the name derived in Step 9.0.1.

### 9.0.3 — Handle existing branch (effort being resumed)

If the branch already exists, git will return a non-zero exit code with a message like
`fatal: A branch named '<branch_name>' already exists`. In that case, run:

```bash
git checkout <branch_name>
```

This is idempotent — switching to an existing branch is safe.

### 9.0.4 — Confirm to the engineer

- If the branch was created: `"Working branch: <branch_name> (created)"`
- If the branch already existed: `"Working branch: <branch_name> (resumed)"`

---

## Step 9.5: Commit Atomically [orchestrator-only]

Stage and commit all created files of .forge in a single commit:

```bash
git add .forge/efforts/<id>/
git add .forge/efforts/README.md
```

If a same-repo parent was updated:

```bash
git add .forge/efforts/<parent-id>/.state.json
```

Commit:

```bash
git commit -m "chore(<id>): scaffold <title> effort"
```

---

### 10 — Record active effort pointer

Write the effort ID to `.forge/EFFORT`:

```bash
echo "<id>" > .forge/EFFORT
```

This file is gitignored (added by `forge:init` and `forge:update`) and serves as
the session-local pointer to the active effort. Skills read this file to identify
the active effort without parsing branch names.

Print: "Active effort: <id>"

## Step 11: Print Summary [orchestrator-only]

Print a human-readable summary:

```
Effort created: <id>
Title:          <title>
Type:           <type> | Tier: <tier> | Risk: <risk>
Subtype:        <subtype if set, else "full-tier">
Production-bound: <yes | no>
Phase:          <currentPhase>
Directory:      .forge/efforts/<id>/
Branch:         <branch_name> (<created | resumed>)
Jira:           <jiraKey — <jiraUrl> | not linked>

Next steps:
  <Appropriate next action based on type, tier, and currentPhase>
```

Always print as the next step:
```
Run `forge:elaborate` to work through requirements and reach a shared understanding of the solution before writing any code.
```

If parent was updated, also print:
```
Parent updated: .forge/efforts/<parent-id>/.state.json (childIds)
```
