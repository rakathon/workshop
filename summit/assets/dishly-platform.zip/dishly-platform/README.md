# dishly

Curated restaurant discovery and food delivery — Wave 1 closed beta.

dishly connects editorial curation with native ordering in a single continuous experience. Every restaurant is placed here by someone who knows food, not paid placement.

---

## Product Artifacts

| Artifact | Link |
|----------|------|
| **Competitive Brief** | [initial-landscape-2026-06-05.md](.forge/products/dishly/competitive/initial-landscape-2026-06-05.md) |
| **Product Vision** | [vision.md](.forge/products/dishly/vision.md) |
| **Product Strategy** | [strategy.md](.forge/products/dishly/strategy.md) |
| **Wave 1 PRD** | [prd.md](.forge/efforts/dishly-wave-1/requirements/prd.md) |
| **Business Requirements** | [business.md](.forge/efforts/dishly-wave-1/requirements/business.md) |
| **User Stories** | [user-stories.md](.forge/efforts/dishly-wave-1/requirements/user-stories.md) |
| **Technical Requirements** | [technical.md](.forge/efforts/dishly-wave-1/requirements/technical.md) |
| **OpenAPI Spec** | [dishly.yaml](.forge/efforts/dishly-wave-1/spec/api/dishly.yaml) |
| **Storage Schema** | [logical-schema.md](.forge/efforts/dishly-wave-1/spec/storage/logical-schema.md) |
| **ADR-001** — User URI structure | [ADR-001](.forge/efforts/dishly-wave-1/spec/arch-decisions/ADR-001-user-uri-structure.md) |
| **ADR-002** — Normalized order items | [ADR-002](.forge/efforts/dishly-wave-1/spec/arch-decisions/ADR-002-normalized-order-items-table.md) |
| **Wireframes** | [wireframe.html](.forge/efforts/dishly-wave-1/spec/ux/wireframe.html) · [🔗 Live](https://rr-productivity-portal-prod.shared.rr-it.com/design-previews/rr-paras-patel/dishly-wireframes/wireframe.html) |
| **Hi-fi Mockup** | [mockup.html](.forge/efforts/consumer-web-discovery/spec/ux/mockup.html) · [🔗 Live](https://rr-productivity-portal-prod.shared.rr-it.com/design-previews/rr-paras-patel/dishly-hifi-mockup/mockup.html) |
| **Personas & Journeys** | [personas-and-journeys.html](design/personas-and-journeys.html) · [🔗 Live](https://rr-productivity-portal-prod.shared.rr-it.com/design-previews/rr-paras-patel/dishly-personas/personas-and-journeys.html) |
| **User Flows** | [user-flows.html](design/user-flows.html) · [🔗 Live](https://rr-productivity-portal-prod.shared.rr-it.com/design-previews/rr-paras-patel/dishly-user-flows/user-flows.html) |
| **Test Plan** | [docs/TEST-PLAN.md](docs/TEST-PLAN.md) — 176 scenarios across 10 suites |
| **UI E2E Test Suite** (26 scenarios, Wave 1) | [ui-e2e-test-suite.md](.forge/products/dishly/test/ui-e2e-test-suite.md) |
| **E2E Test Suite** (Wave 1) | [e2e-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/e2e-test-suite.md) |
| **Acceptance Test Suite** (Wave 1) | [acceptance-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/acceptance-test-suite.md) |
| **Integration Test Suite** (Wave 1) | [integration-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/integration-test-suite.md) |
| **Contract Test Suite** (Wave 1) | [dishly-contract-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/dishly-contract-test-suite.md) |
| **UI E2E Test Suite** (Customer Profile) | [ui-e2e-test-suite.md](.forge/efforts/customer-profile-section/spec/test/ui-e2e-test-suite.md) |
| **E2E Test Suite** (Customer Profile) | [e2e-test-suite.md](.forge/efforts/customer-profile-section/spec/test/e2e-test-suite.md) |
| **Integration Test Suite** (Customer Profile) | [integration-test-suite.md](.forge/efforts/customer-profile-section/spec/test/integration-test-suite.md) |
| **Contract Test Suite** (Customer Profile) | [profile-contract-test-suite.md](.forge/efforts/customer-profile-section/spec/test/profile-contract-test-suite.md) |
| **Gherkin Feature Files** (10 areas) | [features/us/](features/us/) |
| **Playwright Specs** (10 spec files) | [e2e/tests/](e2e/tests/) |
| **API / E2E Tests** (Jest + Supertest) | [backend/__tests__/](backend/__tests__/) |

---

## Screenshots

📸 [View all product screenshots](docs/SCREENSHOTS.md) · 📄 [Download PDF](docs/screenshots/dishly-product-screenshots.pdf)

---

## Quick Start

```bash
./start.sh
```

The script kills any stale processes on ports 3000/3001, applies all DB migrations, seeds 100 NYC restaurants on first run, and boots both services:

| Service | URL |
|---------|-----|
| Frontend (React) | http://localhost:3000 |
| Backend API | http://localhost:3001/dishly/v1 |

**Requirements:** Node.js LTS. No Docker. No cloud. No manual setup.

---

## Project Structure

```
dishly-platform/
├── backend/                  # Node.js + Express API
│   ├── src/
│   │   ├── db/               # SQLite connection, migrations, seed
│   │   ├── middleware/       # JWT auth (requireAuth, signToken)
│   │   └── routes/           # REST handlers — auth, users, addresses,
│   │                         #   payment_methods, restaurants, orders
│   └── __tests__/            # Jest + Supertest API tests (35 tests, 5 suites)
├── frontend/                 # React + Vite SPA
│   └── src/
│       ├── api/              # Fetch client + custom hooks
│       ├── components/       # NavBar, RestaurantCard, shared UI
│       ├── hooks/            # useCart (localStorage + cross-tab sync)
│       └── pages/            # All 11 routes incl. Account, OrderConfirmation
├── e2e/                      # Playwright UI tests (76 scenarios, 11 spec files)
├── features/                 # Gherkin BDD feature files (48 scenarios)
├── data/                     # collections.json, SQLite DB
├── design/                   # Wireframes, hi-fi mockups, personas
├── .forge/                   # Forge framework — PRDs, specs, efforts, test suites
└── start.sh                  # Single-command launcher (kills ports, runs migrations)
```

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19, Vite 8, React Router v7 |
| Backend | Node.js, Express 4 |
| Database | SQLite via `better-sqlite3` |
| Auth | JWT (`jsonwebtoken`), bcrypt |
| Payment | Stripe test mode (mock card flow at checkout) |
| E2E tests | Playwright |
| API tests | Jest + Supertest |
| Dev launcher | `concurrently` |

---

## API

All endpoints are prefixed `/dishly/v1/`. Responses use a `{data, meta}` envelope.

### Discovery (anonymous)
```
GET /restaurants              # search + filter (q, cuisine_id, neighbourhood_id, price_range)
GET /restaurants/:id          # full detail with menu sections and reviews
GET /collections              # curated collections with embedded restaurants
GET /cuisines                 # alphabetical cuisine list
GET /neighbourhoods           # city list (10 cities: 5 NYC + 5 US cities)
```

### Auth
```
POST /auth/register           # { email, password, name? } → { user, token }
POST /auth/login              # { email, password } → { user, token }
GET  /users/me                # bearer → full profile (name, phone, email)
PATCH /users/me               # bearer → update name and/or phone
```

### Profile (bearer required)
```
GET    /users/me/addresses          # list saved delivery addresses (max 2)
POST   /users/me/addresses          # add address { label?, street, city, postcode, is_default? }
PATCH  /users/me/addresses/:id      # update address fields
DELETE /users/me/addresses/:id      # remove address

GET    /users/me/payment_methods          # list saved mock payment methods (max 2)
POST   /users/me/payment_methods          # add method { card_type, cardholder_name }
PATCH  /users/me/payment_methods/:id      # update payment method
DELETE /users/me/payment_methods/:id      # remove payment method
```

### Orders (bearer required)
```
POST /orders                  # place order → 201 { order }
GET  /orders/:id              # order detail (owner only)
GET  /users/me/orders         # order history (newest first)
```

---

## Running Tests

### Backend (Jest + Supertest)

```bash
cd backend && npm test
```

35 tests across 5 suites — in-memory SQLite, no external dependencies.

| Suite | Tests | Covers |
|-------|-------|--------|
| `orders.post.test.js` | 5 | POST /orders |
| `orders.get.test.js` | 3 | GET /orders/:id |
| `users.orders.test.js` | 3 | GET /users/me/orders |
| `profile.integration.test.js` | 16 | Profile schema, CRUD, auth, cap enforcement |
| `location.integration.test.js` | 11 | Neighbourhood API + city filter |

### E2E (Playwright)

```bash
./start.sh &
cd e2e && npx playwright test --project=chromium
```

76 scenarios across 11 spec files covering homepage, search, restaurant menu + quantity stepper, cart, checkout (address pre-fill, dummy card), orders, auth, account profile (name/phone/addresses/payment methods), and global chrome.

---

## SWE Reference

Engineering artifacts for the current codebase. Start here when onboarding or picking up a ticket.

### Customer Profile Section

| Artifact | What it covers |
|----------|---------------|
| [PRD](.forge/efforts/customer-profile-section/requirements/prd.md) | Problem, goals, non-goals, success metrics |
| [Business Requirements](.forge/efforts/customer-profile-section/requirements/business.md) | BR-1..BR-7 with acceptance criteria (MoSCoW) |
| [Technical Requirements](.forge/efforts/customer-profile-section/requirements/technical.md) | TR-1..TR-7: schema, auth, validation, reactive state |
| [User Stories](.forge/efforts/customer-profile-section/requirements/user-stories.md) | Connextra stories grouped by persona |
| [API Spec — profile.yaml](.forge/efforts/customer-profile-section/spec/api/profile.yaml) | OpenAPI 3.1 contract for all profile endpoints |
| [Storage Spec — sqlite.sql](.forge/efforts/customer-profile-section/spec/storage/sqlite.sql) | Physical schema: user_address, user_payment_method |
| [Query Patterns](.forge/efforts/customer-profile-section/spec/storage/query-patterns.md) | All DB access patterns with source traceability |
| [UX Strategy](.forge/efforts/customer-profile-section/spec/ux/ux-strategy.md) | Screen inventory, flows, interaction notes, a11y |
| [Hi-fi Mockup](.forge/efforts/customer-profile-section/spec/ux/mockup.html) | Interactive mockup (22 UI states, dishly tokens) |
| [Wireframe](.forge/efforts/customer-profile-section/spec/ux/wireframe.html) | Low-fidelity structure reference |
| [Implementation Plan](.forge/efforts/customer-profile-section/plan/tasks.md) | 14 tasks across 5 waves with traceability |
| [Verification Report](.forge/efforts/customer-profile-section/verification/report.md) | forge:verify PASS — 14/14 requirements |
| [Validation Report](.forge/efforts/customer-profile-section/validation/report.md) | forge:validate PASS WITH CONCERNS — 4 suggestions |

### Location-Based Filtering

| Artifact | What it covers |
|----------|---------------|
| [PRD](.forge/efforts/add-location-based-filtering/requirements/prd.md) | Problem, goals, non-goals, success metrics |
| [Business Requirements](.forge/efforts/add-location-based-filtering/requirements/business.md) | BR-1..BR-4: city filter, combobox, Near me, seed expansion |
| [Technical Requirements](.forge/efforts/add-location-based-filtering/requirements/technical.md) | TR-1..TR-5: no schema change, client-side filter, bounding boxes |
| [API Spec — location-filter.yaml](.forge/efforts/add-location-based-filtering/spec/api/location-filter.yaml) | GET /neighbourhoods + GET /restaurants with neighbourhood_id |
| [UX Strategy](.forge/efforts/add-location-based-filtering/spec/ux/ux-strategy.md) | City selector IA, flows, all states |
| [Implementation Plan](.forge/efforts/add-location-based-filtering/plan/tasks.md) | 9 tasks across 3 waves |

### Test Suites

| Suite | Scenarios | Type | File |
|-------|-----------|------|------|
| E2E system scenarios | 17 | System E2E | [e2e-test-suite.md](.forge/efforts/customer-profile-section/spec/test/e2e-test-suite.md) |
| UI E2E scenarios | 22 | Playwright | [ui-e2e-test-suite.md](.forge/efforts/customer-profile-section/spec/test/ui-e2e-test-suite.md) |
| API contract scenarios | 20 | Contract | [profile-contract-test-suite.md](.forge/efforts/customer-profile-section/spec/test/profile-contract-test-suite.md) |
| Integration scenarios | 16 | DB integration | [integration-test-suite.md](.forge/efforts/customer-profile-section/spec/test/integration-test-suite.md) |
| Wave 1 E2E suite | 35 | System E2E | [e2e-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/e2e-test-suite.md) |
| Wave 1 contract suite | — | Contract | [dishly-contract-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/dishly-contract-test-suite.md) |
| Wave 1 integration suite | — | DB integration | [integration-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/integration-test-suite.md) |
| Acceptance test suite | — | Acceptance | [acceptance-test-suite.md](.forge/efforts/dishly-wave-1/spec/test/acceptance-test-suite.md) |
| Location E2E suite | 16 | System E2E | [e2e-test-suite.md](.forge/efforts/add-location-based-filtering/spec/test/e2e-test-suite.md) |
| Location UI E2E suite | 12 | Playwright | [ui-e2e-test-suite.md](.forge/efforts/add-location-based-filtering/spec/test/ui-e2e-test-suite.md) |
| Location integration suite | 8 | DB integration | [integration-test-suite.md](.forge/efforts/add-location-based-filtering/spec/test/integration-test-suite.md) |

### All Active Efforts

See [.forge/efforts/README.md](.forge/efforts/README.md) for the full effort registry.

---

## Key Design Decisions

- **City-based location filtering** — restaurants filtered by city via `neighbourhood_id` query param on `GET /restaurants`; `neighbourhood` table reused as flat city list (no schema change); city selector in NavBar, Home hero, and Search page persists via `localStorage` and is cleared on sign-out; Near me uses browser geolocation matched to hardcoded ±0.5° bounding boxes
- **Cart in localStorage** — no backend cart storage; survives tab close/refresh; cross-component sync via `dishly:cart-updated` window event
- **Cart quantity stepper** — "Add to cart" becomes an inline `− qty +` stepper after first add; quantity derives from `useCart` hook state, not local component state; `decrementItem` mirrors `addItem` semantics (localStorage + event broadcast)
- **Auth gate at checkout, not browse** — anonymous users can explore everything; account required only at add-to-cart / checkout
- **NavBar reactive name** — name and initials update without page reload via a `dishly:auth` custom event dispatched on login/register/profile-save; NavBar increments a state counter to force re-render from `localStorage`
- **Profile data server-side** — name and phone on `user` table (additive `ALTER TABLE`); addresses and payment methods in separate tables with `ON DELETE CASCADE`; caps (2 each) enforced server-side with `COUNT` check before `INSERT`
- **Mock card at checkout** — 16-digit dummy card accepted at checkout; auto-formats as `XXXX XXXX XXXX XXXX`; last 4 digits passed via React Router state to order confirmation; card details never sent to backend
- **Simulated delivery** — full order flow works end-to-end; no real courier dispatched; Stripe in test mode only
- **Price as integer tuples** — `{ value: 1600, scale: 2 }` = $16.00; avoids floating-point rounding errors
- **Collections via JSON config** — `data/collections.json` edited directly; no admin UI; empty collections filtered at API level

---

## Wave 1 Scope

**In:** restaurant discovery, keyword search, curated collections, restaurant pages with full menus + quantity stepper, cart, checkout (Stripe test mode, dummy card entry, address pre-fill), order confirmation (last-4 card display), order history, customer profile (name, phone, saved addresses, mock payment methods), NavBar personalization, city-based location filtering (10 cities, Near me geolocation).

**Out:** native iOS/Android app, live courier dispatch, real payment processing, password reset, restaurant onboarding, social discovery, loyalty/rewards.

---

## Seed Data

100 NYC restaurants across 10 cuisine types and 5 neighbourhoods, each with 3+ menu sections, 8+ items with photo URLs, and 3+ seeded reviews. Ratings 3.5–5.0 (curation quality signal). Run `./start.sh` once to seed; subsequent runs skip automatically.
