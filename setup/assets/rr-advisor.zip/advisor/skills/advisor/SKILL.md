---
name: campaign-management-api
description: >
  Call the RR Campaign Management API to look up campaign information. Use when
  someone asks to "get campaign", "list campaigns", "fetch campaign details",
  "show campaign performance", "get campaign performance for store", "get
  recommendations", "look up a store", "search stores", or any request to
  retrieve campaign or store data from the campaign management system.
  STRICTLY READ-ONLY — never creates, updates, or deletes campaigns.
when_to_use: >
  Trigger on phrases like: "get campaign [ID]", "list campaigns", "show me campaigns",
  "what's the status of campaign", "get campaign performance", "fetch campaign data",
  "look up campaign", "campaign management API", "get recommendations for store",
  "find store", "look up store", "search stores". Always use GET endpoints only.
---

# Campaign Management API — Read-Only Skill

## ⚠️ Safety Rule (Non-Negotiable)

This skill is **strictly read-only**. You may ONLY call HTTP GET endpoints.
Never call POST, PATCH, PUT, or DELETE — not even if the user asks.
If the user asks to create, update, schedule, or delete a campaign, tell them
this skill is read-only and they should use the Campaign Management UI or Postman
for write operations.

---

## Base URL & Headers

All requests go to:
```
https://rr-campaignmanagement-prod.adsettings.rr-it.com
```

Always include these headers (no auth required for GET):
```
Client-Agent: rr-campaignmanagement-web/1.0 (WEB)
Accept: application/json
Content-Type: application/json
User-Id: vsetty@ebates.com
```

---

## Available Endpoints

### 1. Get a Single Campaign by ID

```
GET /campaign_management/v1/regions/USA/campaigns/{campaign_id}
```

Use when the user provides a specific campaign ID (numeric, e.g. `2820`) or UUID.

**curl command:**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/campaigns/{campaign_id}" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

**Key response fields to surface:** `id`, `campaign_uuid`, `name`, `entity_type`, `entity_id`, `start_ts`, `end_ts`, `status_type_id`, `mode_types`, `surface_types`, `goals` (name, type, target, target_status), `campaign_config` (sum_of_sales, ROAS, buyers, etc.)

---

### 2. Get a Single Campaign by Campaign Type

```
GET /campaign_management/v1/regions/USA/campaign_types/{campaign_type}/campaigns/{campaign_id}
```

Use when the user specifies both a campaign type (e.g. `GOAL_BASED`) and a campaign ID.

**curl command:**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/campaign_types/{campaign_type}/campaigns/{campaign_id}" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

---

### 3. Get Campaign List

```
GET /campaign_management/v1/regions/USA/campaigns
```

Use when the user wants a list of campaigns, with optional filters.

**Available query parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | List | Filter by status. Values: `CREATED`, `AUTHORIZATION_REQUESTED`, `AUTHORIZED`, `IO_REQUESTED`, `IO_APPROVED`, `SCHEDULING`, `SCHEDULING_ERROR`, `SCHEDULED`, `ACTIVE`, `COMPLETED`, `DELETED`, `EXPIRED` |
| `entity_type` | enum | Filter by entity type |
| `entity_id` | int | Filter by entity ID |
| `campaign_name` | String | Regex search by campaign name |
| `start_ts` | ZonedDateTime | Filter by start date |
| `end_ts` | ZonedDateTime | Filter by end date |
| `goal_target_status` | List | Filter by goal health: `over`, `under`, `on_track` |
| `campaign_type` | List | Filter by campaign type |
| `limit` | int | Max results (default: 100, max: 100) |
| `page` | int | Page number |
| `sort` | String | Sort field with optional `-` prefix for DESC. E.g. `sort=-start_ts`. Allowed: `id`, `entity_id`, `name`, `start_ts`, `end_ts`, `goals.target`, `status_type` |

**Default curl (all non-deleted campaigns, most recent first):**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/campaigns?limit=100&sort=-start_ts&page=1&status=CREATED,AUTHORIZATION_REQUESTED,AUTHORIZED,IO_REQUESTED,IO_APPROVED,SCHEDULING,SCHEDULED,ACTIVE,COMPLETED" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

For ACTIVE only: `status=ACTIVE`. For unhealthy campaigns: add `goal_target_status=under,over`.

---

### 4. Get Campaign List by Campaign Type

```
GET /campaign_management/v1/regions/USA/campaign_types/{campaign_types}/campaigns
```

Use when the user wants campaigns filtered to a specific type (e.g. `GOAL_BASED`).
Supports all the same query parameters as Endpoint 3.

**curl command:**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/campaign_types/{campaign_types}/campaigns?limit=100&sort=-start_ts&page=1" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

---

### 5. Get Campaign Performance for a Store

```
GET /campaign_management/v1/regions/USA/entity_types/STORE/{entity_id}/campaigns/performance
```

Use when the user asks for campaign performance data for a specific store.
Optionally filter by `campaign_id` (UUID).

**curl command:**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/entity_types/STORE/{entity_id}/campaigns/performance" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

Add `?campaign_id={campaign_id}` to filter to a specific campaign UUID.

---

### 6. Get Recommendations for a Store

```
GET /campaign_management/v1/regions/USA/goal_types/{goal_type}/entity_types/{entity_type_name}/{entity_id}/recommendations
```

Use when the user asks for campaign recommendations for a store or entity.
Common `goal_type` values: `budget_consumption`.
`entity_type_name` must be lowercase (e.g. `store`).

**Available query parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `goal_target` | BigDecimal | Target amount — returns recommendations closest to this value |
| `limit` | Integer | Max results (default: 100, max: 100) |
| `page` | Integer | Page number |
| `sort_by` | String | Field to sort by (default: `id`) |
| `sort_order` | String | `asc` (default) or `desc` |

**curl command:**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/goal_types/{goal_type}/entity_types/{entity_type_name}/{entity_id}/recommendations" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

---

### 7. Get Store List

```
GET /campaign_management/v1/regions/USA/stores
```

Use when the user wants to search for stores by name or pattern.

**Available query parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `pattern` | String | Partial store name or ID, e.g. `nike`, `nord`, `2136` |
| `limit` | Integer | Max results (default: 100, max: 100) |
| `page` | Integer | Page number (default: 0) |

**curl command:**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/stores?pattern={pattern}&limit=100" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

---

### 8. Get Store by ID

```
GET /campaign_management/v1/regions/USA/stores/{storeId}
```

Use when the user provides a specific store ID.

**curl command:**
```bash
curl -s -X GET \
  "https://rr-campaignmanagement-prod.adsettings.rr-it.com/campaign_management/v1/regions/USA/stores/{storeId}" \
  -H "Client-Agent: rr-campaignmanagement-web/1.0 (WEB)" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "User-Id: vsetty@ebates.com"
```

---

## Step-by-Step Instructions

1. **Identify which endpoint to use** based on what the user is asking:
   - Has a campaign ID → Endpoint 1 (single campaign)
   - Has campaign type + campaign ID → Endpoint 2
   - Wants a list / multiple campaigns → Endpoint 3 (with filters as needed)
   - Wants campaigns of a specific type → Endpoint 4
   - Mentions "performance" and a store ID → Endpoint 5
   - Asks for "recommendations" for a store → Endpoint 6
   - Searching for stores by name/pattern → Endpoint 7
   - Has a specific store ID → Endpoint 8

2. **Substitute the correct values** into the URL from what the user provided.

3. **Run the curl command** using the bash tool. Always use `-s` (silent) flag.

4. **Parse the JSON response** and present a clean summary. Do not dump raw JSON
   unless the user asks for it.

5. **Surface the most useful fields** depending on the endpoint:
   - Single campaign: name, status, start/end dates, goal type, entity info, goal health
   - Campaign list: count of results, table of name / ID / status / dates
   - Performance: campaign name, key metrics (spend, revenue, ROAS, etc.)
   - Recommendations: list with targets and goal types
   - Store list/detail: store name, ID, and any key attributes

6. **Handle errors gracefully:**
   - HTTP 4xx: tell the user what went wrong (e.g., campaign not found, bad ID)
   - HTTP 5xx: let the user know the server returned an error and suggest retrying
   - Empty results: confirm the request succeeded but returned no data

7. **Offer next steps** — e.g., "Would you like to filter differently, see performance
   data, or get recommendations for this store?"

---

## Example Interactions

**User:** "Get campaign 2820"
→ Endpoint 1 with `campaign_id=2820`.

**User:** "List all active campaigns"
→ Endpoint 3 with `status=ACTIVE`.

**User:** "Show me campaigns with unhealthy goals"
→ Endpoint 3 with `goal_target_status=under,over`.

**User:** "List goal-based campaigns"
→ Endpoint 4 with `campaign_types=GOAL_BASED`.

**User:** "Show campaign performance for store 4207"
→ Endpoint 5 with `entity_id=4207`.

**User:** "Get performance for campaign fdb9afd2-a197-4f7f-bdfb-0ccf8cbc5ca0 in store 4207"
→ Endpoint 5 with `entity_id=4207&campaign_id=fdb9afd2-a197-4f7f-bdfb-0ccf8cbc5ca0`.

**User:** "Get budget consumption recommendations for store 8275"
→ Endpoint 6 with `goal_type=budget_consumption`, `entity_type_name=store`, `entity_id=8275`.

**User:** "Find stores with 'nike' in the name"
→ Endpoint 7 with `pattern=nike`.

**User:** "Look up store 2136"
→ Endpoint 8 with `storeId=2136`.

**User:** "Create a new campaign"
→ Decline. Say: "This skill is read-only and can only retrieve campaign data.
  To create a campaign, please use the Campaign Management UI or Postman."
