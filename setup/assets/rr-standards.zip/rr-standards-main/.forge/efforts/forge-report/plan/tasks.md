# Implementation Plan: Report Skill

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Core Fixes (Independent)

- [x] [checkpoint][wave:1] Add effort-scoped context resolution to `report/SKILL.md` and `report-weekly/SKILL.md` — confirm effort detection strategy (branch-name parse → `.state.json` scan → root fallback) matches ADR-001 before proceeding; update both skills to source meeting transcripts from `.forge/efforts/<id>/meetings/` with soft-warning fallback (TASK-001) — 65dca9d
- [x] [auto][wave:1] Audit `report-transcripts/SKILL.md` for TR-5/TR-6/TR-9 compliance: verify `.vtt` vs `.txt` format discrimination, idempotency check (same-dir same-base-name `.md`), and unconditional prerequisite invocation from `forge:report` and `forge:report:weekly`; fix any gaps (TASK-002) — 65dca9d
- [x] [auto][wave:1] Audit `report-weekly/SKILL.md` for TR-7/TR-8 compliance: verify ISO-8601 week boundaries, Monday–Sunday `START_DATE`/`END_DATE` in filenames, and manual-edit preservation when updating current week; fix any gaps (TASK-003) — 65dca9d
- [x] [auto][wave:1] Audit all 5 preset sub-skills (`report-status`, `report-launch`, `report-delivery`, `report-debrief`, `report-sizing`) for TR-13 compliance: verify each prepends `--report <preset>` to `$ARGUMENTS` and delegates to `../report/SKILL.md` without duplicating logic; fix any gaps (TASK-004) — 65dca9d
- [x] [auto][wave:1] Audit `report/SKILL.md` for TR-10/TR-11/TR-12/TR-14 compliance: verify output files are never committed, `audit_check.py` path resolution order, preset section list conformance (including status-preset roadblocks suppression), and `--out` suffix rules for full vs delta modes; fix any gaps (TASK-005) — 65dca9d

## Wave 2 — Git Notes Integration

- [x] [tdd][wave:2] Add git notes consumption to `report-weekly/SKILL.md` per TR-3/TR-4: for each commit in the week window, run `git notes show <sha>`, parse JSON, incorporate `workItem`/`requirements` fields (ADR-008) into Development Work and Key Decisions sections; silently skip on non-zero exit or malformed JSON; tolerate missing optional fields (TASK-006) — 65dca9d

## Wave 3 — Integration Review and Re-validation

- [x] [checkpoint][wave:3] Review all modified SKILL.md files together for internal consistency — confirm effort-scoped path resolution in TASK-001 flows correctly into transcript processing (TASK-002), weekly generation (TASK-003), and the main report skill (TASK-005) before closing (TASK-007) — 65dca9d
- [x] [auto][wave:3] Re-run `forge:validate` to confirm PASS or PASS WITH CONCERNS with all implementation tasks complete; update validation/report.md (TASK-008) — 65dca9d
