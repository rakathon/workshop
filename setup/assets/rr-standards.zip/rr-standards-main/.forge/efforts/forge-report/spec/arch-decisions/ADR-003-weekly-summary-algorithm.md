# ADR-003: Weekly Summary Algorithm

**Status:** Accepted
**Effort ID:** forge-report
**Date:** 2026-04-16

## Context

The `forge:report:weekly` skill must maintain a set of weekly summary documents covering every calendar week with project activity. These summaries are the primary input to full audit reports. We needed to define: how weeks are bounded, how the updates directory is located, how filenames are constructed, and how re-runs handle existing summaries (including ones that engineers have manually edited).

## Decision

Week boundaries use ISO-8601 numbering (Monday–Sunday) in the local system timezone. `START_DATE` and `END_DATE` in filenames are always Monday and Sunday of the respective week in `YYYY-MM-DD` format. The updates directory is auto-detected in this order: (1) existing directory containing `updates_*.md` files, (2) `project_management/weekly_updates/`, (3) `updates/` at repo root, (4) create `project_management/weekly_updates/`. When updating the current week's summary, only auto-generated sections are updated; content under unrecognized section headers is preserved verbatim. New summaries for past weeks are created fresh; the current week's summary is updated, not replaced.

## Alternatives Considered

**Sunday-to-Saturday week boundaries:** Rejected. ISO-8601 Monday–Sunday is the standard used in Forge's date handling throughout the system. Consistency with the surrounding framework is more important than matching any particular regional convention.

**Require an explicit `--dir` flag for the updates directory:** Rejected. Auto-detection based on existing file patterns makes the skill usable without configuration in projects that already have an established updates location.

**Replace the current week's summary entirely on each run:** Rejected. Engineers sometimes add hand-written context (e.g. a narrative summary paragraph) that would be lost on every re-run. Preserving unrecognized sections protects manual edits.

## Consequences

- The filename format `updates_{START_DATE}_{END_DATE}.md` is stable and sortable.
- Projects that move their updates directory will need one run to re-establish the auto-detection anchor.
- The section-preservation rule requires the skill to parse section headers before writing — this is a structural constraint on the weekly summary format.
- `forge:report` inherits this algorithm by running `forge:report:weekly` as a prerequisite step.
