# ADR-001: Effort-Scoped Context Resolution

**Status:** Accepted
**Effort ID:** forge-report
**Date:** 2026-04-16

## Context

The `forge:report` skill family generates reports and weekly summaries from meeting transcripts, git history, and other project artifacts. All of these artifacts live under an effort's directory (`.forge/efforts/<id>/meetings/`), not at the repository root. The original implementation assumed a global `meetings/` path, which would find the wrong data when multiple efforts exist in the same repository. We needed a reliable strategy to detect which effort is being reported on, and a graceful fallback for when meeting artifacts are missing or sparse.

## Decision

We will resolve the active effort using two strategies in order: (1) parse the current git branch name — if it matches `effort/<id>`, use `<id>` as the active effort; (2) if no branch match, scan `.forge/efforts/*/. state.json` for efforts where `currentPhase` is not `"closed"`, prompting the user to select if multiple are found. Meeting transcripts are sourced from `.forge/efforts/<id>/meetings/`. When no effort is detected, the skill falls back to `meetings/` at the repository root. When the resolved meetings directory is absent or empty, the skill emits a soft warning and continues using whatever sources are available (git history, git notes, weekly summaries, other docs) rather than stopping.

## Alternatives Considered

**Hard-stop when meetings directory is absent:** Rejected. Meeting transcripts are one of several possible inputs. Git history, git notes, and weekly summary files are often sufficient to reconstruct decisions and activity, particularly for recent periods. A hard stop would make the skill unusable on efforts that have activity but no recorded meetings.

**Require explicit `--effort` flag:** Rejected. For engineers working on a single active effort the flag would be mandatory boilerplate. Auto-detection from branch name covers the common case; the multi-effort prompt handles the edge case.

**Scan only `.state.json` without branch-name heuristic:** Rejected. The branch-name strategy is faster and more deterministic — it requires no filesystem scan and has no ambiguity when the engineer is on an `effort/<id>` branch.

## Consequences

- The skill is safe to run in repositories with multiple concurrent efforts.
- Engineers working on `effort/<id>` branches get zero-configuration context detection.
- The soft-warning fallback means reports can always be generated with partial data, but users are informed of what was missing.
- Skills that depend on `forge:report` internally (e.g. `forge:report:weekly`) inherit this resolution strategy.
