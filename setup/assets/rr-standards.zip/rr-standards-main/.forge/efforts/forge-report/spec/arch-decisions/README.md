# Architecture Decisions — forge-report

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-001](ADR-001-effort-scoped-context-resolution.md) | Effort-Scoped Context Resolution | Accepted | 2026-04-16 |
| [ADR-002](ADR-002-report-output-contract.md) | Report Output Contract | Accepted | 2026-04-16 |
| [ADR-003](ADR-003-weekly-summary-algorithm.md) | Weekly Summary Algorithm | Accepted | 2026-04-16 |
| [ADR-004](ADR-004-git-notes-consumption.md) | Git Notes Consumption Contract | Accepted | 2026-04-16 |
| [ADR-005](ADR-005-transcript-processing-contract.md) | Transcript Processing Contract | Accepted | 2026-04-16 |
| [ADR-006](ADR-006-report-terminology-no-audit-prefix.md) | Report Terminology — Remove "Audit" Prefix | Accepted | 2026-04-17 |
| [ADR-007](ADR-007-html-visual-design-system.md) | HTML Report Visual Design System | Accepted | 2026-04-17 |
| [ADR-008](ADR-008-report-output-directory.md) | Report Output Directory Placement | Accepted | 2026-04-17 |
