# ADR-002: Report Output Contract

**Status:** Accepted
**Effort ID:** forge-report
**Date:** 2026-04-16

## Context

The `forge:report` skill must produce consistent, predictable output across five named presets (status, launch, delivery, debrief, sizing), full-report mode, and delta mode. Users need control over output filename, included sections, and report title. Two audiences interact with the output: humans reading the files, and `report_check.py` which parses HTML section IDs programmatically. We needed to define the output contract — what files are always produced, how filenames are derived, how section selection works, and critically, whether output files should ever be committed.

## Decision

Every report invocation produces exactly two output files: one `.html` and one `.md`, always together. Output files are never committed to the repository — the skill must not call `git add` on any output file. For full and preset reports, the `_report` suffix is always appended to the `--out <name>` value (e.g. `--out q2` → `q2_report.html`); for delta reports, `--out <name>` is used as-is. When `--sections` is supplied alongside `--report <preset>`, `--sections` overrides the preset's section list entirely. HTML section IDs are the canonical identifiers for `--sections`/`--exclude` matching and for `report_check.py` section detection.

## Alternatives Considered

**Commit output files to the repository:** Rejected. Report files are generated artifacts. Committing them creates noise in git history and conflicts when multiple engineers generate reports independently. They are consumed and discarded, not tracked.

**Produce only Markdown output:** Rejected. The HTML output provides the rich visual format (hero section, stat tiles, styled cards) that makes these reports useful for stakeholders. Markdown serves as the portable/accessible companion.

**Merge `--sections` with preset section list:** Rejected. Merging creates unpredictable output — users specifying sections want exactly those sections. Presets are a starting point; `--sections` is an explicit override.

## Consequences

- `report_check.py` can reliably parse reports because HTML section IDs are stable and canonical.
- Engineers can always regenerate reports without worrying about git state.
- The `_report` suffix rule means `--out` values should be chosen without the suffix — it will be appended automatically.
- Sub-skills (`forge:report:status` etc.) inherit this contract by delegating to the main skill.
