# ADR-004: Git Notes Consumption Contract

**Status:** Accepted
**Effort ID:** forge-report
**Date:** 2026-04-16

## Context

`forge:commit` attaches structured JSON git notes to commits (ADR-008), linking each commit to work items and requirements. The `forge:report:weekly` skill reads commit history to populate weekly summaries. Without reading these notes, the summaries contain only conventional commit message lines — missing the richer traceability context (which effort task a commit belongs to, which requirements it addresses). We needed a consumption contract that extracts this structure when present without breaking when it is absent.

## Decision

For each commit in the week window, the skill runs `git notes show <sha>`. If the exit code is non-zero or the output is not valid JSON, the commit is summarized from its message alone — no error is raised. If the output is valid JSON and contains a `workItem` or `requirements` field (ADR-008 schema), those values are incorporated into the relevant weekly summary sections (Development Work, Key Decisions). Unknown fields in the JSON are ignored. Missing optional fields (e.g. `requirements` absent) do not error. The skill never assumes a fixed ADR-008 schema version.

## Alternatives Considered

**Parse git log `--notes` flag output directly:** Rejected. The `--notes` flag appends note content to log output with variable formatting that is harder to parse reliably than a direct `git notes show <sha>` call per commit.

**Require git notes to be present and fail if absent:** Rejected. Many repositories and many commits will have no git notes. The skill must degrade gracefully to remain useful outside of strict Forge workflows.

**Cache note content to avoid repeated `git notes show` calls:** Considered but deferred. For the expected commit volumes in a weekly window (typically < 50 commits), the overhead is negligible. Caching can be added if performance becomes a concern.

## Consequences

- Weekly summaries are enriched with work-item and requirement linkages when `forge:commit` has been used, and gracefully unaffected when it has not.
- The skill is forward-compatible with future ADR-008 schema extensions — new fields are silently ignored.
- Engineers using `git notes prune` or force-pushing notes will lose the enrichment for affected commits, but the skill will not error.
