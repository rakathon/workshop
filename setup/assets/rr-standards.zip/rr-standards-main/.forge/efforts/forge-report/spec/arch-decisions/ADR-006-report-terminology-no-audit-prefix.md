# ADR-006: Report Terminology — Remove "Audit" Prefix

**Status:** Accepted
**Effort ID:** forge-report
**Date:** 2026-04-17

## Context

The `forge:report` skill family originated from an earlier implementation that used "audit" as the central metaphor — `audit_check.py`, `audit_report.html`, `audit_delta_*.html`. This terminology carried over into default output filenames, the validation tool name, and auto-detect glob patterns. As the skill was brought into the Forge effort framework and formalized, the "audit" term felt like an implementation artifact rather than a deliberate product decision. "Audit" implies a compliance or financial connotation that doesn't match the skill's actual purpose — synthesizing project activity into readable reports for engineering and product audiences.

## Decision

Remove "audit" as a prefix from all output filenames, tooling, and glob patterns:
- Default full report filename: `audit_report.*` → `report_full.*`
- Default delta report filename: `audit_delta_<YYYYMMDD>.*` → `report_delta_<YYYYMMDD>.*`
- Validation tool: `audit_check.py` → `report_check.py`, relocated from `plugins/forge/tools/` to `plugins/forge/skills/report/` (co-located with the skill)
- Auto-detect glob: `audit_*.html` → `*_report.html` + `report_delta_*.html` (catches all report types including presets)

Prose uses of "audit" as a generic noun ("full audit", "prior audit") are acceptable and not changed — only proper names and filenames are affected.

## Alternatives Considered

**Keep `audit_` prefix for backwards compatibility:** Rejected. This effort explicitly brought the old implementation into scope to clean it up. Backwards compatibility with the pre-Forge implementation is not a goal — the old `audit_*.html` files are not version-controlled artifacts.

**Rename to `forge-report.*` instead of `report_full.*`:** Rejected. The `forge:` prefix belongs to skill invocations, not output artifacts. Output files live in the user's project, not in the plugin, and should have names that make sense in that context without the Forge namespace.

**Co-locate `report_check.py` in a `tools/` subdirectory of the skill:** Rejected. The `tools/` directory existed only to hold `audit_check.py`. With a single file, a subdirectory adds navigation overhead. Co-location with the skill makes the relationship explicit and the `${CLAUDE_SKILL_DIR}/report_check.py` path simpler.

## Consequences

- Engineers running `report_check.py` without arguments will find `*_report.html` and `report_delta_*.html` files automatically — including preset reports like `status_report.html`.
- Old `audit_*.html` files from the pre-Forge implementation are not auto-detected; engineers must pass the filename explicitly if they want to check old reports.
- The `${CLAUDE_SKILL_DIR}/report_check.py` bundled path is shorter and more obvious than the previous `${CLAUDE_SKILL_DIR}/../../tools/audit_check.py`.
