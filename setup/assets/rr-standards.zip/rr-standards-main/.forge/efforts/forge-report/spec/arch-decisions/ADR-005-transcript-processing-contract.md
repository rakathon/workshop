# ADR-005: Transcript Processing Contract

**Status:** Accepted
**Effort ID:** forge-report
**Date:** 2026-04-16

## Context

Meeting recordings arrive in two formats: `.vtt` (Zoom-exported, with speaker attribution) and `.txt` (Whisper-transcribed, no speaker attribution). These require different processing pipelines to produce useful Markdown transcripts. Additionally, `report_check.py` is bundled with the Forge plugin but may also exist at a project-level path — the skill needs a deterministic resolution strategy. We needed to define how format discrimination works, how idempotency is enforced, and how the validation tool is located.

## Decision

Format discrimination is by file extension only: `.vtt` → speaker-attributed pipeline (Attendees section, speaker-labelled Meeting Notes, Key Takeaways); `.txt` → topic-grouped pipeline (Overview, topic-grouped Meeting Transcript, Key Takeaways). Processing a `.vtt` as a `.txt` or vice versa is an error. Before processing any recording, the skill checks for a same-directory, same-base-name `.md` file — if found, that file is skipped. `report_check.py` is resolved in order: (1) `project_management/tools/report_check.py` relative to the repo root, (2) `${CLAUDE_SKILL_DIR}/report_check.py` (co-located with the skill in the plugin). If neither exists, validation is skipped with a warning; report generation is not blocked. Both `forge:report` and `forge:report:weekly` run transcript processing unconditionally as a prerequisite — it is not gated on a flag.

## Alternatives Considered

**Detect format from file content rather than extension:** Rejected. Extension-based discrimination is simpler, faster, and matches the conventions of the tools that produce these files. Content-sniffing adds complexity with no practical benefit since file producers are consistent.

**Make transcript processing opt-in via a flag:** Rejected. Users consistently forget to run prerequisites manually. Running it unconditionally ensures reports are always built from the latest available transcripts without requiring the engineer to remember the correct invocation order.

**Ship `report_check.py` only at the project level:** Rejected. Requiring engineers to copy the tool into each project creates version drift. Bundling it with the plugin ensures all consumers use the current version; the project-level override path allows intentional pinning.

## Consequences

- Engineers can drop new `.vtt` or `.txt` files into the meetings directory and run any report skill — transcripts will be processed automatically.
- The idempotency check means re-running is always safe; only new recordings incur processing cost.
- The two-path resolution for `report_check.py` means plugin upgrades automatically deliver updated validation logic unless a project has pinned its own copy.
- Language sanitization (filler words, profanity neutralization) is applied during processing — the `.md` transcript is the canonical form; the original recording file is not modified.
