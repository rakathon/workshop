# ADR-008: Report Output Directory Placement

**Status:** Accepted
**Effort ID:** forge-report
**Date:** 2026-04-17

## Context

The original implementation wrote report files to the current working directory — wherever the engineer happened to invoke the skill. This made reports hard to find, cluttered the repo root, and gave no indication of which effort or deployable the report covered. In a repository with multiple active efforts or deployables, reports from different contexts would mix in the same directory. We needed a deterministic, context-aware output location that keeps reports co-located with the artifacts they describe.

## Decision

The skill resolves `OUTPUT_DIR` in C0.5 using a four-level priority chain:

1. **Active effort** — if an effort is detected (C0.1/C0.2): `.forge/efforts/<id>/reports/`
2. **Deployable** — if no effort but a single deployable exists under `.forge/deployables/`: `.forge/deployables/<id>/reports/`; multiple deployables prompt for selection.
3. **Product** — if no effort or deployable but a single product exists under `.forge/products/`: `.forge/products/<id>/reports/`; multiple products prompt for selection.
4. **Repo root fallback** — if no Forge context is found: `reports/` at the repository root.

The `reports/` subdirectory is created automatically if absent. All output files (`.html` and `.md`) are written to `OUTPUT_DIR`. Delta cutoff auto-detection searches `OUTPUT_DIR` for prior reports rather than the repo root.

`report_check.py` mirrors this resolution when no explicit file argument is given: it accepts `--out-dir` to override, or auto-detects from the git branch name and `.forge` directory structure.

## Alternatives Considered

**Current working directory (original behavior):** Rejected. Engineers invoke skills from various directories; the output location becomes unpredictable. Reports accumulate at the root, mix across efforts, and have no contextual home.

**Always write to repo root `reports/`:** Rejected. A flat `reports/` at the root doesn't scale to multi-effort repositories — reports from unrelated efforts mix together with no clear ownership. The effort/deployable/product hierarchy provides natural scoping.

**Require explicit `--out-dir` flag:** Rejected. Engineers generating reports during an active effort shouldn't need to specify the output location manually — it should be inferred from context. The flag exists as an override for edge cases, not as the primary mechanism.

**Separate `reports/` directory per effort alongside other artifacts:** Accepted variant. The `reports/` subdirectory sits inside the effort/deployable/product directory rather than alongside it, keeping generated artifacts distinct from the committed discovery and spec artifacts that live in the same directory.

## Consequences

- Reports are co-located with the effort, deployable, or product they describe — engineers know exactly where to look.
- The `.forge/efforts/<id>/reports/` path keeps generated artifacts inside the effort boundary, consistent with how meetings and other effort-scoped artifacts are stored.
- The `reports/` subdirectory must be added to `.gitignore` if teams don't want to commit reports — or left unignored if they want to share them. This is a team-level decision; the skill does not enforce it either way.
- `report_check.py` auto-detection now searches the correct directory rather than the repo root, which means engineers can run `report_check.py` without arguments and get the most recent report for the current effort automatically.
