# Technical Requirements

*Elaborated from: [requirements/business.md](business.md)*
*Elaborated: 2026-04-16*

---

## TR-1: Effort detection from Forge directory structure

*Traces to: BR-2*

The skill must detect the active effort using two strategies in order: (1) parse the current git branch name — if it matches `effort/<id>`, resolve `<id>` as the active effort; (2) if no branch match, scan `.forge/efforts/*/. state.json` for efforts where `currentPhase` is not `"closed"`. If multiple non-closed efforts are found via the scan, the skill must prompt the user to select one. If neither strategy yields an effort, the skill falls back to `meetings/` at the repository root.

---

## TR-2: Graceful degradation when meeting artifacts are absent

*Traces to: BR-2*

When the resolved meetings path (`meetings/` under the effort directory or repo root) is absent, empty, or contains no processable files, the skill must emit a soft warning and continue using whatever sources are available — git history, commit messages, git notes (ADR-008), weekly summary files, and other project documentation — to reconstruct decisions and activity. The skill must never hard-stop due to absent meeting transcripts alone.

---

## TR-3: Git notes read via `git notes show`

*Traces to: BR-4*

For each commit in the week window, the skill must run `git notes show <sha>` and attempt to parse the output as JSON. If the output is valid JSON and contains a `workItem` or `requirements` field (ADR-008 schema), those values must be incorporated into the relevant weekly summary sections. A non-zero exit from `git notes show` or malformed JSON must be caught and silently skipped — the commit message is used as the sole summary in that case.

---

## TR-4: ADR-008 git note schema tolerance

*Traces to: BR-4*

The skill must tolerate missing optional fields in the ADR-008 git note JSON (e.g. absent `requirements` field) without erroring. Only fields that are present and non-null are surfaced in the weekly summary. Unknown fields must be ignored — the skill must not assume a fixed schema version.

---

## TR-5: Transcript format discrimination

*Traces to: BR-1*

The skill must distinguish `.vtt` from `.txt` files by extension and apply the correct processing pipeline: `.vtt` → speaker-attributed format with Attendees section; `.txt` → topic-grouped format with Overview section. Processing a `.vtt` as a `.txt` or vice versa is an error.

---

## TR-6: Idempotent transcript processing

*Traces to: BR-1*

Before processing any recording file, the skill must check whether a corresponding `.md` file already exists in the same directory with the same base name. If it does, that file is skipped entirely. This check must be path-exact — a `.md` with the same name in a different directory does not count.

---

## TR-7: Weekly summary idempotency and preservation of manual edits

*Traces to: BR-3*

When updating the current week's summary (not creating it fresh), the skill must read the existing file and update only the auto-generated sections. Content not matching a known auto-generated section header must be preserved verbatim. The skill must not truncate or replace the file in place.

---

## TR-8: Weekly boundary calculation

*Traces to: BR-3*

Week boundaries must be computed using ISO-8601 week numbering (Monday–Sunday) in the local system timezone. The `START_DATE` and `END_DATE` used in filenames and section headers must always be the Monday and Sunday of the respective week in `YYYY-MM-DD` format, regardless of when within the week the skill is invoked.

---

## TR-9: Prerequisite transcript processing before report and weekly generation

*Traces to: BR-1, BR-3, BR-5*

Both `forge:report` and `forge:report:weekly` must invoke the transcript processing step before scanning for `.md` transcripts. For each `.vtt` and `.txt` file under the resolved meetings path, if no corresponding `.md` exists, it must be processed. This must run unconditionally — not gated on a `--transcripts` flag.

---

## TR-10: Report output never committed

*Traces to: BR-5, BR-6, BR-7*

Neither `.html` nor `.md` report output files must ever be staged or committed by the skill. The skill must not call `git add` on any output file. Post-generation output from `report_check.py` is also excluded from commits.

---

## TR-11: `report_check.py` bundled path resolution

*Traces to: BR-9*

The skill must resolve `report_check.py` by checking two locations in order: (1) `project_management/tools/report_check.py` relative to the repo root; (2) `${CLAUDE_SKILL_DIR}/report_check.py` (co-located with the skill in the plugin). If neither exists, the skill must warn and skip validation without failing report generation.

---

## TR-12: Preset section list conformance

*Traces to: BR-7*

Each named preset must resolve to exactly the documented section list. `--report status` must suppress Data Quality Landmines and Recurring Capacity Drains from the roadblocks section — only Structural Blockers are rendered. When `--sections` is supplied alongside `--report`, `--sections` overrides the preset section list entirely and must not be merged with it.

---

## TR-13: Sub-skill delegation correctness

*Traces to: BR-7*

Each sub-skill (`forge:report:status`, `forge:report:launch`, etc.) must prepend `--report <preset>` to the user-supplied argument string before delegating to the main `forge:report` skill. The merged string must be passed as `$ARGUMENTS` to the main skill. Sub-skills must not duplicate any logic from the main skill.

---

## TR-14: Output filename convention

*Traces to: BR-8, BR-13*

All report filenames use the format `YYYY-MM-DD-HHMM-<name>.html` and `YYYY-MM-DD-HHMM-<name>.md`, where the timestamp is generated once at the start of Step A0 and reflects local time. The `<name>` portion defaults to the report type (`full`, `delta`, or the preset name); `--out <name>` overrides only the name portion. There is no `_report` suffix. These rules must be applied consistently to both `.html` and `.md` outputs. Reports are written into type-specific subdirectories under `OUTPUT_ROOT` (e.g. `OUTPUT_ROOT/full/`, `OUTPUT_ROOT/delivery/`, `OUTPUT_ROOT/delta/`).

---

## TR-15: Delta cutoff auto-detection

*Traces to: BR-6*

When `--delta` is invoked without `--since` or `--compare`, the skill must determine the cutoff date using this priority order: (1) `--since <date>` if provided; (2) generation date extracted from the file named in `--compare`; (3) modification timestamp of the most recently modified `.html` file in `OUTPUT_ROOT/full/` or `OUTPUT_ROOT/delta/`; (4) 7 days before today if no prior report is found. The resolved cutoff and source must be reported to the user before generation begins.

---

## TR-16: Language sanitization scope

*Traces to: BR-5, BR-11*

Language sanitization (removal of filler words, false starts, profanity neutralization, reframing of harsh personal criticisms as process observations) must be applied to all meeting transcript content before it is included in any report section — not only during transcript file processing. Sanitization must never remove technical content, blockers, honest assessments, or frustration directed at systems rather than individuals.

---

## TR-17: Rollout source priority

*Traces to: BR-5, BR-12*

When generating the Rollout Scorecard and Estimated Rollout Timeline sections, the skill must apply this source priority: (1) local GitHub markdown rollout tracking document (any `.md` with `rollout`, `release-plan`, or `release-status` in name/path, or any `.md` containing a table with a Status column and phase/step rows) — use as sole primary source; (2) Confluence via MCP only if no local doc exists and a URL appears in `CLAUDE.md`/`README.md`; (3) synthesize best-effort from runbooks and weekly updates, marking each step's status as "Inferred from transcripts". GitHub markdown is the source of truth; Confluence is a publication target.

---

## TR-18: HTML visual design system conformance

*Traces to: BR-11, BR-12*

Every generated HTML report must conform to the visual design system defined in `section-layouts.md` and `full-report-mode.md` (F7): three-family typography with documented size/weight/letter-spacing/line-height constraints; fixed brand color palette; self-contained HTML with no external dependencies except the Google Fonts import; hero gradient with 2-column layout for full reports and horizontal 4-tile stat row for delta reports; timeline cards with five distinct zones; roadblocks section with sub-label dividers separating the three sub-sections. The `rollout-timeline`, `impediments`, and `coordination` sections must reproduce the component structures specified in `section-layouts.md` exactly.

---

## TR-19: Output directory resolution

*Traces to: BR-14*

The skill must resolve `OUTPUT_DIR` in C0.5 using this priority order:
1. If an active effort is set (`EFFORT_ID`): `OUTPUT_DIR = .forge/efforts/<EFFORT_ID>/reports/`
2. Else if `.forge/deployables/` exists with exactly one deployable: `OUTPUT_DIR = .forge/deployables/<deployable-id>/reports/`; if multiple deployables exist, prompt the user to select one.
3. Else if `.forge/products/` exists with exactly one product: `OUTPUT_DIR = .forge/products/<product-id>/reports/`; if multiple products exist, prompt the user to select one.
4. Else: `OUTPUT_DIR = reports/` at the repository root.

The skill must create `OUTPUT_DIR` if it does not exist. The resolved path must be reported to the user as part of project context detection output. `OUTPUT_DIR` is used as the write destination for all output files and as the search location for prior reports during delta cutoff auto-detection.
