# Business Requirements

*Extracted from: implementation files (forge:report skill family)*
*Extracted: 2026-04-16*

---

## BR-1: Raw transcript conversion

Meeting recordings exported from video tools must be converted into structured, readable Markdown transcripts before any summary or report generation can occur.

**Acceptance criteria:**
- `.vtt` files (Zoom-style, with speaker attribution) produce a `.md` transcript with Attendees, speaker-attributed Meeting Notes with topic headers, and Key Takeaways (5–15 items).
- `.txt` files (Whisper-style, no speaker attribution) produce a `.md` transcript with Overview, topic-grouped Meeting Transcript sections, and Key Takeaways.
- Language sanitization is applied: filler words removed, false starts cleaned, profanity and harsh personal criticisms neutralized into professional phrasing while preserving all technical content, blockers, and honest assessments.
- A recording file that already has a corresponding `.md` file is skipped without modification.
- The output `.md` is written to the same directory as the source file, using the same base filename.
- Processing is available as a standalone skill (`forge:report:transcripts`) and is also run automatically as a prerequisite step inside `forge:report:weekly` and `forge:report`.

---

## BR-2: Effort-scoped meeting discovery

When generating summaries or reports for a specific effort, meeting transcripts must be sourced from that effort's directory, not from a global or repo-root path.

**Acceptance criteria:**
- The skill resolves the active effort from the Forge effort directory structure (`.forge/efforts/<id>/`).
- Meeting transcripts are discovered recursively under `.forge/efforts/<id>/meetings/`.
- If no effort is active or the user invokes the skill outside an effort context, the skill falls back to `meetings/` at the repository root (recursively).
- The resolved meetings path is reported to the user as part of the project context detection output.

---

## BR-3: Weekly summary generation

For every calendar week containing project activity (meetings or commits), a weekly summary document must exist. Any missing summaries are generated automatically; the current week's summary is updated when new activity has occurred since the last write.

**Acceptance criteria:**
- Week boundaries are Monday 00:01 – Sunday 23:59.
- Activity is detected from meeting transcript `.md` files and from `git log --all`.
- For each week with activity but no corresponding summary file, a new summary is generated and saved as `updates_{START_DATE}_{END_DATE}.md` in the resolved updates directory.
- The current week's summary is updated (not replaced) when new activity has occurred; existing manually edited content is preserved.
- Each summary contains: week header, project name, summary paragraph, Top 10 Highlights (exactly 10 bullets, max 20 words each), and categorized sections (Development Work, Documentation, Key Decisions, Meetings & Discussions, Process & Tooling, Investigations & Research, Blockers & Risks, Next Week's Focus).
- The project name is auto-detected: first H1 in `CLAUDE.md`, then first H1 in `README.md`, then repo directory basename.
- The updates directory is auto-detected: existing directory containing `updates_*.md` files → `project_management/weekly_updates/` → `updates/` at repo root → create `project_management/weekly_updates/`.
- After processing, the skill reports: detected project name, detected updates directory, list of missing weeks handled (with date ranges and file paths), and current-week status.
- The skill is available standalone (`forge:report:weekly`) and runs automatically as Step F0 inside `forge:report`.

---

## BR-4: Git notes integration in weekly summaries

When generating weekly summaries, commit metadata written by `forge:commit` — specifically structured JSON git notes following ADR-008, linking commits to work items and requirements — must be surfaced in the summary alongside conventional commit log lines.

**Acceptance criteria:**
- For each commit in the week window, the skill reads any git note attached to that commit (via `git notes show <sha>`).
- If a git note contains structured JSON (ADR-008 format) with work-item or requirement linkages, those linkages are incorporated into the relevant sections of the weekly summary (e.g. Key Decisions, Development Work).
- Commits without git notes are handled gracefully and summarized from their commit message alone.
- Git note reading failures (missing notes, malformed JSON) do not interrupt summary generation; the skill proceeds with the commit message as the fallback.

---

## BR-5: Full report generation

From the accumulated weekly summaries, meeting transcripts, and project documentation, a comprehensive report must be generated in both HTML and Markdown formats covering all relevant sections.

**Acceptance criteria:**
- The default full report includes all auto-detected sections from: mandate, timeline, rollout, rollout-timeline, impediments, roadblocks, slippage, decisions, retro, coordination, loe.
- Both a `.html` file and a `.md` file are always produced together; neither is ever committed to the repository.
- Default output filenames are `YYYY-MM-DD-HHMM-full.html` and `YYYY-MM-DD-HHMM-full.md` when no preset or custom name is given. The timestamp reflects the generation time in local time.
- The report includes a hero section with project overview and stat tiles.
- Section content is synthesized from weekly summaries, transcripts, and git history — not generated from scratch without source material.

---

## BR-6: Delta (incremental) report generation

When only activity since a previous audit or a specified date is relevant, a delta report must be generated that focuses exclusively on what changed in that window.

**Acceptance criteria:**
- Invoking the skill with `--delta` generates an incremental report covering the period since the most recently detected `.html` file in `reports/full/` or `reports/delta/`, or since 7 days ago if no prior report is found.
- A specific cutoff date can be supplied with `--since <date>` (YYYY-MM-DD or natural language).
- A specific prior report can be named with `--compare <file>`, which sets the cutoff from that file's date.
- Delta report output filenames default to `YYYY-MM-DD-HHMM-delta.html` + `.md`; when `--out <name>` is used, the filename is `YYYY-MM-DD-HHMM-<name>.html`.
- Delta reports contain a distinct set of seven sections with stable HTML IDs: `delta-resolved`, `delta-incidents`, `delta-corrections`, `delta-progress`, `delta-status`, `delta-investigations`, `delta-open`.
- Both `.html` and `.md` are always produced.

---

## BR-7: Named report presets

Five named report presets must be available, each targeting a specific audience with a curated, audience-appropriate section selection and default filename.

**Acceptance criteria:**
- The following presets are supported: `status` (Programme Status Report), `launch` (Launch Readiness Report), `delivery` (Engineering Delivery Report), `debrief` (Project Debrief), `sizing` (Effort Sizing Report).
- Each preset resolves to a documented section list and sets the output subdirectory and filename type (e.g. `--report status` → `reports/status/YYYY-MM-DD-HHMM-status.html` + `.md`).
- `--report status` suppresses Data Quality Landmines and Recurring Capacity Drains sub-sections from the roadblocks section; only Structural Blockers are rendered.
- When `--report` and `--sections` are both supplied, `--sections` takes precedence.
- Each preset is also available as a dedicated sub-skill (`forge:report:status`, `forge:report:launch`, `forge:report:delivery`, `forge:report:debrief`, `forge:report:sizing`); each sub-skill simply prepends `--report <preset>` to the user's arguments and delegates to the main `forge:report` skill.

---

## BR-8: Output filename and section control

Users must be able to override the default output filename prefix and select or exclude individual report sections without authoring a new preset.

**Acceptance criteria:**
- `--out <name>` overrides the name portion of the output filename; the timestamp and subdirectory are always derived from the report type. Both full and delta reports produce `YYYY-MM-DD-HHMM-<name>.html`.
- `--sections <comma-list>` restricts the report to only the specified section IDs.
- `--exclude <comma-list>` omits named section IDs from an otherwise full or preset report.
- `--title <text>` overrides the auto-detected report title.
- All flag combinations produce both `.html` and `.md` output.

---

## BR-9: Report validation tooling

After a report is generated, a mechanical validation and review tool (`report_check.py`) must be available to catch stale dates, structural HTML errors, and out-of-order timeline cards.

**Acceptance criteria:**
- `report_check.py` is bundled with the Forge plugin at `${CLAUDE_SKILL_DIR}/report_check.py` and is also discoverable at `project_management/tools/report_check.py` in the consuming project.
- Running `report_check.py <report>.html` without `--fix` reports issues without modifying the file; exit code is non-zero if issues are found.
- Running with `--fix` auto-corrects: stale hero eyebrow date, stale footer date, stale `scored` and `best estimates as of` dates, timeline cards out of chronological order, missing or duplicate `· Current` labels, section count subtitle out of sync with actual week count.
- Review surface flags (`--scorecard`, `--timeline`, `--roadblocks`, `--impediments`, `--slippage`, `--decisions`, `--callouts`, `--all-sections`) print structured tables for each section so the user can cross-reference against latest project state.
- Delta reports trigger delta-specific checks (date range verification, stat tile verification) rather than full-report checks.
- When no file argument is provided, the tool auto-detects the most recent `*_report.html` or `report_delta_*.html` in the current directory.

---

## BR-11: HTML report visual design system

The HTML report must use a consistent, self-contained visual design system across all report types and presets.

**Acceptance criteria:**
- Every HTML report is fully self-contained — no external dependencies except a single Google Fonts import.
- The design uses a fixed three-family typography system (Playfair Display for display headings, Source Serif 4 for body, IBM Plex Mono for labels/metadata) with documented size, weight, letter-spacing, and line-height constraints.
- A fixed brand color palette (purple brand accent, semantic status colors green/yellow/red/orange/blue/amber) is applied consistently across all report types.
- The hero section uses a brand gradient background with a 2-column layout (left: title/description/meta; right: 2×2 stat tile grid) — this layout is fixed across all full reports.
- Delta reports use a compact hero variant with a horizontal 4-tile stat row instead of the 2×2 grid.
- The nav is light-background, full-width sticky, with a 2px brand-colored bottom border.
- Each timeline week is rendered as a structured card with five zones: spine dot, header (date meta + title + status pill), optional milestone banner, narrative summary, and 2-column content grid (decisions left, alerts/risks right).
- The roadblocks section always contains at least a Structural Blockers sub-section, optionally followed by Data Quality Landmines and Recurring Capacity Drains, separated by `.sub-label` dividers.

---

## BR-12: Complex section layout conformance

Three sections require precise, non-trivial HTML structures that must be reproduced exactly for `report_check.py` to parse them correctly.

**Acceptance criteria:**
- The `rollout-timeline` section renders five components in order: Gantt bar, date-band rows (2-column grid with status badge progression), Achievable/Not-Achievable summary cards, biggest schedule risk callout, and optional rolloff risk sub-section.
- The `impediments` section renders an overview bar of six anchor cards (one per category), six category blocks with the correct layout variant per category (2-column card grid for ESCALATE/COORDINATE/DOCUMENT/PLAN; flex-column rows for DEVELOP/CASCADE), and a "Critical leverage point" callout with counts that match the category blocks.
- The `coordination` section renders a table with six columns (External Party, What Was Needed, Should Have Started, Actually Started, Gap, Status) with row-level color coding (`coord-red`, `coord-yellow`, `coord-green`) based on kickoff timing.
- All three sections use HTML `id` attributes matching the canonical section IDs so `report_check.py` and `--sections`/`--exclude` flags can detect them.

---

## BR-13: Report terminology — no "audit" in default output

Report output filenames and tooling must not use the term "audit" as a prefix.

**Acceptance criteria:**
- The default full report output filename is `YYYY-MM-DD-HHMM-full.html` / `YYYY-MM-DD-HHMM-full.md`.
- The default delta report output filename is `YYYY-MM-DD-HHMM-delta.html` / `YYYY-MM-DD-HHMM-delta.md`.
- The validation tool is named `report_check.py` and located at `plugins/forge/skills/report/report_check.py` within the plugin.
- The auto-detect logic in `report_check.py` finds the most recently modified `.html` in `reports/full/` or `reports/delta/` — not `audit_*.html`.

---

## BR-14: Report output directory placement

Generated report files must be stored in a location meaningful to the effort, deployable, or product being reported on — not dumped into the current working directory or the repository root by default.

**Acceptance criteria:**
- If an active effort is detected (C0.1/C0.2), reports are written to `.forge/efforts/<id>/reports/`.
- If no effort is active but a deployable is present under `.forge/deployables/`, reports are written to `.forge/deployables/<id>/reports/`.
- If no effort or deployable is present but a product exists under `.forge/products/`, reports are written to `.forge/products/<id>/reports/`.
- If none of the above apply, reports are written to `reports/` at the repository root.
- When multiple deployables or products exist and no effort context is set, the skill prompts the user to select one.
- The `reports/` subdirectory is created automatically if it does not exist.
- The resolved output path is reported to the user as part of project context detection output.
- `report_check.py` auto-detection uses `OUTPUT_DIR` rather than the repo root when searching for prior reports.

---

## BR-10: Discovery bootstrapping from implementation

The business requirements and technical spec for the `forge:report` skill family must be reverse-engineered from the existing implementation and captured as formal Forge discovery artifacts, so that future development follows standard spec-driven workflow.

**Acceptance criteria:**
- `requirements/business.md` exists and contains BR entries covering all observable behaviors of the skill family.
- `requirements/technical.md` is created (or can be elaborated) from the business requirements via `forge:elaborate`.
- The discovery artifacts accurately reflect what was built, including the reviewer-identified gaps (effort scoping, git notes, bootstrapped discovery).
- `.state.json` reflects an updated suggested risk classification consistent with the scope of the requirements.

---

## PM Design Suggestions

The following implementation prescriptions were found in the source and are captured here separately from requirements. These inform how the skill should be implemented but are not themselves requirements.

1. **File discovery order for `report_check.py`:** Look first at `project_management/tools/report_check.py` in the current project, then at `${CLAUDE_SKILL_DIR}/report_check.py` (bundled co-located with the skill).
2. **Updates directory resolution order:** (1) existing directory with `updates_*.md` files, (2) `project_management/weekly_updates/`, (3) `updates/` at repo root, (4) create `project_management/weekly_updates/`.
3. **Project name resolution order:** (1) first H1 in `CLAUDE.md`, (2) first H1 in `README.md`, (3) repo basename.
4. **Git log command for commits (with notes):** `git log --since="YYYY-MM-DD 00:01" --until="YYYY-MM-DD 23:59" --pretty=format:"%H %h %s (%ad)" --date=short`; then `git notes show <full-SHA>` per commit for enrichment.
5. **Weekly summary filename convention:** `updates_{START_DATE}_{END_DATE}.md` (e.g. `updates_2026-02-10_2026-02-16.md`).
6. **Sub-skill delegation pattern:** Each preset sub-skill (`forge:report:status`, etc.) prepends `--report <preset>` to `$ARGUMENTS` and reads `${CLAUDE_SKILL_DIR}/../report/SKILL.md` to execute.
7. **Preset section lists:** `status` → mandate, rollout-timeline, slippage, roadblocks (structural only), coordination; `launch` → mandate, rollout, rollout-timeline, slippage, coordination, roadblocks (all); `delivery` → timeline, rollout, rollout-timeline, impediments, roadblocks (all), slippage, coordination, retro; `debrief` → mandate, timeline, decisions, slippage, retro; `sizing` → mandate, loe, coordination, slippage.
8. **HTML section IDs** are the canonical identifiers used for `--sections` / `--exclude` matching and by `report_check.py` for section detection.
9. **Neither `.html` nor `.md` output files are ever committed** to the repository (they are untracked artifacts).
10. **ADR-008 git notes format:** Structured JSON attached to commits by `forge:commit`; fields include work item and requirement linkages; read via `git notes show <sha>`.
