# Implementation Plan: forge:update-plan

## Wave 1

- [x] [auto][wave:1] Author `forge:update-plan` SKILL.md + create `forge-update-plan` capability directory (TASK-001) — 835cab1
