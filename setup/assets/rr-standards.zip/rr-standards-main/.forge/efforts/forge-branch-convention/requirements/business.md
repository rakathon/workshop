# Business Requirements — Forge Branch Convention

Parent effort: [forge-plugin](../../forge-plugin/.state.json)

---

### BR-1: Forge Must Not Force Repositories to Adopt a Specific Branch Naming Convention

Engineering teams have established CI/CD pipelines with branch-naming rules baked into
build triggers, deployment gates, and merge policies. These are not negotiable on a
per-tool basis. Forge's current enforcement of `effort/<id>` as the required branch
naming pattern is breaking CI/CD pipelines in repositories that use different
conventions (e.g., `PROJ-1234/description`, `DEV/slug`, `feature/JIRA-456-description`).

Forge must not require any specific branch naming pattern. Teams must be able to
use Forge in a repository without changing the branch convention their CI/CD pipelines
already enforce.

### BR-2: Branch Naming Convention Must Be Configurable Per Repository

Different repositories within the same organization may have different branch naming
conventions. A single global setting is not sufficient. The configuration that tells
Forge how to name effort-related branches must live in the repository itself so that
every engineer working in that repository automatically uses the correct convention
without per-machine setup.

### BR-3: The Branch Naming Configuration Must Be Expressive Enough for Any Convention

The mechanism for configuring branch naming must be able to represent any convention
a team uses — including Jira-prefixed patterns, free-form slugs, conventions with
multiple valid prefix types, and conventions with exceptions. A rigid template or
enumerated list of supported patterns is not sufficient. The configuration must be
readable and editable by engineers without requiring knowledge of Forge internals.

### BR-4: Forge Must Be Able to Name Branches Correctly Without Engineer Input

When creating a branch for a new effort, Forge must derive an appropriate branch name
from the configured convention automatically. Engineers should not need to manually
specify a branch name on every `forge:effort` invocation — the convention, once
configured, should be sufficient for Forge to make the right choice.

### BR-5: The Convention Must Be Inferable from Existing Repository History

For repositories that already have an established branch naming convention, engineers
must not have to describe it from scratch when setting up Forge. Forge must attempt
to detect the existing convention from git history and propose it for confirmation.
This reduces the setup burden and the risk of misconfiguration.

### BR-6: Repositories Using the Standard RR CI/CD Pipeline Must Get the Correct Default

The organization uses a standard Helm-based deployment pipeline delivered via
`rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml`.
This pipeline supports a specific set of branch prefixes: `feat/`, `feature/`,
`release/`, `hotfix/`, and `bugfix/`.

Branch names using these prefixes are the natural convention for repositories using
this pipeline. When Forge is initialized in a repository that uses the standard RR
CI/CD pipeline and has no established branch naming convention, the proposed default
must be this pipeline-aligned convention — not a Forge-internal pattern like
`effort/{id}` that has no meaning to the CI/CD system.
