# Technical Requirements — Forge Branch Convention

Parent effort: [forge-plugin](../../forge-plugin/.state.json)

> Note: Implementation design is captured in `spec/design.md`. This file records
> operational constraints, schema changes, and non-functional requirements not
> derivable from the design alone.

> Note: This effort depends on `forge-effort-pointer`. Branch naming is a generative
> and validation concern only — effort resolution from branch names is not in scope
> here and must not be re-introduced.

---

## Traceability

| TR | BRs |
|----|-----|
| TR-1 | BR-1, BR-2, BR-3 |
| TR-2 | BR-3, BR-4 |
| TR-3 | BR-1, BR-2 |
| TR-4 | BR-2, BR-5, BR-6 |
| TR-5 | BR-4, BR-5, BR-6 |
| TR-6 | BR-6 |
| TR-7 | BR-5, BR-6 |

---

## TR-1: Repository Branch Convention — `.forge/branching.md`

A new file `.forge/branching.md` must be introduced as the canonical repository-level
description of the branch naming convention. It is committed to git and shared across
the team. It has two distinct parts with different consumers:

**YAML frontmatter — consumed by hooks:**

```yaml
---
branch_regex: "^(feature|fix|chore)/[a-z0-9][a-z0-9-]*$"
---
```

The `branch_regex` field is a single POSIX extended regular expression. A branch name
must match this regex to be considered valid. Hooks extract this field at commit time
to perform validation without requiring Claude in the loop.

**Markdown body — consumed by skills (Claude):**

Free prose describing the naming convention in enough detail for Claude to derive the
correct branch name for any given effort. May include: the general pattern, examples,
naming rules, how Jira keys map to branch names, and any team-specific exceptions.

**File is optional.** If absent:
- Hooks fall back to the built-in Forge default validation regex (the RR CI/CD standard).
- Skills fall back to the RR CI/CD standard naming convention.

## TR-2: Branch Naming Is a Generative Concern, Not a Template Substitution

When `forge:effort` creates a branch for a new effort, it must read `.forge/branching.md`
(if present) and derive an appropriate branch name by interpreting the prose body.
There is no fixed token-substitution template — Claude reads the convention and applies
judgment, using the effort title, type, and any Jira key in `.state.json` as inputs.

If no `.forge/branching.md` exists, `forge:effort` applies the RR CI/CD standard
convention (see TR-6) as the default.

## TR-3: Hook Validation Must Use `branch_regex` from Frontmatter

`enforce-branch-policy.sh` must extract `branch_regex` from `.forge/branching.md`
frontmatter (if present) and use it to validate branch names at commit time.
Extraction must be done with a self-contained python3 invocation that parses the
YAML frontmatter block. If the file is absent or the field is missing, the hook
falls back to the built-in Forge default regex.

The hook must not attempt to parse the Markdown body — that is exclusively for
Claude's consumption.

## TR-4: `.forge/branching.md` Must Be Created by `forge:init`

`forge:init` must create `.forge/branching.md` as part of repository initialization.
The file must contain both a `branch_regex` frontmatter field and a prose body that
accurately describes the convention.

Before writing the file, `forge:init` must resolve the convention through the following
priority order (highest to lowest):

1. **Detect the RR standard CI/CD pipeline** (see TR-6) — if found, set the pipeline-
   aligned convention as the baseline proposal.
2. **Infer from git history** (see TR-5) — if a confident match is found, it overrides
   the baseline proposal.
3. **Detect branch filters in CI workflow files** (see TR-7) — if `.github/workflows/ci.yaml`
   or `.github/workflows/ci.yml` defines `on.push.branches` or `on.pull_request.branches`
   filters, extract the allowed prefixes and propose them as the convention.
4. **Forge default** — if none of the above yield a result, propose the Forge default
   convention (`effort/<id>` and standard type prefixes).

In all cases the proposed convention is shown to the engineer for confirmation before
the file is written.

## TR-5: Convention Inference from Git History

`forge:init` must analyze git history to infer the existing branch naming convention
before prompting the engineer. The inference uses two signals:

- Merge commit subject lines (branch names embedded by GitHub/GitLab merge messages)
- Remote tracking branch names

**Inference rules (apply in order, stop at first confident match):**

"Confident" means ≥ 60% of non-mainline branch names match the pattern, with a
minimum of 5 samples.

| Signal | Inferred convention |
|--------|---------------------|
| Majority match `[A-Z]+-\d+/.*` | Jira-prefixed: `PROJ-123/description` |
| Majority match `[A-Z]+-\d+-.*` | Jira-prefixed hyphen-separated: `PROJ-123-description` |
| Majority match `feat/.*`, `fix/.*`, `chore/.*` conventional prefixes | RR CI/CD aligned: conventional commit prefix convention |
| Majority match `feature/.*` or another consistent custom prefix | That prefix convention |
| Fewer than 5 samples or no dominant pattern | No inference — retain baseline from TR-6 or RR standard default |

If a convention is inferred, it is presented with evidence (match count and examples).
The engineer may confirm, adjust, or replace it.

After confirmation, `forge:init` writes `.forge/branching.md` with:
- A `branch_regex` that matches the confirmed convention.
- A prose body describing it in enough detail for Claude to name branches correctly
  for any effort, including how to handle efforts with and without Jira keys.

## TR-6: RR Standard CI/CD Pipeline Detection

When git history inference (TR-5) is not confident, `forge:init` must check whether
the repository uses the organization's standard CI/CD pipeline before falling back to
the Forge default.

**Detection signal:** The presence of a workflow file referencing
`rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml`
in `.github/workflows/`.

```bash
grep -rl "rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml" .github/workflows/ 2>/dev/null
```

**If the pipeline is detected:**

Propose the RR CI/CD-aligned convention as the default. This convention matches the
branch prefixes supported by the Helm-based deployment pipeline:

```markdown
---
branch_regex: "^(feat|feature|release|hotfix|bugfix)/[a-z0-9][a-z0-9-]*$"
---

# Branch Naming Convention

This repository uses the Rakuten Rewards standard CI/CD pipeline
(`rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml`).

Branch names must use one of the supported prefixes, followed by a short lowercase
hyphenated description of the work.

Pattern: `<type>/<description>`

Allowed prefixes:
- `feat/`     — new feature
- `feature/`  — new feature (long form)
- `release/`  — release preparation
- `hotfix/`   — urgent production fix
- `bugfix/`   — bug fix

When creating a branch for a Forge effort, choose the prefix that matches the
nature of the work. Use the effort title to derive the description slug.
Examples: `feat/add-user-preferences`, `bugfix/null-pointer-payment`, `hotfix/auth-timeout`
```

Present to the engineer:
```
Detected Rakuten Rewards standard CI/CD pipeline (helm-upgrade-nonprod).

Proposed default branch convention: <type>/<description>
  where <type> is one of: feat, feature, release, hotfix, bugfix
  Examples: feat/add-user-preferences, bugfix/auth-timeout, hotfix/payment-crash

Use this convention? [Y/n]
Or describe your convention in plain English or as a regex:
```

**If the pipeline is not detected:**

Proceed to git history inference (TR-5). If inference also yields no confident match,
proceed to CI branch filter detection (TR-7). If that also yields no result, propose
the Forge default convention.

## TR-7: CI Workflow Branch Filter Detection

When the RR standard CI/CD pipeline is not detected (TR-6) and git history inference
is not confident (TR-5), `forge:init` must inspect the repository's CI workflow file
for explicit branch filter configuration before falling back to the Forge default.

**Detection target:** `.github/workflows/ci.yaml` or `.github/workflows/ci.yml`
(check in that order; use the first one found).

**Extraction logic:**

Read the file and locate any of these YAML keys:
- `on.push.branches`
- `on.pull_request.branches`

Extract all listed patterns. Strip infrastructure entries (`main`, `master`,
`develop`, `HEAD`, `dependabot/**`, and wildcard-only entries like `**`).

From the remaining patterns, extract the prefix portion (the text before `/**`
or `/*`). Examples:
- `'feat/**'` → `feat`
- `'feature/*'` → `feature`
- `'release/[0-9]*'` → `release`
- `'hotfix-*'` → skip (not a slash-separated convention)

**Confidence rule:** at least 2 distinct non-infrastructure prefixes must be found
from an include list (`branches`, not `branches-ignore`) to proceed. If fewer than
2 are found, set `ci_branches_detected=false` — not enough signal.

**If `ci_branches_detected=true`:**

Construct `branch_regex` from exactly the detected prefixes:

```
^(<prefix1>|<prefix2>|...)/[a-z0-9][a-z0-9-]*$
```

Present to the engineer:

```
Detected branch filters in .github/workflows/ci.yaml:
  Allowed prefixes: <prefix1>, <prefix2>, ...
  (e.g. <example-1>, <example-2>)

Use this as the branch naming convention? [Y/n]
Or describe your convention in plain English or as a regex:
```

The `branch_regex` written to `.forge/branching.md` must contain **only** the
prefixes found in the CI filter — no extras may be added.

**`branches-ignore` patterns are not used** — they tell us what is excluded, not
what is allowed, and cannot be safely inverted into a naming convention.
