# Design Spec — Forge Branch Convention

---

## Overview

This effort introduces `.forge/branching.md` — a committed, repository-shared file
that describes the branch naming convention for a repository. It serves two consumers:

- **Hooks** read the `branch_regex` YAML frontmatter field for commit-time validation.
- **Skills (Claude)** read the Markdown prose body to derive correct branch names when
  creating branches for new efforts.

This effort depends on `forge-effort-pointer`. Branch names are not used for effort
resolution — that is handled by `.forge/EFFORT`. This effort is solely about branch
naming and validation.

---

## New File: `.forge/branching.md`

### Structure

```markdown
---
branch_regex: "<POSIX ERE pattern>"
---

# Branch Naming Convention

<Prose description for Claude>
```

### Frontmatter

One field: `branch_regex`. A single POSIX extended regular expression that branch
names must match to pass hook validation. Hooks extract this with python3.

### Body

Free Markdown prose. Must contain enough information for Claude to derive a correct
branch name for any effort without further input. Recommended content:

- The general pattern (with examples)
- How the effort title maps to a branch slug
- How Jira keys are incorporated when present
- Any exceptions (e.g. hotfix branches, release branches)

### Examples

**GitHub Flow:**
```markdown
---
branch_regex: "^(feature|fix|chore|hotfix|release)/[a-z0-9][a-z0-9-]*$"
---

# Branch Naming Convention

Branches use a type prefix followed by a short lowercase hyphenated description.

Pattern: `<type>/<description>`

Types:
- `feature/` — new functionality
- `fix/` — bug fixes
- `chore/` — maintenance, dependency updates, non-functional changes
- `hotfix/` — urgent production fixes (branch from release tag, not main)
- `release/` — release preparation branches

When creating a branch for a Forge effort, derive the description from the effort
title: lowercase, spaces to hyphens, strip special characters.
Example: effort "Add user preferences" → `feature/add-user-preferences`
```

**Jira-prefixed:**
```markdown
---
branch_regex: "^[A-Z]+-[0-9]+/[a-z0-9][a-z0-9-]*$"
---

# Branch Naming Convention

Branches must begin with a Jira issue key followed by a slash and a short
lowercase hyphenated description.

Pattern: `<JIRA-KEY>/<description>`
Examples: `REWD-1234/add-user-preferences`, `PLAT-89/fix-auth-timeout`

When creating a branch for a Forge effort, use the Jira key from the effort's
`.state.json` if one is present. If no Jira key is associated with the effort,
use `feature/<effort-id>` and flag to the engineer that a Jira ticket should
be linked before merging.
```

---

## Changes by Component

### `forge:effort` — SKILL.md

**Branch naming (Step 9.5):**

```
1. Check whether .forge/branching.md exists.
2. If it exists:
     Read the full file.
     Derive an appropriate branch name by interpreting the prose body.
     Inputs available: effort title, effort type, effort ID, Jira key from
     .state.json (if present).
3. If it does not exist:
     Use default: effort/<effort-id>
4. git checkout -b <branch_name>
   On collision: git checkout <branch_name>
```

Print the derived branch name in the Step 10 summary.

---

### `hooks/pre-tool-use/enforce-branch-policy.sh`

Replace the hardcoded regex with a config-driven lookup:

```bash
branch_regex=""
if [ -f ".forge/branching.md" ]; then
  branch_regex=$(python3 -c "
import re
try:
  content = open('.forge/branching.md').read()
  m = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
  if m:
    for line in m.group(1).splitlines():
      if line.strip().startswith('branch_regex:'):
        val = line.split(':', 1)[1].strip().strip('\"').strip(\"'\")
        print(val)
        break
except:
  pass
" 2>/dev/null)
fi

if [ -z "$branch_regex" ]; then
  branch_regex="^(effort|feature|feat|fix|hotfix|chore|docs|refactor|release)/[a-z0-9][a-z0-9-]*$"
fi

if [[ ! "$current_branch" =~ $branch_regex ]]; then
  # existing enforcement logic (warn or block)
fi
```

---

### `forge:init` — SKILL.md

Add a new step to the init sequence to create `.forge/branching.md`.

**Step — Detect pipeline, infer from history, confirm convention:**

**1. Detect RR standard CI/CD pipeline:**

```bash
grep -rl "rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml" .github/workflows/ 2>/dev/null | head -1
```

If detected, set baseline proposal:
```
branch_regex: "^(feat|feature|release|hotfix|bugfix)/[a-z0-9][a-z0-9-]*$"
```

**2. Infer from git history (overrides pipeline baseline if confident):**

Run inference commands:

```bash
# Merge commit messages often contain branch names
git log --merges --pretty=format:"%s" -200 \
  | grep -oE "[a-zA-Z0-9_-]+/[a-zA-Z0-9_/.-]+" \
  | grep -vE "^(origin|HEAD)/" | sort | uniq -c | sort -rn | head -30

# Remote tracking branches
git branch -r --format="%(refname:short)" 2>/dev/null | sed 's|^origin/||' \
  | grep -vE "^(main|master|HEAD|develop)$"
```

Apply inference rules (stop at first confident match — ≥ 60%, minimum 5 samples):

| Signal | Inferred convention |
|--------|---------------------|
| Majority match `[A-Z]+-\d+/.*` | Jira-prefixed: `PROJ-123/description` |
| Majority match `[A-Z]+-\d+-.*` | Jira-hyphenated: `PROJ-123-description` |
| Majority match `feature/.*` or `feat/.*` | GitHub Flow / RR-aligned |
| Majority match a consistent custom prefix | Custom: `<prefix>/description` |
| < 5 samples or no dominant pattern | No inference |

**3. Present inferred convention for confirmation:**

If inferred (e.g. 14 of 18 recent branches match `feature/.*`):
```
Detected branch naming convention: feature/<description>
  (based on 14 of 18 recent branches, e.g. feature/add-login, feature/fix-timeout)

Use this convention for Forge effort branches? [Y/n]
Or describe your convention in plain English or as a regex:
```

If not inferred and RR pipeline detected:
```
Detected Rakuten Rewards standard CI/CD pipeline (helm-upgrade-nonprod).

Proposed default branch convention: <type>/<description>
  where <type> is one of: feat, feature, release, hotfix, bugfix
  Examples: feat/add-user-preferences, bugfix/auth-timeout, hotfix/payment-crash

Use this convention? [Y/n]
Or describe your convention in plain English or as a regex:
```

If not inferred and no pipeline detected:
```
Could not detect an existing branch naming convention.

Forge default: effort/<effort-id>
  Examples: effort/add-login, effort/fix-session-timeout

Use this convention? [Y/n]
Or describe your convention in plain English or as a regex:
```

**Write `.forge/branching.md`:**

From the confirmed convention, write the file:

- If the engineer confirmed an inferred or default pattern: derive `branch_regex`
  from the pattern, write a prose body that accurately describes the convention.
- If the engineer provided a regex directly: use it verbatim as `branch_regex`, ask
  for a short prose description to include in the body.
- If the engineer described the convention in plain English: derive both the regex and
  the prose body from the description, then confirm both with the engineer before writing.

The prose body must be specific enough that Claude can derive a correct branch name
for any effort — including efforts with and without Jira keys, and efforts of different
types (feature, fix, chore).

---

## Backward Compatibility

**Existing repositories (no `.forge/branching.md`):** Hooks use the built-in default
regex. Skills use `effort/<effort-id>`. Behavior is identical to today.

**Existing `effort/<id>` branches:** Still valid. The default regex includes `effort/`
as an accepted prefix. If a team configures a custom `branch_regex` that excludes
`effort/`, they are intentionally opting out of the default and existing branches
may fail validation — this is expected and acceptable.

---

## Dependency Note

This effort ships after `forge-effort-pointer`. The `forge:effort` branch creation
step (Step 9.5) is modified by both efforts — `forge-effort-pointer` adds the
`.forge/EFFORT` write, this effort replaces the hardcoded branch name with
convention-driven naming. Both changes must be present in the final implementation.
