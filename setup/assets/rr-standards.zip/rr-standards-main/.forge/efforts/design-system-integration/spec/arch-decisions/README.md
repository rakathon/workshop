# Architecture Decisions — design-system-integration

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-001](ADR-001-single-ui-skill-with-runtime-platform-detection.md) | Single forge:ui Skill with Runtime Platform Detection | Accepted | 2026-04-24 |
