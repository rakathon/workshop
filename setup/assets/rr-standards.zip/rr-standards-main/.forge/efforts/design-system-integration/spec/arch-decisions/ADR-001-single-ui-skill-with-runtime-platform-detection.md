# ADR-001: Single forge:ui Skill with Runtime Platform Detection

**Status:** Accepted
**Effort ID:** design-system-integration
**Date:** 2026-04-24
**Created by:** design-system-integration

## Context

During discovery, the question arose of whether to build separate skills per platform
(`forge:ui-web`, `forge:ui-android`, `forge:ui-ios`) or a single skill that handles
all platforms. The initial argument for separate skills was that UI-building prompts
("add a hero section with a store grid") are platform-agnostic, so the wrong skill
could trigger on a given prompt.

The proposed solution was to use project file detection inside each skill to resolve
the platform after triggering. This was identified as circular reasoning: skill
selection happens before the skill runs, so platform-specific trigger conditions cannot
be reliably derived from prompt text alone. Separate skills do not solve the prompt
ambiguity problem — they move it to the user.

The platform-specific knowledge required to generate correct UI code is already
organized by language under `languages/` in the plugin. The skill boundary and the
guide organization are independent concerns.

## Decision

We will build a single `forge:ui` skill that detects the target platform as its first
step by inspecting project build files, then loads only the standards and language
guides for the detected platform.

Platform detection rules:
- Web: `package.json` containing `@rakuten-rewards/uikit`
- Android: `build.gradle` or `settings.gradle` present
- iOS: `Package.swift` or `.xcodeproj` present

If multiple platforms are detected (e.g. a monorepo), the skill asks the engineer to
clarify before proceeding. If no platform can be detected, the skill surfaces a clear
error.

## Alternatives Considered

**Separate skills per platform (`forge:ui-web`, `forge:ui-android`, `forge:ui-ios`)**
Rejected. Prompt-to-skill mapping occurs before the skill runs, so platform-specific
trigger conditions cannot be reliably derived from prompt text. Separate skills would
require the user to know which platform skill to invoke, which defeats the purpose of
automatic triggering. Adding a new platform would also require adding a new skill entry
point rather than just adding new language guides.

## Consequences

- A single invocation surface means no user confusion about which skill to call.
- Platform knowledge remains in language guides under `languages/`, not in the skill
  body — guides evolve independently of the skill.
- Adding Android or iOS support in the future requires only new language guides and an
  extension of the platform detection step; no structural skill changes are needed.
- The skill must handle a "platform not detected" failure gracefully for repos with no
  recognizable build files.
- Monorepos with multiple platforms require one explicit clarifying question per
  invocation in ambiguous cases.
