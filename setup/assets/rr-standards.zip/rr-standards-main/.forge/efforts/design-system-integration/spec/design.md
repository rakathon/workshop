# Discovery Spec — Design System Integration

---

## Deliverables Overview

This effort produces four interconnected deliverables:

| Deliverable | Type | Status | Location |
|-------------|------|--------|----------|
| `design-tokens.md` | Frontend standard | ✓ Complete | `plugins/forge/standards/frontend/` |
| `component-selection.md` | Frontend standard | ✓ Complete | `plugins/forge/standards/frontend/` |
| `responsive-layout.md` | Frontend standard | ✓ Complete | `plugins/forge/standards/frontend/` |
| `ui-design-system/` guides | TypeScript/React language guides | ✓ Complete | `plugins/forge/languages/typescript/react/default/guides/ui-design-system/` |
| `forge:ui` skill | Forge skill | In progress | `plugins/forge/skills/ui/` |

Standards and language guides are complete. The `forge:ui` skill is the remaining
deliverable.

The three-skill architecture originally proposed (`ui-explore`, `ui-component`,
`ui-implement`) has been superseded. See ADR-001.

---

## Standards Architecture

The three frontend standards are complete and validated:

- `plugins/forge/standards/frontend/design-tokens.md` — token vocabulary (color,
  spacing, typography, shadow, border-radius), rules for token usage
- `plugins/forge/standards/frontend/component-selection.md` — component tier hierarchy
  (composite section components first, layout primitives second), import source rules
- `plugins/forge/standards/frontend/responsive-layout.md` — mobile-first breakpoint
  contract, standard section padding, grid column progressions

Companion language guides are complete under
`plugins/forge/languages/typescript/react/default/guides/ui-design-system/`:
- `tokens.md` — concrete UIKit token values and prop usage
- `components.md` — runnable examples for every UIKit component tier
- `responsive-layout.md` — breakpoint patterns and complete section examples
- `page-patterns.md` — homepage and category landing page templates

---

## Skill Architecture

### `forge:ui` — Single Skill, Runtime Platform Detection

**ADR:** [ADR-001](arch-decisions/ADR-001-single-ui-skill-with-runtime-platform-detection.md)

**Purpose:** Generate standards-compliant UI code in any repo using a Rakuten Rewards
design system. Detects the target platform from project build files, loads the
appropriate standards and language guides, then generates correct output without
requiring the user to specify a platform.

**Agent type:** Orchestrator

**Trigger:** UI-building prompts — "build me a page", "add a hero section",
"create a landing page", "I need a store carousel", "generate this UI".

**Platform detection (Step 1):**

| Signal | Platform |
|--------|----------|
| `package.json` containing `@rakuten-rewards/uikit` | Web (TypeScript/React) |
| `build.gradle` or `settings.gradle` present | Android (Kotlin) — future |
| `Package.swift` or `.xcodeproj` present | iOS (Swift) — future |

If multiple platforms detected: ask engineer to clarify before proceeding.
If no platform detected: surface a clear error with setup instructions.

**Web workflow (current):**

1. Detect platform → load `standards/frontend/` + `languages/typescript/react/default/guides/ui-design-system/`
2. Ask ≤3 clarifying questions about what to build (scope, data, sections)
3. Plan page structure top-to-bottom; state assumptions
4. Generate standards-compliant TSX inline — no dev environment management, no specific repo structure required
5. Validate output mentally against standards before emitting (no raw hex, no missing responsive props, correct component tier)

**Standards loaded at runtime:**
- `plugins/forge/standards/frontend/design-tokens.md`
- `plugins/forge/standards/frontend/component-selection.md`
- `plugins/forge/standards/frontend/responsive-layout.md`
- `plugins/forge/languages/typescript/react/default/guides/ui-design-system/` (all four guides)

**Skill location:** `plugins/forge/skills/ui/SKILL.md`

---

## Deferred Scope

The following requirements from the original discovery are explicitly out of scope
for this effort. They are deferred to a future effort, not abandoned.

### UIKit Component Authoring (BR-5, TR-5)

**Deferred.** BR-5 required a skill to guide engineers through authoring new
components for `@rakuten-rewards/uikit` — covering Props API design, design-token
alignment, Storybook story authoring, and WCAG 2.1 AA accessibility. TR-5 defined
the enforcement rules for that skill.

**Rationale:** `forge:ui` is scoped to *consuming* the UIKit in feature repositories.
Component authoring is a distinct workflow that targets the UIKit *library itself*, not
its consumers. It involves different preconditions (UIKit repo access, Storybook setup),
different outputs (component source, stories, JSDoc), and different quality gates
(accessibility audit, Props interface export). Bundling it into `forge:ui` would broaden
the skill beyond its validated scope and introduce precondition complexity that affects
every invocation, even when component authoring is not the goal.

**Next effort:** `forge:ui-component` — a dedicated skill for UIKit component authoring.

### Prototype-to-Production Handoff (BR-4, TR-7)

**Partially addressed; handoff artifact format deferred.** BR-4 required a path from
prototype to production. This is addressed: `forge:ui` supports a `production` mode
(driven by `forge:ui-design`) that accepts a Figma link or written spec and generates
production-quality TSX with all required states. The `ui-spec-template.md` serves as
the structured input that carries design decisions from exploration into implementation.

TR-7 required a discrete handoff artifact written by `forge:ui-design` when an
engineer signals "promote this prototype." The `ui-spec.md` template covers the
structural need, but the explicit "promote" trigger within `forge:ui-design` (a step
that writes a finalized handoff record) is not yet implemented.

**Deferred:** The `promote` trigger and any additional handoff format fields beyond
`ui-spec.md` are deferred to a follow-on effort or a future iteration of
`forge:ui-design`.

---

## Resolved Decisions

| Question | Resolution |
|----------|------------|
| Single skill vs. per-platform skills | Single `forge:ui` skill — see ADR-001 |
| Skill namespace | `forge:ui` — under the forge plugin, consistent with other forge skills |
| Styleguide repo dependency | None — skill generates code directly, no external repo dependency |
| Standards authoring order | Complete — standards authored before skill (satisfies TR-8) |
