# Technical Requirements — Design System Integration

> Implementation design (skill step sequences, module structures, branching logic)
> is captured in `spec/skill.md` per skill. This file records operational constraints,
> external dependencies, standards gaps, and non-functional requirements not derivable
> from the skill designs alone.

---

## Traceability

| TR   | BRs        |
|------|------------|
| TR-1 | BR-1, BR-6 |
| TR-2 | BR-2, BR-6 |
| TR-3 | BR-3, BR-7 |
| TR-4 | BR-4       |
| TR-5 | BR-5, BR-1 |
| TR-6 | BR-2, BR-3 |
| TR-7 | BR-4, BR-5 |
| TR-8 | BR-6       |
| TR-9 | BR-2, BR-7 |

---

## TR-1: Frontend Standards Must Cover UI/UX Authoring Before Skills Are Written

The `plugins/forge/standards/frontend/` directory currently contains
`data-fetching.md` and `external-store-subscriptions.md`. This effort must extend it
with at minimum:

- `design-tokens.md` — canonical token vocabulary (spacing, color semantics, typography
  textStyles, border radius, shadows, breakpoints), with the `@rakuten-rewards/uikit`
  Chakra theme as the implementation reference
- `component-selection.md` — decision hierarchy for choosing a Topic component over
  a primitive, or a primitive over raw CSS; when each tier is appropriate
- `responsive-layout.md` — mobile-first breakpoint contract, required responsive prop
  patterns, and when to use `base`/`medium`/`large` vs. finer breakpoints

These standards must be authored before the skills that reference them are written,
since TR-8 forbids skill content from duplicating standards content.

Companion `.policy.md` files and `.test.yaml` behavioral test specs must be produced
alongside each new standard, following the pattern established by
`external-store-subscriptions.policy.md` and `external-store-subscriptions.test.yaml`.

## TR-2: Each Skill Must Have a Compliant SKILL.md

Each skill produced by this effort (`ui-explore`, `ui-component`, `ui-implement`) must
have a `SKILL.md` that conforms to the rr-standards skill taxonomy (`TAXONOMY.md`
§ Skill). Required sections are: trigger conditions, preconditions, numbered steps,
standards references, and agent type declaration (orchestrator vs. worker).

The SKILL.md is the canonical skill definition. Module files are permitted for
organizing reference content but the SKILL.md controls execution flow.

## TR-3: The Explore Skill Must Start the Dev Server Without Manual Steps

The existing `rakuten-styleguide` skill's `setup.md` requires the engineer to have
already cloned the styleguide repository and have Yarn installed. The redesigned
`ui-explore` skill must detect whether the dev environment is available and provide
actionable remediation steps when it is not — one clear message per missing
prerequisite. If the dev server is already running on the expected port, the skill must
use it without restarting it.

The skill must not require knowledge of the underlying repository structure. The
repository path and port must be discoverable from the skill's preconditions or
configurable via a setting, not hardcoded in the SKILL.md.

## TR-4: Production Implementation Skill Must Enforce Standards at Output Time

`ui-implement` must validate its generated code against the frontend standards defined
in TR-1 before reporting completion. Specifically:

- No raw hex color values in generated component code (must use semantic tokens)
- No hardcoded pixel spacing values (must use token names)
- All interactive elements must have `aria-*` attributes or use components that
  provide them natively
- Responsive props must be present on all layout-affecting props for Container,
  Grid, and spacing-sensitive components

These checks are behavioral, not syntactic — the skill must reason about the output,
not just grep for patterns.

## TR-5: Component Authoring Skill Must Enforce UIKit API Conventions

> **Scope note:** **Deferred** — see BR-5. UIKit component authoring is out of scope
> for this effort. This TR is retained for the follow-on `forge:ui-component` effort.

`ui-component` must guide the engineer toward API shapes consistent with existing UIKit
components. The following conventions are non-negotiable and must be checked:

- Props that accept visual variants must use a `variant` prop with a string union,
  not separate boolean flags (e.g., `variant="primary"` not `isPrimary`)
- All color-bearing props must accept design token names, not raw hex values
- Components must include a Storybook story covering at minimum: default state,
  all variants, and a responsive example
- Components must export their Props interface as a named export alongside the
  component itself
- Every new component must pass a WCAG 2.1 AA accessibility baseline: color contrast,
  keyboard navigability, and appropriate ARIA roles

## TR-6: The Explore Skill Must Be Usable via a Single Natural-Language Invocation

A user who types `/ui-explore create a cashback milestone page with a hero and store
grid` must receive a running prototype without additional configuration steps. The skill
must ask no more than 3 clarifying questions before producing code; questions about
colors, spacing, or typography are forbidden (these are applied from standards
automatically). *(BR-3, BR-7)*

## TR-7: A Handoff Format Must Be Defined Between Explore and Implement

> **Scope note:** Partially addressed. `ui-spec-template.md` satisfies the structural
> requirement for a machine-readable input to the production workflow. The discrete
> "promote this prototype" trigger within `forge:ui-design` is **deferred** to a
> follow-on effort. See `spec/design.md` — Deferred Scope.

The boundary between a proof-of-concept prototype and a production implementation
requires a defined artifact: a design spec that records which prototype screens are
being promoted, the decisions made during exploration (component choices, token
overrides, layout deviations), and the requirements to be met in production
(accessibility, error states, loading states, responsive behavior). The format of this
handoff artifact must be specified as part of this effort's discovery.

This artifact does not need to be complex — it may be as lightweight as a structured
Markdown file written by `ui-explore` when the engineer asks to "promote this prototype"
— but it must exist so that `ui-implement` has a machine-readable input.

## TR-8: Skills Must Reference Standards by Path, Not Reproduce Their Content

No skill produced by this effort may include inline tables of design tokens, component
catalogs, or token-to-CSS mappings. These must be referenced by relative path to the
canonical standard file under `plugins/forge/standards/frontend/`. If a skill's step
requires token lookup, it must instruct the model to read the standard file, not
provide the lookup table inline.

This is enforced at skill review time via `rr-standards:validate`.

## TR-9: The Explore Skill Must Operate Inside the Existing Styleguide Repository

The design team already has the `rr-styleguide-cover` repository cloned and running.
The `ui-explore` skill must target that repository's dev server and `playground.tsx`
pattern — it must not require creating a new project or changing tools. The repository
path must be discoverable from a convention or configurable setting, not hardcoded in
the skill body. If the repository is not found at the expected location, the skill must
surface a clear setup instruction rather than failing silently.
