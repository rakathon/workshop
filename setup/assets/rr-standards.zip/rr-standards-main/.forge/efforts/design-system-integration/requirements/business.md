# Business Requirements — Design System Integration

---

## Context

The Rakuten Rewards design team has built a working skill (`rakuten-styleguide`) that
enables rapid UI prototyping from Figma designs or natural language prompts using the
`@rakuten-rewards/uikit` and `@rakuten-rewards/appshell` component libraries. The
skill works today and produces real value — but it was authored without knowledge of
Forge, rr-standards, or our organizational standards architecture. It is tightly
coupled to a single Next.js repository, has no formal standards documentation backing
it, and produces no guidance about production-quality implementation or UI kit
component authoring.

This effort bridges the gap between the design team's prototyping practice and the
engineering standards framework, and expands coverage to three distinct workflows that
currently have no structured skill or standard support:

1. **UI/UX exploration and proof of concept** — rapid iteration before any production
   commitment
2. **UI kit component authoring** — designing and building new components for the
   shared `@rakuten-rewards/uikit` library
3. **Production implementation from a design spec** — translating a finalized design
   handoff into production-quality, standards-compliant frontend code

---

### BR-1: UI/UX Standards Must Be Captured Formally

The design team's skill encodes significant tacit knowledge about brand compliance,
design token usage, component selection hierarchy, and responsive patterns. This
knowledge currently lives only in a skill's module files — it is not expressed as a
reusable standard that can be applied across tools, teams, or skill versions. The
organizational frontend standards (currently covering external store subscriptions and
data fetching) must be extended to cover UI/UX authoring: design token usage, component
selection hierarchy, responsive layout, and brand compliance rules. These standards must
be the canonical source of truth that skills reference, not re-encode.

### BR-2: The Prototyping Workflow Must Be a Forge-Aligned Skill

The existing `rakuten-styleguide` skill works but is not Forge-aligned: it has no
SKILL.md structure, no precondition checks, no standards references, and no integration
with rr-standards tooling. A redesigned prototyping skill must fit the Forge skill
architecture (SKILL.md-based, with preconditions, steps, and references to
organizational standards). The skill must support both the Figma-to-prototype and
prompt-to-prototype workflows that the design team already uses. Engineers must be able
to invoke it as a slash command (`/rr-standards:ui-explore` or equivalent) without
needing to know the underlying Next.js project's structure.

### BR-3: The Prototyping Skill Must Remain Low-Friction for the Design Team

The design team's primary concern is speed — they need to move from idea to running
prototype in minutes, not hours. Any redesigned skill must preserve or improve on the
current workflow's speed. Requiring the design team to learn Forge concepts or fill in
effort artifacts before prototyping would contradict BR-3. The skill's entry point must
be as simple as: describe what you want (or share a Figma node) → get running code.
Forge alignment is a structural concern for engineers building the skill; it must be
invisible to the design team using it.

### BR-4: There Must Be a Defined Path From Prototype to Production

Currently, prototypes produced by the design skill are disconnected from production
implementation. There is no standard for when a prototype is "good enough" to become
a production reference, no handoff format, and no skill that helps an engineer
implement from a design spec. The result is that production implementations either
ignore the prototype entirely or copy code that was written for demonstration, not
production. A skill must exist that takes a design spec (whether that is a Figma link,
a prototype URL, or a written specification) and guides an engineer through a
production-quality implementation that passes organizational frontend standards.

> **Scope note:** The core requirement is met by `forge:ui` production mode driven by
> `forge:ui-design` and `ui-spec-template.md`. The discrete "promote this prototype"
> trigger and associated handoff record format are **deferred** to a follow-on effort.
> See `spec/design.md` — Deferred Scope.

### BR-5: UI Kit Component Authoring Must Be a Supported Workflow

New components added to `@rakuten-rewards/uikit` currently have no standard guidance
for how they should be designed, structured, or documented. Components are added
ad-hoc, leading to inconsistencies in API shape, token usage, accessibility compliance,
and Storybook coverage. A skill must exist that guides an engineer or designer through
the authoring of a new UIKit component: from design-token alignment through API design,
accessibility requirements, Storybook story authoring, and documentation. The skill
must reference and enforce the frontend standards established in BR-1.

> **Scope note:** **Deferred.** UIKit component authoring targets the UIKit library
> itself, not its consumers. This workflow is out of scope for this effort and will be
> addressed by a dedicated `forge:ui-component` skill in a follow-on effort.
> See `spec/design.md` — Deferred Scope.

### BR-6: Skills Must Encode Standards References, Not Standards Content

None of the three new skills (explore, component, production) should reproduce the
content of organizational standards inline. If the spacing token table appears in a
skill's module file, it will drift from the canonical standard the next time tokens are
updated. Skills must reference standards by path; standards are the single source of
truth. This separation is both a quality requirement and a maintenance requirement.

### BR-7: The Design Team Must Be Able to Use Skills Without Knowing the Standards Framework

The design team uses Claude Code today to prototype but has no knowledge of SKILL.md
files, rr-standards taxonomy, or Forge. Skills built under this effort must be usable
by someone who types a natural-language prompt. The standards framework backing the
skills is for engineers authoring and maintaining skills — not for the end users of
those skills.
