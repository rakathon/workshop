# Privacy Workshop — Meeting Summary
**Date:** 2026-04-10  
**Attendees:** Benjamin Vogan, Tammy Griffin (Privacy), Cory Hartford (Engineering)  
**Duration:** ~2h 10m

---

## Purpose

Kickoff workshop to align the privacy team and engineering on using the Forge framework to automate per-repo data mapping, field-level classification, and eventually DSR (Data Subject Rights) workflows.

---

## Key Discussion Points

### 1. Forge Introduction

Benjamin walked Tammy and Cory through the Forge framework for the first time:

- Forge addresses the AI-driven shift in the SDLC, where code generation is fast but the work before (requirements, design) and after (validation, QA) becomes the bottleneck.
- Forge is structured around four primitives: **efforts**, **deployables**, **capabilities**, and **products**.
- Standards are rule-based (not prose), enabling policy-driven enforcement (blocking vs. advisory) in code review and CI gates.
- Organizational learnings (incidents, bugs, process improvements) can be encoded into Forge standards and automatically benefit all teams.

### 2. Data Map Goal

The primary goal of this effort is to produce a **per-deployable data map** inside every repository — a machine-readable file documenting:

- All durable data stores (databases, S3 buckets, Kafka topics, etc.)
- All tables and fields within those stores
- Data provenance — where each field originated (API input, upstream message, etc.)
- Two classification dimensions per field:
  - **Data governance category** (e.g., Transcend/Julia's category matrix)
  - **DSR scope** — whether each field must be deleted, obfuscated, or returned on user request

### 3. Classification Landscape

The team clarified the current state:

- **Julia's Transcend tool** scans databases and applies privacy categories. Her category matrix is used to train the tool and describes what data points fall under each category.
- **Tammy's DSR tagging map** (Privacy Center Tagging Map) manually tags each column as in-scope for access, soft delete, hard delete, or do-not-share — currently done in Excel.
- A **Transcend-to-Rakuten category mapping** (just finalized with legal) links Transcend categories to the user-facing Privacy Center categories.
- **Retention schedules** have been defined by the Japan Privacy Office (JPO) per data category.
- The two systems (data governance and DSR scope) currently live separately and are not unified in one view.

**Benjamin's position:** The category system can be treated as relatively static; encoding it into Forge as a standard is feasible. The harder problem is the DSR scope classification — the rules aren't fully codified yet, so teaching an AI to automate it is a challenge.

### 4. Code-Based vs. Schema-Based Discovery

Cory raised whether the AI would need to read database schemas directly, since not all fields have a corresponding code class (e.g., PCDP writes audit logs that exist only in the DB schema, not in application code).

Benjamin's response:
- The AI can look beyond ORM classes — it can identify any `INSERT` statement regardless of pattern (Hibernate, raw JDBC, background threads, etc.).
- For the edge case of fields that exist in the DB but are orphaned from code, looking at the database schema as a complement is valid.
- For the typical case, code inspection plus following data to its insert point should be sufficient.
- The AI can infer that a column called `id` is a `member_id` by tracing where it entered the system (e.g., via an API parameter documented as `memberId`).

### 5. Snowflake and Lineage

- Deletes propagated from microservice databases to Snowflake's raw landing layer are partially working (CDC exists on some Postgres pipelines) but are inconsistent.
- Cory noted that Aziz confirmed CDC can be configured on squad databases to propagate deletes to Snowflake — this was flagged as a reasonable ask during DPAAP integration.
- Everything downstream of the raw Snowflake layer (ETL pipelines, BI transformations) is out of scope for Phase 1. The application-level data map covers only the application's writes and the first landing layer.
- Data platform (Snowflake lineage beyond landing) is a future phase.

### 6. Asynchronous DSR Processing

Cory flagged that Journey (and likely other services) will not be able to process delete/access requests synchronously due to data volume:

- **Option A:** Keep the existing DPAAP API model but have services enqueue the work and call a webhook back to Privacy Center when done.
- **Option B:** Publish a single Kafka message (e.g., `user.delete.requested`); all subscribed services consume it, perform the work, and publish completion messages. Privacy Center listens for all acknowledgments.

Benjamin favored Option B for decoupling. The privacy SDK would handle lifecycle management, retries, and error reporting so service teams don't need to build this themselves.

### 7. Decentralized vs. Centralized Deletion Model

Benjamin outlined concerns with the existing centralized model (Privacy Center connecting directly to all DBs):

1. **Invisibility** — teams don't see how their data is classified or what will be deleted.
2. **Application stability** — direct DB deletes bypass application logic and may break invariants.
3. **Storage technology breadth** — the privacy team can't know every storage technology across the company.

With AI, the calculus changes: the AI understands all storage technologies and can generate correct deletion logic. The data map in the repo gives teams visibility. Tests can be auto-generated to verify deletion behavior.

### 8. Live Forge Demo

Benjamin ran `forge:effort` to create the `data-privacy` effort in rr-standards, then live-drafted initial business requirements with AI assistance. The team reviewed and trimmed the AI-suggested BRs:

**Retained BRs (paraphrased):**
- Durable data inventory per deployable (tables, S3, Kafka fields, etc.)
- Two-dimensional field-level classification (data governance + DSR scope)
- Classification standards encoded as organizational artifacts in Forge
- Field provenance / source traceability
- Automated discovery — no manual entry required
- Map must remain current with codebase; drift is a CI blocking signal
- Map lives in the repository as a versioned artifact (scoped to deployable, not repo)
- Data retention period defined per governance category (JPO retention schedule)
- Inventory must enable end-to-end DSR response workflows

**Deferred to later phases (out of scope for Phase 1):**
- Cross-border transfer identification
- Third-party data sharing declaration
- Inter-service data flow / lineage beyond first landing layer
- Data warehouse (Snowflake) scope
- Lawful basis for processing documentation

Benjamin then triggered `forge:elaborate` to derive technical requirements from the business requirements.

### 9. Phased Roadmap

| Phase | Scope |
|-------|-------|
| **Phase 1** | Generate per-deployable data map in each repo (automated, version-controlled, CI-enforced) |
| **Phase 2** | Publish data maps to a central queryable location (Snowflake, Confluent Schema Registry, or similar) on deployment |
| **Phase 3** | Services implement the Data Privacy API / SDK using the data map to handle delete, obfuscate, and access requests |

Phases 2 and 3 can proceed in parallel depending on resourcing.

### 10. Integration with forge:init

Benjamin noted that Forge will be rolled out at an end-of-month Lunch & Learn. If data map generation is integrated into `forge:init`, every team that installs Forge gets a data map automatically. If not ready by then, it can be added via `forge:update`.

### 11. Transcend Relevance

The team discussed whether Forge-generated data maps could reduce or replace Transcend. Benjamin's view:
- Forge addresses the **production applications** layer well.
- Transcend/Julia's work is more focused on the **data warehouse** layer, where data arrives via pipelines not controlled by application repos.
- Until Forge covers Snowflake-side pipelines (via something like a data engineering equivalent of Forge), Transcend remains relevant for that layer.

### 12. Access / Publishing

Tammy does not have GitHub access. Two options discussed:
- Ralph has a CI tool that publishes MD files from GitHub to Confluence with proper formatting.
- A Forge-native internal wiki/portal is on the roadmap for publishing HTML presentations and hosted pages, but not yet built.

---

## Decisions Made

| # | Decision |
|---|----------|
| D1 | Data map is scoped per **deployable**, not per repository |
| D2 | Classification standards will be encoded in Forge as organizational artifacts |
| D3 | Phase 1 scope is limited to generating the data map; publishing/acting on it is Phase 2/3 |
| D4 | Data warehouse (Snowflake) is out of scope for Phase 1 |
| D5 | Asynchronous DSR processing is needed; Kafka-based fan-out is the preferred pattern (to be confirmed) |

---

## Action Items

| Owner | Action |
|-------|--------|
| Cory Hartford | Review sprint capacity with Sorvesh; discuss whether data map work can be brought into current sprint |
| Cory Hartford | Talk to Emmy + Greg to get alignment before committing |
| Tammy Griffin | Send Benjamin: (1) Julia's category matrix, (2) the Transcend-to-Rakuten category mapping, (3) Greg/MST's manual tagging logic |
| Benjamin Vogan | Send Cory the meeting transcript and recording |
| Benjamin Vogan | Ask Ralph about MD-to-Confluence publishing for Tammy's access |
| Benjamin Vogan | Create two privacy standards in Forge: one for data governance classification, one for DSR scope |
| Cory Hartford | Confirm CDC delete propagation gap with Aziz; raise as an ask during DPAAP integration |

---

## Open Questions

| # | Question | Status |
|---|----------|--------|
| Q1 | Does "obfuscate" equate to "anonymize" for UK GDPR purposes? | Tammy's view: yes; no further action needed for Phase 1 |
| Q2 | Who owns classification disputes when AI-generated map is contested? | Team (squad/tribe), with Privacy + Data Compliance as arbiters |
| Q3 | What is the target publishing destination for Phase 2? (Snowflake, Confluent Schema Registry, other?) | To be decided |
| Q4 | Is CDC delete propagation to Snowflake already configured on all squad databases? | Cory to confirm with Aziz |
| Q5 | Should a special "sensitive" category tier be added beyond the existing category set? | No — existing categorization already captures this |
