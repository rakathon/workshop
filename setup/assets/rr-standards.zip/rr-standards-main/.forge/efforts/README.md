# Forge — Work Item Registry

Active work items. Closed items are removed from this registry when they reach `closed`
phase; they remain permanently in `.forge/efforts/` as artifact records.

Hierarchy is shown via indentation — child items appear beneath their parent with a
leading `→`.

| ID | Title | Type | Tier | Risk | Parent | Phase | Status |
|----|-------|------|------|------|--------|-------|--------|
| forge-plugin | AI-Accelerated Software Development Process (Forge Framework) | program | full | P1 |  | planning | in_progress |
| → ai-pr | AI-Powered PR Review | initiative | full | P1 | forge-plugin | discovery | in_progress |
| → forge-effort-pointer | Forge Effort Pointer — Break Dependency on Branch Name for Active Effort Detection | story | full | R3 | forge-plugin | review | in_progress |
| → forge-branch-convention | Forge Branch Convention — Per-Repository Branch Naming Configuration | story | full | R3 | forge-plugin | discovery | in_progress |
| → spec-driven-development | Spec-Driven Development | initiative | full | R2 | forge-plugin | implementation | in_progress |
| rr-standards-test-skill | Behavioral Testing for Skills | story | full | P2 |  | discovery | in_progress |
| data-privacy | Data Privacy | initiative | full | R1 |  | discovery | not_started |
| forge-update-plan | forge:update-plan Skill | story | full | R3 | spec-driven-development | review | in_progress |
| → forge-pr | forge:pr Skill | story | full | R3 | spec-driven-development | planning | in_progress |
| forge-validate-storage | forge:validate-storage Skill | story | full | R3 | spec-driven-development | discovery | in_progress |
| forge-telemetry | Forge Telemetry | story | lightweight | R4 |  | implementation | in_progress |
| report-skill | Report Skill | story | full | R3 |  | discovery | not_started |
| report-skill | Report Skill | story | full | R3 |  | planning | in_progress |
| report-skill | Report Skill | story | full | R3 |  | implementation | in_progress |
| forge-report | Report Skill | story | full | R3 |  | review | in_progress |
