# Implementation Plan: forge:validate-messaging

## Wave 1

- [x] [auto][wave:1] Author `forge:validate-messaging` SKILL.md + create `forge-validate-messaging` capability directory (TASK-001)
