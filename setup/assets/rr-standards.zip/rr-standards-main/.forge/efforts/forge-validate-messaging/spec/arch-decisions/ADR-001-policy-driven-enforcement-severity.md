# ADR-001 — Policy-Driven Enforcement Severity for forge:validate-messaging

**Status:** Accepted
**Effort:** forge-validate-messaging
**Date:** 2026-04-13
**Authors:** rr-benjamin.vogan

---

## Context

This ADR records the same architectural decision as
[forge-validate-api ADR-001](../../../forge-validate-api/spec/arch-decisions/ADR-001-policy-driven-enforcement-severity.md)
applied to the messaging validation skill. The rationale, alternatives, and
consequences are identical; this document captures the messaging-specific context
and the notable difference that the plugin does not currently ship messaging policy
files.

### Problem

The initial implementation of `forge:validate-messaging` hardcoded enforcement severity
(`[REQUIRED]` / `[SUGGESTION]`) directly in the SKILL.md check tables. This produced
two problems shared with `forge:validate-api`:

1. **Drift:** If the messaging standards are updated, the SKILL.md must also be manually
   updated to stay accurate.
2. **No team customisation:** Projects that need stricter or more relaxed messaging
   enforcement cannot adjust it without modifying the plugin.

### Messaging-specific context

This effort also authors the three messaging policy files that serve as the plugin
default (level 3 in the resolution order):

- `standards/messaging/contracts.policy.md`
- `standards/messaging/event-design.policy.md`
- `standards/messaging/versioning.policy.md`

The severity assignments reflect the distinction between rules that cause immediate
technical breakage when violated (blocking) and rules that represent design guidance
or process requirements that cannot cause direct consumer failures (advisory). See the
policy files for per-rule rationale in the Notes column.

---

## Decision

Adopt the same policy-driven enforcement severity pattern as `forge:validate-api`
(see that effort's ADR-001 for full rationale).

**Fallback resolution order** (per standard file, independently):
1. `.forge/deployables/<deployable_id>/policies/messaging/<file>.policy.md`
2. `.forge/policies/messaging/<file>.policy.md`
3. `../../standards/messaging/<file>.policy.md` (plugin default — does not yet exist)

When no policy file is found at any level, all rules are treated as `blocking` and
the report header states: "no policy files found — all rules treated as REQUIRED".

**Relative path loading:** Standards files are loaded using paths relative to the
skill file (`../../standards/messaging/`), consistent with `forge:spec-api` and
`forge:validate-api`. No runtime `find` command is used.

---

## Consequences

**Positive:**
- Teams can define project- or deployable-level policy overrides immediately, without
  waiting for the plugin to ship default messaging policies.
- The all-blocking default is the safest starting position for messaging contracts.
- The pattern is consistent with `forge:validate-api`, making the system learnable.

**Negative / trade-offs:**
- Teams must create policy override files to change enforcement severity from the
  plugin defaults.
- Policy files must follow the same table format as the plugin defaults. No schema
  validation is currently enforced on override files — a malformed override silently
  falls through to the next level.

**Follow-on work:**
- `forge:validate-storage` should adopt the same pattern.
- Consider adding a `forge:check-policy` diagnostic skill that validates override
  files against the expected table format.
