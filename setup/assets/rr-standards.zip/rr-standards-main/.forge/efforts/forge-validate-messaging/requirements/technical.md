# Technical Requirements — forge:validate-messaging

Parent: [business requirements](business.md)

## Traceability

| TR | Satisfies |
|----|-----------|
| TR-1 | BR-1 |
| TR-2 | BR-1 |
| TR-3 | BR-1 |
| TR-4 | BR-3 |
| TR-5 | BR-1 |
| TR-6 | BR-2 |
| TR-7 | BR-1 |
| TR-8 | BR-4 |
| TR-9 | BR-4 |
| TR-10 | BR-1, BR-4 |

---

## TR-1: Load All Messaging Spec Files from the Effort Directory (← BR-1)

The skill must load all files matching `spec/messaging/*.md` from the resolved effort
directory. If no files match, the skill reports:

> "No messaging spec found. Run forge:spec-messaging first."

and halts without error.

**Acceptance criteria:**
- All `.md` files under `spec/messaging/` are loaded and validated.
- Missing or empty directory produces the expected advisory message.
- No crash or silent failure on empty spec directory.

---

## TR-2: Load Messaging Standards Using Relative Paths (← BR-1)

The skill must load the messaging standard files using paths relative to the skill
file itself — not by searching the filesystem for the plugin root at runtime:

- `../../standards/messaging/contracts.md`
- `../../standards/messaging/event-design.md`
- `../../standards/messaging/versioning.md`

If any standard file is absent, the skill warns for that concern and continues applying
the check guidance for rules covered by the missing file.

**Acceptance criteria:**
- Standards are read via relative paths; no `find` command or runtime plugin root
  resolution is used.
- A missing standard file produces a warning, not a hard failure.

---

## TR-3: Apply Every Rule from the Loaded Standards (← BR-1)

The skill must apply the rules defined in the loaded standard files. The standard files
are the authoritative source; the skill must not substitute hardcoded inline rules that
could diverge from the standards over time. Rules present in the loaded standards but
not explicitly listed in the skill instructions must still be checked and reported.

**Acceptance criteria:**
- Each finding references the specific rule ID from the standard (e.g., R-1, R-5).
- A rule added to a standard file is automatically in scope without requiring a skill update.
- If a loaded standard and an inline skill description conflict, the loaded standard wins.

---

## TR-4: Apply Versioning Checks (← BR-3)

For each contract file, versioning checks must be applied as REQUIRED findings (unless
overridden by policy): schema version present, compatibility mode declared, subject
format correct. These are not warnings or suggestions by default.

**Acceptance criteria:**
- Missing version produces a REQUIRED finding.
- Missing compatibility mode produces a REQUIRED finding.
- Subject format mismatch produces a REQUIRED finding.

---

## TR-5: Cross-Contract Uniqueness Check (← BR-1)

After per-contract checks, verify that no two contract files declare the same event name.

**Acceptance criteria:**
- Two contracts with identical event names produce one cross-contract REQUIRED finding.
- Unique event names produce no cross-contract finding.

---

## TR-6: Must Not Write Files or Update State (← BR-2)

The skill must not write or modify any file in the effort directory, `validation/report.md`,
`.state.json`, or any other file. Output is inline session text only.

**Acceptance criteria:**
- After running the skill, `git status` shows no new or modified files.
- `.state.json` mtime is unchanged.
- The no-write prohibition is explicitly documented in the SKILL.md.

---

## TR-7: Run as a Worker Agent (← BR-1)

The skill must be implemented with `agent-type: worker` to prevent messaging standards
from being loaded into the engineer's main session context.

**Acceptance criteria:**
- Frontmatter declares `agent-type: worker`.

---

## TR-8: Load Enforcement Policies with Three-Level Fallback (← BR-4)

For each standard file (contracts, event-design, versioning), the skill must resolve an
enforcement policy using this fallback order, stopping at the first file found:

1. `.forge/deployables/<deployable_id>/policies/messaging/<file>.policy.md`
2. `.forge/policies/messaging/<file>.policy.md`
3. `../../standards/messaging/<file>.policy.md` (plugin default, relative to skill file)

If no policy file is found at any level for a given standard, all rules for that
standard are treated as blocking. Each standard's policy is resolved independently.

Note: the plugin does not currently ship messaging `.policy.md` files. Levels 1 and
2 are therefore the primary customisation mechanism until plugin defaults are added.

**Acceptance criteria:**
- A deployable-level policy file takes precedence over project-level and plugin default.
- A project-level policy file takes precedence over the plugin default.
- Overriding one standard's policy does not affect the others.
- Missing policy at all levels results in all-blocking behaviour.

---

## TR-9: Policy-Driven Severity (← BR-4)

Finding severity must be derived from the loaded policy table:
- `blocking` → `[REQUIRED]`
- `advisory` → `[SUGGESTION]`
- Rule absent from policy → treat as `blocking`

Where the policy entry includes a non-empty Notes field, the note is appended to the finding.

**Acceptance criteria:**
- Changing a rule's severity in a policy file changes how the skill labels it without
  requiring a SKILL.md update.
- Policy notes appear in findings where non-empty.

---

## TR-10: Report Policy Source and Rule IDs in Header and Findings (← BR-1, BR-4)

Each finding must include a rule ID and source standard. The report header must identify
which policy source was applied per standard so engineers know their enforcement posture.

**Acceptance criteria:**
- Every finding includes the rule ID (e.g., `R-1 (contracts)`, `R-7 (event-design)`).
- The report header includes a `**Policy:**` line.
- The report footer includes a per-standard policy source breakdown.
- When no policy was found, the header states "no policy files found — all rules treated as REQUIRED".
