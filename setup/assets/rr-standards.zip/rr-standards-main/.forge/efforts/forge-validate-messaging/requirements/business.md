# Business Requirements — forge:validate-messaging

Parent effort: [spec-driven-development](../../spec-driven-development/)
Deployable: [forge-plugin](../../../deployables/forge-plugin/)

---

## BR-1: Engineers Need Immediate Feedback on Messaging Contract Compliance During Authoring

When engineers author event and message contracts during `forge:spec-messaging`, they
need immediate inline feedback on whether the contracts comply with the organization's
messaging standards — without waiting for a full `forge:validate` gate run.

Missing producer/consumer identification, undefined ordering guarantees, and absent
idempotency approaches are common defects that are expensive to fix after implementation
has begun. Feedback must be driven by the authoritative standard files, not hardcoded
rules, so that it stays accurate as standards evolve.

**Acceptance criteria:**
- Running `forge:validate-messaging` on an effort directory reports all non-compliant
  fields for each contract in `spec/messaging/` within a single session turn.
- The validator reads and applies rules from the live standard files
  (`contracts.md`, `event-design.md`, `versioning.md`) rather than embedding them inline.
- Rules present in the loaded standards but not explicitly listed in the skill are
  still checked and reported.
- The report appears inline in the conversation — no file is written, no state is updated.

---

## BR-2: The Validator Must Not Write Gate Artifacts or Update Workflow State

`forge:validate-messaging` is an inline editing aid, not a phase gate. Phase gates
are the responsibility of `forge:validate`. Writing to `validation/report.md` or
updating `.state.json` would incorrectly signal that a gate check has passed,
misleading the workflow state machine and potentially allowing gate bypass.

**Acceptance criteria:**
- After running `forge:validate-messaging`, no files are created or modified.
- `.state.json` is not updated.
- `validation/report.md` is not created or overwritten.
- The skill output is confined entirely to the conversation session.

---

## BR-3: Versioning Strategy and Schema Completeness Defects Must Be Surfaced Explicitly

Versioning and schema completeness are the highest-risk messaging contract defects.
A contract without a declared version allows consumers to be silently broken when
the schema evolves. A contract with incomplete schema cannot be used as an
implementation contract by the consumer team.

**Acceptance criteria:**
- Contracts missing a schema version are flagged as REQUIRED, not as suggestions.
- Contracts missing a breaking change policy are flagged as REQUIRED.
- Contracts with untyped or incomplete schema fields are flagged as REQUIRED.
- The summary line distinguishes REQUIRED findings from SUGGESTION findings.

---

## BR-4: Teams Must Be Able to Customize Enforcement Severity Without Forking the Plugin

The plugin ships default enforcement behaviour (currently: no messaging policy files,
so all rules are treated as blocking). Individual projects and deployables must be
able to define policy overrides to reflect their specific compliance posture — for
example, downgrading a structural suggestion to advisory during a migration window —
without modifying the plugin itself.

Overrides must be narrowly scoped: a team should be able to change the policy for one
standard without touching the others.

**Acceptance criteria:**
- A project-level policy override in `.forge/policies/messaging/` is applied instead of
  the plugin default when present.
- A deployable-level policy override in `.forge/deployables/<id>/policies/messaging/`
  takes precedence over the project-level or plugin default when present.
- Each standard's policy is resolved independently.
- The report header identifies which policy source was applied per standard.
- When no policy file is found at any level, all rules are treated as blocking and
  the report states this explicitly.
