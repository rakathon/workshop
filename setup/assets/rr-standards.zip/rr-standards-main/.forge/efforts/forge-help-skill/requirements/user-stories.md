# User Stories — forge:help Skill

*Effort: forge-help-skill*
*Derived from: [requirements/business.md](business.md)*
*Written: 2026-04-29*

---

## Orientation — Learning What Forge Provides

- As an engineer new to Forge, I want to run `forge:help` with no argument so that I
  immediately understand what skills, hooks, standards, and language guides are available
  to me without reading any documentation files.

- As an engineer returning to Forge after time away, I want to run `forge:help` so that
  I can quickly reorient myself to what exists today without worrying about whether my
  memory of the catalog is still current.

---

## Conceptual Understanding — How the Framework Works

- As an engineer starting a new piece of work, I want to ask `forge:help` what phases
  the Forge workflow has so that I understand what steps I'll go through and what each
  phase requires.

- As an engineer about to run a skill for the first time, I want to ask `forge:help`
  what a skill does and what its preconditions are so that I can run it confidently
  without surprises.

- As an engineer who hit an unexpected behavior, I want to ask `forge:help` how a
  specific hook works so that I understand why Forge behaved the way it did.

---

## Standards and Language Guides

- As an engineer designing an API, I want to ask `forge:help` what Forge's REST
  standard says about a specific topic so that I can get a direct answer without
  navigating the standards library myself.

- As an engineer reviewing generated code, I want to ask `forge:help` about the
  language guide for my platform so that I understand what conventions Forge applies
  when generating code in that language.

---

## Cross-Area Questions

- As an engineer who wants to understand how Forge enforces standards end to end,
  I want to ask a single question and receive a complete answer that spans hooks,
  standards, and skills so that I don't have to assemble the picture myself from
  multiple sources.

---

## Effort-State Guidance

- As an engineer who is unsure what to do next, I want to ask `forge:help` what
  `forge:status` does so that I understand that it will tell me where my specific
  effort stands and what the recommended next action is.
