# Skill Design — forge:help

*Effort: forge-help-skill*
*Created: 2026-04-29*

---

## Overview

`forge:help` is an orchestrator skill that answers questions about the Forge plugin
by reading the plugin's own documentation dynamically. It never hardcodes lists of
skills, hooks, or standards. Everything it surfaces reflects what is actually installed.

Two modes of operation:

| Invocation | Mode |
|------------|------|
| `forge:help` (no argument) | Catalog mode — full structured overview |
| `forge:help <question>` (any argument) | Q&A mode — synthesized answer |

---

## Discovery Mechanism (BR-1, BR-2, TR-1)

The skill uses AGENTS.md files as its navigation layer throughout. The plugin root
is resolved at runtime using the standard plugin-root resolution fragment
(`plugins/forge/skills/common/plugin-root.md`) — the skill reads
`../../.claude-plugin/plugin.json` relative to its own directory and strips the
suffix to get an absolute `plugin_root` path.

All file reads reference `<plugin_root>/` as the base. Nothing is hardcoded:

| Resource | Discovery path |
|----------|---------------|
| Skills | `<plugin_root>/skills/AGENTS.md` → individual `SKILL.md` files |
| Hooks | `<plugin_root>/hooks/hooks.json` → hook shell scripts |
| Standards | `<plugin_root>/standards/AGENTS.md` → category directories |
| Language guides | `<plugin_root>/languages/AGENTS.md` → language directories |

---

## Catalog Mode (BR-2, TR-2)

When invoked with no argument, the skill executes this discovery sequence:

1. Read `<plugin_root>/skills/AGENTS.md` — enumerates skill directories and phases
2. For each skill directory, check for `SKILL.md` presence to distinguish implemented
   from stub (TR-5 — runtime check, not a static list)
3. Read each implemented skill's `SKILL.md` frontmatter for `name` and `description`
4. Read `<plugin_root>/hooks/hooks.json` — enumerates hook scripts by event type
5. Read each hook script to derive a plain-English one-liner (TR-4)
6. Read `<plugin_root>/standards/AGENTS.md` — enumerates standards categories
7. Read `<plugin_root>/languages/AGENTS.md` — enumerates language guides

Output: a structured Markdown catalog grouped by — Skills (by workflow phase),
Hooks (by event type), Standards (by domain), Language Guides (by language).

---

## Q&A Mode — Cross-Area Synthesis (BR-1, BR-3, BR-4, TR-3)

When invoked with any argument, the skill:

1. Parses the question to identify which component areas it spans (skills, hooks,
   standards, language guides, workflow phases)
2. Navigates AGENTS.md files in each relevant area to locate specific artifacts
3. Reads those artifacts (including hook shell scripts for hook questions — TR-4)
4. Synthesizes a single complete response covering all identified areas

A question that spans hooks and standards (e.g., "how does Forge enforce standards
during code generation?") produces one complete answer describing the end-to-end
behavior — the engineer does not need to ask follow-up questions to assemble the
full picture (BR-3).

Workflow concept questions (phases, preconditions, how to advance) are answered
from the relevant skill SKILL.md files and AGENTS.md phase annotations (BR-4).

---

## Stub Filtering (BR-5, TR-5)

At execution time, before including any skill in catalog output or Q&A answers, the
skill checks:

```bash
[ -f "<plugin_root>/skills/<dir>/SKILL.md" ] && echo "implemented" || echo "stub"
```

Stubs (directories containing only `.gitkeep`) are excluded from all output.
If an engineer explicitly asks about a stub skill by name, the skill responds:
"`forge:<name>` is planned but not yet implemented." — it does not fabricate behavior.

---

## Effort-State Boundary (TR-6)

The skill does not read `.forge/EFFORT`, `.state.json`, or any effort directory.
When a question requires knowing the engineer's specific effort state, the skill:

1. Answers the conceptual part from plugin documentation (preconditions, what the
   skill does, how to know when ready)
2. Directs the engineer to run `forge:status` for their specific effort state

---

## Execution Model (TR-7)

- `agent-type: orchestrator` — runs in the main engineer session
- No sub-agents spawned
- All file reads and synthesis happen inline
- No files written; no effort state modified
- Internal plugin paths never exposed in answers to the engineer
