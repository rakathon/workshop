# Skill Design — forge:pr

**Agent type:** Orchestrator  
**Command:** `forge:pr [<effort-id>]`  
**ADRs:** [ADR-033](../../../deployables/forge-plugin/spec/arch-decisions/ADR-033-project-local-template-overrides.md)

---

## Overview

`forge:pr` creates a pull request for the current branch. It operates in two modes
determined at invocation:

- **Forge mode** — an active Forge effort is associated with the branch. The PR title
  and description are derived from effort artifacts (requirements, implementation plan,
  quality gate results). The effort's phase state is updated on success. *(BRs 1–7)*
- **Fallback mode** — no Forge effort can be resolved. The PR title and description
  are derived from git history and diff analysis. Supersedes the `pr-creation` skill. *(BR-8)*

In both modes the PR title conforms to the organisation's Conventional Commits
standard so it passes the automated PR title linter:

```
<type>(<optional-scope>): <jira-key> - <Description>   # standard
<type>(<optional-scope>)!: <jira-key> - <Description>  # breaking change
```

*(TR-7)*

The skill degrades to fallback mode gracefully rather than erroring — it never
requires a Forge effort to function.

---

## Workflow

```mermaid
flowchart TD
    START([forge:pr invoked]) --> PRE{gh CLI\navailable?}
    PRE -- No --> STOP0([Stop: install gh CLI])
    PRE -- Yes --> C{Duplicate PR\non this branch?}
    C -- Yes --> STOP1([Stop: PR already exists])

    C -- No --> A{.forge/ exists?}
    A -- No --> FB1

    A -- Yes --> B{Effort resolvable\nfrom arg or branch?}
    B -- No --> FB1

    B -- Yes --> D{currentPhase?}

    D -- discovery / validation --> D1{validation.status?}
    D1 -- passed / passed_with_concerns --> E
    D1 -- not_started AND R3/R4 --> D1C{Engineer\nconfirms?}
    D1C -- No --> STOP2([Stop: run forge:validate])
    D1C -- Yes --> E
    D1 -- not_started / failed AND R1/R2 --> STOP2

    D -- implementation / verification --> D2{verification.status?}
    D2 -- passed / passed_with_concerns --> E
    D2 -- not_started AND R3/R4 --> D2C{Engineer\nconfirms?}
    D2C -- No --> STOP3([Stop: run forge:verify])
    D2C -- Yes --> E
    D2 -- not_started / failed AND R1/R2 --> STOP3

    D -- other phases --> E

    E[Resolve Jira key\ntask → effort → branch → none] --> E2
    E2[Derive Conventional Commits type\nfrom effort metadata] --> E3
    E3[Derive scope\nfrom deployable/capability] --> E4
    E4{Breaking\nchange?} --> |Yes| E4Y[Include ! flag\nappend BREAKING CHANGE: to body]
    E4 --> |No| F
    E4Y --> F
    F[Derive PR title\nConventional Commits format] --> F2{Single\ncommit?}
    F2 --> |Yes| F2W[Warn engineer\nre: squash merge] --> G
    F2 --> |No| G
    G[Resolve PR template\n.github → .forge/templates → plugin] --> H
    H[Generate PR description\nfrom Forge artifacts] --> I

    I[Check description length\ntruncate if > 60k chars] --> J
    J[Push branch if needed] --> K[gh pr create]
    K --> L[Write pr metadata\nto .state.json]
    L --> M{currentPhase =\nimplementation or verification?}
    M -- Yes --> N[Advance to review\nupdate README\ncommit]
    M -- No --> O[Record PR only\ncommit]
    N --> DONE1([Done: PR created\nEffort → review])
    O --> DONE2([Done: PR created])

    %% Fallback mode
    FB1[Fallback mode] --> FB3[Determine base branch\ngh / git / prompt]
    FB3 --> FB4{Uncommitted\nchanges?}
    FB4 -- Yes --> FB4W[Warn engineer] --> FB5
    FB4 -- No --> FB5
    FB5{Diff size\n> 100 files / 5k lines?}
    FB5 -- Yes --> FB5W[Warn — proceed\nfocus or abort?] --> FB6
    FB5 -- No --> FB6
    FB6[Analyze commits + diff] --> FB7
    FB7[Resolve Jira key\nfrom branch name] --> FB7B
    FB7B[Derive Conventional Commits type\nfrom commit history] --> FB7C
    FB7C[Derive scope\nfrom diff] --> FB7D
    FB7D{Breaking\nchange?} --> |Yes| FB7E[Include ! flag\nappend BREAKING CHANGE: to body]
    FB7D --> |No| FB8
    FB7E --> FB8
    FB8[Derive PR title\nConventional Commits format] --> FB8B{Single\ncommit?}
    FB8B --> |Yes| FB8W[Warn engineer\nre: squash merge] --> FB9
    FB8B --> |No| FB9
    FB9[Resolve PR template\n.github → .forge/templates → plugin] --> FB10
    FB10[Generate PR description\nfrom commits + diff\nno Forge sections] --> FB11
    FB11[Check description length\ntruncate if > 60k chars] --> FB12
    FB12[Push branch if needed] --> FB13[gh pr create]
    FB13 --> DONE3([Done: PR created])
```

---

## Step 0: Preflight — Verify GitHub CLI

Before any other work, confirm the GitHub CLI is available:

```bash
gh --version
```

If the command fails or is not found, stop immediately:
*"The GitHub CLI (`gh`) is required but not installed or not in PATH. Install it
from https://cli.github.com and authenticate with `gh auth login` before running
`forge:pr`."*

This check applies in both Forge mode and fallback mode. *(TR-1)*

---

## Step 1: Guard Against Duplicate PRs

Before any other work, check whether a PR already exists for the current branch:

```bash
gh pr list --head <current-branch> --state open --json number,url
```

If an open PR is found, stop immediately:
*"A PR already exists for this branch: `<url>`. No new PR created."*

In Forge mode (determined in Step 2), also record the URL and number in `.state.json`
`pr` key if not already present. *(BR-5)*

---

## Step 2: Determine Operating Mode

Check for `.forge/` in the repository root. If absent, enter fallback mode
immediately (skip to § Fallback Mode).

If `.forge/` exists, attempt to resolve the active effort:

1. Use the `<effort-id>` argument if provided.
2. Strip the `effort/` prefix from the current branch name and look up the resulting
   ID in `.forge/efforts/README.md`.
3. If no effort can be resolved from argument or branch name, enter fallback mode.

> **Important:** Never infer the effort by scanning the registry for a single
> in-progress effort. Repositories are shared across engineers — an unrelated effort
> belonging to another engineer must never be attached to this PR. The branch name
> is the only authoritative link. *(BR-1)*

---

## Forge Mode

### Step 3: Check the Quality Gate

The gate to check depends on `currentPhase` in `.state.json`:

| `currentPhase` | Gate | State field |
|---|---|---|
| `discovery`, `validation` | `forge:validate` | `phases.validation.status` |
| `implementation`, `verification` | `forge:verify` | `phases.verification.status` |
| any other | none | — |

For R1/R2 efforts: `passed` or `passed_with_concerns` → proceed; `not_started` or
`failed` → stop:
- Discovery phase: *"Design validation has not passed. Run `forge:validate` before
  creating a PR for discovery artifacts."*
- Implementation phase: *"Verification has not passed. Run `forge:verify` before
  creating a PR."*

For R3/R4 efforts where the gate status is `not_started`: require explicit
confirmation before proceeding — *"The quality gate for this R3/R4 effort has not
been run. The PR description will not include a quality result. Proceed anyway?
(yes/no)"*. If no, stop and direct to the appropriate skill.

`PASS WITH CONCERNS` proceeds in all cases — concerns are surfaced in the PR
description. *(BR-4)*

### Step 4: Resolve the Jira Key

Check in order, use the first found:

1. `plan/jira-sync.json` — look for a `jiraKey` in `tasks[]` matching any ID in
   `phases.implementation.completedTasks`. (Skip silently if file absent.)
2. `.state.json` `jira.key` — use if non-null.
3. Current branch name — match pattern `[A-Z]+-[0-9]+`.
4. None — omit from title.

If a key is found, confirm with the engineer before proceeding:
> "I found Jira key `<jira-key>` (from <source>). Is this the correct ticket for
> this PR? (yes / no / enter a different key)"

- **Yes** — use it.
- **No** — omit the key from the title.
- **Different key** — use the key the engineer provides.

If no key is found, proceed without one — do not prompt the engineer to provide one.

*(BR-7)*

### Step 5: Derive the PR Title

The PR title must conform to the org's Conventional Commits format. *(TR-7)*

#### 5a: Derive the Conventional Commits Type

Infer the type from effort metadata in this order:

1. Read `subtype` from `.state.json`. Apply mapping:
   - `bug-fix`, `hotfix` → `fix`
   - `feature`, `enhancement` → `feat`
   - `refactor` → `refactor`
   - `spike`, `research` → `chore`
   - `docs` → `docs`
2. If `subtype` is null or unmapped, read the first heading and opening paragraph
   of `requirements/business.md` and classify by dominant keyword:
   - "add", "new", "introduce", "implement", "support", "enable" → `feat`
   - "fix", "bug", "patch", "correct", "resolve", "broken" → `fix`
   - "perf", "performance", "optimise", "speed", "latency" → `perf`
   - "refactor", "restructure", "reorganise", "clean" → `refactor`
   - "test", "coverage", "spec" → `test`
   - "document", "docs", "readme" → `docs`
   - "style", "format", "lint", "whitespace" → `style`
   - "ci", "pipeline", "workflow", "action" → `ci`
   - "upgrade", "bump", "dependency", "maintenance" → `chore`
3. If classification is still ambiguous after both steps, present the best candidate
   to the engineer and ask for confirmation:
   *"I inferred Conventional Commits type `<type>` from the effort description. Is that correct, or
   should it be one of: feat / fix / refactor / docs / test / ci / chore?"*

#### 5b: Derive the Scope

Read `deployables[]` from `.state.json`:
- If one deployable is listed, use it as the scope (e.g. `forge-plugin` → `forge-plugin`).
- If multiple deployables are listed, use the first entry.
- If `deployables[]` is empty, check `capabilities` in `.state.json` and use the
  capability name if exactly one is present.
- If neither yields a value, omit the scope.

#### 5c: Determine Breaking Change Flag

Ask the engineer:
*"Does this PR introduce a breaking change (incompatible API update, removal of
a public interface, major behaviour change)? (yes/no)"*

- **Yes** — include `!` after the type/scope in the title, and append the following
  to the PR description body so `semantic-release` detects the major bump from the
  squash commit:
  ```
  BREAKING CHANGE: <brief description of what breaks and migration path>
  ```
- **No** — omit both.

*(TR-7)*

#### 5d: Assemble the Title

```
<type>(<scope>): <jira-key> - <Description>    # key found, scope present
<type>: <jira-key> - <Description>             # key found, no scope
<type>(<scope>): <Description>                 # no key (build/chore exempt)
<type>: <Description>                          # no key, no scope
```

With breaking change flag:
```
<type>(<scope>)!: <jira-key> - <Description>
```

`<Description>` is the effort title, sentence-cased. If the effort title is not
already sentence case, capitalise the first letter.

Examples:
- `feat(forge-plugin): PROJ-1234 - Add PR creation skill`
- `fix(auth): AUTH-789 - Resolve token expiry edge case`
- `feat(forge-plugin)!: PROJ-1234 - Replace title format with Conventional Commits standard`
- `chore: Bump dependency versions`

*(BR-2, BR-3, BR-7, TR-7)*

#### 5e: Single-Commit Warning

Check the number of commits on the branch against the base branch:

```bash
git rev-list <base-branch>..HEAD --count
```

If the count is `1`, warn the engineer before proceeding:

*"This branch has only one commit. On squash merge, GitHub will use the commit
message rather than the PR title. Ensure your commit message also follows the
Conventional Commits format, or add a second commit (e.g. a `chore:` fixup)
before merging."*

This is a warning only — do not block PR creation. *(TR-8)*

### Step 6: Generate the PR Description

Locate the PR template using the following resolution order (first found wins):

1. `.github/pull_request_template.md`
2. `.github/PULL_REQUEST_TEMPLATE.md`
3. `.forge/templates/pull-request.md` — project-local override (ADR-033)
4. `../../templates/pull-request.md` relative to this skill file — Forge plugin
   built-in fallback

**Locations 1–3 are project templates.** Use them as the structural skeleton and
populate each section from Forge artifacts. Append Forge-specific sections
(quality gate result, risk tier, wave task list) after any existing checklist
sections.

**Location 4 is the Forge plugin template.** Populate using the structure below.

**Forge plugin template sections:**

**Summary** — 3–5 bullets synthesized from `requirements/business.md`. Reviewer-
facing prose; do not copy BR identifiers or raw text.

**What was implemented** — completed tasks from `phases.implementation.completedTasks`
grouped by wave, with description and short commit SHA per task. For discovery PRs,
list the artifacts produced (requirements files, spec files, ADRs) instead.

**Quality gate result** — one line stating the result:
- Implementation PR: `forge:verify` status from `phases.verification.status`.
  If `passed_with_concerns`, direct reviewers to `verification/report.md`.
- Discovery PR: `forge:validate` status from `phases.validation.status`.
  If `passed_with_concerns`, direct reviewers to `validation/report.md`.
- If gate was not run (R3/R4 confirmed skip): note that here.

**Risk** — the effort's risk tier and review implication:
- R1/R2: *"Human review required in addition to AI review."*
- R3/R4: *"AI review sufficient; human review optional."*

**Test plan** — Markdown checklist derived from completed tasks and the verification
report if present. If a capability `test-strategy.md` exists for any capability in
`.state.json` `capabilities`, read it and include relevant scenario descriptions.
For discovery PRs, omit this section.

**Reviewer focus** — 1–3 bullets for areas requiring attention, derived from:
`PASS WITH CONCERNS` findings in the quality report, `openDecisions` in `.state.json`,
and `[checkpoint]` annotated tasks in `plan/tasks.md`. Omit if nothing to surface.

Omit any section for which no content can be derived. Do not leave empty headings.

*(BRs 2, 3)*

### Step 7: Check Description Length and Create the PR

Before calling `gh pr create`, check the byte length of the generated description.
GitHub enforces a maximum PR body size of 65,536 characters. If the description
exceeds 60,000 characters, apply these reductions in order until it fits:

1. Replace the "What was implemented" task list with a summary count per wave:
   `Wave N: X tasks complete`.
2. Replace any inline verification/validation report content with a reference:
   `See verification/report.md for full details.`
3. If still over limit after both reductions, append a truncation notice and trim:
   `<!-- Description truncated — full details in effort artifacts -->`

*(TR-5)*

Push the branch if it has no upstream tracking ref:

```bash
git push -u origin <current-branch>
```

If the push fails for any reason, surface the full git error and stop. Do not
attempt to create the PR against an unpushed branch. *(TR-2)*

Determine the base branch:

```bash
gh repo view --json defaultBranchRef --jq '.defaultBranchRef.name'
```

Create the PR:

```bash
gh pr create \
  --title "<title>" \
  --body "<description>" \
  --base <base-branch>
```

### Step 8: Update State and Confirm

Write PR metadata to `.state.json`:

```json
"pr": {
  "number": 42,
  "url": "https://github.com/org/repo/pull/42",
  "createdAt": "<ISO-8601 timestamp>",
  "branch": "<current-branch>"
}
```

Advance the phase only when coming from implementation:

- `currentPhase = implementation` or `verification` → set `currentPhase` to
  `"review"`, set `phases.review.status` to `"in_progress"`, update
  `.forge/efforts/README.md`.  
  Commit: `chore(<id>): open PR #<number>, advance to review phase`
- Any other `currentPhase` → do not change phase state.  
  Commit: `chore(<id>): record PR #<number> for <currentPhase> artifacts`

Confirm to the engineer:
```
PR created: <url>
Effort advanced to: review       ← only if phase advanced
```

*(BRs 5, 6)*

---

## Fallback Mode

### Step F1: Determine the Base Branch

```bash
gh repo view --json defaultBranchRef --jq '.defaultBranchRef.name'
```

If that fails:

```bash
git symbolic-ref refs/remotes/origin/HEAD | sed 's@^refs/remotes/origin/@@'
```

If neither resolves, prompt the engineer: *"What is the base branch for this PR?
(e.g. main, develop)"*

### Step F2: Check for Uncommitted Changes

```bash
git status --porcelain
```

If uncommitted changes exist, warn the engineer before proceeding.

### Step F3: Analyze the Diff

Check diff size first:

```bash
git diff <base-branch>...HEAD --stat
```

If the diff exceeds 100 files or 5,000 lines, warn and ask: proceed with full
analysis, focus on key files, or abort.

Read the full diff:

```bash
git log <base-branch>..HEAD --pretty=format:"%h %s"
git diff -U10 <base-branch>...HEAD
```

Analyze to identify: files added/modified/deleted/renamed; nature of changes
(features, fixes, refactors, tests, config, docs); public API or interface changes;
schema or migration changes; security or privacy implications; dependency changes.

### Step F4: Resolve the Jira Key

Match pattern `[A-Z]+-[0-9]+` against the current branch name.

If a key is found, confirm with the engineer before proceeding:
> "I found Jira key `<jira-key>` from the branch name. Is this the correct ticket
> for this PR? (yes / no / enter a different key)"

- **Yes** — use it.
- **No** — omit the key from the title.
- **Different key** — use the key the engineer provides.

If no key is found, proceed without one — do not prompt the engineer to provide one.

*(BR-7)*

### Step F5: Derive the PR Title

The PR title must conform to the org's Conventional Commits format. *(TR-7)*

#### F5a: Derive the Conventional Commits Type

Read the commit log (`git log <base-branch>..HEAD --pretty=format:"%s"`) and tally
the Conventional Commits type prefixes present:

- If a single type dominates (appears in >50% of commits), use it.
- If multiple types are present with no clear majority, use the type of the most
  recent commit.
- If no commits contain a recognisable Conventional Commits type prefix, classify by the dominant
  nature of the diff:
  - New files added with feature logic → `feat`
  - Existing files patched with bug context → `fix`
  - Test files only → `test`
  - Config/CI files only → `ci`
  - Default → `chore`

#### F5b: Derive the Scope

Identify the most frequently modified top-level package or module directory in the
diff. Use it as the scope if a clear candidate exists. Omit if the changes are
spread across many packages with no single dominant area.

#### F5c: Determine Breaking Change Flag

Ask the engineer:
*"Does this PR introduce a breaking change (incompatible API update, removal of
a public interface, major behaviour change)? (yes/no)"*

- **Yes** — include `!` in the title and append `BREAKING CHANGE: <description>`
  to the PR description body. *(TR-7)*
- **No** — omit both.

#### F5d: Assemble the Title

Apply the same format rules as Forge mode Step 5d. The short description must be
synthesized from the commit log and diff — not fabricated or generic.

#### F5e: Single-Commit Warning

Apply the same single-commit check as Forge mode Step 5e. *(TR-8)*

### Step F6: Generate the PR Description

Apply the same template resolution order as Forge mode Step 6 (locations 1–4).
Populate strictly from commit history and diff analysis. When using the Forge plugin
template (location 4), omit all Forge-specific sections.

If no template is found at any location, generate a description with:

**Summary** — 3–5 bullets derived from commit messages and diff analysis.

**Changes** — grouped by category (features, fixes, refactors, tests, config).
Omit empty categories.

**Test plan** — Markdown checklist derived from test files in the diff. If no test
changes, note that explicitly.

**Breaking changes** — public API, schema, or interface changes found in the diff.
Omit section if none.

Do not fabricate content that cannot be derived from the diff and commit history.

### Step F7: Check Description Length and Create the PR

Apply the same 60,000-character length check as Forge mode Step 7. In fallback
mode, if truncation is needed, reduce the "Changes" section to category-level
summaries before appending the truncation notice. *(TR-5)*

Push the branch if it has no upstream tracking ref. If the push fails, surface
the full git error and stop — do not attempt `gh pr create` against an unpushed
branch. *(TR-2)*

Create with `gh pr create`. No state file to update. Confirm: `PR created: <url>`.

*(TR-7, TR-8)*

---

## Deliverables

In addition to this skill's `SKILL.md`, this effort must produce:

- `plugins/forge/templates/pull-request.md` — the Forge plugin's built-in PR
  template. Must contain all sections from Step 6's Forge plugin template structure,
  formatted as a Markdown PR template with placeholder comments. Must be usable as
  a standalone `.github/pull_request_template.md` if copied by a project.
