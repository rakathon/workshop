# Business Requirements — forge:pr Skill

Parent effort: [spec-driven-development](../../spec-driven-development/requirements/business.md)
Parent program BRs addressed: BR-1, BR-6, BR-7

---

### BR-1: PR Creation Must Be a First-Class Step in the Forge Workflow

The Forge workflow currently ends at implementation without a defined mechanism for
submitting work for human review. Creating a pull request is not a separate, out-of-band
activity — it is the handoff step that closes the implementation phase and opens the
review phase. `forge:pr` must be a named, intentional step in the Forge workflow,
not something the engineer cobbles together with raw `gh` commands after Forge's
guidance ends.

### BR-2: The PR Description Must Be Derived from Forge Artifacts, Not Authored from Memory

Engineers must not have to recall what they built, why they built it, or what they
tested in order to write a PR description. The Forge effort contains all of this
information — requirements, implementation plan, verification result, risk tier. The PR
description must be generated from these artifacts automatically. A PR description
written without Forge context is a compliance gap and a reviewer burden; a description
derived from Forge artifacts is authoritative and consistent.

### BR-3: The PR Description Must Give Reviewers Everything They Need

A reviewer receiving a Forge-generated PR must be able to assess the change without
asking the author follow-up questions. The description must cover: what the effort set
out to accomplish, what was implemented (which tasks, which waves), how it was verified,
and what the reviewer should focus on. The description must also include the Jira ticket
link so the reviewer can trace the work to its origin. Missing any of these elements
shifts work onto the reviewer and defeats the purpose of a structured workflow.

### BR-4: PRs Must Not Be Created Before Verification Passes

A PR must not be submitted for human review if the implementation has not been
verified. Submitting unverified work shifts the burden of quality checking onto human
reviewers, who are ill-positioned to perform it efficiently. `forge:pr` must confirm
that verification has been completed and passed (or passed with concerns) before
creating the PR. If verification has not run, the engineer must be directed to run it
first.

### BR-5: The Effort State Must Reflect That a PR Exists

Once a PR is created, the effort's state must record the PR URL and number. Other
Forge skills and future reporting should be able to determine whether a PR is open for
a given effort without leaving the Forge toolchain. If a PR already exists for the
effort, `forge:pr` must surface it rather than creating a duplicate.

### BR-6: The PR Creation Step Must Advance the Effort to the Review Phase

Creating a PR is the trigger for the review phase. When `forge:pr` creates a PR
successfully, the effort must automatically advance from verification to review. This
keeps the Forge phase state synchronized with the actual state of the work — an effort
with an open PR is in review, not still in implementation or verification.

### BR-7: The PR Title Must Enable Automatic Jira Linking at the Most Specific Level Available

GitHub's Jira integration (Smart Commits / Jira for GitHub app) scans the full PR
title for Jira issue key patterns — it does not require the key to appear at the
start of the title. `forge:pr` must include the most specific Jira key associated
with the work being submitted:

- If the PR covers a specific task or wave, and that task or wave has an associated
  Jira key (e.g. a subtask or child ticket), that key must be used.
- If no task- or wave-level key is available, but the effort itself has an associated
  Jira key (e.g. the parent story or epic), that key must be used.
- If no Jira key is found at any level, the PR title is formatted without one.

This is a zero-cost integration that requires only correct PR title formatting —
no Jira API calls, no separate sync step, no additional tooling. The resolution
order ensures the PR is linked to the most actionable ticket in Jira, not just
the highest-level one.

### BR-8: The Skill Must Work Without a Forge Effort

`forge:pr` must be usable in any repository, not only those with an active Forge
effort. When invoked outside a Forge effort context — no `.forge/` directory, no
active effort, or no effort matching the current branch — the skill must fall back
to generating the PR title and description from the git history of the current
branch against the default base branch. In this mode the skill analyzes commit
messages, the diff, and any project PR template found in `.github/`, and produces
a description equivalent in quality to what the `pr-creation` skill currently
provides. The Forge-specific sections (verification result, wave task list, risk
tier) are omitted in fallback mode; the description is derived entirely from the
code and commit history. The Jira key resolution in BR-7 still applies in fallback
mode — the key may be embedded in the branch name (e.g. `feature/PROJ-1234-...`)
even when no Forge effort exists.
