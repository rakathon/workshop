# Architecture — Slack Support for Forge

*Effort: slack-support*
*Date: 2026-04-21*

---

## Overview

This feature integrates Slack into the Forge workflow by associating a Slack channel
with an effort and providing three independently invokable skills that import messages,
generate summaries, and surface linked resource context. All Slack access is mediated
by the Slack MCP server bundled with the Forge plugin — skills never call the Slack
REST API directly.

---

## Skills

### `forge:slack-channel`

One-time setup skill. Associates a Slack channel with the active effort by writing the
channel ID to `.state.json`. Optionally registers a Claude Code cron for scheduled
import. Takes no required arguments beyond the channel reference.

### `forge:slack-import`

Incremental message import skill. Reads the effort's `slackChannel` from `.state.json`,
fetches messages from the Slack MCP, resolves Confluence and Jira links via the
Atlassian MCP, writes daily message files, and advances the checkpoint. Supports
optional `--from` and `--to` bounds (ISO 8601). When neither is provided, runs from
the last checkpoint through end of the previous calendar day.

### `forge:slack-summarize`

Summary generation skill. Reads daily message files and produces a daily or weekly
summary using Claude. Invoked with `--daily YYYY-MM-DD` or `--weekly YYYY-Www`.
Operates independently of import — can be re-run at any time to regenerate summaries.

---

## Data Flow

```mermaid
flowchart TD
    SlackMCP["Slack MCP"]
    AtlassianMCP["Atlassian MCP"]

    subgraph import["forge:slack-import"]
        direction TB
        FetchMessages["Fetch messages\n& thread replies"]
        EnrichLinks["Enrich Atlassian links"]
        WriteFiles["Write daily message files"]
        AdvanceCheckpoint["Advance .checkpoint"]

        FetchMessages --> EnrichLinks --> WriteFiles --> AdvanceCheckpoint
    end

    subgraph summarize["forge:slack-summarize"]
        direction TB
        ReadFiles["Read daily message file(s)"]
        ExtractTopics["Extract high-priority topics\n& general notes"]
        WriteSummary["Write summary file"]

        ReadFiles --> ExtractTopics --> WriteSummary
    end

    subgraph artifacts["efforts/<id>/messages/"]
        DailyFile["YYYY-MM/YYYY-MM-DD.md"]
        Checkpoint[".checkpoint"]
        DailySummary["YYYY-MM/YYYY-MM-DD-summary.md"]
        WeeklySummary["YYYY-MM/week-Www-summary.md"]
    end

    SlackMCP --> FetchMessages
    AtlassianMCP --> EnrichLinks
    WriteFiles --> DailyFile
    AdvanceCheckpoint --> Checkpoint
    DailyFile --> ReadFiles
    WriteSummary --> DailySummary
    WriteSummary --> WeeklySummary
```

---

## Scheduling

Scheduled import runs on a GitHub Actions workflow using the `schedule` event (cron
syntax). This is the preferred mechanism over Claude Code crons because it runs
headlessly on GitHub's infrastructure regardless of whether any developer has the IDE
open, and the schedule is visible, auditable, and version-controlled alongside the
codebase. See [ADR-001](arch-decisions/ADR-001-github-actions-scheduling.md).

The workflow:
1. Checks out the repository
2. Invokes `forge:slack-import --ci` via the Claude Code CLI — automatically discovers
   and imports all efforts with an associated Slack channel. Authentication uses a
   Slack bot token injected as `SLACK_BOT_TOKEN` and `SLACK_TEAM_ID` repository
   secrets. The GHA workflow uses the `@modelcontextprotocol/server-slack` stdio MCP
   package (not the interactive OAuth HTTP server at `mcp.slack.com`), which accepts
   bot token credentials via environment variables. See
   `spec/gha-checkpoint-findings.md` for the rationale.
3. Invokes `forge:slack-summarize --daily` for each newly imported day across all efforts
4. Commits and pushes the resulting message and summary files back to the branch

The cron cadence is configured in the workflow file (`.github/workflows/slack-import.yml`).
`forge:slack-channel --schedule <cron>` writes the cadence to `.state.json` as a
human-readable reference but does not register a Claude Code cron job.

Manual invocation remains supported — `forge:slack-import` and `forge:slack-summarize`
can be run directly at any time.

---

## MCP Dependencies

| MCP Server | Used by | Purpose |
|---|---|---|
| `slack` (new) | `forge:slack-import` | Fetch channel messages, thread replies, user display names |
| `atlassian` (existing) | `forge:slack-import` | Resolve Confluence and Jira links to summaries |

The `slack` MCP server must be added to the Forge plugin's `.mcp.json`. See
`spec/mcp-config.md` for the required declaration.

---

## Key Design Decisions

- **MCP-only Slack access** — No direct API token management; authentication is
  entirely handled by the MCP server configuration in the user's environment.
- **Summaries are decoupled from import** — Re-summarizing without re-importing is
  a first-class use case (e.g. refining prompt, adding a new topic category).
- **Checkpoint is append-only** — Bounded `--from`/`--to` runs never advance the
  checkpoint, preventing gaps in the incremental history.
- **Today is never included in unattended runs** — The upper bound for checkpoint-
  based runs is `end of previous calendar day` to avoid partial-day data in summaries.
- **Cross-day threads anchor to parent** — Thread replies belong to their parent's
  daily file; the reply's own daily file carries a cross-reference link.
