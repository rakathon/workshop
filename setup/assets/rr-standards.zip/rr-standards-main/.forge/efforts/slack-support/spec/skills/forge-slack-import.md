# Skill Contract — forge:slack-import

*Effort: slack-support*
*Date: 2026-04-21*
*Traces to: BR-2, BR-5, BR-9, BR-10, TR-2, TR-3, TR-4, TR-5, TR-6, TR-9, TR-10, TR-14, TR-15, TR-16*

---

## Purpose

Fetches messages from the effort's associated Slack channel, writes daily message
files with thread structure and Atlassian link enrichment, and advances the import
checkpoint. Supports optional date/time bounds for backfill or targeted imports.

## Agent Type

`orchestrator`

---

## Arguments

| Argument | Required | Description |
|---|---|---|
| `--effort <effort_id>` | No | Target a specific effort by ID. If omitted, resolved via the standard chain (see `plugins/forge/skills/common/effort-resolution.md`). Mutually exclusive with `--ci`. |
| `--from <datetime>` | No | ISO 8601 start bound (inclusive). Overrides checkpoint. Single-effort mode only. |
| `--to <datetime>` | No | ISO 8601 end bound (inclusive). Defaults to end of previous calendar day. Single-effort mode only. |
| `--channel <channel-id>` | No | Limit import to a specific channel. If omitted, all channels in the effort's `slackChannels` array are imported. Single-effort mode only. |
| `--ci` | No | CI mode: scan the repository for all efforts with a non-empty `slackChannels` array and run the import for every channel of each effort. Mutually exclusive with `--effort`, `--from`, and `--to`. |

When neither `--from`, `--to`, nor `--ci` is provided, the import runs for the active
effort from its checkpoint through end of the previous calendar day. When `--from` is
provided without `--to`, the end is end of the previous calendar day.

---

## Preconditions

**PC-1: Target effort has a Slack channel (single-effort mode only)**
If `--ci` is not set, resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: `effort-required`
Pass `--effort` value as the explicit argument (Step 1 of the chain) when provided.

Then read the resolved effort's `.state.json`. If `slackChannels` is absent, null, or
empty, stop:
> "No Slack channels associated with this effort. Run `forge:slack-channel` first."
For each channel entry, use `entry.id` for all Slack API calls and `entry.name` as
the directory name slug.
If `--channel` is provided, verify it exists in `slackChannels`; if not, stop:
> "Channel `<id>` is not associated with this effort."
In CI mode these checks are applied per-effort during the scan (Step 0) rather than
as a global precondition.

**PC-2: Slack MCP available**
Check for `mcp__slack__*` tools. If absent, stop with the standard MCP configuration
error (see `spec/mcp-config.md`).

**PC-3: Atlassian MCP available**
Check for `mcp__atlassian__*` tools. If absent, proceed but skip link enrichment for
all messages and note: "Atlassian MCP unavailable — link enrichment skipped."

**PC-4: Checkpoint or --from present (single-effort mode only)**
If `--ci` is not set and no `.checkpoint` exists for a channel and `--from` is not
provided, stop and prompt per channel:
> "No import checkpoint found for `<channel-id>`. What date should the import start from? (YYYY-MM-DD)"
Use the engineer's response as `--from` for that channel. In CI mode, channels with
no checkpoint and no recoverable start are skipped with a warning rather than halting.

**PC-5: Mutually exclusive flags**
If `--ci` is combined with `--effort`, `--from`, or `--to`, stop:
> "`--ci` runs all efforts from their own checkpoints and cannot be combined with
> `--effort`, `--from`, or `--to`. Use single-effort mode for targeted or bounded imports."

---

## Steps

### Step 0: CI Mode — Scan and Dispatch (--ci only)

If `--ci` is set:

1. Enumerate all directories under `.forge/efforts/`.
2. For each effort directory, read `.state.json`. Collect every effort where
   `slackChannels` is a non-empty array.
3. If no efforts have associated channels, stop:
   > "No efforts with associated Slack channels found. Nothing to import."
4. For each collected effort, and for each channel in that effort's `slackChannels`,
   run Steps 1–7 using that effort+channel pair as context. Per-channel errors are
   caught, logged, and do not halt remaining channels or efforts.
5. After all efforts and channels are processed, print the CI summary (see Step 8 CI
   variant) and exit.

### Step 1: Resolve Target Channels and Import Range

In single-effort mode, determine the set of channels to import:
- If `--channel` is provided: import that channel only.
- If `--channel` is omitted: import all channels in `slackChannels`.

For each channel entry from `slackChannels`, record both `channel_id = entry.id`
(for API calls) and `channel_name = entry.name` (for directory paths).

Run Steps 2–7 once per channel. Each channel uses its own `.checkpoint` at
`messages/slack/<channel-name>/.checkpoint`.

Determine `start` and `end` per channel:

| Condition | `start` | `end` |
|---|---|---|
| Neither `--from` nor `--to` | Checkpoint value | End of previous calendar day (23:59:59 UTC) |
| `--from` only | `--from` value | End of previous calendar day |
| `--from` and `--to` | `--from` value | `--to` value |

If `start >= end`, stop:
> "Import range is empty: `<start>` to `<end>`. Nothing to import."

### Step 2: Fetch Messages

Call `mcp__slack__get_channel_history` with the channel ID, `oldest = start`,
`latest = end`. Paginate through all results. For each top-level message that has
a thread (reply count > 0), call `mcp__slack__get_thread_replies` to fetch all
replies.

Resolve all user IDs encountered to display names via `mcp__slack__get_users`.
Cache resolved names within the run to avoid redundant calls.

### Step 3: Group by Calendar Day

Partition messages by the calendar day of their timestamp (UTC). For each day in the
range that has messages:

- If the daily file already exists, merge new messages in by timestamp — do not
  duplicate messages already present (idempotency by message `ts` identifier)
- If the daily file does not exist, create it

### Step 4: Enrich Atlassian Links

For each message (top-level and reply), scan text for URLs matching:
- `https://rakutenrewards.atlassian.net/wiki/` — Confluence
- `https://rakutenrewards.atlassian.net/jira` — Jira
- `https://rakutenrewards.atlassian.net/browse` — Jira

For each match, call the appropriate Atlassian MCP tool to fetch title and a brief
description. Append the enriched summary inline after the link. If the resource is
inaccessible, append `[summary unavailable: <reason>]` and continue.

### Step 5: Write Daily Message Files

For each day, write (or update) `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD.md`
using the format defined in `spec/storage/messages.md`:

- Top-level messages in ascending timestamp order
- Thread replies nested under their parent with `>` blockquote indentation
- Cross-day replies: append under parent in the parent's daily file; write a
  cross-reference entry in the reply's own daily file (see `spec/storage/messages.md`)
- Enriched Atlassian links rendered inline after the original URL

Create the `YYYY-MM/` directory if it does not exist.

### Step 6: Advance Checkpoint

If this was a watermark-based run (no `--from`/`--to` provided, or `--from` only
with no `--to`): write `end` timestamp to `messages/slack/<channel-name>/.checkpoint`.

If this was a fully bounded run (`--from` and `--to` both provided): do not modify
the checkpoint.

### Step 7: Commit

Use `forge:commit` to stage and commit all written and updated files from this run
(daily message files and `.checkpoint`). In CI mode, run one `forge:commit` per
effort after its Steps 1–6 complete rather than a single commit for all efforts.

### Step 8: Log Run

**Single-effort mode:**

```
forge:slack-import complete
Effort:  <effort_id>
  Channel <channel-name> (<channel-id>):  <N> messages, <D> days written, checkpoint → <value | unchanged>
  Channel <channel-name> (<channel-id>):  <N> messages, <D> days written, checkpoint → <value | unchanged>
Enrichment: <K> links resolved, <L> unavailable (across all channels)
```

**CI mode (printed after all efforts and channels are processed — Step 8):**

```
forge:slack-import complete (CI mode)
Efforts scanned: <total with non-empty slackChannels>
  ✓ <effort_id>/<channel-name> (<channel-id>) — <N> messages, <D> days, checkpoint → <value>
  ✓ <effort_id>/<channel-name> (<channel-id>) — <N> messages, <D> days, checkpoint → <value>
  ✗ <effort_id>/<channel-name> (<channel-id>) — skipped: no checkpoint and no recoverable start date
  ✗ <effort_id>/<channel-name> (<channel-id>) — failed: <error summary>
```

---

## Error Handling

| Condition | Action |
|---|---|
| Slack MCP unavailable | Stop with MCP configuration error |
| Atlassian MCP unavailable | Proceed; skip enrichment; note in log |
| Checkpoint absent, no `--from` | Prompt for start date |
| Checkpoint malformed | Stop with parse error; do not run |
| Import range empty | Stop with range-empty message |
| Partial write failure | Preserve last-good file state; report which day failed; do not advance checkpoint |
| Link enrichment error (single link) | Append `[summary unavailable: <reason>]`; continue |
