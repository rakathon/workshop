# Storage Schema — Slack Message Artifacts

*Effort: slack-support*
*Date: 2026-04-21*
*Traces to: TR-4, TR-5, TR-7, TR-8, TR-15, TR-16*

---

## Overview

All Slack import artifacts are file-based, stored within the effort's own directory.
No database or external store is used. Access is controlled by repository permissions.

---

## Directory Layout

Each associated Slack channel gets its own subdirectory under `messages/`, keyed by
channel name slug. This keeps per-channel message history, checkpoints, and summaries
fully isolated regardless of how many channels an effort has.

```
efforts/<effort_id>/messages/
└── slack/
    └── <channel-name>/
        ├── .checkpoint                # ISO 8601 timestamp of last successful import for this channel
        ├── YYYY-MM/
        │   ├── YYYY-MM-DD.md          # Daily message file
        │   ├── YYYY-MM-DD-summary.md  # Daily summary
        │   └── week-<Www>-summary.md  # Weekly summary (ISO week number)
```

> `<channel-name>` is the Slack display name slug (e.g. `eng-payments`). The channel ID is stored in `.state.json` `slackChannels` and used only for API calls. Slack channel names are already lowercase-hyphenated and safe as directory names.

Example with two channels:

```
efforts/payments-v2/messages/
└── slack/
    ├── eng-payments/
    │   ├── .checkpoint
    │   └── 2026-04/
    │       └── 2026-04-21.md
    └── eng-platform/
        ├── .checkpoint
        └── 2026-04/
            └── 2026-04-21.md
```

---

## .checkpoint

Stored at `efforts/<effort_id>/messages/slack/<channel-name>/.checkpoint` — one file per channel.

| Field | Format | Notes |
|---|---|---|
| Content | ISO 8601 datetime string | e.g. `2026-04-20T23:59:59Z`. Single line, no trailing newline. Absent until first successful import for this channel. |

Behaviour rules:
- Written at the end of a successful watermark-based import for that channel only
- Bounded `--from`/`--to` runs must not modify this file
- If absent and no `--from` argument provided, import halts and prompts for start date for that channel
- If present but malformed, import halts with a parse error — no silent fallback

---

## YYYY-MM-DD.md — Daily Message File

### Front matter

```markdown
# Slack Messages — <channel-name> — <YYYY-MM-DD>

*Channel: <channel-id>*
*Imported: <ISO 8601 datetime>*

---
```

### Top-level message entry

```markdown
**<display-name>** · <HH:MM> UTC

<message text, preserving line breaks>
```

### Thread reply (nested under parent)

```markdown
**<display-name>** · <HH:MM> UTC

<message text, preserving line breaks>
```

Indented with `>` (Markdown blockquote) for each reply in the thread, in reply order.

Full example:

```markdown
**alice** · 09:14 UTC

Should we go with approach A or B for the storage layer?

> **bob** · 09:22 UTC
>
> I'd lean toward A — simpler migration path.
>
> **alice** · 09:31 UTC
>
> Agreed. Let's go with A.
```

### Cross-day thread reference

When a reply to a thread from a prior day lands in this file's date:

```markdown
↩ Reply in thread from 2026-04-19 — [Should we go with approach A or B…](../2026-04/2026-04-19.md)
```

*Anchor fragments are omitted until a future enhancement defines anchor IDs.*

### Confluence / Jira link enrichment

Links matching the organisation base URLs are enriched inline:

```markdown
See design notes: https://rakutenrewards.atlassian.net/wiki/spaces/ENG/pages/12345
> **[Confluence]** Payment Flow Redesign — Covers the proposed v2 checkout sequence and rollback strategy.

Tracked in: https://rakutenrewards.atlassian.net/browse/PDO-1234
> **[Jira · In Progress]** PDO-1234: Migrate preferences API to v2 — Backend migration of member preference endpoints.
```

If enrichment fails:

```markdown
https://rakutenrewards.atlassian.net/wiki/spaces/ENG/pages/99999
> [summary unavailable: 404 Not Found]
```

---

## YYYY-MM-DD-summary.md — Daily Summary File

### Structure

```markdown
# Daily Summary — <channel-name> — <YYYY-MM-DD>

*Generated: <ISO 8601 datetime>*
*Source: [YYYY-MM-DD.md](YYYY-MM-DD.md)*

---

## Architectural Decisions
<items, or "None identified.">

## Planning Decisions
<items, or "None identified.">

## Raised Risks
<items, or "None identified.">

## Raised Bugs
<items, or "None identified.">

## Specification Problems
<items, or "None identified.">

## Time-Off Notices
<items, or "None identified.">

## Status Updates
<items, or "None identified.">

## General Notes
<other notable discussion, or "None.">
```

High-priority sections always appear before General Notes regardless of order of
occurrence in the source messages.

---

## week-\<Www\>-summary.md — Weekly Summary File

### Structure

```markdown
# Weekly Summary — <channel-name> — <YYYY> Week <WW>

*Generated: <ISO 8601 datetime>*
*Source days: YYYY-MM-DD, YYYY-MM-DD, …*

---

## Architectural Decisions
- **<YYYY-MM-DD>** — <item>

## Planning Decisions
- **<YYYY-MM-DD>** — <item>

## Raised Risks
- **<YYYY-MM-DD>** — <item>

## Raised Bugs
- **<YYYY-MM-DD>** — <item>

## Specification Problems
- **<YYYY-MM-DD>** — <item>

## Time-Off Notices
- **<YYYY-MM-DD>** — <item>

## Status Updates
- **<YYYY-MM-DD>** — <item>

## General Notes
<aggregated notable themes across the week>
```

Each item in a high-priority section is attributed to its source day.

---

## PII Considerations

*Traces to: TR-11, TR-12*

- Message files contain author display names (PII — names) and message content
  (may contain incidental PII)
- Files are scoped to the effort directory and protected by repository access control
- No message content is transmitted to external services other than the Slack MCP
  (fetch) and the Atlassian MCP (link enrichment)
- Summary generation is performed within the user's Claude session only
