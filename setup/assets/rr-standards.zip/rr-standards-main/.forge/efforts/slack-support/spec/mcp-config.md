# MCP Configuration — Slack MCP

*Effort: slack-support*
*Date: 2026-04-21*
*Updated: 2026-04-23*
*Traces to: TR-2, TR-13*

---

## Required Change

The Forge plugin's `.mcp.json` must be updated to declare the official Slack MCP server
alongside the existing Atlassian and Uber-context declarations.

### Current `.mcp.json`

```json
{
  "mcpServers": {
    "uber-context": {
      "type": "http",
      "url": "https://uber-context-system.shared-np.rr-it.com/mcp"
    },
    "atlassian": {
      "type": "http",
      "url": "https://mcp.atlassian.com/v1/mcp"
    }
  }
}
```

### Required `.mcp.json`

```json
{
  "mcpServers": {
    "slack": {
      "type": "http",
      "url": "https://mcp.slack.com/mcp"
    },
    "uber-context": {
      "type": "http",
      "url": "https://uber-context-system.shared-np.rr-it.com/mcp"
    },
    "atlassian": {
      "type": "http",
      "url": "https://mcp.atlassian.com/v1/mcp"
    }
  }
}
```

> **Note:** The official Slack MCP server is a hosted HTTP endpoint at
> `https://mcp.slack.com/mcp`. It uses **OAuth 2.0** for authentication — there are
> no environment variables to configure. Authentication is handled via the OAuth flow
> when Claude Code connects to the server. The Slack app backing the integration must
> be a directory-published or internal app registered with a fixed app ID.
>
> OAuth endpoints:
> - Authorization: `https://slack.com/oauth/v2_user/authorize`
> - Token: `https://slack.com/api/oauth.v2.user.access`
>
> Reference: https://docs.slack.dev/ai/slack-mcp-server/

---

## Precondition Check Pattern

Skills that require Slack access must verify the MCP is available before proceeding,
following the same pattern as `forge:extract` uses for the Atlassian MCP:

```
If no mcp__slack__* tools are available in the session:
  Stop with:
    forge:<skill> error: Slack MCP not configured
    Reason: The Slack MCP server is not available in this session.
    Resolution: Ensure the Slack MCP server is declared in the Forge plugin's
                .mcp.json and that you have completed the OAuth authorization
                flow. Restart Claude Code and retry.
```

---

## Available Slack MCP Tools (expected)

| Tool | Used by | Purpose |
|---|---|---|
| `mcp__slack__get_channel_history` | `forge:slack-import` | Fetch messages for a channel in a time range |
| `mcp__slack__get_thread_replies` | `forge:slack-import` | Fetch all replies for a thread |
| `mcp__slack__get_users` | `forge:slack-import` | Resolve user IDs to display names |
| `mcp__slack__list_channels` | `forge:slack-channel` | Look up channel ID by name |

> **Note:** The exact tool names exposed by the official Slack MCP server should be
> verified against the live server at implementation time — the names above are
> provisional based on expected functionality.
