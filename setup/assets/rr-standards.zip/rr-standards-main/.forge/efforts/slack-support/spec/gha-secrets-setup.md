# GitHub Actions Secrets Setup

This is a **manual step**. CI will fail until these secrets are configured in the repository.
The `slack-import` workflow reads all three secrets at runtime — no code change is required once
they are set.

## Where to Configure

GitHub → repository **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

## Required Secrets

| Secret name | Value |
|---|---|
| `SLACK_BOT_TOKEN` | Slack bot token (`xoxb-...`) |
| `SLACK_TEAM_ID` | Slack workspace ID |
| `ANTHROPIC_API_KEY` | Anthropic API key for Claude |

### `SLACK_BOT_TOKEN`

A Slack bot token beginning with `xoxb-`. The bot must have the following OAuth scopes:

- `channels:history` — read message history from public channels
- `channels:read` — list public channels and look up channel IDs
- `users:read` — resolve user IDs to display names in summaries

Create or locate the bot at <https://api.slack.com/apps>, navigate to **OAuth & Permissions**,
grant the scopes above, and copy the **Bot User OAuth Token**.

### `SLACK_TEAM_ID`

The Slack workspace ID, which begins with `T` (e.g. `T01AB2CD3`). To find it:

1. Open Slack in a browser.
2. The workspace ID appears in the URL: `https://app.slack.com/client/<TEAM_ID>/...`

Alternatively, go to **workspace Settings & administration** → **Settings** — the ID is shown
in the URL of that page.

### `ANTHROPIC_API_KEY`

An Anthropic API key for Claude, used by `anthropics/claude-code-action@v1` to run the import
and summarize skills. Generate or retrieve the key from <https://console.anthropic.com/settings/keys>.

## Verifying the Setup

After setting all three secrets, trigger the workflow manually:

**Actions** tab → **Slack Import** → **Run workflow**

A successful run will show green checks on both the *Run Slack import and summarize* step and the
*Commit and push imported files* step. If either step fails, check the step logs for missing or
invalid secret values.
