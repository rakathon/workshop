# GHA + Slack MCP OAuth Checkpoint Findings (TASK-019)

*Effort: slack-support*
*Date: 2026-04-21*
*Traces to: ADR-001, TASK-019, TASK-020*

---

## 1. Claude Code CLI in GitHub Actions

**Answer: Yes — there is an official GitHub Actions integration.**

Anthropic publishes `anthropics/claude-code-action@v1` (source:
https://github.com/anthropics/claude-code-action). This action wraps the Claude Code
CLI and handles installation transparently on GitHub-hosted runners (ubuntu-latest).
No separate install step is needed; the action manages it internally.

### How to invoke

The action accepts a `prompt` parameter for automation mode and a `claude_args`
parameter for any Claude Code CLI flags. Supports `schedule` triggers directly.

**Minimal scheduled workflow skeleton:**

```yaml
name: Slack Import

on:
  schedule:
    - cron: "0 6 * * *"   # 06:00 UTC daily

jobs:
  slack-import:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: anthropics/claude-code-action@v1
        with:
          anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
          prompt: "forge:slack-import --ci"
          claude_args: |
            --max-turns 50
            --mcp-config plugins/forge/.mcp.json
```

### Required secrets

| Secret | Purpose |
|---|---|
| `ANTHROPIC_API_KEY` | Authenticate Claude Code CLI to the Anthropic API |

### Key CLI flags for TASK-020

- `--mcp-config <path>` — load MCP server declarations (needed to make
  `mcp__slack__*` and `mcp__atlassian__*` tools available)
- `--max-turns <n>` — set a ceiling for CI runs to prevent runaway jobs
- `--model <id>` — override model if needed (default is Sonnet)
- `claude_args` accepts any Claude Code CLI argument as a passthrough

Source: https://code.claude.com/docs/en/github-actions

---

## 2. Slack MCP OAuth Token Persistence for CI

**Answer: Not natively supported by the official hosted Slack MCP server.**

The official Slack MCP server (`https://mcp.slack.com/mcp`) uses confidential OAuth
2.0 (user-level authorization). The documented flow requires interactive browser
consent (`https://slack.com/oauth/v2_user/authorize`) — there is no published
mechanism for a headless runner to perform or skip this flow.

The `@modelcontextprotocol/server-slack` npm package (the stdio-based alternative)
uses `SLACK_BOT_TOKEN` and `SLACK_TEAM_ID` environment variables, which are
straightforwardly injectable as GitHub Actions secrets. However, this package is a
**community server** and exposes a different, narrower tool surface compared to the
official hosted server at `mcp.slack.com`.

### Options assessed

| Approach | Feasibility | Notes |
|---|---|---|
| Hosted `mcp.slack.com` + persisted user OAuth token | Uncertain | No official guidance on token persistence; the token issued by `oauth.v2.user.access` is a long-lived user token, but storage and injection mechanism is undocumented for CI |
| `@modelcontextprotocol/server-slack` (stdio) + `SLACK_BOT_TOKEN` | High | Standard bot token works; env var injected via GHA secrets; requires verifying tool name parity with skills' expected `mcp__slack__*` names |
| Slack bot token passed as `Authorization` header to `mcp.slack.com` | Unknown | No official guidance; Slack MCP docs do not describe token injection |

### Recommended approach for TASK-020 and TASK-021

Use the **`@modelcontextprotocol/server-slack` stdio server** with a Slack bot token
for the GitHub Actions workflow. Rationale:

1. Bot tokens (`xoxb-…`) are static, non-interactive credentials that can be stored
   as repository secrets and injected as environment variables — no browser consent
   flow required.
2. The stdio server is the established pattern for MCP in CI environments.
3. `SLACK_BOT_TOKEN` and `SLACK_TEAM_ID` map directly to GitHub Actions secrets.

**MCP config for CI (`.github/mcp-config-ci.json` or inline via `settings`):**

```json
{
  "mcpServers": {
    "slack": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-slack"],
      "env": {
        "SLACK_BOT_TOKEN": "${SLACK_BOT_TOKEN}",
        "SLACK_TEAM_ID": "${SLACK_TEAM_ID}"
      }
    },
    "atlassian": {
      "type": "http",
      "url": "https://mcp.atlassian.com/v1/mcp"
    }
  }
}
```

**Additional secrets required in the GHA workflow:**

| Secret | Purpose |
|---|---|
| `SLACK_BOT_TOKEN` | Bot token for the Slack workspace (`xoxb-…`) |
| `SLACK_TEAM_ID` | Slack workspace/team ID |
| `ATLASSIAN_API_TOKEN` | Atlassian MCP auth (if required by that server) |

The bot token must be obtained manually (TASK-021) from a Slack app with at minimum
`channels:history`, `channels:read`, and `users:read` scopes.

> **Risk:** The `@modelcontextprotocol/server-slack` stdio server may expose
> different tool names than the hosted `mcp.slack.com` server. The skills reference
> `mcp__slack__get_channel_history`, `mcp__slack__get_thread_replies`,
> `mcp__slack__get_users`, and `mcp__slack__list_channels` (see `spec/mcp-config.md`).
> These names must be verified against the stdio server before finalizing the workflow
> (see open questions below).

---

## 3. Recommended Approach for TASK-020 (Workflow Implementation)

Write `.github/workflows/slack-import.yml` with the following structure:

1. **Trigger:** `schedule` with configurable cron (daily, e.g. `0 6 * * *`).
2. **Checkout:** `actions/checkout@v4` with `fetch-depth: 0` (needed for commit/push).
3. **Claude Code invocation:** `anthropics/claude-code-action@v1` with:
   - `prompt`: `"forge:slack-import --ci"`
   - `claude_args`: `--max-turns 100 --mcp-config .github/mcp-config-ci.json`
   - `settings`: inject `SLACK_BOT_TOKEN`, `SLACK_TEAM_ID` as env vars so they reach
     the MCP server subprocess.
4. **Second Claude Code invocation** (or extend the same prompt):
   `forge:slack-summarize --daily` for each imported day.
5. **Commit-and-push:** Either rely on `forge:commit` being invoked within the Claude
   session (preferred — maintains traceability) or add a fallback `git push` step.

A separate CI MCP config file (`.github/mcp-config-ci.json`) should be committed to
the repository. It uses the stdio Slack server (bot token) rather than the OAuth HTTP
server used in interactive developer sessions. The interactive `.mcp.json` in the
plugin remains unchanged.

---

## 4. Open Questions

| # | Question | Blocking? |
|---|---|---|
| OQ-1 | Do the tool names exposed by `@modelcontextprotocol/server-slack` (stdio) match the `mcp__slack__*` names expected by the skills (`get_channel_history`, `get_thread_replies`, `get_users`, `list_channels`)? | Yes — must verify before TASK-004/TASK-007 implementation or before writing the workflow |
| OQ-2 | Does `anthropics/claude-code-action@v1` support MCP env var injection via the `settings` parameter for stdio servers? | Yes — must confirm the env var injection mechanism before TASK-020 |
| OQ-3 | Can the Atlassian MCP (`mcp.atlassian.com`) authenticate headlessly in a GHA runner, or does it also require interactive OAuth? | Yes — Atlassian enrichment in CI depends on this |
| OQ-4 | What Slack app scopes are required for the bot token, and does the workspace allow a bot token for the channels used? | Yes — required for TASK-021 (manual OAuth step) |

---

## 5. Summary

| Item | Confirmed? |
|---|---|
| Official GHA integration for Claude Code CLI | Yes — `anthropics/claude-code-action@v1` |
| Install/invocation mechanism | Action handles it; no separate install step needed |
| Slack MCP OAuth persistence for hosted server | Not documented; no official CI path |
| Alternative: stdio server with bot token | Feasible; standard CI pattern |
| Recommended approach for TASK-020 | Use stdio server + `SLACK_BOT_TOKEN` secret; separate CI MCP config |
| TASK-021 manual step still required | Yes — bot token creation and secret registration |
