# ADR-001: Use GitHub Actions for Scheduled Slack Import

*Effort: slack-support*
*Date: 2026-04-21*
*Status: Accepted*

---

## Context

`forge:slack-import` needs to run on a recurring schedule to keep effort message
files up to date without requiring manual intervention. Two mechanisms were considered:

1. **Claude Code crons** (`CronCreate`) — registered within the Claude Code session,
   run locally on the developer's machine.
2. **GitHub Actions scheduled workflow** — registered in `.github/workflows/`, run
   on GitHub's infrastructure using the `schedule` (cron) event.

## Decision

Use GitHub Actions as the scheduling mechanism.

## Rationale

| Criterion | Claude Code cron | GitHub Actions |
|---|---|---|
| Runs without IDE open | No — requires active Claude Code session | Yes — runs on GitHub's runners |
| Auditable / version-controlled | No — stored in local session state | Yes — workflow file in repo |
| Credentials management | Local environment variables | GitHub Actions secrets |
| Team visibility | Per-developer | Shared; visible in Actions tab |
| Reliability | Dependent on developer uptime | GitHub SLA |

The import is fundamentally a background data-collection job. Tying it to a
developer's local session undermines the goal of continuous, unattended import.
GitHub Actions is the right tool for headless, scheduled repository operations.

## Consequences

- A `.github/workflows/slack-import.yml` file must be added as part of this
  effort's implementation.
- Slack authentication is handled via the Slack MCP server's OAuth 2.0 flow — no
  Slack-specific environment variables need to be configured as repository secrets.
  The OAuth token obtained during authorization must be available to the GitHub
  Actions runner; the mechanism for this is to be confirmed at implementation time
  (see TASK-019).
- The Claude Code CLI must be available in the GitHub Actions runner (installed
  as a step in the workflow).
- `forge:slack-channel --schedule <cron>` records the intended cadence in
  `.state.json` for reference but does not register a Claude Code cron job.

## Alternatives Considered

**Claude Code crons:** Rejected because import reliability depends on a developer
having the IDE running on a machine with valid credentials — not acceptable for
a background data collection workflow.
