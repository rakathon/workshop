# ADR-002: Use Slack MCP Instead of Direct Slack REST API

*Effort: slack-support*
*Date: 2026-04-21*
*Status: Accepted*

---

## Context

`forge:slack-import` needs to fetch channel message history, thread replies, and user
display names from Slack. Two approaches were available:

1. **Direct Slack REST API** — skills call the Slack API endpoints directly using a
   bot token managed in the user's environment.
2. **Official Slack MCP server** — skills call Slack via the official hosted MCP
   server at `https://mcp.slack.com/mcp`, which mediates all API access and handles
   authentication via OAuth 2.0.

## Decision

Use the Slack MCP server for all Slack access. Skills must not call the Slack REST
API directly.

## Rationale

| Criterion | Direct REST API | Slack MCP |
|---|---|---|
| Credential management | Skill must handle token injection, rotation, and error handling | Handled entirely by the MCP server configuration |
| Consistency with existing pattern | N/A | Matches the existing Atlassian MCP pattern already in the plugin |
| Skill complexity | Each skill must implement HTTP calls, pagination, and error handling | Skills call typed MCP tools; transport and pagination are abstracted |
| Token scope enforcement | Skills must document and validate required scopes | MCP server declares and enforces scopes at configuration time |
| Future Slack API changes | Each skill must be updated | MCP server is updated independently of skill logic |

The Forge plugin already uses this pattern for Atlassian access via the Atlassian MCP.
Using the same pattern for Slack keeps the plugin architecture consistent and avoids
introducing a second credential management model.

## Consequences

- The official Slack MCP server (`https://mcp.slack.com/mcp`) must be declared in the
  Forge plugin's `.mcp.json` as a `type: "http"` server (see `spec/mcp-config.md`).
- Authentication is handled via OAuth 2.0 — no environment variables are required.
  Users complete an OAuth authorization flow when Claude Code first connects to the
  server. The backing Slack app must be a directory-published or internal app with a
  fixed app ID.
- All three `forge:slack-*` skills must verify MCP availability as a precondition and
  stop with a clear configuration error if the MCP server is not available.
- Skills are decoupled from Slack API versioning — API changes are absorbed by the
  MCP server, not the skill implementations.
- The exact MCP tool names exposed by the server must be verified at implementation
  time against the live server.

## Alternatives Considered

**Direct Slack REST API:** Rejected. Introducing direct API calls would require each
skill to manage token injection, handle HTTP errors, implement pagination, and stay
current with Slack API changes — all complexity the MCP abstraction eliminates.
