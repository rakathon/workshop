# Implementation Plan: Slack Support for Forge

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Plugin Infrastructure

- [ ] [checkpoint][wave:1] Add Slack MCP server declaration to `plugins/forge/.mcp.json` — confirm `@modelcontextprotocol/server-slack` is the correct package and that `stdio`/`npx` invocation works in the target Claude Code environment before proceeding (TASK-001)
- [ ] [auto][wave:1] Add `slackChannels` (array of `{id, name}` objects) and `slackImportSchedule` optional fields to the `.state.json` schema and document them in `.forge/spec/` or plugin schema docs (TASK-002)
- [ ] [auto][wave:1] Scaffold skill directory structure for `forge:slack-channel`, `forge:slack-import`, and `forge:slack-summarize` under `plugins/forge/skills/` (TASK-003)

## Wave 2 — forge:slack-channel Skill

- [ ] [tdd][wave:2] Implement `forge:slack-channel` SKILL.md: effort resolution via standard chain, add mode (Slack MCP check, channel ID resolution via `mcp__slack__list_channels`, append to `slackChannels` array, duplicate-skip warning), remove mode (no MCP required, remove from array, stop if not associated), `--schedule` cadence write, `--remove`/`--schedule` mutual exclusion, `forge:commit` integration (TASK-004)
- [ ] [auto][wave:2] Write `forge:slack-channel` tests: channel name lookup, channel ID passthrough, multi-channel add in one invocation, duplicate channel skipped with warning, remove mode removes channel, remove fails if channel not associated, `--schedule` writes correctly, `--remove` and `--schedule` together stops with error, missing effort stops with correct error (TASK-005)

## Wave 3 — forge:slack-import Core

- [ ] [tdd][wave:3] Implement checkpoint read/write logic: read `messages/slack/<channel-name>/.checkpoint` per channel, parse ISO 8601, resolve import range (watermark-based vs. bounded), write checkpoint on watermark runs only, halt on malformed checkpoint (TASK-006)
- [ ] [tdd][wave:3] Implement Slack message fetch: call `mcp__slack__get_channel_history` with pagination, call `mcp__slack__get_thread_replies` for threaded messages, resolve user IDs via `mcp__slack__get_users` with in-run cache (TASK-007)
- [ ] [tdd][wave:3] Implement daily message file writer: group messages by UTC calendar day, write `messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD.md` per spec format (author, timestamp, text), merge idempotently by message `ts` on re-run, create `slack/<channel-name>/YYYY-MM/` directory as needed (TASK-008)

## Wave 4 — forge:slack-import Threading & Enrichment

- [ ] [tdd][wave:4] Implement thread structure rendering: nest replies under parent with `>` blockquote indentation in reply order; parent position determined by parent timestamp in top-level flow (TASK-009)
- [ ] [tdd][wave:4] Implement cross-day thread handling: append late replies to parent's daily file; write `↩ Reply in thread from…` cross-reference entry in the reply's own daily file (TASK-010)
- [ ] [tdd][wave:4] Implement Atlassian link enrichment: detect Confluence (`/wiki/`) and Jira (`/jira`, `/browse`) URLs in message text, call Atlassian MCP to fetch title + description, append inline; write `[summary unavailable: <reason>]` on failure and continue (TASK-011)

## Wave 5 — forge:slack-import CI Mode & Wiring

- [ ] [tdd][wave:5] Implement `--ci` scan-and-dispatch mode: enumerate `.forge/efforts/`, collect efforts with non-empty `slackChannels` array, dispatch per effort+channel pair, catch per-channel errors without halting, emit CI summary log with `<effort_id>/<channel-id>` lines (TASK-012)
- [ ] [auto][wave:5] Wire `forge:slack-import` SKILL.md: effort resolution, `--channel` flag to scope to single channel (default all channels in `slackChannels`), all precondition checks (Slack MCP, Atlassian MCP, per-channel checkpoint/`--from`, mutually exclusive flags), `--from`/`--to` range parameters, `forge:commit` per effort, structured per-channel run log output (TASK-013)
- [ ] [auto][wave:5] Write `forge:slack-import` tests: watermark range resolution, bounded range does not advance checkpoint, idempotent re-import, empty range stops correctly, `--channel` scopes import to single channel, CI mode processes multiple efforts and channels, per-channel CI failure does not halt remaining channels or efforts (TASK-014)

## Wave 6 — forge:slack-summarize Skill

- [ ] [tdd][wave:6] Implement daily summary generation: read `messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD.md`, extract high-priority topic sections (architectural decisions, planning decisions, raised risks, raised bugs, specification problems, time-off notices, status updates) in fixed order before general notes, write `messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD-summary.md` (TASK-015)
- [ ] [tdd][wave:6] Implement weekly summary generation: resolve ISO week Monday–Sunday range, read all available daily files for the channel, aggregate high-priority items with per-item day attribution, write `messages/slack/<channel-name>/YYYY-MM/week-<Www>-summary.md` (TASK-016)
- [ ] [auto][wave:6] Wire `forge:slack-summarize` SKILL.md: effort resolution, `--channel` flag to scope to single channel (default all channels in `slackChannels`), per-channel source file precondition check, `--daily`/`--weekly` mutual exclusion, `forge:commit` after write, print per-channel summary output (TASK-017)
- [ ] [auto][wave:6] Write `forge:slack-summarize` tests: daily summary section ordering, weekly summary day attribution, `--channel` scopes summarization to single channel, all channels summarized when `--channel` omitted, regeneration overwrites existing file, missing source file for channel skips with warning, all channels missing stops, partial week proceeds with absent-day note (TASK-018)

## Wave 7 — GitHub Actions Workflow

- [ ] [checkpoint][wave:7] Verify Claude Code CLI is available as a GitHub Actions runner action or installable step, and determine how the Slack MCP OAuth token can be made available to the runner (persisted credential, re-auth flow, or service account approach) — confirm both before writing the workflow (TASK-019)
- [ ] [auto][wave:7] Write `.github/workflows/slack-import.yml`: `schedule` trigger with configurable cron, checkout step, Claude Code CLI invocation of `forge:slack-import --ci`, `forge:slack-summarize --daily` per imported day, commit-and-push step (TASK-020)
- [ ] [manual][wave:7] Complete Slack MCP OAuth authorization for the GitHub Actions runner and configure any resulting credentials as repository secrets per the approach confirmed in TASK-019 (TASK-021)

## Wave 8 — Documentation & Plugin Registration

- [ ] [auto][wave:8] Register all three skills in the Forge plugin manifest (`plugin.json` or equivalent skill registry) so they are discoverable via the skills list (TASK-022)
- [ ] [auto][wave:8] Update `plugins/forge/README.md` and relevant AGENTS.md files to document the three new skills, their arguments, and the Slack MCP setup requirement (TASK-023)
- [ ] [auto][wave:8] Add `forge:slack-*` skills to the plugin's `skills/` AGENTS.md navigation index (TASK-024)
