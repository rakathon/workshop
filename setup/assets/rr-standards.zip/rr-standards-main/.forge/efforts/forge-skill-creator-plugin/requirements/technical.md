# Technical Requirements — forge-skill-creator plugin

*Effort: forge-skill-creator-plugin*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-05-14*

---

## TR-1: Use the rr-standards Python harness for all test execution

*Traces to: BR-1*

The skill must use `run_skill_tests.py` (from rr-standards:test-skill) as its test runner. The Anthropic skill-creator's subagent-based eval runner must not be used. The Python harness is faster, produces deterministic structured output, and does not require a grader LLM.

## TR-2: Test viewer must show with-skill and without-skill outputs side-by-side

*Traces to: BR-1*

The viewer used to present results to the user must render the with-skill and without-skill (baseline) run outputs in a side-by-side layout within each test case. The Anthropic eval-viewer's single-column output layout must not be used. The rr-standards test-viewer (`shared/test-viewer/generate_review.py`) satisfies this requirement.

## TR-3: Test suites must use the test.yaml fixture format

*Traces to: BR-1*

All generated test suites must use the `test.yaml` format supported by the rr-standards harness, including `fixture_dir` support for skills that read, write, or perform side effects on the filesystem. JSON-embedded prompt/assertion definitions (as used by the Anthropic evals format) must not be used as the primary test definition format.

## TR-4: Minimal tests, maximal assertions

*Traces to: BR-1*

Auto-generated test suites must follow the rr-standards test-skill convention: 2–3 tests covering the most important behavioral scenarios, each with 3–5 observable-output assertions. Generating large test suites (the Anthropic skill-creator default of many shallow tests) is prohibited. Each test must be differentiating — it must test behavior an LLM would not produce correctly without the skill's instructions.

## TR-5: Forge context is optional, not required

*Traces to: BR-2*

The skill must be fully functional in a repository with no Forge installation and no `.forge/` directory. Detection of Forge context (presence of `.forge/EFFORT`, `.forge/efforts/`) must be done at runtime and must not cause errors or degraded behavior when absent. When Forge context is present, the skill enhances its behavior (writing discovery artifacts to `.forge/efforts/<id>/`, using effort title as skill name default) but does not require it.

## TR-7: Python harness and test-viewer are bundled within the skill

*Traces to: BR-4*

The skill must bundle its own copies of `run_skill_tests.py` and the test-viewer (`generate_review.py`) under `plugins/forge/skills/skill-creator/`. It must not reference the copies in `plugins/rr-standards/skills/test-skill/`. This makes the skill self-contained, allows independent evolution, and enables rr-standards:test-skill to be deprecated cleanly.

## TR-9: External distribution POSTs to a single API endpoint; backend handles S3 and Box

*Traces to: BR-9*

When a user outside the rr-standards repository publishes a skill, the skill POSTs the packaged `.skill` file to a single HTTPS API Gateway endpoint. The API backend is responsible for depositing the file in both S3 (triggering the Lambda → rr-standards PR pipeline) and the shared Box staging library. The skill has no direct S3 or Box dependency.

This effort owns the API Gateway upload contract — endpoint URL, request format, authentication, and response schema — because it is the interface boundary between this skill and the backend. The contract must be documented in `spec/` before implementation begins.

The API endpoint URL is runtime configuration. The skill must not hardcode it and must surface a clear error if it is not configured. Box folder structure details are owned by the Lambda effort.

The endpoint is an internal HTTPS URL protected by Zscaler — no additional authentication is required from the client. If the request fails with a connection error (not a 4xx/5xx), the skill should surface a plain-language message: "Unable to reach the skill submission endpoint — make sure you are connected to the corporate network or VPN."

## TR-10: Self-review uses forge:review or inline equivalent

*Traces to: BR-8*

The skill must invoke `forge:review` to perform its unprompted quality review pass when operating inside a Forge-initialized repository. When Forge is not available, the skill must perform an inline equivalent check: read the SKILL.md, verify structural completeness (frontmatter fields, no empty sections, test.yaml present, description triggering quality), and surface findings in the same PASS/FAIL format. The review must complete before distribution options are presented.

## TR-8: Offer .skill file packaging as a distribution step

*Traces to: BR-4*

At the end of the session, the skill must offer to package the finished skill as a `.skill` file (a ZIP archive containing the skill directory, renamed to `<skill-name>.skill`). `.skill` files are installable across Claude Code (copy to skills folder), Claude Desktop, and Claude web (Settings → Customize → Skills → Upload Skill). The packaging step should also tell the user how to install the file for their platform. For Forge repos, the skill should additionally offer to commit the skill directory to the repo so it is available via the rr-standards marketplace.

## TR-6: Output location is derived from repo structure, proposed, then confirmed before any writes

*Traces to: BR-2*

The skill must inspect the repository structure to derive the most appropriate skill output location, then present it to the user for confirmation before writing any file.

**Location inference rules (applied in order):**
1. If a `plugins/` directory exists with a `skills/` subdirectory pattern (e.g. `plugins/forge/skills/`), propose placing the new skill alongside existing skills in that structure
2. If a `.claude/skills/` directory exists at the project root, propose that
3. If Forge is initialized but no plugin/skill structure is found, propose `.claude/skills/<skill-name>/` and note it can be moved later
4. If none of the above, propose `<skill-name>/` in the current working directory

The skill presents its reasoning in plain language ("I can see this repo uses `plugins/forge/skills/` for skills — I'll put yours at `plugins/forge/skills/<skill-name>/`") and offers to use that location or enter a different one. No file may be written until the user has confirmed.
