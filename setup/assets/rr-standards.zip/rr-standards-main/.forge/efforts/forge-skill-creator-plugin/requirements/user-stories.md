# User Stories — forge-skill-creator plugin

*Effort: forge-skill-creator-plugin*
*Derived from: [requirements/business.md](business.md)*
*Written: 2026-05-14*

---

## Guided skill creation for non-technical users

- As a non-technical user, I want to say "I want to build a skill that does X" and be guided through the entire process, so that I can create a working, tested skill without knowing what commands to run or what a test harness is.
- As a non-technical user, I want the skill to ask me about who the skill is for, what it does, when it triggers, what it takes as input, how it works, and what it produces — then confirm its understanding before generating anything — so that I don't waste 15 minutes waiting for a draft that is completely wrong.
- As a non-technical user, I want all files written during my session to be readable markdown, so that I can open and understand them without technical knowledge.
- As a non-technical user, I want the skill to pick up where I left off if I close Claude and come back, so that I don't have to start over.

## Improving existing skills

- As a developer with an existing SKILL.md, I want to run `forge:skill-creator` against it to run tests and improve it, so that I get the full test-and-improve loop without recreating the skill from scratch.
- As a developer, I want to be able to revisit the intent and description of an existing skill even while improving it, so that I can course-correct if the original design was off.

## Testing and iteration

- As a skill author, I want tests to run with and without my skill in a side-by-side viewer, so that I can clearly see whether my skill actually improves behavior.
- As a skill author, I want test suites to be small (2–3 tests) with rich assertions, so that runs are fast and failures are specific.
- As a skill author, I want to use fixture directories in my tests, so that I can test skills that read, write, or perform side effects on the filesystem.
- As a skill author, I want the skill to propose specific, plain-language improvements after each test run and wait for my confirmation before changing anything, so that I stay in control of my skill's content.
- As a power user, I want to say "just fix everything" to let the skill apply all improvements autonomously, so that I can move faster when I trust the agent's judgment.

## Quality and review

- As a skill author, I want a quality review to run automatically before I finish, so that I don't publish a skill that fails organizational standards without knowing it.
- As a skill author, I want the review to give me a PASS/FAIL verdict with specific findings, so that I know exactly what to fix rather than just that something is wrong.

## Description optimization

- As a skill author, I want to be offered a description optimization pass after my skill is working, so that Claude reliably triggers it in the right situations.
- As a non-technical user, I want to be able to skip description optimization if I don't need it, so that I'm not blocked by a step I don't understand.

## Output location and Forge integration

- As a developer in the rr-standards repository, I want the skill to place my new skill in the right location within the existing plugin structure, so that it is immediately installable via the marketplace after my PR is merged.
- As a developer in any Forge-initialized repository, I want discovery artifacts written to `.forge/efforts/<id>/` and the skill implementation written to the right place in the repo structure, so that all work is traceable and consistently organized.
- As a developer in a Forge repo with no active effort, I want to be offered the choice to create one or work standalone, so that I can opt into Forge traceability without it being forced on me.
- As any user, I want the skill to show me exactly where it plans to write files and ask for confirmation, so that I never find files in unexpected locations.

## Distribution

- As a skill author outside the rr-standards repository, I want to publish my finished skill to the organization's submission endpoint, so that it enters the review pipeline and gets merged into rr-standards.
- As a skill author, I want my submitted skill to be immediately available in a shared Box staging library, so that colleagues can use it while it is waiting for review.
- As a skill author, I want to package my skill as a `.skill` file, so that I can share it directly with colleagues for installation in Claude Code, Claude Desktop, or Claude web.
- As a user on the corporate network, I want the submission step to work without any credential setup, so that I'm not blocked by AWS or API key configuration.
