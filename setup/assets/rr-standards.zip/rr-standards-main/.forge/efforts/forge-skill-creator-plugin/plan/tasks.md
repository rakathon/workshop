# Implementation Plan: forge-skill-creator plugin

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

**Effort:** forge-skill-creator-plugin
**Type:** story (lightweight / extension)

> **Implementation note (BR-11):** Before writing any code or SKILL.md content,
> the implementer must read both source skills in full:
> - `plugins/rr-standards/skills/test-skill/SKILL.md` (this repo)
> - Anthropic skill-creator: `gh api repos/anthropics/claude-plugins-official/contents/plugins/skill-creator/skills/skill-creator/SKILL.md --jq '.content' | base64 -d`
>
> Copy reusable components directly. Deviations from either source must be intentional.

---

```mermaid
gantt
    title forge-skill-creator Delivery Sequence
    dateFormat YYYY-MM-DD

    section Wave 1 - Scaffold and Study
    Read source skills and scaffold dir      :task1, 2024-01-01, 1d
    Bundle Python harness                    :task2, 2024-01-01, 1d
    Bundle test viewer                       :task3, 2024-01-01, 1d
    Copy Anthropic scripts and agents        :task4, 2024-01-01, 1d
    Copy description optimization scripts    :task5, 2024-01-01, 1d
    Document S3 submission API contract      :crit, task6, 2024-01-01, 1d
    Wave 1 complete                          :milestone, m0, 2024-01-02, 0d

    section Wave 2 - SKILL.md Intake and Draft
    Write SKILL.md intake draft and resume   :task7, 2024-01-02, 1d
    Wave 2 complete                          :milestone, m1, 2024-01-03, 0d

    section Wave 3 - SKILL.md Test and Improve
    Write SKILL.md test and improve loop     :task8, 2024-01-03, 1d
    Wave 3 complete                          :milestone, m2, 2024-01-04, 0d

    section Wave 4 - SKILL.md Review and Publish
    Write SKILL.md review and publish        :task9, 2024-01-04, 1d
    Skill end-to-end usable                  :milestone, m3, 2024-01-05, 0d

    section Wave 5 - Behavioral Validation
    Write test.yaml and fixtures             :task10, 2024-01-05, 1d
    Run test-skill and iterate               :task11, 2024-01-06, 1d
    Behavioral validation passing            :milestone, m4, 2024-01-07, 0d
```

---

## Wave 1 — Scaffold & Source Study

### TASK-001 ✅ [auto][wave:1]

Read both source skills in full, scaffold the `plugins/forge/skills/skill-creator/` directory, and create the initial `SKILL.md` with frontmatter only (name, description stub).

**Satisfies:** BR-4, BR-11, TR-7
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-002 ✅ [auto][wave:1]

Bundle the Python test harness: copy `plugins/rr-standards/skills/test-skill/skill-runner/run_skill_tests.py` into `plugins/forge/skills/skill-creator/skill-runner/run_skill_tests.py`. Verify it runs standalone with `python3 run_skill_tests.py --help`.

> **Note:** Placed in `scripts/` (intentional deviation from plan — separate subdirectory not warranted).

**Satisfies:** TR-1, TR-7
**Standards:** none
**Required tests:** none (asset copy task)

---

### TASK-003 ✅ [auto][wave:1]

Bundle the side-by-side test viewer: copy `plugins/rr-standards/skills/shared/test-viewer/generate_review.py` into `plugins/forge/skills/skill-creator/test-viewer/generate_review.py`. Verify it accepts `--static` flag for headless environments.

> **Note:** Placed in `scripts/` (intentional deviation from plan — separate subdirectory not warranted). `--static` flag present and verified.

**Satisfies:** TR-2, TR-7
**Standards:** none
**Required tests:** none (asset copy task)

---

### TASK-004 ✅ [auto][wave:1]

Copy Anthropic skill-creator reusable components from `anthropics/claude-plugins-official`: `scripts/aggregate_benchmark.py`, `scripts/utils.py`, `agents/grader.md`, `agents/comparator.md`, `agents/analyzer.md`, `scripts/quick_validate.py`. Place under `plugins/forge/skills/skill-creator/scripts/` and `plugins/forge/skills/skill-creator/agents/`. Add `LICENSE.txt` attribution.

**Satisfies:** BR-11, TR-7
**Standards:** none
**Required tests:** none (asset copy task)

---

### TASK-005 ✅ [auto][wave:1]

Copy Anthropic description-optimization scripts: `scripts/run_loop.py`, `scripts/run_eval.py`, `scripts/improve_description.py`, and `assets/eval_review.html`. Place under the same `scripts/` and `assets/` directories. Verify `run_loop.py --help` runs without error.

**Satisfies:** BR-6, BR-11, TR-7
**Standards:** none
**Required tests:** none (asset copy task)

---

### TASK-006 ⚠️ [checkpoint][wave:1]

Document the S3 submission API contract in `plugins/forge/skills/skill-creator/references/submission-api.md`: endpoint URL pattern, HTTP method, request format (multipart or JSON+base64), response schema (201 on success, error codes), and Zscaler network requirement. Share with the Lambda pipeline team for sign-off — confirm contract is agreed before TASK-009 (publish step) is implemented.

> **Gap:** `submission-api.md` is present with full contract content, but is still marked DRAFT — Lambda team sign-off has not been confirmed. TASK-009 was implemented before this checkpoint was cleared.

**Satisfies:** TR-9
**Standards:** none
**Required tests:** none (checkpoint — no code written until contract confirmed)

---

## Wave 2 — SKILL.md: Intake, Draft & Resumability

### TASK-007 ✅ [tdd][wave:2]

Write the intake, draft, and resumability sections of `SKILL.md`. Covers: context detection (Forge vs. standalone), optional Forge effort creation, the seven-dimension interview (conversational, not prescriptive), location inference and confirmation (TR-6 rules), the intent summary-and-confirm gate, SKILL.md draft generation, and phase resumption logic (read existing artifacts to infer current state).

Key behaviors to implement:
- Forge context detection: check `.forge/EFFORT`, `.forge/efforts/`, `.forge/branching.md`
- Location inference: `plugins/*/skills/` → `.claude/skills/` → `.claude/skills/` (Forge) → `<name>/` (CWD)
- Resume logic: SKILL.md present + no test results → resume at testing; test results present → resume at improve loop
- Existing skill mode (BR-10): detect SKILL.md argument or current-dir SKILL.md, skip to test phase

**Satisfies:** BR-1, BR-2, BR-3, BR-7, BR-10, TR-5, TR-6
**Standards:** none
**Required tests:**
- `test_context_detection_forge` — verifies Forge context is detected when `.forge/EFFORT` exists
- `test_context_detection_standalone` — verifies standalone mode when no `.forge/` present
- `test_location_inference_plugins_dir` — verifies `plugins/forge/skills/` pattern is proposed
- `test_location_inference_fallback` — verifies CWD fallback when no known structure found
- `test_resume_from_draft` — verifies skill resumes at test phase when SKILL.md exists but no test results
- `test_resume_from_test_results` — verifies skill resumes at improve loop when test results exist

---

## Wave 3 — SKILL.md: Test & Improve Loop

### TASK-008 ✅ [tdd][wave:3]

Write the test generation, harness execution, and improvement loop sections of `SKILL.md`. Covers: auto-generating `test.yaml` (minimal-tests/maximal-assertions, TR-4), invoking `run_skill_tests.py` via the bundled harness (TR-1), launching the side-by-side viewer (TR-2), proposing improvements section-by-section with confirmation (BR-5), autonomous mode activation on explicit user instruction (BR-5), convergence report table, and `without_skill` baseline reuse across iterations.

Key behaviors:
- `test.yaml` generation: 2–3 tests, 3–5 assertions each, differentiating behavior only
- Viewer: always use bundled `test-viewer/generate_review.py`; use `--static` in headless env
- Improvement mode: default confirmation per change; autonomous on "just fix everything"
- Convergence: show iteration history table after every run

**Satisfies:** BR-1, BR-5, TR-1, TR-2, TR-3, TR-4
**Standards:** none
**Required tests:**
- `test_yaml_generation_minimal` — verifies generated test.yaml has ≤3 tests
- `test_yaml_assertions_count` — verifies each test has 3–5 assertions
- `test_improvement_confirmation_mode` — verifies changes are proposed before applied by default
- `test_autonomous_mode_activation` — verifies autonomous mode activates on "just fix everything"
- `test_convergence_report_shown` — verifies iteration history table appears after each run

---

## Wave 4 — SKILL.md: Review, Finish & Publish

### TASK-009 ✅ [tdd][wave:4]

Write the self-review, description optimization, packaging, and distribution sections of `SKILL.md`. Covers: unprompted `forge:review` invocation (or inline structural check when Forge unavailable), PASS/FAIL verdict with findings (TR-10), optional description optimization offer with plain-language explanation (BR-6), `.skill` file packaging with install instructions for all platforms (TR-8), and S3 API submission via the contracted endpoint (TR-9, TASK-006 must be confirmed first).

Key behaviors:
- Self-review runs automatically; FAIL does not block distribution
- Description optimization: offer after convergence, explain duration, skip gracefully if `claude` CLI absent
- Packaging: ZIP skill directory, rename to `<name>.skill`, show per-platform install instructions
- Distribution: POST to configured endpoint; Zscaler error message on connection failure; endpoint URL from config not hardcoded
- In rr-standards repo: offer `forge:commit` + PR instructions instead of API submission

**Satisfies:** BR-6, BR-8, BR-9, TR-8, TR-9, TR-10
**Standards:** none
**Required tests:**
- `test_self_review_runs_unprompted` — verifies review fires without user asking
- `test_self_review_fail_nonblocking` — verifies FAIL verdict does not prevent distribution step
- `test_packaging_produces_skill_file` — verifies `.skill` ZIP is created with correct contents
- `test_submission_zscaler_error_message` — verifies clear message on connection failure
- `test_description_opt_skippable` — verifies session continues cleanly when user declines opt

---

## Wave 5 — Behavioral Validation

### TASK-010 ✅ [auto][wave:5]

Write `plugins/forge/skills/skill-creator/test.yaml` with 2–3 behavioral test cases and fixtures. Focus on skill-differentiating behavior: (1) a non-technical user creating a skill from scratch — verify draft is produced and test.yaml is generated; (2) an existing SKILL.md improvement — verify the skill skips intake and proceeds to testing; (3) Forge context — verify discovery artifacts land under `.forge/efforts/<id>/` and skill lands outside `.forge/`. Create fixture directories with representative starting states.

**Satisfies:** BR-1, BR-3, BR-10, TR-3, TR-4
**Standards:** `plugins/rr-standards/skills/test-skill/SKILL.md`
**Required tests:** none (test authoring task — the tests ARE the output)

---

### TASK-011 ✅ [tdd][wave:5]

Run `rr-standards:test-skill` against `plugins/forge/skills/skill-creator/` and iterate until `with_skill pass rate ≥ 80%` and `lift ≥ 20%`. Review viewer output after each iteration; apply accepted improvements to `SKILL.md`. Produce convergence report showing final pass rates.

**Satisfies:** BR-1, BR-4, TR-1, TR-4
**Standards:** `plugins/rr-standards/skills/test-skill/SKILL.md`
**Required tests:**
- All tests in `test.yaml` must pass at ≥80% with-skill rate
- Lift vs. baseline must be ≥20%

---
