# Implementation Plan: forge:statusline Skill

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Foundation

### TASK-001 [auto][wave:1]

Create `plugins/forge/statusline/` resource directory and scaffold `forge-statusline.py` with the main entry point, safe JSON parsing, field extraction with defaults, and the two-line output skeleton (`build_line1`, `build_line2` stubs).

**Satisfies:** TR-1, TR-2, TR-3
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-002 [auto][wave:1]

Create `plugins/forge/statusline/forge-subagent-statusline.py` — reads `tasks` array from stdin JSON and emits one JSON line per task formatted as `[type] name · status · Xtk`.

**Satisfies:** BR-6, TR-9
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-003 [auto][wave:1]

Create `plugins/forge/skills/statusline/SKILL.md` — the full `forge:statusline` skill definition covering install flow (Steps 1–5), uninstall flow, `--replace` / `--uninstall` arguments, and the settings merge logic for both `statusLine` and `subagentStatusLine`.

**Satisfies:** BR-1, BR-2, BR-6, TR-6, TR-8
**Standards:** none
**Required tests:** none (skill definition document, not executable code)
**Completed:** 9bed9cf

---

## Wave 2 — Core Script Logic

### TASK-004 [tdd][wave:2]

Implement `_find_forge_root(cwd)` — walks up the directory tree from `cwd` to find the nearest ancestor containing a `.forge/` directory; returns `None` at the filesystem root.

**Satisfies:** TR-4
**Standards:** none
**Required tests:**
- Unit: `test_find_forge_root_finds_ancestor` — returns correct path when `.forge/` exists in a parent
- Unit: `test_find_forge_root_returns_none_at_root` — returns `None` when no `.forge/` exists anywhere
- Unit: `test_find_forge_root_finds_cwd_itself` — returns `cwd` when `.forge/` is directly in it

---

### TASK-005 [tdd][wave:2]

Implement `_resolve_effort(cwd)` — reads `.forge/EFFORT` if present, falls back to branch name suffix parsing, reads `.state.json`, truncates title to 30 chars, returns `{id, title, phase}` or `{}`.

**Satisfies:** TR-4, TR-5
**Standards:** none
**Required tests:**
- Unit: `test_resolve_effort_reads_effort_file` — returns effort from `.forge/EFFORT` when present
- Unit: `test_resolve_effort_falls_back_to_branch` — returns effort from `effort/<id>` branch when no EFFORT file
- Unit: `test_resolve_effort_truncates_title` — titles longer than 30 chars are truncated with `…`
- Unit: `test_resolve_effort_returns_empty_when_no_forge` — returns `{}` when no `.forge/` found
- Unit: `test_resolve_effort_returns_empty_on_corrupt_state` — returns `{}` on malformed `.state.json`

---

### TASK-006 [tdd][wave:2]

Implement `get_effort_context(cwd, session_id)` — wraps `_resolve_effort` with a `/tmp/forge-statusline-<session_id>` cache (5-second TTL based on file mtime).

**Satisfies:** TR-4
**Standards:** none
**Required tests:**
- Unit: `test_effort_cache_hit` — returns cached value without calling `_resolve_effort` within TTL
- Unit: `test_effort_cache_miss_after_ttl` — calls `_resolve_effort` and refreshes cache after 5s
- Unit: `test_effort_cache_uses_session_id` — different session IDs use different cache files

---

### TASK-007 [tdd][wave:2]

Implement `build_line2(pct)` — returns a colored 10-char progress bar string with percentage; green < 70%, yellow 70–89%, red ≥ 90%; handles `None`/`0` gracefully.

**Satisfies:** BR-3, TR-2, TR-3
**Standards:** none
**Required tests:**
- Unit: `test_build_line2_green_below_70` — bar uses green ANSI code when pct < 70
- Unit: `test_build_line2_yellow_70_to_89` — bar uses yellow ANSI code when 70 ≤ pct < 90
- Unit: `test_build_line2_red_at_90` — bar uses red ANSI code when pct ≥ 90
- Unit: `test_build_line2_handles_zero` — returns valid output when pct is 0 or None
**Completed:** 2e10756

---

### TASK-008 [tdd][wave:2]

Implement `build_line1(model, dirname, cost_usd, dur_ms, worktree, cwd, session_id)` — assembles the first status line, including git branch (or worktree branch), effort context segment, cost, and duration; suppresses missing segments gracefully.

**Satisfies:** BR-3, BR-4, TR-2, TR-3, TR-5
**Standards:** none
**Required tests:**
- Unit: `test_build_line1_basic` — returns model and dirname at minimum with no git/effort context
- Unit: `test_build_line1_with_effort` — includes effort ID and phase when effort context present
- Unit: `test_build_line1_worktree_mode` — uses `worktree.branch` when worktree data present
- Unit: `test_build_line1_no_git_repo` — suppresses branch segment outside a git repo

---

## Wave 3 — Script Integration & Hash

### TASK-009 [tdd][wave:3]

Wire `build_line1`, `build_line2`, and `get_effort_context` together in `main()` — reads stdin JSON, extracts all fields with safe defaults, prints two lines; ensures non-zero exit never occurs.

**Satisfies:** TR-1, TR-2, TR-3
**Standards:** none
**Required tests:**
- Integration: `test_main_full_output` — given valid mock JSON, produces two non-empty lines
- Integration: `test_main_graceful_on_empty_json` — given `{}`, produces fallback output without error
- Integration: `test_main_graceful_on_invalid_json` — given garbage stdin, prints fallback and exits 0

---

### TASK-010 [auto][wave:3]

Generate `plugins/forge/statusline/forge-statusline.py.sha256` — compute the combined SHA-256 of `forge-statusline.py` and `forge-subagent-statusline.py` (concatenated in alphabetical filename order) and write to the hash file. Document the algorithm in a comment inside the hash file.

**Satisfies:** TR-7
**Standards:** none
**Required tests:** none (generated artifact — correctness verified by TASK-013)

---

## Wave 4 — forge:update Integration & Skill Polish

### TASK-011 [auto][wave:4]

Update `plugins/forge/skills/update/SKILL.md` — add a staleness check step that computes the combined hash of installed scripts, compares against the plugin's `.sha256` file, and prints the advisory if either script is absent or the hash differs.

**Satisfies:** BR-5, TR-7
**Standards:** none
**Required tests:** none (skill definition document)

---

### TASK-012 [auto][wave:4]

Update `plugins/forge/skills/update/SKILL.md` — replace the existing `find`-based plugin root resolution (Step 3) with a reference to `plugins/forge/skills/common/plugin-root.md` per ADR-034.

**Satisfies:** ADR-034
**Standards:** none
**Required tests:** none (skill definition document)

---

### TASK-013 [auto][wave:4]

Manual smoke-test: install the statusline on a local machine by running `/forge:statusline`, confirm both scripts appear in `~/.claude/`, confirm `~/.claude/settings.json` has both `statusLine` and `subagentStatusLine` entries, and confirm the statusline renders correctly in a Claude Code session — confirm `--uninstall` cleanly removes both.

**Satisfies:** BR-1, BR-2, BR-3, BR-6
**Standards:** none
**Required tests:** none (manual verification task)

---
