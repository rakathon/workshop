# User Stories — forge:statusline Skill

*Effort: forge-statusline*
*Derived from: [requirements/business.md](business.md)*
*Written: 2026-04-26*

---

## Installation

- As a Forge engineer, I want to install the Forge statusline with a single command so that I don't have to manually write a script or edit settings files.
- As a Forge engineer, I want installation to be opt-in so that my existing custom statusline is never overwritten without my consent.
- As a Forge engineer with an existing statusline, I want the skill to stop and tell me what conflicts so that I can decide whether to replace it using `--replace`.
- As a Forge engineer, I want to uninstall the Forge statusline cleanly so that my settings are left in the same state as before I ran the skill.

## Effort Awareness

- As a Forge engineer, I want my statusline to show the active effort ID, title, and current phase so that I always know what I'm working on without switching context.
- As a Forge engineer working in a subdirectory of my repo, I want effort context to still resolve correctly so that the statusline works regardless of where Claude Code was launched.
- As a Forge engineer who is not in a Forge repo, I want the statusline to degrade gracefully to model and directory information so that it never shows errors or blank output.

## Session Health

- As a Forge engineer, I want a color-coded context bar that turns yellow then red as the context window fills so that I know when I'm approaching the limit before it affects my session.
- As a Forge engineer, I want to see session cost and elapsed time at a glance so that I can make informed decisions about starting a new session.

## Worktree Support

- As a Forge engineer running tasks in a `--worktree` session, I want the statusline to show the worktree name and branch so that I can distinguish it from my main session.

## Subagent Panel

- As a Forge engineer running multi-agent workflows, I want the agent panel to show each subagent's type, status, and token count so that I can monitor what's running at a glance.

## Maintenance

- As a Forge engineer who has upgraded the plugin, I want `forge:update` to tell me if my installed statusline scripts are out of date so that I know to re-run `forge:statusline`.
