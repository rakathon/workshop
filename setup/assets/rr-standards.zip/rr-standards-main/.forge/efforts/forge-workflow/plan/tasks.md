# Implementation Plan: Forge Workflow

Tasks within the same wave are independent and can run in parallel on separate git
worktrees. Tasks in wave N+1 require wave N complete before starting.

Each task has a **Produces** section listing every file it creates or updates and a
**Verification** section describing how to confirm the task is complete and correct.

**Capabilities created by this plan** (each is a user-facing feature):

| Capability | What it delivers |
|---|---|
| `forge-effort` | Create and track work efforts; automatic state management via hooks; CLAUDE.md guidance layer |
| `forge-promote` | Advance efforts through phases via the promotion ritual |
| `forge-adr` | Capture architecture decisions during conversation |
| `forge-arch-review` | Validate design against standards; produce architecture review document |
| `forge-plan` | Generate annotated, wave-ordered implementation plan |
| `forge-verify` | Verify implementation delivers stated requirements; per-task quality loop contract |
| `forge-graduate` | Promote completed effort artifacts to canonical deployable documentation |
| `forge-cross-repo` | Create and maintain efforts that span multiple repositories |

**Existing capability modified:** `forge-init` — CLAUDE.md template updated to write the
forge-managed Tier 1 section.

---

## Wave 1 — Foundation (parallel; no dependencies)

- [x] [auto][wave:1] Scaffold the eight new capability directories under `.forge/deployables/forge-plugin/capabilities/` with the standard structure: `requirements/`, `spec/`, `test/`, `security/`, `runbook/`, and a stub `README.md` in each. Also create a stub `spec/arch-decisions/` in capabilities that will have ADRs. (TASK-001)

  **Capability:** all eight new capabilities (structure only)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/` (full tree)
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/` (full tree)
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/` (full tree)
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/` (full tree)
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/` (full tree)
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/` (full tree)
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/` (full tree)
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/` (full tree)

  **Verification:** all eight capability directories exist with complete subdirectory structure matching the `forge-init` capability pattern; each has a non-empty README.md stub.

---

- [x] [auto][wave:1] Define the `.state.json` schema for all forge-workflow fields; write as a schema reference document and a JSON template file. Fields to cover: `subtype`, `productionBound`, `spawnedWorkItems`, `coordinationRef` (with nested `projections`), `upstreamProposals`, `openDecisions`, `phases.*.postApprovalModifications`, and `graduation`. (TASK-002)

  **Capability:** `forge-effort`
  **Requirements:** TR-0 (subtype, productionBound), TR-1 (state schema), TR-4 (coordinationRef), TR-6 (upstreamProposals), TR-9 (postApprovalModifications), TR-12 (graduation)
  **Spec:** State Management (.state.json Schema Extensions)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/spec/state-schema.md` — field-by-field reference with types, constraints, and an annotated example
  - `plugins/forge/templates/workflow/state.json.template` — valid JSON template with all fields and inline comments

  **Verification:** template is valid JSON; every schema field described in the forge-workflow spec's State Management section is present; `coordinationRef.projections` is an array with the correct provenance fields; the template is usable as a starting point by `forge:effort` with minimal substitution.

---

- [x] [auto][wave:1] Write the forge-managed CLAUDE.md section template — the Tier 1 content (~60-80 lines): Forge description, `.forge/` subdirectory explanations, terse intent recognition list (7 entries, one line each including the checkpoint task entry), and the before-write rule. Update the `forge-init` capability spec to reference this template. (TASK-003)

  **Capability:** `forge-init` (modification)
  **Requirements:** TR-10 (three-tier CLAUDE.md), TR-15 (conversational intent), ADR-001 (three-tier context design)
  **Spec:** Tier 1 CLAUDE.md Content, Layer 1 Context Budget Design

  **Produces:**
  - `plugins/forge/templates/forge-claude-md-section.md` — the Tier 1 template
  - `.forge/deployables/forge-plugin/capabilities/forge-init/spec/skills.md` — updated section describing the three-tier injection design and referencing the new template

  **Verification:** template is between 60 and 80 lines; contains all seven intent recognition entries from the spec (including checkpoint task entry); contains the before-write rule referencing hook-injected routing; `forge-init` capability spec references the template path.

---

- [x] [auto][wave:1] Write `AGENTS.md` in `.forge/deployables/forge-plugin/capabilities/` explaining what capabilities are, how to name them, and how to create them; write the equivalent navigation file in `plugins/forge/skills/` for agents working in the distributed plugin. (TASK-001a)

  **Capability:** `forge-init` (modification — the distributed plugin's navigation)
  **Requirements:** ADR-008 (capabilities are user-facing features)
  **Spec:** Tier 1 CLAUDE.md Content (deployables/capabilities explanation)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/AGENTS.md` — defines what a capability is; explains the naming principle (feature name, not layer name); lists current capabilities with one-line descriptions; explains how to create a new capability; includes the counter-examples (what not to name a capability)
  - `plugins/forge/skills/AGENTS.md` — same principle applied to the distributed skills directory, for agents working in the plugin source

  **Verification:** both files explain the naming principle in plain language; both include at least two counter-examples of incorrect capability names; an agent reading either file would correctly name a new capability as a feature rather than a layer.

---

## Wave 2 — Capability Documentation (parallel; depends on Wave 1)

Each task in this wave writes the complete requirements, spec, and success criteria for
one capability. Implementation tasks in Waves 3–6 build against these docs. Writing
documentation before implementation is the same spec-driven approach this effort designs.

- [x] [auto][wave:2] Write `forge-effort` capability documentation. This capability delivers: creating and scaffolding efforts (`forge:effort`), reading effort state (`forge:status`), session handoff (`forge:pause`, `forge:resume`), automatic state management (`update-workflow-state.sh`), phase-aware write context (`phase-context.sh`), session-start workflow context (`inject-workflow-context.sh`), and conversational intent routing (`route-to-skills.sh`). The CLAUDE.md template (TASK-003) is also part of this capability. (TASK-004)

  **Capability:** `forge-effort`
  **Requirements:** BR-1, BR-2, BR-4, BR-5, BR-8, BR-9, BR-11, TR-0, TR-1, TR-2, TR-7a, TR-8, TR-9, TR-11, TR-13, TR-15
  **Spec:** Layer 2 Hooks (all four), Workflow Skills (forge:effort, forge:status, forge:pause, forge:resume), Effort Type Classification

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/spec/hooks.md` — design for all four hooks: trigger, inputs, outputs, exit codes, edge cases, performance limits
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/spec/skills.md` — design for forge:effort, forge:status, forge:pause, forge:resume: arguments, preconditions, numbered steps, outputs, deviation rules, `[orchestrator-only]` markers
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/security/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/runbook/README.md`

  **Verification:** hooks spec includes exit-code table, performance limit, and edge cases for each hook (no active effort, multiple active efforts, offline); skills spec includes numbered steps for each skill; success criteria are measurable (e.g. "forge:effort creates `.state.json` with all required fields within 5 seconds").

---

- [x] [auto][wave:2] Write `forge-promote` capability documentation. This capability delivers the phase promotion ritual (`forge:promote`): checking artifact completeness per tier and phase, presenting a structured phase summary, requiring explicit engineer confirmation, and producing a checkpoint commit. (TASK-005)

  **Capability:** `forge-promote`
  **Requirements:** BR-3, TR-8, TR-11a (discovery→planning requires validation report), ADR-002, ADR-004
  **Spec:** Phase Promotion Skill (forge:promote)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/spec/skills.md` — numbered ritual steps, readiness check table (per transition × per tier), confirmation protocol, checkpoint commit format, handling of post-approval modifications
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-promote/security/README.md`

  **Verification:** spec includes the full readiness check table for all phase transitions (discovery→planning, planning→implementation, implementation→verification, verification→closed); spec explicitly states that FAIL validation result blocks discovery→planning; confirmation protocol defines what input is and is not accepted.

---

- [x] [auto][wave:2] Write `forge-adr` capability documentation. This capability delivers conversational ADR capture (`forge:adr`): detecting decision statements in conversation, sequentially numbering ADRs, writing to the correct effort directory, and updating state. (TASK-006)

  **Capability:** `forge-adr`
  **Requirements:** BR-9 (dual audience), TR-1 (adrsCreated in state)
  **Spec:** Workflow Skills (forge:adr)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/spec/skills.md` — ADR numbering algorithm, template sections (context, decision, alternatives, consequences), state update, conversational trigger patterns
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-adr/security/README.md`

  **Verification:** spec defines the numbering algorithm for gaps in the sequence (e.g. ADR-001 and ADR-003 exist — next is ADR-002 or ADR-004); template sections match the ADR format used in this effort's own ADRs; success criteria include both explicit invocation and conversational trigger.

---

- [x] [auto][wave:2] Write `forge-arch-review` capability documentation. This capability delivers design validation (`forge:arch-review`): checking all discovery artifacts against applicable standards, generating a machine-readable validation report (`validation/report.md`), and generating a self-contained multi-section HTML document for the architecture review meeting (`validation/arch-review.html`). (TASK-007)

  **Capability:** `forge-arch-review`
  **Requirements:** TR-11a, forge:promote readiness (non-FAIL required for discovery→planning)
  **Spec:** Architecture Review Skill (forge:arch-review)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/spec/skills.md` — standards checked per artifact type, per-rule severity definitions (FAIL/CONCERN/NOTE), overall result logic, requirements traceability check, `validation/report.md` structure, HTML section inventory (all 12), HTML technical constraints (self-contained, no external deps, anchor navigation)
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-arch-review/security/README.md`

  **Verification:** spec lists every standard checked and which artifact type triggers it; spec confirms security and privacy checks run on every effort regardless of artifact types; HTML section list matches the 12 sections in the forge-workflow spec; success criteria include an HTML rendering test (opens without server, no external requests).

---

- [x] [auto][wave:2] Write `forge-plan` capability documentation. This capability delivers implementation planning (`forge:plan`): reading discovery artifacts, analysing task dependencies, assigning type annotations and wave groupings, and generating `plan/tasks.md`. For coordination-repo efforts it also generates a deployable-scoped `plan/plan.md`. (TASK-008)

  **Capability:** `forge-plan`
  **Requirements:** TR-7 (coordination plan), TR-7a (task annotations), ADR-005 (annotation format)
  **Spec:** Workflow Skills (forge:plan), Implementation Task Execution Loop (annotation format section)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/spec/skills.md` — dependency analysis algorithm, type assignment heuristics (what makes a task `[checkpoint]` vs `[auto]`), wave grouping algorithm, coordination plan structure (deployable-scoped sections with acceptance criteria and cross-deployable dependencies)
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-plan/security/README.md`

  **Verification:** type assignment heuristics are unambiguous (a given task description produces a deterministic type); wave algorithm guarantees no wave N+1 task precedes a wave N dependency; coordination plan section structure matches TR-7.

---

- [x] [auto][wave:2] Write `forge-verify` capability documentation. This capability delivers two things: (1) `forge:verify` — a one-pass semantic check that the complete implementation delivers the effort's stated goals; and (2) the quality loop contract — the shared SKILL.md that all `forge:build-*` skills extend, defining the per-task implement → lint → validate → test → address loop. (TASK-009)

  **Capability:** `forge-verify`
  **Requirements:** BR-13, TR-10a (quality loop), ADR-007 (loop at task execution not verification)
  **Spec:** Workflow Skills (forge:verify), Implementation Task Execution Loop

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/spec/skills.md` — forge:verify: one-pass analysis approach, inputs (all discovery artifacts + implementation code), report structure, PASS/FAIL semantics, `[orchestrator-only]` sections; quality loop contract: loop steps, default iteration limit (3), linter detection table (language → project config file → CLI command) for all supported languages, TDD protocol, escalation format in `.state.json`
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-verify/security/README.md`

  **Verification:** spec distinguishes forge:verify (one-pass, whole-effort) from the quality loop (iterating, per-task) without ambiguity; linter table covers Go, Java, TypeScript, Kotlin, Swift, Python; iteration limit is stated as a configurable default; escalation format matches the `.state.json` schema from TASK-002.

---

- [x] [auto][wave:2] Write `forge-graduate` capability documentation. This capability delivers effort graduation (`forge:graduate`): merging effort artifacts into deployable canonical documentation, preserving provenance, reconciling post-approval modifications, updating state, and removing the effort from the active registry. (TASK-010)

  **Capability:** `forge-graduate`
  **Requirements:** BR-7, BR-12, TR-12, ADR-002 (rigor at graduation)
  **Spec:** Graduation Skill (forge:graduate)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/spec/skills.md` — inputs, merge algorithm ("update sections, not append" with example), provenance recording, post-approval modification reconciliation, graduation commit structure, registry removal, `[orchestrator-only]` sections
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-graduate/security/README.md`

  **Verification:** spec defines "merge, not append" with a concrete before/after example; specifies how provenance (effort ID) is recorded; specifies the graduation commit message format; success criteria include: deployable docs updated, effort removed from registry, `graduated: true` in state.

---

- [x] [auto][wave:2] Write `forge-cross-repo` capability documentation. This capability delivers three cross-repository skills: `forge:project` (materialise coordination projections into a local sub-effort), `forge:sync` (detect and update stale projections), and `forge:upstream` (surface local discoveries as proposed changes to the coordination effort). (TASK-011)

  **Capability:** `forge-cross-repo`
  **Requirements:** BR-10, TR-4, TR-5, TR-6, TR-14, ADR-003
  **Spec:** Cross-Repository Information Flow (all sections)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/requirements/business.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/requirements/technical.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/requirements/success-criteria.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/spec/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/spec/skills.md` — forge:project: GitHub API fetch, scoping algorithm, provenance header format (all five fields), offline failure behaviour; forge:sync: SHA comparison logic, stale/current/unreachable states, re-materialisation flow; forge:upstream: proposal document structure, `.state.json` `upstreamProposals` schema, `gh pr create` integration
  - `.forge/deployables/forge-cross-repo/spec/arch-decisions/` — cross-repo specific decisions if warranted
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/test/README.md`
  - `.forge/deployables/forge-plugin/capabilities/forge-cross-repo/security/README.md`

  **Verification:** provenance header format specifies all five required fields; SHA comparison logic explicitly handles the offline/unreachable case; success criteria cover both online and offline scenarios for forge:project and forge:sync.

---

## Wave 3 — forge-effort Implementation (parallel; depends on Wave 2)

All tasks in this wave implement the `forge-effort` capability against the docs from TASK-004.

- [x] [auto][wave:3] Implement `update-workflow-state.sh` PostToolUse hook per `forge-effort` capability spec (TASK-012)

  **Capability:** `forge-effort`
  **Requirements:** TR-1, TR-2, TR-9
  **Spec:** Hook 5 (update-workflow-state.sh)

  **Produces:** `plugins/forge/hooks/post-tool-use/update-workflow-state.sh`

  **Verification:** write `spec/api/test.yaml` to a test effort in discovery (typical write) — verify `.state.json` shows `spec.api: "present"`, no `postApprovalModifications` entry. Write `requirements/business.md` while effort is in implementation phase (atypical) — verify `postApprovalModifications` gains an entry with file, phase, and timestamp. Write a source code file — verify hook exits 0 with no state change.

---

- [x] [auto][wave:3] Implement `phase-context.sh` PreToolUse hook per `forge-effort` capability spec (TASK-013)

  **Capability:** `forge-effort`
  **Requirements:** TR-8, ADR-002
  **Spec:** Hook 3 (phase-context.sh)

  **Produces:** `plugins/forge/hooks/pre-tool-use/phase-context.sh`

  **Verification:** with discovery approved and effort in implementation, write to `requirements/business.md` — verify hook exits 0 with an informational message mentioning post-approval tracking. Write to a source file — verify hook exits 0 with no output. Confirm hook never exits 2 for any `.forge/efforts/` write.

---

- [x] [auto][wave:3] Implement `inject-workflow-context.sh` SessionStart hook per `forge-effort` capability spec (TASK-014)

  **Capability:** `forge-effort`
  **Requirements:** BR-4, TR-11, TR-14
  **Spec:** Hook 1 (inject-workflow-context.sh), Tier 2 SessionStart Hook Output

  **Produces:** `plugins/forge/hooks/session-start/inject-workflow-context.sh`

  **Verification:** repo with one implementation-phase effort, one paused task, one open decision — start session — verify output contains current phase, wave progress, pause state as top item, and open decision. Repo with no active efforts — verify "no active efforts" message. Hook completes in under 2 seconds with no network access.

---

- [x] [auto][wave:3] Implement `route-to-skills.sh` UserPromptSubmit hook per `forge-effort` capability spec (TASK-015)

  **Capability:** `forge-effort`
  **Requirements:** TR-15, Tier 3 hook specification
  **Spec:** Hook 2 (route-to-skills.sh)

  **Produces:** `plugins/forge/hooks/user-prompt-submit/route-to-skills.sh`

  **Verification:** prompt `/forge:plan` — verify planning routing context injected. Prompt "let's close this effort out" — verify graduation checklist injected. Prompt "the API looks good" — verify hook emits nothing (low-confidence; handled by CLAUDE.md).

---

- [x] [auto][wave:3] Implement `forge:effort` skill per `forge-effort` capability spec (TASK-016)

  **Capability:** `forge-effort`
  **Requirements:** TR-0, TR-1, TR-2
  **Spec:** Workflow Skills (forge:effort), Effort Type Classification

  **Produces:**
  - `plugins/forge/skills/workflow/effort/SKILL.md`
  - `plugins/forge/skills/workflow/effort/README.md`

  **Verification:** run in a clean repo — verify `.forge/efforts/<id>/` exists with tier-appropriate subdirectories; `.state.json` has all required fields from TASK-002 template including `subtype` and `productionBound`; registry row added. Child effort — verify parent `childIds` updated. PoC effort — verify `productionBound: false`.

---

- [x] [auto][wave:3] Implement `forge:status` skill per `forge-effort` capability spec (TASK-017)

  **Capability:** `forge-effort`
  **Requirements:** BR-1, BR-4
  **Spec:** Workflow Skills (forge:status)

  **Produces:**
  - `plugins/forge/skills/workflow/status/SKILL.md`
  - `plugins/forge/skills/workflow/status/README.md`

  **Verification:** run against an effort with 3 of 11 tasks complete across 2 waves — verify output includes wave-by-wave completion counts, current phase, open decisions, and a "next action" statement. Effort with a pending upstream proposal — verify proposal appears in output.

---

- [x] [auto][wave:3] Implement `forge:pause` and `forge:resume` skills per `forge-effort` capability spec (TASK-018)

  **Capability:** `forge-effort`
  **Requirements:** BR-5, TR-1 (pause state)
  **Spec:** Workflow Skills (forge:pause, forge:resume)

  **Produces:**
  - `plugins/forge/skills/workflow/pause/SKILL.md`
  - `plugins/forge/skills/workflow/pause/README.md`
  - `plugins/forge/skills/workflow/resume/SKILL.md`
  - `plugins/forge/skills/workflow/resume/README.md`

  **Verification:** run forge:pause mid-task — verify `.state.json` `pause` contains `currentTask`, `contextSummary`, `openDecisions`, `nextAction`. Start new session — verify SessionStart hook surfaces pause state at top. Run forge:resume — verify context presented and `pause.active` becomes false.

---

## Wave 4 — Remaining Skills (parallel; depends on Wave 3)

- [x] [checkpoint][wave:4] Implement `forge:promote` skill per `forge-promote` capability spec (TASK-019)

  **Capability:** `forge-promote`
  **Requirements:** BR-3, ADR-004
  **Spec:** Phase Promotion Skill (forge:promote)

  **Checkpoint:** review the phase summary wording and confirmation prompt with the team — this is the primary human-facing interaction in the workflow.

  **Produces:**
  - `plugins/forge/skills/workflow/promote/SKILL.md`
  - `plugins/forge/skills/workflow/promote/README.md`

  **Verification:** missing discovery artifact — stops and lists gap. FAIL in `validation/report.md` — blocks. Complete artifacts, PASS WITH CONCERNS, confirm affirmatively — checkpoint commit exists with correct `.state.json` fields. Ambiguous input ("maybe") — does not advance.

---

- [x] [auto][wave:4] Implement `forge:adr` skill per `forge-adr` capability spec (TASK-020)

  **Capability:** `forge-adr`
  **Requirements:** BR-9, TR-1 (adrsCreated)
  **Spec:** Workflow Skills (forge:adr)

  **Produces:**
  - `plugins/forge/skills/workflow/adr/SKILL.md`
  - `plugins/forge/skills/workflow/adr/README.md`

  **Verification:** repo with ADR-001 — run forge:adr — verify ADR-002 created with correct numbering and all four template sections; `.state.json` `adrsCreated` updated. Trigger conversationally ("let's use PostgreSQL because of transactions") — verify ADR created capturing the stated decision and rationale.

---

- [x] [auto][wave:4] Implement `forge:plan` skill per `forge-plan` capability spec (TASK-021)

  **Capability:** `forge-plan`
  **Requirements:** TR-7, TR-7a, ADR-005
  **Spec:** Workflow Skills (forge:plan)

  **Produces:**
  - `plugins/forge/skills/planning/plan/SKILL.md`
  - `plugins/forge/skills/planning/plan/README.md`

  **Verification:** run against the favorite-stores effort from the user flow — verify every task has a type annotation and a wave annotation; TASK-003 is `[tdd][wave:2]`, TASK-009 is `[checkpoint][wave:4]`; no wave N+1 task precedes a wave N dependency. Run against a coordination-repo effort — verify `plan/plan.md` has deployable-scoped sections.

---

- [x] [auto][wave:4] Implement `forge:arch-review` skill per `forge-arch-review` capability spec (TASK-022)

  **Capability:** `forge-arch-review`
  **Requirements:** TR-11a
  **Spec:** Architecture Review Skill (forge:arch-review)

  **Produces:**
  - `plugins/forge/skills/discovery/arch-review/SKILL.md`
  - `plugins/forge/skills/discovery/arch-review/README.md`

  **Verification:** effort with a known REST violation (missing `code` field in 409 body) — verify `validation/report.md` shows FAIL for that specific rule; overall result FAIL. Clean effort — verify PASS. `arch-review.html` is valid HTML, self-contained (no external URLs), opens without a server, contains all 12 sections with working navigation. Uncovered BR — verify traceability section flags it.

---

- [x] [auto][wave:4] Implement `forge:project` skill per `forge-cross-repo` capability spec (TASK-023)

  **Capability:** `forge-cross-repo`
  **Requirements:** TR-4, TR-5, ADR-003
  **Spec:** Downward Propagation section

  **Produces:**
  - `plugins/forge/skills/cross-repo/project/SKILL.md`
  - `plugins/forge/skills/cross-repo/project/README.md`

  **Verification:** run against a test coordination repo — projected files exist locally with all five provenance header fields; `.state.json` `coordinationRef` populated with source SHA; local sub-effort in registry. Coordination repo unreachable — skill fails with a clear, actionable error.

---

- [x] [auto][wave:4] Implement `forge:sync` skill per `forge-cross-repo` capability spec (TASK-024)

  **Capability:** `forge-cross-repo`
  **Requirements:** TR-14
  **Spec:** Staleness Detection section

  **Produces:**
  - `plugins/forge/skills/cross-repo/sync/SKILL.md`
  - `plugins/forge/skills/cross-repo/sync/README.md`

  **Verification:** after TASK-023, update the source file in the coordination repo — forge:sync reports the projection as stale with the correct SHA delta. Re-materialise — provenance header shows updated SHA. Coordination repo unreachable — reports "unreachable" without error exit.

---

- [x] [auto][wave:4] Implement `forge:upstream` skill per `forge-cross-repo` capability spec (TASK-025)

  **Capability:** `forge-cross-repo`
  **Requirements:** TR-6
  **Spec:** Upward Propagation section

  **Produces:**
  - `plugins/forge/skills/cross-repo/upstream/SKILL.md`
  - `plugins/forge/skills/cross-repo/upstream/README.md`

  **Verification:** run with a change description — proposal document written with title, affected file, change description, rationale; `.state.json` `upstreamProposals` gains entry with `status: "proposed"` and `prUrl: null`. Run with `--pr` flag — `gh pr create` called and PR URL recorded.

---

## Wave 5 — Verification and Quality Loop (parallel; depends on Wave 4)

- [x] [auto][wave:5] Implement `forge:verify` skill per `forge-verify` capability spec (TASK-026)

  **Capability:** `forge-verify`
  **Requirements:** BR-13, ADR-007
  **Spec:** Workflow Skills (forge:verify)

  **Produces:**
  - `plugins/forge/skills/implementation/verify/SKILL.md`
  - `plugins/forge/skills/implementation/verify/README.md`

  **Verification:** effort where one BR has no implementation — report flags it with specific code location. Fully implemented effort — PASS with no gaps. Skill runs correctly as an isolated sub-agent with `[orchestrator-only]` sections properly marked and skipped.

---

- [x] [checkpoint][wave:5] Write the quality loop shared contract per `forge-verify` capability spec; this SKILL.md is extended by all `forge:build-*` implementation skills (TASK-027)

  **Capability:** `forge-verify`
  **Requirements:** TR-10a, ADR-007
  **Spec:** Implementation Task Execution Loop

  **Checkpoint:** review linter detection table and iteration limit with the pilot team before locking — all downstream implementation skills depend on this contract.

  **Produces:**
  - `plugins/forge/skills/implementation/build-contract/SKILL.md`
  - `plugins/forge/skills/implementation/build-contract/README.md`

  **Verification:** linter detection table covers Go, Java, TypeScript, Kotlin, Swift, Python; iteration limit stated as configurable default of 3; TDD discipline section is unambiguous about RED→GREEN→REFACTOR; escalation format matches the `.state.json` schema from TASK-002.

---

## Wave 6 — Graduation (depends on Wave 5)

- [x] [auto][wave:6] Implement `forge:graduate` skill per `forge-graduate` capability spec (TASK-028)

  **Capability:** `forge-graduate`
  **Requirements:** BR-7, BR-12, TR-12
  **Spec:** Graduation Skill (forge:graduate)

  **Produces:**
  - `plugins/forge/skills/workflow/graduate/SKILL.md`
  - `plugins/forge/skills/workflow/graduate/README.md`

  **Verification:** run against the complete favorite-stores effort — `deployables/rewards-backend/requirements/` updated (not appended) with favorites content; `deployables/rewards-backend/spec/` contains API spec and storage schema; ADR-001 registered in deployable ADR index with effort ID as provenance; `.state.json` shows `graduated: true` with timestamp; effort row removed from `.forge/efforts/README.md`. Post-approval modification present — graduation report flags it. Runs correctly as isolated sub-agent.

---

## Wave 7 — Integration Testing (depends on Waves 1–6)

- [x] [tdd][wave:7] End-to-end test: full-tier single-repo effort through the complete lifecycle — creation, discovery, arch-review (one addressable FAIL), promote to planning, planning with annotated tasks, promote to implementation, task execution with quality loop (one iteration requiring a lint fix), forge:verify (PASS), PR review, QA, graduation. No explicit forge commands — only conversational prompts. (TASK-029)

  **Capability:** `forge-effort` test directory (integration suite)
  **Requirements:** BR-11 (no explicit commands required), all BRs and TRs in sequence
  **Spec:** spec/user-flow.md

  **Produces:** `plugins/forge/test/integration/full-tier-lifecycle/`

  **Verification:** every phase produces correct artifacts in the correct locations per the routing table; every phase transition uses the promote ritual; graduation produces correct deployable documentation; zero explicit forge commands in the test prompts.

---

- [x] [tdd][wave:7] End-to-end test: lightweight tier — patch effort (no discovery, implement → CI review → close), extension effort (optional requirements, implement → CI review → close), PoC effort (reduced compliance, non-production merge). (TASK-030)

  **Capability:** `forge-effort` test directory
  **Requirements:** TR-0, ADR-006
  **Spec:** Effort Type Classification

  **Produces:** `plugins/forge/test/integration/lightweight-tier/`

  **Verification:** patch effort completes without `requirements/` or `spec/` directories; PoC with intentional security violation passes CI review (non-blocking); attempting to merge PoC code to a production-tracked branch raises a clear warning.

---

- [x] [tdd][wave:7] End-to-end test: cross-repo effort — coordination effort with two local sub-efforts, forge:project materialises projections, local discovery reveals a coordination gap, forge:upstream creates proposal, coordination effort updated, forge:sync re-materialises stale projection, both local efforts graduate. (TASK-031)

  **Capability:** `forge-cross-repo` test directory
  **Requirements:** BR-10, TR-4–6, TR-14, ADR-003
  **Spec:** Cross-Repository Information Flow (all sections)

  **Produces:** `plugins/forge/test/integration/cross-repo/`

  **Verification:** projections have correct provenance headers; upstream proposal identifies the specific coordination artifact; after coordination update and forge:sync, local projection shows updated SHA; both graduation operations produce correct canonical documentation.

---

## Parallelism Guide

| Worktree | Wave 2 | Wave 3 | Wave 4 | Wave 5 | Wave 6 | Wave 7 |
|----------|--------|--------|--------|--------|--------|--------|
| A | TASK-004 | TASK-012 | TASK-019 ⚑ | TASK-026 | TASK-028 | TASK-029 |
| B | TASK-005 | TASK-013 | TASK-020 | TASK-027 ⚑ | — | TASK-030 |
| C | TASK-006 | TASK-014 | TASK-021 | — | — | TASK-031 |
| D | TASK-007 | TASK-015 | TASK-022 | — | — | — |
| E | TASK-008 | TASK-016 | TASK-023 | — | — | — |
| F | TASK-009 | TASK-017 | TASK-024 | — | — | — |
| G | TASK-010 | TASK-018 | TASK-025 | — | — | — |
| H | TASK-011 | — | — | — | — | — |

Wave 1 (TASK-001, TASK-002, TASK-003) runs on worktrees A, B, C.
⚑ = checkpoint task. Work on other worktrees in the same wave can proceed, but no
Wave N+1 task in the checkpoint's dependency chain begins until the checkpoint is
reviewed and confirmed.
