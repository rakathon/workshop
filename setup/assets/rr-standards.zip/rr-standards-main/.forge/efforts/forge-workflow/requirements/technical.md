# Technical Requirements

## Foundational Constraint: Git as the Artifact Store

All workflow artifacts — requirements, specifications, plans, state files, validation
reports, and any future artifact types — are plain files stored in git repositories.
There is no external database, no service, and no runtime dependency for artifact
storage. Git is the storage layer, git history is the audit trail, and git branches
are the isolation mechanism.

This constraint has consequences that shape every technical requirement below:

- **State changes are commits.** A phase transition, an artifact creation, a plan update —
  each is a commit. There is no out-of-band state. The repository at any commit hash is
  a complete, self-consistent snapshot of the workflow state at that point in time.

- **Visibility is branch-scoped.** An artifact on a feature branch is invisible to agents
  and engineers working on another branch or on main until it is merged. This determines
  where effort artifacts must live.

- **Cross-repository access is not free.** Reading an artifact from another repository
  requires an explicit operation — a fetch, a clone, an API call. There is no shared
  filesystem. Cross-repo information flow must be designed, not assumed.

- **Concurrency is merge-based.** Two engineers updating the same file on different
  branches will encounter a merge conflict. State files that are frequently updated by
  multiple actors must be designed to minimize conflict surface.

---

## TR-0: Every Effort Must Declare a Subtype and Production-Bound Status at Creation

Every effort must be classified at creation with a subtype that determines which phases
are required and whether CI review is mandatory. The subtype is recorded in `.state.json`
and must not be changed after the effort's first commit.

**Production-bound subtypes** (all require `forge:review` as a blocking CI status check):

| Subtype | Discovery required | Arch review required | Planning required | QA required |
|---------|-------------------|---------------------|-------------------|-------------|
| `patch` | No | No | No | No |
| `refactor` | No | No | Optional | No |
| `extension` | Optional | No | Optional | Risk-dependent |

Full-tier work items (epic, initiative, program) always require discovery, arch review,
planning, and QA per their risk classification. They are not subtypes of lightweight —
they are a separate tier.

**Non-production-bound subtype:**

| Subtype | Discovery | Arch review | Planning | CI review | QA |
|---------|-----------|-------------|----------|-----------|-----|
| `poc` | No | No | No | Optional, non-blocking | No |

`productionBound: false` must be set in `.state.json` for all `poc` subtype efforts.
This flag drives two behaviors:
1. `forge:review` is not registered as a required PR status check for this effort
2. Security and privacy validation failures are non-blocking

The `productionBound` flag must never be changed from `false` to `true` on an existing
effort. If a PoC is to be productionized, a new production-tier effort must be created.
The PoC's `.state.json` records the spawned effort under `spawnedWorkItems`.

## TR-1: Effort State Must Be Stored as a Machine-Readable File in the Effort Directory

Each effort must have a `.state.json` file in its effort directory that tracks:

- Identity: work item ID, title, type, tier, risk classification
- Hierarchy: parent ID, child IDs, associated deployables
- Current phase and phase status
- Per-phase artifact inventory (which artifacts exist, which are absent)
- Open decisions and unresolved questions
- Pause state (if interrupted): current task, active context summary, next action
- Cross-repo references: coordination effort ID and repository (for local sub-efforts)
- ADRs created by this effort

State transitions must be committed atomically with the artifact that triggered them.
Creating a requirements file and updating `.state.json` to reflect its presence must be
a single commit. An artifact that exists on disk but is not reflected in state — or a
state that claims an artifact exists when it does not — is a consistency violation.

## TR-2: The Master Registry Must Be a Single File That Reflects All Active Efforts

The `.forge/efforts/README.md` file must present every in-flight effort in the repository in a
single table. It must show: ID, title, type, tier, risk, current phase, and status. The
hierarchy must be visible through indentation (child efforts beneath their parent).

The registry must be updated whenever an effort is created, advances phase, or closes.
Closed efforts are removed from the registry but remain permanently in `.forge/efforts/`.
The registry is the active-work view, not a historical ledger.

Because the registry is a single file updated by many operations, it is a merge conflict
hotspot. The file format must be line-oriented so that additions and removals to different
rows merge cleanly. Each effort must occupy exactly one line in the table.

## TR-3: Git Branching Strategy for Effort Artifacts — Deferred

The question of where effort artifacts live in the git graph (default branch vs feature
branches, short-lived doc branches, PR requirements for `.forge/` changes) has
significant implications for CI/CD, team conventions, and PR policies. These
dependencies extend well beyond the forge-workflow effort.

Branching strategy for effort artifacts is deferred to a dedicated effort. That effort
will determine the conventions and constraints that forge-workflow hooks and skills must
respect, and this requirement will be updated to reflect those decisions.

**Dependency:** Hooks and skills in this spec that commit effort artifacts must be
designed to be branching-strategy-agnostic where possible — committing to the working
tree and leaving the push/PR behavior to the branching strategy effort's conventions.

## TR-4: Cross-Repository References Must Use an Explicit, Resolvable Format

When a local sub-effort references an artifact from a coordination repository, the
reference must include sufficient information to locate and retrieve the artifact
without human interpretation:

- Repository identifier (organization/repo name or URL)
- File path within the repository
- Git ref (branch name or commit SHA) at which the reference was established

References must be stored in the local effort's `.state.json` under a dedicated field
(e.g., `coordinationRef`) so that tooling can resolve them programmatically. The format
must be consistent across all cross-repo references, not ad hoc per-artifact.

A reference to a commit SHA is immutable — it points to a specific version of the
artifact. A reference to a branch name is mutable — it always resolves to the latest
version on that branch. Both forms are valid. The choice determines whether the local
effort sees coordination-level changes automatically or only when explicitly updated.

## TR-5: Downward Propagation Must Produce Local Artifacts, Not Symlinks or Live References

When a coordination effort spawns a local sub-effort in a deployable repository, the
relevant cross-cutting artifacts must be materialized as files in the local effort
directory. They must not be symlinks, submodule references, or live fetches that require
network access to resolve.

The materialized artifacts are a scoped projection: the subset of the coordination-level
artifacts that are relevant to this deployable. The projection must be a coherent,
self-contained artifact that engineers can read and work from without accessing the
coordination repository.

Each materialized projection must include a header or metadata block that records:
- The coordination repository and effort ID it was projected from
- The commit SHA at which the projection was taken
- The date of the projection

This metadata enables tooling to detect when the coordination-level artifact has changed
since the projection was taken and to surface the divergence for review.

## TR-6: Upward Propagation Must Surface Divergence, Not Silently Overwrite

When local discovery or implementation reveals that a coordination-level artifact needs
to change — a missing requirement, an incorrect flow, a new contract — the change must
be surfaced to the coordination repository as a proposed update, not applied silently.

In git terms, this means the change to the coordination artifact is a pull request to
the coordination repository. The local effort must record that an upstream change has
been proposed and track its resolution status in `.state.json`. Local work may proceed
with the proposed change reflected in the local projection (optimistically), but the
local effort's state must indicate that an unresolved upstream change exists until the
coordination-level PR is merged.

Whether the framework automates PR creation or produces a structured change proposal
that an engineer submits manually is an implementation decision. The requirement is that
the mechanism exists, that the change is traceable, and that the local effort does not
silently diverge from the coordination truth.

## TR-7: The Coordination Plan Must Be Expressible as Deployable-Scoped Sections

The coordination-level plan must be structured so that each deployable's responsibilities
are identifiable as a discrete section or set of entries. This structure is what makes
projection to local sub-efforts possible.

Each entry in the coordination plan must specify:
- The requirement or acceptance criterion it addresses
- Which deployable (or deployables) are responsible
- Dependencies on other entries (including cross-deployable dependencies)
- Verification criteria (how completion will be assessed)

The coordination plan does not specify implementation tasks — those are generated during
local planning. It specifies what must be true when the work is done, scoped per
deployable, with cross-deployable dependencies made explicit.

When a local sub-effort is created, the entries from the coordination plan that are
relevant to this deployable must be materialized into the local effort as the seed for
local planning. The local planning process then elaborates these entries into technical
requirements, technical specifications, test plans, and implementation tasks.

## TR-7a: The Local Implementation Plan Must Use Typed, Wave-Annotated Task Format

The local `plan/tasks.md` is a machine-readable artifact, not just a human checklist.
Every task entry must carry two annotations that allow skills and hooks to execute and
track tasks correctly without requiring the agent to infer intent from task descriptions.

**Task type** — governs how an executing agent approaches the task:

| Annotation | Meaning |
|------------|---------|
| `[auto]` | Agent proceeds autonomously; no pause required |
| `[checkpoint]` | Agent pauses before or after for human decision or confirmation |
| `[tdd]` | Agent follows RED → GREEN → REFACTOR discipline; tests must be written and failing before implementation begins |
| `[manual]` | Human action required; agent cannot execute this task |

**Wave number** — governs execution ordering and parallelism:

| Annotation | Meaning |
|------------|---------|
| `[wave:N]` | Dependency group. All tasks in wave N must complete before wave N+1 begins. Tasks within the same wave have no dependency on each other and may be executed in parallel. |

**Required format:**

```
- [ ] [auto][wave:1] Description of task (TASK-NNN)
- [ ] [tdd][wave:2] Description of task (TASK-NNN)
- [ ] [checkpoint][wave:2] Description — note why human input is needed (TASK-NNN)
- [x] [auto][wave:1] Completed task description (TASK-NNN) (a3f9b12)
```

Completed tasks must record the first 7 characters of the commit SHA that satisfied them,
inline after the task description. This is the traceability link from plan to code.

`forge:plan` must assign type and wave annotations to every task it generates. Type is
derived from the nature of the task (design decisions warrant `[checkpoint]`, test-first
work warrants `[tdd]`, automated scaffolding warrants `[auto]`). Wave is derived from
dependency analysis — tasks that depend on prior tasks must be in a later wave; tasks
with no dependencies on pending work may share a wave.

## TR-8: Phase Context Hooks Must Read State from the Working Tree and Inform, Not Block

Phase context is provided by PreToolUse hooks that fire before Write and Edit operations.
These hooks must determine the current phase and status of the relevant effort by reading
`.state.json` from the working tree (not from a cached or in-memory copy).

The hook must:
- Identify which effort the target file belongs to (based on file path)
- Read that effort's `.state.json`
- Determine whether the write is typical for the current phase or atypical (e.g.,
  modifying a requirements file while the effort is in the implementation phase)
- For typical writes: allow silently (exit code 0, no output)
- For atypical writes: allow but emit context to the agent (exit code 0 with
  informational output) explaining the current phase, that this artifact was produced
  in a prior phase, and that the modification will be tracked as a post-approval change

The hook must never block a write to an effort artifact (exit code 2). Development is
not waterfall. The hook's role is awareness — ensuring the agent knows what phase it is
in and that it is modifying a previously approved artifact — not enforcement.

If the target file does not belong to any known effort (e.g., it is a source code file,
not a workflow artifact), the hook must allow the write without interference.

## TR-9: Post-Approval Modifications Must Be Tracked in State

When an artifact that was produced during an approved phase is subsequently modified,
the modification must be recorded in `.state.json`. The state must track:

- Which artifact was modified (file path)
- Which phase the effort was in when the modification occurred
- The commit SHA of the modification

This record serves two purposes:
- **Visibility during review:** Reviewers can see which approved artifacts were modified
  during implementation and assess whether the modifications are consistent with the
  overall design intent.
- **Reconciliation during graduation:** When the effort's artifacts are promoted to
  canonical documentation (TR-12), all post-approval modifications must be reviewed as
  part of the graduation process. The graduated artifact must represent the final,
  coherent state — not the originally approved state with unreviewed patches on top.

No formal reopen process is required to modify an approved artifact. The modification
is permitted, recorded, and reconciled at graduation. The rigor is at the promotion
boundary, not at the moment of edit.

## TR-10: Forge Guidance Must Be Split Across Three Tiers to Preserve Context Budget

The root `CLAUDE.md` is loaded into Claude's context for the entire session. Every line
it contains consumes context that would otherwise be available for code, conversation,
and project-specific instructions. The Forge guidance layer must be designed to minimize
permanent context cost while ensuring Claude always has what it needs when it needs it.

Forge guidance is split across three tiers:

**Tier 1 — CLAUDE.md (~60-80 lines, always present):**
The forge-managed section of the root `CLAUDE.md` contains only what Claude needs to
understand the framework and decide when to engage with it:
- What Forge is and what `.forge/` is for (2-3 sentences)
- The three subdirectory roles: `efforts/` (work-in-progress artifacts), `deployables/`
  (canonical product specs), `products/` (PM-facing capability documentation)
- What an effort is and when workflow artifacts are produced
- Terse intent recognition: a compact list of conversational event types and the
  corresponding action (one line each, no examples)
- The before-write rule: read `.forge/efforts/README.md` and the effort's `.state.json` before
  writing any `.forge/` file

This tier gives Claude the conceptual model. It does not contain routing tables or
verbose pattern descriptions — those would bloat the permanent context without adding
proportional value.

**Tier 2 — SessionStart hook output (injected at session start, ~50-80 lines):**
The `inject-workflow-context.sh` hook reads current state and emits:
- The artifact routing table: every artifact type mapped to its canonical path
- Active effort state: current phase, artifacts present/absent, open decisions, next action
- Pending upstream change proposals and staleness warnings
- Active effort identification rules

This content is fresh at the start of every session. It is more detailed than Tier 1
because it does not permanently consume context — it arrives at session start and may
scroll back as the session grows. For a fresh session focused on workflow work, it will
be available. For a long-running session, Tier 1 provides enough grounding for Claude
to re-derive context from the state files if needed.

**Tier 3 — UserPromptSubmit hook (re-injected on workflow events, ~20-30 lines):**
When the hook detects a workflow-relevant prompt, it re-injects the routing rules and
current state. This compensates for long sessions where Tier 2 content may have
scrolled out. The injection is targeted — only the routing context relevant to the
detected event type, not the full Tier 2 output.

The CLAUDE.md section is forge-managed, bounded by markers, written by `forge:init`,
and updated by `forge:update`. Engineers may read it but should not edit the managed
section directly. It must be maintained as the workflow structure evolves.

## TR-11: Session Start Must Inject Current Workflow State into Agent Context

A SessionStart hook must fire at the beginning of every session and inject the current
workflow state into the agent's context. The injected context must include:

- Active efforts: ID, title, current phase, and status for each in-flight effort
- For the current effort (if determinable from branch or recent activity): full phase
  state, open decisions, pause state (if resuming), and the next required action
- Pending upstream changes: any unresolved coordination-level PRs that affect local work
- Staleness warnings: any projections from coordination artifacts that are behind the
  current coordination commit

This context must be derived from the git-stored state files (`.state.json` and
`.forge/efforts/README.md`), not from an external service. It must be current as of the latest
commit on the default branch.

## TR-10a: Task Implementation Must Execute a Quality Loop Before Marking a Task Complete

When an implementation skill executes a task, it must not mark the task complete based
on the code being written. It must run a quality loop and only mark the task complete
when all checks pass or when the iteration limit is reached and the state is escalated
to the engineer.

**The loop:**

```
while iteration < MAX_ITERATIONS:
  1. Implement (write or update source files)
  2. Run linters for the affected file types
  3. Validate the implementation against the task's acceptance criteria and
     the applicable spec artifacts (API contract, storage schema, etc.)
  4. Run the test suite (or the subset relevant to the changed files)
  5. If all checks pass: commit, mark task complete with SHA, exit loop
  6. If any check fails: address the failures, increment iteration, repeat
If MAX_ITERATIONS reached: escalate to engineer (see below)
```

**Linters:**
The skill must detect the language(s) of the changed files and run the configured
linter for each. Linter configuration lives in the project (eslint, golangci-lint,
ktlint, SwiftLint, etc.). If no linter is configured for a language, skip the lint
step for that language. Linter output must be read and acted upon — a passing lint
step is not assumed.

**Spec validation:**
The skill reads the task's acceptance criteria from `plan/tasks.md` and the relevant
spec artifacts (API contract if implementing an endpoint, storage schema if modifying
data access, etc.) and confirms the implementation addresses them. This is a focused
check on the current task, not the full effort goal — that is `forge:verify`'s scope.

**TDD tasks:**
Tasks annotated `[tdd]` have an additional constraint: tests must be written and
confirmed failing BEFORE implementation code is written. The loop for a TDD task
begins with writing the failing test, then proceeds through implementation until the
test passes.

**Tests:**
Run the test suite or the relevant subset. New tests written as part of the task must
pass. Existing tests must not regress. A task that breaks existing tests is not
complete.

**Iteration limit:**
Default maximum: 3 iterations. After 3 iterations of the loop without all checks
passing, the skill must stop and escalate. It must not continue indefinitely.

The escalation produces a structured pause state in `.state.json`:
- Which task is blocked
- Which checks are still failing (lint errors, spec gaps, test failures)
- What was attempted in each iteration
- The next action the engineer should take

The engineer reviews the remaining concerns, decides whether to adjust the
implementation approach, modify the spec, or accept a known limitation, and resumes.
The limit exists to bound cost and to prevent the skill from silently degrading in
quality over many iterations.

## TR-11a: Design Validation Must Produce a Machine-Readable Report and a Human-Navigable HTML Document

For full-tier efforts, discovery artifacts must be validated against all applicable
organizational standards before implementation begins. This validation must produce two
artifacts in `validation/`:

**`validation/report.md`** — The machine-readable validation record. Must contain:
- An overall result field with one of three values: PASS, PASS WITH CONCERNS, FAIL
- One section per standards domain checked (API, storage, messaging, security, privacy,
  and any others that apply to the effort's artifact types)
- Per-rule findings within each section, with severity: FAIL (MUST violation), CONCERN
  (SHOULD violation or high-risk pattern), or NOTE (informational)
- A requirements traceability section mapping every stated business and technical
  requirement to the design artifact(s) that address it; gaps (requirements with no
  design coverage) must be flagged
- A list of open design questions surfaced during analysis

FAIL result must block advancement from discovery to planning. PASS WITH CONCERNS
permits advancement with the concerns acknowledged. PASS advances without restriction.

**`validation/arch-review.html`** — A self-contained HTML document for architecture
review meetings. Must be:
- Self-contained: no external network dependencies (CSS inline, no CDN)
- Navigable without JavaScript (anchor-based navigation)
- Structured with a fixed navigation index linking to each section
- Detailed enough per section that engineers from security, DevOps, QA, and
  development teams can read their relevant section without needing external context
- Print-friendly: each section breaks naturally to a new page when printed

Required sections: overview, business requirements, technical requirements, architecture
decisions, API design (if applicable), data model (if applicable), messaging and events
(if applicable), security analysis, privacy analysis, standards compliance summary,
requirements traceability matrix, open decisions and risks.

Standards checked must include at minimum: all standards for which spec artifacts
exist in the effort (API → REST standards, storage → storage standards, messaging →
messaging standards), plus security and privacy checks on every effort regardless of
artifact types present.

Lightweight-tier efforts are exempt from the validation requirement. `forge:promote`
must check for the presence of `validation/report.md` and a non-FAIL result before
advancing a full-tier effort from discovery to planning.

## TR-12: Artifact Graduation Must Be a Distinct, Auditable Operation

When a local effort reaches completion, the promotion of its artifacts to the
deployable's canonical documentation must be a deliberate operation, not an automatic
side effect of closing the effort.

The graduation operation must:
- Read the completed effort's requirements, specifications, and design decisions
- Merge them into the appropriate sections of `.forge/deployables/<name>/`
- Preserve the effort ID as provenance metadata in the graduated artifacts
- Update the effort's `.state.json` to record that graduation has occurred
- Produce a commit (or series of commits) that is distinct from the effort close commit

Graduation to product documentation follows the same pattern but targets
`.forge/products/<name>/` and applies to the cross-cutting artifacts from the
coordination effort.

Graduation is not a copy. The canonical documentation must be a coherent, current
representation of the deployable or product — not an append-only log of effort
outputs. When an effort modifies existing capability, the graduation must update
the relevant sections, not add a new section alongside the old one.

## TR-13: Concurrent State Updates Must Be Designed for Merge-Friendly Resolution

`.state.json` and `.forge/efforts/README.md` are updated by multiple operations and potentially
by multiple engineers working concurrently. These files must be structured to minimize
merge conflicts:

**`.state.json`:**
- Each phase's state must be independently updatable. A commit that advances the
  discovery phase must not conflict with a commit that updates the planning phase.
- Array fields (childIds, artifacts) should use sorted, one-item-per-line formatting
  so that additions to different positions merge cleanly.
- The JSON must be formatted with consistent indentation and key ordering so that
  different tools producing the same logical state produce the same bytes.

**`.forge/efforts/README.md`:**
- Each effort must occupy exactly one line in the table (TR-2).
- Additions of new efforts and updates to existing efforts must be independent
  operations that do not require rewriting adjacent lines.

When a merge conflict does occur on a state file, the conflict must be resolvable by
taking the union of both changes (both phase transitions are valid) rather than
requiring a human to determine which change wins. The state model must be designed to
make this union merge correct by default.

## TR-14: Projections Must Include a Staleness Detection Mechanism

Each materialized projection of a coordination-level artifact must include the commit
SHA of the coordination artifact at the time of projection (TR-5). Tooling must be able
to compare this SHA against the current HEAD of the coordination repository to determine
whether the projection is stale.

Staleness detection must be available:
- At session start (TR-11): warn the agent if any projections are behind
- On demand: a skill or command that checks all projections and reports their status
- Before phase transitions: if a local effort is about to advance from discovery to
  planning, stale projections from the coordination effort should be flagged

Staleness is informational, not blocking by default. A stale projection may be
intentional (the local effort has progressed past the point where the coordination
change matters). However, the staleness must be visible so that engineers can make an
informed decision about whether to update the projection.

## TR-15: Forge Must Function Through Conversational Intent Without Requiring Explicit Commands

The primary interface to Forge is natural conversation with Claude Code. Forge must not
depend on engineers using specific skill names, slash commands, or command sequences to
function correctly. The CLAUDE.md routing layer (TR-10), session context (TR-11), and
hooks together must provide Claude with enough context to recognize workflow-relevant
intent in ordinary conversation and execute the appropriate actions automatically.

Engineers who choose to invoke Forge capabilities directly must be able to do so — the
explicit path must remain available and produce identical outcomes. But the conversational
path must work independently of it.

This requires three capabilities working together:

**Intent recognition via CLAUDE.md instructions:**
The CLAUDE.md must include pattern descriptions that map conversational statements to
workflow actions. These are not NLP rules — they are instructions to Claude that describe
what kinds of statements constitute workflow events:
- Statements of decision ("we'll use DynamoDB," "let's go with option B") → create or
  update an ADR
- Statements of completion ("the API work is done," "I've finished the auth changes") →
  update task/phase state, trigger verification checks
- Statements of scope ("we need to build favorites for mobile and web") → identify
  affected deployables, scaffold efforts or sub-efforts
- Statements of planning ("let's break this into tasks," "what do we need to do first")
  → generate or update the implementation plan
- Statements of concern ("I think the session storage approach won't scale") → capture
  as an open decision or risk, update state
- Requests for status ("where are we on this," "what's left") → read state and present
  current phase, artifacts, and next actions

**Automatic state management via PostToolUse hooks:**
When Claude writes or modifies a workflow artifact (requirements file, spec, ADR, plan),
a PostToolUse hook must detect the artifact type and update `.state.json` and the master
registry accordingly. The agent does not need to explicitly update state — state changes
are a side effect of artifact creation and modification.

**Conversational graduation and promotion:**
When an engineer says "this work is done" or "let's close this out," Claude must
recognize this as an effort completion event and initiate the graduation process:
reading the effort's artifacts, promoting them to the deployable's canonical docs,
updating state, and updating the registry. The engineer experiences this as a natural
conclusion to the conversation, not as a multi-step ceremony.

The explicit skill invocation path must remain available for power users and automation.
But the conversational path must be the default, and it must produce the same artifacts,
state transitions, and promotions as the explicit path. An engineer who never learns a
single Forge command must still get the full benefit of the workflow.

---

## Constraints

### Git-Specific Constraints

- All workflow operations must be expressible as sequences of git-native operations
  (read, write, commit, push, fetch). No operation may require a running service or
  database to function.
- Cross-repository operations must work over HTTPS using standard git hosting APIs
  (GitHub API). SSH-only or custom protocol dependencies are not acceptable for
  cross-repo tooling.
- Hooks and skills must not assume a specific branch is checked out. They must read
  state from the working tree and handle the possibility that the working tree is on
  any branch, including a detached HEAD.
- Commit messages for workflow state changes must follow conventional commit format and
  include the effort ID in the scope (e.g., `chore(forge-workflow): advance to planning`).
  This enables filtering git log by effort.
- The total size of workflow artifacts for a single effort should not make cloning or
  fetching the repository materially slower. Artifact files should target a maximum of
  500 lines. Binary artifacts (images, diagrams) should be avoided in favor of
  text-based formats where possible.

### Cross-Repository Constraints

- Cross-repo propagation must not require the engineer to have write access to the
  coordination repository at the time of local effort creation. Read access is
  sufficient for downward propagation; upward propagation (proposing changes) requires
  the ability to create a pull request, which may use a fork.
- Cross-repo references must degrade gracefully when the coordination repository is
  inaccessible (offline, permissions changed). The local effort must remain functional
  with its materialized projections even if it cannot reach the coordination repository.
- Cross-repo state aggregation (e.g., "is this coordination effort complete across all
  deployable repos?") is the coordination repository's responsibility. Local repos
  report their own status; the coordination repo aggregates.

### Process Constraints

- Effort artifact commits to the default branch (TR-3) must not require PR review for
  documentation-only changes to `.forge/` directories. Branch protection rules must
  permit direct commits or auto-merged PRs for workflow artifact updates.
- Phase gate hooks must not add perceptible latency to normal file writes. The hook
  must complete its check in under 500ms. If it cannot determine the relevant effort
  from the file path, it must allow the write immediately rather than performing an
  expensive search.
- Graduation (TR-12) must be an explicit operation that the engineer or agent invokes,
  not an automatic trigger. Effort completion does not automatically modify deployable
  or product documentation — the promotion is a deliberate act with its own review.
