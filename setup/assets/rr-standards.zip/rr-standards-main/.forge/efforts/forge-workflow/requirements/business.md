# Business Requirements

### BR-1: Engineers Must Have a Clear, Guided Path from Intent to Implementation

The process from "we need to build X" to "code is ready to review" must be guided step
by step. At each stage, the engineer and their AI agent must know: what the current phase
is, what output is required before advancing, and how to produce that output. An engineer
who is new to a work item — or resuming after an interruption — must be able to determine
their next required action without reading the full directory tree or asking what was done
before they arrived.

### BR-2: Workflow Artifact Placement Must Be Automatic and Correct

The forge directory taxonomy is complex and context-dependent. An engineer asking an AI
agent to "capture the requirements for this epic" or "draft the API spec" must get those
artifacts in the correct location without knowing the taxonomy themselves. This must hold
whether the engineer invokes a specific skill explicitly or makes a conversational request.

Artifacts that land in the wrong location break traceability, cause phase gate checks to
miss them, and leave future agents — in follow-on sessions or on different work items —
without the context they need. Correct placement must not depend on the engineer knowing
where things go.

### BR-3: The Workflow Must Surface Phase Context and Track Modifications to Approved Work

The workflow has a defined sequence: discovery before planning, planning before
implementation. This sequence represents the intended flow, not a rigid gate. In
practice, implementation surfaces missing requirements, planning reveals design gaps,
and discovery is revisited as understanding deepens. This is expected and productive.

What must not happen is that these revisions occur silently. An agent or engineer
modifying an approved requirement or specification during implementation must be aware
that the artifact was approved and that they are changing the agreed baseline. The
modification must be recorded — not blocked — so that it is visible during review and
reconciled before the effort's artifacts are graduated to canonical documentation.

The workflow must guide, not obstruct. Blocking writes to approved artifacts treats
development as waterfall and kills the exploratory flow that produces good software.
Surfacing modifications and requiring reconciliation before promotion preserves
flexibility during the work while ensuring rigor at the points that matter.

### BR-4: Workflow State Must Be Immediately Readable at Any Session Start

When a new session begins — whether it is the same engineer continuing work or a different
contributor picking up in-flight work — the current state of the work item must be
immediately available without traversing the directory tree. The state must communicate:
what phase the work is in, which artifacts exist, which decisions are open, and what action
is required to advance. The overhead of reconstructing "where we are" must be zero.

### BR-5: In-Flight Work Must Survive Session Boundaries Without Information Loss

AI sessions are bounded. Development work spans days or weeks. A work item that is
mid-discovery, mid-plan, or mid-implementation must be fully resumable in a subsequent
session without requiring the engineer to reconstruct context from scratch.

The state of the work item — open design questions, partially completed artifacts, decisions
under consideration, approved artifacts — must be persisted across sessions, not held only
in context. A work item that can only be continued by the same engineer in the same session
is not a work item — it is a conversation.

### BR-6: The Workflow Must Scale to Work Item Complexity

A story-level bug fix must not require discovery, validation, and formal planning phases.
An effort introducing a new API surface must. The workflow must apply the appropriate
level of rigor to each type of work item. Tier and risk classification must determine which
phases are required, which artifacts must be produced, and which gates must be passed before
the work can advance.

A process that applies effort-level rigor to story-level work will not be adopted. The
guarantee of the lightweight tier is not reduced quality — standards enforcement and PR
review remain active at every tier. The guarantee is that ceremony is proportional to the
risk and scope of the work.

### BR-7: Modifications to Approved Artifacts Must Be Visible and Reconciled Before Graduation

Once a design artifact — an API contract, a storage schema, an architecture decision — is
approved and the work advances past discovery, the artifact represents a committed baseline.
Modifying it during subsequent phases is permitted and expected — implementation reveals
constraints, planning surfaces gaps, and revisiting the design is how good software is
built.

What matters is that modifications are visible, not that they are prevented. Every change
to an approved artifact must be recorded as a post-approval modification so that it is
surfaced during review and addressed during graduation. The reconciliation point is not the
moment of edit — it is the moment the effort's artifacts are promoted to canonical
documentation. At that point, all post-approval modifications must be reviewed and the
graduated artifact must represent the final, coherent state of the design.

### BR-8: Work Item Hierarchy Must Be Readable Without Traversing Directories

Development work is hierarchical: programs contain efforts, efforts contain epics,
epics contain stories. An engineer working on a story must be able to identify the epic and
effort it serves. A team lead reviewing progress must be able to see all in-flight work
at every level without reading individual effort directories.

The registry must present the complete active hierarchy in a single view. Hierarchy is a
first-class concern — it must be maintained as work items are created, advanced, and closed,
not reconstructed from directory structure after the fact.

### BR-9: Workflow Artifacts Must Serve Both Human Readers and AI Agents

Every artifact the workflow produces serves two audiences. Human readers — engineers,
architects, leads — use them for documentation, design review, and onboarding. AI agents
use them for navigation, constraint loading, and phase gate decisions.

An artifact that communicates clearly to engineers but is structurally ambiguous to agents
fails half its purpose. An artifact that is machine-navigable but opaque to humans fails
the other half. The workflow must produce artifacts that both audiences can consume
independently, without requiring translation or supplemental context from the other format.

### BR-10: Coordination and Local Efforts Operate at Different Levels of Scope and Detail

When an effort spans multiple repositories — a backend service, iOS app, Android app,
web app, browser extension — the work is organized across two distinct levels that serve
different purposes and audiences.

The effort in the coordination repository captures two levels of concern. At the
product level: user-facing requirements, user flows, and user stories. At the system
level: technical interaction flows that span deployables — which systems communicate,
what contracts and events exist between them, and how data moves through the feature.
This system-level technical view is what makes it possible to identify which deployables
must change, what interfaces must exist between them, and how to decompose the work into
a coherent plan that can be executed across repositories.

What the coordination repository does not contain is the internal implementation detail
of any individual deployable — how that deployable fulfills its responsibilities
internally, what its technical architecture looks like, or how it structures its tests.
That level of detail belongs in the local sub-effort.

Each deployable has a sub-effort in its own repository. The coordination effort produces
a high-level plan scoped to requirements and acceptance criteria: what each deployable
must deliver and how its outputs will be verified, without prescribing how the work will
be done internally. This plan is projected to each local sub-effort as the seed for local
planning.

Each local sub-effort then elaborates that projection into a full local plan: technical
requirements specific to this deployable, technical specifications that describe how those
requirements will be met, and a detailed implementation plan describing exactly what will
be built. This elaboration is the local discovery process — it produces artifacts that
are scoped to this deployable and are never represented in the coordination repository.

The coordination plan answers "what must be true when this work is done." The local plan
answers "how we will make it true." Both must exist; neither substitutes for the other.

The relationship between the coordination effort and each local sub-effort must be
maintained. Changes to the coordination-level cross-cutting artifacts — user flows,
responsibility assignments, shared contracts — must be assessable for impact on each
local sub-effort. Discoveries at the local level that reveal gaps or errors in the
cross-cutting artifacts must surface as proposed changes to the coordination effort.
Divergence between the coordination view and the local view must be surfaced and resolved,
not silently permitted.

### BR-11: Forge Must Not Depend on Engineers Using Specific Commands or Sequences

Forge must work through natural conversation with Claude Code. Engineers must not need
to learn skill names, memorize command sequences, or understand the directory taxonomy to
get the full benefit of the workflow. The conversational path must be the primary path.

When an engineer says "we've decided to use DynamoDB for session storage," Forge
recognizes this as an architectural decision and creates an ADR in the correct location.
When an engineer says "the API endpoint work is done," Forge updates the task state,
checks verification criteria, and begins the appropriate promotion of artifacts. When
an engineer says "let's start planning the mobile work," Forge identifies the relevant
coordination artifacts, creates the local sub-effort, and materializes the projections.

Engineers who want to interact with Forge directly — using explicit skill invocations,
slash commands, or specific workflow operations — must be able to do so. Direct invocation
is valuable for power users who want precision and for automation pipelines that need
deterministic behavior. But direct invocation must never be *required* for the workflow
to function correctly. An engineer who never uses a Forge command must get the same
artifacts, state transitions, and promotions as one who does.

The test is not whether Forge is hidden — it is whether Forge *depends* on the engineer
knowing it exists. An engineer who has never heard of Forge should be able to work through
a complete effort by having a normal conversation with Claude Code, and the workflow
should function correctly. An engineer who knows Forge well should be able to use it
more efficiently, but not more correctly.

### BR-12: Completing an Effort Must Promote All Its Artifacts to Canonical Documentation

An effort directory is a working space. When the work is done, the effort becomes a
historical record of the journey. The canonical representation of what was built and why
must live somewhere that outlasts the effort.

When an effort that creates or meaningfully modifies a deployable reaches completion, the
artifacts produced — requirements, technical specifications, design decisions, test
strategies — must be reflected in the deployable's canonical documentation. This applies
to all artifact types, not only requirements. The deployable docs become the authoritative
reference for what the deployable is now. The effort record answers "how did we get here";
the deployable docs answer "what is it."

When a full effort completes — all downstream efforts closed, all deliverables shipped —
its cross-cutting artifacts must be reflected in the associated product documentation.
The product docs are the PM-facing, cross-deployable view of the capability. An effort
that ships without updating the canonical documentation has delivered code but not
completed the work.
