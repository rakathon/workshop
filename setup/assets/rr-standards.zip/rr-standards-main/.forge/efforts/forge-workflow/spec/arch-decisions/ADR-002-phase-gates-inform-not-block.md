# ADR-002: Phase Gates Inform but Never Block Workflow Artifact Writes

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

The Forge workflow has a defined phase sequence: discovery before planning, planning
before implementation. The original forge-plugin specification used hard blocking (exit
code 2) to enforce this sequence — a PreToolUse hook would block writes to downstream
artifact paths if the current phase had not been approved.

This design treats the phase sequence as a strict gate: you cannot write implementation
code until discovery is approved, you cannot modify approved requirements without going
through a reopen process.

In practice, software development is not waterfall. Discovery is revisited during
planning. Implementation reveals gaps in the specification. Requirements change when
code exposes unforeseen constraints. A system that blocks these natural revisions forces
engineers to work around the tool rather than with it, and reduces adoption.

The question is: how do we preserve the intent of phase sequencing (requirements before
implementation, approved designs before coding) without blocking the exploratory flow
that produces good software?

## Decision

PreToolUse hooks for workflow artifact writes exit 0 (allow) in all cases. When a write
is atypical for the current phase — for example, modifying a requirements file during
the implementation phase — the hook emits informational context (exit 0 with output)
making the agent aware of the situation. The write proceeds.

Post-approval modifications are tracked automatically by the PostToolUse hook in
`.state.json`. The rigor is applied at graduation: before effort artifacts are promoted
to canonical deployable documentation, all post-approval modifications must be reviewed
and reconciled. The graduated artifact represents the final, coherent state of the
design.

The one meaningful hard gate — source code cannot be written before discovery is
approved for full-tier work items — is the single exception. This gate uses exit code 2
because writing implementation code when requirements and design are unapproved is
categorically different from updating a requirements file during implementation.

## Alternatives Considered

**Hard-block all out-of-phase writes (original design).**
Rejected. Implementation often reveals constraints that require returning to discovery
artifacts. Blocking these writes forces engineers to use a formal reopen ceremony before
making a practical correction, adding overhead that reduces adoption. A tool that
frustrates productive engineering behavior will not be used.

**Advisory block with easy bypass.**
Considered. A soft block that says "this is out of phase, are you sure?" and accepts
"yes" as a bypass. Rejected because the result is functionally identical to allowing
the write — engineers will always bypass — while adding friction without adding safety.

**No phase awareness in hooks.**
Rejected. Without hook-level awareness, post-approval modifications are invisible. The
graduation reconciliation step depends on knowing which artifacts were modified after
approval. Completely removing phase awareness loses the audit trail that makes
graduation meaningful.

**Block writes to approved artifacts; allow writes to unapproved artifacts.**
Rejected as a variant of the original design. The blocking behavior is the problem
regardless of the approval status of the specific file. The distinction that matters
is not "is this file approved?" but "is the modification visible and will it be
reconciled?" Tracking achieves this without blocking.

## Consequences

- Workflow artifacts can be modified at any phase. The system trusts the engineer to
  make useful modifications and records them for reconciliation rather than preventing
  them.
- The PostToolUse hook must reliably detect and record post-approval modifications. If
  this tracking fails silently, the graduation reconciliation step loses its input and
  modifications may be promoted without review.
- The graduation skill becomes a meaningful quality boundary. It is the point where
  the permissive edit-time behavior is reconciled into a coherent, reviewed result.
  If graduation is skipped or done carelessly, the benefit of tracking is lost.
- The single hard gate (source code before approved discovery) is the most important
  enforcement point and should be robust. All other artifact write hooks are
  informational.
- This decision diverges from the gate model described in the parent forge-plugin spec.
  When the forge-workflow effort graduates, the parent spec should be updated to reflect
  this decision.
