# Forge Workflow — Technical Specification

## Overview

This specification describes how the Forge workflow system uses Claude Code's extension
mechanisms — CLAUDE.md, hooks, skills, and agents — to fulfill the business and technical
requirements defined in the forge-workflow effort. The system operates through three
cooperating layers:

1. **The Guidance Layer (CLAUDE.md)** — A forge-managed section (~60-80 lines) loaded into
   Claude's context for the entire session. Provides the conceptual model of Forge and a
   terse intent recognition list. Deliberately compact — routing tables and detailed
   patterns are injected by hooks at session start and on demand, preserving context budget
   for project-specific content.

2. **The Context and Tracking Layer (Hooks)** — Shell scripts that fire at Claude Code
   lifecycle events. Inject dynamic state at session start, provide phase awareness before
   writes, update state after writes, and track post-approval modifications. Hooks never
   block workflow artifact writes.

3. **The Operation Layer (Skills)** — Explicit, invocable capabilities for power users and
   automation. Every operation that can be triggered conversationally can also be invoked
   directly. Skills are the deterministic path; conversation is the primary path.

**Design principles:**

- **Conversation-first.** The system must function correctly when the engineer never
  invokes a command. Skills exist for precision and automation, not as prerequisites.
- **Inform, don't block.** Phase context is awareness, not enforcement. Hooks emit
  context; they do not prevent writes. Rigor is applied at graduation, not at edit time.
- **Git is the only storage.** All state is files in git. No services, no databases,
  no runtime dependencies.
- **State is a side effect.** Engineers and agents produce artifacts; hooks derive state
  changes from artifact creation and modification. No one explicitly manages `.state.json`.

---

## Layer 1: CLAUDE.md — The Guidance Layer

### Context Budget Design

CLAUDE.md content persists in Claude's context window for the entire session and
competes with code, conversation, and project-specific instructions. The Forge guidance
layer is designed as three tiers to minimize permanent context cost:

| Tier | Mechanism | Size | Content | Persistence |
|------|-----------|------|---------|-------------|
| 1 | CLAUDE.md forge-managed section | ~60-80 lines | Conceptual model + terse intent list | Always present |
| 2 | SessionStart hook output | ~50-80 lines | Routing table + current state | Fresh each session; may scroll back in long sessions |
| 3 | UserPromptSubmit hook output | ~20-30 lines | Targeted routing re-injection | On-demand when workflow event detected |

The CLAUDE.md section gives Claude the framework understanding needed to recognize when
to engage with `.forge/`. The hooks provide operational detail at the moment it's needed.

### Location and Ownership

The forge guidance lives in a forge-managed section of the project's root `CLAUDE.md`,
bounded by markers. Written by `forge:init`, updated by `forge:update`. Engineers may
read it but should not edit the managed section directly.

```
<!-- forge:managed:start -->
## Forge Workflow
...
<!-- forge:managed:end -->
```

### Tier 1: CLAUDE.md Content (~60-80 lines)

The managed section contains three things: conceptual understanding, terse intent list,
and the before-write rule. It does not contain routing tables or verbose pattern
descriptions — those live in hook output.

**Approximate CLAUDE.md section content:**

```markdown
## Forge Workflow

This project uses Forge, a structured development workflow system. Forge manages work
artifacts — requirements, specifications, plans, architecture decisions, and validation
reports — in the `.forge/` directory. These artifacts are the source of truth for
what is being built, why, and how far along it is.

### The `.forge/` directory

`.forge/` has three subdirectories, each with a distinct purpose:

- **`efforts/`** — Work-in-progress artifacts. Each effort (a unit of work, from a
  multi-repo initiative down to a single story) has its own subdirectory containing
  requirements, specifications, plans, and decisions produced during that work. Efforts
  are active while the work is in progress and become historical records when closed.

- **`deployables/`** — Canonical, living documentation for each technical deployable
  unit in this repository. Updated when efforts complete (graduate). Reflects the
  current state of the deployable — what it does, what decisions shaped it, what
  constraints it operates under.

  Each deployable contains a `capabilities/` directory. A capability is a user-facing
  feature — it is named after what it delivers to the engineer, not the architectural
  layer it belongs to. `forge-init` is a capability because it delivers the `forge:init`
  experience. "initialization-infrastructure" is not a capability name — that is an
  architectural grouping. When creating or naming a capability, ask: "what does an
  engineer *do* with this?" — the answer is the capability name.

- **`products/`** — PM-facing documentation for business capabilities that span
  multiple deployables. Present only in coordination repositories.

### Recognizing workflow events

When the conversation contains one of these, take the corresponding action in addition
to responding naturally — do not announce it, just do it:

- Technical decision made ("we'll use X", "let's go with Y because Z") → write an ADR
- Requirements described ("it must do X", "users need to be able to Y") → update requirements
- Design discussed ("the API should look like X", "data flows from X to Y") → update spec
- Work completed ("that's done", "task X is finished") → update plan task status
- Concern raised ("I'm worried about X", "this might not work because Y") → record as open decision
- Checkpoint task reached and blocked ("I need to confirm X before I can proceed") → record as open decision, note which task is blocked
- Status asked ("where are we", "what's left") → read state and summarize
- Work declared complete ("we're done", "let's close this out") → initiate graduation

### Before writing any `.forge/` file

1. Read `.forge/efforts/README.md` to identify active efforts
2. Read the relevant effort's `.state.json` to confirm current phase
3. The session context injected at startup contains the full artifact routing table —
   use it to determine the correct path for the artifact type you are writing
4. If the file already exists, read it before writing

The PostToolUse hook updates `.state.json` automatically after every artifact write.
Commit artifact changes with: `docs(<effort-id>): <description>`
```

### Tier 2: SessionStart Hook Output (~50-80 lines)

Emitted by `inject-workflow-context.sh` at session start. Contains the operational
detail that the CLAUDE.md deliberately omits. See Hook 1 specification below for the
full output format.

**Includes:**
- Artifact routing table (artifact type → canonical path for every artifact type)
- Current effort state: phase, artifacts present/absent, open decisions, next action
- Upstream change proposal status
- Staleness warnings for coordination projections
- Active effort identification rules

### Tier 3: UserPromptSubmit Hook Output (~20-30 lines)

Emitted by `route-to-skills.sh` when a workflow event is detected in the prompt.
Provides targeted re-injection of the routing rules and state relevant to the specific
operation being triggered — compensating for long sessions where Tier 2 content may
have scrolled out of effective context.

**Emitted only for:** Explicit skill invocations, effort completion events, cross-repo
operations, and any operation where routing ambiguity would cause a meaningful error.

---

## Layer 2: Hooks — The Context and Tracking Layer

### Hook 1: SessionStart — inject-workflow-context.sh

**Purpose:** Inject the current workflow state into Claude's context at the beginning of
every session, so the agent knows what's happening before the engineer says anything.
Fulfills TR-11 (session start context) and BR-4 (immediately readable state).

**Trigger:** Session start

**Behavior:**

1. Read `.forge/efforts/README.md` to get the list of all active efforts
2. For each active effort, read `.state.json`
3. Identify the most likely "current" effort:
   - If only one effort is in_progress, that's the current effort
   - If the current git branch name matches an effort ID, use that
   - If multiple efforts are active, list all with a prompt to clarify
4. For the current effort, emit:
   - Current phase and status
   - Artifacts present and absent
   - Open decisions (if any)
   - Pause state and next action (if resuming)
   - Post-approval modifications (if any — flags for reconciliation)
5. For cross-repo sub-efforts, check staleness:
   - Read `coordinationRef` from `.state.json`
   - If the ref includes a commit SHA, compare against the coordination repo's current
     HEAD via `gh api` (non-blocking; skip if offline)
   - Emit staleness warning if projection is behind
6. Exit code 0 (never blocks session start)

**Output format (emitted to Claude):**

```
## Forge — Active Workflow Context

**Current effort:** forge-workflow (initiative)
**Phase:** discovery (in_progress)
**Tier:** full | **Risk:** R2

**Artifacts:**
- requirements/business.md ✓
- requirements/technical.md ✓
- spec/ (empty — no design artifacts yet)

**Next suggested action:** Begin design work — create API specifications or
architecture decisions based on the technical requirements.

**Open decisions:** none

**Post-approval modifications:** none
```

**Performance:** Must complete in under 2 seconds. Staleness checks via GitHub API run
in a background subprocess and emit asynchronously if they complete within the timeout.
If they don't, the session starts without staleness info.

### Hook 2: UserPromptSubmit — route-to-skills.sh

**Purpose:** Reinforce intent recognition by detecting obvious workflow commands in the
engineer's prompt and injecting additional context. This is a safety net — the CLAUDE.md
intent patterns are the primary mechanism; this hook catches cases where additional
context would help Claude choose the right action.

**Trigger:** After user submits a prompt, before Claude responds

**Behavior:**

1. Scan the prompt for high-confidence intent signals:
   - Explicit skill invocations (`/forge:plan`, `forge:promote`, etc.) → inject the
     skill's instructions directly
   - Effort-related keywords with an effort ID ("start working on PROJ-1234") → inject
     effort context if not already the current effort
   - Completion signals ("mark as done", "close this effort") → inject graduation
     checklist context
2. For low-confidence or ambiguous signals: do nothing (let CLAUDE.md handle it)
3. Exit code 0 (never blocks)

**Design constraint:** This hook must not duplicate what CLAUDE.md already provides. Its
role is supplementary — catching edge cases and providing extra context for high-stakes
operations (like graduation) where getting it right matters enough to warrant redundancy.

### Hook 3: PreToolUse — phase-context.sh

**Purpose:** Before any Write or Edit to a `.forge/` path, inform Claude about the
current phase and whether the target artifact was produced in an earlier (possibly
approved) phase. Fulfills TR-8 (phase context) and BR-3 (surface modifications to
approved work).

**Trigger:** Before Write or Edit operations

**Applies to:** Files under `.forge/efforts/` only. Writes to `.forge/deployables/`,
`.forge/products/`, source code, or any path outside `.forge/efforts/` are allowed
without interference.

**Behavior:**

1. Extract the effort ID from the target file path
   (e.g., `.forge/efforts/forge-workflow/requirements/business.md` → `forge-workflow`)
2. Read `.forge/efforts/<id>/.state.json`
3. Determine the artifact category from the file path:
   - `requirements/` → requirements artifact
   - `spec/` → design artifact
   - `validation/` → validation artifact
   - `plan/` → planning artifact
4. Determine whether this write is "typical" for the current phase:
   - Discovery phase: writing to requirements/ or spec/ is typical
   - Planning phase: writing to plan/ is typical
   - Implementation phase: writing to plan/ (task updates) is typical; writing to
     requirements/ or spec/ is atypical (post-approval modification)
5. If typical: exit code 0, no output
6. If atypical: exit code 0, emit informational context:

```
Note: You are modifying requirements/business.md, which was produced during the
discovery phase (approved on 2026-03-15). The effort is currently in the implementation
phase. This modification will be tracked as a post-approval change and must be
reconciled during graduation. Proceed with the modification.
```

**Performance:** Must complete in under 200ms. Reads exactly two things: the file path
(from hook arguments) and `.state.json` (one file read). No network calls.

### Hook 4: PreToolUse — inject-generation-standards.sh

**Purpose:** Before writing source code files (not `.forge/` artifacts), inject the
relevant coding standards into Claude's context. This is an existing hook from the
forge-init capability, included here for completeness.

**Trigger:** Before Write or Edit operations on source code paths

**Applies to:** Source code files only (determined by extension and path). NOT applied
to `.forge/` paths, documentation, or hook scripts.

**Behavior:** Maps file path to relevant standards (REST, security, storage, messaging,
etc.) and emits the standard file paths as context injection. Unchanged from the
forge-init specification.

### Hook 5: PostToolUse — update-workflow-state.sh

**Purpose:** After any Write or Edit to a `.forge/efforts/` path, detect what kind of
artifact was created or modified and update `.state.json` and `.forge/efforts/README.md`
automatically. This is the mechanism that makes state management invisible — the
engineer and agent produce artifacts, and state is derived. Fulfills TR-9 (post-approval
tracking) and TR-15 (automatic state management).

**Trigger:** After Write or Edit operations complete successfully

**Applies to:** Files under `.forge/efforts/` only.

**Behavior:**

1. Extract the effort ID from the written file path
2. Read `.forge/efforts/<id>/.state.json`
3. Determine the artifact category and update the artifact inventory:
   - `requirements/business.md` written → set `phases.discovery.artifacts.requirements.business` to `"present"`
   - `spec/api/*.yaml` written → set `phases.discovery.artifacts.spec.api` to `"present"`
   - `spec/storage/*.md` written → set `phases.discovery.artifacts.spec.storage` to `"present"`
   - `spec/messaging/*.md` written → set `phases.discovery.artifacts.spec.messaging` to `"present"`
   - `spec/test-strategy.md` written → set `phases.discovery.artifacts.spec.testStrategy` to `"present"`
   - `spec/arch-decisions/ADR-*.md` written → append to `phases.discovery.artifacts.adrsCreated`
   - `plan/tasks.md` written → set `phases.planning.status` to `"in_progress"` if `"not_started"`
   - `validation/report.md` written → set `phases.validation.status` to `"in_progress"`; parse the
     overall result (PASS / PASS WITH CONCERNS / FAIL) and record in `phases.validation.result`
   - `validation/arch-review.html` written → set `phases.validation.artifacts.htmlPresentation` to `"present"`
4. Check for post-approval modifications:
   - If the artifact category belongs to a phase whose status is `"approved"`, append a
     record to `phases.<phase>.postApprovalModifications`:
     ```json
     {
       "file": "requirements/business.md",
       "modifiedDuringPhase": "implementation",
       "modifiedAt": "2026-03-27T14:30:00Z"
     }
     ```
5. Write updated `.state.json`
6. If the effort's phase or status changed, update the corresponding row in
   `.forge/efforts/README.md`
7. Exit code 0 (PostToolUse hooks cannot block; they are informational)

**Atomicity note:** The hook updates `.state.json` in the working tree. The CLAUDE.md
instructions tell Claude to commit the artifact and the state change together. The hook
does not create commits — Claude does, guided by the CLAUDE.md behavioral rules.

### Hook 6: PostToolUse — monitor-context.sh

**Purpose:** Monitor remaining context window and warn when it's depleting. Existing
hook from the forge-plugin specification — included for completeness.

**Trigger:** After all tool uses

**Behavior:** At 35% remaining context, emit WARNING suggesting forge:pause. At 25%,
emit CRITICAL requiring immediate pause. Debounced to fire at most once per 5 tool uses.

---

## Layer 3: Skills — The Operation Layer

Skills are the explicit invocation path. Every workflow operation that CLAUDE.md
enables conversationally has a corresponding skill that can be invoked directly. Skills
produce identical outcomes to the conversational path but offer precision, repeatability,
and scriptability.

### Skill Design Principles

1. **Skills are optional.** Every skill's behavior can be triggered conversationally.
   Skills exist for power users and CI/CD pipelines.
2. **Skills and conversation share hooks.** Whether an artifact is written by a skill or
   by conversational Claude, the same PostToolUse hooks fire and the same state updates
   occur.
3. **Skills reference standards and templates.** Skills do not contain rules — they point
   Claude to the standard or template that contains the rules.
4. **Orchestrator vs worker classification applies.** Heavy analytical operations
   (validation, review, graduation) run as isolated sub-agents to protect the main
   session's context window.
5. **Worker context boundaries are marked in SKILL.md.** When a skill can be invoked
   either as an orchestrator (in the main session) or as a worker (isolated sub-agent),
   sections of its SKILL.md that only apply in the main session must be marked
   `[orchestrator-only]`. A worker sub-agent reading the SKILL.md must skip these
   sections. Examples of orchestrator-only content: reading `.state.json` to check
   workflow phase, emitting status to the engineer, invoking other skills, updating the
   master registry. Workers receive their context from the hook injection and their input
   parameters — they do not navigate session state.

### Workflow Skills

| Skill | Type | Purpose | Conversational equivalent |
|-------|------|---------|--------------------------|
| `forge:effort` | Orchestrator | Create a new effort, scaffold directories, register in README | "Let's start working on X" |
| `forge:status` | Orchestrator | Read and present current effort state | "Where are we?" |
| `forge:promote` | Orchestrator | Advance effort to next phase (mark discovery approved, etc.) | "Discovery looks good, let's move to planning" |
| `forge:pause` | Orchestrator | Persist pause state for session handoff | "Let's pick this up tomorrow" |
| `forge:resume` | Orchestrator | Restore pause state and present context | (Automatic at session start if pause state exists) |
| `forge:arch-review` | Worker | Validate design artifacts against all applicable standards and produce a detailed validation report + multi-page HTML document for architecture review meetings | "Let's prepare the architecture review" |
| `forge:verify` | Worker | Verify implementation delivers stated requirements and matches spec — distinct from test execution | "Let's verify everything before opening the PR" |
| `forge:graduate` | Worker | Promote effort artifacts to deployable/product canonical docs | "QA passed, let's close this effort out" |
| `forge:plan` | Orchestrator | Generate implementation plan from discovery artifacts | "Let's break this into tasks" |
| `forge:project` | Orchestrator | Create local sub-effort from coordination effort, materialize projections | "Let's start the backend work for this effort" |
| `forge:sync` | Orchestrator | Check and update stale projections from coordination repo | "Are we up to date with the coordination effort?" |
| `forge:upstream` | Orchestrator | Create a change proposal for a coordination-level artifact | "The API contract needs to change — the coordination effort should know" |
| `forge:adr` | Orchestrator | Create an ADR in the active effort | "We've decided to use X because Y" |

### Cross-Repository Skills

| Skill | Type | Purpose |
|-------|------|---------|
| `forge:project` | Orchestrator | Fetches coordination effort artifacts via GitHub API, creates local sub-effort, materializes projections with provenance headers, records `coordinationRef` in `.state.json` |
| `forge:sync` | Orchestrator | For each projection in the local effort, compares the provenance commit SHA against the coordination repo's current HEAD. Reports stale, current, or unreachable for each. Optionally re-materializes stale projections. |
| `forge:upstream` | Orchestrator | Creates a structured change proposal document in the local effort. Optionally creates a PR to the coordination repo via `gh pr create`. Records the proposal and its status in `.state.json`. |

### Implementation Task Execution Loop

Implementation skills (`forge:build-api`, `forge:build-repo`, etc.) do not declare a
task complete when the code is written. They run a quality loop and only mark the task
complete when all checks pass. This keeps the quality boundary inside the implementation
cycle — not deferred to CI or a manual review step.

**Loop per task:**

```
iteration = 0
while iteration < 3:

  Step 1 — Implement
    Write or update source files per the task description,
    the task's acceptance criteria, and applicable spec artifacts.
    For [tdd] tasks: write the failing test first, then implement.

  Step 2 — Lint
    Run the configured linter(s) for all changed file types.
    Read the output. Fix any errors or warnings before continuing.

  Step 3 — Validate against spec
    Read the task's acceptance criteria from plan/tasks.md.
    Read the applicable spec artifacts (API contract, storage schema, etc.).
    Confirm the implementation satisfies them.
    If gaps exist, address them in the current iteration.

  Step 4 — Run tests
    Run the test suite or the affected subset.
    For [tdd] tasks: confirm the test written in Step 1 now passes.
    Confirm no existing tests regress.

  If all checks pass:
    Commit with conventional message + effort scope
    Record commit SHA in plan/tasks.md next to the task
    Update .state.json (PostToolUse hook handles this)
    Mark task complete — exit loop

  iteration += 1

If limit reached without passing:
  Record escalation state in .state.json pause field:
    - Which task is blocked
    - Which checks are still failing
    - What was attempted each iteration
  Surface to engineer — do not mark the task complete
```

**Why the limit is 3 by default:** Three iterations is enough to address the typical
correction cycle (implement → fix lint → fix test) without allowing runaway cost or
quality degradation. An implementation that cannot pass all checks after three
iterations has a problem that needs human judgment — a deeper design issue, an
ambiguous spec, or a conflict between requirements — not another automated pass.

**forge:verify is separate and distinct.** The per-task loop validates each task in
isolation against its own acceptance criteria. `forge:verify` runs once after all tasks
are complete and checks whether the whole implementation — across all tasks — delivers
the stated effort goals. The loop catches per-task correctness; `forge:verify` catches
integration gaps and semantic delivery.

### Phase Promotion Skill (forge:promote)

**Classification:** Orchestrator

**Purpose:** Advance an effort from one phase to the next. This is not a state flag
flip — it is a defined ritual that checks readiness, presents a phase summary, requires
explicit engineer confirmation, and produces an auditable checkpoint commit.

**Why a ritual matters:** The discovery-to-planning gate is the one meaningful phase
gate in the workflow. Allowing `forge:promote` to advance an effort without checking
readiness would make the gate advisory. The ritual ensures the engineer is making an
informed decision, not accidentally advancing.

**Behavior for discovery → planning promotion:**

1. **Check artifact completeness.** Read `.state.json` and verify all required
   discovery artifacts are present for the effort's tier:
   - Full tier: business requirements, technical requirements, and at least one spec
     artifact (API, storage, messaging, or ADR)
   - Lightweight tier: no discovery artifacts required — advancement is always permitted
   If required artifacts are absent, present the gap and stop. Do not advance.

2. **Surface post-approval context.** If any artifacts were modified after a prior
   approval (tracked in `postApprovalModifications`), list them. These must be
   acknowledged before re-promotion.

3. **Present a phase summary.** Emit a structured summary for the engineer to review:
   - Artifacts produced: list each with a one-line description
   - ADRs recorded: list each with its decision
   - Open decisions remaining (if any)
   - Risk classification

4. **Require explicit confirmation.** Ask the engineer: "Does this look complete and
   correct? Confirm to advance to planning." The engineer must respond affirmatively.
   `forge:promote` must not advance on ambiguous input.

5. **Create a checkpoint commit.** Commit `.state.json` with `currentPhase` updated
   to `"planning"` and `phases.discovery.status` set to `"approved"` with the
   approver (engineer) and timestamp recorded. Commit message:
   `chore(<effort-id>): promote discovery to planning`

6. **Update the registry.** Update the effort's row in `.forge/efforts/README.md` to reflect
   the new phase.

**Behavior for other phase transitions** (planning → implementation, implementation →
verification, etc.) follows the same pattern: check readiness for the target phase,
present a summary, confirm, commit, update registry. The specific readiness checks
differ by phase:

| Transition | Required for advancement |
|------------|--------------------------|
| discovery → planning | `validation/report.md` present (full tier); `validation/report.md` result must be PASS or PASS WITH CONCERNS — FAIL blocks advancement |
| planning → implementation | `plan/tasks.md` present with at least one wave of tasks |
| implementation → verification | All tasks in all waves marked complete with commit SHAs |
| verification → closed | `forge:verify` report present and showing PASS |

### Architecture Review Skill (forge:arch-review)

**Classification:** Worker (isolated sub-agent)

**Why isolated:** Reads the full set of discovery artifacts plus every applicable
standard from the standards library. Produces two substantial output artifacts. Running
in the main session would consume context needed for the subsequent workflow. Running
isolated also ensures consistent analysis quality regardless of what else has happened
in the session.

**Purpose:** Validate the effort's design artifacts against all applicable standards,
check requirements traceability, and produce two artifacts: a detailed findings report
and a self-contained HTML document for the architecture review meeting.

**Conversational trigger:** "Let's prepare for the architecture review," "validate the
design," "generate the arch review doc."

**When to run:** After discovery artifacts are complete (requirements + spec artifacts
present) and before `forge:promote` to planning. Full-tier efforts must have a passing
or passing-with-concerns validation report before advancement is permitted.

---

**Output 1: `validation/report.md`**

The machine-readable validation record. Structured for git-diffability and for
consumption by `forge:promote` (which reads the overall result). Contains:

- Header: effort ID, date, risk tier, overall result (PASS / PASS WITH CONCERNS / FAIL)
- One section per standard domain checked, with per-rule findings
- Requirements traceability section
- Open design questions surfaced during analysis

Overall result logic:
- **PASS** — no failures, zero or more informational notes
- **PASS WITH CONCERNS** — no failures, one or more concerns (things that may cause
  problems but do not violate a standard)
- **FAIL** — one or more standard violations that must be resolved before implementation

Per-finding severity:
- **FAIL** — violates a MUST rule in the applicable standard
- **CONCERN** — violates a SHOULD rule, or a pattern that commonly causes problems
- **NOTE** — informational, no action required

Example structure:
```markdown
# Architecture Review Report: favorite-stores
**Date:** 2026-03-29 | **Risk:** R2 | **Result:** PASS WITH CONCERNS

## Requirements Coverage
| Requirement | Design Coverage | Status |
|-------------|----------------|--------|
| BR-1: Add favorites | POST /v1/members/me/favorites, member_favorites table | ✓ |
| BR-4: 50-store limit | DB trigger (ADR-001), HTTP 409 response | ✓ |
| TR-5: Atomic capacity | PostgreSQL trigger — concurrent writes cannot both pass | ✓ |

## API Contract (standards/api/rest.md)
| Rule | Severity | Finding |
|------|----------|---------|
| Resource URLs use nouns | ✓ PASS | `/favorites` correct |
| POST 201 for new resource | ⚠ CONCERN | Duplicate add returns 200 — acceptable but... |
| Error body includes `code` field | ✗ FAIL | 409 response body missing `code` field |

## Data Model (standards/storage/relational.md)
...

## Security (standards/security/owasp.md, auth.md)
...

## Privacy (standards/privacy/pii-handling.md)
...
```

---

**Output 2: `validation/arch-review.html`**

A self-contained HTML document (no external dependencies — all CSS inline) designed
for projection and navigation in an architecture review meeting. Engineers from
security, DevOps, QA, and development teams must be able to read their relevant
section without needing context from other sections.

Structure: a fixed navigation sidebar with links to each section. Each section occupies
a full page-height block and addresses a single concern with sufficient detail for the
relevant engineering audience.

**Sections:**

| Section | Primary audience | Content |
|---------|-----------------|---------|
| Overview | All | Effort name, date, team, risk tier, one-paragraph summary |
| Business Requirements | All | Each BR in plain language with acceptance criteria |
| Technical Requirements | Developers, DevOps | NFRs, performance targets, constraints, integrations |
| Architecture Decisions | All | Each ADR: decision, rationale, alternatives rejected |
| API Design | Developers, QA | Endpoints rendered from OpenAPI spec: URL, method, request/response schemas, status codes, auth requirement |
| Data Model | Developers, DevOps | Tables/collections rendered from storage schema: columns, types, constraints, indexes, relationships, capacity notes |
| Messaging & Events | Developers, DevOps | Event types, schemas, producers, consumers, ordering guarantees (if applicable) |
| Security Analysis | Security, Developers | Auth flow, OWASP checklist findings, secrets handling, input validation, identified risks |
| Privacy Analysis | Security, Developers | Data classifications, PII fields identified, retention, consent requirements, findings |
| Standards Compliance | All | Summary table: each standard checked, result (PASS/CONCERN/FAIL), finding count |
| Requirements Traceability | QA, Developers | Full matrix: each requirement mapped to its design coverage; gaps highlighted |
| Open Decisions & Risks | All | Unresolved design questions, known risks, items deferred to implementation |

**HTML constraints:**
- Self-contained: no CDN, no external fonts, no network dependencies
- Renders correctly when opened from a file system (no server required)
- Navigable without JavaScript (anchor-based navigation is sufficient)
- Print-friendly: each section naturally breaks to a new page when printed
- Readable when projected: minimum 14px body text, high contrast

---

**Analysis behavior:**

The skill reads applicable standards based on what artifact types exist in the effort:
- Always checked: requirements traceability, ADR quality
- If `spec/api/` exists: REST API standards
- If `spec/storage/` exists: applicable storage standards per store type
- If `spec/messaging/` exists: messaging contract standards
- Always checked (for any design): security implications (OWASP, auth), privacy
  implications (PII in API responses, data retention)

The skill does not skip a standards check because the effort does not obviously touch
that domain. A standards check that produces "not applicable" is better than an
applicable standard silently missed. Security and privacy checks run on every effort
regardless of artifact types present.

**[orchestrator-only]** sections (skipped when running as worker):
- Reading `.state.json` for workflow phase
- Updating `.forge/efforts/README.md`
- Invoking other skills

The worker receives: effort directory path, standards library path, effort ID.

### Graduation Skill (forge:graduate)

**Classification:** Worker (isolated sub-agent)

**Why isolated:** Graduation reads the full set of effort artifacts and the full set of
existing deployable/product documentation, then produces a merged result. This is a
large-context operation that should not consume the engineer's main session context.

**Behavior:**

1. Read the effort's `.state.json` to identify:
   - Associated deployables (from `deployables` field)
   - Associated products (from `businessProducts` field)
   - Post-approval modifications (from `phases.*.postApprovalModifications`)
2. Read all effort artifacts: requirements, specifications, ADRs, test strategies
3. Read the current canonical documentation for each associated deployable
4. For each artifact type, merge the effort's content into the canonical docs:
   - **Requirements:** Update or add sections in `deployables/<name>/requirements/`
   - **Specifications:** Update or add sections in `deployables/<name>/spec/`
   - **ADRs:** Already written to the canonical ADR directory during discovery — verify
     they reference this effort ID in their metadata
   - **Capability-level artifacts:** If the effort targets a specific capability, update
     `deployables/<name>/capabilities/<cap>/`
5. If post-approval modifications exist, flag them in the graduation report for review
6. Write updated canonical documentation files
7. Update the effort's `.state.json`: set `graduated: true`, record graduation timestamp
8. Remove the effort from `.forge/efforts/README.md` (it is now closed)
9. Return a graduation report to the main session summarizing what was promoted

For coordination efforts: repeat the process targeting `.forge/products/<name>/` instead
of `.forge/deployables/<name>/`.

---

## Effort Type Classification

Every effort is declared as one of four subtypes at creation. Subtype determines which
phases are required, whether CI review is mandatory, and whether the work item is
production-bound. `forge:effort` prompts for subtype when the context doesn't make it
obvious; engineers can also declare it conversationally ("this is a bug fix" or
"we're building a PoC").

### Production-Bound Subtypes

All three production-bound subtypes require `forge:review` as a blocking CI status
check before merge. This is non-negotiable regardless of effort size. Standards
enforcement runs at the same bar as full-tier work; the difference is in which
upstream phases are required, not in how the code is reviewed.

**Patch** — minimal change, no architectural impact
*Examples: bug fix, copy change, configuration tweak, dependency update*

| Phase | Required? |
|-------|-----------|
| Discovery (requirements + spec) | No |
| Arch review | No |
| Planning | No |
| Implementation | Yes |
| CI review (`forge:review`) | Yes — blocking |
| QA | No |

Tests: existing tests must pass; a regression test is recommended for bug fixes.

**Refactor** — structural improvement with no behavioral change
*Examples: extract method, rename, reorganize modules, reduce duplication*

| Phase | Required? |
|-------|-----------|
| Discovery | No |
| Arch review | No |
| Planning | Optional (helpful for large refactors) |
| Implementation | Yes |
| CI review (`forge:review`) | Yes — blocking |
| QA | No |

Tests: existing test suite must pass unchanged after the refactor. A refactor that
requires test changes to pass is not a pure refactor — it is an extension.

**Extension** — additive change to an existing capability
*Examples: add API endpoint, add request/response field, add database column, add event type*

| Phase | Required? |
|-------|-----------|
| Discovery (requirements + spec) | Optional — required if non-trivial scope |
| Arch review | No |
| Planning | Optional |
| Implementation | Yes |
| CI review (`forge:review`) | Yes — blocking |
| QA | Risk-dependent (R2 extensions should have QA) |

Tests: required for new functionality. An extension that touches an API contract or
data model must have corresponding tests for the new behavior.

### Non-Production-Bound Subtype

**PoC / Spike** — exploratory work that will not go to production
*Examples: feasibility prototype, internal demo, technology evaluation, algorithm
exploration, architecture comparison*

| Phase | Required? |
|-------|-----------|
| Discovery | No |
| Arch review | No |
| Planning | No |
| Implementation | Yes |
| CI review (`forge:review`) | Optional — non-blocking if run |
| Security / privacy validation | Not required |
| Test coverage | Not required |
| QA | No |

PoC/spike efforts are declared non-production-bound at creation. This is recorded in
`.state.json` as `"productionBound": false`. Non-production-bound work items:
- Must not be merged to production-tracked branches
- Are exempt from security and privacy blocking checks
- Are exempt from test coverage requirements
- May be reviewed with `forge:review` for learning, but failures do not block

### PoC to Production: A New Effort Is Required

If a PoC proves the concept and the team decides to build it for production, a new
production-tier effort must be created. The PoC findings inform the new effort; the
PoC code does not become production code.

The new effort goes through the full process: requirements documented, design validated
via `forge:arch-review`, implementation against approved spec, full CI review passing,
QA sign-off. This is not bureaucratic overhead — it is the process that catches the
security vulnerabilities, missing test coverage, and standards violations that PoC code
routinely contains.

The PoC's `.state.json` records the spawned production effort under `spawnedWorkItems`
when the new effort is created, maintaining the lineage for traceability.

**This boundary is structural, not advisory.** A PoC effort marked `productionBound: false`
will not have `forge:review` as a required PR status check. Attempting to merge PoC
code to a production branch should be flagged at the CI level. The system does not
prevent this absolutely — a determined engineer can always bypass — but it makes the
intent explicit and the path of least resistance correct.

### `.state.json` for Lightweight Efforts

Lightweight efforts (patch, refactor, extension, PoC) still use `.state.json` for
identity, hierarchy, and state tracking. The schema is the same; the difference is
which phase fields are populated. A patch effort may have only `implementation` phase
data and an empty `discovery` phase. This is expected and valid — absent phase data
means the phase was not required for this effort type, not that it was skipped.

The `productionBound` field is set at creation and must not be changed after the
effort's first commit.

## Cross-Repository Information Flow

### Reference Format (TR-4)

All cross-repo references use a consistent format stored in `.state.json`:

```json
{
  "coordinationRef": {
    "repo": "org/coordination-repo",
    "effortId": "favorite-stores",
    "branch": "main",
    "commitSha": "a1b2c3d4e5f6",
    "projectedAt": "2026-03-27T10:00:00Z",
    "projections": [
      {
        "source": ".forge/efforts/favorite-stores/requirements/business.md",
        "local": ".forge/efforts/favorite-stores-backend/requirements/projected-business.md",
        "sourceSha": "a1b2c3d4e5f6"
      },
      {
        "source": ".forge/efforts/favorite-stores/plan/plan.md",
        "local": ".forge/efforts/favorite-stores-backend/plan/projected-plan.md",
        "sourceSha": "a1b2c3d4e5f6"
      }
    ]
  }
}
```

### Downward Propagation (TR-5)

When `forge:project` (or its conversational equivalent: "let's start the backend work
for favorite-stores") runs:

1. **Fetch coordination artifacts** via GitHub API:
   ```
   gh api repos/org/coordination-repo/contents/.forge/efforts/favorite-stores/requirements/business.md
   ```
   Decode base64 content. Repeat for each artifact to be projected.

2. **Scope the projection.** The skill reads the coordination plan to identify which
   sections are relevant to this deployable. For requirements, it extracts the subset
   that applies to this repository. For the plan, it extracts the entries assigned to
   this deployable.

3. **Materialize with provenance headers.** Each projected file is written with a
   metadata header:
   ```markdown
   <!-- forge:projection
     source_repo: org/coordination-repo
     source_effort: favorite-stores
     source_file: .forge/efforts/favorite-stores/requirements/business.md
     source_commit: a1b2c3d4e5f6
     projected_at: 2026-03-27T10:00:00Z
   -->

   # Business Requirements (Projected from favorite-stores)

   [Scoped content relevant to this deployable...]
   ```

4. **Scaffold the local sub-effort** with `.state.json` containing `coordinationRef`
   and `parentId` pointing to the coordination effort. Register in `.forge/efforts/README.md`.

5. **Commit** the projected artifacts, `.state.json`, and registry update atomically.

### Upward Propagation (TR-6)

When local work reveals a coordination-level change is needed:

1. **Conversational trigger:** Engineer says "the API contract needs a new field that
   the coordination effort doesn't know about." Claude recognizes this as an upstream
   change event (via CLAUDE.md intent patterns).

2. **Record locally.** Claude writes a change proposal in the local effort:
   ```
   .forge/efforts/favorite-stores-backend/upstream-proposals/001-add-store-id-field.md
   ```
   The proposal describes what needs to change and why.

3. **Update state.** `.state.json` records the pending upstream proposal:
   ```json
   {
     "upstreamProposals": [
       {
         "id": "001",
         "file": "upstream-proposals/001-add-store-id-field.md",
         "status": "proposed",
         "targetRepo": "org/coordination-repo",
         "targetFile": ".forge/efforts/favorite-stores/spec/api/favorites-api.yaml",
         "prUrl": null
       }
     ]
   }
   ```

4. **Optionally create PR.** If the engineer has write access to the coordination repo
   (or can fork), `forge:upstream` creates a PR:
   ```
   gh pr create --repo org/coordination-repo --title "..." --body "..."
   ```
   The PR URL is recorded in the proposal's `prUrl` field.

5. **Track resolution.** The SessionStart hook checks the status of upstream proposals
   and reports whether they've been merged, are still open, or were rejected.

### Staleness Detection (TR-14)

The SessionStart hook checks projection freshness:

1. For each projection in `coordinationRef.projections`, read the `sourceSha`
2. Query the coordination repo's current HEAD for the source file:
   ```
   gh api repos/org/coordination-repo/commits?path=<source_file>&per_page=1
   ```
3. Compare the latest commit SHA against `sourceSha`
4. If different: emit a staleness warning in the session context
5. If the API call fails (offline, permissions): skip silently — the local projection
   remains usable

---

## State Management

### .state.json Schema Extensions

The forge-workflow effort extends the base `.state.json` schema with:

```json
{
  "subtype": "patch | refactor | extension | poc",  // TR-0: lightweight effort classification
  "productionBound": true,          // TR-0: false for poc subtype only; immutable after first commit
  "spawnedWorkItems": [],           // TR-0: production efforts spawned from this PoC
  "coordinationRef": { ... },       // TR-4: cross-repo reference (local sub-efforts)
  "upstreamProposals": [ ... ],     // TR-6: pending upstream changes
  "phases": {
    "discovery": {
      "postApprovalModifications": [ // TR-9: tracked modifications
        {
          "file": "requirements/business.md",
          "modifiedDuringPhase": "implementation",
          "modifiedAt": "2026-03-27T14:30:00Z"
        }
      ]
    }
  },
  "graduation": {                   // TR-12: graduation tracking
    "graduated": false,
    "graduatedAt": null,
    "graduatedTo": []               // ["deployables/forge-plugin", "products/forge"]
  }
}
```

### Merge-Friendly Design (TR-13)

**`.state.json` formatting rules:**
- Keys sorted alphabetically at every level
- Arrays formatted one item per line
- Consistent 2-space indentation
- No trailing commas (standard JSON)

**Why this helps:** Two engineers adding different ADRs to the `adrsCreated` array will
each add a line in a different position. With one-item-per-line formatting, git can
auto-merge these additions. Two engineers updating different phase statuses will modify
different key paths — these merge cleanly because JSON keys at the same nesting level
are on different lines.

**`.forge/efforts/README.md` formatting rules:**
- One effort per table row, one row per line (no line wrapping)
- Rows sorted by effort ID (or by hierarchy position)
- Additions are new lines; removals are line deletions; updates are in-place edits to
  a single line

---

## Conversational Flow Examples

### Example 1: Starting a new effort

**Engineer:** "We need to build a favorites feature for stores. It'll need changes to
the backend, iOS app, and Android app."

**What Claude does (guided by CLAUDE.md):**
1. Recognizes scope statement → identifies three deployables
2. Reads `.forge/efforts/README.md` to check for existing efforts
3. Creates `.forge/efforts/favorite-stores/` with scaffolded directories
4. Creates `.state.json` with type: initiative, tier: full, deployables listed
5. Updates `.forge/efforts/README.md` with new row
6. Commits atomically
7. Responds naturally, confirming the effort was created and asking about requirements

**PostToolUse hook fires:** Updates `.state.json` artifact inventory (redundant with
skill's own update — hook is idempotent).

### Example 2: Capturing an architectural decision mid-conversation

**Engineer:** "Actually, let's use Redis for the favorites cache instead of DynamoDB.
It's simpler and we already have a Redis cluster."

**What Claude does:**
1. Recognizes decision statement → ADR creation
2. Reads `.state.json` to get current effort and ADR count
3. Creates `spec/arch-decisions/ADR-001-redis-for-favorites-cache.md` with context,
   decision, alternatives (DynamoDB), and rationale (simplicity, existing infrastructure)
4. Commits with `docs(favorite-stores): ADR-001 use Redis for favorites cache`

**PostToolUse hook fires:** Appends ADR to `adrsCreated` in `.state.json`.

### Example 3: Resuming work in a new session

**SessionStart hook fires:** Reads `.forge/efforts/README.md`, finds `favorite-stores` effort in
discovery phase. Emits context:

```
## Forge — Active Workflow Context

**Current effort:** favorite-stores (initiative)
**Phase:** discovery (in_progress)
**Artifacts:** requirements ✓, ADR-001 ✓, API spec (absent), storage schema (absent)
**Next suggested action:** Design the favorites API specification.
```

**Engineer:** "Let's pick up where we left off."

**Claude:** Already has full context from the hook. Proceeds to design the API spec.

### Example 4: Implementation verification before PR

**Engineer:** "All tasks are done. Let's verify before I open the PR."

**What Claude does:**
1. Recognizes verification request → launch `forge:verify` as isolated sub-agent
2. Sub-agent reads all discovery artifacts (requirements, spec, ADRs, test strategy)
   and traverses the implementation to check coverage
3. Sub-agent returns a structured report: each requirement confirmed delivered or
   flagged as a gap, with specific code locations for any gaps found
4. Claude presents the verification report — if gaps exist, implementation resumes;
   if clean, engineer proceeds to open the PR

**Why isolated:** Verification reads the full discovery artifact set plus the codebase.
Running in the main session would consume context needed for the subsequent implementation
or PR work.

### Example 5: Closing an effort after QA

**Engineer:** "QA passed and the PR is merged. Let's close this effort out."

**What Claude does:**
1. Recognizes graduation trigger — crucially, this follows QA sign-off, not just
   task completion. Graduation is the final step after verification, review, and QA.
2. Reads `.state.json` to confirm all phases complete (implementation, verification,
   review, QA)
3. Reads post-approval modifications (if any) and flags them for reconciliation
4. Launches `forge:graduate` as an isolated sub-agent
5. Sub-agent reads effort artifacts and existing deployable docs
6. Sub-agent merges effort artifacts into `deployables/favorites-backend/`
7. Sub-agent updates `.state.json` with graduation record
8. Sub-agent removes effort from `.forge/efforts/README.md`
9. Returns graduation report to main session
10. Claude presents summary: "Favorites effort graduated. Deployable docs updated.
    2 post-approval modifications were reconciled."

**Note on sequencing:** Graduation is not triggered by "all tasks done" or by "PR
merged" alone. The trigger is the engineer explicitly closing the effort after QA
confirms the feature is working correctly in the pre-production environment.

---

## Requirement Traceability

| Requirement | Mechanism |
|-------------|-----------|
| BR-1: Guided path | SessionStart hook (next action), CLAUDE.md (behavioral rules) |
| BR-2: Automatic placement | CLAUDE.md taxonomy routing rules |
| BR-3: Surface modifications | PreToolUse phase-context hook (informational), PostToolUse state tracking |
| BR-4: Readable state at session start | SessionStart inject-workflow-context hook |
| BR-5: Cross-session survival | `.state.json` persistence, forge:pause/resume |
| BR-6: Scale to complexity | Tiering in `.state.json`, CLAUDE.md phase requirements per tier |
| BR-7: Reconcile before graduation | PostToolUse tracks post-approval mods; forge:graduate reconciles |
| BR-8: Readable hierarchy | `.forge/efforts/README.md` registry with indented hierarchy |
| BR-9: Dual audience | Markdown artifacts (human-readable) with structured metadata (machine-parseable) |
| BR-10: Multi-repo coordination | forge:project (downward), forge:upstream (upward), coordinationRef in state |
| BR-11: No required commands | CLAUDE.md intent patterns, PostToolUse auto-state, conversational graduation |
| BR-12: Graduation to canonical docs | forge:graduate skill, provenance metadata, coherent merge |
| TR-0: Effort subtype and production-bound declaration | `.state.json` subtype + productionBound fields; forge:effort prompts at creation |
| TR-1: Machine-readable state | `.state.json` schema |
| TR-2: Single-file registry | `.forge/efforts/README.md` |
| TR-3: Branching strategy | Deferred to dedicated effort |
| TR-4: Cross-repo references | `coordinationRef` in `.state.json` |
| TR-5: Materialized projections | forge:project with provenance headers |
| TR-6: Upward propagation | forge:upstream, upstream-proposals directory, PR creation |
| TR-7: Deployable-scoped plan | Coordination plan structure with deployable assignments |
| TR-7a: Task type and wave annotations | `plan/tasks.md` format, `forge:plan` generation, PostToolUse completion tracking |
| TR-8: Phase context hooks | PreToolUse phase-context.sh (inform, never block) |
| TR-9: Post-approval tracking | PostToolUse update-workflow-state.sh |
| TR-10: CLAUDE.md navigator | Forge-managed section in root CLAUDE.md |
| TR-11: Session start injection | SessionStart inject-workflow-context.sh |
| TR-10a: Implementation quality loop | Per-task loop in implementation skills; escalation to engineer at iteration limit |
| TR-11a: Design validation report + HTML presentation | forge:arch-review worker skill |
| TR-12: Graduation operation | forge:graduate worker skill (after QA, not after task completion) |
| TR-13: Merge-friendly state | Sorted keys, one-item-per-line arrays, one-row-per-line registry |
| TR-14: Staleness detection | SessionStart hook, coordinationRef.sourceSha comparison |
| TR-15: Conversational intent | CLAUDE.md intent patterns, UserPromptSubmit routing, PostToolUse auto-state |
