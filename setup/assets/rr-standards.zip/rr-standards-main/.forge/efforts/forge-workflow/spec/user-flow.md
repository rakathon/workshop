# User Flow: From Product Brief to Validated Implementation

This document traces a single engineer working through a complete Forge workflow —
receiving a product requirements brief and delivering a validated implementation —
using only natural conversation with Claude Code. No Forge commands are explicitly
invoked at any point.

**Scenario:** Add a "Favorite Stores" feature to the Rewards backend API service,
allowing members to save, retrieve, and remove stores from a personal favorites list.
The PM has written a product brief and handed it to engineering.

---

## Session 1: Receiving the Brief and Extracting Requirements

### Session Start

The engineer opens Claude Code in the rewards-backend repository.

**SessionStart hook fires.**

```
## Forge — Active Workflow Context

No active efforts found in this repository.

The .forge/ directory is initialized. When you're ready to start a new piece of
work, describe what you need to build and Forge will scaffold the effort.
```

---

### Starting the Work

**Engineer:**
> "We've got a new feature to build. The PM sent over a brief for Favorite Stores —
> members should be able to save stores they visit often and get them back quickly.
> Here's the document: [pastes PRD]"

**PRD content (abbreviated):**
```
Title: Favorite Stores
Goal: Allow members to bookmark stores for quick access
User stories:
  - As a member, I can add a store to my favorites
  - As a member, I can view my list of favorite stores
  - As a member, I can remove a store from my favorites
  - As a member, my favorites persist across sessions and devices
Constraints:
  - Max 50 favorites per member
  - Must work offline (cached on device)
  - Response time < 200ms for favorites retrieval
Out of scope: Store recommendations based on favorites (future work)
```

**Claude Code does:**
1. Recognizes scope statement with a PRD attached → new effort
2. Reads `.forge/efforts/README.md` — no active efforts
3. Scaffolds `.forge/efforts/favorite-stores/` with `.state.json`, `requirements/`,
   `spec/`, `validation/`, `plan/` directories
4. Registers effort in `.forge/efforts/README.md`
5. Begins extracting business requirements from the PRD

**Artifacts created:**
```
.forge/efforts/favorite-stores/.state.json          (created)
.forge/efforts/README.md                                     (updated)
```

**PostToolUse hook fires:** Updates registry row — `favorite-stores | discovery | in_progress`.

**Claude responds:**
> "I've started a new effort for Favorite Stores. Let me extract the business
> requirements from this brief.
>
> A few questions before I write them up: Should removing a favorite be soft-delete
> (recoverable) or hard-delete? And does the 50-store limit apply per-member globally,
> or per region?"

---

### Business Requirements Extraction

**Engineer:**
> "Hard delete is fine. The limit is global per member — same 50 stores regardless
> of region."

**Claude Code does:**
1. Has the PRD and clarification answers in context
2. Writes business requirements to canonical path

**Artifact created:** `.forge/efforts/favorite-stores/requirements/business.md`

```markdown
# Business Requirements

### BR-1: Members Can Save Stores as Favorites
Members must be able to add any store to a personal favorites list. A store may only
appear once in a member's favorites list.

### BR-2: Members Can Retrieve Their Favorites List
Members must be able to retrieve their full favorites list. The list must be consistent
across all devices and sessions — a favorite added on mobile must appear on web.

### BR-3: Members Can Remove Favorites
Members must be able to remove a store from their favorites list. Removal is permanent.

### BR-4: Favorites List Is Bounded
A member's favorites list is limited to 50 stores. Attempts to add a 51st store must
be rejected with a clear error. The limit is global per member, not per device or region.

### BR-5: Favorites Retrieval Must Be Fast
The favorites list must be retrievable in under 200ms. This supports offline-capable
clients that cache the list on-device and must be able to refresh it quickly on reconnect.
```

**PostToolUse hook fires:** Updates `.state.json` — `requirements.business: "present"`.

---

## Session 2: Technical Requirements and Specification

The engineer returns the next morning.

**SessionStart hook fires.**

```
## Forge — Active Workflow Context

**Current effort:** favorite-stores (epic)
**Phase:** discovery (in_progress)
**Tier:** full | **Risk:** R2

**Artifacts:**
- requirements/business.md ✓
- requirements/technical.md (absent)
- spec/ (empty)

**Next suggested action:** Derive technical requirements and begin specification.

**Open decisions:** none
```

---

### Deriving Technical Requirements

**Engineer:**
> "Let's think through the technical requirements. This is a backend API — the iOS
> and Android apps will consume it. We're using PostgreSQL for storage. We already
> have a Redis cluster for caching."

**Claude Code does:**
1. Recognizes technical discussion → derive technical requirements
2. Synthesizes from: business requirements + engineer's context (PostgreSQL, Redis,
   existing API patterns in the codebase)
3. Reads existing codebase context from `docs/codebase/STACK.md` and
   `docs/codebase/ARCHITECTURE.md` (brownfield context)

**Artifact created:** `.forge/efforts/favorite-stores/requirements/technical.md`

```markdown
# Technical Requirements

### TR-1: REST API for Favorites CRUD
Favorites operations must be exposed as REST endpoints consistent with the existing
Rewards API conventions: resource-oriented URLs, standard HTTP methods, JSON responses.

### TR-2: Member Identity from Auth Token
All favorites endpoints must be authenticated. Member identity must be derived from
the JWT token — no member ID in the request body or path for write operations.

### TR-3: Idempotent Add Operation
Adding a store that is already in favorites must succeed (HTTP 200) without creating
a duplicate. The response must indicate the store was already present.

### TR-4: PostgreSQL Storage with Redis Cache
Favorites must be stored in PostgreSQL as the system of record. The favorites list
must be cached in Redis with a TTL appropriate for the 200ms retrieval SLA. Cache
invalidation must occur on any write operation.

### TR-5: Capacity Limit Enforced at Write Time
The 50-store limit must be enforced atomically at the database layer. A race condition
where two concurrent add operations both pass a pre-check but together exceed the limit
must not be possible.

### TR-6: Pagination Not Required at Current Scale
The favorites list is bounded at 50 items. Pagination is not required. The list must
always be returned in full.
```

**PostToolUse hook fires:** Updates `.state.json` — `requirements.technical: "present"`.

---

### API Specification

**Engineer:**
> "Let's design the API. I'm thinking three endpoints: add, remove, and list."

**Claude Code does:**
1. Recognizes design discussion → create API spec
2. Reads `requirements/business.md` and `requirements/technical.md` for constraints
3. Reads existing API contracts in the codebase for conventions
4. Checks `plugins/forge/standards/api/rest.md` for API design standards

**Artifact created:** `.forge/efforts/favorite-stores/spec/api/favorites-api.yaml`

```yaml
# Favorites API Contract
# OpenAPI 3.1

paths:
  /v1/members/me/favorites:
    get:
      summary: List member's favorite stores
      security: [bearerAuth: []]
      responses:
        200:
          content:
            application/json:
              schema:
                type: object
                properties:
                  favorites:
                    type: array
                    items: { $ref: '#/components/schemas/FavoriteStore' }
                  total: { type: integer }
    post:
      summary: Add store to favorites
      requestBody:
        content:
          application/json:
            schema:
              properties:
                storeId: { type: string }
      responses:
        200: { description: Store already in favorites }
        201: { description: Store added to favorites }
        409: { description: Favorites list is full (50 stores) }

  /v1/members/me/favorites/{storeId}:
    delete:
      summary: Remove store from favorites
      responses:
        204: { description: Store removed }
        404: { description: Store not in favorites }
```

**PostToolUse hook fires:** Updates `.state.json` — `spec.api: "present"`.

---

### Storage Schema

**Engineer:**
> "What should the schema look like?"

**Claude Code does:**
1. Recognizes design discussion → create storage schema
2. Applies TR-4 (PostgreSQL + Redis), TR-5 (atomic capacity check)

**Artifact created:** `.forge/efforts/favorite-stores/spec/storage/favorites-schema.md`

```markdown
# Storage Schema: Favorites

## PostgreSQL

### Table: member_favorites
| Column       | Type        | Constraints                    |
|--------------|-------------|-------------------------------|
| id           | UUID        | PK, default gen_random_uuid() |
| member_id    | UUID        | NOT NULL, FK members.id       |
| store_id     | VARCHAR(64) | NOT NULL                      |
| created_at   | TIMESTAMPTZ | NOT NULL, default now()       |

Unique constraint: (member_id, store_id)
Check constraint: enforced via trigger — count per member_id must not exceed 50

## Redis Cache
Key: `favorites:{member_id}`
Value: JSON array of FavoriteStore objects
TTL: 300 seconds
Invalidated on: any write to member_favorites for that member_id
```

**PostToolUse hook fires:** Updates `.state.json` — `spec.storage: "present"`.

---

### Architectural Decision

**Engineer:**
> "I think we should enforce the 50-store cap with a database trigger rather than
> in application code. That way it's guaranteed even if we add another write path later."

**Claude Code does:**
1. Recognizes architectural decision → write ADR immediately

**Artifact created:** `.forge/efforts/favorite-stores/spec/arch-decisions/ADR-001-capacity-limit-via-db-trigger.md`

```markdown
# ADR-001: Enforce Favorites Capacity Limit via Database Trigger

**Status:** Accepted
**Created by:** favorite-stores
**Date:** 2026-03-29

## Context
The favorites list is bounded at 50 stores per member (BR-4, TR-5). The limit must
be enforced atomically and must hold regardless of how many write paths exist now
or in the future.

## Decision
Enforce the 50-store capacity limit via a PostgreSQL BEFORE INSERT trigger on
member_favorites. The trigger counts existing rows for the member and raises an
exception if the count is already at 50.

## Alternatives Considered
**Application-layer check:** Count rows before insert in service code. Rejected —
subject to race conditions under concurrent writes and not enforced if new write
paths are added without updating the check.

## Consequences
- Limit is guaranteed at the database level regardless of application code
- Application must handle the trigger exception and translate it to HTTP 409
- Trigger adds a small overhead to insert operations (acceptable at this scale)
```

**PostToolUse hook fires:** Updates `.state.json` — appends `ADR-001` to `adrsCreated`.

---

## Session 3: Architecture Review, Planning, and Test Design

**SessionStart hook fires.**

```
## Forge — Active Workflow Context

**Current effort:** favorite-stores (epic)
**Phase:** discovery (in_progress)
**Tier:** full | **Risk:** R2

**Artifacts:**
- requirements/business.md ✓
- requirements/technical.md ✓
- spec/api/favorites-api.yaml ✓
- spec/storage/favorites-schema.md ✓
- spec/arch-decisions/ADR-001 ✓

**Discovery appears complete.** All expected artifact types are present.
**Next suggested action:** Run forge:arch-review to validate the design before
advancing to planning.
```

---

### Architecture Review

**Engineer:**
> "Discovery looks good. Let's prepare the architecture review."

**Claude Code does:**
1. Recognizes arch review trigger → launches `forge:arch-review` as isolated sub-agent
2. Sub-agent reads all discovery artifacts and all applicable standards
3. Sub-agent produces two artifacts

**Artifacts created:**
```
.forge/efforts/favorite-stores/validation/report.md       (created)
.forge/efforts/favorite-stores/validation/arch-review.html (created)
```

**PostToolUse hook fires:** Parses overall result from report.md — records
`phases.validation.result: "PASS WITH CONCERNS"`.

**Report summary returned to main session:**

```
Architecture Review: favorite-stores
Result: PASS WITH CONCERNS

API Contract (api/rest.md)
  ✓ Resource naming correct (/favorites uses noun form)
  ✓ Auth required on all endpoints
  ⚠ CONCERN: POST /favorites returns 200 for duplicate add. Standard expects 200 for
    idempotent operations to indicate the state is already correct — acceptable here
    but should be documented in the API spec to avoid ambiguity for consumers.
  ✗ FAIL: 409 response body missing required `code` field per error response standard.

Data Model (storage/relational.md)
  ✓ UUID primary key
  ✓ TIMESTAMPTZ for timestamps
  ⚠ CONCERN: FK to members.id has no ON DELETE CASCADE specified. If a member is
    deleted, orphaned favorites rows will remain. Retention intent should be stated.

Security (security/owasp.md, security/auth.md)
  ✓ Member identity from JWT, not from request body
  ✓ No member ID exposed in list response
  ✓ No SQL injection risk (parameterized queries in schema)

Privacy (privacy/pii-handling.md)
  ✓ store_id is not PII
  ✓ No PII stored in member_favorites table

Requirements Traceability
  ✓ BR-1 through BR-5: all covered by API endpoints + storage schema
  ✓ TR-1 through TR-6: all addressed in spec artifacts

Failures: 1  |  Concerns: 2  |  Notes: 0
```

**Engineer:**
> "The 409 error body issue is valid — let's fix the API spec to add the `code` field.
> The cascade question is a good catch, I'll add a note. The 200/201 concern is
> intentional design, I'll document it."

**Claude Code does:**
1. Updates `spec/api/favorites-api.yaml` to add `code` field to 409 response body
2. Updates `spec/storage/favorites-schema.md` to document FK deletion behaviour
3. Adds a note to the API spec clarifying the 200 for duplicate-add is intentional

**PreToolUse hook fires** (phase-context.sh) for spec edits:
Discovery phase is still in_progress — writes are typical. No notification needed.

**Engineer:**
> "Good. The FAIL is resolved and concerns are documented. Let's advance."

---

### Advancing Discovery to Planning (forge:promote ritual)

**Claude Code does:**
1. Recognizes advancement intent → runs forge:promote ritual for discovery → planning
2. **Checks artifact completeness:** business requirements ✓, technical requirements ✓,
   API spec ✓, storage schema ✓, ADR-001 ✓, validation/report.md ✓, result is not FAIL ✓
3. **Presents phase summary:**

```
Discovery Phase Summary — favorite-stores

Artifacts produced:
  requirements/business.md      5 business requirements
  requirements/technical.md     6 technical requirements
  spec/api/favorites-api.yaml   3 endpoints (GET, POST, DELETE)
  spec/storage/favorites-schema.md  PostgreSQL table + Redis cache
  spec/arch-decisions/ADR-001   Capacity limit via DB trigger

Architecture review: PASS WITH CONCERNS (all concerns addressed)
Risk classification: R2
Open decisions: none

Confirm advancement to planning?
```

**Engineer:**
> "Confirmed."

**Claude Code does:**
1. Commits `.state.json` with `phases.discovery.status: "approved"`,
   `currentPhase: "planning"`, approver and timestamp recorded
2. Updates `.forge/efforts/README.md` registry row

```
chore(favorite-stores): promote discovery to planning
```

---

### Implementation Plan

**Engineer:**
> "Let's break this into tasks."

**Claude Code does:**
1. Reads all discovery artifacts to derive tasks
2. Derives dependency waves from task relationships
3. Annotates each task with execution type

**Artifact created:** `.forge/efforts/favorite-stores/plan/tasks.md`

```markdown
# Implementation Plan: Favorite Stores

## Wave 1 — Foundation (no dependencies)
- [ ] [auto][wave:1] Create migration: member_favorites table + capacity trigger (TASK-001)
- [ ] [auto][wave:1] Create migration: Redis cache key conventions + TTL config (TASK-002)

## Wave 2 — Repository Layer (depends on Wave 1)
- [ ] [tdd][wave:2] Implement FavoritesRepository: add, remove, list, capacity check (TASK-003)
- [ ] [auto][wave:2] Implement Redis cache: get, set, invalidate (TASK-004)

## Wave 3 — Service Layer (depends on Wave 2)
- [ ] [tdd][wave:3] Implement FavoritesService: orchestrates repository + cache (TASK-005)

## Wave 4 — API Layer (depends on Wave 3)
- [ ] [auto][wave:4] Implement GET /v1/members/me/favorites (TASK-006)
- [ ] [auto][wave:4] Implement POST /v1/members/me/favorites (TASK-007)
- [ ] [auto][wave:4] Implement DELETE /v1/members/me/favorites/{storeId} (TASK-008)
- [ ] [checkpoint][wave:4] Wire auth middleware to member identity extraction — confirm
  token claim name with auth team before implementing (TASK-009)

## Wave 5 — Integration (depends on Wave 4)
- [ ] [tdd][wave:5] Integration tests: full request/response cycle for all three endpoints (TASK-010)
- [ ] [auto][wave:5] Error path tests: capacity exceeded, store not found, unauthenticated (TASK-011)
```

**PostToolUse hook fires:** Updates `.state.json` — `phases.planning.status: "in_progress"`.

---

### Test Strategy

**Engineer:**
> "Let's write up the test strategy before we start coding."

**Artifact created:** `.forge/efforts/favorite-stores/spec/test-strategy.md`

```markdown
# Test Strategy: Favorite Stores

## Unit Tests

### FavoritesRepository
- Add store: success, duplicate (idempotent), capacity exceeded (51st store)
- Remove store: success, store not in favorites
- List: empty list, partial list, full list (50 items)
- Capacity trigger: concurrent adds that would both pass a pre-check

### FavoritesService
- Cache hit path: returns cached result, does not query database
- Cache miss path: queries database, populates cache
- Write path: updates database, invalidates cache

## Integration Tests

### API Contract (happy paths)
- GET favorites: 200 with correct schema
- POST favorites: 201 on first add, 200 on duplicate
- DELETE favorites: 204 on success

### API Contract (error paths)
- POST with full list (50 stores): 409 with error body including `code` field
- DELETE for store not in favorites: 404
- Any endpoint without auth token: 401

### Performance
- GET favorites with cold cache: must complete within 200ms (TR-5)
- GET favorites with warm cache: must complete within 50ms

## Acceptance Criteria (QA verification)
Each business requirement must be tested end-to-end in the pre-production environment:
- BR-1: Add store, verify it appears in subsequent GET
- BR-2: Add on one device, retrieve from another (different auth token, same member)
- BR-3: Remove store, verify it no longer appears in GET
- BR-4: Add 50 stores, attempt 51st, verify 409
- BR-5: Measure GET response time under realistic load
```

---

### Advancing Planning to Implementation (forge:promote ritual)

**Engineer:**
> "Plan looks good. Let's start building."

**Claude Code does:**
1. Recognizes advancement intent → runs forge:promote ritual for planning → implementation
2. **Checks artifact completeness:** `plan/tasks.md` present with 11 tasks across 5 waves ✓
3. **Presents phase summary:**

```
Planning Phase Summary — favorite-stores

plan/tasks.md: 11 tasks across 5 waves
  Wave 1: 2 tasks (auto) — foundation migrations
  Wave 2: 2 tasks (tdd + auto) — repository + cache layers
  Wave 3: 1 task (tdd) — service layer
  Wave 4: 4 tasks (auto + checkpoint) — API layer
  Wave 5: 2 tasks (tdd + auto) — integration tests

Checkpoint: TASK-009 requires auth team confirmation before implementation.

Confirm advancement to implementation?
```

**Engineer:**
> "Yes, let's go."

**Claude Code commits** checkpoint commit: `chore(favorite-stores): promote planning to implementation`

---

## Session 4: Implementation — Wave 1 and 2

**SessionStart hook fires.**

```
## Forge — Active Workflow Context

**Current effort:** favorite-stores (epic)
**Phase:** implementation (in_progress)

**Progress:**
- Wave 1: pending (2 tasks)
- Wave 2: pending (2 tasks, depends on Wave 1)
- Waves 3–5: pending

**Next action:** Begin Wave 1 tasks (TASK-001, TASK-002).
```

**Engineer:**
> "Let's start building. Wave 1 first."

---

### TASK-001: Database Migration

**PreToolUse hook fires** (inject-generation-standards.sh) before writing migration file.
Standards injected: `storage/relational.md`, `version-control/git.md`.

**Quality loop — iteration 1:**

1. **Implement:** Claude writes `db/migrations/YYYYMMDD_member_favorites.sql` with table,
   unique constraint, and capacity trigger per ADR-001 and the storage schema.
2. **Lint:** No linter configured for SQL files — step skipped.
3. **Validate against spec:** Migration matches `spec/storage/favorites-schema.md` columns,
   constraints, and trigger specification. ✓
4. **Run tests:** Migration integration test runs — table created, trigger fires correctly,
   51st insert rejected. ✓

All checks pass on iteration 1. Claude commits:
```
feat(favorite-stores): add member_favorites table and capacity trigger [TASK-001]
```

`plan/tasks.md` updated: `- [x] [auto][wave:1] ... (TASK-001) (a3f9b12)`

**PostToolUse hook fires:** Records completion in `.state.json`.

---

### TASK-002: Redis Configuration

Quality loop runs similarly — configuration validated against spec, no lint issues,
smoke test confirms connection. Committed. Wave 1 complete.

Claude notes Wave 2 is now unblocked.

---

### TASK-003: FavoritesRepository (TDD)

**[tdd] annotation** — tests must be written and failing before implementation begins.

**PreToolUse hook fires.** Standards injected: `testing/unit.md`, `storage/relational.md`.

**Quality loop — iteration 1:**

1. **Implement (RED phase):** Claude writes `FavoritesRepositoryTest.java` covering all
   scenarios from the test strategy. Runs tests — all 9 tests fail as expected (no
   implementation yet). RED confirmed.

2. **Implement (GREEN phase):** Claude writes `FavoritesRepository.java` to make tests
   pass. Runs tests — 8 of 9 pass. One test fails: concurrent capacity check test is
   non-deterministic without transaction isolation.

**Quality loop — iteration 2:**

1. **Implement:** Claude adds `@Transactional(isolation = SERIALIZABLE)` to the
   capacity-check method to handle concurrent writes correctly.
2. **Lint:** `checkstyle` reports one issue — missing Javadoc on the public `add()` method.
3. **Implement:** Claude adds the Javadoc.
4. **Lint:** Clean. ✓
5. **Validate against spec:** `add()` returns correct HTTP semantics, `remove()` throws
   correct exception for missing store, `list()` returns all rows. ✓
6. **Run tests:** All 9 tests pass. ✓

All checks pass on iteration 2. Claude commits:
```
feat(favorite-stores): implement FavoritesRepository with capacity enforcement [TASK-003]
```

`plan/tasks.md` updated: `- [x] [tdd][wave:2] ... (TASK-003) (c7e2d84)`

---

## Session 5: Implementation — Waves 3–4 and Checkpoint

**SessionStart hook fires.**

```
## Forge — Active Workflow Context

**Current effort:** favorite-stores
**Phase:** implementation (in_progress)

**Progress:**
- Wave 1: ✓ complete (TASK-001, TASK-002)
- Wave 2: TASK-003 ✓, TASK-004 pending
- Wave 3: not started
- Wave 4: not started (includes checkpoint: TASK-009)

**Next action:** Complete Wave 2 (TASK-004), then proceed to Wave 3.
```

Waves 3 and most of Wave 4 proceed conversationally. Each task is implemented, tested,
and committed. The engineer marks each complete.

---

### TASK-009: Checkpoint — Auth Middleware

**Engineer:**
> "I need to wire up the auth middleware but I'm not sure which claim in the JWT has
> the member ID. I need to check with the auth team."

**Claude Code does:**
1. Recognizes the checkpoint condition — external dependency before proceeding
2. Records the open decision in `.state.json`:

```json
"openDecisions": [
  {
    "id": "OD-001",
    "description": "JWT claim name for member ID — confirm with auth team",
    "blockedTask": "TASK-009",
    "raisedAt": "2026-03-29T11:30:00Z"
  }
]
```

**Claude:**
> "I've recorded that as an open decision. TASK-009 is blocked on the auth team's
> response. The other Wave 4 tasks (TASK-006, TASK-007, TASK-008) can proceed in
> parallel — they don't depend on TASK-009 until integration time."

The three API endpoint tasks proceed. Later the same session:

**Engineer:**
> "Auth team confirmed: the claim is `member_uuid`."

**Claude Code does:**
1. Recognizes decision resolution → clear open decision, implement TASK-009

```json
"openDecisions": []
```

TASK-009 implemented and committed.

---

## Session 6: Wave 5 — Integration Tests and Validation

**SessionStart hook fires.**

```
## Forge — Active Workflow Context

**Current effort:** favorite-stores
**Phase:** implementation (in_progress)

**Progress:** All waves complete except Wave 5 (integration tests).
**Open decisions:** none
**Next action:** Complete Wave 5 (TASK-010, TASK-011), then run verification.
```

**Engineer:**
> "Let's write the integration tests and then verify everything is working."

Integration tests written against the live test database following the test plan.
TASK-010 and TASK-011 implemented and committed.

---

### Implementation Verification

**Engineer:**
> "All tasks are done. Let's verify before I open the PR."

**Claude Code does:**
1. Recognizes verification request → launch isolated sub-agent for implementation
   verification (heavy operation, isolated to protect main session context)
2. Sub-agent reads:
   - `requirements/business.md` (5 BRs to verify)
   - `requirements/technical.md` (6 TRs to verify)
   - `spec/api/favorites-api.yaml` (API contracts to verify)
   - `spec/storage/favorites-schema.md` (schema to verify)
   - `spec/arch-decisions/ADR-001` (trigger to verify)
   - `plan/tasks.md` (all tasks marked complete)
   - Implementation code (traverses source tree)
3. Sub-agent checks each requirement against implementation

**Verification report returned to main session:**

```markdown
# Implementation Verification Report

**Result: PASS — implementation delivers stated goals**

## Business Requirements
- BR-1 (Add favorites): ✓ POST endpoint implemented, idempotent add confirmed
- BR-2 (Cross-device consistency): ✓ PostgreSQL as source of record, Redis cache
  invalidated on write — any device reading after write gets updated list
- BR-3 (Remove favorites): ✓ DELETE endpoint implemented, hard-delete confirmed
- BR-4 (50-store limit): ✓ Enforced via database trigger (ADR-001), 409 response
  implemented in service layer
- BR-5 (Fast retrieval): ✓ Cache-hit path implemented, Redis TTL configured at 300s

## Technical Requirements
- TR-1 (REST API): ✓ Three endpoints match OpenAPI spec
- TR-2 (Auth from token): ✓ member_uuid claim extracted in middleware, no member ID
  in request body
- TR-3 (Idempotent add): ✓ Duplicate add returns 200, not 201
- TR-4 (PostgreSQL + Redis): ✓ Both implemented per schema spec
- TR-5 (Atomic capacity check): ✓ Trigger enforces limit at database layer
- TR-6 (No pagination): ✓ Full list always returned

## Gaps Found
None.
```

**PostToolUse hook fires:** Updates `.state.json` — `phases.implementation.status: "complete"`.

---

## Session 7: Code Review and QA

**Engineer:**
> "Verification passed. Opening a PR."

Claude creates a well-formed PR description referencing the effort, all BRs addressed,
the API spec, and the verification report.

GitHub Actions triggers `forge:review` automatically. The AI review checks:
- REST API standards compliance ✓
- Security: auth on all endpoints ✓
- No PII in logs ✓
- Test coverage: unit + integration ✓

**Review result:** PASS. This is an R2 change — human reviewer approval also required.
Human reviewer approves. PR merged.

---

### QA Validation

After merge, the feature deploys to the pre-production environment.

**Engineer:**
> "Feature is in staging. Let's run QA."

**Claude Code does:**
1. Recognizes QA intent → reads test strategy acceptance criteria
2. Walks through each acceptance criterion against the staging environment

```
QA Execution: Favorite Stores

BR-1: Add store, verify in GET             ✓ PASS
BR-2: Add on one device, retrieve on web   ✓ PASS
BR-3: Remove store, verify absent in GET   ✓ PASS
BR-4: Add 50 stores, 51st returns 409      ✓ PASS
BR-5: GET favorites response time          ✓ PASS (avg 42ms cold, 18ms warm)

Performance: All responses under 200ms threshold

Defects found: 0

QA Result: PASS — ready for production
```

---

## Session 8: Closing the Effort

**Engineer:**
> "QA signed off. We're done with this effort."

**Claude Code does:**
1. Recognizes effort completion → initiate graduation
2. Launches `forge:graduate` as isolated sub-agent
3. Sub-agent reads full effort artifacts and current deployable docs
4. Sub-agent merges into `.forge/deployables/rewards-backend/`:
   - Requirements updated to reflect favorites capability
   - API spec added to deployable spec directory
   - Storage schema added
   - ADR-001 registered in deployable ADR index
5. `.state.json` updated: `graduated: true`
6. Effort removed from `.forge/efforts/README.md` registry

**Claude:**
> "Favorite Stores effort graduated. The rewards-backend deployable documentation
> has been updated with the favorites requirements, API contract, storage schema,
> and ADR-001. The effort record remains in `.forge/efforts/favorite-stores/` as
> a permanent history.
>
> 1 ADR promoted, 2 requirements documents promoted, 1 API spec promoted,
> 1 storage schema promoted, 1 test strategy promoted."

---

## What the Engineer Never Did

Throughout this flow the engineer:

- Never used a Forge slash command or skill invocation
- Never manually created a directory or chose a file path
- Never updated `.state.json` or `.forge/efforts/README.md`
- Never had to remember which phase they were in
- Never had to ask where a document should go
- Never had to look up how to structure a requirements file, ADR, or test plan

They described their work. Forge kept the record.
