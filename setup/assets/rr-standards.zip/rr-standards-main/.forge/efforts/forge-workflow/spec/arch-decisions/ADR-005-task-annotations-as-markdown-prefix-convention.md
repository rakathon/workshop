# ADR-005: Task Annotations Use Markdown Prefix Convention in plan/tasks.md

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

The local implementation plan (`plan/tasks.md`) needs to communicate two kinds of
machine-readable information about each task:

1. **Type** — how an executing agent should approach the task (proceed autonomously,
   pause for human decision, follow TDD discipline, or require manual human action).
2. **Wave** — which dependency group the task belongs to, enabling parallel execution
   of independent tasks within a wave.

Without this information, agents executing the plan must infer task type from
description text (unreliable) and must treat all tasks as sequential (slow). The format
chosen must be machine-parseable by skills (`forge:plan`, `forge:verify`, implementation
skills) while remaining readable in plain text by engineers.

Other workflow frameworks have made different choices about how to structure plan
artifacts, each with different tradeoffs between machine-readability, human-readability,
and maintenance overhead.

## Decision

Tasks in `plan/tasks.md` carry type and wave as inline prefix annotations using a
bracket convention:

```
- [ ] [auto][wave:1] Scaffold the database migration (TASK-001)
- [ ] [tdd][wave:2] Implement the repository layer (TASK-002)
- [ ] [checkpoint][wave:2] Wire auth middleware — confirm claim name first (TASK-003)
- [x] [auto][wave:1] Create Redis cache configuration (TASK-004) (a3f9b12)
```

Allowed type values: `[auto]`, `[checkpoint]`, `[tdd]`, `[manual]`.
Wave values: `[wave:N]` where N is a positive integer.

Completed tasks record the first 7 characters of the satisfying commit SHA inline.

`forge:plan` assigns both annotations to every task it generates. Implementation skills
parse these annotations to determine execution behavior. `forge:verify` uses wave
structure to understand the intended dependency ordering when checking implementation
completeness.

## Alternatives Considered

**XML task format (GSD approach).**
GSD uses structured XML for tasks with explicit `<name>`, `<files>`, `<action>`,
`<verify>`, and `<done>` elements. Rejected. XML is machine-parseable but is not
human-readable as plain text in a terminal or diff view. Engineers reading the plan
file should be able to scan it without parsing markup. The information density of XML
also makes the plan file harder to edit conversationally.

**JSONL routing files per task (Trellis approach).**
Trellis stores per-task context in `.trellis/tasks/{task}/implement.jsonl`. Rejected
for type and wave annotations specifically. JSONL is appropriate for spec routing (which
files to inject as context) but creates a maintenance burden for basic task metadata —
a separate file per task means the plan is no longer readable as a single document.
The JSONL approach is worth considering for spec context routing on R1/R2 work (as noted
in the Trellis learnings) but is the wrong format for plan task annotations.

**Separate machine-readable plan file alongside human-readable markdown.**
Two files: `plan/tasks.md` (human-readable) and `plan/tasks.json` (machine-readable).
Rejected. Two files that must stay in sync are two files that will diverge. The plan
is the source of truth; having two representations of it with no enforcement of
consistency creates confusion about which is canonical.

**YAML frontmatter in tasks.md.**
YAML frontmatter at the top of the plan file declaring task types and wave assignments
separately from the task list. Rejected. Frontmatter decouples the annotation from the
task it describes, making the file harder to read and edit. Inline annotations keep the
metadata co-located with the task.

**No annotations; infer from description text.**
Rejected. Description-based inference is unreliable — "Implement the auth middleware"
could be auto, checkpoint, or TDD depending on context. Agents that cannot reliably
determine when to pause will either pause too often (friction) or never (missed
checkpoints). Explicit annotations remove the ambiguity.

## Consequences

- All tools that read or write `plan/tasks.md` must implement the annotation parser.
  This is a stable, simple format but it is a format commitment — changing the
  convention later requires migrating existing plan files.
- The format is human-readable and diff-friendly. Adding a task, completing a task,
  or changing a wave assignment produces a minimal, legible diff.
- `forge:plan` is responsible for generating correct type and wave assignments.
  Incorrect assignments (a task that should be `[checkpoint]` marked `[auto]`) will
  cause agents to proceed autonomously through decisions that require human input.
  The assignment logic in `forge:plan` is the critical quality point.
- Completed task SHAs are recorded inline. This makes `plan/tasks.md` a lightweight
  traceability artifact — plan → code — without requiring engineers to cross-reference
  git log. It also enables `forge:verify` to identify which commits should be examined
  when checking implementation completeness.
