# ADR-006: PoC/Spike Code Does Not Become Production Code — A New Effort Is Required

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

Proof-of-concept and spike work items are declared non-production-bound at creation.
They are built with reduced compliance requirements: no mandatory security validation,
no privacy review, no test coverage requirements, and no blocking CI review. This
reduction is appropriate — demanding production-quality rigor for a two-day feasibility
prototype wastes engineering time on work that may be discarded entirely.

However, many production defects, security vulnerabilities, and architectural mistakes
originate as PoC code that "worked so well we just shipped it." The absence of tests,
the hardcoded credentials, the missing input validation, the unreviewed data handling —
all present in the PoC because the engineer correctly didn't bother with these for an
internal demo — become production liabilities when the code is promoted rather than
rewritten.

The question is: what mechanism prevents this? Options range from trusting engineers
to assess code quality themselves, to requiring a standards remediation pass before
PoC code can merge to a production branch, to requiring a completely new effort.

## Decision

PoC/spike code is never directly promoted to production. If the PoC proves the concept
and the team decides to build it as a production capability, a new production-tier
effort is created from scratch. The PoC's findings — what was learned, what approach
worked, what to avoid — inform the requirements and design of the new effort. The PoC
code serves as a reference implementation. The production effort re-implements against
an approved spec, with full test coverage and CI review.

This is recorded in `.state.json`:
- The PoC effort has `"productionBound": false`, immutable after the first commit
- When a production effort is created as a follow-on, the PoC records the new effort's
  ID under `spawnedWorkItems`
- The production effort records the PoC's ID under `parentId` or a `derivedFrom` field

`forge:review` is not registered as a required PR status check for PoC efforts. The
system does not absolutely prevent a PoC from being merged to a production branch —
a determined engineer can always bypass controls — but the path of least resistance
is correct: PoC code has no blocking CI review, so it should not be on a branch that
requires it.

## Alternatives Considered

**Trust engineers to assess PoC code quality and apply standards remediation themselves.**
Rejected. This is the status quo that produces the anti-pattern. Engineers under
delivery pressure will consistently underestimate the gap between PoC quality and
production quality. The decision to trust individual judgment on a systemic problem
has been made before and has not worked.

**Require a standards remediation pass before PoC code can merge to a production branch.**
Considered. The idea: PoC code can be upgraded in-place by running it through the
standards validation pipeline before promotion. Rejected for two reasons:
1. Remediation is not the same as proper design. Adding tests to PoC code verifies
   the PoC's behavior, not the correct behavior. Adding input validation to PoC code
   patches the most obvious issues without the systematic review that would catch
   the non-obvious ones.
2. It creates a well-trodden shortcut: engineers build a PoC, run remediation, and
   ship — having bypassed requirements documentation, design review, and the
   architecture review meeting that would have caught the fundamental problems in
   the approach.

**Require a formal conversion ritual that keeps the code but upgrades the work item.**
Considered. Marking the effort as production-bound after passing a validation gate.
Rejected. The problem with PoC code is rarely that specific functions are wrong; it
is that the overall architecture was designed for demonstration, not for production
operation. A function that fetches all records works fine in a demo with 10 records
and fails in production with 10 million. A new effort with a proper design phase
catches this. In-place remediation does not.

## Consequences

- Teams must budget for a follow-on production effort when PoC work succeeds. The
  PoC is not free if the concept proves viable — it is an investment that reduces
  risk in the production effort, not a shortcut to shipping.
- The production effort benefits from the PoC: known failure modes are documented,
  the approach is validated, the estimated complexity is grounded in real
  implementation experience rather than theoretical estimation. The new effort's
  discovery phase should be significantly more accurate as a result.
- PoC code is valuable as a reference implementation during the production effort's
  implementation phase. The implementation team can consult it. They should not copy
  it wholesale.
- Engineers who want to avoid this friction will be tempted to classify production
  work as a PoC to skip the process. This is the more dangerous failure mode — it
  should be addressed through team norms and engineering leadership, not through
  technical controls that make PoC classification difficult. Forge assumes good faith;
  it does not prevent deliberate misuse.
