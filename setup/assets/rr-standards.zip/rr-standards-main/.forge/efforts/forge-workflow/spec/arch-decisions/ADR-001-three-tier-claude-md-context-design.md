# ADR-001: Three-Tier CLAUDE.md Context Design

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

Forge needs to give Claude the knowledge to operate as a workflow agent — routing
artifacts to the correct locations, recognizing workflow events in conversation, and
understanding the state of in-flight work — without Claude having to explicitly invoke
commands to acquire that knowledge.

The root `CLAUDE.md` is loaded into Claude's context for the entire session and competes
with code, conversation history, and project-specific instructions. Engineers using Forge
will also have project-specific content they need in CLAUDE.md. A naive implementation
that puts all Forge guidance directly in CLAUDE.md would consume 25%+ of its usable
space before the project has said anything about itself.

Forge must balance two competing needs: enough context to function without explicit
commands, and enough remaining context budget for project-specific instructions to be
effective.

## Decision

Forge guidance is split across three tiers:

**Tier 1 — CLAUDE.md (~60-80 lines, always present):**
A forge-managed section containing only what Claude needs to understand the framework
and decide when to engage with it: what Forge is, what `.forge/` is for and its three
subdirectories (efforts, deployables, products), a terse intent recognition list (one
line per event type), and the before-write rule.

**Tier 2 — SessionStart hook output (~50-80 lines, injected fresh each session):**
The artifact routing table, current effort state, open decisions, pending upstream
proposals, staleness warnings, and active effort identification. This content is
detailed but not permanently loaded — it arrives at session start and may scroll back
in long sessions.

**Tier 3 — UserPromptSubmit hook output (~20-30 lines, on demand):**
Targeted re-injection of routing rules and current state when a workflow event is
detected in the engineer's prompt. Compensates for long sessions where Tier 2 content
has scrolled out of effective context.

## Alternatives Considered

**Put all routing rules and intent patterns in CLAUDE.md directly.**
Rejected. The full guidance (routing tables, verbose intent patterns, behavioral rules)
would require 120+ lines in CLAUDE.md — consuming ~25% of a typical project's context
budget before any project-specific content. Engineers with complex projects would find
the Forge section crowding out their own instructions.

**Use a separate `.forge/CLAUDE.md` file.**
Rejected. Claude Code does not automatically load subdirectory CLAUDE.md files. A
separate file would require the engineer to explicitly read it, which defeats the
always-on requirement. The SessionStart hook achieves the same injection without
requiring the engineer to know the file exists.

**Use an MCP server for dynamic guidance delivery.**
Rejected for the same reasons as ADR-017 (standards discoverability): introduces a
network dependency that fires on every session start, breaks co-versioning between
guidance content and skill behavior, requires infrastructure to maintain.

**Keep Tier 1 minimal (5-10 lines) as a pure pointer.**
Considered but rejected. If CLAUDE.md says only "see hook output for Forge guidance,"
Claude has no framework understanding before the hook fires and no grounding for
conversational intent recognition if the Tier 2 output has scrolled out. The 60-80
line budget for Tier 1 is the minimum that gives Claude a working mental model.

## Consequences

- The forge-managed CLAUDE.md section is compact and stable — it changes only when
  the fundamental Forge concepts change, not when routing tables or intent patterns
  are refined.
- Any future Forge feature adding guidance content must decide which tier it belongs
  to. Detailed operational content (specific paths, specific patterns) belongs in
  hook output. Conceptual content belongs in CLAUDE.md.
- Long sessions may lose Tier 2 routing context. The Tier 3 UserPromptSubmit hook
  compensates but cannot cover all cases. Engineers working in very long sessions on
  workflow-heavy work may occasionally need to re-orient Claude by asking for status.
- The split creates a dependency on SessionStart hook execution. If a session starts
  without the hook firing (e.g., in a non-standard Claude Code environment), Claude
  will have the conceptual model but lack the routing table. The terse intent list
  in Tier 1 provides a fallback that still supports conversational recognition, even
  without precise path routing.
