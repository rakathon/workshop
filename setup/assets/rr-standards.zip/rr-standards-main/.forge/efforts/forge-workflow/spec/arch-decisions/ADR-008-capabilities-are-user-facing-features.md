# ADR-008: Capabilities Are User-Facing Features, Not Architectural Layers

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

When planning the forge-workflow implementation, capabilities were incorrectly
named and scoped as architectural layers: `forge-workflow-core`, `forge-workflow-full`,
`forge-implementation`. These names describe how the code is organised internally
— tiers, packages, layers — rather than what the engineer does with them.

The existing capabilities (`forge-init`, `forge-pin`) demonstrate the correct
pattern implicitly, but this principle was not documented anywhere. An agent or
engineer without prior context will default to architectural naming unless the
principle is stated explicitly.

The mistake is consequential: a capability named after an architectural layer
groups things incorrectly (what belongs in "core" vs "full" is ambiguous and
changes over time), produces documentation that describes implementation rather
than value, and makes it harder for engineers to find the capability they need.

## Decision

A capability is a **user-facing feature** named after what it delivers to the
engineer. The name must answer the question: "what does an engineer *do* with
this?" — not "what architectural role does this play?"

This principle is encoded in three places so it is discoverable regardless of
how an engineer or agent arrives at the capabilities directory:

1. **The CLAUDE.md Tier 1 template** — the always-on guidance layer includes the
   capability definition and the counter-example in the `deployables/` explanation,
   so any agent working near a deployable has this context.

2. **`AGENTS.md` in the capabilities directory** — explicit navigation guide with
   the naming principle, a table of correct vs incorrect names, and instructions
   for creating a new capability.

3. **This ADR** — the decision record that explains why the principle exists and
   what failure it prevents.

**Examples of correct capability names:**

| Capability | What the engineer does |
|---|---|
| `forge-init` | Initialises a repository |
| `forge-effort` | Creates and tracks a work effort |
| `forge-arch-review` | Runs an architecture review |
| `forge-graduate` | Graduates a completed effort |

**Examples of incorrect capability names and why:**

| Bad name | Why it is wrong |
|---|---|
| `forge-workflow-core` | "core" describes an architectural tier, not a feature |
| `forge-workflow-full` | "full" describes a package level, not what the engineer does |
| `forge-validation-infrastructure` | "infrastructure" describes implementation, not value |
| `forge-phase-management` | "phase management" is a mechanism; the feature is `forge-promote` |

Names containing "core", "base", "infrastructure", "utils", "common", "full", "lite",
or "layer" are almost certainly wrong for a capability.

## Alternatives Considered

**Name capabilities after architectural tiers (core, full, etc.).**
This is the pattern that was accidentally used. Rejected because tier names are
unstable (what is "core" today may be split later), do not communicate user value,
and require the engineer to know the internal architecture to find what they need.

**Name capabilities after the package they belong to.**
Similar problem. Package groupings are implementation details; engineers look for
features, not packages.

**No naming principle — rely on context from existing examples.**
Rejected. Implicit patterns are not reliably learned by agents or new engineers.
The mistake that prompted this ADR happened with two correct examples (`forge-init`,
`forge-pin`) already visible. The principle must be stated, not inferred.

## Consequences

- Every new capability must pass the "what does an engineer do with this?" test
  before the name is accepted. This is a lightweight review that takes seconds.
- The CLAUDE.md template, the capabilities AGENTS.md, and this ADR must be kept
  consistent if the principle is ever refined.
- The incorrect capability names created during planning (`forge-workflow-core`,
  `forge-workflow-full`, `forge-implementation`) must not be used. The correct
  names (`forge-effort`, `forge-promote`, `forge-arch-review`, etc.) are documented
  in the forge-workflow implementation plan.
