# ADR-003: Cross-Repo Artifacts Are Materialized Projections, Not Live References

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

When an effort spans multiple repositories, coordination-level artifacts (user
requirements, system-level technical flows, the high-level plan) must be accessible
from each deployable's local repository. A backend engineer working on a local
sub-effort needs to see the relevant slice of the coordination-level requirements
without having to navigate to a separate repository.

Several mechanisms exist for making content from one git repository accessible in
another. Each has different tradeoffs around offline availability, maintenance overhead,
and how changes in the source are propagated to consumers.

## Decision

When a coordination effort spawns a local sub-effort via `forge:project`, the relevant
coordination-level artifacts are fetched via GitHub API, scoped to the content
applicable to this deployable, and written as real files in the local repository under
`.forge/efforts/<sub-effort-id>/`. These files are committed to the local repository.

Each projected file includes a provenance metadata header recording the source
repository, source effort ID, source file path, and the commit SHA of the source
artifact at the time of projection. This metadata enables staleness detection.

Upward propagation (local discoveries that require changes to coordination-level
artifacts) is handled separately via `forge:upstream`, which creates a change proposal
locally and optionally opens a pull request to the coordination repository.

## Alternatives Considered

**Git submodules.**
Rejected. Submodules require all contributors to run `git submodule update` after
cloning, create a complex DX for branching and updating, and were already rejected
for standards distribution in ADR-011. The same DX problems apply here.

**Symbolic links.**
Rejected. Symlinks do not survive cloning to a different machine, break on Windows,
and are invisible to engineers reading the file tree without following the link. A
projected file that is not actually readable locally provides no value.

**Live API fetch on every read.**
Rejected. Reading a coordination-level artifact would require network access to the
coordination repository at the moment the engineer or agent needs it. This breaks
offline workflows, adds latency to every artifact read, and creates a hard dependency
on the coordination repository being accessible. Forge is designed to function with
git as the only dependency.

**Reference-only pointer in state (URL + path, no local copy).**
Rejected. An engineer starting a session needs to be able to read the coordination
requirements without knowing to fetch them first. The SessionStart hook can emit
staleness warnings for materialized files; it cannot fetch live content without network
access at session start.

**Git subtrees.**
Rejected. Subtrees merge the upstream repository's history into the local repository,
which is incorrect for scoped projections — the local repository should not carry
the coordination repository's full commit history. Subtrees also make it non-obvious
which content comes from the coordination effort vs. the local effort.

## Consequences

- Projected artifacts are available offline immediately after `forge:project` runs.
  No network access is required to read them.
- Staleness is a known state, not an error. The provenance commit SHA enables the
  SessionStart hook to detect when the coordination-level artifact has changed since
  the projection was taken and surface this to the engineer.
- Projections may drift from the source. The staleness detection mechanism makes
  this drift visible, but it does not prevent it. Engineers must consciously decide
  to update a stale projection.
- Upward propagation is an explicit operation. Local discoveries that change
  coordination artifacts are not automatically reflected upstream — they require the
  engineer to create a proposal via `forge:upstream`. This is intentional: the
  coordination effort is the source of truth, and changes to it should be deliberate.
- The projected files are real commits in the local repository. They appear in git
  log and can be reviewed, blamed, and diffed like any other file. This provides an
  audit trail of what was known about coordination requirements at any point in the
  local effort's history.
