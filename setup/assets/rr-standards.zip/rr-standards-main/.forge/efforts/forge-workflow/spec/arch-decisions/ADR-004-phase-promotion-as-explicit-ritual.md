# ADR-004: Phase Promotion Is an Explicit Ritual Requiring Engineer Confirmation

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

The forge-workflow design has one meaningful phase gate: discovery must be approved
before implementation begins on a full-tier work item. The purpose of this gate is to
ensure that requirements and design are complete and coherent before engineering
resources are committed to building against them.

The question is what "approval" means mechanically. A state flag set when artifacts are
present is technically sufficient to enforce the gate. But it conflates two different
things: the artifacts existing and an engineer making an informed judgment that they are
ready.

The gate's value is not that it prevents implementation before files exist — it is that
it creates a moment of deliberate human judgment before a significant investment of
engineering effort. A system that advances automatically when artifact presence is
detected provides a gate but not the judgment.

## Decision

`forge:promote` is a defined ritual, not a state flag update. For the discovery →
planning transition, the ritual consists of five steps in sequence:

1. **Readiness check:** Verify all required discovery artifacts are present for the
   effort's tier. If any are absent, present the gap and stop without advancing.
2. **Post-approval surface:** List any artifacts modified after a prior approval cycle,
   if applicable.
3. **Phase summary:** Present a structured summary of what was produced — each artifact,
   each ADR, open decisions remaining, and the risk classification — for the engineer
   to review.
4. **Explicit confirmation:** Ask the engineer to confirm advancement. `forge:promote`
   must not advance on ambiguous input and must not advance without a response.
5. **Checkpoint commit:** Commit the phase transition to git with the approver and
   timestamp recorded in `.state.json`. This creates an auditable record of who
   approved discovery and when.

Other phase transitions (planning → implementation, implementation → verification, etc.)
follow the same pattern with phase-appropriate readiness checks.

## Alternatives Considered

**Automatic advancement when all required artifacts are detected.**
Rejected. Automatic advancement treats artifact presence as a proxy for readiness.
An engineer can have a `requirements/business.md` file with placeholder content and
a `spec/api/` directory with an incomplete contract. The files exist; the work is not
ready. The ritual's value is the human judgment step, not the existence check.

**Advisory promotion with no confirmation step.**
Considered as a lighter alternative. The skill would present a summary but allow
advancement without confirmation. Rejected because this is functionally identical
to automatic advancement — an agent running without a human present would always
advance. The confirmation step is the signal that a human has reviewed the summary.

**Simple yes/no confirmation without a phase summary.**
Considered. Asking "are you ready to advance to planning?" without showing what is
being approved is a lower-overhead alternative. Rejected because it gives the engineer
nothing to review. The phase summary is what makes the confirmation meaningful — it
surfaces the work product so the engineer can notice if something is missing or wrong
before implementation begins.

**Confirmation via a separate approval skill or command.**
Considered. Separating the summary presentation from the state transition, requiring
the engineer to run two operations. Rejected as unnecessary ceremony. A single ritual
skill with a confirmation step achieves the same outcome with less friction.

## Consequences

- Phase advancement always requires a human at the gate. Automated pipelines that call
  `forge:promote` must provide a mechanism for the confirmation signal, or must have
  advancement explicitly bypassed via a flag (which should require elevated permission
  to prevent casual bypass).
- The checkpoint commit provides a permanent record of who approved discovery and when.
  This satisfies audit requirements for regulated work and provides a reference point
  for post-mortems when implementation diverges from the approved design.
- The ritual adds a small amount of overhead to each phase transition. This is
  intentional — the gate should have friction proportional to its importance. The
  cost of the ritual is a few seconds of review; the cost of advancing a poorly
  reviewed discovery phase is measured in engineering days of rework.
- The readiness check in step 1 is a prerequisite, not the gate itself. Artifacts
  must exist before the ritual can run. The ritual's unique contribution is steps 3
  and 4 — the human review and confirmation.
