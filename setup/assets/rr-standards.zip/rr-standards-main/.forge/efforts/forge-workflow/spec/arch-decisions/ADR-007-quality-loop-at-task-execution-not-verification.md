# ADR-007: The Quality Loop Runs at Task Execution, Not at Verification

**Status:** Accepted
**Created by:** forge-workflow
**Date:** 2026-03-29

## Context

The workflow has two points where code quality can be assessed:

1. **During task execution** — after each task is implemented, before it is marked
   complete. The implementation skill has the changed files in context, the spec
   artifacts loaded, and a natural pause point before committing.

2. **At verification** — after all tasks complete, `forge:verify` assesses whether
   the full implementation delivers the effort's stated goals.

The question is: where does the automated quality loop (lint → spec validation → tests
→ address concerns → repeat) live? It could live in `forge:verify` (running the loop
after all implementation is declared done), in each implementation skill (running it
after each task), or in both.

## Decision

The quality loop runs inside each implementation skill, at task execution time. When
an implementation skill is working on a task, it loops — implement, lint, validate
against spec, run tests, address failures — until all checks pass or the iteration
limit (3 by default) is reached. The task is not committed and not marked complete
until the loop exits with all checks passing.

`forge:verify` is a single-pass analytical skill. It runs after all tasks are marked
complete and checks whether the aggregate implementation delivers the effort's stated
goals — not whether individual tasks are clean. It reads design artifacts and code, and
produces a structured report. It does not loop.

## Alternatives Considered

**Loop in forge:verify instead of in the implementation skill.**
Rejected. By the time `forge:verify` runs, all tasks are committed. Looping in
`forge:verify` means multiple rounds of additional implementation commits after the
implementation phase is nominally complete. This is confusing — implementation is
supposed to be done. It also means that lint errors and test failures from task 1
are discovered after task 10 is complete, when the engineer may no longer have the
context for task 1's changes.

**Loop in both forge:verify and in the implementation skill.**
Rejected as unnecessary redundancy. The per-task loop catches task-level correctness.
`forge:verify`'s value is in checking goal delivery and integration — semantic checks
that individual task loops cannot perform because they operate with limited context.
Adding a loop to `forge:verify` would conflate two different kinds of quality checks
and make `forge:verify`'s purpose ambiguous.

**No loop — run checks once per task and report without retrying.**
Rejected. A single-pass check that reports "test failure on line 42" and stops leaves
the engineer to manually re-run the implementation skill for a correction that the
skill could handle itself. The loop's purpose is to handle the predictable correction
cycle (implement → fix lint → fix test) autonomously, reserving engineer attention
for the corrections that require judgment.

**Loop with no iteration limit.**
Rejected. An uncapped loop is a runaway cost and quality risk. After two or three
correction iterations that haven't resolved all failures, the remaining failures
almost always require human judgment — a spec ambiguity, a design conflict, a missing
dependency. The loop continuing past this point wastes resources without improving
outcomes. Three iterations is the default; it is configurable per project.

## Consequences

- Task completion is a meaningful signal. When a task is marked complete with a commit
  SHA, it means the code compiled, linted cleanly, passed spec validation, and all
  tests passed. Engineers and agents reviewing the plan can trust this signal.
- The implementation skill must be capable of running shell commands (linters, test
  runners) in the project environment. This requires the skill to know which linters
  and test runners are configured for the project — derivable from the project's
  tooling configuration (package.json, Makefile, go.mod, etc.).
- Escalation at the iteration limit is not a failure — it is a correct outcome. A
  task that cannot be completed in three iterations has a problem worth the engineer's
  attention. The escalation state in `.state.json` provides the context needed for
  the engineer to make an informed decision.
- `forge:verify`'s responsibility is clearly scoped: goal delivery and integration
  completeness. It does not re-run lint or tests; it trusts that the per-task loop
  has handled those. This scope clarity makes `forge:verify` faster and its findings
  more meaningful.
