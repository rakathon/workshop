# forge-init Design

## Overview

This epic delivers five artifacts: three skills (`forge:init`, `forge:pin`,
`forge:update`) and two shell hooks (generation standards injection, version
enforcement). Together they ensure every repository is initialized correctly, can
optionally be pinned to a specific version, stays current via migrations, and receives
the appropriate coding standards at code generation time.

## Deployable Inventory

| Deployable | Type | Scope | Trigger |
|-----------|------|-------|---------|
| `forge:init` | Skill | Interactive | Manual invocation |
| `forge:pin` | Skill | Interactive | Manual invocation |
| `forge:update` | Skill | Interactive | Manual invocation |
| `inject-generation-standards.sh` | Hook | Project (in plugin cache) | PreToolUse: Write, Edit |
| `forge-version-check.sh` | Hook | User (global) | SessionStart |

## Architecture

```
Developer machine
├── ~/.claude/
│   ├── settings.json              ← user-scope plugin activations
│   └── plugins/cache/
│       └── <marketplace>/forge/
│           ├── <sha-v1>/          ← pinned version for Repo B
│           │   ├── plugin.json
│           │   ├── standards/
│           │   ├── languages/
│           │   └── hooks/
│           │       ├── pre-tool-use/
│           │       │   └── inject-generation-standards.sh
│           │       └── session-start/
│           │           └── forge-version-check.sh  ← registered globally
│           └── <sha-v2>/          ← pinned version for Repo A
│               └── ...
│
├── Repo A/
│   ├── .claude/
│   │   └── settings.json         ← enabledPlugins: forge@forge-local, hook refs to sha-v2
│   ├── .claude-plugin/
│   │   └── marketplace.json      ← ref: v2.0.0, sha: sha-v2
│   ├── .forge/
│   │   ├── version               ← key=value, forge_min_version=2.0.0
│   │   └── ...
│   └── CLAUDE.md                 ← forge:managed section
│
└── Repo B/
    ├── .claude/
    │   └── settings.json         ← enabledPlugins: forge@forge-local, hook refs to sha-v1
    ├── .claude-plugin/
    │   └── marketplace.json      ← ref: v1.0.0, sha: sha-v1
    ├── .forge/
    │   ├── version               ← key=value, forge_min_version=1.0.0
    │   └── ...
    └── CLAUDE.md
```

## Key File Locations

| File | Owner | Purpose |
|------|-------|---------|
| `.forge/compliance` | Engineers / PE | Optional key=value exemption record; absent = full compliance |
| `.claude-plugin/marketplace.json` | `forge:pin` | Pins forge plugin to a specific version tag + SHA; optional |
| `.claude/settings.json` (marketplace) | `forge:pin` | Registers `extraKnownMarketplaces` and `enabledPlugins` entries |
| `.claude/settings.json` (hook) | `forge:init` / `forge:update` | Registers `PreToolUse` hook path pointing to plugin cache |
| `.forge/version` | `forge:init` / `forge:pin` / `forge:update` | key=value version record; read by enforcement hook |
| `CLAUDE.md` | `forge:init` / `forge:update` | Navigation instructions for AI agents; forge:managed section |
| `~/.claude/plugins/cache/<mp>/forge/<sha>/` | Claude Code | Plugin content at a specific version |
| `plugin.json` (in cache) | rr-standards release | Plugin version declaration (JSON — Claude Code format) |
| `VERSIONS.json` (in rr-standards) | Productivity Engineering | Mandatory deadline per major version (JSON — fetched via `gh api`) |

## Cross-Cutting Concerns

### GitHub API

All GitHub API calls use `gh api` — the GitHub CLI, which is a prerequisite for
Forge. `gh` handles authentication transparently (tokens, SSO, etc.) and works
with private repositories. No separate auth configuration is required by engineers.

**Skills** use `gh api --template` (Go templates) to extract fields without `jq`:

```bash
# Latest release tag
gh api repos/rewards-guilds/rr-standards/releases/latest \
  --template '{{.tag_name}}'

# Commit SHA for a tag
gh api repos/rewards-guilds/rr-standards/git/ref/tags/v1.2.3 \
  --template '{{.object.sha}}'
```

**Enforcement hook** uses `gh api` with `--template` and `base64 -d` to fetch
`VERSIONS.json` without `jq`. A 5-second timeout prevents session-start delays:

```bash
encoded=$(gh api "repos/rewards-guilds/rr-standards/contents/VERSIONS.json" \
  --template '{{.content}}' 2>/dev/null)
versions_json=$(printf '%s' "$encoded" | tr -d '\n' | base64 -d 2>/dev/null)
```

If `gh` is not authenticated or the network is unavailable, the hook degrades
gracefully — skips the deadline check and emits a warning.

### gh CLI Prerequisite

`gh` must be installed and authenticated before using Forge. It is not installed
by `forge:init`. The `rr-core` package must declare `Bash(gh *)` permission in
`settings.json` — currently only the `review` package declares it.

### Shell-Only Constraint

Both hooks are pure shell with no dependencies beyond `gh` CLI (prerequisite) and
POSIX utilities. No `jq`, Python, or Node.js required. This is achieved by:
- `.forge/version` using `key=value` format (not JSON) — read with `grep`/`cut`
- `plugin.json` version extraction using `sed` on a known stable JSON field
- `VERSIONS.json` fetched via `gh api --template` + `base64 -d`; extracted with `sed`
- Semver comparison using shell arithmetic on split version deployables
- Date comparison using lexicographic string comparison of ISO 8601 dates

### Hook Location Resolution

TR-6.3 (requirements) states hooks are installed to `.claude/hooks/`. TR-3.2 corrects
this: hook scripts live **in the plugin cache** and are referenced by absolute path
from `.claude/settings.json`. The design follows TR-3.2.

The injection hook path in settings.json:
```
~/.claude/plugins/cache/<marketplace>/forge/<sha>/hooks/pre-tool-use/inject-generation-standards.sh
```

The enforcement hook path: it is registered **globally** in `~/.claude/settings.json`
at global plugin install time. Its path references the user's globally installed
plugin cache entry. When the developer updates their global plugin, this path
updates to point to the new version's hook.

### `.forge/version` Additional Field

The enforcement hook needs to compare the active plugin version against
`forge_min_version` without reading JSON from the plugin cache. Design adds a new
field `active_version` to `.forge/version`, maintained by `forge:init` and
`forge:update`. This allows the hook to perform the sync check with pure shell.

This is a design amendment to TR-4.1 — see [skills.md](skills.md#version-record).

## Design Documents

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:init`, `forge:pin`, and `forge:update` detailed design |
| [hooks.md](hooks.md) | Injection hook and enforcement hook detailed design |
