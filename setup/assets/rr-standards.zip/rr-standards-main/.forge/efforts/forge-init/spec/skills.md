# forge-init Skills Design

Design for `forge:init`, `forge:pin`, and `forge:update`. All skills are interactive,
run in the engineer's Claude Code session, and use Claude Code tools (Read, Write,
Edit, Bash) for all file and network operations. GitHub API calls use `gh api`.

---

## Skill Responsibilities

| Skill | Responsibility |
|-------|---------------|
| `forge:init` | Set up hooks, `.forge/` structure, CLAUDE.md. No version awareness. |
| `forge:pin` | Create/update version pin in `.claude-plugin/marketplace.json`. No structure work. |
| `forge:update` | Migrate repo contents to match the currently pinned (or installed) version. |

These skills compose cleanly:
- **Unpinned setup**: `forge:init` only
- **Pinned setup**: `forge:pin` → `/plugin install forge@forge-local` → `forge:init`
- **Version upgrade**: `forge:pin --version X` → `/plugin install forge@forge-local` → `forge:update`

---

## forge:init

### Arguments

None. forge:init has no flags — version management is forge:pin's responsibility.

### Flow

```
PC-1: Plugin installed (cache search)
PC-2: Not inside .forge subdir
PC-3: No duplicate CLAUDE.md markers

Step 1: Discover plugin root from cache
        plugin_root = dirname(dirname(find plugin.json))

Step 2: Detect init mode (.forge/ exists → merge, else → create)

Step 3: Select repository type (create mode only)
        Present prompt: "Source code / Product / Coordination?"
        Map to repo_type: deployable | product | project
        Merge mode: read existing repo_type from .forge/version, skip prompt

Step 4: Determine forge_min_version
        IF .claude-plugin/marketplace.json exists → read ref, strip "v"
        ELSE → empty string

Step 5: Register PreToolUse hook in .claude/settings.json (hook only)

Step 6: Create .forge/ directory structure from templates in plugin_root
        Always:   README.md, spec/, efforts/
        deployable only: deployables/
        product only:   products/

Step 7: Write .forge/version
        forge_min_version = <from Step 4>
        active_version    = <installed version>
        initialized_with  = <installed version>
        repo_type         = <from Step 3>
        (skip if already exists in merge mode)

Step 8: Write CLAUDE.md forge:managed section
        (always refresh even in merge mode)

Step 9: Print summary (includes repo type label)
```

### Key Design Decisions

- forge:init never calls the GitHub API — it only reads what's already installed
- forge:min_version is derived from marketplace.json if present, keeping the version
  record consistent regardless of which skill was run first
- Plugin root is found via `dirname(dirname(plugin.json))` — one level up from
  `.claude-plugin/` to the actual plugin root
- repo_type is set interactively at first init via a plain-language wizard; merge
  mode re-uses the existing value rather than re-prompting
- Deployables and products directories are created only for the repo types that use
  them — source code repos get `deployables/`, product repos get `products/`

---

## forge:pin

### Arguments

| Flag | Description |
|------|-------------|
| `--version <semver>` | Version to pin to. Default: latest release. |

### Flow

```
PC-1: gh installed and authenticated
PC-2: Not inside .forge subdir

Step 1: Resolve target version via GitHub API (tag + SHA)

Step 2: Create/update .claude-plugin/marketplace.json
        Uses git-subdir source pointing to plugins/forge/ in rr-standards

Step 3: Update .claude/settings.json
        - extraKnownMarketplaces["forge-local"] → ./.claude-plugin
        - enabledPlugins: remove all forge@*, add forge@forge-local

Step 4: Update .forge/version forge_min_version IF .forge/version exists

Step 5: Instruct user to run /plugin install forge@forge-local
        Pause until confirmed

Step 6: Print summary with next steps (forge:init or forge:update)
```

### Key Design Decisions

- forge:pin has no knowledge of hooks or directory structure — that's forge:init
- forge:pin updates `forge_min_version` in `.forge/version` when it exists so the
  version enforcement hook stays in sync without requiring forge:init to re-run
- The "next steps" in the summary are important: the user must know to run either
  forge:init (first time) or forge:update (subsequent upgrades) after installing

---

## forge:update

### Arguments

| Flag | Description |
|------|-------------|
| `--yes` | Skip confirmation for MINOR/PATCH migrations |

### Flow

```
PC-1: .forge/version exists
PC-2: Plugin installed

Step 1: Read current_version from .forge/version active_version

Step 2: Resolve target_version
        IF .claude-plugin/marketplace.json exists → read ref
        ELSE → discover from installed plugin cache
        Refuse if target < current (downgrade not supported)
        Exit cleanly if target = current (nothing to do)

Step 3: Discover plugin_root from cache

Step 4: Classify migration (MAJOR or MINOR/PATCH)

Step 5: Check active work items (MAJOR only — block if any)

Step 6: Fetch migration manifest from plugin_root/migrations/

Step 7: Pre-migration report + confirmation
        --yes skips confirmation for MINOR/PATCH only

Step 8: Snapshot files for rollback

Step 9: Apply migration (atomic):
  9.1  Update hook path in settings.json
  9.2  Refresh CLAUDE.md forge:managed section
  9.3  Create new .forge/ directories (from manifest)
  9.4  Apply .state.json schema migrations (from manifest)
  9.5  Update .forge/version: active_version, last_migrated_*
  9.6  Print summary

Rollback: restore snapshot on any failure in Step 9
```

### Key Design Decisions

- forge:update does NOT update `forge_min_version` — that's forge:pin's responsibility
- forge:update does NOT touch `.claude-plugin/marketplace.json` — pin is already set
- Downgrade refusal is a hard stop, not a confirmation prompt — partial downgrades
  risk corrupting `.state.json` in ways that are hard to recover from
- The target version comes from the pin (or installed version), NOT from a CLI flag.
  Separating "change the pin" (forge:pin) from "apply the migration" (forge:update)
  means forge:update is always migrating to what's already committed in the repo

---

## CLAUDE.md Template

The forge:managed section written by `forge:init` (and refreshed by `forge:update`):

```markdown
<!-- forge:managed:start -->
## Forge Framework

This repository uses the Forge AI-accelerated development framework.
Plugin version: v<version>

### Standards Navigation

When navigating standards or language guides, explicitly read the AGENTS.md
file in each relevant directory before loading individual files. Claude Code
does not load AGENTS.md automatically.

Standards and language guides are bundled with the Forge plugin at:
  ~/.claude/plugins/cache/<marketplace-dir>/forge/<sha>/

### Deployable Artifacts

Deployables are registered in `.forge/deployables/`. When a deployable directory exists,
read `.forge/deployables/<deployable-name>/` for canonical artifacts:
- `requirements/`  — business and technical requirements
- `spec/`        — architecture, ADRs, published interfaces
- `capabilities/`      — capability-scoped requirements, design, and test strategy (ADR-028)
- `test-strategy.md` — deployable-level test strategy
- `security.md`    — threat model and security controls
- `deployment.md`  — deployment and rollback procedures
- `runbook/`       — operational procedures

Deployable directories are created by `forge:deployable` during discovery. Not every
repository will have deployables registered yet.

### PM Product Artifacts

PM products are registered in `.forge/products/` (product-role repos only). When a
product directory exists, read `.forge/products/<product-name>/` for:
- `requirements/`  — cross-deployable PM requirements
- `strategy.md`    — vision, goals, OKRs, success metrics
- `roadmap.md`     — PM roadmap
- `deployables.md`  — which deployables implement this product, with repo cross-refs (ADR-029)

PM product directories are created by `forge:product-init` and are only present in
repositories with `repo_types` including `"product"`.

### Work Items

Active work items are listed in `.forge/efforts/README.md`.
Work item artifacts are in `.forge/efforts/<id>/`.
<!-- forge:managed:end -->
```

---

## Version Record (.forge/version)

```
forge_min_version=<semver>   # minimum version; set by forge:init (from pin) and forge:pin
active_version=<semver>      # version currently active; updated by forge:init and forge:update
initialized_with=<semver>    # version that ran forge:init; never changed after init
initialized_at=<ISO-8601>    # UTC timestamp of forge:init run
last_migrated_with=<semver>  # version that ran forge:update; empty until first migration
last_migrated_at=<ISO-8601>  # UTC timestamp of most recent forge:update
repo_type=deployable          # repository role: deployable (default), effort, or product (per ADR-029)
```

**Who sets what:**

| Field | Set by | When |
|-------|--------|------|
| `forge_min_version` | `forge:init` (reads from marketplace.json if present) | At init |
| `forge_min_version` | `forge:pin` | When pin changes (if .forge/version exists) |
| `active_version` | `forge:init` | At init |
| `active_version` | `forge:update` | After each migration |
| `initialized_with` | `forge:init` | At init only, never changed |
| `initialized_at` | `forge:init` | At init only, never changed |
| `last_migrated_with` | `forge:update` | After each migration |
| `last_migrated_at` | `forge:update` | After each migration |
| `repo_type` | `forge:init` | At init only — determination mechanism TBD (TR open question 5) |
