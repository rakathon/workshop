# forge-init Hooks Design

Design for the two shell hooks delivered by the forge-init epic.
Both hooks are pure POSIX shell with no external tool dependencies.

---

## Hook 1: Generation Standards Injection

**File:** `hooks/pre-tool-use/inject-generation-standards.sh`
(in plugin cache at `~/.claude/plugins/cache/<marketplace-dir>/forge/<sha>/`)

**Trigger:** `PreToolUse` — matcher `Write|Edit`

**Scope:** Project — registered in `.claude/settings.json` with an absolute path
to the hook within the pinned plugin cache entry. Each project's hook path points
to its pinned version's hook script, ensuring the correct version's standards are
always injected.

**Purpose:** Before any Write or Edit tool call, detect the target file's language,
find the corresponding language guide in the plugin cache, and output it to stdout
so Claude Code injects it into the model's context. Standards are enforced at
generation time without engineer invocation (TR-6.1, BR-3).

### Compliance Exemption Check

Before any other logic, the hook checks whether the repository is in
compliance-exempt mode (TR-9.2). If exempt, exit 0 immediately — no injection,
no warning, no output:

```bash
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  [ "$cs" = "exempt" ] && exit 0
fi
```

### Input

Claude Code passes the tool call input to the hook. The file path is available via
environment variable. The exact variable name follows the Claude Code hooks
specification — to be confirmed during implementation. Expected:

```bash
FILE_PATH="${CLAUDE_TOOL_INPUT_FILE_PATH:-}"   # for Write
# or
FILE_PATH="${CLAUDE_TOOL_INPUT_PATH:-}"        # verify against Claude Code spec
```

The hook exits 0 (allow) in all cases — it never blocks a Write or Edit.

### Language Detection

The hook determines language from the file extension:

```bash
get_language() {
  local ext="${1##*.}"
  case "$ext" in
    go)                   echo "go" ;;
    java)                 echo "java" ;;
    kt|kts)               echo "kotlin" ;;
    swift)                echo "swift" ;;
    ts|tsx)               echo "typescript" ;;
    js|jsx|mjs|cjs)       echo "javascript" ;;
    py)                   echo "python" ;;
    rb)                   echo "ruby" ;;
    rs)                   echo "rust" ;;
    *)                    echo "" ;;
  esac
}
```

Files with no extension, or extensions not in this table, produce an empty language.
The hook proceeds without injection (non-blocking).

### Standard Path Resolution

The hook script knows its own location via `BASH_SOURCE[0]`. Standards and language
guides are co-located in the same plugin cache entry:

```bash
# The hook lives at: <plugin_root>/hooks/pre-tool-use/inject-generation-standards.sh
# Standards live at: <plugin_root>/standards/
# Language guides:   <plugin_root>/languages/<lang>/

PLUGIN_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
LANG_GUIDE="$PLUGIN_ROOT/languages/$language/guide.md"
```

The specific filename within the language directory (`guide.md` or similar) is
defined by the rr-standards repository structure for each language.

### Injection

If a language guide is found, output its content to stdout. Claude Code reads the
hook's stdout and injects it as additional context before the tool call proceeds.

```bash
if [ -f "$LANG_GUIDE" ]; then
  cat "$LANG_GUIDE"
fi
exit 0
```

### Degraded Mode

```bash
# No language detected for this extension
if [ -z "$language" ]; then
  exit 0   # silent — no injection, no warning; most files have no standard
fi

# Language detected but no guide file
if [ ! -f "$LANG_GUIDE" ]; then
  echo "forge: no language guide for .$ext files" >&2
  exit 0   # warn to stderr, do not block
fi

# PLUGIN_ROOT resolution failed (e.g. hook script moved)
if [ ! -d "$PLUGIN_ROOT" ]; then
  echo "forge: cannot resolve plugin root from hook path" >&2
  exit 0   # warn, do not block
fi
```

### Complete Script

```bash
#!/usr/bin/env sh
set -e

# Resolve plugin root from hook's own location
PLUGIN_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"

# Check for compliance exemption — skip injection for exempt repos (TR-9.2)
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  [ "$cs" = "exempt" ] && exit 0
fi

# Get target file path from Claude Code hook input
FILE_PATH="${CLAUDE_TOOL_INPUT_FILE_PATH:-${CLAUDE_TOOL_INPUT_PATH:-}}"

if [ -z "$FILE_PATH" ]; then
  exit 0  # no path available — proceed without injection
fi

# Detect language from extension
ext="${FILE_PATH##*.}"
language=""
case "$ext" in
  go)             language="go" ;;
  java)           language="java" ;;
  kt|kts)         language="kotlin" ;;
  swift)          language="swift" ;;
  ts|tsx)         language="typescript" ;;
  js|jsx|mjs|cjs) language="javascript" ;;
  py)             language="python" ;;
  rb)             language="ruby" ;;
  rs)             language="rust" ;;
esac

if [ -z "$language" ]; then
  exit 0
fi

# Find the language guide
LANG_GUIDE="$PLUGIN_ROOT/languages/$language/guide.md"

if [ ! -f "$LANG_GUIDE" ]; then
  printf "forge: no language guide for .%s files\n" "$ext" >&2
  exit 0
fi

# Inject — output to stdout for Claude Code context injection
cat "$LANG_GUIDE"
exit 0
```

---

## Hook 2: Version Enforcement

**File:** `hooks/session-start/forge-version-check.sh`
(in plugin cache — but registered at **user scope**)

**Trigger:** `SessionStart`

**Scope:** User (global) — registered in `~/.claude/settings.json` when the developer
installs the Forge plugin. Runs at the start of every Claude Code session regardless
of which repository is open.

**Purpose:** Enforce that the repository is initialized, that the pinned plugin
version meets the project minimum, and that the mandatory organizational upgrade
deadline has not passed. Must complete in under 500ms (TR constraint).

### Algorithm

```
1. Check .forge/version exists
   → absent: print notice, exit 0 (non-blocking)

2. Check .forge/compliance for coding_standards=exempt (TR-9.3)
   → if exempt: print notice identifying repo as coding-standards-exempt; exit 0

3. Read forge_min_version and active_version from .forge/version

4. Compare active_version vs forge_min_version
   → active < min: print error, exit 1 (block) unless in-progress impl task → exit 0 with warning

4. Extract major version from forge_min_version

5. Fetch VERSIONS.json (with 1-second timeout)
   → unreachable: print warning about skipped deadline check, exit 0

6. Extract mandatoryAfter for this major version from VERSIONS.json
   → major not listed: exit 0 (no deadline for this version)

7. Compare today's date against mandatoryAfter
   → today >= mandatoryAfter: print error, exit 1 (block)
   → today within warning window (30 days before): print warning, exit 0
   → today before warning window: exit 0 (optionally note newer version if available)
```

Steps 3–7 are skipped entirely when the repository is compliance-exempt (step 2
short-circuits to exit 0).

### Semver Comparison

```bash
# Returns 0 if $1 >= $2, 1 if $1 < $2
version_gte() {
  local a b IFS=.
  local v1=($1) v2=($2)
  for i in 0 1 2; do
    a="${v1[$i]:-0}"
    b="${v2[$i]:-0}"
    [ "$a" -gt "$b" ] && return 0
    [ "$a" -lt "$b" ] && return 1
  done
  return 0  # equal
}
```

### Date Comparison

ISO 8601 dates (YYYY-MM-DD) compare correctly as strings due to their zero-padded
format.

```bash
today=$(date -u +%Y-%m-%d)
warning_date=$(date -u -d "$mandatory_after -30 days" +%Y-%m-%d 2>/dev/null \
  || date -u -v-30d +%Y-%m-%d 2>/dev/null)  # GNU date | BSD date

if [ "$today" \> "$mandatory_after" ] || [ "$today" = "$mandatory_after" ]; then
  # deadline passed
elif [ -n "$warning_date" ] && \
     ([ "$today" \> "$warning_date" ] || [ "$today" = "$warning_date" ]); then
  # within 30-day warning window
fi
```

Note: `date -d` (GNU/Linux) and `date -v` (BSD/macOS) syntax differs for date
arithmetic. The hook attempts GNU syntax first, then BSD. If neither works,
the warning window check is skipped — the mandatory deadline check still runs
via string comparison.

### VERSIONS.json Fetch

`VERSIONS.json` is fetched from the rr-standards repository using `gh api` — the
GitHub CLI prerequisite. This handles authentication for private repositories
without any engineer configuration. `--template` extracts the base64-encoded file
content; `base64 -d` decodes it; `sed` parses the known JSON structure.

```bash
# Fetch VERSIONS.json via gh (authenticated, private repo safe)
# GitHub Contents API returns base64-encoded content
encoded=$(gh api \
  "repos/rewards-guilds/rr-standards/contents/VERSIONS.json" \
  --template '{{.content}}' 2>/dev/null)

if [ -z "$encoded" ]; then
  printf "forge: WARNING — cannot reach marketplace for deadline check\n" >&2
  # skip deadline enforcement, continue
else
  versions_json=$(printf '%s' "$encoded" | tr -d '\n' | base64 -d 2>/dev/null)
  mandatory_after=$(printf '%s' "$versions_json" | \
    sed -n "/\"v${major}\"/,/}/{s/.*\"mandatoryAfter\": *\"\([^\"]*\)\".*/\1/p;}" | \
    head -1)
fi
```

`base64 -d` is available on Linux (GNU coreutils) and macOS 12.3+. `tr -d '\n'`
strips the embedded newlines GitHub includes in base64 content responses.

**Latency:** `gh api` is slower than a raw `curl` to a public URL but still
completes within a few hundred milliseconds on a normal connection. The 500ms
budget is tight; if profiling shows this is exceeded, a local cache of VERSIONS.json
(refreshed daily via a background process) can be introduced in a future iteration.

### Active Work Item Check

For the "active < min" case, before blocking the session the hook checks whether
an active implementation task is in progress:

```bash
has_active_impl() {
  for state_file in .forge/efforts/*/.state.json; do
    [ -f "$state_file" ] || continue
    phase=$(sed -n 's/.*"currentPhase": *"\([^"]*\)".*/\1/p' "$state_file" | head -1)
    status=$(sed -n '/implementation/,/}/{s/.*"status": *"\([^"]*\)".*/\1/p;}' \
      "$state_file" | head -1)
    if [ "$phase" = "implementation" ] && [ "$status" = "in_progress" ]; then
      return 0
    fi
  done
  return 1
}
```

### Output Messages

All user-facing messages are written to stderr. Exit code determines blocking:

```bash
# Non-blocking notice (not initialized)
printf "forge: this repository is not initialized with Forge. Run forge:init.\n" >&2
exit 0

# Non-blocking warning (version sync issue + active task)
printf "forge: WARNING — forge_min_version (%s) > active_version (%s)\n" \
  "$forge_min" "$active" >&2
printf "forge: run forge:update when this task is complete.\n" >&2
exit 0

# Blocking error (version sync issue, no active task)
printf "forge: ERROR — this project requires forge >= %s but active version is %s.\n" \
  "$forge_min" "$active" >&2
printf "forge: run forge:update to re-establish consistency.\n" >&2
exit 1

# Blocking error (mandatory deadline passed)
printf "forge: ERROR — forge v%s support ended on %s.\n" "$major" "$mandatory_after" >&2
printf "forge: run forge:update to migrate this repository to the current version.\n" >&2
exit 1

# Warning (approaching deadline)
printf "forge: WARNING — forge v%s requires migration by %s (%s days remaining).\n" \
  "$major" "$mandatory_after" "$days_remaining" >&2
exit 0

# Network degraded
printf "forge: WARNING — cannot verify mandatory upgrade deadline (network unavailable).\n" >&2
exit 0
```

### Complete Script

```bash
#!/usr/bin/env sh

# forge version enforcement hook — SessionStart, user scope
# Runs in every Claude Code session. Must complete in < 500ms.

# Only relevant in Forge-initialized repositories
if [ ! -f ".forge/version" ]; then
  printf "forge: this repository is not initialized. Run forge:init.\n" >&2
  exit 0
fi

# Check for compliance exemption (TR-9.3)
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  if [ "$cs" = "exempt" ]; then
    printf "forge: this repository is coding-standards-exempt.\n" >&2
    exit 0
  fi
fi

# Read version fields
forge_min=$(grep "^forge_min_version=" .forge/version | cut -d= -f2)
active=$(grep "^active_version=" .forge/version | cut -d= -f2)

if [ -z "$forge_min" ] || [ -z "$active" ]; then
  printf "forge: WARNING — .forge/version is malformed. Run forge:init.\n" >&2
  exit 0
fi

# Semver comparison helper
version_gte() {
  local a b IFS=.
  local v1=($1) v2=($2)
  for i in 0 1 2; do
    a="${v1[$i]:-0}"; b="${v2[$i]:-0}"
    [ "$a" -gt "$b" ] && return 0
    [ "$a" -lt "$b" ] && return 1
  done
  return 0
}

# Check active version meets minimum
if ! version_gte "$active" "$forge_min"; then
  if has_active_impl 2>/dev/null; then
    printf "forge: WARNING — active version %s < forge_min_version %s. " \
      "$active" "$forge_min" >&2
    printf "Run forge:update after this task.\n" >&2
    exit 0
  else
    printf "forge: ERROR — active version %s < forge_min_version %s. " \
      "$active" "$forge_min" >&2
    printf "Run forge:update.\n" >&2
    exit 1
  fi
fi

# Extract major version for deadline check
major=$(echo "$forge_min" | cut -d. -f1)

# Fetch mandatory deadline via gh (authenticated, private repo safe)
encoded=$(gh api "repos/rewards-guilds/rr-standards/contents/VERSIONS.json" \
  --template '{{.content}}' 2>/dev/null)
versions_json=$(printf '%s' "$encoded" | tr -d '\n' | base64 -d 2>/dev/null)

if [ -z "$versions_json" ]; then
  printf "forge: WARNING — cannot verify upgrade deadline (gh unavailable or not authenticated).\n" >&2
  exit 0
fi

mandatory_after=$(printf '%s' "$versions_json" | \
  sed -n "/\"v${major}\"/,/}/{s/.*\"mandatoryAfter\": *\"\([^\"]*\)\".*/\1/p;}" | \
  head -1)

if [ -z "$mandatory_after" ]; then
  exit 0  # no deadline defined for this major version
fi

today=$(date -u +%Y-%m-%d)

if [ "$today" \> "$mandatory_after" ] || [ "$today" = "$mandatory_after" ]; then
  printf "forge: ERROR — forge v%s support ended on %s. Run forge:update.\n" \
    "$major" "$mandatory_after" >&2
  exit 1
fi

# Check 30-day warning window
warning_date=$(date -u -d "$mandatory_after -30 days" +%Y-%m-%d 2>/dev/null \
  || date -u -v-30d -j -f "%Y-%m-%d" "$mandatory_after" +%Y-%m-%d 2>/dev/null || echo "")

if [ -n "$warning_date" ] && \
   { [ "$today" \> "$warning_date" ] || [ "$today" = "$warning_date" ]; }; then
  printf "forge: WARNING — forge v%s migration required by %s. Run forge:update soon.\n" \
    "$major" "$mandatory_after" >&2
fi

exit 0
```

---

## has_active_impl Helper

```bash
has_active_impl() {
  for state_file in .forge/efforts/*/.state.json; do
    [ -f "$state_file" ] || continue
    phase=$(sed -n 's/.*"currentPhase": *"\([^"]*\)".*/\1/p' "$state_file" | head -1)
    impl_status=$(sed -n '/"implementation"/,/}/{
      s/.*"status": *"\([^"]*\)".*/\1/p
    }' "$state_file" | head -1)
    if [ "$phase" = "implementation" ] && [ "$impl_status" = "in_progress" ]; then
      return 0
    fi
  done
  return 1
}
```

---

## Testing Requirements (TR-6.4)

The injection hook requires automated tests covering:

| Test case | Expected behaviour |
|-----------|-------------------|
| `.go` file | Injects Go language guide to stdout |
| `.java` file | Injects Java language guide to stdout |
| `.ts` file | Injects TypeScript language guide to stdout |
| `.py` file | Injects Python language guide to stdout |
| `.md` file | No injection; exits 0 silently |
| File with no extension | No injection; exits 0 silently |
| Language guide file absent | Warning to stderr; exits 0 |
| Plugin root unresolvable | Warning to stderr; exits 0 |
| No file path in environment | No injection; exits 0 silently |
| `.forge/compliance` with `coding_standards=exempt` | No injection; exits 0 silently |

The enforcement hook requires tests covering:

| Test case | Expected behaviour |
|-----------|-------------------|
| No `.forge/version` | Notice to stderr; exits 0 |
| `active_version < forge_min_version`, no active task | Error to stderr; exits 1 |
| `active_version < forge_min_version`, active impl task | Warning to stderr; exits 0 |
| `forge_min_version` malformed | Warning to stderr; exits 0 |
| `mandatoryAfter` passed | Error to stderr; exits 1 |
| Within 30-day warning window | Warning to stderr; exits 0 |
| Before warning window | Exits 0 silently |
| `VERSIONS.json` unreachable | Warning to stderr; exits 0 |
| Major version not in `VERSIONS.json` | Exits 0 silently |
| `.forge/compliance` with `coding_standards=exempt` | Notice to stderr; exits 0 |
