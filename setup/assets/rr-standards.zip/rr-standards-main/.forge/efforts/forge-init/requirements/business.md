# Business Requirements — Installation & Distribution

Parent program: [forge-plugin](../../forge-plugin/requirements/business.md)
Primary program BRs addressed: BR-10, BR-15, BR-16, BR-20

---

### BR-1: Every Repository Must Be Initialized Before Development Begins

A repository that has not been initialized with Forge is outside organizational standards
from its first commit. Engineers must not be required to manually create CLAUDE.md,
the `.forge/` directory structure, or the master work registry. A single `forge:init`
invocation must produce a fully configured repository, ready for standards-based
development, with no additional configuration steps required.

### BR-2: Initialization Must Merge Safely with Existing Repository Content

Brownfield repositories — the majority in any organization — already have content that
must not be destroyed. A CLAUDE.md may have project-specific instructions that predate
Forge. Running `forge:init` on these repositories must add the required Forge content
without overwriting, truncating, or conflicting with existing instructions. An engineer
must be able to run `forge:init` on any repository — including one already partially
configured — and receive a predictable, non-destructive result.

### BR-3: An Initialized Repository Must Be Immediately Ready for Generation-Time Standards Enforcement

Initialization is not complete when the files are created. After `forge:init`, the
first time an engineer writes a source file with Claude Code, the correct organizational
coding standards must be automatically loaded as generation context without the engineer
invoking any additional command. If initialization does not produce this automatic
enforcement, the standards mandate (BR-15 of the program) cannot be met — engineers
would need to opt in to standards on every session, which is indistinguishable from
having no standards at all.

### BR-4: Initialization Must Support Both Installation Modes Without Engineer Decision

The organization supports two Forge plugin installation modes: global (shared across all
repositories on the engineer's machine) and per-project (embedded in the repository). In
practice, engineers should not need to understand this distinction to initialize correctly.
`forge:init` must detect which mode is applicable and configure the repository accordingly.
An engineer who runs `forge:init` without knowing what installation mode their environment
uses must still get a correctly configured repository. If the Forge plugin is installed in
both the current project, and globally, the current project's version takes precedence. 

### BR-5: The Framework Must Know Its Own Installed Version in Every Repository

Upgrade enforcement (BR-16 of the program) requires that `forge:update`, the version
enforcement hook, and CI tooling can all determine: what version of Forge is currently
installed in a repository, how long the installation has been at that version, and
whether a mandatory update window has been exceeded. This is impossible without a
machine-readable version record created at initialization time and updated on every
upgrade. The version record must exist in every initialized repository from the moment
`forge:init` completes.

### BR-6: Upgrade Must Be a Distinct, Safe, Controlled Operation

Installing Forge for the first time and upgrading an existing installation are different
operations with different risks. An upgrade may change skill behavior, hook exit codes,
or standards rules. Applying upgrade changes without warning during an in-progress task
is disruptive — an engineer mid-implementation who is forced to take a breaking skill
change faces changed behavior at the worst possible moment. The upgrade path must be
explicit: a `forge:update` command that engineers run intentionally, that reports what
will change before applying it, and that protects engineers in active implementation
work from forced breaking changes.

### BR-7: Engineers Must Know When an Update Is Available

The organization cannot enforce version currency if engineers do not know they are
behind. The framework must emit a visible, non-blocking notice at session start when
the installed version of Forge is behind the current release. The notice must be
non-blocking so it does not interrupt in-progress work; it must be visible so it is
not missed. Engineers must be able to act on it immediately by running `forge:update`,
or defer it if they are in active work.

### BR-8: The Framework Must Enforce a Maximum Lag Period

Voluntary upgrades are insufficient to maintain organizational standards currency.
After a Productivity Engineering-defined maximum lag period, an available update
becomes mandatory — the version enforcement hook must block development operations
in repositories that exceed this lag. This enforcement must apply consistently across
all teams and repositories; no team may run an outdated Forge installation indefinitely
by simply deferring voluntary upgrades.

### BR-9: Version Enforcement Must Not Block Engineers in Active In-Progress Work

BR-8 requires enforcement; this requirement constrains how it is applied. Blocking
an engineer who is currently implementing a task mid-sprint — because a Forge update
became mandatory while they were working — disrupts in-progress work that has already
been started against a known, validated behavior set. Enforcement must apply at natural
stopping points (session start before any new task begins, before discovery or planning
phases begin) but must not interrupt an active implementation task that was started
before the enforcement window closed.

### BR-10: Repositories Must Be Able to Opt Out of Standards Enforcement

Not every repository in the organization is actively developed. Deprecated
repositories require occasional maintenance — dependency patches, security fixes,
configuration updates — but imposing full standards compliance on code that is
scheduled for retirement is disproportionate. Engineers performing routine maintenance
on a deprecated repository must not be blocked by standards enforcement that has no
practical value for code that will never be refactored to meet current standards.

### BR-11: Standards Enforcement Opt-Out Must Not Disable Forge Tooling

Opting out of standards compliance must not disable Forge work item tracking, product
artifact management, or version management. A deprecated repository may still have
active work items, and engineers must be able to use Forge workflow tools even when
standards enforcement is relaxed. The exemption is scoped to compliance enforcement
only — standards injection, review blocking, and version deadline blocking — not to
the framework as a whole.

### BR-12: The Master Work Registry Must Support Cross-Repository Work Item References

Work items in this repository may declare parent items that exist in a separate
project-coordination repository (per ADR-027 and BR-23 of the program). The master
registry at `.forge/efforts/README.md` — created by `forge:init` at initialization time —
must be capable of representing these cross-repo references without breaking the
registry's navigability. An engineer reading the local registry must be able to
identify when a work item's broader context lives elsewhere, and the CLAUDE.md
navigation instructions must direct agents to the local canonical documentation
(`.forge/deployables/`, `.forge/efforts/`) as the primary source while acknowledging
that cross-repo context may exist upstream.

---

Success criteria: [success-criteria.md](success-criteria.md)
