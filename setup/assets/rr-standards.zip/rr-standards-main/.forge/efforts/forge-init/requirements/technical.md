# Technical Requirements — Installation & Distribution

Parent program: [forge-plugin](../../forge-plugin/requirements/technical.md)

---

## TR-1: forge:init Skill

### TR-1.1: Command Surface

`forge:init` accepts no flags. It is a setup-only command responsible for hook
registration, `.forge/` directory structure, and CLAUDE.md — it has no version
pinning responsibilities.

Version pinning is handled by the separate `forge:pin` skill (TR-10). Engineers who
want to lock their team to a specific Forge version run `forge:pin` before or after
`forge:init` — the two skills are order-independent.

`forge:init` always writes to `.claude/settings.json` at **project scope**, ensuring
all contributors who clone the repository get the hook registered automatically.
User scope is not supported.

### TR-1.2: Idempotency

Running `forge:init` on an already-initialized repository must be safe and must
produce the same end state as the first run. It must not create duplicate content,
reset state written after initialization, or destroy any artifacts in `.forge/efforts/`.
The skill must detect existing initialization and operate in merge mode (TR-2.2)
rather than create mode when the `.forge/` directory already exists.

### TR-1.3: Output

`forge:init` must print a structured summary of every action taken: files created,
files updated (with the change made), files left unchanged, and the version recorded.
Engineers must be able to verify initialization from the output alone without inspecting
the resulting files.

### TR-1.4: Repository Type Selection

On first initialization (create mode), `forge:init` must prompt the engineer to
select the repository type before creating any files. The prompt must present three
options with plain-language descriptions — not framework jargon — that allow an
engineer unfamiliar with Forge to make the correct choice:

1. **Source code repository** — a service, application, or library that engineers
   build and ship. Maps to `repo_type=deployable`. Creates `deployables/` and
   `efforts/`.

2. **Product repository** — owned by a product manager. Tracks product strategy,
   roadmap, and cross-team requirements. Contains no source code. Maps to
   `repo_type=product`. Creates `products/` and `efforts/`.

3. **Coordination repository** — houses planning artifacts for a project spanning
   multiple repositories. Contains no source code. Maps to `repo_type=project`.
   Creates `efforts/` only.

In merge mode (repository already initialized), `forge:init` reads `repo_type` from
the existing `.forge/version` and skips the prompt. The existing type is shown in
the summary output.

The `repo_type` value recorded by this prompt is written to `.forge/version` (TR-4.1)
and controls which artifact directories are created (TR-3.1).

---

## TR-2: CLAUDE.md Generation and Merge

### TR-2.1: Create Mode (No Existing CLAUDE.md)

When no CLAUDE.md exists, create it from the Forge CLAUDE.md template. The generated
file must include at minimum:

- A Forge-managed section marker (see TR-2.3) wrapping the Forge content
- An explicit instruction to read the appropriate AGENTS.md files when navigating
  standards or language guides, with the path to the rr-standards installation
  (Claude Code does not load AGENTS.md automatically; without this instruction, agents
  working outside a forge: skill will not receive standards navigation context)
- An explicit instruction to read `.forge/deployables/<name>/` for canonical deployable
  artifacts (requirements, design, test strategy, security, deployment, runbook, and
  `capabilities/<name>/` for capability-level requirements and design per ADR-028) when
  working on a specific deployable; without this instruction, AI agents will not know
  where to find the authoritative deployable-level documentation
- An explicit instruction to read `.forge/products/<name>/` for PM product artifacts
  (requirements, strategy, roadmap, deployables cross-reference) when working on a
  PM product in a product-role repository (ADR-029)
- References to the rr-standards installation path, resolved using the detected
  installation mode (TR-5.1)
- The Forge hooks reference, pointing to `.claude/hooks/` in the repository

### TR-2.2: Merge Mode (Existing CLAUDE.md)

When a CLAUDE.md already exists, merge Forge content into it without modifying any
content outside the Forge-managed section:

- If a Forge-managed section (TR-2.3) already exists: replace its content with the
  current Forge template content, preserving all content outside the section markers
- If no Forge-managed section exists: append the Forge-managed section to the end
  of the file, preserving all existing content unchanged

Under no circumstances may merge mode overwrite, truncate, or reorder content that
exists outside the Forge-managed section markers.

### TR-2.3: Forge-Managed Section Markers

The Forge content within CLAUDE.md must be delimited by stable, machine-readable
markers:

```
<!-- forge:managed:start -->
... Forge-generated content ...
<!-- forge:managed:end -->
```

These markers enable `forge:init` (idempotent merge), `forge:update` (incremental
update), and diagnostic tooling to locate Forge content precisely. They must never
appear more than once in a file; `forge:init` must validate this and fail with a
diagnostic error if duplicate markers are detected.

---

## TR-3: Forge Directory Structure

### TR-3.1: Required Directories and Files

`forge:init` must create the following structure if not already present. Existing
files must not be overwritten. Which artifact directories are created depends on the
repository type selected during initialization (TR-1.4).

**Always created (all repository types):**

```
.forge/
├── README.md           # master work item registry (empty table at init)
├── version             # installation version record (TR-4) — key=value format
├── spec/
│   ├── README.md       # repo-level cross-deployable design artifacts index
│   └── arch-decisions/
│       └── README.md   # repo-level ADR index
└── efforts/
    └── README.md       # work item registry index (empty table at init)
```

**Created only for `repo_type=deployable` (source code repositories):**

```
.forge/
└── deployables/
    └── README.md       # deployable registry (empty table at init)
```

**Created only for `repo_type=product` (product repositories):**

```
.forge/
└── products/
    └── README.md       # product registry (empty table at init)
```

Individual deployable directories (`.forge/deployables/<name>/`) are created later by
`forge:deployable` during discovery — the deployable list is not known at initialization
time. PM product directories (`.forge/products/<name>/`) are created by
`forge:product-init`.

Capability directories (`.forge/deployables/<name>/capabilities/<capability-name>/`) are not
created by `forge:init`. Per ADR-028, capabilities are identified and created during
the discovery phase of the work items that deliver them, not at repository
initialization time.

The `.forge/efforts/README.md` master registry table must include a `Parent` column to
accommodate work items whose parent lives in a different repository (BR-12, BR-23 of
the program). Cross-repo parent references use the provisional `repo:org/repo/id`
format (see Open Question 6).

### TR-3.2: Settings and Hooks

`forge:init` must write the required hook registrations into `.claude/settings.json`
(see TR-5.2 and TR-6). Hook scripts are bundled within the plugin cache and are
referenced by path from `settings.json` — they are not copied into the project. The
plugin cache entry is the authoritative source for hook script content.

---

## TR-4: Version Record

### TR-4.1: Format and Location

`forge:init` must write `.forge/version` as a flat `key=value` file. JSON is not used
because this file is read primarily by shell hooks, and `key=value` eliminates any
JSON parsing dependency — `grep` and `cut` are sufficient, both POSIX standard with
no installation required.

```
forge_min_version=1.2.3
active_version=1.2.3
initialized_with=1.2.3
initialized_at=2026-03-15T10:00:00Z
last_migrated_with=
last_migrated_at=
repo_type=product
```

Fields:
- `forge_min_version` — the minimum Forge plugin version the project configuration
  is valid for. The version enforcement hook (TR-8) reads this with:
  `grep "^forge_min_version=" .forge/version | cut -d= -f2`
- `active_version` — the version currently pinned in `.claude-plugin/marketplace.json`.
  Maintained by `forge:init` and `forge:update`. Allows the enforcement hook to compare
  the active version against `forge_min_version` using only shell key=value reads,
  without JSON parsing of the plugin cache. Normally equals `forge_min_version`; a
  divergence indicates manual editing of `.forge/version`.
- `initialized_with` — the plugin version that ran `forge:init`; never changed after init.
- `last_migrated_with` / `last_migrated_at` — set by `forge:update` (TR-7); empty
  until the first migration is run.
- `repo_type` — the role of this repository in the Forge framework. `product` (default)
  for repositories that contain source code and product artifacts. `project` for
  repositories whose primary purpose is hosting cross-repo project-level artifacts
  per ADR-027. Written by `forge:init` at initialization time. The mechanism by which
  `forge:init` determines the correct value is an open question (see Open Questions).

### TR-4.2: Format Rules

- One field per line, `key=value` with no spaces around `=`
- Values are unquoted plain strings
- Empty fields are represented as `key=` (key present, value empty) — not omitted
- No comments, no sections, no nesting
- Shell hooks read fields with: `grep "^<key>=" .forge/version | cut -d= -f2`
- Skills update fields with: `sed -i "s/^<key>=.*/<key>=<value>/" .forge/version`

### TR-4.3: Version Source

The active Forge plugin version is read from `plugin.json` in the cache entry
corresponding to the ref/SHA pinned in `.claude-plugin/marketplace.json`. `forge:init`
reads this version to populate `forge_min_version` and `initialized_with`. If the
plugin cache entry for the pinned version is absent or its manifest cannot be read,
`forge:init` must fail with a diagnostic error; initialization must not proceed with
an unknown version value.

### TR-4.4: Migration Tracking

Each `forge:update` run must update `last_migrated_with`, `last_migrated_at`, and
`forge_min_version` in `.forge/version` before completing. This records the highest
plugin version the project configuration has been explicitly validated against.

---

## TR-5: Plugin Installation

### TR-5.1: Project Scope Only

`forge:init` always activates the Forge plugin at **project scope** by writing to
`.claude/settings.json` in the current repository. This file is committed to version
control, ensuring every contributor who clones the repository gets Forge activated
automatically without any manual install step.

User scope (`~/.claude/settings.json`) is not supported by `forge:init`. The plugin
must already be installed (via `/plugin install forge@rr-standards --scope project`
or equivalent) before `forge:init` is run.

### TR-5.2: Plugin Discovery

`forge:init` does not create or modify `.claude-plugin/marketplace.json`. That file
is managed exclusively by `forge:pin` (TR-10).

`forge:init` discovers the currently installed Forge plugin by searching the Claude
Code plugin cache. It prefers a `forge-local` installation (set up by `forge:pin`) if
present, falling back to the global `rr-standards` installation. The discovered plugin
path provides the hook script path, template files, and version for Steps 3–7.

If no Forge plugin is found in the cache, `forge:init` fails with a diagnostic
directing the engineer to run `/plugin install forge@rr-standards`.

### TR-5.3: forge_min_version Determination

`forge:init` reads `forge_min_version` from the existing `.claude-plugin/marketplace.json`
if the file is present (written by a prior `forge:pin` run). If the file is absent
(unpinned repository), `forge_min_version` is written as empty in `.forge/version`,
meaning no minimum version is enforced by the version hook.

This design allows `forge:pin` and `forge:init` to be run in any order: if
`forge:pin` was run first, `forge:init` picks up the pinned version automatically.
If `forge:init` was run first, `forge:pin` can be run later and will update
`forge_min_version` in `.forge/version` directly (TR-10.3).

### TR-5.5: Hook Registration

`forge:init` writes exactly one entry to `.claude/settings.json` at project scope: the
`PreToolUse` hook registration pointing to the injection hook script in the plugin cache
(TR-6.3). It does not write `extraKnownMarketplaces` or `enabledPlugins` entries — those
are managed by `forge:pin` (TR-10). Existing settings content outside the forge hook
entry is preserved unchanged.

### TR-5.4: Plugin Path for CLAUDE.md

Standards content is bundled within the cached plugin directory. CLAUDE.md must
reference the plugin cache path for standards navigation. The exact path is resolved
from the cached SHA directory at init time and written into the CLAUDE.md
forge-managed section.

---

## TR-6: Generation Standards Injection Hook

### TR-6.1: Hook Purpose

The generation standards injection hook is a Claude Code `PreToolUse` hook that fires
before any Write or Edit operation and loads the applicable organizational coding
standard for the file being written. This is the mechanism by which standards
enforcement happens at generation time (BR-3) without requiring engineer invocation.

### TR-6.2: Hook Behavior

For each Write or Edit tool call, the hook must:

1. Inspect the target file path and determine its language from the file extension
2. Resolve the corresponding language guide path from the rr-standards installation
3. If a language guide exists: inject it as a system context message before the
   tool call proceeds
4. If no language guide exists for the detected language: proceed without injection
   and log a warning (do not block)
5. If the rr-standards path cannot be resolved: log a warning and proceed (degraded
   mode — do not block file writes)

### TR-6.3: Hook Installation

The hook script lives in the plugin cache at:
`~/.claude/plugins/cache/<marketplace>/forge/<sha>/hooks/pre-tool-use/inject-generation-standards.sh`

It is not copied into the project. `forge:init` registers it in `.claude/settings.json`
by absolute path (TR-3.2). `forge:update` updates the registered path in

`settings.json` to point to the new SHA's hook script when migrating.

### TR-6.4: Hook Testing

The hook is critical infrastructure — a hook that fails silently means standards are
not enforced at generation time and no engineer or tool will detect the gap. The hook
must have automated tests covering: correct language detection, correct standard path
resolution for each supported language, graceful degradation when rr-standards is
unreachable, and correct behavior when the file extension has no associated standard.

---

## TR-7: forge:update Skill

`forge:update` is a **project configuration migration** skill. It does not update the
Forge plugin itself — plugin updates are performed by the developer via
`claude plugin update forge@rr-standards-marketplace`. `forge:update` runs after a
plugin update to migrate the project's committed configuration to match the new plugin
version.

### TR-7.1: Command Surface

`forge:update` accepts the following optional flags:

| Flag | Description | Default |
|------|-------------|---------|
| `--yes` | Skip confirmation for MINOR/PATCH migrations | false |

`forge:update` does not accept a `--version` flag. The target version is always
derived from the current pin in `.claude-plugin/marketplace.json` (set by `forge:pin`)
or, for unpinned repositories, from the currently installed plugin version. To change
the target version, run `forge:pin --version <semver>` first, then run `forge:update`.

When `--version` is omitted, `forge:update` migrates to the latest release tag.
When provided, it resolves the specified tag to its SHA via the GitHub API — the same
resolution mechanism as `forge:init` (TR-5.3). If the specified tag does not exist,
`forge:update` fails with a diagnostic error listing available release tags.

### TR-7.2: Trigger and Scope

`forge:update` detects that the latest available release (or the `--version` specified)
is newer than the `ref` currently pinned in `.claude-plugin/marketplace.json` and
applies the configuration changes required to bring the project up to date.

If the project is already at the target version, `forge:update` exits with a message
confirming the project configuration is current.

### TR-7.3: Pre-Migration Report

Before applying any changes, `forge:update` must produce a report showing:

- Current pinned version (from `.claude-plugin/marketplace.json` `ref` field) vs.
  target version — displayed as human-readable version labels, not SHAs
- Whether the difference is a MAJOR version bump (breaking) or MINOR/PATCH
  (non-breaking)
- Enumerated list of configuration changes that will be applied: `ref` + `sha` update
  in `.claude-plugin/marketplace.json`, `.state.json` schema migrations, hook
  registration updates in `.claude/settings.json`, new `.forge/` directories, CLAUDE.md
  section changes
- Whether any active work items are in progress

The engineer must confirm before changes are applied. `--yes` skips confirmation for
MINOR/PATCH migrations only; MAJOR migrations always require explicit confirmation.

### TR-7.4: Active Work Protection

For MAJOR version migrations, `forge:update` must check for active in-progress work
items (`.state.json` where `currentPhase: "implementation"` and
`phases.implementation.status: "in_progress"`). When detected:

- Emit a warning listing the active work items and their IDs
- Do not apply the major migration automatically
- Instruct the engineer to complete or pause active work items before migrating
- Do not offer to proceed anyway — a partial migration against in-progress work risks
  state corruption

MINOR and PATCH migrations may be applied regardless of active work state.

### TR-7.6: Migration Atomicity

All migrations must be atomic: either all changes are applied successfully or none
are. If any step fails mid-migration, `forge:update` must roll back all changes made
so far and leave the project in its pre-migration state. A failed partial migration
that leaves `.claude-plugin/marketplace.json` on a new SHA while `.forge/version`
still reflects the old version is worse than a clean failure with a clear error.

### TR-7.5: Migration Application

When the engineer confirms, apply:

1. Update `.claude-plugin/marketplace.json`: set `ref` to the target version tag
   and `sha` to the corresponding commit SHA (resolved via GitHub API per TR-5.3)
   (per ADR-026 — this is the primary version pin; Claude Code will load the new
   plugin version on next session start)
2. Fetch and cache the new plugin version if not already in the cache
3. Update hook registrations in `.claude/settings.json` to match the new plugin
   version's hook definitions
4. Update the `forge:managed` section of CLAUDE.md with the new template content,
   preserving all content outside the managed section (TR-2.2)
5. Create any `.forge/` directories introduced in the new plugin version that do not
   yet exist; existing files are never overwritten
6. Update `.forge/version`: set `forge_min_version` to the new version,
   `last_migrated_with`, and `last_migrated_at` (TR-4.3)
7. Print a summary of all changes applied

### TR-7.7: Downgrade Protection

`forge:update` must refuse to migrate to a version older than the current
`active_version` recorded in `.forge/version`. Downgrade migrations are not supported
because they risk corrupting `.state.json` files that were written against a newer
schema.

If the target version (from the pin or from the installed plugin) is less than
`active_version`, `forge:update` must stop with:
> "Downgrade from v<current> to v<target> is not supported. To move to an older
> version, re-initialize the repository from scratch."

If the target equals `active_version`, `forge:update` exits cleanly with "Nothing
to do."

---

## TR-8: Version Enforcement Hook

### TR-8.1: Hook Purpose and Installation

A Claude Code `SessionStart` hook that runs at the start of every session and checks
whether the developer's currently installed Forge plugin version satisfies the minimum
required by the current repository.

Unlike the generation standards injection hook (TR-6), the version enforcement hook is
installed at **`user` scope** as part of the global Forge plugin installation — not by
`forge:init`. It must run even in repositories where `forge:init` has not yet been run,
so it can detect uninitialized repositories. It is registered once when the developer
installs the Forge plugin and applies to all their Claude Code sessions.

### TR-8.2: Enforcement Behavior

At session start, the hook must:

1. Check whether `.forge/version` exists in the current repository
2. If absent: emit a non-blocking notice that this repository is not initialized;
   suggest running `forge:init` (do not block — the developer may be in a repository
   that intentionally does not use Forge)
3. If present: read `forge_min_version` and compare to the installed plugin version
   at `~/.claude/plugins/cache/forge/plugin.json`

Per ADR-026, each project pins its plugin version via `.claude-plugin/marketplace.json`.
Claude Code loads the pinned version automatically; the active version and the project's
required version are always in sync unless `.forge/version` has been manually edited or
the cache entry was evicted. Version comparison outcomes:

- **Active version ≥ `forge_min_version`**: proceed. If a newer version is available
  in the rr-standards marketplace, emit a non-blocking notice suggesting `forge:update`.

- **Active version < `forge_min_version`**: the local marketplace pin and `.forge/version`
  are out of sync — most likely because `.forge/version` was manually edited or the cache
  was cleared. Block with a diagnostic error and instruct the engineer to run
  `forge:update` to re-establish consistency. If an active implementation task is in
  progress, emit a warning instead of a block and allow the session to proceed.

- **No `.forge/version`**: emit a non-blocking notice that this repository is not
  initialized and suggest running `forge:init`. Do not block — the developer may be
  in a repository that intentionally does not use Forge.

### TR-8.3: Mandatory Update Deadline Enforcement

In addition to per-repository minimum version enforcement, the hook must enforce
organization-wide mandatory update deadlines. These are defined in `VERSIONS.json`
in the marketplace repository and specify a `mandatoryAfter` date per major version:

```json
{
  "v2": {
    "latestRelease": "2.1.0",
    "mandatoryAfter": "2026-05-01"
  }
}
```

After `mandatoryAfter`, a developer still on an older major version is blocked
regardless of the repository's `forge_min_version`. This enforcement applies even
if the repository's `forge_min_version` is satisfied by the older version.

If `VERSIONS.json` is unreachable (network unavailable, marketplace offline), the
hook must degrade gracefully: skip the deadline check, emit a warning that mandatory
deadline enforcement could not be verified, and allow the session to proceed. The
per-repository minimum version check (TR-8.2) still runs using locally available data.

---

## TR-9: Compliance Exemption

### TR-9.1: Exemption Record

A repository may exempt itself from coding standards enforcement by creating
`.forge/compliance` as a key=value file (same format as `.forge/version`):

```
coding_standards=exempt
reason=Repository deprecated — scheduled for decommission Q3 2026
```

Fields:
- `coding_standards` — `enforced` (default) or `exempt`. Controls coding standards
  enforcement only: the generation standards injection hook, the coding standards
  check in `forge:review`, and version deadline blocking.
- `reason` — free text; required when `coding_standards=exempt`

When `.forge/compliance` is absent or `coding_standards` is absent, `enforced` is
assumed. `forge:init` does not create `.forge/compliance` — its absence means full
enforcement.

The field is named `coding_standards` rather than a generic `mode` to allow the
file to express other exemption types in future (e.g. `security_review`) without
ambiguity.

### TR-9.2: Effect on Generation Standards Injection Hook

When `coding_standards=exempt`, the injection hook must skip standard injection and
exit 0 silently. The hook reads `.forge/compliance` at runtime:

```bash
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  [ "$cs" = "exempt" ] && exit 0
fi
```

### TR-9.3: Effect on Version Enforcement Hook

When `coding_standards=exempt`, the version enforcement hook must not block the
session for version mismatch or mandatory deadline. It must emit a non-blocking
notice identifying the repository as coding-standards-exempt and allow the session
to proceed.

### TR-9.4: Effect on forge:review

When `coding_standards=exempt`, `forge:review` must skip the coding standards check
(`rr-standards-plugin` category) and run all other checks normally:

- ❌ Coding standards (`rr-standards-plugin`) — skipped
- ✅ Security — runs normally
- ✅ Privacy — runs normally
- ✅ Error handling — runs normally
- ✅ Traceability — runs normally
- ✅ Duplication — runs normally
- ✅ Historical context — runs normally

The review report must note that coding standards enforcement is exempt. This is a cross-cutting concern: the `forge:review` skill must read
`.forge/compliance` before spawning specialist agents.

### TR-9.5: What Exemption Does Not Affect

The following are unaffected by `coding_standards=exempt`:
- All non-coding-standards review checks (security, privacy, error handling, etc.)
- `forge:init` and `forge:update` — operate normally
- Work item tracking (`.forge/efforts/`) — unaffected
- Deployable artifact management (`.forge/deployables/`) — unaffected
- CLAUDE.md generation and maintenance — unaffected

---

## TR-10: forge:pin Skill

### TR-10.1: Command Surface

`forge:pin` pins a repository to a specific Forge plugin version. It is optional —
repos without a pin load whatever version the engineer has globally installed.

| Flag | Description | Default |
|------|-------------|---------|
| `--version <semver>` | Version to pin to (e.g. `1.2.3` or `v1.2.3`) | latest release |

`forge:pin` and `forge:init` are order-independent. Both must be idempotent —
re-running `forge:pin` to the same version must produce an "unchanged" result.

### TR-10.2: Local Marketplace Creation

`forge:pin` must create or update `.claude-plugin/marketplace.json` in the project
root, pinning the Forge plugin to a specific release using both a semantic version
tag and its corresponding commit SHA:

```json
{
  "name": "forge-local",
  "plugins": [{
    "name": "forge",
    "source": {
      "source": "git-subdir",
      "url": "https://github.com/rewards-guilds/rr-standards.git",
      "path": "plugins/forge",
      "ref": "v1.2.3",
      "sha": "<commit-sha-for-v1.2.3>"
    }
  }]
}
```

`forge:pin` must also write to `.claude/settings.json`:
- `extraKnownMarketplaces["forge-local"]` pointing to `./.claude-plugin`
- `enabledPlugins["forge@forge-local"]` set to `true` (removing any other `forge@*` entries)

### TR-10.3: forge_min_version Sync

If `.forge/version` exists when `forge:pin` is run, `forge:pin` must update
`forge_min_version` to the new pin value. This keeps the version record in sync
with the pin without requiring `forge:init` to be re-run.

### TR-10.4: Plugin Installation

After writing the marketplace configuration, `forge:pin` must instruct the engineer
to run `/plugin install forge@forge-local` to fetch and cache the pinned version.
`forge:pin` must pause and wait for confirmation before completing, because subsequent
`forge:update` steps require the plugin to be cached.

### TR-10.5: Version Tag Resolution

`forge:pin` resolves the target version as follows:
1. If `--version <semver>` is provided: verify the tag exists and retrieve its SHA
2. If omitted: fetch the latest release tag and its SHA
3. Both `ref` and `sha` are written to the marketplace config (cryptographic pin)
4. If the repo is already pinned to the requested version with identical SHA, exit
   cleanly with "Already pinned. Nothing to do."

### TR-10.6: Commit Requirement

The files modified by `forge:pin` (`.claude-plugin/marketplace.json`,
`.claude/settings.json`, `.forge/version`) must be committed to version control for
the pin to be shared with the team. `forge:pin` must include an explicit commit
reminder in its output with the exact git commands to use.

---

## Constraints

### Technical Constraints

- All skills and hooks must run within Claude Code without requiring additional
  runtime dependencies beyond a standard development environment (shell, git)
- The version enforcement hook must not add perceptible latency to normal session
  starts when the repository is current; the check must complete in under 500ms
- CLAUDE.md merge operations must be implemented without sed or awk; file reads and
  writes are handled by Claude Code tools directly
- The hooks format must be compatible with the Claude Code hooks specification;
  the specific format (shell, JS, Python) is deferred to design

### Process Constraints

- `forge:init` must never modify files outside of CLAUDE.md, `.forge/`, and
  `.claude/settings.json`; it must not touch source code, test files, or existing
  configuration files. `.claude-plugin/` is owned by `forge:pin`, not `forge:init`.
- `forge:init` must not install the Forge plugin or the `gh` CLI — both must
  already be present before `forge:init` is run
- The `gh` CLI must be installed and authenticated before using any Forge skill or
  hook that makes GitHub API calls; Forge does not configure `gh` authentication
- The `rr-core` package must declare `Bash(gh *)` in its `settings.json` permissions
  (currently only the `review` package declares this)
- Every Forge release must be tagged in the rr-standards repository using semantic
  versioning (`v<major>.<minor>.<patch>`); untagged commits cannot be referenced by
  `--version` and are not valid pin targets
- Mandatory update deadlines are set by Productivity Engineering in `VERSIONS.json`
  in the marketplace and must be changeable without modifying the hook itself
- Active work protection in `forge:update` applies only to MAJOR version migrations;
  MINOR and PATCH migrations may be applied without active work checks

### Open Questions

1. ~~**rr-standards package path for per-project mode**~~ — **Resolved:** The Forge
   plugin is a Claude Code plugin cached at `~/.claude/plugins/cache/forge/` on the
   developer's machine. There is no per-project plugin code directory. Plugin scope
   (`user` vs `project`) controls which `settings.json` file activates the plugin,
   not where the plugin code lives. CLAUDE.md references the static plugin cache path.

2. ~~**Hook format**~~ — **Resolved:** Shell scripts (`.sh`). JSON parsing uses
   `sed` with known field patterns — no external tools required. The `.forge/version`
   file uses `key=value` format (not JSON) specifically to make shell parsing trivial.
   `VERSIONS.json` from the marketplace is parsed with `sed` after `curl` fetch.
   All logic (semver comparison, ISO date comparison) is implementable in pure POSIX
   shell. Shell is consistent with the existing hook convention in the codebase.

3. **Lag period default values** — what are the Productivity Engineering-defined
   maximum lag periods for breaking and non-breaking Forge updates?
   - **Impact:** TR-8.2 enforcement behavior; determines how aggressively version
     enforcement blocks sessions
   - **Decision needed by:** design phase; requires Productivity Engineering input

4. **Cross-repo downstream consumer identification** — when a deployable's published
   interface changes, Forge can identify consuming deployables within the same repository
   by scanning `dependencies/` directories under `.forge/deployables/`. It cannot
   automatically identify consumers in other repositories. Options include: a
   central interface registry (external service, conflicts with ADR-001); a
   convention-based search across repositories (requires cross-repo tooling); or
   relying on PR description and `forge:review` output to signal that an interface
   changed, leaving cross-repo consumer notification to the publishing team.
   - **Impact:** `forge:product-update` behavior when a `spec/interfaces/` artifact
     changes; PR review output for interface-changing PRs
   - **Decision needed by:** design phase for `forge:product` and `forge:product-update`
     skills

5. ~~**`repo_type` determination at `forge:init` time**~~ — **Resolved:** `forge:init`
   defaults `repo_type` to `deployable` (the common case — source code repositories).
   Engineers initializing a project-coordination repository (ADR-027) manually change
   the value to `project` after `forge:init` completes. No flag is added; TR-1.1
   (no flags) is preserved. This is a one-time action for a minority of repositories.

6. **Cross-repo `parentId` reference format stability** — the workflow design specifies
   a provisional `repo:org/repo/work-item-id` format for cross-repo work item
   references in `.state.json`, but the format is coupled to the GitHub repository
   location. Two problems are unresolved: (a) resolution — how does tooling map a
   `repo:` URI to a filesystem path or clone URL without assuming a fixed directory
   layout; (b) identity stability — when a project migrates from a private repository
   to a shared one (per ADR-027), all `repo:` references pointing at the old location
   must remain valid or be updated atomically. The canonical identity scheme for a
   effort repository must be decided before the format is considered settled.
   - **Impact:** `.state.json` schema migrations (TR-7, Step 9.4); any skill that
     reads or writes `parentId` or `effortRef` for cross-repo work items
   - **Decision needed by:** design phase for the Multi-Repository Project Support epic
     (Initiative 2)

7. **Project repository discovery** — when an engineer in a product repository needs
   to navigate upstream to a effort repository (e.g., to read the project-level
   requirements that motivated a local epic), there is no specified mechanism for
   knowing which effort repository to look in. Options include: a
   `.forge/project-repos.json` registry file written by `forge:init` or a separate
   skill; a CLAUDE.md directive; convention-based naming; or a central registry
   service (conflicts with ADR-001).
   - **Impact:** `forge:init` behavior in product repositories participating in
     cross-repo projects; CLAUDE.md template content for product repositories
   - **Decision needed by:** design phase for the Multi-Repository Project Support epic
     (Initiative 2)
