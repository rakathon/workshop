# Success Criteria — Installation & Distribution

- [ ] A new repository can be fully initialized for Forge development with a single
      `forge:init` invocation, with no additional configuration required afterward
- [ ] Running `forge:init` on a repository with an existing CLAUDE.md preserves all
      pre-existing CLAUDE.md content; only Forge-specific sections are added or updated
- [ ] After `forge:init`, writing a source file in Claude Code automatically loads
      the correct language-specific coding standard without engineer invocation
- [ ] `forge:init` writes to `.claude/settings.json` (project scope); any contributor
      who clones the repository gets the hook registered automatically
- [ ] Every initialized repository contains `.forge/version` with the installed plugin
      version and initialization timestamp; `forge_min_version` is populated from the
      pin when `forge:pin` has been run, or left empty for unpinned repositories
- [ ] `forge:pin` creates `.claude-plugin/marketplace.json` pinning the team to a
      specific Forge version; re-running to the same version produces "nothing to do"
- [ ] Files written by `forge:pin` (marketplace.json, settings.json, .forge/version)
      include an explicit commit reminder so engineers know to share the pin
- [ ] `forge:update` reports a diff of what will change before applying any changes;
      engineers can accept or abort before changes are applied
- [ ] `forge:update` refuses downgrade migrations with a clear diagnostic
- [ ] Session start in a repository behind the current Forge release emits a visible,
      non-blocking upgrade notice
- [ ] Repositories exceeding the Productivity Engineering-defined maximum lag period
      are blocked by the version enforcement hook before new tasks begin; in-progress
      implementation tasks are not blocked mid-task
- [ ] A repository can set `coding_standards=exempt` in `.forge/compliance`;
      engineers are not blocked by standards injection, the coding standards check
      in forge:review, or version deadline blocking; all other review checks still run
- [ ] Every coding standards exemption has a committed reason
- [ ] Coding standards exemption does not disable Forge work item tracking,
      forge:init, forge:update, or non-coding-standards review checks
