# forge-init — Implementation Plan

Design references: `../spec/skills.md`, `../spec/hooks.md`

---

## Delivery Order

```
Wave 1 (parallel — no dependencies):
  T-1  Injection hook script
  T-2  Enforcement hook script
  T-3  CLAUDE.md managed-section template
  T-4  .forge/ directory file templates
  T-9  marketplace.json
  T-10 VERSIONS.json

Wave 2 (depends on Wave 1):
  T-5  forge:init SKILL.md
  T-11 forge:pin SKILL.md

Wave 3 (parallel — depend on Wave 2):
  T-6  forge:init README.md
  T-7  forge:update SKILL.md
  T-12 forge:pin README.md

Wave 4 (depends on T-7):
  T-8  forge:update README.md
```

---

## T-1: Generation Standards Injection Hook

**File:** `plugins/forge/hooks/pre-tool-use/inject-generation-standards.sh`

**Design ref:** `../spec/hooks.md § Hook 1`

| # | Description |
|---|-------------|
| T-1.1 | Write hook script: compliance check (`coding_standards=exempt` → exit 0), file path extraction from env, language detection via extension case statement, plugin-root resolution via `BASH_SOURCE`, language guide path construction, stdout injection via `cat`, graceful degradation for missing guide or unrecognised extension |
| T-1.2 | Make script executable (`chmod +x`) |

**Acceptance:**
- `.go` file → Go guide injected to stdout; exits 0
- `.java` file → Java guide injected; exits 0
- `.md` file → no injection; exits 0 silently
- Guide file absent → warning to stderr; exits 0
- `coding_standards=exempt` in `.forge/compliance` → exits 0 silently

---

## T-2: Version Enforcement Hook

**File:** `plugins/forge/hooks/session-start/forge-version-check.sh`

**Design ref:** `../spec/hooks.md § Hook 2`

| # | Description |
|---|-------------|
| T-2.1 | Write hook script: `.forge/version` existence check; compliance exemption check; read `forge_min_version` and `active_version` via `grep`/`cut`; `version_gte` semver comparison helper; `has_active_impl` work item check; `gh api` fetch of `VERSIONS.json` with `--template`/`base64 -d`; ISO date comparison for `mandatoryAfter`; 30-day warning window; all blocking/warning/notice exit paths |
| T-2.2 | Make script executable |

**Acceptance:**
- No `.forge/version` → notice to stderr; exits 0
- `active_version < forge_min_version`, no active task → error; exits 1
- `active_version < forge_min_version`, active impl task → warning; exits 0
- `mandatoryAfter` passed → error; exits 1
- Within 30-day window → warning; exits 0
- `VERSIONS.json` unreachable → warning; exits 0
- `coding_standards=exempt` → notice; exits 0

---

## T-3: CLAUDE.md Managed-Section Template

**File:** `plugins/forge/templates/claude-md.md`

**Design ref:** `../spec/skills.md § CLAUDE.md Template`

| # | Description |
|---|-------------|
| T-3.1 | Write the managed-section template content: `<!-- forge:managed:start -->` / `<!-- forge:managed:end -->` markers wrapping Forge version notice, standards navigation instruction (read AGENTS.md), plugin cache path reference, deployable artifacts instruction (read `.forge/deployables/<name>/`), PM product artifacts instruction (read `.forge/products/<name>/` in product-role repos), work items reference |

**Acceptance:**
- File contains both managed-section markers exactly once
- Contains instruction to read AGENTS.md with plugin cache path placeholder
- Contains instruction to read `.forge/deployables/<name>/`
- Contains instruction to read `.forge/products/<name>/` (product-role repos)
- Contains plugin version placeholder (`{{version}}`) for substitution at init time

---

## T-4: .forge/ Directory File Templates

**Directory:** `plugins/forge/templates/forge/`

**Design ref:** `../spec/skills.md § forge:init Step 6`

| # | Description |
|---|-------------|
| T-4.1 | `templates/forge/README.md` — empty work item registry (table with headers: ID, Title, Type, Tier, Risk, Phase, Status) |
| T-4.2 | `templates/forge/spec/README.md` — repo-level cross-product design index (mirrors current `.forge/spec/README.md` structure) |
| T-4.3 | `templates/forge/spec/arch-decisions/README.md` — empty ADR index (table with headers: ADR, Title, Status; note about adding ADRs) |
| T-4.4 | `templates/forge/products/README.md` — empty product registry (table with headers: Product, Type, Status, Description) |
| T-4.5 | `templates/forge/projects/README.md` — empty work item registry index (table with headers: ID, Title, Type, Parent, Risk, Phase, Status) |

**Acceptance:**
- Each template file is valid Markdown
- Tables have correct headers matching the conventions established in this repository

---

## T-5: forge:init SKILL.md

**File:** `plugins/forge/skills/init/SKILL.md`

**Design ref:** `../spec/skills.md § forge:init`
**Depends on:** T-1, T-2, T-3, T-4 (must know what each produces)

| # | Description |
|---|-------------|
| T-5.1 | Write SKILL.md frontmatter (name, description) and preconditions (plugin installed via cache search, not inside `.forge/` subdir, no duplicate managed markers) |
| T-5.2 | Implement Step 1: discover installed plugin from cache (prefer forge-local, fall back to rr-standards); extract plugin_root, sha, marketplace_dir, version; validate version extracted |
| T-5.3 | Implement Step 2: merge mode detection (`.forge/` exists → merge) |
| T-5.4 | Implement Step 3: read `forge_min_version` from `.claude-plugin/marketplace.json` if present, else empty |
| T-5.5 | Implement Step 4: register PreToolUse hook in `.claude/settings.json`; detect created/updated/unchanged |
| T-5.6 | Implement Step 5: create `.forge/` directory structure from T-4 templates; skip existing files |
| T-5.7 | Implement Step 6: write `.forge/version` (key=value; 6 fields including `active_version`); skip if exists in merge mode |
| T-5.8 | Implement Step 7: CLAUDE.md create/merge using T-3 template; managed-section marker handling |
| T-5.9 | Implement Step 8: print structured summary (Created / Updated / Unchanged sections) with commit reminder |

**Acceptance:**
- Running in empty repo: all files created; `.forge/version` written; CLAUDE.md created with managed section
- Running in repo with existing CLAUDE.md: content outside managed section preserved
- Running twice (idempotent): no files overwritten; summary shows "Unchanged"
- forge:pin run first: `forge_min_version` populated from marketplace.json
- forge:pin not run: `forge_min_version` written as empty

---

## T-6: forge:init README.md

**File:** `plugins/forge/skills/init/README.md`

**Depends on:** T-5

| # | Description |
|---|-------------|
| T-6.1 | Write README: purpose, when to use (no flags), idempotency note, relationship to forge:pin (order-independent), what gets created (file list), post-init commit instruction |

---

## T-7: forge:update SKILL.md

**File:** `plugins/forge/skills/update/SKILL.md`

**Design ref:** `../spec/skills.md § forge:update`
**Depends on:** T-5, T-11

| # | Description |
|---|-------------|
| T-7.1 | Write SKILL.md frontmatter and preconditions (`.forge/version` exists; plugin installed) |
| T-7.2 | Implement Step 1: read `active_version` from `.forge/version` |
| T-7.3 | Implement Step 2: resolve target version — from marketplace.json pin if present, else from installed plugin; refuse downgrade; exit cleanly if already at target |
| T-7.4 | Implement Step 3: discover plugin root from cache |
| T-7.5 | Implement Step 4: classify MAJOR vs MINOR/PATCH |
| T-7.6 | Implement Step 5: active work item scan for MAJOR migrations; block if active impl task found |
| T-7.7 | Implement Steps 6–7: fetch migration manifest; pre-migration report with confirmation (`--yes` for MINOR/PATCH only) |
| T-7.8 | Implement Step 8: snapshot for rollback |
| T-7.9 | Implement Step 9: atomic migration (update hook paths in settings.json; refresh CLAUDE.md; create new `.forge/` dirs; apply schema migrations; update `.forge/version` active_version); rollback on any failure |

**Acceptance:**
- Already at target version: exits with "nothing to do"
- Downgrade attempt: refused with diagnostic
- MINOR migration: report shown; `--yes` skips confirmation; hook paths and CLAUDE.md updated
- MAJOR migration with active impl task: blocked with task IDs listed
- MAJOR migration confirmed: all steps applied atomically
- Failure mid-migration: all changes rolled back; error identifies failed step

---

## T-8: forge:update README.md

**File:** `plugins/forge/skills/update/README.md`

**Depends on:** T-7

| # | Description |
|---|-------------|
| T-8.1 | Write README: purpose, distinction from `/plugin update` and `forge:pin`, `--yes` flag, MAJOR vs MINOR/PATCH behaviour, atomicity guarantee, downgrade not supported |

---

## T-9: marketplace.json

**File:** `marketplace.json` (rr-standards repository root)

**Design ref:** `../spec/README.md § Key File Locations`

| # | Description |
|---|-------------|
| T-9.1 | Write `marketplace.json` listing the forge plugin with `source: "./plugins/forge"` (relative path within this repo) |

**Acceptance:**
- Valid JSON; `name` matches plugin name in `plugins/forge/.claude-plugin/plugin.json`
- Source path resolves to the plugin directory

---

## T-10: VERSIONS.json

**File:** `VERSIONS.json` (rr-standards repository root)

**Design ref:** `../spec/hooks.md § VERSIONS.json Fetch`

| # | Description |
|---|-------------|
| T-10.1 | Write initial `VERSIONS.json` with an entry for the current major version (v0); `latestRelease` and `mandatoryAfter` placeholder (Productivity Engineering to set real date before enforcement is activated) |

**Acceptance:**
- Valid JSON; structure matches the schema the enforcement hook parses
- `mandatoryAfter` set to a far-future date so enforcement is not immediately triggered

---

## T-11: forge:pin SKILL.md

**File:** `plugins/forge/skills/pin/SKILL.md`

**Design ref:** `../spec/skills.md § forge:pin`
**Depends on:** T-1, T-2, T-3, T-4

| # | Description |
|---|-------------|
| T-11.1 | Write SKILL.md frontmatter and preconditions (`gh` installed and authenticated, not inside `.forge/` subdir) |
| T-11.2 | Implement Step 1: resolve target version via `gh api`; strip leading `v` from user input; error with available tags on not-found |
| T-11.3 | Implement Step 2: apply all file changes in single Python script (marketplace.json, settings.json, .forge/version); compare before/after; output STATUS line and change details |
| T-11.4 | Implement Step 3: conditional plugin install prompt — only when marketplace.json was created or updated (pin changed) |
| T-11.5 | Implement Step 4: print structured summary (Created / Updated / Unchanged); include commit reminder with exact git commands |

**Acceptance:**
- First-time pin: marketplace.json created, settings.json updated, prompt shown
- Re-pin to same version: "Already pinned. Nothing to do."
- Re-pin to different version: marketplace.json updated, install prompt shown
- `--version v1.2.3` (with v prefix): correctly strips to produce tag `v1.2.3`
- `.forge/version` exists: `forge_min_version` updated
- `.forge/version` absent: no error; noted in summary

---

## T-12: forge:pin README.md

**File:** `plugins/forge/skills/pin/README.md`

**Depends on:** T-11

| # | Description |
|---|-------------|
| T-12.1 | Write README: purpose, when to use (optional, order-independent with forge:init), `--version` flag, what gets created/updated, post-pin commit requirement |

---

## Completion Criteria

The forge-init epic is complete when:
- [ ] T-1: injection hook script present and executable
- [ ] T-2: enforcement hook script present and executable
- [ ] T-3: CLAUDE.md template present with correct managed-section markers
- [ ] T-4: all five `.forge/` directory templates present
- [ ] T-5: `forge:init` SKILL.md implements all 8 steps; passes acceptance criteria
- [ ] T-6: `forge:init` README.md present
- [ ] T-7: `forge:update` SKILL.md implements all 9 steps; passes acceptance criteria
- [ ] T-8: `forge:update` README.md present
- [ ] T-9: `marketplace.json` present at repository root
- [ ] T-10: `VERSIONS.json` present at repository root
- [ ] T-11: `forge:pin` SKILL.md implements all 4 steps; passes acceptance criteria
- [ ] T-12: `forge:pin` README.md present
