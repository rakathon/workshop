# Business Requirements — forge:update

---

### BR-1: Determine the Version the Repository Was Last Configured Against

`forge:update` must identify which version of the Forge plugin last configured the
current repository. This version is the baseline from which any migration must depart.
Without a reliable baseline, the skill cannot determine which migrations are needed, and
cannot guarantee that re-running after a partial failure will converge rather than
re-apply changes that already succeeded.

The repository version record is the authoritative source for this baseline. It must
reflect the version that successfully completed configuration — not the version that
initiated it.

---

### BR-2: Determine the Target Version from the Project's Pin or the Installed Plugin

`forge:update` must identify the version it should migrate the repository to. The target
is determined by the project's configuration, not by a user-supplied argument:

- If the project has a version pin (`.claude-plugin/marketplace.json`), the target is
  the version declared in that pin. Engineers change the target by running `forge:pin
  --version <semver>` before running `forge:update`.
- If the project has no pin, the target is the version currently installed in the
  developer's plugin cache.

This design keeps "deciding which version to use" (a team decision, expressed by the
pin) separate from "migrating the repository to that version" (a mechanical operation,
performed by `forge:update`). A `--version` flag on `forge:update` would allow the
target to diverge from what the team has committed, creating a state where the
repository appears migrated to a version the team has not actually adopted.

---

### BR-3: Apply All Configuration Changes Required by the Target Version

When the repository is behind the target version, `forge:update` must apply every
configuration change the new version requires. This includes, but is not limited to:

- Updating the version references in the repository's version record and in CLAUDE.md
- Updating hook registrations to reference the correct scripts for the new version
- Creating any new `.forge/` directories or files introduced in the new version
- Renaming or restructuring existing `.forge/` directories or files when a new version
  requires a different layout
- Migrating `.state.json` schema fields when the work-item schema changes between versions

The set of required changes is version-specific. `forge:update` must not hard-code
assumptions about what migrations are needed; it must apply whatever the new version
declares. This allows future Forge releases to introduce structural changes without
requiring changes to the migration mechanism itself.

---

### BR-4: Do Nothing When the Repository Is Not Initialized

If the current repository does not have a Forge version record, `forge:update` must
not attempt any migration. It must output a clear, actionable message explaining that
the repository is not yet initialized and directing the engineer to run `forge:init`
first.

Silent failure or partial execution in an uninitialized repository would leave the
repository in an ambiguous state — neither uninitialized nor correctly configured.
`forge:update` has no reliable baseline to depart from without the version record
that `forge:init` creates.

---

### BR-5: Do Nothing When the Repository Is Already at the Target Version

If the repository's version record already reflects the target version, `forge:update`
must not re-apply migrations. It must output a clear message confirming that the
repository configuration is current and no action is needed.

This allows engineers to run `forge:update` defensively — to verify that a repository
is up to date — without risk of unintended changes. It also makes `forge:update` safe
to invoke in automation (e.g., as part of a team onboarding script) where the version
state of each repository is not known in advance.

---

### BR-6: Update the Version Record Last to Enable Safe Re-Runs

The version record in the repository must be the last thing `forge:update` modifies.
All other configuration changes — directory creation, file restructuring, CLAUDE.md
updates, hook registration updates — must be applied before the version record is
updated to reflect the new version.

This ordering guarantee makes `forge:update` safe to re-run after a partial failure.
If the skill stops mid-migration — due to an error, a session interruption, or a
hook abort — the version record will still reflect the previous version. A subsequent
`forge:update` invocation will detect that the migration is incomplete and re-apply it
from the beginning, rather than concluding (incorrectly) that the migration succeeded.

An updated version record is the commit of record that migration is complete. Nothing
prior to that commit is final.
