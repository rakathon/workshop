# forge-update — Implementation Plan

Design reference: `../spec/skills.md`

Current state: `plugins/forge/skills/update/SKILL.md` and `README.md` exist from the
forge-init epic. They cover the basic migration flow but are missing the migration
manifest system, multi-version sequencing, idempotency rules, and terminal version
record guarantee. The `plugins/forge/migrations/` directory does
not exist.

---

## Delivery Order

```
Wave 1 (no dependencies):
  T-1  migrations/ directory and README

Wave 2 (depends on T-1 for manifest path; sequential — same file):
  T-2  SKILL.md — Step 6: multi-version manifest discovery
  T-3  SKILL.md — Step 9: restructure migration application
  T-4  SKILL.md — Step 10: terminal version record

Wave 3 (depends on T-2 and T-3 — references their outputs):
  T-5  SKILL.md — Steps 7 and 8: pre-migration report and snapshot

Wave 4 (depends on T-3, T-4, T-5 — rollback mirrors snapshot and step 9):
  T-6  SKILL.md — Rollback

Wave 5 (depends on all SKILL.md changes):
  T-7  README.md
```

---

## T-1: migrations/ Directory and README

**Files:**
- `plugins/forge/migrations/` (new directory)
- `plugins/forge/migrations/README.md` (new file)

| # | Description |
|---|-------------|
| T-1.1 | Create `plugins/forge/migrations/` directory with a `.gitkeep` |
| T-1.2 | Write `README.md` explaining: the manifest filename convention (`<from-version>-to-<to-version>.json`), the full JSON schema (from/to/breaking/steps fields), all four supported operation types (`create-dir`, `rename`, `state-field`, `claude-md`) with their required fields and idempotency behavior, and the rule that an absent manifest means no structural changes for that version transition |

**Acceptance:**
- `plugins/forge/migrations/` exists and is tracked in git
- README documents the filename convention with an example filename
- README documents the full manifest JSON schema with an example
- README documents all four op types, their required fields, and their idempotency behavior
- README notes that unrecognised `op` values cause `forge:update` to abort before applying any changes

---

## T-2: SKILL.md — Step 6: Multi-Version Manifest Discovery

**File:** `plugins/forge/skills/update/SKILL.md`

**Current state:** Step 6 looks for a single file at
`<plugin_root>/migrations/<current_major>-to-<target_major>.md` and returns either
"manifest present" or "configuration-only".

**Required state:** Step 6 scans the `migrations/` directory for all applicable JSON
manifests, filters to the current→target version range, sorts them into application
order, and returns an ordered list.

| # | Description |
|---|-------------|
| T-2.1 | Replace the single-file lookup with a directory scan of `<plugin_root>/migrations/*.json` |
| T-2.2 | Add filename parsing: extract `from` and `to` semver values from each filename using the `<from>-to-<to>.json` convention |
| T-2.3 | Add version range filter: keep only manifests where `from` ≥ `current_version` and `to` ≤ `target_version` |
| T-2.4 | Add ascending sort by `from` version |
| T-2.5 | Add unrecognised-op validation: read each manifest in the sequence and check all `op` values against the allowed set before Step 8 (before any changes are applied). Abort with a diagnostic identifying the unknown op and the manifest filename if any are found |
| T-2.6 | Handle no-manifests case: set `configuration_only=true` and continue — the always-required operation (CLAUDE.md refresh) still runs |

**Acceptance:**
- Repo at v1.0.0, plugin at v3.0.0, manifests exist for v1→v2 and v2→v3: sequence is [v1→v2, v2→v3]
- Repo at v1.0.0, plugin at v1.2.0, no manifests in range: `configuration_only=true`
- Manifest contains unrecognised op: abort with diagnostic before Step 8 (no files changed)
- Manifests present but none in range: treated as `configuration_only=true`

---

## T-3: SKILL.md — Step 9: Restructure Migration Application

**File:** `plugins/forge/skills/update/SKILL.md`

**Current state:** Step 9 has five sub-steps — 9.1 CLAUDE.md refresh, 9.2 create
directories, 9.3 state-field migrations, 9.4 version record update, 9.5 print summary.
Missing: rename operation, idempotency rules; `.forge/version` update must be removed
(it moves to Step 10). Note: hooks are auto-registered from the installed plugin —
no `.claude/settings.json` writes needed.

**Required state:** Step 9 applies the always-required CLAUDE.md refresh then
manifest-declared operations in sequence, with explicit idempotency rules for each
operation type. `.forge/version` update and print summary are no longer part of Step 9.

| # | Description |
|---|-------------|
| T-3.1 | ~~Add hook-path update~~ — removed; hooks are auto-registered from the installed plugin |
| T-3.2 | Establish CLAUDE.md refresh as the sole always-required operation before manifest steps. Idempotency: full replacement is always safe |
| T-3.3 | Restructure manifest step application: for each manifest in the ordered sequence from Step 6, apply its `steps` array in order |
| T-3.4 | Implement `create-dir` with idempotency: check if directory exists before creating; skip with no output if already present; append to `new_paths_created` on creation |
| T-3.5 | Implement `rename` with idempotency: skip if `from` is absent (already applied); error if both `from` and `to` exist (ambiguous — report and stop, do not roll back, require engineer resolution); on success append `to` to `new_paths_created` |
| T-3.6 | Implement `state-field` with idempotency: for each `.forge/efforts/*/.state.json`, skip the file if it already uses the new field name; otherwise read, rename field at all levels, write back |
| T-3.7 | Remove Step 9.4 (version record update) and Step 9.5 (print summary) — these become Steps 10 and 11 |

**Acceptance:**
- `create-dir` skips silently if the directory exists
- `rename` skips silently if `from` is absent
- `rename` stops with an error message (not a rollback) if both `from` and `to` exist
- `state-field` processes every `.state.json` in `.forge/efforts/`; skips files already using the new field name
- `.forge/version` is not written anywhere in Step 9

---

## T-4: SKILL.md — Step 10: Terminal Version Record

**File:** `plugins/forge/skills/update/SKILL.md`

**Current state:** `.forge/version` is updated in Step 9.4, updating `active_version`,
`last_migrated_with`, and `last_migrated_at`. `forge_min_version` is not updated.

**Required state:** Version record update is a new Step 10, is the last write operation
before the summary, and updates all four fields.

| # | Description |
|---|-------------|
| T-4.1 | Extract the version record update from Step 9.4 and create a new Step 10 section |
| T-4.2 | Add `forge_min_version` to the fields updated, set to `<target_version>` |
| T-4.3 | Add an explicit note in Step 10: this is the terminal write operation; its completion is the signal that migration succeeded; `initialized_with` and `initialized_at` are never modified by `forge:update` |
| T-4.4 | Add a note for the edge case where Step 9 succeeds but Step 10 fails: report the error and explain that the repository is fully migrated but the version record was not written; re-running `forge:update` is safe and all Step 9 operations will be skipped via idempotency |

**Acceptance:**
- `.forge/version` is not written in Step 9; it is only written in Step 10
- Step 10 updates `active_version`, `forge_min_version`, `last_migrated_with`, `last_migrated_at`
- Step 10 does not modify `initialized_with` or `initialized_at`
- Step 10 failure message explains re-run is safe

---

## T-5: SKILL.md — Steps 7 and 8: Report and Snapshot

**File:** `plugins/forge/skills/update/SKILL.md`

**Current state:**
- Step 7 report lists CLAUDE.md and `.forge/version` changes but not manifests being applied.
- Step 8 snapshot covers only CLAUDE.md and `.forge/version`.

**Required state:**
- Step 7 report enumerates all manifests being applied and all operations from those manifests.
- Step 8 snapshot includes the `from` path for any `rename` operations in the manifests.
  Note: `.claude/settings.json` is not included — hooks are auto-registered from the plugin.

| # | Description |
|---|-------------|
| T-5.1 | ~~Update Step 7 report to include `.claude/settings.json`~~ — removed; no hook writes |
| T-5.2 | Update Step 7 report to show how many manifests will be applied and list each one (e.g., "v1.0.0 → v2.0.0  (3 steps)") |
| T-5.3 | Update Step 7 report to enumerate each operation from the manifests (one line per step), so the engineer can see exactly what structural changes will be made before confirming |
| T-5.4 | Update Step 7 report to describe `.forge/version` changes as updating all four fields: `active_version`, `forge_min_version`, `last_migrated_with`, `last_migrated_at` |
| T-5.5 | ~~Update Step 8 snapshot to include `.claude/settings.json`~~ — removed; no hook writes |
| T-5.6 | Update Step 8 snapshot to include the `from` path of every `rename` operation in the manifest sequence, so rollback can restore them if needed |

**Acceptance:**
- Report lists each manifest with its version range and step count
- Report lists each manifest step individually
- Report describes all four version record fields being updated
- Snapshot includes CLAUDE.md, `.forge/version`, and all rename `from` paths

---

## T-6: SKILL.md — Rollback

**File:** `plugins/forge/skills/update/SKILL.md`

**Current state:** Rollback restores CLAUDE.md and `.forge/version`, removes
`new_paths_created`.

**Required state:** Rollback reverses any completed `rename` operations using snapshot
values; handles rollback failure by reporting what to restore manually.
Note: `.claude/settings.json` is not in the snapshot — no hook writes happen.

| # | Description |
|---|-------------|
| T-6.1 | ~~Add `.claude/settings.json` to rollback~~ — removed; no hook writes |
| T-6.2 | Add handling for completed `rename` operations: if `to` exists and `from` does not (rename was applied), move `to` back to `from` as part of rollback |
| T-6.3 | Add handling for rollback failure: if a rollback step itself fails, report which step failed and print the original snapshot value for that file so the engineer can restore manually |
| T-6.4 | Update the rollback failure message to note that re-running `forge:update` is safe after a successful rollback (all operations are idempotent) |

**Acceptance:**
- Rollback restores CLAUDE.md, `.forge/version`, and any `.state.json` files from snapshot
- Rollback reverses completed rename operations
- Rollback removes directories and files in `new_paths_created` (reverse order)
- If rollback step fails, message identifies the step and prints the snapshot content for manual recovery
- Success rollback message tells engineer re-run is safe

---

## T-7: README.md

**File:** `plugins/forge/skills/update/README.md`

**Current state:** README contains two inaccuracies — it says `forge:update` updates
`.claude-plugin/marketplace.json` (it does not; that is forge:pin) and it lists a
`--version` flag (which the design removed). It does not mention the migration manifest
system or idempotency.

| # | Description |
|---|-------------|
| T-7.1 | Remove the bullet "Updates `.claude-plugin/marketplace.json` to the new version tag + SHA" from the What it does section — replace with accurate description of what forge:update actually changes |
| T-7.2 | Remove `--version <semver>` from the flags table and usage line |
| T-7.3 | Add a section explaining the migration manifest system: what manifests are, where they live, that they are bundled with the plugin, and that their absence means no structural changes are needed |
| T-7.4 | Add a note on re-run safety: if forge:update is interrupted mid-migration, re-running it is safe — individual operations are idempotent and already-applied steps are skipped |

**Acceptance:**
- No mention of `--version` flag
- No mention of forge:update touching `.claude-plugin/marketplace.json`
- Describes migration manifest system at a user-facing level
- Explains re-run safety explicitly

---

## Completion Criteria

The forge-update epic is complete when:

- [ ] T-1: `plugins/forge/migrations/` exists with README documenting manifest format
- [ ] T-2: Step 6 discovers and sequences all applicable manifests; validates ops before Step 8
- [ ] T-3: Step 9 applies always-required op (claude-md refresh) and manifest ops with idempotency; does not write `.forge/version`; does not write `.claude/settings.json`
- [ ] T-4: Step 10 is the terminal write; updates all four version record fields; handles partial failure cleanly
- [ ] T-5: Step 7 report enumerates manifests and operations; Step 8 snapshot covers all modified files
- [ ] T-6: Rollback restores all snapshotted files (CLAUDE.md, .forge/version, .state.json files); reverses renames; handles rollback failure
- [ ] T-7: README is accurate; documents manifest system and re-run safety
