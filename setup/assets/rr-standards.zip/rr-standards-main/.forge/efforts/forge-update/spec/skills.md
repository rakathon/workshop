# forge:update Skill Design

---

## Skill Responsibilities

`forge:update` migrates a repository's committed Forge configuration to be compatible
with the currently active plugin version. It does not update the plugin itself — plugin
updates are performed via `/plugin install forge@forge-local` or the equivalent. It does
not change the version pin — pin changes are performed by `forge:pin`.

`forge:update`'s sole responsibility: read what version the repository was last
configured for, read what version is now active, and apply whatever the new version
declares as required changes.

---

## Preconditions

| # | Condition | Failure behavior |
|---|-----------|-----------------|
| PC-1 | `.forge/version` exists | Stop: "This repository is not initialized. Run forge:init first." Exit 0 (expected condition, not an error). |
| PC-2 | Forge plugin is present in the cache | Stop: "The Forge plugin does not appear to be installed. Run `/plugin install forge@rr-standards`." |

PC-1 is checked before PC-2. An uninitialized repository should not produce a
plugin-not-found error.

---

## Flow

```
PC-1: .forge/version exists
PC-2: Plugin present in cache

Step 1:  Read current_version from .forge/version
Step 2:  Resolve target_version from pin or installed cache
         → DOWNGRADE: stop with diagnostic
         → NOOP (current = target): stop with "nothing to do"
Step 3:  Discover plugin_root from cache
Step 4:  Classify MAJOR vs MINOR/PATCH
Step 5:  Check active work items (MAJOR only — block if any found)
Step 6:  Discover and sequence migration manifests
Step 7:  Pre-migration report and confirmation
         → cancelled: stop cleanly
Step 8:  Snapshot files for rollback
Step 9:  Apply each manifest in sequence (idempotent per operation)
         → failure: rollback all changes, report failed step
Step 10: Update .forge/version (terminal)
Step 11: Print summary with commit reminder
```

---

## Step 1: Read Current Version

Read `active_version` from `.forge/version`:

```bash
current_version=$(grep "^active_version=" .forge/version | cut -d= -f2)
```

If `active_version` is empty or the field is absent, stop with:
> "Cannot read active_version from .forge/version. The file may be malformed.
> Inspect it manually or re-run forge:init."

---

## Step 2: Resolve Target Version

**Pinned repository** (`.claude-plugin/marketplace.json` exists):

```bash
target_ref=$(sed -n 's/.*"ref": *"\([^"]*\)".*/\1/p' .claude-plugin/marketplace.json)
target_version="${target_ref#v}"
```

If `target_ref` is empty or the file is malformed:
> "Cannot read pinned version from .claude-plugin/marketplace.json. Run forge:pin
> to re-establish the pin."

**Unpinned repository** (no `.claude-plugin/marketplace.json`):

Find the installed plugin in the cache. Prefer `forge-local`, fall back to any `forge`
cache entry:

```bash
plugin_json=$(find ~/.claude/plugins/cache/forge-local -maxdepth 4 \
              -name "plugin.json" -path "*/forge/*" 2>/dev/null | head -1)
[ -z "$plugin_json" ] && \
  plugin_json=$(find ~/.claude/plugins/cache -maxdepth 5 \
                -name "plugin.json" -path "*/forge/*" 2>/dev/null | head -1)
target_version=$(grep '"version"' "$plugin_json" | \
  sed 's/.*"version": *"\([^"]*\)".*/\1/')
```

**Version comparison:**

```bash
version_lt() {
  # Returns 0 (true) if $1 < $2
  local IFS=. v1=($1) v2=($2)
  for i in 0 1 2; do
    a="${v1[$i]:-0}"; b="${v2[$i]:-0}"
    [ "$a" -lt "$b" ] && return 0
    [ "$a" -gt "$b" ] && return 1
  done
  return 1
}

if version_lt "$target_version" "$current_version"; then
  # DOWNGRADE
elif [ "$target_version" = "$current_version" ]; then
  # NOOP
fi
```

- **DOWNGRADE**: stop with "Downgrade from v`<current>` to v`<target>` is not supported. To move to an older version, re-initialize the repository from scratch."
- **NOOP**: print "forge:update: already at v`<target_version>`. Nothing to do." Exit 0.

Record: `current_version`, `target_version`.

---

## Step 3: Discover Plugin Root

```bash
plugin_json=$(find ~/.claude/plugins/cache/forge-local -maxdepth 4 \
              -name "plugin.json" -path "*/forge/*" 2>/dev/null | head -1)
[ -z "$plugin_json" ] && \
  plugin_json=$(find ~/.claude/plugins/cache -maxdepth 5 \
                -name "plugin.json" -path "*/forge/*" 2>/dev/null | head -1)
plugin_root=$(dirname "$(dirname "$plugin_json")")
sha=$(basename "$plugin_root")
marketplace_dir=$(basename "$(dirname "$(dirname "$plugin_root")")")
```

Record: `plugin_root`, `sha`, `marketplace_dir`.

---

## Step 4: Classify Migration

```bash
current_major=$(echo "$current_version" | cut -d. -f1)
target_major=$(echo "$target_version" | cut -d. -f1)

if [ "$target_major" -gt "$current_major" ]; then
  migration_type="MAJOR"
else
  migration_type="MINOR/PATCH"
fi
```

---

## Step 5: Active Work Item Check (MAJOR only)

Skip for MINOR/PATCH migrations.

Scan `.forge/efforts/*/.state.json` for any work item where `currentPhase` is
`"implementation"` and `phases.implementation.status` is `"in_progress"`.

If found, stop with a warning listing the active work item IDs:
> "The following work items are in active implementation: [ids]
> Complete or pause active work before applying a MAJOR migration."

Do not offer to proceed anyway. A MAJOR migration against in-progress work risks
`.state.json` schema corruption.

---

## Step 6: Discover and Sequence Migration Manifests

### Manifest Location

Migration manifests live in the plugin cache at:

```
<plugin_root>/migrations/<from-version>-to-<to-version>.json
```

For example: `migrations/v1.2.0-to-v2.0.0.json`

Manifests are only present when a migration is required. Their absence means no
structural changes are needed for that version transition.

### Discovery Algorithm

1. Enumerate all `.json` files under `<plugin_root>/migrations/`
2. Parse each filename to extract `from` and `to` semver values
3. Keep only manifests where `from` ≥ `current_version` and `to` ≤ `target_version`
4. Sort the kept manifests by `from` version (ascending)

If no manifests are found, the migration is configuration-only: CLAUDE.md refresh
and version record update are always performed regardless of manifests.

### Manifest Schema

```json
{
  "from": "1.2.0",
  "to": "2.0.0",
  "breaking": true,
  "steps": [
    { "op": "create-dir",  "path": ".forge/capabilities" },
    { "op": "rename",      "from": ".forge/spec/interfaces", "to": ".forge/interfaces" },
    { "op": "state-field", "field": "currentPhase", "rename": "phase" },
    { "op": "claude-md",   "action": "refresh" }
  ]
}
```

An unrecognised `op` value must abort the migration before Step 8 (before any changes
are applied), with a diagnostic identifying the unknown operation and the manifest file.

---

## Step 7: Pre-Migration Report and Confirmation

Present the migration plan before applying any changes:

```
forge:update — migration plan

  Current:  v<current_version>
  Target:   v<target_version>
  Type:     MAJOR | MINOR/PATCH

  Manifests to apply: <N> | none (configuration-only)
  <for each manifest: "  - v<from> → v<to>  (<step count> steps)">

  Operations:
    CLAUDE.md                        forge:managed section refreshed
    .forge/version                   active_version, forge_min_version,
                                     last_migrated_with, last_migrated_at updated
    <one line per manifest step, if any>

  Active work items in implementation: none | <ids>
```

Confirmation behavior:
- **MAJOR**: always prompt. Require explicit `y`. `--yes` does not skip MAJOR prompts.
- **MINOR/PATCH with `--yes`**: skip prompt, print `(--yes: skipping confirmation)`.
- **MINOR/PATCH without `--yes`**: prompt. Require explicit `y`.

If the user does not confirm: "Migration cancelled." Exit 0.

---

## Step 8: Snapshot for Rollback

Read and store current contents of all files that will be modified. Any file that
will be created during migration (not currently present) is recorded as absent.

```
snapshot = {
  "CLAUDE.md":                   <current content or ABSENT>,
  ".forge/version":              <current content>,
  <for each rename op: "from" path>: <current content or ABSENT>
  <for each .state.json that will be modified>: <current content>
}
new_paths_created = []
```

If any snapshot read fails: "Cannot snapshot `<file>`. Migration aborted." Exit.

---

## Step 9: Apply Migrations

Apply all manifest steps in the sequenced order from Step 6, then the always-required
operations. On any failure, execute Rollback (see Rollback section) and report the
failed step.

### Always-Required Operation (every migration, with or without manifests)

**claude-md refresh:**

Read template from `<plugin_root>/templates/claude-md.md`. Substitute:
- `{{forge_version}}` → `v<target_version>`
- `{{marketplace_dir}}` → `<marketplace_dir>`
- `{{sha}}` → `<sha>`

Replace the content between `<!-- forge:managed:start -->` and `<!-- forge:managed:end -->`
(inclusive) with the rendered template. Preserve all content outside the markers. If
no markers exist, append the full section.

### Manifest-Declared Operations

Apply manifest steps in the order they appear in each manifest, applying manifests in
the sequence established in Step 6.

**`create-dir`:**

Create the directory at `path` if it does not already exist. Add to `new_paths_created`.
Skip (no-op) if the directory is already present.

**`rename`:**

Move `from` to `to`.
- Skip (no-op) if `from` is absent — the rename was already applied.
- Error if both `from` and `to` exist — ambiguous state; report the conflict and
  require engineer resolution before re-running.
- On success, remove `from` from snapshot (it no longer exists) and add `to` to
  `new_paths_created` if `to` was not previously present.

**`state-field`:**

For every `.forge/efforts/*/.state.json`, rename JSON field `field` to `rename` at
all levels of the document. Read each file, transform, write back.
Skip any file that already uses `rename` as the field name (already applied).

---

## Step 10: Update Version Record (Terminal)

This is the last write operation. Its completion signals that migration succeeded.

Update `.forge/version` using a Python script (preferred over sed for multi-field
in-place updates with dynamic timestamp generation):

```python
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
python3 - "<target_version>" "$TIMESTAMP" <<'PYEOF'
import re, sys
version, timestamp = sys.argv[1], sys.argv[2]
with open(".forge/version") as f:
    content = f.read()
def update_field(text, key, value):
    if re.search(rf'^{key}=', text, re.MULTILINE):
        return re.sub(rf'^{key}=.*', f'{key}={value}', text, flags=re.MULTILINE)
    return text.rstrip('\n') + f'\n{key}={value}\n'
content = update_field(content, 'active_version', version)
content = update_field(content, 'forge_min_version', version)
content = update_field(content, 'last_migrated_with', version)
content = update_field(content, 'last_migrated_at', timestamp)
with open(".forge/version", "w") as f:
    f.write(content)
PYEOF
```

Fields updated:
```
active_version      = <target_version>
forge_min_version   = <target_version>
last_migrated_with  = <target_version>
last_migrated_at    = <UTC timestamp: YYYY-MM-DDTHH:MM:SSZ>
```

`initialized_with` and `initialized_at` are never modified.

If this step fails after Step 9 succeeded: report the error. The repository is in a
fully migrated state but the version record has not been updated. The engineer can
manually update `.forge/version` or re-run `forge:update` — all Step 9 operations are
idempotent and will be skipped.

---

## Step 11: Print Summary

```
forge:update complete — forge v<current_version> → v<target_version>

  Updated:
    CLAUDE.md                        (forge:managed section refreshed)
    .forge/version                   (active_version, forge_min_version updated)
    <one line per operation applied from manifests>

  Migration type: MAJOR | MINOR/PATCH

Commit these files to share the migration with your team:
  git add CLAUDE.md .forge/
  git commit -m "chore: migrate forge to v<target_version>"
```

---

## Rollback

On any failure during Step 9 (before Step 10), restore all snapshotted files and
remove any newly created paths:

```
FOR each file in snapshot:
  IF snapshot value is ABSENT: delete the file if it exists
  ELSE: write snapshot content back to the file path
FOR each path in new_paths_created (reverse order):
  Remove file or directory (directories only if now empty)
```

Print:
> "Migration failed at step 9 (`<op>` on `<path>`): `<error>`. All changes have
> been rolled back. Re-running forge:update is safe."

If rollback itself fails, report which rollback step failed and what its original
snapshot value was, so the engineer can restore manually.

---

## Key Design Decisions

**Version record last (TR-5).**
The version record is updated in Step 10, after all Step 9 operations complete. This
is not an implementation convenience — it is a correctness requirement. A version
record that reflects the new version is the definitive signal that migration is done.
Any earlier update risks leaving the repository in a state where the version record
says "migrated" but the repository contents are not fully migrated. Re-run safety
depends entirely on this ordering.

**Sequential manifests, not a combined plan (TR-3).**
Each manifest is applied against the result of the prior manifest. This ensures that
intermediate states are well-defined and that each operation is applied to the
filesystem state it was designed for. A combined plan synthesized from multiple
manifests could produce an incorrect end state — for example, if v1→v2 creates a
directory that v2→v3 then renames, a combined plan might create it at the final name
(correct), or might create it at the intermediate name and not rename (incorrect),
with no mechanical way to distinguish the two outcomes.

**Idempotency per operation (TR-4).**
Each operation checks whether it has already been applied before executing. This
allows re-run after any partial failure: Step 9 re-executes all operations, but
already-applied operations are skipped. Combined with the version-last guarantee, this
means re-running after any failure converges to the correct end state without manual
intervention.

**CLAUDE.md refresh is always-required and not manifest-declared.**
CLAUDE.md refresh happens on every migration regardless of whether any manifest
declares it. This keeps the managed section current with the active plugin version.
Plugin hooks are registered automatically by Claude Code from the installed plugin,
so forge:update does not write to `.claude/settings.json`.

**forge:update does not touch `.claude-plugin/marketplace.json`.**
The pin is the engineer's declaration of intent. `forge:update` reads the pin to
determine its target — it does not write the pin. Separating "change the target"
(forge:pin) from "migrate to the target" (forge:update) means `forge:update` is
always migrating to what the team has already committed to, never making a version
decision on the team's behalf.
