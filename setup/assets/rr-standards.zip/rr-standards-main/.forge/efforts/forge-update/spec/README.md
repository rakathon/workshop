# forge-update Design

## Overview

This epic delivers one skill and one static artifact type: the `forge:update` skill
and the migration manifest format that makes it extensible.

`forge:update` is the configuration migration skill that brings a repository's
committed Forge configuration — directory structure, CLAUDE.md, and `.state.json`
schemas — up to date with the currently active Forge plugin version.

It is always the third step in the version upgrade sequence:

```
1. forge:pin --version <new-version>   ← change the version pin (forge:pin)
2. /plugin install forge@forge-local   ← fetch the new plugin version into cache
3. forge:update                        ← migrate committed repo files to match
```

For unpinned repositories, steps 1–2 are replaced by updating the globally installed
plugin, and `forge:update` is run afterward.

## Deliverables

| Artifact | Type | Scope |
|----------|------|-------|
| `forge:update` | Skill (SKILL.md) | Interactive, invoked in engineer session |
| `plugins/forge/migrations/<from>-to-<to>.json` | Migration manifest | Static; bundled in plugin cache; read by forge:update |

The migration manifest format is the mechanism by which future Forge releases declare
what structural changes `forge:update` must apply. Without a specified format, the
skill would require changes every time a new version introduced new migrations.

## Architecture

```
Engineer session
│
├── .forge/version               ← source of truth: what version last configured this repo
├── .claude-plugin/marketplace.json  ← source of truth: what version to migrate to (pinned)
│
└── forge:update
    │
    ├── Step 1: Read current_version from .forge/version active_version
    ├── Step 2: Resolve target_version from pin or installed cache
    ├── Step 3: Discover plugin_root from cache
    ├── Step 4: Classify MAJOR vs MINOR/PATCH
    ├── Step 5: Check active work items (MAJOR only)
    ├── Step 6: Discover and sequence migration manifests
    │           plugin_root/migrations/<from>-to-<to>.json (for each version step)
    ├── Step 7: Pre-migration report and confirmation
    ├── Step 8: Snapshot for rollback
    ├── Step 9: Apply migrations (manifests in sequence, then version record last)
    │   ├── 9.N.1  create-dir
    │   ├── 9.N.2  rename
    │   ├── 9.N.3  state-field
    │   ├── 9.N.4  claude-md refresh
    │   └── (repeat for each manifest N)
    └── Step 10: Update .forge/version (terminal — signals migration complete)
```

## Key Design Decisions

**Version record updated last.** The `.forge/version` update is the final operation.
An updated version record is the commit of record that migration completed. If the
skill fails mid-migration, the version record still reflects the prior version, and
re-running will re-apply from the start. Individual operations are idempotent, so
already-applied steps are skipped on re-run.

**Sequential manifest application.** When migrating across multiple versions (e.g.,
v1 → v3), each manifest is applied in order (v1→v2, then v2→v3) rather than
constructing a combined plan. Each manifest executes against a known intermediate
state. A synthesized combined plan risks producing an incorrect end state that cannot
be mechanically verified.

**Manifests are declarative.** Migration manifests enumerate operations using a small,
fixed set of operation types. The skill applies them mechanically — no reasoning about
what each operation means, only whether the idempotency pre-check passes. This keeps
migration application deterministic regardless of the migration content.

## Design Document

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:update` detailed design — flow, manifest format, multi-version algorithm, idempotency rules, rollback |
