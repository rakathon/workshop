# User Stories — Arch Review

*Effort: arch-review*
*Derived from: [requirements/business.md](business.md)*
*Written: 2026-05-04*

---

## Running the review

- As a discovery author, I want to run `forge:arch-review` and be guided through a short interview so that the generated document reflects context that isn't in the spec artifacts (rollout approach, cost assumptions, open risks).
- As a discovery author, I want the skill to run `forge:validate` automatically if it hasn't been run yet so that I don't have to remember to run it separately before the review meeting.
- As a discovery author, I want the skill to re-use an existing `validation/report.md` if it's current so that I'm not waiting for a redundant validation pass.

## Review meeting experience

- As an architecture reviewer, I want a single self-contained HTML document I can open from `file://` so that I can review it without needing a server or internet access.
- As an architecture reviewer, I want each validation finding labelled as "safe to skip if time-limited" or "must examine in depth" so that a time-boxed meeting can focus on what matters.
- As an architecture reviewer, I want C4 diagrams rendered directly in the page so that I can orient myself spatially before examining contracts and data models.
- As an architecture reviewer, I want API contracts rendered as interactive OpenAPI documentation so that I can explore request/response schemas without switching tools.
- As an architecture reviewer, I want message contracts presented as cards that show the base class and only the extensions so that I'm not reviewing already-approved envelope fields.

## Data and contracts review

- As an architecture reviewer, I want to see governance and privacy classification alongside the data model when the data-mapping skill has been run so that I can assess PII obligations without cross-referencing a separate document.
- As an architecture reviewer, I want a visible gap notice when governance classification is absent so that I know it hasn't been assessed rather than assuming it has.
- As an architecture reviewer, I want per-endpoint security information (auth requirement, input validation) rendered inline with the API contract so that I don't have to cross-reference a separate security section.

## Cost and rollout review

- As an architecture reviewer, I want interactive cost sliders for key variable parameters (e.g., cache TTL, message volume) so that I can explore cost implications of architectural choices during the meeting.
- As an architecture reviewer, I want a high-level rollout section that tells me whether a migration, feature flag, or experiment is involved so that I can assess delivery risk without needing an implementation runbook.
- As an architecture reviewer, I want an afterword section capturing future extensions and outstanding questions so that deferred decisions are visible and don't get lost.
