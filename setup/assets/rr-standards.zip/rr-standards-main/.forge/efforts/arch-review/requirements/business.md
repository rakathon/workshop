# Business Requirements — Arch Review

*Effort: arch-review*
*Created: 2026-05-04*

---

## BR-1: Architecture review package enables a clear approve/send-back decision

The `forge:arch-review` skill produces a self-contained HTML document that gives the reviewing group (architecture/tech leads) everything they need to make an approve-or-send-back decision during a time-boxed meeting — without requiring access to raw spec artifacts.

**Acceptance criteria:**
- The HTML document contains all nine required sections
- A validation section explicitly marks each finding as "safe to skip if time-limited" or "must examine in depth"
- The document opens from `file://` with no external dependencies

---

## BR-2: Document follows a nine-section layout optimised for architecture review meetings

The HTML document is structured as nine sections in this order:
1. Effort Overview — what we're building, why, key requirements/constraints, desired delivery date
2. Validation Report — AI-generated findings with priority signal (skip vs. examine in depth)
3. C4 Diagrams — system and/or container diagrams giving spatial architecture overview
4. Data Model — logical and physical diagrams; governance/privacy classification when available
5. Contracts — API contracts (interactive OpenAPI) and message contracts
6. Risk Mitigation — failures, abuse scenarios, and cross-cutting security (secrets, network policies)
7. Rollout — migration, experiments, feature flags
8. Cost Analysis — resource and operational cost implications
9. Afterword — future extensions and outstanding questions

**Acceptance criteria:**
- All nine sections are always present (with "not applicable" placeholder if no content)
- Sections are navigable via a sticky nav element

---

## BR-3: Validation section gives reviewers a clear priority signal

The validation section explicitly sorts findings into two tiers so a time-boxed meeting can focus on what matters.

**Acceptance criteria:**
- Each finding is labelled either "safe to skip if time-limited" or "must examine in depth"
- FAIL-severity findings are always in "must examine in depth"
- CONCERN/SUGGESTION findings default to "safe to skip" unless they touch security, privacy, or uncovered BRs

---

## BR-4: C4 architectural diagrams give reviewers spatial understanding before detail sections

System-level and/or container-level C4 diagrams are rendered directly in the HTML page so reviewers can orient themselves before examining contracts and data models.

**Acceptance criteria:**
- At least one C4 diagram is rendered (system context minimum; container diagram when multiple services are involved)
- Diagrams render correctly in the self-contained HTML without a build server
- Diagrams are authored in Mermaid and rendered client-side within the page

---

## BR-5: API contracts are rendered interactively

API specs are rendered as interactive OpenAPI documentation — not static tables — so reviewers can explore request/response schemas during the meeting.

**Acceptance criteria:**
- Each OpenAPI spec in `spec/api/` is rendered with an interactive UI (expandable endpoints, schemas, example values)
- The interactive renderer is self-contained with no CDN or external dependencies

---

## BR-6: Security analysis is co-located with contracts; cross-cutting concerns live in risk mitigation

Per-contract security (auth required, rate limiting, input validation per endpoint; trust model per consumer) is rendered inline within §5. Cross-cutting concerns (secrets management, network policies, mTLS) are in §6 Risk Mitigation.

**Acceptance criteria:**
- Each API endpoint in §5 shows its auth requirement and input validation status alongside the contract
- Each messaging consumer in §5 shows its trust model
- §6 includes a dedicated cross-cutting security subsection

---

## BR-8: `forge:arch-review` uses an interview style before generating the document

Rather than generating the HTML document in a single unattended pass, `forge:arch-review` first runs a focused interview — asking the author targeted questions about rollout approach, cost assumptions, outstanding risks, and open decisions — then generates the document from the combined artifact + interview answers. This mirrors the `forge:elaborate` pattern.

**Acceptance criteria:**
- The skill asks questions in a conversational loop before writing the HTML
- Each question has a recommended answer that the author can accept, modify, or reject
- Agreed answers are written to intermediate spec artifacts before the HTML is generated
- The HTML is only generated after the interview loop concludes

---

## BR-9: Rollout section (§7) captures high-level process, not step-by-step execution detail

The rollout section conveys the shape of the rollout — what phases exist, whether there is a migration, whether feature flags or experiments are involved, what the rollback approach is — at a level of detail appropriate for a review meeting. It is not an implementation runbook.

**Acceptance criteria:**
- Rollout process is inferred from spec artifacts (presence of storage schema changes → migration flag, BR language about gradual rollout → feature flag candidate) and supplemented by interview answers
- Section always present; renders "No rollout considerations identified" if inference and interview yield nothing notable

---

## BR-10: Cost analysis section (§8) is infrastructure-focused and interactive

The cost analysis covers AWS infrastructure cost (compute, storage, messaging, cache) for the effort's deployed components. Where key parameters affect cost non-linearly (e.g., cache TTL vs. memory, message volume vs. Kafka partition count), the section renders an interactive element allowing reviewers to explore the cost implications of parameter choices during the meeting.

**Acceptance criteria:**
- Cost figures are based on AWS pricing for the infrastructure components identified in the spec
- At least one interactive parameter exploration is present when a variable cost driver is identified
- Interactive elements use only inline JavaScript — no CDN dependencies
- If cost data cannot be determined, a gap notice is shown prompting the author to provide estimates

---

## BR-7: Data model section includes governance and privacy classification when data-mapping output is present

When the data-mapping skill has been run for the effort, field-level governance and privacy classifications are rendered alongside the schema in §4. When absent, a visible gap notice is shown rather than silently omitting the information.

**Acceptance criteria:**
- If data-mapping output exists: each field in the schema shows its governance/privacy classification
- If data-mapping output is absent: §4 displays a clearly visible notice that governance classification has not been assessed
