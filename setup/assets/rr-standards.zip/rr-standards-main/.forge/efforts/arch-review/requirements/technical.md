# Technical Requirements — Arch Review

*Effort: arch-review*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-05-04*

---

## TR-1: Skill is installed at `plugins/forge/skills/arch-review/`

*Traces to: BR-1*

The skill must live at the top-level `skills/` path — only skills directly under `skills/` are installed by the plugin. The existing stub at `skills/discovery/arch-review/` has never been installed. The new implementation replaces it; the stub directory is removed.

---

## TR-2: Skill runs `forge:validate` if `validation/report.md` is absent or stale

*Traces to: BR-3*

Before generating the HTML, the skill checks whether `validation/report.md` exists and was produced after the most recent modification to any discovery artifact. If absent or stale, it runs `forge:validate` first and waits for it to complete. If `validation/report.md` already exists and is current, the skill uses it directly without re-running validation.

---

## TR-3: HTML document is fully self-contained — no external URLs

*Traces to: BR-1, BR-5*

The generated HTML file must open correctly via `file://` with no network access. All CSS is written inline in a `<style>` block. No CDN references, no external fonts, no external JavaScript. The interactive OpenAPI renderer must be bundled inline (e.g., a minified build embedded as an inline `<script>`). File size must not exceed 500KB; verbose spec content is summarised rather than quoted verbatim.

---

## TR-4: Visual design follows the PR #246 design system

*Traces to: BR-1*

The HTML uses the three-family typography system (Playfair Display for display headings, Source Serif 4 for body, IBM Plex Mono for labels/metadata), the defined colour palette (brand `#8529cd`, semantic status colours), and the section structure (72px padding, 1100px max-width container, alternating `.alt` backgrounds) established in `skills/report/references/full-report-mode.md`. Google Fonts are loaded via `@import` (one external dependency permitted for fonts only).

---

## TR-5: C4 diagrams are authored in Mermaid and rendered client-side

*Traces to: BR-4*

Diagrams are written as Mermaid source embedded in the HTML. The Mermaid JS library is bundled inline in the document so diagrams render without a server. System-context diagrams are generated for all efforts; container-level diagrams are generated when multiple services or deployables are identified in the spec artifacts.

---

## TR-6: Interactive OpenAPI rendering is self-contained

*Traces to: BR-5*

The interactive OpenAPI UI is rendered using a client-side library (e.g., a minified build of Swagger UI or Redoc) embedded inline — not loaded from a CDN. Each `spec/api/*.yaml` spec is inlined as a JSON blob passed to the renderer. The renderer must support expandable endpoints, request/response schema exploration, and example values.

---

## TR-7: Data-mapping output detection is file-based

*Traces to: BR-7*

The skill detects data-mapping output by checking for the presence of a data-mapping artifact file in the effort's spec directory (exact path TBD once the data-mapping skill is merged). If the file is absent, §4 renders a standardised gap notice. The detection logic must not fail or warn on efforts that predate the data-mapping skill.

---

## TR-8: Validation findings are prioritised using a deterministic rule

*Traces to: BR-3*

Priority classification uses this rule:
- FAIL severity → always "must examine in depth"
- CONCERN/SUGGESTION touching security, privacy, or an uncovered BR → "must examine in depth"
- All other CONCERN/SUGGESTION findings → "safe to skip if time-limited"

The priority label must be visually distinct (colour-coded badge) in the rendered HTML.

---

## TR-12: Skill runs a pre-generation interview loop before writing the HTML

*Traces to: BR-8*

Before generating `arch-review.html`, the skill runs a focused interview covering:
1. Rollout — phases, migration presence, feature flag candidates, rollback approach
2. Cost — which AWS services are involved, key variable cost drivers, any known estimates
3. Risk mitigation — failure modes, abuse scenarios, cross-cutting security gaps not covered by the contracts section
4. Afterword — future extensions the author wants to capture, outstanding open questions

The interview follows the same conventions as `forge:elaborate`: one question at a time, each with a recommended answer, agreed answers written to intermediate spec artifacts (`spec/rollout.md`, `spec/cost.md`, `spec/risks.md`) before the next question is asked. HTML generation begins only after the interview loop concludes or the author signals they are done.

If a spec artifact already exists (e.g., from a prior run), the skill reads it and skips questions already resolved by its content.

---

## TR-13: Rollout section is inferred from artifacts and supplemented by interview answers

*Traces to: BR-9*

The skill infers rollout signals automatically:
- Presence of `spec/storage/` with schema changes → flag as requiring a migration
- BR text containing "gradual", "percentage", "experiment", "flag", or "A/B" → flag as feature flag candidate
- Multiple deployables in `.state.json` → flag as requiring coordinated rollout

These inferences, plus answers from the TR-12 interview, are combined to populate `spec/rollout.md` and then rendered as §7. The section always renders; if no signals are found and interview yields nothing, the section shows: "No rollout considerations identified."

---

## TR-15: Interactive cost parameter baseline values are inferred from spec artifacts, with interview fallback

*Traces to: BR-10, TR-14*

For each interactive cost parameter (e.g., cache TTL, message volume, replica count), the skill first attempts to read the value from spec artifacts — storage specs, technical requirements, ADRs. If a value is found, it becomes the slider/input default without prompting the author. If no value is found in the artifacts, the TR-12 interview asks explicitly: "What is your expected [parameter]? I'll use this as the baseline for the [service] cost model." The interview only asks about parameters the spec does not already answer.

---

## TR-14: Cost analysis uses AWS pricing data fetched via web search; interactive elements use inline JavaScript

*Traces to: BR-10*

The skill fetches current AWS pricing for the infrastructure components identified in spec artifacts (e.g., ElastiCache, MSK/Kafka, RDS, Lambda, DynamoDB) using web search at generation time. Interactive cost sliders or input fields (e.g., cache TTL vs. ElastiCache memory usage and monthly cost) are implemented using inline `<script>` blocks with no external dependencies. The interaction model is pure JavaScript — no framework, no CDN. If pricing cannot be fetched or cost drivers cannot be determined from spec artifacts, §8 renders a gap notice.

---

## TR-10: Message contracts are rendered as structured cards showing base class and extensions only

*Traces to: BR-2 (§5 Contracts)*

Message contracts in §5 are rendered as one card per event type. Each card shows:
- **Contract name** (reversed-domain format per `contracts.md` R-2)
- **Topic** and **compatibility mode**
- **Base class** — one of: `Message`, `UserInitiatedMessage`, `ApiInitiatedMessage` — with a brief description of what that class provides (standard envelope fields are pre-approved and not repeated)
- **Extensions** — only the fields the contract adds beyond the base class schema, shown as a collapsible `<details>` block
- **Producer** and **consumers**
- **Delivery guarantee** and **idempotency approach**

The base-class envelope fields (`message_id`, `event_name`, `event_version`, `produced_at_ms`, `trace_id`, `client_context`, `member`, `visit_id`, etc.) are not rendered individually — reviewers are assumed to have already approved those schemas. Only extensions to the base class are surfaced for review.

---

## TR-11: `forge:arch-review` is restricted to the discovery phase

*Traces to: BR-1*

`forge:arch-review` enforces the same phase guard as `forge:validate`: it only runs when `currentPhase = "discovery"` and `phases.discovery.status != "approved"`. If discovery is already approved, the skill stops with:

> "Discovery is already approved. To re-run arch-review, first run `forge:reopen discovery`."

Note: `forge:reopen` is currently a stub. Until it is implemented, re-running arch-review after approval requires manually resetting `phases.discovery.status` in `.state.json`. This is a known gap and does not block this effort.

---

## TR-9: Skill output path and commit convention

*Traces to: BR-1*

The skill writes two files and commits them atomically:
- `<effort_dir>/validation/report.md` — machine-readable findings (for `forge:promote`)
- `<effort_dir>/validation/arch-review.html` — the presentation document

Commit message: `docs(<effort-id>): generate architecture review package`

The skill does not modify `.state.json` or `README.md` — those remain the orchestrator's responsibility.
