# Skills Design — ai-pr

Skills that implement the AI-powered PR review workflow. Skills producing machine-readable
output conform to the shared review output schema
(`.forge/efforts/forge-plugin/spec/review-output-schema.md`).

---

## Internal Agents

`forge:review` is a Tier-2 worker skill (see forge-plugin skills design § Three-Tier
Context Model) that internally orchestrates Tier-3 specialist agents in parallel. These
agents are not skills — they have no `SKILL.md`, do not appear in the command palette,
and are never invoked directly. They are spawned by `forge:review` via the Task tool.

The orchestration sequence and data contracts are defined in TR-1.8.

### Specialist agents

| Agent | Check | Receives | Returns |
|-------|-------|----------|---------|
| `rr-standards-plugin-reviewer` | `rr-standards-plugin` | Diff + language guide(s) + applicable standards | `findings[]`, `check` record |
| `security-reviewer` | `security` | Diff + security standard + security policy | `findings[]`, `check` record |
| `privacy-reviewer` | `privacy` | Diff + privacy standard + data handling policy | `findings[]`, `check` record |
| `traceability-reviewer` | `traceability` | Diff + requirements + tech spec + plan items | `findings[]`, `check` record |
| `test-plan-reviewer` | `test-coverage` | Diff + test strategy + requirements | `findings[]`, `check` record |
| `error-handling-reviewer` | `error-handling` | Diff + error handling standard | `findings[]`, `check` record |
| `historical-context-reviewer` | `historical-context` | Git blame + commit log for modified files | `findings[]`, `check` record |
| `duplication-detector` | `duplication` | Diff + relevant existing source files | `findings[]`, `check` record |

### Confidence-scorer agent

Runs after all specialists complete. Receives the full findings set from all dimensions
and scores each finding 0–100 using the rubric in the review output schema (§ Confidence
Scoring). Returns a map of `finding_id → confidence_score`. Running this as a separate
agent gives it a focused context (findings only, no source code) and lets it calibrate
scores across dimensions with the complete picture.

---

## forge:simplify

**Agent type:** Worker (non-interactive)
**Trigger:** Manual invocation by an engineer after a PR has been merged. Not a CI gate.

**Purpose:** A post-approval simplification pass. Distinct lifecycle from `forge:review` —
this skill runs on merged code, not on a PR under review. Its findings are never blocking.
It identifies and applies safe refactors that do not change observable behaviour.

**Input:**
- `--base <branch>` — the branch the capability was merged into (default: auto-detected
  from `git symbolic-ref refs/remotes/origin/HEAD`). Used to scope the diff to the
  merged capability's changes.
- `--pr <number>` — convenience: look up the merged PR by number to establish the diff
  scope instead of computing it from the branch.
- `--apply` — if present, apply the proposed simplifications directly to the current
  working tree and present them for review. If absent (default), produce a report only.

**Workflow:**
1. Establish the diff scope (same as `forge:review`)
2. Load the files touched by the merge, in full — simplification requires seeing
   complete context, not just the diff
3. Identify simplification opportunities in four categories:

   **a. Extraction** — blocks of logic duplicated two or more times that could be
   extracted to a shared function, method, or constant. Minimum reportable duplication
   size: 5 lines or 3 non-trivial expressions.

   **b. Nesting reduction** — conditional chains or loop bodies that could be flattened
   using early returns, guard clauses, or inversion. Flag only when the reduction is
   unambiguous — do not flag intentional state-machine nesting.

   **c. Naming** — identifiers that are ambiguous (`temp`, `data`, `result`) or
   misleading (name contradicts behaviour). Do not flag stylistic preferences
   (camelCase vs. snake_case) — only correctness-relevant naming issues.

   **d. Dead code** — unreachable branches, unused variables, or unused exports that
   were introduced in the merged PR. Do not flag pre-existing dead code outside the
   diff scope.

4. For each opportunity: record the category, the specific location, what the current
   code does, what the simplified form would look like, and why the simplification
   is safe (no behaviour change).
5. Score each opportunity by impact: **high** (removes meaningful complexity or
   duplication), **medium** (reduces noise), **low** (minor clarity improvement).
6. Emit output — see Output section below.
7. If `--apply`: apply high-impact opportunities only; present each change for
   engineer confirmation before writing. Do not batch-apply without confirmation.

**What simplify does NOT do:**
- Propose refactors that change observable behaviour (different outputs, changed error
  paths, modified API contracts)
- Flag style issues not related to correctness or clarity
- Re-flag issues that were already reviewed and accepted in `forge:review`
- Propose architecture changes (layer restructuring, new abstractions) — these belong
  in a design session, not a simplification pass

**Output:**

*Without `--apply`* — human-readable report:
- Summary: N opportunities found across X categories
- Each opportunity: location, current code excerpt, proposed simplified form, impact level
- No AI signal; no verdict; no blocking/advisory/informational classification — all
  simplification opportunities are suggestions only

*With `--apply`* — interactive application mode:
- Presents each high-impact opportunity in sequence
- Shows a before/after diff; waits for engineer confirmation before applying
- After all confirmations: applies accepted changes, produces a summary of what was changed

**Error conditions:**
- Diff is unparseable or missing → diagnostic message; exit
- AI service unavailable → diagnostic message; exit
- Cost ceiling exceeded → diagnostic message; exit

---

## forge:review

See `.forge/efforts/ai-pr/requirements/technical.md` for the full specification.
Skill text is authored during implementation.

---

## forge:review-security

Convenience alias for `forge:review --checks security`.

Exists so CI workflows and branch protection rules can reference a stable named status
check (`forge:review-security`) without embedding `--checks security` in workflow YAML.
The underlying implementation is `forge:review` with the `security` check selected.

Skill text is authored during implementation.

---

## forge:review-privacy

Convenience alias for `forge:review --checks privacy`.

Same rationale as `forge:review-security` — named for stable CI status check targeting.
The underlying implementation is `forge:review` with the `privacy` check selected.

Skill text is authored during implementation.
