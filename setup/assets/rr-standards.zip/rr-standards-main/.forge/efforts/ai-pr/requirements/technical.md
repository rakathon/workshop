# Technical Requirements — AI-Powered PR Review

Parent program: [forge-plugin](../../forge-plugin/requirements/technical.md)

---

## TR-1: Review Skill Architecture

### TR-1.1: Worker Isolation

`forge:review` must run as an isolated sub-agent (worker) via the Task tool with a
fresh context window. It must not have access to the engineer's accumulated session
history. Inputs passed to the worker:

- The PR diff, computed as `git diff <base>...HEAD`. The base branch is provided via
  `--base <branch>` (see forge-plugin TR-6 for the full diff input requirement).
  In CI, GitHub Actions passes `--base ${{ github.event.pull_request.base.ref }}`.
  Locally, the developer passes `--base <branch>` or accepts the auto-detected default.
- The applicable standards and enforcement policy documents
- Work item artifacts, loaded as follows: if the PR diff includes an update to a
  Forge implementation plan state file, the agent reads that change to identify the
  work item, then loads the linked technical specification and requirements from
  `.forge/efforts/<id>/` at the base branch HEAD. If no plan state update is present,
  work item artifacts are not available and the traceability review does not run.

This isolation prevents context pollution and maintains consistent output quality
regardless of main session length (BR-11).

### TR-1.2: Skill Command Surface

The following commands must be implemented:

| Command | Agent type | What it does |
|---------|-----------|--------------|
| `forge:review` | Worker | PR review. Runs all checks by default; `--checks <name,...>` runs a specific subset. Each check is a specialist agent run in parallel. Produces a structured findings report with AI signal and positive observations. |
| `forge:review-security` | Worker | Convenience alias for `forge:review --checks security`. Exists so CI workflows and branch protection rules can reference a stable named status check without embedding the `--checks` flag in workflow configuration. |
| `forge:review-privacy` | Worker | Convenience alias for `forge:review --checks privacy`. Same rationale as `forge:review-security`. |
| `forge:simplify` | Worker | Post-approval simplification pass: identifies and applies safe refactors (extract shared logic, reduce nesting, improve naming) that do not change behaviour. Distinct lifecycle from review — runs after an approved PR, not during gate review. |

**Available check names** (map directly to schema category values; usable with `--checks`):

| Check name | Category | What it evaluates |
|------------|----------|-------------------|
| `rr-standards-plugin` | `rr-standards-plugin` | Language standards, idioms, and patterns from the applicable language guide |
| `security` | `security` | OWASP issues, authentication, secrets handling, injection, and attack surface |
| `privacy` | `privacy` | PII handling, data minimisation, consent flows, and retention |
| `traceability` | `traceability` | Code changes trace to requirements in the linked work item (TR-9) |
| `test-coverage` | `test-coverage` | Test plan conformance — implemented tests match strategy; strategy covers requirements (TR-1.7) |
| `error-handling` | `error-handling` | Error paths, failure modes, recovery behaviour, and observability of failures |
| `historical-context` | `historical-context` | Git blame and commit history context for modified sections (TR-1.5) |
| `duplication` | `duplication` | Textual and semantic code duplication (TR-10) |

**Default behaviour** (`--checks` omitted): all checks run. Selective applicability rules
(TR-1.6) determine which checks produce findings — a check that does not apply to what
changed records `result: "skipped"` rather than `"fail"` and produces no findings.

### TR-1.3: Output Modes

The review skill must support two output modes, controlled by an explicit `--ci` flag,
as required by the forge-plugin review capability standard:

**Interactive mode** (default, no flag) — for local developer use before pushing:
- Human-readable terminal output, structured by severity with clear suggested actions
- The same findings content as CI mode; no information is withheld in interactive mode
- Developers are expected to run review skills locally as a first-pass gate

**CI mode** (`--ci`) — for GitHub Actions:
- Machine-readable JSON to stdout conforming to the Forge review output schema
  (`.forge/efforts/forge-plugin/spec/review-output-schema.md`); no decorative output
- Exit code 1 on FAIL or ERROR; exit code 0 on PASS
- GitHub Actions additionally renders the JSON into a human-readable PR comment and
  posts it to the PR (this is the Actions workflow's responsibility, not the skill's)

The human-readable content (both modes) must include:
- **Risk classification**: R1–R4 with explicit rationale for the assigned level
- **Findings**: each finding must include category (coding standards / security /
  privacy / traceability / test plan conformance / error handling), severity (blocking /
  advisory / informational), the specific rule or standard violated, the file and
  line reference, and the recommended resolution
- **Positive observations**: specific strengths worth noting; not balance commentary
  to soften findings — only included when the review genuinely identifies something
  done well. Must not be present when there is nothing specific to observe.
- **AI signal**: `approve` or `request-for-changes`, with a one-line summary of
  the reason if request-for-changes
- **Standards applied**: list of standards documents loaded and applied during review

The machine-readable record must match the schema defined in TR-7.2.

### TR-1.4: False-Positive Controls

The review skill must not flag the following categories of issues. These must be
stated explicitly in the skill's prompt to prevent noise that erodes engineer trust:

- **Pre-existing issues**: findings that are not introduced or modified by lines in
  the PR diff. A violation present in unchanged code is out of scope (see TR-7.1).
- **Linter/compiler-catchable issues**: type errors, import errors, formatting
  violations, test failures, and any issue that a configured linter or type-checker
  will catch. These run separately in CI. The AI review covers semantic issues that
  automated tools cannot detect.
- **Lint-suppressed lines**: a line with a lint-ignore or nolint annotation has
  already been explicitly accepted by the author for that rule. Do not re-flag it.
- **Intentional changes**: changes that are directly and obviously related to the
  stated purpose of the PR (as described in the PR title, description, and linked
  work item). Do not flag a change as suspicious simply because it is unexpected —
  verify against context before raising it.
- **Pedantic nitpicks**: style or naming issues not explicitly called out in the
  applicable standard or CLAUDE.md. Senior engineers would not raise these in review.

These controls reduce false positives before confidence scoring is applied (TR-12).
Confidence scoring provides a second filter; these controls are the first.

### TR-1.5: Historical Context Review

`forge:review` must include a historical context pass as one of its parallel review
dimensions. This pass examines:

- **Git blame for modified files**: determines when each modified section was last
  changed and by whom. Sections that were stable for a long time and are now being
  modified warrant closer scrutiny; recently changed sections may explain patterns
  that look unusual at first glance.
- **Commit history for modified files**: reviews recent commit messages touching
  these files. A commit message may explain why code is written a particular way
  (e.g., working around an upstream bug or a known limitation). Without this context,
  the review may flag intentional patterns as violations.

Findings from the historical context pass are surfaced as informational findings
unless they reveal a clear correctness issue (e.g., a section modified in this PR
reverts a fix from a prior commit without explanation).

### TR-1.6: Selective Check Applicability

Not every check runs on every PR. Each check must evaluate its own applicability
before running and record `result: "skipped"` (not `"fail"`) in the machine-readable
output when the condition is not met. Skipped checks produce no findings and do not
affect the verdict. This keeps cost and noise proportional to what actually changed.

Applicability conditions for `forge:review` checks:

| Check | Category | Skipped when |
|-------|----------|-------------|
| `traceability` | `traceability` | PR diff contains no Forge plan state file update |
| `test-coverage` | `test-coverage` | PR diff contains no Forge plan state file update (no work item = no test strategy to load) |
| `historical-context` | `historical-context` | All modified files are newly created (no prior history to load) |

The `exclusions` array (TR-8) is distinct from skipped checks: an exclusion means a
file was present in the diff but was not reviewed at all; a skipped check means the
check ran its applicability test and determined it was not applicable to what changed.

### TR-1.7: Test Plan Conformance Check

**This check has nothing to do with code coverage metrics.** It does not measure line,
branch, or function coverage. It does not invoke any coverage tool.

The `test-coverage` check (schema category: `test-coverage`) evaluates two questions:

**1. Implementation conformance** — did the engineer implement the tests the test
strategy required?
- Load the test strategy from `spec/test-strategy.md` in the work item's Forge
  directory (`.forge/efforts/<id>/spec/test-strategy.md` at base branch HEAD)
- Compare the test cases and scenarios described in the strategy against the test
  code introduced or modified in the PR diff
- Flag as a blocking finding any test scenario in the strategy that has no corresponding
  test implementation in the diff — unless the strategy explicitly marks it as deferred
- Flag as an advisory finding any test in the diff that does not map to a scenario in
  the strategy (new test without a strategy backing)

**2. Requirements coverage** — does the test strategy cover the requirements in scope
for this PR?
- Load the requirements artifacts for the work item (TR-9.2)
- For each requirement relevant to the changed code, verify that the test strategy
  includes at least one scenario that exercises that requirement
- Flag as a blocking finding any in-scope requirement with no test coverage in the
  strategy — this is a gap in the strategy itself, not the implementation

If the work item is identified (plan state update present) but no test strategy file
exists at the expected path: emit an informational finding noting the absence. Do not
skip — the absence of a test strategy is visible information, not a non-event.

### TR-1.8: Internal Agent Architecture

`forge:review` runs as a worker skill (TR-1.1) but internally orchestrates specialist
agents in parallel — one per requested check. No specialist sees another's findings
during analysis; this prevents cross-domain context pollution and keeps scoring quality
high as the number of active checks grows.

**Orchestration sequence:**

1. Run pre-review eligibility checks (TR-4.5); exit early if not eligible
2. Parse diff; detect changed languages; identify changed files
3. Load shared artifacts: language guide(s), applicable standards, work item artifacts
   (TR-9.2) if a plan state update is in the diff
4. Evaluate applicability conditions (TR-1.6) for each requested check; mark
   inapplicable checks as `skipped`
5. Spawn applicable specialist agents in parallel, each receiving only its required
   inputs (see data contracts below)
6. For large PRs (TR-3.2): partition the diff into file groups before step 5; spawn
   the applicable specialist set per partition in parallel; deduplicate cross-partition
   findings after collection
7. Collect findings arrays from all completed agents
8. Spawn confidence-scorer agent with the complete collected findings set (all
   dimensions combined); it returns a map of `finding_id → confidence_score`
9. Apply advisory threshold promotion
10. Run post-review eligibility checks (TR-4.5); discard and exit silently if PR
    state changed during review
11. Compose the final output record conforming to the review output schema

**Specialist agent data contracts:**

| Check | Agent receives | Skipped when |
|-------|---------------|--------------|
| `rr-standards-plugin` | Diff + language guide(s) + applicable language-agnostic standards | — |
| `security` | Diff + security standard + applicable security policy | — |
| `privacy` | Diff + privacy standard + data handling policy | — |
| `traceability` | Diff + requirements artifacts + tech spec + plan items | No plan state update in diff |
| `test-coverage` | Diff + test strategy + requirements artifacts | No plan state update in diff |
| `error-handling` | Diff + error handling standard | — |
| `historical-context` | Git blame output + recent commit log for modified files | All modified files are newly created |
| `duplication` | Diff + relevant existing source files (same layers as changed files) | — |

Each specialist returns a `findings` array and a `check` record conforming to the
shared review output schema (`.forge/efforts/forge-plugin/spec/review-output-schema.md`).

**Confidence-scorer agent:**

After all specialists complete, a dedicated confidence-scorer agent receives the full
findings set and scores each finding 0–100 using the rubric in the review output schema
(§ Confidence Scoring). This runs as a separate agent — not inline in the orchestrator —
so the scorer operates with a focused context (findings, not source code) and can
calibrate scores across dimensions with the complete picture. It returns a map of
`finding_id → confidence_score`.

**Context isolation principle:**

Each specialist receives only the standards and artifacts relevant to its check. The
security specialist does not receive the test strategy; the traceability specialist does
not receive OWASP policy documents. This is not only an efficiency measure — loading
irrelevant context degrades analysis quality by introducing noise that causes agents to
conflate concerns across domains.

---

## TR-2: Language Detection and Standards Injection

### TR-2.1: Automatic Language Detection

The review skill must detect the file extensions present in the PR diff and map them
to the corresponding language-specific standards documents. Detection must happen at
skill invocation time without engineer input.

### TR-2.2: Standards Coverage

Language-specific standards must exist and be loadable for each supported platform:
Java, Go, Node.js, Kotlin, Swift, Objective-C, TypeScript. If a language has no
corresponding standards document, the review must proceed with the available
language-agnostic standards and note the gap in the findings output.

### TR-2.3: Standards Reference Pattern

The review skill must reference standards documents at their canonical paths in
`rr-standards`, not embed rules inline. Standards are authoritative; the skill is an
evaluator. If a standard changes, the review behavior changes automatically without
skill modification.

### TR-2.4: Guide Version and Conflict Resolution

When loading a language guide for review, the skill must check the guide's declared
`Implements:` version against the current version of the referenced standard and apply
the conflict resolution hierarchy defined in `standards/TAXONOMY.md`:

- **Current guide** — apply in full
- **MINOR-stale guide** — apply guide patterns for rules it covers; evaluate rules
  added in the newer standard version directly against the standard; note in the review
  output which rules were evaluated without guide coverage
- **MAJOR-stale guide** — treat as supplementary; evaluate all correctness against the
  current standard; apply guide patterns only for language idioms the standard does not
  address; note in the review output that the guide is MAJOR-stale and which rules were
  evaluated without guide coverage

The review output must identify when a stale guide was loaded and what impact this had
on coverage — engineers must be able to distinguish findings sourced from the standard
directly from findings sourced from guide-specific patterns.

The technical specification for the current work item (loaded via TR-1.1) takes
precedence over both the standard and the guide during implementation and review — but
only when the design phase is approved: the work item's `.state.json` must show
`design.status: complete` and `design.approvedAt` set. An approved spec's intentional
deviations from general standards have already been reviewed and accepted; they must not
be re-flagged during code review.

If no approved spec is present (e.g., the PR has no plan state update, or the design
phase is not yet complete), the standard is authoritative and the tech spec, if any,
is the artifact being evaluated rather than the authority.

---

## TR-3: Large PR Handling

### TR-3.1: Diff Size Threshold

The review skill must assess diff size before beginning analysis. The threshold for
triggering parallel review is configurable (default: TBD during design). The threshold
must be documented in the skill's README.

### TR-3.2: Parallel Partitioned Review

For diffs exceeding the threshold, the skill must:
1. Partition the diff into file groups (by layer: API handlers, data access, tests,
   configuration, etc.)
2. Spawn a parallel worker per file group, each with a fresh context window
3. Each worker applies the full review criteria to its partition
4. The orchestrator aggregates findings from all workers into a single unified report,
   deduplicating findings that span multiple partitions

### TR-3.3: Aggregation Consistency

The aggregated report must present findings in a consistent format regardless of how
many partitions were reviewed. The AI signal (approve / request-for-changes) must be
derived from the full aggregated findings, not from any individual partition's signal.

### TR-3.4: Re-Review Scope

When a developer pushes new commits to an open PR, the review re-runs. Two re-review
modes must be supported:

- **Full diff mode**: re-evaluates the complete PR diff from base branch to HEAD on
  every trigger. Produces the highest-quality result because the reviewer has full
  context of the entire change. Higher cost per invocation.
- **Incremental mode**: evaluates only commits pushed since the last completed review.
  Faster and cheaper; appropriate for iterative development where the author is
  addressing specific findings. Carries the risk that cross-commit context is lost —
  a finding that spans earlier and later commits may be missed.

Both modes must be implemented. The default mode and per-repository configuration
mechanism are deferred to the design phase. The skill README must document the
tradeoffs so teams can make an informed choice.

---

## TR-4: GitHub Actions Integration

### TR-4.1: Automatic Trigger

The review must run automatically on PR creation and update (push to a PR branch). It
must not require engineer invocation. The trigger is a GitHub Actions workflow
(`pr-review.yml`).

### TR-4.2: Required Status Check

The review must set a GitHub required status check. The check name must be stable and
configurable for branch protection rule targeting. The check must be set on every PR,
including draft PRs (configurable).

### TR-4.3: PR Comment and Inline Review Comments

The review must surface findings in two forms:

1. **Inline review comments**: each finding that can be anchored to a specific diff
   line must be posted as a GitHub review comment on that line. This is the primary
   way engineers navigate and address findings during code review.

2. **Summary review comment**: a single PR comment containing the complete review
   report — risk classification, all findings (including any that could not be anchored
   to a specific line), suppressions in effect, excluded files, standards applied, and
   the AI signal. On re-review (PR update), the previous summary comment must be
   updated in-place rather than creating a new comment.

### TR-4.4: Cost Ceiling

The review invocation must operate within a configurable per-invocation cost ceiling
defined by Productivity Engineering. An invocation that would exceed the ceiling must
fail with a diagnostic error rather than producing partial output silently.

### TR-4.5: Review Eligibility Checks

The review must perform an eligibility check before beginning and again immediately
before posting any output.

**Pre-review check** — skip and exit with a passing status if:
- The PR is closed or already merged
- The PR is a draft (configurable — some teams prefer reviews on drafts)
- The PR is an automated/trivial PR (dependency version bumps, generated file
  updates, lock file changes with no other changes) — these are better handled by
  dedicated tools
- The current HEAD SHA already has a complete review from `forge:review` (see
  idempotency below)

**Post-review check** (before posting the comment) — discard findings and exit
silently if:
- The PR was closed or merged during the review
- The HEAD SHA changed during the review (a new commit was pushed while the review
  was running) — the review is now stale; the next trigger will produce a fresh review

### TR-4.6: Idempotency

Running `forge:review` twice on the same PR at the same HEAD SHA must be a no-op
on the second run. The skill must check whether the current HEAD SHA already has a
summary review comment from a completed `forge:review` invocation. If it does, the
skill exits with the pre-review eligibility check (TR-4.5) without running the full
review.

This is distinct from incremental mode (TR-3.4), which handles the case where new
commits have been pushed. Idempotency handles the case where nothing has changed.

---

## TR-5: Degraded Mode

### TR-5.1: Failure Classification

The review must distinguish between these failure modes and surface them with distinct
messages:
- **AI service unavailable**: the model API is unreachable or returned a non-retryable
  error
- **Cost ceiling exceeded**: the diff exceeds the configured cost ceiling
- **Invalid input**: the diff or supporting context is malformed

### TR-5.2: Status Check Behavior on Failure

On AI service unavailability, the status check must be set to `failure` (not `error`
or `pending`) with a message that is clearly a service outage, not a code quality
failure. Engineers must be able to distinguish an outage from a legitimate rejection.

### TR-5.3: Override Mechanism

A Productivity Engineering override must exist to mark a PR as manually approved
during an outage. The override must be: logged, associated with the approving
authority, and produce a status check result that is distinct from a standard AI
approval.

---

## TR-6: Audit Record

### TR-6.1: Artifact Persistence

The machine-readable review record (TR-7.2) is the audit artifact for R1/R2 PRs.
No separate audit artifact format is required — the same record written to the CI
metrics database (TR-7.3) serves both purposes.

The database write is best-effort for all PRs, including R1/R2. A write failure
must not fail the review or block the PR status check. Write failures on R1/R2 PRs
must generate a higher-severity operational alert than failures on R3/R4 PRs, to
ensure gaps in the audit record are surfaced promptly.

### TR-6.2: Retention

Audit records must be retained for the duration defined by the organization's
compliance policy. The storage mechanism must support this retention without manual
management.

### TR-6.3: Scope

The audit record applies to R1/R2 PRs. R3/R4 PR review output is posted as a PR
comment but is not required to be persisted as a separate audit artifact.

---

## TR-7: Metrics Collection and Reporting

### TR-7.1: Review Scope — New Code Only

The review skill evaluates only the lines of code introduced or modified in the PR
diff. Pre-existing code in unchanged files is out of scope. This constraint applies
to all review modes: standard, security, and privacy. Findings must be anchored to
specific changed lines; a finding that cannot be anchored to a changed line must not
be emitted as a blocking finding.

This scoping decision means Forge does not replace SonarQube's whole-repository
analysis. It replaces SonarQube's per-PR analysis on new code, which is the gating
concern. Historical and trending metrics are derived from the accumulation of per-PR
records over time.

### TR-7.2: Machine-Readable Output Record

Every review invocation must produce a machine-readable record (JSON) in addition to
the human-readable PR comment. The record must capture sufficient information for
metrics aggregation, audit, and trend analysis. At minimum it must cover:

- **PR identity**: repository, PR number, commit SHA, branch
- **Review metadata**: timestamp, model identifier, token usage (input and output)
- **Risk classification**: the R1–R4 level assigned to this PR
- **Standards applied**: identifiers and versions of all standards loaded during review
- **Findings**: for each finding — the rule identifier (join key for trend queries),
  the standard it belongs to, the finding category, the effective severity after
  policy application, and the file and line location
- **Decision**: approve or request-for-changes

The specific field names, JSON structure, and schema version mechanism are deferred
to the design phase. The schema must be versioned; changes that alter or remove
existing fields are breaking changes requiring a major version increment.

### TR-7.3: Metrics Database Integration

The machine-readable record must be written to the existing CI metrics database on
every review invocation — including invocations that produce an `approve` decision.
Connection details and write mechanism are deferred to the design phase; the
requirement is that no review record is silently discarded.

The metrics database write is a best-effort side effect: a write failure must not
fail the review or block the PR status check. Write failures must be logged and
surfaced as a distinct operational alert.

### TR-7.4: Report Generation

A skill or GitHub Actions workflow must exist that queries the CI metrics database
and produces a quality trend report on demand. The report must include at minimum:
- Finding counts by severity over a selectable time window
- Finding counts by rule and by standard
- Per-repository and cross-repository views
- Decision distribution (approve vs. request-for-changes) by risk level

This capability is the direct functional replacement for SonarQube's reporting UI.
Design of the report format and query interface is deferred to the design phase.

---

## TR-8: File and Directory Exclusions

### TR-8.1: Per-Repository Exclusion Configuration

The review skill must support a configurable exclusion list per repository, defined
using glob patterns in a version-controlled configuration file co-located with the
repository (file name and location deferred to design). Patterns in this file are
applied before any review begins — matching files are not loaded into the review
context.

### TR-8.2: Default Exclusion Set

A default exclusion set must be maintained and applied to every repository unless
overridden. The default set must cover at minimum:
- Generated protobuf and gRPC output files
- Vendored dependencies (e.g., `vendor/`, `node_modules/`)
- Lock files
- Build output directories

The default set is defined by Productivity Engineering and versioned with the Forge
framework. Repositories may extend it (add patterns) or selectively override it
(remove default patterns) via their local configuration.

### TR-8.3: Exclusion Transparency

Every review report must include the list of files that were present in the diff but
excluded from review. The exclusion reason (matched pattern) must be included. This
ensures exclusions are visible and auditable — a file is never silently skipped.

---

## TR-9: Traceability Review

### TR-9.1: Work Item Identification

The traceability review is activated when the PR diff includes an update to a Forge
implementation plan state file. The review agent reads this state change to identify
which work item is being implemented. If no plan state update is present, the
traceability review does not run; the summary report must note the absence. Absence
of a plan state update is not a blocking finding — not all changes are Forge-driven.

### TR-9.2: Artifact Loading

Once the work item is identified, the review agent loads from `.forge/efforts/<id>/`
at the base branch HEAD:
- The implementation plan item describing what this change commits to deliver
- The technical specification the plan item references
- The business and technical requirements the specification traces to

### TR-9.3: Traceability Evaluation

The agent evaluates the code diff against the loaded artifacts and checks:
- Does the implementation cover what the plan item committed to deliver?
- Are there requirements or specification clauses with no corresponding code changes?
- Does the code introduce behaviour not described in the technical specification?

Findings in the traceability category are subject to the same blocking/informational
severity model as all other finding categories.

---

## TR-10: Duplication Detection

### TR-10.1: Duplication Scope

The review must detect code duplication between files in the PR diff and between the
diff and existing code in the repository. Two forms must be detected:

- **Textual duplication**: copy-pasted blocks with minor editing
- **Semantic duplication**: blocks that accomplish the same logic with different
  variable names, minor structural variation, or equivalent expressions

### TR-10.2: Finding Format

A duplication finding must identify: all locations of the duplicated logic (file and
line for each occurrence), a concise description of what is duplicated, and
recommended remediation — typically extraction to a shared function, method, or
constant.

### TR-10.3: Threshold

Trivial duplication must not be flagged: two-line blocks, common boilerplate,
test data fixtures, and language-mandated repetition (e.g., error wrapping patterns)
are below threshold. The minimum reportable duplication size is deferred to the design
phase and must be configurable.

---

## TR-11: Inline Finding Suppression

### TR-11.1: Suppression Syntax

Engineers may suppress a specific finding at a specific location using an inline
annotation comment on the line immediately preceding the flagged code:

```
// forge:suppress <rule-id> <reason>
```

The `rule-id` must match a stable rule identifier from the applicable enforcement
policy. The reason is free text and is syntactically required; its content is not
validated.

### TR-11.2: Suppression Behaviour

A suppressed finding is removed from the blocking and informational finding counts
and does not influence the AI signal. The suppression is not silent: the summary
review comment must list all active suppressions present in the diff, with the rule
suppressed, the file and line, and the stated reason.

### TR-11.3: Metrics Tracking

Suppressed findings must be included in the machine-readable output record with a
suppression flag and the stated reason, so that suppression rates can be monitored
in the metrics database alongside ordinary findings.

### TR-11.4: Scope

A suppression applies to the annotated line and rule only. It does not suppress other
rules at the same line, the same rule at other lines, or the same rule in future PRs
that touch the same line. For rule-level suppression across an entire repository, the
project-level enforcement override (`.forge/enforcement.yml`) is the appropriate
mechanism.

---

## TR-12: Confidence Scoring

### TR-12.1: Per-Finding Confidence Score

After all findings are collected, each finding must be independently scored 0–100
for likelihood of being a real, actionable issue rather than a false positive. The
scoring rubric is defined in the Forge review output schema
(`.forge/efforts/forge-plugin/spec/review-output-schema.md § Confidence Scoring`)
and must be provided verbatim to the scoring agent.

Confidence scoring is a second-pass filter applied after false-positive controls
(TR-1.4). TR-1.4 eliminates clear non-findings before they enter the finding list;
confidence scoring handles ambiguous cases that the reviewer emitted but may not
be real.

### TR-12.2: Confidence Threshold

A configurable `confidence_threshold` (default: 80) governs suppression. Findings
with `confidence` below the threshold are confidence-suppressed:

- Excluded from `verdict.blocking_count`, `verdict.advisory_count`, and
  `verdict.informational_count`
- Do not influence the AI signal (`approve` / `request-for-changes`)
- Not posted as inline comments or included in the human-readable summary
- Retained in the machine-readable output record with `confidence_suppressed: true`
  so suppression rates can be monitored in the metrics database (TR-7)

The threshold is configurable per repository in the same configuration file as the
file exclusion list (TR-8.1).

### TR-12.3: Independence from Developer Suppression

Confidence suppression (automatic, based on score) is independent of
`forge:suppress` annotations (developer-initiated, rule-specific, with a stated
reason — TR-11). Both may apply to the same finding simultaneously. They are tracked
separately in the output record and the metrics database.

---

## Constraints

### Technical Constraints

- Must run within GitHub Actions without additional runtime dependencies beyond the
  Claude Code environment
- Must operate within the configurable per-invocation cost ceiling
- Review output format must be stable across versions; changes to output format that
  would break downstream consumers (branch protection rules, audit tooling) are
  breaking changes requiring a major version increment
- AI output is not fully deterministic — two runs on identical input may produce
  different findings. This is accepted and expected. The goal of structured standards,
  isolated workers, and a defined output format is to minimize variation, not eliminate
  it. Human reviewers exhibit equivalent variation; the AI review is held to the same
  standard, not a higher one.

### Process Constraints

- The approval policy (R1/R2 requires human review; R3/R4 AI-sufficient) must be
  owned by Productivity Engineering and enforced via branch protection rules, not
  hardcoded in the skill
- Language-specific standards must pre-exist for a language before that language can
  be reviewed to its full standard; the review must degrade gracefully for languages
  without standards
- Cyclomatic and cognitive complexity enforcement is owned by the project's configured
  linter, not by the AI review agents. Go projects use `golangci-lint` (which
  aggregates `gocyclo`, `gocognit`); TypeScript projects use ESLint with the built-in
  `complexity` rule or `eslint-plugin-sonarjs`. The AI review covers semantic
  complexity that linters cannot measure — this falls under the coding standards
  review category and requires no separate complexity agent.

### Open Questions

1. ~~**Audit record storage location**~~ — **Resolved:** R1/R2 audit records are written
   to the existing CI metrics database alongside all other per-PR review records
   (TR-7.3). The full machine-readable record (TR-7.2) is the audit artifact. No
   separate storage mechanism is required.

2. **Large PR diff threshold** — what is the default threshold (in tokens or line count)
   for triggering parallel review?
   - **Impact:** Determines TR-3.1 configuration and affects per-invocation cost
   - **Decision needed by:** start of design phase

3. **Draft PR behavior** — should the review run on draft PRs? Running on drafts
   provides earlier feedback; not running avoids cost on in-progress work.
   - **Impact:** TR-4.4 GitHub Actions trigger configuration
   - **Decision needed by:** design phase

4. ~~**Standards version applied at review time**~~ — **Resolved (Option A):** The review
   loads standards at the forge framework version installed in the repository — the version
   present in the repo at the time of the review run. Teams control when they adopt updated
   standards by choosing when to run `forge:update`. This model is consistent with the
   eviction-based versioning in `rr-standards`: each standard file reflects the current
   version; previous versions are in git history. Drift from current organizational
   standards is a team-controlled risk, accepted in exchange for predictable review
   behaviour — a PR that passes today will not fail tomorrow because a standard changed
   upstream. The `forge:update` mechanism is the controlled upgrade path.
