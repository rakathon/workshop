# Business Requirements — AI-Powered PR Review

Parent program: [forge-plugin](../../forge-plugin/requirements/business.md)
Primary program BRs addressed: BR-4, BR-11, BR-17, BR-18

---

### BR-1: AI Must Verify Standards Compliance Before Human Review

Every pull request must receive an AI compliance review before human reviewers see it.
The review must examine coding standards, security policy, privacy policy, and
traceability to requirements. It must produce a structured findings report and an
explicit approve or request-for-changes signal. Human reviewers must not be the
primary mechanism for catching standards violations — they should focus on logic,
architecture, and judgment. The AI review is a gate, not a suggestion.

### BR-2: Review Coverage Must Be Tiered by Risk

The approval requirement is tiered:
- **R1/R2 changes** (authentication, payments, PII, core capabilities): AI approval is one
  required signal; a human reviewer must also approve before merge is permitted.
- **R3/R4 changes** (new capabilities, minor changes): AI approval is sufficient.

Developers always decide when to merge. The approval policy is owned by Productivity
Engineering and must be implementable via GitHub branch protection rules and CODEOWNERS
configuration without changes to the review skill itself.

### BR-3: Review Quality Must Not Degrade With PR Size

Large PRs must receive reviews of equivalent quality to small PRs. Context limitations
must not cause the review to miss findings on large diffs. The review must produce a
unified, complete findings report regardless of diff size.

### BR-4: The AI Review Signal Must Be a Required GitHub Status Check

The AI review result (approve or request-for-changes) must be surfaced as a required
GitHub status check on every PR. A PR that has not received an AI review signal cannot
be merged. This check must run automatically without engineer invocation — it must
trigger on PR creation and update.

### BR-5: Degraded Mode Must Be Explicit and Consistent

When the AI service is unavailable, the PR review must fail with a structured diagnostic
error — not silently pass. No PR may auto-pass during an outage without an explicit,
logged override from Productivity Engineering. The degraded behavior must be consistent
across all teams and PRs; no team may receive different availability than another.

### BR-6: AI Review Decisions on R1/R2 PRs Must Be Auditable

The rationale for every AI approve or request-for-changes decision on a R1/R2 PR must
be persisted as an artifact associated with that PR. The artifact must include: which
standards were applied, which findings were identified, what evidence supported the
conclusion, and the final signal emitted. It must be queryable after the session that
produced it has ended, supporting dispute resolution and compliance audit.

### BR-7: Language-Specific Standards Must Be Detected and Applied Automatically

The review must detect which languages are present in the PR diff and apply the
corresponding language-specific coding standards. Engineers must not need to specify
which standards apply or invoke any additional command — language detection and
standards loading must happen automatically as part of the review.

### BR-8: Forge Review Must Produce Metrics Sufficient to Replace SonarQube Reporting

The organization currently uses SonarQube for static analysis and code quality metrics.
The Forge review capability must collect equivalent metrics as a byproduct of each PR
review, eliminating the need for SonarQube. Reproducing the SonarQube UI is not a
requirement — the GitHub PR interface is sufficient for surfacing findings. What is
required is that the data produced by each review is written to the existing CI metrics
database so that quality trends can be tracked and reports can be generated on demand.

### BR-9: Review Gating Must Apply Only to New Code; No Repository-Level Quality Gate Is Required

Review gating applies only to new code introduced in the PR diff. Pre-existing
violations in the repository are not a gating concern — they are a metrics and
trend concern only. No repository-level quality gate is required.

### BR-10: The Review Must Provide Actionable Remediation Guidance for Every Finding

Identifying a violation is necessary but not sufficient. Engineers must be able to
resolve any blocking finding using only the information in the review report, without
consulting external documentation. For every finding, the review must explain what
correct code looks like, why the current code violates the rule, and what the engineer
must do to fix it. This is the primary differentiator from static analysis tools such
as SonarQube, which surface violations without prescribing resolutions.

### BR-11: Human Approval Is Always a Valid Alternative to AI Approval

The AI review is a quality signal, not a veto. A human engineer's approval is
sufficient to permit merge at all risk levels — it always overrides the AI signal.
This is the escalation path for disputed findings: an engineer who believes a finding
is incorrect, or who accepts the risk of a flagged issue, can request human review.
A human approval allows the PR to merge regardless of the AI decision.

This design also preserves the existing human review culture rather than replacing it.
The AI review accelerates the process by making human review optional for most PRs;
it does not make human review impossible.

### BR-12: Review Turnaround Must Not Become a Developer Bottleneck

The AI review must complete and post its result within 15 minutes of PR creation or
update. The organization currently averages 8 or more hours waiting for human PR
review; the AI review must be a substantial improvement, not a new queue. Reviews
that consistently exceed 15 minutes undermine the tool's value — a slow automated
review is no better than waiting for a human, and may be worse if it blocks progress
without the benefit of judgment.

If the 15-minute target cannot be reliably met for the organization's typical PR
sizes, the deployment approach must be reconsidered before broad rollout.

### BR-13: SonarQube Decommission Is Per-Repository, Contingent on Coverage Parity

SonarQube is removed on a per-repository basis, not in a single organization-wide
cutover. A repository can decommission SonarQube once Forge covers all categories
that SonarQube currently enforces for that repository. Repositories where Forge
coverage is incomplete continue to use SonarQube for the uncovered categories until
parity is reached. There is no mandated decommission date — the migration is
driven by coverage, not by schedule.

### BR-14: Review Must Support Configurable File and Directory Exclusions

Teams must be able to configure patterns to exclude from review — generated code,
vendored dependencies, migration scripts, and other files where findings are expected
but not actionable. Excluded files must be visible in the review report; exclusions
must not silently reduce coverage. The exclusion configuration must be per-repository
and version-controlled alongside the repository it governs.

### BR-15: Review Must Detect Code Duplication

The review must identify duplicated logic as a distinct finding category — both
textual copy-paste and semantic duplication where two blocks accomplish the same
thing with different variable names or minor structural differences. Duplication
findings must identify all locations of the duplicated logic and provide remediation
guidance. Trivial or unavoidable duplication (common boilerplate, test fixtures) must
not be flagged; the threshold is a configuration concern.

### BR-16: Engineers Must Be Able to Suppress Specific Findings at Specific Locations

An engineer must be able to suppress a specific finding at a specific code location
using an inline annotation that includes the rule identifier and a reason. Suppressions
are not silent — every active suppression is listed in the review report with its rule
and stated reason. Suppressed findings are tracked in the metrics database so that
suppression rates can be monitored over time.

---

Success criteria: [success-criteria.md](success-criteria.md)
