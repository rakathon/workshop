# Success Criteria — AI-Powered PR Review

- [ ] 100% of pull requests receive an AI review signal before human review; no PR
      reaches a human reviewer without an approve or request-for-changes signal
- [ ] Review quality (measured by human reviewer finding rate on reviewed PRs)
      is equivalent for PRs of any size
- [ ] AI service outages produce a structured diagnostic error on 100% of affected PRs;
      no PR auto-passes during an outage without a logged Productivity Engineering override
- [ ] 100% of AI blocking decisions on R1/R2 PRs have a persisted audit record queryable
      after the session that produced them has ended
- [ ] Engineers report that the AI review catches standards issues they would have
      previously missed or caught only in human review
- [ ] Per-PR metrics are written to the CI metrics database on every review invocation;
      write failures are surfaced as operational alerts and tracked for remediation
- [ ] A report generation capability exists that queries the metrics database and
      produces a quality trend report on demand; SonarQube can be decommissioned once
      this is operational
- [ ] Review gating applies only to new code in the diff; pre-existing violations do
      not block PR merge
