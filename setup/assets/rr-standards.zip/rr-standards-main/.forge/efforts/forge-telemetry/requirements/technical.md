# Technical Requirements — Forge Telemetry

**Effort:** forge-telemetry  
**Phase:** discovery  
**Last updated:** 2026-04-15 (rev 2 — added TR-18 through TR-21 for per-turn Stop hook)

---

## Derives from

- BR-1 Skill usage visibility
- BR-2 Session-level insights
- BR-3 Token and cost tracking
- BR-4 Effort phase progression
- BR-5 Non-invasive collection
- BR-6 Engineer identity attribution
- BR-7 Per-turn cost and model visibility

---

## Collection Mechanism

### TR-1 — Hook-Based Instrumentation

Telemetry must be collected exclusively via Claude Code lifecycle hooks. No agent
prompts, no manual commands, and no code instrumentation in skill scripts.

**Hook events used:**

| Event | Purpose | BR |
|---|---|---|
| `SessionStart` | Emit `session_start` event; capture session ID and entrypoint | BR-2, BR-6 |
| `UserPromptSubmit` | Detect `forge:*` skill invocations in the submitted prompt; record turn start timestamp | BR-1, BR-7 |
| `PostToolUse` (Write\|Edit) | Detect phase status changes in `.forge/efforts/*/.state.json` | BR-4 |
| `Stop` | Emit `turn_complete` event with model, token counts, cost, duration, and active skill | BR-7 |
| `SessionEnd` | Emit `session_end` with token/cost rollup from transcript JSONL | BR-3 |

Rationale: hooks receive structured JSON on stdin and execute asynchronously, making
them the only mechanism that does not alter the engineer's observable workflow.

---

### TR-2 — Session Start — Source Filtering

The `SessionStart` hook fires on every Claude Code context event, including
`resume`, `clear`, and `compact`. A `session_start` telemetry event must only be
emitted when `source == "startup"` (a genuine new session), not on context
management events.

**Implementation:** Parse the `source` field from the JSON payload on stdin before
emitting any telemetry.

---

### TR-3 — Skill Detection — Prompt Scanning

Skill invocation is detected in the `UserPromptSubmit` hook by scanning the
submitted prompt text for patterns matching `forge:<skill-name>` or
`/forge:<skill-name>`.

**TR-3.1** — The detection must be case-insensitive.  
**TR-3.2** — Only canonical `forge:*` skill names are tracked; free-form mentions
("let's use forge plan") are not captured.  
**TR-3.3** — The full qualified skill name (e.g., `forge:commit`) must be recorded
in the event payload, not a shortened alias.

---

### TR-4 — Phase Transition Detection

The `PostToolUse` hook for Write/Edit operations must inspect the written file path.
If the path matches `.forge/efforts/<id>/.state.json`, the hook reads the file and
compares the `currentPhase` and the phase's `status` field against a cached prior
value to detect changes.

**TR-4.1** — Only genuine state changes (prior ≠ current) produce a telemetry event.  
**TR-4.2** — The cache is per-session (in-memory or temp file); no cross-session state
diff is required.  
**TR-4.3** — If the `.state.json` file cannot be parsed (malformed JSON), the hook
must exit 0 silently without emitting a telemetry event.

---

### TR-5 — Session End — Transcript Parsing

The `SessionEnd` hook must extract token usage and model from the Claude Code
transcript JSONL file. The transcript path is provided in the hook's stdin payload.

**TR-5.1** — Fields extracted: `model`, `cc_version`, `entrypoint`, `turns`,
`input_tokens`, `output_tokens`, `cache_read_tokens`, `cache_creation_tokens`.  
**TR-5.2** — Estimated cost is calculated client-side using a hardcoded pricing table
(input, output, cache-read, cache-creation rates per model).  
**TR-5.3** — If the transcript is absent or unreadable, the event is emitted with
token fields set to `null` rather than omitted.  
**TR-5.4** — Cost is rounded to 6 decimal places (USD).

---

## Event Schema

### TR-6 — Canonical Event Payload

Every telemetry event POSTed to the API must conform to this schema:

```json
{
  "event_id":        "<uuid-v4>",
  "event_timestamp": "<ISO-8601-UTC>",
  "event_type":      "session_start | session_end | skill_invoked | phase_transition | turn_complete",
  "engineer_id":     "<OS username>",
  "repo_name":       "<git remote basename or directory name>",
  "skill_name":      "<forge:skill-name or null>",
  "effort_id":       "<active effort id or null>",
  "phase":           "<current phase name or null>",
  "forge_version":   "<semver string>",
  "session_id":      "<claude-code-session-uuid>",
  "metadata":        { ... }
}
```

**TR-6.1** — `event_id` must be a UUID v4 generated at event construction time.  
**TR-6.2** — `engineer_id` is derived from `$USER` or `$LOGNAME`; never from git config
(which may differ per repo).  
**TR-6.3** — `repo_name` is derived from the git remote `origin` URL basename (strip
`.git` suffix). Falls back to `basename $PWD` if no remote is configured.  
**TR-6.4** — `metadata` shape varies by event type (see TR-7 through TR-10).

---

### TR-7 — `session_start` Metadata

```json
{
  "entrypoint": "cli | vscode | jetbrains | web",
  "git_branch": "<branch-name or null>"
}
```

---

### TR-8 — `session_end` Metadata

```json
{
  "model":                 "<model-id>",
  "cc_version":            "<claude-code-version>",
  "entrypoint":            "cli | vscode | jetbrains | web",
  "git_branch":            "<branch-name or null>",
  "turns":                 <integer>,
  "input_tokens":          <integer or null>,
  "output_tokens":         <integer or null>,
  "cache_read_tokens":     <integer or null>,
  "cache_creation_tokens": <integer or null>,
  "estimated_cost_usd":    <float or null>
}
```

---

### TR-9 — `skill_invoked` Metadata

```json
{
  "skill_name": "forge:plan"
}
```

(Duplicated from top-level `skill_name` for query convenience in the warehouse.)

---

### TR-10 — `phase_transition` Metadata

```json
{
  "phase":  "<phase-name>",
  "from":   "<prior-status>",
  "to":     "<new-status>"
}
```

---

## Delivery

### TR-11 — HTTP POST to API

All events are delivered via HTTP POST to a configurable endpoint.

**TR-11.1** — Endpoint is read from `$FORGE_TELEMETRY_URL`. Default:
`https://rr-productivity-portal-dev-feat-pdo-8958.shared-np.rr-it.com/api/forge-events`  
**TR-11.2** — Request body is `application/json`.  
**TR-11.3** — Curl timeout is 5 seconds (`--max-time 5`).  
**TR-11.4** — The POST runs in a background subshell (`&`) for all events except
`session_end`, which must `wait` for delivery before the hook exits.  
**TR-11.5** — Non-2xx responses and curl failures are silently discarded (no retry,
no error output to the engineer).

---

### TR-12 — No Local Persistence Requirement

Events are fire-and-forget over HTTP. Local fallback buffering (e.g., writing to
`.forge/telemetry/events.sql`) is not required for production correctness and may
be removed once API delivery is confirmed reliable.

---

## Performance

### TR-13 — Hook Latency Budget

- `SessionStart` and `UserPromptSubmit` hooks: ≤ 200 ms total wall time (including
  the background curl spawn).
- `PostToolUse` (Write/Edit): ≤ 100 ms for the synchronous path; POST is async.
- `SessionEnd`: ≤ 3 seconds total (transcript parse + blocking POST).

---

## Resilience and Safety

### TR-14 — Metadata Sanitisation

Before serialising metadata to JSON, all string values must be sanitised to prevent
injection. Specifically, field values derived from shell variables (branch names,
usernames, file paths) must be passed through a JSON-safe quoting step before
embedding in the payload body.

**TR-14.1** — Use `jq` for payload construction wherever available; fall back to
manual escaping if `jq` is absent.  
**TR-14.2** — If `jq` output is empty or malformed (partial output), the hook must
skip event emission and exit 0 rather than sending a corrupted payload.

---

### TR-15 — Dependency Availability

Hooks must gracefully degrade when optional dependencies are absent.

| Dependency | Absent behaviour |
|---|---|
| `jq` | Emit event with `metadata: {}` and log a warning to stderr (not stdout) |
| `python3` | Skip cost calculation; set `estimated_cost_usd: null` |
| `git` | Set `repo_name` to directory basename; set `git_branch` to null |
| `curl` | Skip HTTP delivery silently; exit 0 |

---

## Data Warehouse

### TR-16 — Snowflake Schema

Events are loaded into a Snowflake table with the following structure:

```sql
CREATE TABLE IF NOT EXISTS forge_events (
    event_id          STRING        NOT NULL,
    event_timestamp   TIMESTAMP_LTZ NOT NULL,
    event_type        STRING        NOT NULL,
    engineer_id       STRING        NOT NULL,
    repo_name         STRING        NOT NULL,
    skill_name        STRING,
    effort_id         STRING,
    phase             STRING,
    forge_version     STRING,
    session_id        STRING,
    metadata          VARIANT,

    CONSTRAINT pk_forge_events PRIMARY KEY (event_id)
);

-- Migration: add session_id to existing deployments (run once against tables created before v0.6)
ALTER TABLE forge_events ADD COLUMN IF NOT EXISTS session_id STRING;
```

**TR-16.1** — `metadata` is stored as a VARIANT (schema-on-read) to allow event type
schemas to evolve without DDL changes.  
**TR-16.2** — `event_id` is the primary deduplication key; duplicate inserts must be
idempotent (INSERT OR IGNORE / MERGE semantics).

---

### TR-17 — Pre-Built Reporting Views

The schema must include views that address the business requirements directly:

| View | Addresses |
|---|---|
| `forge_session_summary` | BR-2, BR-3: one row per session with token/cost/skill rollup |
| `forge_skill_usage` | BR-1: skill invocation counts by engineer, repo, and day |
| `forge_daily_cost` | BR-3: total estimated cost per engineer per day |

`turn_complete` events are written directly to `forge_events` (no dedicated view
required — BR-7 is served by querying `WHERE event_type = 'turn_complete'`).

---

## Per-Turn Telemetry (Stop Hook)

### TR-18 — Stop and StopFailure Hook Registration

Both `Stop` and `StopFailure` hooks must be registered in `hooks/hooks.json`. Both
events mark the end of a turn — `Stop` on success, `StopFailure` when the turn ends
with an error. Both must emit a `turn_complete` event so that failed turns are not
silently dropped from telemetry.

```json
"Stop": [
  {
    "hooks": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/hooks/stop/capture-turn-telemetry.sh"
      }
    ]
  }
],
"StopFailure": [
  {
    "hooks": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/hooks/stop/capture-turn-telemetry.sh"
      }
    ]
  }
]
```

The same script handles both events. It must read `stop_reason` from the stdin
payload — for `StopFailure` this will reflect the failure reason.

**TR-18.1** — The hook script must exit 0 always; it must never block turn completion.  
**TR-18.2** — Neither hook uses a `matcher` field (Stop/StopFailure do not support matchers).  
**TR-18.3** — Both hooks point to the same script; no branching logic is needed based
on which event fired — the `stop_reason` field in stdin distinguishes them.

---

### TR-19 — Turn Start Timestamp

To calculate turn duration, the `UserPromptSubmit` hook must write a timestamp to a
temp file at the start of each turn. The `Stop` hook reads and deletes this file.

**TR-19.1** — Temp file path: `/tmp/forge-turn-start-${FORGE_SESSION_ID}.txt`  
**TR-19.2** — Content: Unix epoch seconds (`date +%s`).  
**TR-19.3** — The `Stop` hook computes duration as `stop_time - start_time`. If the
file is absent (first turn before `UserPromptSubmit` has run, or file was cleaned up),
duration is recorded as `null`.  
**TR-19.4** — The `Stop` hook deletes the temp file after reading it so the next turn
starts fresh.

---

### TR-20 — Active Skill Propagation

The `UserPromptSubmit` hook already detects the active `forge:*` skill. This must
be propagated to the `Stop` hook so the `turn_complete` event can include `skill_name`.

**TR-20.1** — Detected skill name is written to `/tmp/forge-active-skill-${FORGE_SESSION_ID}.txt`.  
**TR-20.2** — If no forge skill was detected in the prompt, the file is written with
an empty string (not omitted).  
**TR-20.3** — The `Stop` hook reads this file to populate `skill_name` in the event.
The file is **not** deleted by the `Stop` hook — it persists until the next
`UserPromptSubmit` overwrites it, so multi-turn skill interactions are attributed
correctly throughout the entire response sequence.

---

### TR-21 — `turn_complete` Event Payload

The `Stop` hook emits a `turn_complete` event via `telemetry_event`. The `metadata`
object must include:

```json
{
  "model":                 "<model-id from Stop hook stdin>",
  "input_tokens":          <integer or null>,
  "output_tokens":         <integer or null>,
  "cache_read_tokens":     <integer or null>,
  "cache_creation_tokens": <integer or null>,
  "estimated_cost_usd":    <float or null>,
  "duration_seconds":      <integer or null>,
  "stop_reason":           "end_turn | max_tokens | tool_use | <other>"
}
```

**TR-21.1** — Token counts are read from the `usage` field of the Stop hook's stdin
JSON payload. Field names in the payload: `input_tokens`, `output_tokens`,
`cache_read_input_tokens`, `cache_creation_input_tokens`.  
**TR-21.2** — `model` is read from the `model` field of the Stop hook's stdin JSON
payload.  
**TR-21.3** — `stop_reason` is read from the `stop_reason` field of the Stop hook's
stdin JSON payload.  
**TR-21.4** — Cost is calculated using the same pricing table as `session_end`
(TR-5.2), applied to this turn's token counts.  
**TR-21.5** — The `skill_name` top-level field in the canonical event payload (TR-6)
is populated from the active skill temp file (TR-20).  
**TR-21.6** — The POST is fire-and-forget (background `&`); the hook must not block
on delivery.
