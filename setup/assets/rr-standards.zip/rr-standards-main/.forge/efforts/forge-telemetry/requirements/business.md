# Business Requirements — Forge Telemetry

**Effort:** forge-telemetry  
**Phase:** discovery  
**Last updated:** 2026-04-15 (rev 2 — added BR-7 per-turn telemetry)

---

## Context

Engineering teams adopt the Forge AI-accelerated development framework, but there is no
visibility into how it is actually being used day-to-day. Without usage data, it is
impossible to measure adoption, identify skill gaps, understand session costs, or make
evidence-based improvements to the framework.

This effort captures that signal non-invasively via Claude Code lifecycle hooks, giving
engineering leads a continuous, low-overhead picture of forge usage without requiring
engineers to change their workflow.

---

## Business Requirements

### BR-1 — Daily Skill Usage Visibility

Engineering leads must be able to see which Forge skills are invoked each day, by
which engineers, and at what frequency — without requiring engineers to manually log
activity.

**Acceptance criteria:**
- A report or dashboard can show skill invocation counts per engineer per day.
- All `forge:*` skills are captured (e.g., `forge:plan`, `forge:commit`, `forge:status`).
- Data is available within minutes of an engineer completing a session.

---

### BR-2 — Session-Level Usage Insights

Engineering leads must be able to understand the shape of engineer Claude Code
sessions: how long they run, how many interaction turns they contain, which repository
and branch they occurred on, and which active effort (if any) the work belongs to.

**Acceptance criteria:**
- Each session produces a single summary record with: engineer identity, repository,
  branch, duration proxy (turns), session entry point, and linked effort ID.
- Sessions with no forge activity are still recorded (zero-skill sessions provide
  baseline for adoption rate calculation).

---

### BR-3 — Token Consumption and Cost Tracking

Engineering managers need to understand the token cost of Claude Code usage per
engineer and per day, so that costs can be attributed and forecast.

**Acceptance criteria:**
- Session-end records include: total input tokens, output tokens, cache read tokens,
  cache creation tokens, model used, and estimated cost in USD.
- Daily and per-engineer rollups are queryable without manual calculation.

---

### BR-4 — Effort Phase Progression Tracking

The framework requires engineers to move efforts through defined phases
(discovery → planning → implementation → verification). Engineering leads need
visibility into whether engineers are following the process and where efforts stall.

**Acceptance criteria:**
- A phase transition is recorded each time an effort's phase status changes.
- The record captures: engineer, effort ID, phase name, previous status, and new status.
- No manual action is required from the engineer to produce these records.

---

### BR-5 — Non-Invasive Data Collection

Telemetry must not interrupt the engineer's workflow. Slow or failed telemetry
delivery must be invisible to the engineer.

**Acceptance criteria:**
- Hook execution does not add perceptible latency to tool operations.
- Telemetry failures are silent (no error shown to the engineer).
- Engineers are not required to configure or invoke anything to enable telemetry.

---

### BR-6 — Engineer Identity Attribution

All telemetry events must be attributable to an individual engineer so that usage
patterns can be analyzed at the person level.

**Acceptance criteria:**
- Engineer identity is captured automatically from the OS environment (no manual entry).
- Identity is consistent across sessions on the same machine.

---

### BR-7 — Per-Turn Cost and Model Visibility

Engineering leads need visibility into cost and model usage at the turn level, not
just at session end. Turn-level data allows teams to identify which Forge skills are
expensive, which models are being used per skill, and how long each turn takes —
enabling targeted optimisation of prompts and skill designs.

**Acceptance criteria:**
- Each completed turn produces a record containing: model used, token counts
  (input, output, cache read, cache creation), estimated turn cost in USD, turn
  duration in seconds, and the Forge skill being served (if any).
- Turn records are associated with the parent session ID for aggregation.
- The data is available for querying at the same granularity as session-level data.
