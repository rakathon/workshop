# Implementation Plan — Forge Telemetry

**Effort:** forge-telemetry  
**Tier:** lightweight / extension  
**Risk:** R4  
**Last updated:** 2026-04-15

---

## Status

| Wave | Tasks | Done |
|---|---|---|
| 1 — Per-Turn Telemetry (Stop Hook) | 3 | 3 |

---

## Wave 1 — Per-Turn Telemetry (Stop Hook)

All tasks in this wave can be completed sequentially by one engineer.

---

### TASK-001 — Write turn start timestamp in UserPromptSubmit hook [auto] — 4188c1d

**Derives from:** TR-19  
**File:** `plugins/forge/hooks/user-prompt-submit/route-to-skills.sh`

After extracting `FORGE_SESSION_ID` from hook stdin (already done), append a line
that writes the current epoch timestamp to a temp file:

```bash
# Record turn-start time for duration calculation in the Stop hook
if [ -n "$FORGE_SESSION_ID" ]; then
  date +%s > "/tmp/forge-turn-start-${FORGE_SESSION_ID}.txt"
fi
```

Also write the detected skill name (or empty string) to its temp file after the
skill-detection block (section A):

```bash
# Propagate active skill to Stop hook (TR-20)
printf '%s' "${SKILL:-}" > "/tmp/forge-active-skill-${FORGE_SESSION_ID}.txt"
```

The second write must happen unconditionally — even when no skill is detected — so
the Stop hook always finds the file. Place it immediately before `exit 0` at the
end of the script (default path D).

**Acceptance:** `cat /tmp/forge-turn-start-<session_id>.txt` shows a Unix epoch
integer after submitting a prompt. `cat /tmp/forge-active-skill-<session_id>.txt`
shows `plan` after invoking `forge:plan`, and is empty after a non-skill prompt.

---

### TASK-002 — Create Stop hook script [auto] — 4188c1d

**Derives from:** TR-18, TR-20, TR-21  
**New file:** `plugins/forge/hooks/stop/capture-turn-telemetry.sh`

The script must:

1. Read the Stop hook stdin JSON (contains `model`, `usage.*`, `stop_reason`).
2. Extract `session_id` and export as `FORGE_SESSION_ID`.
3. Source `../lib/telemetry.sh`.
4. Read and delete `/tmp/forge-turn-start-${FORGE_SESSION_ID}.txt`; compute
   `duration_seconds = now - start` (null if file absent).
5. Read (but do not delete) `/tmp/forge-active-skill-${FORGE_SESSION_ID}.txt`
   for `skill_name`.
6. Extract token fields from stdin: `input_tokens`, `output_tokens`,
   `cache_read_input_tokens` (→ `cache_read_tokens`),
   `cache_creation_input_tokens` (→ `cache_creation_tokens`).
7. Extract `model` and `stop_reason` from stdin.
8. Calculate `estimated_cost_usd` using the pricing table from
   `capture-session-end.sh` (copy the Python snippet or extract to a shared helper).
9. Build metadata JSON via `jq` and call `telemetry_event "turn_complete" "$skill_name" "$metadata"`.
10. Exit 0.

The POST must run in a background subshell (`&`). The script must never exit
non-zero.

**Acceptance:** After a `forge:plan` prompt, `/tmp/forge-telemetry-debug.txt` shows
a `turn_complete` event with non-null `input_tokens`, `model`, `duration_seconds`,
and `skill_name = "forge:plan"`.

---

### TASK-003 — Register Stop and StopFailure hooks in hooks.json [auto] — 4188c1d

**Derives from:** TR-18  
**File:** `plugins/forge/hooks/hooks.json`

Add both `Stop` and `StopFailure` entries pointing to the same script:

```json
"Stop": [
  {
    "hooks": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/hooks/stop/capture-turn-telemetry.sh"
      }
    ]
  }
],
"StopFailure": [
  {
    "hooks": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/hooks/stop/capture-turn-telemetry.sh"
      }
    ]
  }
]
```

Insert both between `PostToolUse` and `SessionEnd` to match the lifecycle order
shown in the hooks diagram.

**Acceptance:** `cat plugins/forge/hooks/hooks.json` shows both `Stop` and
`StopFailure` keys pointing to `capture-turn-telemetry.sh`.

---

~~TASK-004 — dropped~~ No Snowflake schema change required. `turn_complete` events
are written directly into the existing `forge_events` table via `telemetry_event`.
Query with `WHERE event_type = 'turn_complete'` to retrieve per-turn records.
