# Technical Requirements — forge:validate-api

## Traceability

| TR | Satisfies |
|----|-----------|
| TR-1 | BR-1 |
| TR-2 | BR-1 |
| TR-3 | BR-1 |
| TR-4 | BR-2 |
| TR-5 | BR-1 |
| TR-6 | BR-3 |
| TR-7 | BR-4 |
| TR-8 | BR-4 |
| TR-9 | BR-3, BR-4 |

---

## TR-1 — Load all API contract files from the effort

The skill must load all files matching `spec/api/*.yaml` from the target effort
directory (`.forge/efforts/<effort_id>/spec/api/`).

**Acceptance Criteria:**
- All `.yaml` files under `spec/api/` are discovered and processed.
- If no files are found, the skill emits: "No API spec found. Run forge:spec-api first."
  and exits cleanly without error.

---

## TR-2 — Load REST standard files using relative paths

The skill must load the REST standard files using paths relative to the skill file
itself, not by searching the filesystem for the plugin root at runtime:

- `../../standards/api/rest/contracts.md`
- `../../standards/api/rest/protocol.md`
- `../../standards/api/rest/security.md`

If any standard file is absent, the skill warns for that concern and continues applying
general REST conventions for the rules covered by the missing file.

**Acceptance Criteria:**
- Standards are read via relative paths; no `find` command or runtime plugin root
  resolution is used.
- A missing standard file produces a warning, not a hard failure.

---

## TR-3 — Apply every rule from the loaded standards

The skill must apply the rules defined in the loaded standard files. The standard files
are the authoritative source; the skill must not substitute hardcoded inline rules that
could diverge from the standards over time. Rules present in the loaded standards but
not explicitly listed in the skill instructions must still be checked and reported.

**Acceptance Criteria:**
- Each finding references the specific rule ID from the standard (e.g., R-2, R-7).
- A rule added to a standard file is automatically in scope for the next invocation
  without requiring a skill update.
- If a loaded standard and an inline skill description conflict, the loaded standard wins.

---

## TR-4 — No file writes, no state updates

The skill must NOT write to `validation/report.md` or update `.state.json`. Output is
inline session output only.

**Acceptance Criteria:**
- The skill produces no file system side effects on any invocation.
- No calls to Write tool, no shell redirects, no artifact creation.
- This constraint is explicitly documented in the SKILL.md as the first section after
  the introduction.

---

## TR-5 — Run as a worker agent

The skill must run as a worker to avoid loading standards and policy content into the
engineer's main session context.

**Acceptance Criteria:**
- `agent-type: worker` is declared in the SKILL.md frontmatter.
- The skill runs as an isolated sub-agent invoked by the engineer or an orchestrator.

---

## TR-6 — Severity labels, rule IDs, and grouped report format

Each finding must include a severity label, the rule ID from the standard, and the
source standard in parentheses. Findings are grouped by contract section and endpoint.

**Acceptance Criteria:**
- Every finding has a severity label: `[REQUIRED]` or `[SUGGESTION]`.
- Every finding includes the rule ID (e.g., `R-2 (contracts)`, `R-1 (security)`).
- Findings are grouped: contract-level checks first, then per-endpoint with path+method
  as a sub-heading.
- The report ends with a summary: `**Summary:** N REQUIRED, M SUGGESTION`.
- The report header identifies the policy source for each standard.

---

## TR-7 — Load enforcement policies with three-level fallback

For each standard file (contracts, protocol, security), the skill must resolve an
enforcement policy using this fallback order, stopping at the first file found:

1. `.forge/deployables/<deployable_id>/policies/api/rest/<file>.policy.md`
2. `.forge/policies/api/rest/<file>.policy.md`
3. `../../standards/api/rest/<file>.policy.md` (plugin default, relative to skill file)

Each standard's policy is resolved independently. If `<deployable_id>` is not available
from the effort's `.state.json`, level 1 is skipped.

**Acceptance Criteria:**
- A deployable-level policy file takes precedence over both project-level and plugin default.
- A project-level policy file takes precedence over the plugin default.
- Overriding one standard's policy does not affect the others.
- If no policy file is found at any level, all rules for that standard are treated as blocking.

---

## TR-8 — Policy-driven severity

The skill must derive finding severity from the loaded policy table, not from hardcoded
labels in the skill instructions. The policy table maps rule IDs to `blocking` or
`advisory`:

- `blocking` → report as `[REQUIRED]`
- `advisory` → report as `[SUGGESTION]`

Rules not present in the policy table default to `blocking`. Where the policy entry
includes a non-empty `Notes` field, the note is appended to the finding.

**Acceptance Criteria:**
- Changing a rule's severity in a policy file changes how the skill labels it without
  requiring a SKILL.md update.
- Policy notes appear in findings where non-empty.
- A rule absent from the policy is treated as blocking.

---

## TR-9 — Report policy source in header

The report header must identify which policy source (plugin default, project override,
or deployable override) was applied for each standard, so engineers know what
enforcement posture they are being evaluated against.

**Acceptance Criteria:**
- The report header includes a `**Policy:**` line summarising the source per standard.
- The footer includes a per-standard policy source breakdown when sources differ.
