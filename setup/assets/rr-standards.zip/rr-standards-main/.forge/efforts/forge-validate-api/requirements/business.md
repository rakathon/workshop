# Business Requirements — forge:validate-api

## Context

During `forge:spec-api`, engineers author OpenAPI YAML contracts iteratively.
Without targeted, immediate feedback, standards violations accumulate across multiple
design sessions and are expensive to fix in batch at the end of discovery. A targeted
API validator closes this feedback loop at the point of authoring.

---

## BR-1 — Immediate inline standards feedback during API authoring

**Description:** When engineers author an OpenAPI YAML contract during `forge:spec-api`,
they need immediate inline feedback on whether the contract complies with the
organization's REST standards — without waiting until the full `forge:validate` run at
the end of discovery.

Without targeted API validation, standards violations accumulate over multiple design
sessions and are expensive to fix in batch. Feedback must be driven by the authoritative
standard files, not hardcoded rules, so that it stays accurate as standards evolve.

**Acceptance Criteria:**
- Running `forge:validate-api` during or after `forge:spec-api` surfaces standards
  violations within the current session before the engineer moves on.
- The validator reads and applies the rules from the live standard files
  (`contracts.md`, `protocol.md`, `security.md`) rather than embedding them inline.
- Rules present in the loaded standards but not explicitly listed in the skill are
  still checked and reported.
- Feedback is available without leaving the Claude Code session.

---

## BR-2 — Editing aid, not a gate artifact

**Description:** The targeted API validator must not write a gate artifact or update any
state. It is an editing aid used during authoring, not a phase gate. Only `forge:validate`
owns `validation/report.md`.

**Acceptance Criteria:**
- Running `forge:validate-api` does not modify `validation/report.md`.
- Running `forge:validate-api` does not modify `.state.json`.
- Multiple invocations produce no file system side effects.
- `forge:validate-api` output is ephemeral session output only.

---

## BR-3 — Actionable report, no context switch required

**Description:** The inline report must be actionable immediately in the session where
the engineer is working, without requiring them to context-switch to a different tool
or file.

**Acceptance Criteria:**
- Each finding includes a severity label (REQUIRED or SUGGESTION), a rule ID, and the
  source standard so the engineer can cross-reference directly.
- Findings are grouped by endpoint so the engineer can act on one endpoint at a time.
- The report includes a summary line (N REQUIRED, M SUGGESTION) so the engineer can
  gauge overall compliance at a glance.
- When no API spec is found, the skill reports a clear, actionable message rather than
  failing silently.

---

## BR-4 — Teams must be able to customize enforcement severity without forking the plugin

**Description:** The organization's plugin ships default enforcement policies that define
which rule violations block promotion and which are advisory. Individual projects and
deployables must be able to override these defaults to reflect their specific compliance
posture — for example, treating a normally advisory rule as blocking for a high-risk
payments API, or relaxing a blocking rule during a migration window — without modifying
the plugin itself.

Overrides must be narrowly scoped: a team should be able to change the policy for one
standard (e.g., `contracts`) without touching the policies for others (e.g., `security`).

**Acceptance Criteria:**
- A project-level policy override in `.forge/policies/api/rest/` is applied instead of
  the plugin default when present.
- A deployable-level policy override in `.forge/deployables/<id>/policies/api/rest/` is
  applied instead of the project-level or plugin default when present.
- Each standard's policy is resolved independently; overriding one does not affect others.
- The report header identifies which policy source was applied for each standard
  (plugin default, project override, or deployable override).
- If no policy file exists at any level, all rules are treated as blocking.
