# Implementation Plan: forge:validate-api

## Wave 1 — Skill Implementation

- [x] [auto][wave:1] Author `forge:validate-api` SKILL.md + create `forge-validate-api` capability directory (TASK-001) — e52657a
