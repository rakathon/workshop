# ADR-001 — Policy-Driven Enforcement Severity for Validation Skills

**Status:** Accepted
**Effort:** forge-validate-api
**Date:** 2026-04-13
**Authors:** rr-benjamin.vogan

---

## Context

The `forge:validate-api` skill (and by extension the other targeted validators:
`forge:validate-storage`, `forge:validate-messaging`, `forge:validate-tests`) checks
API contracts against the organizational REST standards and produces findings. Each
finding must carry a severity so engineers know whether to fix it before promoting or
treat it as optional guidance.

Two approaches were considered for determining severity:

**Option A — Hardcode severity in the SKILL.md.**
The skill lists each check inline with a fixed `[REQUIRED]` or `[SUGGESTION]` label.
Simple to author. No additional files to load.

**Option B — Load severity from companion policy files.**
Each standard file (`contracts.md`, `protocol.md`, `security.md`) has a companion
`.policy.md` that maps rule IDs to `blocking` or `advisory`. The skill reads the
policy at runtime and derives the label from it.

The initial implementation used Option A. During review it was identified that this
approach had two significant problems:

1. **Drift:** If the standard is updated (a rule added or its severity changed), the
   SKILL.md must also be updated manually. There is no mechanism to detect or prevent
   the drift.

2. **No team customisation:** Some teams (e.g., payments, PII-handling services) need
   stricter enforcement than the organizational default. Others (e.g., during a
   migration window) may need to temporarily relax a blocking rule. With hardcoded
   severity, the only way to change enforcement is to modify the plugin — which affects
   all teams simultaneously.

The companion policy files (`contracts.policy.md`, `protocol.policy.md`,
`security.policy.md`) already existed as part of the rr-standards enforcement policy
framework. They were not being used by the validation skills.

---

## Decision

**Adopt Option B.** Validation skills load companion policy files at runtime and derive
finding severity from the policy table. The policy files — not the skill instructions —
are the authoritative source of enforcement severity.

**Fallback resolution order** (per standard file, independently):
1. `.forge/deployables/<deployable_id>/policies/api/rest/<file>.policy.md` — deployable override
2. `.forge/policies/api/rest/<file>.policy.md` — project-wide override
3. `../../standards/api/rest/<file>.policy.md` — plugin default (relative to skill file)

The skill stops at the first file found for each standard. Overriding one standard's
policy does not affect others.

**Severity mapping:**
- `blocking` in policy → `[REQUIRED]` in the finding
- `advisory` in policy → `[SUGGESTION]` in the finding
- Rule absent from the policy → treated as `blocking`

**Report transparency:** The report header identifies which policy source was applied
for each standard so engineers always know what enforcement posture they are being
evaluated against.

---

## Alternatives Considered

**Option A — Hardcoded severity in SKILL.md**

Rejected because:
- Severity cannot be customised without modifying the plugin, which affects all teams.
- Drift between the standard and the skill is silent and undetectable.
- Rules added to a standard are invisible to the skill until it is manually updated.

**Embedding severity directly in the standard files**

Rejected because standards define *what* is required, not *how strictly* it is enforced
in any given context. Mixing enforcement policy into the standard file would make it
impossible for teams to override severity without forking the standard itself.

**Single project-level policy (no deployable-level)**

Considered but rejected. A monorepo may contain services with materially different risk
profiles (e.g., a public member-data API and an internal admin tooling API). A single
project-level policy cannot express both. The deployable-level override provides the
necessary granularity without requiring separate repositories.

---

## Consequences

**Positive:**
- Severity stays accurate as standards evolve — no manual SKILL.md updates required for
  rule severity changes.
- Teams can tighten or relax enforcement for their specific context without touching the
  plugin.
- The policy source is transparent in every report, making enforcement auditable.
- The same pattern is applicable to `forge:validate-storage`, `forge:validate-messaging`,
  and `forge:validate-tests` without redesign.

**Negative / trade-offs:**
- The skill performs additional file reads at startup (one policy file per standard).
  For typical usage this is negligible.
- Teams who want to customize enforcement must create and maintain policy override files.
  The plugin default applies if they do not.
- Policy files must follow the same table format as the plugin defaults. No schema
  validation is currently enforced on override files — a malformed override silently
  falls through to the next level.

**Follow-on work:**
- `forge:validate-storage`, `forge:validate-messaging`, and `forge:validate-tests`
  should adopt the same policy resolution pattern (tracked as part of their respective
  implementation tasks).
- Consider adding a `forge:check-policy` diagnostic skill that validates override files
  against the expected table format.
