# Implementation Plan: forge:validate

## Wave 1 — Skill Implementation

- [x] [auto][wave:1] Author `forge:validate` SKILL.md + create `forge-validate` capability directory (TASK-001) — c1951c3
