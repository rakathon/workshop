# Implementation Plan: forge:validate-storage

## Wave 1

- [x] [auto][wave:1] Author `forge:validate-storage` SKILL.md + create `forge-validate-storage` capability directory (TASK-001) — bb9544b
