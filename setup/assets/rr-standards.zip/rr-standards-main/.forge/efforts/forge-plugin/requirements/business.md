# Business Requirements

### BR-1: Reduce Total Cycle Time Without Degrading Quality

The time from product requirements delivery to production deployment must decrease.
This reduction must not come at the cost of defect rates, security posture, or privacy
compliance. The process must be faster at every stage, not just the coding stage.

### BR-2: Enforce Requirements Fidelity Before Design Begins

Product requirement documents frequently describe proposed solutions rather than the
underlying business need. Engineering teams must be able to extract and validate the
true business requirements — what problem is being solved for whom — before committing
to any technical approach. Designing against a prescribed solution rather than a real
need is a primary cause of rework.

### BR-3: Ensure Designs Are Complete and Validated Before Implementation Begins

Technical designs (APIs, data schemas, message contracts, architecture decisions) must
be validated against the stated requirements for completeness and correctness before
coding begins. Given that code generation is now fast, the relative cost of discovering
a design flaw during implementation has increased. Design must be treated as the
highest-leverage phase for quality investment.

### BR-4: Enforce Organizational Standards Automatically, Not Through Human Review

Compliance with coding standards, security policies, and privacy policies must be
verified mechanically on every pull request. This verification must produce an AI
approval or request-for-changes signal before human reviewers see the PR. Human
reviewers should not be the primary mechanism for catching standards violations —
they should focus on logic, architecture, and judgment.

For high-risk changes (authentication, payments, PII, core capabilities), AI approval is
one required signal. A human reviewer must also approve before merge is permitted.
For lower-risk changes, AI approval is sufficient. Developers always decide when to
merge. The approval policy is defined by the Productivity Engineering quality group
and enforced mechanically via branch protection rules.

### BR-5: Identify and Manage Risk Continuously

The appropriate level of rigor — in design, review, testing, and deployment — must be
proportional to the risk of the work. Risk is assessed continuously as work moves through
the process: an initial classification is made at the start, but it is revisited as
discovery reveals new information, as design surfaces security or privacy implications,
and as implementation uncovers complexity that was not initially apparent. A risk
classification can be escalated at any phase; it is never locked. High-risk work
(authentication, payments, PII handling, data migrations) must trigger deeper scrutiny
at every phase. Low-risk work must not be burdened with unnecessary process overhead.

### BR-6: Maintain Full Traceability from Business Requirement to Production Code

Every implementation artifact — design decisions, code, tests, deployment
configurations — must be traceable to the business requirement it serves. This
supports debugging, compliance auditing, change impact analysis, and onboarding of
new engineers. Traceability must be machine-navigable, not dependent on commit message
discipline.

### BR-7: Integrate with Existing Project Management Tooling

The development process must not create a parallel tracking system. Work must flow
into and out of Jira (the organization's existing system of record). Engineers must
not be required to manually synchronize state between tools.

### BR-8: Ensure Operational Readiness Is Part of the Definition of Done

A capability is not complete when code is merged. Runbooks, monitoring, and alerting
configurations are required artifacts for production readiness. The process must
produce these artifacts as a standard output of development, not as an afterthought.

### BR-9: Enable Fast Diagnosis and Response to Production Incidents

When production issues occur, AI agents must be able to diagnose root cause quickly
using existing monitoring infrastructure (DataDog) and execute runbooks to remediate
known issues automatically, raising only unrecognized patterns to engineers. The
process must produce the operational context (runbooks, deployment history, service
maps) needed to support this before a capability ships.

### BR-10: Be Consistent and Repeatable Across Teams and Technologies

The process must produce consistent outputs regardless of which team, technology
stack, or individual engineer is involved. A new repository should start with correct
standards, tooling, and structure already in place. Onboarding must not require deep
familiarity with the tooling or the history of the codebase.

### BR-11: Maintain Consistent Agent Output Quality Regardless of Session Length

AI agent output quality degrades as context fills during a session. This degradation
is silent — there is no signal to the engineer that the quality of generated code,
designs, or reviews has decreased. The process must prevent quality from degrading as
sessions grow long or as the scope of work within a session expands. This applies to
both interactive engineer sessions and automated CI/CD pipeline sessions.

### BR-12: AI Agent Autonomy Must Have Defined, Enforceable Boundaries

Engineers must be able to trust that AI agents will act autonomously within defined
boundaries and escalate appropriately outside those boundaries. Unexpected autonomous
actions erode trust. Unexpected pauses for routine, recoverable decisions erode
adoption. Every agent that executes work on behalf of an engineer must have explicit,
documented rules governing what it can do without asking and what requires engineer
decision.

Specifically: agents must escalate to the engineer for any deviation that requires
modifying an approved design artifact (API contract, schema, test strategy). Fixing a
bug or adding missing error handling does not require escalation. Changing the storage
model or adding a new external dependency does.

### BR-13: Implementation Must Be Verified Against Stated Goals, Not Just Task Completion

Task completion is an unreliable proxy for goal delivery. Tasks can be marked complete
with stub implementations, missing integration wiring, or code that satisfies the
literal task description but not the underlying requirement. The process must verify
that the implementation actually delivers the phase goal before the work moves to
review or QA. This verification must be distinct from test execution — it is a
semantic check against requirements and design artifacts, not a test runner output.

### BR-14: The Framework Tooling Itself Must Be Testable and Maintain Quality Over Time

The hooks, skills, and validation logic that form the framework are themselves software
artifacts. A hook that fails silently undermines the governance model it enforces. A
skill that produces incorrect output degrades every engineer who uses it. The framework
must have automated tests for its critical deployables — particularly the phase gate
hooks, the generation standards injection hook, and the standard validation logic.
The framework must have a mechanism for engineers to know when their installed version
is out of date and what has changed.

### BR-15: Framework Adoption is Mandatory for All Development

Forge is not optional. Because Forge enforces organizational coding standards, security
policy, and privacy policy, using it is a condition of those standards being met — not
a recommendation. Every piece of development work, regardless of team, platform, or
size, must flow through the appropriate tier of the framework.

"Mandatory" does not mean uniform ceremony. The lightweight tier (story/task work)
exists specifically so that PoCs, small bug fixes, and low-risk changes do not carry
initiative-level overhead. But lightweight-tier work is still Forge work: at minimum,
PR review (forge:review) runs on every PR, and the relevant standards are active at
generation time. No team may opt out of standards enforcement on the grounds that their
work is too small or experimental.

The mandate is organizational, defined by Productivity Engineering, and enforced
mechanically — not by asking teams to self-report compliance. Brownfield repositories
must be onboarded, not exempted. New repositories must start with Forge initialized.

### BR-16: Framework Version Currency Must Be Maintained with Controlled Rollout

All developers must be on a current version of the framework. An outdated installation
may be missing standards, security policies, or hooks that the current version requires —
allowing stale versions in production use undermines the consistency guarantees the
framework exists to provide.

However, updates cannot be imposed simultaneously on everyone. A developer in the middle
of active implementation who is forced to upgrade faces changed behavior, broken tooling,
and disrupted in-flight work. The rollout mechanism must:

- Distinguish breaking from non-breaking updates. Breaking changes alter skill behavior
  or hook exit codes. Non-breaking changes add new standards, new skills, or
  documentation. These carry different adoption urgency.
- Protect developers with active in-progress work from forced mid-task upgrades. A
  developer currently implementing a task should not be required to upgrade until the
  current task or phase reaches a natural stopping point.
- Define a maximum acceptable lag period, after which the update becomes mandatory even
  for developers who have not voluntarily adopted it. The lag period is set by
  Productivity Engineering and may differ for breaking versus non-breaking changes.
- Always initialize new projects on the latest version.
- Emit a visible, non-blocking notice when an update is available so developers can
  adopt early if they choose.

The rollout mechanism must be operable by Productivity Engineering without requiring
all developers to take simultaneous manual action.

### BR-17: Framework Must Remain Functional When AI Services Are Unavailable

The framework must not leave development workflows in an undefined or silent failure
state when AI services are temporarily unreachable. `forge:review` is a blocking status
check on every PR; an AI service outage that produces no response is operationally
equivalent to a service that has gone down across all teams simultaneously. This is an
unacceptable single point of failure if the degraded behavior is not explicitly designed.

Every framework capability that depends on an AI service must have a defined degraded-mode
behavior. The behavior must be:
- **Explicit**: engineers can distinguish an AI service outage from a legitimate review
  failure or a rejected PR
- **Consistent**: the same degraded behavior applies regardless of which team, PR, or
  engineer is affected — no team receives preferential availability
- **Documented**: the degraded behavior is part of the framework specification, not a
  side effect of implementation

The specific degraded behavior for each capability (block with diagnostic error, require
manual Productivity Engineering override, auto-pass with a logged warning) is a decision
to be made per capability. This requirement mandates that the decision be made and
documented, not what the decision must be.

### BR-18: AI Agent Decisions Must Be Auditable

Decisions made by AI agents that affect PR merge eligibility, rollout progression, or
incident response are consequential, organization-affecting events — not transient outputs
to be displayed and discarded. An AI agent that blocks a R2 PR has made a decision that
may be disputed by the engineer, reviewed by a compliance function, or need to be debugged
when the framework produces incorrect outputs. The rationale for that decision — which
standards were applied, which findings were identified, what evidence supported the
conclusion — must be persisted with sufficient context to support:

- **Dispute resolution**: an engineer contesting an AI blocking decision must be able to
  see the full reasoning, not just the outcome
- **Compliance audit**: regulated functions must be able to demonstrate what checks were
  applied and when, for a defined retention period
- **Framework debugging**: incorrect AI decisions (false positives, missed violations)
  must be investigable after the fact without depending on session history

Displaying structured output in a session satisfies none of these needs. The audit record
must be a persisted artifact, associated with the specific event (PR number, deployment
ID, incident ID), and queryable independently of the session that produced it.

### BR-19: Changes to Organizational Standards Must Follow a Governed Process

A change to an organizational standard is not equivalent to a code change. Standards
changes affect every team and every project simultaneously — without any team explicitly
deciding to adopt the change. A poorly reviewed security standard update could invalidate
compliant code across the entire organization, conflict with existing architectural
decisions, or introduce requirements that are infeasible for some platforms.

The process for proposing, reviewing, and publishing changes to standards must be
explicitly defined and distinct from the standards themselves and from the version rollout
mechanism (BR-16). At minimum, the process must define:
- Who may propose a change and in what form
- What cross-team impact assessment is required before approval
- Who has the authority to approve publication, and what quorum or review is required
- What notice period applies before a change becomes effective for consuming projects
- How breaking changes (changes that would require code modifications in compliant
  projects) are distinguished from non-breaking additions

Unilateral standards changes — by any individual, team, or tool — are not permitted.

### BR-20: Framework Tooling Must Not Add Overhead Beyond What Validations Require

The validations the framework performs — security checks, privacy review, standards
compliance, design validation — are organizational requirements. They were always
required; they were not being done. The friction of performing them is inherent and
intentional. This requirement does not ask the framework to make required validations
feel costless.

What this requirement does address is tooling overhead — friction introduced by the
framework itself, on top of the validations it performs:
- Engineers should not need to understand the framework's internal structure to complete
  routine work; skill invocation and hook behavior must handle complexity invisibly
- The framework must not require ceremony around itself: configuration steps, invocation
  sequences, or state management that consumes engineer attention without contributing
  to a validation or artifact
- When a gate blocks progress, the reason must be clear and actionable; a blocked
  engineer must know exactly what is required of them, not just that something is wrong
- Outputs produced by the framework (review reports, validation findings, verification
  results) must be immediately usable — engineers must not need to re-verify or
  reinterpret them before acting

The test is not "is this less work than doing nothing?" — doing nothing was never an
option. The test is: **does the framework make required validations easier to perform
correctly than performing them manually would be?** If engineers find the framework
harder to use than doing the equivalent work by hand, the tooling has failed its purpose.

### BR-21: A Formal Exception and Waiver Process Must Exist

BR-15 establishes that framework adoption is mandatory. In practice, enterprise
environments encounter situations where the standard process cannot apply within the
required timeframe: an acquired codebase during integration, a regulated environment
with tooling constraints that are incompatible with Forge, an emergency patch requiring
immediate production access when the standard gate sequence would introduce unacceptable
delay.

The absence of a defined waiver process does not prevent exceptions from occurring. It
makes them informal, invisible, and unauditable — which is strictly worse than a governed
process. A formal exception process must exist and must:
- Require explicit approval from Productivity Engineering for any deviation
- Specify the scope of the deviation: which requirements are waived, for which project
  or repository, and for which time-bounded period
- Produce a logged audit record associated with the approving authority and the stated
  justification
- Have a defined expiry that requires renewal or escalation to a permanent process change;
  waivers that are never revisited are de facto permanent opt-outs

A waiver is not an opt-out. It is a managed, visible deviation from a requirement that
the organization has committed to — one that Productivity Engineering can see, track, and
close when the underlying condition no longer applies.

### BR-22: Framework Must Be Compatible with Multiple AI Coding Agents Where Possible

Forge's skills, hooks, and standards conventions must be designed to work across multiple
AI coding agents — including Claude Code, GitHub Copilot, Codex, and Cursor — wherever
this is achievable without compromising capability. Locking the framework to a single
vendor creates an organizational dependency and limits adoption by teams whose toolchain
includes other agents.

Where standards and conventions are platform-neutral (e.g., AGENTS.md navigation files,
standard document structure, enforcement policies), they must use the most broadly
supported convention available. Where capabilities are necessarily platform-specific
(e.g., Claude Code PreToolUse hooks for injection, SKILL.md for skill registration),
this is acceptable for v1, but the design must document the platform dependency and
identify the migration path if a future cross-platform abstraction becomes available.

v1 is Claude Code-primary. All skills, hooks, and workflows are built for Claude Code.
Cross-platform compatibility is a design constraint on conventions and artifact formats,
not a requirement to implement multi-platform execution in v1.

---

Success criteria: [success-criteria.md](success-criteria.md)

---

## Scope Decisions

The following questions were raised during requirements analysis and have been resolved.
Architectural decisions (mechanism choices, technology selections) are recorded as ADRs
in `.forge/spec/arch-decisions/`.

1. **Platform scope**
   - **Decision:** All platforms are in scope: mobile (iOS, Android), web front-end,
     backend services, data engineering, and data science. Platform-specific skills will
     be built incrementally through workshops run with each engineering group, rather
     than all at once. Participation in the workshop that produces a standard is how
     engineers become code owners for that standard.

2. **PR review approval policy**
   - **Decision:** AI approval is one required signal on every PR. It is not the only
     gate. For R1 and R2 changes, a human reviewer must also approve before merge is
     permitted. For R3 and R4 changes, AI approval is sufficient. Developers always
     decide when to merge. The approval policy is defined by the Productivity Engineering
     quality group and implemented by Platform Services via branch protection rules and
     CODEOWNERS configuration. Policy changes do not require changes to skills or hooks.
