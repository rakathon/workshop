# Technical Requirements

## Development Process Phases

The following describes the complete development lifecycle from PM handoff to
production operation. For each phase, the expected inputs and outputs are defined,
the primary failure modes are identified, and the opportunities for AI agent
involvement are described.

Phases 1 and 2 (Discovery and Validation) apply to full-tier workflows (programs,
initiatives, and epics) and are optional for story/task work. All remaining phases apply
universally.

---

### Phase 1: Discovery

**Input:** PM-provided product document (PRD, Jira epic, user story, or equivalent);
existing system context
**Output:** Business requirements, technical requirements, API contracts, storage
schemas, message contracts, test strategy, risk classification, architecture
decisions, open questions list

**How this phase works:**
Discovery is not a linear sequence of requirements-then-design. Requirements and
design activities are interleaved: drafting an API contract reveals a requirement that
was not in the PM document; designing a storage schema reveals that two requirements
conflict; identifying a security implication during design reshapes the business
requirement it stems from. This is expected and productive. The goal is not to
complete requirements before touching design — it is to arrive at a set of
requirements and designs that are mutually coherent and complete enough to implement
against.

The phase is complete when: the PM document has been interrogated for true business
needs (not just prescribed solutions), the technical implications have been elaborated,
the primary designs are drafted and internally consistent, and there are no open
questions that would require re-doing significant design work.

Engineer implementation decisions made during discovery — choices about approach,
libraries, patterns — must be captured explicitly and honored during implementation.
These are not suggestions for the implementing agent to reconsider; they are locked
decisions.

**Primary failure modes:**
- PM document treated as requirements rather than as input to the discovery process
- Requirements discovered during design work are not captured back into the
  requirements artifact, creating silent inconsistency
- Requirements and design are approved at different times and end up inconsistent
- Implicit requirements (security, privacy, compliance, accessibility) are not
  surfaced until implementation or review, where they are expensive to address
- The team begins implementation before requirements and design are mutually coherent

**Where AI agents add value:**
- Decompose PM documents into discrete, independently testable business requirements;
  distinguish prescribed implementations from underlying needs
- Identify implicit requirements (security, privacy, compliance, accessibility) based
  on the nature of the capability and data it handles
- Produce an initial risk classification (R1–R4) to calibrate the depth of discovery
- Translate business requirements into technical requirements: NFRs, integration
  constraints, security and privacy implications, scalability targets
- Identify integration points with existing systems and flag conflicts between
  requirements and known technical constraints
- Generate initial API contract drafts conforming to REST standards
- Generate storage schema proposals appropriate to the described access patterns
- Generate message contract proposals conforming to messaging standards
- Cross-check designs against each other for consistency
- Identify security and privacy risks in proposed designs
- Record architecture decisions with rationale, alternatives considered, and the
  requirement each decision serves
- Surface gaps and generate clarifying questions when design work reveals ambiguity

---

### Phase 2: Design Validation

**Input:** Discovery artifacts (requirements and designs); risk classification
**Output:** Validation report with pass/fail per check, required revisions, and
informational suggestions

**Primary failure modes:**
- Designs approved without verifying every stated requirement is addressed
- Test strategy does not cover the failure scenarios most likely in production
- Validation catches style issues but misses semantic gaps between requirements and design
- Security and privacy issues in the design are not caught before implementation begins

**Where AI agents add value:**
- Cross-reference each business and technical requirement against the designs; flag
  requirements with no corresponding design coverage
- Cross-reference the test strategy against requirements and design to identify
  untested paths and missing edge cases
- Validate API designs against organizational REST standards
- Validate storage schemas against organizational data modeling standards
- Validate message contracts against organizational messaging standards
- Produce a prioritized gap report: required changes (block approval) and suggestions
  (informational)

---

### Phase 3: Implementation Planning

**Input:** Validated discovery artifacts, risk classification
**Output:** Ordered, dependency-mapped implementation tasks annotated with type and
wave; corresponding Jira tickets

**Primary failure modes:**
- Tasks defined without dependencies, causing blocked work mid-sprint
- Cross-cutting concerns (auth, logging, error handling, tests) omitted as explicit tasks
- Plans created in isolation from Jira, requiring manual re-entry
- Plans become stale and are not maintained as implementation progresses
- Independent tasks executed sequentially when they could proceed in parallel

**Where AI agents add value:**
- Generate implementation tasks from validated designs, including cross-cutting
  concerns as explicit tasks (not assumptions)
- Identify task dependencies and express them as explicit ordering constraints
- Annotate tasks with execution type (autonomous, checkpoint requiring human
  decision, checkpoint requiring human action, TDD discipline)
- Group tasks into dependency waves to enable parallel execution of independent work
- Synchronize the plan with Jira
- Update the plan as implementation progresses, recording commit SHAs at task
  completion

---

### Phase 4: Implementation

**Input:** Validated discovery artifacts, implementation plan, organizational coding
standards, codebase context (brownfield projects)
**Output:** Working code, tests (unit, integration, end-to-end), pull requests

**How this phase works for brownfield projects:**
Before implementing against an existing codebase, the agent must understand the
current system — its technology stack, architectural patterns, naming conventions,
existing integrations, and areas of known concern. Without this context, organizational
standards are applied without regard for the existing patterns, producing code that
is standards-compliant but inconsistent with the codebase. A codebase analysis must
be available as reference material before implementation begins on any brownfield
project.

**Primary failure modes:**
- Code does not match the agreed design
- Coding standards not followed consistently
- Test coverage insufficient or tests validate implementation rather than requirements
- Security and privacy vulnerabilities introduced during coding
- Agent deviates from the design to address an unexpected issue without escalating,
  producing implementation that silently diverges from approved artifacts
- Agent interrupts the engineer for trivial recoverable issues that it could and
  should handle autonomously

**Where AI agents add value:**
- Analyze existing codebases to produce structured documentation of stack, patterns,
  conventions, integrations, and concerns — used as reference context for all
  subsequent implementation work on that project
- Scaffold new projects and modules with correct structure, dependencies, and
  configuration
- Implement capabilities against the validated design, honoring locked engineer decisions
- Write unit and integration tests against the agreed test strategy
- Write end-to-end tests for critical user journeys
- Enforce coding standards at generation time (not just after the fact) by loading
  standards as context before writing any source file
- Create well-structured commits with structured metadata for traceability
- Apply deviation rules: autonomously fix bugs and add missing error handling;
  escalate to the engineer for any deviation that requires modifying an approved
  design artifact

**Note:** Code generation speed is already fast. The primary opportunity in this phase
is quality, standards adherence, and traceability — not raw speed.

---

### Phase 4.5: Implementation Verification

**Input:** Completed implementation (code + commits), validated design artifacts,
implementation plan with task completion record
**Output:** Verification report: goal delivery confirmation or specific gaps identified

**Why this phase exists:**
Task completion is not goal delivery. An agent that marks all tasks complete has not
necessarily delivered the intended behavior — it may have produced stubs, missed
integration wiring, or satisfied the letter of the task without its intent. This
verification step checks semantic goal delivery before the work moves to review or
QA, catching gaps when they are cheapest to fix.

**Primary failure modes:**
- Stubs accepted as implementations (compile, pass unit tests, fail in practice)
- Missing wiring between deployables (each piece works, but they're not connected)
- Implementation satisfies task description but not the underlying requirement

**Where AI agents add value:**
- Read validated design artifacts and the implementation task list with commit SHAs
- Verify that the implementation delivers the stated phase goal, not just that tasks
  are marked complete
- Identify stubs, orphaned code, and missing integration points
- Produce a structured report that distinguishes confirmed delivery from gaps, with
  specific locations in the code for each gap found

---

### Phase 5: Code Review and Compliance Verification

**Input:** Pull requests
**Output:** AI approval or request-for-changes with structured findings; risk
classification; human reviewer approval (required for R1/R2)

**Approval model:**
AI approval is one required signal on every PR. The approval policy is tiered by risk:
- R1/R2 (auth, payments, PII, core capabilities): AI approval + human reviewer approval required
- R3/R4 (new capabilities, minor changes): AI approval sufficient

A human must merge the PR — the AI provides a review signal, it does not merge.
The merge policy is defined by the Productivity Engineering quality group and enforced
via branch protection rules. Merging triggers the pre-production deployment that QA
runs against.

**Primary failure modes:**
- Human reviewers are a throughput bottleneck
- Standards compliance checked inconsistently across reviewers
- Security and privacy issues missed under time pressure
- PRs not validated against original requirements — code is correct but solves the
  wrong problem
- Large PRs reviewed at reduced quality due to context limitations

**Where AI agents add value:**
- Automatically verify coding standards compliance before human review begins
- Evaluate security policy adherence (OWASP, organizational security standards)
- Evaluate privacy policy adherence (data handling, PII exposure, consent)
- Validate that the implementation matches the agreed design
- Validate that the implementation traces back to the stated requirements
- Assign a risk level to the PR with explicit rationale so human reviewers can
  calibrate their attention accordingly
- For large PRs: partition by file group and review in parallel, aggregating findings
  into a unified report — review quality must not degrade with diff size

---

### Phase 6: QA and Validation

**Input:** Deployed code in a pre-production environment, test plans, requirements
**Output:** QA sign-off or a prioritized list of defects with requirement traceability

**Primary failure modes:**
- Test coverage determined by what testers think to test, not what requirements require
- Defects reported without traceability to requirements, making prioritization difficult
- Regression coverage decays as the test suite does not keep pace with the product

**Where AI agents add value:**
- Execute test plans against the deployed pre-production environment
- Map discovered defects back to the requirement they violate
- Identify requirements that have no corresponding test coverage
- Generate regression test cases from defects to prevent recurrence

---

### Human Gate: Production Deploy Approval

A human must explicitly approve production deployment after QA sign-off. The engineer
or release manager reviews the QA sign-off document, accepts any remaining open defects,
and initiates the deployment. This approval is the trigger for Phase 7 — the rollout
monitor does not start until a human has made this decision.

---

### Phase 7: Deployment and Rollout

**Input:** QA sign-off and human production deploy approval
**Output:** Code running in production; rollout decision log

**Primary failure modes:**
- Canary deployments inadequately monitored; degraded signals missed
- Rollback decisions delayed because humans must manually evaluate metrics
- Progressive rollout stages proceed on schedule rather than on signal

**Where AI agents add value:**
- Monitor canary metrics and error rates continuously during staged rollouts
- Recommend proceed or rollback based on observed signals and configurable thresholds
- Produce a rollout decision log for audit and post-mortem purposes

---

### Phase 8: Production Operations

**Input:** Production monitoring data (logs, metrics, traces), runbooks, deployment
history
**Output:** Diagnosed incidents, remediation actions, post-mortem material

**Primary failure modes:**
- Incident diagnosis is slow because engineers manually correlate logs, metrics, and
  deployments without structured guidance
- Runbooks out of date or nonexistent for new capabilities
- The same incident types recur because learning is not captured

**Where AI agents add value:**
- Analyze production logs and metrics to identify root cause and correlate with recent
  deployments or configuration changes
- Execute runbook steps in response to known incident patterns
- Flag when an incident does not match any known pattern and requires human escalation
- Generate post-mortem material from the incident timeline

---

## Implementation Requirements

The following describes the capabilities that must exist to realize the agent
opportunities above. These are organized by category, not by priority.

### 1. Workflow Infrastructure

- A tiered workflow model: full workflow for initiatives and epics (all phases, all
  artifacts); lightweight workflow for stories and tasks (implementation and validation
  only, no upstream design artifacts required). Validation capabilities (standards,
  security, privacy) apply at all tiers regardless.
- Workflow state that tracks the current phase, tier, artifacts produced, decisions
  made, open questions, and the current position within an interrupted operation so
  that interrupted work can be resumed without starting over.
- An explicit session pause and resume capability: engineers must be able to stop
  mid-task and create a structured handoff that preserves current position and active
  context for the next session — whether that is the same engineer or a colleague.
- A repository initialization capability that creates a correct CLAUDE.md, project
  structure, and standards references for a new codebase, and that merges gracefully
  into an existing CLAUDE.md without overwriting existing content. The generated or
  updated CLAUDE.md must include an explicit instruction to read AGENTS.md files when
  navigating standards or language guides — Claude Code does not load AGENTS.md
  automatically, and without this instruction agents working outside a forge: skill
  will not get standards navigation context.
- A master work registry (a single file at the repository level) that gives engineers
  and agents an at-a-glance view of all in-flight work without traversing directories.
- Work items may be organized into a hierarchy: programs contain initiatives, initiatives
  contain epics, epics contain stories. When initializing a new work item, the engineer
  may specify a parent work item ID. The initialization capability must: record `parentId`
  in the new item's `.state.json`; add the new item's ID to the parent's `childIds` array;
  and update the master registry to display the new item indented beneath its parent.
  Omitting a parent is valid — top-level work items have `parentId: null`.
- All artifact files have a target maximum of 500 lines. Any single-file artifact
  (`<name>.md`) may be expanded to a same-named directory (`<name>/`) when it approaches
  this limit. The directory form must contain a `README.md` as the index and entry point,
  with content split into logical subdocuments. All skills that read or write these
  artifacts must handle both the file form and the directory form transparently. The
  decision to expand is made at authoring time by the generating skill or engineer.
- A spike work item type for time-boxed investigation. Spikes follow a two-phase
  lightweight workflow — investigation followed by findings review — and produce
  `findings/findings.md` as their primary artifact in place of the standard
  requirements/spec/plan structure. Spike code is exploratory and not production-bound;
  a spike may produce prototype or proof-of-concept code as part of the investigation
  (comparing approaches, going far enough down an implementation path to produce a
  confident estimate). PR review is optional for spike code, not required. A spike must
  record a `timebox` deadline in its state at initialization; a spike whose timebox has
  passed without approved findings is overdue and must be flagged at session start.
  Implementation verification, QA, and runbook phases do not apply. A spike may spawn
  child work items (epics or stories) recorded in its findings phase state under
  `spawnedWorkItems`.
- Jira integration with the repository as source of truth: as work progresses, the
  corresponding Jira ticket is updated to reflect current state. A Jira ticket can
  initialize a workflow. Conflict detection is required when a Jira ticket has been
  manually modified in a way that diverges from repository state.

### 2. Discovery Phase Capabilities

Requirements and design capabilities are part of a unified discovery toolset. They
may be invoked in any order and are expected to be used iteratively.

- Extract business requirements from a PM document, distinguishing prescribed
  solutions from underlying needs and identifying implicit requirements
- Validate requirements for completeness, testability, and internal consistency
- Elaborate business requirements into technical requirements: NFRs, integration
  constraints, security and privacy implications
- Produce an initial risk classification (R1–R4) based on the nature of the requirements
- Design REST API contracts (OpenAPI), validated against requirements
- Design storage schemas (PostgreSQL, DynamoDB, OpenSearch, Redis) appropriate to
  described access patterns
- Design message contracts that are versioned and standards-compliant
- Record architecture decisions with rationale, alternatives considered, and the
  requirement each decision serves
- Design a high-level test strategy
- Templates for: business requirements, technical requirements, API contract, storage
  schema, message contract, test strategy, ADR

### 3. Design Validation Capabilities

- Cross-reference the full set of discovery artifacts and produce a validation report:
  requirement coverage, standards compliance, design consistency, test strategy
  completeness
- Validation report must distinguish required changes (block approval) from suggestions
  (informational)

### 4. Implementation Phase Capabilities

- Analyze an existing codebase and produce structured documentation of its technology
  stack, architecture, conventions, integrations, and concerns — for use as reference
  context on any brownfield project (delivered via `forge:init`; `forge:map` deprecated)
- Scaffold new projects and modules by service archetype (REST API service,
  event-driven service, Lambda function, data pipeline) with correct structure,
  dependencies, and configuration
- Implement API endpoints, data access layers, and message producers/consumers against
  validated designs, for each supported platform and language
- Write unit, integration, and end-to-end tests against the agreed test strategy
- Generate implementation task plans with explicit dependency ordering, task types,
  and wave groupings for parallel execution
- Create well-formed commits with structured metadata (conventional commit messages,
  machine-parseable git notes) and verify that commits are atomic and correctly scoped
- Enforce coding standards at generation time — standards must be loaded as context
  before any source file is written, without requiring explicit engineer invocation
- Each implementation agent must have explicit, documented deviation rules: what it
  handles autonomously, and what it must escalate to the engineer

### 5. Implementation Verification Capability

- Verify that a completed implementation delivers the stated phase goal — not just
  that tasks are marked complete — by comparing implementation artifacts against the
  validated design and requirements
- Identify stubs, missing integration wiring, and code that satisfies task description
  but not the underlying requirement
- Produce a structured verification report that feeds into the PR description and is
  referenced by the review skill

### 6. Review and Compliance Capabilities

- Review a pull request against coding standards, security policy, and privacy policy;
  produce a structured report with a risk classification and an AI approval or
  request-for-changes signal
- Evaluate security policy adherence specifically (OWASP, organizational security
  standards) for high-risk changes
- Evaluate privacy policy adherence specifically (PII handling, data minimization,
  consent, retention) for PRs touching member data
- Validate that PR changes trace back to stated requirements and agreed design
- For large PRs: partition review by file group and execute groups in parallel;
  review quality must not degrade with diff size
- Integrate with GitHub Actions to run automatically on every PR
- Approval policy (which PR types require human approval in addition to AI) must be
  implementable via GitHub branch protection rules and CODEOWNERS configuration
- Every review skill must support two output modes, selectable via an explicit `--ci`
  flag:
  - **Interactive mode** (default, no flag): human-readable output formatted for
    terminal consumption; structured by severity with clear suggested actions; suitable
    for a developer running the skill locally before pushing. Developers are expected
    to run review skills locally as a first-pass gate — the interactive experience must
    be actionable, not a raw data dump.
  - **CI mode** (`--ci`): machine-readable JSON to stdout conforming to the Forge review
    output schema (`.forge/efforts/forge-plugin/spec/review-output-schema.md`); no
    decorative or conversational output; exit code 1 on FAIL or ERROR, exit code 0 on
    PASS. This is the mode GitHub Actions workflows use.
  The same skill serves both contexts. CI mode must be a strict subset of the information
  in the interactive report — nothing is hidden in interactive mode that appears in CI
  mode.
- Every review skill that operates on a diff must accept a `--base <branch>` parameter
  specifying the branch being merged into (the diff base). When not provided, the skill
  auto-detects the repository default branch via `git symbolic-ref refs/remotes/origin/HEAD`.
  In CI, GitHub Actions always passes `--base` explicitly using
  `${{ github.event.pull_request.base.ref }}` — there is no ambiguity in CI. Locally,
  developers may omit it to accept the default or pass it explicitly when reviewing
  against a non-default target (e.g., a release branch). The diff is computed as
  `git diff <base>...HEAD` (three-dot diff: changes introduced by the current branch
  since diverging from base, excluding changes made to base in the meantime).
  As a local convenience, skills may also accept `--pr <number>` to review an existing
  PR by number using `gh pr diff`; this is optional and supplements rather than replaces
  `--base`.

### 7. Operations Capabilities

- Generate a runbook as part of the definition of done for any production capability; the
  runbook is stored as a per-capability-area file in `docs/runbook/` with a regenerated
  index at `docs/runbook/README.md` — not as a single growing flat file
- Analyze DataDog logs and metrics in the context of a known runbook and deployment
  history to diagnose incidents; the diagnose skill reads `docs/runbook/README.md` to
  locate the relevant area file(s) rather than scanning a single monolithic file
- Execute runbook remediation steps autonomously for safe actions; require engineer
  confirmation for unsafe actions (schema changes, data deletion, anything without a
  defined rollback)
- Monitor deployment metrics and logs during staged rollouts; recommend proceed or
  rollback based on observed signals; execute known failure responses without
  requiring human intervention

### 8. Standards

The following standards must exist and must be referenced by the capabilities above.
Standards must serve dual use: each rule must read naturally both as a directive for
a code generator ("do X") and as a criterion for a code reviewer ("check for X").
Standards must be progressive — the most critical rules at the top, detail at the
bottom — so that partial injection still covers the highest-impact cases.

- REST API design (resources, naming, status codes, versioning, error responses)
- Version control (branch naming, conventional commits, atomic changes, git notes)
- Security (OWASP Top 10, authentication and authorization, input validation, secrets)
- Privacy (PII classification, data handling, retention, consent)
- Data storage (relational, document, search, cache)
- Messaging (contract design, Kafka-specific, backward/forward compatibility)
- Testing (strategy, unit, integration, end-to-end, contract)
- Observability (logging, metrics, tracing, alerting, runbooks)
- Deployment (canary configuration, rollback criteria, CI/CD pipeline)
- Language coding guidelines for each supported platform (Java, Go, Node.js, Kotlin,
  Swift, Obj-C, TypeScript) — minimum context needed to evaluate language-specific
  code correctly; not comprehensive style guides

Standards for each platform are produced collaboratively with the engineers who will
own and maintain them. Code ownership is established through the workshop process that
produces each standard.

---

## Constraints

### Technical Constraints

- All skills and workflow tooling must run within Claude Code without requiring
  additional runtime dependencies beyond what is already installed in the development
  environment
- Heavy operations (PR review, PM document analysis, incident diagnosis) must run
  in isolated sub-agents with fresh context windows to prevent context pollution and
  maintain consistent output quality regardless of main session length
- Jira integration must use the organization's existing Jira instance and
  authentication mechanisms
- Monitoring integration must use DataDog as the primary observability platform
- Sub-agent invocations that run in GitHub Actions (PR review, rollout monitoring,
  incident diagnosis) must operate within a configurable per-invocation cost ceiling
  defined by Productivity Engineering; invocations that would exceed the ceiling must
  fail with a diagnostic error, not silently degrade or produce partial output

### Process Constraints

- The process must not require engineers to use every phase for every piece of work —
  low-risk work (R4) must be completable with minimal overhead
- Human review and approval must remain in the process at critical gates: discovery
  approval, design approval, and PR merge for R1/R2 changes; the goal is to make
  those reviews faster and better, not to remove them
- Standards must be discoverable and usable without invoking a skill — an engineer
  working without any Forge tooling must still be able to find and apply the standards
- Standards must be maintained in a central repository and referenced by all projects,
  not embedded per-project; a change to a standard must propagate to all projects
  automatically
- The framework tooling (hooks, skills, validation logic) must have automated tests
  for critical deployables before being deployed to production use
- Framework adoption is mandatory for all development work in all repositories —
  no team or project may opt out; ceremony scales with work type but standards
  enforcement (forge:review on every PR) has no minimum-size exemption
- Framework version updates must not force simultaneous adoption across all teams;
  a controlled rollout mechanism with defined lag periods and active-work protection
  is required before any mandatory version upgrade is enforced

### Business Constraints

- The process must work for all platform teams: mobile (iOS/Android), web, backend
  services, data engineering, and data science
- The process must integrate with, not replace, existing quality and security gate
  requirements
- The PR review approval policy (which changes require human approval in addition to
  AI) must be owned by Productivity Engineering and implementable without changes to
  the tooling itself — policy changes should not require skill or hook changes
