# Meeting Summary: Forge Roadmap Planning

**Date:** 2026-04-17  
**Participants:** Manna, Vogan

---

## Quick Recap

Manna and Vogan discussed progress and planning for the Forge AI initiative, covering multiple workstreams including PR review, MVP development, and agent implementation. They reviewed the roadmap structure, identifying missing initiatives such as design, PMO, product management, and SRE components, while discussing the need to expand beyond just engineering-focused skills to include broader development processes. The conversation touched on technical challenges around environment management, testing approaches, and the need for better data isolation between environments. They also discussed cost optimization strategies for Forge, noting that cache reads and writes represent the majority of costs rather than input/output tokens, and the importance of creating proper bug reporting mechanisms through either a new JIRA project or existing request forms.

---

## Next Steps

### Manna
- Fully update the Gantt chart by the end of the day
- Send Vogan the link to the Forge roadmap document
- Talk to the team about running tests in parallel to avoid slowing down continuous delivery
- Include Vogan in discussions about data management for environment stability once Forge settles
- Add notes about the Forge workshop kickoff that was already completed
- List all initiatives from the PR in the roadmap document
- Clean up and organize the roadmap structure
- Think about creating a new JIRA space called Daybreak for AI initiatives including Forge
- Talk with Paris about the bug reporting/intake process idea
- Download the meeting transcript from Zoom and add it to the meetings directory using the year-month-day-time format

### Vogan
- Review the Forge roadmap that Manna worked on
- Update training and other sections with items he wants to add
- Conduct a roadshow with squad leads or tribe squad leads to gather feedback on Forge
- Review the PR and provide feedback on the initiatives
- Set up a way for people to report bugs for Forge (ticket/intake system)
- Set up a meetings directory in the Forge plugin effort repo

---

## Summary

### Project Updates and Implementation Progress

Manna provided an update on multiple ongoing projects, including the Forge PR review with three MVPs completed and a fourth in progress, and the ephemeral MVP set to be rolled out to a service next week. Abhishek is working on utilizing Uber Context to automate creating dependencies for mock data, while the team is also implementing security and SRE agents, with Julia's implementation being taken over due to her tight schedule. Manna discussed the hosting platform, mentioning the addition of a host code plugin to the marketplace and the need to address GitHub handling, potentially through a GitHub bot that would store files in S3 for engineers without GitHub accounts.

### Forge Implementation Planning

Manna and Vogan discussed plans for implementing Forge, including the need for users without GitHub accounts to access it through EKS pods with an API that operates under a system account. They also talked about reorganizing the skill definition structure to better centralize information about pull requests and commits. Manna mentioned creating a Gantt chart for timeline tracking and asked Vogan to review the updated roadmap for the Forge plugin plan, which Manna had expanded to cover the complete Forge roadmap.

### Standards Review Process Alignment

Vogan and Manna discussed the need to align on standards review processes and address challenges with running tests in the delivery pipeline. They highlighted the importance of making the process quick and efficient, with microservices being deployed within a day. Manna suggested creating a separate UAT environment for long-running processes to avoid slowing down the delivery system. Vogan shared an example of a tenancy model used in a previous project to manage database access and data scoping.

### Data Management Across Environments

Vogan and Manna discussed challenges with data management across environments, particularly regarding tenant identifiers and test functionality. They agreed that tests should create and manage their own data independently to avoid conflicts, including setting up data in a well-known state and tearing it down after testing. The team planned to conduct a roadshow to gather feedback from squad leads and address any emerging issues, though specific details about the format were left open. They also briefly touched on training initiatives including a forge workshop kickoff and lunch and learn sessions.

### Forge Expansion Strategy

Vogan and Manna discussed the need to expand Forge's focus beyond engineering to include design, product management, and other activities left of engineering. They agreed that initiatives like competitive analysis and design should be represented in their roadmap and stored in the coordination repo to be published on their wiki. Manna emphasized the importance of capturing strategic grounding and project management inputs, noting that Forge is not restricted to their zones of comfort and should include artifacts produced earlier in the process.

### Framework Initiatives Planning

Vogan and Manna discussed adding various initiatives to their framework, including design, PMO, product management, SRE, and infrastructure components. They identified missing areas such as developer experience and scaffolding, and agreed to list all initiatives in a PR for review. Vogan also suggested including the development of Forge itself as a separate initiative, covering improvements like review skills, versioning, and cleanup of the R standards repo.

### Token Cost Optimization

Vogan discussed a report shared by Rajiv, highlighting that the cost of input and output tokens is minimal compared to cache reads and writes, which account for 70% of the total cost. He suggested optimizing the process by reducing token volume and potentially restructuring the progressive discovery approach into smaller files, though this could increase the number of tool calls and impact speed. Manna and Vogan explored how context is passed between tool calls and the LLM, though specific details about cache behavior during tool calls remain unclear.

### Forge Optimization and Bug Management

Vogan and Manna discussed the need to build a harness for optimizing Forge, emphasizing the importance of demonstrating significant cost savings to justify investment. They explored creating a bug reporting system, considering either a new JIRA project or a dedicated space within an existing project to manage Forge-related issues. Manna mentioned implementing a request form system to centralize ad hoc requests and shared that Powell's team and his team are currently using a form to triage and prioritize incoming requests.
