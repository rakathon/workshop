← [Design Overview](README.md)

## Repository Layout — Marketplace and Plugin Structure

This document describes how the `rr-standards` repository is organized as a Claude Code
plugin marketplace hosting two plugins.

Three structural changes from the current state:
1. `plugins/forge/` is renamed to `.forge/` — the design artifact directory becomes a hidden
   dotfile directory, keeping it out of the way of the distributed plugin content.
2. A new `plugins/forge/` directory becomes the Forge plugin root.
3. A new `plugins/rr-standards/` directory becomes the rr-standards plugin root.

The `standards/` and `languages/` directories move inside `plugins/forge/` as bundled content.

---

### Top-Level Directory Structure

```
plugins/rr-standards/                          ← marketplace repository
│
├── .claude-plugin/
│   └── marketplace.json               # Marketplace definition
│
├── .forge/                            # Forge design artifacts (RENAMED from plugins/forge/)
│   └── efforts/                         # Epic designs, requirements, design docs
│       ├── forge-plugin/
│       ├── ai-pr/
│       ├── rr-standards-plugin/
│       └── ...
│
├── plugins/forge/                             # Forge plugin root
│   ├── .claude-plugin/
│   │   └── plugin.json                # Plugin manifest: name: forge
│   ├── skills/                        # forge: skills — unprefixed dirs, plugin name is namespace
│   ├── hooks/                         # Session start, tool use, and prompt submit hooks
│   ├── settings.json                  # Default permissions (allow-list seed for forge:init)
│   ├── standards/                     # Bundled standards library content (moved from repo root)
│   └── languages/                     # Bundled language guides (moved from repo root)
│
├── plugins/rr-standards/                      # rr-standards plugin root
│   ├── .claude-plugin/
│   │   └── plugin.json                # Plugin manifest: name: rr-standards
│   ├── skills/                        # rr-standards: skills — unprefixed dirs, plugin name is namespace
│   └── hooks/                         # rr-standards-specific hooks (if any)
│
├── templates/                         # Authoring templates (TBD — may move into plugins/forge/)
├── scripts/                           # Utility scripts (TBD — may move into plugins/forge/)
└── skills/                            # Existing skills (TBD — may move into plugins/forge/)
```

The `.forge/` directory is not distributed with either plugin. It contains internal
design artifacts — requirements, technical specs, and skill design documents — used
by the people building and maintaining the tooling.

---

### `.claude-plugin/marketplace.json`

```json
{
  "$schema": "https://anthropic.com/claude-code/marketplace.schema.json",
  "name": "rr-standards",
  "description": "Rewards & Guilds engineering standards and workflow tooling for Claude Code",
  "owner": {
    "name": "Rewards & Guilds Engineering"
  },
  "plugins": [
    {
      "name": "forge",
      "description": "Workflow management for software projects — structured discovery, design, implementation, review, QA, and operations phases with bundled coding standards",
      "source": "./plugins/forge",
      "category": "development",
      "homepage": "https://github.com/rewards-guilds/rr-standards/tree/main/plugins/forge"
    },
    {
      "name": "rr-standards",
      "description": "Standards library authoring and maintenance tools — author, validate, review, and track coverage of the rr-standards library",
      "source": "./plugins/rr-standards",
      "category": "development",
      "homepage": "https://github.com/rewards-guilds/rr-standards/tree/main/plugins/rr-standards"
    }
  ]
}
```

---

### `plugins/forge/` Plugin Contents

The Forge plugin provides all workflow skills (`forge:` prefix), hooks, and bundled
standards content to project teams. It is installed globally per developer machine.

```
plugins/forge/
├── .claude-plugin/
│   └── plugin.json           # name: forge, version, description, author
├── skills/                    # One subdirectory per forge: skill, each with SKILL.md
│   ├── init/                  # → /forge:init
│   ├── status/                # → /forge:status
│   ├── review/                # → /forge:review
│   └── ...                    # Plugin name provides the namespace; no "forge-" prefix needed
├── hooks/                     # Hook scripts
│   ├── session-start/
│   ├── user-prompt-submit/
│   ├── pre-tool-use/
│   └── post-tool-use/
├── settings.json              # Default allow-list permissions (seed for forge:init)
├── standards/                 # Bundled standards library
│   ├── TAXONOMY.md
│   ├── COVERAGE.md
│   ├── api/
│   ├── security/
│   ├── storage/
│   └── ...
└── languages/                 # Bundled language guides
    ├── go/
    ├── java/
    ├── kotlin/
    └── ...
```

The skills, hooks, and settings structures match the package architecture defined in
`distribution.md § Package Architecture`. The `skills/` directory contains one
subdirectory per `forge:` skill, each with a `SKILL.md` and `README.md`.
The plugin name (`forge`) is the automatic namespace — skill directory names are
unprefixed. (`commands/` is the legacy Claude Code location; `skills/` is current.)

---

### `plugins/rr-standards/` Plugin Contents

The rr-standards plugin provides maintenance skills (`rr-standards:` prefix) for
authors working in this repository. It has no value in effort repositories that
consume standards rather than author them.

```
plugins/rr-standards/
├── .claude-plugin/
│   └── plugin.json           # name: rr-standards, version, description, author
├── skills/                    # One subdirectory per rr-standards: skill, each with SKILL.md
│   ├── author/                # → /rr-standards:author
│   ├── validate/              # → /rr-standards:validate
│   ├── review/                # → /rr-standards:review
│   └── coverage/              # → /rr-standards:coverage
└── hooks/                     # rr-standards-specific hooks (if any)
```

Skill workflows are defined in
`.forge/efforts/rr-standards-plugin/spec/skills.md`.

---

### Path Conventions After Restructuring

All paths in design documents that previously referred to `standards/` or `languages/`
as repo-root directories now refer to paths inside the Forge plugin:

| Old path (repo root) | New path (inside Forge plugin) |
|---------------------|-------------------------------|
| `standards/api/rest.md` | `plugins/forge/standards/api/rest.md` |
| `standards/TAXONOMY.md` | `plugins/forge/standards/TAXONOMY.md` |
| `languages/go/guides/` | `plugins/forge/languages/go/guides/` |
| `languages/java/AGENTS.md` | `plugins/forge/languages/java/AGENTS.md` |

The `TAXONOMY.md` artifact type identification rules use paths relative to the
`plugins/forge/` plugin root — `standards/` means `plugins/forge/standards/` within the installed
plugin.

---

### Relationship Between `.forge/` and the Plugin Directories

`.forge/efforts/` contains the **design artifacts** that govern what gets built — epic
requirements, design documents, skill specifications, and the review output schema.
These are working documents for the people building and maintaining the tooling.

`plugins/forge/` and `plugins/rr-standards/` contain the **distributable artifacts** — the actual
SKILL.md files, hook scripts, and settings that Claude Code installs.

The design artifacts in `.forge/efforts/` are not distributed with either plugin.
