← [Design Overview](README.md)

## Distribution Architecture

### Two-Plugin Marketplace Model

Forge and the rr-standards maintenance tools are distributed as two independent Claude
Code plugins through a plugin marketplace. The rr-standards repository serves as the
marketplace for now; the plugins may be moved to a dedicated marketplace repository later.

```
plugins/rr-standards/                    ← marketplace repository
├── .forge/                      ← Forge design artifacts (internal; not distributed)
├── plugins/forge/                       ← Forge plugin
└── plugins/rr-standards/                ← rr-standards maintenance plugin
```

**Forge plugin** (`forge:` command prefix) — workflow management for any software project.
Contains all Forge workflow skills, hooks, templates, and the bundled standards content
(`plugins/forge/standards/` and `plugins/forge/languages/` directories). Engineers installing the Forge
plugin get everything needed for code generation and review without a separate download
step. The plugin is installed globally per developer machine so `forge:init` is available
in any project before that project has been initialized.

**rr-standards plugin** (`rr-standards:` command prefix) — standards library authoring
and maintenance tools. Contains the skills for maintaining the rr-standards standards
library: `rr-standards:author`, `rr-standards:validate`, `rr-standards:review`,
`rr-standards:coverage`. Designed for the rr-standards taxonomy. Can be installed in
other repositories that maintain a compatible standards library structure, but has no
value in a typical effort repository that consumes standards rather than authoring them.

The two plugins are independent: installing one does not require the other.

### Project File Structure (Forge plugin installed)

With the plugin model, the standards content arrives with the plugin — there is no
gitignored `plugins/rr-standards/` download directory and no `rr-standards-version` file.
`forge:init` configures the project to use the already-installed plugin content.

```
<project-root>/
├── .claude/
│   ├── settings.json             # committed: hook registrations + permissions
│   └── skills/                   # committed: skill SKILL.md shortcuts
│       ├── forge-status/
│       ├── forge-review/
│       └── ...
├── plugins/forge/
│   ├── README.md                 # active work item index
│   └── spec/arch-decisions/
│       └── README.md
├── docs/runbook/
│   └── README.md
└── CLAUDE.md                     # standards references point to plugin-bundled content
```

### Initializing a New Project

`forge:init` handles first-time project setup. Because the plugin bundles the standards,
there is no tarball to download — `forge:init` only configures the project:

1. Prompt for which packages to activate
2. Run `setup.sh --packages <list>` to install skill shortcuts and register hooks in
   `.claude/settings.json`
3. Create or merge CLAUDE.md with standards references pointing to the plugin's bundled
   standards location (greenfield: create; brownfield: merge without overwriting)
4. Create `plugins/forge/README.md`, `plugins/forge/spec/arch-decisions/README.md`, `docs/runbook/README.md`
5. Configure the git notes push/fetch refspec
6. Commit all generated files

A contributor cloning an already-initialized project only needs the Forge plugin
installed on their machine — the committed `.claude/` files activate immediately.

### Updating the Forge Plugin

Plugin updates are managed through Claude Code's built-in plugin update mechanism.
There is no `forge:update` command — engineers use the standard Claude Code plugin
update flow to install new versions.

The session-start hook announces pending updates and enforces deadlines:

**Minor and patch versions** (new skills, new standards, documentation):
- The session-start hook detects a newer version and notes it in the session context
- No blocking — update at your convenience via Claude Code

**Major versions** (hook behaviour changes, `.state.json` schema changes, skill output
format changes):
- Announced by the session-start hook with the enforcement deadline
- Before the deadline: advisory only; update via Claude Code at your convenience
- After `mandatoryAfter`: the session-start hook blocks the session and instructs the
  engineer to update the Forge plugin via Claude Code before continuing

**Enforcement deadlines** are read from `VERSIONS.json` in the marketplace repository:

```json
{
  "v2": {
    "latestRelease": "v2.1.0",
    "mandatoryAfter": "2026-05-01"
  }
}
```

### Why Two Plugins, Not One

Engineering teams using Forge to build software need the workflow skills and bundled
standards. They do not need standards authoring tools — `rr-standards:author` and
`rr-standards:validate` have no use in a effort repository that consumes standards
rather than authoring them.

Maintainers of the rr-standards library need the authoring and validation tools. They
may or may not also use Forge for their development workflow.

Keeping the plugins separate means each is independently useful and independently
versioned. A team could install the rr-standards plugin to validate standards artifacts
without having the full Forge workflow plugin in that repository.

### Why Packages Remain Within the Forge Plugin

Within the Forge plugin, the package model (rr-core, workflow-light, workflow-full,
implementation, review, qa, operations) is retained for selective installation. Teams
that only need review and operations do not need to install the full workflow package.
This is internal Forge plugin organization — the packages are not separately distributed
plugins. `setup.sh --packages <list>` selects which packages to activate from the
already-installed plugin content.

The concerns that ruled out per-package plugin distribution in an earlier design
(versioning across packages, cross-package consistency, standards sharing dependency
model) do not apply to the two-plugin model because Forge and rr-standards are genuinely
independent — they share no `.state.json` schema, no skill output formats, and no
inter-plugin dependencies.

---

## Package Architecture

Packages bundle related skills, hooks, templates, and settings into installable units.
Each package declares its dependencies. `setup.sh` resolves the dependency graph and
installs required packages automatically — a team that installs `workflow-full` does
not need to separately install `workflow-light` or `rr-core`.

### Dependency Graph

```
rr-core                   (no dependencies — install this first or let it be pulled in)
├── workflow-light        (requires: rr-core)
│   ├── workflow-full     (requires: workflow-light)
│   ├── implementation    (requires: workflow-light)
│   └── qa               (requires: workflow-light)
├── review               (requires: rr-core)
└── operations           (requires: rr-core)
```

The three packages that require `workflow-light` (not just `rr-core`) do so because
they depend on skills or state that `workflow-light` owns:
- `implementation` — `implement/commit` prompts the engineer to invoke `plan/update`
  immediately after creating a commit. `plan/update` lives in `workflow-light`.
- `qa` — `qa/regression-tests` writes test files into the codebase and records them
  in `.state.json`. The PostToolUse hooks that update `.state.json` live in `workflow-light`.
- `workflow-full` — adds the discovery/validation phase skills on top of the planning
  skills (`plan/generate`, `plan/update`) that `workflow-light` owns.

### Package Definitions

```
packages/
│
├── rr-core/
│   ├── Requires: (none)
│   ├── Skills:   workflow/init, workflow/status, workflow/promote,
│   │             workflow/revert, workflow/reopen
│   ├── Hooks:    SessionStart (×1: inject-workflow-context),
│   │             SessionStart (×1: inject-standards-reminder),
│   │             UserPromptSubmit,
│   │             PreToolUse: inject-generation-standards.sh
│   ├── Settings: Bash(git *), Bash(plugins/rr-standards/hooks/**)
│   └── Templates: project/project-claude-md.md, project/settings.json
│
├── workflow-light/
│   ├── Requires: rr-core
│   ├── Skills:   plan/generate, plan/update,
│   │             workflow/jira-pull, workflow/jira-push, workflow/jira-resolve
│   ├── Hooks:    PostToolUse (×2: update-workflow-state, queue-jira-sync)
│   ├── Settings: Write(plugins/forge/**), Edit(plugins/forge/**), Write(docs/**), Bash(curl *)
│   └── Templates: workflow/implementation-plan.md
│
├── workflow-full/
│   ├── Requires: workflow-light   (which brings rr-core)
│   ├── Skills:   requirements/extract, requirements/validate,
│   │             requirements/classify-risk, requirements/elaborate,
│   │             spec/api, spec/storage, spec/messaging,
│   │             spec/record-decision, spec/test-strategy,
│   │             validate/design, validate/api, validate/storage,
│   │             validate/messaging, validate/test-coverage
│   ├── Hooks:    PreToolUse (×2: enforce-phase-gates, protect-approved-artifacts)
│   ├── Settings: Write(plugins/forge/**/spec/**), Write(plugins/forge/**/validation/**)
│   └── Templates: workflow/business-requirements.md, workflow/technical-requirements.md,
│                  workflow/architecture-decision-record.md, workflow/test-strategy.md,
│                  workflow/design-validation-report.md,
│                  spec/api-contract.yaml, spec/storage-schema.md,
│                  spec/message-contract.md
│
├── implementation/
│   ├── Requires: workflow-light   (for plan/update, called after implement/commit)
│   ├── Skills:   implement/scaffold, implement/api, implement/repository,
│   │             implement/messaging, implement/tests, implement/commit
│   ├── Hooks:    (none)
│   ├── Settings: Bash(git notes *), + language build tools (go, mvn, npm, etc. —
│   │             added by forge:init based on declared tech stack)
│   └── Templates: (language-specific — linked from languages/, not copied)
│
├── review/
│   ├── Requires: rr-core
│   ├── Skills:   review/pr, review/security, review/privacy, review/traceability
│   ├── Hooks:    (none)
│   ├── Settings: Bash(gh *)
│   ├── Templates: review/pr-review-report.md
│   └── GitHub Actions: templates/github-actions/pr-review.yml
│
├── qa/
│   ├── Requires: workflow-light   (for .state.json PostToolUse hooks)
│   ├── Skills:   qa/execute, qa/map-defects, qa/coverage-gaps, qa/regression-tests
│   ├── Hooks:    (none — uses workflow-light's PostToolUse hooks)
│   ├── Settings: Bash(curl *)     (pre-prod environment API calls)
│   └── Templates: qa/test-execution-report.md, qa/defect-report.md, qa/sign-off.md
│
└── operations/
    ├── Requires: rr-core
    ├── Skills:   operate/generate-runbook, operate/diagnose, operate/remediate,
    │             operate/rollout-monitor
    ├── Hooks:    (none)
    ├── Settings: Bash(curl *), Bash(gh *)
    ├── Templates: (seeds docs/runbook/README.md at forge:init time; forge:runbook adds per-capability-area files)
    └── GitHub Actions: templates/github-actions/rollout-monitor.yml,
                        templates/github-actions/incident-response.yml
```

### Common Installation Profiles

`setup.sh` accepts a comma-separated package list and resolves the full dependency
closure before installing:

```bash
# Full enterprise team (all phases, all tiers)
plugins/rr-standards/setup.sh --packages workflow-full,implementation,review,qa,operations
# Resolves to: rr-core, workflow-light, workflow-full, implementation, review, qa, operations

# Story/task team (lightweight workflow only — no discovery phase tooling)
plugins/rr-standards/setup.sh --packages workflow-light,implementation,review
# Resolves to: rr-core, workflow-light, implementation, review

# CI/CD automation only (no interactive session tooling)
plugins/rr-standards/setup.sh --packages review,operations
# Resolves to: rr-core, review, operations

# Operations/SRE (incident response only)
plugins/rr-standards/setup.sh --packages operations
# Resolves to: rr-core, operations
```

`setup.sh` installation order respects the dependency graph (parents before children).
Installing a package that is already installed is idempotent — `setup.sh` checks the
installed package list and skips packages that are already present at the correct version.

`setup.sh --update` re-installs all currently-installed packages from the updated
`plugins/rr-standards/` content without prompting for package selection. The list of installed
packages is persisted in `.rr-standards-packages` (committed alongside `rr-standards-version`)
so `forge:update` can re-apply the same package set to the new version.

---

## Settings Architecture

### What `.claude/settings.json` Does

Claude Code reads `.claude/settings.json` to determine which tool uses require approval,
which tool uses are automatically allowed or denied, and which hooks to execute at each
lifecycle event. For rr-standards tooling to work correctly, both the permission model
and the hook registrations must be present.

`setup.sh` writes and maintains this file. Engineers do not edit it directly. When a
new package is installed, `setup.sh` merges the package's required additions into the
existing file.

### Permission Model

The minimum permissions required for the rr-core package to function:

```json
{
  "permissions": {
    "allow": [
      "Bash(git *)",
      "Bash(plugins/rr-standards/hooks/**)",
      "Bash(plugins/rr-standards/setup.sh *)"
    ],
    "deny": []
  }
}
```

Additional packages add to the allow list:

| Package         | Additional permissions required                              |
|-----------------|--------------------------------------------------------------|
| workflow-full   | `Write(plugins/forge/**)`, `Edit(plugins/forge/**)`, `Write(docs/**)`       |
| implementation  | `Bash(git notes *)`, language build tools (e.g. `Bash(go *)`, `Bash(mvn *)`) |
| review          | `Bash(gh *)` (GitHub CLI for PR data)                       |
| qa              | `Bash(curl *)` (pre-prod environment calls)                  |
| operations      | `Bash(curl *)` (DataDog API calls), `Bash(gh *)` (Actions)  |
| jira (any)      | `Bash(curl *)` (Jira REST API)                               |

**Why explicit allow-listing rather than broad `Bash(*)`:** The PreToolUse hooks enforce
phase gates, but they operate at the Claude tool level. Broad Bash access would allow an
engineer to bypass phase gates by running `git commit` directly. Explicit allow-listing
for specific Bash patterns means an out-of-phase direct commit attempt would fail at
the permissions level without requiring the hook to catch it.

### Hook Registrations

Hooks are registered in the `hooks` section of `.claude/settings.json`. Each entry
specifies the lifecycle event, the tool pattern it matches (if scoped), and the command
to execute. `setup.sh` writes these registrations when packages are installed.

Project-level hooks (installed by `setup.sh`, registered in `.claude/settings.json`)
point to scripts inside `plugins/rr-standards/hooks/` — the gitignored downloaded content.
This means hooks always run at the version corresponding to the downloaded rr-standards
release; they do not require re-copying when `forge:update` runs.

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          { "type": "command", "command": "plugins/rr-standards/hooks/session-start/01-inject-workflow-context.sh" },
          { "type": "command", "command": "plugins/rr-standards/hooks/session-start/02-inject-standards-reminder.sh" }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          { "type": "command", "command": "plugins/rr-standards/hooks/user-prompt-submit/01-route-to-skills.sh" }
        ]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          { "type": "command", "command": "plugins/rr-standards/hooks/pre-tool-use/inject-generation-standards.sh" },
          { "type": "command", "command": "plugins/rr-standards/hooks/pre-tool-use/02-enforce-phase-gates.sh" },
          { "type": "command", "command": "plugins/rr-standards/hooks/pre-tool-use/03-protect-approved-artifacts.sh" }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          { "type": "command", "command": "plugins/rr-standards/hooks/post-tool-use/01-update-workflow-state.sh" },
          { "type": "command", "command": "plugins/rr-standards/hooks/post-tool-use/02-monitor-context.sh" },
          { "type": "command", "command": "plugins/rr-standards/hooks/post-tool-use/03-queue-jira-sync.sh" }
        ]
      }
    ]
  }
}
```

**Note:** The version-check and enforcement hook (`03-check-rr-standards-updates.sh`)
runs from the global plugin (`~/.claude/hooks/`), not from `plugins/rr-standards/`. It must
run even when `plugins/rr-standards/` is absent. This hook is not registered by `setup.sh`;
it is registered once during global plugin installation.

### Merge Safety

`setup.sh` uses a JSON merge strategy, not file overwrite. When adding a new package:
1. Read existing `.claude/settings.json` (or start from `templates/project/settings.json`)
2. Append new `allow` entries to `permissions.allow` (deduplicating)
3. Append new hook registrations to the appropriate event arrays
4. Write the result back

This means the file is safe to extend at any time. Running `setup.sh` twice for the
same package is idempotent — deduplication prevents double-registration.

---

## Platform Workshop Architecture

Platform-specific skills (for mobile, web, data engineering, data science) are built
through structured workshops with each engineering group. A workshop is not a meeting —
it is a facilitated, artifact-producing session that outputs:

1. **Platform design standards** — added to `standards/` or `languages/<platform>/`
2. **Platform-specific skill variants** — override or extend the base skills for that platform
3. **Validation criteria** — what does "correct" look like for this platform

The `workshop/` skill facilitates this process. It guides participants through:

```
Session 1: Inventory (what patterns do you actually use?)
  Output: Pattern inventory document

Session 2: Standards Derivation (which patterns should be standard?)
  Output: Draft platform standards

Session 3: Skill Design (how should Claude help with each pattern?)
  Output: Skill SKILL.md drafts

Session 4: Validation Design (how do we know Claude got it right?)
  Output: Validation criteria and test cases

Session 5: Review and Publish
  Output: Final standards, skills, and validation tests committed to rr-standards
```

Platforms to cover (in recommended sequence based on team readiness and impact):
1. Backend services (Java/Kotlin/Go)
2. Web front-end (TypeScript/React)
3. Mobile iOS (Swift)
4. Mobile Android (Kotlin)
5. Data engineering (Python/Spark)
6. Data science (Python/notebooks)

---
