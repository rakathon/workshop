← [Design Overview](README.md)

## Git Metadata Model

### Structured git notes

The `implement/commit` skill attaches a structured JSON note to every task-completion
commit via `git notes`. This keeps commit messages clean and conventional while preserving
rich metadata that future agents can consume programmatically. The note is written at
commit time, when the full context (tests written, standards applied, deviations) is
present in the session.

```bash
git notes add -m '<json>' <commit-sha>
```

Note schema:
```json
{
  "workId": "PROJ-1234",
  "taskId": "TASK-001",
  "taskTitle": "Implement preference storage",
  "phase": "implementation",
  "testsWritten": ["PreferenceRepositoryTest"],
  "coveragePct": 87,
  "standardsChecked": ["standards/storage/relational.md"],
  "deviations": [],
  "timestamp": "2026-01-15T14:22:00Z"
}
```

Notes are structured (not prose) so the `diagnose` skill can correlate production
incidents with specific task completions by querying git notes without natural language
extraction. The `workflow/revert` skill uses the `workId` and `taskId` fields to
identify which commits belong to a logical unit of work.

### Commit SHA tracking in plan/tasks.md

Every completed task row in `plan/tasks.md` records the first 7 characters of its
commit SHA inline:

```markdown
- [x] Implement preference storage (a3f9b12)
- [x] Add API endpoint for preference update (c7e2d84)
- [ ] Write integration tests
```

This gives human readers a direct link from plan to code. It is the mechanism the
`workflow/revert` skill uses to determine which commits to revert for a given task
or phase.

---

## External Integration Architecture

### Jira Integration

**Mechanism:** Direct Jira REST API calls via authenticated `curl` in hook scripts and
skills. No MCP server or additional infrastructure required for v1.

**Credentials:** Stored as environment variables in the developer's shell profile or
CI/CD secrets store. Required variables:
```
JIRA_BASE_URL=https://your-org.atlassian.net
JIRA_API_TOKEN=...
JIRA_USER_EMAIL=...
```

**Jira Sync State:** The `plan/jira-sync.json` file tracks the mapping between local
task IDs and Jira ticket keys, plus sync status per task.

```json
{
  "epicKey": "PROJ-1234",
  "lastFullSync": "2026-01-15T10:30:00Z",
  "tasks": [
    {
      "localId": "TASK-001",
      "jiraKey": "PROJ-1251",
      "title": "Scaffold service",
      "localStatus": "complete",
      "jiraStatus": "Done",
      "syncStatus": "in_sync",
      "lastSynced": "2026-01-15T10:30:00Z"
    }
  ]
}
```

**Conflict Resolution Flow:**
1. `jira-push` skill detects Jira status differs from local status
2. Skill writes conflict details to `.state.json` and `jira-sync.json`
3. `session-start` hook surfaces the conflict at the next session
4. Engineer invokes `jira-resolve` skill, which presents both states and asks for
   the authoritative version (repo wins by default; engineer can override)

**Jira-Initiated Workflows:**
The `jira-pull` skill accepts a Jira ticket key. It fetches the ticket, its description,
and its acceptance criteria, then initializes a `.forge/efforts/<key>/` directory using those
as the starting point for requirements or (for small tickets) directly for implementation.
Tier is inferred from ticket type: Epic → initiative/epic tier (all phases required);
Story/Task → story/task tier (implementation required, upstream phases available on
demand).

### DataDog Integration

**Mechanism:** DataDog REST API calls via authenticated `curl` in the `diagnose` and
`rollout-monitor` skills. Required variables:
```
DATADOG_API_KEY=...
DATADOG_APP_KEY=...
DATADOG_SITE=datadoghq.com
```

**Diagnose Skill Flow:**
1. Accepts: service name, time window, and optional runbook path
2. Queries DataDog Logs API for errors in the window
3. Queries DataDog Metrics API for anomalies (error rate, latency, saturation)
4. Cross-references findings with the runbook playbooks
5. Produces a structured diagnosis report: root cause hypothesis, supporting evidence,
   recommended remediation steps (or escalation if no matching pattern)

**Rollout Monitor Skill Flow:**
1. Accepts: service name, deployment ID, success thresholds (configurable per standard)
2. Polls DataDog Metrics for error rate and latency against baseline
3. Evaluates against `standards/deployment/rollback-criteria.md` thresholds
4. Produces a structured recommendation: PROCEED, PAUSE, or ROLLBACK with rationale
5. In GitHub Actions context, sets an Actions output variable that the workflow acts on

### GitHub Actions Integration

Claude Code runs in non-interactive (`--print`) mode within GitHub Actions jobs. It
receives context via file inputs and produces structured output consumed by the workflow.

**Template Workflows (in `templates/github-actions/`):**

#### `pr-review.yml` — Automated PR Review
```
Trigger: pull_request (opened, synchronize)
Steps:
  1. Checkout repository (including rr-standards)
  2. Generate PR diff and context file
  3. Run: claude --print "Apply /review/pr to this PR" < context.md
  4. Parse output: extract risk level, pass/fail, findings
  5. Post structured review as PR comment
  6. Set required check status based on outcome
  7. (If R1/R2 findings) Request human review from security/privacy team
```

#### `rollout-monitor.yml` — Deployment Monitoring Agent
```
Trigger: deployment_status (success) — runs continuously during rollout
Steps:
  1. Determine service name and deployment ID from event
  2. Run: claude --print "Apply /operate/rollout-monitor for <service>"
  3. Parse recommendation: PROCEED | PAUSE | ROLLBACK
  4. PROCEED: advance to next rollout stage (or complete)
  5. PAUSE: hold current stage, notify on-call
  6. ROLLBACK: trigger rollback workflow, notify on-call with diagnosis
```

#### `incident-response.yml` — Triggered Incident Diagnosis and Remediation
```
Trigger: Manual or alert webhook
Steps:
  1. Receive service name and time window
  2. Run: claude --print "Apply /operate/diagnose for <service> in last <window>"
  3. Parse diagnosis output: matched playbook (or "no match"), root cause, evidence
  4. If no playbook matched: page on-call with raw diagnosis report — stop here
  5. If playbook matched:
     a. Run: claude --print "Apply /operate/remediate using <playbook-section>"
     b. Remediate executes SAFE steps autonomously; stops at any UNSAFE step
     c. If fully resolved: post resolution summary to incident channel
     d. If blocked by UNSAFE step or step failure: page on-call with diagnosis
        report, completed steps, and blocking step — hand off to engineer
```

**Context File Format** (passed to Claude in non-interactive mode):
```markdown
# Context

## Active Workflow
[Contents of .forge/efforts/<id>/.state.json if present]

## Relevant Standards
[Paths to applicable standards documents]

## Task
[Specific instruction for this invocation]

## Input Data
[PR diff / deployment metrics / log excerpts]
```

---
