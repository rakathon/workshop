# Review Skill Output Schema

Authoritative definition of the machine-readable output record produced by every
Forge review skill. All review skills must conform to this schema. The human-readable
PR comment is a rendering of this record; the record is the source of truth.

Skills governed by this schema:
- `forge:review` (forge plugin; ai-pr epic)
- `forge:review-security` (forge plugin; ai-pr epic)
- `forge:review-privacy` (forge plugin; ai-pr epic)
- `rr-standards:review` (rr-standards plugin; rr-standards-plugin epic)

---

## Design Decisions

**Single schema across all review skills.** Each skill checks different things, but
all produce the same envelope. Consumers (metrics pipeline, audit tooling, branch
protection) parse one schema regardless of which skill ran.

**`locations` is an array.** Findings may span multiple files (e.g., duplication
detection reporting both the original and the copy). Parallel partition workers
each report all locations of a cross-file finding; the orchestrator deduplicates
on a canonical sort of the location set.

**Declared vs. effective severity.** When advisory findings for a rule exceed the
policy's `advisory_threshold`, the skill promotes those findings to blocking for
the verdict. Each finding carries both `declared_severity` (from the policy) and
`severity` (effective, after any promotion), plus `advisory_promoted: true` when
they differ. This lets metrics track both raw advisory volume and threshold-crossing
frequency independently.

**Confidence scoring.** After findings are collected, each finding is independently
scored 0–100 for likelihood of being a real, actionable issue (not a false positive).
Findings below a configurable `confidence_threshold` (default: 80) are
confidence-suppressed: they are excluded from all verdict counts and do not influence
the AI signal, but are retained in the output record with `confidence_suppressed: true`
so suppression rates can be monitored. Confidence is orthogonal to severity — a
blocking finding with low confidence is suppressed; an informational finding with high
confidence is surfaced. This is distinct from developer-initiated `forge:suppress`
annotations, which are intentional and carry a stated reason.

**Selective check applicability.** Not every check runs on every review. A check that
does not apply to the current target records `result: "skipped"` — present in the
`checks` array so consumers can distinguish "ran and passed" from "not applicable."
Skipped checks produce no findings and do not affect the verdict. Examples: the
`policy-consistency` check is skipped when no companion policy file exists; the
`traceability` check is skipped when the PR contains no Forge plan state update;
`test-coverage` is skipped when the diff touches only documentation or configuration.

**Positive observations.** Review skills may record genuine strengths in a top-level
`observations` array. These are not balance commentary to soften findings — they are
specific, accurate observations about what the code or artifact does well. An empty
`observations` array is normal and does not indicate a low-quality review.

**Duration at two levels.** The invocation carries total wall-clock `duration_ms`.
Each check carries its own `duration_ms`. For parallel checks, per-check times
sum to more than the wall-clock total — that difference is the parallelism saving.

**`result: "error"` is distinct from `"fail"`.** A service outage or cost-ceiling
breach is not a code quality failure. Consumers must surface these differently.

**Schema versioning.** `schema_version` follows semver. Any change that removes or
renames an existing field is a MAJOR increment. Adding new optional fields is MINOR.

---

## Schema

```json
{
  "schema_version": "1.0.0",

  "review": {
    "skill":          "forge:review-standard",
    "invocation_id":  "<uuid>",
    "started_at":     "<iso8601>",
    "completed_at":   "<iso8601>",
    "duration_ms":    4823,
    "model":          "claude-opus-4-6",
    "token_usage": {
      "input":        12345,
      "output":       678
    }
  },

  "target": {
    "type":           "pr",
    "repository":     "rewards-guilds/rr-standards",
    "pr_number":      42,
    "base_sha":       "abc123",
    "head_sha":       "def456",
    "branch":         "feat/my-standard",
    "review_mode":    "full-diff"
  },

  "verdict": {
    "result":                     "fail",
    "signal":                     "request-for-changes",
    "risk_level":                 null,
    "blocking_count":             3,
    "advisory_count":             7,
    "informational_count":        2,
    "suppressed_count":           1,
    "confidence_threshold":       80,
    "confidence_suppressed_count": 4
  },

  "checks": [
    {
      "check_id":     "quality-checklist",
      "name":         "Quality checklist",
      "category":     "quality",
      "result":       "fail",
      "duration_ms":  1240,
      "finding_ids":  ["f-001", "f-002"]
    },
    {
      "check_id":     "version-bump",
      "name":         "Version bump validation",
      "category":     "version",
      "result":       "pass",
      "duration_ms":  320,
      "finding_ids":  []
    }
  ],

  "findings": [
    {
      "id":                 "f-001",
      "check_id":           "quality-checklist",
      "severity":           "blocking",
      "declared_severity":  "blocking",
      "advisory_promoted":  false,
      "category":           "quality",
      "rule_id":            "R-3",
      "standard_ref":       "standards/api/rest.md@1.2.0",
      "locations": [
        {
          "file":       "standards/api/rest.md",
          "line_start": 45,
          "line_end":   45
        }
      ],
      "description":      "Compliance checklist item for R-3 is not a binary yes/no assertion",
      "evidence":         "- Does the API use plural nouns?",
      "suggested_action": "Rephrase as: '[ ] API resource paths use plural nouns (R-3)'",
      "suppressed":             false,
      "suppression_reason":     null,
      "confidence":             92,
      "confidence_suppressed":  false
    }
  ],

  "artifacts_loaded": [
    { "path": "standards/api/rest.md",        "version": "1.2.0" },
    { "path": "standards/api/rest.policy.md", "version": "1.0.0" }
  ],

  "exclusions": [],

  "observations": [
    {
      "category":    "quality",
      "description": "Error paths are consistently handled with structured error types throughout the new API surface"
    }
  ]
}
```

---

## Field Reference

### `review`

| Field | Type | Description |
|-------|------|-------------|
| `skill` | string | Skill identifier (e.g. `forge:review-standard`) |
| `invocation_id` | string (UUID) | Unique per invocation; ties PR comment to stored record |
| `started_at` | string (ISO 8601) | Wall-clock start time |
| `completed_at` | string (ISO 8601) | Wall-clock end time |
| `duration_ms` | integer | Total wall-clock duration in milliseconds |
| `model` | string | Model identifier used for this invocation |
| `token_usage.input` | integer | Input tokens consumed |
| `token_usage.output` | integer | Output tokens produced |

### `target`

`target.type` determines which fields are present:

**`type: "pr"`** — a GitHub pull request (used by `forge:review`, `forge:review-security`,
`forge:review-privacy`, `forge:review-standard`):

| Field | Type | Description |
|-------|------|-------------|
| `type` | string | `"pr"` |
| `repository` | string | `org/repo` |
| `pr_number` | integer | GitHub PR number |
| `base_sha` | string | Base branch commit SHA |
| `head_sha` | string | PR HEAD commit SHA |
| `branch` | string | PR branch name |
| `review_mode` | string | `"full-diff"` or `"incremental"` |

**`type: "file"`** — a single artifact file (used by `forge:validate-standard --ci`):

| Field | Type | Description |
|-------|------|-------------|
| `type` | string | `"file"` |
| `path` | string | Repo-relative path to the validated file |

### `verdict`

| Field | Type | Description |
|-------|------|-------------|
| `result` | string | `"pass"` · `"fail"` · `"error"` |
| `signal` | string | `"approve"` · `"request-for-changes"` · `null` (on error) |
| `risk_level` | string | `"R1"`–`"R4"` for code reviews; `null` for standards reviews |
| `blocking_count` | integer | Findings with effective severity `"blocking"` (includes advisory-promoted) |
| `advisory_count` | integer | Findings with declared severity `"advisory"` (regardless of promotion) |
| `informational_count` | integer | Findings with effective severity `"informational"` |
| `suppressed_count` | integer | Findings suppressed via inline annotation |
| `confidence_threshold` | integer | The confidence threshold in effect for this invocation (default: 80) |
| `confidence_suppressed_count` | integer | Findings below `confidence_threshold`; excluded from all other counts |

`result: "error"` is distinct from `"fail"` — a service outage or cost-ceiling
breach must not be surfaced to engineers as a code quality failure.

### `checks`

One entry per check the skill performed. `check_id` is a stable identifier —
the join key for "which checks fail most often" trend queries. A check with
`result: "skipped"` ran but was not applicable (e.g., no companion policy file
exists — policy-consistency check was skipped, not failed).

| Field | Type | Description |
|-------|------|-------------|
| `check_id` | string | Stable identifier; never renamed or reused |
| `name` | string | Human-readable check name |
| `category` | string | See category values below |
| `result` | string | `"pass"` · `"fail"` · `"skipped"` |
| `duration_ms` | integer | Time this check took; may sum to more than `review.duration_ms` when checks run in parallel |
| `finding_ids` | string[] | IDs of findings produced by this check |

**Category values:** `quality` · `rr-standards-plugin` · `security` · `privacy` ·
`traceability` · `test-coverage` · `error-handling` · `version` · `policy-consistency` ·
`guide-staleness` · `duplication` · `historical-context`

**Note on `test-coverage`:** This category is about test plan conformance — verifying
that the tests in the PR implement what `spec/test-strategy.md` specified, and that
the strategy covers all in-scope requirements. It does not measure code coverage
percentages or invoke any coverage tool.

### `findings`

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique within this invocation (e.g., `"f-001"`) |
| `check_id` | string | Which check produced this finding |
| `severity` | string | Effective severity: `"blocking"` · `"advisory"` · `"informational"` |
| `declared_severity` | string | Severity as declared in the enforcement policy, before any advisory threshold promotion |
| `advisory_promoted` | boolean | `true` when `declared_severity` is `"advisory"` and the finding was promoted to `"blocking"` because the advisory count for this rule exceeded `advisory_threshold` |
| `category` | string | Same values as check categories |
| `rule_id` | string | Stable R-N identifier from the applicable standard; `null` if not rule-anchored |
| `standard_ref` | string | Path and version of the standard the rule belongs to (e.g., `"standards/api/rest.md@1.2.0"`); `null` if not applicable |
| `locations` | object[] | One or more file locations (see below); `[]` if finding cannot be anchored |
| `description` | string | What was found |
| `evidence` | string | The actual snippet of text or code that triggered the finding |
| `suggested_action` | string | Concrete remediation step |
| `suppressed` | boolean | `true` if suppressed by an inline annotation |
| `suppression_reason` | string | The stated reason from the suppression annotation; `null` if not suppressed |
| `confidence` | integer (0–100) | Likelihood this finding is a real, actionable issue (see Confidence Scoring) |
| `confidence_suppressed` | boolean | `true` if excluded from verdict counts because `confidence` < `confidence_threshold` |

**`locations` entry:**

| Field | Type | Description |
|-------|------|-------------|
| `file` | string | Repo-relative file path |
| `line_start` | integer | First line of the flagged range (1-indexed) |
| `line_end` | integer | Last line of the flagged range; equals `line_start` for single-line findings |

For multi-file findings (e.g., duplication), all locations are listed. The orchestrator
deduplicates cross-partition findings by canonical-sorting the `locations` array and
hashing the result alongside `rule_id`.

### `artifacts_loaded`

List of every standard, policy, and language guide loaded during the review.

| Field | Type | Description |
|-------|------|-------------|
| `path` | string | Repo-relative path to the artifact |
| `version` | string | Version declared in the artifact at load time |

### `exclusions`

Populated by code review skills only. Empty array for standards reviews.

| Field | Type | Description |
|-------|------|-------------|
| `file` | string | Repo-relative path of the excluded file |
| `pattern` | string | The exclusion pattern that matched |

### `observations`

Optional array of positive observations about the reviewed code or artifact. May be
empty. Not surfaced in verdict counts — purely informational.

| Field | Type | Description |
|-------|------|-------------|
| `category` | string | Same values as check categories |
| `description` | string | What was done well; specific and accurate, not generic praise |

---

## Advisory Threshold Promotion

When an enforcement policy sets `advisory_threshold: N` for a rule, the review skill
counts advisory findings for that rule across the entire review. If the count exceeds
N, every finding for that rule is promoted:

- `severity` → `"blocking"`
- `declared_severity` remains `"advisory"`
- `advisory_promoted` → `true`
- `verdict.blocking_count` increases by the number of promoted findings

`verdict.advisory_count` reflects the raw declared-advisory count regardless of
promotion, so that suppression rates and advisory volumes can be tracked in metrics
independently of threshold configuration.

---

## Confidence Scoring

After all findings are collected, each finding is independently scored 0–100 for
likelihood of being a real, actionable issue rather than a false positive.

**Scoring rubric** (provide verbatim to the scoring agent):

| Score | Meaning |
|-------|---------|
| 0 | Not confident. False positive that does not stand up to light scrutiny, or is a pre-existing issue not introduced by this PR. |
| 25 | Somewhat confident. Might be real but could not be verified. If stylistic, the relevant standard does not explicitly call it out. |
| 50 | Moderately confident. Likely real but a nitpick or low-frequency issue. Not among the most important findings in the PR. |
| 75 | Highly confident. Verified real, likely to be encountered in practice, important relative to the rest of the PR — or explicitly called out in the applicable standard. |
| 100 | Absolutely certain. Confirmed real, will happen frequently, evidence is direct. |

**Suppression:** Findings with `confidence` < `confidence_threshold` have
`confidence_suppressed: true` and are excluded from `verdict.blocking_count`,
`verdict.advisory_count`, and `verdict.informational_count`. They do not influence
the AI signal. They are retained in the `findings` array with their full detail so
suppression rates can be monitored in the metrics database.

`confidence_threshold` is configurable per repository (default: 80). Confidence
suppression is independent of developer-initiated `forge:suppress` annotations —
both may apply to the same finding simultaneously.

---

## Error Records

When `verdict.result` is `"error"`, `findings` is empty and `checks` reflects which
checks completed before the error. The `review` envelope is populated as far as
possible. An `error` object is added at the top level:

```json
"error": {
  "code":    "cost-ceiling-exceeded",
  "message": "Estimated cost of 4.20 USD exceeds configured ceiling of 2.00 USD"
}
```

Error codes: `"ai-service-unavailable"` · `"cost-ceiling-exceeded"` · `"invalid-input"`
