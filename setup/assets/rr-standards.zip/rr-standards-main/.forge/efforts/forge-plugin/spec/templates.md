← [Design Overview](README.md)

## Template Architecture

Templates are the starting point for all workflow artifacts. Skills copy and populate
templates rather than generating from scratch. This ensures structural consistency.

```
templates/
│
├── workflow/
│   ├── business-requirements.md     Structured BR document with FR/NFR sections
│   ├── technical-requirements.md    Structured TR document with NFR/constraints
│   ├── architecture-decision-record.md  ADR template (context, decision, consequences)
│   ├── test-strategy.md             Test strategy template (by level and risk)
│   ├── design-validation-report.md  Validation report (requirement × design matrix)
│   ├── implementation-plan.md       Task list with dependency and Jira fields
│   └── (none — runbook lives at docs/runbook/ in each project, not under .forge/)
│
├── spec/
│   ├── api-contract.yaml           OpenAPI 3.1 template with required sections
│   ├── storage-schema.md           Schema template (one section per storage type)
│   └── message-contract.md         Message contract template (envelope + payload)
│
├── review/
│   └── pr-review-report.md         PR review report (sections for each check type)
│
├── qa/
│   ├── test-execution-report.md    Scenario-by-scenario execution results (pass/fail/
│   │                               blocked) with links to test-strategy.md scenarios
│   ├── defect-report.md            Defect list with requirement traceability (each
│   │                               defect maps to a BR or TR, severity, and status)
│   └── sign-off.md                 QA sign-off record: scope, defect summary, open
│                                   items accepted by product, approver, date
│
├── project/
│   ├── project-claude-md.md        Template for a consuming project's CLAUDE.md.
│   │                               Used by init-repo to create or merge. Contains
│   │                               sections for: project context, standards references
│   │                               (with plugins/rr-standards/ paths), workflow config,
│   │                               available skills, active hooks, and project-specific
│   │                               rule overrides. See CLAUDE.md Template Design below.
│   └── settings.json               Base settings.json template for .claude/settings.json.
│                                   Defines minimum required permissions and hook
│                                   registrations for rr-core. Package-specific additions
│                                   are merged in by setup.sh. See Settings Architecture.
│
└── github-actions/
    ├── pr-review.yml               GitHub Actions workflow for automated PR review
    ├── rollout-monitor.yml         Workflow for deployment monitoring agent
    └── incident-response.yml       Workflow for incident diagnosis agent
```

### CLAUDE.md Template Design

`templates/project/project-claude-md.md` is the canonical structure for every consuming
project's CLAUDE.md. `init-repo` uses it as the source when creating a new CLAUDE.md
(greenfield) or as the merge guide when extending an existing one (brownfield — it adds
sections that are absent without touching sections that exist).

The template has six sections. The first two (`Project Context` and `Standards`) are
the highest-priority output of `init-repo`, because they are what makes standards
discoverable without any skill invocation:

```markdown
# [Project Name] — Claude Code Guide

## Project Context

**Service:** [service-name]
**Purpose:** [one-sentence description of what this service does]
**Technology Stack:** [primary language(s) and frameworks — e.g., "Java 21, Spring Boot 3"]
**Domain:** [business domain — e.g., "member rewards", "payments", "notifications"]

---

## Standards

This project follows organizational standards from rr-standards (`plugins/rr-standards/`).
All standards are readable directly — no skill invocation required.

### Always Active

- REST API design:       `plugins/rr-standards/standards/api/rest.md`
- Security (auth):       `plugins/rr-standards/standards/security/auth.md`
- Security (OWASP):      `plugins/rr-standards/standards/security/owasp.md`
- Security (secrets):    `plugins/rr-standards/standards/security/secrets.md`
- Privacy (PII):         `plugins/rr-standards/standards/privacy/pii-handling.md`
- Privacy (classify):    `plugins/rr-standards/standards/privacy/data-classification.md`
- Logging:               `plugins/rr-standards/standards/observability/logging.md`
- Version control:       `plugins/rr-standards/standards/version-control/git.md`

### Language-Specific

<!-- init-repo fills in the applicable entry based on the declared tech stack -->
<!-- Delete entries that do not apply -->
- Go:         `plugins/rr-standards/languages/go/`
- Java:       `plugins/rr-standards/languages/java/`
- TypeScript: `plugins/rr-standards/languages/typescript/`
- Python:     `plugins/rr-standards/languages/python/`
- Kotlin:     `plugins/rr-standards/languages/kotlin/`
- Swift:      `plugins/rr-standards/languages/swift/`

### Data Storage

<!-- Check which storage technologies this service uses -->
<!-- [ ] PostgreSQL:  `plugins/rr-standards/standards/storage/relational.md` -->
<!-- [ ] DynamoDB:    `plugins/rr-standards/standards/storage/document.md`   -->
<!-- [ ] OpenSearch:  `plugins/rr-standards/standards/storage/search.md`     -->
<!-- [ ] Redis:       `plugins/rr-standards/standards/storage/cache.md`      -->

### Messaging

<!-- Uncomment if this service produces or consumes events -->
<!-- - Contracts: `plugins/rr-standards/standards/messaging/contracts.md` -->
<!-- - Kafka:     `plugins/rr-standards/standards/messaging/kafka.md`     -->

---

## Workflow

**rr-standards version:** [version tag from `rr-standards-version` — e.g., `v1.2.0`]
**Packages installed:** [e.g., rr-core, workflow-full, implementation, review, qa]
**Default tier:** [full | lightweight]

Work artifacts live in `.forge/efforts/<work-id>/`. See `.forge/efforts/README.md` for all in-flight work.
Project-scoped documents live in `docs/` (ADRs at `.forge/spec/arch-decisions/`, runbook at
`docs/runbook/`).

### Forge Skills Available

<!-- Generated by setup.sh — do not edit manually -->
<!-- forge:effort, forge:status, forge:promote, forge:revert, forge:reopen, forge:help -->
<!-- forge:extract, forge:elaborate, forge:classify, forge:spec-api, forge:spec-storage -->
<!-- forge:spec-messaging, forge:adr, forge:spec-tests, forge:validate -->
<!-- forge:plan, forge:scaffold, forge:build-api, forge:build-repo, forge:build-messaging -->
<!-- forge:test, forge:commit, forge:update-plan -->
<!-- forge:review, forge:qa, forge:runbook, forge:diagnose, forge:remediate, forge:monitor -->
<!-- forge:jira-pull, forge:jira-push, forge:jira-resolve -->

### Hooks Active

- **SessionStart:** workflow context summary, standards path reminder
- **PreToolUse:** phase gate enforcement (blocks writes to plan/ and source code
  when discovery is present but not approved); approved artifact protection
- **PostToolUse:** workflow state updates, Jira sync queuing

---

## Project-Specific Rules

<!-- Add project-specific rules that extend or constrain the organizational standards. -->
<!-- Examples: -->
<!-- - This service stores PII. Apply R1 rigor to all authentication and data access work. -->
<!-- - All schema migrations require review by #platform-infra before merge. -->
<!-- - Capability flags are managed via LaunchDarkly — do not add conditional logic directly. -->

---

## Key Locations

| Purpose                  | Path                  |
|--------------------------|-----------------------|
| In-flight work index     | `.forge/efforts/README.md`         |
| Work item artifacts      | `.forge/efforts/<work-id>/`  |
| Architecture decisions   | `.forge/spec/arch-decisions/`         |
| Operational runbook      | `docs/runbook/`           |
| rr-standards             | `plugins/rr-standards/`          |
```

**What `init-repo` does with this template:**

- *Greenfield:* copies template, prompts engineer for the values in `[]` placeholders,
  fills in tech stack and domain, uncomments applicable storage and messaging sections,
  fills in the rr-standards version tag (from `rr-standards-version`), and writes the installed skills list.
- *Brownfield:* reads the existing CLAUDE.md. Adds any sections that are absent (e.g.,
  adds `## Standards` if not present, adds `## Key Locations` if not present). Never
  overwrites existing content in sections that are already present — those represent
  project customization.

---
