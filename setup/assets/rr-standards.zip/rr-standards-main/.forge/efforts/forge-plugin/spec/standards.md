← [Design Overview](README.md)

## Standards Architecture

Standards are markdown documents that define the organizational rules for a topic area.
They are language-agnostic. Language-specific implementation guides live in `languages/`
and reference the relevant standards.

### Standards Catalog

The following standards must exist. Those marked `[new]` do not currently exist and
must be created as part of this initiative.

```
standards/
│
├── api/
│   ├── rest.md               [rewrite] REST API design (resources, naming, status codes,
│   │                                   versioning, error responses, pagination)
│   ├── versioning.md         [new]     API versioning strategy and compatibility rules
│   └── contract-testing.md  [new]     Contract test requirements between services
│
├── storage/
│   ├── relational.md         [new]     PostgreSQL schema design (naming, normalization,
│   │                                   indexing strategy, migration standards)
│   ├── document.md           [new]     DynamoDB design (key design, access patterns,
│   │                                   single-table vs multi-table, capacity planning)
│   ├── search.md             [new]     OpenSearch index design (mapping, analyzers,
│   │                                   query patterns, index lifecycle)
│   └── cache.md              [new]     Redis usage patterns (key naming, TTL strategy,
│                                       cache-aside vs write-through, eviction policy)
│
├── messaging/                [new category]
│   ├── contracts.md          [new]     Message contract design (schema, envelope,
│   │                                   required fields, versioning strategy)
│   ├── kafka.md              [new]     Kafka-specific standards (topic naming, partition
│   │                                   strategy, consumer groups, offset management)
│   └── compatibility.md     [new]     Backward/forward compatibility rules for contracts
│
├── security/
│   ├── owasp.md              [new]     OWASP Top 10 checklist and mitigation requirements
│   ├── auth.md               [rewrite] Authentication and authorization patterns
│   ├── secrets.md            [new]     Secrets management (never in code, rotation,
│   │                                   approved secret stores)
│   └── input-validation.md  [new]     Input validation and sanitization requirements
│
├── privacy/                  [new category]
│   ├── data-classification.md [new]   Data classification tiers (public, internal,
│   │                                   confidential, restricted/PII)
│   ├── pii-handling.md       [new]    PII identification, minimization, masking,
│   │                                   and access control requirements
│   ├── retention.md          [new]    Data retention periods by classification
│   └── consent.md            [new]   Consent requirements for data collection and use
│
├── testing/
│   ├── strategy.md           [new]    How to design a test strategy (coverage by risk,
│   │                                   test pyramid, what belongs at each level)
│   ├── unit.md               [new]    Unit test standards (structure, naming, mocking)
│   ├── integration.md        [new]    Integration test standards (Testcontainers,
│   │                                   scope, shared state management)
│   ├── e2e.md                [new]    End-to-end test standards (scope, environments,
│   │                                   data management, flakiness rules)
│   └── contract.md           [new]    Contract test standards (consumer-driven,
│                                       provider verification)
│
├── observability/
│   ├── logging.md            [rewrite] Log structure, levels, required fields, PII rules
│   ├── metrics.md            [new]    Metric naming, labels, required service metrics
│   ├── tracing.md            [new]    Distributed tracing standards (span naming,
│   │                                   propagation, sampling)
│   ├── alerting.md           [new]    Alert design (signal vs noise, severity levels,
│   │                                   on-call routing)
│   └── runbooks.md           [new]    Runbook structure and required content
│
├── version-control/          [new category]
│   └── git.md               [new]    Branching strategy and naming conventions,
│                                     conventional commit message format, atomic commit
│                                     discipline (one logical change per commit, aligned
│                                     with task boundaries), git notes push/fetch
│                                     configuration, merge vs. rebase policy, branch
│                                     protection requirements, PR workflow integration.
│                                     Branch naming convention: <work-id>/<short-description>
│                                     in kebab-case (e.g. PROJ-1234/add-user-preference-
│                                     storage). The work-id prefix enables tooling to
│                                     correlate branches to .state.json without parsing
│                                     commit messages.
│
└── deployment/               [new category]
    ├── canary.md             [new]    Canary deployment configuration, traffic ramp
    │                                  schedule, success/failure metrics
    ├── rollback-criteria.md  [new]    Conditions that trigger automatic rollback,
    │                                  manual rollback process
    └── github-actions.md    [new]    CI/CD pipeline standards (required checks, approval
                                       gates, deployment workflow structure)
```

### Standards Document Structure

Every standard follows this structure (defined in `templates/standard-template.md`):

```markdown
# Standard: [Topic]

## Purpose
[What this standard governs and why it exists]

## Scope
[What it applies to; what it explicitly excludes]

## Requirements
[The actual rules — use MUST/SHOULD/MAY language]

## Rationale
[Why these requirements exist — the "because" behind the "what"]

## Examples
[Concrete right and wrong examples]

## Validation Checklist
[Machine-checkable list that skills use to validate compliance]

## Related Standards
[Links to related standards]
```

---
