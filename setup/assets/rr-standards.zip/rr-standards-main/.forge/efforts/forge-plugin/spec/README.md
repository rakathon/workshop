# Architecture: AI-Accelerated Software Development Process

> **Visual reference:** [Forge Workflow Diagram](../../../../docs/workflows/forge-workflow-diagram.md) —
> phase sequence, human gates, and per-phase Activities / Artifacts / Skills.

## Overview

This document describes the technical architecture for the tools, standards, skills, hooks,
and integrations needed to realize the requirements in `requirements/`. Everything runs
inside Claude Code sessions, with the repository as the system of record and GitHub Actions
as the CI/CD integration surface. No additional runtime infrastructure is required beyond
what a development team already has.

---

## Guiding Principles

**1. The repository is the source of truth.**
All workflow state, artifacts, and decisions live in version-controlled files. This provides
auditability, collaboration, and durability without an additional database or service.

**2. Standards are separate from skills.**
Skills reference standards documents; they do not embed them. When a standard changes,
every skill that references it benefits automatically. Standards are also usable without
invoking any skill.

**3. Skills do one thing.**
Each skill has a single, focused purpose. Composition is handled by the `using-skills`
orchestration layer. This keeps skills testable, replaceable, and extendable with
platform-specific variants.

**4. Discovery is co-evolutionary, not sequential.**
Requirements and design are not sequential phases — they are a single continuous discovery
process. Writing an API contract reveals missing requirements. Designing a schema reveals
conflicting constraints. This is not failure; it is how understanding is built. The two
artifact sets (requirements/ and spec/) co-evolve freely during discovery. The gate that
matters is before implementation: both must be approved together before code is written.
Ceremony scales with risk — full discovery is required for epics and initiatives; stories
and tasks can proceed directly to implementation.

**5. Validation is always active; ceremony scales with risk.**
Standards compliance, security, and privacy checks apply regardless of workflow tier.

**6. Humans remain in the loop at gates, not in the loop on mechanics.**
Phase transitions require explicit human approval. Mechanical work — generating drafts,
running checks, syncing state — is delegated to agents. Reviewers see pre-processed,
structured output, not raw changes.

**7. GitHub Actions is the CI/CD runtime.**
For automation that operates outside interactive sessions (PR review, rollout monitoring,
incident response), Claude runs in non-interactive mode within GitHub Actions workflows.

**8. Standards govern generation and evaluation — not just evaluation.**
The same standards document that `forge:review` uses to evaluate a PR is injected
into Claude's context when writing code. This eliminates the most expensive failure
mode: Claude generates code that violates a standard, a human or automated review
catches it, the engineer fixes it, and the cycle repeats. When standards are active
at generation time, violations are prevented rather than corrected. A standard written
once governs both the output quality and the review quality.

**9. Analytical skills run in isolated sub-agents; orchestration runs in the main session.**
Skills that consume large volumes of external data — PR diffs, PM documents, DataDog
logs, test result sets — run as worker sub-agents with fresh, isolated context windows.
This prevents context pollution: the diff content from a 50-file PR review does not
linger in the engineer's session and does not influence subsequent operations. Orchestrator
skills (workflow state management, routing, interactive artifact authoring) run in the
main session where they can see accumulated workflow context. The structured output
protocol (Skill Design Rule #3) is the contract between orchestrators and workers.

**10. Context quality is actively monitored, not just structurally protected.**
The worker/orchestrator split protects context quality for heavy operations by
giving each worker a fresh, isolated context window. But the orchestrator's own
context is not infinite. A PostToolUse hook monitors remaining context in the
main session and injects warnings at defined thresholds, giving engineers and
agents visibility into context state before quality silently degrades. Engineers
who receive a context warning should start a new session and invoke `forge:resume`
to continue from the recorded pause state.

**11. Agent autonomy has explicit, documented boundaries.**
Every skill that executes work on behalf of an engineer defines what it can do
without asking and what it must escalate. Agents do not ask for permission on
routine recoverable issues (bugs, missing error handling, broken imports) — this
erodes adoption. Agents do not make architectural decisions autonomously
(design artifact changes, new external dependencies, schema modifications) —
this erodes trust. The boundary between autonomous action and escalation is
documented in each skill's SKILL.md and is not left to the agent's judgment.

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│  Developer's Claude Code Session (Interactive)                      │
│                                                                     │
│  ┌─────────────┐  ┌──────────────────┐  ┌──────────────────────┐  │
│  │   Skills    │  │   Hooks          │  │   CLAUDE.md          │  │
│  │  (SKILL.md) │  │  (Shell scripts) │  │  (Always-loaded      │  │
│  │             │  │                  │  │   standards refs)    │  │
│  └──────┬──────┘  └───────┬──────────┘  └──────────────────────┘  │
│         │                 │                                         │
│         ▼                 ▼                                         │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │             Repository (Source of Truth)                    │   │
│  │  .forge/efforts/<id>/    docs/    standards/    skills/    templates/   │   │
│  └────────────────────────┬────────────────────────────────────┘   │
└───────────────────────────┼─────────────────────────────────────────┘
                            │
         ┌──────────────────┼──────────────────┐
         ▼                  ▼                  ▼
   ┌───────────┐     ┌───────────┐     ┌──────────────┐
   │   Jira    │     │  DataDog  │     │ GitHub       │
   │  (REST)   │     │  (REST)   │     │ Actions      │
   └───────────┘     └───────────┘     │              │
                                       │  ┌─────────┐ │
                                       │  │ Claude  │ │
                                       │  │ (--print│ │
                                       │  │  mode)  │ │
                                       │  └─────────┘ │
                                       └──────────────┘
```

### Agent Architecture

Within the developer's Claude Code session, skills are not all equal participants.
**Orchestrator skills** run directly in the session. **Worker skills** are spawned as
isolated sub-agents via the Claude Code Task tool, each with a fresh context window.

```
Developer's Claude Code Session (Orchestrator Context)
┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│  Orchestrator Skill                                              │
│  (forge:effort, forge:status, forge:commit, forge:plan, ...)       │
│      │                                                           │
│      │  spawn via Task tool                                      │
│      ▼                                                           │
│  ┌───────────────────────────────────────────────────────────┐   │
│  │  Worker Sub-Agent  (isolated context window)              │   │
│  │                                                           │   │
│  │  Receives:  input artifact path(s)                        │   │
│  │             relevant standards paths                      │   │
│  │             output schema                                 │   │
│  │                                                           │   │
│  │  Produces:  structured result (JSON or templated .md)     │   │
│  │             written to artifact path or returned inline   │   │
│  └───────────────────────────────────────────────────────────┘   │
│      │                                                           │
│      │  structured result                                        │
│      ▼                                                           │
│  Orchestrator writes artifact, updates .state.json               │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

**Multiple workers in parallel:** When `forge:review` encounters a large diff, the
orchestrating skill splits the changed files into groups and spawns one worker per
group concurrently. Each worker reviews its file group against the relevant standards
and returns a structured finding set. The orchestrator aggregates the findings into
a unified report. This addresses both context quality (each worker sees only the files
relevant to its task) and throughput (groups are reviewed in parallel).

**What workers receive (the context packet):**
- The path(s) to the input artifact(s) — the worker reads them itself
- The paths to the relevant standards documents — no inline embedding
- The output schema the worker must conform to
- The work-id for traceability — not the full workflow state

Workers do not receive the engineer's full session history, prior skill outputs, or
`.state.json`. They operate on exactly what they need and nothing more.

---

## Key Locations

| Purpose                  | Path                      |
|--------------------------|---------------------------|
| In-flight work index     | `.forge/efforts/README.md`         |
| Work item artifacts      | `.forge/efforts/<work-id>/`  |
| Architecture decisions   | `.forge/spec/arch-decisions/`         |
| Operational runbook      | `docs/runbook/`           |
| Codebase profile         | `docs/codebase/`          |
| rr-standards             | `plugins/rr-standards/`          |

---

## Detailed Design

| Area | Document |
|------|----------|
| Workflow infrastructure — directory structure, state model, tiering, phase gates | [workflow.md](workflow.md) |
| Skills — full catalog, design rules, orchestrator/worker classification, routing | [skills.md](skills.md) |
| Hooks — hook inventory and communication protocol | [hooks.md](hooks.md) |
| Standards — catalog of required standards and document structure | [standards.md](standards.md) |
| Templates — workflow templates and CLAUDE.md template design | [templates.md](templates.md) |
| Integrations — git metadata model, Jira, DataDog, GitHub Actions | [integrations.md](integrations.md) |
| Distribution — plugin marketplace model, package architecture, settings, platform workshops | [distribution.md](distribution.md) |
| Repository layout — marketplace.json, forge-plugin/, rr-standards-plugin/ structure | [repository-layout.md](repository-layout.md) |
| Implementation phasing — six delivery phases | [../plan/tasks.md](../plan/tasks.md) |
| Architectural decisions — ADR-001 through ADR-029 | [.forge/deployables/forge-plugin/spec/arch-decisions/README.md](../../../deployables/forge-plugin/spec/arch-decisions/README.md) |
