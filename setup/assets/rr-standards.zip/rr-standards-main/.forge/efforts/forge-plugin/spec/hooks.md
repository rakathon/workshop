← [Design Overview](README.md)

## Hooks Architecture

Hooks are shell scripts triggered at specific Claude Code lifecycle events. They enforce
constraints, inject context, and update state — work that should not require human
attention.

### Hook Inventory

```
hooks/
│
├── session-start/
│   ├── 01-inject-workflow-context.sh
│   │     Finds all active workflows in .forge/. For each in-progress workflow,
│   │     emits a summary of current phase, pending actions, and Jira sync status.
│   │     Keeps engineers oriented without requiring them to ask.
│   │
│   ├── 02-inject-standards-reminder.sh
│   │     Emits a brief reminder of the project's CLAUDE.md standards reference paths.
│   │     Prevents Claude from generating code before loading relevant standards.
│   │
│   └── 03-check-rr-standards-updates.sh
│         Lives in the GLOBAL PLUGIN (~/.claude/hooks/), not inside plugins/rr-standards/.
│         Runs before any project-level session-start hooks. Performs two checks:
│
│         1. Bootstrap check: if rr-standards-version exists in the project but
│            plugins/rr-standards/ does not, emits: "This project uses rr-standards
│            v1.2.0 but it has not been initialized. Run forge:update to
│            initialize before continuing." Does not block — always exits 0 so
│            the session opens and the engineer can run forge:update.
│
│         2. Version currency check: runs `git fetch` against the rr-standards
│            release remote in the background (non-blocking, detached process).
│            Reads the current rr-standards-version and fetches VERSIONS.json
│            from the remote to determine:
│            - If a newer minor/patch release exists within the current major:
│              emits a one-line notice: "rr-standards v1.3.0 is available —
│              run forge:update to apply." Does not block.
│            - If a new major version is available before its mandatoryAfter
│              date: emits a warning with the deadline: "rr-standards v2.0.0
│              is available. Required by 2026-05-01. Run forge:update --major
│              to review the changelog and adopt."
│            - If a major version's mandatoryAfter date has passed: BLOCKS the
│              session (exit code 2) with: "rr-standards v2.0.0 is mandatory
│              as of 2026-05-01. Run forge:update --major to upgrade before
│              continuing."
│
│         Does not run if no network is available (detects failure silently).
│         Does not fire during GitHub Actions runs.
│
├── user-prompt-submit/
│   └── 01-route-to-skills.sh
│         Detects intent in the user prompt (e.g., "start working on PROJ-1234",
│         "review this PR", "I'm done with requirements"). Suggests the appropriate
│         skill invocation before Claude responds. Does not block — surfaces the
│         recommendation as a pre-prompt injection.
│
├── pre-tool-use/
│   ├── inject-generation-standards.sh
│   │     Applies to: Write, Edit (source code paths only — not .forge/, docs/, hooks/)
│   │     Reads the project CLAUDE.md Standards section. Maps the target file path to
│   │     the relevant standards (by extension and path pattern):
│   │       - Any source file      → always injects: version-control/git.md,
│   │                                security/owasp.md, security/auth.md
│   │       - API paths            → also injects: api/rest.md
│   │       - Auth/token paths     → also injects: security/secrets.md
│   │       - Data access paths    → also injects: storage/relational.md (or equivalent)
│   │       - Message handlers     → also injects: messaging/contracts.md
│   │     Emits the applicable standards paths as a pre-write context injection:
│   │     "Before writing this file, read and apply: [paths]". Does NOT block —
│   │     always exits 0. This prevents violations at generation time rather than
│   │     catching them at review time, eliminating the generate→review→fix loop.
│   │
│   ├── 02-enforce-phase-gates.sh
│   │     Applies to: Write, Edit
│   │     Reads .state.json. Applies a single gate: if discovery is present in state
│   │     and not yet approved, blocks writes to plan/ and source code paths.
│   │     Writes to requirements/ and spec/ are NEVER blocked — these co-evolve
│   │     freely throughout discovery. Writes to validation/ are blocked until
│   │     discovery is approved. This hook does not create a requirements→design gate.
│   │     Exit code 2 with structured error message on violation.
│   │
│   └── 03-protect-approved-artifacts.sh
│         Applies to: Write, Edit (.forge/ paths only)
│         Prevents modification of artifacts that have been marked approved in
│         .state.json. If a phase is approved and a write to its artifact directory
│         is attempted, exits with code 2 and instructs the engineer to invoke
│         workflow/reopen to deliberately move the phase back to in_progress first.
│         Protects finalized requirements, validated designs, and approved plans
│         from accidental drift while still providing a clear, documented escape hatch.
│
└── post-tool-use/
    ├── 01-update-workflow-state.sh
    │     Applies to: Write, Edit
    │     After a skill writes a workflow artifact, detects which artifact was created
    │     and updates .state.json accordingly (e.g., marks requirements/business.md
    │     as present, updates the artifacts list for the current phase).
    │
    ├── 02-monitor-context.sh
    │     Applies to: all tool uses (PostToolUse)
    │     Reads remaining context percentage from the Claude Code hook environment.
    │     Emits a structured warning when context is depleting:
    │       - WARNING (35% remaining): "Context is 65% full. Consider wrapping up
    │         this session. If you need to continue, invoke forge:pause to record
    │         your position, then start a new session and run forge:resume."
    │       - CRITICAL (25% remaining): "Context is 75% full. Output quality may
    │         degrade. Invoke forge:pause now and resume in a fresh session."
    │     Debounced: emits at most once per 5 tool uses, unless severity escalates
    │     (WARNING → CRITICAL always emits immediately regardless of debounce).
    │     Does not block (always exits 0). Does not fire during GitHub Actions
    │     runs — context monitoring is for interactive sessions only.
    │
    └── 03-queue-jira-sync.sh
          Applies to: Write, Edit (on plan/ and .state.json)
          After plan updates or phase transitions, sets syncStatus to "pending" in
          .state.json. The jira-push skill reads this flag and syncs on next invocation.
          Does not call Jira directly — queues the intent, preserving session performance.
```

### Hook Communication Protocol

Hooks communicate with Claude through stdout. For `PreToolUse` hooks:
- Exit code `0`: allow the operation, optionally emit context to Claude
- Exit code `2`: block the operation, emit reason to Claude as a structured message

Blocked messages follow this format to ensure Claude presents them clearly:
```json
{
  "type": "phase_gate_violation",
  "blocked": true,
  "reason": "Requirements phase must be approved before design artifacts can be created.",
  "currentPhase": "requirements",
  "currentStatus": "draft",
  "requiredStatus": "approved",
  "nextAction": "Have the requirements reviewed and invoke /workflow promote to approve."
}
```

---
