← [Design Overview](README.md)

## Workflow Infrastructure

### Directory Structure

The repository contains three categories of spec artifacts, governed by the repository's
role(s). See **Repository Roles** below for how roles compose.

**Work-scoped** (`.forge/efforts/<work-id>/`): artifacts that belong to a specific piece of work.
Created when the work starts, updated as the work progresses, and left in place
permanently as a record of what was built, why, and how it was validated. Future
engineers and AI agents read these to understand intent before modifying code.

The `requirements/` and `spec/` subdirectories are part of a single co-evolutionary
discovery process. They do not have a sequential gate between them — spec work is
expected to reveal and refine requirements, and requirements changes are expected to
reshape the spec. Both are worked on freely and approved together as a unit before
implementation begins.

**Deployable-scoped** (`.forge/deployables/<name>/`): canonical, living artifacts for a
technical deployable unit. Updated incrementally as PRs merge. Never closed or archived —
these documents reflect the current state of the deployable for as long as the deployable exists.

**Product-scoped** (`.forge/products/<name>/`): canonical documentation for a PM-managed
business capability (e.g., Favorites, Sign Up, Referral Program). Present only in
product-role repositories. Spans multiple deployables across one or more repos.

```
.forge/
├── README.md                     # Master registry: one row per work item with ID, title,
│                                 # type, tier, risk, current phase, and status. Single
│                                 # entry point for engineers and agents to see all in-flight
│                                 # work without traversing subdirectories. Maintained by
│                                 # workflow/init, workflow/promote, and plan/update.
│                                 #
│                                 # Hierarchy is displayed via indentation — child items are
│                                 # listed beneath their parent with a leading →. Example:
│                                 #
│                                 #   | forge-plugin          | program     | R2 | planning     |
│                                 #   | → initiative-code-review | initiative  | R2 | discovery    |
│                                 #   | → → epic-ai-pr-review    | epic        | R2 | not_started  |
│                                 #   | → → epic-security-review | epic        | R3 | not_started  |
│                                 #   | → initiative-platform    | initiative  | R2 | not_started  |
│                                 #
│                                 # The directory stays flat; the registry is the structural view.
│                                 #
│                                 # Closed work items are removed from the registry when their
│                                 # phase reaches closed. They remain permanently in .forge/efforts/
│                                 # as the artifact record. The registry is the active-work view,
│                                 # not a historical ledger — this keeps it naturally bounded.
│                                 #
│                                 # In product-role repos, a second table beneath the work item
│                                 # registry lists PM products: name, PM owner, and status.
├── spec/                         # Cross-cutting technical spec artifacts. Not scoped to any
│   │                             # single work item — represent the current agreed technical
│   │                             # architecture across all deployables or the whole repository.
│   │                             # Work items contribute to these documents; they do not own them.
│   └── arch-decisions/           # Architecture Decision Records. Numbered sequentially
│       ├── README.md             #   regardless of which work item prompted them.
│       └── ADR-NNN-*.md          #   forge:adr writes here; forge:init creates the index.
│
│                                 # NOTE: `design/` is NOT a Forge-managed directory.
│                                 # In this organization "design" means UI/UX work.
│                                 # If a repository has UI/UX specifications, they live in
│                                 # `design/` alongside the Forge directories — Forge does not
│                                 # create or govern that directory.
├── deployables/                   # Present in deployable-role repos. One directory per
│   └── <deployable-name>/         #   technical deployable unit. See Deployable Canonical
│       └── ...                   #   Artifacts section below for full structure.
├── efforts/                     # Present in effort-role repos. All individual work items.
│   └── <work-id>/                # e.g., PROJ-1234 or initiative-name
│       ├── .state.json           # Machine-readable workflow state
│       ├── requirements/
│       │   ├── business.md       # Goal statement: what this work item must accomplish
│       │   └── technical.md      # Technical goals: NFRs, constraints, integration targets
│       │                         # These are the STATED GOALS for this work item — not a delta.
│       │                         # Discovery includes a gap analysis: compare these goals against
│       │                         # the current deployable/capability requirements to understand what
│       │                         # needs to change. The gap drives the design.
│       ├── spec/
│       │   ├── api/              # API contract files (OpenAPI YAML)
│       │   ├── storage/          # Storage schema files (one per store type)
│       │   └── messaging/        # Message contract files
│       │                         # Note: test strategy is NOT a work item artifact.
│       │                         # Tests verify capabilities, not delivery vehicles.
│       │                         # Test strategy lives in .forge/deployables/<name>/capabilities/<f>/
│       │                         # and is authored there during discovery. (ADR-028)
│       ├── validation/
│       │   └── report.md         # Design validation report (gated artifact)
│       └── plan/
│           ├── tasks.md          # Implementation task list
│           ├── initiatives.md    # (optional) Roadmap or initiative breakdown — valid for
│           │                     #   program-type work items; any descriptive name is fine
│           └── jira-sync.json    # Jira synchronization state
└── products/                     # Present in product-role repos. One directory per PM product.
    └── <product-name>/           # e.g., favorites, sign-up, referral-program
        ├── README.md             # Overview: PM owner, target users, current status
        ├── strategy.md           # Vision, goals, OKRs, success metrics
        ├── requirements/
        │   └── business.md       # Cross-deployable PM requirements
        ├── roadmap.md            # PM roadmap
        ├── deployables.md         # Which deployables implement this product, with repo cross-refs
        └── artifacts/
            └── README.md         # Generated artifacts (analysis, prototypes, outputs)
```

For **spike** work items the standard requirements/spec/plan tree is replaced by a
single findings artifact — spikes produce knowledge, not code:

```
    └── <work-id>/                # (spike)
        ├── .state.json
        └── findings/
            └── findings.md       # Investigation results, recommendation, and links to
                                  #   any work items spawned from the findings
```

```
docs/
├── runbook/                      # Operational runbook — one file per capability area.
│   ├── README.md                 #   Index of all playbooks with one-line summaries.
│   └── <capability-area>.md         #   forge:runbook creates or updates the area file
│                                 #   and regenerates the index. forge:diagnose reads
│                                 #   the index then the relevant area file(s).
│                                 #   Cross-cutting procedures go in common/.
└── codebase/                     # Brownfield codebase profile. Produced by forge:map
    ├── STACK.md                  #   and referenced from the project CLAUDE.md.
    ├── ARCHITECTURE.md           #   Updated when significant architectural changes
    ├── CONVENTIONS.md            #   occur. Not work-scoped — covers the whole project.
    ├── INTEGRATIONS.md
    └── CONCERNS.md
```

**Traceability between scopes:** An ADR records the work-id that prompted it in its
metadata (`Created by: PROJ-1234`). The work-id's `.state.json` records the ADR numbers
it produced in its `artifacts` list. This means you can navigate in both directions:
from a work-id to its ADRs, and from an ADR back to the work that created it.

### Repository Roles

A repository may serve one or more roles. `forge:init` writes a `repo_types` array to
`.forge/version` to describe the roles the repository fills. Roles are not mutually
exclusive — a mono-repo may serve all three simultaneously.

| Role | Meaning | Directories present |
|------|---------|-------------------|
| `deployable` | The repo contains one or more technical deployable units | `.forge/deployables/` |
| `project` | The repo coordinates work items (epics, initiatives, programs) | `.forge/efforts/` |
| `product` | The repo hosts PM product documentation spanning multiple deployables | `.forge/products/` |

```
repo_types = ["deployable"]                        # default for a single-service repo
repo_types = ["effort"]                          # work item coordination repo (ADR-027)
repo_types = ["product"]                          # PM product documentation repo
repo_types = ["product", "effort"]               # PM product docs + cross-deployable work items
repo_types = ["deployable", "effort"]             # deployable repo that also hosts cross-repo work
repo_types = ["deployable", "product", "effort"]  # all three — full mono-repo
```

Migration: repositories initialized before ADR-029 carry a `repo_type` scalar. The old
value `product` (meaning an engineering deliverable) maps to `["deployable"]`. The old
value `project` maps to `["effort"]`. Both forms are accepted by tooling until the
forge-init epic implements migration.

### Repository Type Variations

The `.forge/` directory does not always live at the repository root. Its placement
mirrors the scope of what it governs, and that scope depends on the shape of the
repository.

**Single-deployable repository** (the default): `.forge/` lives at the root. One
deployable deployable, one spec tree. `repo_types = ["deployable"]`.

**Monorepo with multiple independent deployables**: `.forge/` is replicated per deployable,
sitting alongside each deployable's source. Each deployable governs its own work items,
ADRs, and runbook independently. A root-level `.forge/` may exist for cross-cutting
concerns that span multiple deployables.

```
repo-root/
├── .forge/                        # Cross-cutting work (spans multiple deployables)
│   └── efforts/
├── deployable-a/
│   ├── src/
│   ├── .forge/                    # Work scoped to deployable-a
│   │   ├── README.md
│   │   └── efforts/
│   └── docs/
└── deployable-b/
    ├── src/
    ├── .forge/                    # Work scoped to deployable-b
    │   ├── README.md
    │   └── efforts/
    └── docs/
```

**Monolithic application with multiple modules** (e.g., a mobile app with distinct
capability areas): `.forge/` lives at the root, but `projects/` items are prefixed or
grouped to indicate the module they touch. The work-id itself carries the module
context (e.g., `payments-PROJ-1234`), or a module-level subdirectory is added inside
`projects/` when a module has enough volume to warrant it:

```
.forge/
├── README.md                     # Registry covering all modules
└── efforts/
    ├── payments/                 # Module-level grouping (optional, for high-volume modules)
    │   └── PROJ-1234/
    ├── loyalty/
    │   └── PROJ-1235/
    └── PROJ-1236/                # Module-agnostic or cross-module work at root of projects
```

**Product + project mono-repo** (a repository that hosts both PM product documentation
and the cross-deployable work items that deliver those products):
`repo_types = ["product", "effort"]`

```
.forge/
├── README.md                     # Work item registry + PM product index
├── efforts/                     # Work items (epics, initiatives, programs)
│   └── <work-id>/
└── products/                     # PM product documentation
    ├── favorites/
    ├── sign-up/
    └── referral-program/
```

**The rule:** `.forge/` lives at the level that matches the deployment and ownership
boundary. If a team owns a deployable end-to-end, `.forge/` lives at the root of their
deployable. If multiple teams share a monorepo, each team's deployable has its own `.forge/`.
The internal structure of `.forge/` — `README.md`, `projects/`, `deployables/`, `products/`
— is identical regardless of where it lives; only the directories present vary by role.

### Multi-Repository Projects

Some initiatives require coordinated changes across more than one product repository.
Per ADR-027, project-level artifacts for these initiatives live in a **project
repository** — a repository whose primary purpose is hosting cross-repo project
artifacts, not source code. The `.forge/` structure inside a effort repository is
identical to any other repository; the distinction is purpose, not layout.

**Repository type marker**

`forge:init` writes a `repo_type` field to `.forge/version` so tooling can distinguish
repository roles without inferring from content:

```
repo_type = product    # default for all product repositories
repo_type = effort    # effort repository per ADR-027
```

The field is written at init time. All existing repositories without this field are
treated as `product`.

**Cross-repo parent reference format**

The `parentId` field in `.state.json` currently holds a bare work item ID, implicitly
scoped to the same repository. To support cross-repo parent-child relationships, a
`repo:` prefix signals that the parent lives in a different repository:

```
Same-repo parent:   "parentId": "auth-platform-initiative"
Cross-repo parent:  "parentId": "repo:org/efforts-repo/auth-platform-initiative"
```

Bare IDs remain valid for same-repo parents — no migration required for existing items.
The `childIds` array follows the same convention: bare IDs for same-repo children,
`repo:`-prefixed for cross-repo children.

> **Open question (deferred to forge-init epic):** Resolution mechanism — how does
> tooling resolve a `repo:` reference to a filesystem path or clone URL? Candidates
> include a `.forge/project-repos.json` registry file, a CLAUDE.md directive, or an
> environment variable. This is not decided here.

**Deployable artifact project attribution**

When a discovery skill creates or amends a deployable canonical artifact
(`.forge/deployables/<deployable>/requirements/*.md`, etc.) as part of a cross-repo project,
that artifact must carry machine-readable attribution identifying the originating
project. This is satisfied by a `effortRef` field in the work item's `.state.json`,
populated at initialization when the item belongs to a cross-repo project:

```json
"effortRef": "repo:org/efforts-repo/auth-platform-initiative"
```

Discovery skills that write to deployable canonical artifacts read `effortRef` from state
and include it in each amendment block they write. This makes traceability navigable
by tooling without requiring prose parsing.

Example amendment stamp:

```markdown
### BR-23: ... *(project: auth-platform-initiative @ org/efforts-repo)*
```

`effortRef` is `null` for work items that are not part of a cross-repo project.

**Registry behavior for cross-repo items**

The master registry (`.forge/efforts/README.md`) is a per-repository active-work view. It
shows only work items that live in this repository. A cross-repo `parentId` in a local
`.state.json` is navigable by tooling but does not produce a registry row — the parent
is displayed only in the effort repository's own registry. This keeps the registry
bounded and avoids dual-maintenance.

The indented hierarchy display in the registry reflects only the local portion of the
hierarchy. A top-level epic whose parent initiative lives in a effort repository
appears at the root level of the local registry with its `parentId` visible in
`.state.json` for those who navigate to the full state.

> **Open question (deferred to forge-init epic):** Project repository discovery — how
> does a deployable repository surface which effort repositories it participates in, so
> that engineers can navigate upstream without prior knowledge? Not decided here.

> **Open question (deferred to forge-init epic):** Cross-repo reference format stability —
> the `repo:org/repo/work-item-id` format is currently coupled to the GitHub repository
> location. This creates two unresolved problems: (1) resolution — tooling must map a
> GitHub path to a filesystem location or clone URL without assuming a fixed directory
> layout; (2) identity stability — when a project migrates from a private repository to
> a shared one (per ADR-027), all `repo:` references pointing at the old location must
> be updated or redirected. Until these are resolved, the `repo:` format should be
> treated as provisional. The forge-init epic must decide the canonical identity scheme
> for a effort repository before the format is considered settled.

> **Open question (deferred to forge-init epic):** Migration mechanics — when a
> project moves from a private dedicated repository to a shared effort repository,
> all `repo:` references pointing to the old location must remain valid or be updated
> atomically. The migration path depends on the identity scheme resolved above and is
> not specified here.

---

For story/task work, `plan/tasks.md` is the only artifact created by default. The
`requirements/`, `spec/`, and `validation/` directories are not created automatically
but are fully available if the engineer chooses to use them. If a story turns out to
warrant a spec phase — because it is more complex than anticipated, or because it
touches a critical area — the engineer invokes the relevant spec skills and those
artifacts are created on demand. The workflow state tracks whichever phases were used,
regardless of tier.

For spike work, `findings/findings.md` is the only artifact. The requirements/spec/plan
tree is not created. A spike that exceeds its `timebox` date without approved findings is
flagged by the session-start hook as overdue.

### Artifact Size Limit and Flexible Expansion

All artifact files have a target maximum of 500 lines. Files that exceed this limit degrade
context quality when loaded as skill input — partial reads miss critical content and context
windows fill faster.

**The expansion pattern:** Any single-file artifact (`<name>.md`) may be converted to a
same-named directory (`<name>/`) when it approaches 500 lines. The directory form follows
these rules:

- A `README.md` inside the directory is the index and entry point: it summarises the
  artifact's purpose and links to subdocuments.
- Content splits into subdocuments named by logical area (wave, deployable, capability area,
  requirement domain, etc.).
- The decision to expand is made at authoring time by the generating skill or engineer.
- **Skills must handle both forms**: a file at `<path>.md` or a directory at `<path>/`
  with `<path>/README.md` as the entry point. A skill that reads `plan/tasks.md` must
  also work when the task list has been expanded to `plan/tasks/README.md` +
  `plan/tasks/wave-1.md`, etc.

This applies to all work-scoped artifacts: `plan/tasks.md`, `requirements/business.md`,
`requirements/technical.md`, `spec/test-strategy.md`, `validation/report.md`,
`verification/report.md`, and QA artifacts under `qa/`.

**Project-scoped artifacts are handled differently:**
- `docs/runbook/` is a directory from the outset — it accumulates playbooks across every
  capability that ships and has no natural single-work-item scope.
- `.forge/efforts/README.md` (the master registry) is bounded by removing closed work items from
  the registry when closed, not by splitting the file.

### Project-to-Deployable Lifecycle

Work items in `.forge/efforts/` and canonical artifacts in `.forge/deployables/` serve
different purposes and have different lifecycles. Understanding the relationship between
them is essential for knowing where to create and find documentation.

**The core principle: goal statement vs. current state**

A work item's requirements are a **goal statement** — what we need to accomplish with
this work item, written as a focused, in-scope view of the desired outcome. Engineers
write these during discovery to give the team a single place to see what the work item
is trying to achieve.

The deployable and capability directories capture the **current state** — the accumulated
specification of what the deployable or capability does right now, updated at each PR merge
to reflect what has been delivered. Work items are closed when done; deployable and capability
artifacts are maintained indefinitely.

**Gap analysis connects the two.** During discovery, the team compares the work item's
goal statement against the current deployable/capability requirements to understand what needs
to change. That comparison — the gap — drives the design. The gap is not stored as a
separate document; it is the design work itself. After implementation ships, the
deployable/capability requirements are updated to reflect the delivered state, and the work
item requirements remain as a permanent record of what the team set out to accomplish.

**What is never a work item artifact: test strategy**

Test plans and test strategies belong exclusively in the deployable/capability canonical
directory. Work items are delivery vehicles — they deliver code that implements
requirements. You do not test a project; you test a capability. Test strategy is authored
directly in `.forge/deployables/<name>/capabilities/<capability>/test-strategy.md` during the
discovery phase of the work item that creates or modifies the capability. Validation reads
the test strategy from the deployable/capability directory, not from the work item.

---

**Scenario 1: Work item creates a new deployable**

*Discovery phase:*
- Work item goal statement written to `.forge/efforts/<id>/requirements/` — what
  we need the deployable to do when this work item is done
- `forge:deployable` creates `.forge/deployables/<name>/` with empty canonical stubs
- Gap analysis: work item goals are compared to current deployable state (empty for a new
  deployable, so goals directly become the initial deployable requirements)
- Design artifacts (API contracts, storage schemas, messaging contracts) written to
  `.forge/efforts/<id>/spec/`
- `.state.json` updated: `deployables: ["<name>"]`
- Test strategy authored directly in `.forge/deployables/<name>/test-strategy.md`

*At each PR merge:*
- `forge:deployable-update` reads the work item goals and updates the deployable canonical
  requirements to reflect what was delivered

*At work item close:*
- `.forge/efforts/<id>/` remains permanently — the work item requirements record
  what the team set out to accomplish
- `.forge/deployables/<name>/` reflects delivered state and is maintained going forward

---

**Scenario 2: Work item creates a new capability of an existing deployable**

*Discovery phase:*
- Work item goal statement written to `.forge/efforts/<id>/requirements/` — what
  we need the capability to do when this work item is done
- `forge:capability` creates `.forge/deployables/<name>/capabilities/<capability>/`
- Gap analysis: work item goals are compared to current capability state (empty for a new
  capability, so goals directly inform the initial capability requirements)
- Design artifacts written to `.forge/efforts/<id>/spec/`
- `.state.json` updated: `deployables: ["<name>"], capabilities: ["<name>/<capability>"]`
- Test strategy authored directly in
  `.forge/deployables/<name>/capabilities/<capability>/test-strategy.md`

*At each PR merge:*
- `forge:deployable-update` updates the capability canonical requirements to reflect what
  was delivered

---

**Scenario 3: Work item adds to or updates an existing capability**

*Discovery phase:*
- Work item goal statement written to `.forge/efforts/<id>/requirements/` — what
  we need to accomplish with this update. This is the focused view of the work item's
  intent, not a copy of the full capability spec.
- Gap analysis: work item goals are compared to current capability requirements to
  identify what needs to change. This analysis drives the design.
- Design artifacts written to `.forge/efforts/<id>/spec/`
- `.state.json`: `deployables: ["<name>"], capabilities: ["<name>/<capability>"]`
- Test strategy updated directly in the existing capability canonical directory

*At each PR merge:*
- `forge:deployable-update` updates the existing capability canonical requirements to
  reflect the delivered state. The actual delta is the git diff on the deployable
  requirements files — not a separately stored document.

---

**What lives where — summary**

| Artifact | Location | Purpose |
|---|---|---|
| Work item requirements | `.forge/efforts/<id>/requirements/` | Goal statement — what this work item must accomplish. Permanent record of intent. |
| Work item design | `.forge/efforts/<id>/spec/` | Design artifacts produced to achieve those goals (API contracts, schemas, message contracts). Permanent record. |
| Deployable canonical requirements | `.forge/deployables/<name>/requirements/` | Current complete requirements — updated at each PR merge to reflect delivered state. |
| Deployable canonical design | `.forge/deployables/<name>/spec/` | Current architecture — updated at each PR merge. |
| Capability canonical requirements | `.forge/deployables/<name>/capabilities/<f>/requirements/` | Current complete capability requirements — updated at each PR merge. |
| Capability canonical design | `.forge/deployables/<name>/capabilities/<f>/spec/` | Current capability design — updated at each PR merge. |
| Capability test strategy | `.forge/deployables/<name>/capabilities/<f>/test-strategy.md` | Authored during discovery, maintained for the life of the capability. |
| ADRs | `.forge/deployables/<name>/spec/arch-decisions/` | Permanent — never edited after acceptance. |
| Implementation plan | `.forge/efforts/<id>/plan/tasks.md` | Permanent record. |
| Validation report | `.forge/efforts/<id>/validation/report.md` | Permanent record. |
| PM product requirements | `.forge/products/<name>/requirements/` | Cross-deployable PM requirements — maintained for the life of the product. Product-role repos only. |
| PM product strategy | `.forge/products/<name>/strategy.md` | Vision, goals, OKRs, success metrics. Product-role repos only. |

---

### Workflow State Model

`.forge/efforts/<id>/.state.json` is the machine-readable state. Hooks read this to enforce
phase gates. Skills write to it when phases are completed or approved.

```json
{
  "id": "PROJ-1234",
  "title": "User preference opt-out",
  "type": "program | initiative | epic | story | task | spike",
  "tier": "full | lightweight",
  "risk": "R1 | R2 | R3 | R4",
  "parentId": null,
  "childIds": [],
  "effortRef": null,
  "deployables": [],
  "capabilities": [],
  "businessProducts": [],
  "timebox": null,
  // deployables: identifiers of the technical deployables this work item contributes to (e.g. ["forge-plugin"]).
  //   Set during discovery as contributing deployables are identified. Empty is valid at creation.
  // capabilities: identifiers of specific capabilities within those deployables, in "<deployable>/<capability>"
  //   form (e.g. ["forge-plugin/forge-review"]). Set during discovery. Empty for work items
  //   that touch only deployable-level concerns with no specific capability scope. (ADR-028)
  // businessProducts: (optional) identifiers of PM products this work item contributes to (e.g. ["favorites"]).
  //   Informational only — does not drive phase gate logic. Supports navigation from work item
  //   to PM product documentation. Only meaningful when a product-role repo is in scope.
  "currentPhase": "discovery | validation | planning | implementation | verification | review | qa | deployment | operations | investigation | findings",
  "pause": {
    "active": false,
    "pausedAt": null,
    "note": "Stopped mid-task after completing TASK-002. TASK-003 (implement preference storage) is next.",
    "nextAction": "forge:build-repo — implement preference storage against spec/storage/preferences.sql"
  },
  "phases": {
    "discovery": {
      "status": "not_started | in_progress | approved",
      "approvedBy": null,
      "approvedAt": null,
      "note": "Requirements and design co-evolve freely within this phase. Neither is gated on the other. Both must be complete before this phase can be approved. Design Validation (Phase 2) runs on the completed discovery artifacts before forge:promote is invoked — the validation report is an input to the approval decision, not a post-approval activity. Approval unlocks planning and implementation.",
      "artifacts": {
        "requirements": {
          "business": "absent | draft | present",
          "technical": "absent | draft | present"
        },
        "spec": {
          "api": "absent | draft | present",
          "storage": "absent | draft | present",
          "messaging": "absent | draft | present"
          // testStrategy is intentionally absent from work item artifacts.
          // Test strategy lives in the deployable/capability canonical directory and is
          // authored there directly during discovery. Validation reads it from
          // .forge/deployables/<name>/capabilities/<f>/test-strategy.md, derived from
          // the capabilities[] field. (ADR-028)
        },
        "adrsCreated": [".forge/spec/arch-decisions/ADR-003-*.md"]
      }
    },
    "validation": {
      "status": "not_started | in_progress | passed | passed_with_concerns | failed",
      "artifacts": ["validation/report.md"]
    },
    "planning": {
      "status": "not_started | in_progress | complete",
      "artifacts": ["plan/tasks.md"]
    },
    "implementation": {
      "status": "not_started | in_progress | complete",
      "completedTasks": [
        { "id": "TASK-001", "commitSha": "a3f9b12", "wave": 1, "type": "auto" }
      ],
      "remainingTasks": ["TASK-002", "TASK-003"],
      "checkpoint": {
        "activeSkill": "implement/api",
        "lastCompletedStep": 3,
        "updatedAt": "2026-01-15T14:22:00Z"
      }
    },
    "verification": {
      "status": "not_started | in_progress | passed | passed_with_gaps",
      "artifacts": ["verification/report.md"]
    },
    "investigation": {
      "status": "not_started | in_progress | complete",
      "timebox": "2026-03-19",
      "artifacts": ["findings/findings.md"]
    },
    "findings": {
      "status": "not_started | in_progress | approved",
      "approvedBy": null,
      "approvedAt": null,
      "spawnedWorkItems": [],
      "artifacts": ["findings/findings.md"]
    }
  },
  "environments": {
    "preProd": {
      "url": "https://api-staging.your-org.com",
      "authEnvVar": "PREPROD_API_KEY"
    }
  },
  "jira": {
    "key": "PROJ-1234",
    "baseUrl": "https://your-org.atlassian.net",
    "epicKey": null,
    "lastSynced": null,
    "syncStatus": "never | in_sync | conflict | pending",
    "conflictDetails": null
  },
  "createdAt": "2026-01-01T00:00:00Z",
  "updatedAt": "2026-01-01T00:00:00Z"
}
```

### Tiering Logic

Tier is set at initialization and drives which phases are required and which hooks are
active. The engineer selects the tier, guided by the `init` skill.

| Phase                          | Full Tier (Program/Initiative/Epic) | Spike Tier                    | Story/Task Tier               |
|--------------------------------|-------------------------------------|-------------------------------|-------------------------------|
| Discovery (requirements+spec)| Required + human approval           | Not applicable                | Optional (skipped by default) |
| Design Validation              | Required — runs before Discovery Gate | Not applicable              | Optional (skipped by default) |
| Planning                       | Required                            | Not applicable                | Optional (tasks.md only)      |
| Investigation                  | Not applicable                      | Required                      | Not applicable                |
| Implementation                 | Required                            | Not applicable                | Required                      |
| Implementation Verification    | Required (R1/R2); Optional (R3/R4)  | Not applicable                | Optional                      |
| PR Review                      | Required (AI + human for R1/R2)     | Optional                      | Required (AI + human for R1/R2)|
| QA                             | Required                            | Not applicable                | Required                      |
| Runbook                        | Required (R1/R2)                    | Not applicable                | Optional                      |
| Findings Review                | Not applicable                      | Required + human approval     | Not applicable                |

Within the Discovery phase for full-tier workflows, requirements and spec are worked
on concurrently without a gate between them. The phase as a whole is approved once both
the requirements and spec artifacts are judged complete — a single `workflow/promote`
invocation covering both. This is not a sequential requirements-then-spec process; it
is a single co-evolutionary process that produces two artifact sets.

### Task Type and Wave Annotations in plan/tasks.md

Every task in `plan/tasks.md` carries two annotations generated by `forge:plan`:

**Type** — governs how an executing agent handles the task:
- `[auto]` — execute autonomously; no pause required
- `[checkpoint]` — pause before proceeding; engineer must confirm or decide
- `[tdd]` — follow RED→GREEN→REFACTOR discipline; do not skip the failing-test step
- `[manual]` — a step the agent cannot execute (e.g., run a database migration); provide instructions and wait

**Wave** — the dependency group the task belongs to. Tasks in the same wave are
independent and can execute in parallel. Wave N+1 does not begin until wave N is
complete. `forge:plan` assigns wave numbers based on dependency analysis.

Example `plan/tasks.md` entry:
```
- [ ] [auto][wave:1] Implement user preference repository against storage/preferences.sql (TASK-001)
- [ ] [auto][wave:1] Write unit tests for PreferenceRepository (TASK-002)
- [ ] [checkpoint][wave:2] Implement preference API endpoint — confirm auth middleware approach before proceeding (TASK-003)
- [ ] [tdd][wave:2] Write integration tests for preference endpoint (TASK-004)
```

The `[checkpoint]` type is used when the task description alone is insufficient for
autonomous execution — typically when the engineer made a decision during discovery
that the executor needs to confirm it has understood correctly, or when a task touches
a known ambiguous area. Checkpoint tasks do not require re-running `forge:promote`;
they are lightweight confirmations within the implementation flow.

### Phase Gate Enforcement

There is one meaningful gate in the full-tier workflow: **implementation cannot begin
until discovery is approved**. There is no gate between requirements and spec —
they are worked on concurrently within the discovery phase.

The `PreToolUse` hook enforces this by inspecting the write target path:

- Writes to `requirements/` or `spec/`: **always allowed** during discovery. Spec
  work may freely update requirements, and requirements changes may reshape the spec.
- Writes to `validation/`: allowed once discovery is `in_progress` (discovery artifacts
  exist but approval is not yet required). Validation runs before `forge:promote` so
  that the validation report can inform the approval decision.
- Writes to `plan/` or source code: blocked if discovery is present in `.state.json`
  and not yet `approved`.

For story/task workflows, no gates are active by default. If the engineer opts into
discovery for a story, the same gate applies once discovery is added to state — they
cannot begin writing implementation code until `workflow/promote` has approved the
combined requirements + spec artifacts they chose to produce.

For spike workflows, the only gate is `findings` approval before the spike can be closed.
Source code writes are permitted — a spike may produce exploratory or prototype code as
part of the investigation (trying different approaches, going far enough down an
implementation path to produce a confident estimate). This code is not production-bound;
PR review is optional, not required. An overdue timebox does not block the investigation
— it emits a warning.

---
