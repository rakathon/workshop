← [Design Overview](README.md)

## Skills Architecture

### Product: Forge

The skills defined in this architecture are shipped as a single product named **Forge**.
Every skill registers a slash command prefixed with `forge:`, making the product boundary
visible and unambiguous. Engineers type `forge:commit`, not `/implement-commit`. The
prefix makes it immediately clear that a command is part of this toolset, and keeps
all Forge commands grouped together in Claude Code's command palette.

**Command naming principle:** Commands are named for what the engineer intends to do,
not for the directory group the skill lives in. The directory structure (`skills/implement/
commit/`) is for development organization. The command name (`forge:commit`) is for the
engineer's mental model. Group names are dropped when the product prefix makes them
redundant.

**SKILL.md frontmatter** for every Forge skill:
```markdown
---
name: forge:<command>
description: One-line description of what this command does
---
```

### Command Quick Reference

> **Global plugin command** (`forge:init`) is installed in `~/.claude/` and available
> in every project session. All other commands are installed per-project by `forge:init`.
> Plugin updates are handled by Claude Code's built-in plugin update mechanism — there
> is no `forge:update` command.

| Command | What it does |
|---------|-------------|
| `forge:effort` | Start a new workflow for a work item |
| `forge:init` | ★ One-time project setup (CLAUDE.md, settings, hooks); standards bundled with plugin |
| `forge:status` | Show current phase, pending actions, and Jira sync state |
| `forge:promote` | Approve the current phase via the defined ritual |
| `forge:reopen` | Move an approved phase back to in-progress |
| `forge:revert` | Revert a task, phase, or work-id at the semantic level |
| `forge:help` | Recommend the right next command based on current state (`using-skills`) |
| `forge:check-reqs` | Check requirements for completeness and testability |
| `forge:jira-pull` | Initialize workflow from an existing Jira ticket |
| `forge:jira-push` | Push current state to Jira |
| `forge:jira-resolve` | Resolve a Jira ↔ repo conflict |
| `forge:extract` | PM document → structured business requirements |
| `forge:elaborate` | Business requirements → technical requirements |
| `forge:classify` | Assign R1–R4 risk classification |
| `forge:spec-api` | Design REST API contract (OpenAPI) |
| `forge:spec-storage` | Design storage schema |
| `forge:spec-messaging` | Design message contract |
| `forge:adr` | Record an architecture decision |
| `forge:spec-tests` | Design high-level test strategy |
| `forge:validate` | Full cross-reference design validation |
| `forge:plan` | Generate implementation task list from validated design |
| `forge:update-plan` | Mark task complete, record commit SHA, queue Jira sync |
| `forge:scaffold` | Scaffold a new project or module by archetype |
| `forge:build-api` | Implement API endpoints from contract |
| `forge:build-repo` | Implement data access layer from schema |
| `forge:build-messaging` | Implement message producers/consumers from contract |
| `forge:test` | Write unit, integration, and E2E tests |
| `forge:commit` | Create a well-formed commit with git note |
| `forge:map` | Analyze existing codebase; produce structured profile in `docs/codebase/` |
| `forge:pause` | Record session pause state and next action for handoff |
| `forge:resume` | Restore from recorded pause state and surface next action |
| `forge:review` | PR review; all checks by default; `--checks <name,...>` for a targeted subset |
| `forge:review-security` | Alias: `forge:review --checks security` (named for CI status check targeting) |
| `forge:review-privacy` | Alias: `forge:review --checks privacy` (named for CI status check targeting) |
| `forge:simplify` | Post-approval simplification: extract shared logic, reduce nesting, improve naming without changing behaviour |
| `forge:qa` | Run test plan against pre-production environment |
| `forge:runbook` | Generate or update the operational runbook |
| `forge:diagnose` | Diagnose a production incident using DataDog + runbook |
| `forge:remediate` | Execute runbook remediation steps autonomously |
| `forge:monitor` | Monitor rollout signals and recommend proceed/rollback |
| `forge:verify` | Verify implementation delivers stated goals (not just task completion) |

### Taxonomy

Skills are organized into functional groups. Each skill lives in
`skills/<group>/<skill-name>/` with a `SKILL.md` (Claude instructions) and `README.md`
(user documentation). The `forge:` command for each skill is shown in brackets.

```
skills/
│
├── workflow/                   # Workflow lifecycle management
│   ├── project/  [forge:effort]
│   │                           # Start a new workflow; detects greenfield vs. brownfield;
│   │                           # tier sets which phases are required vs. available-on-demand;
│   │                           # checkpoints progress so partial init is resumable
│   ├── status/        [forge:status]
│   │                           # Show current workflow state and next actions;
│   │                           # reads .forge/efforts/README.md and active .state.json
│   ├── promote/       [forge:promote]
│   │                           # Approve the current phase via a defined ritual.
│   │                           # For discovery: reviews BOTH requirements and design
│   │                           # artifacts together, produces a combined summary,
│   │                           # awaits human confirmation, creates a checkpoint commit,
│   │                           # and marks discovery approved — unblocking validation
│   │                           # and implementation. Not a simple state flag flip.
│   ├── revert/        [forge:revert]
│   │                           # Revert a task, phase, or entire work-id by parsing
│   │                           # commit SHAs from plan/tasks.md, reconciling git history,
│   │                           # presenting an execution plan for confirmation, executing
│   │                           # the revert, and updating .state.json and .forge/efforts/README.md
│   ├── reopen/        [forge:reopen]
│   │                           # Move an approved phase back to in_progress without
│   │                           # reverting any code. Use when a design flaw is found
│   │                           # mid-implementation and discovery must be revisited, or
│   │                           # when a promoted plan needs revision. Steps:
│   │                           #   1. Accept scope: discovery | validation | planning
│   │                           #   2. Confirm with engineer (shows what will be unlocked)
│   │                           #   3. Set phase status back to in_progress in .state.json
│   │                           #   4. Re-enables writes to that phase's directories
│   │                           #      (the PreToolUse hook reads the updated state)
│   │                           #   5. Updates .forge/efforts/README.md to reflect the regression
│   │                           #   6. Does NOT revert code — use workflow/revert for that
│   ├── jira-pull/     [forge:jira-pull]    # Initialize workflow from an existing Jira ticket
│   ├── jira-push/     [forge:jira-push]    # Push current state to Jira
│   ├── jira-resolve/  [forge:jira-resolve] # Resolve a Jira ↔ repo conflict
│   ├── pause/         [forge:pause]
│   │                           # Record intentional session pause. Writes pause state
│   │                           # to .state.json: current task, decisions in flight,
│   │                           # and explicit next action. Optionally creates a
│   │                           # checkpoint commit. session-start hook detects active
│   │                           # pause and surfaces it as top priority on resume.
│   └── resume/        [forge:resume]
│                               # Restore from recorded pause state. Reads pause block
│                               # from .state.json, presents current position and next
│                               # action, and routes to the appropriate skill.
│
├── requirements/               # Discovery phase — requirements artifact skills.
│   │                           # These may be invoked before, during, or after design
│   │                           # skills. There is no sequencing requirement between
│   │                           # requirements/* and spec/* skills.
│   ├── extract/       [forge:extract]       # PM document → structured business requirements
│   ├── validate/      [forge:check-reqs]    # Check requirements for completeness and testability
│   ├── classify-risk/ [forge:classify]      # Assign R1–R4 risk classification
│   └── elaborate/     [forge:elaborate]     # Business requirements → technical requirements
│
├── spec/                     # Discovery phase — design artifact skills.
│   ├── api/           [forge:spec-api]       # Design REST API contracts (OpenAPI)
│   ├── storage/       [forge:spec-storage]   # Design storage schemas (Postgres/Dynamo/OpenSearch/Redis)
│   ├── messaging/     [forge:spec-messaging] # Design message contracts
│   ├── record-decision/ [forge:adr]            # Record an ADR to .forge/spec/arch-decisions/; updates the ADR
│   │                           # index and links back to the current work-id
│   └── test-strategy/ [forge:spec-tests]     # Design high-level test strategy
│
├── validate/                   # Phase 4 skills
│   ├── spec/        [forge:validate]          # Full design validation (requirements coverage + standards)
│   ├── api/           [forge:validate-api]      # Validate API contract against REST standards
│   ├── storage/       [forge:validate-storage]  # Validate schema against data modeling standards
│   ├── messaging/     [forge:validate-messaging]# Validate contract against messaging standards
│   └── test-coverage/ [forge:validate-tests]    # Validate test strategy covers all requirements
│
├── plan/                       # Phase 5 skills
│   ├── generate/      [forge:plan]         # Validated design → implementation task list
│   └── update/        [forge:update-plan]  # Mark tasks complete. Called after implement/commit:
│                               # reads the commit SHA from the just-created commit,
│                               # records it inline next to the task in plan/tasks.md,
│                               # marks the task complete in .state.json, and queues
│                               # a Jira sync. Does NOT write git notes — that is
│                               # implement/commit's responsibility.
│
├── implement/                  # Phase 4 skills
│   ├── scaffold/      [forge:scaffold]          # New project/module scaffolding by archetype
│   ├── api/           [forge:build-api]         # Implement API endpoints from contract
│   ├── repository/    [forge:build-repo]        # Implement data access layer from schema
│   ├── messaging/     [forge:build-messaging]   # Implement message producers/consumers from contract
│   ├── tests/         [forge:test]              # Write unit, integration, and E2E tests
│   ├── commit/        [forge:commit]            # Create a well-formed commit following the git standard:
│                               #   1. Verify the working branch follows the convention
│                               #      <work-id>/<short-description> (e.g.
│                               #      PROJ-1234/add-preference-storage). Warn and
│                               #      offer to rename if it does not match.
│                               #   2. Inspect staged changes and confirm they are
│                               #      scoped to a single logical task (flag mixed
│                               #      concerns for the engineer to resolve)
│                               #   3. Propose a conventional commit message
│                               #      (feat/fix/chore/docs/test/refactor + scope +
│                               #      description) based on what changed; engineer
│                               #      confirms or edits
│                               #   4. Create the commit
│                               #   5. Attach a structured git note to the commit
│                               #   6. Prompt the engineer to invoke plan/update to
│                               #      record the SHA and mark the task complete
│   └── verify/        [forge:verify]            # Implementation verification worker. Runs after
│                               # implementation is declared complete and before
│                               # forge:review. Reads: validated design artifacts,
│                               # plan/tasks.md with commit SHAs, changed source files.
│                               # Verifies: does the implementation deliver the stated
│                               # phase goal? Are stubs present? Is wiring complete?
│                               # Distinguishes confirmed delivery from gaps. Produces
│                               # verification/report.md — referenced by forge:review
│                               # and included in the PR description.
│
├── review/                     # Phase 7 skills
│   ├── pr/            [forge:review]            # PR review. Runs all checks by default.
│   │                           # --checks <name,...> selects a specific subset.
│   │                           # Each check is a specialist agent run in parallel.
│   │                           # Diffs over size threshold: partitioned across parallel
│   │                           # workers per file group; aggregated into one report.
│   ├── security/      [forge:review-security]   # Alias: forge:review --checks security.
│   │                           # Named separately so CI workflows and branch protection
│   │                           # can reference a stable check name without embedding
│   │                           # the --checks flag in workflow configuration.
│   ├── privacy/       [forge:review-privacy]    # Alias: forge:review --checks privacy.
│   │                           # Same rationale as review-security.
│   ├── traceability/  [forge:review-trace]      # Validate PR changes trace to stated requirements
│   └── simplify/      [forge:simplify]          # Post-approval simplification pass. Runs AFTER
│                               # a PR is approved and merged, not during gate review.
│                               # Identifies safe refactor opportunities: extract shared
│                               # logic, reduce nesting, improve naming, remove dead code.
│                               # Proposes changes as a follow-up PR or a set of commits
│                               # on a simplification branch. Never changes behaviour.
│
├── qa/                         # Phase 6 skills — validation against a pre-production
│   │                           # environment. Pre-prod URL is stored in .state.json
│   │                           # (see Workflow State Model). All skills in this group
│   │                           # read spec/test-strategy.md as their coverage target.
│   ├── execute/       [forge:qa]               # Drive the test plan against pre-production. Reads
│   │                           # test-strategy.md for the scenarios to exercise.
│   │                           # Produces a structured test execution report covering
│   │                           # each scenario: pass, fail, or blocked.
│   ├── map-defects/   [forge:map-defects]      # Given a test execution report, map each failed scenario
│   │                           # to the business or technical requirement it violates.
│   │                           # Output: defect report with requirement traceability —
│   │                           # each defect links to a specific BR or TR, so prioritization
│   │                           # is based on business impact, not defect severity alone.
│   ├── coverage-gaps/ [forge:check-coverage]   # Identify requirements that have no corresponding test
│   │                           # coverage in the executed test plan. Distinguishes blocking
│   │                           # gaps (untested R1/R2 requirements) from informational ones.
│   └── regression-tests/ [forge:regression]   # Generate regression test cases from confirmed defects to
│                               # prevent recurrence. Writes test files into the appropriate
│                               # test suite, keyed to the requirement they protect.
│
├── operate/                    # Phase 8–10 skills
│   ├── generate-runbook/ [forge:runbook]    # Create or update a capability-area file in
│   │                           # docs/runbook/ and regenerate docs/runbook/README.md.
│   ├── diagnose/      [forge:diagnose]      # Analyze DataDog logs/metrics + runbook for root cause.
│   │                           # Produces a structured diagnosis report: root cause
│   │                           # hypothesis, supporting evidence, matched runbook
│   │                           # playbook (or "no match" if unknown pattern), and
│   │                           # recommended remediation steps. When invoked from
│   │                           # GitHub Actions, passes the report to operate/remediate.
│   ├── remediate/     [forge:remediate]     # Execute runbook playbook steps autonomously. Accepts
│   │                           # a diagnosis report and the matched playbook section.
│   │                           # Classifies each step as SAFE or UNSAFE:
│   │                           #   SAFE actions (executed without human approval):
│   │                           #     - Triggering a service restart via GitHub Actions
│   │                           #     - Clearing a known cache key
│   │                           #     - Adjusting a capability flag to a pre-approved value
│   │                           #     - Scaling a service within pre-approved bounds
│   │                           #   UNSAFE actions (require engineer confirmation):
│   │                           #     - Database writes or schema changes
│   │                           #     - Deleting data or queues
│   │                           #     - Any action not explicitly listed in the runbook
│   │                           #     - Any action that has no rollback defined
│   │                           # If all steps succeed: posts resolution summary to the
│   │                           # incident channel. If a SAFE step fails or an UNSAFE
│   │                           # step is encountered: pages on-call with the diagnosis
│   │                           # report, steps completed so far, and the blocking step.
│   └── rollout-monitor/ [forge:monitor]     # Evaluate rollout signals, recommend proceed/rollback
│
├── init/              [forge:init]     # GLOBAL PLUGIN SKILL — lives in ~/.claude/commands/,
│                               # not installed per-project. Available in every
│                               # project before that project is initialized.
│                               # Standards are bundled with the Forge plugin — no
│                               # download needed. One-time project setup. Steps:
│                               #   1. Prompt for which packages to activate
│                               #   2. Run setup.sh --packages <list> (installs skill
│                               #      shortcuts to .claude/commands/ and registers
│                               #      hooks in .claude/settings.json)
│                               #   3. Detect greenfield vs. brownfield:
│                               #      Greenfield: create CLAUDE.md from template
│                               #        with standards references pointing to the
│                               #        plugin-bundled content location;
│                               #        create .forge/efforts/README.md,
│                               #        .forge/spec/arch-decisions/README.md,
│                               #        docs/runbook/README.md
│                               #      Brownfield: merge into existing CLAUDE.md
│                               #        without overwriting existing content
│                               #   4. Configure git notes push/fetch refspec
│                               #   5. Commit all generated and modified files
└── map/               [forge:map]               # Brownfield codebase analysis worker. Run once
                                # at brownfield onboarding; updated after major
                                # architectural changes. Spawns parallel analysis
                                # workers per focus area (technology stack, architecture,
                                # conventions, integrations, concerns). Produces:
                                #   docs/codebase/STACK.md
                                #   docs/codebase/ARCHITECTURE.md
                                #   docs/codebase/CONVENTIONS.md
                                #   docs/codebase/INTEGRATIONS.md
                                #   docs/codebase/CONCERNS.md
                                # Output is referenced from the project CLAUDE.md and
                                # loaded as context for all subsequent skills — bridging
                                # org-wide standards with project-local reality.
```

### Skill Design Rules

1. **One input, one output.** Each skill takes a defined input (a file, a PR, a Jira key)
   and produces a defined artifact or report. Side effects (updating `.state.json`,
   queuing a Jira sync) are handled by hooks, not by the skill itself.

2. **Skills reference standards, not contain them.** A skill instructs Claude to apply
   the standard at `standards/api/rest.md`, not to apply rules inline. This keeps skills
   thin and standards authoritative.

3. **Skills emit structured output.** Where downstream hooks or GitHub Actions consume
   skill output, the output follows a defined format (documented in the skill's README).

4. **Platform-specific skills are variants.** The `spec/api/` skill has a generic
   version and platform-specific variants (e.g., `spec/api/mobile/`). Variants inherit
   the base skill's structure and override the sections specific to that platform.

5. **SKILL.md instructions use numbered steps.** Every SKILL.md defines its process as
   an explicitly numbered sequence (1.0 Check prerequisites, 1.1 Read state, 2.0 Generate
   draft, etc.). This makes skill behavior predictable, auditable, and resumable. The
   checkpoint field in `.state.json` references step numbers so interrupted skills can
   continue from the last completed step rather than restarting from scratch.

5b. **Implementation skills define deviation rules.** Every skill that writes or
    modifies source code declares, in its SKILL.md, what it handles autonomously
    and what it must escalate to the engineer. The rule is:
    - **Handle autonomously:** Fixing bugs in code just written, adding missing error
      handling, fixing broken imports or missing dependencies.
    - **Escalate to engineer:** Any deviation that requires modifying an approved
      design artifact (API contract, schema, test strategy). The escalation path
      is `forge:reopen` on the relevant artifact, not an inline question.
    This rule prevents two failure modes: agents that ask permission for routine
    fixes (erodes adoption) and agents that silently modify approved designs
    (erodes trust and auditability).

6. **Standards govern generation and evaluation.** A skill that generates code (e.g.,
   `forge:build-api`) and a skill that evaluates code (e.g., `forge:review`) reference
   the same standards documents. The `inject-generation-standards.sh` PreToolUse hook
   ensures standards are always in Claude's context before a source file is written —
   without any skill invocation required. When authoring a standard, write it as if it
   will be read both by an engineer writing new code and by an evaluator reviewing
   existing code. Both use cases must be served by the same document.

7. **Skills are classified as orchestrators or workers.** Orchestrator skills run in the
   main Claude Code session and manage workflow state, interactive decisions, and artifact
   authoring. Worker skills run as isolated sub-agents via the Task tool with fresh context
   windows. A skill is a worker if it: (a) consumes large input volumes (diffs, logs, PM
   documents), (b) produces a self-contained structured output without interactive
   back-and-forth, and (c) has no reason to see the engineer's accumulated session history.
   Every other skill is an orchestrator. The classification is declared in the skill's
   SKILL.md frontmatter (`agent-type: orchestrator | worker`) and enforced by convention.

8. **Worker skills spawn internal agents for parallel analysis passes.** A worker skill
   that runs multiple independent analysis passes must spawn each pass as an internal
   agent via the Task tool — not run them in sequence in a single context window. Internal
   agents are **not skills**: they have no `SKILL.md` file, do not appear in the command
   palette, and are never invoked directly by engineers or CI. They are defined as agent
   specifications in the epic's `spec/skills.md`. Each internal agent receives only the
   context required for its specific pass. This is the primary mechanism for maintaining
   analysis quality across multiple dimensions — each agent starts with a clean, focused
   context rather than one polluted by findings from unrelated passes.

### Three-Tier Context Model

Forge uses three tiers of context isolation. Each tier can only see what is explicitly
passed to it — never its parent's full context.

| Tier | What runs here | Context available |
|------|---------------|-------------------|
| **1 — Main session** | Orchestrator skills | Full session history, `.state.json`, open files |
| **2 — Worker skills** | `forge:review`, `forge:extract`, `forge:verify`, etc. | Only what's explicitly passed at invocation; no session history |
| **3 — Internal agents** | Specialist reviewers, partition workers, confidence scorer | Only the subset of the worker's context relevant to their specific pass |

The tiers are not optional — every skill declares its tier via `agent-type: orchestrator`
or `agent-type: worker`, and worker skills that spawn internal agents document those
agents explicitly in their epic's `spec/skills.md`. Tiers exist to prevent two failure
modes: context pollution (earlier findings biasing later analysis) and context overflow
(accumulating inputs until quality degrades).

**Worker skills with documented internal agent architectures:**
- `forge:review` — see `.forge/efforts/ai-pr/spec/skills.md § Internal Agents`
- `rr-standards:review` — see `.forge/efforts/rr-standards-plugin/spec/skills.md § Internal Agents`

### Orchestrator / Worker Classification

The following table is the canonical classification for all Forge skills. This determines
whether a skill runs inline in the engineer's session or is spawned as an isolated sub-agent.

| Skill | Command | Agent Type | Rationale |
|-------|---------|-----------|-----------|
| workflow/project | `forge:effort` | Orchestrator | Interactive setup; writes .state.json |
| workflow/init | `forge:init` | Orchestrator | **Global plugin.** Interactive; configures project with plugin-bundled standards content |
| workflow/status | `forge:status` | Orchestrator | Reads session state; no large inputs |
| workflow/promote | `forge:promote` | Orchestrator | Phase gate ritual; requires human confirm |
| workflow/reopen | `forge:reopen` | Orchestrator | State-only write; no large inputs |
| workflow/revert | `forge:revert` | Orchestrator | Interactive; requires engineer validation |
| workflow/help | `forge:help` | Orchestrator | Routing; reads .state.json |
| jira/pull | `forge:jira-pull` | Orchestrator | Minimal API response; interactive |
| jira/push | `forge:jira-push` | Orchestrator | Minimal payload; no large inputs |
| jira/resolve | `forge:jira-resolve` | Orchestrator | Interactive conflict resolution |
| workflow/pause | `forge:pause` | Orchestrator | State write; requires session context |
| workflow/resume | `forge:resume` | Orchestrator | Reads pause state; interactive routing |
| requirements/extract | `forge:extract` | **Worker** | Reads large PM documents |
| requirements/elaborate | `forge:elaborate` | Orchestrator | Interactive; iterates with engineer |
| requirements/classify | `forge:classify` | Orchestrator | Quick; no large inputs |
| requirements/check | `forge:check-reqs` | Orchestrator | Reads small requirements files |
| spec/api | `forge:spec-api` | Orchestrator | Interactive; iterates with engineer |
| spec/storage | `forge:spec-storage` | Orchestrator | Interactive; iterates with engineer |
| spec/messaging | `forge:spec-messaging` | Orchestrator | Interactive; iterates with engineer |
| spec/adr | `forge:adr` | Orchestrator | Short-form; interactive |
| spec/tests | `forge:spec-tests` | Orchestrator | Interactive; iterates with engineer |
| validation/validate | `forge:validate` | **Worker** | Cross-references multiple large artifacts |
| plan/generate | `forge:plan` | Orchestrator | Interactive; engineer approves tasks |
| plan/update | `forge:update-plan` | Orchestrator | State write; no large inputs |
| implement/scaffold | `forge:scaffold` | Orchestrator | Interactive; small targeted output |
| implement/build-api | `forge:build-api` | Orchestrator | Interactive; engineer guides generation |
| implement/build-repo | `forge:build-repo` | Orchestrator | Interactive; engineer guides generation |
| implement/build-messaging | `forge:build-messaging` | Orchestrator | Interactive; engineer guides generation |
| implement/test | `forge:test` | Orchestrator | Interactive; engineer guides generation |
| implement/commit | `forge:commit` | Orchestrator | Quick; needs current session context |
| implement/verify | `forge:verify` | **Worker** | Reads design artifacts + code; high input volume |
| review/pr | `forge:review` | **Worker** | Reads entire PR diff; high context volume |
| review/security | `forge:review-security` | **Worker** | Targeted analysis of large code surface |
| review/privacy | `forge:review-privacy` | **Worker** | Targeted analysis of large code surface |
| review/simplify | `forge:simplify` | **Worker** | Reads merged diff + full files; high context volume |
| qa/run | `forge:qa` | **Worker** | Reads test result sets; maps to requirements |
| qa/map-defects | `forge:map-defects` | **Worker** | Cross-references defects with requirements |
| qa/check-coverage | `forge:check-coverage` | Orchestrator | Reads small summary files |
| qa/regression | `forge:regression` | **Worker** | Reads full regression output |
| operate/runbook | `forge:runbook` | Orchestrator | Interactive; short document |
| operate/diagnose | `forge:diagnose` | **Worker** | Reads DataDog logs + runbook; high volume |
| operate/remediate | `forge:remediate` | Orchestrator | Requires human confirm for UNSAFE steps |
| operate/monitor | `forge:monitor` | **Worker** | Reads rollout signals continuously |
| map | `forge:map` | **Worker** | Spawns parallel codebase analysis sub-agents |

**Note on `forge:remediate`:** Remediation is an orchestrator despite its autonomous
execution of SAFE steps because it must pause and surface UNSAFE steps to the engineer
in the live session. A worker cannot interrupt itself for human input mid-execution.

### Using-Skills Orchestration

`using-skills` is a skill that engineers invoke at the start of any session (or any
time they are unsure what to do next). It reads `.state.json` and `.forge/efforts/README.md`,
then applies the following routing logic to present a ranked set of recommended next
actions — it never blocks, only advises:

**Routing table** (evaluated top-to-bottom; first matching row wins):

| Condition | Recommendation |
|-----------|----------------|
| Pause state active in `.state.json` | **Highest priority:** `forge:resume` — surface position and next action before anything else |
| No `.state.json` found | `forge:effort` |
| `currentPhase: discovery`, no artifacts yet | `forge:extract` (start with the PM doc) |
| `currentPhase: discovery`, requirements present, no design artifacts | `forge:spec-api` or `forge:spec-storage` |
| `currentPhase: discovery`, design artifacts present, requirements incomplete | `forge:elaborate` (design revealed missing requirements) |
| `currentPhase: discovery`, both artifact sets present but not approved | `forge:promote` |
| `currentPhase: validation` | `forge:validate` |
| `currentPhase: planning` | `forge:plan` |
| `currentPhase: implementation`, remaining tasks > 0 | `forge:build-api`, `forge:build-repo`, `forge:build-messaging`, or `forge:test` — matching the next task type |
| `currentPhase: implementation`, task complete, no commit yet | `forge:commit` |
| `currentPhase: implementation`, all tasks complete, no verification report | `forge:verify` |
| `currentPhase: implementation`, committed, plan not updated | `forge:update-plan` |
| `currentPhase: verification`, report shows gaps | Return to `forge:build-*` for the specific gaps |
| `currentPhase: verification`, report shows delivery confirmed | `forge:promote` |
| `currentPhase: review` | `forge:review` |
| `currentPhase: qa` | `forge:qa` |
| `currentPhase: deployment` | `forge:monitor` |
| `currentPhase: operations` | `forge:diagnose` or `forge:runbook` |
| Jira `syncStatus: pending` (any phase) | Surface as a secondary recommendation alongside the primary |
| Checkpoint present in `.state.json` | Surface as highest priority: `forge:` + the interrupted skill name |

**Within discovery — no single recommended next step:** During the discovery phase,
requirements and design are co-evolutionary. The routing table above gives a starting
recommendation based on artifact state, but does not enforce it — the engineer may
invoke any `requirements/*` or `spec/*` skill in any order. `using-skills` makes
the current artifact state visible (which documents exist, which are drafts vs. present)
so the engineer can make an informed choice, not a prescribed one.

**The `UserPromptSubmit` hook** detects intent in free-text prompts (e.g., "I'm done
with requirements," "let's review this PR") and surfaces a `using-skills` recommendation
as a pre-prompt injection. The hook does not block the prompt — it adds context that
guides Claude's response toward the appropriate skill invocation.

---
