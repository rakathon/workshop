# Learnings from GET SHIT DONE (GSD)

Reference: https://github.com/gsd-build/get-shit-done

GSD is a lightweight meta-prompting and context engineering system for Claude Code,
OpenCode, Gemini CLI, and Codex. As of March 2026 it has 24,700+ GitHub stars and
is trusted by engineers at Amazon, Google, Shopify, and Webflow. It is designed
primarily for solo developers on greenfield projects, which makes it a different
target than Forge — but its implementation reveals several genuine gaps in our
architecture that are worth addressing.

This document captures what our architecture should adopt, adapt, or consciously avoid
from GSD's implementation. It should be read alongside `architecture.md` and the
`conductor-learnings.md` document, and used to inform plan-phase revisions.

---

## What GSD Does Well (Adopt or Adapt)

### 1. Context Monitoring Hook

GSD ships a `PostToolUse` hook (`gsd-context-monitor.js`) that reads the remaining
context percentage after every tool call and injects structured warnings when context
is depleting:

- **WARNING** at 35% remaining
- **CRITICAL** at 25% remaining
- Debounced to 1 warning per 5 tool calls (unless severity escalates)
- GSD-aware: different message when a project is active vs. exploratory session

This is a genuine safety net. Forge's worker/orchestrator split addresses context rot
for heavy operations (PR diffs, PM documents run in isolated workers). But the
orchestrator's context is unmanaged. An engineer in a long design session with multiple
forge:spec-* invocations can silently degrade quality without any warning.

**What to adopt:** A `PostToolUse` hook (`02-monitor-context.sh`) that reads
remaining context percentage from Claude's hook environment and injects a structured
warning. The hook infrastructure is already defined in our architecture; this is one
additional script in the `post-tool-use/` directory.

---

### 2. Deviation Rules — Explicit Autonomy Boundaries for Agents

GSD's executor agent has four explicit rules governing what it can do without asking:

- **Rule 1:** Auto-fix bugs (code doesn't work as written)
- **Rule 2:** Auto-add critical missing functionality (error handling, validation, auth checks)
- **Rule 3:** Auto-fix blocking issues (missing dependencies, broken imports)
- **Rule 4:** Ask for architectural changes (new tables, new external dependencies, breaking changes)

This clear scope prevents two failure modes: infinite loops of asking the user for
routine fixes, and agents making architectural decisions without consent.

**What to adopt:** Every implementation skill's SKILL.md should define equivalent
deviation rules appropriate to its scope. For Forge, Rule 4 should be more specific:
any deviation that requires modifying a design artifact (the API contract, the schema,
the test strategy) must be surfaced to the engineer and resolved by reopening the
relevant discovery artifact via `forge:reopen` before proceeding — not just asking
inline.

---

### 3. Goal-Backward Verification

GSD's verifier agent does not check "did all tasks complete?" — it checks "does the
code actually deliver the phase goal?" This distinction matters because tasks can be
marked complete with stub code, orphaned implementations, or missing wiring that
task completion alone doesn't reveal.

The verifier works backwards from goal → required artifacts → integration wiring,
catching gaps that task-level completion tracking misses.

**What to adopt:** A `forge:verify` worker skill that runs after implementation is
declared complete and before `forge:review`. It reads the validated design artifacts,
the task list (with commit SHAs), and the changed code, then checks: does the
implementation match the design? Are there stubs or missing integration points? This
fills the gap between implementation completion (engineer-declared) and formal QA
(pre-production test execution). The structured output feeds into the PR description
and is referenced by `forge:review`.

---

### 4. Machine-Readable Task Types in Plans

GSD plans are structured XML with explicit task types:

```xml
<task type="auto">
  <name>Create login endpoint</name>
  <files>src/app/api/auth/route.ts</files>
  <action>Use jose for JWT. Validate credentials. Return httpOnly cookie.</action>
  <verify>curl -X POST localhost:3000/api/auth returns 200 + Set-Cookie</verify>
  <done>Valid credentials return cookie, invalid return 401</done>
</task>
```

Task types: `auto` (proceed), `checkpoint:human-verify` (pause for visual check),
`checkpoint:decision` (pause, user decides), `checkpoint:human-action` (unavoidable
manual step), `tdd` (enforce RED→GREEN→REFACTOR).

**What to adapt:** Our `plan/tasks.md` is human-readable markdown. Task completion
and commit SHAs are tracked in `.state.json`, but there is no machine-readable signal
for when an executing agent should pause vs. proceed vs. follow a specific discipline.
We do not need full XML, but we should add type annotations to task entries in
`plan/tasks.md`. A simple prefix convention (`[auto]`, `[checkpoint]`, `[tdd]`) is
sufficient for the `forge:build-*` skills to parse and the plan/tasks.md format to
remain human-readable. The `forge:plan` skill should assign types during task
generation based on the nature of each task.

---

### 5. Wave-Based Parallel Execution of Implementation Tasks

GSD's planner analyzes task dependencies upfront and groups tasks into waves:
- Tasks in the same wave are independent and run in parallel (each in a fresh context)
- Waves execute sequentially (wave N+1 waits for wave N to complete)

This beats both "all sequential" (slow) and "all parallel" (dependency violations,
silent failures) approaches.

**What to adapt:** Forge's worker/orchestrator architecture already supports this
pattern — the PR review chunking strategy spawns multiple workers in parallel. The
same pattern should apply to implementation task execution. `forge:plan` should
analyze task dependencies during generation and annotate each task with a wave number.
`forge:build-*` skills should be able to execute a wave of independent tasks in
parallel, each as an isolated worker, rather than requiring sequential engineer
interaction for every task. The wave annotations belong in `plan/tasks.md` (alongside
the type annotations described above) and in `.state.json` under the planning phase.

---

### 6. Codebase Mapping for Brownfield Projects

GSD's `/gsd:map-codebase` spawns parallel analysis agents that produce seven
structured documents:

- `STACK.md` — Technology choices, versions, key dependencies
- `ARCHITECTURE.md` — Patterns, service boundaries, key abstractions
- `STRUCTURE.md` — Directory layout and conventions
- `CONVENTIONS.md` — Naming, formatting, error handling patterns in use
- `TESTING.md` — What tests exist, coverage, testing patterns
- `INTEGRATIONS.md` — External service dependencies and contracts
- `CONCERNS.md` — Technical debt, fragile areas, known issues

These become permanent reference material that subsequent skills load as context.

**What to adopt:** A `forge:map` skill (worker) for brownfield projects. The Week 3
pilot team is almost certainly brownfield. Without codebase mapping, the generation
standards hook fires against files it has no knowledge of — injecting org-wide
standards without understanding the existing patterns in the codebase. A `forge:map`
output provides the project-specific context that bridges org standards with local
reality. Output lives in `docs/codebase/` (project-scoped, not work-scoped) and is
referenced from the project CLAUDE.md.

---

### 7. Session Pause/Resume — Intentional Handoff

GSD has `/gsd:pause-work` (creates a structured handoff document recording current
position, active context, decisions made, and explicit next step) and `/gsd:resume-work`
(restores from it at the start of a new session).

Forge's `.state.json` checkpoint field handles failure recovery — if a skill is
interrupted, the next invocation can resume from the last completed step. But this
is failure recovery, not intentional handoff. There is no "I'm done for the day,
create a handoff" workflow for engineers who stop mid-task or want to hand work to
a colleague.

**What to adopt:** `forge:pause` should write a structured handoff section into the
work item's `.state.json` (current task, decisions in flight, explicit next action)
and optionally create a handoff commit. The `session-start/01-inject-workflow-context.sh`
hook should detect an explicit pause state and surface it as the top recommendation
rather than the general workflow summary.

---

### 8. Background Update Mechanism

GSD ships a `SessionStart` hook (`gsd-check-update.js`) that spawns a background
process to check npm for a new version (non-blocking, 10-second timeout, result
cached to disk). Engineers discover updates via `/gsd:update`, which shows a
changelog preview before installing.

Forge is distributed via git submodule. A team could run stale standards or hooks
for weeks without knowing rr-standards has been updated.

**What to adopt:** A session-start hook that runs `git fetch` against the rr-standards
submodule remote (background, non-blocking) and compares the local submodule SHA
against the remote HEAD. If behind, injects a one-line notice: "rr-standards has
updates — run `forge:update` to review and apply." The update command shows a summary
of what changed in standards and hooks since the installed version.

---

### 9. Testing Infrastructure for the Tooling Itself

GSD has 16 test files covering state management, frontmatter parsing, command routing,
phase operations, roadmap parsing, and directory integrity — running across Ubuntu,
macOS, and Windows against three Node versions. The test suite is a first-class part
of the repository.

Forge has no test suite for skills, hooks, or standards validation logic. The
`forge:validate-standard` skill is central to workshop quality control and to the
ongoing standard-writing process — but there is no automated verification that it
works correctly. The phase gate hooks have no tests; a broken hook fails silently.

**What to adopt:** A test suite for hooks (particularly `02-enforce-phase-gates.sh`
and `inject-generation-standards.sh`) and for the `forge:validate-standard` skill.
Shell `bats` or equivalent for the bash hooks. Integration tests that verify the hook
fires correctly and produces the expected output for known inputs. This should precede
broad rollout — a broken phase gate that fails silently undermines the entire
governance model.

---

## What GSD Does That We Deliberately Won't Replicate

### 1. Per-Project Standards (Embedded, Not Shared)

GSD embeds code style guides and conventions directly into each project's `.planning/`
directory. When GSD is installed on a new project, it creates project-local copies
of all documentation.

**Our approach is different by design.** Standards live in rr-standards and are
referenced from each project's CLAUDE.md, not copied into it. A change to the Go
standard propagates to all projects automatically. GSD's approach creates drift across
projects; ours does not. This is a deliberate trade-off in favor of organizational
consistency.

### 2. Solo-Developer Scope

GSD has no approval policy, no required review tiers, no concept of organizational
governance. The verification loop is "did it work?" not "does this comply with
organizational policy?"

For a solo developer on a greenfield project, this is correct. For an enterprise
handling sensitive member data with compliance requirements and multi-team ownership,
it is insufficient. Our tiered approval model (R1–R4, AI approval + human approval
for high-risk changes) is explicitly enterprise-scoped and should not be softened to
match GSD's simpler model.

### 3. No Operations Phase

GSD ends at verification (UAT). It has no runbook generation, incident diagnosis,
rollout monitoring, or production remediation capabilities.

This is a scope choice appropriate for GSD's audience. Forge's Phase 4 operations
capabilities (forge:diagnose, forge:remediate, forge:monitor) are a genuine
differentiator for an organization with production reliability requirements and
on-call responsibilities.

### 4. No Issue Tracker Integration

GSD has no Jira integration. Work lives entirely in `.planning/`.

Forge's repository-as-source-of-truth with downstream Jira sync (Phase 5) addresses
a real enterprise coordination need that GSD's audience doesn't have. We should not
deprioritize Jira integration on the basis that GSD doesn't need it.

---

## Gaps in Our Architecture Revealed by GSD

### Gap 1: No Context Monitoring

Forge has no mechanism to warn Claude when the main session context is depleting.
The worker/orchestrator split helps, but orchestrator context is unmanaged.

**Proposed addition:** `post-tool-use/02-monitor-context.sh` — reads remaining context
percentage, injects WARNING at 35% and CRITICAL at 25%, debounced.

### Gap 2: No Deviation Rules in Implementation Skills

Forge's `forge:build-*` skills have no defined rules for what agents can do
autonomously vs. what requires engineer decision when unexpected issues arise.

**Proposed addition:** Explicit deviation rules in every implementation skill's
SKILL.md. Rule 4 equivalent: any deviation requiring modification of a design
artifact must surface to the engineer and be resolved via `forge:reopen` before
proceeding.

### Gap 3: No Goal-Backward Verification Step

Between implementation completion and formal QA, there is no agent that verifies
"did we actually deliver what was planned?" Completion is entirely engineer-declared.

**Proposed addition:** `forge:verify` worker skill — reads validated design artifacts
+ task list (with commit SHAs) + changed code, verifies goal delivery and design
conformance before the PR is opened.

### Gap 4: Task Types Not Machine-Readable in Plans

`plan/tasks.md` has no machine-readable type annotation. Agents executing tasks have
no signal for when to pause vs. proceed autonomously vs. follow TDD discipline.

**Proposed addition:** Type annotations in `plan/tasks.md` tasks (`[auto]`,
`[checkpoint]`, `[tdd]`). `forge:plan` assigns types during task generation. Parsed
by `forge:build-*` skills at execution time.

### Gap 5: No Wave Annotations in Plans

Task dependencies are not captured in `plan/tasks.md`. All tasks are implicitly
sequential, which prevents parallel execution of independent work.

**Proposed addition:** Wave number annotations in `plan/tasks.md` tasks, generated
by `forge:plan` from dependency analysis. `forge:build-*` skills execute tasks within
a wave in parallel (as isolated workers), waves sequentially.

### Gap 6: No Codebase Mapping for Brownfield Projects

`forge:init` detects brownfield and merges gracefully, but does not analyze the
existing codebase. Standards injection fires without understanding the project's
existing patterns.

**Proposed addition:** `forge:map` worker skill — produces structured codebase
documentation (`docs/codebase/`) that bridges org-wide standards with project-local
reality. Run once at brownfield onboarding; updated when significant architectural
changes occur.

### Gap 7: No Intentional Session Handoff

`.state.json` checkpoint handles failure recovery for interrupted skills. There is no
"I'm done for the day, create a handoff" workflow for mid-task pauses or handoffs
between engineers.

**Proposed addition:** `forge:pause` skill — writes explicit pause state to
`.state.json`, optionally creates a checkpoint commit. Session-start hook surfaces
pause state as top priority recommendation.

### Gap 8: No Update Awareness for the Submodule

Teams may run stale standards and hooks without knowing rr-standards has been updated.
No notification mechanism exists.

**Proposed addition:** Session-start hook that runs `git fetch` against rr-standards
remote (background, non-blocking) and notifies if the installed version is behind
remote HEAD. `forge:update` command to review changes and apply.

### Gap 9: No Test Suite for Hooks and Skills

Hooks fail silently. `forge:validate-standard` has no automated verification. A
broken phase gate undermines the entire governance model without any signal.

**Proposed addition:** Test suite for hooks (shell bats) and for
`forge:validate-standard`. Required before broad rollout.

---

## Summary of Architectural Changes

| Change | Section Affected | Priority |
|--------|-----------------|----------|
| Add `post-tool-use/02-monitor-context.sh` | Hooks Architecture | High — low effort, safety net for long sessions |
| Add deviation rules to implementation skill SKILL.md files | Skills Architecture | High — needed before build-* skills run reliably |
| Add `forge:verify` worker skill | Skills Architecture | High — fills the implementation→QA quality gap |
| Add task type annotations to `plan/tasks.md` | Workflow Infrastructure, Skills | Medium — needed before automated task execution |
| Add wave annotations to `plan/tasks.md` | Workflow Infrastructure, Skills | Medium — enables parallel implementation |
| Add `forge:map` worker skill for brownfield | Skills Architecture | Medium — needed for pilot team onboarding |
| Add `forge:pause` and pause state to `.state.json` | Workflow Infrastructure, Skills | Medium — quality of life for team workflows |
| Add session-start submodule update check hook | Hooks Architecture | Low — operational; important at scale |
| Add test suite for hooks and `forge:validate-standard` | Quality infrastructure | High before broad rollout; lower for pilot |
