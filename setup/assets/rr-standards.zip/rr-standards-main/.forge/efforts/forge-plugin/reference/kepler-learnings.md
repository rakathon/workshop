# Kepler: Verifiable AI for Financial Services — Learnings

Source: https://claude.com/blog/how-kepler-built-verifiable-ai-for-financial-services-with-claude

## What Kepler Built

Kepler built AI-powered financial analysis where outputs must be traceable, reproducible, and auditable — not just plausible. Their core insight: verifiability requires architectural discipline, not just better prompts.

---

## Key Patterns

### 1. Deterministic Infrastructure Layer

Operations that require provable correctness (ratio calculations, fiscal period resolution) run in a dedicated execution environment outside the LLM. The LLM handles reasoning; deterministic code handles computation.

**Forge relevance:** Several checks in `forge:validate` and the `validate-*` skills are structurally deterministic — does every task have a wave annotation? does every BR-* have a covering spec? are all referenced ADR numbers present? These could be pre-flighted with grep/parse before the LLM reasoning pass, making certain gate failures immediately reproducible and independent of model variance.

---

### 2. Structured Provenance in Reports

Every result traces to an exact source: "exact line item highlighted in the source document." Findings aren't prose — they're structured records with a citable origin.

**Forge relevance:** `validation/report.md` and `verification/report.md` produce narrative findings. There is no enforced schema linking each finding to a specific artifact, requirement ID, or file location. Adopting a structured finding format — `source`, `rule`, `finding`, `severity` — would make reports machine-readable and enable downstream tooling (e.g., `forge:remediate` that knows exactly which BR-003 needs attention).

---

### 3. Multi-Model Tier Routing

Opus handles complex reasoning (intent decomposition, ambiguity resolution). Sonnet handles constrained, high-throughput operations. The routing is explicit and intentional.

**Forge relevance:** Model selection in skills is currently implicit or ad-hoc. A declared `model_tier` in skill metadata (`reasoning | throughput | either`) would document intent, reduce cost on lower-stakes skills, and support harness-level routing decisions.

---

### 4. Idempotency as a Design Constraint

"Idempotent skills" produce identical outputs for identical inputs. Kepler tests every change against thousands of known-correct answers per pipeline stage.

**Forge relevance:** `rr-standards:test-skill` measures accuracy improvement but not output *stability* across re-runs. For gate skills (`forge:validate`, `forge:verify`), inconsistent verdicts on unchanged artifacts undermine trust. An idempotency mode — run the same skill N times on identical input, flag structural variance — would meaningfully improve confidence in gate results.

---

### 5. Ambiguity Escalation Over Silent Assumption

Claude stops and requests clarification rather than assuming terminology meanings, preventing downstream analysis failures.

**Forge relevance:** `forge:elaborate` already does this well — question-by-question interview before writing specs. This is a strength to preserve in all discovery-phase skills.

---

## Highest-Leverage Opportunities for Forge

| Priority | Idea | Effort | Benefit |
|----------|------|--------|---------|
| 1 | Structured provenance schema for `validation/report.md` and `verification/report.md` | Medium | Machine-readable findings, enables remediation tooling |
| 2 | Deterministic pre-flight pass before LLM validation checks | Medium | Reproducible failures, reduced model variance in gates |
| 3 | Idempotency testing mode in `rr-standards:test-skill` | Low-Medium | Measurable confidence in gate skill consistency |
| 4 | `model_tier` metadata on skills | Low | Cost reduction, documents intent |

## What Forge Already Does Well

- **Ambiguity escalation** — `forge:elaborate` interviews before writing
- **Multi-stage pipelines** — wave-based implementation, parallel sub-agents in `forge:review`
- **Domain ontology** — standards + language guides + AGENTS.md navigation
- **Automated evals** — `rr-standards:test` and `rr-standards:test-skill`
- **Content engineering** — standards loaded as structured context, not injected as prompt strings
