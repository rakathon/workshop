# Learnings from Trellis

Reference: https://github.com/mindfold-ai/trellis

This document captures what our architecture should adopt, adapt, or consciously avoid from
Trellis's implementation. It should be read alongside `spec/` documents and used to inform
plan-phase revisions and implementation decisions.

**Context:** Trellis is a multi-platform AI coding workflow framework (~4,171 GitHub stars)
distributed as an npm package (`@mindfoldhq/trellis`). Its tagline is "the best agent harness."
It is the closest publicly available implementation to what Forge aims to build.

---

## Summary Comparison

| Dimension | Trellis | Forge (planned) |
|---|---|---|
| Scope | Task-centered AI workflow for single team/repo | Organisation-wide lifecycle governance with multi-repo support |
| Distribution | npm install + `trellis init` CLI | Claude Code plugin marketplace + `forge:init` |
| Spec injection | PreToolUse hook — per-task JSONL routing | PreToolUse hook — generation standards + phase gates |
| Quality enforcement | SubagentStop hook (ralph loop) | Review skills with `--ci` mode + `forge:review` required status check |
| State model | `task.json` per task + `.current-task` pointer | `.state.json` per work item, hierarchical, phased |
| Platform support | 11 platforms (Claude Code, Cursor, Codex, etc.) | v1 Claude Code-primary; multi-platform in v2 |
| Traceability | JSONL session logs + session journals | git notes + Jira bidirectional sync |
| Standards | Project-embedded spec files per task | Centralised standards catalog + versioned plugin distribution |
| Operations | Not addressed | Full operations phase (runbooks, DataDog, incident response) |
| Team adoption | Per-developer opt-in | Mandatory enforcement (ADR-020) |

---

## What Trellis Does Well (Adopt or Adapt)

### 1. JSONL Context Files as Declarative Spec Routing

Trellis stores per-task context routing in `.trellis/tasks/{task}/implement.jsonl`,
`check.jsonl`, and `debug.jsonl`. Each line is a JSON object with `file` and `reason` keys:

```json
{"file": ".trellis/spec/cli/backend/error-handling.md", "reason": "ErrorHandling"}
{"file": ".trellis/spec/cli/backend/script-conventions.md", "reason": "ScriptConventions"}
```

The `inject-subagent-context.py` hook reads these files, loads the referenced spec files, and
prepends their contents to the subagent's prompt. The dispatch agent never reads specs
directly — it is a "pure dispatcher."

**What to adopt:** See the hybrid design decision below — JSONL routing is the right mechanism
for R1/R2 structured work but is not the right default for the general case. The hook
infrastructure (read routing file → load referenced standards → prepend to subagent prompt)
is directly reusable.

**Adaptation note:** Our routing file format should reference standards by their canonical
path in `plugins/forge/standards/` not by absolute paths, to survive the restructured
repository layout described in `spec/repository-layout.md`.

---

### Design Decision: AGENTS.md Index vs. JSONL Routing for Spec Injection

Trellis's JSONL routing is deterministic but task-scoped. An alternative is injecting an
AGENTS.md index at session start — a file listing all standards with descriptions of when
each should be read, allowing the AI to self-select which standards apply.

**AGENTS.md index strengths:**
- Handles ad-hoc work (the dominant case — most developer requests are not through a formal
  work item). JSONL routing only fires when a task is active; AGENTS.md is always present.
- Lower maintenance overhead — no routing file to author per task.
- No stale routing problem — if a standard moves, the AI fails visibly (can't read it)
  rather than silently getting no injection.
- Index descriptions can encode concrete trigger conditions that the model is reasonably
  good at evaluating: "read when writing code that accepts external input or constructs queries."

**AGENTS.md index weaknesses:**
- The AI doesn't know what it doesn't know. A developer asking Claude to "add an API endpoint"
  might trigger the REST standard but miss the privacy standard's section on PII in API
  responses, because Claude doesn't classify the endpoint as handling personal data.
- Injection timing: if injected at pre-tool-use (write time), the AI is already writing —
  there is no loop to say "stop, read standards, then continue." If injected at session start,
  the AI may not reference it when deep in implementation.
- No audit trail — you cannot reconstruct which standards were consulted for a given commit
  (matters for BR-18 on R1 work).

**JSONL routing strengths:**
- Deterministic — the right standards are guaranteed present regardless of AI judgment.
- Produces an auditable record of which standards were applied.
- Correct routing is reviewed at task-planning time when there is bandwidth to think about it,
  not deferred to the moment of implementation.

**JSONL routing weaknesses:**
- Only active when a task is in progress. Does nothing for ad-hoc requests.
- Routing files must be authored and maintained per task. If the file is wrong, injection
  is wrong — and there is no fallback.
- Adds planning overhead that is disproportionate for low-risk work.

**Resolved design: risk-tiered hybrid**

Use each mechanism where it is strongest, driven by the active work item's risk tier:

| Situation | Injection mechanism |
|---|---|
| No active work item (ad-hoc) | AGENTS.md index injected at session start |
| Active task, R3/R4 (story/task tier) | AGENTS.md index — lightweight, appropriate to risk |
| Active task, R1/R2 (epic+ tier) | Explicit `context.jsonl` in the work item spec directory |

The `inject-generation-standards.sh` hook checks for an active work item (via
`.forge/.current-work-item` or equivalent). If a `context.jsonl` exists in that work
item's `spec/` directory, inject those standards directly. Otherwise, inject the AGENTS.md
index and let the AI self-select.

The `forge:brainstorm` / planning skill generates `context.jsonl` as part of the work item
spec, making explicit routing automatic for structured R1/R2 work rather than a manual
authoring burden. This aligns injection precision with the risk tier — the cases where
missing a standard is most costly (R1/R2) are exactly where routing is explicit and reviewed.

---

### 2. The Ralph Loop — Hook-Enforced Quality Gates

Trellis's `ralph-loop.py` is a `SubagentStop` hook that fires when the `check` subagent
tries to stop. It blocks termination until either:

- **Programmatic**: Named `verify:` commands in `worktree.yaml` all pass.
- **Marker-based**: Named completion markers (e.g., `LINT_FINISH`, `TYPECHECK_FINISH`) derived
  from `check.jsonl` `reason` fields appear in the agent's output.

Safety limits: max 5 iterations, 30-minute timeout, state file at `.trellis/.ralph-state.json`.
Anti-gaming: the block message explicitly warns "Do NOT output markers just to escape the loop."

**What to adopt:** Our `forge:review` skill currently operates as a single pass. For the
implementation-verification skill (`forge:verify`, which verifies implementation against the
PRD and acceptance criteria), a similar loop mechanism prevents the verifier from
self-terminating before all checks complete. The marker-based approach is particularly
useful because it works without requiring test commands to be pre-registered.

**Adaptation note:** We have stricter quality bar requirements (BR-13, BR-18). The ralph loop
should also persist its pass/fail result to the work item's `.state.json` as an auditable
record, not just block or allow the stop. This gives us the audit trail Trellis lacks.

---

### 3. "Pure Dispatcher" Sub-Agent Architecture

Trellis's dispatch agent is explicitly designed as a pure orchestrator: it reads `task.json`
for the `next_action` array and fires subagents in phase order. It reads nothing else.
All spec context is delivered by the `inject-subagent-context.py` PreToolUse hook before
each subagent starts. This means:

- Dispatch agents don't accumulate spec context across phases (no context contamination).
- Every subagent starts with exactly the context it needs for its phase.
- The hook, not the agent, controls what context a phase receives.

**What to adopt:** Our orchestrator/worker model in `spec/skills.md` already reflects this
split. What Trellis makes concrete is the hook as the context authority — the orchestrator
literally cannot load the wrong spec because it never loads specs at all. Our
`inject-generation-standards.sh` should be extended with agent-type awareness: when firing
a worker that is a `review` worker, inject review standards; when firing an `implement`
worker, inject generation standards. Phase identity should be detectable from the tool call
parameters (e.g., the subagent's `description` field or a naming convention).

---

### 4. Agent Phase Tracking via Hook (not Agent)

In Trellis, `current_phase` in `task.json` is updated by the `inject-subagent-context.py`
hook, not by the dispatch agent. This means phase tracking is accurate even if the dispatch
agent forgets or hallucinates. The hook is the canonical phase recorder.

**What to adopt:** Our `post-tool-use` hook that updates workflow state (`spec/hooks.md`)
should write `current_phase` to `.state.json` at each subagent boundary, not rely on the
orchestrator skill to call a state-update skill. Phase is infrastructure, not agent output.

---

### 5. Session Journal with Auto-Rotation

Trellis's `record-session` skill persists session summaries to
`workspace/{developer}/journal-N.md`, auto-rotating at 2000 lines and updating a developer
index. The skill auto-commits `.trellis/` metadata after recording.

This solves a real problem: session output from long work sessions is ephemeral. A journal
that is committed to the repo provides a human-readable audit trail without requiring full
JSONL log retention.

**What to adopt:** Our `forge:session-close` skill (or an equivalent) should persist a
structured session summary to `docs/codebase/sessions/{developer}/` or similar. Unlike
Trellis, we should anchor the journal entry to the work item (`.state.json` ID and current
phase) to make it queryable as part of BR-18 (AI decisions must be auditable). The auto-commit
of session metadata is a pattern we should replicate — make the framework self-maintaining.

---

### 6. Structured PRD per Task (not just a Plan)

Trellis stores a `prd.md` per task in `.trellis/tasks/{task}/`. This is distinct from the
implementation plan — it is the "what and why" for a single task, injected into both the
implement and check subagents so they can verify against intent, not just task completion.

The `brainstorm` skill generates the PRD with explicit acceptance criteria and out-of-scope
items. The `check` skill reads the PRD to determine whether implementation satisfies stated
goals.

**What to adapt:** We already have this concept at the work item level (`requirements/`,
`spec/`). What Trellis shows is the value of a single, compact, injectable "intent document"
per task that travels with the implementation context. For our story/task tier, a lightweight
`prd.md` (acceptance criteria + out-of-scope) alongside `plan/tasks.md` would let our
verification skill check intent rather than just code quality. This directly supports
BR-13 (implementation verified against goals, not just task completion).

---

### 7. Spec Depth Enforcement at Commit Boundary

Trellis's `finish-work` skill contains a hard-block rule: if infrastructure or cross-layer
code changed but the related spec is still abstract (principle text only, no contracts or
signatures), the commit is blocked. The `update-spec` skill enforces a 7-section mandatory
template for infra specs: Scope/Trigger, Signatures, Contracts, Validation/Error Matrix,
Cases, Tests Required, Wrong vs Correct.

**What to adopt:** Our `forge:review` already plans to check standards compliance. Trellis
shows that the enforcement should be at the implementation boundary (pre-commit), not only
at the review boundary (post-push). Our `pre-tool-use` hook that protects approved artifacts
could be extended to check that new infra/cross-layer code has a corresponding spec in
`spec/` before allowing the Write or Edit tool call to proceed. This is a tighter feedback
loop than PR review.

---

### 8. Brownfield Codebase Mapping (`forge:map` analogue)

Trellis's `onboard` skill performs a structured codebase mapping for brownfield repositories:
it reads the codebase structure, identifies existing patterns, and fills in spec templates
based on observed conventions. This is surfaced as a skill (not a hook) that a developer
runs once when first setting up Trellis on an existing project.

**What to adopt:** Our brownfield onboarding initiative is planned but not yet designed.
Trellis confirms that a dedicated one-time mapping skill is the right pattern — not a hook
that runs on every session. The output of `forge:map` should populate deployable-level spec
stubs in `.forge/deployables/<name>/spec/` with observed patterns marked as `[inferred]`
rather than `[defined]`, making it clear what needs human validation.

---

### 9. Self-Documenting via Meta-Skill

Trellis documents its own architecture in `.claude/skills/trellis-meta/SKILL.md` — a skill
that can be invoked to explain the system. It includes a `trellis-local` separation pattern:
project customizations go in a separate skill so the meta-skill stays clean and upgrades
can be merged without conflict.

**What to adopt:** A `forge:help` or `forge:meta` skill that explains the Forge architecture,
current workflow state, and available skills would directly serve developer adoption (BR-15).
The local/upstream separation pattern is directly applicable to our plugin versioning design:
project-level overrides should live in a `forge-local` or `.forge/overrides/` layer rather
than modifying the installed plugin, so `forge:update` can safely replace installed skills
without clobbering project customisations.

---

### 10. Five-Category Root Cause Taxonomy in Break-Loop

Trellis's `break-loop` skill (triggered after repeated debug failures) mandates a
five-dimension analysis with a lettered root cause taxonomy (A through E), a "why fixes
failed" section, a "prevention mechanisms" section, and a "systematic expansion" step that
asks where else the same issue might exist. Critically: the analysis output must immediately
update spec files, not remain as chat output.

**What to adapt:** We do not currently have a `forge:debug-debrief` or equivalent skill. For
R1/R2 work items, a structured incident debrief skill that feeds its output into the deployable
`spec/` directory is a natural extension of the operations phase. The forcing function of
"analysis is worthless if it stays in chat" is a principle we should build into the skill
definition.

---

## What to Deliberately Not Replicate

### 1. Per-Developer Opt-In Adoption Model

Trellis is installed per-developer via `trellis init -u your-name`. Adoption is voluntary.
Each developer can choose which platforms to enable and can skip Trellis entirely.

**Why we must not replicate:** BR-15 (mandatory adoption) and ADR-020 (`forge:review` as
a required PR status check) are explicit Forge decisions. A voluntary model produces the
inconsistent quality gates and traceability gaps that Forge exists to eliminate. The value
of universal standards enforcement is destroyed by an opt-out model.

---

### 2. Project-Embedded Standards (No Central Catalog)

Trellis stores standards as `.trellis/spec/` files inside each project repository. Every
project has its own copy of conventions. There is no central catalog, no versioning,
no shared publishing mechanism. If a standard needs updating, each project is updated
independently.

**Why we must not replicate:** This is antithetical to our plugin distribution model (ADR-016)
and the rr-standards catalog mission. Central, versioned standards with controlled rollout
(BR-16) is a foundational Forge commitment. Trellis's per-project approach scales to a
single team; our target is cross-team consistency across all Rakuten Rewards repositories.

---

### 3. Approval Model Without Phase Gate Enforcement

Trellis has a planning phase (the dispatch agent calls a `plan` subagent that can reject
requirements) but does not enforce phase sequencing as a hard gate. There is no equivalent
to our discovery-must-be-approved-before-implementation gate. Developers can run any skill
at any time regardless of phase state.

**Why we must not replicate:** Our single phase gate (discovery approval before
implementation) is a deliberate architectural decision (BR-2, BR-3). The gate's value is
exactly that it is not advisory — it is blocking. Trellis's soft planning phase allows
teams to shortcut the requirements process; our customers have explicitly cited requirements-
to-implementation divergence as a top pain point.

---

### 4. No Operations Phase

Trellis has no concept of runbooks, production monitoring, or incident response. The
workflow ends at code merge.

**Why we must not replicate:** BR-8 (runbook as part of definition of done) and the full
operations initiative reflect the decision that AI-assisted operations is within scope.
Trellis's scope is narrower by design; ours is intentionally broader to cover the full
software lifecycle.

---

### 5. In-Memory Task State (No Audit Trail)

Trellis's `task.json` is mutable and replaced on update. Historical states are not preserved.
The JSONL session logs are agent output logs, not structured audit records.

**Why we must not replicate:** BR-18 (AI decisions must be auditable, persisted, queryable)
is a non-negotiable requirement. Our `.state.json` append-only history model and structured
git notes provide the audit trail Trellis lacks. For compliance and incident postmortem use
cases, we need to be able to answer "what decision did the AI make on this PR, and with what
inputs, on date X?"

---

### 6. Flat Task Structure (No Hierarchy)

Trellis tasks are flat: each task is a peer directory under `.trellis/tasks/`. There is no
hierarchy between tasks, no parent/child relationships, no program/initiative/epic/story/task
tiering.

**Why we must not replicate:** Our work item hierarchy (program → initiative → epic →
story → task) maps directly to how Rakuten Rewards plans and tracks work. Flat task lists
cannot represent multi-sprint programs, cross-deployable dependencies, or the governance
model needed for R1 risk. The tiering also drives proportionality (BR-5, BR-20) — a task-tier
item should not require the same governance overhead as a program-tier initiative.

---

## Specific Implementation Signals

The following are concrete details from Trellis that should directly inform our implementation:

### Hook Communication Protocol Confirmation

Trellis's hooks return structured JSON with `additionalContext`, `updatedInput`, and
`permissionDecision` fields — the same format we specify in `spec/hooks.md`. This validates
our hook communication design; we are using the same Claude Code API surface.

### Agent Description-Based Context Routing

Trellis detects agent type from the calling skill's description or a naming convention
(e.g., the agent name `check` triggers the ralph loop). We should formalise agent type
detection via the `description` field prefix convention: worker agents spawned by Forge
orchestrators should use a `forge:implement`, `forge:check`, `forge:review` prefix in their
`description` so hooks can route context by type without parsing prompt content.

### Safety Limits on Hook-Enforced Loops

Ralph loop safety limits: max 5 iterations, 30-minute timeout, state file for cross-invocation
persistence. Our equivalent hooks should specify these limits explicitly in `spec/hooks.md`
rather than leaving them as implementation details.

### `spec_scope: active_task` for Monorepos

Trellis supports a `spec_scope: active_task` configuration in `.trellis/config.yaml` that
limits spec injection to the active task's package specs rather than the entire monorepo
spec catalog. Our session-start hook should implement an equivalent: when a `.forge/`
work item is active, only inject standards tagged as relevant to that work item's domain
(derivable from the `deployables` and `capabilities` fields in `.state.json`).

### Platform Workshop Architecture

Trellis's `trellis-meta` skill describes a "platform workshop" adoption model: 5 sessions,
each with a different goal (install, first task, spec writing, team onboarding, customisation).
Our adoption initiative should design an equivalent `forge:workshop` curriculum. The 5-session
structure maps well to our staged mandatory adoption rollout (BR-15, BR-16).

---

## Gap Analysis: What Trellis Has That We Have Not Yet Designed

| Trellis Capability | Forge Status | Notes |
|---|---|---|
| Spec injection strategy | Designed — see hybrid design decision in §1 | AGENTS.md index for ad-hoc/R3/R4; `context.jsonl` routing for R1/R2 |
| SubagentStop quality loop | Not designed | Design as part of `forge:verify` skill |
| Session journal auto-commit | Not designed | Include in `forge:session-close` skill |
| Compact/clear hook re-injection | Partially designed | `session-start` hook fires on compact; validate completeness |
| Brownfield codebase mapping | Initiative planned | Confirm single-skill pattern (not hook) |
| Per-task intent document (PRD) | Not designed for story/task tier | Add lightweight `prd.md` for story/task tier |
| Spec depth enforcement (pre-commit) | Not designed | Extend `pre-tool-use` hook with spec-depth check |
| Meta-skill (system self-documentation) | Not designed | Low priority; add as adoption aid |
| Multi-platform generation | Planned for v2 | Confirmed feasible via Trellis's npm CLI approach |

---

## Adoption Recommendation

The three highest-leverage adoptions from Trellis, ranked by impact on our requirements:

1. **Per-task JSONL spec routing** — Directly solves context precision (BR-11, BR-20). Low
   implementation cost relative to impact. Can be incrementally adopted: hooks fall back to
   full catalog injection when no routing file exists.

2. **SubagentStop quality loop (ralph-loop equivalent)** — Directly solves verification
   reliability (BR-13). The marker-based approach is resilient without requiring pre-registered
   test commands, which suits our early-stage implementation.

3. **Session journal with auto-commit** — Directly solves audit trail (BR-18) for session-
   level decisions. Low cost, high immediate value, and positions us to build richer
   queryability later.
