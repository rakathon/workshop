# Learnings from obra/superpowers

Reference: https://github.com/obra/superpowers

This document captures what our architecture should adopt, adapt, or consciously avoid
from Superpowers' implementation. It should be read alongside `spec/README.md` and the
other learnings documents (`conductor-learnings.md`, `gsd-learnings.md`, `trellis-learnings.md`).

---

## What Superpowers Is

Superpowers is a multi-platform AI coding agent skill library. Its core premise: instead
of letting the agent improvise a development process, inject opinionated, tested, mandatory
process documents ("skills") at session start. The skills enforce discipline around
design-before-code, TDD, systematic debugging, and subagent orchestration.

It ships as a Claude Code plugin (also Cursor, Gemini CLI, OpenCode, Codex) and is
installable from the official Claude plugin marketplace.

**Philosophy in one sentence:** "Mandatory workflows, not suggestions."

---

## Architecture Overview

### The Bootstrapping Model

Superpowers uses a single session-start hook that reads the full content of one skill
(`using-superpowers/SKILL.md`) and injects it into Claude's context as `additionalContext`.
That one skill establishes all the rules:

- Check every available skill before responding to any prompt
- If there is even a 1% chance a skill applies, invoke it before doing anything else
- User instructions > Superpowers skills > default system prompt

All other skills are loaded lazily: only their frontmatter metadata (name + description)
is pre-loaded. The full SKILL.md content is read only when the skill becomes relevant.
This is deliberate token efficiency — the agent knows what skills exist without holding
their entire bodies in context.

**Contrast with Forge:** Forge's hooks operate at a more granular lifecycle level
(session-start, user-prompt-submit, pre-tool-use, post-tool-use) and enforce structural
constraints via hard gates, not just behavioral priming. Both approaches inject context
at session start; Superpowers uses that injection to establish meta-behavior, while Forge
uses it for workflow orientation.

### Skill Format

Every skill lives in `skills/<skill-name>/SKILL.md` with YAML frontmatter:

```yaml
---
name: skill-name
description: "Description Claude sees when deciding whether to invoke"
---
```

The body is markdown instructions for Claude. Key structural conventions in Superpowers
that are worth noting:

- **`<HARD-GATE>` tags**: XML-style delimiters that mark absolute rules; forces compliance
- **`<SUBAGENT-STOP>` tags**: Causes a skill to short-circuit when running as a subagent,
  so the subagent doesn't re-trigger the full orchestration chain
- **Graphviz `dot` diagrams**: Process flowcharts expressed as code blocks; rendered
  visually for humans, structured for AI
- **"Iron Laws"** with explicit anti-rationalization tables: Each rigidly-enforced skill
  lists the exact thoughts an AI might use to skip the rule, countered with the correct
  behavior. This is a behavioral engineering technique, not just documentation.
- **Red Flags tables**: Enumerate and counter common rationalizations agents use to
  skip required steps

**What to examine for Forge:** The Iron Law / Red Flags pattern is notably absent from
our SKILL.md design principles. Our skills use numbered steps and deviation rules, but
do not explicitly name and counter the failure modes (rationalizations) that would
cause an agent to skip or shortcut those steps. This is worth adding.

### Agent (Subagent) Definitions

Agents live in `agents/<name>.md` with YAML frontmatter:

```yaml
---
name: code-reviewer
description: |
  Use this agent when a major project step has been completed...
  Examples: <example>...</example>
model: inherit
---
[Full system prompt]
```

The `model: inherit` field means the agent uses whatever model the parent session uses.
The `<example>` blocks in the description are used by the platform to suggest when to
invoke the agent.

**Key structural insight:** Superpowers separates "agent" (a subagent prompt template
dispatched via Task tool) from "skill" (a process document for Claude). Forge uses the
same distinction (orchestrator skills spawn worker sub-agents), but Superpowers formalizes
it with a dedicated `agents/` directory and its own frontmatter format. Our current
design documents worker sub-agents as specifications inside epic `spec/skills.md` files;
they do not have their own directory or file format. Worth evaluating whether a dedicated
`agents/` directory would improve discoverability and maintenance.

### Hook Architecture

Superpowers uses **one hook**: a session-start script that injects the bootstrapping
skill. That is the entire hook surface.

```
hooks/
└── session-start    (bash script; also hooks.json for Claude Code, hooks-cursor.json for Cursor)
```

The session-start script:
1. Reads full content of `skills/using-superpowers/SKILL.md`
2. JSON-escapes it
3. Returns it as `additionalContext` in the hook response
4. Detects platform (Claude Code vs Cursor vs other) via env vars and emits the
   appropriate JSON format

There are no PreToolUse, PostToolUse, or UserPromptSubmit hooks. All behavioral enforcement
happens through the skills themselves (an agent that loads the right skills before acting
will behave correctly). Phase gates are behavioral, not structural.

**Contrast with Forge's hook model:** Forge's hooks are structurally enforcing:
PreToolUse hooks block writes to downstream artifact paths until phases are approved
(exit code 2). Superpowers' approach relies entirely on the agent choosing to follow
the process — if the agent skips a skill invocation, nothing structural stops it.
Superpowers compensates with behavioral engineering (Iron Laws, anti-rationalization)
where Forge compensates with structural enforcement (hard gates).

This is a meaningful philosophical difference:
- Superpowers trusts the agent to follow the process if the process is well-described
- Forge does not trust the agent and enforces the process structurally

For an enterprise compliance context, Forge's approach is more appropriate. For
flexibility and ease of adoption, Superpowers' approach is lower friction.

### Distribution Model

Superpowers ships as a single Claude Code plugin from the official marketplace:

```
/plugin install superpowers@claude-plugins-official
/plugin update superpowers
```

The plugin structure:
```
.claude-plugin/
└── plugin.json       # name, version, author, keywords
```

Skills, agents, hooks, and commands directories are all referenced by the plugin.
There is no package system — you get the whole thing or nothing.

**Contrast with Forge's model:** Forge uses a two-plugin marketplace model (forge + rr-standards)
with an internal package architecture (rr-core, workflow-light, workflow-full, implementation,
review, qa, operations) for selective installation. Superpowers' all-or-nothing approach
is simpler to install and maintain but doesn't support teams that only need a subset of
capabilities. Forge's package model adds complexity but serves organizations where different
teams have very different needs.

---

## What Superpowers Does Well (Adopt or Adapt)

### 1. The Meta-Skill Pattern

Superpowers' most important architectural insight is the meta-skill: a single skill whose
job is to tell Claude how to use all other skills. `using-superpowers` is loaded at session
start and establishes the rule "always check skills before responding."

Our `using-skills` skill exists for the same purpose and is routed by the UserPromptSubmit
hook. The difference is where the meta-skill is injected: Superpowers puts it in
`additionalContext` via the session-start hook (so it's always present from the first
moment); Forge surfaces it as a recommendation when the prompt matches a skill-use pattern.

**What to consider:** Injecting the meta-skill content at session start (not just
recommending it) would mean every session starts with Claude understanding the skill
invocation protocol. Currently, an engineer who doesn't invoke `forge:help` or
`forge:status` may not be oriented to the skill system. A session-start hook that
injects a brief skill-use summary (not the full skill, but a reminder that skills exist
and how to find them) would close this gap.

### 2. Iron Laws and Anti-Rationalization Tables

This is Superpowers' most distinctive behavioral engineering technique. Every rigidly-
enforced rule is paired with:
- A named "Iron Law" statement (e.g., "NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST")
- A table of "Red Flags" — specific thoughts the agent might have to rationalize
  skipping the rule — with explicit counters for each

Example:
```
| Agent thinks... | Reality |
|---|---|
| "The tests are simple enough that I can write them after" | No. Write them first. |
| "The existing tests cover this path" | Verify this is true before writing code. |
```

This is not just documentation — it is proactive counter-programming against the specific
failure modes the authors observed. It works because it names the failure mode before it
occurs, making it visible to the agent as a recognized pattern rather than a novel
rationalization.

**What to adopt for Forge:** Our implementation skills (`forge:build-api`,
`forge:build-repo`, etc.) have deviation rules that define what to handle autonomously
vs. escalate. But they do not name the failure modes that would cause an agent to skip
or misapply those rules. Adding a brief anti-rationalization section to each implementation
skill's SKILL.md would address the gap between "the agent knows the rule" and "the agent
follows the rule under pressure."

### 3. `<SUBAGENT-STOP>` Tags for Context Isolation

When a skill is invoked by a subagent (not the main session), Superpowers uses
`<SUBAGENT-STOP>` tags to tell the agent to short-circuit. This prevents a subagent from
recursively invoking the full orchestration chain — it reads the tag, knows it's running
as a subagent, and skips the parts that only make sense in the main session.

**What to adopt for Forge:** Our three-tier context model (main session → worker skills →
internal agents) has a similar problem: if a worker skill reads its SKILL.md and sees
instructions to "invoke `forge:status` and check the workflow state," it would be wrong
for the worker to do this (workers have no access to session state). We currently document
this in the worker classification table, but the skill's SKILL.md itself has no mechanism
to tell a worker "skip this section — it only applies when running in the main session."

A `[orchestrator-only]` or `[main-session-only]` marker in SKILL.md sections would
serve the same purpose as `<SUBAGENT-STOP>`.

### 4. Graphviz Diagrams in Skill Files

Superpowers embeds Graphviz `dot` language diagrams inside skill markdown as code blocks.
These serve two purposes:
- For humans: rendered as visual flowcharts in documentation
- For AI: structured representation of decision logic that is easier to process than
  prose branching

**What to consider for Forge:** Our SKILL.md files use numbered steps and routing tables.
For the more complex workflow skills (e.g., `using-skills`'s routing table, or the
`forge:promote` phase completion ritual), a Graphviz diagram embedded alongside the prose
would make the decision logic more explicit and less ambiguous.

### 5. Deprecated Commands Forwarding to Skills

Superpowers' `commands/` directory exists for backward compatibility. All commands now
simply tell the user the command is deprecated and redirect to the current skill. This
provides a clean migration path without breaking existing users.

**What to adopt for Forge:** As Forge evolves and skills are renamed or consolidated,
keeping stub commands that forward to the new skill name (with a deprecation notice)
prevents breakage for engineers who have the old command name in muscle memory.

### 6. Evidence-Over-Claims Enforcement

A Superpowers core principle: "No completion claims without fresh command output."
The verification-before-completion skill enforces that an agent cannot declare a task
done without running the relevant commands and showing output. This is a specific guard
against the failure mode where an agent says "I've completed the implementation" without
having actually verified it.

**Forge already has this** in `forge:verify`, which runs before `forge:promote`. But
the principle could be stated more explicitly in implementation skills — particularly
in the deviation rules for `forge:build-api` and `forge:build-repo`, which should
explicitly say "do not declare a task complete without running the build and confirming
compilation."

### 7. Two-Stage Review (Spec Compliance + Code Quality)

Superpowers' `subagent-driven-development` skill enforces two separate review passes per
task: spec compliance first (did we build the right thing?), then code quality (did we
build it well?). These are separate subagents with separate prompts, and the order matters.

**Forge already has this separation** via `forge:verify` (delivery against stated goals)
and `forge:review` (code quality, security, standards). The separation is architecturally
sound. What Superpowers adds is that both happen per-task during implementation, not just
at PR time. Worth considering whether `forge:verify` should be invokable at the task level,
not just as a pre-promotion gate.

---

## What Superpowers Does That We Deliberately Won't Replicate

### 1. Structural-Gate-Free Architecture

Superpowers has no PreToolUse hooks enforcing phase gates. An agent can write production
code at any point. The only enforcement is behavioral (the skills tell the agent not to).
For an enterprise with compliance requirements, audit trail needs, and multiple concurrent
contributors, this is insufficient. Forge's hard gates (exit code 2 on phase violations)
are the right call.

### 2. No Standards Library

Superpowers contains no organization-wide standards. Its skills contain behavioral
guidance (TDD, debugging process, commit practices) but no domain standards (REST API
design, storage schema conventions, security requirements). Each team using Superpowers
would layer their own standards on top.

Forge's standards library (`standards/`, `languages/`) bundled with the plugin is a
significant differentiator. It means the same skill that generates an API contract is
enforcing the same REST standard that `forge:review` will evaluate the PR against.
Superpowers doesn't close this loop.

### 3. Single-Platform Workflow (No Jira, No DataDog, No GitHub Actions)

Superpowers is a Claude Code / multi-agent tool. It has no integrations with project
management systems, observability platforms, or CI/CD pipelines. Forge's Jira sync,
DataDog integration, and GitHub Actions automation (`forge:diagnose`, `forge:remediate`,
`forge:monitor`) serve a different use case: teams that run software in production and
need to close the loop between planning, implementation, and operations.

### 4. No Repository State Model

Superpowers has no `.state.json`, no phase tracking, no master registry, no audit trail
of what was built and when. The traceability (requirement → design → implementation →
test → PR) that Forge provides through `.forge/efforts/` and structured git notes does
not exist in Superpowers. For enterprise software development, this traceability is a
requirement, not a nice-to-have.

### 5. No Package Selectivity

Superpowers is all-or-nothing. A team that only wants PR review cannot install just the
review skill; they get the full library. Forge's package model allows a CI-only install
(review + operations, no workflow skills) for teams that don't want the interactive
workflow tooling.

---

## Gaps in Our Architecture Revealed by Superpowers

### Gap 1: Session-Start Skill Orientation

Superpowers ensures that from the first moment of any session, Claude knows it is
operating inside a skill system and must check skills before acting. Forge's session-start
hooks inject workflow context and a standards reminder — but they do not inject the
skill-use meta-instruction.

A new engineer in a Forge-initialized project who doesn't know to invoke `forge:help`
will not be automatically oriented to the skill system. The session-start hook should
emit a brief reminder that Forge skills are available and how to find them (the existing
`01-inject-workflow-context.sh` gets close, but could be more explicit about the skill
invocation protocol).

**Proposed addition:** Extend `01-inject-workflow-context.sh` to include a one-line
skill invocation reminder: "To see available actions: `/forge:status`" or similar.
Or add a dedicated `04-inject-skill-reminder.sh` that mirrors what Superpowers'
session-start hook injects for `using-superpowers`.

### Gap 2: No Anti-Rationalization Patterns in Implementation Skills

Our deviation rules define what agents must escalate vs. handle autonomously. They do not
name the specific failure modes (rationalizations) that would cause an agent to violate
those rules under pressure. Superpowers' Iron Law + Red Flags pattern is an effective
technique for making rules stick.

**Proposed addition:** Add a `## Common Failure Modes` or `## Anti-Rationalizations`
section to each implementation skill's SKILL.md. This section names the specific thoughts
an agent might use to skip or shortcut the skill's required steps, with explicit counters.
This is especially important for:
- `forge:test` (where the rationalization is "the implementation is self-evidently correct")
- `forge:build-api` / `forge:build-repo` (where the rationalization is "this is a minor
  deviation, I'll just implement it and document it later")
- `forge:commit` (where the rationalization is "these are related changes, I'll put them
  in one commit")

### Gap 3: No Subagent Context-Boundary Markers in SKILL.md

Our worker skills have sections that only apply when running in the main session
(e.g., "check `.state.json` for context"). When a worker sub-agent reads a SKILL.md,
it encounters these instructions without a mechanism to know they don't apply.

**Proposed addition:** A `[orchestrator-only]` marker (or equivalent) for SKILL.md
sections that should not be executed by a worker sub-agent. This mirrors Superpowers'
`<SUBAGENT-STOP>` tags and makes the context-boundary explicit in the skill file itself
rather than relying on the worker to infer it from the worker/orchestrator classification.

### Gap 4: Agent Definitions Lack Formal Directory and Format

Our internal agents (the specialist reviewers spawned by `forge:review`, the analysis
workers spawned by `forge:map`) are documented as specifications inside epic `spec/skills.md`
files. They do not have their own directory, their own file format, or their own frontmatter.

Superpowers' `agents/` directory with YAML frontmatter (including `model: inherit` and
`<example>` blocks in the description) provides a clear, discoverable location for agent
definitions. When the number of internal agents grows, our current documentation-in-spec
approach will be harder to maintain.

**Proposed consideration:** Evaluate whether a `agents/` directory alongside `skills/`
would improve the maintainability of our internal agent definitions. This is not urgent
but becomes increasingly relevant as `forge:review`, `forge:map`, and `forge:diagnose`
each add multiple internal agents.

### Gap 5: Lazy Skill Loading Not Specified

Superpowers explicitly designs for lazy loading: only frontmatter metadata is pre-loaded;
full skill content is loaded on demand. This is why Claude Code can "know" about 20+ skills
without them all consuming context.

Our current design is silent on whether skill bodies are loaded lazily or eagerly. For
the Forge plugin, which has 35+ skills, the lazy loading question is material.

**Proposed clarification:** Document in the skill design rules whether Forge skill bodies
are lazily loaded (relying on Claude Code's built-in behavior for skill discovery) or
whether there is any explicit management of which skills are in context at any given time.
This affects how much we can assume Claude "knows" about all available Forge skills in
any given session.

---

## Summary Table

| Dimension | Superpowers | Forge |
|-----------|-------------|-------|
| **Enforcement model** | Behavioral (Iron Laws, anti-rationalization) | Structural (PreToolUse hard gates) + behavioral |
| **Hook surface** | Session-start only | Session-start + UserPromptSubmit + PreToolUse + PostToolUse |
| **Phase gates** | None | Hard gates (exit code 2) enforced by hooks |
| **Standards library** | None | Bundled (standards/, languages/) with plugin |
| **State model** | None | `.state.json` per work item; phase tracking; checkpoint/resume |
| **Audit trail** | None | `.forge/efforts/` + structured git notes |
| **Integrations** | None | Jira, DataDog, GitHub Actions |
| **Subagent model** | Informal (agents/ dir, dispatched by skills) | Formal three-tier classification; declared in frontmatter |
| **Distribution** | Single plugin, all-or-nothing | Two plugins + internal package system |
| **Skill discovery** | Meta-skill at session start; lazy full-content loading | UserPromptSubmit hook + `forge:help` routing |
| **Anti-rationalization** | Explicit Iron Laws + Red Flags tables | Not present; deviation rules only |
| **Subagent context markers** | `<SUBAGENT-STOP>` tags | Not present in SKILL.md files |
| **Target use case** | General-purpose AI coding discipline | Enterprise software development lifecycle |

---

## Summary of Recommended Changes

The following additions to our architecture are warranted based on this analysis:

| Change | Priority | Section Affected |
|--------|----------|-----------------|
| Extend `01-inject-workflow-context.sh` to include a skill-invocation reminder | Medium | Hooks Architecture |
| Add anti-rationalization patterns to implementation skills' SKILL.md | High | Skill Design Rules + individual SKILL.md files |
| Add `[orchestrator-only]` markers for SKILL.md sections that don't apply to workers | Medium | Skill Design Rules |
| Document lazy vs. eager skill loading behavior | Low | Skill Design Rules |
| Evaluate `agents/` directory for internal agent definitions | Low | Repository Layout, Skills Architecture |
