# Learnings from Google Conductor

Reference: https://github.com/gemini-cli-extensions/conductor

This document captures what our architecture should adopt, adapt, or consciously avoid
from Conductor's implementation. It should be read alongside `architecture.md` and used
to inform plan-phase revisions.

---

## What Conductor Does Well (Adopt or Adapt)

### 1. Commit SHA Tracking in the Task Plan

Conductor records the first 7 characters of each task's commit SHA directly in `plan.md`
next to the completed task marker. This creates a direct, human-readable link from every
planned task to the exact code change that satisfied it.

```
- [x] Implement user preference storage (a3f9b12)
- [x] Add API endpoint for preference update (c7e2d84)
```

**What to adopt:** Our `plan/tasks.md` should record commit SHAs at task completion.
This is traceability (BR-6) implemented at zero additional infrastructure cost. The
`plan/update` skill should include this as a required step.

---

### 2. git notes for Rich Task Metadata

Beyond commit SHAs in plan files, Conductor attaches detailed task summaries to commits
via `git notes`. The commit message stays clean and conventional; the full context
(what was implemented, what tests were written, what deviations from plan occurred)
lives in the note.

```bash
git notes add -m "Task: Implement preference storage
Track: PROJ-1234
Phase: 2 - Data Layer
Tests written: PreferenceRepositoryTest (12 assertions)
Coverage: 87%
Deviations: None" <commit-sha>
```

**What to adopt:** The `implement/tests` and `create-commit` skills should write git
notes with structured metadata. This enables semantic analysis of the git history by
future agents without requiring them to parse commit messages or plan files. It is
particularly valuable for the `diagnose` skill, which can correlate production incidents
with specific task completions.

**What to adapt:** Conductor's notes are prose. Ours should be structured (JSON or
consistent key-value) so they are machine-parseable by the `diagnose` and `rollout-monitor`
skills without natural language extraction.

---

### 3. Semantic Revert Capability

Conductor's `/conductor:revert` understands logical work units, not raw commits. Given
a track, phase, or task name, it parses the commit SHAs from `plan.md`, reconciles
non-linear git history (rebases, squashes, merges), presents an execution plan, and
reverts the logical unit.

This is meaningfully different from `git revert <sha>` — it reverses a capability, not
a commit.

**What to adopt:** We need a `workflow/revert` skill that operates at the same semantic
level: revert a task, a planning phase, or an entire work-id. The commit SHAs recorded
in `plan/tasks.md` (see point 1) are the mechanism that makes this possible.

---

### 4. Resumable Multi-Step Operations

Conductor uses `setup_state.json` to checkpoint initialization progress. If setup fails
or is interrupted partway through, the next invocation resumes from the last successful
step rather than starting over.

**What to adopt:** Any skill that writes multiple artifacts (e.g., `requirements/extract`
writing both `business.md` and `technical.md`, or `design/api` writing multiple contract
files) should checkpoint its progress in `.state.json`. A partially-completed skill run
should be continuable, not restartable from scratch. The `init` skill in particular
needs this — creating a full workflow directory is many steps and failure mid-way leaves
an inconsistent state.

---

### 5. Numbered Protocol Steps in Skill Definitions

Conductor's skill instructions (their GEMINI.md equivalents) use explicitly numbered
protocols: step 1.0, 1.1, 1.2, then 2.0, 2.1, etc. Each step has explicit success
criteria and failure handling. This makes skill behavior predictable, auditable, and
debuggable.

**What to adopt:** Our SKILL.md files should use numbered steps rather than prose
instructions. This matters because:
- When a skill fails partway through, the engineer can see exactly which step failed
- Resumable operations (point 4) can reference step numbers in checkpoint state
- It reduces ambiguity in how Claude interprets the instruction sequence

---

### 6. Phase Completion as a Defined Ritual, Not Just a Gate

Conductor's phase completion protocol is a 10-step ritual: run tests, verify coverage,
generate verification steps, await human confirmation, create checkpoint commit, attach
git notes, update plan. The gate is not just a boolean check — it is a structured
process that produces its own artifact (the checkpoint commit with notes).

**What to adopt:** Our `workflow/promote` skill (which advances a phase to `approved`)
should follow a defined protocol rather than just updating `.state.json`. For full-tier
workflows this includes: running relevant validation checks, producing a phase summary,
requiring the engineer to explicitly confirm, creating a checkpoint commit, and only
then marking the phase approved.

---

### 7. PR Review Chunking Strategy

Conductor's `/conductor:review` uses a 300-line threshold: small diffs are reviewed in
one pass; large diffs are processed file-by-file with user confirmation between chunks.
This is a practical acknowledgment that large context windows degrade quality.

**What to adopt:** Our `review/pr` skill should implement the same chunking logic. A
PR with 50 changed files cannot be reviewed at the same quality level as a PR with
5 files if processed in one pass. The skill should assess diff size first, and if it
exceeds a threshold, perform iterative file-by-file analysis and aggregate findings.
The threshold should be configurable in the skill's configuration.

---

### 8. Master Registry File

Conductor maintains `conductor/tracks.md` — a human-readable registry of all tracks
with their status. This is separate from the per-track `.state.json` and serves a
different purpose: giving an at-a-glance view of all work without having to open
individual directories.

**What to adapt:** We should maintain `.forge/efforts/README.md` as a human-readable index of
all work items: their ID, title, type, tier, risk, current phase, and status. The
`workflow/init` skill creates the entry; `workflow/promote` and `plan/update` keep it
current. This gives engineers and agents a single file to understand what is in flight
without traversing the directory tree.

---

### 9. Greenfield vs. Brownfield Detection

Conductor's setup command detects whether a project is new or existing before choosing
how to scaffold. For existing projects it reads existing structure and adapts rather
than overwriting.

**What to adopt:** Our `init-repo` skill must do the same. It should detect whether a
`.forge/` directory, `CLAUDE.md`, or `docs/` already exists and adapt accordingly —
merging, not overwriting. Blind overwrite of an existing CLAUDE.md would destroy project
customizations.

---

## What Conductor Does That We Deliberately Won't Replicate

### 1. Single-Project, Single-Context Design

Conductor is scoped to one project per setup. Its context files (`product.md`,
`tech-stack.md`, etc.) are project-specific. It has no concept of shared organizational
standards across many projects.

**Our approach is different by design.** Our standards are organization-wide, maintained
in a central repository (rr-standards), and referenced by all projects. A Conductor-style
setup embeds standards per-project; our architecture pulls them from a shared source.
This is a deliberate trade-off in favor of consistency and maintainability across an
enterprise.

### 2. Code Style Guides as In-Repository Files

Conductor ships language-specific style guides as checked-in files within its `conductor/`
directory. This means every project carries its own copy of the Go style guide, Python
style guide, etc.

**Our approach:** Standards live in rr-standards and are referenced from each project's
CLAUDE.md, not copied into it. A change to the Go standard propagates to all projects
automatically. Conductor's approach creates drift; ours does not.

### 3. Free-Form Prose in git notes

Conductor's git notes are readable but not machine-parseable. As noted above, we will
use structured key-value metadata in git notes so future agents can consume them
programmatically.

### 4. Advisory Phase Gates

Conductor's phase completion gates are human-confirmation-based and technically
bypassable ("Ignore warnings and proceed"). This is pragmatic for a general-purpose tool
but insufficient for our enterprise compliance requirements. Our `PreToolUse` hooks
enforce gates at the tool call level — the engineer cannot write to a downstream artifact
path without triggering a hard block (exit code 2), not a soft warning.

---

## Gaps in Our Architecture Revealed by Conductor

### Gap 1: No Revert Capability

We have no analog to Conductor's `/conductor:revert`. Our architecture assumes forward
progress. If an implementation task is completed incorrectly, or an entire phase needs
to be reopened, there is no defined mechanism. This needs a `workflow/revert` skill.

**Proposed addition:** `workflow/revert` skill that accepts a scope (task, phase, or
work-id), parses commit SHAs from `plan/tasks.md`, validates the revert plan with the
engineer, executes the git revert, and updates `.state.json` and `.forge/efforts/README.md`.

### Gap 2: No Checkpoint/Resume for Multi-Artifact Skills

Our skills are defined as single logical operations but several of them write multiple
files. We have no mechanism to resume a partially-completed skill run. If `design/api`
fails after writing three of five contract files, the engineer has no way to continue
from step 3.

**Proposed addition:** A `checkpoint` field in `.state.json` at the phase level,
recording the last completed step number for the active skill. Skills reference this
on invocation to determine whether to start fresh or resume.

### Gap 3: No Human-Readable Work Registry

Our `.forge/` tree is navigable but has no single entry point for "what is in flight".
An engineer joining a project mid-stream has to inspect multiple directories to
understand the state of work.

**Proposed addition:** `.forge/efforts/README.md` maintained as an index of all work items.
Updated by `workflow/init`, `workflow/promote`, and `plan/update`.

### Gap 4: Commit SHAs Not Tracked in Plan

Our current plan model (`plan/tasks.md`) tracks task status but not the commit that
satisfied each task. Without this, the traceability from plan → code is only as good
as commit message discipline, which degrades over time.

**Proposed addition:** The `plan/update` skill must record the commit SHA next to each
task it marks complete. Standardized git notes (structured JSON) written at commit time.

### Gap 5: PR Review Has No Chunking Strategy

Our `review/pr` skill is defined at a high level but has no guidance on how to handle
large diffs. For an enterprise with PRs that can span dozens of files, single-pass review
quality will degrade.

**Proposed addition:** Explicit chunking protocol in the `review/pr` skill definition,
with a configurable line threshold and a defined aggregation step that synthesizes
per-chunk findings into a unified report.

---

## Summary of Architectural Changes

The following changes to `architecture.md` are warranted based on this analysis:

| Change | Section Affected |
|--------|-----------------|
| Add `workflow/revert` to skill taxonomy | Skills Architecture |
| Add `.forge/efforts/README.md` master registry | Workflow Infrastructure |
| Add checkpoint/resume to `.state.json` model | Workflow State Model |
| Add commit SHA + structured git notes to `plan/update` and commit skills | Skills Architecture |
| Add phase completion ritual to `workflow/promote` | Skills Architecture, Hooks |
| Add chunking protocol to `review/pr` | Skills Architecture |
| Add greenfield/brownfield detection to `init-repo` | Skills Architecture |
| Document that git notes are structured JSON | Data Models |
