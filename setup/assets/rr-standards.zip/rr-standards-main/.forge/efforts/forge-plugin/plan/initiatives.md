# Forge Framework — Initiatives & Epics

High-level delivery plan. Each epic becomes its own work item in projects with its own Forge workflow.

---

## Initiative 1: Automated Code Review

*Sprint 1 priority. Delivers AI PR feedback with no Forge infrastructure dependency.*

**Sprint goal:** Automated AI PR feedback within 2–3 weeks.

| Epic | What it delivers |
|------|-----------------|
| AI PR Review | Chunked diff analysis, parallel sub-agent review, aggregated findings report. Detects languages in the diff and injects the corresponding coding standards — review is grounded in org standards, not Claude's training set alone. |
| Security Review | OWASP/standards-based automated security analysis per PR |
| Privacy Review | PII and data handling review per PR |
| Traceability Review | Requirements-to-implementation coverage check |
| Review Automation | GitHub Actions trigger so reviews run without manual invocation |

**Key constraint — AI PR Review:** Language-specific coding standards must exist in a consumable form for each language in scope (Go, Java, TypeScript, Kotlin, Swift, Python). Writing or formalizing missing standards is in scope for that epic. The skill must detect which languages are present in the PR and load the appropriate standards before reviewing.

---

## Initiative 2: Forge Platform Core

*Foundational infrastructure. Initiatives 3–6 depend on this being stable. Existing `skills/workflow/` and `packages/` remain supported throughout.*

| Epic | What it delivers |
|------|-----------------|
| Workflow State & Registry | `.state.json` schema, `.forge/efforts/README.md` master registry, phase model |
| Session Continuity | `forge:pause` / `forge:resume`, context monitoring hook |
| Installation & Distribution | `forge:init`, `forge:update`, `setup.sh` redesign, version enforcement hook |
| Brownfield Onboarding | ~~`forge:map`~~ (deprecated) — brownfield codebase analysis and greenfield/brownfield detection incorporated into `forge:init` · **Complete** |
| Multi-Repository Project Support | Cross-repo reference format for work item hierarchy; `repo_type` marker in `.forge/version`; `effortRef` field in `.state.json` for product artifact attribution; registry representation for cross-repo items. (BR-23, ADR-027) |

---

## Initiative 3: Spec-Driven Development

*The upstream AI-assisted workflow from idea to working code.*

| Epic | What it delivers |
|------|-----------------|
| Discovery Phase | Requirements capture, design generation (API, storage, messaging, ADR, test strategy), validation |
| Planning | Plan generation, risk/tier classification, wave-based task annotation |
| Implementation Phase | Scaffolding, code generation, phase gate enforcement, commit SHA tracking |

---

## Initiative 4: Quality & Assurance

*Structured QA process with formal sign-off, replacing informal review.*

| Epic | What it delivers |
|------|-----------------|
| QA Execution | Test execution assistance, defect mapping, coverage gap analysis |
| QA Sign-off | Quality gate decisions, templates, regression test generation |

---

## Initiative 5: Operations

*AI-assisted production operations, post-deploy.*

| Epic | What it delivers |
|------|-----------------|
| Runbook Generation | Auto-generated runbooks from codebase and deployment config |
| Incident Response | Diagnosis tooling, safe/unsafe remediation classification |
| Production Monitoring | Rollout monitor, alerting standards, `rollout-monitor.yml` Actions template |

---

## Initiative 6: Integrations

*Eliminate remaining manual handoffs.*

| Epic | What it delivers |
|------|-----------------|
| Jira Bi-directional Sync | Pull from Jira, push status back, conflict detection/resolution |
| GitHub Actions Expansion | Automation beyond PR review — scheduled jobs, incident triggers |

---

## Initiative 7: Adoption & Migration

*Runs as a thread throughout, not a phase that starts at the end.*

| Epic | What it delivers |
|------|-----------------|
| Alpha Workflow Support | Existing `skills/workflow/` and `packages/` remain functional until teams migrate |
| Migration Tooling | Migration guide, cutover tooling, team-by-team transition support |
| Platform Onboarding | Workshops, platform-specific standards and skill variants per team |

---

## Initiative 8: Developer Experience & Scaffolding

*Covers "day zero" of any new service — before a single line of product code is written.*

| Epic | What it delivers |
|------|-----------------|
| Service Scaffolding | `forge:scaffold` generates a new service skeleton: CDK app, Dockerfile, `.devcontainer`, `docker-compose.yml`, GitHub Actions CI stub, health-check endpoint, structured logging bootstrap, and test harness — matched to the detected language (Go, Java, TypeScript, Kotlin, Swift) |
| Local Dev Environment | `forge:localenv` generates `docker-compose.yml` with all service dependencies (databases, caches, queues), `.env.local` template with required vars, and seed scripts so any engineer can `docker compose up` and be running in minutes |
| Developer Onboarding | `forge:onboard` generates a project-specific onboarding guide from the effort registry and deployables — prerequisites, first PR checklist, local setup verification steps |

---

## Initiative 9: Infrastructure & Cloud

*AWS + CDK/CloudFormation. All infrastructure is generated as code, never clicked through a console.*

| Epic | What it delivers |
|------|-----------------|
| CDK Stack Generation | `forge:infra` generates CDK stacks for standard patterns: VPC, ECS Fargate services, Lambda functions, API Gateway, RDS Aurora (PostgreSQL), DynamoDB tables with GSIs, ElastiCache (Redis), OpenSearch domains — parameterized per environment (dev/staging/prod) |
| Multi-Env Config | Environment-specific configuration pattern: CDK context variables, SSM Parameter Store paths, and per-environment override strategy. Generates `cdk.json` and environment stacks |
| Infrastructure Validation | `forge:validate-infra` reviews CDK stacks against org standards (security groups, encryption at rest, tagging policy, IAM least-privilege) before deploy |
| Cost Awareness | Generates cost-tagged resource stacks; provides cost estimate commentary in CDK code using AWS Pricing API conventions |

---

## Initiative 10: Data Layer

*Schema, migration, and data operations across all four database technologies in use.*

| Epic | What it delivers |
|------|-----------------|
| PostgreSQL / Aurora Migrations | `forge:migrate` generates Flyway migration scripts from storage schema changes; validates naming conventions, reversibility, and index safety before apply |
| DynamoDB Provisioning | CDK constructs for table + GSI definitions generated directly from `forge:spec-storage` output; includes capacity mode selection (on-demand vs. provisioned) and auto-scaling config |
| Redis / ElastiCache Setup | CDK constructs for ElastiCache cluster; generates connection config, eviction policy guidance, and TTL strategy from storage design |
| OpenSearch Index Management | Index template generation, ILM policy, and mapping validation from storage design; CDK domain provisioning |
| Backup & DR | `forge:dr` generates backup policies (RDS snapshots, DDB point-in-time recovery, ElastiCache backup), RTO/RPO documentation, and failover runbooks per deployable |

---

## Initiative 11: Observability Platform

*Every service ships with instrumentation, dashboards, and alerts — not as an afterthought.*

| Epic | What it delivers                                                                                                                                                                    |
|------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Instrumentation Scaffolding | `forge:instrument` injects structured logging (JSON, correlation IDs), CloudWatch metrics emission, and OpenTelemetry trace spans into generated service code — matched to language |
| Standards Population | Fills the currently-empty `standards/observability/` files with concrete patterns for logging format, metric naming, trace propagation, and alert severity levels                   |
| Dashboard Generation | `forge:dashboard` generates CloudWatch dashboard CDK constructs from a deployable's defined metrics and SLOs                                                                        |
| Alert Rule Generation | Generates CloudWatch Alarm CDK constructs from SLO definitions; maps to SNS topics / PagerDuty as configured                                                                        |
| SLO / SLI Definition | Adds SLO definition step to the discovery phase (`forge:spec-slo`); SLOs flow downstream into dashboards and alerts                                                                    |

---

## Initiative 12: Release, Security & Governance

*The full lifecycle tail: how features ship safely, secrets stay secret, and the system stays compliant.*

| Epic | What it delivers |
|------|-----------------|
| CI/CD Pipeline Generation | `forge:pipeline` generates GitHub Actions workflow files for build, test, CDK deploy, and post-deploy smoke tests — parameterized per language and environment tier |
| Feature Flags | `forge:flags` generates AWS AppConfig feature flag definitions and client SDK integration; links flags to effort IDs for traceability |
| Secrets Management | `forge:secrets` generates AWS Secrets Manager / SSM Parameter Store CDK constructs and application-side retrieval patterns; enforces no-plaintext-in-code policy via PR review hook |
| Dependency & Supply Chain | `forge:deps` runs SBOM generation and vulnerability scan as a PR gate; surfaces high/critical CVEs with remediation guidance |
| Release Management | `forge:release` generates changelog from conventional commits, bumps semver, creates GitHub release with artifact links |
| Compliance & Audit | `forge:audit` generates audit logging injection and retention policy CDK constructs; produces compliance summary artifact during `forge:verify` |
| Service Decommissioning | `forge:decommission` orchestrates service sunset: deprecation notice, data migration plan, traffic-drain runbook, and CDK teardown stub |

---

## Delivery Sequence

```
Now        → Initiative 1  (Code Review — already in flight)
Next       → Initiative 2  (Platform Core — unlocks everything below)
Then       → Initiatives 3, 4, 5, 8 in parallel
               (Spec-Driven Dev, QA, Operations, Developer Experience)
            → Initiative 9  (Infrastructure — depends on Platform Core + Spec-Driven Dev)
            → Initiative 10 (Data Layer — depends on forge:spec-storage being stable)
            → Initiative 11 (Observability — depends on service scaffolding from Init 8+9)
Later      → Initiative 12 (Release/Governance — builds on all shipped capabilities)
            → Initiative 6  (Jira/GH Actions — enhances already-shipped capabilities)
Throughout → Initiative 7  (Adoption & Migration)
```
