# Technical Requirements

## TR-1: forge:effort Must Create and Checkout the Working Branch

When `forge:effort` scaffolds a new effort, its final step must create a git branch
and check it out. The branch name is derived from `.forge/branching.md` if present:
Claude reads the prose body and derives an appropriate name using the effort title,
type, ID, and Jira key as inputs. If `.forge/branching.md` does not exist, the
default branch name is `effort/<effort-id>`.

The branch creation step must be idempotent: if the branch already exists (effort
resumed after interruption), checkout without error.

For cross-repo sub-efforts created by `forge:project`, the same convention applies:
derive from `.forge/branching.md` if present, otherwise use `effort/<local-effort-id>`.

## TR-2: A PreToolUse Hook Must Block git commit and git push to the Default Branch

A new hook `enforce-branch-policy.sh` fires on every Bash tool call. Its only
responsibility is to check whether the command contains a git commit or git push
targeting the default branch. If it does, it exits 2 (block) with a structured
diagnostic.

**Detection logic:**
- Tool name is `Bash`
- Command contains `git commit` or `git push` (substring match, not exact)
- Current branch (`git branch --show-current`) is `main`, `master`, or the value of
  `init.defaultBranch` in git config

**Structured diagnostic (JSON to stderr):**
```json
{
  "type": "branch_policy_violation",
  "blocked": true,
  "reason": "Direct commits to 'main' are not permitted. All work must happen on a feature branch and be merged via pull request.",
  "currentBranch": "main",
  "activeEffort": "<effort-id or null>",
  "nextAction": "Switch to your effort branch: git checkout <working-branch>"
}
```

The `<working-branch>` value is read from `.state.json` field `workingBranch` for
the active effort; falls back to `effort/<effort-id>` if absent.

If no active effort is detected: `nextAction` instructs the engineer to create one
with `forge:effort` before committing.

**Performance:** The hook must complete in under 100ms. It reads the branch name from
`git branch --show-current` (one process) and does a substring match (no file I/O).

**Exit codes:**
- Exit 2: commit or push to default branch detected — blocked
- Exit 0: all other cases — allowed

## TR-3: The Hook Must Not Block Legitimate Administrative Operations

The hook must detect and allow through a defined set of administrative operations that
legitimately need to touch the default branch:

- `forge:update` migrations (updating the forge:managed CLAUDE.md section)
- `forge:init` initialization of a new repository (first commit establishing .forge/)
- Manual override: presence of `FORGE_ALLOW_MAIN_COMMIT=1` environment variable,
  which the engineer must set explicitly and which is not persisted

Administrative operations detected via a `FORGE_ADMIN_OP=<reason>` environment variable
set by the skill invoking the operation. The hook logs the override to `.forge/audit/`
for traceability.

## TR-4: forge:init Must Install a Local pre-push Git Hook

In addition to the Claude Code PreToolUse hook (which only covers the AI agent),
`forge:init` must install a local git `pre-push` hook that enforces the same branch
policy for direct git CLI use by engineers.

The pre-push hook:
- Reads the branch being pushed
- If the target is the default branch and the source is not a merge commit from a
  reviewed PR: blocks with a clear error
- Can be bypassed with `git push --no-verify` for emergency operations

This creates defense in depth: both the AI agent path (PreToolUse hook) and the
direct CLI path (git pre-push hook) enforce the same policy.

## TR-5: SessionStart Hook Must Detect Branch Drift

The `inject-workflow-context.sh` SessionStart hook must include a branch check:

1. Read the current git branch
2. Read the active effort ID from `.forge/efforts/README.md`
3. Read the expected branch name from `.forge/efforts/<active-effort-id>/.state.json`
   field `workingBranch` if present; otherwise fall back to `effort/<active-effort-id>`
4. If the current branch does not match the expected branch, emit a warning as the
   top item in the session context:

```
⚠️ **Branch mismatch detected:**
Active effort: forge-branching (feat/forge-branching)
Current branch: main

Switch to the effort branch before making any changes:
  git checkout feat/forge-branching
```

5. If the current branch matches: proceed normally with no warning.

The warning does not block the session — it informs. The engineer may have legitimate
reasons to be on another branch (reviewing another effort, checking main state). The
warning ensures they know before any work is done.

## TR-6: A New Capability forge-branching Delivers This Work

The enforcement hook, git pre-push hook, and forge:effort branch creation are delivered
as the `forge-branching` capability in `.forge/deployables/forge-plugin/capabilities/`.

`forge:init` is updated to install `enforce-branch-policy.sh` as a PreToolUse hook
and to run `git config` to set the `pre-push` hook path.

The `forge-effort` capability spec is updated to add branch creation as a required
final step of effort scaffolding.

## TR-7: Branch Naming Taxonomy

All branches in a Forge-managed repository must match the repository's configured
branch naming convention, stored in `.forge/branching.md`.

**Validation source:**

`enforce-branch-policy.sh` must extract `branch_regex` from `.forge/branching.md`
YAML frontmatter using a self-contained python3 invocation. If the file is absent
or the field is missing, fall back to the Forge built-in default regex:

```
^(effort|feature|feat|fix|hotfix|chore|docs|refactor|release)/[a-z0-9][a-z0-9-]*$
```

**For repositories using the RR standard CI/CD pipeline**, `.forge/branching.md`
will contain:

```
branch_regex: "^(feat|feature|release|hotfix|bugfix)/[a-z0-9][a-z0-9-]*$"
```

Allowed prefixes in that case:

| Prefix | When to use |
|--------|-------------|
| `feat/` | New feature (short form) |
| `feature/` | New feature (long form) |
| `release/` | Release preparation |
| `hotfix/` | Urgent production fix |
| `bugfix/` | Bug fix |

**Slug format:**
- Lowercase letters, digits, and hyphens only
- No leading or trailing hyphens
- Maximum 40 characters
- Derived from the key words in the task description

**Validation:** `enforce-branch-policy.sh` must check that the current branch matches
the resolved `branch_regex` before allowing a `git commit`. If the branch name does
not match, block with a diagnostic referencing `.forge/branching.md` and offering a
suggested name.

## TR-8: CLAUDE.md Must Include Branch Creation Intent Patterns and Type Inference

The forge-managed CLAUDE.md section must include guidance for branch creation when
no active effort exists. When the engineer describes work conversationally, the agent
must create the appropriately named branch without prompting — unless the type is
genuinely ambiguous.

The agent must first read `.forge/branching.md` (if present) to determine the allowed
prefixes for this repository. All inference and suggestions must use only prefixes
permitted by the resolved convention.

**Type inference rules for RR pipeline repositories (evaluated in priority order):**

1. If an active effort exists: branch is already created by `forge:effort` — no inference needed
2. If engineer references production, urgent, critical, "hotfix", "emergency":
   → `hotfix/<slug>`
3. If engineer references a bug, crash, error, regression, "not working", "broken":
   → `bugfix/<slug>`
4. If engineer references release, version, tag, changelog:
   → `release/<version-or-slug>`
5. If engineer describes adding, building, implementing new functionality:
   → `feat/<slug>`
6. If type cannot be determined: ask one clarifying question offering only the
   prefixes allowed by the repository's convention

**For repositories using the Forge default convention**, the full inference rule set
applies: fix, hotfix, docs, refactor, chore, release, feature — in that priority order.

**Slug derivation:** extract the 3–5 most descriptive words from the request,
lowercase, join with hyphens, drop articles and prepositions. Optionally prefix with
a Jira ticket ID if referenced (e.g. `bugfix/REWD-1234-auth-crash`).

**Branch creation action:** when a branch creation intent is detected and no active
effort exists, the agent runs `git checkout -b <type>/<slug>` as part of its response.
It confirms the branch name to the engineer: "Created branch: bugfix/auth-flow-crash"

## TR-9: enforce-branch-policy.sh Must Emit a Push-Time Alignment Warning

When `enforce-branch-policy.sh` intercepts a `git push` command (not `git commit`),
it must perform a secondary check: does the work being pushed match the branch type?

**Check sequence (after the default-branch block check passes):**

1. Read the current branch name and extract its type prefix
2. If the branch matches the effort-branch pattern from the resolved `branch_regex`:
   skip alignment check (effort branches are always correct)
3. If the branch does not match the resolved `branch_regex`: emit a format warning
   referencing `.forge/branching.md` and exit 0
4. Read the commits being pushed: `git log origin/<default-branch>..HEAD --oneline`
5. Read the changed files: `git diff origin/<default-branch>...HEAD --name-only`
6. Invoke `claude -p` with the branch type, commit messages, changed file paths, and
   the allowed prefixes from `.forge/branching.md` (if present), asking: "Does the
   work described by these commits and files match a '<type>' branch? If not, suggest
   a better branch name using only these allowed prefixes: <list>."
7. If the subprocess times out (>10 seconds) or fails: skip the check, exit 0 silently
8. If misaligned: emit a warning to stdout (not stderr), exit 0

**Warning format:**
```
⚠️  Branch name may not match the work being pushed.
    Current branch: bugfix/auth-flow-crash
    Commits and changes suggest: feat/auth-token-refresh

    To rename: git branch -m feat/auth-token-refresh
    Proceeding with push anyway — rename before opening your PR.
```

**Exit code:** always 0 for this check — it is advisory only. The push proceeds
regardless of the alignment check result.

**Performance:** the `claude -p` invocation runs in a subprocess. The total additional
latency for a push is bounded by the 10-second timeout. If the check would cause
unacceptable delay, engineers can set `FORGE_SKIP_BRANCH_VALIDATION=1` to bypass.

## Constraints

- The PreToolUse hook must complete in under 100ms (single git command + string match)
- The hook must not break existing workflows that legitimately operate on branches
  other than main (all such operations are already on feature branches and unaffected)
- The FORGE_ALLOW_MAIN_COMMIT override must not be persisted in any file tracked by
  git (environment variable only) — it cannot become a default
