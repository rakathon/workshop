# Business Requirements

### BR-1: All Development Work Must Happen on Feature Branches

No code, documentation, or workflow artifact may be committed directly to the default
branch. Every piece of work — from a one-line bug fix to a multi-week initiative —
must be performed on a dedicated feature branch and merged to the default branch via a
pull request. This applies to AI agents and engineers equally.

The default branch must always represent reviewed, approved work. A commit that lands
on main without a pull request has bypassed every quality gate the organization has
established: peer review, CI checks, standards compliance, and approval policy. The
Forge framework exists to enforce these gates. It cannot do so if agents commit directly
to main.

### BR-2: Forge Must Prevent Direct Commits to the Default Branch Without Manual Override

The framework must make it structurally impossible — not merely discouraged — for an
agent to commit to the default branch in the course of normal development work. When an
agent attempts a direct commit or push to the default branch, the operation must be
blocked with a clear explanation and a concrete path forward.

This block must apply to agents acting on engineer instructions ("commit this") as well
as to agents acting autonomously (executing a task in a plan). Neither scenario may
result in an unreviewed commit landing on main.

A manual override path must exist for repository administrators performing legitimate
maintenance (e.g., updating the forge:managed CLAUDE.md section after a plugin update).
This override must require explicit acknowledgment, not just a flag or bypass argument.

### BR-3: Effort Creation Must Establish the Working Branch

When an engineer starts a new effort, the branch where that work will live must be
created automatically as part of effort initialization. The engineer should not need to
remember to create a branch, choose a name, or check out the branch manually. Starting
an effort and being on the correct working branch are the same operation.

The branch name is derived from the repository's branch naming convention, stored in
`.forge/branching.md`. If no convention file exists, the default is `effort/<id>`.
This keeps effort branches consistent with how the team names all other branches.

### BR-4: The Framework Must Detect and Recover from Branch Drift

An engineer who ends up on the wrong branch — whether through direct checkout, rebase,
or merge operations — must be informed at the start of the next session. The framework
must detect when the working branch does not match the active effort and surface this
as an actionable warning, not a silent error.

Recovery must be guided: the framework tells the engineer which branch to switch to,
not just that something is wrong.

### BR-5: Branch Policy Must Be Enforced Consistently Regardless of How Work Is Initiated

Branch policy applies whether the engineer explicitly invokes a forge skill, makes a
conversational request, or the agent acts autonomously on a task plan. The enforcement
mechanism must sit below the skill and conversation layer — in hooks that fire
regardless of how the commit command reaches the shell. An agent that bypasses skills
and uses the Bash tool directly must face the same enforcement as one following the
full workflow.

### BR-6: Branch Names Must Communicate the Nature of the Change

Every branch in the organization's repositories must signal — at a glance, without
reading any code — what kind of work it represents. An engineering manager reviewing
an open PR queue, a developer picking up an in-flight branch, or an automation tool
deciding which CI workflow to run must be able to determine whether a branch contains
a bug fix, a new feature, a documentation update, or a production emergency from the
branch name alone.

This is an organizational standard, not a preference. Inconsistent branch naming
creates friction at every handoff point: reviewers do not know what to expect before
opening a PR, release managers cannot quickly identify which branches need expedited
review, and automation cannot reliably distinguish change types. The cost of
inconsistent naming compounds as the number of concurrent branches grows.

Consistent naming also makes git history permanently more readable. Branch names
appear in merge commits, PR titles, and changelog tooling long after the work is
done. A branch named `wip-stuff` tells nothing to someone reading the history six
months later. A branch named `fix/session-token-expiry` is self-documenting.

The framework must enforce this standard, not merely suggest it. An engineer who
names a branch incorrectly must be informed before that name becomes part of the
permanent record.

### BR-7: Branches Not Associated With Efforts Must Follow the Repository's Naming Convention

Not every branch an engineer creates will correspond to a Forge effort. Ad-hoc bug
fixes, hotfixes, and feature work are legitimate development activities that do not
warrant a full effort lifecycle. These branches must follow the repository's configured
branch naming convention, stored in `.forge/branching.md`.

For repositories using the Rakuten Rewards standard CI/CD pipeline
(`rewards-devops/gh-reusable-workflows/.github/workflows/helm-upgrade-nonprod.yaml`),
the allowed prefixes are: `feat/`, `feature/`, `release/`, `hotfix/`, `bugfix/`.

For repositories without a configured convention, the Forge default type-prefixed
convention applies. The same rules that make effort branches machine-readable and
human-obvious apply here.

### BR-8: The Agent Must Infer Branch Type From Conversational Context

When an engineer asks the agent to create a branch or start work that does not map
to an existing effort, the agent must determine the appropriate branch type from the
request — not ask the engineer to pick from a taxonomy they should not need to know.
An engineer who says "let's fix the crash in the auth flow" should get a branch
named `bugfix/auth-flow-crash` (for RR pipeline repos) or the closest match from the
repository's configured convention — without any additional ceremony.

When the type genuinely cannot be inferred, the agent may ask a single clarifying
question offering only the prefixes allowed by the repository's convention. It must
not ask unless necessary.

### BR-9: The Agent Must Warn When Branch Name Does Not Match the Work Being Pushed

An engineer may start work expecting to make a small fix but end up building a
substantial new feature, or name a branch optimistically and then implement something
different. At push time — when the work is about to be shared — the agent must check
whether the commits and changed files are consistent with the branch name.

If misaligned, the engineer must be informed with a concrete suggestion for a better
branch name. This is a warning, not a block. The engineer may have context the agent
lacks and must always be able to proceed. The warning ensures the mismatch is visible
before it becomes part of the permanent PR and merge record.
