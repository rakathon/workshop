# Implementation Plan: Forge Branch Policy Enforcement

Tasks within the same wave are independent and can run in parallel on separate git
worktrees. Tasks in wave N+1 require wave N complete before starting.

**Capabilities created by this plan:**
- `forge-branching` — the enforcement hook, git pre-push hook template, branch taxonomy validation, and push-time alignment warning

**Existing capabilities modified:**
- `forge-effort` — branch creation added as final step of effort scaffolding (TR-1)
- `forge-init` — installs git pre-push hook during repository initialization (TR-4)
- `forge-effort` (hooks) — `inject-workflow-context.sh` updated with branch drift detection (TR-5)
- CLAUDE.md template — branch creation intent patterns and type inference (TR-8)

---

## Wave 1 — Capability Documentation (parallel; no dependencies)

- [x] [auto][wave:1] Scaffold the `forge-branching` capability directory under `.forge/deployables/forge-plugin/capabilities/` with the standard structure (requirements/, spec/, test/, security/, runbook/) and write the capability documentation: business requirements, technical requirements, success criteria, spec/README.md, and spec/hooks.md covering `enforce-branch-policy.sh` and the git pre-push hook template. (TASK-001)

  **Capability:** `forge-branching` (new)
  **Requirements:** TR-2 (PreToolUse hook), TR-3 (admin override), TR-4 (git pre-push hook), TR-6 (capability delivery)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-branching/` (full tree)
  - `requirements/business.md` — why branch enforcement exists
  - `requirements/technical.md` — hook behavior spec: detection logic, exit codes, structured diagnostic format, performance limit, admin override protocol, audit logging
  - `requirements/success-criteria.md` — measurable acceptance criteria
  - `spec/README.md` — capability overview
  - `spec/hooks.md` — detailed design for `enforce-branch-policy.sh` (PreToolUse) and `pre-push.sh` (git hook template): trigger, detection logic, exit code table, admin override protocol, audit log format, performance constraints, edge cases
  - `test/README.md`, `security/README.md`, `runbook/README.md`

  **Verification:** hooks.md includes exit code table (exit 2 for main commit, exit 0 for all else); admin override protocol documented; audit log format specified; `FORGE_ALLOW_MAIN_COMMIT` constraint (env var only, not persisted) explicit in requirements.

---

- [x] [auto][wave:1] Write the spec update for the `forge-effort` capability covering branch creation (TR-1) and write the spec update for `inject-workflow-context.sh` branch drift detection (TR-5). These are additions to existing capability specs, not new capabilities. (TASK-002)

  **Capability:** `forge-effort` (modification)
  **Requirements:** TR-1 (branch creation in forge:effort), TR-5 (branch drift in SessionStart hook)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/spec/skills.md` — updated: add branch creation as the final step in forge:effort's numbered steps (after atomic commit, before print summary): `git checkout -b effort/<id>` from HEAD; idempotent if branch exists
  - `.forge/deployables/forge-plugin/capabilities/forge-effort/spec/hooks.md` — updated: add branch drift check to `inject-workflow-context.sh` spec as a new section in Hook 1 behavior: read current branch, compare to expected `effort/<active-effort-id>`, emit warning at TOP of context output if mismatch

  **Verification:** forge:effort skills.md now has branch creation as a numbered step with idempotency note; hooks.md shows the drift warning appearing before the artifact inventory section; warning is informational (exit 0, not blocking).

---

- [x] [auto][wave:1] Write the spec update for `forge-init` capability covering installation of the git `pre-push` hook during repository initialization (TR-4). (TASK-003)

  **Capability:** `forge-init` (modification)
  **Requirements:** TR-4 (git pre-push hook installation)

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-init/spec/skills.md` — updated: add a new step in the forge:init flow that installs `.git/hooks/pre-push` from the `forge-branching` hook template (`plugins/forge/hooks/pre-push/pre-push.sh`); makes it executable; records installation in `.forge/version`

  **Verification:** spec shows pre-push hook installation as an explicit forge:init step; template path is referenced correctly; step notes `git push --no-verify` bypass is available for emergencies.

---

## Wave 2 — Implementation (parallel; depends on Wave 1)

- [x] [auto][wave:2] Implement `enforce-branch-policy.sh` PreToolUse hook per the `forge-branching` capability spec. (TASK-004)

  **Capability:** `forge-branching`
  **Requirements:** TR-2 (detection and blocking), TR-3 (admin override)

  **Produces:**
  - `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh` (executable)

  **Behavior:**
  1. Check tool name — if not `Bash`, exit 0 immediately
  2. Read the Bash command from `CLAUDE_TOOL_INPUT`
  3. If command does not contain `git commit` or `git push`, exit 0
  4. Check for admin override: if `FORGE_ALLOW_MAIN_COMMIT=1` or `FORGE_ADMIN_OP` is set, log to `.forge/audit/` and exit 0
  5. Get current branch: `git branch --show-current`
  6. Determine default branch: `git config init.defaultBranch` (fallback: `main`)
  7. If current branch matches default branch: emit structured diagnostic to stderr, exit 2
  8. Otherwise: exit 0

  **Verification:** attempt `git commit` on main → blocked with JSON diagnostic; `git commit` on feature branch → allowed; `FORGE_ALLOW_MAIN_COMMIT=1 git commit` on main → allowed, audit log entry written; hook completes in under 100ms.

---

- [x] [auto][wave:2] Implement the `pre-push.sh` git hook template that forge:init installs into `.git/hooks/` per the `forge-branching` capability spec. (TASK-005)

  **Capability:** `forge-branching`
  **Requirements:** TR-4 (git pre-push hook)

  **Produces:**
  - `plugins/forge/hooks/pre-push/pre-push.sh` (executable template)

  **Behavior:** The git pre-push hook receives the remote name and URL on stdin. For each ref being pushed, if the target ref is `refs/heads/main` or `refs/heads/master`, block with a clear error message directing the engineer to open a PR instead. Allow `git push --no-verify` as the emergency bypass (standard git mechanism, no additional forge logic needed).

  **Verification:** `git push origin main` from a feature branch → blocked with message; `git push --no-verify origin main` → passes through; pushing a non-main branch → allowed.

---

- [x] [auto][wave:2] Update `plugins/forge/skills/workflow/effort/SKILL.md` to add branch creation as the final scaffolding step, per the updated `forge-effort` capability spec from TASK-002. (TASK-006)

  **Capability:** `forge-effort` (modification)
  **Requirements:** TR-1

  **Produces:**
  - `plugins/forge/skills/workflow/effort/SKILL.md` — updated: Step 5 (Scaffold Directories) gains a new sub-step after the atomic commit:
    ```
    5.5 Create and checkout the working branch [orchestrator-only]
        Run: git checkout -b effort/<id>
        If branch already exists: git checkout effort/<id> (idempotent)
        Confirm to engineer: "Working branch created: effort/<id>"
    ```

  **Verification:** forge:effort SKILL.md has branch creation as step 5.5; idempotency documented; branch name format is `effort/<effort-id>`.

---

- [x] [auto][wave:2] Update `plugins/forge/hooks/session-start/inject-workflow-context.sh` to add branch drift detection per the updated `forge-effort` capability spec from TASK-002. (TASK-007)

  **Capability:** `forge-effort` (modification)
  **Requirements:** TR-5

  **Produces:**
  - `plugins/forge/hooks/session-start/inject-workflow-context.sh` — updated: immediately after identifying the active effort (before emitting any other context), check if the current branch matches `effort/<active-effort-id>`; if mismatch, emit the branch drift warning as the absolute first item in the output

  **Verification:** session start on `main` with `forge-branching` as active effort → drift warning appears at top of context before artifact inventory; session start on `effort/forge-branching` → no drift warning; session start with no active effort → no drift check.

---

- [x] [auto][wave:2] Update `plugins/forge/skills/init/SKILL.md` to include git pre-push hook installation as a forge:init step, per the updated `forge-init` capability spec from TASK-003. (TASK-008)

  **Capability:** `forge-init` (modification)
  **Requirements:** TR-4

  **Produces:**
  - `plugins/forge/skills/init/SKILL.md` — updated: new step after CLAUDE.md write — copy `plugins/forge/hooks/pre-push/pre-push.sh` to `.git/hooks/pre-push`, make executable

  **Verification:** running forge:init on a clean repository results in `.git/hooks/pre-push` existing and being executable; the hook blocks `git push origin main` from that repository.

---

## Wave 3 — Integration Tests (depends on Wave 2)

- [x] [tdd][wave:3] Integration test: branch enforcement — verify the PreToolUse hook blocks direct commits and pushes to main in all scenarios including admin override. (TASK-009)

  **Capability:** `forge-branching` (test directory)
  **Requirements:** TR-2, TR-3, BR-2, BR-5

  **Produces:**
  - `plugins/forge/test/integration/branch-enforcement/README.md`
  - `plugins/forge/test/integration/branch-enforcement/scenario.md`

  **Scenarios to cover:**
  - Agent attempts `git commit` on main via Bash tool → blocked (exit 2), structured JSON diagnostic, correct `nextAction` pointing to effort branch
  - Agent attempts `git commit` on feature branch → allowed (exit 0)
  - Agent attempts `git push origin main` on main → blocked
  - `FORGE_ALLOW_MAIN_COMMIT=1` set → allowed, audit log entry at `.forge/audit/<timestamp>.json`
  - `FORGE_ADMIN_OP=forge:init` set → allowed
  - No active effort on main → blocked, `nextAction` says to run `forge:effort` first
  - `git status`, `git log`, `git diff` on main → allowed (not commit/push commands)

  **Verification:** each scenario has input (branch state + command), expected exit code, expected output content.

---

- [x] [tdd][wave:3] Integration test: effort branch creation and drift detection — verify that forge:effort creates the working branch and that the SessionStart hook detects drift. (TASK-010)

  **Capability:** `forge-effort` (test directory)
  **Requirements:** TR-1, TR-5, BR-3, BR-4

  **Produces:**
  - `plugins/forge/test/integration/effort-branch/README.md`
  - `plugins/forge/test/integration/effort-branch/scenario.md`

  **Scenarios to cover:**
  - `forge:effort` on main → creates `effort/<id>` branch, checks it out, commits scaffold files, engineer is now on effort branch (not main)
  - `forge:effort` when branch already exists (resume) → idempotent checkout, no error
  - Session start on `effort/forge-branching` → no drift warning
  - Session start on `main` with active effort `forge-branching` → drift warning at top of context with exact branch name to switch to
  - Session start with no active effort → no drift check, no warning
  - `forge:project` creates `effort/<sub-effort-id>` branch in the local repo

  **Verification:** each scenario shows input state, expected session context output, and .state.json / branch state outcomes.

---

## Wave 4 — Branch Taxonomy and Naming Convention (parallel; depends on Wave 1)

- [x] [auto][wave:4] Update `forge-branching` capability documentation to add specs for branch taxonomy validation (TR-7) and push-time alignment warning (TR-9). Update `forge-branching/spec/hooks.md` with: branch name format validation logic in `enforce-branch-policy.sh`, the alignment warning behavior on `git push`, `claude -p` invocation format, timeout handling, and the `FORGE_SKIP_BRANCH_VALIDATION=1` bypass. Update `forge-branching/requirements/technical.md` to reflect TR-7, TR-8, TR-9. (TASK-011)

  **Capability:** `forge-branching` (modification)
  **Requirements:** TR-7, TR-8, TR-9, BR-6, BR-7, BR-8

  **Produces:**
  - `.forge/deployables/forge-plugin/capabilities/forge-branching/spec/hooks.md` — updated with branch taxonomy table, name validation logic, alignment warning design, claude -p call format, timeout and bypass handling
  - `.forge/deployables/forge-plugin/capabilities/forge-branching/requirements/technical.md` — updated with TR-7, TR-8, TR-9

  **Verification:** spec/hooks.md lists all 8 allowed branch types; alignment warning format matches TR-9; claude -p invocation and timeout are specified; bypass env var documented.

---

- [x] [auto][wave:4] Update CLAUDE.md forge-managed section template (`plugins/forge/templates/forge-claude-md-section.md`) to add branch creation intent patterns and type inference rules per TR-8. Add a new section "Creating branches" to the forge-managed section covering: when to use effort/ vs type-prefixed, the 8-rule inference sequence, slug derivation, and the branch creation action (git checkout -b). (TASK-012)

  **Capability:** `forge-init` (modification — CLAUDE.md template)
  **Requirements:** TR-8, BR-6, BR-7

  **Produces:**
  - `plugins/forge/templates/forge-claude-md-section.md` — updated: new "Creating branches" section (10-15 lines) added within the forge-managed markers; must keep total under 80 lines

  **Verification:** template line count still ≤80; "Creating branches" section present; all 8 inference rules listed (fix, hotfix, docs, refactor, chore, release, feature, ask-if-ambiguous); slug derivation rule present; git checkout -b action specified.

---

## Wave 5 — Implementation (parallel; depends on Wave 4)

- [x] [auto][wave:5] Update `enforce-branch-policy.sh` to add: (1) branch name format validation on `git commit` — block if branch doesn't match `effort/<id>` or `<type>/<slug>` pattern with a clear diagnostic; (2) push-time alignment warning — on `git push`, invoke `claude -p` to check whether commits and changed files match the branch type, emit warning to stdout if misaligned. (TASK-013)

  **Capability:** `forge-branching`
  **Requirements:** TR-7 (format validation), TR-9 (alignment warning)

  **Produces:**
  - `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh` — updated with two new checks after the default-branch block check

  **Behavior additions:**
  - On `git commit`: after confirming not on default branch, validate branch name format against pattern `^(effort/[a-z0-9-]+|feature/[a-z0-9-]+|fix/[a-z0-9-]+|hotfix/[a-z0-9-]+|chore/[a-z0-9-]+|docs/[a-z0-9-]+|refactor/[a-z0-9-]+|release/[a-z0-9.]+)$`; if invalid: exit 2 with diagnostic
  - On `git push`: after the default-branch block check, run alignment check — read commits and files, invoke `claude -p "Does the work in these commits (branch: <name>) match the branch type? If not, suggest a better name." --max-tokens 100` with 10-second timeout; emit formatted warning if misaligned; exit 0 always

  **Verification:** `git commit` on branch `wip-stuff` → blocked, format diagnostic; `git commit` on `fix/auth-crash` → allowed; `git push` with feature work on `fix/` branch → warning emitted, push proceeds; `FORGE_SKIP_BRANCH_VALIDATION=1` set → alignment check skipped.

---

## Wave 6 — Integration Tests (depends on Wave 5)

- [x] [tdd][wave:6] Integration test: branch naming convention — verify taxonomy validation and push-time alignment warning. (TASK-014)

  **Capability:** `forge-branching` (test directory)
  **Requirements:** TR-7, TR-9, BR-6, BR-8

  **Produces:**
  - `plugins/forge/test/integration/branch-naming/README.md`
  - `plugins/forge/test/integration/branch-naming/scenario.md`

  **Scenarios to cover:**
  - `git commit` on `fix/auth-crash` → allowed (valid type/slug format)
  - `git commit` on `wip-stuff` → blocked, diagnostic suggests valid format
  - `git commit` on `Feature/auth` (uppercase) → blocked, diagnostic explains lowercase requirement
  - `git push` with docs-only changes on `fix/` branch → alignment warning, push proceeds
  - `git push` with feature commits on `fix/` branch → warning with suggested `feature/` name, push proceeds
  - `FORGE_SKIP_BRANCH_VALIDATION=1` on `git push` → no alignment check, push proceeds
  - Alignment check times out (>10s) → push proceeds silently, no error

---

- [x] [tdd][wave:6] Integration test: conversational branch creation — verify type inference from natural language. (TASK-015)

  **Capability:** `forge-init` (CLAUDE.md template test)
  **Requirements:** TR-8, BR-7

  **Produces:**
  - `plugins/forge/test/integration/branch-inference/README.md`
  - `plugins/forge/test/integration/branch-inference/scenario.md`

  **Scenarios to cover:**
  - "Let's fix the crash in the auth flow" → creates `fix/auth-flow-crash`
  - "We need to add a favorites endpoint" → creates `feature/favorites-endpoint`
  - "Clean up the unused imports in the API layer" → creates `refactor/remove-unused-imports`
  - "Update the README with setup instructions" → creates `docs/readme-setup-instructions`
  - "This is an urgent prod issue with login" → creates `hotfix/login-issue`
  - "Bump the Redis dependency to 4.x" → creates `chore/bump-redis-4`
  - "I want to do some work" (ambiguous) → agent asks one clarifying question with type options listed
  - Active effort exists → no branch creation prompt, `effort/<id>` already checked out

