# Implementation Plan: forge-plugin-root-resolution

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Fix all non-compliant skills

All six tasks are independent edits to individual SKILL.md files and can be executed in parallel.

### TASK-001 [auto][wave:1]

Fix `forge:plan` Step 4E: replace the ad-hoc `find ~/.claude/plugins/cache` block with an explicit "Resolve plugin root using `plugins/forge/skills/common/plugin-root.md`" step, then use `<plugin_root>` for the `standards/AGENTS.md` reference that follows.

**Satisfies:** BR-1, BR-2, TR-1, TR-2, TR-3
**Standards:** none
**Required tests:** none (SKILL.md prose edit — no executable code)

---

### TASK-002 [auto][wave:1]

Fix `forge:update` PC-2 and Step 2: remove both ad-hoc `find ~/.claude/plugins/cache` blocks used for version discovery. Replace with the canonical `plugin-root.md` resolution. The version string needed for comparison can be read directly from `../../.claude-plugin/plugin.json` once `plugin_root` is resolved.

**Satisfies:** BR-1, BR-2, TR-1, TR-2, TR-3
**Standards:** none
**Required tests:** none (SKILL.md prose edit — no executable code)

---

### TASK-003 [auto][wave:1]

Fix `forge:validate-storage` Step 2: remove the `../../../../` relative-path derivation prose and the inline `../../../../standards/storage/<type>.md` path. Replace with an explicit "Resolve plugin root using `plugins/forge/skills/common/plugin-root.md`" step and use `<plugin_root>/standards/storage/<type>.md` throughout.

**Satisfies:** BR-1, BR-2, TR-1, TR-2, TR-3
**Standards:** none
**Required tests:** none (SKILL.md prose edit — no executable code)

---

### TASK-004 [auto][wave:1]

Fix `forge:spec-storage`: replace the `../../../../standards/storage/<type>.md` relative path reference with an explicit "Resolve plugin root using `plugins/forge/skills/common/plugin-root.md`" step and use `<plugin_root>/standards/storage/<type>.md`.

**Satisfies:** BR-1, BR-2, TR-1, TR-2, TR-3
**Standards:** none
**Required tests:** none (SKILL.md prose edit — no executable code)

---

### TASK-005 [auto][wave:1]

Fix `forge:adr` Step 5: add an explicit "Resolve plugin root using `plugins/forge/skills/common/plugin-root.md`" step before the `<plugin_root>/templates/adr.md` reference.

**Satisfies:** BR-1, BR-2, TR-1, TR-2, TR-3
**Standards:** none
**Required tests:** none (SKILL.md prose edit — no executable code)

---

### TASK-006 [auto][wave:1]

Fix `forge:spec-tests`: add an explicit "Resolve plugin root using `plugins/forge/skills/common/plugin-root.md`" step before the `<plugin-root>/standards/testing/...` resource references.

**Satisfies:** BR-1, BR-2, TR-1, TR-2, TR-3
**Standards:** none
**Required tests:** none (SKILL.md prose edit — no executable code)

---

## Wave 2 — Audit and close

### TASK-007 [auto][wave:2]

Audit all SKILL.md files under `plugins/forge/skills/` to confirm no remaining uses of `find ~/.claude/plugins/cache`, `find ~/.claude/plugins`, relative-path plugin root derivation (`../../../../`), or bare `<plugin_root>` variable references without a preceding resolution step. Fix any discovered gaps before marking complete.

**Satisfies:** BR-1, BR-2, TR-1, TR-2
**Standards:** none
**Required tests:** none (audit task)
