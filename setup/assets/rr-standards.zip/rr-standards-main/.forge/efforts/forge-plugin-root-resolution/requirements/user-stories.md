# User Stories — forge-plugin-root-resolution

*Effort: forge-plugin-root-resolution*
*Derived from: [requirements/business.md](business.md)*
*Written: 2026-04-28*

---

## Consistent standards across the project lifecycle

- As a developer, I want reviews and validations to always use the same plugin version my project was built against, so that a standards update in a newer cached plugin version doesn't silently break my PR.

- As a developer, I want to know immediately and clearly when the plugin cannot be found — rather than receiving wrong output from a stale version — so that I can diagnose and fix the problem rather than trust a corrupted result.

## Predictable skill behavior regardless of cache state

- As a Forge contributor, I want every skill that loads plugin resources to resolve the plugin root through a single canonical method, so that I only have one place to update if the plugin directory layout ever changes.

- As a Forge contributor, I want skills to fail fast with a clear error when the plugin manifest is missing, so that I can distinguish "plugin not installed" from "skill logic error" without inspecting internals.
