# Business Requirements — forge-plugin-root-resolution

*Effort: forge-plugin-root-resolution*
*Created: 2026-04-28*

---

## BR-1: Plugin root resolution must identify the active plugin version, not the latest cached version

When a Forge skill resolves the plugin root, it must resolve the version of the plugin
that is currently active for the project — not whichever version happens to be newest
or first in the cache directory.

**Acceptance criteria:**
- Skills that load standards, templates, or migration manifests do so from the active plugin version
- If multiple plugin versions are cached, the active version is used exclusively
- No skill uses `find ~/.claude/plugins/cache` or equivalent filesystem scanning to locate the plugin root

---

## BR-2: Standards loaded during review must match the version the project was built against

Review and validation skills must compare implementation artifacts against the standards
packaged in the active plugin version — the version the project pinned when work began.
A project must not suddenly fail review because a newer version of a standard was picked up
from a different cached plugin version.

**Acceptance criteria:**
- forge:review, forge:validate, forge:validate-storage, forge:validate-api, and forge:validate-messaging all load standards from the active plugin version
- Standards version is consistent within a single skill invocation
- Upgrading the plugin version is an explicit, intentional act — not a side effect of having a new cache entry present
