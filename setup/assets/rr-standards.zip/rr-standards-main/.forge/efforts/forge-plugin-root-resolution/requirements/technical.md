# Technical Requirements — forge-plugin-root-resolution

*Effort: forge-plugin-root-resolution*
*Elaborated from: [requirements/business.md](business.md)*
*Created: 2026-04-28*

---

## TR-1: Plugin root must be derived from the executing skill's own file path, not filesystem search

*Traces to: BR-1, BR-2*

The canonical resolution method is: read `../../.claude-plugin/plugin.json` relative
to the skill's own directory. Because a skill's `SKILL.md` lives at
`<plugin_root>/skills/<skill-name>/SKILL.md`, this relative path always resolves to
the manifest of the exact plugin version currently executing that skill — regardless
of how many other versions are cached on disk.

No skill may use `find`, glob patterns, or any other filesystem scan of
`~/.claude/plugins/cache` to locate the plugin root. There are no exemptions —
including `forge:update`, which operates on the host repository's `.forge/` artifacts
and has no need to discover or compare cached plugin versions.

## TR-2: All skills needing the plugin root must explicitly use `plugin-root.md`

*Traces to: BR-1, BR-2*

Every skill that needs to access plugin resources (standards, templates, migrations,
scripts) must resolve the plugin root by referencing:
  `plugins/forge/skills/common/plugin-root.md`

Relative-path derivation (e.g. counting `../../../../` from the skill directory) is
not acceptable — it is fragile under directory structure changes and has no single
point of maintenance. The canonical fragment is the required abstraction.

Skills that reference `<plugin_root>` as a variable in resource paths but do not
include an explicit resolution step are also non-compliant — an undefined variable
causes the model to improvise resolution, typically with `find`, reintroducing the
version-confusion bug. Every skill must include a named step that invokes
`plugin-root.md` before any resource path using `<plugin_root>` is referenced.

**Affected skills (full inventory at time of writing):**

| Skill | Issue |
|-------|-------|
| `forge:plan` | Ad-hoc `find ~/.claude/plugins/cache` in Step 4E |
| `forge:update` | Ad-hoc `find ~/.claude/plugins/cache` in PC-2 and Step 2 |
| `forge:validate-storage` | Relative path `../../../../` instead of `plugin-root.md` |
| `forge:spec-storage` | Relative path `../../../../` instead of `plugin-root.md` |
| `forge:adr` | References `<plugin_root>/templates/adr.md` with no resolution step |
| `forge:spec-tests` | References `<plugin-root>/standards/testing/...` with no resolution step |

---

## TR-3: Skills must fail fast with a standard error when the plugin manifest cannot be read

*Traces to: BR-1, BR-2*

If `../../.claude-plugin/plugin.json` cannot be read via the relative path, the skill
must stop immediately with:

> "The Forge plugin does not appear to be installed or the manifest is missing.
> Try reinstalling the plugin."

No fallback to `find` or any other discovery mechanism is permitted. An unresolvable
manifest means the execution context is unknown; any fallback would silently reintroduce
the version-confusion bug this effort is fixing.
