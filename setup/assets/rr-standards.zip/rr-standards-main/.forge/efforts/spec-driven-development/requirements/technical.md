# Technical Requirements — Spec-Driven Development

Defines the capabilities that must be built to realize the business requirements for
this initiative. Phases 1–4.5 correspond directly to the forge-plugin program TR;
content is scoped here to what Initiative 3 owns.

---

## Phase 1: Discovery

**Input:** PM-provided product document (PRD, Jira epic, user story, or equivalent);
existing system context
**Output:** Business requirements, technical requirements, API contracts, storage
schemas, message contracts, test strategy, risk classification, architecture
decisions, open questions list

**How this phase works:**
Discovery is not a linear sequence of requirements-then-design. Requirements and design
activities are interleaved: drafting an API contract reveals a requirement not in the PM
document; designing a storage schema reveals that two requirements conflict; identifying
a security implication during design reshapes the business requirement it stems from.
This is expected and productive. The goal is not to complete requirements before touching
design — it is to arrive at requirements and designs that are mutually coherent and
complete enough to implement against.

The phase is complete when: the PM document has been interrogated for true business needs
(not just prescribed solutions), technical implications have been elaborated, primary
designs are drafted and internally consistent, and there are no open questions that
would require re-doing significant design work.

Engineer implementation decisions made during discovery — choices about approach,
libraries, patterns — must be captured explicitly and honored during implementation.
These are not suggestions for the implementing agent to reconsider; they are locked
decisions.

**Primary failure modes:**
- PM document treated as requirements rather than as input to the discovery process
- Requirements discovered during design are not captured back into the requirements
  artifact, creating silent inconsistency
- Requirements and design approved at different times and end up inconsistent
- Implicit requirements (security, privacy, compliance, accessibility) not surfaced
  until implementation or review, where they are expensive to address
- Team begins implementation before requirements and design are mutually coherent

**Capabilities required:**
- Extract business requirements from a PM document; distinguish prescribed solutions
  from underlying needs; identify implicit requirements (security, privacy, compliance,
  accessibility) based on the nature of the capability and data it handles
- Validate requirements for completeness, testability, and internal consistency
- Elaborate business requirements into technical requirements: NFRs, integration
  constraints, security and privacy implications, scalability targets
- Produce an initial risk classification (R1–R4) based on the nature of the requirements
- Identify integration points with existing systems; flag conflicts between requirements
  and known technical constraints
- Design REST API contracts (OpenAPI), validated against requirements and organizational
  REST standards
- Design storage schemas (PostgreSQL, DynamoDB, OpenSearch, Redis) appropriate to
  described access patterns
- Design message contracts that are versioned and standards-compliant
- Cross-check designs against each other for consistency
- Identify security and privacy risks in proposed designs
- Record architecture decisions with rationale, alternatives considered, and the
  requirement each decision serves
- Design a high-level test strategy
- Surface gaps and generate clarifying questions when design work reveals ambiguity
- Templates for: business requirements, technical requirements, API contract, storage
  schema, message contract, test strategy, ADR

---

## Phase 2: Design Validation

**Input:** Discovery artifacts (requirements and designs); risk classification
**Output:** Validation report with pass/fail per check, required revisions, and
informational suggestions

**Primary failure modes:**
- Designs approved without verifying every stated requirement is addressed
- Test strategy does not cover the failure scenarios most likely in production
- Validation catches style issues but misses semantic gaps between requirements and design
- Security and privacy issues in the design not caught before implementation begins

**Capabilities required:**
- Cross-reference each business and technical requirement against the designs; flag
  requirements with no corresponding design coverage
- Cross-reference the test strategy against requirements and design to identify untested
  paths and missing edge cases
- Validate API designs against organizational REST standards
- Validate storage schemas against organizational data modeling standards
- Validate message contracts against organizational messaging standards
- Produce a prioritized gap report: required changes (block approval) vs. suggestions
  (informational)
- The validation report must be a persisted artifact associated with the effort, not
  a terminal-only output

---

## Phase 3: Implementation Planning

**Input:** Validated discovery artifacts, risk classification
**Output:** Ordered, dependency-mapped implementation tasks annotated with type and
wave; plan artifact written to effort directory

**Primary failure modes:**
- Tasks defined without dependencies, causing blocked work mid-sprint
- Cross-cutting concerns (auth, logging, error handling, tests) omitted as explicit tasks
- Plans become stale and are not maintained as implementation progresses
- Independent tasks executed sequentially when they could proceed in parallel

**Capabilities required:**
- Generate implementation tasks from validated designs, including cross-cutting concerns
  as explicit tasks (not assumptions)
- Identify task dependencies and express them as explicit ordering constraints
- Annotate tasks with execution type:
  - `[auto]` — agent executes autonomously
  - `[checkpoint]` — requires engineer decision or action before proceeding
  - `[tdd]` — test-first discipline required
  - `[manual]` — human-only task, not suitable for agent execution
- Group tasks into dependency waves to enable parallel execution of independent work
- Record the plan to `.forge/efforts/<id>/plan/tasks.md`
- Update the plan as implementation progresses, recording commit SHAs at task completion

---

## Phase 4: Implementation

**Input:** Validated discovery artifacts, implementation plan, organizational coding
standards, codebase context (brownfield projects)
**Output:** Working code, tests (unit, integration, end-to-end), pull requests

**How this phase works for brownfield projects:**
Before implementing against an existing codebase, the agent must understand the current
system — its technology stack, architectural patterns, naming conventions, existing
integrations, and areas of known concern. Without this context, organizational standards
are applied without regard for existing patterns, producing code that is
standards-compliant but inconsistent with the codebase. A codebase analysis must be
available as reference material before implementation begins on any brownfield project.

**Primary failure modes:**
- Code does not match the agreed design
- Coding standards not followed consistently
- Test coverage insufficient or tests validate implementation rather than requirements
- Security and privacy vulnerabilities introduced during coding
- Agent deviates from the design to address an unexpected issue without escalating,
  producing implementation that silently diverges from approved artifacts
- Agent interrupts the engineer for trivial, recoverable issues it could handle
  autonomously

**Capabilities required:**
- Analyze existing codebases to produce structured documentation of stack, patterns,
  conventions, integrations, and concerns — used as reference context for all subsequent
  implementation work on that project
- Scaffold new projects and modules by service archetype (REST API service,
  event-driven service, Lambda function, data pipeline) with correct structure,
  dependencies, and configuration
- Implement capabilities against the validated design, honoring locked engineer decisions
  from discovery
- Write unit and integration tests against the agreed test strategy
- Write end-to-end tests for critical user journeys
- Enforce coding standards at generation time — standards must be loaded as context
  before any source file is written, without requiring explicit engineer invocation
- Create well-structured commits with conventional commit messages and machine-parseable
  git notes for traceability
- Apply deviation rules explicitly per agent:
  - **Autonomous:** bug fixes, missing error handling, straightforward recoverable issues
  - **Escalate:** any deviation requiring modification of an approved design artifact
    (API contract, schema, test strategy, storage model, external dependency addition)

**Note:** Code generation speed is already fast. The primary opportunity in this phase
is quality, standards adherence, and traceability — not raw speed.

---

## Phase 4.5: Implementation Verification

**Input:** Completed implementation (code + commits), validated design artifacts,
implementation plan with task completion record
**Output:** Verification report: goal delivery confirmation or specific gaps identified

**Why this phase exists:**
Task completion is not goal delivery. An agent that marks all tasks complete has not
necessarily delivered the intended behavior — it may have produced stubs, missed
integration wiring, or satisfied the letter of the task without its intent. This
verification step checks semantic goal delivery before the work moves to review or QA,
catching gaps when they are cheapest to fix.

**Primary failure modes:**
- Stubs accepted as implementations (compile, pass unit tests, fail in practice)
- Missing wiring between deployables (each piece works, but they are not connected)
- Implementation satisfies task description but not the underlying requirement

**Capabilities required:**
- Read validated design artifacts and the implementation task list with commit SHAs
- Verify that the implementation delivers the stated phase goal, not just that tasks
  are marked complete
- Identify stubs, orphaned code, and missing integration points
- Produce a structured report that distinguishes confirmed delivery from gaps, with
  specific locations in the code for each gap found
- The verification report is a persisted artifact at `.forge/efforts/<id>/validation/`
  that feeds into the PR description and is referenced by the review skill

---

## Constraints

### Dependencies on Platform Core (Initiative 2)

This initiative depends on the following infrastructure delivered by Platform Core:

- `.state.json` schema with phase tracking, artifact inventory, and open decisions
- Session pause/resume capability preserving phase position and active context
- Master work registry (`.forge/efforts/README.md`) and work item hierarchy
- Artifact file/directory duality: any single-file artifact may expand to a same-named
  directory when approaching 500 lines; all discovery and planning skills must handle
  both forms transparently

### Standards Dependency

Implementation (Phase 4) enforces coding standards at generation time. The relevant
standards must exist and be consumable before Phase 4 skills are built. Standards
are delivered by the rr-standards repository and are not in scope for this initiative
to produce — but their availability is a hard dependency.

Required standards: REST API design, storage (PostgreSQL, DynamoDB, OpenSearch, Redis),
messaging (Kafka), testing strategy, security, privacy, observability, and language
coding guidelines for each supported platform (Go, Java, TypeScript, Kotlin, Swift,
Python).

### Agent Architecture

Heavy operations — PM document analysis, design validation, implementation verification
— must run in isolated sub-agents with fresh context windows. They must not accumulate
context from a long interactive session. This is the primary mechanism for satisfying
BR-SDD-6 (consistent output quality regardless of session length).

### Output Modes

Discovery and planning skills produce human-readable output by default. Where a skill
also produces a persisted artifact, the artifact is the authoritative output — the
terminal display is a summary. Skills must not require the engineer to copy output
from the terminal to create an artifact.

---

## Capability Artifact Requirement

Every skill delivered by this initiative must have a corresponding capability directory
in `.forge/deployables/forge-plugin/capabilities/forge-<skill-name>/`. The capability
directory is the canonical, living documentation for that skill — it persists after
this initiative closes and is updated at each subsequent PR that modifies the skill.

Each capability directory must contain:

```
.forge/deployables/forge-plugin/capabilities/forge-<skill-name>/
├── README.md                  # One-paragraph capability summary
├── requirements/
│   ├── business.md            # What problem this skill solves and for whom
│   ├── technical.md           # How the skill is specified: interface, steps, inputs/outputs
│   └── success-criteria.md    # Measurable conditions for the skill being correct
├── spec/
│   ├── README.md              # Spec overview and navigation
│   ├── skills.md              # Full skill interface spec (mirrors initiative spec/skills.md entry)
│   └── arch-decisions/        # Capability-scoped ADRs (if any)
├── runbook/                   # Operational notes (can be minimal for skills)
├── security/                  # Security considerations (can be minimal for most skills)
└── test/                      # Test strategy for this skill
```

The `spec/skills.md` content for each capability is derived from the corresponding
entry in `.forge/efforts/spec-driven-development/spec/skills.md`. The
`requirements/business.md` describes the specific user problem the skill addresses
(not the initiative-level requirements — those are in this file).

**Note on `forge-promote`:** This capability directory already exists with prior
content. When the `forge:promote` SKILL.md is authored in this initiative, the
existing capability requirements and spec must be reviewed and updated to match
the interface defined in this initiative's `spec/skills.md`.
