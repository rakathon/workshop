# ADR-001: PM Document Ingestion Mode

**Status:** Accepted
**Effort ID:** spec-driven-development
**Date:** 2026-04-02

## Context

`forge:extract` must ingest PM documents to produce structured business requirements.
PM documents exist in different locations depending on the team's tooling maturity:
some teams have fully Forge-enabled product repositories with structured
`.forge/products/` artifacts; others drop documents locally into the working repo;
others author in Confluence. The skill must handle all three without forcing teams
onto a single path. At the same time, arbitrary URL fetching (e.g., Google Docs,
Notion, internal wikis) creates network dependency, reproducibility concerns, and
unpredictable HTML parsing.

## Decision

`forge:extract` supports three ingestion modes, evaluated in the following priority
order:

1. **`--product <repo>/<name>`** (primary) — reads `.forge/products/<name>/requirements/business.md`
   from a product-role repository. This is the standard path for teams using the full
   Forge product structure, where the PM has maintained structured requirements.
2. **`--from <file-path>`** (secondary) — reads a local file (Markdown, plain text,
   or HTML) present in the current repository or filesystem. Engineers using this mode
   download or export the PM document before invoking the skill.
3. **`--confluence <url>`** (tertiary) — retrieves a Confluence page at extraction time
   via the Atlassian MCP server. This mode is available specifically for Confluence
   because it is the organization's standard documentation platform. The Atlassian MCP
   handles authentication (OAuth 2.1 or API token, depending on the configured server)
   and returns clean page content without requiring per-engineer credential management.

No other URL types are supported. Paste mode (no flag) is a fallback: the orchestrator
collects pasted content, writes it to a temp file, and the worker reads the temp file.

## Alternatives Considered

**Universal URL fetching via WebFetch:** Accept any URL and fetch it directly.
Rejected because Confluence requires authentication — WebFetch sends plain HTTP
requests with no auth headers and will receive a 403 or a login redirect for any
private page (which is effectively all pages). Additionally, arbitrary URL fetching
introduces unpredictable HTML parsing and network dependency for non-Confluence tools.

**curl with environment variables:** Use `curl` with `CONFLUENCE_EMAIL` and
`CONFLUENCE_API_TOKEN` environment variables for Basic auth. Viable but requires
per-engineer credential setup, introduces credentials into the shell environment,
and adds a manual configuration step that the MCP approach eliminates entirely.

**File-only mode:** Require engineers to always provide a local file. Rejected because
it creates unnecessary friction for Confluence users and does not leverage the
structured product artifact path that Forge-mature teams have already built.

**Confluence CLI:** No widely pre-installed CLI tool exists for Confluence. The
available community tools (e.g., `confluence-cli`) require an additional installation
step with no assurance of being present in the engineer's environment.

**Unified flag with auto-detection:** Infer the mode from a single `--source` argument
(detect whether it's a product ref, path, or URL). Rejected because explicit mode
selection makes intent clear and avoids ambiguous parsing (e.g., a string that could
be either a relative path or a product ref).

## Consequences

- Teams using Confluence as their PM documentation platform get native support without
  exporting files first, provided the Atlassian MCP is configured in Claude Code
  settings. Two MCP servers are supported: the official Atlassian Rovo MCP (Cloud-only,
  OAuth 2.1) and sooperset/mcp-atlassian (Cloud + Data Center, API token). The skill
  checks for a `confluence_get_page` tool at invocation time and fails clearly if
  neither is configured, with instructions for both setup paths.
- Teams using other documentation tools (Notion, Google Docs, internal wikis) must
  export to Markdown or plain text before invoking `forge:extract`. This is a one-time
  step per document; extraction is infrequent.
- The `--product` mode creates a dependency on the product repo being accessible and
  having maintained `.forge/products/<name>/requirements/business.md`. Teams without
  a product repo fall through to `--from` or `--confluence`.
- The paste fallback exists for ad-hoc cases but produces a temp file that is
  gitignored and deleted after extraction — it is not a durable ingestion path.
