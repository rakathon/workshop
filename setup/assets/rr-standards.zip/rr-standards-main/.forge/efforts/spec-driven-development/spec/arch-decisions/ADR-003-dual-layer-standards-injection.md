# ADR-003: Dual-Layer Standards Injection for Implementation Skills

**Status:** Accepted
**Effort ID:** spec-driven-development
**Date:** 2026-04-02

## Context

Implementation skills (`forge:build-api`, `forge:build-repo`, `forge:build-messaging`)
must apply organizational coding standards at generation time — before any source file
is written, not after. The forge-plugin already provides the `inject-generation-standards.sh`
PreToolUse hook as the primary mechanism: it fires automatically on every `Write` or
`Edit` to a source path and injects the applicable standards into Claude's context.

The question is whether implementation skills should also explicitly reference
standards in their `SKILL.md` instructions, or rely entirely on the hook.

## Decision

Implementation skills use dual-layer standards injection:

1. **Primary layer:** The `inject-generation-standards.sh` PreToolUse hook fires
   automatically on every source file write. This is the runtime enforcement mechanism.
2. **Secondary layer:** Each implementation skill's `SKILL.md` explicitly names the
   applicable standards file (e.g., `standards/api/rest.md`) in its instructions,
   instructing Claude to read it at the start of the skill. This is the design-time
   documentation mechanism.

Both layers instruct Claude to load standards from the external file, consistent with
ADR-003 (forge-plugin) — rules live in the standards files, not in the skill instructions.

## Alternatives Considered

**Hook-only injection:** Rely entirely on the PreToolUse hook; skills contain no
standards references. Rejected for two reasons: (1) the hook could be misconfigured,
absent on a new repository before `forge:init` completes, or disabled for debugging —
a skill that explicitly loads standards is resilient to hook failure; (2) a skill
whose `SKILL.md` names the applicable standards is self-documenting about which
standards govern its output, which matters for review and auditing.

**Skill-only injection (no hook):** Have each skill load standards explicitly and
remove the hook. Rejected because hook-based injection is automatic — it applies even
to manual writes and edits outside of skills, and it cannot be forgotten. The hook is
the more comprehensive enforcement mechanism.

**Embedding rules inline in SKILL.md:** Write the actual rules directly in the skill
instructions rather than referencing standards files. Rejected per ADR-003 (forge-plugin):
standards are the authoritative source; embedding rules in skills creates duplication
and maintenance divergence.

## Consequences

- Standards are applied even when the hook is misconfigured (skill layer) and even
  when engineers write code outside of a skill (hook layer). Defense in depth.
- Each implementation skill's `SKILL.md` is self-contained and auditable: a reviewer
  reading the skill can identify which standards it enforces without inspecting hook
  configuration.
- When a new standard is added or an existing one is moved, both the hook configuration
  and the affected skill `SKILL.md` files must be updated. This is low-frequency
  maintenance; the benefit outweighs the cost.
