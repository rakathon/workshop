# ADR-002: No Unified forge:discover Skill

**Status:** Accepted
**Effort ID:** spec-driven-development
**Date:** 2026-04-02

## Context

The discovery phase requires multiple activities: extracting requirements from a PM
document, classifying risk, elaborating technical requirements, designing API contracts,
designing storage schemas, designing message contracts, recording architectural
decisions, and designing a test strategy. These activities are co-evolutionary: design
work reveals missing requirements, and requirements changes reshape designs. ADR-006
(forge-plugin) explicitly establishes that discovery is a single co-evolutionary phase
— requirements and design are not gated on each other.

A natural question arose during design: should there be a `forge:discover` wrapper
skill that orchestrates all discovery activities in sequence, giving engineers a single
"start discovery" command?

## Decision

There is no `forge:discover` wrapper skill. Engineers invoke individual discovery
skills (`forge:extract`, `forge:classify`, `forge:elaborate`, `forge:spec-api`,
`forge:spec-storage`, etc.) in any order. The `using-skills` routing layer (the
`UserPromptSubmit` hook) surfaces the recommended next skill based on current artifact
state, guiding engineers without prescribing a sequence.

## Alternatives Considered

**A `forge:discover` orchestrator that calls all skills in sequence:** Would call
`forge:extract`, then `forge:elaborate`, then `forge:spec-api`, etc. in a fixed
order. Rejected because this reintroduces a sequential gate model that ADR-006
explicitly rejected — just hidden inside a wrapper. A co-evolutionary process cannot
be correctly expressed as a linear sequence. An engineer who realizes mid-API-design
that a requirement is missing should update requirements immediately, not wait for the
sequence to loop back.

**A `forge:discover` wrapper that runs skills in any order based on prompts:** A
conversational orchestrator that asks "what would you like to work on?" and routes to
sub-skills. Rejected because this duplicates the `using-skills` routing logic that
already exists in the `UserPromptSubmit` hook, and because the resulting invocation
sequence (`forge:discover` → menu → sub-skill) is more indirect than invoking the
sub-skill directly.

## Consequences

- Engineers new to the framework may not know which skill to invoke first. Mitigation:
  `forge:status` and the `using-skills` hook both surface the recommended next step
  based on artifact inventory. The framework guides without prescribing.
- The absence of a single "start discovery" command means the framework's guidance
  mechanism (`using-skills` routing) must be effective enough to orient new engineers
  without a wrapper.
- Individual skill invocations are independently testable and independently deployable
  as SKILL.md files — they do not need to be shipped as a unit.
- The `using-skills` routing table must be kept current as new discovery skills are
  added; it is the primary orientation mechanism.
