# Implementation Plan: Spec-Driven Development

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

**Each task delivers two artifacts:**
1. `plugins/forge/skills/<dir>/SKILL.md` — the authored skill instructions
2. `.forge/deployables/forge-plugin/capabilities/forge-<skill>/` — the capability
   directory with `requirements/` and `spec/` for that skill (canonical, living docs)

Per the delivery model for this initiative, each task is delivered as a child effort
(story) with its own branch and PR.

Spec reference: `.forge/efforts/spec-driven-development/spec/skills.md`
ADRs: `.forge/efforts/spec-driven-development/spec/arch-decisions/`
Capability template: `.forge/deployables/forge-plugin/capabilities/forge-plan/`

---

## Wave 1 — Requirements Skills

No conceptual dependencies. These skills operate on a PM document or requirements
file that exists independently of any other skill.

- [x] [tdd][wave:1] Author `forge:extract` SKILL.md + create `forge-extract` capability — worker skill, 3 ingestion modes (product repo, local file, Confluence), writes `requirements/business.md` and `suggestedRisk` to `.state.json`; run `rr-standards:test-skill` to verify extraction quality before marking complete (TASK-001)
- [x] [auto][wave:1] Author `forge:classify` SKILL.md + create `forge-classify` capability — orchestrator, reads `suggestedRisk` advisory, loads risk rubric, confirms with engineer, writes `risk` field to `.state.json` (TASK-002)
- [x] [auto][wave:1] Author `forge:elaborate` SKILL.md + create `forge-elaborate` capability — orchestrator, BRs → TRs, interactive co-authoring, reads existing `spec/` for implied TRs, writes `requirements/technical.md` (TASK-003)

---

## Wave 2 — Design Skills, Gate Skills, and Commit Utility

Conceptually depend on wave 1: authoring these skills correctly requires understanding
what requirements skills produce. Design skills are independent of each other.

- [x] [tdd][wave:2] Author `forge:spec-api` SKILL.md + create `forge-spec-api` capability — orchestrator, loads `standards/api/rest.md`, interactive OpenAPI YAML authoring, inline standard checks per endpoint, handles non-standard overrides with ADR flag (TASK-004)
- [x] [auto][wave:2] Author `forge:spec-storage` SKILL.md + create `forge-spec-storage` capability — orchestrator, loads `standards/storage/<type>.md`, interactive schema authoring, inline GDPR/PII checks (TASK-005)
- [x] [auto][wave:2] Author `forge:spec-messaging` SKILL.md + create `forge-spec-messaging` capability — orchestrator, loads `standards/messaging/contracts.md`, interactive event contract authoring (TASK-006)
- [ ] [auto][wave:2] Author `forge:spec-tests` SKILL.md + create `forge-spec-tests` capability — orchestrator, writes to capability canonical directory per ADR-028, creates capability directory if absent (TASK-007)
- [x] [tdd][wave:2] Author `forge:promote` SKILL.md + update `forge-promote` capability — orchestrator, three-phase ritual (discovery/planning/verification), artifact inventory check, `validation/report.md` result check; `forge-promote` capability already exists — review and update requirements/spec to match this initiative's interface definition; run `rr-standards:test-skill` before marking complete (TASK-008)
- [x] [auto][wave:2] ~~Author `forge:reopen` SKILL.md~~ — REMOVED: forge:reopen is not needed; phase gates are not enforced in Forge v1 (ADR-031) (TASK-009)
- [x] [auto][wave:2] Author `forge:commit` SKILL.md + create `forge-commit` capability — orchestrator, conventional commit message proposal, branch check, staged-changes scope check, structured git note attachment (ADR-008 format) (TASK-010)

---

## Wave 3 — Validation Skills and Plan Utility

Validation skills depend on knowing the output formats produced by wave 2 design
skills. `forge:update-plan` depends on knowing the SHA and git note format from
`forge:commit` (wave 2).

- [x] [tdd][wave:3] Author `forge:validate` SKILL.md + create `forge-validate` capability — worker, full cross-reference (requirements traceability + standards compliance + cross-spec consistency + ADR quality), optional internal agent spawning for large artifact sets, writes `validation/report.md` with grep-extractable `**Result:**` header; run `rr-standards:test-skill` to verify findings quality (TASK-011) — 197ea14
- [x] [auto][wave:3] Author `forge:validate-api` SKILL.md + create `forge-validate-api` capability — targeted worker, loads `standards/api/rest.md`, inline report only (TASK-012) — 5276ce2
- [x] [auto][wave:3] Author `forge:validate-storage` SKILL.md + create `forge-validate-storage` capability — targeted worker, loads applicable storage standard, inline report only (TASK-013) — ec0ac3f
- [x] [auto][wave:3] Author `forge:validate-messaging` SKILL.md + create `forge-validate-messaging` capability — targeted worker, loads `standards/messaging/contracts.md`, inline report only (TASK-014) — d3f77fb
- [ ] [auto][wave:3] Author `forge:validate-tests` SKILL.md + create `forge-validate-tests` capability — targeted worker, loads `standards/testing/strategy.md` + effort requirements, inline report only (TASK-015)
- [x] [auto][wave:3] Author `forge:update-plan` SKILL.md + create `forge-update-plan` capability — orchestrator, marks task `[x]` in `plan/tasks.md`, records commit SHA inline, updates `.state.json` `completedTasks`, sets `jira.syncStatus = "pending"` (TASK-016) — 8134e7f

---

## Wave 4 — Implementation Skills

Depend on design and validation skills being authored (waves 2–3): the `forge:build-*`
skills reference spec artifacts produced by design skills and must correctly specify
deviation rules (ADR-005) and dual-layer standards injection (ADR-003).

- [ ] [auto][wave:4] Author `forge:scaffold` SKILL.md + create `forge-scaffold` capability — orchestrator, synthesis-based (no archetype templates exist), reads `docs/codebase/STACK.md`, proposes directory tree for engineer confirmation before writing, wires scaffold to spec artifacts when present (TASK-017)
- [ ] [tdd][wave:4] Author `forge:build-api` SKILL.md + create `forge-build-api` capability — orchestrator, implements endpoints from `spec/api/*.yaml`, uses `forge:build-contract` quality loop, dual-layer standards injection (ADR-003), deviation escalation via `forge:reopen` (ADR-005); run `rr-standards:test-skill` to verify deviation rules (TASK-018)
- [ ] [tdd][wave:4] Author `forge:build-repo` SKILL.md + create `forge-build-repo` capability — orchestrator, implements data access layer from `spec/storage/*.md`, `forge:build-contract` quality loop, deviation escalation via `forge:reopen` (TASK-019)
- [ ] [auto][wave:4] Author `forge:build-messaging` SKILL.md + create `forge-build-messaging` capability — orchestrator, implements producers/consumers from `spec/messaging/*.md`, `forge:build-contract` quality loop, deviation escalation via `forge:reopen` (TASK-020)
- [ ] [auto][wave:4] Author `forge:test` SKILL.md + create `forge-test` capability — orchestrator, reads capability `test-strategy.md` from deployable directory, implements unit/integration/E2E tests per strategy, runs tests before committing (TASK-021)

---

## Wave 5 — ADR Graduation

- [ ] [checkpoint][wave:5] Graduate ADR-005 (deviation escalation via forge:reopen) to forge-plugin canonical ADR set as ADR-030+ — confirm next available ADR number with Platform Core team, verify content applies across all initiatives, supersede effort-scoped ADR-005 with reference to canonical ADR (TASK-022)
