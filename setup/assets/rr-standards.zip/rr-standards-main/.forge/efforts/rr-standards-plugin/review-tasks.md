# Review Tasks — rr-standards-plugin Design Session

All changes made in the session that produced this file. Work through each item
with the author. Check off when reviewed and accepted; annotate with notes if
changes are needed.

---

## 1. Design Artifacts

### Standard Template

File: `templates/standard-template.md`

- [x] **Structure** — Six sections: Overview, Scope, R-N Rules, Compliance Checklist,
      Examples, Related. Examples updated: pseudo-code only (no language-specific syntax);
      no `<details>` collapse. Language guides section now visible, not commented out.
- [x] **Authoring guidance** — In HTML comments; invisible in rendered output; removed
      before publishing.
- [x] **Quality checklist** — Updated: added Related section check (language guide links
      required), updated examples check (pseudo-code, explains why).
- [x] **Voice and format** — Directive imperative throughout.

### Enforcement Policy Template

File: `templates/enforcement-policy-template.md`

- [x] **Structure** — Standard reference header, advisory_threshold, policy metadata,
      severity table (Rule | Severity | Notes). Complete.
- [x] **Guidance on severity choice** — Three tiers: blocking, advisory (count-based
      threshold), informational. Maintenance guidance fixed (minor/major semver).
- [x] **Quality checklist** — Updated: valid values include advisory; advisory_threshold
      type check added.

### Taxonomy Reference

File: `standards/TAXONOMY.md`

- [x] **Artifact types table** — Language guide limit raised to 500 lines per file;
      location pattern updated for single-file and directory variants; enforcement
      policy severity updated to blocking/advisory/informational with advisory_threshold.
- [x] **Required sections** — Standard examples updated (pseudo-code only, no `<details>`);
      enforcement policy metadata updated (advisory_threshold added); language guide
      directory pattern documented with AGENTS.md requirement.
- [x] **Boundary rules** — Verified correct.
- [x] **AGENTS.md/README.md rule** — Verified correct.
- [x] **Versioning** — MINOR update clarified: policy must add rows for new rules (not
      optional). Enforcement policy MINOR update requirement corrected.

### Coverage Map

File: `standards/COVERAGE.md`

- [x] **Status definitions** — absent / stub / draft / complete / major-stale (language
      guides only). Pre-taxonomy note explains why draft files with old FS-N structure are
      still valuable. "over-limit" removed as a status; AGENTS.md files exceeding 100 lines
      are "complete" with a note in the Notes column.
- [x] **Standards inventory** — 21 draft, 2 stub, 4 absent. Accepted as-is (manual scan).
- [x] **Language guides inventory** — 20 draft, 7 stub, 3 languages with no guides.
      Swift/Objective-C style guides excluded; pre-taxonomy style references, not
      implementation guides. Accepted as-is.
- [x] **AGENTS.md inventory** — 8 complete (6 over 100-line limit, noted in Notes column),
      2 stub (kotlin, sql). "over-limit" collapsed into complete + Notes per review decision.
- [x] **Priority gaps** — Top 5 in program-blocking order: security, observability, CI/CD,
      Kotlin, SQL. Order verified as correct.

### Skills Design

File: `.forge/efforts/rr-standards-plugin/spec/skills.md`

- [x] **forge:author-standard** — Create vs. update split added: existing files open for
      editing rather than re-copying the template (which would destroy content). Skip
      behaviour preserved for sections with no existing content.
- [x] **forge:validate-standard** — Detection rules now reference TAXONOMY.md §Artifact
      Type Identification directly rather than re-stating them inline. Eliminates
      AGENTS.md-under-standards misfire and stays in sync as taxonomy evolves.
- [x] **forge:coverage** — major-stale detection added: checks each language guide's
      declared Implements: version against current standard version; MAJOR drift overrides
      complete/draft status. Missing Implements: declaration recorded as draft with note.
- [x] **forge:review-standard** — New skill added (was missing from design doc). Diff-aware
      PR review worker: classifies changed artifacts, delegates quality checklist to
      forge:validate-standard, classifies change type (MAJOR/MINOR/PATCH via semantic
      judgment on R-N rule changes), validates version bump, checks policy row consistency,
      checks guide staleness. Guide staleness always informational on standard PRs; blocking
      only when guide author chose to update the guide. Human approval always valid merge path.

### Hook Design

File: `.forge/efforts/rr-standards-plugin/spec/hook.md`

- [x] **Scope** — Language detection only (file extension → language guide). Semantic
      detection (what kind of file → which category standard) is the agent's job.
      Verify this split is correct.
- [x] **Language mapping** — 8 languages: Go, Java, Kotlin, Swift, TypeScript, JavaScript,
      Python, SQL. Embedded in hook as a `case` statement — no separate mapping file.
      Verify coverage is complete for supported languages.
- [x] **Injection format** — Hook outputs AGENTS.md content as a prepended system message.
      Verify this is the right mechanism.
- [x] **Degradation** — No match or file not found: informational note, proceed without
      blocking. Script error: fail gracefully, never block Write/Edit. Verify.
- [x] **Maintenance rule** — New language requires updating hook script + deploy via
      `forge:update`. Build skills for new languages must declare guides in SKILL.md
      until hook is updated. Verify this is clear and correct.
