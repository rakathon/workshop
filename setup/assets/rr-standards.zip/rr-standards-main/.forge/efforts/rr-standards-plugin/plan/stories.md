# rr-standards-plugin — Implementation Plan

Deliverables for the rr-standards plugin: four skills.
Design reference: `../spec/skills.md`, `../spec/hook.md`.

---

## Delivery Order

```
S-1: rr-standards:validate   ← foundation; S-2 delegates to it
S-2: rr-standards:author     ← depends on S-1
S-3: rr-standards:coverage   ← independent; can run in parallel with S-2
S-4: rr-standards:review     ← independent; most complex
S-5: validate --active mode  ← extends S-1; depends on S-1 being complete
```

---

## S-1: rr-standards:validate ✓ COMPLETE (2026-03-08)

**What:** Worker skill that validates a single standards artifact against the
quality checklist for its type. Supports interactive and `--ci` output modes.

**Location:** `plugins/rr-standards/skills/validate/`

**Design refs:** `../spec/skills.md § rr-standards:validate`, TR-3.1–3.4,
`standards/TAXONOMY.md § Artifact Type Identification`

| Task | Status | Description |
|------|--------|-------------|
| T-1.1 | ✓ | Write `SKILL.md` — detect artifact type from TAXONOMY.md rules; load correct TR-3 checklist; emit interactive or `--ci` JSON report conforming to review output schema (`target.type: "file"`) |
| T-1.2 | ✓ | Write `README.md` — purpose, invocation modes, `--ci` flag, exit codes |

**Acceptance:**
- ✓ Given a valid standard file → PASS report with no blocking findings
- ✓ Given a standard missing required sections → FAIL with blocking finding per check ID
- ✓ Given `--ci` flag → JSON to stdout conforming to review output schema; exit 1 on FAIL

**Notes:** Validated through 3 eval iterations using skill-creator. Final pass rate:
100% with_skill vs ~20% without_skill across interactive and CI output modes.
Key fixes applied: explicit links-check-always-runs rule, count = individual findings
not check IDs, blocking_count/informational_count computed from findings[] array.

---

## S-2: rr-standards:author ✓ COMPLETE (2026-03-08)

**What:** Orchestrator skill that guides an author through creating or updating
a standards artifact. Delegates final validation to `rr-standards:validate`.

**Location:** `plugins/rr-standards/skills/author/`

**Design refs:** `../spec/skills.md § rr-standards:author`, templates in `templates/`

**Depends on:** S-1 (delegates via Task tool)

| Task | Status | Description |
|------|--------|-------------|
| T-2.1 | ✓ | Write `SKILL.md` — prompt for artifact type and name; derive path from TAXONOMY.md; copy template (create mode) or open existing (update mode); walk sections interactively; spawn `rr-standards:validate` via Task tool; display returned report |
| T-2.2 | ✓ | Write `README.md` — purpose, walkthrough vs. manual mode, example session |

**Acceptance:**
- ✓ Create mode: copies correct template to correct taxonomy path
- ✓ Update mode: opens existing file without overwriting; confirms intent first
- ✓ After authoring: validate report is displayed inline; blocking gaps listed before finishing

**Notes:** Iteration 1 evals run (3 evals × with_skill + without_skill). Benchmark:
94.3% with_skill vs 57.7% without_skill (+37pp delta). Key failure mode without skill:
ad-hoc enforcement policy template, no Standard: header, no validation step.
Marked complete after user review (2026-03-08).

---

## S-3: rr-standards:coverage ✓ COMPLETE (2026-03-08)

**What:** Worker skill that walks all standards and language guide locations,
computes coverage status for each, and writes `<root>/standards/COVERAGE.md`.

**Location:** `plugins/rr-standards/skills/coverage/`

**Design refs:** `../spec/skills.md § rr-standards:coverage`, TR-4

| Task | Status | Description |
|------|--------|-------------|
| T-3.1 | ✓ | Write `SKILL.md` — accept optional `<root-dir>` argument (defaults to cwd); walk `<root>/standards/` and `<root>/languages/`; enumerate all 9 expected standard categories and 7 expected languages as absent when not present (Part B); apply absent/stub/draft/complete/major-stale rules; write `<root>/standards/COVERAGE.md`; emit summary with top-5 priority gaps |
| T-3.2 | ✓ | Write `README.md` — purpose, when to run, `<root-dir>` argument, output format, coverage status definitions |

**Acceptance:**
- ✓ Produces a COVERAGE.md with a row for every expected artifact location
- ✓ Correctly identifies absent, stub, draft, complete, and major-stale artifacts
- ✓ Summary highlights the five highest-priority gaps
- ✓ `<root-dir>` argument respected — scan scoped to given directory, not repo root
- ✓ Trailing slash on `<root-dir>` stripped correctly
- ✓ Absent entries enumerated even when root is brand new and empty (consistent counts)

**Notes:** Validated through 3 eval iterations using skill-creator. Final pass rate:
100% with_skill vs 8.3% without_skill (delta +0.92).
Key fixes applied: `<root-dir>` positional argument with validation; Part B enumeration
in Steps 2–3 to list all 9 standard categories and 7 language directories as absent
when root is empty (prevents 0-count output on greenfield directories).

---

## S-4: rr-standards:review ✓ COMPLETE (2026-03-08, security-reviewer + hook-reviewer added 2026-03-08)

**What:** Worker skill for PR gate review of standards artifact changes. Spawns
parallel internal agents per changed artifact; applies confidence scoring;
produces structured report conforming to review output schema.

**Location:** `plugins/rr-standards/skills/review/`

**Design refs:** `../spec/skills.md § rr-standards:review` (full workflow + internal agents),
`.forge/efforts/forge-plugin/spec/review-output-schema.md`

| Task | Status | Description |
|------|--------|-------------|
| T-4.1 | ✓ | Write `SKILL.md` — parse diff; classify changed files via TAXONOMY.md; spawn one `artifact-reviewer` agent per changed artifact via Task tool (parallel); spawn `confidence-scorer`; produce per-artifact and overall verdict |
| T-4.2 | ✓ | Write internal agent instructions for `artifact-reviewer` — quality checklist, change-type classification, version bump validation, policy-standard consistency, guide-standard consistency |
| T-4.3 | ✓ | Write internal agent instructions for `confidence-scorer` — score findings 0–100 per review output schema rubric |
| T-4.4 | ✓ | Write `README.md` — purpose, `--base` and `--pr` flags, `--ci` flag, CI setup example |
| T-4.5 | ✓ | Update `SKILL.md` — route `skills/**/SKILL.md` files as `skill-definition` type (security-reviewer only); spawn one `security-reviewer` agent per changed artifact (all types) in parallel with artifact-reviewer agents; merge security findings into per-artifact report and overall verdict |
| T-4.6 | ✓ | Write internal agent instructions for `security-reviewer` — five checks: `prompt-injection`, `hidden-unicode`, `instruction-override`, `obfuscation`, `exfiltration`; full-file scan at HEAD; diff-slice scan for added lines; confidence threshold 70; code-block exclusion; false-negative bias instruction to confidence-scorer |
| T-4.7 | ✓ | Update `SKILL.md` — route `skills/**/references/*.md` as `agent-reference` (security-reviewer), `templates/*.md` as `template` (security-reviewer), `.claude/hooks/*.sh` as `hook-script` (hook-reviewer); update classification special-cases and spawn step; update confidence-scorer prompt to include hook-security category; update per-artifact report to show hook security section |
| T-4.8 | ✓ | Write internal agent instructions for `hook-reviewer` — four checks: `network-exfiltration`, `credential-access`, `file-exfiltration`, `obfuscated-execution`; diff-slice scan; confidence threshold 70; comment exclusion; false-negative bias; `per_artifact_security_verdict` output |

**Acceptance:**
- ✓ PR touching only non-artifact files → passing result, no findings
- ✓ PR with missing version bump on a standard → FAIL with blocking `version-bump` finding
- ✓ PR with stale policy rows → FAIL with blocking `policy-consistency` finding
- ✓ `--ci` flag → JSON to stdout conforming to review output schema; exit 1 on FAIL
- ☐ PR with "ignore previous instructions" in a standard → FAIL with blocking `prompt-injection` finding
- ☐ PR with zero-width space outside a code block → FAIL with blocking `hidden-unicode` finding
- ☐ PR modifying a `SKILL.md` with injection pattern → FAIL (security-reviewer runs on skill definitions)
- ☐ PR where injection pattern appears only inside a fenced code block → PASS (code block excluded)
- ☐ PR modifying a `skills/**/references/*.md` agent reference → security-reviewer runs, not artifact-reviewer
- ☐ PR modifying a hook script with `curl | bash` pattern → FAIL with blocking `obfuscated-execution` finding
- ☐ PR modifying a hook script that reads `~/.aws/credentials` → FAIL with blocking `credential-access` finding

---

## S-5: rr-standards:validate — Active Behavioral Validation

**What:** Extend the validate skill with an `--active` mode that tests whether a
standard is behaviorally effective — not just structurally correct. Implements an
evaluation accuracy test (canonical example classification with train/test split),
a generation lift test, and an optional iterative improvement loop using LLM extended
thinking. Draws directly from the skill-creator eval loop pattern.

**Location:** `plugins/rr-standards/skills/validate/` (update existing `SKILL.md` and `README.md`)

**Design refs:** `../spec/skills.md § rr-standards:validate § Active Testing`,
`../requirements/business.md § BR-11`

**Depends on:** S-1 (extends it)

| Task | Status | Description |
|------|--------|-------------|
| T-5.1 | ✓ | Define `.evals.json` golden examples schema: `{standard_path, standard_version, generated_at, generated_by, examples: [{id, type: "compliant"\|"non_compliant", artifact_snippet, violates_rules: [R-N, ...], rationale}]}`; documented in `standards/TAXONOMY.md § Companion Artifacts` |
| T-5.2 | ✓ | Extend validate `SKILL.md`: add `--active`, `--improve`, `--iterations` flags; add Phase 2 (eval accuracy) and Phase 3 (generation lift) workflow steps; add `eval-accuracy` and `generation-lift` to stable check IDs table |
| T-5.3 | ✓ | Implement auto-generation of `.evals.json`: 5 compliant + 5 non-compliant examples derived from the standard's rules and Examples section; write to `<standard-path>.evals.json`; include `"generated_by": "auto"` marker |
| T-5.4 | ✓ | Implement 60/40 stratified train/test split and per-run classification loop: ask Claude to classify each example against the standard without disclosing ground truth; compute `train_accuracy`, `test_accuracy`, `baseline_accuracy`, `lift`, and per-rule failure rate |
| T-5.5 | ✓ | Implement generation lift test (Phase 3): generate 3 artifacts with/without standard, evaluate each against the compliance checklist, report per-item and aggregate delta |
| T-5.6 | ✓ | Implement iterative improvement loop (`--improve`): identify top-3 failing rules, use extended thinking to suggest rewording, apply author-accepted changes, re-evaluate, track history, select best test-set version; max 5 iterations |
| T-5.7 | ✓ | Update `README.md`: document `--active`, `--improve`, `--iterations` flags; add example session showing eval-accuracy output; document `.evals.json` format and curation guidance |
| T-5.8 | ✓ | Validated against `plugins/forge/standards/api/rest.md`: authored `plugins/forge/standards/api/rest.evals.json` with 5 compliant + 5 non-compliant examples covering 8 distinct rules (R-2, R-4, R-12, R-14, R-17, R-18, R-19, R-23); `"generated_by": "author"` |

**Acceptance:**
- ✓ `--active` runs structural checks first, then Phase 2 (eval accuracy) and Phase 3 (generation lift)
- ✓ If `.evals.json` is absent: auto-generates with `"generated_by": "auto"` and notes it needs author review
- ✓ `eval-accuracy` is blocking when `test_accuracy < 0.80` OR `lift < 0.20`
- ✓ `generation-lift` is always informational; reports per-checklist-item compliance delta
- ✓ Phase 2 report identifies the top-3 R-N rules by misclassification rate
- ✓ `--improve` iterates up to 5 times; selects the version with the best test-set accuracy; reports full iteration history
- ✓ `plugins/forge/standards/api/rest.md` passes `--active` validation (eval-accuracy ≥ 0.80) directly or after `--improve`

---

## Completion Criteria

The rr-standards-plugin epic is complete when:
- [x] `rr-standards:validate` has `SKILL.md` and `README.md` at `plugins/rr-standards/skills/validate/`
- [x] `rr-standards:coverage` has `SKILL.md` and `README.md` at `plugins/rr-standards/skills/coverage/`
- [x] `rr-standards:author` has `SKILL.md` and `README.md`
- [x] `rr-standards:review` has `SKILL.md` and `README.md`
- [x] `rr-standards:review` `SKILL.md` routes `skill-definition` type to security-reviewer and spawns security-reviewer for all artifact types
- [x] `rr-standards:review` `security-reviewer` agent instructions cover all five check IDs with code-block exclusion and false-negative bias
- [x] `rr-standards:review` `SKILL.md` routes `agent-reference` and `template` types to security-reviewer, `hook-script` type to hook-reviewer
- [x] `rr-standards:review` `hook-reviewer` agent instructions cover all four check IDs with comment exclusion and false-negative bias
- [x] `rr-standards:validate` passes its own quality checklist when run on a sample standard (confirmed via 100% eval pass rate across 3 iterations)
- [x] `rr-standards:coverage` produces a correct `standards/COVERAGE.md` for this repository
- [x] `rr-standards:test` is implemented and documented (S-5 — delivered as a standalone skill at `plugins/rr-standards/skills/test/` rather than an `--active` extension of validate, consistent with `spec/skills.md`)
- [x] `.test.yaml` schema is defined; auto-generation works when examples file is absent (S-5 T-5.1, T-5.3 — format changed from `.evals.json` to `.test.yaml` during implementation)
- [x] `plugins/forge/standards/api/rest.md` passes behavioral validation (S-5 T-5.8)
