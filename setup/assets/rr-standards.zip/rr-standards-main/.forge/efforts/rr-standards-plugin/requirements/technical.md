# Technical Requirements — Coding Guidelines, Standards, and Guides

Parent initiative: [ai-pr](../../ai-pr/requirements/technical.md)

---

## Current State

The repository contains two primary locations for standards content:

- **`standards/<category>/`** — language-agnostic rules (what to build)
- **`languages/<lang>/guides/<area>/`** — language-specific implementation guides (how to build it)

**Mature areas:** REST API, Testing (unit/integration/e2e), Messaging, Extension Development, Skills framework

**Stubs (no content):** Observability (`logging.md`, `overview.md`), Security (`overview.md`), Deployment (`ci-cd.md`), PostgreSQL storage, Kotlin, SQL

**Partial:** Go (guides exist, AGENTS.md thin), Swift (style guide complete, project structure missing), Storage (DynamoDB complete, PostgreSQL absent)

This epic defines the infrastructure for the standards library — artifact taxonomy, templates, quality criteria, and skills. Writing the missing standards themselves is out of scope; those are separate stories that will use the infrastructure this epic produces.

---

## TR-1: Artifact Taxonomy

### TR-1.1: Artifact Types

The following artifact types must be formally defined and documented in a single
taxonomy reference (suggested path: `standards/TAXONOMY.md` or incorporated into
`standards/AGENTS.md`):

| Type | Location pattern | Purpose |
|------|-----------------|---------|
| **Language-agnostic standard** | `standards/<category>/<standard>.md` | Defines what is required, independent of language or framework. Rules that apply regardless of how the code is written. |
| **Language guide** | `languages/<lang>/guides/<area>/<guide>.md` | Defines how to implement a standard in a specific language or framework. Always references its parent standard. |
| **Enforcement policy** | `standards/<category>/<standard>.policy.md` and `languages/<lang>/<lang>.policy.md` | Assigns a severity (blocking / advisory / informational) to each rule in the companion standard or language guide. Sets the advisory_threshold for count-based blocking. Authored by IC codeowners. Not injected at generation time — loaded at review time only. |
| **AGENTS.md** | Every directory in `standards/` and `languages/` | AI navigation file. Tells an agent what is in the directory, which files are relevant for which tasks, and how to navigate to related content. |
| **README.md** | Selected directories | User-facing catalog. Entry point for engineers browsing the repository. Not every directory requires both — the taxonomy must define when each is required. |
| **Template** | `templates/<artifact-type>-template.md` | Structural scaffold for creating a new artifact. Filled in by authors; not consumed directly by agents. |

### TR-1.2: Required Sections per Artifact Type

**Language-agnostic standard** must contain:
1. **Overview** — what this standard governs and why it exists
2. **Scope** — what it applies to; explicit list of what is out of scope
3. **Rules** — the substantive requirements. Each rule must be stated in a form
   that works for both generation ("do X") and evaluation ("check for X"). Rules
   may be numbered (FR-N) when there are many; unnumbered sections are acceptable
   for shorter standards.
4. **Examples** — conceptual examples in pseudo-code for non-obvious rules; each
   example explains why the pattern is correct; no language-specific syntax (runnable
   examples belong in language guides)
5. **Related** — links to related standards and to language guides that implement
   this standard

Note: Standards do **not** contain a compliance checklist. Evaluation assertions
(what a reviewer checks to determine whether each rule is satisfied) belong in the
companion enforcement policy, not the standard. This allows enforcement criteria to
evolve independently of rule definitions and allows projects to override evaluation
expectations without modifying the standard.

**Language guide** must contain:
1. **Overview** — what this guide covers; guide version; optionally, which standard it
   implements and that standard's version (required only when the guide references a standard)
2. **Related standard** — link to the parent standard in `standards/` when one exists;
   standalone guides that have no companion standard are valid — the section should note
   that the guide is standalone or link to related content
3. **Linter** — name the linter used for this language and the config file path
   (e.g., `ktlint`, config at `.editorconfig`). State that generated code must pass
   the linter. Do not restate lint rules — the reference is sufficient.
4. **Prerequisites** — tools, libraries, or configuration required
5. **Implementation** — step-by-step guidance with complete, runnable code examples
6. **Verification** — how to confirm the implementation is correct (test command,
   lint check, or observable behavior)

**Enforcement policy file** must contain:
1. **Standard reference** — which standard or language guide this policy governs
2. **Severity table** — one row per rule: rule identifier (matching the rule's
   identifier in the companion standard), default severity (`blocking` or
   `informational`), and an optional one-line rationale for non-obvious choices
3. **Version** — the version of the companion standard this policy was authored
   against; a major version bump in the standard requires policy review

**AGENTS.md** must contain:
1. **Directory purpose** — one-paragraph description of what is in this directory
2. **File index** — for each file or subdirectory: name, one-line purpose, and when
   an agent should reference it

**README.md** must contain:
1. **Purpose** — what this directory is for
2. **Contents catalog** — table or list of available content with descriptions
3. **Usage guidance** — how engineers should use this content

### TR-1.3: Boundaries Between Types

The taxonomy must document the following boundary decisions explicitly:

**Standard vs. language guide:**
- A language-agnostic standard must not contain language-specific code. It may
  reference language guides for implementation examples.
- A language guide must not restate the rules; it must show how to satisfy them.
- A language guide may optionally reference a companion standard. If it does, it must
  link to an existing standard file and declare the version it implements. Guides
  without a companion standard are valid standalone guides.

**Evaluation scope:**
- A language-agnostic standard operates at **design-time scope**: it can validate a
  tech spec, OpenAPI document, or other design artifact before any code is written.
  `forge:validate` uses standards at this scope.
- A language guide operates at **code-time scope**: it validates implementation — how
  the code expresses the standard in a specific language. `forge:review` uses language
  guides at this scope.
- Both scopes apply to most work: the API standard validates the design; the Java
  language guide validates the Spring Boot implementation of that design. They are
  complementary, not sequential gates.

**Standard vs. enforcement policy:**
- A standard contains only rules — what is correct. It must not contain severity
  assignments.
- An enforcement policy contains only severity assignments — it must not restate or
  modify the rules. If a rule needs to change, the standard is updated; if the
  organizational importance of a rule changes, the policy is updated.

**Standard vs. linter:**
- A language guide references the linter by name and config path. It must not
  restate lint rules. Lint rules are enforced by the linter at CI time; the standard
  covers semantic rules that linters cannot detect.

**AGENTS.md vs. README.md:**
- AGENTS.md is for AI navigation; README.md is for human browsing. A directory may
  have both, one, or neither — the taxonomy must specify when each is required.

---

## TR-2: Templates

### TR-2.1: Standard Template (`templates/standard-template.md`)

A template exists at this path but must be reviewed and updated to conform to the
taxonomy defined in TR-1.2. The updated template must:
- Contain all required sections from TR-1.2 with authoring instructions inline
- Include a worked example showing positive and negative code (with language
  placeholder markers)
- Be self-contained: an author with no prior knowledge of the format must be able
  to produce a compliant draft by following the template alone

### TR-2.2: Language Guide Template (`templates/language-guide-template.md`)

A template must be created at this path. It must:
- Contain all required sections from TR-1.2 with authoring instructions inline
- Include a placeholder for the related standard link
- Show the expected format for code blocks (language specifier, comments for clarity)
- Include a verification section with example test commands

### TR-2.3: AGENTS.md Template (`templates/agents-md-template.md`)

A template must be created at this path. It must:
- Contain all required sections from TR-1.2 with authoring instructions inline
- Include an example file index table with sample entries
- Provide guidance on how to write navigation links that remain valid as the
  repository grows

### TR-2.4: Enforcement Policy Template (`templates/enforcement-policy-template.md`)

A template must be created at this path. It must:
- Contain the standard reference placeholder and severity table structure
- Include an example severity table with sample rules at all three severity levels
- Include inline authoring guidance explaining when to choose blocking vs. advisory vs. informational
- Include the version field with a note that major standard version bumps require
  policy review

---

## TR-3: Quality Criteria

### TR-3.1: Standard Quality Checklist

The following checks must be defined and documented. Each check must be binary
(pass/fail) so it can be applied mechanically by an agent or a human reviewer:

**Structural completeness:**
- [ ] All required sections from TR-1.2 are present (Overview, Scope, Rules,
      Examples, Related)
- [ ] No section contains only placeholder text from the template
- [ ] All internal links resolve to files that exist

**Rule quality:**
- [ ] Every rule is stated in dual-use form: can be read as a generation directive
      and as an evaluation criterion
- [ ] No rule is purely procedural ("follow the guide") — each must state a
      specific, checkable outcome
- [ ] Rules do not contain language-specific code (language-agnostic standards only)

**Examples:**
- [ ] At least one positive (compliant) example is present
- [ ] Examples use pseudo-code or plain prose — no language-specific syntax
- [ ] Examples do not use placeholder variable names (e.g., `foo`, `bar`) in
      production-pattern illustrations

**Metadata:**
- [ ] A version number is present (semantic versioning; initial publications at `1.0.0`)
- [ ] Related standards links are present and resolve

**Token efficiency (see TR-7):**
- [ ] Rules are stated in imperative, directive form — not preceded by motivational prose
- [ ] No rule or checklist item is duplicated or paraphrased elsewhere in the document
- [ ] File does not exceed 300 lines
- [ ] Each code example is the minimum length needed to demonstrate the rule; no
      tutorial-length walkthroughs

### TR-3.2: Language Guide Quality Checklist

- [ ] All required sections are present (Overview, Related standard, Prerequisites,
      Implementation, Verification)
- [ ] If the guide references a companion standard (i.e., a link to `standards/` is
      present), that link resolves to an existing file
- [ ] If an `Implements:` declaration is present in Overview, it is well-formed:
      `Guide: X.Y.Z | Implements: standards/<category>/<standard>.md@X.Y.Z`
- [ ] All code examples are complete and runnable (no ellipses or "..." placeholders
      in critical sections)
- [ ] The Verification section includes a concrete command or observable behavior
- [ ] No section contains only placeholder text

**Token efficiency (see TR-7):**
- [ ] The guide does not restate rules from a parent standard — it only adds
      implementation specifics (check applies only when a standard is referenced)
- [ ] File does not exceed 500 lines (single-file guide) — see TAXONOMY.md for the
      multi-context directory form

### TR-3.3: AGENTS.md Quality Checklist

- [ ] Directory purpose paragraph is present and accurate
- [ ] Every file and subdirectory in the directory has an entry in the file index
- [ ] File index entries include: file name, one-line purpose, and a "when to use" note

**Token efficiency (see TR-7):**
- [ ] File index entries are one line each — no paragraph-length descriptions
- [ ] File does not exceed 100 lines

### TR-3.4: Enforcement Policy Quality Checklist

- [ ] Standard reference is present and resolves to an existing standard file
- [ ] Every rule in the companion standard has an entry in the severity table
- [ ] No rule is present in the severity table that does not exist in the companion
      standard (stale entries are a defect)
- [ ] Every severity value is exactly `blocking`, `advisory`, or `informational` — no other values
- [ ] The version field matches the current version of the companion standard
- [ ] The policy file contains no rule text — only rule identifiers and severity
      assignments

---

## TR-4: Standards Coverage Map

### TR-4.1: Coverage Reference Document

A single document must exist that records the coverage state of the standards library.
Suggested path: `standards/COVERAGE.md`. It must contain:
- For each standard category (`api/`, `storage/`, `testing/`, etc.): status of each
  file (present and complete / draft / stub / absent)
- For each language (`java/`, `go/`, `swift/`, etc.): status of AGENTS.md and each
  guide area (present / partial / stub / absent)
- The date of last review

### TR-4.2: Stub Identification

All existing stub files (files with fewer than 10 lines of substantive content) must
be identified and listed in the coverage document. The current known stubs are:

**Standards:**
- `standards/observability/overview.md` — empty
- `standards/observability/logging.md` — empty
- `standards/security/overview.md` — empty
- `standards/deployment/ci-cd.md` — empty
- `standards/storage/postgresql.md` — empty
- `standards/messaging/messaging.md` — near-empty TOC only

**Languages:**
- `languages/kotlin/` — AGENTS.md stub (3 lines), no guides
- `languages/sql/` — AGENTS.md stub (3 lines), no guides

**Partial:**
- `languages/go/AGENTS.md` — 118 lines; has guides but AI navigation thin
- `languages/swift/` — strong style guide and testing, missing project structure guide

---

## TR-5: Skills

### TR-5.1: `rr-standards:author`

**Agent type:** Orchestrator (interactive; iterates with engineer)

**Purpose:** Scaffold a new standard or language guide from the appropriate template,
guiding the author through required sections.

**Behavior:**
1. Prompt for artifact type (standard / language guide / enforcement policy / AGENTS.md)
2. Run Domain Scope Assessment before naming files when creating a new standard or language guide
3. Prompt for category or language and artifact name
4. Copy the appropriate template to the correct path in the repository
5. Walk the author through each required section, providing authoring guidance inline
6. After each section, prompt for content or to skip (marking it as a known gap)
7. On completion, invoke `rr-standards:validate` automatically and surface the
   quality report before the author commits

**Output:** A new artifact file at the correct path, pre-populated with the author's
content, conforming to the taxonomy structure.

### TR-5.2: `rr-standards:validate`

**Agent type:** Worker (reads artifact file; produces structured report)

**Purpose:** Evaluate a draft standard, language guide, enforcement policy, or AGENTS.md
against the quality criteria defined in TR-3 and produce an actionable gap report.

**Flags:**
- `--ci` — machine-readable JSON output; exit code 1 on FAIL

**Behavior:**
1. Accept a file path or directory as input
2. Detect artifact type from path (standard / language guide / enforcement policy / AGENTS.md)
3. Apply the corresponding quality checklist from TR-3
4. For each failing check: record the check, the evidence (what was found or missing),
   and a suggested fix
5. Produce a structured report with: overall pass/fail, blocking gaps (must fix before
   publication), and informational findings (should fix but not blocking)

**Output:** Human-readable inline report (default), or machine-readable JSON (`--ci`).

**Stable check IDs** (join keys for trend queries — never renamed or reused):

| `check_id` | Applies to | Severity |
|------------|------------|----------|
| `required-sections` | All types | Blocking |
| `rule-identifiers` | Standard | Blocking |
| `size-limit` | All types | Blocking |
| `severity-values` | Policy | Blocking |
| `policy-completeness` | Policy | Blocking |
| `implements-declaration` | Language guide | Blocking |
| `related-standard-link` | Language guide | Blocking |
| `file-index-complete` | AGENTS.md | Blocking |
| `links` | All types | Blocking |
| `rule-quality` | Standard | Informational |
| `examples-quality` | Standard, language guide | Informational |
| `metadata` | Standard | Informational |
| `no-rule-text` | Policy | Blocking |
| `no-rule-restatement` | Language guide | Informational |
| `entry-length` | AGENTS.md | Informational |

### TR-5.3: `rr-standards:coverage`

**Agent type:** Worker

**Purpose:** Generate or refresh the standards coverage map (TR-4.1).

**Behavior:**
1. Walk `standards/` and `languages/` directories
2. For each file: assess status (present+complete / draft / stub / absent) using
   line count and section presence as heuristics
3. Write `standards/COVERAGE.md` with the current state
4. Surface a summary: total artifact count, complete count, stub count, and the
   highest-priority gaps based on program requirements

### TR-5.4: `rr-standards:review`

**Agent type:** Orchestrator (non-interactive; PR gate worker)

**Purpose:** Review a pull request that modifies standards artifacts. Parses the diff,
classifies changed files using `standards/TAXONOMY.md`, and runs a parallel batch of
sub-agents to produce per-artifact and overall APPROVE/DENY verdicts. Detailed behavior
is specified in TR-9 (standards change review) and TR-10 (prompt injection security
screening).

**Input:**
- `--base <branch>` — diff base branch (auto-detected from `git symbolic-ref` when omitted)
- `--pr <number>` — optional; review an existing PR by number using `gh pr diff`
- `--ci` — machine-readable JSON output; omit for interactive terminal output
- `--skip-test` — omit `rr-standards:test --ci` from the parallel batch

**Sub-agents spawned in parallel** (via Task tool):
- `rr-standards:validate --ci` — structural quality checks per changed artifact
- `rr-standards:test --ci` — behavioral effectiveness check per changed standard or guide
- `artifact-reviewer` — change-type classification, version bump, policy consistency,
  guide staleness (one instance per changed standards artifact)
- `security-reviewer` — prompt injection, hidden Unicode, instruction override,
  obfuscation, exfiltration (one per standards artifact, SKILL.md, agent reference, template)
- `hook-reviewer` — network exfiltration, credential access, file exfiltration,
  obfuscated execution (one per changed hook script)

**Stable check IDs** — see TR-9 and TR-10 for the complete list. Summary:

| `check_id` | Category | Agent |
|---|---|---|
| `quality-checklist` | `quality` | artifact-reviewer |
| `version-bump` | `version` | artifact-reviewer |
| `policy-consistency` | `policy-consistency` | artifact-reviewer |
| `guide-staleness` | `guide-staleness` | artifact-reviewer |
| `prompt-injection` | `security` | security-reviewer |
| `hidden-unicode` | `security` | security-reviewer |
| `instruction-override` | `security` | security-reviewer |
| `obfuscation` | `security` | security-reviewer |
| `exfiltration` | `security` | security-reviewer |
| `network-exfiltration` | `hook-security` | hook-reviewer |
| `credential-access` | `hook-security` | hook-reviewer |
| `file-exfiltration` | `hook-security` | hook-reviewer |
| `obfuscated-execution` | `hook-security` | hook-reviewer |

**Output:** Overall APPROVE/DENY verdict; per-artifact findings sections; posted as a
PR comment in CI. Human approval is always a valid merge path — the verdict is a signal,
not a veto.

---

### TR-5.5: `rr-standards:test`

**Agent type:** Worker (non-interactive; delegates execution to Python harness)

**Purpose:** Measure the behavioral effectiveness of a standard or language guide by
running with/without-context LLM evaluations and computing verdict accuracy and lift.
This is the behavioral testing counterpart to `rr-standards:validate`'s structural checks.

**Input:** File path to a standard or language guide (or a directory for batch mode).

**Flags:**
- `--ci` — machine-readable JSON output; suppresses the test viewer and ignores
  `--iterations`; exit code 1 if `test-accuracy` FAIL
- `--iterations N` — number of iterative improvement cycles to run (default: 1;
  ignored when `--ci` is passed)
- `--clean` — delete the workspace for this standard before starting; discards all
  prior iterations, benchmarks, and feedback

**Behavior:**
1. Accept a file path or directory. If directory: enumerate all standards and language
   guides within it.
2. Locate or auto-generate the `.test.yaml` companion file for each artifact (same
   auto-generation logic as the former `--active` mode)
3. Resolve `artifact_file` references in the test file (substitute referenced fixture
   files as inline `artifact_snippet` values before passing to the harness)
4. Invoke the Python test harness script
   (`<skill-base-dir>/test-runner/run_tests.py`) with the resolved test data and
   workspace path as arguments
5. The harness runs all tests, collects compact JSON summaries, aggregates benchmark
   results, and writes workspace files (see Workspace layout below)
6. Launch `test-viewer/generate_review.py` as a background HTTP server; wait for the
   author to confirm review completion
7. Read `feedback.json` written by the viewer; present proposed rule improvements per
   R-N; apply author-accepted changes to the standard file
8. Re-run steps 4–7 for each additional iteration up to `--iterations N`

**Executor requirements** (TR-5.5.1):
- Zero runtime dependencies beyond what the host environment already provides
- All test cases must be executed concurrently; a failure in one test must not affect
  others
- Each test uses a **two-phase evaluation model** to prevent expectation contamination:
  - **Phase 1 (blind):** evaluator receives the artifact snippet and the standard/guide,
    but NOT the test expectations; produces a verdict and free-form reasoning
  - **Phase 2 (grading):** a second evaluator receives the Phase 1 output alongside the
    test expectations and scores it; the grading evaluator has no standard context —
    it evaluates whether Phase 1 met the expectations only
  - Both `with_<ctx>` and `without_<ctx>` run Phase 1 blind; `without_<ctx>` Phase 1
    receives only the artifact snippet (no standard, no expectations)
- Evaluator prompts must instruct the evaluator to produce structured output only, with
  no surrounding prose or markdown; the executor must tolerate evaluator responses that
  contain valid structured output embedded in other text, and must record a test error
  (not crash) when no valid structured output is found in the response
- The executor must persist per-test evaluation outputs, grading results, and the prompts
  used to a workspace directory so authors can inspect individual outcomes; an aggregate
  accuracy summary across all tests must be written on run completion
- `without_<ctx>` results from a prior iteration must be reusable in subsequent
  iterations without re-running (the unguided baseline is deterministic per snippet)
- Executor exits non-zero if `test-accuracy` FAIL (`with_accuracy < 0.80`); low lift
  (`lift < 0.20`) emits a `generation_lift_warning` but does not cause a non-zero exit

**Context variable `<ctx>`:** `standard` for language-agnostic standards; `guide` for
language guides. Subprocess workspace directories are named `with_<ctx>/` and
`without_<ctx>/` accordingly.

**Stable check IDs** (see TR-5.2 for the validate skill's check IDs):

| `check_id` | Applies to | Severity |
|------------|------------|----------|
| `test-accuracy` | Standard, language guide | Blocking |
| `generation-lift` | Standard, language guide | Informational |

**Pass thresholds:**
- `test-accuracy: PASS` requires `with_accuracy ≥ 0.80` — did the standard's own tests pass?
- `generation-lift: WARNING` when `lift < 0.20` — informational only; does not cause FAIL or affect exit code
- A standard can PASS `test-accuracy` with zero or negative lift — the blocking gate is accuracy, not lift

**CI output (`--ci`):**
When `--ci` is passed, the skill suppresses the test viewer and the iterative
improvement loop. The Python harness runs once and the skill emits a single JSON
record to stdout:
```json
{
  "verdict": {
    "result": "pass" | "fail",
    "with_accuracy": 0.NN,
    "without_accuracy": 0.NN,
    "lift": 0.NN,
    "generation_lift_warning": true | false
  },
  "tests": [
    {
      "test_id": "<id>",
      "expected_verdict": "compliant" | "non_compliant",
      "with_verdict_correct": true | false,
      "without_verdict_correct": true | false,
      "with_pass_rate": 0.NN,
      "without_pass_rate": 0.NN
    }
  ]
}
```

Field definitions:
- `verdict.result`: `"pass"` when `with_accuracy ≥ 0.80`; `"fail"` otherwise (lift does not affect result)
- `verdict.generation_lift_warning`: `true` when `lift < 0.20`; informational signal, never affects `result`
- `verdict.with_accuracy`: fraction of tests (0.0–1.0) where `with_<ctx>` Phase 1 verdict was correct
- `verdict.without_accuracy`: fraction of tests where `without_<ctx>` Phase 1 verdict was correct
- `verdict.lift`: `with_accuracy − without_accuracy`
- `tests[].with_pass_rate` / `tests[].without_pass_rate`: per-test accuracy (1.0 or 0.0 for single runs)
- `tests[].with_verdict_correct` / `tests[].without_verdict_correct`: boolean; `true` if Phase 2 grading
  determined the Phase 1 verdict matched `expected_verdict`

Exit code 1 if `verdict.result == "fail"`. Exit code 0 on pass.

---

## TR-6: Standards Loading — Generation vs. Review Time

Enforcement policy files are **never** loaded at code generation time. At generation
time only the standard and language guide are loaded — the agent needs to know what
correct code looks like, not how severely violations will be treated. Policy files
are loaded only at review time, by `forge:review`, alongside the companion standard.
This keeps generation context lean and ensures severity assignments have no influence
over what code is produced.

At review time, `forge:review` loads: (1) the standard, (2) the companion policy
file, (3) the project-level override file if one exists. Project overrides win over
the default policy; the default policy wins where no override is present.

### TR-6.1: File-Type to Standard Mapping

A canonical mapping must exist from file type (extension or path pattern) to the
relevant standards documents that must be loaded before generating or editing that
file type. This mapping is consumed by the PreToolUse hook (TR-6.2) and by individual build skills.

The mapping must cover all supported languages and standard categories. Example
entries (non-exhaustive):

| File pattern | Standards to inject |
|-------------|---------------------|
| `*.go` | `languages/go/AGENTS.md` + `standards/api/rest.md` (if API file) |
| `*.java` | `languages/java/AGENTS.md` + relevant category standard |
| `*.ts`, `*.tsx` | `languages/typescript/AGENTS.md` + relevant category standard |
| `*.swift` | `languages/swift/AGENTS.md` + relevant category standard |
| `*.kt` | `languages/kotlin/AGENTS.md` + relevant category standard |
| `*.py` | `languages/python/AGENTS.md` + relevant category standard |
| `**/migrations/**` | `standards/storage/postgresql.md` (or equivalent) |
| `**/kafka/**`, `**/messaging/**` | `standards/messaging/message-standards.md` |

The mapping must be maintained as a single authoritative source — not duplicated
across skills and hooks. When a new standard or language guide is added to the
repository, the mapping must be updated as part of the same change.

### TR-6.2: Universal Enforcement via the PreToolUse Hook

Standards injection must apply to **every** Write/Edit tool use, regardless of how
the session was initiated. Whether the engineer invoked a `forge:` build skill, used
a custom prompt, or made a direct request to the agent in free text — if code is
being written, the relevant standards must be in context before the first line is
generated.

A PreToolUse hook is the mechanism that enforces this universally. It fires on every
Write/Edit, inspects the target file path, looks up the canonical mapping from TR-6.1,
and injects the corresponding standards documents as context before the write proceeds.
Because the hook fires at the tool level — not the skill level — it cannot be bypassed
by any session pattern.

The hook must:
- Use the canonical mapping from TR-6.1 as its sole source of truth for which
  standards apply to which file types
- Inject both the language guide and the relevant category standard when both exist
  for the target file type
- Proceed without injection (not error) when no mapping entry matches the target
  path; it may emit an informational note that no standard was found for the file type
- Be maintained as standards are added: adding a new standard to the library without
  updating the hook mapping is a defect

### TR-6.3: Build Skill Standards Declaration

In addition to the universal hook enforcement in TR-6.2, every build skill
(`forge:build-api`, `forge:build-repo`, `forge:build-messaging`, and any future build
skill) must explicitly declare, in its `SKILL.md`, which standards it loads. This
declaration is supplementary to the hook — it makes the skill's standards contract
explicit and auditable, and enables `forge:validate-standard` to verify that every
referenced standard exists and passes quality criteria.

The declaration must:
- List standards by path, not by description
- Cover both the category standard and the language guide where one exists
- Be verified as part of the skill's own quality check: a skill that declares a
  standard that does not exist, or that has not passed quality criteria, is itself
  non-compliant

---

## TR-7: Token Efficiency

Standards are injected as context before every Write/Edit tool use. Every token a
standard consumes is a token unavailable for the code being generated, the design
artifacts being read, or the engineer's prompt. Verbose standards degrade agent output
quality — not immediately, but progressively, as multiple standards are injected
simultaneously and context fills. This is the same failure mode as BR-11 in the
forge-plugin program requirements, applied to the standards themselves.

The requirement is not to make standards brief at the cost of completeness. The
requirement is to achieve correct agent output with the minimum token cost. Every
sentence that does not change agent behavior is waste.

### TR-7.1: Directive Writing Style

Rules must be stated in imperative, active voice: **"Use X"**, **"Return Y"**,
**"Name endpoints Z"** — not "It is recommended to use X", "Y should be returned",
or "Best practices suggest naming endpoints Z". The directive form is shorter and
unambiguous. Agents do not require persuasion or context about why a rule exists to
follow it; rationale, when necessary at all, belongs in a separate ADR, not inline
in the standard.

### TR-7.2: Progressive Disclosure

Within any standard, the most critical rules must appear first. If a standard is
partially injected due to context pressure — or if an agent reads only the first N
tokens before beginning generation — it must have encountered the highest-impact
rules. Low-frequency edge cases and detailed exceptions belong at the end.

### TR-7.3: No Cross-Document Duplication

A rule stated in a language-agnostic standard must not be restated in a language
guide. The language guide adds implementation specifics (which library, which
pattern, which file) — it does not repeat the rule itself. If both the standard and
the guide are injected, the agent reads the rule once, not twice.

Similarly, rules must not be duplicated within a single document.

### TR-7.4: Minimal Examples

Each code example must be the minimum length needed to demonstrate the rule it
illustrates. The example must show the pattern clearly; it must not be a working
application, a full class, or a tutorial. An example that demonstrates a single rule
in 5 lines is better than one that demonstrates the same rule in 50.

One positive example per rule pattern is the default. A negative example (showing
the non-compliant form) is added only when the distinction is non-obvious.

### TR-7.5: File Size Limits

| Artifact type | Maximum lines |
|--------------|---------------|
| Language-agnostic standard | 300 |
| Language guide | 500 |
| Enforcement policy | 150 |
| AGENTS.md | 100 |

These are hard limits, not targets. A standard that approaches its limit must be
split into focused sub-documents (following the expansion pattern defined in the
forge-plugin workflow infrastructure) rather than allowed to grow beyond it.
Splitting a standard does not reduce the per-injection cost if the entire directory
is injected; the mapping in TR-6.1 must inject specific files, not directories.

---

## TR-8: Enforcement Policy Model

### TR-8.1: Severity Levels

Three severity levels are supported:

| Severity | Meaning |
|----------|---------|
| `blocking` | Any single finding of this severity blocks the PR. The violation must be resolved before `forge:review` approves. |
| `advisory` | Findings accumulate. The PR is blocked only when the total advisory count exceeds `advisory_threshold` (a policy-level setting). Below the threshold, findings are surfaced but do not block. |
| `informational` | Surfaced in the review report and never blocks, regardless of count. For engineer awareness only. |

`advisory_threshold` is defined in the companion policy file header. The default
is `null` (advisory findings never block). Set to an integer to enable
count-based blocking. Can be overridden per-project via `.forge/enforcement.yml`.

The severity assigned to a rule is the organizational default — the IC codeowners'
judgment of how seriously this violation should be treated across all projects.
Projects that need a different posture for a specific rule use the project override
mechanism (TR-8.3).

### TR-8.2: Policy File Structure

Each standard (`<standard>.md`) has a companion policy file (`<standard>.policy.md`)
co-located in the same directory. Each language guide root has a companion policy
(`<lang>.policy.md`) in the language root directory.

The rule identifier in the policy table must match the identifier used in the
companion standard. Standards must use consistent, stable rule identifiers (e.g.,
`R-N` or `FR-N`) so that policy entries remain valid across standard revisions that
do not change the rule's meaning. Rule identifiers are also the join key used by
the `ai-pr` metrics pipeline to aggregate findings across PRs and compute trends —
a rule identifier change that does not represent a rule change breaks historical
continuity in the metrics database and must be treated as a breaking change.

### TR-8.3: Project-Level Override

A project may override the default severity for any rule by placing an override file
at `.forge/enforcement.yml` in the repository root. The file lists only the rules
being overridden; all other rules inherit the default from the companion policy file.

Override entries must include a `reason` field. This prevents silent policy drift and
creates an audit trail for deviations from the organizational default.

### TR-8.4: Authorship and Governance

The default policy file is authored by the IC codeowners who own the standard, as a
required deliverable of the workshop that produces the standard. A standard without a
companion policy file is incomplete and must not be published.

When a standard's major version increments (rules removed or changed in meaning), the
companion policy must be reviewed and re-versioned. When a standard's minor version
increments (rules added), new rows must be added to the policy for the new rules;
existing rows remain valid. Patch updates require no policy change unless rule names
were corrected.

### TR-8.5: Scope — v1 Decisions

- **Repository-level override only**: team-level or squad-level override is out of
  scope for v1. Projects that need sub-repository granularity must use separate
  repositories or defer to v2.
- **Three severity levels**: `blocking`, `advisory`, and `informational`. Additional
  tiers (e.g., per-category thresholds) are out of scope for v1.

### TR-10.6: Internal Agent Reference Files in Scope

Files matching `skills/**/references/*.md` are internal agent instruction files
loaded by skill orchestrators via the Task tool and passed as instructions to
spawned agents (e.g., `artifact-reviewer.md`, `confidence-scorer.md`,
`security-reviewer.md`). A compromised agent reference file can cause an
orchestrating skill to behave maliciously — approving harmful standards, leaking
content, or producing misleading reports.

These files are classified as `agent-reference` type and routed to
`security-reviewer` only (not `artifact-reviewer`). The same five checks apply
as for `skill-definition` type (TR-10.1).

### TR-10.7: Hook Scripts

Files matching `.claude/hooks/*.sh` are PreToolUse or PostToolUse hook scripts
that execute as shell code on every Write/Edit tool call across every session.
A malicious hook is the highest-value attack target in the repository: it runs
with shell privileges, fires before every file write, and is invisible to the
agent generating code.

These files are classified as `hook-script` type and routed to a new
`hook-reviewer` internal agent (distinct from `security-reviewer` — the threat
model is shell code execution, not AI context injection). The `hook-reviewer`
applies four checks:

| Check ID | Description | Severity |
|---|---|---|
| `network-exfiltration` | `curl`/`wget`/`nc` calls targeting external URLs at hook runtime (not in comments or heredocs) | blocking |
| `credential-access` | Reads of `~/.ssh/`, `~/.aws/`, `$AWS_SECRET_*`, `$HOME/.config`, or any variable whose name contains `SECRET`, `KEY`, `TOKEN`, or `PASSWORD` | blocking |
| `file-exfiltration` | Writing repo file content to `/tmp`, pipes to external processes, or path traversal (`../`) outside the repo root | blocking |
| `obfuscated-execution` | Use of `eval`, base64-decoded command strings, or `$(...)` / `` ` `` `` ` `` with externally-fetched input | blocking |

All four checks are blocking at confidence ≥ 70. The same code-block exclusion and
false-negative bias rules from TR-10.4 apply.

The `hook-reviewer` also scans the diff slice for added lines (same TR-10.3 pattern
as `security-reviewer`) and tags findings with `in_diff: true` when introduced by
the PR.

### TR-10.8: Templates in Scope

Files matching `templates/*.md` are scaffolding templates used by `rr-standards:author`
to create new standards and language guides. Injecting malicious content into a
template propagates that content into every artifact created from it — a supply-chain
attack on the standards authoring workflow.

These files are classified as `template` type and routed to `security-reviewer` only
(not `artifact-reviewer`). The same five checks apply as for `skill-definition` type.

---

## TR-9: Standards Change Review

### TR-9.1: Diff-Aware Review Skill

A skill `forge:review-standard` must exist as a non-interactive worker. It accepts a
git diff of changes to `rr-standards` as input. For each changed artifact file in the
diff, the skill:

1. Detects the artifact type from its path (using the taxonomy location patterns)
2. Applies the quality checklist for that type to the current state of the file
3. Runs version bump validation (TR-9.2)
4. Runs policy-standard consistency checks when applicable (TR-9.3)
5. Produces a structured report: blocking gaps and informational findings, one section
   per changed artifact

Output follows the same blocking/informational structure as `forge:validate-standard`.
The skill may be invoked manually or by the PR gate workflow (TR-9.4).

### TR-9.2: Version Bump Validation

For each changed standard or language guide, the skill must determine what kind of
change was made by examining the diff and verify the version increment is appropriate:

| Change type | Required increment |
|-------------|-------------------|
| Rules removed or changed in meaning | MAJOR |
| Rules added | MINOR or greater |
| No rule changes (examples, prose, formatting) | PATCH or greater |
| No content changes affecting the rendered document | version unchanged acceptable |

A missing version bump is a blocking finding. An insufficient bump (e.g., PATCH when
MINOR was required) is a blocking finding. An excessive bump (e.g., MAJOR when only
a rule was added) is an informational finding — it communicates more urgency than
warranted but does not misrepresent correctness.

### TR-9.3: Policy and Guide Consistency with Standard Version

**Policy-standard consistency:** When a standard is modified, the skill must locate
the companion policy file and verify:

- Every rule currently in the standard has exactly one row in the policy table
- No row in the policy references a rule identifier that no longer exists in the
  standard (stale rows)

Both conditions are blocking findings. The skill must identify specifically which rule
IDs are missing or stale in the policy, so the author can fix them without reading the
full diff.

When an enforcement policy is modified directly (not as a consequence of a standard
change), the skill must verify that the standard reference version in the policy header
matches the current version of the companion standard, or is within a compatible range
(MINOR increment: policy remains valid; MAJOR increment: policy must be updated).

**Guide-standard consistency:** The severity of guide staleness findings depends on
which artifact is being changed, because the person changing a standard is not
responsible for updating guides — that requires language expertise they may not have.

When a **standard** is modified, the skill must search `languages/` for all language
guide files that declare an `Implements:` reference to that standard. Stale guide
findings on a standard change PR are always **informational** — the standard must be
mergeable without waiting for guide owners (who have different expertise) to update
their guides. The findings must identify:

- Which guides are now behind
- For MINOR bumps: which new rule IDs are not yet covered by each guide
- For MAJOR bumps (HIGH PRIORITY): that the guide is now MAJOR-stale and will be
  treated as supplementary only until updated (per the conflict resolution hierarchy in
  `standards/TAXONOMY.md`); the specific rules whose meaning changed or were removed;
  and a statement that code generation quality for affected rules is degraded until the
  guide is updated

MAJOR-stale guide findings must be recorded in the coverage map with status
`major-stale` and treated as higher priority than absent stubs — a MAJOR-stale guide
actively risks producing conflicting guidance rather than simply providing none.

This creates visibility and a work queue for guide owners without blocking the standard author.

When a **language guide** is modified directly, the skill must verify that the declared
standard version in the guide's `Implements:` header matches the current standard version.
Here the MINOR/MAJOR rules apply with their normal severity, because the guide author
chose to update the guide and should bring it current:
- Guide declares a version behind by a MINOR bump: informational finding
- Guide declares a version behind by a MAJOR bump: blocking finding

**Guide usability during staleness:** A guide whose declared standard version is behind
must remain fully loadable and usable. Its implementation content is still valid for the
rules it covers. Staleness is a tracked gap in the coverage map, not a breakage. Agents
loading a stale guide should use its content and, where possible, also load the current
standard to be aware of rules the guide does not yet cover.

### TR-9.4: PR Gate on rr-standards

A GitHub Actions workflow must run `forge:review-standard` automatically on every pull
request to `rr-standards` that modifies at least one file in `standards/` or
`languages/`. The workflow must:

- Post findings as a PR comment (summary always; inline diff comments where a finding
  can be anchored to a specific changed line)
- Set a named required status check so branch protection can gate on the result
- Human approval is always a valid merge path — the status check result is a signal,
  not a veto. A human reviewer may approve and merge despite open findings.

Pull requests that modify only non-artifact files (e.g., `.forge/`, `templates/`,
`scripts/`) do not trigger `forge:review-standard`.

---

## TR-10: Prompt Injection Security Screening

### TR-10.1: `security-reviewer` Internal Agent

A new internal agent `security-reviewer` must be added to `rr-standards:review`.
It runs in parallel with the existing `artifact-reviewer` agents. One
`security-reviewer` agent is spawned per changed artifact file.

**Purpose:** Detect prompt injection, instruction override, hidden Unicode, and
exfiltration patterns in changed standards artifacts and skill definitions.

**Checks** (all blocking at or above the confidence threshold; see TR-10.4):

| Check ID | Description |
|----------|-------------|
| `prompt-injection` | Known injection strings present: "ignore previous instructions", "disregard all", "forget your instructions", "disregard the above", "new task:", or semantically equivalent phrasings that attempt to nullify prior context |
| `hidden-unicode` | Zero-width spaces (U+200B–U+200D), right-to-left override (U+202E), bidirectional control characters (U+2066–U+2069, U+200F), or other invisible/control Unicode outside fenced code blocks |
| `instruction-override` | Patterns that attempt to redefine agent role or override context: "Your new role is", "From now on you are", "You are now", "Override:", "New system prompt:", "Act as", or equivalents that redirect agent behaviour away from its stated purpose |
| `obfuscation` | Base64-encoded strings of non-trivial length (>50 chars) appearing outside fenced code blocks; HTML entity sequences that decode to executable-looking text; systematic homoglyph or Cyrillic character substitution used to disguise instruction keywords |
| `exfiltration` | Instructions to read files outside `standards/`, `languages/`, `skills/`, or `templates/`; instructions to make HTTP/network requests; instructions to access environment variables, credentials, or system configuration |

### TR-10.2: Scope — Artifact Types Covered

The `security-reviewer` applies to all artifact types already covered by
`artifact-reviewer` (standards, language guides, enforcement policies, AGENTS.md)
and additionally to `SKILL.md` files in `skills/`.

Skill definitions are not standards taxonomy artifacts and are currently skipped by
`artifact-reviewer`. They must be explicitly included in the `security-reviewer`
scope because skill definitions are loaded directly as AI agent instructions and are
an equally high-value target for injection attacks.

The taxonomy classification step in `rr-standards:review` (workflow step 2) must be
updated: files matching `skills/**/SKILL.md` are classified as `skill-definition`
type and routed to `security-reviewer` only (not `artifact-reviewer`). All other
artifact types are routed to both agents.

### TR-10.3: Full-File Scan, Not Diff-Only

The `security-reviewer` must scan the **full content of each changed artifact at
HEAD**, not only the diff. An injection pattern may have been introduced in an
earlier commit; scanning only the diff would fail to detect it.

Additionally, the diff slice for added lines (+) is scanned separately. A pattern
present only in the base (removed by the PR) produces an informational finding. A
pattern present in added lines produces a blocking finding regardless of whether it
also appears in the base.

### TR-10.4: Confidence Threshold for Security Findings

Security findings use a minimum confidence score of 70 (on the 0–100 scale from the
review output schema). Findings below 70 are surfaced as informational rather than
blocking. This reduces false positives on legitimate content that superficially
resembles injection patterns (e.g., a security standard that documents injection
defenses by example, or a language guide that shows sanitisation code).

Security findings must use asymmetric confidence scoring: false negatives (missed
injections) are more costly than false positives (benign content flagged). When
uncertain, confidence must default to blocking with a note explaining the ambiguity,
so the human reviewer can make an informed decision.

### TR-10.5: Security Finding Severity in Report

Security findings appear as a dedicated section in the per-artifact report, separate
from quality and version findings. Blocking security findings set the per-artifact
verdict to FAIL regardless of quality findings. The overall PR verdict is FAIL if
any artifact has a blocking security finding.

---

## Constraints

### Out of Scope for This Epic

Writing the missing standards (security, observability, deployment, PostgreSQL,
Kotlin, SQL) is **not in scope** for this epic. This epic produces the infrastructure
— taxonomy, templates, quality criteria, coverage map, and skills — that subsequent
stories will use to write those standards efficiently and consistently.

### Dependency on This Epic

The following are blocked on this epic completing:
- Stories to write missing standards (security, observability, etc.)
- `forge:review` language-specific standards injection (TR-2.3 in ai-pr technical
  requirements) — the review skill can only inject standards that exist and conform
  to the taxonomy so they can be loaded reliably
- `forge:build-*` skill compliance with TR-6.2 — build skills cannot declare
  standards they load until those standards exist, are structured consistently,
  and the canonical mapping (TR-6.1) is in place

### Open Questions

1. **Version numbering for language guides** — should language guides carry their
   own semantic version, or inherit the version of their parent standard?
   - **Impact:** TR-2.2 template design and TR-3.2 quality checklist
   - **Decision needed by:** design phase

2. **AGENTS.md vs README.md requirement** — the taxonomy must specify when each is
   required. Current practice is inconsistent (some directories have both, some have
   one, some have neither).
   - **Impact:** TR-1.3 boundary definition and TR-2.3 template scope
   - **Decision needed by:** design phase

3. **Coverage status thresholds** — what line count / section presence heuristic
   should `forge:coverage` use to distinguish "present and complete" from "draft"
   from "stub"?
   - **Impact:** TR-4 coverage map accuracy and TR-5.3 skill implementation
   - **Decision needed by:** design phase
