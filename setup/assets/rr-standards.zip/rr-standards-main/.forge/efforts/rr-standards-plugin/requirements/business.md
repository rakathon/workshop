# Business Requirements — Coding Guidelines, Standards, and Guides

Parent initiative: [ai-pr](../../ai-pr/requirements/business.md)
Primary program BRs addressed: BR-4 (enforce standards automatically), BR-11 (maintain agent output quality regardless of session length), BR-14 (framework tooling must be testable), BR-19 (governed process for standards changes)

---

## Context

The `forge:review` skill verifies that every pull request meets organizational coding
standards. For that verification to work, standards must exist in a form that an AI
agent can load, interpret, and apply mechanically. This epic defines the infrastructure
that makes standards trustworthy and usable: a clear artifact taxonomy, templates that
encode the quality bar, quality checks that can be applied before publication, and
skills that guide authors through creation and validation.

Standards are complemented by enforcement policy files — separate artifacts that
assign severity to each rule. The standard defines what is correct; the policy defines
how seriously a violation is treated. These evolve independently and are authored by
IC codeowners as a joint output of the same workshop.

This epic is not about writing all the standards. It is about ensuring that every
standard written — now and in the future — is structured correctly, is complete, and
is usable by both engineers and AI agents.

---

### BR-1: A Shared Definition of What Constitutes a Standards Artifact Must Exist

There is no single authoritative definition of what types of artifacts make up the
standards library, what sections each type requires, or what the difference is between
a standard and a language guide. Authors creating new content must currently infer
these conventions from existing examples, which are inconsistent. Consumers —
engineers and AI agents alike — cannot reliably predict what they will find when they
open a standards file.

A clear, documented taxonomy of artifact types must exist, covering: what each type
is for, what sections it must contain, and where it belongs in the repository
structure. This is the foundation that all other requirements in this epic depend on.

### BR-2: Creating a New Standard or Language Guide Must Start from a Template

Authors creating a new standard or language guide must not start from a blank file.
Starting from scratch produces inconsistent structures, missing sections, and
variable quality. A template must exist for each artifact type, encoding the required
sections, the quality bar, and authoring guidance. The template must be self-contained
and copy-able — an author should be able to copy it, fill it in, and have a
publishable artifact without consulting additional documentation.

### BR-3: Standards Must Be Evaluable Against Defined Quality Criteria Before Publication

There must be a defined, checkable set of quality criteria for each artifact type.
An author — or an AI agent — must be able to inspect a draft standard and determine
whether it is ready to publish. The criteria must be specific and binary (present /
absent, satisfied / not satisfied), not subjective. A standard that passes the
quality check is ready for team review; one that fails is not.

Currently there is no defined quality bar. Some standards are comprehensive and
well-structured (testing, REST API); others are stubs or are missing key sections.
Without a quality gate, consumers cannot know whether a given standard can be trusted
as authoritative.

### BR-4: AI Agents Must Be Able to Create and Validate Standards Artifacts

Engineers must be able to invoke a skill to scaffold a new standard or language guide
from the appropriate template, guided through the required sections. Similarly, a
skill must exist to validate an existing draft against the quality criteria and produce
a gap report that tells the author precisely what to fix.

This serves two purposes: it makes standards creation faster and more consistent, and
it allows AI agents to create standards for new platforms or languages as part of a
platform onboarding workshop, without requiring a human author to know the conventions.

### BR-5: Standards Must Be Structured for Dual Use — Generation and Evaluation

Every standard must be usable in two modes:
- **Generation mode**: an AI agent generating new code reads the standard and produces
  code that satisfies it
- **Evaluation mode**: an AI agent reviewing existing code reads the same standard and
  checks whether the code satisfies it

A standard that works only for generation (written as a how-to guide) or only for
evaluation (written as a checklist) is half-useful. The same document must serve both.
This is the property that allows `forge:review` to use standards authored for
`forge:build-api` — there is one standard, not one for writing and one for reviewing.

Evaluation operates at two scopes, and standards must support both:
- **Design-time evaluation**: a language-agnostic standard (e.g., the REST API
  standard) can validate a tech spec, OpenAPI document, or design artifact before a
  single line of code exists. `forge:validate` operates at this scope.
- **Code-time evaluation**: a language guide validates the implementation — how the
  code expresses the standard in a specific language and framework. `forge:review`
  operates at this scope.

Standards must not duplicate rules from a project's linter configuration. The linter
enforces syntactic and stylistic rules automatically; the standard covers semantic
rules that linters cannot detect (e.g., "all public method inputs must be validated
before use"). Language guides reference the linter by name and config path — that
reference is sufficient to instruct an agent to generate linter-compliant code without
restating every lint rule.

### BR-7: Coding Agents Must Generate Code That Adheres to the Relevant Standard

When an AI coding agent generates source code — whether implementing an API endpoint,
a data access layer, a message consumer, or any other artifact — the relevant
standards and language guides must be loaded as context before any code is written.
Code generation without the relevant standard is not acceptable; it produces output
that may be internally consistent but non-compliant with the organizational rules the
standard encodes.

This is the generative counterpart to BR-5. BR-5 requires that standards be
structured so they *can* be used for generation. This requirement mandates that they
*are* used for generation: the standard is not a post-hoc check, it is the
specification that code generation follows. A coding agent that produces code and then
checks it against the standard has the causal direction wrong. The standard must be
present in the agent's context before the first line is written.

For language-specific code, the applicable language guide must be loaded in addition
to the category standard. The language guide bridges the gap between "what is
required" (the standard) and "how to implement it in this language" (the guide).

### BR-8: Enforcement Evaluation and Severity Must Be Defined Separately From the Rules, With Project-Level Override

A rule defines what is correct. How to evaluate whether it is satisfied, and how
seriously a violation is treated, are distinct concerns — they can change without the
rule changing, and different projects may legitimately have different tolerances.
Mixing evaluation assertions or severity into the rule document conflates correctness
with enforcement policy and makes policy changes require edits to technical artifacts.

Each standard must have a companion enforcement policy file. For each rule, the policy
defines two things: (1) the **assertion** — a binary yes/no statement a reviewer applies
to determine whether the rule is satisfied (e.g., "URI follows the required path
structure"); and (2) the **severity** — how a failure is treated. The standard itself
must not contain a compliance checklist; all evaluation assertions belong in the policy.

Severity has three levels:
- **Blocking** — the violation must be fixed before the PR is approved
- **Advisory** — findings accumulate; the PR is blocked only when the count exceeds a
  configurable threshold set in the policy. Below the threshold, findings are surfaced
  but do not block. This enables quality enforcement at scale: a single style divergence
  is tolerated, but fifty is not.
- **Informational** — surfaced in the review report and never blocks, regardless of count

The default policy is authored by the IC codeowners who own the standard, as a
required output of the same workshop that produces the standard. The default policy
is the organizational baseline.

Projects may override the default severity for specific rules via a single
repository-level policy file. This file lists only the deviations from the default;
rules with no override entry inherit the default. Repository-level override is the
supported scope for v1.

### BR-6: Coverage Gaps in the Standards Library Must Be Visible and Trackable

The current state of the standards library is partially known: some areas are
comprehensive, others are empty stubs, and the gaps are not systematically tracked.
A consumer looking for the security standard or the PostgreSQL schema standard will
find a stub with no content and no indication of when content will arrive.

The coverage state of the standards library — what exists, what is a draft, what is
a stub, what is absent — must be visible in a single place. Gap tracking must be
maintained as standards are added or updated.

### BR-9: Changes to Published Standards Must Be AI-Reviewed Before Merge

The standards library is itself a critical artifact — it is the specification that
`forge:review` uses to evaluate every code PR across the organisation. A poorly-formed
standard, an incorrect version bump, or a standard whose companion policy is now stale
propagates silently into every review run until someone notices. The current process
provides no gate; a standards change merges if a human approves it, with no automated
check that the change is structurally correct or that the version communicates the right
signal to downstream consumers.

Every pull request that modifies a standards artifact — a standard, language guide, or
enforcement policy — must be reviewed by an AI skill before it can merge. The review
must check at minimum:

- **Version bump correctness**: has the version been incremented appropriately for the
  scope of the change (rules added → MINOR, rules removed or changed → MAJOR, all else
  → PATCH)?
- **Template compliance**: does the artifact still conform to the current template
  structure and pass the quality checklist?
- **Policy-standard consistency**: if the standard changed, does the companion
  enforcement policy still have a row for every current rule, and no row for rules that
  no longer exist?
- **Conciseness**: does the artifact remain within its size limits?

Human approval is always a valid merge path — the AI signal is advisory, not a veto.
A human reviewer who understands the context can override a finding. The requirement
is that the AI check runs and its output is visible before a human approves.

### BR-10: Standards and Skill Artifacts Must Be Screened for Prompt Injection Before Merge

Standards documents, language guides, enforcement policies, and skill definitions
(`SKILL.md` files) are injected directly into AI coding agents as context before
code generation and review. A malicious actor who can introduce content into these
artifacts — via a compromised PR, a supply chain attack, or a social engineering
attempt — can direct agents to produce harmful code, exfiltrate source code, bypass
security checks, or behave contrary to the engineer's intent. The attack surface is
large: every developer who uses a `forge:build-*` or `rr-standards:*` skill is
affected until the injection is detected and reverted.

Every pull request that modifies a standards artifact, skill definition, internal
agent reference file, hook script, or template must be screened for malicious
content before it can merge. The screening must cover the full attack surface
of content that reaches AI coding agents:

**Prompt injection targets** (standards, language guides, AGENTS.md, SKILL.md,
internal agent reference files, templates):
- Classic prompt injection patterns that attempt to override or supersede agent instructions
- Hidden Unicode characters that conceal instructions from human reviewers but are
  parsed by AI models (zero-width spaces, bidirectional control characters, homoglyphs)
- Instruction override patterns that attempt to redefine the agent's role or goal mid-context
- Obfuscated content (encoding, unusual character substitution) that may bypass
  naive pattern matching
- Exfiltration-oriented instructions that direct agents to access resources outside
  the standards scope (files, environment variables, credentials, network)

**Shell execution targets** (hook scripts in `.claude/hooks/`):
- Network exfiltration via `curl`/`wget` at hook runtime
- Credential access (SSH keys, AWS secrets, token environment variables)
- File exfiltration (writing repo content to `/tmp` or external pipes)
- Obfuscated execution (`eval`, base64-decoded commands)

Findings from the security screen are **blocking** — a PR containing a confirmed
injection pattern cannot merge automatically. Human approval is always a valid merge
path; the human reviewer must see the finding and understand the risk before
approving. The security screen is the only gate that applies to skill definitions
(`SKILL.md` files), which are otherwise outside the standards taxonomy review scope.

### BR-11: Standards and Language Guides Must Be Behaviorally Validated, Not Just Structurally Correct

A standard or language guide that passes structural checks — correct sections, R-N
identifiers, binary checklist items — may still fail in practice if its rules are too
ambiguous for consistent interpretation, its examples leave non-obvious rules unclear,
or its compliance checklist items cannot be applied uniformly to diverse artifacts.

Structural validation (BR-3, BR-4) is a necessary prerequisite but is not sufficient.
A published standard or language guide must also demonstrate measurable behavioral
effectiveness:

- **Evaluation accuracy**: given a set of canonical compliant and non-compliant artifact
  examples, an LLM applying only the standard (or guide) should correctly classify them
  at or above a defined accuracy threshold
- **Generation lift**: an LLM generating an artifact with the standard (or guide) as
  context should produce a compliant result measurably more reliably than without it
- **Rule consistency**: for rules whose interpretation is non-obvious, the standard must
  produce consistent LLM classifications across repeated evaluation runs

Behavioral validation is the standard-authoring equivalent of the skill-creator eval
loop: the artifact under test is the standard or guide itself, and the metric is whether
it makes the LLM more correct and consistent when applied. A standard that increases LLM
classification accuracy by fewer than 20 percentage points over the unguided baseline is
a candidate for rule clarification or additional examples before publication.

Behavioral validation is a **separate workflow** from structural validation. It is
invoked as `rr-standards:test` — a dedicated skill — not as a flag on
`rr-standards:validate`. This separation reflects the different cadences: structural
validation is a lightweight gate run on every authoring session; behavioral testing is
a heavier measurement exercise run when the author wants to confirm a standard's
effectiveness, or before publication.

The behavioral validation mechanism must:

1. Support a canonical **test cases** format — a set of compliant and non-compliant
   artifact examples stored alongside the standard or guide — that provides ground truth
   for accuracy measurement
2. **Auto-generate initial examples** when none exist, so authors can start measuring
   immediately without manually writing a test harness
3. Apply a **train/test split** to prevent rule authors from inadvertently overfitting
   standard text to specific test cases
4. Identify **which specific rules** had the most classification failures, giving authors
   a targeted signal for improvement
5. Support an optional **iterative improvement loop** — using LLM extended thinking to
   suggest rule clarifications — re-measuring after each iteration to confirm improvement
6. Present `with_<ctx>` and `without_<ctx>` LLM outputs **side-by-side** in a browser
   review UI so authors can compare outputs without switching pages
7. **Auto-save feedback** from the review UI to the workspace — no manual file handling
   required from the author

### BR-13: Behavioral Test Results Must Be Reproducible, Unbiased, and Fast Enough to Support Iteration

Test results must be **reproducible and auditable**: the same standard and test cases
must produce the same result regardless of session state, prior conversation context,
or how many other operations the author has performed. A result that cannot be
reproduced cannot be trusted as a quality signal, and an author cannot know whether
an improvement to the standard caused the result to change or whether the session
context did.

Test suite execution must **not degrade as the number of test cases grows**: authors
must receive feedback quickly enough to act on it in a single working session. A test
suite that takes minutes per test case is not usable as an iterative authoring tool.
A failure in one test case must not prevent other test cases from running.

Accuracy measurements must be **unbiased**: the deployable that evaluates whether a
standard is satisfied must not have access to the expected outcome before producing
its verdict. A measurement methodology that allows the evaluator to see expected
outcomes before reasoning inflates accuracy scores and does not reflect the standard's
actual effectiveness.

Authors must be able to **iterate across multiple improvement cycles** without
re-running test evaluations whose inputs have not changed. When an author revises a
rule and re-runs the test suite, only the affected evaluations should be re-executed;
prior results must remain available for comparison.

The skill must support a **non-interactive CI mode**: a single run that emits a
machine-readable summary and signals failure when the accuracy threshold is not met,
so it can be used as a gate in automated pipelines without human interaction.

### BR-12: Standards and Language Guides Must Be Scoped to a Single Concern

A standard or language guide that covers too many independent concerns produces a
compliance checklist too long to apply reliably, rules that change for unrelated
reasons, and a document that cannot be fully read and internalized in a single sitting.
These are the same failure modes as the existing `standards/api/rest.md` (1,257 lines):
comprehensive as a reference, but not actionable as a standard.

Before any new standard or language guide is authored, the domain must be assessed for
scope. Three signals indicate a domain is too broad for a single artifact:

1. **Rule count**: enumerating the domain's rules produces more than ~10 items — the
   upper limit of a compliance checklist a reviewer can hold in mind at once.
2. **Independent clusters**: the rules group into 3 or more clusters that have different
   codeowners, change at different rates, or apply to different artifact types.
3. **Rule depth**: one or more rules require more than 3 sentences to specify without
   ambiguity, indicating the rule is covering multiple sub-rules.

When any signal is present, the domain must be decomposed into focused sub-artifacts,
each within its applicable size limit (300 lines for a standard, 500 lines for a
language guide) and covering a single coherent cluster of rules. The correct response
to a complex domain is decomposition, not compression. Compressing guidance to fit the
limit — by omitting rationale, collapsing nuance, or removing examples for non-obvious
rules — defeats the purpose of the artifact and will cause `rr-standards:test`
behavioral validation to fail (the standard will not measurably improve LLM accuracy
over baseline because the compressed rules are too thin to be actionable).

The `rr-standards:author` skill must perform this assessment before any file is created,
and must guide the author to a decomposition plan when the signals are present.

---

Success criteria: [success-criteria.md](success-criteria.md)
- [ ] **DEFERRED** The test skill reports which rules had the most classification failures,
      giving authors a targeted signal for improving ambiguous rules — the improvement loop
      surfaces R-N feedback but the standalone accuracy summary does not list top failing rules;
      deferred to a future patch of `rr-standards:test`
- [x] The test skill supports an `--iterations N` flag that runs an iterative
      improvement loop using LLM extended thinking to suggest rule clarifications,
      re-measuring accuracy after each iteration
- [x] The test skill presents with/without outputs side-by-side in a browser UI;
      feedback auto-saves to the workspace when the author submits
