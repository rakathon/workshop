# Success Criteria — Coding Guidelines, Standards, and Guides

- [ ] A documented artifact taxonomy exists, covering all current artifact types in
      `standards/` and `languages/`, with required sections defined for each
- [ ] A template exists for each artifact type; a new author can produce a
      correctly-structured draft by following the template alone
- [ ] Quality criteria are defined for each artifact type; every existing standard
      can be evaluated against them to produce a pass/fail + gap list
- [ ] A `forge:create-standard` or equivalent skill exists that scaffolds a new
      standard from the template, guided through required sections
- [ ] A `forge:validate-standard` or equivalent skill exists that checks a draft
      against quality criteria and produces an actionable gap report
- [ ] The coverage state of the standards library is documented in a single reference
      (what exists, what is draft, what is stub, what is absent)
- [ ] Every standard in the library, when evaluated against the quality criteria,
      either passes or has a tracked gap item
- [ ] A file-type to standard mapping exists for all supported languages and
      standard categories; the mapping is maintained as new standards are added
- [ ] All build skills (`forge:build-api`, `forge:build-repo`, `forge:build-messaging`)
      load the relevant standard and language guide before generating any source file;
      this is verifiable by inspection of the skill definitions
- [ ] Every published standard has a companion enforcement policy file with a severity
      assigned to each rule; the policy is authored by the standard's IC codeowners
- [ ] `forge:review` loads the companion policy (and project override if present) at
      review time and applies severity to determine blocking vs. informational findings
- [ ] A project-level override mechanism exists and is documented; projects with no
      overrides require no configuration
- [ ] Every PR to `rr-standards` that modifies a standard, language guide, or
      enforcement policy triggers an automated AI review; the review result is posted
      as a PR comment before a human approves the change
- [ ] Every PR to `rr-standards` that modifies a standards artifact or skill
      definition is screened for prompt injection, hidden Unicode, instruction
      override, obfuscation, and exfiltration patterns; security findings are
      blocking and visible before a human approves the change
- [ ] `rr-standards:validate` scope is limited to structural quality checks; it does
      not perform behavioral testing
- [ ] `rr-standards:test` exists as a separate skill that runs behavioral validation
      for language-agnostic standards and language guides
- [ ] A canonical test cases format is defined and documented; examples can be
      auto-generated when a standard or guide has no existing test file
- [ ] The test skill runs evaluations without consuming the current session's context
      window, and executes all test cases concurrently so that execution time does not
      grow linearly with test count
