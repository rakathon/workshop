# PreToolUse Hook Design — Standards Injection

---

## Purpose

Inject the relevant language guide into the agent's context before any Write or
Edit tool call. This ensures standards are present before the first line of code
is generated, regardless of whether the session was initiated via a `forge:` build
skill or a direct engineer prompt.

The hook handles **language detection** only — it maps file extension to language
guide. **Category detection** (e.g., "this is an API handler, load the REST
standard") is semantic reasoning handled by the agent, not the hook.

---

## Hook Properties

| Property | Value |
|----------|-------|
| Type | PreToolUse |
| Triggers on | `Write`, `Edit` tool calls |
| Script path | `.claude/hooks/inject-generation-standards.sh` |
| Language | bash |

---

## Logic

```
1. Extract target file path from tool call parameters (the `path` field)
2. Get the file extension from the path
3. Look up the extension in the embedded language mapping (case statement)
4. If a language match is found:
   a. Resolve: languages/<lang>/AGENTS.md
   b. If the file exists: read its content
   c. Output a context injection block (see format below)
5. If no match, or if the AGENTS.md file does not exist:
   a. Output an informational note: "No standard found for [ext] — proceeding without injection"
   b. Do not block the tool call
```

The hook must never block or error a Write/Edit due to a standards lookup failure.
Standards injection is best-effort; a lookup failure is not a reason to prevent
code generation.

---

## Language Mapping (embedded in hook — no separate file)

| Extension(s) | Language | Standards path |
|-------------|----------|----------------|
| `.go` | go | `languages/go/AGENTS.md` |
| `.java` | java | `languages/java/AGENTS.md` |
| `.kt`, `.kts` | kotlin | `languages/kotlin/AGENTS.md` |
| `.swift` | swift | `languages/swift/AGENTS.md` |
| `.ts`, `.tsx` | typescript | `languages/typescript/AGENTS.md` |
| `.js`, `.jsx` | typescript | `languages/typescript/AGENTS.md` |
| `.py` | python | `languages/python/AGENTS.md` |
| `.sql` | sql | `languages/sql/AGENTS.md` |

Test files (e.g., `*_test.go`, `*Test.java`) map to the same language as their
source counterparts — the same AGENTS.md applies.

The mapping is a `case` statement in the shell script. No external mapping file.
Adding a new language requires updating the script and deploying via `forge:update`.

---

## Injection Format

The hook outputs a block that Claude Code prepends as a system message before the
tool call:

```
[STANDARDS CONTEXT — injected by inject-generation-standards.sh]
Target file: <path>
Language: <language>

<contents of languages/<lang>/AGENTS.md>

[END STANDARDS CONTEXT]
```

---

## Degradation Behaviour

| Condition | Behaviour |
|-----------|-----------|
| Extension not in mapping | Informational note; proceed |
| AGENTS.md not found at expected path | Informational note; proceed |
| Hook script errors (any reason) | Fail gracefully; do not block Write/Edit |

---

## Maintenance

When a new language is added to `rr-standards`:
1. Create `languages/<lang>/AGENTS.md` and ensure it passes the AGENTS.md quality checklist
2. Add the file extension(s) to the `case` statement in the hook script
3. Deploy the updated hook via `forge:update`

A language guide added without updating the hook will not be injected automatically.
Build skills for that language must declare the guide explicitly in their `SKILL.md`
(per TR-6.3) until the hook is updated.
