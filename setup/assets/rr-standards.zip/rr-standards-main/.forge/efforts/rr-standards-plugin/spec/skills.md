# Skills Design — rr-standards-plugin

> **rr-standards plugin skills** — The skills in this document belong to the
> `rr-standards` plugin (prefix: `rr-standards:`), not the Forge plugin. They are
> distributed from the `plugins/rr-standards/` directory of this marketplace repository
> and are designed specifically for the rr-standards taxonomy. They have no value in
> a typical effort repository that consumes standards rather than authoring them.

Five skills implement the authoring and validation workflow for the standards library.
This document defines the workflow for each. Skill text (`SKILL.md` files) is
authored during implementation.

---

## rr-standards:author

**Agent type:** Orchestrator (interactive — iterates with the engineer)
**Trigger:** Manual invocation by a standards author

**Input:** None required at invocation; the skill prompts for all decisions.

**Workflow:**
1. Prompt: artifact type — standard / language guide / enforcement policy / AGENTS.md
2. **If artifact type is "standard or language guide" and mode is create:** run Domain
   Scope Assessment before naming any files (see § Domain Scope Assessment below).
3. Prompt: category or language, and artifact name (or names, if the assessment
   produced a decomposition plan)
4. Derive the target file path from the taxonomy location patterns (`TAXONOMY.md`)
5. If the file does not exist (**create** mode):
   - Copy the appropriate template to the target path
   - Proceed to step 6
5. If the file already exists (**update** mode):
   - Display the existing file content; confirm intent (update existing / bail)
   - If confirmed: open the existing file for editing — do not re-copy the template
   - Proceed to step 6
6. Ask the user whether they want to be walked through the process of authoring the standard or want to do it manually:
   - If they want a walk through proceed to step 7
   - If they want to author manually then stop
7. Walk the author through each required section in sequence:
   - Display the section heading and its authoring guidance
   - Show existing content for that section (if any) and prompt for changes, or offer "skip"
   - Skipped sections with no existing content receive a
     `<!-- TODO: [section name] — not yet authored -->` placeholder
8. After all sections: spawn `rr-standards:validate` as a worker via the Task tool,
   passing the artifact file path; receive and display the returned report inline
9. If blocking gaps remain: list them; prompt the author to address before continuing
10. If only informational findings (or none): offer to finish

**Output:** Artifact file (or files, for decomposed domains) at the correct taxonomy
path(s), created or updated with author content.

**Error handling:**
- File already exists in create mode → switch to update mode; confirm before proceeding
- Author skips required section with no existing content → insert TODO comment; flag as
  blocking gap in validation
- Template not found → fail with message pointing to `templates/`

### Domain Scope Assessment

Triggered when creating a new standard or language guide (not an update, not an
enforcement policy, not an AGENTS.md). Runs before any file is named or created.

**Step A — Enumerate candidate rules:**
Ask: "Describe the domain this artifact will govern. What behaviors or structures must
every implementation satisfy?" Work with the author to produce a flat list of candidate
rules. Do not write the rule text — just name what each rule covers (e.g., "URI
versioning format", "JWT validation on member endpoints", "timestamp encoding").

**Step B — Count and cluster:**
Count the candidates. Group them into natural clusters by asking: "Which of these rules
would be reviewed by the same person? Which would change together when the platform
evolves?" Name each cluster.

**Step C — Apply the split signals** (from `standards/TAXONOMY.md § Domain Scope
Assessment`). Present findings:

> "This domain has N candidate rules across K clusters. The signals indicate: [rule count
> exceeds 10 / clusters are independently owned / one or more rules require deep
> specification]. I recommend splitting into K focused artifacts: [name each with its
> cluster of rules]. Each would fit comfortably within its size limit with full depth."

If no signals are present, confirm single-file scope and proceed to the main workflow.

**Step D — Author confirms decomposition plan:**
If splitting, get explicit agreement on: (a) the sub-artifact names and paths, and (b)
the rule-to-sub-artifact assignments. Then run the main authoring workflow for each
sub-artifact in sequence, starting with an AGENTS.md for the shared directory.

When creating multiple sub-artifacts: each is authored, validated, and finalized before
moving to the next. Cross-reference links between sub-artifacts are added to each
Related section after all are created.

---

## rr-standards:validate

**Agent type:** Worker (non-interactive)
**Trigger:** Invoked by `rr-standards:author` after authoring, directly by an author,
or by a CI step

**Input:**
- `<file-path>` — path to the artifact file or directory to validate (required)
- `--ci` flag — switches to CI output mode (see Output below)

**Invocation modes:**

| Mode | How invoked | Output format |
|------|-------------|---------------|
| Interactive | `rr-standards:author` delegation, or author running without `--ci` | Human-readable inline report |
| CI | Any invocation with `--ci` flag | Machine-readable JSON to stdout (review output schema) |

**Workflow:**
1. Receive file path and mode flag
2. Detect artifact type by applying the ordered rules from `standards/TAXONOMY.md §
   Artifact Type Identification` — filename checks before path-prefix checks. Do not
   re-state the rules inline; load them from TAXONOMY.md at validation time so the skill
   stays in sync as the taxonomy evolves.
3. Load the corresponding quality checklist (from TR-3)
4. For each checklist item: evaluate against file content; record pass / fail
5. For each failing item: record the check, the evidence (what was found or missing),
   and a concrete suggested fix
6. Emit output in the format for the current mode (see Output below)

**Blocking vs. informational in validation:**
- Blocking: missing required section, no rule identifiers, file exceeds size limit,
  broken links, severity values not in allowed set, missing or empty Assertion column in policy rows
- Informational: placeholder variable names in examples, sparse Related section

**Stable check IDs** (join keys for trend queries — never renamed or reused):

| `check_id` | Applies to | Severity |
|------------|------------|----------|
| `required-sections` | All types | Blocking |
| `rule-identifiers` | Standard | Blocking |
| `size-limit` | All types | Blocking |
| `compliance-checklist` | Standard | Blocking |
| `severity-values` | Policy | Blocking |
| `policy-completeness` | Policy | Blocking |
| `implements-declaration` | Language guide | Blocking |
| `related-standard-link` | Language guide | Blocking |
| `file-index-complete` | AGENTS.md | Blocking |
| `links` | All types | Blocking |
| `rule-quality` | Standard | Informational |
| `examples-quality` | Standard, language guide | Informational |
| `metadata` | Standard | Informational |
| `no-rule-text` | Policy | Blocking |
| `no-rule-restatement` | Language guide | Informational |
| `entry-length` | AGENTS.md | Informational |

**Output:**

*Interactive mode* — human-readable inline report:
- Summary line: PASS or FAIL with counts
- Blocking gaps grouped under a "Must fix" heading, each with the check name,
  what was found, and a suggested fix
- Informational findings grouped under a "Should fix" heading
- Concludes with a prompt when invoked from `rr-standards:author`

*CI mode (`--ci`)* — machine-readable JSON to stdout conforming to the shared review
output schema (`.forge/efforts/forge-plugin/spec/review-output-schema.md`), using
`target.type: "file"` (see schema for the file target shape). Exit code 1 on FAIL
or ERROR; exit code 0 on PASS.

---

## rr-standards:test

**Agent type:** Worker (non-interactive)
**Trigger:** Manual invocation by a standards author; run after structural validation
passes and the author wants to confirm behavioral effectiveness before publication

**Input:**
- `<file-path>` — path to a standard or language guide file, or a directory (required)
- `--ci` — machine-readable JSON output; suppresses the test viewer and ignores
  `--iterations`; runs the harness once and exits; exit code 1 on FAIL
- `--iterations N` — number of iterative improvement cycles to run (default: 1;
  ignored when `--ci` is passed)
- `--clean` — deletes the entire workspace for this standard before starting
  (`rm -rf .rr-standards/validate/workspace/<slug>`); discards all prior iterations,
  benchmarks, and feedback

**Invocation modes:**

| Mode | How invoked | Output format |
|------|-------------|---------------|
| Interactive | Author running without `--ci` | Human-readable summary + test viewer + improvement loop |
| CI | Any invocation with `--ci` | JSON record to stdout; no viewer; single run |

**Purpose:** Measure whether the standard (or guide) makes an LLM more accurate and
consistent at evaluating artifacts — structural correctness alone cannot confirm this.
A standard that passes structural checks but fails behavioral testing is a candidate
for rule clarification or additional examples before publication.

Supported artifact types: language-agnostic standards and language guides only.

**Context variable `<ctx>`:** `standard` for language-agnostic standards; `guide` for
language guides. Subprocess workspace directories are named `with_<ctx>/` and
`without_<ctx>/` accordingly.

**Test file format** (`<artifact-path>.test.yaml`):
YAML is used (not JSON) because `artifact_snippet` values are always multi-line code or
API fragments — literal block scalars (`|`) eliminate escaping.

```yaml
standard_path: plugins/forge/standards/api/rest/contracts.md
standard_version: 1.0.0
generated_at: 2026-03-08
generated_by: auto | author
tests:
- id: ex-1
  name: Short descriptive name for the test viewer header
  expected_verdict: compliant
  artifact_snippet: |
    GET /v1/orders/{id}
    → 200 { "data": {...}, "meta": {...} }
  expectations:
  - The reviewer correctly identifies this snippet as compliant
  - R-3 is cited as satisfied
- id: ex-2
  name: Short descriptive name for the test viewer header
  expected_verdict: non_compliant
  artifact_snippet: |
    GET /v1/order/{id}
    → 200 { "order": {...} }
  expectations:
  - The reviewer correctly identifies this snippet as non_compliant
  - R-3 is cited as violated (collection segment not plural)
  - R-7 is cited as violated (response envelope missing)
```

`artifact_file` references: a test may use `artifact_file: fixtures/<file>` instead of
an inline `artifact_snippet`. The skill resolves these before invoking the harness — the
harness always receives inline `artifact_snippet` values.

For language guide tests: `guide_path` replaces `standard_path` as the primary key;
`standard_path` is retained so R-N identifiers can be resolved.

If no `.test.yaml` exists, the skill auto-generates examples by reasoning from the
artifact's own rules and examples, writes the file, and notes that the author should
curate before treating results as authoritative.

**Workflow:**
1. Locate or auto-generate the `.test.yaml` companion file
2. Resolve all `artifact_file` references (substitute fixture file contents as
   `artifact_snippet` inline values)
3. Invoke `<skill-base-dir>/test-runner/run_tests.py` with the resolved test data,
   standard file path, and workspace path
4. The Python harness runs all evaluations (see Python harness below); the skill waits
   for the harness to complete
5. Launch `test-viewer/generate_review.py` as a background HTTP server; emit the
   results summary and wait for the author to confirm "done reviewing"
6. Read `feedback.json` written by the viewer; propose rule improvements per R-N;
   apply author-accepted changes to the standard file
7. Re-run steps 3–6 for each additional iteration up to `--iterations N`

**Python harness** (`test-runner/run_tests.py`)

The harness is a standalone Python script (stdlib only — no pip packages). It does
not use the Agent tool or any in-context LLM mechanism. All test execution happens
via subprocesses.

**Two-phase evaluation model:** Each test case is evaluated in two distinct phases to
prevent expectation contamination:

- **Phase 1 (blind evaluation):** The subprocess receives the artifact snippet and the
  standard (or guide) — but **not** the test expectations. It produces a verdict
  (`compliant` / `non_compliant`) and free-form reasoning. This ensures the evaluator
  reasons from the standard alone, not from hints in the expected outcomes.
- **Phase 2 (grading pass):** A second subprocess receives the Phase 1 output alongside
  the test expectations. It scores the Phase 1 output against each expectation and
  determines `verdict_correct`. The grading subprocess has **no standard context** —
  it evaluates whether Phase 1 met the expectations, not whether the artifact is
  compliant itself.

This two-phase design means `without_<ctx>` evaluations are also run blind: the
baseline subprocess receives only the artifact snippet (no standard, no expectations)
in Phase 1, then its output is graded in Phase 2 using the same expectations.

Execution model:
- Spawns one `threading.Thread` per test case; all threads launched simultaneously
- Each thread runs two phases for both `with_<ctx>` and `without_<ctx>`, using four
  subprocess invocations total per test (Phase 1 with, Phase 1 without, Phase 2 grade
  with output, Phase 2 grade without output)
- Full Phase 1 evaluation prompts (artifact snippet + standard, no expectations) are
  constructed by the skill and passed to each subprocess via stdin or a temporary file
- `without_<ctx>` subprocess isolation: the Phase 1 prompt contains only the artifact
  snippet — no standard, no expectations, no files; isolation is enforced by the prompt
- Each subprocess writes `outputs/output.md`, `grading.json`, `test_metadata.json`,
  and `prompt.txt` directly to the workspace and returns a compact JSON summary on stdout
- The harness collects summaries, aggregates benchmark results, and writes `benchmark.json`
- One progress line printed per completed test
- Exits non-zero if `test-accuracy` FAIL

`without_<ctx>` result reuse: results from the previous iteration are copied rather than
re-run — the baseline subprocess takes no standard as input, so its output for a given
snippet is deterministic.

**Workspace layout:**
```
.rr-standards/validate/workspace/<slug>/
└── iteration-N/
    ├── feedback.json          ← written by test viewer on submit
    ├── benchmark.json         ← accuracy summary across all tests
    └── <test-id>/
        ├── with_<ctx>/
        │   ├── outputs/output.md    ← Phase 1 evaluator output (verdict + reasoning)
        │   ├── grading.json         ← Phase 2 grading result (verdict_correct, expectation scores)
        │   ├── test_metadata.json   ← test id, name, expected_verdict, artifact_snippet
        │   └── prompt.txt           ← full Phase 1 prompt passed to the subprocess
        └── without_<ctx>/
            ├── outputs/output.md
            ├── grading.json
            ├── test_metadata.json
            └── prompt.txt
```

`prompt.txt` is written by the harness alongside `outputs/output.md`. It contains the
full Phase 1 prompt (including all instructions and the artifact snippet, but not
expectations). The test viewer reads this file to render the "Prompt" section in the
review UI, allowing authors to inspect exactly what context the evaluator received.

`.rr-standards/` is gitignored. The workspace is created automatically; no upfront
directory tree setup is required.

**Stable check IDs:**

| `check_id` | Severity | Description |
|------------|----------|-------------|
| `test-accuracy` | Blocking | `with_accuracy ≥ 0.80` — the standard's own test expectations were met |
| `generation-lift` | Informational | `lift ≥ 0.20` — standard measurably improves over unaided baseline; warning when below threshold but never blocks |

**Pass thresholds:**
- **PASS** if `with_accuracy ≥ 0.80` (test-accuracy PASS)
- **FAIL** (blocking) if `with_accuracy < 0.80`
- `lift < 0.20` produces a `generation-lift` WARNING in output but does not fail the run
- Always include: accuracy table (with/without/lift), top rules by failure rate

**CI output (`--ci`)**

When `--ci` is passed:
- The Python harness runs once; the test viewer is not launched; the improvement loop
  is skipped regardless of `--iterations`
- The skill emits a single JSON record to stdout and exits:

```json
{
  "verdict": {
    "result": "pass",
    "with_accuracy": 1.0,
    "without_accuracy": 0.75,
    "lift": 0.25
  },
  "tests": [
    {
      "test_id": "ex-c1",
      "expected_verdict": "compliant",
      "with_verdict_correct": true,
      "without_verdict_correct": true,
      "with_pass_rate": 1.0,
      "without_pass_rate": 0.8
    },
    {
      "test_id": "ex-nc1",
      "expected_verdict": "non_compliant",
      "with_verdict_correct": true,
      "without_verdict_correct": false,
      "with_pass_rate": 1.0,
      "without_pass_rate": 0.57
    }
  ]
}
```

- `verdict.result`: `"pass"` when `with_accuracy ≥ 0.80`; `"fail"` otherwise
- `verdict.with_accuracy`: fraction of tests where `with_<ctx>` verdict was correct (0.0–1.0)
- `verdict.without_accuracy`: fraction of tests where `without_<ctx>` verdict was correct (0.0–1.0)
- `verdict.lift`: `with_accuracy − without_accuracy`
- `verdict.generation_lift_warning`: `true` when `lift < 0.20`; informational only, does not affect `result`
- `tests[].with_pass_rate` / `tests[].without_pass_rate`: per-test accuracy across repeated runs
  (single-run harnesses emit 1.0 or 0.0; multi-run harnesses average)
- `tests[].with_verdict_correct` / `tests[].without_verdict_correct`: boolean for this run

Exit code 1 if `verdict.result == "fail"`. Exit code 0 on pass.

**Test viewer**

After the harness completes, the skill launches `test-viewer/generate_review.py` as a
background HTTP server. The browser opens automatically to the review UI:

- Each logical test is shown as a single page
- `with_<ctx>` output on the left (green header), `without_<ctx>` on the right (red header)
- One feedback textarea per test covers both sides — not one per run
- Feedback auto-saves to `feedback.json` in the workspace when the author clicks
  "Submit All Reviews" — no file download or manual save step

**Iterative improvement loop**

The improvement loop runs for the number of cycles specified by `--iterations N`
(default: 1).

When feedback is available (`feedback.json` written by the test viewer):

1. Identify the top R-N rules by failure rate from the benchmark
2. For each rule: reason about why the rule is misinterpreted — is it ambiguous, are
   examples missing or insufficient, are checklist items not evaluable?
3. Present specific suggested rewording for each rule; apply only author-accepted changes
4. Re-run the harness with the updated artifact (iteration N+1), passing
   `--previous-workspace` to the viewer so prior feedback is shown alongside new results
5. Track history: `[{iteration, with_accuracy, without_accuracy, lift, rules_changed}]`
6. Repeat up to `--iterations` cycles
7. Report full iteration history; flag if no improvement across all iterations

Exit conditions: `test_accuracy ≥ 0.80 AND lift ≥ 0.20` achieved; iteration limit
reached; no feedback file found (first run); no rule improvements suggested.

**Directory mode**

When `<file-path>` resolves to a directory, the skill:
1. Enumerates all standards and language guides in the directory
2. Loads or auto-generates `.test.yaml` for each in parallel
3. Constructs all evaluation prompts (for all standards) and passes to the harness
4. The harness spawns threads for all tests across all standards simultaneously
5. Writes per-standard benchmark files alongside a combined `benchmark.json`
6. Launches the viewer with the combined workspace

---

## rr-standards:review

**Agent type:** Worker (non-interactive)
**Trigger:** PR gate GitHub Actions workflow (automatic), or manual invocation by an author

**Input:**
- `--base <branch>` — the branch being merged into (the diff base). When omitted,
  auto-detected from `git symbolic-ref refs/remotes/origin/HEAD`. In CI, GitHub
  Actions always passes this explicitly. Locally, developers may omit it or override.
- `--pr <number>` — optional convenience: review an existing PR by number using
  `gh pr diff` instead of computing the diff locally.
- `--ci` — CI output mode (machine-readable JSON); omit for interactive terminal output.

The diff is computed as `git diff <base>...HEAD` (three-dot: changes introduced by
the current branch since diverging from base).

**Workflow:**
1. Parse the diff to identify all changed files
2. Classify each changed file. Apply special-case rules first (in order), then fall
   through to taxonomy rules:
   - `skills/**/SKILL.md` → `skill-definition` (security-reviewer only)
   - `skills/**/references/*.md` → `agent-reference` (security-reviewer only)
   - `templates/*.md` → `template` (security-reviewer only)
   - `.claude/hooks/*.sh` → `hook-script` (hook-reviewer only)
   - Otherwise: apply `standards/TAXONOMY.md § Artifact Type Identification`

   Files that match no rule (e.g., `.forge/`, `scripts/`, `docs/`) are skipped silently.
3. If no classified artifacts were found: emit a single-line note and exit with a
   passing result — the PR gate does not fire for non-artifact
   changes.
4. Spawn agents in a single parallel batch via the Task tool:
   - One `artifact-reviewer` per standards artifact (types: standard, language-guide,
     enforcement-policy, AGENTS.md)
   - One `security-reviewer` per artifact of types: standard, language-guide,
     enforcement-policy, AGENTS.md, skill-definition, agent-reference, template
   - One `hook-reviewer` per artifact of type: hook-script

   Pass each `artifact-reviewer` agent:
   - The artifact file content before the diff (base) and after (HEAD)
   - The diff slice for this artifact only
   - The detected artifact type from step 2
   - The companion policy file path, if any (standards only)
   - Paths of language guides declaring `Implements: <this standard>` (standards only)
5. Wait for all agents to complete. Collect findings[], check records, and
   per-artifact verdicts from artifact-reviewer, security-reviewer, and
   hook-reviewer agents.
6. Spawn confidence-scorer agent with the complete findings set; apply returned scores;
   suppress findings below `confidence_threshold` per the review output schema
   (§ Confidence Scoring).
7. Produce a structured report with one section per changed artifact:
    - Artifact path and detected type
    - Change-type classification with evidence (which rules changed)
    - Version bump verdict (pass / blocking / informational)
    - Quality checklist findings
    - Policy consistency findings, if applicable
    - Guide consistency findings, if applicable
    - Security findings (prompt injection, hidden Unicode, instruction override,
      obfuscation, exfiltration), if any — shown as a dedicated "Security" section
    - Per-artifact verdict: PASS or FAIL (any blocking finding → FAIL)
8. Produce an overall verdict: PASS if all per-artifact verdicts pass; FAIL otherwise

**Stable check IDs** (join keys for trend queries — never renamed or reused):

| `check_id` | Category | Description |
|------------|----------|-------------|
| `quality-checklist` | `quality` | Required sections and structural conformance |
| `version-bump` | `version` | Semver increment matches change type |
| `policy-consistency` | `policy-consistency` | Policy rows match current rule set |
| `guide-staleness` | `guide-staleness` | Language guide Implements: version currency |
| `prompt-injection` | `security` | Injection strings that attempt to nullify prior agent context |
| `hidden-unicode` | `security` | Invisible/control Unicode outside fenced code blocks |
| `instruction-override` | `security` | Patterns that redefine agent role or redirect behaviour |
| `obfuscation` | `security` | Encoded or substituted content concealing instructions |
| `exfiltration` | `security` | Instructions targeting files, env vars, or network outside scope |
| `network-exfiltration` | `hook-security` | curl/wget calls to external URLs in hook scripts |
| `credential-access` | `hook-security` | Reads of SSH/AWS/token credentials in hook scripts |
| `file-exfiltration` | `hook-security` | Writing repo content to /tmp or external pipes in hook scripts |
| `obfuscated-execution` | `hook-security` | eval/base64-decoded commands in hook scripts |

**Blocking vs. informational:**
- Blocking: missing or insufficient version bump, missing required section, missing
  policy rows, stale policy rows, language guide MAJOR-stale when guide is the changed
  artifact, any security check finding with confidence ≥ 70
- Informational: excessive version bump, sparse Related section, guide MINOR-stale,
  guide MAJOR-stale when the standard (not the guide) is the changed artifact,
  missing companion policy file, security check findings with confidence < 70

**Output:**
- Machine-readable record conforming to the shared review output schema:
  `.forge/efforts/forge-plugin/spec/review-output-schema.md`
- Human-readable PR comment rendered from the record (summary always; inline diff
  comments where a finding can be anchored to a specific changed line)
- Overall verdict drives the named required status check for branch protection
- Human approval is always a valid merge path — the status check is a signal, not a veto

**Error conditions** (`verdict.result: "error"` — not a quality failure):
- Diff is unparseable or missing → `invalid-input`
- `standards/TAXONOMY.md` cannot be loaded → `invalid-input`
- AI service unavailable or non-retryable error → `ai-service-unavailable`
- Cost ceiling exceeded → `cost-ceiling-exceeded`

### Internal Agents

`rr-standards:review` is a Tier-2 worker that spawns Tier-3 internal agents in
parallel. These agents have no `SKILL.md` and are not user-invokable.

#### artifact-reviewer

One agent per changed standards artifact; all run in parallel.

**Receives:** artifact file at base, artifact file at HEAD, diff slice for this
artifact, artifact type, companion policy file path (may be absent), language guide
paths declaring `Implements:` for this standard (may be empty).

**Runs the following checks for its single artifact:**

**a. Quality checklist** — evaluate the artifact against the checklist from TR-3 for
its detected type. Loads checklist criteria from `standards/TAXONOMY.md § Required
Sections` directly (same source as `forge:validate-standard`; no delegation to that
skill). Returns findings[] for `check_id: quality-checklist`.

**b. Change-type classification** — examine the diff slice to determine the required
semver increment:

| Evidence in diff | Required increment |
|------------------|--------------------|
| R-N identifier present before, absent after | MAJOR |
| Rule text changed in meaning (semantic judgment) | MAJOR |
| R-N identifier absent before, present after | MINOR or greater |
| No R-N changes; only prose, examples, or formatting | PATCH or greater |

"Changed in meaning" vs. "clarified wording" is a semantic judgment — reason about
whether a rule's intent or scope changed, not just whether words changed. When
uncertain, lean toward the higher increment and note the uncertainty in the finding.

**c. Version bump validation** — compare the declared version before and after:
- Version unchanged when a bump was required → blocking finding
- Version incremented insufficiently → blocking
- Version incremented excessively → informational
- No version declared → blocking finding

Returns findings[] for `check_id: version-bump`.

**d. Policy-standard consistency** (standards with rule changes only):
- Every R-N identifier in the current standard must have exactly one policy row →
  missing rows are blocking
- No policy row may reference an R-N identifier absent from the standard → stale
  rows are blocking
- No companion policy file exists → informational finding
- Skipped (`result: "skipped"`) when the artifact is a language guide, not a standard.

Returns findings[] for `check_id: policy-consistency`.

**e. Guide-standard consistency** (standards only):
- Guide behind by MINOR → informational; note new rule IDs not yet covered
- Guide behind by MAJOR → informational but HIGH PRIORITY; note MAJOR-stale status
  and which rules changed or were removed
- Guide staleness is always informational when the standard is the changed artifact —
  the standard must be mergeable without waiting for guide owners
- When the changed artifact IS a language guide: behind by MINOR → informational;
  behind by MAJOR → blocking (author chose to update; should bring it current)
- Skipped (`result: "skipped"`) when no language guides declare `Implements:` for
  this standard.

Returns findings[] for `check_id: guide-staleness`.

**Returns:** findings[] (all checks combined), one check record per check_id, and a
per-artifact verdict (PASS if no blocking findings; FAIL otherwise).

#### security-reviewer

One agent per changed artifact file (standards artifacts and `SKILL.md` files);
runs in parallel with `artifact-reviewer` agents.

**Scope:** All standards artifact types (standard, language-guide, enforcement-policy,
AGENTS.md) plus skill-definition (`skills/**/SKILL.md`), agent-reference
(`skills/**/references/*.md`), and template (`templates/*.md`) types. Does not
handle hook-script type — that is routed to `hook-reviewer`.

**Scan target:** Full file content at HEAD. Additionally scan the diff slice for
added lines (+) separately (see TR-10.3).

**Runs the following checks:**

**a. Prompt injection** (`check_id: prompt-injection`) — Scan for strings or
semantically equivalent phrasings that attempt to nullify prior context:
"ignore previous instructions", "disregard all", "forget your instructions",
"disregard the above", "new task:", and equivalents. Flag both literal matches
and paraphrased variants where the intent is clear.

**b. Hidden Unicode** (`check_id: hidden-unicode`) — Scan for invisible or
control characters outside fenced code blocks: zero-width spaces (U+200B–U+200D),
right-to-left override (U+202E), bidirectional controls (U+2066–U+2069, U+200F),
and other Unicode with no legitimate use in documentation prose.

**c. Instruction override** (`check_id: instruction-override`) — Scan for patterns
that attempt to redefine agent role or redirect agent behaviour mid-context:
"Your new role is", "From now on you are", "You are now", "Override:", "New system
prompt:", "Act as", and equivalents.

**d. Obfuscation** (`check_id: obfuscation`) — Scan for: base64-encoded strings
>50 chars outside fenced code blocks; HTML entity sequences decoding to
executable-looking text; systematic homoglyph or Cyrillic character substitution
used to disguise instruction keywords.

**e. Exfiltration** (`check_id: exfiltration`) — Scan for instructions to: access
files outside `standards/`, `languages/`, `skills/`, or `templates/`; make HTTP or
network requests; read environment variables, credentials, or system configuration.

**All check IDs are blocking** at confidence ≥ 70. Findings below 70 are
surfaced as informational. Content inside fenced code blocks (` ```...``` `) is
excluded from checks a, b, c, and d — code examples may legitimately demonstrate
attack patterns for defensive purposes.

**Returns:** findings[] for all five check IDs; per-artifact security verdict
(FAIL if any finding is blocking, PASS otherwise).

#### hook-reviewer

One agent per changed hook script (`hook-script` type); runs in parallel with all
other agents.

**Scope:** Files matching `.claude/hooks/*.sh`. Shell code — not AI context — so
the checks are code analysis, not prompt injection detection.

**Runs the following checks:**

**a. Network exfiltration** (`check_id: network-exfiltration`) — Scan for `curl`,
`wget`, `nc`, or `fetch` commands that make outbound network calls at hook runtime
(i.e., not in comments or heredocs used as documentation). URL destinations that
resolve to internal tooling (e.g., GitHub API via `gh`) are expected and should not
be flagged. Flag calls to arbitrary external domains or IP addresses.

**b. Credential access** (`check_id: credential-access`) — Scan for reads of:
`~/.ssh/`, `~/.aws/`, `~/.config/`, any variable whose name contains `SECRET`,
`KEY`, `TOKEN`, or `PASSWORD` (case-insensitive), `$HOME` followed by a path into
a credential directory, or `$(security find-generic-password ...)` (macOS keychain
access). Legitimate hook use of `$GITHUB_TOKEN` passed by the CI environment is
expected — flag reads that reach beyond the CI-provided env into user home directories
or credential stores.

**c. File exfiltration** (`check_id: file-exfiltration`) — Scan for: writing
repository file content (via `cat`, `cp`, redirects, or pipes) to `/tmp`, to a path
outside the repository root, or to a pipe that feeds an outbound network call. Path
traversal patterns (`../` escaping the repo root) are also a finding.

**d. Obfuscated execution** (`check_id: obfuscated-execution`) — Scan for: `eval`
applied to a non-literal string, base64-decoded content passed to a shell interpreter
(`base64 -d | bash`, `base64 -d | sh`), or command substitution (`` `...` `` or
`$(...)`) where the inner command fetches content from a network source.

**All four checks are blocking** at confidence ≥ 70. The code-block exclusion from
`security-reviewer` does not apply (there are no fenced code blocks in shell scripts).
Inline comments (`# ...`) are excluded from all checks. Diff-slice scanning (TR-10.3
pattern) applies: tag findings `in_diff: true` when introduced by the PR.

**Returns:** findings[] for all four check IDs; `per_artifact_security_verdict`
(FAIL if any finding has confidence ≥ 70).

#### confidence-scorer

Receives the complete findings set from all artifact-reviewers. Scores each finding
0–100 using the rubric in the review output schema (§ Confidence Scoring). Returns a
map of `finding_id → confidence_score`.

---

## rr-standards:coverage

**Agent type:** Worker (non-interactive)
**Trigger:** Manual, or from CI; run when a standard is added or updated to keep the map current

**Input:** None; operates on the full repository.

**Workflow:**
1. Walk `standards/` and `languages/` directories
2. Identify all expected artifact locations from the taxonomy
3. For each location, apply the coverage status rules:
   - **Absent**: file does not exist
   - **Stub**: file exists; no required section headings present, or all sections empty
   - **Draft**: file exists; at least one required section has content;
     at least one required section is missing or empty
   - **Complete**: file exists; all required sections present with substantive content
4. For each language guide with status complete or draft, additionally check for staleness:
   - If the guide has no `Implements:` declaration: it is a standalone guide — record the
     status based on section completeness only (no staleness check applies)
   - If the guide has an `Implements:` declaration: read the declared version and the
     current version of the referenced standard file
   - If the standard version has advanced by a MAJOR bump since the guide's declared version:
     record status as **major-stale** (overrides complete/draft — staleness takes precedence)
   - If the referenced standard file does not exist: record as **broken-reference** with a
     note that the standard link is broken
5. Write `standards/COVERAGE.md` with the current state
6. Emit a summary: total artifacts, complete / draft / stub / absent / major-stale counts,
   and the five highest-priority gaps based on program requirements

**Output:** `standards/COVERAGE.md` updated; summary printed to terminal.
