# Implementation Plan: Forge Effort Pointer

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Pointer Infrastructure

- [x] [auto][wave:1] Update `forge:init` SKILL.md — add `EFFORT` entry to `.forge/.gitignore` during repository initialization (TASK-001) <!-- 4b82cf2 -->
- [x] [auto][wave:1] Update `forge:update` SKILL.md — add migration step to append `EFFORT` to `.forge/.gitignore` in repos that don't already have it (TASK-002) <!-- 4b82cf2 -->
- [x] [auto][wave:1] Update `forge:effort` SKILL.md — write `.forge/EFFORT` after branch creation (TASK-003) <!-- 4b82cf2 -->
- [x] [auto][wave:1] Update `forge:resume` SKILL.md — write `.forge/EFFORT` on resume (TASK-004) <!-- 4b82cf2 -->
- [x] [auto][wave:1] Update `forge:pause` SKILL.md — delete `.forge/EFFORT` on pause (TASK-005) <!-- 4b82cf2 -->
- [x] [auto][wave:1] Update `inject-workflow-context.sh` — replace branch-stripping with `.forge/EFFORT` read; degrade silently if absent or stale (TASK-006) <!-- 4b82cf2 -->
- [x] [auto][wave:1] Write `skills/common/effort-resolution.md` — canonical 4-step resolution chain spec, parameterised by skill category (TASK-007) <!-- 4b82cf2 -->

## Wave 2 — Resolution Chain Replacement

- [x] [auto][wave:2] Update `forge:commit` SKILL.md — replace branch-inference with reference to `skills/common/effort-resolution.md`; declare category: effort-optional (TASK-008) <!-- 3c46807 -->
- [x] [auto][wave:2] Update `forge:status` SKILL.md — replace branch-inference with reference to `skills/common/effort-resolution.md`; declare category: display (TASK-009) <!-- 3c46807 -->
- [x] [auto][wave:2] Update `forge:promote` SKILL.md — replace branch-inference with reference to `skills/common/effort-resolution.md`; declare category: effort-required (TASK-010) <!-- 3c46807 -->
- [x] [auto][wave:2] Update `forge:validate` SKILL.md — replace branch-inference with reference to `skills/common/effort-resolution.md`; declare category: effort-required (TASK-011) <!-- 3c46807 -->
- [x] [auto][wave:2] Update `forge:validate-api` SKILL.md — replace branch-inference with reference to `skills/common/effort-resolution.md`; declare category: effort-required (TASK-012) <!-- 3c46807 -->
- [x] [auto][wave:2] Update `forge:validate-messaging` SKILL.md — replace branch-inference with reference to `skills/common/effort-resolution.md`; declare category: effort-required (TASK-013) <!-- 3c46807 -->
- [x] [auto][wave:2] Update `forge:update-plan` SKILL.md — replace branch-inference with reference to `skills/common/effort-resolution.md`; declare category: effort-required (TASK-014) <!-- 3c46807 -->
