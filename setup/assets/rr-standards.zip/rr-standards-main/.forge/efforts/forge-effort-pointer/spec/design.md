# Design Spec — Forge Effort Pointer

---

## Overview

This effort introduces `.forge/EFFORT` — a gitignored, session-local file that holds
the ID of the effort currently being worked on. All skills and hooks that need effort
context read this file first. Branch names are removed from the resolution chain
entirely.

The resolution chain adds a new step — in-session context — that allows Claude to
identify the active effort from files it has already read or written during the
conversation, without prompting the engineer. This removes disruptive prompts from
everyday workflows like `forge:commit`.

---

## New File: `.forge/EFFORT`

```
<effort-id>
```

A single line. Trim whitespace on read. Gitignored via `.forge/.gitignore`.

---

## Effort Resolution Chain

Four steps. Stops at the first step that yields a valid effort ID (directory exists
at `.forge/efforts/<id>`). Not all steps are executed by all skill categories —
see the per-category rules below.

```
Step 1  Explicit argument supplied to the skill?
           → Use it. Verify .forge/efforts/<id>/ exists; error if not.

Step 2  .forge/EFFORT exists and is non-empty?
           → Read the ID.
           → Valid (.forge/efforts/<id>/ exists): use it.
           → Stale (directory missing): delete file silently, continue.

Step 3  In-session context  [Claude skills only — hooks skip]
           Has Claude accessed files under .forge/efforts/<id>/ during this
           conversation? (e.g. read requirements, wrote spec, edited tasks)
           → If yes: use that effort ID. Do not write .forge/EFFORT.
           → If multiple effort directories were accessed: use the most recently
             accessed one.
           → If none: continue.

Step 4  Prompt or degrade  [behaviour varies by skill category]

        Effort-required skills (forge:validate, forge:validate-api,
        forge:validate-messaging, forge:promote, forge:update-plan):
           List efforts from .forge/efforts/README.md:
             in_progress first, then not_started.
           Ask: "Which effort are you working on? (Enter ID or number)"
           Write chosen ID to .forge/EFFORT.

        Effort-optional skills (forge:commit):
           Proceed without effort context. Do not prompt.
           A commit with no associated effort is valid.

        Display skills (forge:status):
           Show the requested output without effort context if none was resolved.
           Then offer: "No active effort set. Would you like to set one? [Y/n]"
           If yes: list active efforts, let engineer choose, write to .forge/EFFORT.
           If no: complete without writing.

        Hooks (inject-workflow-context.sh):
           Steps 1–2 only. If neither resolves, inject no effort context. Silent.
```

---

## Shared Fragment: `skills/common/effort-resolution.md`

The 4-step resolution chain is specified once in a canonical shared fragment at
`skills/common/effort-resolution.md`. Each affected skill's "identify effort"
section is replaced with a single reference to this fragment plus a category
declaration:

```
Resolve the active effort using the standard chain defined in:
  skills/common/effort-resolution.md
Skill category: <effort-required | effort-optional | display>
```

Claude reads the fragment at invocation time and applies the chain with the
category-specific Step 4 behaviour. The chain logic lives in exactly one place —
if the resolution chain changes in the future, only the fragment needs updating.

**Fragment structure:** The fragment documents all four steps in full, with
explicit per-category behaviour at Step 4. It also defines the category taxonomy
so any new skill can declare its category without needing to read multiple existing
skills for reference.

---

## Changes by Component

### `forge:effort` — SKILL.md

After the branch checkout in Step 9.5, add:

```
Write effort_id to .forge/EFFORT (create or overwrite).
Print: "Active effort: <effort_id>"
```

---

### `forge:resume` — SKILL.md

After restoring session state and checking out the branch, add:

```
Write effort_id to .forge/EFFORT (create or overwrite).
Print: "Active effort: <effort_id>"
```

---

### `forge:pause` — SKILL.md

After writing pause state to `.state.json`, add:

```
Delete .forge/EFFORT if it exists.
Print: "Active effort pointer cleared."
```

---

### `forge:commit` — SKILL.md

Replace the existing branch-inference effort identification section with:

```
Resolve the active effort using the standard chain defined in:
  skills/common/effort-resolution.md
Skill category: effort-optional
```

---

### `forge:status` — SKILL.md

Replace the existing branch-inference effort identification section with:

```
Resolve the active effort using the standard chain defined in:
  skills/common/effort-resolution.md
Skill category: display
```

---

### `forge:promote`, `forge:validate`, `forge:validate-api`,
### `forge:validate-messaging`, `forge:update-plan` — SKILL.md

In each skill, replace the existing branch-inference effort identification section
with:

```
Resolve the active effort using the standard chain defined in:
  skills/common/effort-resolution.md
Skill category: effort-required
```

---

### `hooks/session-start/inject-workflow-context.sh`

Remove all branch-prefix stripping and branch-name matching. Replace with:

```bash
current_effort=""
if [ -f ".forge/EFFORT" ]; then
  effort_id=$(cat ".forge/EFFORT" | tr -d '[:space:]')
  if [ -n "$effort_id" ] && [ -d ".forge/efforts/$effort_id" ]; then
    current_effort="$effort_id"
  else
    rm -f ".forge/EFFORT"  # stale pointer, remove silently
  fi
fi
# If current_effort is empty, no effort context is injected this session.
```

---

### `skills/init/SKILL.md`

Add to the gitignore step:

```bash
echo "EFFORT" >> .forge/.gitignore
```

---

### `skills/update/SKILL.md`

Add a migration step: if `.forge/.gitignore` exists but does not contain `EFFORT`,
append it:

```bash
if [ -f ".forge/.gitignore" ] && ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

---

## Backward Compatibility

**Engineers on existing `effort/<id>` branches:** On first use after this change,
Steps 1–2 will not resolve (no `.forge/EFFORT` file yet). Step 3 will resolve if
Claude has worked on that effort in the session; otherwise effort-required skills
prompt once and write the file, effort-optional skills proceed silently.

**Existing `.state.json` files:** No schema changes. This effort touches only
skill/hook behaviour, not the data model.
