# Integration Test: forge:status — Effort Resolution (TASK-009)

Tests that `forge:status` resolves the active effort via the shared
`effort-resolution.md` fragment rather than inline branch-parsing logic.

---

## Scenario 1: `.forge/EFFORT` present

**Setup:**
- `.forge/EFFORT` contains a single effort ID, e.g. `forge-pr`
- The effort has a valid `.forge/efforts/forge-pr/.state.json`

**Invocation:**
```
forge:status
```

**Expected behaviour:**
- The skill reads `.forge/EFFORT` and resolves `effort_id = forge-pr` immediately.
- No git branch inspection is performed.
- No prompt is shown to the engineer asking which effort to use.
- The status report is printed for effort `forge-pr`.

**Pass condition:** Status report displayed without any effort-selection prompt.

---

## Scenario 2: No `.forge/EFFORT`, no in-session context

**Setup:**
- `.forge/EFFORT` does not exist.
- No effort ID is stored in the current session context.
- Multiple efforts are registered in `.forge/efforts/README.md` with mixed statuses
  (some `in_progress`, some `closed`).

**Invocation:**
```
forge:status
```

**Expected behaviour:**
- The skill follows the full resolution chain in `effort-resolution.md`.
- Because no pointer file and no session context resolves to a single effort, the
  skill presents a general summary of all active efforts.
- The skill then offers to set the active effort (e.g. "Would you like to set one
  as active?") so subsequent commands resolve automatically.
- The engineer is not left with an unresolved error — the graceful fallback path
  from `effort-resolution.md` is exercised.

**Pass condition:** General effort summary displayed; offer to set active effort
presented; no hard failure or unhandled "which effort?" prompt that blocks progress.

---

## Verify Checklist

- [ ] Scenario 1: Status report shown for effort resolved from `.forge/EFFORT` without any prompt
- [ ] Scenario 1: No git branch inspection performed
- [ ] Scenario 2: General summary of all efforts shown when no pointer or context exists
- [ ] Scenario 2: Offer to set active effort is presented; engineer can decline without error
- [ ] Scenario 2: If engineer accepts and chooses an effort, `.forge/EFFORT` is written
- [ ] `SKILL.md` references `plugins/forge/skills/common/effort-resolution.md`
- [ ] `SKILL.md` declares `Skill category: display`
- [ ] `SKILL.md` contains no `current branch` or branch-prefix stripping logic

## Structural Verification Script

```bash
skill="plugins/forge/skills/status/SKILL.md"
grep -q "current branch" "$skill"          && echo "FAIL: old branch logic present"  || echo "PASS: branch parsing removed"
grep -q "effort-resolution.md" "$skill"    && echo "PASS: fragment referenced"       || echo "FAIL: fragment missing"
grep -q "display" "$skill"                 && echo "PASS: category declared"         || echo "FAIL: category missing"
```
