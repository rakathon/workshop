# forge:validate-api — Effort Resolution via Shared Fragment

**Task:** TASK-012
**Artifact under test:** `plugins/forge/skills/validate-api/SKILL.md`

---

## Purpose

Verify that `forge:validate-api` delegates effort resolution to the shared fragment
(`plugins/forge/skills/common/effort-resolution.md`) and no longer contains
inline branch-parsing logic. Covers two runtime paths: pointer file present and
no pointer or context available.

---

## Scenario 1: `.forge/EFFORT` present with valid effort

**Setup:**
- `.forge/EFFORT` contains a valid effort ID, e.g. `favorites-api`
- `.forge/efforts/favorites-api/spec/api/` contains at least one `*.yaml` file

**Expected behaviour:**
1. The skill reads `.forge/EFFORT` and resolves `<effort_id>` to `favorites-api`
   without inspecting the current branch name.
2. `<spec_dir>` resolves to `.forge/efforts/favorites-api/spec/api/`.
3. The skill proceeds to Step 1 (locate contract files) and lists the YAML files
   found.

**Pass criterion:** The skill locates `spec/api/*.yaml` under the effort pointed to
by `.forge/EFFORT` and does not prompt the engineer to choose an effort.

---

## Scenario 2: No pointer, no context → prompts engineer to choose effort

**Setup:**
- `.forge/EFFORT` does not exist
- No effort ID was passed as an explicit argument
- No in-session effort context is available
- Multiple efforts exist under `.forge/efforts/`

**Expected behaviour:**
1. The skill follows the standard resolution chain in `effort-resolution.md`.
2. Finding no unambiguous effort, it prompts the engineer to choose from the
   available efforts or reports that no active effort was found.
3. If the engineer cannot or does not choose, the skill stops with:
   `"No active effort found. Cannot locate spec/api/*.yaml."`

**Pass criterion:** The skill does not silently pick an effort at random; it either
prompts the engineer to select or halts with the correct stop message.

---

## Structural Verification Script

Run from the repository root:

```bash
skill="plugins/forge/skills/validate-api/SKILL.md"
grep -q "current branch matches" "$skill" && echo "FAIL: old branch logic present" || echo "PASS: branch parsing removed"
grep -q "effort-resolution.md" "$skill"   && echo "PASS: fragment referenced"      || echo "FAIL: fragment missing"
grep -q "effort-required" "$skill"         && echo "PASS: category declared"        || echo "FAIL: category missing"
grep -q "Cannot locate spec/api" "$skill" && echo "PASS: stop message preserved"   || echo "FAIL: stop message missing"
```

---

## Expected Structural Output

All lines must read `PASS`. Any `FAIL` indicates a regression.

---

## Checklist

- [ ] `SKILL.md` no longer contains `current branch matches` or prefix list logic
- [ ] `SKILL.md` references `plugins/forge/skills/common/effort-resolution.md`
- [ ] `SKILL.md` declares `Skill category: effort-required`
- [ ] Stop message `"No active effort found. Cannot locate spec/api/*.yaml."` is preserved
- [ ] Scenario 1 resolves correctly from `.forge/EFFORT` without branch inspection
- [ ] Scenario 2 prompts or halts with the correct stop message when no effort is resolvable
