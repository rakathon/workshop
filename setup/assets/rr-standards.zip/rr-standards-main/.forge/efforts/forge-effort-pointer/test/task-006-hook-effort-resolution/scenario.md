# Integration Test: Hook Effort Resolution (TASK-006)

Tests for `plugins/forge/hooks/session-start/inject-workflow-context.sh`
effort resolution via `.forge/EFFORT` file, introduced in TASK-006.

## Scenarios

### Scenario 1: `.forge/EFFORT` exists with valid effort ID
**Given:** `.forge/EFFORT` contains a valid effort ID and the matching effort directory exists  
**When:** The hook runs  
**Then:** The hook uses that effort and injects its context into the system message  
**Verify:** Output contains the effort ID from the EFFORT file

### Scenario 2: `.forge/EFFORT` exists with stale ID (no matching directory)
**Given:** `.forge/EFFORT` contains an effort ID that has no corresponding directory under `.forge/efforts/`  
**When:** The hook runs  
**Then:** The hook deletes `.forge/EFFORT` silently and produces no output  
**Verify:** `.forge/EFFORT` no longer exists after the hook runs; no error output; empty output

### Scenario 3: `.forge/EFFORT` absent, multiple in-progress efforts
**Given:** `.forge/EFFORT` does not exist and multiple efforts are listed as `in_progress` in `.forge/efforts/README.md`  
**When:** The hook runs  
**Then:** The hook degrades silently — no effort context is injected, no prompt is emitted  
**Verify:** Output is empty (or minimal); no effort-specific content in the system message

### Scenario 4: `.forge/EFFORT` absent, single in-progress effort
**Given:** `.forge/EFFORT` does not exist and exactly one effort is listed as `in_progress` in `.forge/efforts/README.md`  
**When:** The hook runs  
**Then:** The hook degrades silently — no single-in-progress fallback is applied  
**Verify:** Output is empty; the hook does NOT resolve the single in-progress effort

### Scenario 5: `.forge/EFFORT` contains unsafe content (path traversal)
**Given:** `.forge/EFFORT` contains `../../etc/passwd` or another path-traversal string  
**When:** The hook runs  
**Then:** The hook rejects the content, deletes `.forge/EFFORT` silently, and produces no output  
**Verify:** `.forge/EFFORT` no longer exists; no error output; empty output

## Verify Checklist

- [ ] Scenario 1: output contains the effort ID from `.forge/EFFORT`
- [ ] Scenario 2: `.forge/EFFORT` deleted silently; output empty
- [ ] Scenario 3: output empty when multiple in-progress efforts and no EFFORT file
- [ ] Scenario 4: output empty when single in-progress effort and no EFFORT file (no fallback)
- [ ] Scenario 5: `.forge/EFFORT` deleted silently; output empty for unsafe content

## Test Execution

Run against a temp repo to validate all scenarios:

```bash
HOOK_PATH="$(git rev-parse --show-toplevel)/plugins/forge/hooks/session-start/inject-workflow-context.sh"
REPO=$(mktemp -d)
cd "$REPO"
git init -q
mkdir -p .forge/efforts/my-effort
cat > .forge/efforts/README.md << 'EOF'
# Forge — Work Item Registry
| ID | Title | Type | Tier | Risk | Parent | Phase | Status |
|----|-------|------|------|------|--------|-------|--------|
| my-effort | My Effort | story | full | R3 |  | implementation | in_progress |
EOF
cat > .forge/efforts/my-effort/.state.json << 'EOF'
{"id":"my-effort","title":"My Effort","type":"story","tier":"full","risk":"R3","parentId":null,"currentPhase":"implementation","phases":{"implementation":{"status":"in_progress","completedTasks":[],"remainingTasks":["TASK-001"]}},"childIds":[],"productionBound":true}
EOF
cat > .forge/README.md << 'EOF'
# Forge
EOF

# Scenario 1: EFFORT file present with valid ID
echo "my-effort" > .forge/EFFORT
output=$(bash "$HOOK_PATH" 2>/dev/null)
echo "$output" | grep -q "my-effort" && echo "PASS: Scenario 1 - EFFORT file used" || echo "FAIL: Scenario 1 - effort not found in output"

# Scenario 2: EFFORT file with stale ID
echo "nonexistent-effort" > .forge/EFFORT
output=$(bash "$HOOK_PATH" 2>/dev/null)
[ ! -f ".forge/EFFORT" ] && echo "PASS: Scenario 2 - stale EFFORT deleted" || echo "FAIL: Scenario 2 - stale file not deleted"
[ -z "$output" ] && echo "PASS: Scenario 2 - output empty" || echo "FAIL: Scenario 2 - unexpected output: $output"

# Scenario 3: No EFFORT file, multiple in-progress efforts — hook degrades silently
cat > .forge/efforts/README.md << 'EOF'
# Forge — Work Item Registry
| ID | Title | Type | Tier | Risk | Parent | Phase | Status |
|----|-------|------|------|------|--------|-------|--------|
| my-effort | My Effort | story | full | R3 |  | implementation | in_progress |
| other-effort | Other Effort | story | full | R2 |  | discovery | in_progress |
EOF
mkdir -p .forge/efforts/other-effort
cp .forge/efforts/my-effort/.state.json .forge/efforts/other-effort/.state.json
rm -f .forge/EFFORT
output=$(bash "$HOOK_PATH" 2>/dev/null)
[ -z "$output" ] && echo "PASS: Scenario 3 - silent degradation with multiple efforts" || echo "FAIL: Scenario 3 - unexpected output: $output"

# Scenario 4: No EFFORT file, single in-progress effort — hook must NOT fall back
cat > .forge/efforts/README.md << 'EOF'
# Forge — Work Item Registry
| ID | Title | Type | Tier | Risk | Parent | Phase | Status |
|----|-------|------|------|------|--------|-------|--------|
| my-effort | My Effort | story | full | R3 |  | implementation | in_progress |
EOF
rm -f .forge/EFFORT
output=$(bash "$HOOK_PATH" 2>/dev/null)
[ -z "$output" ] && echo "PASS: Scenario 4 - no single-effort fallback" || echo "FAIL: Scenario 4 - hook incorrectly fell back to single effort: $output"

# Scenario 5: EFFORT file with path-traversal content
printf '../../etc/passwd' > .forge/EFFORT
output=$(bash "$HOOK_PATH" 2>/dev/null)
[ ! -f ".forge/EFFORT" ] && echo "PASS: Scenario 5 - unsafe EFFORT deleted" || echo "FAIL: Scenario 5 - unsafe file not deleted"
[ -z "$output" ] && echo "PASS: Scenario 5 - output empty" || echo "FAIL: Scenario 5 - unexpected output: $output"

cd - > /dev/null && rm -rf "$REPO"
```

## Expected Results

All tests should report PASS.
