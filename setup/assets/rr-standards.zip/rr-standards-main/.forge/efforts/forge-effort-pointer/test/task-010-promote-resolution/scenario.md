# forge:promote — Effort Pointer Resolution — Test Scenario

**Task:** TASK-010
**Skills under test:** `forge:promote`
**Fragment under test:** `plugins/forge/skills/common/effort-resolution.md`

---

## Scenario 1: `.forge/EFFORT` present — promote uses that effort without prompting

### Setup

- Active effort: `payment-refactor` with `.forge/efforts/payment-refactor/.state.json` present and `currentPhase: discovery`
- `.forge/EFFORT` exists and contains `payment-refactor`
- Multiple efforts may exist in `.forge/efforts/README.md` (pointer takes precedence)
- Current branch: any (e.g. `main` or `effort/payment-refactor`)

### Input

**Conversational prompt to Claude:**

> Promote this effort.

### Expected Outcomes

1. `forge:promote` invokes the effort-resolution chain from `effort-resolution.md`.
2. The chain reads `.forge/EFFORT` first and resolves `payment-refactor` immediately.
3. The skill does NOT prompt the engineer to choose an effort.
4. The skill reads `.forge/efforts/payment-refactor/.state.json` and proceeds with advancement.
5. The skill presents the confirmation:
   ```
   Ready to mark discovery as approved and advance to planning? (yes/no)
   ```

### Verify

- [ ] No "which effort?" prompt is shown to the engineer
- [ ] The effort resolved is `payment-refactor` (matches `.forge/EFFORT` contents)
- [ ] The confirmation message names `payment-refactor`
- [ ] `.forge/EFFORT` is not modified during resolution

---

## Scenario 2: No pointer, no in-session context — promote prompts engineer to choose effort, writes `.forge/EFFORT`

### Setup

- Multiple active efforts exist in `.forge/efforts/README.md`:
  - `payment-refactor` (currentPhase: discovery)
  - `user-profile-v2` (currentPhase: planning)
- `.forge/EFFORT` does NOT exist
- No in-session effort context has been established (fresh session, no prior forge:* invocations)
- Current branch: `main` (no effort ID in branch name)

### Input

**Conversational prompt to Claude:**

> Promote this effort.

### Expected Outcomes

1. `forge:promote` invokes the effort-resolution chain from `effort-resolution.md`.
2. The chain finds no `.forge/EFFORT` pointer and no in-session context.
3. Branch name `main` does not resolve to an effort ID.
4. The chain finds multiple active efforts and cannot auto-resolve.
5. The skill asks the engineer to choose:
   ```
   Multiple active efforts found. Which effort do you want to promote?
     1. payment-refactor (discovery)
     2. user-profile-v2 (planning)
   ```
6. Engineer selects `payment-refactor`.
7. The skill writes `payment-refactor` to `.forge/EFFORT` so subsequent invocations resolve without prompting.
8. The skill proceeds with the promotion for `payment-refactor`.

### Verify

- [ ] A prompt listing the active efforts is shown before any promotion step
- [ ] After the engineer selects an effort, `.forge/EFFORT` is created containing `payment-refactor`
- [ ] The confirmation message names `payment-refactor`
- [ ] Subsequent invocations (Scenario 1 conditions) no longer prompt

---

## Scenario Summary

| # | `.forge/EFFORT` | Active efforts | Branch | Expected behavior |
|---|-----------------|----------------|--------|-------------------|
| 1 | present (`payment-refactor`) | one or more | any | Resolves immediately; no prompt; uses pointer |
| 2 | absent | multiple | `main` | Prompts engineer to choose; writes `.forge/EFFORT` after selection |
