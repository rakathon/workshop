# Integration Test Scenario: forge:resume Writes Active Effort Pointer

**Effort:** `my-resumed-effort` (used across sub-scenarios; reset between sub-scenarios)
**Skill under test:** `forge:resume` — Step 7b: Write Active Effort Pointer
**File written:** `.forge/EFFORT`

Each sub-scenario below is independent. Reset `.forge/` between sub-scenarios.

---

## Sub-Scenario A: Stale `.forge/EFFORT` is overwritten with the resumed effort ID

Tests that when a `.forge/EFFORT` file already exists (left over from a prior session
or a different effort), `forge:resume` overwrites it with the ID of the effort being resumed.

### Setup

```bash
mkdir -p .forge/efforts/my-resumed-effort/requirements

cat > .forge/efforts/my-resumed-effort/.state.json << 'EOF'
{
  "id": "my-resumed-effort",
  "pauseState": {
    "activePhase": "implementation",
    "activeTask": "TASK-001",
    "contextSummary": "Implementing the widget endpoint.",
    "lastCompletedStep": "Wrote the handler skeleton.",
    "nextAction": "Add request validation to the handler.",
    "pausedAt": "2026-04-14T18:00:00Z"
  },
  "currentPhase": "implementation",
  "phases": {
    "discovery": { "status": "approved" },
    "planning": { "status": "approved" },
    "implementation": { "status": "in_progress" },
    "verification": { "status": "not_started" },
    "review": { "status": "not_started" }
  },
  "title": "My Resumed Effort",
  "type": "story"
}
EOF

# Simulate a stale EFFORT file from a prior session on a different effort
echo "old-effort" > .forge/EFFORT
```

### A.1 — forge:resume invoked

**Input prompt:**
> "Resume my-resumed-effort."

**Expected: Step 7b fires after clearing pauseState**

After Claude presents the resume summary and clears `pauseState`, it must write
`.forge/EFFORT` before committing. The output must include the line:

```
Active effort: my-resumed-effort
```

**Verification:**

```bash
stored=$(cat .forge/EFFORT | tr -d '[:space:]')
[ "$stored" = "my-resumed-effort" ] && echo "PASS: EFFORT overwritten with resumed effort ID" \
  || echo "FAIL: got '$stored'"
```

Expected output: `PASS: EFFORT overwritten with resumed effort ID`

**Additional checks:**

1. `pauseState` is cleared in `.state.json`:
   ```bash
   jq '.pauseState' .forge/efforts/my-resumed-effort/.state.json
   # Expected: null
   ```

2. Commit created:
   ```bash
   git log --oneline -3 | grep "resume session"
   # Expected: one match — "chore(my-resumed-effort): resume session"
   ```

3. `.forge/EFFORT` is NOT staged or included in the commit (it is gitignored):
   ```bash
   git show --name-only HEAD | grep "EFFORT"
   # Expected: no output
   ```

---

## Sub-Scenario B: No prior `.forge/EFFORT` — file is created from scratch

Tests that `forge:resume` creates `.forge/EFFORT` when no pointer file existed.

### Setup

```bash
mkdir -p .forge/efforts/my-resumed-effort/requirements

cat > .forge/efforts/my-resumed-effort/.state.json << 'EOF'
{
  "id": "my-resumed-effort",
  "pauseState": {
    "activePhase": "discovery",
    "activeTask": null,
    "contextSummary": "Extracting requirements from the PRD.",
    "lastCompletedStep": "Completed BR-1 through BR-4.",
    "nextAction": "Run forge:elaborate to expand BRs into TRs.",
    "pausedAt": "2026-04-15T09:30:00Z"
  },
  "currentPhase": "discovery",
  "phases": {
    "discovery": { "status": "in_progress" },
    "planning": { "status": "not_started" },
    "implementation": { "status": "not_started" },
    "verification": { "status": "not_started" },
    "review": { "status": "not_started" }
  },
  "title": "My Resumed Effort",
  "type": "story"
}
EOF

# Ensure no EFFORT file exists
rm -f .forge/EFFORT
```

### B.1 — forge:resume invoked

**Input prompt:**
> "Pick up where we left off on my-resumed-effort."

**Expected: Step 7b creates `.forge/EFFORT`**

The output must include:

```
Active effort: my-resumed-effort
```

**Verification:**

```bash
[ -f ".forge/EFFORT" ] && echo "PASS: EFFORT created when absent" \
  || echo "FAIL: EFFORT not created"

stored=$(cat .forge/EFFORT | tr -d '[:space:]')
[ "$stored" = "my-resumed-effort" ] && echo "PASS: correct content after create" \
  || echo "FAIL: got '$stored'"
```

Expected output:
```
PASS: EFFORT created when absent
PASS: correct content after create
```

---

## Sub-Scenario C: Output line "Active effort: <id>" is present

Tests that the required print statement appears in Claude's output after Step 7b.

### Setup

Same as Sub-Scenario B.

### C.1 — forge:resume invoked; output checked

**Input prompt:**
> "Resume my-resumed-effort."

**Expected: Output contains the pointer confirmation**

Scan Claude's response for the line:

```
Active effort: my-resumed-effort
```

This line must appear after the resume summary block (after Step 4 output) and
before the "Context restored" confirmation (Step 9). It may appear on a line by
itself or as part of a status block — the exact surrounding text is not mandated,
but the phrase `Active effort: my-resumed-effort` must be present verbatim.

---

## Simulation Script

Run to validate the core write behavior without invoking Claude:

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
mkdir -p .forge

# Simulate: stale EFFORT exists from a previous effort
echo "old-effort" > .forge/EFFORT

# forge:resume writes the correct effort ID
effort_id="my-resumed-effort"
echo "$effort_id" > .forge/EFFORT

stored=$(cat .forge/EFFORT | tr -d '[:space:]')
[ "$stored" = "$effort_id" ] && echo "PASS: EFFORT overwritten with resumed effort ID" \
  || echo "FAIL: got '$stored'"

# Simulate: no EFFORT file existed
rm .forge/EFFORT
echo "$effort_id" > .forge/EFFORT
[ -f ".forge/EFFORT" ] && echo "PASS: EFFORT created when absent" \
  || echo "FAIL: EFFORT not created"

stored=$(cat .forge/EFFORT | tr -d '[:space:]')
[ "$stored" = "$effort_id" ] && echo "PASS: correct content after create" \
  || echo "FAIL: got '$stored'"

cd - && rm -rf "$tmpdir"
```

Expected output:
```
PASS: EFFORT overwritten with resumed effort ID
PASS: EFFORT created when absent
PASS: correct content after create
```
