# Task-011: forge:validate — Effort Resolution via Shared Fragment

Tests that `forge:validate` resolves the active effort using the shared
`effort-resolution.md` chain rather than its own inline branch-parsing logic.

---

## Scenario 1: `.forge/EFFORT` pointer present

**Setup:**
- A `.forge/EFFORT` file exists containing `my-effort`
- `.forge/efforts/my-effort/` is scaffolded with a valid `.state.json`
  (`currentPhase: "discovery"`, `phases.discovery.status: "pending"`) and
  `requirements/business.md`
- No effort ID is passed as an argument
- The current branch is `main` (does not match any effort slug)

**Expected behaviour:**
- `forge:validate` reads `.forge/EFFORT`, resolves `effort_id` as `my-effort`
- ORC-1 proceeds using `.forge/efforts/my-effort/.state.json`
- No prompt is issued asking the engineer to choose an effort

**Pass criterion:** Skill reaches ORC-2 using `my-effort` without any
"which effort?" prompt.

---

## Scenario 2: No pointer, no in-session context — multiple efforts present

**Setup:**
- No `.forge/EFFORT` file exists
- No effort ID has been set in the current session
- `.forge/efforts/` contains two effort directories: `alpha-effort` and `beta-effort`
- The current branch is `main`

**Expected behaviour:**
- `forge:validate` cannot auto-resolve the effort (pointer absent, session
  context absent, multiple candidates)
- The skill lists the available efforts (`alpha-effort`, `beta-effort`) and
  asks the engineer to choose one before proceeding

**Pass criterion:** Skill surfaces a choice prompt listing both efforts and
does not proceed to ORC-1 until the engineer selects one.

---

## Verify Checklist

- [ ] Scenario 1: ORC-1 proceeds using effort from `.forge/EFFORT` without any prompt
- [ ] Scenario 1: No git branch inspection performed
- [ ] Scenario 2: Choice prompt lists all available efforts before ORC-1 is entered
- [ ] `SKILL.md` references `plugins/forge/skills/common/effort-resolution.md`
- [ ] `SKILL.md` declares `Skill category: effort-required`
- [ ] `SKILL.md` contains no `current branch` or branch-prefix stripping logic

## Structural Verification Script

```bash
skill="plugins/forge/skills/validate/SKILL.md"
grep -q "current branch" "$skill"          && echo "FAIL: old branch logic present"  || echo "PASS: branch parsing removed"
grep -q "effort-resolution.md" "$skill"    && echo "PASS: fragment referenced"       || echo "FAIL: fragment missing"
grep -q "effort-required" "$skill"         && echo "PASS: category declared"         || echo "FAIL: category missing"
```
