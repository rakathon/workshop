# forge:init — .forge/.gitignore Creation — Test Scenario

**Task:** TASK-001
**Skill under test:** `forge:init` (Step 6b: Write .forge/.gitignore)

---

## Scenario 1: forge:init creates .forge/.gitignore with EFFORT entry (create mode)

### Setup

- Fresh repository with no `.forge/` directory
- Forge plugin installed

### Input

Run `forge:init` in a clean repository. When prompted for repository type, select
`1` (Source code repository). Accept the default for all other prompts.

To simulate Step 6b in isolation in a temp directory:

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
git init
mkdir -p .forge
# Simulate Step 6b
if [ ! -f ".forge/.gitignore" ]; then
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

### Expected Outcomes

1. `.forge/.gitignore` is created.
2. `.forge/.gitignore` contains exactly the line `EFFORT`.
3. The Step 8 summary lists `.forge/.gitignore` under **Created**.

### Verify

- [ ] `.forge/.gitignore` exists
- [ ] `grep -qx "EFFORT" .forge/.gitignore` exits 0
- [ ] `wc -l < .forge/.gitignore` = `1` (exactly one line)
- [ ] Step 8 summary lists `.forge/.gitignore` under **Created**

---

## Scenario 2: forge:init is idempotent — does not duplicate EFFORT entry (merge mode)

### Setup

- Repository already has `.forge/` initialized (from Scenario 1 or a prior run)
- `.forge/.gitignore` exists and contains `EFFORT`

### Input

Re-run `forge:init` (merge mode is detected automatically because `.forge/` exists).

To simulate Step 6b idempotency in isolation:

```bash
# Precondition: .forge/.gitignore exists with EFFORT
if ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
# Count occurrences
count=$(grep -cx "EFFORT" .forge/.gitignore)
```

### Expected Outcomes

1. `forge:init` completes without error.
2. `.forge/.gitignore` still contains exactly one `EFFORT` line — no duplication.
3. The Step 8 summary lists `.forge/.gitignore` under **Unchanged**.

### Verify

- [ ] `.forge/.gitignore` exists
- [ ] `grep -cx "EFFORT" .forge/.gitignore` = `1` (no duplicate)
- [ ] Step 8 summary lists `.forge/.gitignore` under **Unchanged**

---

## Scenario 3: forge:init appends EFFORT to an existing .forge/.gitignore that lacks it

### Setup

- Repository has `.forge/` and `.forge/.gitignore` already exists but does not contain `EFFORT`
  (e.g. created manually or by an older forge:init version)

```bash
echo "# custom entries" > .forge/.gitignore
echo ".env" >> .forge/.gitignore
```

### Input

Run `forge:init` (merge mode) or simulate Step 6b directly:

```bash
if ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

### Expected Outcomes

1. `EFFORT` is appended to `.forge/.gitignore`.
2. Pre-existing lines in the file are preserved.
3. The Step 8 summary lists `.forge/.gitignore` under **Updated**.

### Verify

- [ ] `grep -qx "EFFORT" .forge/.gitignore` exits 0
- [ ] `grep -q "# custom entries" .forge/.gitignore` exits 0 (prior content preserved)
- [ ] `grep -q ".env" .forge/.gitignore` exits 0 (prior content preserved)
- [ ] `grep -cx "EFFORT" .forge/.gitignore` = `1` (appended exactly once)
- [ ] Step 8 summary lists `.forge/.gitignore` under **Updated**

---

## Simulation Script

Run all three scenarios end-to-end against a temp directory:

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
git init

# Scenario 1: create mode
if [ ! -f ".forge/.gitignore" ]; then
  mkdir -p .forge
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
grep -qx "EFFORT" .forge/.gitignore && echo "PASS: Scenario 1 — EFFORT in .gitignore" || echo "FAIL: Scenario 1 — EFFORT not in .gitignore"

# Scenario 2: idempotency (merge mode)
if ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
count=$(grep -cx "EFFORT" .forge/.gitignore)
[ "$count" -eq 1 ] && echo "PASS: Scenario 2 — idempotent (no duplicate)" || echo "FAIL: Scenario 2 — duplicated entry (count=$count)"

# Scenario 3: append to existing file without EFFORT
echo "# custom" > .forge/.gitignore
echo ".env" >> .forge/.gitignore
if ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
grep -qx "EFFORT" .forge/.gitignore && echo "PASS: Scenario 3 — EFFORT appended" || echo "FAIL: Scenario 3 — EFFORT not appended"
grep -q ".env" .forge/.gitignore && echo "PASS: Scenario 3 — prior content preserved" || echo "FAIL: Scenario 3 — prior content lost"
append_count=$(grep -cx "EFFORT" .forge/.gitignore)
[ "$append_count" -eq 1 ] && echo "PASS: Scenario 3 — appended exactly once" || echo "FAIL: Scenario 3 — appended multiple times (count=$append_count)"

cd - && rm -rf "$tmpdir"
```

---

## Scenario Summary

| # | Starting state | Trigger | Expected .forge/.gitignore outcome | Summary section |
|---|----------------|---------|-------------------------------------|-----------------|
| 1 | No `.forge/` (create mode) | `forge:init` | Created with sole entry `EFFORT` | Created |
| 2 | `.forge/.gitignore` has `EFFORT` (merge mode) | `forge:init` | No change; still exactly one `EFFORT` | Unchanged |
| 3 | `.forge/.gitignore` exists without `EFFORT` | `forge:init` | `EFFORT` appended; prior lines preserved | Updated |
