# Scenario: forge:pause Deletes the Active Effort Pointer

**TASK-005** — pause skill deletes `.forge/EFFORT`
**Reference:** `plugins/forge/skills/pause/SKILL.md` — Step 5b

When `forge:pause` runs it must delete `.forge/EFFORT` to clear the session-local
active effort pointer. An absent file is the canonical "no active effort" state.
An empty file is treated as stale and must never be intentionally created.

---

## Scenario 1 — EFFORT exists before pause: file is deleted

### Setup

```bash
mkdir -p .forge
echo "my-effort" > .forge/EFFORT

# Confirm file is present
[ -f ".forge/EFFORT" ] && echo "SETUP OK: EFFORT present" || echo "SETUP FAIL"
```

### Expected

After `forge:pause` runs, `.forge/EFFORT` no longer exists.

### Verify

```bash
# 1. EFFORT file has been deleted
[ ! -f ".forge/EFFORT" ] && echo "PASS: EFFORT deleted" || echo "FAIL: EFFORT still exists"

# 2. Confirmation message was printed
# (inspect Claude's response / skill output)
# Expected: output contains "Active effort pointer cleared."
```

---

## Scenario 2 — EFFORT does not exist before pause: no error occurs

### Setup

```bash
mkdir -p .forge
rm -f .forge/EFFORT

# Confirm file is absent
[ ! -f ".forge/EFFORT" ] && echo "SETUP OK: EFFORT absent" || echo "SETUP FAIL"
```

### Expected

`forge:pause` runs without error even when `.forge/EFFORT` is already absent.
The `rm -f` flag ensures a missing file is not treated as an error.

### Verify

```bash
# 1. The delete command exits cleanly (exit code 0)
rm -f .forge/EFFORT
exit_code=$?
[ "$exit_code" -eq 0 ] && echo "PASS: no error when EFFORT absent" || echo "FAIL: exit code $exit_code"

# 2. Confirmation message is still printed
# Expected: output contains "Active effort pointer cleared."
```

---

## Scenario 3 — File is deleted, not emptied

### Setup

```bash
mkdir -p .forge
echo "my-effort" > .forge/EFFORT

# Confirm file has content
[ -s ".forge/EFFORT" ] && echo "SETUP OK: EFFORT non-empty" || echo "SETUP FAIL"
```

### Expected

After `forge:pause`, `.forge/EFFORT` is completely gone — not present as an empty file.
The canonical "no active effort" signal is file absence, not empty content.

### Verify

```bash
# 1. File is absent (not merely empty)
rm -f .forge/EFFORT
[ ! -f ".forge/EFFORT" ] && echo "PASS: file deleted (not emptied)" || echo "FAIL: file still present (may be empty)"

# 2. Writing an empty file would be a bug — confirm the rm approach is used
# Expected: the skill uses `rm -f .forge/EFFORT`, NOT `echo "" > .forge/EFFORT`
#           or `truncate -s 0 .forge/EFFORT`
```

---

## Step 5b Ordering Check

### Expected sequence within forge:pause

1. Step 5: `pauseState` written to `.state.json`
2. **Step 5b: `rm -f .forge/EFFORT` executed, "Active effort pointer cleared." printed**
3. Step 6: `.state.json` staged and committed

The EFFORT pointer is deleted after state is persisted but before the git commit, so
that if the commit fails the pointer is still cleared (the engineer's local session
ends either way).

### Verify

```bash
# After pause completes:

# 1. .state.json contains a pauseState block
grep -q "pauseState" .forge/efforts/<id>/.state.json && echo "PASS: pauseState written" || echo "FAIL"

# 2. .forge/EFFORT is absent
[ ! -f ".forge/EFFORT" ] && echo "PASS: EFFORT absent" || echo "FAIL: EFFORT present"

# 3. A commit was made referencing the pause
git log --oneline -1 | grep "pause" && echo "PASS: pause commit present" || echo "FAIL: no pause commit"
```

---

## Shell Simulation (non-interactive verification)

Run the following to verify the core mechanics without invoking the full skill:

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
mkdir -p .forge

# Case 1: EFFORT exists — should be deleted
echo "my-effort" > .forge/EFFORT
rm -f .forge/EFFORT
[ ! -f ".forge/EFFORT" ] && echo "PASS: EFFORT deleted" || echo "FAIL: EFFORT still exists"

# Case 2: EFFORT does not exist — should not error
rm -f .forge/EFFORT
exit_code=$?
[ "$exit_code" -eq 0 ] && echo "PASS: no error when EFFORT absent" || echo "FAIL: exit code $exit_code"

# Case 3: EFFORT must be deleted, not emptied
echo "my-effort" > .forge/EFFORT
rm -f .forge/EFFORT
[ ! -f ".forge/EFFORT" ] && echo "PASS: file deleted (not emptied)" || echo "FAIL: file still present (may be empty)"

cd - && rm -rf "$tmpdir"
```

Expected output:
```
PASS: EFFORT deleted
PASS: no error when EFFORT absent
PASS: file deleted (not emptied)
```
