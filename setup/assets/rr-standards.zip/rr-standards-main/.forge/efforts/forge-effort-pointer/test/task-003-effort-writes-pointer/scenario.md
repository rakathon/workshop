# forge:effort Writes .forge/EFFORT Pointer — Test Scenario

**Task:** TASK-003
**Skill under test:** `forge:effort` (Step 9.5.4)

---

## Scenario 1: forge:effort writes .forge/EFFORT after branch creation

### Setup

- Repository initialized with `forge:init` (`.forge/` directory exists)
- Current branch: `main`
- No prior `.forge/EFFORT` file

### Input

Invoke `forge:effort` and supply:

- **Title:** `Test Effort 123`
- **Derived ID:** `test-effort-123`
- **Type:** task
- **Tier:** lightweight
- **Subtype:** patch

### Expected Outcomes

1. `forge:effort` scaffolds the effort directory and creates the working branch `effort/test-effort-123`.
2. Immediately after confirming the working branch (Step 9.5.3), the skill executes:
   ```bash
   echo "test-effort-123" > .forge/EFFORT
   ```
3. The skill prints: `"Active effort: test-effort-123"`
4. The Step 10 summary includes the line:
   ```
   Active effort:  test-effort-123  (.forge/EFFORT written)
   ```

### Verify

- [ ] `.forge/EFFORT` exists
- [ ] `cat .forge/EFFORT | tr -d '[:space:]'` = `test-effort-123` (trimmed, no extra whitespace)
- [ ] `.forge/EFFORT` contains exactly one line (`wc -l < .forge/EFFORT` ≤ 1)
- [ ] Skill output contains `"Active effort: test-effort-123"` (printed in Step 9.5.4)
- [ ] Step 10 summary contains `Active effort:  test-effort-123  (.forge/EFFORT written)`

---

## Scenario 2: .forge/EFFORT is overwritten when forge:effort is run again

### Setup

- `.forge/EFFORT` already exists from a prior effort (contains `old-effort-id`)
- Repository initialized with `forge:init`
- Current branch: `main`

### Input

Invoke `forge:effort` with a new effort:

- **Title:** `Test Effort 123`
- **Derived ID:** `test-effort-123`
- **Type:** task
- **Tier:** lightweight
- **Subtype:** patch

### Expected Outcomes

1. `forge:effort` completes normally.
2. After Step 9.5.4 runs, `.forge/EFFORT` contains `test-effort-123`, not `old-effort-id`.

### Verify

- [ ] `.forge/EFFORT` exists
- [ ] `cat .forge/EFFORT | tr -d '[:space:]'` = `test-effort-123` (old value overwritten)
- [ ] `.forge/EFFORT` does NOT contain `old-effort-id`

---

## Scenario 3: .forge/EFFORT contains the exact effort ID (no branch prefix)

### Setup

- Repository initialized with `forge:init`
- Current branch: `main`

### Input

Invoke `forge:effort` with:

- **Title:** `My Feature Work`
- **Derived ID:** `my-feature-work`
- **Type:** story
- **Tier:** full
- **Risk:** R3

### Expected Outcomes

1. The working branch created is `effort/my-feature-work`.
2. `.forge/EFFORT` contains `my-feature-work` — just the effort ID, **not** the full branch name.

### Verify

- [ ] `.forge/EFFORT` exists
- [ ] `cat .forge/EFFORT | tr -d '[:space:]'` = `my-feature-work`
- [ ] `.forge/EFFORT` does NOT contain `effort/` prefix
- [ ] `git branch --show-current` = `effort/my-feature-work` (branch uses prefix; file does not)

---

## Manual Verification Script

Run this script to simulate and verify the EFFORT write step in isolation:

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
mkdir -p .forge

effort_id="test-effort-123"
echo "$effort_id" > .forge/EFFORT

# Verify content
stored=$(cat .forge/EFFORT | tr -d '[:space:]')
[ "$stored" = "$effort_id" ] && echo "PASS: EFFORT file contains correct ID" || echo "FAIL: got '$stored', expected '$effort_id'"

# Verify it's a single line
lines=$(wc -l < .forge/EFFORT)
[ "$lines" -le 1 ] && echo "PASS: single line" || echo "FAIL: multiple lines ($lines)"

# Verify overwrite behavior (forge:effort run twice)
echo "other-effort" > .forge/EFFORT
echo "$effort_id" > .forge/EFFORT
stored=$(cat .forge/EFFORT | tr -d '[:space:]')
[ "$stored" = "$effort_id" ] && echo "PASS: overwrite works" || echo "FAIL: overwrite failed, got '$stored'"

cd - && rm -rf "$tmpdir"
```

---

## Scenario Summary

| # | Precondition | Input | Expected result |
|---|--------------|-------|-----------------|
| 1 | No prior `.forge/EFFORT` | New effort `test-effort-123` | `.forge/EFFORT` created with `test-effort-123`; printed in output |
| 2 | `.forge/EFFORT` exists with `old-effort-id` | New effort `test-effort-123` | `.forge/EFFORT` overwritten with `test-effort-123` |
| 3 | No prior `.forge/EFFORT` | New effort `my-feature-work` | `.forge/EFFORT` contains bare ID (no `effort/` prefix) |
