# Integration Test: TASK-014 — update-plan effort resolution

Verifies that `forge:update-plan` resolves the active effort through the shared
`effort-resolution.md` chain rather than inline branch-parsing logic.

---

## Scenario 1: `.forge/EFFORT` pointer present

**Setup:**
- Repository contains at least one effort directory, e.g. `.forge/efforts/my-feature/`.
- `.forge/EFFORT` exists with contents `my-feature`.
- The current branch name does NOT match any effort slug (e.g. `main`).
- `my-feature/.state.json` contains a `phases.implementation` block with at least one
  entry in `remainingTasks`.
- `my-feature/plan/tasks.md` exists with a matching task line.

**Invocation:**
```
forge:update-plan
```

**Expected behaviour:**
1. The skill reads `.forge/EFFORT` and resolves `<effort_id>` = `my-feature`.
2. `<effort_dir>` is set to `.forge/efforts/my-feature/`.
3. `<tasks_file>` resolves to `.forge/efforts/my-feature/plan/tasks.md`.
4. `<state_file>` resolves to `.forge/efforts/my-feature/.state.json`.
5. The skill proceeds to Step 2 without prompting the engineer to choose an effort.

**Pass criteria:**
- No "which effort?" prompt is shown.
- The correct `tasks_file` and `state_file` paths are used.
- The `.forge/EFFORT` pointer is the resolution source (not branch name inspection).

---

## Scenario 2: No pointer, no context — prompt engineer

**Setup:**
- `.forge/EFFORT` does not exist.
- The current branch name does NOT match any effort slug (e.g. branch is `main`).
- `.forge/efforts/README.md` lists two or more efforts in active / implementation phase.

**Invocation:**
```
forge:update-plan
```

**Expected behaviour:**
1. The skill cannot resolve `<effort_id>` automatically.
2. The skill presents the list of active efforts to the engineer and asks which effort
   this task belongs to.
3. After the engineer selects an effort, the skill proceeds normally.

**Pass criteria:**
- The skill does NOT silently pick an effort at random.
- The engineer receives a clear prompt listing the available efforts.
- After selection, the correct `<effort_dir>`, `<tasks_file>`, and `<state_file>` are used.

---

## Verify Checklist

- [ ] Scenario 1: Effort resolved from `.forge/EFFORT` without any prompt
- [ ] Scenario 1: No git branch inspection performed
- [ ] Scenario 1: Correct `tasks_file` and `state_file` paths derived from resolved effort
- [ ] Scenario 2: Engineer receives a list of active efforts and a prompt to choose
- [ ] Scenario 2: Skill does not silently pick an effort at random
- [ ] `SKILL.md` references `plugins/forge/skills/common/effort-resolution.md`
- [ ] `SKILL.md` declares `Skill category: effort-required`
- [ ] `SKILL.md` contains no `current branch` or branch-prefix stripping logic

## Structural Verification Script

```bash
skill="plugins/forge/skills/update-plan/SKILL.md"
grep -q "current branch" "$skill"          && echo "FAIL: old branch logic present"  || echo "PASS: branch parsing removed"
grep -q "effort-resolution.md" "$skill"    && echo "PASS: fragment referenced"       || echo "FAIL: fragment missing"
grep -q "effort-required" "$skill"         && echo "PASS: category declared"         || echo "FAIL: category missing"
```
