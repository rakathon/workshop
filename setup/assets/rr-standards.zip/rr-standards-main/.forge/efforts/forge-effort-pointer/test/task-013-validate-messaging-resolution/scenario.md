# Task-013: validate-messaging Effort Resolution — Integration Scenarios

Tests that `forge:validate-messaging` resolves the active effort using the shared
`effort-resolution.md` chain rather than inline branch-parsing logic.

---

## Scenario 1: `.forge/EFFORT` pointer file present

**Setup:**
- `.forge/EFFORT` contains the string `my-feature`
- `.forge/efforts/my-feature/spec/messaging/` contains at least one `.md` contract file
- No argument is passed to the skill

**Expected behaviour:**
- The skill reads `.forge/EFFORT` and resolves `<effort_dir>` to `.forge/efforts/my-feature`
- The skill loads contracts from `.forge/efforts/my-feature/spec/messaging/*.md`
- Validation proceeds and an inline report is produced
- No prompt to the engineer to supply an effort ID

**Pass criterion:** Validation report appears with `**Effort:** my-feature`; no
"Cannot resolve effort" message is emitted.

---

## Scenario 2: No pointer file and no resolvable context

**Setup:**
- `.forge/EFFORT` does not exist
- `.forge/efforts/` contains more than one effort directory (ambiguous)
- No argument is passed to the skill
- Current git branch does not encode an effort ID

**Expected behaviour:**
- The skill follows the full effort-resolution chain and exhausts all options
- The skill stops with the canonical error message:
  > "Cannot resolve effort. Pass the effort ID as an argument: `forge:validate-messaging <effort-id>`"
- No validation is attempted; no files are written

**Pass criterion:** The exact stop message above is printed; the skill does not
attempt to load any contracts or produce a partial report.

---

## Verify Checklist

- [ ] Scenario 1: Contracts loaded from effort pointed to by `.forge/EFFORT`; no prompt shown
- [ ] Scenario 1: No git branch inspection performed
- [ ] Scenario 2: Canonical stop message printed; no partial validation attempted
- [ ] `SKILL.md` references `plugins/forge/skills/common/effort-resolution.md`
- [ ] `SKILL.md` declares `Skill category: effort-required`
- [ ] `SKILL.md` contains no `current branch` or branch-prefix stripping logic

## Structural Verification Script

```bash
skill="plugins/forge/skills/validate-messaging/SKILL.md"
grep -q "current branch" "$skill"          && echo "FAIL: old branch logic present"  || echo "PASS: branch parsing removed"
grep -q "effort-resolution.md" "$skill"    && echo "PASS: fragment referenced"       || echo "FAIL: fragment missing"
grep -q "effort-required" "$skill"         && echo "PASS: category declared"         || echo "FAIL: category missing"
```
