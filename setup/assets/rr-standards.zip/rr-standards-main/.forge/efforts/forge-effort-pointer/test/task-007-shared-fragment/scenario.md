# Shared Effort-Resolution Fragment — Structural Completeness Test

**Task:** TASK-007
**Artifact under test:** `plugins/forge/skills/common/effort-resolution.md`

---

## Purpose

Verify that the canonical effort-resolution fragment exists and contains all required
sections. This is a documentation/structural completeness test — it does not execute
skill logic, but confirms that the shared fragment is present and structurally sound
so that skill authors can safely reference it.

---

## Verification Script

Run from the repository root:

```bash
fragment="plugins/forge/skills/common/effort-resolution.md"
[ -f "$fragment" ] && echo "PASS: fragment exists" || echo "FAIL: fragment missing"
grep -q "Step 1" "$fragment" && echo "PASS: Step 1 present" || echo "FAIL: Step 1 missing"
grep -q "Step 2" "$fragment" && echo "PASS: Step 2 present" || echo "FAIL: Step 2 missing"
grep -q "Step 3" "$fragment" && echo "PASS: Step 3 present" || echo "FAIL: Step 3 missing"
grep -q "Step 4" "$fragment" && echo "PASS: Step 4 present" || echo "FAIL: Step 4 missing"
grep -q "effort-required" "$fragment" && echo "PASS: effort-required category present" || echo "FAIL: effort-required missing"
grep -q "effort-optional" "$fragment" && echo "PASS: effort-optional category present" || echo "FAIL: effort-optional missing"
grep -q "display" "$fragment" && echo "PASS: display category present" || echo "FAIL: display missing"
grep -q "Stale Pointer" "$fragment" && echo "PASS: stale pointer handling present" || echo "FAIL: stale pointer section missing"
grep -q "\.forge/EFFORT" "$fragment" && echo "PASS: EFFORT file referenced" || echo "FAIL: EFFORT file not referenced"
```

---

## Expected Output

All lines must read `PASS`. Any `FAIL` line indicates a gap in the fragment.

---

## Checklist

- [ ] Fragment file exists at `plugins/forge/skills/common/effort-resolution.md`
- [ ] Step 1 (explicit argument) is documented
- [ ] Step 2 (`.forge/EFFORT` file) is documented with bash snippet
- [ ] Step 3 (in-session context) is documented with Claude-only caveat
- [ ] Step 4 (prompt or degrade) is documented with all four category sub-sections
- [ ] `effort-required` category lists the applicable skills
- [ ] `effort-optional` category lists the applicable skills
- [ ] `display` category lists the applicable skills
- [ ] Hooks category (`inject-workflow-context.sh`) is documented
- [ ] Writing rules for `.forge/EFFORT` are specified per step
- [ ] Stale pointer handling section is present and unambiguous
- [ ] Fragment is self-contained (no external files required to understand it)
