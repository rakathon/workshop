# forge:update — Ensure .forge/.gitignore contains EFFORT — Test Scenario

**Task:** TASK-002 (forge-effort-pointer)
**Skill under test:** `plugins/forge/skills/update/SKILL.md` — Step 9.2

---

## Overview

Step 9.2 of `forge:update` must ensure that `.forge/.gitignore` contains an `EFFORT`
entry so the session-local `.forge/EFFORT` file is never committed. Three cases are
tested:

1. `.forge/.gitignore` does not exist → created with `EFFORT`
2. `.forge/.gitignore` exists but does not contain `EFFORT` → `EFFORT` appended
3. `.forge/.gitignore` already contains `EFFORT` → no change (idempotent)

---

## Invocation Convention

The migration logic is a self-contained shell fragment. Each scenario invokes it
directly in a temporary directory that represents the repository state:

```bash
# Migration logic under test (Step 9.2 of forge:update)
if [ ! -f ".forge/.gitignore" ]; then
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

---

## Scenario 1: .forge/.gitignore does not exist — created with EFFORT

### Setup

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
mkdir -p .forge
# .forge/.gitignore is intentionally absent
```

### Input

Apply the Step 9.2 migration logic:

```bash
if [ ! -f ".forge/.gitignore" ]; then
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

### Expected Outcomes

- `.forge/.gitignore` is created
- The file contains exactly one line: `EFFORT`
- No other files in `.forge/` are modified

### Verify

```bash
grep -qx "EFFORT" .forge/.gitignore && echo "PASS: Case 1 - created" || echo "FAIL: Case 1"
```

- [ ] `.forge/.gitignore` exists
- [ ] `grep -qx "EFFORT" .forge/.gitignore` exits 0
- [ ] `wc -l < .forge/.gitignore` = `1` (exactly one line)

---

## Scenario 2: .forge/.gitignore exists but missing EFFORT — EFFORT appended

### Setup

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
mkdir -p .forge
echo "worktrees/" > .forge/.gitignore
# .forge/.gitignore exists with content but no EFFORT entry
```

### Input

Apply the Step 9.2 migration logic:

```bash
if [ ! -f ".forge/.gitignore" ]; then
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

### Expected Outcomes

- `.forge/.gitignore` retains its original content (`worktrees/`)
- `EFFORT` is appended as a new line
- No other files are modified

### Verify

```bash
grep -qx "EFFORT" .forge/.gitignore && echo "PASS: Case 2 - appended" || echo "FAIL: Case 2"
```

- [ ] `grep -qx "EFFORT" .forge/.gitignore` exits 0
- [ ] `grep -qx "worktrees/" .forge/.gitignore` exits 0 — original content preserved
- [ ] `wc -l < .forge/.gitignore` = `2` (original line + EFFORT)

---

## Scenario 3: .forge/.gitignore already contains EFFORT — no change (idempotent)

### Setup

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"
mkdir -p .forge
echo "EFFORT" > .forge/.gitignore
# .forge/.gitignore already has EFFORT
```

### Input

Apply the Step 9.2 migration logic:

```bash
if [ ! -f ".forge/.gitignore" ]; then
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
```

### Expected Outcomes

- `.forge/.gitignore` is unchanged
- `EFFORT` appears exactly once (not duplicated)
- No other files are modified

### Verify

```bash
count=$(grep -cx "EFFORT" .forge/.gitignore)
[ "$count" -eq 1 ] && echo "PASS: Case 3 - idempotent" || echo "FAIL: Case 3 (count=$count)"
```

- [ ] `grep -cx "EFFORT" .forge/.gitignore` = `1` — exactly one occurrence, not duplicated
- [ ] File content is identical to pre-migration state

---

## Batch Test (All Three Cases)

The following script runs all three scenarios in sequence and reports PASS/FAIL for each:

```bash
tmpdir=$(mktemp -d)
cd "$tmpdir"

# Case 1: no .forge/.gitignore
mkdir -p .forge
if [ ! -f ".forge/.gitignore" ]; then
  echo "EFFORT" > .forge/.gitignore
elif ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
grep -qx "EFFORT" .forge/.gitignore && echo "PASS: Case 1 - created" || echo "FAIL: Case 1"

# Case 2: .forge/.gitignore exists but missing EFFORT
echo "worktrees/" > .forge/.gitignore
if ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
grep -qx "EFFORT" .forge/.gitignore && echo "PASS: Case 2 - appended" || echo "FAIL: Case 2"

# Case 3: idempotent - already has EFFORT
echo "EFFORT" > .forge/.gitignore
if ! grep -qx "EFFORT" ".forge/.gitignore"; then
  echo "EFFORT" >> .forge/.gitignore
fi
count=$(grep -cx "EFFORT" .forge/.gitignore)
[ "$count" -eq 1 ] && echo "PASS: Case 3 - idempotent" || echo "FAIL: Case 3 (count=$count)"

cd - && rm -rf "$tmpdir"
```

---

## Scenario Summary

| # | Initial state of `.forge/.gitignore` | Expected result | Key assertion |
|---|--------------------------------------|-----------------|---------------|
| 1 | Does not exist | Created with `EFFORT` | `grep -qx "EFFORT"` exits 0; file has 1 line |
| 2 | Exists, contains `worktrees/`, no `EFFORT` | `EFFORT` appended | Both `worktrees/` and `EFFORT` present |
| 3 | Exists, already contains `EFFORT` | No change | `EFFORT` appears exactly once |
