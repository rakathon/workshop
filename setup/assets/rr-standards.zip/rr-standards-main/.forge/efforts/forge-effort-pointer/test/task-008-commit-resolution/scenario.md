# Integration Test: TASK-008 — forge:commit Effort Resolution

Validates that forge:commit resolves the active effort via the shared
`effort-resolution.md` chain and handles the effort-optional fallback correctly.

---

## Scenario 1: Effort file present — commit proceeds with effort context

**Setup:**
- `.forge/EFFORT` exists and contains a valid effort ID (e.g., `forge-commit`)
- `.forge/efforts/forge-commit/` directory exists with `plan/tasks.md` and `.state.json`
- One or more files are staged for commit

**Steps:**
1. Invoke `forge:commit`
2. The skill reads `.forge/EFFORT` via the `effort-resolution.md` chain
3. The effort ID `forge-commit` is resolved successfully

**Expected behaviour:**
- `<effort_id>` is set to `forge-commit`
- `<effort_dir>` resolves to `.forge/efforts/forge-commit/`
- Phase sentinel check executes (Step 0 phase check)
- Scope check in Step 2 compares staged files against `plan/tasks.md`
- Step 5 attaches a structured git note referencing the effort
- Step 6 asks whether the commit completes a task before marking done
- No prompt asking the engineer to choose an effort is shown

---

## Scenario 2: No `.forge/EFFORT`, no in-session context — commit proceeds without effort context

**Setup:**
- `.forge/EFFORT` does not exist
- No effort ID has been established in the current session context
- One or more files are staged for commit

**Steps:**
1. Invoke `forge:commit`
2. The skill runs the `effort-resolution.md` chain; all resolution steps return nothing
3. No effort is resolved

**Expected behaviour:**
- The skill continues without effort context — no error, no prompt
- Phase sentinel check is skipped (as documented: "Skip this check if no effort context was resolved")
- Scope check notes that no `<tasks_file>` exists and continues
- Step 5 (git note attachment) is skipped
- Step 6 (task completion) is skipped
- Commit message is proposed and commit is created normally

---

## Verify Checklist

- [ ] Scenario 1: `.forge/EFFORT` is read and effort ID resolved before any commit steps
- [ ] Scenario 1: No "which effort?" prompt is shown to the engineer
- [ ] Scenario 1: Commit includes a structured git note referencing the effort
- [ ] Scenario 2: Commit proceeds without error when no effort context is available
- [ ] Scenario 2: No prompt asking the engineer to choose an effort
- [ ] `SKILL.md` references `plugins/forge/skills/common/effort-resolution.md`
- [ ] `SKILL.md` declares `Skill category: effort-optional`
- [ ] `SKILL.md` contains no `current branch` or branch-prefix stripping logic

## Structural Verification Script

```bash
skill="plugins/forge/skills/commit/SKILL.md"
grep -q "current branch" "$skill"          && echo "FAIL: old branch logic present"  || echo "PASS: branch parsing removed"
grep -q "effort-resolution.md" "$skill"    && echo "PASS: fragment referenced"       || echo "FAIL: fragment missing"
grep -q "effort-optional" "$skill"         && echo "PASS: category declared"         || echo "FAIL: category missing"
```
