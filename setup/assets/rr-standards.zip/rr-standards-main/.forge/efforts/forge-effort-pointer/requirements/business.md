# Business Requirements — Forge Effort Pointer

Parent effort: [forge-plugin](../../forge-plugin/.state.json)

---

### BR-1: Forge Must Reliably Identify the Active Effort Regardless of Branch Naming Convention

Multiple Forge skills depend on knowing which effort the engineer is currently working
on. The current implementation resolves effort identity by stripping known prefixes
(`effort/`, `fix/`, `feat/`, etc.) from the git branch name and matching the remainder
against registered effort IDs. This is fragile: it fails silently when the branch name
does not follow Forge's convention, and it can produce an incorrect match when a branch
slug coincidentally overlaps with an effort ID from another context.

Forge must have a reliable, convention-independent mechanism for identifying the active
effort that does not break when branch naming conventions differ across repositories.

### BR-2: Effort Resolution Must Degrade Gracefully When No Pointer Is Set

When an engineer opens a repository with no active effort pointer, Forge skills must
not fail or produce confusing errors. When no effort can be identified automatically,
the skill must prompt the engineer to choose from the list of active efforts rather
than halting with an error. The chosen effort must be persisted for the remainder
of the session so the engineer is not re-prompted on every command.

### BR-3: The Active Effort Pointer Must Be Local Developer State, Not Shared Repository State

The pointer that identifies which effort a developer is currently working on is personal
to that developer's working session. Two engineers may be working on different efforts
in the same repository at the same time. The active effort pointer must not be
committed to the shared git history — it must be local to each developer's environment
so it does not interfere with other contributors.
