# Technical Requirements — Forge Effort Pointer

Parent effort: [forge-plugin](../../forge-plugin/.state.json)

> Note: Implementation design is captured in `spec/design.md`. This file records
> operational constraints, schema changes, and non-functional requirements not
> derivable from the design alone.

---

## Traceability

| TR | BRs |
|----|-----|
| TR-1 | BR-1, BR-3 |
| TR-2 | BR-1, BR-2 |
| TR-3 | BR-2 |
| TR-4 | BR-1, BR-2 |

---

## TR-1: Active Effort Pointer — `.forge/EFFORT` File

A new file `.forge/EFFORT` must be introduced as the primary mechanism for identifying
the active effort in a developer's session. The file contains a single line: the effort
ID of the effort currently being worked on.

**Format:**
```
forge-effort-pointer
```

**Write semantics:**
- Created (or overwritten) by `forge:effort` immediately after branch creation.
- Created (or overwritten) by `forge:resume` after restoring session state.
- Deleted (not emptied) by `forge:pause` when the session ends. An absent file
  means no active effort; an empty file is not a valid state and must be treated
  as stale on read.
- Created (or overwritten) by effort-required and display skills when an effort is
  chosen at Step 4 of the resolution chain (see TR-2), subject to the write rules
  for that skill's category.

**Read semantics:**
- Read at Step 2 of the resolution chain, before in-session context or prompting.
- If present, non-empty, and the ID matches a directory under `.forge/efforts/`,
  use it without further resolution.
- Treated as stale and deleted silently if any of the following are true:
  - The file is empty or contains only whitespace.
  - The ID does not match any directory under `.forge/efforts/`.
  Resolution continues to the next step after deletion.

## TR-2: Effort Resolution Chain Must Be Branch-Name-Independent

All skills and hooks that need to identify the active effort must follow this chain.
Branch names must not be consulted at any step. The chain has four steps; which
steps are executed depends on the skill category (see below).

1. **Explicit argument** — If the skill was invoked with an effort ID argument, use it.
   Verify `.forge/efforts/<id>/` exists; error if not.

2. **`.forge/EFFORT` file** — If the file exists and contains a valid effort ID, use it.
   If stale (no matching directory), delete the file silently and continue.

3. **In-session context** — If Claude has accessed files under `.forge/efforts/<id>/`
   during this conversation (e.g. reading requirements, writing spec, implementing tasks),
   that effort ID is known from context. Use it without prompting or writing to
   `.forge/EFFORT`. This step is available to all Claude-executed skills; it is not
   available to bash hooks.

4. **Prompt or degrade** — Behaviour at this step is skill-category-dependent:

   - **Effort-required skills** (`forge:validate`, `forge:validate-api`,
     `forge:validate-messaging`, `forge:promote`, `forge:update-plan`):
     The skill cannot operate meaningfully without an effort. Prompt the engineer
     to choose from active efforts. Write the chosen ID to `.forge/EFFORT`.

   - **Effort-optional skills** (`forge:commit`):
     Proceed without effort context. Do not prompt. A commit without an associated
     effort is valid — engineers commit code outside Forge efforts routinely.

   - **Display skills** (`forge:status`):
     If no effort is identified by Steps 1–3, show a summary without effort context,
     then offer: "No active effort set. Would you like to set one? [Y/n]"
     If yes, list active efforts and let the engineer choose. Write to `.forge/EFFORT`
     only if they confirm.

   - **Hooks** (`inject-workflow-context.sh`):
     Execute Steps 1–2 only (no Claude context, no prompting). If neither resolves
     an effort, inject no effort context and continue silently.

This chain must be implemented consistently. No component may extend it with branch
name parsing or other ad-hoc resolution mechanisms.

## TR-3: `.forge/EFFORT` Must Be Gitignored

`.forge/EFFORT` is local developer state. It must not be committed to the repository.
It must be added to `.forge/.gitignore` during `forge:init`. Any repository that
already has a `.forge/` directory without this entry must have it added by `forge:update`.

## TR-4: Affected Components

The following components must be updated to remove branch-name effort inference and
adopt the resolution chain defined in TR-2:

| Component | Category | Change |
|-----------|----------|--------|
| `skills/effort/SKILL.md` | — | Write `.forge/EFFORT` after branch creation |
| `skills/resume/SKILL.md` | — | Write `.forge/EFFORT` on resume |
| `skills/pause/SKILL.md` | — | Delete `.forge/EFFORT` on pause |
| `skills/commit/SKILL.md` | Effort-optional | Apply 4-step chain; do not prompt at Step 4 |
| `skills/status/SKILL.md` | Display | Apply 4-step chain; offer opt-in at Step 4 |
| `skills/promote/SKILL.md` | Effort-required | Apply 4-step chain; prompt at Step 4 |
| `skills/validate/SKILL.md` | Effort-required | Apply 4-step chain; prompt at Step 4 |
| `skills/validate-api/SKILL.md` | Effort-required | Apply 4-step chain; prompt at Step 4 |
| `skills/validate-messaging/SKILL.md` | Effort-required | Apply 4-step chain; prompt at Step 4 |
| `skills/update-plan/SKILL.md` | Effort-required | Apply 4-step chain; prompt at Step 4 |
| `hooks/session-start/inject-workflow-context.sh` | Hook | Steps 1–2 only; degrade silently |
| `skills/init/SKILL.md` | — | Add `EFFORT` to `.forge/.gitignore` |
| `skills/update/SKILL.md` | — | Migration: append `EFFORT` to `.forge/.gitignore` if absent |
