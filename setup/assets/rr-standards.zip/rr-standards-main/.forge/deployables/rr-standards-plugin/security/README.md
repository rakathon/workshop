# Security Policy — rr-Standards Plugin

## Primary Concern: Prompt Injection

Standards artifacts and skill definitions are loaded as Claude context. A maliciously
crafted standard or skill definition could attempt to override Claude's instructions
(`ignore previous instructions`, hidden unicode, exfiltration patterns).

**Controls:**
- `rr-standards:review` spawns a `security-reviewer` agent for all changed artifacts
- Five check IDs: `prompt-injection`, `hidden-unicode`, `instruction-override`,
  `obfuscation`, `exfiltration`
- Code blocks are excluded from injection checks (false-negative bias)
- Confidence threshold: 70 (lower than standard findings — security findings are
  surfaced at lower confidence to minimize false negatives)

## Hook Script Security

The generation standards injection hook is also screened by the `hook-reviewer` agent:
- Four check IDs: `network-exfiltration`, `credential-access`, `file-exfiltration`,
  `obfuscated-execution`
- Comment exclusion applied; false-negative bias

## Standards Change Governance

Changes to organizational standards require governed review (BR-19 of the forge-plugin
program). The `rr-standards:review` PR gate enforces structural and behavioral quality
before any standard reaches the main branch.
