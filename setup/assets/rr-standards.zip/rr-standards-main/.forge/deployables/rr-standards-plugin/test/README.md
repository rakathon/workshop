# Test Strategy — rr-Standards Plugin

## Approach

Skills are tested using with/without-context behavioral evals via `rr-standards:validate --active`.

**Pass criteria:** ≥80% with-skill accuracy on the test split of `.evals.json` examples.
**Generation lift:** Informational; < 20pp improvement over baseline surfaces as a warning, not a failure.

## Benchmarks (as of 2026-03-08)

| Skill | With-skill | Without-skill | Delta |
|-------|-----------|--------------|-------|
| `rr-standards:validate` | 100% | ~20% | +80pp |
| `rr-standards:author` | 94.3% | 57.7% | +37pp |
| `rr-standards:coverage` | 100% | 8.3% | +92pp |
| `rr-standards:review` (security-reviewer) | 100% | 57% | +43pp |

## Eval Artifacts

`.evals.json` files reside alongside their standard in the codebase:
- `plugins/forge/standards/api/rest.evals.json` — 5 compliant + 5 non-compliant examples covering 8 rules; `"generated_by": "author"`

## Regression Policy

Re-run evals before merging any skill modification. A drop below 80% is a blocking finding in `rr-standards:review`.

## Test Plans

_None yet. Added per area as the plugin evolves._
