# Technical Requirements — rr-Standards Plugin

Founding document: [`.forge/efforts/rr-standards-plugin/requirements/technical.md`](../../../projects/rr-standards-plugin/requirements/technical.md)

Requirements were established during the rr-standards-plugin epic discovery phase.
The founding document is the authoritative source. Amendments below record changes
made after discovery approval.

---

## Amendments

**2026-03-08** — TR-10 added: prompt injection security screening requirement;
`security-reviewer` internal agent specification added to `rr-standards:review`
design (see founding document amendment note).

**2026-03-20** — TR-1.2, TR-1.3, TR-3.2 amended: a language guide is no longer
required to reference a companion standard. Language guides without a companion
standard are valid standalone guides. When a standard reference is present (link to
`standards/` or `Implements:` declaration), it must be valid — a broken link or
malformed declaration remains a blocking defect. `rr-standards:validate` checks
`implements-declaration` and `related-standard-link` are now conditional on the
reference being present. `rr-standards:coverage` no longer treats a missing
`Implements:` declaration as a draft indicator for standalone guides.

**2026-03-23** — TR-1.2, TR-3.3 amended: Navigation guidance (links to related content
outside the directory) is no longer a required section for AGENTS.md files. TR-3.3
checklist item removed accordingly. Additionally, the Linter section is now only
required for language-version AGENTS.md files (`languages/<lang>/<version>/AGENTS.md`);
language-root AGENTS.md files (`languages/<lang>/AGENTS.md`) are exempt. TAXONOMY.md
and `rr-standards:validate` SKILL.md updated to reflect both changes.
