# Privacy — rr-Standards Plugin

_To be populated if applicable._

## Data Handled

The rr-standards plugin does not handle personal data. It operates on:

| Data | Classification | Notes |
|------|---------------|-------|
| Standards artifact content | Internal | Organizational coding rules and guidelines |
| Skill definitions | Internal | Claude Code skill instructions |
| Eval examples | Internal | Synthetic code snippets for behavioral testing |

No PII, no user data, no external data flows.

## Privacy Review Scope

The `security-reviewer` agent within `rr-standards:review` screens for prompt
injection and exfiltration patterns in standards artifacts — this is a security
control, not a privacy concern.

## Amendments

_None._
