# rr-Standards Plugin

Coding guidelines, standards taxonomy, and authoring/review skills. Provides the
artifact taxonomy, templates, quality checks, and skills that make organizational
coding standards trustworthy and consistently usable by engineers and AI agents.

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | What the plugin must do and why |
| [requirements/technical.md](requirements/technical.md) | Skill specifications, hook design, taxonomy requirements |
| [spec/README.md](spec/README.md) | Architecture and skill design overview |
| [spec/arch-decisions/](spec/arch-decisions/README.md) | ADRs scoped to this plugin |
| [spec/interfaces/README.md](spec/interfaces/README.md) | Published skills (validate, author, coverage, review) |
| [test/README.md](test/README.md) | Test strategy, eval benchmarks, and area plans |
| [security/README.md](security/README.md) | Threat model, trust boundaries, and security controls |
| [privacy/README.md](privacy/README.md) | Data classification, handling, and retention |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Contributing Work Items

| Work Item | Type | Phase |
|-----------|------|-------|
| [rr-standards-plugin](../../projects/rr-standards-plugin/.state.json) | epic | planning (implementation complete) |
