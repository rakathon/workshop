# rr-Standards Plugin — Upstream Dependencies

Interfaces this plugin consumes from other products.

| Publisher | Interface | Version dependency | Notes |
|-----------|-----------|-------------------|-------|
| forge-plugin | Review output schema | Current | `rr-standards:review` output conforms to the Forge review output schema defined in `.forge/efforts/forge-plugin/spec/review-output-schema.md` |
