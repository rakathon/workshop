# test-skill

Behavioral testing infrastructure for skills in the Forge AI-accelerated development
framework. Delivers the `rr-standards:test-skill` skill, which measures whether a
skill's instructions measurably improve LLM task execution accuracy.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `rr-standards:test-skill` | Skill | Interactive / CI | Manual invocation |
| `skill-runner/run_skill_tests.py` | Harness | Automated | Invoked by skill |

**`rr-standards:test-skill`** reads a skill's `test.yaml`, runs the executor with
and without the skill's instructions in context, grades outputs against declared
expectations, and presents results in the shared test viewer. Supports an iterative
improvement loop that proposes targeted SKILL.md changes based on reviewer feedback.

**`run_skill_tests.py`** is the stdlib-only Python harness that handles fixture
lifecycle (copy → hooks → executor → collect → grade), two-phase evaluation, and
benchmark aggregation. Skill authors do not call it directly.

## Test File Format

Each skill under test provides `test.yaml` alongside its `SKILL.md`:

```
<skill-dir>/
├── SKILL.md
├── test.yaml        ← test definitions
└── fixtures/        ← per-test filesystem state
```

Tests declare `fixture_dir`, lifecycle hooks (`beforeTest`, `afterTest`,
`beforeAllTests`, `afterAllTests`), a `prompt`, a `prompt_baseline`, and
`expectations` — assertions the grader checks against the executor's outputs.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| forge-adr (forge-plugin) | Reference implementation; its `test.yaml` is the canonical example |

## Implementation Location

- `plugins/rr-standards/skills/test-skill/` — `rr-standards:test-skill` SKILL.md and harness
- `plugins/rr-standards/skills/shared/test-viewer/` — viewer shared with `rr-standards:test`

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/skill.md](spec/skill.md) | `rr-standards:test-skill` detailed design |

## Parent Deployable

This capability belongs to the [rr-standards-plugin](../../README.md) deployable.
