# Skill Design — rr-standards:test-skill

---

## rr-standards:test-skill

**Agent type:** Worker (non-interactive)
**Trigger:** Manual invocation by a skill author; run after the skill is functional and
the author wants to confirm behavioral effectiveness before publishing

**Input:**
- `<skill-path>` — repo-relative path to a skill directory (the directory containing
  `SKILL.md`), required
- `--ci` — machine-readable JSON output; suppresses the test viewer and ignores
  `--iterations`; runs the harness once and exits
- `--iterations N` — number of iterative improvement cycles to run (default: 1;
  ignored when `--ci` is passed)
- `--clean` — delete the entire workspace for this skill before starting
  (`rm -rf .rr-standards/validate/workspace/<slug>`)
- `--ids id,id` — run only the specified test IDs; all other tests are skipped

**Invocation modes:**

| Mode | How invoked | Output |
|------|-------------|--------|
| Interactive | Author running without `--ci` | Human-readable summary + test viewer + improvement loop |
| CI | Any invocation with `--ci` | JSON record to stdout; no viewer; single run |

**Purpose:** Measure whether the skill's instructions make an LLM more likely to
execute a task correctly. A skill that passes structural review (SKILL.md is
well-formed) may still fail behaviorally — the instructions may be ambiguous, the
happy-path steps may be underspecified, or edge-case handling may be missing.
`rr-standards:test-skill` provides a quantitative signal by comparing task execution
accuracy with and without the skill in context.

---

## Test File Format (`test.yaml`)

`test.yaml` lives alongside `SKILL.md` in the skill directory. Fixtures, when needed,
live in a `fixtures/` subdirectory at the same level.

```yaml
skill_path: plugins/forge/skills/adr
skill_version: 1.0.0
generated_at: '2026-03-30'
generated_by: author            # 'author' or 'auto'

# Suite-level hooks — run once in the skill directory, optional
beforeAllTests: |
  echo "global setup if needed"
afterAllTests: |
  echo "global teardown if needed"

tests:

- id: conversational-trigger
  name: Automatic ADR creation from a conversational decision statement
  fixture_dir: fixtures/conversational-trigger   # directory to copy; omit if not needed
  beforeTest: |                                  # runs in the temp copy before executor
    git init -q
    git checkout -q -b effort/payment-service-v2
  afterTest: |                                   # runs in the temp copy after executor
    echo "per-test teardown if needed"
  prompt: |-
    During a design session for the payment service, we discussed caching options
    and landed on this: "We'll use Redis for the session cache — it gives us
    sub-millisecond read performance and we don't want to add database load for
    every API request that needs session validation." Record this architectural
    decision.

    Do NOT run any git commit commands.
  prompt_baseline: |-
    During a design session for the payment service, we discussed caching options
    and landed on this: "We'll use Redis for the session cache — it gives us
    sub-millisecond read performance and we don't want to add database load for
    every API request that needs session validation." Record this architectural
    decision.

    Do NOT run any git commit commands.
  expected_output: ADR-001 created with all four sections. state.json updated.
  expectations:
  - The ADR filename matches the pattern ADR-001-*.md
  - The ADR header contains 'Effort ID: payment-service-v2'
  - All four sections (Context, Decision, Alternatives Considered, Consequences) are present and non-empty
  - The state.json adrsCreated array contains an entry for the new ADR without a .md extension
  - No git commit was run — only a suggested commit was printed

# Example: test with no fixture directory, just a single file as context
- id: validate-single-file
  name: Skill operating on a single input file
  artifact_file: fixtures/sample-input.md       # made available in the temp dir; omit if not needed
  beforeTest: bash fixtures/validate-single-file/setup.sh
  prompt: |-
    Review the file sample-input.md and ...
  prompt_baseline: |-
    Review the file sample-input.md and ...
  expected_output: ...
  expectations:
  - ...

# Example: test requiring rich git history and multiple branches
- id: pr-description
  name: PR description generation from commit history
  fixture_dir: fixtures/pr-description
  beforeTest: |
    git init -q
    git checkout -q -b main
    git add .
    git commit -q -m "chore: initial state" --allow-empty
    git checkout -q -b feat/payment-retry
    echo "retry logic" >> src/payment.ts
    git add .
    git commit -q -m "feat: add payment retry with exponential backoff"
    echo "tests" >> src/payment.test.ts
    git add .
    git commit -q -m "test: add retry integration tests"
  prompt: Write a PR description for the changes on the current branch.
  prompt_baseline: Write a PR description for the changes on the current branch.
  expected_output: PR description covering the two commits with summary and test plan.
  expectations:
  - The PR description mentions exponential backoff
  - A test plan section is present
```

**Field notes:**

| Field | Level | Required | Notes |
|-------|-------|----------|-------|
| `skill_path` | Suite | Yes | Repo-relative path to the skill directory |
| `skill_version` | Suite | Yes | Must match the version in SKILL.md frontmatter |
| `generated_at` | Suite | Yes | ISO date |
| `generated_by` | Suite | Yes | `author` or `auto` |
| `beforeAllTests` | Suite | No | Shell script or command; runs once before any test setup, in the skill directory |
| `afterAllTests` | Suite | No | Shell script or command; runs once after all tests complete, in the skill directory |
| `id` | Test | Yes | Kebab-case identifier, unique within the file |
| `name` | Test | Yes | Human-readable description |
| `fixture_dir` | Test | No | Repo-relative path to a directory under `fixtures/`; copied to a fresh temp dir before `beforeTest` runs. Omit when the executor needs no pre-existing directory state |
| `artifact_file` | Test | No | Repo-relative path to a single file; copied into the temp dir root before `beforeTest` runs. Mutually exclusive with `fixture_dir` |
| `beforeTest` | Test | No | Shell script or command; runs in the temp directory after fixture copy but before the executor. Use for git setup, file creation, environment configuration, or any other per-test state |
| `afterTest` | Test | No | Shell script or command; runs in the temp directory after the executor completes but before cleanup. Use for assertions that are easier to express as shell commands, or per-test teardown |
| `prompt` | Test | Yes | Task given to the executor in `with_skill` runs. Must not contain `expectations` or hint at expected outcomes. Must not include the "save outputs" instruction — the runner injects the outputs path at runtime |
| `prompt_baseline` | Test | Yes | Task given in `without_skill` runs. Identical to `prompt` for most tests; may differ when `prompt` uses a skill-specific invocation keyword |
| `expected_output` | Test | Yes | Human-readable description of the correct result; never given to executor or grader |
| `expectations` | Test | Yes | Verifiable assertions; stored in `test_metadata.json` and given only to the grader |

Hook values are shell scripts. A single-line value is treated as a single command.
A multi-line YAML block scalar (`|`) is written to a temporary file and executed with
`bash`. To call a script in `fixtures/`, write `bash fixtures/<test-id>/setup.sh`.

For interactive tests where the skill may ask a clarifying question or present a
choice, `prompt` may include a fallback response the executor should use *if* the
scenario arises — but must not state that the scenario *will* arise (e.g.,
`"If you need clarification, respond with: ..."` — not `"When the skill asks for
clarification, respond with:..."`).

---

## Workflow

### Step 1 — Parse Input

Validate that `<skill-path>/SKILL.md` exists. If not:
```
ERROR: No SKILL.md found at <skill-path>/SKILL.md.
       Provide the path to a skill directory, not a file.
```
Exit.

### Step 2 — Locate or Auto-Generate `test.yaml`

Look for `<skill-path>/test.yaml`.

**If it exists:** read it. If `skill_version` does not match the version declared in
`SKILL.md`, emit an informational warning:
```
NOTE: test.yaml skill_version (<version>) does not match SKILL.md version (<version>).
      Test results may not reflect the current skill.
```

**If it does not exist:** auto-generate an initial test suite (see § Auto-Generation).
Write it to `<skill-path>/test.yaml`. Emit:
```
NOTE: No test.yaml found. Auto-generated N tests at <skill-path>/test.yaml.
      Review the auto-generated expectations before treating results as authoritative.
```

### Step 3 — Prepare Workspace

Derive the slug from the skill directory name (e.g., `plugins/forge/skills/adr` →
`adr`). If two skills in different plugins share a name, qualify the slug (e.g.,
`forge-adr`).

**If `--clean` was passed:**
```bash
rm -rf .rr-standards/validate/workspace/<slug>
```

Determine the next iteration number: scan
`.rr-standards/validate/workspace/<slug>/iteration-N/` directories; use the next
available N (start at 0).

Create the workspace directory:
```bash
mkdir -p .rr-standards/validate/workspace/<slug>/iteration-N
```

**Reuse `without_skill` results from the previous iteration:**
`without_skill` runs have no dependency on `SKILL.md` — their output for a given
test is deterministic. If N > 0, check whether
`.rr-standards/validate/workspace/<slug>/iteration-M/` (M = N−1) contains a
completed `<test-id>/without_skill/outputs/transcript.md`. If it does, mark that
test's `without_skill` as reused (copy the prior directory rather than re-running).

Emit one line when reuse applies:
```
NOTE: Reusing without_skill results from iteration M for K/total tests.
```

### Step 4 — Run the Harness

Invoke the Python harness:

```bash
python3 <skill-base-dir>/skill-runner/run_skill_tests.py \
  --test-file "<skill-path>/test.yaml" \
  --workspace ".rr-standards/validate/workspace/<slug>/iteration-N" \
  [--ids <id,id>] \
  [--no-baseline]   # when reusing all without_skill results
```

The harness handles fixture setup, executor invocation, output collection, grading,
and `benchmark.json` aggregation. Wait for it to complete before proceeding.

If the harness exits non-zero (system error), emit:
```
ERROR: Test harness failed. Check that the `claude` CLI is available in PATH.
Details: <stderr>
```
Exit.

#### Python Harness — Execution Model

The harness is a standalone Python script (stdlib only). It does not use the Agent
tool or any in-context LLM mechanism. All execution happens via `claude -p`
subprocesses.

**Test lifecycle (per test, per variant):**

```
beforeAllTests  (once, in skill dir)
│
└─ for each test:
   1. Create temp dir  /tmp/forge-test-<timestamp>-<test-id>/
   2. Copy fixture_dir into it  (if present)
      OR copy artifact_file into it  (if present)
   3. Create outputs/ inside temp dir
   4. Run beforeTest  (if present, in temp dir)
   5. Run executor  (Phase 1 — claude -p, in temp dir)
   6. Collect outputs/ into workspace
   7. Run afterTest  (if present, in temp dir)
   8. Delete temp dir
   9. Run grader  (Phase 2 — claude -p, against collected outputs)

afterAllTests  (once, in skill dir)
```

Hook execution: the hook value is written to a temp file and run with `bash` in the
relevant directory. A non-zero exit from any hook aborts the test and marks all
expectations as failed with the hook's stderr as evidence.

**Two-phase evaluation (per test, per variant):**

- **Phase 1 — Execution:** The executor subprocess receives the task prompt and
  produces outputs. For `with_skill`, the full text of `SKILL.md` is prepended
  inside a `<skill>` element:
  ```
  The following skill defines how to handle <skill-name> tasks. Follow its
  instructions when executing the task below.

  <skill name="<skill-name>">
  <SKILL.md contents>
  </skill>

  Task:

  <prompt>

  Save any files you created or modified, plus a transcript.md describing what
  you did and why (including any questions asked, decisions made, or branches
  taken), to: <outputs_dir>
  ```
  For `without_skill`, `prompt_baseline` is used with no skill content prepended.
  The executor has no knowledge of `expectations`.

- **Phase 2 — Grading:** A second subprocess receives the grader instructions,
  the `expectations` from `test.yaml`, and the paths to `outputs/transcript.md`
  and `outputs/`. It evaluates each expectation and writes `grading.json`. The
  grader subprocess never receives `SKILL.md`.

`SKILL.md` is read fresh from disk for each `with_skill` run, so iterative changes
are picked up without restarting.

**Workspace layout written by the harness:**

```
.rr-standards/validate/workspace/<slug>/
└── iteration-N/
    ├── benchmark.json
    └── <test-id>/
        ├── with_skill/
        │   ├── test_metadata.json     ← test id, name, prompt, assertions
        │   ├── prompt.txt             ← full Phase 1 prompt (with skill wrapper)
        │   ├── grading.json           ← Phase 2 grading result
        │   ├── timing.json            ← executor and grader durations
        │   └── outputs/
        │       ├── transcript.md      ← required; executor describes what it did
        │       └── <other output files>
        └── without_skill/
            └── (same structure; prompt.txt has no skill wrapper)
```

`.rr-standards/` is gitignored. No upfront directory creation is required.

**`test_metadata.json` schema:**
```json
{
  "eval_id": "conversational-trigger",
  "eval_name": "Automatic ADR creation from a conversational decision statement",
  "prompt": "<prompt as given to the executor, without the skill wrapper>",
  "assertions": ["<expectation 1>", "<expectation 2>"]
}
```

**`grading.json` schema:**
```json
{
  "expectations": [
    {
      "text": "<original expectation string>",
      "passed": true,
      "evidence": "<specific quote or observation from transcript or outputs>"
    }
  ],
  "summary": {
    "passed": 4,
    "failed": 1,
    "total": 5,
    "pass_rate": 0.80
  }
}
```

Field names `text`, `passed`, and `evidence` are required exactly as written —
`test-viewer/generate_review.py` depends on them.

**`benchmark.json`** aggregates all test results across both variants. Run
configurations are exactly `"with_skill"` and `"without_skill"`. Each `with_skill`
entry appears before its `without_skill` counterpart. Schema matches the format
consumed by `test-viewer/generate_review.py`.

### Step 5 — Collect Results and Emit Summary

Read `benchmark.json`. Emit:

```
Behavioral validation complete — iteration N.

Results:
  with_skill pass rate:    N%
  without_skill pass rate: N%
  Lift: +N%
  test-accuracy: PASS | FAIL
  generation-lift: OK | WARNING (lift < 20% — skill may not improve over baseline)
```

**Pass thresholds:**

| Check | Threshold | Blocking? |
|-------|-----------|-----------|
| `test-accuracy` | `with_skill_pass_rate ≥ 0.80` | Yes — FAIL when below |
| `generation-lift` | `lift ≥ 0.20` | No — WARNING only |

### Step 6 — CI Mode Exit

*CI mode only (`--ci`):*

Read `.rr-standards/validate/workspace/<slug>/iteration-N/ci_report.json` written by
the harness. Emit its contents to stdout as the sole output:

```json
{
  "verdict": {
    "result": "pass",
    "with_skill_pass_rate": 0.87,
    "without_skill_pass_rate": 0.33,
    "lift": 0.53,
    "generation_lift_warning": false
  },
  "tests": [
    {
      "test_id": "conversational-trigger",
      "test_name": "Automatic ADR creation from a conversational decision statement",
      "with_skill_pass_rate": 1.0,
      "without_skill_pass_rate": 0.20,
      "passed": true
    }
  ]
}
```

- `verdict.result`: `"pass"` when `with_skill_pass_rate ≥ 0.80`; `"fail"` otherwise
- `generation_lift_warning`: `true` when `lift < 0.20` (does not affect `result`)

Exit code 0. Do not proceed to Step 7.

### Step 7 — Launch Viewer (interactive mode)

```bash
nohup python3 <skill-base-dir>/test-viewer/generate_review.py \
  ".rr-standards/validate/workspace/<slug>/iteration-N" \
  --skill-name "<skill-path>" \
  --benchmark ".rr-standards/validate/workspace/<slug>/iteration-N/benchmark.json" \
  > /dev/null 2>&1 &
```

If N > 0, also pass:
```bash
  --previous-workspace ".rr-standards/validate/workspace/<slug>/iteration-M"
```

Emit:
```
The test viewer is now running in your browser. Review each test's with_skill and
without_skill outputs side-by-side and leave feedback in the text box. When you
are done, click "Submit All Reviews".

Come back here and say "done reviewing" to apply feedback and continue.
```

Wait for the user to confirm before proceeding.

### Step 8 — Iterative Improvement

*(Skipped when `--iterations 1` or when already at the iteration limit.)*

**Read feedback:**

Read `.rr-standards/validate/workspace/<slug>/iteration-N/feedback.json`. If it does
not exist:
```
ERROR: No feedback found. The viewer was closed before feedback was submitted.
       Re-run to try again, or pass --clean to start fresh.
```
Exit.

**Propose improvements:**

Analyse feedback alongside the `benchmark.json` test failure breakdown. Group findings
by which part of SKILL.md they implicate (a step, an edge-case rule, an example).
For each implicated section, propose a specific, targeted change:

```
Iteration N — Proposed improvements

Section: <step or section heading in SKILL.md>
Feedback: <paraphrase of reviewer comment or observed failure pattern>
Current text:
  "<current SKILL.md text>"
Proposed change:
  "<improved text>"
Reason: <why this change addresses the observed failure>
Apply? (yes / no / edit)
```

Do not apply any change without explicit author acceptance. `edit` means the author
provides replacement text; apply that instead of the proposal.

After all accepted changes are applied, re-read `SKILL.md` from disk before the next
iteration — the harness reads it fresh, but the skill must also hold the updated
content for context when generating further proposals.

**Re-run:**

Increment the iteration counter and return to Step 3, passing `--no-baseline` to
the harness (reuses all `without_skill` results from iteration N).

**Convergence report** (after each iteration):

```
Improvement history:
| Iteration | with_skill | without_skill | Lift  | Sections changed        |
|-----------|------------|---------------|-------|-------------------------|
| 0         | N%         | N%            | +N%   | —                       |
| 1         | N%         | N%            | +N%   | Step 4, Error handling  |
```

If `with_skill_pass_rate ≥ 0.80`:
```
test-accuracy target reached at iteration N. Skill is behaviourally validated.
```
If additionally `lift ≥ 0.20`:
```
generation-lift target reached — skill measurably improves over baseline.
```

---

## Auto-Generation

When `test.yaml` does not exist, generate a minimal initial test suite by reading
`SKILL.md` and identifying the skill's primary scenarios:

1. **Identify the happy path(s):** the 2–3 most common invocations described in SKILL.md.
2. **Identify edge cases likely to differ between `with_skill` and `without_skill`:**
   focus on behaviours the skill instructions explicitly encode that a competent LLM
   would not do by default (e.g., gap-filling ADR numbers, detecting semantic duplicates).
   Avoid testing obvious behaviours that pass even without instructions.
3. **Determine fixture need:** if SKILL.md describes filesystem operations, create
   `fixture_dir` entries pointing to `fixtures/<test-id>/`; emit a note that the author
   must populate those directories before running. If the skill operates only on text
   passed in the prompt, omit `fixture_dir`.
4. **Write 3–5 expectations per test** that describe observable output characteristics,
   not internal process steps.

Target: 2–4 tests in total. Write the file to `<skill-path>/test.yaml` and the
`fixtures/` directory structure (empty, to be populated by the author) if needed.

---

## Relationship to rr-standards:test

`rr-standards:test-skill` uses the same viewer binary, workspace root, benchmark
schema, and grading schema as `rr-standards:test`. The Python harness
(`skill-runner/run_skill_tests.py`) is a peer to `test-runner/run_tests.py` — both
read their respective test file formats and write the same workspace structure.

| | `rr-standards:test` | `rr-standards:test-skill` |
|---|---|---|
| Artifact | Standard / language guide (`.md` file) | Skill directory (`SKILL.md`) |
| Test file | `<artifact>.test.yaml` (sibling to artifact) | `test.yaml` (in skill dir) |
| Fixture | Text snippet inline or via `artifact_file` | Directory tree via `fixture_dir`, or none |
| Phase 1 task | Review artifact for compliance; emit verdict | Execute a task; write files and transcript |
| Phase 2 task | Grade verdict against expectations | Grade outputs and transcript against expectations |
| Success criterion | `expected_verdict: compliant\|non_compliant` | `expectations` list |
| Harness | `test-runner/run_tests.py` | `skill-runner/run_skill_tests.py` |
| Workspace slug | Artifact file stem (e.g., `contracts`) | Skill directory name (e.g., `adr`) |
