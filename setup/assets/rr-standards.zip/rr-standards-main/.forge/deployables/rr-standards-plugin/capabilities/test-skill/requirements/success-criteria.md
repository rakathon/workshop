# Success Criteria — Behavioral Testing for Skills

- [ ] `test.yaml` lives alongside `SKILL.md` in the skill directory; `fixtures/`
      lives alongside it — the same layout as `<standard>.test.yaml` and `fixtures/`
      for standard tests
- [ ] `rr-standards:test-skill` accepts a skill path, locates `test.yaml`, and
      runs the full `with_skill` + `without_skill` + grading pipeline without manual
      intervention
- [ ] The shared runner (`skill-runner/run_skill_tests.py`) reads any skill's
      `test.yaml`; there are no per-skill runner scripts
- [ ] Test workspaces are created under `.rr-standards/validate/workspace/<slug>/` —
      the same root used by `rr-standards:test`
- [ ] Test fixtures are copied to isolated `/tmp/` directories before each run; source
      fixture directories are never modified
- [ ] Executor prompts contain no assertions and no hints about expected outcomes;
      assertions are stored only in `test_metadata.json` and given only to the grader
- [ ] Both `with_skill` and `without_skill` variants run for every test; the aggregate
      benchmark reports pass rates for both and the delta between them
- [ ] `grading.json` uses `text`, `passed`, and `evidence` fields exactly as required
      by `test-viewer/generate_review.py`
- [ ] Results are viewable via the existing `test-viewer/generate_review.py` with no
      changes to the viewer
- [ ] `without_skill` results from a prior iteration are reused in subsequent
      iterations; the runner does not re-run them unless `--clean` is passed
- [ ] `--ci` mode emits `ci_report.json` and exits 0; `verdict.result` is `"fail"` when
      `with_skill_pass_rate < 0.80`; `generation_lift_warning` is `true` when `lift < 0.20`
- [ ] `--iterations N` runs an improvement loop: after each iteration the skill reads
      feedback, proposes SKILL.md changes, waits for approval, and re-runs only
      `with_skill` variants
- [ ] When `test.yaml` does not exist, the skill auto-generates a minimal initial
      test suite and emits a notice to the author
- [ ] The skill works for any skill in any plugin directory
- [ ] The forge:adr prototype (`evals/evals.json`, `evals/fixtures/`, `evals/run_evals.py`,
      `evals/grade_evals.py`) is migrated to `test.yaml` + `fixtures/` and passes
      all criteria above when invoked via `rr-standards:test-skill`
