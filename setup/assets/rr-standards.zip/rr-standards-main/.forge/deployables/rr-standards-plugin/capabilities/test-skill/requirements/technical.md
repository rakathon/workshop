# Technical Requirements — Behavioral Testing for Skills

---

## Current State

The `rr-standards:test` skill tests standards and language guides via a Python harness
(`test-runner/run_tests.py`) and displays results in a shared viewer
(`test-viewer/generate_review.py`). The test definition format is `<artifact>.test.yaml`
alongside the artifact file, with fixtures in a `fixtures/` subdirectory and a workspace
at `.rr-standards/validate/workspace/<slug>/iteration-N/`.

For skills, a prototype evaluation pattern exists in `plugins/forge/skills/adr/evals/`:
`run_evals.py`, `grade_evals.py`, and `evals.json`. This prototype demonstrates the
isolation and grading approach but uses different naming conventions, a JSON test format,
and a separate workspace root. It must be migrated during implementation of this effort
to align with the conventions below.

This effort defines `rr-standards:test-skill` — a skill that uses the same conventions
as `rr-standards:test` so skill authors and standard authors share a single mental model.

---

## TR-1: Skill Test Definition Format

### TR-1.1: File Location and Naming

Each skill's test definition lives alongside `SKILL.md` in the skill directory, with
fixtures in a subdirectory at the same level — directly mirroring the layout used for
standards:

```
<skill-dir>/
├── SKILL.md
├── test.yaml             ← test definition (analogous to contracts.test.yaml)
└── fixtures/             ← fixture assets (analogous to fixtures/ for standards)
    ├── <test-name>/      ← one subdirectory per filesystem-fixture test
    │   └── .forge/       ← (example: forge:adr fixture contents)
    └── <test-name-2>/
```

The filename is `test.yaml`. Unlike standards — where multiple `.test.yaml` files can
exist in the same directory, each named after its artifact — a skill directory contains
exactly one skill (`SKILL.md`), so no disambiguating prefix is needed.

### TR-1.2: Test Definition Schema

The YAML structure follows the same conventions as `.test.yaml` for standards, adapted
for the executor model:

```yaml
skill_path: plugins/forge/skills/adr     # repo-relative path to the skill directory
skill_version: 1.0.0                     # from SKILL.md frontmatter (version field)
generated_at: '2026-03-30'
generated_by: author                     # 'author' or 'auto'
tests:

- id: conversational-trigger
  name: Automatic ADR creation from a conversational decision statement
  fixture_dir: fixtures/conversational-trigger   # omit when no fixture needed
  beforeTest: |                                  # git setup, file creation, etc.
    git init -q
    git checkout -q -b effort/payment-service-v2
  prompt: |-
    During a design session for the payment service...
  prompt_baseline: |-
    During a design session for the payment service...
  expected_output: ADR-001 created with all four sections. state.json updated.
  expectations:
  - The ADR filename matches the pattern ADR-001-*.md
  - The ADR header contains 'Effort ID: payment-service-v2'
  - All four sections (Context, Decision, Alternatives Considered, Consequences) are present and non-empty
  - The state.json adrsCreated array contains an entry for the new ADR without a .md extension
  - No git commit was run — only a suggested commit was printed
```

**Field definitions:**

| Field | Required | Notes |
|-------|----------|-------|
| `skill_path` | Yes | Repo-relative path to the skill directory |
| `skill_version` | Yes | Must match the version in SKILL.md frontmatter |
| `generated_at` | Yes | ISO date of last generation or authoring |
| `generated_by` | Yes | `author` or `auto` |
| `tests[].id` | Yes | Kebab-case identifier, unique within the file |
| `tests[].name` | Yes | Human-readable description of what the test exercises |
| `beforeAllTests` | Suite | No | Shell script or command; runs once before any test, in the skill directory |
| `afterAllTests` | Suite | No | Shell script or command; runs once after all tests, in the skill directory |
| `fixture_dir` | Test | No | Repo-relative path to a directory in `fixtures/`; copied to a fresh temp dir. Omit when no directory state is needed |
| `artifact_file` | Test | No | Repo-relative path to a single file; copied into the temp dir root. Mutually exclusive with `fixture_dir` |
| `beforeTest` | Test | No | Shell script or command; runs in the temp dir after fixture copy, before the executor. Use for git setup, file creation, or any per-test state |
| `afterTest` | Test | No | Shell script or command; runs in the temp dir after the executor, before cleanup |
| `prompt` | Test | Yes | The task given to the executor in `with_skill` runs. Must not contain assertions or hints about expected outcomes. Must not include the "save outputs" instruction — the runner injects the output path at runtime |
| `prompt_baseline` | Test | Yes | The task given to the executor in `without_skill` runs. For most tests identical to `prompt`; may differ when `prompt` uses a skill-specific invocation keyword |
| `expected_output` | Test | Yes | Human-readable description of the correct result. Not used programmatically — for author reference only |
| `expectations` | Test | Yes | List of verifiable assertions about the executor's outputs and transcript |

**Constraints on `prompt` content** — matching the unbiased evaluation requirement
for standards (TR-1.3 in the parent standards effort):

- Must not state what the grader will check
- Must not describe expected behaviour in terms of what the skill "should" do
- For interactive scenarios (clarifying questions, duplicate detection): may provide
  a fallback response the executor should use *if* the scenario arises, but must not
  state that the scenario *will* arise (e.g., "if you need clarification, respond with X"
  — not "when the skill asks for clarification, respond with X")

### TR-1.3: Test Lifecycle and Hook Execution

Each test runs in a fresh temp directory. The runner executes these steps in order:

1. Create `/tmp/forge-test-<timestamp>-<test-id>/`
2. Copy `fixture_dir` into it (if present), OR copy `artifact_file` into the root (if present)
3. Create `outputs/` inside the temp dir
4. Run `beforeTest` hook in the temp dir (if present)
5. Run the executor (Phase 1 — see TR-2)
6. Collect `outputs/` contents into the workspace run directory
7. Run `afterTest` hook in the temp dir (if present)
8. Delete the temp dir
9. Run the grader (Phase 2 — see TR-3)

Suite-level hooks run outside the per-test lifecycle:
- `beforeAllTests` runs once in the skill directory before step 1 of the first test
- `afterAllTests` runs once in the skill directory after step 9 of the last test

Hook values are shell scripts. A single-line value is a single command. A multi-line
YAML block scalar is written to a temp file and run with `bash`. A non-zero exit from
any hook aborts that test and marks all its expectations as failed, with the hook's
stderr as evidence.

The executor receives only: the working directory (via CWD) and the prompt with the
outputs path injected. It does not receive the fixture path, fixture name, hook
contents, or any description of the test setup.

### TR-1.4: Executor Output Contract

The runner appends the following instruction to every prompt at runtime, substituting
the actual path:

```
Save any files you created or modified, plus a transcript.md describing what you
did and why (including any questions asked, decisions made, or branches taken), to:
<outputs_dir>
```

`transcript.md` is required. The grader uses it to verify behavioral assertions
(e.g., "a clarifying question was asked before any file was created"). If the executor
does not write it, the grader treats any transcript-dependent assertion as `failed`.

---

## TR-2: Skill Injection

### TR-2.1: With-Skill Runs

For `with_skill` runs, the runner prepends the full text of `SKILL.md` to the prompt:

```
The following skill defines how to handle <skill-name> tasks. Follow its instructions
when executing the task below.

<skill name="<skill-name>">
<SKILL.md contents>
</skill>

Task:

<prompt>

<output instruction>
```

`SKILL.md` is read fresh from disk at run time so that iteration N+1 automatically
picks up any changes made between iterations.

### TR-2.2: Without-Skill Baseline Runs

For `without_skill` runs, the runner uses `prompt_baseline` with no skill content:

```
<prompt_baseline>

<output instruction>
```

`without_skill` results are stable across SKILL.md iterations (the baseline has no
dependency on SKILL.md). The runner must not re-run `without_skill` if a prior result
exists in the workspace for the same test ID, unless `--clean` is passed.

---

## TR-3: Grading

### TR-3.1: Grader Invocation

After the executor completes, the grader receives:

- The `expectations` list from `test.yaml` (never from the executor's prompt)
- The path to `outputs/transcript.md`
- The path to `outputs/`

The grader writes `grading.json` to the run directory (sibling of `outputs/`).

### TR-3.2: Grading Output Schema

`grading.json` must use the same schema as for standards tests, as required by
`test-viewer/generate_review.py`:

```json
{
  "expectations": [
    {
      "text": "<original expectation string>",
      "passed": true,
      "evidence": "<specific quote or observation>"
    }
  ],
  "summary": {
    "passed": 4,
    "failed": 1,
    "total": 5,
    "pass_rate": 0.80
  }
}
```

Field names `text`, `passed`, and `evidence` are required exactly as written.

---

## TR-4: Workspace Structure

### TR-4.1: Location

Skill test workspaces use the same root as standard test workspaces:

```
.rr-standards/validate/workspace/<slug>/iteration-N/
```

The slug is derived from the skill directory name (e.g., `plugins/forge/skills/adr`
→ `adr`). If two skills in different plugins share a directory name, the runner
must use a qualified slug (e.g., `forge-adr`).

### TR-4.2: Directory Layout

```
.rr-standards/validate/workspace/<slug>/
└── iteration-N/
    ├── benchmark.json
    ├── <test-id>/
    │   ├── with_skill/
    │   │   ├── test_metadata.json
    │   │   ├── grading.json
    │   │   ├── timing.json
    │   │   └── outputs/
    │   │       ├── transcript.md
    │   │       └── <other output files>
    │   └── without_skill/
    │       └── (same structure)
    └── <test-id-2>/
        └── ...
```

### TR-4.3: test_metadata.json

```json
{
  "eval_id": "conversational-trigger",
  "eval_name": "Automatic ADR creation from a conversational decision statement",
  "prompt": "<the prompt actually given to the executor, without the skill wrapper>",
  "assertions": ["<expectation 1>", "<expectation 2>"]
}
```

`assertions` is copied from `test.yaml` at run time so the grader can read
them without opening the test file. It must not appear in any prompt sent to the
executor.

### TR-4.4: benchmark.json and Viewer Compatibility

`benchmark.json` must conform to the same schema consumed by
`test-viewer/generate_review.py`. Run configurations are `"with_skill"` and
`"without_skill"`. Both `rr-standards:test` and `rr-standards:test-skill` use the
same viewer binary — no fork.

---

## TR-5: Runner Script

### TR-5.1: Location

The runner is a shared Python script inside the `rr-standards:test-skill` skill
directory, directly parallel to `test-runner/run_tests.py` in `rr-standards:test`:

```
plugins/rr-standards/skills/test-skill/
├── SKILL.md
├── skill-runner/
│   └── run_skill_tests.py     ← analogous to test-runner/run_tests.py
```

Individual skills contain only `test.yaml` and `fixtures/` — no per-skill
runner scripts. The runner is shared infrastructure, not duplicated per skill.

### TR-5.2: Runner Responsibilities

`run_skill_tests.py` accepts the path to a `test.yaml` file and:

- Reads the test definition and resolves fixture paths relative to the test.yaml
- Accepts `--ids`, `--no-baseline`, `--iteration`, `--clean`, and `--verbose` flags
- Creates `.rr-standards/validate/workspace/<slug>/iteration-N/` and increments N
- For each test: copies fixture to `/tmp/` (if `fixture_dir` present), runs claude,
  collects outputs, writes `test_metadata.json` and `timing.json`
- Runs the grader for each completed run
- Writes `benchmark.json`
- Prints the viewer launch command on completion
- Exits non-zero if `claude` CLI is not found in PATH

### TR-5.3: Skill Orchestration

`rr-standards:test-skill` is the Claude skill that drives `run_skill_tests.py`. It is
not a replacement for the script — it orchestrates it. The skill:

1. Resolves the skill path from the invocation argument
2. Locates `test.yaml` or auto-generates it (TR-6)
3. Invokes `run_skill_tests.py` with the appropriate flags
4. Launches the viewer
5. In `--iterations N` mode: reads `feedback.json`, proposes SKILL.md changes, waits
   for approval, re-runs with `--no-baseline` (reusing prior `without_skill` results)

---

## TR-6: Auto-Generation

When `test.yaml` does not exist, the skill auto-generates an initial test suite
from `SKILL.md`. The same principles apply as for standards auto-generation (minimise
fixture count, maximise rule coverage, focus on skill-differentiating behaviours):

- 2–4 tests covering the skill's primary scenarios
- `fixture_dir` omitted unless SKILL.md clearly describes filesystem operations
- 3–5 expectations per test focused on observable outputs
- Emits a notice:
  ```
  NOTE: No test.yaml found. Auto-generated N tests at <path>.
  Review the auto-generated expectations before treating results as authoritative.
  ```

Expectations must focus on outcomes that differ between `with_skill` and
`without_skill` — assertions a competent LLM would pass without skill instructions
are low-value.

---

## TR-7: Invocation Interface

```
/rr-standards:test-skill <skill-path> [--ci] [--iterations N] [--clean] [--ids id,id]
```

Mirrors the `rr-standards:test` interface exactly, with `<skill-path>` (directory
containing `SKILL.md`) in place of the artifact file path.

The CI report schema mirrors `rr-standards:test`, with skill-appropriate field names:

```json
{
  "verdict": {
    "result": "pass | fail",
    "with_skill_pass_rate": 0.85,
    "without_skill_pass_rate": 0.40,
    "lift": 0.45,
    "generation_lift_warning": false
  },
  "tests": [
    {
      "test_id": "conversational-trigger",
      "with_skill_pass_rate": 1.0,
      "without_skill_pass_rate": 0.33,
      "passed": true
    }
  ]
}
```

`verdict.result` is `"fail"` when `with_skill_pass_rate < 0.80`. The
`generation_lift_warning` flag is `true` when `lift < 0.20` (informational, does not
affect `result`) — consistent with `rr-standards:test`.

---

## TR-8: Relationship to rr-standards:test

`rr-standards:test-skill` is a peer skill to `rr-standards:test`. They share:

- Test definition conventions (`test.yaml` / `*.test.yaml`, `fixtures/` subdirectory)
- Workspace root (`.rr-standards/validate/workspace/`)
- `benchmark.json` schema
- `grading.json` schema (`text` / `passed` / `evidence`)
- `test-viewer/generate_review.py` (unchanged, used by both)
- The with/without measurement pattern and the 0.80 / 0.20 thresholds
- The `--ci`, `--iterations`, `--clean` invocation flags

They differ in:

| | `rr-standards:test` | `rr-standards:test-skill` |
|---|---|---|
| Artifact | Standard / language guide file | Skill directory (SKILL.md) |
| Test file | `<artifact>.test.yaml` | `test.yaml` |
| Fixture | Text snippet (`artifact_file` / `artifact_snippet`) | Directory tree (`fixture_dir`) or none |
| Executor task | Review an artifact for compliance | Execute a task and produce outputs |
| Success criterion | `expected_verdict: compliant\|non_compliant` | `expectations` list |
| Runner | `test-runner/run_tests.py` | `skill-runner/run_skill_tests.py` |

## TR-9: Migration of Existing Prototype

The forge:adr skill contains a prototype evaluation directory (`evals/`) that must be
migrated during implementation:

| Before | After |
|--------|-------|
| `plugins/forge/skills/adr/evals/evals.json` | `plugins/forge/skills/adr/test.yaml` |
| `plugins/forge/skills/adr/evals/fixtures/` | `plugins/forge/skills/adr/fixtures/` |
| `plugins/forge/skills/adr/evals/run_evals.py` | Deleted — superseded by shared `run_skill_tests.py` |
| `plugins/forge/skills/adr/evals/grade_evals.py` | Deleted — grading integrated into `run_skill_tests.py` |

The six existing eval cases and their fixture directories are correct and should be
preserved; only the format and location change. The `evals/` directory is removed.
