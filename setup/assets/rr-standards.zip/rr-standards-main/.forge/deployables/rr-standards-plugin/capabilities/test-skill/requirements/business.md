# Business Requirements — Behavioral Testing for Skills

---

## Context

The `rr-standards:test` skill provides behavioral validation for standards and language
guides: given a candidate artifact, does applying the standard as context make an LLM
more accurate? This is effective for *context* artifacts — documents whose purpose is
to improve LLM output quality when loaded as a reference.

Skills are different. A skill is a set of *behavioral instructions* — it changes what
the LLM *does*, not what it knows. Testing a skill means verifying that following its
instructions causes the LLM to execute a task correctly: write the right files, ask the
right questions, detect conflicts, number things correctly. The LLM acts as an executor
producing outputs, not as a reviewer rendering a compliance verdict.

The measurement pattern is the same in both cases: run the LLM with the artifact in
context (`with_skill`) and without (`without_skill`), then evaluate both outputs against
known-good expectations. The difference is in the fixtures, the executor's task, and
what constitutes a passing result.

Currently, skill testing is ad hoc. Developers accumulate temp directories in `/tmp`,
write prompts directly into subagent invocations, and manually assess whether the
output looks right. There is no standard fixture format, no isolation guarantee, no
record of which behaviors were tested, and no way to confidently say that a skill
change improved or regressed behavior.

---

### BR-1: Skills Must Have a Standard Test Case Format

A skill author must be able to define a set of test cases for their skill in a
structured file that lives alongside the skill. The format must capture:

- What environment to set up before the executor runs (the fixture)
- What prompt to give the executor
- What the baseline prompt is when the skill is not available
- What assertions must be true of the executor's output

The format must be skill-agnostic: it must work for skills whose fixtures are
filesystem trees, skills that operate on text passed in the prompt, and skills with no
fixture at all. The fixture type is specified per test case; the test runner handles
setup accordingly.

A test file that does not yet exist must be auto-generatable from the skill's SKILL.md,
producing a minimal but executable initial test suite that the author can immediately
run and refine.

### BR-2: Test Fixtures Must Be Isolated

When a test runs, the executor must operate on a fresh copy of the fixture — not on
the fixture files that live in the repository. Changes the executor makes (files
created, files modified) must not persist between test runs and must never affect the
source fixture.

Isolation serves two purposes: it prevents test runs from interfering with each other,
and it ensures the executor sees the exact state defined by the fixture — no drift from
a prior run that partially completed.

### BR-3: Expected Outcomes Must Be Unknown to the Executor

The assertions that define a passing result must not appear in the prompt given to the
executor. The executor must encounter the task naturally, as a real user would present
it, and produce its output without knowing what it will be graded on.

This is the skill-testing equivalent of the unbiased evaluation requirement in
`rr-standards:test` (BR-13 of the parent epic). An executor that knows the expected
outcomes can satisfy assertions superficially without actually doing the work correctly.

Assertions live in the test definition and are only given to the grading step, after
the executor has completed.

### BR-4: The Skill Must Produce a Quantitative With/Without Comparison

For a skill test to be meaningful, it must answer the question: does having the skill's
instructions in context make the executor more likely to do the right thing? A test
that only measures `with_skill` behavior is not sufficient — it cannot distinguish
between "the skill made this better" and "the task was easy and the executor would have
done it anyway."

Every test run must include both a `with_skill` variant (executor has the skill's
SKILL.md in context) and a `without_skill` baseline (executor receives only the raw
prompt, no skill instructions). Both variants are graded against the same expectations.
The aggregate pass rates and the delta between them constitute the primary signal.

### BR-5: Results Must Be Reviewable in the Existing Test Viewer

The test viewer already supports side-by-side comparison of with/without outputs,
grading display, and feedback collection. The skill test output must produce a
workspace structure compatible with the existing viewer so that skill authors use the
same review workflow as standard authors. There is one viewer, not two.

### BR-6: The Skill Must Support Iterative Improvement

A skill author will rarely get SKILL.md right on the first attempt. After reviewing
test results, they should be able to apply feedback and re-run without re-running
evaluations whose inputs have not changed. The `without_skill` baseline is stable
across iterations of the skill (the baseline prompt doesn't change when SKILL.md
changes); re-running it is unnecessary and wastes time.

The skill must support an improvement loop: review outputs, optionally propose SKILL.md
changes, re-run only the `with_skill` variants, compare new results to the previous
iteration.

### BR-7: The Skill Must Support CI Mode

A skill that passes tests in development should continue passing after changes. The
skill must support a non-interactive mode that runs all test cases, produces a
machine-readable result, and exits with a signal that a CI pipeline can consume.

---

Success criteria: [success-criteria.md](success-criteria.md)
