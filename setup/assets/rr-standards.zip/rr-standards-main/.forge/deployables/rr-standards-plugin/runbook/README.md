# Runbook — rr-Standards Plugin

## Areas

| Area | Document | Status |
|------|----------|--------|
| Skill eval regression (with-skill accuracy drops below 80%) | _(pending)_ | Not started |
| Standards taxonomy mismatch (artifact not classified) | _(pending)_ | Not started |
| Coverage scan producing 0-count output | _(pending)_ | Not started |
