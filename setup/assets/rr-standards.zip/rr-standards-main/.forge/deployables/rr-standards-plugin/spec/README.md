# rr-Standards Plugin — Architecture

Full design detail is in the rr-standards-plugin work item:
- [Skills design](../../../projects/rr-standards-plugin/spec/skills.md)
- [Hook design](../../../projects/rr-standards-plugin/spec/hook.md)

## Overview

The plugin consists of four skills and one hook:

**Skills:**
- `rr-standards:validate` — validates a single standards artifact against the quality
  checklist for its type; supports interactive and `--ci` output modes; `--active` mode
  runs behavioral eval accuracy and generation lift tests
- `rr-standards:author` — guides an author through creating or updating a standards
  artifact; delegates final validation to `rr-standards:validate`
- `rr-standards:coverage` — walks all standards and language guide locations, computes
  coverage status, writes `COVERAGE.md`
- `rr-standards:review` — PR gate review for standards artifact changes; spawns parallel
  internal agents (artifact-reviewer, security-reviewer, hook-reviewer, confidence-scorer)

**Hook:**
- `inject-generation-standards.sh` — PreToolUse hook injecting the applicable
  language guide before any Write/Edit operation

## Skill Locations

| Skill | Path |
|-------|------|
| `rr-standards:validate` | `plugins/rr-standards/skills/validate/` |
| `rr-standards:author` | `plugins/rr-standards/skills/author/` |
| `rr-standards:coverage` | `plugins/rr-standards/skills/coverage/` |
| `rr-standards:review` | `plugins/rr-standards/skills/review/` |
