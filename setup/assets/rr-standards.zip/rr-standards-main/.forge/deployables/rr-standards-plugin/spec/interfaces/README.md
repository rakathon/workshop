# rr-Standards Plugin — Published Interfaces

Interfaces published by the rr-standards plugin. Consuming products (e.g., forge-plugin
review capabilities) depend on these interfaces.

## Skills

| Skill | Invocation | Output |
|-------|-----------|--------|
| `rr-standards:validate` | `/rr-standards:validate <file> [--ci] [--active] [--improve] [--iterations N]` | Interactive report or JSON conforming to review output schema (`target.type: "file"`) |
| `rr-standards:author` | `/rr-standards:author` | Guided session; delegates to validate at end |
| `rr-standards:coverage` | `/rr-standards:coverage [<root-dir>]` | Writes `<root>/standards/COVERAGE.md`; prints summary |
| `rr-standards:review` | `/rr-standards:review [--base <branch>] [--pr <number>] [--ci] [--skip-test]` | Interactive report or JSON conforming to review output schema |

## Review Output Schema Conformance

All skills that emit machine-readable output conform to the Forge review output schema:
[`.forge/efforts/forge-plugin/spec/review-output-schema.md`](../../../../projects/forge-plugin/spec/review-output-schema.md)

## Eval Schema

The `.evals.json` companion artifact format is a published interface for behavioral
testing of standards. Schema defined in `standards/TAXONOMY.md § Companion Artifacts`.

## Taxonomy

`standards/TAXONOMY.md` is a published interface that skills use to classify artifact
types and determine applicable quality checklists.
