# rr-Standards Plugin — Architectural Decisions

| ADR | Title | Status |
|-----|-------|--------|

_No ADRs yet. Design decisions for this plugin were made during the rr-standards-plugin
epic discovery phase and are documented in the work item design artifacts:
[`.forge/efforts/rr-standards-plugin/spec/`](../../../../projects/rr-standards-plugin/spec/)._

## Adding a New ADR

1. Copy the template below into a new file: `ADR-NNN-short-title.md`
2. Fill in all sections
3. Add a row to the table above

```markdown
← [Decisions Index](README.md)

# ADR-NNN: Title

**Status:** Proposed | Accepted | Deprecated | Superseded by [ADR-NNN](ADR-NNN-filename.md)
**Date:** YYYY-MM-DD

## Context

[The situation, forces, and problem that motivated this decision]

## Decision

[What was decided]

## Consequences

**Positive:**
- ...

**Negative:**
- ...

## Alternatives Considered

[Optional — include when alternatives were explicitly weighed]
```
