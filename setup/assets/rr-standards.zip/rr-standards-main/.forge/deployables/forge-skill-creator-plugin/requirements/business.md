# Business Requirements — forge-skill-creator plugin
<!-- graduated-from: forge-skill-creator-plugin at 2026-05-15T05:45:24Z -->

*Deployable: forge-skill-creator-plugin*
*Created: 2026-05-14*

---

## BR-1: Non-technical users can build a skill with no prior knowledge of the toolchain

A non-technical user who says "I want to build a skill that does X" should be guided through the entire skill creation process — from intent capture to working, tested SKILL.md — without needing to know which commands to run, in what order, or what a test harness is. The skill holds context across all phases (interview → draft → test → refine) so the user never has to re-explain their intent.

**Acceptance criteria:**
- A user with no knowledge of forge:elaborate, skill-creator, or rr-standards:test-skill can produce a working, behaviorally validated skill in a single session
- The skill infers where the user is in the process and picks up from there without requiring explicit phase commands
- Context established during the intent interview is used directly to generate test cases and improvement proposals — the user is never asked to re-describe their goal
- Technical jargon (eval, assertion, harness, frontmatter) is either avoided or explained inline when first encountered

## BR-2: Output files are written to a sensible, user-confirmed location

The skill must infer the best output location from the repository context and confirm it with the user before writing anything.

**Acceptance criteria:**
- In a Forge-initialized repository with an active effort: discovery and planning artifacts (requirements, user stories, ADRs) are written under `.forge/efforts/<id>/`; the skill implementation (SKILL.md and supporting files) is written to a location outside `.forge/`, derived by inspecting the existing plugin/skill directory structure (e.g. `plugins/forge/skills/<skill-name>/` if that pattern is present)
- In a Forge-initialized repository with no active effort: the skill offers to create a Forge effort, or to work standalone; in either case it still inspects the repo structure to propose a sensible skill output location
- In a non-Forge repository: all output goes under a `<skill-name>/` directory in the current working directory
- The proposed skill output location is always derived from what actually exists in the repo — the skill never defaults to `<skill-name>/` in the CWD when a more appropriate location is evident from the directory structure
- Before writing any files, the skill presents its proposed output path(s) in plain language ("I'll put the skill here: `plugins/forge/skills/my-skill/` — does that look right?") and waits for the user to confirm or specify a different path
- The skill never writes files to a location the user has not approved

## BR-3: The skill establishes understanding across seven dimensions before drafting

Before generating any SKILL.md draft, the skill must work through seven areas of understanding with the user (not necessarily in this order — follow the conversation naturally, but ensure all seven are covered):

1. **Role** — who is this skill for? What kind of user will invoke it?
2. **Purpose** — what problem does it solve? What is its overall goal?
3. **Trigger** — when does it activate? What does the user say or do to invoke it?
4. **Inputs** — what does the user (or system) provide to the skill? Files, arguments, context?
5. **Process** — how does the skill work step by step? What does Claude do when it runs?
6. **Outputs and side-effects** — what does it produce? Files written, messages sent, external systems touched?
7. **Location** — where should the skill be written in the repository?

Edge cases and constraints may be deferred to the iterative loop, but all seven dimensions must be addressed before drafting begins.

**Acceptance criteria:**
- The seven dimensions are the *target understanding*, not a prescribed question list — Claude must reach that understanding through natural conversation, using whatever questions make sense given what the user has already said
- Claude must not ask questions whose answers are already evident from the user's description or the repository context
- Claude must not present the seven dimensions as a form or checklist to the user — the conversation should feel like talking to a knowledgeable colleague who is trying to understand the problem
- After the conversation has covered all seven dimensions sufficiently, the skill produces a plain-language summary and waits for explicit confirmation before drafting — the user must agree the summary is correct before any file is generated
- The summary-and-confirm step is non-skippable
- For existing skills (BR-10), dimensions 1–6 are derived from the existing SKILL.md and confirmed rather than asked from scratch; dimension 7 is the existing file location unless the user wants to move it

## BR-4: The skill carries the forge brand and replaces both the Anthropic skill-creator and rr-standards:test-skill

The new skill must be recognizable as the organization's official, blessed skill creation toolchain — distinct from the Anthropic skill-creator plugin. rr-standards:test-skill is deprecated and superseded by this skill; all test execution capability moves here.

**Acceptance criteria:**
- The skill is named `forge:skill-creator` and lives within the forge plugin under `plugins/forge/skills/skill-creator/`
- The Python test harness and test-viewer are bundled directly within this skill (not referenced from rr-standards:test-skill)
- rr-standards:test-skill is marked deprecated with a pointer to `forge:skill-creator`
- Users who previously used rr-standards:test-skill can migrate by switching to `forge:skill-creator`

## BR-5: Improvement proposals require confirmation by default, with an opt-in autonomous mode

When proposing changes to a SKILL.md after a test run, the skill must show each proposed change and the reason for it, and wait for the user to accept, reject, or edit each one before writing. A user may opt into autonomous mode by explicitly saying so (e.g. "just fix everything", "go ahead and apply all changes") — in that mode the skill applies all improvements without prompting and reports what it changed afterward.

**Acceptance criteria:**
- Default behavior: each proposed change is shown with a plain-language explanation of what went wrong and what the fix does; the user must respond before the skill writes anything
- Autonomous mode: activated only by explicit user instruction; the skill applies all changes and produces a summary of what was changed and why
- Autonomous mode does not persist across sessions — each new invocation starts in confirmation mode
- In both modes, the convergence report (iteration history table) is always shown after each run

## BR-6: Description optimization is offered as an optional final step

After the user is satisfied with the skill's behavior, the skill offers — but does not require — a description optimization pass that tunes the SKILL.md `description` field to maximize triggering accuracy in Claude.

**Acceptance criteria:**
- The offer is presented in plain language: the user is told what the step does and roughly how long it takes before they decide
- The user can skip it without any negative consequence to the rest of the workflow
- When run, the step uses the Anthropic `run_loop.py`/`run_eval.py` scripts (bundled within the skill) and requires the `claude` CLI to be available in PATH
- If the `claude` CLI is not available, the skill surfaces a clear message and skips the step gracefully rather than erroring

## BR-7: All session artifacts are human-readable markdown; state is derived from what exists on disk

The skill must not write JSON or binary state files to track session progress. All intermediate and final artifacts are markdown files a non-technical user can open and read. When re-invoked, the skill determines where to resume by reading the existing markdown artifacts — no separate state file is needed.

**Acceptance criteria:**
- No `.skill-creator-session.json` or equivalent machine-only state files are written
- Every file written during a session (intent summary, requirements, draft SKILL.md, test expectation notes, iteration summaries) is valid, readable markdown
- On re-invocation, the skill reads existing artifacts in the output directory (or `.forge/efforts/<id>/` in Forge context) and infers current phase: if a SKILL.md draft exists but no test results, resume from testing; if test results exist, resume from the improvement loop
- The phase inference is shown to the user: "I can see you've already got a draft — picking up from the test phase." The user can correct or start over if needed

## BR-8: The skill performs an unprompted quality review pass before finishing

Before presenting the finished skill to the user, the skill must run a self-review pass — without being asked — to surface quality issues, gaps in the SKILL.md, and any behavioral test failures that should be addressed. The user receives a clear verdict and a list of issues (if any) before the session ends.

**Acceptance criteria:**
- The review pass runs automatically after the iterative improvement loop reaches convergence or the user signals they are satisfied
- The review uses `forge:review` (or an equivalent inline check if forge is not available) to evaluate the SKILL.md against organizational quality standards
- The user sees a PASS/FAIL verdict with specific findings before being offered packaging or distribution options
- A FAIL result does not block the user from continuing — it surfaces issues and recommends fixes, but the user decides whether to act on them

## BR-9: Finished skills are distributed through a pipeline that ends in rr-standards

A skill produced by forge:skill-creator must have a clear, automated path into the organization's official skill library (rr-standards), regardless of where the user is working.

**Acceptance criteria:**
- In the rr-standards repository: the user raises a PR; merge makes the skill available via the marketplace
- In any other context (another repository, or no repository): the skill offers to publish the packaged `.skill` file to the organization's distribution store (Box or S3 — see open decision), which triggers an automated pipeline that creates a feature branch on rr-standards, places the skill in the correct location, and raises a PR
- CI on the rr-standards PR runs all validation and review skills automatically against the submitted skill
- The user is told what will happen at each step before it happens; the publish action is opt-in

## BR-10: The skill improves existing skills, not just creates new ones

A user who already has a SKILL.md can invoke `forge:skill-creator` to improve it — the skill detects the existing artifact, skips the intent interview and drafting phases, and picks up at the test-and-improve loop.

**Acceptance criteria:**
- If an existing SKILL.md is provided (via argument or detected in the current directory), the skill reads it, summarizes what it does, and confirms with the user before running tests
- The improvement loop, self-review, and distribution steps all apply identically to improvement sessions
- The user can also ask to revisit the intent / description even for an existing skill — the skill should not assume the existing SKILL.md is correct, only that it is the starting point
- Deprecation of `rr-standards:test-skill` is out of scope for this effort — handled as a separate task after `forge:skill-creator` ships

## BR-11: The implementation draws directly from the Anthropic skill-creator and rr-standards:test-skill

`forge:skill-creator` is not built from scratch — it is a synthesis of two open-source implementations that each do something well. The implementer must study both and take the best from each rather than reinventing either.

**From the Anthropic skill-creator (`anthropics/claude-plugins-official`):**
- The overall skill creation and improvement workflow (capture intent → draft → test → review → iterate)
- The approach to writing SKILL.md instructions (progressive disclosure, supporting files, writing style guidance)
- The eval viewer integration (`eval-viewer/generate_review.py`) — reuse or adapt this directly
- The description optimization loop (`run_loop.py`, `run_eval.py`) — reuse directly
- The grader, comparator, and analyzer agent patterns (`agents/grader.md`, `agents/comparator.md`, `agents/analyzer.md`)
- The benchmark aggregation script (`scripts/aggregate_benchmark.py`)
- Direct copying of open-source components is explicitly permitted and encouraged where it avoids duplication

**From `rr-standards:test-skill`:**
- The Python test harness (`run_skill_tests.py`) — the execution engine for all test runs
- The `test.yaml` format with `fixture_dir` support
- The minimal-tests/maximal-assertions philosophy
- The workspace directory structure (`.rr-standards/validate/workspace/<slug>/iteration-N/`)
- The `benchmark.json` output format and convergence report

**Acceptance criteria:**
- The implementer reads both SKILL.md files in full before writing a line of `forge:skill-creator`
- Any component that exists in either source and can be reused without modification is copied rather than rewritten
- Deviations from either source are intentional and documented (e.g., side-by-side viewer replacing the Anthropic single-column viewer)
