# Security Policy — Forge Framework

_To be populated. Produced as part of the forge-plugin security review._

## Trust Boundary

The Forge framework operates within the developer's Claude Code session and CI
environment. It does not introduce network-accessible services or external datastores.
Primary security concerns:

- **Hook scripts** — installed into `.claude/hooks/` and executed on every Write/Edit
  operation; must not introduce code execution vectors or credential access
- **Skill definitions** — `SKILL.md` files loaded as Claude context; subject to the
  same prompt injection screening as standards artifacts (see rr-standards-plugin)
- **CI integration** — `forge:review` runs in GitHub Actions with access to PR diffs
  and repository contents; credentials must be scoped to read-only where possible
- **Version update mechanism** — `forge:update` modifies hook scripts and CLAUDE.md;
  update integrity must be verifiable

## Review Requirements

All changes to hook scripts and skill definitions are subject to the `hook-reviewer`
and `security-reviewer` agents within `rr-standards:review`.
