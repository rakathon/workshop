# Test Strategy — Forge Framework

_To be populated during the forge-plugin planning and implementation phases._

## Scope

| Area | What is tested |
|------|---------------|
| Hooks | Generation standards injection: correct language detection, correct standard path resolution, graceful degradation when rr-standards is unreachable |
| Hooks | Version enforcement: lag period evaluation, active-work detection, degraded mode on unreachable manifest |
| Skills | Behavioral accuracy: with/without-context eval benchmarks; PASS threshold ≥80% with-skill accuracy |
| Phase gates | Valid and invalid phase transitions; pre-condition enforcement |
| State schema | `.state.json` backward compatibility across versions |
| Review output schema | `forge:review` output conformance across all input types and check combinations |

## Approach

- **Hooks** require deterministic unit tests given their critical infrastructure role (a silently failing hook means standards are not enforced and no tool will detect the gap)
- **Skills** are tested using the with/without-context eval methodology established by rr-standards-plugin; `.evals.json` companion files alongside each standard
- **Integration** tests cover the full phase lifecycle from `forge:init` through `forge:review` on a representative repository

## Test Plans

_None yet. Added per epic as implementation proceeds._
