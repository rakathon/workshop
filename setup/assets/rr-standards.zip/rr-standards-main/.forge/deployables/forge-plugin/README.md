# Forge Framework

AI-accelerated software development process. Provides the workflow engine, skills,
hooks, and integrations that enforce organizational standards across all repositories.

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | What the framework must do and why |
| [requirements/technical.md](requirements/technical.md) | Development lifecycle phases, implementation requirements, constraints |
| [spec/README.md](spec/README.md) | Architecture overview and guiding principles |
| [spec/arch-decisions/](spec/arch-decisions/README.md) | ADR-001 through ADR-025 |
| [spec/interfaces/README.md](spec/interfaces/README.md) | Published interfaces (skills, hooks, state schema) |
| [test/README.md](test/README.md) | Test strategy, area plans, and eval benchmarks |
| [security/README.md](security/README.md) | Threat model, trust boundaries, and security controls |
| [privacy/README.md](privacy/README.md) | Data classification, handling, and retention |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Contributing Work Items

| Work Item | Type | Phase |
|-----------|------|-------|
| [forge-plugin](../../projects/forge-plugin/.state.json) | program | planning |
| [ai-pr](../../projects/ai-pr/.state.json) | initiative | discovery |
| [forge-init](../../projects/forge-init/.state.json) | epic | discovery |
