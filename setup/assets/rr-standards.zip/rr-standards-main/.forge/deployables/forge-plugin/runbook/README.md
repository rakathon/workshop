# Runbook — Forge Framework

_To be populated. Produced as part of the forge-plugin operations phase._

## Areas

| Area | Document | Status |
|------|----------|--------|
| Version enforcement failures | _(pending)_ | Not started |
| AI service outage (forge:review degraded mode) | _(pending)_ | Not started |
| Hook installation failures | _(pending)_ | Not started |
| Productivity Engineering override procedure | _(pending)_ | Not started |
