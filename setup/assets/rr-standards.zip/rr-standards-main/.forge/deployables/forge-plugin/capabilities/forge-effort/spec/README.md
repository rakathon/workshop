# forge-effort Capability Overview

The `forge-effort` capability is the foundation of the Forge workflow system. It provides
the scaffolding, state management, session persistence, and context injection that all
other Forge capabilities depend on.

---

## What This Capability Delivers

**Skills:**
- `forge:effort` — Creates and scaffolds a new work effort (directories, `.state.json`, registry entry).
- `forge:status` — Reads `.state.json` and presents current effort state in a human-readable summary.
- `forge:pause` — Persists pause state to `.state.json` for session handoff.
- `forge:resume` — Restores pause state and re-injects context for the engineer picking up the work.

**Hooks:**
- `inject-workflow-context.sh` (SessionStart) — At every session start, injects the artifact routing
  table and current effort state into Claude's context. The primary mechanism for zero-overhead
  state recovery.
- `route-to-skills.sh` (UserPromptSubmit) — Detects workflow events in the engineer's prompt and
  re-injects targeted routing context. Compensates for long sessions where SessionStart output has
  scrolled out.
- `phase-context.sh` (PreToolUse) — Before any write to `.forge/efforts/`, informs Claude whether
  the write is typical for the current phase. Never blocks. Always exits 0.
- `update-workflow-state.sh` (PostToolUse) — After any write to `.forge/efforts/`, detects the
  artifact type and updates `.state.json` and `.forge/efforts/README.md` automatically.

**CLAUDE.md content:**
- The forge-managed Tier 1 section (~60-80 lines) written by `forge:init`. Contains the conceptual
  model of Forge, the terse intent recognition list, and the before-write rule. Always present in
  context for the entire session.

---

## When to Use This Capability

**Use `forge:effort`** when starting any new unit of work that should be tracked — from a one-line
bug fix (subtype: patch) to a multi-repo initiative (full-tier). The skill is optional; Claude
will scaffold the effort conversationally when the engineer describes the scope.

**Use `forge:status`** when the engineer needs a summary of current phase, artifact inventory,
open decisions, and next actions. Equivalent to Claude reading `.state.json` and summarizing —
the skill is the explicit invocation path for the same behavior.

**Use `forge:pause`** at the end of a session when work is mid-task and the engineer wants to
hand off cleanly. Records enough context for the next session to resume without reconstruction.

**Use `forge:resume`** at the start of a session after a pause. Equivalent to the SessionStart
hook's automatic restoration — the skill provides the explicit path for cases where the engineer
wants to explicitly trigger the context injection.

---

## Key Design Decisions

### ADR-001: Three-Tier CLAUDE.md Context Design

Forge guidance is split across three tiers to preserve context budget. Tier 1 (always-on
CLAUDE.md section) gives Claude the conceptual model. Tier 2 (SessionStart hook output) provides
the routing table and current state at the beginning of each session. Tier 3 (UserPromptSubmit
hook output) re-injects targeted context when a workflow event is detected mid-session.

This split keeps the permanent CLAUDE.md footprint to ~60-80 lines while ensuring Claude always
has what it needs when it needs it.

See: [ADR-001](../../../../efforts/forge-workflow/spec/arch-decisions/ADR-001-three-tier-claude-md-context-design.md)

### ADR-002: Phase Gates Inform but Never Block Workflow Artifact Writes

The `phase-context.sh` hook exits 0 in all cases for workflow artifact writes. When a write
is atypical for the current phase (e.g., modifying a requirements file during implementation),
the hook emits informational context — it does not prevent the write. Post-approval modifications
are tracked in `.state.json` and reconciled at graduation, not blocked at edit time.

This decision rejects the original hard-gate model because software development is not waterfall.
The rigor is at the graduation boundary, not at the moment of edit.

See: [ADR-002](../../../../efforts/forge-workflow/spec/arch-decisions/ADR-002-phase-gates-inform-not-block.md)

### ADR-008: Capabilities Are User-Facing Features, Not Architectural Layers

This capability is named `forge-effort` — not `forge-workflow-core` or `forge-state-management` —
because the name must answer "what does an engineer do with this?" A capability named after an
architectural tier describes implementation, not value.

See: [ADR-008](../../../../efforts/forge-workflow/spec/arch-decisions/ADR-008-capabilities-are-user-facing-features.md)

---

## Specification Files

| File | Contents |
|------|----------|
| [state-schema.md](state-schema.md) | Complete `.state.json` schema with all forge-workflow extension fields, field-level documentation, and a fully-populated example |
| [hooks.md](hooks.md) | Detailed design for all four hooks: trigger, behavior, exit codes, performance limits, edge cases |
| [skills.md](skills.md) | Detailed design for forge:effort, forge:status, forge:pause, forge:resume |
| [arch-decisions/](arch-decisions/) | Architectural decisions made during this capability's design |

## Requirements Files

| File | Contents |
|------|----------|
| [requirements/business.md](../requirements/business.md) | Capability-level business requirements |
| [requirements/technical.md](../requirements/technical.md) | Capability-level technical requirements |
| [requirements/success-criteria.md](../requirements/success-criteria.md) | Measurable acceptance criteria |
