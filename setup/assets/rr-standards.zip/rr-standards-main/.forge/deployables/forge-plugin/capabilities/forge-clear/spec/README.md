# forge-clear — Design Overview

`forge:clear` is a single-responsibility skill: it deletes `.forge/EFFORT` and
prints a recovery hint. It has no knowledge of `.state.json`, effort phase,
tasks, or git history.

## Responsibility Boundary

| Skill | Owns |
|-------|------|
| `forge:clear` | Deleting `.forge/EFFORT` |
| `forge:effort` | Writing `.forge/EFFORT` when selecting or creating an effort |
| `forge:pause` | Writing `pauseState` to `.state.json`, committing, then deleting `.forge/EFFORT` |
| `forge:resume` | Restoring context and writing `.forge/EFFORT` for the resumed effort |

## Key Files

| File | Action |
|------|--------|
| `.forge/EFFORT` | Deleted (`rm -f`) |

## Design Documents

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:clear` detailed flow |
