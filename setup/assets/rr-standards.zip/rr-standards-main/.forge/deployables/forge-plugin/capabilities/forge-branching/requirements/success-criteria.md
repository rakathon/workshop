# Success Criteria — forge-branching

- [ ] `git commit` executed via the Bash tool on the default branch is blocked with
      exit code 2; a JSON diagnostic is emitted on stderr containing `type`,
      `blocked`, `reason`, `currentBranch`, `activeEffort`, and `nextAction`
- [ ] `git commit` executed via the Bash tool on a feature branch exits 0 without
      any diagnostic output
- [ ] `git push origin main` executed via the Bash tool on the default branch is
      blocked with exit code 2 and a JSON diagnostic
- [ ] `git status` executed via the Bash tool on the default branch exits 0 without
      any diagnostic output (not a commit/push command)
- [ ] `git log` executed via the Bash tool on the default branch exits 0 without
      any diagnostic output
- [ ] `FORGE_ALLOW_MAIN_COMMIT=1 git commit` on the default branch exits 0 (allowed)
      and writes an audit log entry to `.forge/audit/<timestamp>.json` containing
      `operation`, `reason`, `branch`, and `timestamp`; the `reason` field value is
      exactly `FORGE_ALLOW_MAIN_COMMIT=1 set by engineer` (per TR-2.2)
- [ ] `FORGE_ADMIN_OP=forge:init git commit` on the default branch exits 0 (allowed)
      and writes an audit log entry with `reason` equal to the `FORGE_ADMIN_OP` value
- [ ] The hook p50 latency is under 100ms measured on a repository with 100+ commits,
      on both a warm and cold filesystem cache
- [ ] `git push origin main` from a repository with the `pre-push.sh` hook installed
      is blocked with a message directing the engineer to open a PR and noting the
      `--no-verify` bypass path
- [ ] `git push origin main --no-verify` bypasses the `pre-push.sh` hook and is not
      blocked (standard git `--no-verify` behavior)
- [ ] `git push origin effort/my-feature` from any branch exits 0 without blocking
- [ ] The audit log file is created in `.forge/audit/` even if that directory does not
      yet exist

## Branch Name Format Validation (TR-7)

- [ ] `git commit` on a branch named `wip-stuff` is blocked with exit code 2; stderr
      contains a JSON diagnostic with `type: "branch_name_violation"`, `blocked: true`,
      `currentBranch: "wip-stuff"`, `allowedFormats` listing all 8 valid types, and
      `nextAction` containing a `git branch -m` rename instruction
- [ ] `git commit` on `Feature/auth` (uppercase) is blocked with exit code 2; the
      `currentBranch` field in the diagnostic reflects the exact branch name including
      the uppercase character
- [ ] `git commit` on `fix/auth-crash` exits 0 without any output (valid format)
- [ ] `git commit` on `effort/my-effort` exits 0 without any output (effort branches
      are always valid)
- [ ] `git commit` on `release/1.2.3` exits 0 (dots permitted in release slugs)
- [ ] `FORGE_SKIP_BRANCH_VALIDATION=1 git commit` on `wip-stuff` exits 0 without any
      output (bypass skips format validation)

## Push-Time Branch Alignment Warning (TR-9)

- [ ] `git push` with documentation-only commits on a `fix/` branch emits a warning
      to stdout containing `⚠️` and a suggestion starting with `docs/`; exit code is 0
- [ ] `git push` with feature-adding commits on a `fix/` branch emits a warning to
      stdout suggesting a `feature/` branch name; exit code is 0
- [ ] `git push` on an `effort/` branch does not trigger the alignment check; exit 0
      with no warning
- [ ] `FORGE_SKIP_BRANCH_VALIDATION=1 git push` skips the alignment check entirely;
      exit 0 with no output
- [ ] `git push` when the `claude` binary is unavailable or times out (>10 seconds)
      exits 0 silently; the push is not blocked or warned

## Branch Type Inference via CLAUDE.md (TR-8)

- [ ] Conversational prompt "let's fix the crash in the auth flow" (no active effort)
      results in branch `fix/auth-flow-crash` being created and checked out
- [ ] Conversational prompt "we need to add a favorites endpoint" results in a branch
      starting with `feature/`
- [ ] Conversational prompt describing urgent production issue results in a branch
      starting with `hotfix/`
- [ ] Ambiguous prompt that cannot be classified results in a single clarifying question
      listing at least 4 branch types; no branch is created until the engineer responds
- [ ] When an active effort exists, conversational work prompts do not trigger branch
      creation; the effort branch remains checked out
