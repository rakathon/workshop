# forge-about-me — Design Overview

`forge:about-me` is a single interactive skill with no sub-agents and no
Forge effort dependency. Its design is shaped by two constraints:

**Constraint 1: Workshop efficiency.** The skill runs in a workshop setting
where participants are time-constrained. Every question must earn its place —
anything inferable from provided materials must be inferred, not asked.

**Constraint 2: Surface portability.** The skill is distributed as a Forge
plugin available to both Claude Code users (terminal, IDE, Desktop app with
a project loaded) and pure Desktop/Chat users. Output behaviour must adapt
to the surface without requiring the user to understand the distinction.

## Skill Design

See [skills.md](skills.md) for the full skill design including flow, surface
sections, and output format specification.

## Key Design Decisions

**Why no runtime surface detection?**
Any programmatic probe is unreliable for distinguishing surfaces. Bash tool
availability cannot tell Claude Code apart from a Desktop session with an
MCP server attached. `claude --version` cannot distinguish them if both are
installed on the same machine. Claude already knows which surface it is
running on from its own system context — the same pattern used by the
Anthropic skill-creator, which handles this with named surface sections at
the bottom of the skill rather than a detection step. This is simpler and
always correct.

**Why `~/.claude/CLAUDE.md` and never the project CLAUDE.md?**
Personal context (who I am, how I communicate) has no place in a project
repo. Project `CLAUDE.md` files are checked in, shared with the team, and
scoped to that codebase. The user-level `~/.claude/CLAUDE.md` is the correct
home — it applies to all Claude Code sessions automatically and is never
committed to version control.

**Why write directly without asking, rather than offering a choice?**
In Claude Code there is only one correct destination for personal context:
`~/.claude/CLAUDE.md`. Presenting a choice implies `about-me.md` is an
equally valid option, which it isn't — `about-me.md` is for surfaces where
`~/.claude/CLAUDE.md` cannot be written.

**Why `about-me.md` as the filename?**
The skill is named `forge:about-me`. Using the same root for the output
file makes the connection obvious to users and predictable for documentation.
`my-context-profile.md` is descriptive but opaque to someone who just ran
`/forge:about-me` and wants to find what was created.
