# Security — forge-graduate

## Trust Boundary

`forge:graduate` runs as an isolated worker sub-agent within the engineer's Claude Code
session. It reads from and writes to the local repository only. It makes no network calls
and handles no credentials.

## Primary Security Surfaces

- **Canonical documentation writes** — the skill writes to `.forge/deployables/<name>/`
  and `.forge/products/<name>/`, which are authoritative documentation directories. Only
  content derived from the graduating effort's artifacts may be written. The skill must
  not write content outside the canonical paths for the named deployables and products.

- **Registry modification** — the skill removes a row from `.forge/efforts/README.md`. It must
  remove only the target effort's row; no other registry content may be altered.

- **Provenance comment injection** — the `<!-- graduated-from: -->` comment is written
  into canonical Markdown documents. This content is static and derived only from the
  effort ID and the graduation timestamp. It must not interpolate arbitrary content from
  effort artifacts.

- **Effort ID as input** — the effort ID is passed by the orchestrator. The skill uses
  the effort ID to construct file paths. Path traversal must be prevented: the skill must
  validate that the resolved effort directory path is within `.forge/efforts/` before
  reading any files.

## Prompt Injection Risk

Effort artifacts (requirements, specifications) are written by engineers and agents
during the development process. They may contain Markdown that would be interpreted as
instructions if injected into a model context. The graduation skill reads these artifacts
to extract their structured content (sections, headings, body text) and writes that
content to canonical documents.

The `rr-standards:review` `security-reviewer` agent checks all PRs that modify skill
definitions for prompt injection risk. Any change to the graduation skill's SKILL.md
triggers this review.

## Scope Restriction

The skill must not modify any files outside these paths:

- `.forge/efforts/<effort_id>/.state.json` — graduation state update
- `.forge/efforts/README.md` — registry row removal
- `.forge/deployables/<name>/` — canonical deployable documentation (named in `.state.json`)
- `.forge/products/<name>/` — canonical product documentation (named in `.state.json`)
- `.forge/spec/arch-decisions/` — ADR provenance field addition only (no other modifications)

Writes to any path not in this list are a security violation and must not occur.

## Review Requirements

All PRs that modify the `forge:graduate` SKILL.md or skill implementation trigger the
`security-reviewer` agent in `rr-standards:review`.
