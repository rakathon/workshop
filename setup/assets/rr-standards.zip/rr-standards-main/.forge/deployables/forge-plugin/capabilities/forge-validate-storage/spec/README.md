# Spec — forge-validate-storage

| Artifact | Description |
|----------|-------------|
| [skills.md](skills.md) | Skill interface spec — steps, checks, output format |

**Standards loaded at runtime:** `standards/storage/<type>.md` (PostgreSQL, DynamoDB, Redis, OpenSearch, or Browser Extension)

**Input artifacts consumed:**
- `spec/storage/*.md` — physical schema files produced by `forge:spec-storage`
- `spec/storage/query-patterns.md` — for index-to-pattern cross-referencing (optional)
- `spec/storage/logical-schema.md` — for entity relationship context (optional)

**Output:** Inline session report only — no files written.

**Consumed by:** Engineer — this is a pure editing aid.
