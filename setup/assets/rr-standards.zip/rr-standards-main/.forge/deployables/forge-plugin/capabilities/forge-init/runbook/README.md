# Runbook — forge-init

Operational procedures for the forge-init deliverables: the three skills and two hooks.

---

## Procedures

### forge:init Fails — Plugin Not Found

**Symptom:** `forge:init` stops with "The Forge plugin does not appear to be installed."

**Cause:** No `plugin.json` found under `~/.claude/plugins/cache/` matching `*/forge/*`.

**Resolution:**
1. Install the plugin: `/plugin install forge@rr-standards`
2. Re-run `forge:init`

If `forge:pin` has been run first, install via the local marketplace:
`/plugin install forge@forge-local`

---

### forge:init Fails — Duplicate Managed Markers

**Symptom:** `forge:init` stops with "CLAUDE.md already contains duplicate
forge:managed markers."

**Cause:** CLAUDE.md contains more than one `<!-- forge:managed:start -->` marker —
likely from a manual edit or a failed prior run.

**Resolution:**
1. Open `CLAUDE.md` and locate both marker blocks
2. Remove the duplicate block (keep the one with current content)
3. Ensure exactly one `<!-- forge:managed:start -->` / `<!-- forge:managed:end -->` pair
4. Re-run `forge:init`

---

### forge-version-check.sh Blocking Sessions

**Symptom:** Session start is blocked with "forge: ERROR — active version X <
forge_min_version Y."

**Cause:** `.forge/version` `active_version` is below `forge_min_version`. Most
commonly caused by manually editing `.forge/version` or clearing the plugin cache.

**Resolution — if no active implementation task:**
1. Run `forge:update` to migrate to the current pinned version

**Resolution — if an active implementation task is in progress:**
The hook should have emitted a warning (exit 0), not a block. If blocking:
- Check that `.forge/efforts/<id>/.state.json` has `currentPhase: "implementation"`
  and `phases.implementation.status: "in_progress"`
- If state is correct but the hook is still blocking, file a bug

---

### forge-version-check.sh Blocking on Expired Deadline

**Symptom:** Session start is blocked with "forge: ERROR — forge vN support ended on
DATE."

**Cause:** The mandatory upgrade deadline defined by Productivity Engineering in
`VERSIONS.json` has passed for the major version in this repository.

**Resolution:**
1. Run `forge:update` to migrate to the current version
2. Commit the resulting changes
3. If the repository has active in-progress MAJOR migrations, see the active work
   protection procedure below

**Productivity Engineering override (exceptional only):**
If a team cannot update before a deadline due to extenuating circumstances, PE can
extend the `mandatoryAfter` date in `VERSIONS.json`. This is a repository-level change
and must go through the normal PR process.

---

### forge:update Rolls Back — Migration Failed

**Symptom:** `forge:update` reports "Migration failed at step N — rolling back."

**Cause:** One of the nine migration steps failed (e.g., a settings.json write failed
due to a JSON syntax error, or a `.state.json` migration encountered a malformed state
file).

**Resolution:**
1. Check the error message — it identifies the specific failed step
2. Verify the files listed in the rollback summary are in their pre-migration state
3. Fix the underlying cause (e.g., repair malformed `.state.json`)
4. Re-run `forge:update`

If rollback itself fails, manually restore the files from git:
```bash
git checkout -- .forge/version .claude/settings.json CLAUDE.md
```

---

### forge:update Blocked — Active MAJOR Migration Work

**Symptom:** `forge:update` refuses with "Cannot apply MAJOR migration — active
implementation tasks found: [IDs]."

**Cause:** One or more `.forge/efforts/<id>/.state.json` files have
`currentPhase: "implementation"` and `phases.implementation.status: "in_progress"`.
`forge:update` refuses to apply MAJOR migrations while implementation is in progress
to avoid corrupting in-flight state.

**Resolution — preferred:**
1. Complete or pause the active work items before running `forge:update`

**Resolution — if the work item is abandoned:**
1. Manually set `phases.implementation.status` to `"paused"` or `"complete"` in the
   relevant `.state.json` files
2. Re-run `forge:update`

---

### Standards Not Being Injected at Generation Time

**Symptom:** Writing a `.go` or `.ts` file in Claude Code does not appear to load
the language guide.

**Cause options:**
- Hook not registered in `.claude/settings.json`
- Hook path in `settings.json` points to a non-existent SHA (plugin cache evicted)
- Language guide absent from plugin cache for this language
- Repository has `coding_standards=exempt` in `.forge/compliance`

**Diagnosis:**
```bash
# Check hook is registered
cat .claude/settings.json | grep inject-generation-standards

# Check hook script exists at the registered path
ls <path-from-settings.json>

# Check language guide exists
ls ~/.claude/plugins/cache/<marketplace>/forge/<sha>/languages/go/
```

**Resolution:**
1. If hook path is broken: re-run `forge:init` (merge mode refreshes the hook
   registration) or run `forge:update` if the plugin version changed
2. If guide is absent: file a standards gap report — the language guide must be
   authored in rr-standards
3. If repository is exempt and should not be: remove or update `.forge/compliance`
