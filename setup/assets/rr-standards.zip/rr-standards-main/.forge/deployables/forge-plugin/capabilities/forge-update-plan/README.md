# forge-update-plan

Task completion tracking for the Forge AI-accelerated development framework.
Delivers the `forge:update-plan` skill that marks implementation tasks complete in
`plan/tasks.md` and `.state.json`, records commit SHA for permanent traceability,
and queues Jira sync.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:update-plan` | Skill | Interactive | Run after `forge:commit` to mark a task complete |

**`forge:update-plan`** performs four actions atomically: marks the task `[x]` in
`plan/tasks.md` with the commit SHA appended inline, moves the task from
`remainingTasks` to `completedTasks` in `.state.json`, sets `jira.syncStatus =
"pending"` to trigger Jira sync, and creates a follow-up chore commit recording
the completion.

Task auto-detection reads the most recent commit message and git notes for a
`TASK-NNN` reference — engineers can typically run `forge:update-plan` with no
arguments immediately after `forge:commit`.

## Why This Capability Exists

Without a dedicated skill, engineers frequently forget to update `plan/tasks.md`
and `.state.json` after committing implementation work. This creates plan drift:
tasks appear incomplete in the plan when they are done in the code. `forge:verify`,
`forge:status`, and Jira sync all depend on plan accuracy — if the plan drifts,
downstream skills produce incorrect results. This capability closes that gap by
making plan updates the natural last step of every commit.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-commit](../forge-commit/) | Commits implementation work; calls `forge:update-plan` to mark the task complete. |
| [forge-plan](../forge-plan/) | Generates `plan/tasks.md` that forge:update-plan updates. |
| [forge-verify](../forge-verify/) | Reads `completedTasks` and SHA links written by forge:update-plan to verify implementation. |
| [forge-effort](../forge-effort/) | Provides the effort directory and `.state.json` that forge:update-plan references. |

## Implementation Location

`plugins/forge/skills/update-plan/` — `forge:update-plan` SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| `requirements/business.md` | Business drivers for plan accuracy and traceability |
| `requirements/technical.md` | Technical requirements for each update step |
| `spec/README.md` | Skill design overview |
| `spec/skills.md` | Detailed skill specification |
