# forge-spec-messaging

Co-authors event and message contracts during the discovery phase. Guides the engineer
through the five decisions required for each event (schema, producer, consumers, ordering,
idempotency), applies inline standard checks after each confirmation, and writes contracts
to `spec/messaging/`.

**Skill:** `forge:spec-messaging`
**Classification:** Orchestrator
**Part of:** spec-driven-development initiative (Initiative 3)
