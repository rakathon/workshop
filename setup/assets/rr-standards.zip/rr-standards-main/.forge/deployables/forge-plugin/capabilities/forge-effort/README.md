# forge-effort

Effort lifecycle management for the Forge AI-accelerated development framework.
Delivers the `forge:effort` skill and supporting hooks that create, track, and
maintain the state of work efforts from inception through graduation.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:effort` | Skill | Interactive | Manual invocation |
| `effort-state.sh` | Hook | Project | PostToolUse: Write, Edit |

**`forge:effort`** creates a new effort directory under `.forge/efforts/<name>/`
with the standard scaffold: `PLAN.md`, `.state.json`, `CLAUDE.md` guidance layer,
and `worktrees/` directory. Registers the effort in the Forge state registry and
sets the initial phase to `discovery`.

**`effort-state.sh`** fires after Write and Edit tool calls to automatically
update `.state.json` when effort artifacts change. Ensures state is always
consistent with on-disk content without requiring manual engineer invocation.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-promote](../forge-promote/) | Advances an effort through phases; depends on effort existing. |
| [forge-plan](../forge-plan/) | Generates PLAN.md inside an existing effort directory. |
| [forge-verify](../forge-verify/) | Runs quality loop against tasks within an effort. |
| [forge-graduate](../forge-graduate/) | Promotes completed effort artifacts to canonical docs. |

## Implementation Location

`plugins/forge/skills/effort/` — `forge:effort` SKILL.md and README.md
`plugins/forge/hooks/post-tool-use/effort-state.sh`

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview and key design decisions |
| [spec/skills.md](spec/skills.md) | `forge:effort` detailed design |
| [spec/hooks.md](spec/hooks.md) | `effort-state.sh` hook detailed design |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | Relevant ADRs |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
