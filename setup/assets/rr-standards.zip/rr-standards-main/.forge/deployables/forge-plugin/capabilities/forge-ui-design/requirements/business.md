# Business Requirements — forge-ui-design

Parent deployable: [forge-plugin](../../requirements/business.md)

<!-- graduated-from: design-system-integration at 2026-04-25T23:10:46Z -->

---

## BR-3: The Prototyping Skill Must Remain Low-Friction for the Design Team

The design team's primary concern is speed — they need to move from idea to running
prototype in minutes, not hours. Any redesigned skill must preserve or improve on the
current workflow's speed. Requiring the design team to learn Forge concepts or fill in
effort artifacts before prototyping would contradict this requirement. The skill's entry
point must be as simple as: describe what you want (or share a Figma node) → get running
code. Forge alignment is a structural concern for engineers building the skill; it must
be invisible to the design team using it.

## BR-4: There Must Be a Defined Path From Prototype to Production

Currently, prototypes produced by the design skill are disconnected from production
implementation. There is no standard for when a prototype is "good enough" to become
a production reference, no handoff format, and no skill that helps an engineer
implement from a design spec. `forge:ui-design` addresses this by conversationally
authoring a `ui-spec.md` that carries design decisions from exploration into
production implementation.

The discrete "promote this prototype" trigger within `forge:ui-design` (a step that
writes a finalized handoff record) is deferred to a follow-on effort. The `ui-spec.md`
template satisfies the structural handoff requirement.

## BR-7: The Design Team Must Be Able to Use Skills Without Knowing the Standards Framework

The design team uses Claude Code today to prototype but has no knowledge of SKILL.md
files, rr-standards taxonomy, or Forge. `forge:ui-design` must be usable by someone
who types a natural-language prompt like "let's design the UI" or "help me spec out
this page". The standards framework backing the skill is for engineers authoring and
maintaining it — not for the end users.
