# Technical Requirements — forge-spec-messaging

Parent: [business requirements](business.md)

---

## TR-1: Messaging Standard Loaded from Standards Directory

Loads `standards/messaging/contracts.md` from the plugin standards directory per ADR-003.
If absent, warns and continues with general messaging conventions.

## TR-2: Event Scope Confirmed Before Design Begins

When `--event <name>` is not provided, derives a proposed event list from requirements
and presents it to the engineer for confirmation. Design of individual contracts does not
begin until scope is confirmed. This prevents authoring contracts for the wrong events.

## TR-3: Five Decisions Elicited Per Event

For each event: (1) schema with field names and types, (2) producer identity, (3) named
consumers or explicit "unknown" marker, (4) ordering guarantee, (5) idempotency approach.
All five must be present before the contract file is written.

## TR-4: Inline Checks Fire Per Event After Confirmation

After the engineer confirms an event's decisions, five checks apply immediately: schema
defined, producer named, consumers identified or marked unknown, ordering stated, idempotency
documented. Violations propose a fix and offer to update before writing.

## TR-5: Non-Standard Choices Recorded with Rationale

When the engineer overrides a standard requirement, the rationale is recorded as an inline
comment in the contract file and the engineer is prompted to run `forge:adr`.

## TR-6: Contracts Written to Capability Canonical Path

Contracts are written to `<effort_dir>/spec/messaging/<event-name>.md` using
lowercase-with-hyphens filenames. `.state.json` is updated after writing:
`phases.discovery.artifacts.spec.messaging = "present"`.

## TR-7: Effort Directory Resolved from Argument or .state.json

`<effort_dir>` = `.forge/efforts/<effort-id>/`. If `<effort-id>` is not provided as an
argument, the skill resolves it from the active branch name or `.state.json`.
