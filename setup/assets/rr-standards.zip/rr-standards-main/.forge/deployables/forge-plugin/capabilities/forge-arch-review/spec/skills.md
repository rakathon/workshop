# forge:arch-review Skill Design
<!-- graduated-from: arch-review at 2026-05-04T20:02:05Z -->

Design for the `forge:arch-review` skill. The skill is an orchestrator that conducts
a pre-generation interview, runs `forge:validate` when needed, and generates a
self-contained HTML architecture review document.

Implementation: `plugins/forge/skills/arch-review/`

---

## forge:arch-review

### Classification

**Orchestrator** — runs in the engineer's main session

The skill is interactive: it conducts a question-by-question interview before
generating output. Running as an orchestrator (not an isolated worker) is therefore
necessary to maintain conversational context across the interview and generation steps.

### Phase Guard

Only runs when `currentPhase = "discovery"` and `phases.discovery.status != "approved"`.
Stops with a clear message if the phase guard fails, referencing `forge:reopen discovery`
(currently a stub).

### Outputs

Two files committed atomically (plus any interview spec files written during the session):

| File | Purpose |
|------|---------|
| `<effort_dir>/validation/report.md` | Machine-readable findings; gate artifact for `forge:promote` |
| `<effort_dir>/validation/arch-review.html` | Presentation document for the review meeting |
| `<effort_dir>/spec/rollout.md` | Rollout plan written during interview |
| `<effort_dir>/spec/cost.md` | Cost analysis written during interview |
| `<effort_dir>/spec/risks.md` | Risk mitigation written during interview |

Commit message: `docs(<effort-id>): generate architecture review package`

### Nine-Section HTML Layout

All nine sections are always present. Sections with no content render a gap notice.

| # | Section | `id` | Content | `.alt` background |
|---|---------|------|---------|------------------|
| 1 | Effort Overview | `overview` | Summary, BRs table, TRs table, delivery date callout | No |
| 2 | Validation Report | `validation` | Findings tiered: "Must Examine In Depth" / "Safe to Skip" | Yes |
| 3 | C4 Diagrams | `c4` | Mermaid C4Context (always) + C4Container (when multi-service) | No |
| 4 | Data Model | `data-model` | ERD + physical schema; governance classification or gap notice | Yes |
| 5 | Contracts | `contracts` | API accordion with auth badges; messaging cards (base class + extensions only) | No |
| 6 | Risk Mitigation | `risks` | Failure Modes, Abuse Scenarios, Cross-Cutting Security | Yes |
| 7 | Rollout | `rollout` | Phases, migration flag, feature flags, rollback approach | No |
| 8 | Cost Analysis | `cost` | Interactive AWS cost sliders (IIFE JS, no CDN) | Yes |
| 9 | Afterword | `afterword` | Future extensions, outstanding questions | No |

### Numbered Steps

```
Step 1: Resolve active effort (effort-required category)

Step 2: Phase guard — check currentPhase == "discovery" and status != "approved"

Step 3: Check forge:validate freshness
        - Report is current if validation/report.md exists AND is newer than all
          files under requirements/ and spec/ (excluding rollout.md, cost.md, risks.md)
        - If stale or absent: run forge:validate and wait for completion
        - If current: reuse existing report

Step 4: Read all discovery artifacts
        - requirements/, spec/ (recursively), validation/report.md, .state.json
        - Note presence flags: api_present, storage_present, messaging_present,
          adrs_present, data_mapping_present
        - Note existing interview spec files: rollout_spec_present, cost_spec_present,
          risks_spec_present
        - Findings terminology: **REQUIRED** = FAIL tier, **SUGGESTION** = CONCERN tier

Step 5: Pre-generation interview (one question at a time, with recommended answer)
        Topic 1: Rollout (skip if rollout_spec_present)
          — infer signals from artifacts, ask for confirmation/correction
          — write agreed answer to spec/rollout.md immediately
        Topic 2: Cost (skip if cost_spec_present)
          — infer AWS services, ask for variable parameters and baseline values
          — write agreed answer to spec/cost.md immediately
        Topic 3: Risk Mitigation (skip if risks_spec_present)
          — infer candidates from artifact presence, ask for confirmation
          — write agreed answer to spec/risks.md immediately
        Topic 4: Afterword (always ask — stored in memory only, no file written)
          — ask for future extensions and outstanding questions
          — if context pressure causes recall failure during §9: ask author to repeat
        — Conclude: ask "Ready to generate?" before proceeding

Step 6: Fetch AWS pricing via WebFetch tool
        — fetch canonical AWS pricing pages for each identified service
        — if pricing unavailable: note gap; §8 renders gap notice for that service

Step 7: Generate C4 diagram source
        — always: C4Context system diagram using actual entities from spec
        — when multi-service: C4Container diagram
        — use Mermaid C4Context / C4Container syntax (not generic flowchart)

Step 8: Generate HTML document (multi-pass, see Pass Strategy below)
        Pass 1: Write full HTML shell with CSS, nav, section placeholders
        Passes 2–10: Inject each section by replacing <!-- SECTION:id --> placeholder
          — use Edit tool for sections <4KB
          — use Python heredoc str.replace for sections ≥4KB

Step 9: Compute overall result badge
        — grep **Result:** from validation/report.md
        — map: PASS → badge-pass, PASS WITH CONCERNS → badge-concern,
               FAIL → badge-fail, unknown → badge-concern / UNKNOWN
        — replace RESULT_BADGE_CLASS and OVERALL_RESULT in nav using Edit tool

Step 10: Commit all artifacts
         — branch guard: warn if on main/master
         — mkdir -p validation/
         — git add validation/report.md validation/arch-review.html
           spec/rollout.md spec/cost.md spec/risks.md (|| true for missing files)
         — git commit -m "docs(<effort-id>): generate architecture review package"

Step 11: Print summary (REQUIRED / SUGGESTION counts from report.md)
```

### Pass Strategy for HTML Generation

```
Pass 1  — full HTML shell: DOCTYPE, head (CSS + Google Fonts @import + Mermaid CDN
          script), nav with 9 section anchors and RESULT_BADGE_CLASS placeholder,
          <main> with 9 <!-- SECTION:id --> placeholders, DOMContentLoaded Mermaid init

Pass 2  — §1 overview:     section-wrap (no alt), BRs table, TRs table
Pass 3  — §2 validation:   section-wrap alt, "Must Examine In Depth" + "Safe to Skip" tables
Pass 4  — §3 c4:           section-wrap, mermaid divs with C4Context/C4Container source
Pass 5  — §4 data-model:   section-wrap alt, ERD mermaid + physical schema + governance
Pass 6  — §5 contracts:    section-wrap, API accordion (details/summary) + messaging cards
Pass 7  — §6 risks:        section-wrap alt, Failure Modes / Abuse Scenarios / Cross-Cutting
Pass 8  — §7 rollout:      section-wrap, phases/migration/flags/rollback from rollout.md
Pass 9  — §8 cost:         section-wrap alt, AWS cost sliders (IIFE JS per driver)
Pass 10 — §9 afterword:    section-wrap, future extensions + outstanding questions
```

### Design System (PR #246)

```css
/* Typography */
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,400;0,8..60,600;1,8..60,300&family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&display=swap');

:root {
  --brand: #8529cd;
  --bg: #f9f6fe;
  --bg-alt: #ffffff;
  --green: #009470; --green-bg: #e6f6f2; --green-border: #b3e8da;
  --red: #b83232;   --red-bg: #fdf0f0;   --red-border: #f5c0c0;
  --yellow: #b08000; --yellow-bg: #fdf8e6; --yellow-border: #eedda0;
  --blue: #1d4ed8;  --blue-bg: #eff4ff;  --blue-border: #bfcfff;
}

/* Nav: sticky top, brand bottom border */
nav { position: sticky; top: 0; border-bottom: 2px solid var(--brand); }

/* Sections */
.section-wrap { padding: 72px 0; }
.section-wrap.alt { background: var(--bg-alt); }
.section-inner { max-width: 1100px; margin: 0 auto; padding: 0 2rem; }
h2.section-title { font-family: 'Playfair Display'; font-size: 28px;
                   border-bottom: 2px solid var(--brand); }
```

### Key Design Decisions

- **Orchestrator not worker**: the interview requires conversational context; isolated workers cannot hold a dialogue with the engineer
- **forge:validate integration**: staleness check uses Python (portable across macOS/Linux); excludes interview-written spec files from staleness calculation to prevent spurious re-runs
- **9 sections not 12**: C4 diagrams and rollout/cost/afterword replace the old 12-section layout's separate Security/Privacy/Standards Compliance sections — security is now co-located with contracts (per-endpoint), cross-cutting security is in Risk Mitigation
- **Messaging cards**: show base class + extensions only; pre-approved envelope fields (`message_id`, `event_name`, `event_version`, `produced_at_ms`, `trace_id`, plus base-class-specific fields) are not repeated as extension fields
- **IIFE pattern for cost JS**: prevents function name collisions when multiple sliders appear on the same page
- **Gap notices not placeholder text**: absent content (governance, rollout, cost, risks) renders a visible yellow gap notice — makes absent information visible rather than hiding it with "not applicable" prose

### Validation Findings Terminology

`forge:validate` uses `**REQUIRED**` and `**SUGGESTION**` labels. The arch-review skill maps these as:
- `**REQUIRED**` → FAIL tier, `.tag-fail` badge, "REQUIRED" display text
- `**SUGGESTION**` → CONCERN tier, `.tag-concern` badge, "SUGGESTION" display text

Priority tier rule:
- `**REQUIRED**` → "Must Examine In Depth" (always)
- `**SUGGESTION**` mentioning security/privacy/PII/auth/uncovered BR → "Must Examine In Depth"
- All other `**SUGGESTION**` → "Safe to Skip If Time-Limited"

### forge:promote Gate

`forge:promote` reads `validation/report.md` before advancing discovery to planning.
The gate applies to full-tier efforts only (lightweight efforts are exempt).
- `PASS` or `PASS WITH CONCERNS` → advancement permitted
- `FAIL` → advancement blocked until REQUIRED findings resolved
- Report absent → skill prompts engineer to run `forge:arch-review`

### Messaging Base Classes

Three pre-approved base classes understood by the skill:

| Class | When to use | Pre-approved fields |
|-------|-------------|---------------------|
| `Message` | Scheduled jobs, webhooks, server-to-server | message_id, event_name, event_version, produced_at_ms, trace_id |
| `UserInitiatedMessage` | Direct user actions in client apps | + client_context, member, visit_id, cdn, security |
| `ApiInitiatedMessage` | Public API publishing on behalf of client | + api_context (locale, user_agent, client_ip) |

Standards: `plugins/forge/standards/messaging/`
