# forge-clear

Clears the session-local active effort pointer so the engineer can work outside
the context of a specific effort. Makes no changes to effort state, artifacts,
or git history.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:clear` | Skill | Interactive | Manual invocation |

**`forge:clear`** deletes `.forge/EFFORT` if it is present, then prints a
recovery hint. The effort directory and `.state.json` are left completely
untouched. The engineer can reactivate the effort at any time by running
`forge:effort` (to select it from a list) or `forge:resume` (to restore a
paused session).

## Relationship to forge:pause

`forge:pause` is the full handoff flow: it synthesizes a context summary, writes
`pauseState` to `.state.json`, commits the change, and then deletes `.forge/EFFORT`.

`forge:clear` only does the last part — deleting `.forge/EFFORT`. Use it when you
want to step away from an effort context without recording a pause checkpoint.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-effort](../forge-effort/) | Writes `.forge/EFFORT` when selecting an effort; `forge:clear` removes it |
| forge-pause _(part of forge-effort)_ | Full handoff that also clears `.forge/EFFORT` after committing pause state |

## Implementation Location

`plugins/forge/skills/clear/` — `forge:clear` SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Why this capability exists |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable acceptance criteria |
| [spec/README.md](spec/README.md) | Design overview |
| [spec/skills.md](spec/skills.md) | `forge:clear` detailed design |
| [test/README.md](test/README.md) | Test strategy |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
