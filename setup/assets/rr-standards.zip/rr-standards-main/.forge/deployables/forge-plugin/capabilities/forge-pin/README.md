# forge-pin

Optional version pinning for the Forge AI-accelerated development framework.
Locks a repository to a specific Forge plugin version so all contributors use
the same behavior regardless of what is globally installed.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:pin` | Skill | Interactive | Manual invocation |

**`forge:pin`** creates or updates `.claude-plugin/marketplace.json` with a
cryptographic pin (semver tag + commit SHA) for the Forge plugin. Updates
`.claude/settings.json` to activate the local marketplace. Syncs
`forge_min_version` in `.forge/version` if the file already exists.

Pinning is optional — repositories without a pin load whatever Forge version the
engineer has globally installed. When used, `forge:pin` is order-independent with
`forge:init`.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-init](../forge-init/) | Reads the pin at init time to populate `forge_min_version`. Order-independent. |
| forge-update _(separate branch)_ | Run after `forge:pin --version X` to apply configuration migrations. |

## Implementation Location

`plugins/forge/skills/pin/` — `forge:pin` SKILL.md and README.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/technical.md](requirements/technical.md) | Technical requirements (TR-10) |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Design overview |
| [spec/skills.md](spec/skills.md) | `forge:pin` detailed design |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations and pin integrity model |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
