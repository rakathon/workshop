# Architecture Decisions — forge-graduate

## Applicable Decisions

| ADR | Title | Relevance |
|-----|-------|-----------|
| [ADR-002](../../../../../../../../.forge/efforts/forge-workflow/spec/arch-decisions/ADR-002-phase-gates-inform-not-block.md) | Phase Gates Inform but Never Block Workflow Artifact Writes | Graduation is the rigor point that ADR-002's permissive edit-time model defers to. Post-approval modifications accumulate throughout the effort; graduation is where they are reconciled. |

## Summary

ADR-002 establishes that phase gates never block writes to workflow artifacts. The
consequence for graduation is that modifications to approved artifacts may accumulate
throughout the effort — in the implementation phase, in planning, at any point. These
modifications are tracked in `.state.json` by the PostToolUse hook.

`forge:graduate` is the point where this accumulated record is acted on. Before writing
any canonical documentation, the skill reads the full list of post-approval modifications
and includes them in the graduation report. The graduated canonical document reflects the
final state of the effort's artifacts, including all modifications. The engineer sees a
clear record of what changed after approval, and that record is committed alongside the
graduation changes.

This design places rigor at the promotion boundary rather than at the moment of edit —
which is the explicit consequence stated in ADR-002.
