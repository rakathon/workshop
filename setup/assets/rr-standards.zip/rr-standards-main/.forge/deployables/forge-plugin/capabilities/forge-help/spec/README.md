# forge-help Spec

Design artifacts for the `forge:help` capability.

## Contents

| File | Description |
|------|-------------|
| [skills.md](skills.md) | Detailed skill specification — catalog mode, Q&A mode, stub filtering, effort-state boundary |
| `arch-decisions/` | ADRs scoped to this capability (currently none) |

## Design Summary

`forge:help` is a read-only orchestrator skill with no side effects. It uses AGENTS.md
files as its navigation layer and never hardcodes lists of skills, hooks, or standards.
Two key design principles:

1. **Dynamic, not static** — every catalog entry and every Q&A answer is derived from
   reading the plugin's own documentation at execution time. The skill cannot go stale
   because it reads what is actually installed.

2. **Synthesis, not enumeration** — the skill reads source artifacts and produces a
   synthesized plain-English answer. The engineer never sees internal file paths or raw
   artifact content.

## Key Design Decisions

### AGENTS.md as the sole discovery layer

Hardcoding skill lists in the help skill would require the help skill to be updated
every time a new skill ships. Using AGENTS.md as the navigation layer delegates that
responsibility to the AGENTS.md authors — consistent with how all other Forge skills
navigate the plugin.

### No sub-agents

`forge:help` runs inline in the main session. The catalog and Q&A workloads are
read-heavy but not parallelizable in a way that justifies sub-agent overhead. Spawning
sub-agents for a read-only, lightweight task would add latency and context fragmentation
for no benefit.

### Effort state is explicitly out of scope

`forge:help` is a documentation layer, not a state inspector. Reading `.state.json`
would blur the boundary between "what does Forge do?" and "what is my effort's current
state?". The former belongs to `forge:help`; the latter belongs to `forge:status`. This
boundary keeps each skill's responsibility sharp and prevents `forge:help` from needing
access to effort directories.

## Related Documentation

- [forge:status](../../../forge-effort/) — handles effort-state questions that `forge:help` deflects
- [forge-plugin standards](../../../../spec/) — deployable-level architectural standards
