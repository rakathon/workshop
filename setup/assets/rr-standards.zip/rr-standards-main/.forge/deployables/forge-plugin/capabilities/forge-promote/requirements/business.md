# Business Requirements — forge-promote

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-6 (traceability), BR-10 (consistent process)

## BR-1: Phase Completion Must Be Explicitly Recorded for Traceability

An effort that moves from discovery to implementation without any record of when
discovery was considered complete is harder to audit, harder to hand off, and harder
to reason about. Recording phase approvals in `.state.json` gives the team a
shared, machine-readable record of progress that can be surfaced by `forge:status`
and `.forge/efforts/README.md` without traversing every artifact.

## BR-2: Advisory Readiness Check Surfaces Gaps Without Blocking Progress

Engineers may deliberately promote before all artifacts are complete — for example,
starting a spike implementation before design is fully documented. The skill must
surface what is missing so the engineer can make an informed decision, but the
decision to proceed is always theirs.

## BR-3: Phase Artifacts Remain Editable After Promotion

Promoting a phase does not lock its artifacts. Requirements, specs, and plans must
remain editable at any point regardless of phase status. Promotion records intent
and progress; it does not enforce a workflow boundary.

---
Success criteria: [success-criteria.md](success-criteria.md)
