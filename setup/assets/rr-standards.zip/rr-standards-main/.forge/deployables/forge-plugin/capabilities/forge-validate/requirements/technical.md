# Technical Requirements — forge-validate

Parent business requirements: [requirements/business.md](business.md)
Skill design spec: [spec/skills.md](../spec/skills.md)

---

## TR-1: Artifact Loading (← BR-1, BR-2)

The validate worker must load all discovery artifacts from the effort directory:

- `requirements/business.md`
- `requirements/technical.md`
- `spec/api/*.yaml` (all files matching the glob)
- `spec/storage/*.md` (all files matching the glob)
- `spec/messaging/*.md` (all files matching the glob)
- `spec/arch-decisions/*.md` (all files matching the glob)

Artifact loading must be tolerant of absent optional artifacts — if no files match
a glob (e.g., no `spec/api/` directory exists), that domain is skipped and its
checks are marked "not applicable" in the report. Only `requirements/business.md`
is required; the orchestrator pre-invocation step (not the worker) enforces its
presence before spawning.

**Acceptance criteria:**
- Worker loads all present artifacts before beginning any check.
- Missing optional artifact directories produce "not applicable" check entries, not errors.
- A missing `requirements/technical.md` produces a CONCERN finding, not a FAIL.

---

## TR-2: Parallelization Threshold (← BR-3)

After loading artifacts, the worker must count the total number of lines across all
loaded files.

- If total line count > 1,000: spawn four internal analysis agents in parallel
  (see TR-3 through TR-6 for what each agent checks). Wait for all four to complete
  before synthesizing results.
- If total line count ≤ 1,000: run all checks as a single sequential pass in the
  worker session.

The threshold is evaluated on loaded content, not file sizes on disk.

**Acceptance criteria:**
- Given artifacts totaling 1,200 lines, four sub-agents are spawned.
- Given artifacts totaling 800 lines, no sub-agents are spawned.
- Both paths produce identical `validation/report.md` structure.

---

## TR-3: Requirements Traceability Check (← BR-1)

For each BR-* identifier in `requirements/business.md` and each TR-* identifier in
`requirements/technical.md`, at least one spec artifact must reference or address it.

**Coverage rules:**
- A spec artifact "covers" a requirement if it contains any content that can
  reasonably be traced to that requirement's intent (not merely a literal string
  match of the identifier).
- Uncovered BRs → FAIL finding (severity: REQUIRED).
- Uncovered TRs → CONCERN finding (severity: SUGGESTION).
- If `requirements/technical.md` is absent: skip TR coverage check; emit a SUGGESTION
  noting that technical requirements have not been elaborated.

When run via internal agents: the `requirements-traceability-agent` receives all
BRs, all TRs, and summaries of all spec artifacts. It returns a coverage map:
`{req_id: [covering_artifact, ...], uncovered: [req_id, ...]}`.

**Acceptance criteria:**
- Any BR with no covering spec artifact produces a REQUIRED finding.
- Any TR with no covering spec artifact produces a SUGGESTION finding.
- All uncovered requirements are listed individually in the report.

---

## TR-4: Standards Compliance Check (← BR-1)

For each spec domain present in the effort's `spec/` directory, load and apply the
applicable standard from the Forge plugin standards directory. Only load standards
for domains that are actually present.

| Spec domain | Applicable standard | Standard path |
|-------------|---------------------|---------------|
| `spec/api/*.yaml` | REST API standard | `standards/api/rest/` (all sub-files) |
| `spec/storage/*.md` | Storage standard (type-specific) | `standards/storage/<type>.md` |
| `spec/messaging/*.md` | Messaging contracts standard | `standards/messaging/contracts.md` |

**Compliance findings:**
- Violations of the applicable standard → REQUIRED finding.
- Advisory deviations → SUGGESTION finding.
- If a standard file is not found in the plugin directory: emit a SUGGESTION warning
  that the standard could not be loaded; do not produce false REQUIRED findings.

When run via internal agents: `api-standards-agent` receives `spec/api/*.yaml` and
the REST standard path; `storage-standards-agent` receives `spec/storage/*.md` and
the applicable storage standard path. Each returns `findings[]`.

**Acceptance criteria:**
- No standards are loaded for domains absent from `spec/`.
- A missing standard file produces a SUGGESTION, not a REQUIRED finding.
- Each violation is attributed to the specific artifact file and line (where possible).

---

## TR-5: Cross-Spec Consistency Check (← BR-1)

Identify conflicts between spec artifacts within the same effort. A conflict is a
case where one artifact asserts something that another artifact contradicts or
requires something that another artifact does not provide.

**Example conflicts to detect:**
- An API endpoint writes to a storage field that does not exist in the storage schema.
- A messaging event references an entity type not defined in the storage schema.
- A TR declares a performance SLA that no spec artifact addresses.
- Two spec artifacts define different schemas for the same named entity.

**Conflict findings:**
- Each conflict → REQUIRED finding identifying the two artifacts and the nature of
  the conflict.

When run via internal agents: `cross-spec-consistency-agent` receives all spec
artifacts and returns `conflicts: [{artifact_a, artifact_b, description}]`.

**Acceptance criteria:**
- A conflict between `spec/api/` and `spec/storage/` produces a REQUIRED finding.
- No false positives when a single spec artifact is present (no cross-spec check
  possible with only one artifact).

---

## TR-6: ADR Quality Check (← BR-1)

For each ADR file in `spec/arch-decisions/*.md`, verify that the following sections
are present:

- `## Context` (or `Context`)
- `## Decision` (or `Decision`)
- `## Alternatives` (or `Alternatives Considered`)
- `## Consequences` (or `Consequences`)

**ADR findings:**
- Missing section(s) in any ADR → SUGGESTION finding (severity: SUGGESTION) naming
  the file and the missing sections.
- An ADR with all four sections present: no finding.

**Acceptance criteria:**
- An ADR missing `## Alternatives` produces a SUGGESTION finding.
- An ADR with all four sections produces no finding for that file.

---

## TR-7: Output Format — Grep-Extractable Result (← BR-2, BR-4)

The output file must be `validation/report.md` within the effort directory.

**Required format:**
```
**Result:** PASS | PASS WITH CONCERNS | FAIL

## <Check Name>

<findings for this check>
```

The `**Result:**` line must be the first non-blank line of the file. It must
contain exactly one of: `PASS`, `PASS WITH CONCERNS`, `FAIL`. No other content
may appear before this line.

Each finding must have an explicit severity label: `**REQUIRED**` or `**SUGGESTION**`.

**Acceptance criteria:**
- `grep '^\*\*Result:\*\*' validation/report.md` returns exactly one line.
- The returned line ends with one of the three valid values.
- Every finding in the report has a severity label.

---

## TR-8: Worker-Only Execution; Orchestrator Updates State (← BR-2)

`forge:validate` runs as a worker spawned by an orchestrator pre-invocation check.
The worker does not update `.state.json` directly. The orchestrator reads the
`**Result:**` line from `validation/report.md` after the worker completes, then
updates `.state.json`:

```json
"phases": {
  "validation": { "status": "passed" | "passed_with_concerns" | "failed" }
}
```

The worker's only state side-effect is writing `validation/report.md` and committing it.

**Orchestrator pre-invocation checks:**
1. Confirm `currentPhase = "discovery"` and `phases.discovery.status != "approved"`.
2. Confirm `requirements/business.md` exists.
3. Check for an active checkpoint in `.state.json`.
4. Spawn the worker.
5. After completion, read `**Result:**` and update `.state.json`.
6. Present the result to the engineer.

**Acceptance criteria:**
- The worker does not write to `.state.json`.
- The orchestrator updates `phases.validation.status` after the worker completes.
- If the worker fails to produce `validation/report.md`, the orchestrator surfaces
  the failure and sets `phases.validation.status = "failed"`.

---

## TR-9: Result Computation Rules (← BR-1)

The overall result is computed from all findings across all checks:

| Condition | Result |
|-----------|--------|
| Any finding with severity REQUIRED | FAIL |
| No REQUIRED findings; one or more SUGGESTION findings | PASS WITH CONCERNS |
| No findings at all | PASS |

**Acceptance criteria:**
- A single REQUIRED finding produces `**Result:** FAIL` regardless of SUGGESTION count.
- Zero findings produces `**Result:** PASS`.
- Only SUGGESTION findings produces `**Result:** PASS WITH CONCERNS`.
