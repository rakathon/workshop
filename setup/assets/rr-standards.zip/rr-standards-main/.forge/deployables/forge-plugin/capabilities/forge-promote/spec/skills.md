# forge:promote Skill Design

Design for the `forge:promote` skill. The skill is interactive, runs as an orchestrator
in the engineer's Claude Code session, and uses Claude Code tools (Read, Write, Bash)
for all file and git operations.

Related: [forge-arch-review skill design](../../forge-arch-review/spec/skills.md) |
[forge-verify skill design](../../forge-verify/spec/skills.md)

Implementation: `plugins/forge/skills/promote/`

---

## forge:promote

### Purpose and Scope

`forge:promote` advances an effort from its current phase to the next phase in the
defined sequence: `discovery → planning → implementation → verification → closed`.
It executes the promotion ritual defined in ADR-004: a five-step sequence that checks
readiness, surfaces context, presents a summary, requires explicit confirmation, and
produces an auditable checkpoint commit.

This skill is the only mechanism for advancing effort phases. Phase advancement must
not happen as a side effect of artifact creation or any hook. `forge:promote` is
the deliberate act; hooks are informational.

### Arguments

`forge:promote [<effort-id>] [--target <phase>]`

- `<effort-id>` — Optional. The ID of the effort to advance. If omitted,
  `forge:promote` auto-detects the active effort from branch name or registry.
- `--target <phase>` — Optional. Advance to the named phase, approving all
  intermediate phases in one operation. If omitted, advances exactly one step
  (current → next). Valid phases: `discovery`, `planning`, `implementation`,
  `verification`, `review`, `qa`, `deployment`.
  - If `targetPhase` is unknown: stop with an error listing valid phases.
  - If `targetPhase` is at or before `currentPhase`: **exit silently** (no-op).
    This is the normal outcome when calling skills (forge:plan, forge:commit,
    forge:verify) invoke `forge:promote --target X` and the effort has already
    advanced past X.
- No `--force` or `--skip` flags. The confirmation step cannot be bypassed.

### Preconditions

- **PC-1:** The effort directory exists at `.forge/efforts/<effort-id>/`
- **PC-2:** The effort's `.state.json` is present and readable
- **PC-3:** The effort's `currentPhase` is not `"closed"` (closed efforts cannot
  be advanced)
- **PC-4:** `forge:arch-review` has been run before invoking `forge:promote` for
  the discovery → planning transition on full-tier efforts (enforced by readiness
  check, not as a precondition check)

---

### [orchestrator-only] Ritual Steps

`forge:promote` runs entirely as an orchestrator. It does not spawn sub-agents.
All five steps execute in a single session with the engineer.

#### Step 1: Compute Gap and Determine Target

Read `.state.json`. Extract `currentPhase`.

```
PHASE_SEQUENCE = [discovery, planning, implementation, verification, review, qa, deployment]
```

**With `--target <phase>`:**
- If `targetPhase` is not in `PHASE_SEQUENCE`: stop with an error listing valid phases.
- If `targetPhase` is at or before `currentPhase`: **exit silently** — no changes,
  no output. (Expected no-op when calling skills have already advanced the effort.)
- Otherwise: `gap` = all phases from `currentPhase` up to (not including) `targetPhase`.

**Without `--target`:**
- If `currentPhase` is `deployment`: stop — "This effort is already at the final phase."
- `targetPhase` = next phase after `currentPhase`; `gap` = `[currentPhase]`.

---

#### Step 2: Advisory Readiness Checks (Non-Blocking, Per ADR-031)

For each phase in the gap, show advisory artifact status. These are informational —
the engineer can proceed regardless.

**discovery in gap:**
- `requirements/business.md` — present or absent
- `requirements/technical.md` — present or absent
- `spec/` artifact types — which are present (api, storage, messaging)
- **Validation gate:** if `validation/report.md` is absent:
  > "No validation report found. Run `forge:validate` before advancing out of
  > discovery? (yes/no/skip)"
  - **yes**: invoke `forge:validate` inline and wait for its report, then continue
  - **no/skip**: note the absence and continue without blocking

**planning in gap:**
- `plan/tasks.md` — present or absent; task count if present

**implementation in gap:**
- Completed vs. remaining task count (advisory only — does not block)

**All other phases:** no checks needed.

---

#### Step 3: Surface Post-Approval Modifications

---

#### Step 4: Confirm

If the gap contains more than one phase, show the full advancement chain and advisory summary:
```
Advance <phase1> → <phase2> → ... → <targetPhase> for <effort-id>?
<advisory summary from Step 2>
Proceed? (yes/no)
```

If the gap contains exactly one phase:
```
Ready to mark <currentPhase> as approved and advance to <nextPhase>? (yes/no)
```

If the engineer says no: stop, make no changes.
If yes: proceed to Step 5.

---

#### Step 6: Surface Post-Approval Modifications

Read `postApprovalModifications` from `.state.json`. If the array is non-empty,
present each entry:

```
Post-approval modifications since last approval:
- spec/api/openapi.yaml — modified during implementation (commit: a3f9b12)
- requirements/technical.md — modified during planning (commit: 7c23d04)
```

These will be acknowledged by the promotion and moved to
`phases.<current-phase>.reconciledModifications`. If the array is empty, skip
this section silently.

---

#### Step 7: Phase Summary

Present the full phase summary. Format:

```
Promotion summary: <effort-id> — <current-phase> → <next-phase>

Artifacts produced:
- requirements/business.md — <first heading from file>
- requirements/technical.md — <first heading from file>
- spec/api/openapi.yaml — <first heading or filename>
- validation/report.md — Overall result: PASS WITH CONCERNS

ADRs recorded:
- ADR-001: <decision title from file>
- ADR-002: <decision title from file>

Open decisions remaining: <count, or "None">
<list open decisions from .state.json openDecisions if any>

Concerns from validation:
<paste concerns section from validation/report.md if result was PASS WITH CONCERNS>
<omit this section if result was PASS>

Post-approval modifications to acknowledge:
<list from Step 2, or omit if none>

Risk classification: <riskTier from .state.json>

Does this look complete and correct? Confirm to advance to <next-phase>
(yes / confirm / approved) or cancel:
```

---

#### Step 8: Explicit Confirmation (single-step only — multi-step confirmed in Step 4)

Wait for engineer input. Apply the confirmation protocol:

**Accepted (advance):** `yes`, `confirm`, `approved`, `approve`, `proceed`, `y`
(case-insensitive, leading/trailing whitespace trimmed)

**Rejected (do not advance, request explicit confirmation):** `maybe`, `sure`, `ok`,
`fine`, `sounds good`, or any input not in the accepted list

**Cancelled (stop, no state changes):** `no`, `cancel`, `stop`, `abort`

**No response / session end:** No state changes made.

When rejected: respond with:
> "Please confirm explicitly with 'yes', 'confirm', or 'approved' to advance, or
> cancel with 'no'."
Await input again.

---

#### Step 9: Apply Promotions

For each phase in the gap (in order), apply the promotion and create a commit before
moving to the next phase. One commit per phase — preserves audit trail for multi-step
advances.

**Per-phase update to `.state.json`:**

Set the following fields for the phase being approved:
- `phases.<phase>.status` → `"approved"`
- `phases.<phase>.approvedBy` → git `user.name` (`user.email` if name unavailable; `"unknown"` if neither)
- `phases.<phase>.approvedAt` → current UTC ISO-8601 timestamp
- `currentPhase` → next phase in sequence
- `phases.<next-phase>.status` → `"in_progress"`

If `postApprovalModifications` is non-empty (first phase in gap only):
- Move all entries to `phases.<phase>.reconciledModifications`
- Set `postApprovalModifications` to `[]`

**Checkpoint commit (per phase):**

```bash
git add .forge/efforts/<effort-id>/.state.json
git commit -m "chore(<effort-id>): approve <phase> phase"
```

The commit contains only `.state.json`. If the commit fails, report the error and stop.
Do not proceed to the next phase in the gap if a commit fails.

**After all phases approved — registry update:**

Update the effort's row in `.forge/efforts/README.md` to reflect the final `currentPhase`.

```bash
git add .forge/efforts/README.md
git commit -m "chore(<effort-id>): update registry — advanced to <targetPhase>"
```

**Confirm to engineer:**

```
Promoted: <effort-id>
  <phase1>  → approved  (<ISO-8601>)
  <phase2>  → approved  (<ISO-8601>)   [if multi-step]
Now in:   <targetPhase>

Note: approved artifacts remain editable — promotion does not lock them.
```

---

### Advisory Checks Reference (Per ADR-031 — Non-Blocking)

All checks are informational. The engineer proceeds regardless of missing artifacts.

| Phase in gap | Advisory items shown |
|-------------|---------------------|
| discovery | business.md, technical.md, spec/ artifacts; **validation gate** if report absent |
| planning | plan/tasks.md presence and task count |
| implementation | completed vs. remaining task count |
| all others | no checks |

**Validation gate (discovery exit):** if `validation/report.md` is absent, offer a
`yes/no/skip` prompt to run `forge:validate` inline. Not a hard block — the engineer
may skip and advance without a validation report.

---

### Confirmation Protocol Reference

| Input | Action |
|-------|--------|
| `yes`, `confirm`, `approved`, `approve`, `proceed`, `y` | Advance |
| `no`, `cancel`, `stop`, `abort` | Cancel, no state changes |
| `maybe`, `sure`, `ok`, `fine`, `sounds good` | Reject, request explicit confirmation |
| Any other input | Reject, request explicit confirmation |

---

### Checkpoint Commit Format

```
chore(<effort-id>): approve <phase> phase
```

One commit per phase approved. For multi-step advances, multiple commits are created
in sequence — one per phase in the gap. Each commit contains only `.state.json`.
Distinct from artifact commits. The registry commit is a separate final commit.

---

### `.state.json` Fields Updated by forge:promote

| Field | Value after promotion |
|-------|----------------------|
| `currentPhase` | Target phase |
| `phases.<current>.status` | `"approved"` (discovery, verification); `"complete"` (planning) |
| `phases.<current>.approvedBy` | git user identity |
| `phases.<current>.approvedAt` | UTC ISO-8601 timestamp |
| `phases.<next>.status` | `"in_progress"` |
| `phases.<current>.reconciledModifications` | Former `postApprovalModifications` entries (if any) |
| `postApprovalModifications` | `[]` (cleared) |

---

### Deviation Rules

- **Never advance without confirmation.** If confirmation is not received (session ends,
  engineer cancels), `.state.json` must not be modified.
- **Exit silently when target ≤ current.** No output, no error — this is the expected
  no-op path when calling skills invoke `--target` after the effort has advanced.
- **Never modify source code.** `forge:promote` writes only `.state.json` and
  `.forge/efforts/README.md`.
- **Never spawn sub-agents.** The entire ritual runs in the orchestrator session.
- **Advisory checks are informational.** Per ADR-031, missing artifacts do not block
  promotion. The engineer sees what is absent and decides to proceed or cancel.
- **Validation gate is a prompt, not a hard block.** The engineer can skip validation
  and advance without a report. The skip is noted but does not prevent promotion.
