# Business Requirements — forge-spec-messaging

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-3 (designs validated before implementation), BR-6 (traceability)

---

## BR-1: Ordering and Idempotency Decisions Must Be Made Before Implementation, Not Discovered During It

A producer built for at-least-once delivery and a consumer built for at-most-once will
fail at integration — silently, and in ways that are hard to diagnose. By the time this
mismatch surfaces (typically in a code review or an integration test), both sides have
committed implementations that need to be rewritten. The cost is hours, not minutes.

Engineers need a design-time tool that makes ordering and idempotency decisions explicit
for every event, before any implementation begins. Leaving these decisions implicit or
deferred is not acceptable for production-bound event contracts.

## BR-2: Message Contracts Must Be Agreed Between Producers and Consumers Before Either Starts Implementing

When a producer and consumer are developed concurrently without an agreed contract, schema
mismatches, unexpected field types, and missing fields are discovered at integration time.
Defining the contract as a shared artifact during discovery gives both teams a stable
interface to implement against.

## BR-3: Standard Compliance Must Be Verified During Contract Authoring, Not After

Deferred validation (checking compliance only when `forge:validate` is run) means
non-compliant contracts enter the spec/messaging/ directory and may be used as the basis
for implementation before the issue is caught. Inline checks during authoring surface
violations immediately — when the cost of correction is a single field change, not a
committed implementation rework.

## BR-4: Unknown Consumers Must Be Explicitly Flagged, Not Silently Omitted

When the consuming service is not yet known during discovery, leaving the consumer field
blank is not a valid state. An engineer or agent implementing the event producer without a
named consumer has no way to coordinate delivery guarantees, error handling, or retry
policies. Unknown consumers must be explicitly called out as an open action item rather
than silently omitted from the contract.

---

Success criteria: [success-criteria.md](success-criteria.md)
