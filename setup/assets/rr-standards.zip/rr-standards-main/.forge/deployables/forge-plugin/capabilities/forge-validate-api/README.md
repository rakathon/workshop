# forge-validate-api

Targeted validation of API contracts against the organization's REST standards.
Delivers the `forge:validate-api` skill — an inline editing aid used during
`forge:spec-api` authoring that provides immediate standards feedback without
writing gate artifacts or updating effort state.

**Skill:** `forge:validate-api`  **Classification:** Worker
Part of the spec-driven-development initiative.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:validate-api` | Skill | Worker | Manual invocation during or after `forge:spec-api` |

**`forge:validate-api`** scans `spec/api/*.yaml` in the active effort, applies the
REST standard checks per contract and per endpoint, and prints an inline session
report grouped by endpoint. Findings are labeled REQUIRED (must fix before promoting)
or SUGGESTION (informational).

## Why This Capability Exists

When engineers author OpenAPI contracts over multiple design sessions, standards
violations accumulate and become expensive to fix in batch during the `forge:validate`
gate. `forge:validate-api` closes the feedback loop at the point of authoring —
engineers can check compliance after each `forge:spec-api` pass and fix violations
immediately, keeping the final gate review fast.

This capability is intentionally separate from `forge:validate` (the phase gate) and
`forge:review-security` / `forge:review-privacy`. It is scoped exclusively to REST
standard compliance of the OpenAPI contract.

## How It Relates to forge:validate

| Aspect | forge:validate-api | forge:validate |
|--------|-------------------|----------------|
| Purpose | Editing aid | Phase gate |
| Writes `validation/report.md` | NO | YES |
| Updates `.state.json` | NO | YES |
| Scope | API contracts only | All discovery artifacts |
| When to use | During authoring | End of discovery |
| Agent type | Worker | Orchestrator |

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-spec-api](../forge-spec-api/) | Produces the `spec/api/*.yaml` files that forge:validate-api checks |
| [forge-elaborate](../forge-elaborate/) | Produces requirements that drive contract design |
| [forge-promote](../forge-promote/) | The phase gate that must pass before promotion; runs forge:validate |

## Implementation Location

`plugins/forge/skills/validate-api/` — `forge:validate-api` SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| `requirements/business.md` | Business drivers for inline API validation |
| `requirements/technical.md` | Technical requirements for each validation check |
| `spec/README.md` | Skill design overview |
| `spec/skills.md` | Detailed skill specification |
