# Business Requirements — forge:validate-api

## Context

During `forge:spec-api`, engineers author OpenAPI YAML contracts iteratively.
Without targeted, immediate feedback, standards violations accumulate across multiple
design sessions and are expensive to fix in batch at the end of discovery. A targeted
API validator closes this feedback loop at the point of authoring.

---

## BR-1 — Immediate inline standards feedback during API authoring

**Description:** When engineers author an OpenAPI YAML contract during `forge:spec-api`,
they need immediate inline feedback on whether the contract complies with the
organization's REST standards — without waiting until the full `forge:validate` run at
the end of discovery.

Without targeted API validation, standards violations accumulate over multiple design
sessions and are expensive to fix in batch.

**Acceptance Criteria:**
- Running `forge:validate-api` during or after `forge:spec-api` surfaces standards
  violations within the current session before the engineer moves on.
- The report identifies at minimum: incorrect or missing HTTP status codes, missing error
  schemas, auth gaps on write operations, and non-noun resource paths.
- Feedback is available without leaving the Claude Code session.

---

## BR-2 — Editing aid, not a gate artifact

**Description:** The targeted API validator must not write a gate artifact or update any
state. It is an editing aid used during authoring, not a phase gate. Only `forge:validate`
owns `validation/report.md`.

**Acceptance Criteria:**
- Running `forge:validate-api` does not modify `validation/report.md`.
- Running `forge:validate-api` does not modify `.state.json`.
- Multiple invocations produce no file system side effects.
- `forge:validate-api` output is ephemeral session output only.

---

## BR-3 — Actionable report, no context switch required

**Description:** The inline report must be actionable immediately in the session where
the engineer is working, without requiring them to context-switch to a different tool
or file.

**Acceptance Criteria:**
- Each finding includes a severity label (REQUIRED or SUGGESTION) so the engineer can
  triage immediately.
- Findings are grouped by endpoint so the engineer can act on one endpoint at a time.
- The report includes a summary line (N REQUIRED, M SUGGESTION) so the engineer can
  gauge overall compliance at a glance.
- When no API spec is found, the skill reports a clear, actionable message rather than
  failing silently.
