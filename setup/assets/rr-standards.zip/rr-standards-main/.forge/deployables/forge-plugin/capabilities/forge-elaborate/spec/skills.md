# Skills — forge-elaborate

## forge:elaborate

**Classification:** Orchestrator

**Conversational equivalent:** "let's understand this problem", "deep dive on this effort",
"interview me about this", "I want to think this through", "help me understand what we're building",
"explore this with me", "what are we missing?", "what questions should we be asking?"

**Arguments:** `<effort-id>` (optional — if absent, no-effort mode)

**Inputs:**
- `<effort_dir>/requirements/business.md` — read if present; source of established BRs
- `<effort_dir>/requirements/technical.md` — read if present; source of established TRs
- `<effort_dir>/requirements/user-stories.md` — read if present; avoid duplication
- `<effort_dir>/spec/` — all artifacts read for established decisions
- `<effort_dir>/.state.json` — read for current phase
- Conversational answers from the engineer throughout the interview

**Outputs (effort mode):**
- `<effort_dir>/requirements/business.md` — new BR entries appended as agreed
- `<effort_dir>/requirements/technical.md` — new TR entries appended as agreed
- `<effort_dir>/spec/arch-decisions/ADR-NNN-*.md` — created via `forge:adr` as decisions are agreed
- `<effort_dir>/requirements/user-stories.md` — written at interview conclusion
- `<effort_dir>/.state.json` — `risk` field written by `forge:classify` (invoked after user stories)

**Outputs (no-effort mode):**
- Shared understanding held in context throughout the session
- At session end: written wherever the engineer chooses, or not at all

---

## Steps

### Step 0: Resolve Active Effort

Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: effort-optional

If no effort is found: enter **no-effort mode** (see No-Effort Mode section below).
If an effort is found: record `effort_id` and `effort_dir` and continue to Step 1.

---

### Step 1: Read All Existing Artifacts

Read every artifact that exists:
- `<effort_dir>/requirements/business.md`
- `<effort_dir>/requirements/technical.md`
- `<effort_dir>/requirements/user-stories.md`
- All files under `<effort_dir>/spec/`
- `<effort_dir>/.state.json`

Build an internal picture of what is already established:
- Which business requirements exist and whether they are complete
- Which technical constraints exist
- Which architectural decisions have been made
- Which spec artifacts exist and what design work they represent
- What is visibly missing or underspecified

Do not ask about anything already established.

---

### Step 2: Begin the Interview

Open with a brief orientation statement — what you have read and what you understand
so far — then ask the first question.

**Ordering heuristic (not a fixed sequence):**

The skill respects a natural dependency order as a default orientation:
1. Business requirements — what must be true for users, what problem is being solved
2. Technical constraints — measurable bounds, environmental mandates, technology mandates
3. Data model — what entities exist, their relationships, what gets persisted
4. Integration contracts — interfaces, APIs, messages to/from other systems
5. Internal implementation — how the system achieves the above

This ordering is a starting orientation. The skill must adapt:
- Skip layers where artifacts already exist and are complete
- Cycle back to earlier layers when a deeper question reveals a gap
- Follow productive threads wherever they lead

The goal is shared understanding — not checklist completion.

---

### Step 3: For Each Question, Provide a Recommendation

Every question the skill asks must include a recommended answer with a brief rationale.
The engineer may accept, modify, or reject the recommendation. The skill engages with
the engineer's response rather than just recording it.

Example question form:
> "How should we handle cases where the user's session expires mid-transaction?
> I'd recommend failing the transaction and returning a clear error — the alternative
> of completing the transaction with a stale session creates an auth gap. Does that
> match your intent, or is there a reason to prefer a different approach?"

---

### Step 4: Write Each Agreed Answer Immediately

As soon as an answer is agreed upon, classify it and write it before asking the next
question:

**Business requirement** — something that must be true from the user's or business's
perspective, regardless of implementation:
→ Append to `<effort_dir>/requirements/business.md` as a new `BR-N` entry

**Technical constraint** — a measurable bound, an environmental mandate, or a
technology mandate that constrains the implementation:
→ Append to `<effort_dir>/requirements/technical.md` as a new `TR-N` entry

**Architectural decision** — a choice between alternatives with a rationale:
→ Invoke `forge:adr` immediately to create the ADR in `spec/arch-decisions/`

Do not accumulate answers to write later. Write before the next question.

**Classification guide:**

| Agreed answer | Classification | Example |
|---------------|---------------|---------|
| What users need or what must be true for the business | BR | "Merchants must be able to see their payout status in real time" |
| A measurable performance, scale, or availability target | TR | "Must support 1000 RPS at p95 ≤ 50ms" |
| A technology or environment mandate | TR | "Must run on Java 8 — upgrade is out of scope for this effort" |
| A choice between design alternatives | ADR | "We will use DynamoDB over RDS because our access pattern is purely key-value" |
| A choice of module structure, service boundary, or ownership | ADR | "We will create a new module X rather than extending module Y" |

---

### Step 5: Continue Until No More Productive Questions

Keep asking until:
- All business requirements are understood and complete
- All technical constraints are captured
- The data model (if there is one) is understood and agreed
- Integration contracts are understood (what goes in/out and to/from where)
- Internal implementation is understood at the level needed to begin planning
- No further question would materially improve the shared understanding

Or until the engineer signals that the understanding is sufficient.

---

### Step 6: Write User Stories

After the interview concludes, derive user stories from the established business
requirements and shared understanding, and write `<effort_dir>/requirements/user-stories.md`.

User stories use Connextra format:

```
As a <role>, I want <capability> so that <outcome>.
```

User stories are not a restatement of BRs. They are the human-centred view of what
those requirements mean for real users. One BR may yield multiple user stories; one
user story may span multiple BRs. Use judgment.

Structure `user-stories.md` as:

```markdown
# User Stories — <effort title>

*Derived from: [requirements/business.md](business.md)*
*Written: <YYYY-MM-DD>*

---

## <Theme or capability grouping>

- As a <role>, I want <capability> so that <outcome>.
- As a <role>, I want <capability> so that <outcome>.

## <Next theme>

...
```

---

### Step 7: Run forge:classify

After writing user stories, invoke `forge:classify`. The shared understanding is now
fully captured, making this the earliest point at which a well-grounded risk
classification can be produced. `forge:classify` reads the risk rubric, surfaces a
recommendation, and confirms with the engineer before writing to `.state.json`.

If `forge:classify` fails or the engineer declines classification at this point,
continue to Step 8 without blocking.

---

### Step 8: Navigation Prompt

After `forge:classify` completes (or is skipped), ask the engineer:

> "The shared understanding is written. What next?
>
> 1. **Commit this work** — I'll run `forge:commit` to create a checkpoint
> 2. **Move to planning** — I'll run `forge:plan` to break this into implementation tasks
> 3. Something else — tell me what you'd like to do"

Do not automatically commit, plan, or transition phase without the engineer's choice.

---

## No-Effort Mode

When no active effort is found, enter no-effort mode.

The interview proceeds identically to Steps 2–5. The skill builds the same depth of
shared understanding, asks the same quality of questions, and provides recommendations.

The only difference: nothing is written during the interview. Agreed answers are held
in context.

After the interview concludes (Step 5):

> "We've developed a solid shared understanding. Would you like to write this anywhere?
> If so, where — a new file in the current directory, a new effort, or somewhere else?
> Or would you prefer to keep it in context and move straight to implementation planning?"

If the engineer wants to write it: ask for a target and write accordingly.
If the engineer does not: end the session without any file writes.

---

## Error Handling

| Condition | Behavior |
|-----------|---------|
| No effort found | Enter no-effort mode (not an error) |
| `forge:adr` fails during write | Log the failure, surface it to the engineer, offer to retry before continuing |
| Engineer does not respond after two exchanges | Stop; suggest re-invoking when ready |
| Effort exists but all artifacts are empty/stub | Treat as cold start; read what exists and proceed |
