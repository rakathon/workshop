# forge-graduate — Architecture

This capability delivers the `forge:graduate` skill, which promotes a completed effort's
artifacts to the canonical documentation for the associated deployable or product.
Graduation is the final operation in an effort's lifecycle: it closes the effort as
active work and ensures the deployable's canonical docs reflect the current state.

---

## Artifact Inventory

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:graduate` | Skill | Worker (isolated sub-agent) | Invoked by orchestrator after QA sign-off |

---

## Architecture

```
Main session (orchestrator)
│
│  Engineer: "QA passed. Let's close this effort out."
│
│  Claude (orchestrator):
│    1. Confirm all phases complete and QA signed off
│    2. Read post-approval modifications (informational)
│    3. Launch forge:graduate as isolated sub-agent
│
└──► forge:graduate (worker sub-agent)
       │
       │  Input: effort ID
       │
       ├── Read .forge/efforts/<id>/.state.json
       │     → deployables, businessProducts, postApprovalModifications
       │
       ├── Read all effort artifacts
       │     → requirements/, spec/, capabilities/
       │
       ├── Read current canonical docs
       │     → .forge/deployables/<name>/ or .forge/products/<name>/
       │
       ├── Merge (update, not append)
       │     → requirements/* updated in deployable
       │     → spec/* updated in deployable
       │     → capabilities/<cap>/* updated (if scoped)
       │     → ADRs: verify effort ID present (not moved)
       │
       ├── Write updated canonical docs
       ├── Update .state.json graduation fields
       ├── Remove effort row from .forge/efforts/README.md
       ├── Commit graduation changes
       │
       └── Return graduation report to main session

Main session: present graduation report to engineer
```

---

## Key Design Decisions

**Why isolated:** Graduation reads the full set of effort artifacts and the full set of
existing deployable documentation, then produces a merged result. For a mature deployable
with multiple prior graduations, the canonical documentation may be substantial. Running
this in the main session would consume context budget needed for subsequent work.

**Merge, not append:** The canonical documentation is a description of what the deployable
is now — not a history of what was added when. Each graduation updates the relevant
sections to reflect the current state. The effort directory preserves the history.

**ADRs are not moved:** ADRs are written to the canonical directory during discovery, not
at graduation. Graduation verifies that each ADR produced by the effort references the
effort ID in its metadata, but does not move, copy, or re-write ADRs.

**Explicit trigger:** Graduation is not triggered by PR merge or task completion.
It requires the engineer (or orchestrator, acting on the engineer's instruction) to
explicitly invoke it after QA confirms the feature is working in a pre-production
environment. This ensures only validated work reaches canonical documentation.

**Post-approval reconciliation:** ADR-002 establishes that phase gates inform but never
block. The consequence is that post-approval modifications accumulate in `.state.json`
throughout the effort. Graduation is the reconciliation point: modifications are surfaced
in the graduation report, and the graduated artifact represents the final intentional state.

---

## Relation to ADR-002

ADR-002 (phase gates inform, not block) establishes the permissive edit-time model that
makes graduation meaningful. Because writes to approved artifacts are never blocked,
post-approval modifications can accumulate silently throughout the effort. Graduation is
the rigor point: it surfaces all modifications, requires the engineer to see them, and
produces a committed, auditable record of what was promoted.

Without graduation, the permissive edit-time model would produce canonical documentation
that silently reflects unapproved implementation-time changes. With graduation,
those changes are visible and deliberately reconciled.

---

## Design Documents

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:graduate` detailed skill design |
| [arch-decisions/README.md](arch-decisions/README.md) | Relevant architectural decisions |
