# Success Criteria — forge-elaborate

`forge:elaborate` is correct when:

- [ ] When invoked with no prior artifacts, the skill begins the interview without stopping or requiring a prior step to have been completed
- [ ] When invoked with partial artifacts, the skill reads them all before asking the first question, and the first question addresses a gap — not something already established
- [ ] For every question asked, the skill provides a recommended answer with a rationale before waiting for the engineer's response
- [ ] When an answer is agreed upon as a business requirement, it is appended to `requirements/business.md` before the next question is asked
- [ ] When an answer is agreed upon as a technical constraint, it is appended to `requirements/technical.md` before the next question is asked
- [ ] When an answer is agreed upon as an architectural decision, `forge:adr` is invoked immediately and the ADR is created before the next question is asked
- [ ] The skill cycles back to earlier layers when deeper questions reveal gaps (e.g. a data model question surfaces a missing BR — the skill resolves the BR before continuing with the data model)
- [ ] The skill does not ask about something that is already resolved in the existing artifacts
- [ ] The interview terminates when the skill has no more productive questions, or when the engineer signals sufficient understanding
- [ ] After termination, `requirements/user-stories.md` is written in Connextra format ("As a <role>, I want <capability> so that <outcome>")
- [ ] When the interview is about to enter the data model layer and `spec/storage/` is absent, the skill pauses and offers to invoke `forge:spec-storage` before asking storage questions
- [ ] When the interview is about to enter the API contract layer and `spec/api/` is absent, the skill pauses and offers to invoke `forge:spec-api`
- [ ] When the interview is about to enter the messaging contract layer and `spec/messaging/` is absent, the skill pauses and offers to invoke `forge:spec-messaging`
- [ ] When a spec skill is invoked, the interview resumes after it completes and the skill re-reads all spec artifacts before continuing
- [ ] When the engineer declines spec delegation, the interview continues directly and does not re-offer for that layer in the same session
- [ ] Spec skill delegation is not offered in no-effort mode
- [ ] After writing user stories (effort mode), `forge:classify` is invoked before the navigation prompt
- [ ] If `forge:classify` fails or the engineer declines classification, the skill continues to the navigation prompt without blocking
- [ ] After `forge:classify` completes (or is skipped), the skill offers three options: commit with `forge:commit`, plan with `forge:plan`, or do something else
- [ ] In no-effort mode, no files are written until the engineer explicitly decides to write the shared understanding somewhere
- [ ] An ADR is created for decisions (choice between alternatives with rationale); a TR is written for constraints (measurable bounds, environmental mandates, technology mandates)
- [ ] The skill is not triggered by "elaborate requirements", "expand the BRs into TRs", or "what are the NFRs?" — these phrases now belong to the retired behaviour
