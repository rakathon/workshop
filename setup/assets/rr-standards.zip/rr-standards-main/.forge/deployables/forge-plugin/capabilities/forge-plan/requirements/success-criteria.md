# Success Criteria — forge-plan

## Epic/Story/Task/Spike efforts (plan/tasks.md)

- [ ] Every task carries both a type annotation (`[auto]`, `[checkpoint]`, `[tdd]`,
      or `[manual]`) and a wave annotation (`[wave:N]`); no task is missing either
- [ ] No wave N+1 task precedes its wave N dependency — dependency ordering is
      correct across all waves
- [ ] Tasks in the same wave have no dependency on each other and can run in parallel
- [ ] Repository layer, service layer, and domain model tasks receive `[tdd]` annotation
- [ ] Checkpoint tasks include a note in their description explaining what needs to
      be confirmed before or after the task executes
- [ ] Every task block includes `**Satisfies:**`, `**Standards:**`, and
      `**Required tests:**` fields; no field is omitted
- [ ] Every stated BR-*/TR-* requirement has at least one task in `**Satisfies:**`
      that addresses it
- [ ] `**Standards:**` entries are file paths relative to the plugin root, not prose;
      `forge:plan` reads `standards/AGENTS.md` before writing tasks
- [ ] `**Required tests:**` entries for `[tdd]` tasks name specific test functions
      and describe what each verifies; scaffolding/config tasks state `none (<reason>)`
- [ ] For coordination efforts, `plan/plan.md` is written with one section per
      deployable containing acceptance criteria and cross-deployable dependencies
- [ ] `forge:plan` commits with `chore(<effort-id>): generate implementation plan`

## Initiative/Program efforts (plan/epics.md)

- [ ] `plan/epics.md` is written; `plan/tasks.md` is not written for initiative/program efforts
- [ ] Each epic section contains: Name, Deployable, High-Level Output, Relevant
      Requirements, Success Criteria, and Dependencies (if any)
- [ ] Every epic has a Deployable field assigned; no epic is missing a repo assignment
- [ ] Relevant Requirements lists BR-*/TR-* IDs with brief quotes from the initiative
      requirements; every initiative requirement is assigned to at least one epic
- [ ] Success Criteria items are measurable and unambiguous — confirmable by automated
      check, demo, or defined process; no subjective criteria
- [ ] Epic count is 3–8; EPIC IDs are sequential in recommended delivery order
- [ ] `forge:plan` commits with `chore(<effort-id>): generate initiative epic breakdown`
