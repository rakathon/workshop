# Business Requirements — forge-cross-repo

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-10

---

## BR-1: Engineers Must Be Able to Work Locally Without Navigating to a Coordination Repository

When a feature spans multiple repositories, an engineer working in one deployable's
repository must be able to read the relevant coordination requirements, plans, and
contracts without leaving their local context. Requiring engineers to navigate to a
separate repository — or switch to a browser tab — to understand what they are building
introduces friction that compounds across every session and every team member.

Coordination-level artifacts must be available locally, as real files, readable offline.
An engineer who clones the repository and opens a session must have immediate access to
the requirements they are working against, without fetching, mounting, or requesting
access to the coordination repository in that moment.

## BR-2: Context-Switching to Understand Requirements Breaks Engineering Flow

The cost of context-switching is not only the time taken. Switching to another repository
or document system interrupts the mental model the engineer has built, and the context
that was live in the Claude session — code, conversation, intent — is not present in the
coordination repository view. Engineers who must leave the local context to read
requirements will read them less, understand them less precisely, and drift from the
intended design.

Local projections eliminate the need for context-switching. The requirements the engineer
needs are in the same repository as the code, findable by the same tools and session
context that apply to everything else in the project.

## BR-3: Local Engineers Must Be Able to Work Offline and Independently

Network access to a coordination repository must not be a prerequisite for doing local
implementation work. In practice, engineers work in conditions where network access is
limited or unavailable — on flights, in spotty connectivity environments, or when the
coordination repository's host is temporarily unreachable. More importantly, the
principle that "git is the only dependency" must hold: once an engineer has cloned the
repository, the local projections must be fully usable without any additional fetch.

This is why materialized projections are the correct model. A reference-only pointer
that requires a live fetch is not a local artifact — it is a network dependency with a
local address.

## BR-4: Divergence Between Coordination and Local Artifacts Must Be Surfaced, Not Permitted to Accumulate Silently

Coordination-level artifacts change as the feature evolves. A requirement is refined.
A contract is updated. A plan entry is reassigned. When a local projection was taken
against an earlier version, it is stale — and the engineer may not know.

Silent staleness is dangerous. An engineer who implements against an outdated
projection of the requirements is building the wrong thing, but nothing in their
environment tells them so. The divergence is only discovered later, at review, or
worse, in production.

Staleness must be surfaced. When a projection is behind the current coordination
artifact, the engineer must be informed at session start so they can decide whether to
update the projection before proceeding. The decision is theirs — the staleness may be
intentional, or the change may not affect their work — but the information must be
available for that decision to be made.

## BR-5: Local Discoveries That Affect Coordination Artifacts Must Have a Structured Path to the Coordination Repository

Local implementation work regularly reveals gaps, errors, and necessary changes in
coordination-level artifacts. An API contract may be missing a field. A requirement
may be ambiguous. A cross-deployable dependency may have been incorrectly specified.
These discoveries must have a structured path upstream, not be handled ad hoc.

Without a structured mechanism, engineers either silently diverge from the coordination
view (the local projection reflects reality; the coordination repository does not), or
they try to coordinate informally outside any tool. Both patterns produce coordination
drift: the coordination repository stops reflecting what is actually being built.

`forge:upstream` provides the structured path. It writes a change proposal locally so
the discovery is recorded, and optionally creates a pull request to the coordination
repository so the proposal is visible to the engineers maintaining it. The local
sub-effort's state records the pending proposal so that staleness and pending upstream
changes are surfaced together at session start.

---

Success criteria: [success-criteria.md](success-criteria.md)
