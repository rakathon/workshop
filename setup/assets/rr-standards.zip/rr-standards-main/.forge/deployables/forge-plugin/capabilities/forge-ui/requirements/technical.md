# Technical Requirements — forge-ui

Parent business requirements: [requirements/business.md](business.md)

<!-- graduated-from: design-system-integration at 2026-04-25T23:10:46Z -->

---

## Traceability

| TR   | BRs        |
|------|------------|
| TR-3 | BR-3, BR-7 |
| TR-4 | BR-4       |
| TR-6 | BR-2, BR-3 |
| TR-8 | BR-6       |
| TR-9 | BR-2, BR-7 |

---

## TR-3: The Explore Skill Must Start the Dev Server Without Manual Steps

The existing `rakuten-styleguide` skill's `setup.md` requires the engineer to have
already cloned the styleguide repository and have Yarn installed. The redesigned
`forge:ui` skill must detect whether the dev environment is available and provide
actionable remediation steps when it is not — one clear message per missing
prerequisite. If the dev server is already running on the expected port, the skill must
use it without restarting it.

The skill must not require knowledge of the underlying repository structure. The
repository path and port must be discoverable from the skill's preconditions or
configurable via a setting, not hardcoded in the SKILL.md.

## TR-4: Production Implementation Skill Must Enforce Standards at Output Time

`forge:ui` in production mode must validate its generated code against the frontend
standards before reporting completion. Specifically:

- No raw hex color values in generated component code (must use semantic tokens)
- No hardcoded pixel spacing values (must use token names)
- All interactive elements must have `aria-*` attributes or use components that
  provide them natively
- Responsive props must be present on all layout-affecting props for Container,
  Grid, and spacing-sensitive components

These checks are behavioral, not syntactic — the skill must reason about the output,
not just grep for patterns.

## TR-6: The Skill Must Be Usable via a Single Natural-Language Invocation

A user who types `/forge:ui create a cashback milestone page with a hero and store
grid` must receive a running prototype without additional configuration steps. The skill
must ask no more than 3 clarifying questions before producing code; questions about
colors, spacing, or typography are forbidden (these are applied from standards
automatically).

## TR-8: Skills Must Reference Standards by Path, Not Reproduce Their Content

`forge:ui` must not include inline tables of design tokens, component catalogs, or
token-to-CSS mappings. These must be referenced by relative path to the canonical
standard file under `plugins/forge/standards/frontend/`. If a skill's step requires
token lookup, it must instruct the model to read the standard file, not provide the
lookup table inline.

This is enforced at skill review time via `rr-standards:validate`.

## TR-9: The Skill Must Operate Inside the Existing Styleguide Repository

The design team already has the `rr-styleguide-cover` repository cloned and running.
`forge:ui` must target that repository's dev server and `playground.tsx` pattern when
operating in prototype mode — it must not require creating a new project or changing
tools. The repository path must be discoverable from a convention or configurable
setting, not hardcoded in the skill body. If the repository is not found at the expected
location, the skill must surface a clear setup instruction rather than failing silently.
