# Business Requirements — forge-validate

Parent deployable: [forge-plugin](../../../deployables/forge-plugin/requirements/business.md)
Parent initiative: [spec-driven-development](../../spec-driven-development/requirements/business.md)

---

## BR-1: Inconsistencies in Discovery Artifacts Are Expensive to Find During Implementation

When engineers begin implementing a feature without verifying that their discovery
artifacts are internally consistent and standards-compliant, defects in the design
surface during coding — at the point of highest cost. A requirements gap means
rework. A spec that contradicts a standard means a design correction mid-sprint.
An ADR with missing sections means an undocumented decision that can't be reviewed.
Engineers need an automated check that runs before implementation starts, identifies
these problems while the cost of fixing them is low, and produces a clear report of
what to address.

**Acceptance criteria:**
- Given a complete set of discovery artifacts (business requirements, technical
  requirements, at least one spec artifact), when `forge:validate` is invoked, then
  it produces a report identifying all requirements without spec coverage, all
  spec artifacts that violate applicable standards, and all cross-spec conflicts.
- Given a clean set of artifacts, when `forge:validate` is invoked, then the report
  contains `**Result:** PASS` and no required-revision findings.

---

## BR-2: There Is No Machine-Readable Gate Preventing Promotion of Non-Validated Efforts

`forge:promote` is the phase gate that moves an effort from discovery to planning.
Without a machine-readable gate artifact, `forge:promote` cannot enforce that
validation has occurred — it can only check for file presence, not outcome. Engineers
can skip validation and promote anyway. The gate artifact (`validation/report.md`
with a grep-extractable `**Result:**` line) is the mechanism by which `forge:promote`
enforces that validation was run and passed (or was explicitly waived) before
implementation begins.

**Acceptance criteria:**
- Given no `validation/report.md` exists, when `forge:promote` is invoked, then it
  stops with: "Design validation has not been run. Run `forge:validate` before
  promoting."
- Given `validation/report.md` contains `**Result:** FAIL`, when `forge:promote`
  is invoked, then it stops with: "Design validation failed. Resolve required-revision
  findings in `validation/report.md` before promoting."
- Given `validation/report.md` contains `**Result:** PASS` or `PASS WITH CONCERNS`,
  when `forge:promote` is invoked, then it proceeds normally.

---

## BR-3: Full Validation Must Complete Quickly Even for Large Efforts

Efforts with many spec artifacts — multiple API contracts, complex storage schemas,
many ADRs — can produce large combined artifact sets. A sequential single-agent
validation pass over a large set may take too long and risk context exhaustion. The
validation skill must internally parallelize across check domains for large artifact
sets (>1,000 lines total), so that validation time stays acceptable regardless of
effort size.

**Acceptance criteria:**
- Given a set of discovery artifacts totaling more than 1,000 lines, when
  `forge:validate` is invoked, then it spawns four analysis agents in parallel
  (requirements traceability, API standards, storage standards, cross-spec consistency)
  and synthesizes their results.
- Given a set of discovery artifacts totaling 1,000 lines or fewer, when
  `forge:validate` is invoked, then it runs as a single-pass check without spawning
  sub-agents.

---

## BR-4: The Validation Result Must Be Programmatically Readable by Other Skills

`forge:promote` and other downstream automation must be able to determine whether
validation passed without parsing free-form prose. The `**Result:**` line format —
`**Result:** PASS | PASS WITH CONCERNS | FAIL` — is the grep-extractable marker
that all Forge skills use to read validation outcomes. The format must be consistent
so that a simple grep never returns ambiguous results.

**Acceptance criteria:**
- Given any `validation/report.md` written by `forge:validate`, when a downstream
  skill runs `grep '^\*\*Result:\*\*'`, then it returns exactly one line with one of
  the three values: `PASS`, `PASS WITH CONCERNS`, or `FAIL`.
- The `**Result:**` line must be the first non-blank line in `validation/report.md`.
