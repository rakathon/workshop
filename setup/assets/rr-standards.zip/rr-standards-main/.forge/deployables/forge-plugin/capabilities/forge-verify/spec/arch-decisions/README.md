# Architecture Decisions — forge-verify

## ADRs Scoped to This Capability

| ADR | Title | Status |
|-----|-------|--------|
| ADR-007 | [Quality loop runs at task execution, not at verification](../../../../../efforts/forge-workflow/spec/arch-decisions/ADR-007-quality-loop-at-task-execution-not-verification.md) | Accepted |

## Key Design Consequences

**ADR-007** is the foundational decision for this capability. It establishes:

- The quality loop lives in implementation skills, not in `forge:verify`
- `forge:verify` is a single-pass analytical skill with no loop
- Task completion is a meaningful signal (lint, spec validation, and tests all passed)
- `forge:verify`'s scope is goal delivery and integration completeness — not re-running
  per-task checks

Implementors of `forge:build-*` skills must read ADR-007 before designing the skill's
task execution behavior.
