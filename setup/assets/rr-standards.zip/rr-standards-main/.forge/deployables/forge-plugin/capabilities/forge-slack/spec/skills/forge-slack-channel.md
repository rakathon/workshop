# Skill Contract — forge:slack-channel

*Effort: slack-support*
*Date: 2026-04-21*
*Traces to: BR-1, TR-1, TR-13*

---

## Purpose

Manages the Slack channel associations for an effort. Supports adding one or more
channels, removing a channel, and optionally recording a scheduled import cadence.
Must be run (in add mode) before any other Slack skill can operate on the effort.

## Agent Type

`orchestrator`

---

## Arguments

| Argument | Required | Description |
|---|---|---|
| `<channel>` | Yes | Slack channel name (e.g. `#eng-payments`) or channel ID (e.g. `C012AB3CD`). May be specified multiple times. |
| `--effort <effort_id>` | No | Target a specific effort by ID. If omitted, resolved via the standard chain (see `plugins/forge/skills/common/effort-resolution.md`). |
| `--remove` | No | Remove the specified channel(s) from the effort's associations rather than adding them. |
| `--schedule <cron>` | No | Cron expression for scheduled import (e.g. `"0 9 * * *"`). Records the cadence in `.state.json` for reference. Does not register a Claude Code cron — scheduling is handled by the GitHub Actions workflow. Add mode only. |
| `--update-name` | No | Update the stored display name for an already-associated channel (e.g. after a Slack rename) and rename the local message directory. |

One of add or remove mode is active per invocation. `--remove` and `--schedule` are mutually exclusive.

---

## Preconditions

**PC-1: Target effort exists**
Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: `effort-required`
Pass `--effort` value as the explicit argument (Step 1 of the chain) when provided.

**PC-2: Slack MCP available (add mode only)**
In add mode, check for `mcp__slack__*` tools. If absent, stop with the standard MCP
configuration error (see `spec/mcp-config.md`). Remove mode does not require the MCP
— it only edits `.state.json`.

**PC-3: Duplicate channel (add mode — warn, don't stop)**
If any of the provided channels are already present in `slackChannels`, warn and skip:
> "Channel `<channel-id>` is already associated with this effort. Skipping."

**PC-4: Channel not associated (remove mode — stop)**
If a channel provided with `--remove` is not present in `slackChannels`, stop:
> "Channel `<channel-id>` is not associated with this effort."

**PC-5: --remove and --schedule are mutually exclusive**
If both are provided, stop:
> "`--remove` and `--schedule` cannot be used together."

---

## Steps

### Step 1: Resolve Channel ID(s)

**Add mode:** For each `<channel>` that begins with `#` or is a plain name (not a
`C…` ID), call `mcp__slack__list_channels` to look up the channel ID. If not found,
stop: "Channel `<channel>` not found. Check the name and try again."
Store each resolved channel ID and display name. The channel display name is used as
the directory slug for all message files under `messages/slack/<channel-name>/`.
Sanitize the name: lowercase, replace spaces with hyphens, strip any characters that
are not alphanumeric or hyphens.

**Remove mode:** Accept channel IDs or names as provided. If a name is given (not a
`C…` ID), attempt to resolve it via `mcp__slack__list_channels` to confirm identity,
but the MCP is not strictly required — the value in `slackChannels` is authoritative.

### Step 2: Update .state.json

Read `.forge/efforts/<effort_id>/.state.json`.

**Add mode:** Append a `{"id": "<channel-id>", "name": "<channel-name-slug>"}` object
to the `slackChannels` array (creating the field as an empty array if absent). Skip
channels already present (match by `id`). Do not add duplicate entries.

If `--schedule` was provided, also set:
```json
"slackImportSchedule": "<cron-expression>"
```

**Step 2b — Handle name drift:** If `--update-name` is passed, or if the resolved
channel name differs from the stored name for an existing channel ID, update the
`name` field in the matching `slackChannels` entry and rename the directory
`messages/slack/<old-name>/` to `messages/slack/<new-name>/` if it exists. Warn the
engineer of the rename.

**Remove mode:** Remove the matching `{id, name}` object from the `slackChannels`
array (match by `id`).

Write the updated `.state.json`.

### Step 3: Confirm Schedule (add mode with --schedule only)

Print a reminder to the engineer:

```
Schedule recorded: <cron expression>
To activate scheduled import, configure the GitHub Actions workflow at
.github/workflows/slack-import.yml with this cadence and ensure
the Slack MCP OAuth authorization has been completed for the GitHub Actions runner.
```

### Step 4: Commit

Use `forge:commit` to stage and commit the updated `.state.json`.

### Step 5: Print Summary

**Add mode:**
```
forge:slack-channel complete (add)
Effort:  <effort_id>
Added:   <display-name> (<channel-id>), ...
Skipped: <channel-id> (already associated), ...
Schedule: <cron expression, or "none — invoke forge:slack-import manually">

Next steps:
  forge:slack-import   — run first import
```

**Remove mode:**
```
forge:slack-channel complete (remove)
Effort:  <effort_id>
Removed: <display-name> (<channel-id>), ...
Remaining channels: <display-name> (<channel-id>), ... (or "none")
```

---

## Error Handling

| Condition | Action |
|---|---|
| Slack MCP unavailable (add mode) | Stop with MCP configuration error |
| Channel not found (add mode) | Stop with name-check suggestion |
| Channel not associated (remove mode) | Stop; list currently associated channels |
| `--remove` and `--schedule` combined | Stop with mutual exclusion error |
| `.state.json` write fails | Stop; do not commit partial state |
