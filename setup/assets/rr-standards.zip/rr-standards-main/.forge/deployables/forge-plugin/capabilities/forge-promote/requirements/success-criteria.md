# Success Criteria — forge-promote

- [ ] Promoting discovery → planning sets phases.discovery.status = "approved" and currentPhase = "planning"
- [ ] Advisory checks report missing artifacts but do not block promotion
- [ ] A single yes/no confirmation is sufficient — no typed string required
- [ ] After promotion, requirements/ and spec/ remain editable (no lock)
- [ ] When invoked with no active effort, the skill stops gracefully rather than erroring
- [ ] .forge/efforts/README.md is updated to reflect the new currentPhase
