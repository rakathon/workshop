# Runbook — forge-effort

Operational guidance for diagnosing and recovering from issues with the forge-effort
capability: inconsistent state, corrupt registry, and hooks that fire unexpectedly.

---

## Diagnosing State Inconsistencies

### Symptom: Artifact Exists on Disk but Is Not Reflected in .state.json

**Cause:** The `update-workflow-state.sh` PostToolUse hook did not fire, or the agent
committed the artifact without committing the updated `.state.json`.

**Recovery:**
1. Read the artifact's path to determine its category (requirements, spec, plan, etc.).
2. Read the effort's `.state.json`.
3. Manually update the appropriate field:
   - `requirements/business.md` present on disk → set `phases.discovery.artifacts.requirements.business: "present"`
   - Follow the artifact-to-field mapping in [spec/hooks.md](../spec/hooks.md) Hook 4.
4. Commit the corrected `.state.json`:
   ```
   git add .forge/efforts/<id>/.state.json
   git commit -m "chore(<id>): fix state inconsistency — sync artifact inventory"
   ```

### Symptom: .state.json Claims an Artifact Is Present but the File Does Not Exist

**Cause:** An artifact was deleted or moved without updating `.state.json`.

**Recovery:**
1. Determine whether the artifact was intentionally removed or accidentally moved.
2. If intentionally removed: set the field back to `"absent"` and commit.
3. If accidentally moved: move the file back to its canonical path and verify the field is `"present"`.
4. If unsure: restore the artifact from git history:
   ```
   git log --diff-filter=D -- .forge/efforts/<id>/requirements/business.md
   git show <sha>:.forge/efforts/<id>/requirements/business.md > .forge/efforts/<id>/requirements/business.md
   ```

---

## Recovering a Corrupted .state.json

### Symptom: .state.json Contains Invalid JSON

**Cause:** A partial write (hook interrupted mid-execution), a manual edit error, or a
merge conflict that was resolved incorrectly (leaving conflict markers in the JSON).

**Recovery:**
1. Check git history for the last valid version:
   ```
   git log -- .forge/efforts/<id>/.state.json
   git show <sha>:.forge/efforts/<id>/.state.json
   ```
2. Compare the last valid version against the current file.
3. If the current file has conflict markers (`<<<<<<<`, `=======`, `>>>>>>>`): resolve by
   taking the union of both changes (see TR-13 — merge conflicts should be resolvable by
   union). Both phase status updates are valid; both ADR additions are valid.
4. Validate the resulting JSON (use `python3 -m json.tool .state.json` or equivalent).
5. Commit the corrected file with a note:
   ```
   git add .forge/efforts/<id>/.state.json
   git commit -m "chore(<id>): fix corrupt .state.json — resolved merge conflict"
   ```

### Symptom: .state.json Is Missing Required Fields

**Cause:** Created by an older version of `forge:effort`, or manually created without
following the schema.

**Recovery:**
1. Read [spec/state-schema.md](../spec/state-schema.md) for the full required field list.
2. Read the effort's artifact directory to reconstruct missing fields:
   - `id` — from the directory name
   - `currentPhase` — from which artifacts are present and which are absent
   - `phases.*` — from artifact presence on disk
3. Add missing fields with reasonable defaults (see schema defaults).
4. Commit and note the repair in the commit message.

---

## Recovering a Corrupted Registry

### Symptom: .forge/efforts/README.md Has Duplicate Rows

**Cause:** Concurrent commits that both added rows for the same effort, merged without
conflict detection because the rows appeared at different positions.

**Recovery:**
1. Open `.forge/efforts/README.md`.
2. Identify the duplicate rows (same effort ID appearing more than once).
3. Remove the duplicate row, keeping the row with the most recent phase status.
4. Commit:
   ```
   git add .forge/efforts/README.md
   git commit -m "chore: fix duplicate registry entry for <id>"
   ```

### Symptom: Registry Row Is Stale (Phase Does Not Match .state.json)

**Cause:** A phase transition was committed to `.state.json` but the corresponding
`.forge/efforts/README.md` update was not committed in the same operation.

**Recovery:**
1. Read the effort's `.state.json` to get the current `currentPhase` and status.
2. Find the effort's row in `.forge/efforts/README.md` and update it to match.
3. Commit:
   ```
   git add .forge/efforts/README.md
   git commit -m "chore: sync registry row for <id> — phase was <old> now <new>"
   ```

### Symptom: Effort Missing from Registry but Directory Exists

**Cause:** `forge:effort` was run but the registry update commit failed, or the
registry row was accidentally deleted.

**Recovery:**
1. Read `.forge/efforts/<id>/.state.json` to get all required fields.
2. Add a row to `.forge/efforts/README.md` in the correct position (beneath parent if applicable).
3. Commit:
   ```
   git add .forge/efforts/README.md
   git commit -m "chore: restore registry entry for <id>"
   ```

---

## Hook Diagnostic Steps

### Symptom: phase-context.sh Appears to Block a Write

**First check:** Confirm the exit code. `phase-context.sh` must never exit 2 for any
`.forge/efforts/` path. If a write was blocked, the cause is a different hook.

**Diagnostic steps:**
1. Run the hook directly on the target path and examine the exit code:
   ```
   .claude/hooks/phase-context.sh '{"tool_name": "Write", "tool_input": {"file_path": "<path>"}}'
   echo "Exit: $?"
   ```
2. If exit code is 2: this is a bug in the hook implementation. File a bug report with
   the exact path and `.state.json` state. Do not modify the hook to work around the bug
   without understanding the root cause.
3. If exit code is 0: the write was not blocked by `phase-context.sh`. Check other hooks.

### Symptom: update-workflow-state.sh Not Updating .state.json After Artifact Write

**Diagnostic steps:**
1. Confirm the file path is under `.forge/efforts/`. Writes to other paths are no-ops.
2. Confirm the artifact matches one of the 8 recognized patterns (see Hook 4 in
   [spec/hooks.md](../spec/hooks.md)).
3. Check that `.state.json` exists and is valid JSON before the write.
4. Run the hook directly:
   ```
   .claude/hooks/update-workflow-state.sh '{"tool_name": "Write", "tool_input": {"file_path": "<path>"}}'
   ```
5. If the hook runs but does not update state, add temporary debug output to identify
   which step is failing. Remove debug output before committing.

### Symptom: inject-workflow-context.sh Not Emitting Context at Session Start

**Diagnostic steps:**
1. Confirm `.forge/efforts/README.md` exists. The hook exits silently if it does not.
2. Confirm at least one effort is active in the registry.
3. Run the hook manually to see its output:
   ```
   .claude/hooks/inject-workflow-context.sh '{}'
   ```
4. Check for JSON parse errors in `.state.json` files (a corrupt file causes that effort
   to be skipped).
5. If output is correct when run manually but not appearing in sessions, verify the hook
   is registered in `.claude/settings.json` under the `hooks.SessionStart` key.

---

## Pause State Recovery

### Symptom: forge:resume Says "No Pause State Found" but Work Was Paused

**Cause:** The commit containing the pause state update was not pushed, or the current
branch does not have the pause commit.

**Recovery:**
1. Check git log for a recent pause commit:
   ```
   git log --oneline -- .forge/efforts/<id>/.state.json | head -10
   ```
2. If the pause commit is on another branch, cherry-pick it or check out the correct branch.
3. If the commit was never made (session ended before `forge:pause` completed), the pause
   state is lost. Proceed by reading artifact files to reconstruct context manually and run
   `forge:status` to see the current state.

---

## Effort Directory Cleanup

When an effort is closed and graduated, it remains in `.forge/efforts/` as a historical
record. The registry entry is removed, but the directory is preserved. This is by design.

To archive old efforts and reduce repository size:
1. Confirm the effort's `.state.json` has `graduation.graduated: true`.
2. Move the effort directory to an archive location outside `.forge/`:
   ```
   mkdir -p .forge/archive/
   mv .forge/efforts/<id>/ .forge/archive/<id>/
   ```
3. Commit with a note. Do not delete effort directories — they are the audit trail of how
   the work was done, and `git rm` would remove them from history only if the history is
   rewritten, which should not be done for workflow artifacts.
