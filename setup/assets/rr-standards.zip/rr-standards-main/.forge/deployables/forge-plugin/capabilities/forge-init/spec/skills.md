# forge:init Skill Design

Design for the `forge:init` skill. The skill is interactive, runs in the engineer's
Claude Code session, and uses Claude Code tools (Read, Write, Edit, Bash) for all file
operations. It makes no GitHub API calls — it only reads what is already installed.

Related: [forge-pin skill design](../../forge-pin/spec/skills.md) |
forge-update skill design _(separate capability)_

Implementation: `plugins/forge/skills/init/`

---

## forge:init

### Arguments

None. `forge:init` has no flags — version management is `forge:pin`'s responsibility.

### Preconditions

- **PC-1:** Forge plugin is installed in the Claude Code plugin cache
- **PC-2:** Not running inside a `.forge/` subdirectory
- **PC-3:** CLAUDE.md (if present) does not contain duplicate `forge:managed:start`
  markers

### Flow

```
Step 1: Discover plugin root from cache
        Prefer forge-local; fall back to rr-standards global install
        plugin_root = dirname(dirname(plugin.json))
        Extract: sha, marketplace_dir, version

Step 2: Detect init mode
        .forge/ exists  → merge mode
        .forge/ absent  → create mode

Step 3: Select repository type (create mode only)
        Prompt: "Source code / Product / Coordination?"
        Map to: deployable | product | project
        Merge mode: read existing repo_type from .forge/version

Step 3b: Legacy repository check (create mode only)
        Prompt: "Is this a legacy repository?"
        Map to: is_legacy = true | false (default false)

Step 3c: Brownfield analysis offer (create mode, repo_type=deployable, is_legacy=false)
        Detect existing source code (build files, source extensions)
        If found: prompt engineer to opt in to repository analysis
        Map to: run_brownfield_analysis = true | false (default false)

Step 4: Determine forge_min_version
        .claude-plugin/marketplace.json exists → read pinned ref, strip "v"
        absent → empty string (unpinned)

Step 5: Create .forge/ directory structure from plugin templates
        Always:      README.md, spec/, efforts/
        deployable:  deployables/
        product:     products/
        Skip files that already exist in merge mode

Step 5c: Brownfield deployable scaffolding (run_brownfield_analysis=true only)
        [Orchestrator] Phase 1: Identify deployables via build file scan (Bash/Glob only,
                       no source file reads); present list for engineer confirmation
        [Orchestrator] Phase 2: Assemble context packet per deployable; spawn one worker
                       sub-agent per deployable concurrently via Task tool
        [Worker]       Step A: Read and analyse deployable — dependencies/stack, entry
                       points, all contract surfaces (REST routes+types, gRPC protos,
                       GraphQL schema, message consumer/producer registrations,
                       in-memory interfaces), data models, config, test posture;
                       identify capabilities from package dirs, route groups, annotations
        [Worker]       Step B: Write .forge/deployables/<name>/ with populated content:
                       spec/README.md — tech stack table, component table, high-level
                       flows; requirements — endpoint/entity/config tables; security
                       posture; test coverage summary; all AI-inferred content wrapped
                       in ⚠ marker; unbridgeable gaps use ✏ Needs input stub
        [Worker]       Step C: Write .forge/deployables/<name>/capabilities/<cap>/
                       spec/README.md — contracts (REST/gRPC/GraphQL/messages/interfaces),
                       data model, component structure, flows, algorithms stub;
                       requirements — inferred from contract surfaces and entity reads
        [Worker]       Step D: Return JSON result {deployable, capabilities, files_created,
                       files_skipped}
        [Orchestrator] Phase 3: Collect worker results; aggregate counts; report failures

Step 6: Write .forge/version
        All 7 fields; skip entirely if file already exists in merge mode

Step 7: Write CLAUDE.md forge:managed section
        Create mode: write full file from template
        Merge mode:  replace section between markers; append if no markers found
        Always refreshed — even in merge mode

Step 8: Install git branch protection hook [orchestrator-only]
        Source:      plugins/forge/hooks/pre-push/pre-push.sh (from the installed Forge plugin)
        Destination: .git/hooks/pre-push
        Action:      copy the template to destination, make it executable (chmod +x)
        If .git/hooks/pre-push already exists:
          - Compare with template
          - If different: overwrite and note the update
          - If identical: skip silently
        Note to engineer: "Branch protection installed: direct pushes to main are blocked.
                           Use git push --no-verify to bypass in emergencies."

        Precondition: .git/ directory exists (the repo is initialized). forge:init runs
        after git init if needed, so this precondition is always met.

Step 9: Print summary
        forge:init complete — forge v<version>
        Repository type: <human-readable label>
        Brownfield: <N deployables, M capabilities> (if run_brownfield_analysis=true)
        Created / Updated / Unchanged (per file)
        Plugin: <marketplace_dir>/forge/<sha[:12]>...
        Pin: <forge_min_version | "unpinned">
        Commit reminder with exact git commands
```

### Key Design Decisions

- `forge:init` never calls the GitHub API — it only reads what's already installed
- `forge_min_version` is derived from `marketplace.json` if present, keeping the
  version record consistent regardless of which skill was run first
- Plugin root is found via `dirname(dirname(plugin.json))` — two levels up from the
  cached `plugin.json`
- `repo_type` is set interactively at first init via a plain-language wizard; merge
  mode re-uses the existing value rather than re-prompting
- `deployables/` and `products/` directories are created only for the repo types that
  use them

### CLAUDE.md Injection — Three-Tier Design

`forge:init` writes a forge-managed section into the project's `CLAUDE.md` as Tier 1
of a three-tier context injection strategy (ADR-001). The tiers are:

| Tier | Mechanism | Size | Content | Persistence |
|------|-----------|------|---------|-------------|
| 1 | CLAUDE.md forge-managed section | ~60-80 lines | Conceptual model + terse intent list | Always present |
| 2 | SessionStart hook output | ~50-80 lines | Routing table + current state | Fresh each session |
| 3 | UserPromptSubmit hook output | ~20-30 lines | Targeted routing re-injection | On-demand |

**Budget constraint:** Tier 1 is capped at ~60-80 lines because CLAUDE.md persists in
Claude's context for the entire session and competes with project-specific instructions.
Routing tables and verbose intent patterns belong in hook output (Tiers 2-3), not here.

**Template location:** `plugins/forge/templates/forge-claude-md-section.md`

The template is the canonical Tier 1 content. `forge:init` reads this file from the
installed plugin and writes it between `<!-- forge:managed:start -->` and
`<!-- forge:managed:end -->` markers in the project's `CLAUDE.md`.

**Merge behaviour:**
- Create mode: write full CLAUDE.md from template
- Merge mode: replace content between existing markers; append if no markers found
- Always refreshed — even in merge mode

**Template content summary:** The managed section contains three things:
1. Conceptual understanding — what Forge is and what `.forge/`'s three subdirectories
   (efforts, deployables, products) contain, including the capabilities naming principle
   from ADR-008
2. Terse intent recognition list — eight one-line entries mapping conversation signals
   to workflow actions (write ADR, update requirements, update spec, update task status,
   record open decision, checkpoint handling, summarize status, initiate graduation)
3. Before-write rule — four steps Claude must follow before writing any `.forge/` file

---

## Version Record (.forge/version)

`forge:init` writes this file. The full field set is shared with
[forge-pin](../../forge-pin/spec/skills.md) and forge-update; fields owned by this
capability are marked below.

```
forge_min_version=<semver>   # read from marketplace.json at init time (forge:pin may set later)
active_version=<semver>      # set by forge:init; updated by forge:update
initialized_with=<semver>    # set by forge:init; never changed after init
initialized_at=<ISO-8601>    # set by forge:init; never changed after init
last_migrated_with=<semver>  # set by forge:update; empty at init
last_migrated_at=<ISO-8601>  # set by forge:update; empty at init
repo_type=deployable          # set by forge:init via interactive prompt; never changed after init
```

**Fields written by forge:init:**

| Field | When | Notes |
|-------|------|-------|
| `forge_min_version` | At init | Reads from `.claude-plugin/marketplace.json` if present; else empty |
| `active_version` | At init | Version of the installed plugin |
| `initialized_with` | At init only | Never changed after init |
| `initialized_at` | At init only | Never changed after init |
| `last_migrated_with` | At init | Written as empty; updated by forge:update |
| `last_migrated_at` | At init | Written as empty; updated by forge:update |
| `repo_type` | At init only | Set via interactive prompt in create mode |
