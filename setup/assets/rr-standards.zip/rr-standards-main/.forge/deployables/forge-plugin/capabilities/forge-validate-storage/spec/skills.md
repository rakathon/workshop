# forge:validate-storage — Skill Specification

**Agent type:** Worker
**Skill file:** `plugins/forge/skills/validate-storage/SKILL.md`

## Purpose

Targeted validation of storage schemas (spec/storage/*.md) against the applicable
organizational storage standard. An inline editing aid for use during
forge:spec-storage — not a phase gate.

## Inputs

- `spec/storage/*.md` — all storage schema files in the effort
- `standards/storage/<type>.md` — the applicable standard, loaded from plugin standards directory

## Worker Steps

1. Load spec/storage/*.md. If none, report: "No storage spec found. Run forge:spec-storage first."
2. Detect storage technology from filename. If ambiguous, list files and ask.
3. Load applicable standard from plugin standards directory.
4. Per entity, apply checks:
   - Primary key defined
   - All fields have explicit types
   - Soft-delete policy documented
   - Indexes are query-driven (cross-reference spec/storage/query-patterns.md if present)
   - PII fields have retention period + deletion obligation
5. Apply technology-specific checks per standard.
6. Print inline report grouped by entity. Format:
   ```
   ## Storage Validation Report
   **Standard:** standards/storage/postgres.md

   ### Entity: users
   - [REQUIRED] email field is PII — retention period not documented
   - [SUGGESTION] Consider partial index on deleted_at for soft-delete queries

   **Summary:** N REQUIRED, M SUGGESTION
   ```
7. Do NOT write any file. Do NOT update .state.json.

## Output

Inline session report only.

## Technology-Specific Checks

### PostgreSQL
- All timestamp fields must use TIMESTAMPTZ
- Composite PKs require documented justification
- Index names follow `idx_<table>_<column>` pattern
- UUID PKs preferred over serial/integer

### DynamoDB
- entity_type and schema_version fields required on every item type
- Partition key must be defined with access-pattern justification
- All attribute names must be snake_case
- Timestamp fields must use ISO-8601 format
- GSI count: warn if > 10, require action if > 20

### Redis
- Key schema must document naming pattern
- TTL required for session data, tokens, and caches
- Data structure type must be specified per key

### OpenSearch
- Index mapping must define field types
- Analyzer config recommended for text search fields
- Index name pattern: `<service>-<entity>-<env>`

### Browser Extension Storage
- All storage keys must be namespaced by feature/module
- Schema version field (_version) recommended
- Sensitive data must have encryption noted

## PII Fields (Default Detection)

The following field names are treated as PII by default:
email, name, first_name, last_name, phone, phone_number, dob, date_of_birth,
address, postal_code, zip_code, ip_address, device_id, ssn, tax_id,
credit_card, card_number, account_number, gender, nationality, any field
with `_pii` suffix or explicit PII annotation.

## Constraints

- Must NOT write to validation/report.md
- Must NOT update .state.json
- Must NOT write any other file
- All output is inline session content only
- Can be run multiple times during discovery without side effects
