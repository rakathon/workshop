# forge:graduate Skill Design

Design for the `forge:graduate` skill. The skill runs as an isolated worker sub-agent,
receives an effort ID from the orchestrator, and returns a graduation report.

Implementation: `plugins/forge/skills/graduate/`

---

## forge:graduate

### Classification

**Worker (isolated sub-agent)**

The skill reads the full set of effort artifacts and the full set of existing canonical
documentation for each associated deployable or product, then produces a merged result.
This is a large-context operation. Running it in the main session would consume context
budget needed for subsequent engineering work. Isolation keeps the main session clean
while graduation runs in a dedicated context window.

### Arguments

| Argument | Type | Description |
|----------|------|-------------|
| `effort_id` | string | The ID of the effort to graduate (e.g., `favorite-stores`) |

No other arguments. The worker derives all paths from the effort ID and the effort's
`.state.json`. The orchestrator does not pass file paths or deployable names — those are
read from state.

### Preconditions

- **PC-1:** `.forge/efforts/<effort_id>/` exists
- **PC-2:** `.forge/efforts/<effort_id>/.state.json` is present and readable
- **PC-3:** `.state.json` has at least one entry in `deployables` or `businessProducts`
- **PC-4:** The effort is not already graduated (`graduation.graduated` is absent or false)

---

### Steps

#### Step 1 — Read effort `.state.json`

Read `.forge/efforts/<effort_id>/.state.json`. Extract:

- `deployables` — list of deployable names to update
- `businessProducts` — list of product names to update (coordination efforts)
- `capabilities` — specific capability within a deployable (if scoped)
- `phases.*.postApprovalModifications` — all post-approval modification records across
  all phases

If `deployables` and `businessProducts` are both empty or absent, halt immediately and
return an error report:

```
ERROR: forge:graduate cannot proceed — effort <id> has no associated deployables or
products in .state.json. Set 'deployables' or 'businessProducts' before graduating.
```

#### Step 2 — Read all effort artifacts

Read the complete artifact set from the effort directory:

- `requirements/` — all requirement documents
- `spec/` — all specification documents
- `capabilities/<cap>/` — capability-scoped artifacts (if `capabilities` is populated)
- `plan/` — implementation plan (for context only; not promoted to canonical docs)

Do not read validation reports, verification reports, or arch-review output — these are
effort-internal artifacts and are not promoted to canonical documentation.

#### Step 3 — Read current canonical documentation

For each deployable in the `deployables` list, read the current contents of:

- `.forge/deployables/<name>/requirements/` — all existing requirement documents
- `.forge/deployables/<name>/spec/` — all existing specification documents
- `.forge/deployables/<name>/capabilities/<cap>/` — if the effort is capability-scoped

For each product in the `businessProducts` list, read the current contents of:

- `.forge/products/<name>/requirements/`
- `.forge/products/<name>/spec/`

If a target directory does not exist, it will be created in Step 7.

#### Step 4 — Merge effort artifacts into canonical documentation

For each artifact type, apply the merge algorithm. The algorithm is **update, not append**:
the canonical document must be a single coherent document after graduation, not a layered
record of successive efforts.

**Merge algorithm:**

```
For each effort artifact file:
  1. Identify the corresponding canonical document (by name convention)
  2. If the canonical document does not exist → create it from the effort artifact
  3. If the canonical document exists:
     a. Parse the sections in both documents (H2 headings as section boundaries)
     b. For each section in the effort artifact:
        - If the section exists in the canonical document → replace its content
        - If the section does not exist in the canonical document → append it
     c. Preserve sections in the canonical document not addressed by the effort
  4. Add the provenance comment (Step 5) to the top of the document
```

**Example — correct (update):**

Before graduation, `deployables/favorites-backend/requirements/business.md` contains:

```markdown
# Business Requirements

## BR-1: Users Can Save Favorite Stores
[original content from a prior effort]
```

After graduating the "favorite-stores-v2" effort, which updated BR-1 and added BR-2:

```markdown
<!-- graduated-from: favorite-stores-v2 at 2026-03-27T14:30:00Z -->
# Business Requirements

## BR-1: Users Can Save Favorite Stores
[updated content from favorite-stores-v2 — replaces the original]

## BR-2: Users Can Reorder Favorites
[new section added by favorite-stores-v2]
```

**Example — incorrect (append — do not do this):**

```markdown
# Business Requirements

## BR-1: Users Can Save Favorite Stores
[original content — preserved unchanged]

## Requirements added by favorite-stores-v2

### BR-1: Users Can Save Favorite Stores (Updated)
[updated content added alongside original]

### BR-2: Users Can Reorder Favorites
[new content appended]
```

The append pattern is a graduation failure. It creates duplicate sections and forces
readers to reconcile conflicting content. Never produce it.

#### Step 5 — Add provenance metadata

After merging, add a provenance comment to each updated canonical document. Place the
comment immediately after the H1 heading line:

```markdown
# Document Title
<!-- graduated-from: <effort_id> at <ISO-8601-timestamp> -->
```

If a provenance comment from a previous graduation already exists in the document,
replace it with the new one. There must be at most one provenance comment per document.

#### Step 6 — Verify ADR provenance

For each ADR produced by this effort (listed in `.state.json` under `adrs`), verify that
the ADR document at `.forge/spec/arch-decisions/<adr-file>` contains a `**Created by:**`
field referencing this effort:

```markdown
**Created by:** <effort_id>
```

Do not move or copy ADRs. Do not modify ADR content. If an ADR is missing the effort
reference, add only the `**Created by:**` metadata field. Record any ADRs that required
this fix in the graduation report.

If the ADR does not exist in the canonical directory, record this as a missing ADR in
the graduation report. Do not create the ADR — its absence means it was never written
to the canonical location and requires engineer attention.

#### Step 7 — Write updated canonical documentation

Write all merged documents to their canonical paths. Create parent directories as needed.

The set of files written in this step becomes the `graduatedTo` list recorded in Step 8.

#### Step 8 — Update `.state.json` graduation fields

Update `.forge/efforts/<effort_id>/.state.json` to add:

```json
{
  "graduation": {
    "graduated": true,
    "graduatedAt": "<ISO-8601 timestamp>",
    "graduatedTo": [
      ".forge/deployables/<name>/requirements/business.md",
      ".forge/deployables/<name>/requirements/technical.md",
      ".forge/deployables/<name>/spec/api/...",
      "..."
    ]
  }
}
```

`graduatedTo` must list every file path written in Step 7, relative to the repository
root (prefixed with `.forge/`).

#### Step 9 — Remove effort row from `.forge/efforts/README.md`

Remove the effort's row from the active registry. The effort directory remains intact.
Only the registry row is removed.

The registry is line-oriented: each effort occupies exactly one row. Remove that row and
no other content. Do not reformat the table or adjust surrounding rows.

#### Step 10 — Commit graduation changes

Stage and commit all changes from Steps 7, 8, and 9 in a single commit:

```
docs(graduation): graduate effort-<id> to <deployable-name>
```

The commit must contain only:
- Updated canonical documentation files (from Step 7)
- Updated effort `.state.json` (from Step 8)
- Updated `.forge/efforts/README.md` (from Step 9)

No source code, no test files, no other content.

#### Step 11 — Return graduation report to main session

Compose and return the graduation report. The report is the only output from the worker.
The orchestrator presents it to the engineer.

**Graduation report format:**

```
## forge:graduate — Graduation Report

**Effort:** <effort_id>
**Graduated at:** <ISO-8601 timestamp>
**Target:** <deployable or product name>

### Files Updated

- `.forge/deployables/<name>/requirements/business.md` (updated)
- `.forge/deployables/<name>/requirements/technical.md` (updated)
- `.forge/deployables/<name>/spec/api/endpoints.md` (created)
- ...

### ADR Verification

- ADR-003: ✓ Created by effort-<id> field present
- ADR-004: ✓ Created by effort-<id> field present

### Post-Approval Modifications Reconciled

[If none:]
None. All graduated artifacts were in their approved state.

[If present:]
The following artifacts were modified after their phase was approved. The graduated
documents reflect the final (modified) state, not the originally approved state.

| Artifact | Modified in phase | Commit |
|----------|------------------|--------|
| `requirements/technical.md` | implementation | abc1234 |
| `spec/api/endpoints.md` | implementation | def5678 |

These modifications have been promoted to canonical documentation. No further action
is required unless the modifications represent a significant design change that
warrants a new ADR.

### Summary

Graduation complete. Effort effort-<id> is now closed.
```

---

### [orchestrator-only] Sections

The following steps are performed by the orchestrator in the main session, not by the
worker. When the skill runs as a worker sub-agent, skip these entirely.

**[orchestrator-only] Pre-graduation checks:**

Before launching the worker, the orchestrator must confirm:

1. Read `.state.json` and verify `currentPhase` is at or past `qa` and all required
   phases have a `status` of `complete` or `approved`
2. Confirm with the engineer that QA has signed off in a pre-production environment
3. Check for post-approval modifications and inform the engineer before proceeding
4. Launch `forge:graduate` as an isolated sub-agent, passing the effort ID

**[orchestrator-only] Post-graduation actions:**

After receiving the graduation report from the worker:

1. Present the graduation report to the engineer
2. If any missing ADRs were reported, prompt the engineer to write them before closing
3. Confirm the graduation commit was created

The worker does not perform these steps. The worker receives the effort ID, runs Steps
1–11, and returns the graduation report.
