# ADR-001: Interview Model Replaces Automated TR Derivation

**Status:** Accepted
**Date:** 2026-04-25
**Capability:** forge-elaborate

---

## Context

The original `forge:elaborate` read `requirements/business.md`, mechanically applied five
technical dimension categories (performance, scale, integrations, security/privacy,
consistency/durability) to each BR, drafted a complete set of TRs, and presented them to
the engineer for review in a single pass.

This model produced technically valid TR documents but did not produce shared understanding.
The engineer reviewed an AI-generated document and approved or edited it — a document review,
not a design collaboration. Engineers reported that the resulting TRs felt like paperwork rather
than thinking. The deeper problem: gaps in the business requirements were not surfaced because
the skill had no mechanism to ask "but what does this BR actually mean?" — it could only derive
technical implications from what was written, not identify what was missing.

The root cause is that automated derivation treats requirements as a complete input and produces
a technical translation as output. Real discovery is iterative: requirements and design inform
each other, earlier gaps are exposed by later questions, and the most valuable thinking happens
in the conversation, not in the document review.

---

## Decision

Replace automated TR derivation with a conversational interview model. The skill reads all
existing artifacts to understand what has been established, then interviews the engineer with
relentless, dependency-ordered questions until a genuine shared understanding is reached.

For each question, the skill provides a recommended answer with rationale. When an answer is
agreed upon, it is classified and written immediately to the appropriate artifact — not
accumulated for a final batch write.

The interview is not a fixed sequence of questions. It follows a natural dependency ordering
(business requirements → technical constraints → data model → contracts → internal implementation)
as a default orientation, but cycles back freely when deeper exploration reveals gaps in earlier
layers.

---

## Consequences

**Positive:**
- Engineers develop genuine understanding of the problem, not just document coverage
- Gaps in business requirements are surfaced during the interview, before implementation
- The skill is useful at any stage of discovery — it reads what exists and asks about what's missing
- The iterative, cycling nature of the interview matches how good engineering design actually works

**Negative:**
- The skill is slower than automated derivation for efforts where requirements are already complete
- The quality of the interview depends on the skill exercising good judgment about question ordering and depth — this is harder to specify precisely than a mechanical derivation algorithm

**Mitigations:**
- The natural dependency ordering heuristic gives the skill a starting orientation
- The skill is instructed to skip layers where artifacts are already complete and not to ask about what is already resolved
