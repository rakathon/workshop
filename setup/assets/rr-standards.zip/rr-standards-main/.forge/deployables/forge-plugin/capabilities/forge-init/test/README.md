# Test Strategy — forge-init

## Scope

| Area | What is tested |
|------|---------------|
| `inject-generation-standards.sh` | Language detection, guide path resolution, graceful degradation, compliance exemption bypass |
| `forge-version-check.sh` | Version comparison, active work detection, deadline enforcement, degraded network mode, compliance exemption bypass |
| `forge:init` skill | Idempotency (create vs. merge mode), directory structure per repo_type, CLAUDE.md create and merge, `.forge/version` field population, hook registration in settings.json, summary output format |

---

## Approach

### Hook Unit Tests

Both hooks are critical infrastructure — a silently failing hook means standards are
not enforced and no tool will detect the gap. Hooks require deterministic unit tests
in isolation.

Test framework: shell-based test scripts exercising the hook scripts directly with
controlled environment variables and fixture files.

**inject-generation-standards.sh test cases:**

| Test case | Input | Expected output |
|-----------|-------|----------------|
| Go file | `FILE_PATH=main.go`, guide present | Guide content on stdout; exit 0 |
| Java file | `FILE_PATH=Service.java`, guide present | Guide content on stdout; exit 0 |
| TypeScript file | `FILE_PATH=index.ts`, guide present | Guide content on stdout; exit 0 |
| Python file | `FILE_PATH=app.py`, guide present | Guide content on stdout; exit 0 |
| Markdown file | `FILE_PATH=README.md` | Empty stdout; exit 0 |
| No extension | `FILE_PATH=Makefile` | Empty stdout; exit 0 |
| Guide absent | `FILE_PATH=main.go`, no guide | Warning on stderr; exit 0 |
| Plugin root bad | Hook moved from expected location | Warning on stderr; exit 0 |
| No FILE_PATH | Environment variable unset | Empty stdout; exit 0 |
| Exempt repo | `.forge/compliance` has `coding_standards=exempt` | Empty stdout; exit 0 |

**forge-version-check.sh test cases:**

| Test case | Fixture state | Expected output |
|-----------|--------------|----------------|
| Uninitialized repo | No `.forge/version` | Notice on stderr; exit 0 |
| Compliance exempt | `.forge/compliance` has `coding_standards=exempt` | Notice on stderr; exit 0 |
| Version current | `active_version=forge_min_version` | Exit 0 silently (no output) |
| Version behind, no active task | `active < min`, no `.state.json` | Error on stderr; exit 1 |
| Version behind, active task | `active < min`, impl in_progress `.state.json` | Warning on stderr; exit 0 |
| Malformed version | `.forge/version` missing fields | Warning on stderr; exit 0 |
| Deadline passed | `mandatoryAfter` set to past date | Error on stderr; exit 1 |
| Within 30-day window | `mandatoryAfter` 15 days away | Warning on stderr; exit 0 |
| Outside window | `mandatoryAfter` 60 days away | Exit 0 silently |
| Major not in VERSIONS | `v99` not in JSON | Exit 0 silently |
| `gh` unavailable | Mock `gh` to return empty | Warning on stderr; exit 0 |

### Skill Behavioral Tests

`forge:init` is tested using the with/without-context eval methodology from rr-standards.
`.evals.json` companion file alongside `SKILL.md`.

The eval set must have ≥ 5 compliant and 5 non-compliant examples covering the main
behavioral rules. `rr-standards:validate --active` provides the harness.

### Integration Tests

End-to-end tests covering the full initialization and upgrade lifecycle on a temporary
git repository:

1. Fresh repo → `forge:init` → verify all files created with correct content
2. Existing CLAUDE.md → `forge:init` → verify only forge:managed section added;
   pre-existing content preserved
3. `forge:init` → re-run `forge:init` → verify no files overwritten (idempotency)
4. Pre-existing `.claude-plugin/marketplace.json` (written by forge:pin) → `forge:init`
   → verify `forge_min_version` populated from pin
5. `forge:init` with no marketplace.json → verify `forge_min_version` written as empty

---

## Test Plans

_None yet — to be added during implementation phase._

## Coverage Notes

The injection hook and version enforcement hook are the highest-priority items for
automated testing. Skill behavioral tests catch regression in the LLM-executed
workflows. Integration tests catch file system and settings.json edge cases that unit
tests cannot exercise.
