# forge:validate-api — Skill Specification

**Agent type:** Worker
**Skill file:** `plugins/forge/skills/validate-api/SKILL.md`

## Purpose

Targeted validation of API contracts (spec/api/*.yaml) against the organization's
REST standards. An editing aid for use during forge:spec-api authoring. Provides
immediate inline feedback without writing to validation/report.md or updating state.

## When to Use

Use during or after forge:spec-api to get immediate standards feedback on the
current API contract. Not a substitute for forge:validate (which is the phase gate).

## Inputs

- `spec/api/*.yaml` — all OpenAPI contract files in the effort
- `standards/api/rest/` — loaded from the Forge plugin standards directory

## Worker Steps

1. Locate all `spec/api/*.yaml` files. If none found, report: "No API spec found. Run forge:spec-api first."
2. Load the REST standard from the plugin standards directory.
3. For each YAML file, parse and apply checks:
   - Contract-level: components/schemas/Error present, info.version present and semver, all $ref resolve
   - Per endpoint: resource path is a noun, correct status codes (200/201/204/400/401/404/422/500), error response schema uses Error component, write operations (POST/PUT/PATCH/DELETE) have auth specified
4. Compute per-endpoint and per-contract findings with severity (REQUIRED / SUGGESTION).
5. Print inline report grouped by endpoint. Format:
   ```
   ## API Validation Report
   **Standard:** standards/api/rest/

   ### Contract
   - [REQUIRED] components/schemas/Error is not defined
   - [REQUIRED] info.version "1.0" does not follow semver (expected x.y.z)

   ### POST /resources
   - [REQUIRED] Missing 401 response for authenticated endpoint
   - [SUGGESTION] Consider adding 429 for rate limiting

   ### GET /resources/{id}
   - [REQUIRED] Missing 404 response

   **Summary:** N REQUIRED, M SUGGESTION
   ```
6. Do NOT write any file. Do NOT update .state.json.

## Output

Inline session report only. No artifact written.

## Checks Reference

### Contract-Level Checks

| Check | Severity | Description |
|-------|----------|-------------|
| `components/schemas/Error` present | REQUIRED | Top-level error schema must be defined |
| `info.version` semver | REQUIRED | Version must follow x.y.z format |
| All `$ref` resolve | REQUIRED | Every reference must point to a defined component |

### Per-Endpoint Checks

| Check | Severity | Description |
|-------|----------|-------------|
| Resource path is a noun | REQUIRED | Path segments must not contain action verbs |
| Required status codes declared | REQUIRED | See per-method matrix below |
| Error responses reference Error schema | REQUIRED | 4xx/5xx must use Error component |
| Write operations have auth | REQUIRED | POST/PUT/PATCH/DELETE must declare security |

### Status Code Matrix

| Method | Required Codes | Optional (SUGGESTION) |
|--------|---------------|----------------------|
| GET | 200, 400, 401, 404, 500 | 429 |
| POST | 201, 400, 401, 422, 500 | 429 |
| PUT | 200, 400, 401, 404, 422, 500 | 429 |
| PATCH | 200, 400, 401, 404, 422, 500 | 429 |
| DELETE | 204, 400, 401, 404, 500 | 429 |

## Constraints

- MUST NOT write `validation/report.md`
- MUST NOT update `.state.json`
- MUST NOT create any file system artifact
- Runs as worker agent (isolated context, does not pollute main session)
