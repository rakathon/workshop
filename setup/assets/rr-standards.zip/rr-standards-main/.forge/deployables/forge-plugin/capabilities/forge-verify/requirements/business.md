# Business Requirements — forge-verify

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-3, BR-6, BR-12
New capability BRs: BR-13

---

## BR-13: Completing All Implementation Tasks Must Not Be Confused with Delivering the Effort's Goals

Task completion is a statement about code quality within the scope of a single task —
the code compiles, linters pass, the task's acceptance criteria are satisfied, tests
pass. It is not a statement about whether the effort as a whole delivers its stated
goals.

An effort can have every task marked complete and still fail to deliver:

- A task may implement a stub that compiles but does not provide real behavior. The
  per-task quality loop validates the stub as correct because the stub satisfies the
  task's acceptance criteria.
- Wiring between components may be missing. Individual tasks implement both ends of a
  connection, but the connection is never made. Each task passes verification in
  isolation; the system does not work end-to-end.
- A business requirement may be addressed by no task at all — a gap in planning that
  was not caught during the plan phase.
- Multiple tasks may together satisfy a requirement only when all are complete, but no
  individual task's acceptance criteria captures the cross-task dependency.

Engineers opening a pull request need to know the implementation actually works before
asking reviewers to invest time. A PR opened on a codebase that has every task checked
off but has integration gaps, stubs in load-bearing paths, or uncovered requirements
wastes reviewer effort and erodes confidence in the planning process.

The workflow must provide a distinct, final check — after all implementation tasks are
complete but before the PR is opened — that answers the question the per-task quality
loop cannot: does the complete implementation deliver what the effort promised?

## BR-14: The Per-Task Quality Loop Must Be a Shared Contract Across All Implementation Skills

The Forge workflow will have multiple implementation skills for different domains:
`forge:build-api`, `forge:build-repo`, and others. Each of these skills executes
implementation tasks. The quality loop that runs within each skill — implement, lint,
validate against spec, test, commit — must be consistent across all skills.

An engineer switching from backend to API work should not encounter different iteration
limits, different escalation formats, or different TDD disciplines depending on which
build skill is running. A CI pipeline interpreting task state from `.state.json` must
be able to rely on a uniform escalation structure regardless of which implementation
skill produced it.

The quality loop is infrastructure, not a per-skill concern. It must be defined once,
as a shared contract, and every implementation skill must execute it identically. Adding
a new implementation skill must not require redesigning the quality loop from scratch.

---

Success criteria: [success-criteria.md](success-criteria.md)
