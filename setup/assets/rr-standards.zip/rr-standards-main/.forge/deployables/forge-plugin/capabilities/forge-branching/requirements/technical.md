# Technical Requirements — forge-branching

Parent deployable: [forge-plugin](../../requirements/technical.md)

---

## TR-1: enforce-branch-policy.sh — PreToolUse Hook

### TR-1.1: Trigger

The hook is registered as a Claude Code `PreToolUse` hook at project scope in
`.claude/settings.json`. It fires on every Bash tool call.

### TR-1.2: Detection Logic

The hook must evaluate the following conditions in order before blocking:

1. **Tool name check:** The tool name must be `Bash`. If the tool is not `Bash`, exit 0
   immediately without reading the command or checking the branch.
2. **Command check:** The command (read from `CLAUDE_TOOL_INPUT`) must contain the
   substring `git commit` or `git push`. Substring match only — no parsing. If neither
   substring is present, exit 0 immediately.
3. **Admin override check:** If `FORGE_ALLOW_MAIN_COMMIT` equals `1` or if
   `FORGE_ADMIN_OP` is set and non-empty, proceed to the admin override path: write an
   audit log entry (TR-2.2) and exit 0.
4. **Current branch:** Run `git branch --show-current` and capture the output. If the
   output is empty (detached HEAD state), exit 0 — no branch to protect.
5. **Default branch:** Determine the default branch by reading
   `git config init.defaultBranch`; if not set, the fallback is `main`.
6. **Branch comparison:** If the current branch (step 4) does not equal the default
   branch (step 5), exit 0 — the engineer is already on a feature branch.
7. **Block:** If the current branch equals the default branch and no override is active,
   the hook blocks (exit 2) with a structured diagnostic on stderr.

### TR-1.3: Exit Code Table

| Condition | Exit Code | Effect |
|-----------|-----------|--------|
| Tool is not Bash | 0 | Allowed — not a shell command |
| Command has no `git commit` / `git push` | 0 | Allowed — not a commit/push |
| `FORGE_ALLOW_MAIN_COMMIT=1` or `FORGE_ADMIN_OP` set | 0 | Allowed — override active; audit log written |
| Current branch is empty (detached HEAD) | 0 | Allowed — no branch to protect |
| Current branch is not the default branch | 0 | Allowed — not on main |
| Current branch equals default branch, no override | 2 | Blocked — branch policy violation |

### TR-1.4: Structured Diagnostic Format

When blocking, the hook must emit the following JSON object to stderr:

```json
{
  "type": "branch_policy_violation",
  "blocked": true,
  "reason": "Direct commits to 'main' are not permitted. All work must happen on a feature branch and be merged via pull request.",
  "currentBranch": "<current-branch>",
  "activeEffort": "<effort-id or null>",
  "nextAction": "Switch to your effort branch: git checkout effort/<effort-id>"
}
```

Field rules:
- `currentBranch` — the value returned by `git branch --show-current`
- `activeEffort` — the active effort ID read from `.forge/efforts/README.md` if present;
  `null` if no active effort can be determined
- `nextAction` — if an active effort is found: `"Switch to your effort branch: git checkout effort/<effort-id>"`;
  if no active effort: `"Create an effort branch first: use forge:effort to start a new effort"`

### TR-1.5: Active Effort Detection

The hook must attempt to read the active effort ID from `.forge/efforts/README.md`. It looks
for a row in the efforts table where the status column is `active` and extracts the
effort ID from that row.

If `.forge/efforts/README.md` does not exist or cannot be parsed, set `activeEffort` to `null`
and proceed. If multiple active effort rows are found, use the first one in the table.
The hook must never exit 2 due to a `.forge/efforts/README.md` read failure — fail open (treat
as no active effort).

If `.forge/efforts/README.md` is absent, unreadable, unparseable, or contains no active effort
row, `activeEffort` is `null` and the `nextAction` instructs the engineer to create an
effort.

### TR-1.6: Performance Constraint

The hook must complete in under 100ms. This is achieved by:
- Exiting immediately on tool name mismatch (no git calls)
- Exiting immediately on command mismatch (no git calls)
- Using a single `git branch --show-current` call (one process)
- Using a single `git config` call only when needed
- No file I/O beyond the optional effort ID read

---

## TR-2: Admin Override Protocol

### TR-2.1: Override Signals

The hook recognizes two environment variable signals as administrative overrides:

- `FORGE_ALLOW_MAIN_COMMIT=1` — general admin override; explicitly set by the
  engineer for the current shell invocation only
- `FORGE_ADMIN_OP=<reason>` — set by Forge skills (`forge:init`, `forge:update`) when
  performing a legitimate operation that requires touching the default branch

Both variables must be set in the environment for the specific shell session only.
They must not be persisted in any file tracked by git or in any shell profile.

If both `FORGE_ALLOW_MAIN_COMMIT=1` and `FORGE_ADMIN_OP` are set, the `FORGE_ADMIN_OP`
value is used as the reason in the audit log — it is more specific than the general
flag.

When either override is detected, the hook must:
1. Allow the operation (exit 0)
2. Write an audit log entry to `.forge/audit/` (TR-2.2)

### TR-2.2: Audit Log Format

Every administrative bypass must produce an audit record at:
`.forge/audit/<ISO-8601-timestamp>.json`

The audit record must contain:

```json
{
  "operation": "direct_commit_override",
  "reason": "<value of FORGE_ADMIN_OP, or 'FORGE_ALLOW_MAIN_COMMIT=1 set by engineer' if only the general flag is set>",
  "branch": "<current branch at time of override>",
  "timestamp": "<ISO-8601 UTC timestamp>"
}
```

The `.forge/audit/` directory is created by the hook if it does not exist.

Audit log files are named with the UTC ISO-8601 timestamp at the moment of the override,
replacing colons with hyphens to produce a valid filename:
`<YYYY-MM-DDTHH-MM-SSZ>.json`

Example: `2026-03-27T14-30-00Z.json` — note that colons are replaced with hyphens
throughout (including between hours, minutes, and seconds).

---

## TR-3: pre-push.sh — Git Hook Template

### TR-3.1: Standard Git Hook Interface

`pre-push.sh` is a standard git `pre-push` hook. Git invokes it with the remote name
and remote URL as arguments. For each ref being pushed, git writes one line to the
hook's stdin in the format:
`<local ref> <local sha1> <remote ref> <remote sha1>`

### TR-3.2: Detection Logic

The hook reads all refs from stdin. For each ref, it checks whether the remote ref
(field 3) equals `refs/heads/main` or `refs/heads/master`. If any pushed ref targets
either of these values, the hook blocks by printing an error message to stderr and
exiting 1.

If no pushed ref targets the default branch, the hook exits 0.

### TR-3.3: Block Message Format

When blocking, the hook must print the following to stderr, inserting the actual target
branch name (extracted from the pushed ref) in place of `<branch>`:

```
forge: direct push to '<branch>' is not permitted. Open a pull request instead.
All work must be merged via pull request.

To open a pull request: gh pr create
To bypass this check (emergency only): git push --no-verify
```

For example, if the target branch is `main` the first line reads:
`forge: direct push to 'main' is not permitted. Open a pull request instead.`

### TR-3.4: No-Verify Bypass

The `--no-verify` flag is a standard git mechanism that causes git to skip all hooks
when pushing. The `pre-push.sh` hook does not implement any additional bypass logic —
when `git push --no-verify` is used, git simply does not invoke the hook. This is the
intended emergency bypass path.

### TR-3.5: Installation

`forge:init` installs this hook by copying
`plugins/forge/hooks/pre-push/pre-push.sh` to `.git/hooks/pre-push` and making it
executable. The hook is not committed to the repository (`.git/` is not tracked by
git), but engineers who clone the repository can reinstall it by re-running `forge:init`.

---

## TR-7: Branch Naming Taxonomy

Effort-level requirement: [TR-7 in forge-branching effort](../../../../../efforts/forge-branching/requirements/technical.md#tr-7-branch-naming-taxonomy)

All branches in a Forge-managed repository must match one of the following patterns:

- `effort/<effort-id>` — created automatically by `forge:effort` and `forge:project`
- `<type>/<slug>` — where `<type>` is one of: `feature`, `fix`, `hotfix`, `chore`, `docs`, `refactor`, `release`

`enforce-branch-policy.sh` validates the current branch name against these patterns on
every intercepted `git commit`. If the name does not match, the hook blocks with a
`branch_name_violation` diagnostic (exit 2) that includes the invalid name, the list of
allowed formats, and a suggested rename command.

See the hooks spec for the full validation regex and structured diagnostic format.

---

## TR-8: CLAUDE.md Branch Creation Intent Patterns

Effort-level requirement: [TR-8 in forge-branching effort](../../../../../efforts/forge-branching/requirements/technical.md#tr-8-claudemd-must-include-branch-creation-intent-patterns-and-type-inference)

The forge-managed CLAUDE.md section must include type-inference rules that allow the
agent to create an appropriately named branch without prompting when the engineer
describes work conversationally. Type is inferred in priority order from keywords in
the engineer's request (bug/crash/error → `fix`, production/urgent → `hotfix`, docs →
`docs`, cleanup/refactor → `refactor`, dependency/version → `chore`, release/tag →
`release`, new functionality → `feature`). If the type is genuinely ambiguous, the
agent asks one clarifying question listing the options.

The slug is derived from the 3–5 most descriptive words in the request (lowercase,
hyphen-joined, articles and prepositions dropped). Branch creation runs
`git checkout -b <type>/<slug>` and confirms the branch name to the engineer.

---

## TR-9: Push-Time Branch Alignment Warning

Effort-level requirement: [TR-9 in forge-branching effort](../../../../../efforts/forge-branching/requirements/technical.md#tr-9-enforce-branch-policysh-must-emit-a-push-time-alignment-warning)

When `enforce-branch-policy.sh` intercepts a `git push` command (after the default-branch
block check and format validation pass), it must perform an advisory alignment check:
does the work being pushed match the branch type?

The check invokes `claude -p` with the branch name, recent commit messages, and changed
file paths, asking whether the branch type matches the work. The subprocess is bounded
by a 10-second timeout. If misaligned, the hook emits a warning to stdout and exits 0 —
the push always proceeds. If the subprocess fails or times out, the check is skipped
silently.

Setting `FORGE_SKIP_BRANCH_VALIDATION=1` bypasses push-time checks (both alignment and
any push-specific format checks); commit-time format validation (TR-7) is unaffected by
this bypass.

---

## Constraints

- The PreToolUse hook must complete in under 100ms (single git command + string match)
- `FORGE_ALLOW_MAIN_COMMIT` must not be persisted in any file tracked by git;
  environment variable only — it cannot become a default
- `FORGE_ADMIN_OP` must not be persisted; it is set only by Forge skills for the
  duration of the specific operation
- The hook must not break existing workflows on feature branches — all such operations
  exit 0 at the branch check step without any file I/O or diagnostic output
- The audit directory (`.forge/audit/`) must be created on demand; `forge:init` does
  not pre-create it
