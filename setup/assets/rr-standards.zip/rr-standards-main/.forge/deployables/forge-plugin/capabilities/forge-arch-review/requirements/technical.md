# Technical Requirements — forge-arch-review
<!-- graduated-from: arch-review at 2026-05-04T20:02:05Z -->

Parent deployable: [forge-plugin](../../requirements/technical.md)
Implements: TR-11a (Design Validation Report + HTML Presentation)

---

## TR-1: Skill is installed at `plugins/forge/skills/arch-review/`

*Traces to: BR-1*

The skill must live at the top-level `skills/` path — only skills directly under `skills/` are installed by the plugin. The previous stub at `skills/discovery/arch-review/` was never installed and has been removed.

---

## TR-2: Skill runs `forge:validate` if `validation/report.md` is absent or stale

*Traces to: BR-3*

Before generating the HTML, the skill checks whether `validation/report.md` exists and was produced after the most recent modification to any discovery artifact (excluding `spec/rollout.md`, `spec/cost.md`, `spec/risks.md` which are written during the interview). If absent or stale, it runs `forge:validate` first. If current, it uses the existing report directly.

---

## TR-3: HTML document permits two external resources only

*Traces to: BR-1*

The generated HTML file must open correctly via `file://`. Two external dependencies are permitted:
1. Google Fonts `@import` — for typography (Playfair Display, Source Serif 4, IBM Plex Mono)
2. Mermaid JS CDN `<script>` — for C4 diagram rendering. If opened offline, Mermaid source text remains readable.

All other CSS is written inline in a `<style>` block. No CDN references for JavaScript frameworks or UI libraries. File size must not exceed 500KB.

---

## TR-4: Visual design follows the PR #246 design system

*Traces to: BR-1*

The HTML uses:
- Three-family typography: Playfair Display (display headings ≥20px), Source Serif 4 (body), IBM Plex Mono (labels/metadata/badges)
- Brand colour: `#8529cd`
- Background: `#f9f6fe`
- Status colours: green `#009470`, red `#b83232`, yellow `#b08000`, blue `#1d4ed8`
- Section structure: `padding: 72px 0`, `max-width: 1100px`, alternating `.alt` backgrounds
- Section headers: `2px solid var(--brand)` bottom border, Playfair Display h2 at 28px

---

## TR-5: C4 diagrams use Mermaid C4Context/C4Container syntax

*Traces to: BR-4*

Diagrams are written using proper Mermaid C4 diagram types (`C4Context`, `C4Container`). System-context diagrams are generated for all efforts; container-level diagrams are generated when multiple services or deployables are identified in the spec artifacts.

---

## TR-6: API contracts rendered as self-contained accordion with security badges

*Traces to: BR-5*

The interactive API accordion uses `<details>`/`<summary>` HTML elements — no external renderer. Each endpoint summary shows:
- HTTP method tag (coloured)
- Auth badge: `AUTH ✓` (green) if `security` declared; `AUTH ✗` (red) if absent
- Input validation badge: `INPUT VALIDATION ✓/~/✗` based on schema constraints

---

## TR-7: Messaging cards show base class + extensions only

*Traces to: BR-5*

Message contracts are rendered as cards showing:
- Contract name, topic, compatibility mode
- Base class (`Message`, `UserInitiatedMessage`, or `ApiInitiatedMessage`) with brief description
- Extension fields only (beyond the base class schema) in a collapsible `<details>` block

Base class envelope fields (`message_id`, `event_name`, `event_version`, `produced_at_ms`, `trace_id`, and base-class-specific fields) are NOT listed as extension fields — they are pre-approved and not repeated.

---

## TR-8: Data-mapping output detection is file-based

*Traces to: BR-7*

The skill detects governance classification by checking for files matching `spec/data-mapping*.md` or `spec/governance*.md` in the effort directory. If absent, §4 renders a standardised gap notice. Detection must not fail on efforts that predate data-mapping tooling.

---

## TR-9: Validation findings are prioritised using a deterministic rule

*Traces to: BR-3*

Priority classification:
- `**REQUIRED**` severity → always "must examine in depth"
- `**SUGGESTION**` mentioning security, privacy, PII, authentication, authorisation, or an uncovered BR → "must examine in depth"
- All other `**SUGGESTION**` findings → "safe to skip if time-limited"

The priority label uses a visually distinct colour-coded badge.

---

## TR-10: Skill output path and commit convention

*Traces to: BR-1*

The skill writes two files and stages/commits them atomically (along with any interview spec files):
- `<effort_dir>/validation/report.md` — machine-readable findings (for `forge:promote`)
- `<effort_dir>/validation/arch-review.html` — the presentation document
- `<effort_dir>/spec/rollout.md`, `spec/cost.md`, `spec/risks.md` — if written during interview

Commit message: `docs(<effort-id>): generate architecture review package`

The skill does not modify `.state.json` or `README.md`.

---

## TR-11: Pre-generation interview covers four topics

*Traces to: BR-8*

Before generating the HTML, the skill interviews the author on:
1. Rollout — phases, migration, feature flags, rollback
2. Cost — AWS services, key variable cost drivers, baseline parameter values
3. Risk mitigation — failure modes, abuse scenarios, cross-cutting security gaps
4. Afterword — future extensions, outstanding questions

One question at a time with a recommended answer. Agreed answers written immediately to `spec/rollout.md`, `spec/cost.md`, `spec/risks.md`. If these files exist (re-run), skip already-resolved topics.

---

## TR-12: Rollout section inferred from artifacts and supplemented by interview

*Traces to: BR-9*

Rollout signals inferred automatically:
- `spec/storage/` present with schema changes → migration flag
- BR text containing "gradual", "experiment", "flag", "A/B" → feature flag candidate
- Multiple deployables in `.state.json` → coordinated rollout

Combined with interview answers to populate `spec/rollout.md` and render §7.

---

## TR-13: Cost analysis uses AWS pricing fetched via WebFetch; interactive sliders use inline JavaScript

*Traces to: BR-10*

The skill fetches current AWS pricing from canonical AWS pricing pages using the WebFetch tool. Interactive cost controls use inline `<script>` blocks with the IIFE pattern — no external library. Each slider uses a unique function name to avoid collisions. Baseline parameter values are read from spec artifacts first; gaps are filled by the interview. If pricing cannot be fetched, a gap notice is rendered.

---

## TR-14: Interactive cost parameter baseline values inferred from spec, filled by interview

*Traces to: BR-10, TR-13*

For each variable cost parameter, the skill first reads the value from spec artifacts (storage specs, TRs, ADRs). If found, it becomes the slider default without prompting. If not found, the interview asks explicitly for the baseline value.

---

## TR-15: Phase guard — discovery phase only

*Traces to: BR-1*

The skill only runs when `currentPhase = "discovery"` and `phases.discovery.status != "approved"`. If discovery is already approved, the skill stops with a message referencing `forge:reopen discovery` (currently a stub — manual `.state.json` workaround documented).

---

## Constraints

- HTML file must not exceed 500KB; summarise verbose spec content rather than quoting verbatim
- Branch guard: warns if running on `main`/`master` before committing
- The staleness check excludes `rollout.md`, `cost.md`, `risks.md` to prevent spurious `forge:validate` re-runs on subsequent arch-review invocations
