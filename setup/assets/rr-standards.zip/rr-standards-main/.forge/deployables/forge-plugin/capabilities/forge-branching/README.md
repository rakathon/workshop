# forge-branching

Branch policy enforcement for the Forge AI-accelerated development framework.
Delivers `enforce-branch-policy.sh` (PreToolUse hook) and `pre-push.sh` (git hook
template) to prevent direct commits and pushes to the default branch from both AI
agents and engineers.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `enforce-branch-policy.sh` | Hook | Project (plugin cache) | PreToolUse: Bash |
| `pre-push.sh` | Git hook template | Repository | `git push` |

**`enforce-branch-policy.sh`** fires before every Bash tool call and checks whether
the command is a `git commit` or `git push` targeting the default branch. If it is,
the hook exits 2 (block) with a structured JSON diagnostic on stderr, preventing the
AI agent from committing directly to main. Administrative operations are allowed
through via explicit environment variable override, with all overrides written to an
audit log.

**`pre-push.sh`** is a standard git `pre-push` hook template installed by `forge:init`
into `.git/hooks/pre-push`. It reads the pushed refs from stdin and blocks any push
targeting `refs/heads/main` or `refs/heads/master`, providing the same enforcement
for direct CLI use that the PreToolUse hook provides for the AI agent path. Engineers
can bypass it with `git push --no-verify` for emergency operations.

## Why Branch Enforcement Exists

The default branch must always represent reviewed, approved work. A commit that
lands on main without a pull request has bypassed every quality gate the organization
has established: peer review, CI checks, standards compliance, and approval policy.

This enforcement is structural, not advisory. Discouraging direct commits is
insufficient — both the AI agent path and the direct CLI path must be blocked by
hooks that fire regardless of how the commit command reaches the shell.

## Defense in Depth

| Path | Enforcement |
|------|------------|
| AI agent via Bash tool | `enforce-branch-policy.sh` (PreToolUse) |
| Engineer via `git` CLI | `pre-push.sh` (git hook) |
| Admin override | `FORGE_ALLOW_MAIN_COMMIT=1` + audit log |
| Emergency bypass | `git push --no-verify` (CLI only) |

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-init](../forge-init/) | Installs `pre-push.sh` into `.git/hooks/` and registers `enforce-branch-policy.sh` in `.claude/settings.json` |
| [forge-effort](../forge-effort/) | Creates and checks out `effort/<id>` branch during effort scaffolding |

## Implementation Location

`plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`
`plugins/forge/hooks/pre-push/pre-push.sh`

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements (BR-1 through BR-4) |
| [requirements/technical.md](requirements/technical.md) | Technical requirements — hook behavior, exit codes, admin override, audit logging |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable acceptance criteria |
| [spec/README.md](spec/README.md) | Architecture overview and defense-in-depth rationale |
| [spec/hooks.md](spec/hooks.md) | Detailed design for `enforce-branch-policy.sh` and `pre-push.sh` |
| [test/README.md](test/README.md) | Test strategy |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
Primary program BRs addressed: BR-1, BR-2, BR-5.
