# Skills — forge-cross-repo

---

## forge:project

**Purpose:** Create a local sub-effort from a coordination effort by fetching, scoping,
and materializing the relevant cross-cutting artifacts as local files.

**Arguments:**
- `--coordination-repo <org/repo>` (required) — GitHub repository identifier for the
  coordination repository
- `--effort-id <id>` (required) — Effort ID in the coordination repository to project from

### Steps

1. **Validate inputs.** Confirm both `--coordination-repo` and `--effort-id` are
   present. Confirm `gh` CLI is available and authenticated:
   ```
   gh auth status
   ```
   If either flag is missing or `gh` is not authenticated, fail with a clear error
   before making any API calls.

2. **Fetch the coordination effort's plan.** Retrieve the plan from the coordination
   repository to identify which sections are scoped to this deployable:
   ```
   gh api repos/<org/repo>/contents/.forge/efforts/<effort-id>/plan/plan.md
   ```
   Decode the base64 `content` field. Record the `sha` field as the source blob SHA.
   If the plan does not exist, proceed with full (unscoped) projection and emit a
   warning.

3. **Scope the projection.** Read the plan to identify artifacts relevant to this
   deployable. Ask the engineer: "Which deployable in this repository does this
   sub-effort serve?" Use the answer to filter the plan entries by `responsible`
   deployable assignment. If the coordination plan has no per-deployable sections,
   project the full plan with a scoping note.

4. **Fetch all artifacts to be projected.** For each artifact identified in step 3,
   call the GitHub API:
   ```
   gh api repos/<org/repo>/contents/<artifact-path>
   ```
   Decode the base64 content. Record the blob `sha` for each artifact. If any API
   call fails, abort immediately — do not create partial results.

5. **Determine the local effort ID.** Derive the local effort ID by appending the
   deployable name to the coordination effort ID (e.g., `favorite-stores` +
   `backend` → `favorite-stores-backend`). Confirm with the engineer.

6. **Materialize projected files.** For each fetched artifact, write a local file
   under `.forge/efforts/<local-effort-id>/` with the projected-\* naming convention.
   Each file must begin with the provenance header in exactly this format:
   ```
   <!-- forge:projection
     source_repo: <org/repo>
     source_effort: <effort-id>
     source_file: <path-in-coordination-repo>
     source_commit: <blob-sha>
     projected_at: <ISO-8601>
   -->
   ```
   After the header, write the scoped artifact content.

7. **Fetch the coordination repository's HEAD SHA.** This records the overall
   coordination repository state at projection time:
   ```
   gh api repos/<org/repo>/commits/main --jq '.sha'
   ```

8. **Scaffold .state.json.** Create `.forge/efforts/<local-effort-id>/.state.json`
   using the state.json template. Populate the `coordinationRef` object:
   ```json
   {
     "coordinationRef": {
       "branch": "main",
       "commitSha": "<head-sha-from-step-7>",
       "effortId": "<coordination-effort-id>",
       "projectedAt": "<ISO-8601-now>",
       "projections": [
         {
           "local": ".forge/efforts/<local-effort-id>/requirements/projected-business.md",
           "source": ".forge/efforts/<effort-id>/requirements/business.md",
           "sourceSha": "<blob-sha-from-step-4>"
         }
       ],
       "repo": "<org/repo>"
     }
   }
   ```

9. **Register in .forge/efforts/README.md.** Add a new row to the master registry table with
   the local effort ID, title, type, tier, risk, current phase (`discovery`), and
   status (`not_started`). Set the parent reference to `repo:<org/repo>/<effort-id>`.

10. **Report outcome.** Print a summary listing: the local effort ID created, all
    projected files written, and the coordinationRef recorded. Remind the engineer to
    commit the result.

**Offline error format:**
```
Error: GitHub API unreachable for repos/<org/repo>/contents/<path>
Reason: <error message from gh>
Action: Check network connectivity, run `gh auth login` to re-authenticate,
        and verify you have read access to <org/repo>.
No files were created. forge:project requires network access.
```

---

## forge:sync

**Purpose:** Compare local projection SHAs against the current coordination repository
to detect stale projections. Optionally re-fetch and rewrite stale projections.

**Arguments:**
- `--rematerialise` (optional) — re-fetch and rewrite stale projections with updated
  content and provenance headers

### Steps

1. **Locate sub-efforts with coordinationRef.** Read `.forge/efforts/README.md` to find all
   active efforts. For each, check whether `.state.json` contains a `coordinationRef`
   object. Collect all that do.

2. **For each projection in coordinationRef.projections:**

   a. Read `sourceSha` from the projection entry.

   b. Query the coordination repository for the current blob SHA of the source file:
      ```
      gh api repos/<org/repo>/commits?path=<source_file>&per_page=1
      ```
      Extract the blob SHA for the source file from the response.

   c. Classify the projection:
      - **current** — local `sourceSha` matches current blob SHA
      - **stale** — local `sourceSha` differs from current blob SHA
      - **unreachable** — the API call failed (any error)

3. **Report projection states.** For each projection, emit one line per state:
   ```
   current   .forge/efforts/favorite-stores-backend/requirements/projected-business.md
   stale     .forge/efforts/favorite-stores-backend/plan/projected-plan.md
             local:   a1b2c3d4
             current: e5f6a7b8
   unreachable  .forge/efforts/favorite-stores-backend/requirements/projected-technical.md
             reason: HTTP 403 Forbidden
   ```

4. **If --rematerialise is passed:** For each projection in `stale` state:

   a. Fetch the updated content:
      ```
      gh api repos/<org/repo>/contents/<source_file>
      ```

   b. Decode the base64 content.

   c. Rewrite the projected file with a new provenance header reflecting the updated
      `source_commit` and `projected_at`. Preserve the scoped content structure.

   d. Update the `sourceSha` in the `coordinationRef.projections` entry in `.state.json`.

   e. Update `coordinationRef.commitSha` and `coordinationRef.projectedAt` to reflect
      the new projection.

5. **Report outcome.** Summarize: N current, N stale, N unreachable. If
   `--rematerialise` was run: list files rewritten and confirm `.state.json` was
   updated.

**Offline behavior:** When any API call fails, classify the projection as `unreachable`
with the reason and continue to the next projection. Do not raise an error. Exit cleanly
after reporting all projections.

---

## forge:upstream

**Purpose:** Record a change proposal for a coordination-level artifact and optionally
create a pull request to the coordination repository.

**Arguments:**
- Description of the change (provided interactively or as prompt context)
- `--pr` (optional) — create a GitHub pull request to the coordination repository

### Steps

1. **Confirm coordinationRef exists.** Read the active effort's `.state.json`. If no
   `coordinationRef` is present, fail:
   ```
   Error: No coordinationRef found in .state.json.
   forge:upstream requires a local sub-effort created by forge:project.
   Run forge:project first to establish the coordination link.
   ```

2. **Identify the target coordination file.** Ask the engineer: "Which file in the
   coordination repository needs to change?" Present the list of projected source files
   from `coordinationRef.projections` as options. Accept a custom path if the target
   file was not projected.

3. **Gather change information.** If not already provided in the prompt:
   - What needs to change (the specific change, not just the symptom)
   - Why it needs to change (the local discovery or implementation finding)
   - What the proposed content should look like

4. **Determine proposal ID and slug.** Read existing entries in `upstream-proposals/`
   to find the highest existing ID. Increment by one (zero-padded to three digits).
   Derive a kebab-case slug from the change title (e.g., `add-store-id-field`).

5. **Write the proposal document.** Create:
   `.forge/efforts/<effort-id>/upstream-proposals/<id>-<slug>.md`

   With the following structure:
   ```markdown
   # Upstream Proposal <id>: <title>

   **Status:** proposed
   **Target repository:** <org/coordination-repo>
   **Target file:** <path-in-coordination-repo>
   **Created:** <ISO-8601>

   ## Change Description

   [What needs to change in the coordination artifact]

   ## Rationale

   [The local discovery or implementation finding that necessitates this change]

   ## Proposed Content

   [The specific content to add, modify, or remove]
   ```

6. **Update .state.json.** Add a new entry to the `upstreamProposals` array:
   ```json
   {
     "file": "upstream-proposals/<id>-<slug>.md",
     "id": "<id>",
     "prUrl": null,
     "status": "proposed",
     "targetFile": "<path-in-coordination-repo>",
     "targetRepo": "<org/coordination-repo>"
   }
   ```

7. **If --pr is passed:** Create the pull request:
   ```
   gh pr create \
     --repo <org/coordination-repo> \
     --title "forge:upstream: <title>" \
     --body "<proposal document content>"
   ```
   On success, record the PR URL in the `prUrl` field of the new `upstreamProposals`
   entry and update `.state.json`.

   On failure, report the error clearly. Leave the proposal document and `.state.json`
   entry intact (with `prUrl: null`). Inform the engineer that the proposal is recorded
   locally and can be submitted as a PR manually.

8. **Report outcome.** Confirm the proposal file path, the `.state.json` update, and
   (if `--pr`) the PR URL or failure reason.
