# Test Strategy — forge-pin

## Scope

| Area | What is tested |
|------|---------------|
| `forge:pin` skill | Marketplace file creation, settings.json entries, `forge_min_version` sync, idempotency (same-version re-pin), version tag resolution, error on unknown tag |

## Approach

### Skill Behavioral Tests

`forge:pin` is tested using the with/without-context eval methodology from
rr-standards. `.evals.json` companion files alongside `SKILL.md`.

Each eval set must have ≥ 5 compliant and 5 non-compliant examples covering the
main behavioral rules. `rr-standards:validate --active` provides the harness.

### Integration Tests

End-to-end tests on a temporary git repository:

| Test case | Expected result |
|-----------|----------------|
| First-time pin to latest | `.claude-plugin/marketplace.json` created with `ref` + `sha`; `settings.json` updated; install prompt shown |
| Re-pin to same version | "Already pinned. Nothing to do." — no files modified |
| Re-pin to different version | `marketplace.json` updated; install prompt shown |
| `--version v1.2.3` (with v prefix) | Leading `v` stripped correctly; correct tag resolved |
| `--version` with unknown tag | Fails with diagnostic listing available tags |
| `.forge/version` present | `forge_min_version` updated in place |
| `.forge/version` absent | No error; noted in summary |
| Commit reminder in output | Summary includes exact `git add` / `git commit` commands |
