# Success Criteria — forge-classify

`forge:classify` is correct when:

- [ ] When `suggestedRisk` is present in `.state.json`, that value and its rationale are surfaced to the engineer before the recommendation is made
- [ ] The recommendation output names at least one indicator that fired and at least one higher-tier indicator that did not — showing the reasoning, not just the conclusion
- [ ] When the engineer confirms the recommendation, `risk` is written to `.state.json` in R-notation (`R1`, `R2`, `R3`, or `R4`) — never "HIGH", "LOW", or other synonyms
- [ ] When the engineer overrides the recommendation, the override tier and stated rationale are written to `.state.json` — not the original recommendation
- [ ] After writing, `suggestedRisk` and `suggestedRiskRationale` are cleared from `.state.json` (set to null or removed)
- [ ] When re-invoked on an effort with an existing classification, the current tier and rationale are shown before the new recommendation flow begins
- [ ] The summary output includes the tier consequence line appropriate to the committed tier (R1 → full discovery + arch review; R4 → lightweight process)
- [ ] The skill stops without writing to `.state.json` if the engineer chooses to revise (reconsider) rather than confirm or override
- [ ] If `requirements/business.md` is absent, the skill proceeds with a warning rather than stopping
- [ ] If `standards/risk/classification.md` is absent, the built-in fallback rubric is used and the absence is noted
- [ ] When invoked outside the discovery phase, the skill warns the engineer and asks for confirmation before proceeding — it does not silently block or silently proceed
