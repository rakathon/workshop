# Skill Contract — forge:slack-summarize

*Effort: slack-support*
*Date: 2026-04-21*
*Traces to: BR-3, BR-4, TR-7, TR-8, TR-9*

---

## Purpose

Generates a daily or weekly summary from imported Slack message files. Operates
independently of `forge:slack-import` — can be re-run at any time to regenerate
summaries. Uses Claude to extract structured signal from message content within the
user's own session.

## Agent Type

`orchestrator`

---

## Arguments

| Argument | Required | Description |
|---|---|---|
| `--effort <effort_id>` | No | Target a specific effort by ID. If omitted, resolved via the standard chain (see `plugins/forge/skills/common/effort-resolution.md`). |
| `--channel <channel-id>` | No | Scope summarization to a single channel. If omitted, summaries are generated for all channels in the effort's `slackChannels` array. |
| `--daily <YYYY-MM-DD>` | One of | Generate (or regenerate) the daily summary for the given date |
| `--weekly <YYYY-Www>` | One of | Generate (or regenerate) the weekly summary for the given ISO week (e.g. `2026-W17`) |

Exactly one of `--daily` or `--weekly` must be provided.

---

## Preconditions

**PC-1: Target effort exists**
Resolve the active effort using the standard chain defined in:
  `plugins/forge/skills/common/effort-resolution.md`
Skill category: `effort-required`
Pass `--effort` value as the explicit argument (Step 1 of the chain) when provided.

**PC-2: Source file(s) exist**

Determine the set of channels to summarize: `--channel` if provided, otherwise all
entries in `slackChannels`. For each channel:

- For `--daily`: `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD.md` must exist.
- For `--weekly`: at least one daily file in the target week's channel directory must exist.

If no source files exist for a channel, skip it with a warning:
> "No message files found for channel `<channel-id>` on `<date>`. Run `forge:slack-import` first."
If no channels have source files at all, stop with:
> "No message files found for any channel for the requested date. Run `forge:slack-import` first."

---

## Steps

### Step 1: Load Source Messages

Determine the set of channels to summarize from `slackChannels`. Each channel entry
provides `entry.name` (directory slug) and `entry.id` (for display purposes in output).

**Daily mode:** Read the single daily message file for the target date.

**Weekly mode:** Determine the Monday–Sunday date range for the target ISO week.
Read all daily message files that exist within that range. Note which days are absent.

### Step 2: Extract High-Priority Topics

Analyse the loaded message content and identify items belonging to each high-priority
topic category. For weekly mode, record the source date for each item.

High-priority categories (in order of appearance in the output):

| Section heading | What to look for |
|---|---|
| Architectural Decisions | Choices about system design, technology selection, patterns, or interfaces |
| Planning Decisions | Scope changes, milestone adjustments, task assignments, prioritisation changes |
| Raised Risks | Concerns about delivery, dependencies, technical debt, or external factors |
| Raised Bugs | Bug reports or reproduction steps mentioned in conversation |
| Specification Problems | Issues, contradictions, or gaps identified in existing specs or requirements |
| Time-Off Notices | Planned absences, holidays, or reduced availability |
| Status Updates | Progress reports, blockers, completions, or escalations |

For weekly mode, prefix each item with `**<YYYY-MM-DD>** —`.

If a category has no items, write `None identified.`

### Step 3: Extract General Notes

Identify other notable discussion not covered by the high-priority sections.
Summarise in 2–5 bullet points. If nothing notable remains, write `None.`

### Step 4: Write Summary File

Run Steps 1–3 once per channel. Write one summary file per channel:

**Daily mode:** Write to `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD-summary.md`
using the daily summary format from `spec/storage/messages.md`.

**Weekly mode:** Determine the `YYYY-MM` directory from the Monday of the target week.
Write to `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/week-<Www>-summary.md`
using the weekly summary format from `spec/storage/messages.md`.

If the file already exists, overwrite it (regeneration is always a full rewrite).

### Step 5: Commit

Use `forge:commit` to stage and commit the written summary file.

### Step 6: Print Summary

```
forge:slack-summarize complete
Effort:  <effort_id>
Mode:    <daily YYYY-MM-DD | weekly YYYY-Www>
Output:  <effort_dir>/messages/slack/<channel-name>/YYYY-MM/<filename>
Topics:  <N> high-priority items found across <K> categories
```

For weekly mode, also list which days were included and which were absent.

---

## Error Handling

| Condition | Action |
|---|---|
| Source file absent for a channel | Skip that channel with warning; continue with remaining channels |
| No source files for any channel | Stop: "No message files found for any channel for the requested date. Run `forge:slack-import` first." |
| Weekly mode — some days absent | Note missing days; generate from available days |
| No messages in source file | Write summary with all sections as "None identified." |
| Output directory absent | Create it before writing |
