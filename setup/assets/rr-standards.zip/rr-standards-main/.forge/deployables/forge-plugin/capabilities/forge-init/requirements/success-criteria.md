# Success Criteria — forge-init

- [ ] A new repository can be fully initialized for Forge development with a single
      `forge:init` invocation, with no additional configuration required afterward
- [ ] Running `forge:init` on a repository with an existing CLAUDE.md preserves all
      pre-existing CLAUDE.md content; only Forge-specific sections are added or updated
- [ ] After `forge:init`, writing a source file in Claude Code automatically loads
      the correct language-specific coding standard without engineer invocation
- [ ] `forge:init` writes to `.claude/settings.json` (project scope); any contributor
      who clones the repository gets the hook registered automatically
- [ ] Every initialized repository contains `.forge/version` with the installed plugin
      version and initialization timestamp; `forge_min_version` is populated from the
      pin when `forge:pin` has been run first, or left empty for unpinned repositories
- [ ] Session start in a repository behind the current Forge release emits a visible,
      non-blocking upgrade notice
- [ ] Repositories exceeding the Productivity Engineering-defined maximum lag period
      are blocked by the version enforcement hook before new tasks begin; in-progress
      implementation tasks are not blocked mid-task
- [ ] A repository can set `coding_standards=exempt` in `.forge/compliance`;
      engineers are not blocked by standards injection, the coding standards check
      in forge:review, or version deadline blocking; all other review checks still run
- [ ] Every coding standards exemption has a committed reason
- [ ] Coding standards exemption does not disable Forge work item tracking,
      `forge:init`, or non-coding-standards review checks
- [ ] When `forge:init` is run in create mode on a deployable repository that contains
      existing source code, the engineer is offered the option to analyze the repository
      and generate `.forge/deployables/` scaffolding before any files are created
- [ ] When the engineer opts in to brownfield analysis, `forge:init` presents the
      identified deployable list for confirmation before writing any scaffold files
- [ ] Brownfield analysis defaults to `n` (skip); pressing Enter without input does
      not trigger analysis
- [ ] Brownfield scaffolding produces populated content derived from code analysis —
      not blank stubs. All AI-inferred content is wrapped in a visible `⚠ AI-inferred`
      warning marker; sections that cannot be inferred use a `✏ Needs input` stub
- [ ] A repository with a defined API surface (routes, handlers, or proto files)
      produces `requirements/technical.md` with an inferred endpoint table and
      `spec/README.md` with an inferred component and data flow overview
- [ ] A repository with no readable API surface still produces useful output:
      stack detection from the build manifest and `✏ Needs input` prompts
- [ ] Running `forge:init` in merge mode (`.forge/` already exists) never triggers the
      brownfield analysis prompt
- [ ] Capability analysis and file creation for each deployable run as isolated worker
      sub-agents spawned concurrently — the orchestrator's context window is not
      populated with source file contents from the codebase
- [ ] A single worker failure does not abort scaffolding for other deployables; failed
      deployables are reported in the summary so the engineer can scaffold them manually
- [ ] When `forge:init` completes and `CONFLUENCE_URL`, `CONFLUENCE_USERNAME`, or
      `CONFLUENCE_API_TOKEN` are unset, the summary includes a setup block listing all
      three variable names, example values, and the Atlassian API token URL
- [ ] When all three Confluence environment variables are set, the summary prints a
      single `✓ Atlassian MCP (Confluence): credentials configured` line instead of
      the setup block
- [ ] The Confluence credential check does not block `forge:init` from completing
      regardless of whether credentials are configured
