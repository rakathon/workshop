# Test Plan — forge-effort

This document describes the test approach for the forge-effort capability: its four hooks
and four skills. Tests are organized in three levels: unit tests for hooks (mocked file
system), integration tests for skill invocations (real file system, no network), and
end-to-end tests (complete conversational workflow).

---

## Unit Tests — Hooks

Hook unit tests operate on a mocked or temporary `.forge/` directory. They verify that each
hook produces the correct exit code and output given a specific input state. No Claude Code
session is required; hooks are shell scripts and can be tested directly.

### inject-workflow-context.sh

| Test ID | Scenario | Input state | Expected exit | Expected output |
|---------|----------|-------------|---------------|-----------------|
| H1-01 | No `.forge/efforts/README.md` | Empty repo | 0 | None |
| H1-02 | One active effort, single in_progress | `README.md` with one effort; `.state.json` in discovery | 0 | Context block with effort ID, phase, artifact inventory |
| H1-03 | Branch name matches effort ID | Branch `effort/forge-workflow`; effort `forge-workflow` active | 0 | Context block identifies `forge-workflow` as current |
| H1-04 | Multiple active efforts, no branch match | Two efforts in `README.md`; branch name matches neither | 0 | Context block lists all; note to clarify |
| H1-05 | Effort with pause state | `.state.json` has `pauseState` populated | 0 | Context block includes "Resuming from pause" and nextAction |
| H1-06 | Post-approval modifications present | `.state.json` has one entry in `phases.discovery.postApprovalModifications` | 0 | Context block includes modification warning |
| H1-07 | `coordinationRef` is null | Standalone effort | 0 | No staleness section |
| H1-08 | Offline (API calls skipped) | `coordinationRef` set; `gh` not available or returns error | 0 | Context block without staleness info; no error emitted |
| H1-09 | Corrupt `.state.json` | Malformed JSON in one effort | 0 | Warning naming affected effort; other efforts processed normally |

### route-to-skills.sh

| Test ID | Scenario | Input prompt | Expected exit | Expected output |
|---------|----------|--------------|---------------|-----------------|
| H2-01 | No `.forge/efforts/README.md` | Any | 0 | None |
| H2-02 | Explicit skill invocation | `forge:status` | 0 | Skill routing context |
| H2-03 | Effort creation signal | "start working on PROJ-1234" | 0 | Effort creation context |
| H2-04 | Graduation signal | "QA passed, let's close this out" | 0 | Graduation checklist context |
| H2-05 | Ambiguous prompt | "let's review the work" | 0 | None (low confidence) |
| H2-06 | Normal code-focused prompt | "fix the NullPointerException" | 0 | None |

### phase-context.sh

| Test ID | Scenario | Input path | `.state.json` currentPhase | Expected exit | Expected output |
|---------|----------|------------|----------------------------|---------------|-----------------|
| H3-01 | Path outside `.forge/efforts/` | `src/main/App.java` | Any | 0 | None |
| H3-02 | Typical discovery write | `.forge/efforts/foo/requirements/business.md` | `discovery` | 0 | None |
| H3-03 | Post-approval modification | `.forge/efforts/foo/requirements/business.md` | `implementation` (discovery = `approved`) | 0 | Informational note |
| H3-04 | Typical planning write | `.forge/efforts/foo/plan/tasks.md` | `planning` | 0 | None |
| H3-05 | Writing plan in discovery | `.forge/efforts/foo/plan/tasks.md` | `discovery` | 0 | None (later phase, not atypical) |
| H3-06 | `.state.json` missing | `.forge/efforts/missing/requirements/business.md` | N/A | 0 | None |
| H3-07 | Writing `.state.json` itself | `.forge/efforts/foo/.state.json` | Any | 0 | None |
| H3-08 | Discovery phase not approved | `.forge/efforts/foo/requirements/business.md` | `implementation` (discovery = `in_progress`) | 0 | None (not approved, no tracking needed) |

**Critical check for H3-03 through H3-08:** exit code must be 0 in every case. Use
`assert_exit_code 0` explicitly in each test.

### update-workflow-state.sh

| Test ID | Scenario | Written path | `.state.json` before | Expected field after |
|---------|----------|-------------|----------------------|----------------------|
| H4-01 | Business requirements written | `requirements/business.md` | `business: "absent"` | `business: "present"` |
| H4-02 | Technical requirements written | `requirements/technical.md` | `technical: "absent"` | `technical: "present"` |
| H4-03 | API spec written | `spec/api/payments-api.yaml` | `api: "absent"` | `api: "present"` |
| H4-04 | Storage schema written | `spec/storage/schema.md` | `storage: "absent"` | `storage: "present"` |
| H4-05 | Messaging spec written | `spec/messaging/events.md` | `messaging: "absent"` | `messaging: "present"` |
| H4-06 | ADR written (first) | `spec/arch-decisions/ADR-001-foo.md` | `adrsCreated: []` | `adrsCreated: ["ADR-001-foo.md"]` |
| H4-07 | ADR written (second) | `spec/arch-decisions/ADR-002-bar.md` | `adrsCreated: ["ADR-001-foo.md"]` | `adrsCreated: ["ADR-001-foo.md", "ADR-002-bar.md"]` |
| H4-08 | Plan written fresh | `plan/tasks.md` | `phases.planning.status: "not_started"` | `phases.planning.status: "in_progress"` |
| H4-09 | Validation report with PASS | `validation/report.md` (result: PASS) | `phases.validation.status: "not_started"` | `status: "in_progress"`, `result: "PASS"` |
| H4-10 | Post-approval modification | `requirements/business.md` (discovery = approved) | `postApprovalModifications: []` | One entry added |
| H4-11 | Path outside efforts | `src/App.java` | Any | Unchanged (no-op) |
| H4-12 | Duplicate ADR write | `spec/arch-decisions/ADR-001-foo.md` (already in list) | `adrsCreated: ["ADR-001-foo.md"]` | `adrsCreated: ["ADR-001-foo.md"]` (no duplicate) |

---

## Integration Tests — Skills

Integration tests invoke the skills in a real (temporary) repository with a real
`.forge/` directory. No network access is required. GitHub API calls in hooks are
mocked or disabled via environment variable.

### forge:effort

| Test ID | Scenario | Inputs | Expected outcome |
|---------|----------|--------|-----------------|
| I1-01 | Create full-tier epic | `--type epic --risk R2` | `.state.json` with `tier: "full"`, `currentPhase: "discovery"`, `productionBound: true` |
| I1-02 | Create patch effort | `--type story --subtype patch` | `.state.json` with `tier: "lightweight"`, `subtype: "patch"`, `currentPhase: "implementation"` |
| I1-03 | Create poc effort | `--type story --subtype poc` | `.state.json` with `productionBound: false`, `subtype: "poc"` |
| I1-04 | Create with parent | `--parent existing-epic` | `.state.json` with `parentId: "existing-epic"`; parent's `childIds` updated |
| I1-05 | Effort ID collision | `--title "Existing Effort"` where ID already exists | Error message; no files written |
| I1-06 | Registry updated | Any successful creation | `.forge/efforts/README.md` has exactly one new row |
| I1-07 | Commit produced | Any successful creation | `git log` shows one commit with `chore(<id>): scaffold` prefix |

### forge:status

| Test ID | Scenario | `.state.json` state | Expected output |
|---------|----------|---------------------|----------------|
| I2-01 | Discovery, no artifacts yet | All artifact fields `"absent"` | Lists all required artifacts as absent |
| I2-02 | Discovery, partial artifacts | Some `"present"`, some `"absent"` | Correctly differentiates present vs absent |
| I2-03 | Implementation, wave tracking | 2 of 4 tasks complete in wave 1 | Wave 1: 2/4, wave 2: not started |
| I2-04 | Open decisions present | `openDecisions` has one entry | Decision listed with blocking task |
| I2-05 | Paused effort | `pauseState` populated | Shows resume context |
| I2-06 | No active effort | Empty registry | Graceful message, no crash |

### forge:pause

| Test ID | Scenario | Session state | Expected `.state.json` change |
|---------|----------|--------------|-------------------------------|
| I3-01 | Pause mid-implementation | Active task TASK-003 | `pauseState.activeTask: "TASK-003"` |
| I3-02 | Pause in discovery | No active task | `pauseState.activeTask: null`, `pauseState.contextSummary` populated |
| I3-03 | Commit produced | Any successful pause | `git log` shows one commit with `chore(<id>): pause session` prefix |
| I3-04 | No active effort | Empty registry | Error message; no crash |

### forge:resume

| Test ID | Scenario | Pause state | Expected behavior |
|---------|----------|-------------|------------------|
| I4-01 | Resume with valid pause state | `pauseState` populated | Prints context summary; clears `pauseState` in `.state.json` |
| I4-02 | Resume with no pause state | `pauseState: null` | "No pause state found" message; no crash |
| I4-03 | Resume with stale task reference | `pauseState.activeTask` references deleted task | Surfaces discrepancy; asks engineer to clarify |
| I4-04 | Commit produced after resume | Any successful resume | `git log` shows `chore(<id>): resume session` commit |
| I4-05 | Open decisions surfaced | `openDecisions` non-empty at pause time | Decisions listed prominently in resume output |

---

## End-to-End Tests — Conversational Workflow

End-to-end tests verify that the conversational path produces identical outcomes to the
explicit skill invocation path. These tests require a Claude Code session and are run
manually or via the Claude CLI.

### E2E-01: Conversational Effort Creation

1. Start a session in an initialized repository with no active efforts.
2. Say: "We need to build a rate-limiting layer for the API."
3. Assert: `.forge/efforts/rate-limiting-layer/` created.
4. Assert: `.state.json` present with correct fields.
5. Assert: `.forge/efforts/README.md` has one new row.
6. Compare `.state.json` structure against one produced by explicit `forge:effort --type epic --risk R2`.

**Pass condition:** Conversational output is structurally equivalent to explicit invocation output.

### E2E-02: Automatic State Update After Artifact Write

1. Start a session with an active effort in discovery phase.
2. Say: "Let's document the business requirements." Then produce `requirements/business.md`.
3. Assert: `.state.json` has `phases.discovery.artifacts.requirements.business: "present"`.
4. Assert: The write was not blocked by `phase-context.sh`.
5. Assert: The state was updated by `update-workflow-state.sh` without explicit agent action.

**Pass condition:** State updated automatically; no explicit state management step in conversation.

### E2E-03: Post-Approval Modification Tracking

1. Set up an effort with discovery phase marked `approved`.
2. Start a session. Modify `requirements/business.md`.
3. Assert: `phase-context.sh` emitted an informational note (exit 0, not 2).
4. Assert: `update-workflow-state.sh` added an entry to `phases.discovery.postApprovalModifications`.

**Pass condition:** Modification was permitted, tracked, and not blocked.

### E2E-04: Pause and Resume Round-Trip

1. Start a session with an effort in implementation, mid-task.
2. Say: "Let's stop here and pick this up tomorrow."
3. Assert: `pauseState` populated in `.state.json`.
4. Start a new session.
5. Assert: SessionStart hook surfaces the pause state.
6. Say: "Let's resume."
7. Assert: Context restored; `pauseState` cleared; engineer can proceed with next action.

**Pass condition:** Full round-trip with no information loss. Resumed agent correctly identifies active task and next action.

---

## Test Infrastructure Notes

- Unit tests for hooks: use a temporary directory with seeded `.forge/` structure.
- Mock network calls: set `FORGE_SKIP_STALENESS_CHECK=1` to disable GitHub API calls in tests.
- Consistent `.state.json` output: verify key ordering (alphabetical) and array formatting
  (one item per line) in all written files to validate TR-13 compliance.
- All tests must clean up their temporary directories on exit, including on failure.
