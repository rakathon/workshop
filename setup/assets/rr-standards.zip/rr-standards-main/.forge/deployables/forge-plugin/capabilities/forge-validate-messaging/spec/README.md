# Spec — forge-validate-messaging

## Artifacts

- [skills.md](skills.md) — Skill specification: inputs, worker steps, output format
