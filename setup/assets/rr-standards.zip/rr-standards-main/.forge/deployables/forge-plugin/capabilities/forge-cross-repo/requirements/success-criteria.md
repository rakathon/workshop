# Success Criteria — forge-cross-repo

---

## forge:project

**SC-1: Projected files have all five provenance header fields.**
Every file materialized by `forge:project` must begin with a `<!-- forge:projection ...
-->` header containing exactly the five fields: `source_repo`, `source_effort`,
`source_file`, `source_commit`, and `projected_at`. A projected file missing any field
is a defect.

**SC-2: coordinationRef is written to .state.json.**
After `forge:project` completes, the local sub-effort's `.state.json` must contain a
`coordinationRef` object with all required fields: `repo`, `effortId`, `branch`,
`commitSha`, `projectedAt`, and a `projections` array. Each projection entry must
include `source`, `local`, and `sourceSha`.

**SC-3: Local sub-effort appears in the registry.**
The new local sub-effort must appear as a row in `.forge/efforts/README.md` with a cross-repo
parent reference in the `repo:<org/repo>/<effort-id>` format.

**SC-4: Offline invocation produces a clear error, not a partial result.**
When `forge:project` is invoked without network access to the coordination repository,
it must exit with a clear error message identifying the failure and provide actionable
guidance. No files or `.state.json` entries must be created as a partial result.

---

## forge:sync

**SC-5: A stale projection is reported with the correct SHA delta.**
When a projection's `sourceSha` does not match the current blob SHA in the coordination
repository, `forge:sync` must report the projection as `stale` and display both the
locally recorded SHA and the current SHA from the coordination repository.

**SC-6: An unreachable coordination repository produces a graceful report, not an error.**
When the GitHub API is unreachable, `forge:sync` must report each projection as
`unreachable` and provide the reason. The command must exit cleanly; the local
projections must remain intact and usable.

**SC-7: A re-materialised projection has an updated provenance header and updated .state.json.**
When `forge:sync --rematerialise` updates a stale projection, the rewritten file must
have a new `source_commit` and `projected_at` in its provenance header. The
`sourceSha` in the corresponding `coordinationRef.projections` entry and the
`coordinationRef.commitSha` in `.state.json` must both reflect the updated SHA.

---

## forge:upstream

**SC-8: The proposal document is written with all required sections.**
After `forge:upstream` completes, a file exists at
`.forge/efforts/<effort-id>/upstream-proposals/<id>-<slug>.md` containing all five
required sections: title, target repository/file, change description, rationale, and
proposed content.

**SC-9: .state.json upstreamProposals array is updated.**
The local sub-effort's `.state.json` must contain a new entry in `upstreamProposals`
with `id`, `file`, `status: "proposed"`, `targetRepo`, `targetFile`, and `prUrl: null`.

**SC-10: PR URL is recorded when --pr flag is used.**
When `forge:upstream --pr` creates a pull request successfully, the `prUrl` field of
the corresponding `upstreamProposals` entry in `.state.json` must be set to the URL
of the created PR (not null).
