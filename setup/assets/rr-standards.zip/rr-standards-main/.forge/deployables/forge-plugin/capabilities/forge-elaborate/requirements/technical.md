# Technical Requirements — forge-elaborate

Parent: [business requirements](business.md)
Upstream program requirements: forge-plugin TR § Discovery Phase Capabilities

---

## TR-1: Effort Resolution with Graceful No-Effort Fallback

*Traces to: BR-4, BR-5*

The skill resolves the active effort using the standard effort-resolution chain. If no effort is found, the skill does not stop — it enters no-effort mode, conducting the full interview in-context and withholding artifact writes until the engineer decides where (if anywhere) to write the shared understanding.

## TR-2: Artifact Inventory Read Before First Question

*Traces to: BR-4*

Before asking any question, the skill reads every artifact that exists in the effort directory: `requirements/business.md`, `requirements/technical.md`, `requirements/user-stories.md`, all files under `spec/`, and `.state.json`. From this inventory it determines what has already been established and what is missing. The first question must be informed by this state — the skill must never ask about something already resolved.

## TR-3: Interview Follows Natural Dependency Ordering, Adaptively

*Traces to: BR-2*

The interview respects the natural dependency order of understanding: business requirements before technical constraints, technical constraints before specification artifacts, data model before interface contracts, interface contracts before internal implementation. The skill follows this order as a default orientation, not as a fixed sequence. When deeper exploration reveals a gap in an earlier layer (e.g. a data model discussion exposes a missing business requirement), the skill cycles back and resolves the earlier gap before continuing.

The skill is not prescribed a rigid step sequence. It must exercise judgment about what the most productive next question is at each point, given what is already known.

## TR-4: One Recommended Answer Per Question

*Traces to: BR-1*

For each question asked, the skill provides its own recommended answer along with a brief rationale. The engineer may accept, modify, or reject the recommendation. The skill must not ask open-ended questions without a position — every question comes with a proposed answer the engineer can engage with.

## TR-5: Agreed Answers Written Immediately to the Correct Artifact

*Traces to: BR-3*

As soon as an answer is agreed upon:
- If it belongs to business requirements: appended to `requirements/business.md` as a new BR entry
- If it is a technical constraint (a measurable bound, an environmental constraint, a technology mandate): appended to `requirements/technical.md` as a new TR entry
- If it is an architectural decision (a choice between alternatives with a rationale): created immediately via `forge:adr` in the effort's `spec/arch-decisions/` directory

Writing is not deferred. The skill does not accumulate answers to write at the end.

## TR-6: ADR vs Technical Constraint Distinction

*Traces to: BR-3*

An ADR records a decision — a choice between alternatives with a rationale (e.g. "we will use DynamoDB", "we will create a new module X"). A TR records a constraint — a bound or requirement the system must satisfy regardless of how it is implemented (e.g. "must support 1000 RPS at p95 ≤ 50ms", "must run on Java 8 for the duration of this effort"). The skill applies this distinction consistently when classifying each agreed answer.

## TR-7: Interview Terminates on Exhaustion or Engineer Signal

*Traces to: BR-1*

The interview ends when the skill determines there are no more productive questions — no unresolved business requirements, no missing technical constraints, no unexplored integration points or data model gaps — or when the engineer signals that the understanding is sufficient. Both conditions are valid termination points.

## TR-8: User Stories Written After Interview Concludes

*Traces to: BR-6*

After the interview concludes, the skill writes `requirements/user-stories.md` using the Connextra template:

```
As a <role>, I want <capability> so that <outcome>.
```

User stories are derived from the agreed business requirements and the shared understanding developed during the interview. They are not a restatement of BRs — they are the human-centred view of what those BRs mean for real users.

## TR-9: Post-Write Navigation Prompt (Effort Mode)

*Traces to: BR-1*

After writing `requirements/user-stories.md` in effort mode, the skill asks the engineer whether they want to:
1. Commit the session's work using `forge:commit`
2. Proceed to planning with `forge:plan`
3. Do something else

The skill does not automatically commit or transition phase.

## TR-10: No-Effort Mode — End-of-Session Write Decision

*Traces to: BR-5*

In no-effort mode, after the interview concludes, the skill asks the engineer whether they want the shared understanding written anywhere and, if so, where. If the engineer wants to write it, the skill asks for a target location (e.g. a file path or an effort to create). If the engineer does not want to write it, the skill ends without any file writes.

## TR-11: Trigger Vocabulary Reflects New Purpose

*Traces to: BR-1*

The skill is triggered by language that reflects deep understanding and problem exploration, not technical elaboration mechanics. Trigger phrases include: "let's understand this problem", "deep dive on this effort", "interview me about this", "I want to think this through", "help me understand what we're building", "explore this with me", "what are we missing?", "what questions should we be asking?".

The old triggers ("elaborate requirements", "expand the BRs into TRs", "what are the NFRs?") are retired along with the old behaviour.

## TR-12: Spec Skill Delegation at Layer Boundaries

*Traces to: BR-2, BR-4*

When the interview is about to enter the data model, interface contract, or messaging
contract layer, and the corresponding spec artifact is absent, the skill pauses and
offers to invoke the relevant spec skill (`forge:spec-storage`, `forge:spec-api`,
`forge:spec-messaging`) before asking questions about that layer. If the engineer
accepts, the spec skill runs and the interview resumes after it completes, with all
newly written spec artifacts re-read. If the engineer declines, the interview
continues without spec delegation and does not re-offer for that layer in the
current session. Delegation is not offered in no-effort mode.

## TR-13: forge:classify Invoked After User Stories Are Written

*Traces to: BR-1*

After `requirements/user-stories.md` is written, the skill invokes `forge:classify`
before presenting the navigation prompt. This is the earliest point at which a
well-grounded risk classification can be produced — all business requirements,
technical constraints, and user stories are written and the shared understanding is
complete. If `forge:classify` fails or the engineer declines to classify, the skill
continues to the navigation prompt without blocking.
