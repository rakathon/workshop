# Success Criteria — forge-about-me

- [ ] `forge:about-me` completes without requiring any Forge effort or git repository
- [ ] The skill extracts role fields from a pasted LinkedIn profile without re-asking for fields already present
- [ ] The skill asks role deep-dive questions only for fields not answered in the extraction phase
- [ ] Writing samples are collected one at a time; the skill waits for "that's all" before proceeding to analysis
- [ ] The tone description is presented for confirmation before being included in the output
- [ ] The assembled context block contains exactly four sections in the specified order
- [ ] Descriptive content (My Role + Communication Audience + Tone & Voice opening) is under 250 words
- [ ] Anti-patterns that appear in the user's own writing samples are omitted from the output
- [ ] In Claude Code, the block is written to `~/.claude/CLAUDE.md` without prompting for a choice
- [ ] The skill never writes to a project `CLAUDE.md` under any circumstance
- [ ] In Claude.ai / Claude Desktop, the block is saved as `about-me.md` with Custom Instructions guidance
- [ ] In Cowork, the block is saved as `about-me.md` and the full path is shared
- [ ] The output block is wrapped with `<!-- forge:about-me:start -->` and `<!-- forge:about-me:end -->` markers in every output destination
- [ ] On a second run in Claude Code, the existing marker span in `~/.claude/CLAUDE.md` is replaced in full — no duplicate sections, no content outside the markers disturbed
- [ ] The Company Context section is reproduced verbatim — not summarised or paraphrased
