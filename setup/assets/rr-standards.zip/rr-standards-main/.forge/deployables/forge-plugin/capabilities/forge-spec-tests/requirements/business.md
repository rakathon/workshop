# Business Requirements — forge-spec-tests

## BR-1: Test Strategy Belongs to the Capability, Not the Work Item

A work item is a delivery vehicle. Its requirements describe what the team set out
to accomplish. Its test strategy, however, describes how to verify that the capability
works — and that knowledge belongs to the capability permanently, not just for the
duration of the work item that created it.

When test strategy is written in spec/test-strategy.md (work item scope), it becomes
inaccessible to forge:verify and forge:qa after the work item closes. When it is in
the capability directory (for capability-scoped work) or the effort spec directory
(for initiative-scope work), it survives closure and is available to all future
work items that modify the same capability or initiative.

## BR-2: Test Scenarios Must Be Traceable to Acceptance Criteria

A test that verifies "it works" with no link to a stated acceptance criterion is
unverifiable. An acceptance criterion with no corresponding test scenario is untested.
Traceability between test scenarios and acceptance criteria makes both gaps and
coverage visible before implementation begins.

## BR-3: Test Strategy Designed Before Implementation Produces Better Tests

Tests written after implementation tend to validate what the code does. Tests
designed from requirements validate what the code should do. Designing at discovery
time, from acceptance criteria, prevents tests from being written to confirm existing
behavior rather than verify requirements.

## BR-4: The Engineer Declares What Kind of Test Suite They Need

The skill must not silently decide what kind of test suite to produce based on
heuristics about the repository or effort type. The engineer declares the intent
(e2e, contract, integration, or full). The skill's job is to validate
whether that intent is achievable given the available spec, not to substitute its
own judgment for the engineer's.

## BR-5: Missing Spec Is Surfaced Explicitly With Actionable Next Steps

When the available spec is insufficient to produce the requested test plan type,
the skill must surface the gap explicitly — naming what is missing and which Forge
skill to run to create it. Silent fallback to a less-detailed test type is not
acceptable: the engineer cannot fix a gap they do not know exists.

## BR-6: Test Suites Do Not Include Unit Tests

Unit tests are implementation decisions made by the writing engineer. They verify
isolation behavior not visible to requirements. Including them in a discovery-time
test suite adds noise and creates false completeness signals. This skill produces
only observable-behavior tests: e2e, contract, and integration.

## BR-7: Test Strategy Is Extensible for Load Tests

The test strategy document must include a placeholder section for load test
scenarios. This placeholder enables a future `forge:spec-tests --load-tests`
invocation to extend the document without replacing it. Load test design itself
is deferred to v2.

---
Success criteria: [success-criteria.md](success-criteria.md)
