# Spec — forge-spec-storage

| Artifact | Description |
|----------|-------------|
| [skills.md](skills.md) | Skill interface spec |

**Standards loaded:** `plugins/forge/standards/storage/<type>.md` (loaded in Phase 3)

**Output artifacts written:**
- `spec/storage/logical-schema.md` — Mermaid ERD with entities and relationships (Phase 1)
- `spec/storage/query-patterns.md` — access pattern table (Phase 2)
- `spec/storage/<type>.md` or `spec/storage/<type>.sql` — physical schema with fields, indexes, and PII annotations (Phase 3)

**Output consumed by:** `forge:validate-storage`, `forge:validate`, `forge:verify`
