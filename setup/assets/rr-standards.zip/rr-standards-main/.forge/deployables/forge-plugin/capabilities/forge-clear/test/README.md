# Test Strategy — forge-clear

## Scope

| Area | What is tested |
|------|---------------|
| `forge:clear` skill | File deletion, idempotency, no-op when file absent, no state side effects |

## Approach

### Skill Behavioral Tests

`forge:clear` is tested using the with/without-context eval methodology from
rr-standards. `.evals.json` companion files alongside `SKILL.md`.

Each eval set must have ≥ 5 compliant and 5 non-compliant examples covering the
main behavioral rules.

### Integration Tests

End-to-end tests on a temporary git repository:

| Test case | Expected result |
|-----------|----------------|
| `.forge/EFFORT` present with valid ID | File deleted; "Active effort cleared: <id>" printed; `.state.json` untouched |
| `.forge/EFFORT` absent | "No active effort is set." printed; no error |
| `.forge/EFFORT` empty | Treated as absent; "No active effort is set." printed |
| Run twice in a row | Second invocation prints "No active effort is set."; no error |
| `.state.json` present | File contents identical before and after `forge:clear` |
| Git status after clear | No staged or unstaged changes |
