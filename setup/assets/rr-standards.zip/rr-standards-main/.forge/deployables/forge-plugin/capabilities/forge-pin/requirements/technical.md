# Technical Requirements — forge-pin

Parent deployable: [forge-plugin](../../requirements/technical.md)

---

## TR-10: forge:pin Skill

### TR-10.1: Command Surface

`forge:pin` pins a repository to a specific Forge plugin version. It is optional —
repos without a pin load whatever version the engineer has globally installed.

| Flag | Description | Default |
|------|-------------|---------|
| `--version <semver>` | Version to pin to (e.g. `1.2.3` or `v1.2.3`) | latest release |

`forge:pin` and `forge:init` are order-independent. Both must be idempotent —
re-running `forge:pin` to the same version must produce an "unchanged" result.

### TR-10.2: Local Marketplace Creation

`forge:pin` must create or update `.claude-plugin/marketplace.json` in the project
root, pinning the Forge plugin to a specific release using both a semantic version tag
and its corresponding commit SHA:

```json
{
  "name": "forge-local",
  "plugins": [{
    "name": "forge",
    "source": {
      "source": "git-subdir",
      "url": "https://github.com/rewards-guilds/rr-standards.git",
      "path": "plugins/forge",
      "ref": "v1.2.3",
      "sha": "<commit-sha-for-v1.2.3>"
    }
  }]
}
```

`forge:pin` must also write to `.claude/settings.json`:
- `extraKnownMarketplaces["forge-local"]` pointing to `./.claude-plugin`
- `enabledPlugins["forge@forge-local"]` set to `true` (removing any other `forge@*`
  entries)

### TR-10.3: forge_min_version Sync

If `.forge/version` exists when `forge:pin` is run, `forge:pin` must update
`forge_min_version` to the new pin value. This keeps the version record in sync with
the pin without requiring `forge:init` to be re-run.

This is the mechanism that keeps `forge:pin` and `forge:init` order-independent: if
`forge:init` was run first and `forge:pin` is run later, `forge_min_version` is updated
in place without needing to re-run `forge:init`.

### TR-10.4: Plugin Installation

After writing the marketplace configuration, `forge:pin` must instruct the engineer
to run `/plugin install forge@forge-local` to fetch and cache the pinned version.
`forge:pin` must pause and wait for confirmation before completing, because subsequent
`forge:update` steps require the plugin to be cached.

### TR-10.5: Version Tag Resolution

`forge:pin` resolves the target version via the GitHub API using the `gh` CLI:

1. If `--version <semver>` is provided: strip leading `v`; verify the tag exists and
   retrieve its SHA via `gh api repos/rewards-guilds/rr-standards/git/ref/tags/<tag>`
2. If omitted: fetch the latest release tag via
   `gh api repos/rewards-guilds/rr-standards/releases/latest`
3. Both `ref` (semver tag) and `sha` (commit SHA) are written to the marketplace
   config — the SHA provides a cryptographic pin
4. If the repo is already pinned to the requested version with identical SHA, exit
   cleanly with "Already pinned. Nothing to do."
5. If the specified tag does not exist, fail with a diagnostic listing available tags

### TR-10.6: Commit Requirement

The files modified by `forge:pin` (`.claude-plugin/marketplace.json`,
`.claude/settings.json`, `.forge/version`) must be committed to version control for
the pin to be shared with the team. `forge:pin` must include an explicit commit
reminder in its output with the exact git commands to use.

---

## Constraints

- `forge:pin` has no knowledge of hooks or `.forge/` directory structure — that
  belongs to `forge:init`
- `forge:pin` does not modify `active_version` in `.forge/version` — only
  `forge_min_version`. `active_version` is managed by `forge:init` and `forge:update`
- The `gh` CLI must be installed and authenticated before running `forge:pin`; it
  makes GitHub API calls to resolve version tags and SHAs
- Every Forge release must be tagged with semantic versioning (`v<major>.<minor>.<patch>`);
  untagged commits are not valid pin targets
