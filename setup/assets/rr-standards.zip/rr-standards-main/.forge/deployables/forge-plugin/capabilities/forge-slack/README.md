# forge-slack

<!-- graduated-from: slack-support at 2026-04-23T21:50:06Z -->

Slack integration for the Forge AI-accelerated development framework. Associates Slack
channels with efforts, imports messages on a periodic schedule, and generates daily and
weekly summaries enriched with linked Confluence and Jira resource context.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:slack-channel` | Skill | Interactive | Manual invocation |
| `forge:slack-import` | Skill | Interactive + CI | Manual or GitHub Actions schedule |
| `forge:slack-summarize` | Skill | Interactive | Manual invocation |

**`forge:slack-channel`** associates or removes a Slack channel from the active effort,
storing the channel ID and display name in `.state.json`.

**`forge:slack-import`** fetches messages from the effort's associated Slack channels
via the Slack MCP, enriches Atlassian links, writes daily markdown files, and advances
a per-channel checkpoint. Supports optional `--from`/`--to` date bounds and `--ci` mode
for repository-wide batch import via GitHub Actions.

**`forge:slack-summarize`** reads imported daily message files and generates daily or
weekly summaries, prominently surfacing high-priority topics (architectural decisions,
planning decisions, risks, bugs, spec problems, time-off, status updates).

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-effort](../forge-effort/) | Provides the `.state.json` schema that `slackChannels` is written to |

## Implementation Location

`plugins/forge/skills/slack-channel/`, `plugins/forge/skills/slack-import/`,
`plugins/forge/skills/slack-summarize/`

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [spec/README.md](spec/README.md) | Architecture overview |
| [spec/skills/forge-slack-channel.md](spec/skills/forge-slack-channel.md) | `forge:slack-channel` skill contract |
| [spec/skills/forge-slack-import.md](spec/skills/forge-slack-import.md) | `forge:slack-import` skill contract |
| [spec/skills/forge-slack-summarize.md](spec/skills/forge-slack-summarize.md) | `forge:slack-summarize` skill contract |
| [spec/storage/messages.md](spec/storage/messages.md) | Message file storage schema |
| [spec/arch-decisions/ADR-001-github-actions-scheduling.md](spec/arch-decisions/ADR-001-github-actions-scheduling.md) | ADR-001: GitHub Actions for scheduling |
| [spec/arch-decisions/ADR-002-slack-mcp-over-direct-api.md](spec/arch-decisions/ADR-002-slack-mcp-over-direct-api.md) | ADR-002: Slack MCP over direct API |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | ADR index |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
