# Design Spec — forge-ui

Parent deployable: [forge-plugin](../../requirements/business.md)

<!-- graduated-from: design-system-integration at 2026-04-25T23:10:46Z -->

Related ADR: [ADR-001 — Single forge:ui Skill with Runtime Platform Detection](../../../spec/arch-decisions/ADR-001-single-ui-skill-with-runtime-platform-detection.md)

---

## Purpose

`forge:ui` generates standards-compliant UI code using the Rakuten Rewards design
system — correct component hierarchy, design tokens, and mobile-first responsive
layout. It detects the target platform from project build files, loads the appropriate
standards and language guides, then generates correct output without requiring the user
to specify a platform.

**Agent type:** Orchestrator

**Skill location:** `plugins/forge/skills/ui/SKILL.md`

---

## Trigger Conditions

UI-building prompts: "build me a page", "add a hero section", "create a landing page",
"I need a store carousel", "generate this UI", "build a [anything UI-related]",
"implement this design", or "what components should I use for X". If the request
involves producing or planning React/Kotlin/Swift UI code, this skill applies.

---

## Platform Detection (Step 1)

| Signal | Platform |
|--------|----------|
| `package.json` containing `@rakuten-rewards/uikit` | Web (TypeScript/React) |
| `build.gradle` or `settings.gradle` present | Android (Kotlin) — future |
| `Package.swift` or `.xcodeproj` present | iOS (Swift) — future |

If multiple platforms detected: ask engineer to clarify before proceeding.
If no platform detected: surface a clear error with setup instructions.

---

## Web Workflow (Current)

1. Detect platform → load `standards/frontend/` + `languages/typescript/react/default/guides/ui-design-system/`
2. Ask ≤3 clarifying questions about what to build (scope, data, sections)
3. Plan page structure top-to-bottom; state assumptions
4. Generate standards-compliant TSX inline — no dev environment management, no specific repo structure required
5. Validate output mentally against standards before emitting (no raw hex, no missing responsive props, correct component tier)

---

## Standards Loaded at Runtime

- `plugins/forge/standards/frontend/design-tokens.md`
- `plugins/forge/standards/frontend/component-selection.md`
- `plugins/forge/standards/frontend/responsive-layout.md`
- `plugins/forge/languages/typescript/react/default/guides/ui-design-system/tokens.md`
- `plugins/forge/languages/typescript/react/default/guides/ui-design-system/components.md`
- `plugins/forge/languages/typescript/react/default/guides/ui-design-system/responsive-layout.md`
- `plugins/forge/languages/typescript/react/default/guides/ui-design-system/page-patterns.md`

---

## Deferred Scope

### UIKit Component Authoring (BR-5, TR-5)

Deferred to a dedicated `forge:ui-component` skill in a follow-on effort. UIKit
component authoring targets the UIKit library itself, not its consumers, and involves
different preconditions, outputs, and quality gates than `forge:ui`.

### Prototype-to-Production Handoff Trigger

The `promote` trigger within `forge:ui-design` (a step that writes a finalized handoff
record when an engineer signals "promote this prototype") is deferred to a follow-on
effort. `ui-spec-template.md` covers the structural handoff need.
