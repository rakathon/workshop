# Skills — forge-spec-storage

## forge:spec-storage

**Classification:** Orchestrator

**Invocation:** `forge:spec-storage [--type postgres|dynamo|redis|opensearch]`

**Multi-storage:** Run once per storage technology. Each pass produces its own file in
`spec/storage/`; earlier files are left unchanged. Example: run `--type postgres` for
the primary store, then `--type redis` for the cache layer.

**Phases (sequential, with restart support):**

| Phase | Output artifact | Commit message |
|-------|----------------|----------------|
| 0 — Detect restart | — | — |
| 1 — Logical schema | `spec/storage/logical-schema.md` | `docs(<effort-id>): Phase 1 — logical storage schema` |
| 2 — Query patterns | `spec/storage/query-patterns.md` | `docs(<effort-id>): Phase 2 — storage query patterns` |
| 3 — Physical schema | `spec/storage/<type>.md` or `spec/storage/<type>.sql` | `docs(<effort-id>): Phase 3 — physical storage schema (<type>)` |

**Phase 0 — Restart detection:** Reads each existing output artifact and evaluates its content against requirements and known spec (API contracts, messaging contracts) to determine whether the phase is truly complete — not merely whether the file exists. A phase is incomplete if the artifact is absent or if its content is missing entities, patterns, or physical definitions implied by the requirements. Resumes from the earliest incomplete phase, summarizing completed phases before continuing. If all three phases are complete, reports complete and stops unless the engineer requests a revision. **`--type` bypass:** if `--type` is provided and no file for that specific storage type exists yet in `spec/storage/`, the Phase 3 completeness check is skipped and the skill proceeds directly to Phase 3 — enabling multi-storage additions without re-running Phases 1 and 2.

**Phase 1 — Logical schema:** Reads `<effort_dir>/requirements/business.md` and `technical.md`, and checks `<effort_dir>/spec/api/` and `<effort_dir>/spec/messaging/` for implicit entity nouns. Enumerates entities and relationships (no fields, no technology). Confirms with engineer. Writes `logical-schema.md` with a Mermaid ERD.

**Phase 2 — Query patterns:** Derives access patterns from all available sources — requirements verbs ("find by", "look up", "filter on"), UI artifacts in `spec/ui/` (screens, lists, search controls), flows in `spec/flows/` (user journeys, sequence diagrams, state machines), API contracts in `<effort_dir>/spec/api/` (if present), and messaging consumers in `<effort_dir>/spec/messaging/` (if present). API and messaging specs may not exist yet when storage is designed early; all other sources are consulted regardless. Each pattern records its source. Confirms the full list with the engineer. Writes `query-patterns.md` as a table of pattern / entity / filters / sort / source / notes.

**Phase 3 — Physical schema:** Resolves storage type from `--type` flag, or by reading the tech stack table in `.forge/deployables/<deployable-name>/spec/README.md` (deployable name from `deployables` in `.state.json`), or engineer prompt if no deployable spec is found. Loads the applicable storage standard from the plugin standards directory. Offers engineer a choice of one-entity-at-a-time or all-at-once review before designing. Designs each entity with: all fields (types, nullability, constraints), PK, FKs or key design, indexes driven by Phase 2 query patterns, soft-delete policy, PII inline annotations with retention and deletion obligation. Updates `.state.json` `phases.discovery.artifacts.spec.storage = "present"` in a named Step 3d before committing.

**No formal effort:** Artifacts are written to `spec/storage/` in the current working directory; engineer describes domain conversationally in Phase 1. Effort header omitted from output files.
