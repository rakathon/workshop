# forge:adr Skill Design

Design for the `forge:adr` skill. The skill is an orchestrator — it reads effort state,
computes the next ADR number, writes the ADR file, updates the effort index and state,
and commits. It runs in the engineer's Claude Code session using Claude Code tools.

Implementation: `plugins/forge/skills/adr/`

---

## forge:adr

### Purpose

Capture an architectural decision as an ADR file. ADRs can be scoped to an active
effort, a specific deployable, or the repository as a whole. Works both when invoked
explicitly by the engineer and when triggered automatically by a conversational
decision statement.

### Arguments

All arguments are optional.

| Argument | Description |
|---------|-------------|
| `title` | The decision subject as a short phrase. Used to derive the ADR filename slug and heading. Inferred from conversation if omitted. |
| `decision` | The decision in one or two sentences. Written into the Decision section. Inferred from conversation if omitted. |
| `--effort <id>` | Write to this effort's `spec/arch-decisions/` directory. Overrides automatic effort detection. |
| `--deployable <id>` | Write directly to this deployable's `spec/arch-decisions/` directory. Use for retroactive ADRs added after an effort is graduated. |
| `--status Proposed` | Set the ADR status to `Proposed` instead of the default `Accepted`. |

### Preconditions

- **PC-1:** Forge is initialized in this repository (`.forge/efforts/README.md` exists).

An active effort is not required. When no scope can be determined from arguments or
context, the skill asks the engineer where to write the ADR.

### Numbered Steps

1. **Determine write target** (see TR-7)

   Resolve `adr_scope` (`effort` | `deployable` | `repository`) and `adr_dir` using
   this priority order:
   - `--effort <id>` → effort scope; read `.state.json`, stop if missing
   - `--deployable <id>` → deployable scope; stop if deployable directory missing
   - Active effort from context (branch name → single open `.state.json` → conversation)
   - Ask the engineer — present open efforts, deployables, and repository as options

   Read `.forge/efforts/README.md` before writing. Record `adr_scope`, `adr_dir`, and
   `effort_id` or `deployable_id` as applicable.

2. **Find next ADR number**

   Scan `<adr_dir>` for files matching `ADR-NNN-*.md`. Find the lowest positive integer
   not present in the set (gap-filling). Zero-pad to three digits. This is `adr_num`.
   If `<adr_dir>` does not exist, create it; `adr_num` is `001`.

3. **Determine title and decision text**

   Use `title` and `decision` arguments if provided. Otherwise extract from the most
   recent decision statement in the conversation. If neither argument nor clear
   conversational decision is present, ask:
   1. "What decision should I record?" — wait for response
   2. If bare title with no rationale: "What was the reasoning behind this decision?"
   Do not fabricate — ask rather than guess.

4. **Semantic overlap check** (see TR-9)

   Read title lines from every existing `ADR-NNN-*.md` in `<adr_dir>`. For effort
   scope, also locate the associated deployable and scan its ADR titles (TR-9.2).

   Classify each overlapping candidate as **duplicate** (same concern, same choice)
   or **conflict** (same concern, different choice). Read the `## Decision` section
   from any candidate where the title alone is ambiguous (TR-9.3).

   - **Conflict found**: present the conflicting ADR and ask the engineer to confirm
     supersession, confirm different aspects, or cancel (TR-9.4). On confirmed
     supersession, record the ADR in `superseded_adrs` for Step 5.
   - **Duplicate found (no conflict)**: ask the engineer to confirm distinct or cancel
     (TR-9.5).
   - **No overlap**: proceed silently.

5. **Update superseded ADRs** (see TR-9.4) — only if `superseded_adrs` is non-empty

   For each superseded ADR: update its `**Status:**` line to
   `Superseded by ADR-<adr_num>` and update its Status column in the relevant index
   from `Accepted` to `Superseded`.

5. **Derive slug and filename**

   Convert title to kebab-case (lowercase, hyphens, no punctuation, ≤ 60 characters
   at a word boundary). Filename: `ADR-<adr_num>-<slug>.md`. Full path:
   `<adr_dir>/ADR-<adr_num>-<slug>.md`. If the path already exists, prompt the
   engineer before overwriting.

6. **Derive slug and filename**

   Convert title to kebab-case (lowercase, hyphens, no punctuation, ≤ 60 characters
   at a word boundary). Filename: `ADR-<adr_num>-<slug>.md`. Full path:
   `<adr_dir>/ADR-<adr_num>-<slug>.md`. If the path already exists, prompt the
   engineer before overwriting.

7. **Write the ADR file**

   Populate all four sections from conversation. No section may be left empty.
   Write scope metadata on the appropriate line:
   - Effort scope: `**Effort ID:** <effort-id>`
   - Deployable scope: `**Deployable:** <deployable-id>`
   - Repository scope: omit both lines

8. **Update the ADR index**

   Read `<adr_dir>/README.md`. Create if missing with heading
   `# Architecture Decisions — <scope-label>` where scope-label is the effort ID,
   deployable ID, or `Repository`. Append a row for the new ADR in numeric order.

9. **Update `.state.json` `adrsCreated`** (effort scope only)

   Skip this step for deployable and repository scope.

   Append `ADR-<adr_num>-<slug>` (without `.md`) to
   `phases.discovery.artifacts.adrsCreated` in `<effort_dir>/.state.json`.
   ADRs are not phase-specific — always write to the discovery array.

10. **Confirm and suggest commit**

    Print the files written and a suggested commit command. Include superseded ADR
    files in the `git add` if Step 5 ran. Do not run the commit.

    ```
    docs(<scope-label>): ADR-<adr_num> <decision-subject>
    ```

    Where `<scope-label>` is the effort ID, deployable ID, or `repo`.

---

### ADR Template

```markdown
# ADR-NNN: <Title>

**Status:** Accepted
**Effort ID:** <effort-id>      ← effort scope only
**Deployable:** <deployable-id> ← deployable scope only; omit both for repository scope
**Date:** <YYYY-MM-DD>

## Context

<Why this decision was needed. What problem was being solved, what constraints
existed, what was learned during conversation that made this decision necessary.>

## Decision

<The decision itself, stated clearly and directly. "We will use X." Not hedged.>

## Alternatives Considered

<Each alternative meaningfully considered before this decision was made.
For each: what it was and why it was not chosen.
If no alternatives were considered: "No alternatives were explicitly considered.">

## Consequences

<What this decision means going forward. What is now easier, what is now harder,
what constraints it imposes, what follow-on decisions it enables or forecloses.>
```

---

### [Orchestrator-Only] Before-Write Read

Before writing any file, read:
1. `.forge/efforts/README.md` — confirm registry is consistent
2. `<effort_dir>/.state.json` (effort scope only) — get current `adrsCreated` array

The `.state.json` read ensures the array is current before appending. If `.state.json`
does not exist in the effort directory, stop — a malformed effort directory must not
receive ADRs until the state file is present.
