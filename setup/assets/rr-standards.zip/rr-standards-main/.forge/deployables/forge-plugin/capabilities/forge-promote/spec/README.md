# forge-promote — Architecture

This capability delivers the `forge:promote` skill. It is a single-artifact capability:
one orchestrator-only skill that executes the phase promotion ritual for any effort
transition. No hooks are delivered by this capability.

---

## Artifact Inventory

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:promote` | Skill (orchestrator) | Interactive | Manual invocation |

---

## The Promotion Ritual

`forge:promote` is not a state flag update. It is a five-step ritual defined by
ADR-004 (Phase Promotion Is an Explicit Ritual Requiring Engineer Confirmation):

1. **Readiness check** — Verify all required phase exit artifacts are present for the
   effort's tier. If any are absent, report the gap and stop without advancing.

2. **Post-approval surface** — If any artifacts were modified after a prior approval
   cycle (tracked in `postApprovalModifications` in `.state.json`), list them so the
   engineer can acknowledge the baseline has changed.

3. **Phase summary** — Present a structured review of what was produced: each artifact,
   each ADR, open decisions remaining, validation concerns (if any), and the effort's
   risk classification.

4. **Explicit confirmation** — Ask the engineer to confirm advancement. `forge:promote`
   must not advance on ambiguous input and must not advance without a response.

5. **Checkpoint commit + registry update** — Commit `.state.json` with the phase
   transition recorded (approver and timestamp), then update `.forge/efforts/README.md`.

---

## Phase Transition Map

```
discovery → planning → implementation → verification → closed
```

Each arrow represents one `forge:promote` invocation. The skill always advances exactly
one phase per invocation — there is no skip-ahead option.

---

## Hard Gate: discovery → planning (Full Tier)

The discovery → planning transition is the one meaningful hard gate in the workflow
(ADR-002). For full-tier efforts:

- `validation/report.md` must be present (produced by `forge:arch-review`)
- The overall result must be PASS or PASS WITH CONCERNS
- A FAIL result is an absolute block — `forge:promote` stops before presenting the
  summary or requesting confirmation

This is the only place in the workflow where a missing or failed artifact causes an
unconditional stop. All other gates check for artifact presence but do not block on
content (e.g., the planning gate checks that tasks exist but does not evaluate their
quality).

---

## Tier Behavior

| Tier | discovery → planning gate |
|------|--------------------------|
| Full (`full`) | Requires business reqs, technical reqs, ≥1 spec artifact, non-FAIL validation report |
| Lightweight (`patch`, `refactor`, `extension`, `poc`) | No discovery artifacts required; gate is bypassed |

All other transitions (planning → implementation, etc.) apply the same readiness checks
regardless of tier.

---

## Key Files

| File | Purpose |
|------|---------|
| [skills.md](skills.md) | `forge:promote` detailed design |
| [arch-decisions/README.md](arch-decisions/README.md) | Relevant ADRs (ADR-002, ADR-004) |
| [../requirements/business.md](../requirements/business.md) | Why this capability exists |
| [../requirements/technical.md](../requirements/technical.md) | How it must behave |
| [../requirements/success-criteria.md](../requirements/success-criteria.md) | Measurable acceptance criteria |
