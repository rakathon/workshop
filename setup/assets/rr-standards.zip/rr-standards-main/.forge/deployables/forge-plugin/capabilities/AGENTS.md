# Capabilities — Navigation Guide

This directory contains one subdirectory per capability of the forge-plugin deployable.

## What a Capability Is

A capability is a **user-facing feature**. It is named after what it delivers to the
engineer, not the architectural layer it belongs to.

**`forge-init`** is a capability because an engineer runs `forge:init` to initialize
a repository. The name describes the experience.

**`forge-pin`** is a capability because an engineer runs `forge:pin` to pin the plugin
version. The name describes the experience.

## How to Name a Capability

Ask: **"What does an engineer *do* with this?"**

The answer is the capability name.

| ✓ Good capability name | ✗ Not a capability name | Why the bad name is wrong |
|------------------------|------------------------|--------------------------|
| `forge-effort` | `forge-workflow-core` | "core" is an architectural layer, not a feature |
| `forge-arch-review` | `forge-validation-infrastructure` | "infrastructure" describes implementation, not value |
| `forge-graduate` | `forge-workflow-full` | "full" is a tier/package label, not a feature |
| `forge-promote` | `forge-phase-management` | "phase management" is a mechanism, not what the engineer does |

A capability name that contains words like "core", "infrastructure", "base", "utils",
"common", "full", or "lite" is almost certainly wrong. Those are architectural groupings.

## What a Capability Contains

Each capability directory has a standard structure:

```
<capability-name>/
├── README.md               # What this capability delivers; when to use it
├── requirements/
│   ├── business.md         # Why this capability exists (user needs)
│   ├── technical.md        # How it must behave (preconditions, inputs, outputs, errors)
│   └── success-criteria.md # Measurable acceptance criteria
├── spec/
│   ├── README.md           # Capability overview
│   ├── skills.md           # Skill design: numbered steps, arguments, deviation rules
│   ├── hooks.md            # Hook design (if applicable): trigger, exit codes, edge cases
│   └── arch-decisions/     # Decisions specific to this capability
├── test/
│   └── README.md           # Test approach and coverage requirements
├── security/
│   └── README.md           # Security considerations
└── runbook/
    └── README.md           # Operational notes
```

The `spec/skills.md` and `spec/hooks.md` are the design documents for the Claude
instruction files (`SKILL.md`) that ship in `plugins/forge/`. Writing capability
docs before writing `SKILL.md` is the spec-driven approach.

## Current Capabilities

| Capability | What it delivers | When to read this directory |
|---|---|---|
| `forge-init` | Initialize a repository for Forge use (`forge:init`) | Modifying initialization logic, `.forge/` directory structure, or the CLAUDE.md template |
| `forge-pin` | Pin the installed Forge plugin version (`forge:pin`) | Changing version pinning, `VERSIONS.json`, or the version enforcement hook |
| `forge-effort` | Create and track work efforts; automatic state management via hooks; CLAUDE.md guidance layer | Changing `.state.json` schema, effort lifecycle, effort creation, or any hook that fires on effort events |
| `forge-clear` | Clear the session-local active effort pointer without modifying effort state (`forge:clear`) | Changing the clear behavior, pointer file handling, or the relationship between `forge:clear` and `forge:pause` |
| `forge-promote` | Advance efforts through phases via the promotion ritual (`forge:promote`) | Modifying phase advancement logic, phase sentinel behavior, or the promotion checklist |
| `forge-classify` | Assign an R1–R4 risk classification to an effort (`forge:classify`) | Changing the risk rubric, classification logic, or how risk tier is stored in `.state.json` |
| `forge-elaborate` | Build shared understanding through conversational interview; produces BRs, TRs, ADRs, and user stories (`forge:elaborate`) | Modifying the interview model, artifact write logic, template resolution, or user story output |
| `forge-adr` | Capture architecture decisions during conversation (`forge:adr`) | Changing ADR format, numbering, scope resolution, or the ADR index structure |
| `forge-spec-api` | Co-author REST API contracts during discovery (`forge:spec-api`) | Modifying API contract authoring flow, OpenAPI output format, or REST standard integration |
| `forge-spec-storage` | Design storage schemas during discovery (`forge:spec-storage`) | Modifying schema authoring flow, storage standard integration, or PII/retention handling |
| `forge-spec-messaging` | Design event and message contracts during discovery (`forge:spec-messaging`) | Modifying event contract authoring, producer/consumer design flow, or messaging standard integration |
| `forge-spec-tests` | Author test strategies for capabilities during discovery (`forge:spec-tests`) | Modifying test strategy generation, scenario mapping, or test type coverage |
| `forge-validate` | Full cross-reference validation of discovery artifacts; phase gate (`forge:validate`) | Changing validation rules, traceability checks, or the validation report format |
| `forge-validate-api` | Inline validation of API contracts against REST standards (`forge:validate-api`) | Changing API contract validation rules or enforcement severity resolution |
| `forge-validate-messaging` | Inline validation of event contracts against messaging standards (`forge:validate-messaging`) | Changing messaging contract validation rules or enforcement severity resolution |
| `forge-validate-storage` | Inline validation of storage schemas against storage standards (`forge:validate-storage`) | Changing storage schema validation rules or enforcement severity resolution |
| `forge-arch-review` | Validate design against standards; produce architecture review document (`forge:arch-review`) | Modifying architecture review scope, checklist, or output format |
| `forge-plan` | Generate annotated, wave-ordered implementation plan (`forge:plan`) | Modifying task generation, wave ordering, initiative breakdown, or the tasks.md template |
| `forge-commit` | Structured commit creation enforcing branch convention and conventional commits (`forge:commit`) | Changing commit format rules, branch convention enforcement, or the phase sentinel that fires on commit |
| `forge-update-plan` | Mark implementation tasks complete with commit SHA traceability (`forge:update-plan`) | Modifying task completion logic, SHA recording, or Jira sync behavior |
| `forge-branching` | Branch policy enforcement via PreToolUse and pre-push hooks | Changing branch naming rules, hook trigger conditions, or per-repository branch config |
| `forge-verify` | Verify implementation delivers stated requirements; quality loop contract (`forge:verify`) | Modifying verification logic, PASS/FAIL criteria, or the verification report format |
| `forge-graduate` | Promote completed effort artifacts to canonical deployable documentation (`forge:graduate`) | Changing graduation merge algorithm, provenance metadata, or the capability directory structure |
| `forge-cross-repo` | Create and maintain efforts that span multiple repositories (`forge:project`, `forge:sync`, `forge:upstream`) | Modifying cross-repo effort projection, sync logic, or upstream proposal handling |
| `forge-slack` | Associate Slack channels with efforts; import messages; generate daily and weekly summaries (`forge:slack-channel`, `forge:slack-import`, `forge:slack-summarize`) | Modifying Slack channel association, message import logic, summary generation, or scheduling behavior |
| `forge-ui` | Generate standards-compliant UI code using the Rakuten Rewards design system — platform detection, component selection, design token usage, responsive layout (`forge:ui`) | Modifying UI generation logic, platform detection, standards loading, or output validation rules |
| `forge-ui-design` | Conversationally author a UI spec through a structured interview; produces `ui-spec.md` for consumption by `forge:ui` (`forge:ui-design`) | Modifying the interview flow, spec template, mode handling (explore/API-driven/Figma), or handoff format |
| `forge-help` | Live documentation and Q&A for the Forge framework — catalog mode (all skills, hooks, standards) and Q&A mode (answers questions by reading plugin artifacts) (`forge:help`) | Modifying catalog discovery logic, Q&A synthesis, stub filtering, effort-state boundary, or the help skill's trigger description |
| `forge-statusline` | Install and configure the Forge-aware Claude Code statusline showing effort phase, git branch, and session health (`forge:statusline`) | Modifying statusline script generation, installation logic, settings.json integration, or the sub-agent statusline variant |

## Creating a New Capability

1. Name the capability after what the engineer does with it
2. Create the directory with the standard structure above
3. Write `requirements/` and `spec/` before writing any `SKILL.md`
4. Add a row to the capabilities table in this file
5. The `SKILL.md` implementation files live in `plugins/forge/skills/<name>/`
