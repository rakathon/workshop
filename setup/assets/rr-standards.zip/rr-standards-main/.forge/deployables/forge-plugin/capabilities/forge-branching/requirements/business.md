# Business Requirements — forge-branching

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-1, BR-2, BR-5, BR-6, BR-7, BR-8, BR-9

---

## BR-1: All Development Work Must Happen on Feature Branches

No code, documentation, or workflow artifact may be committed directly to the default
branch. Every piece of work must be performed on a dedicated feature branch and merged
to the default branch via a pull request. This applies to AI agents and engineers
equally.

The default branch must always represent reviewed, approved work. A commit that lands
on main without a pull request has bypassed every quality gate the organization has
established: peer review, CI checks, standards compliance, and approval policy. The
Forge framework exists to enforce these gates. It cannot do so if agents or engineers
commit directly to main.

## BR-2: Forge Must Structurally Prevent Direct Commits to the Default Branch

The framework must make it structurally impossible — not merely discouraged — for an
agent or engineer to commit to the default branch in the course of normal development
work. When an agent attempts a direct commit or push to the default branch, the
operation must be blocked with a clear explanation and a concrete path forward.

This block must apply to agents acting on engineer instructions as well as to agents
acting autonomously on a task plan. Neither scenario may result in an unreviewed commit
landing on main.

A manual override path must exist for repository administrators performing legitimate
maintenance operations. This override must require explicit acknowledgment via an
environment variable that is not persisted, and every use must be logged.

## BR-3: Admin Override Path Must Exist and Be Audited

Structural enforcement must not prevent legitimate administrative operations that
require touching the default branch — for example, `forge:init` establishing the
initial `.forge/` structure, or `forge:update` applying migrations.

The override mechanism must require an explicit, ephemeral signal (not a persisted
flag or configuration) that the engineer has consciously set for the specific
operation. Every administrative bypass must produce an audit record so that the use
of overrides is visible and reviewable.

## BR-4: Defense in Depth — Both Agent and CLI Paths Must Be Enforced

Branch policy applies whether work is initiated via the AI agent or directly via the
`git` CLI. A hook that only covers one path leaves the other unprotected.

The enforcement mechanism must sit at both entry points:
- The AI agent path (Bash tool) — via a PreToolUse hook that fires regardless of
  how the commit command reaches the shell
- The direct CLI path — via a git `pre-push` hook installed by `forge:init`

An engineer who bypasses skills and uses the git CLI directly must face the same
enforcement as the AI agent.

## BR-5: Branch Names Must Communicate the Nature of the Change

Every branch must signal — without reading any code — what kind of work it represents.
Reviewers, release managers, and automation tools must be able to determine whether a
branch contains a bug fix, a new feature, a documentation update, or a production
emergency from the branch name alone.

Inconsistent branch naming creates friction at every handoff: reviewers do not know
what to expect before opening a PR, release managers cannot quickly identify which
branches need expedited review, and automation cannot reliably distinguish change
types. Branch names appear in merge commits, PR titles, and changelogs long after the
work is done — a name like `wip-stuff` tells nothing; `fix/session-token-expiry` is
self-documenting.

The framework must enforce this standard. An engineer who names a branch incorrectly
must be informed before that name becomes part of the permanent record.

## BR-6: Non-Effort Branches Must Follow a Type-Prefixed Naming Convention

Not every branch corresponds to a Forge effort. Ad-hoc bug fixes, documentation
updates, and exploratory refactors are legitimate activities without a full effort
lifecycle. These branches must follow a consistent convention: `<type>/<slug>` where
type is one of the defined set (feature, fix, hotfix, chore, docs, refactor, release)
and slug is a short kebab-case description.

The framework must reject branches that do not conform — a commit on a branch named
`my-branch` or `wip` must be blocked until the branch is renamed to a valid format.

## BR-7: The Agent Must Infer Branch Type Without Requiring the Engineer to Know the Taxonomy

When an engineer asks the agent to start work that does not map to an existing effort,
the agent must determine the appropriate branch type from the request without prompting
the engineer to choose from a list they should not need to know.

"Let's fix the crash in the auth flow" must produce `fix/auth-flow-crash` without
ceremony. Only when the type is genuinely ambiguous may the agent ask one clarifying
question. It must not ask unless necessary.

## BR-8: The Agent Must Warn at Push Time When Branch Name Does Not Match the Work

An engineer may name a branch for the work they expect to do, then end up doing
something different. At push time — when the work is about to be shared — the agent
must check whether the commits and changed files are consistent with the branch type.

If misaligned, the engineer must be informed with a concrete suggested alternative.
This is always a warning, never a block — the engineer may have context the agent
lacks and must always be able to proceed. The warning ensures the mismatch is visible
before it becomes part of the PR and merge record.

---

Success criteria: [success-criteria.md](success-criteria.md)
