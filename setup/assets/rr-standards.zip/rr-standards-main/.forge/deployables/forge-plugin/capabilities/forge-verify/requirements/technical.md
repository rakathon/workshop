# Technical Requirements — forge-verify

Parent deployable: [forge-plugin](../../requirements/technical.md)
Program TRs addressed: TR-10a

---

## TR-V-1: forge:verify Skill

### TR-V-1.1: Classification and Isolation

`forge:verify` is a Worker skill that runs as an isolated sub-agent. It does not share
context with the main engineer session. It reads discovery artifacts and implementation
code; it does not read session state, conversation history, or per-task loop state.

Running isolated ensures:
- Consistent analysis quality regardless of what has accumulated in the main session
- No contamination from partial implementation context held in the engineer's current
  conversation
- The full discovery artifact set can be loaded without consuming context the engineer
  needs for subsequent work

### TR-V-1.2: Inputs

The sub-agent receives:
- All discovery artifacts: `requirements/business.md`, `requirements/technical.md`,
  all ADRs under `spec/arch-decisions/`
- All spec artifacts: `spec/README.md`, `spec/skills.md`, any other files in `spec/`
- The implementation plan: `plan/tasks.md`
- Implementation code: all source files modified by tasks in the plan

The sub-agent must derive the list of relevant source files from the task SHAs recorded
in `plan/tasks.md` (each completed task records its commit SHA inline). It reads the
changed files for each task commit.

### TR-V-1.3: Verification Checks

For each business requirement in `requirements/business.md`:
- Identify which task(s) are responsible for delivering it (from `plan/tasks.md`)
- Confirm that the implementation code at the task's commit SHA provides real behavior
  — not a stub, empty function, or TODO placeholder
- Confirm that all components the requirement depends on are wired together in the code

For each technical requirement in `requirements/technical.md`:
- Apply the same check: responsible task(s), real implementation, integration wiring
- Additionally check that any spec-level contracts (API shapes, data models, event
  schemas) are reflected accurately in the implementation

For each ADR:
- Confirm the implementation does not contradict the decision
- For decisions that prescribe a specific technical approach (e.g., "use optimistic
  locking"), confirm the prescribed approach is used

**Stub detection:** A stub is any of:
- A function or method body consisting solely of: `return null`, `return undefined`,
  `return {}`, `throw new Error("not implemented")`, `TODO`, `FIXME`, `panic("TODO")`,
  or a language-equivalent placeholder
- An interface implementation where every method is a stub
- A configuration entry that references a handler or callback that is itself a stub

**Missing wiring:** Missing wiring is any of:
- A component registered in configuration but never called in a request path
- An event emitter with no subscriber, or a subscriber that is never registered
- A middleware or interceptor defined but not added to the chain
- A dependency injected into a constructor but never used in any method body

### TR-V-1.4: Output — Verification Report

`forge:verify` writes its output to `verification/report.md` in the effort directory.

**Report structure:**

```markdown
# Verification Report

**Effort:** <effort-id>
**Date:** <ISO-8601>
**Result:** PASS | FAIL

## Summary

[One paragraph: overall assessment. If PASS, confirm the implementation delivers the
effort's stated goals. If FAIL, summarize the critical gaps.]

## Requirement Coverage

### Business Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| BR-1 | <title> | PASS | Implemented in <file>:<line> |
| BR-2 | <title> | FAIL | No implementation found — see Gap 1 |

### Technical Requirements

| ID | Requirement (short) | Status | Notes |
|----|---------------------|--------|-------|
| TR-1 | <title> | PASS | |
| TR-2 | <title> | FAIL | Stub detected — see Gap 2 |

## Gaps

Each gap entry must include:
- Which requirement it affects
- The specific code location (file path + line number or function name)
- A plain-language description of what is missing or incomplete

### Gap 1 — <short title>

**Requirement:** BR-2
**Location:** `src/auth/session.ts:42` — `validateSession()`
**Description:** Function body returns `null` unconditionally. No session validation
logic is present.

[... additional gaps ...]

## ADR Compliance

| ADR | Decision | Status | Notes |
|-----|----------|--------|-------|
| ADR-001 | Use optimistic locking for ... | PASS | Used in `storage/repo.go:88` |
```

### TR-V-1.5: Result Semantics

**PASS:** All requirements have real implementation evidence. No stubs in load-bearing
paths. No missing integration wiring. All ADRs complied with.

**FAIL:** One or more requirements have no implementation evidence, are covered only by
stubs, have missing wiring, or the implementation contradicts an ADR.

There is no PASS WITH CONCERNS result for `forge:verify`. The check is binary: the
implementation either delivers the effort's stated goals or it does not. A concern that
is not a gap — a subjective quality observation, a stylistic preference, a potential
future risk — is out of scope for `forge:verify`.

### TR-V-1.6: Phase Sentinel Integration

`forge:verify` participates in the Phase Sentinel pattern at two points:

**Phase Entry Check (before spawning worker):**
Check `currentPhase` in `.state.json`:
- If `currentPhase` is `"verification"` or later: proceed silently — no phase check needed.
- If `currentPhase` is before `"verification"`: invoke
  `forge:promote <effort-id> --target verification` and wait for it to complete
  before spawning the worker. `forge:promote` will surface advisory checks for all
  phases in the gap and ask the engineer to confirm.

**Phase Completion Check (after PASS result):**
After presenting the PASS verification report:
- Invoke `forge:promote <effort-id> --target review` to offer immediate advancement
  to the review phase.
- If the result is FAIL: skip — implementation must resume before advancing.

Per ADR-031, these checks are advisory: the engineer can decline advancement and proceed
with verification without state changes.

---

## TR-V-2: Implementation Quality Loop Contract

### TR-V-2.1: Scope

The quality loop is a shared contract executed by all `forge:build-*` implementation
skills. Every implementation skill must execute the loop identically. The loop governs
what happens between a task being started and a task being committed and marked complete.

### TR-V-2.2: Loop Iteration Limit

Default maximum: **3 iterations**.

The limit is configurable per project via `.forge/config` (if present):
```
quality_loop_max_iterations=5
```

When no config is present, 3 is used. The configured value applies to all
`forge:build-*` skills in the repository.

### TR-V-2.3: Loop Steps (in order)

```
iteration = 0
while iteration < MAX_ITERATIONS:

  Step 1 — Implement
    Write or update source files per the task description,
    the task's acceptance criteria (from plan/tasks.md),
    and the applicable spec artifacts (API contract, storage schema, etc.).
    For [tdd] tasks: write the failing test first, then implement.
    Confirm the test fails before proceeding to Step 2.

  Step 2 — Lint
    Detect the language(s) of all files modified in Step 1.
    Run the configured linter for each detected language (see TR-V-2.5).
    Read the linter output in full.
    If errors or warnings are present: address them before continuing.
    If no linter is configured for a language: skip lint for that language.

  Step 3 — Validate against spec
    Read the task's acceptance criteria from plan/tasks.md.
    Read the applicable spec artifacts (API contract if implementing an endpoint;
    storage schema if modifying data access; event contract if publishing events).
    Confirm the implementation satisfies all acceptance criteria.
    If gaps exist: address them in the current iteration (do not defer to a future
    iteration or to forge:verify).

  Step 4 — Run tests
    Run the test suite or the affected subset.
    For [tdd] tasks: confirm the test written in Step 1 now passes.
    Confirm no existing tests regress.
    A task that breaks an existing test is not complete.

  If all checks pass (Steps 2, 3, 4):
    Commit with conventional message including effort scope:
      chore(<effort-id>): implement <task-title> (TASK-NNN)
    Record the first 7 characters of the commit SHA inline in plan/tasks.md:
      - [x] [auto][wave:1] Task description (TASK-NNN) (a3f9b12)
    Mark task complete — exit loop

  iteration += 1

If MAX_ITERATIONS reached without all checks passing:
  → Escalate (TR-V-2.6)
```

### TR-V-2.4: TDD Protocol

Tasks annotated `[tdd]` have a mandatory RED → GREEN → REFACTOR discipline:

1. **RED** — Write the test. Run it. Confirm it fails. If the test passes before any
   implementation is written, the test is incorrect — fix the test before proceeding.
2. **GREEN** — Write the minimum implementation to make the test pass.
3. **REFACTOR** — Improve the implementation without breaking the test.

The test must be written and confirmed failing **before** any implementation code is
written. An implementation skill that writes implementation first and then writes a
test that happens to pass has not followed TDD — it has written code and added a
passing test, which is a different and weaker discipline.

### TR-V-2.5: Linter Detection Table

The implementation skill detects which linter to run by checking for configuration
files in the project root (or standard config locations for the language).

| Language | Config file(s) | CLI command |
|----------|----------------|-------------|
| TypeScript / JavaScript | `eslint.config.*` or `.eslintrc.*` | `npx eslint <files>` |
| Go | `.golangci.yml` or `golangci-lint` binary in PATH | `golangci-lint run <files>` |
| Java | `checkstyle.xml` or PMD config in `pom.xml` / `build.gradle` | `mvn checkstyle:check` or `./gradlew checkstyle` |
| Kotlin | `.editorconfig` + detekt config | `./gradlew detekt` |
| Swift | `.swiftlint.yml` | `swiftlint <files>` |
| Python | `.flake8`, `setup.cfg [flake8]`, or `pyproject.toml [tool.flake8]` | `flake8 <files>` |

If a language is detected but no matching config file is found, skip the lint step for
that language. Do not fail or warn — absence of a linter config is a valid project
configuration.

If a config file is present but the linter binary is not installed, emit a warning
(do not fail the loop). The implementation skill does not install linter tooling.

### TR-V-2.6: Escalation Format

When the iteration limit is reached without all checks passing, the implementation
skill must write the following structure to the `pause` field of `.state.json`:

```json
{
  "pause": {
    "reason": "quality_loop_limit_reached",
    "taskId": "TASK-NNN",
    "taskDescription": "Human-readable task title",
    "iterationsAttempted": 3,
    "remainingFailures": {
      "lint": [
        "src/foo.ts:42 — 'bar' is assigned but never used (no-unused-vars)"
      ],
      "specValidation": [
        "Acceptance criterion 3 not satisfied: response must include 'correlationId' field"
      ],
      "tests": [
        "TestFoo/TestBar — expected 200, got 404"
      ]
    },
    "iterationSummary": [
      "Iteration 1: Implemented handler. Lint: 2 errors. Tests: 3 failures.",
      "Iteration 2: Fixed lint. Tests: 1 failure (integration test).",
      "Iteration 3: Attempted fix. Integration test still failing — likely missing middleware wiring."
    ],
    "suggestedNextAction": "Review middleware registration in src/app.ts. The route handler is defined but the auth middleware may not be applied to this route."
  }
}
```

All fields are required. `suggestedNextAction` must be a specific, actionable
recommendation — not a generic "review the code" statement.

The escalation commit message must follow the conventional commit format:
```
chore(<effort-id>): pause TASK-NNN — quality loop limit reached
```

---

## Constraints

- `forge:verify` must not run the test suite or linter. It is an analytical skill.
  Linting and testing are the quality loop's responsibility, executed per task at
  implementation time.
- `forge:verify` must not modify implementation code. It reads and reports.
- The quality loop must not silently swallow linter errors. Each error must be read,
  addressed, and confirmed resolved before the loop proceeds to Step 3.
- The iteration count resets per task, not per effort. Each task begins at iteration 0.
- Escalation state persists in `.state.json` until the task is resumed and completed.
  The implementation skill must detect existing escalation state when resumed and
  present the prior iteration summary to the engineer before continuing.
