# Business Requirements

*Extracted from: PM document paste (Slack Support Integration)*
*Extracted: 2026-04-21*

---

## BR-1: Slack Channel Association

An effort may have one or more associated Slack channels. Each association must be recorded with the effort so that tooling can reference it.

**Acceptance criteria:**
- One or more Slack channels can be associated with an effort; each association stores both the channel ID (stable API identifier) and the channel display name (used as the directory name for imported messages)
- Each channel association persists across sessions and is readable by other Forge skills
- An effort with no Slack channels behaves identically to the current state (the association is optional)
- Channels can be added to an effort incrementally without removing existing associations
- When a channel's display name changes in Slack, the stored name can be updated via `forge:slack-channel`; the existing message directory is renamed to match
- Each channel can be individually removed from an effort's associations without affecting other associated channels or existing imported message files

---

## BR-2: Periodic Message Import

Slack messages from an effort's associated channel are imported into the repository on a periodic basis. Messages are stored as markdown files organized chronologically.

**Acceptance criteria:**
- Messages from the associated Slack channel are pulled into the repository without manual intervention
- Imported messages are written to `efforts/<effort_id>/messages/YYYY-MM/<YYYY-MM-DD>.md`, one file per day
- Re-running the import for a day that already has a file updates it rather than creating a duplicate
- Messages are attributed to their author and include timestamps
- The import records a checkpoint after each successful run so that a subsequent run can resume from where the last one ended; a run that finds zero messages still advances the checkpoint so that already-confirmed-empty ranges are not re-scanned
- When no explicit date range is provided, the import automatically runs from the last checkpoint through the current time, minus a short configurable lag buffer (default: 5 minutes) to account for Slack API delivery lag and ensure in-flight messages are not permanently missed
- Thread replies sent after the import window opens, whose parent message predates the window, are fetched and included; the import looks back a configurable number of days (default: 30) before the window start to find threads with recent activity
- When no checkpoint exists, the import must prompt the user for a start date rather than attempting to fetch the full channel history
- When invoked in CI mode, the import scans all efforts in the repository, identifies every effort with an associated Slack channel, and runs the import for each one sequentially; per-effort results are reported individually

---

## BR-3: Daily Summaries

A daily summary is generated from each day's imported messages. The summary must give particular prominence to a defined set of high-signal topics while still covering other notable discussion.

**Acceptance criteria:**
- A human-readable summary of each day's Slack messages is produced and accessible
- The summary gives prominent, labeled sections to the following high-priority topics when present: architectural decisions, planning decisions, raised risks, raised bugs, raised problems with specifications, time-off notices, and status updates
- Topics not in the high-priority list may appear in a general notes section at the summary's discretion
- The summary is updated if new messages are imported for a day that already has a summary

---

## BR-4: Weekly Summaries

A weekly summary is generated from the week's imported messages. Like daily summaries, it must prominently highlight the same high-priority topics aggregated across the week.

**Acceptance criteria:**
- A human-readable summary spanning a full week of messages is produced and accessible
- The summary gives prominent, labeled sections to the following high-priority topics when present across the week: architectural decisions, planning decisions, raised risks, raised bugs, raised problems with specifications, time-off notices, and status updates
- The summary aggregates other notable themes and discussion in a general notes section
- Weekly summaries are generated on a consistent schedule aligned with the import cadence

---

## BR-10: Thread Structure Preservation

Slack threads must be imported and stored in a way that preserves their parent-reply relationship. A thread reply must be visually and structurally associated with the message that started the thread, not interleaved with top-level channel messages by timestamp.

**Acceptance criteria:**
- Thread replies are nested under their parent message in the daily file
- The parent message is anchored at its original send time in the top-level message flow
- All replies in a thread appear beneath the parent in reply order, regardless of when they were sent
- A thread with replies spanning multiple days is anchored on the day the parent message was sent; replies sent on later days are included under that parent entry and also cross-referenced in the daily file for the day the reply was sent
- Top-level messages that are not thread parents appear in the normal chronological flow

---

## BR-5: Linked Resource Surfacing

When imported Slack messages contain links to Confluence pages or Jira tickets, short summaries of those linked resources appear alongside the link in the stored notes.

**Acceptance criteria:**
- Links to Confluence pages in imported messages are enriched with a short summary of the linked page's content
- Links to Jira tickets in imported messages are enriched with a short summary of the ticket (title, status, description)
- Enrichment is best-effort: if a linked resource is inaccessible or returns an error, the link is preserved without a summary and the failure is noted
- Enriched summaries are appended inline or in a sidebar note adjacent to the original link reference

---

## BR-6: Slack API Authentication *(Implicit — not stated in PM document)*

Access to the Slack channel for message import requires authenticated and authorized API access.

**Acceptance criteria:**
- Slack API credentials are stored securely and never committed to the repository *(Implicit — not stated in PM document)*
- Access is scoped to the minimum permissions required to read channel messages *(Implicit — not stated in PM document)*
- Credentials can be rotated without changing the import logic *(Implicit — not stated in PM document)*

---

## BR-7: PII and Message Content Handling *(Implicit — not stated in PM document)*

Slack messages may contain personally identifiable information (names, email addresses, @-mentions, and other behavioral or conversational data). The import mechanism must handle this responsibly.

**Acceptance criteria:**
- Imported message files are stored only within the effort's own directory scope and are not exposed to unrelated efforts *(Implicit — not stated in PM document)*
- The channel association and imported messages are accessible only to contributors with access to the repository *(Implicit — not stated in PM document)*
- No message content is transmitted to third-party services other than Confluence and Jira for the link-enrichment feature described in BR-5 *(Implicit — not stated in PM document)*

---

## BR-8: Import Observability *(Implicit — not stated in PM document)*

The periodic import is an automated behavior that must be observable so failures can be detected and diagnosed.

**Acceptance criteria:**
- A successful import run produces a log entry or summary indicating how many messages were imported and for which date range *(Implicit — not stated in PM document)*
- A failed import run surfaces a clear error message that identifies the channel and the nature of the failure *(Implicit — not stated in PM document)*
- Persistent import failures do not silently corrupt or overwrite previously imported message files *(Implicit — not stated in PM document)*

---

## BR-9: Import Date/Time Range Selection

When invoking a message import, the user may optionally specify a start date/time and end date/time to bound the range of messages fetched. When no range is provided the import falls back to its default incremental behavior using the stored watermark.

**Acceptance criteria:**
- The import accepts an optional start date/time parameter
- The import accepts an optional end date/time parameter
- When both are provided, only messages within that range are fetched and written
- When only a start is provided, messages from that point through `now - lag-buffer` are fetched
- When neither is provided, the import runs incrementally from the last watermark through `now - lag-buffer`
- Specifying an explicit end bound (`--to`) disables the lag buffer for that run; the exact bound is used as-is
- Specifying a range does not overwrite or reset the stored watermark for future incremental runs

---

## PM Design Suggestions

The following implementation suggestions were found in the PM document and are captured here for the design phase. They are prescriptions, not requirements.

- Messages should be stored "inside the `efforts/<effort_id>/messages/` directory — structured similarly to how meeting transcripts are stored in `efforts/<effort_id>/meetings/`" *(section: paragraph 2)*
- The directory structure should use a top-level `YYYY-MM/` directory with daily files inside *(section: paragraph 2)*
