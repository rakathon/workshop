# Architectural Decisions — forge-init

Decisions specific to or most relevant to the forge-init deliverables. All ADRs are
held in the forge-plugin deployable at
[`../../../spec/arch-decisions/`](../../../spec/arch-decisions/).

---

## Relevant ADRs

| ADR | Title | Relevance to forge-init |
|-----|-------|------------------------|
| [ADR-001](../../../spec/arch-decisions/ADR-001-repository-as-state-store.md) | Repository as State Store | `.forge/version` and `.forge/` structure are version-controlled; no external state |
| [ADR-016](../../../spec/arch-decisions/ADR-016-two-tier-plugin-distribution.md) | Two-Tier Plugin Distribution | Explains global vs. per-project install; `forge:pin` implements the project-local tier |
| [ADR-017](../../../spec/arch-decisions/ADR-017-standards-discoverability-via-claude-md.md) | Standards Discoverability via CLAUDE.md | Motivates the forge:managed section; explains why AGENTS.md must be explicitly read |
| [ADR-020](../../../spec/arch-decisions/ADR-020-mandatory-adoption-enforced-via-init-and-review.md) | Mandatory Adoption via init and review | `forge:init` is the adoption gate; explains why enforcement is in the init flow |
| [ADR-021](../../../spec/arch-decisions/ADR-021-version-currency-via-semantic-versioning-and-lag-periods.md) | Version Currency via Semantic Versioning | Motivates `VERSIONS.json`, `forge_min_version`, mandatory deadlines, and the 30-day window |
| [ADR-023](../../../spec/arch-decisions/ADR-023-work-item-hierarchy-modeled-in-state.md) | Work Item Hierarchy Modeled in State | Defines the `.forge/efforts/README.md` registry format with `Parent` column and hierarchy display; forge:init creates this registry to support cross-repo work item references (BR-12) |
| ~~[ADR-025](../../../spec/arch-decisions/ADR-025-product-scoped-canonical-artifact-directory.md)~~ | ~~Product-Scoped Canonical Artifact Directory~~ | Superseded by ADR-029 — see ADR-029 for the current `deployables/`/`products/` directory model |
| [ADR-026](../../../spec/arch-decisions/ADR-026-per-project-plugin-version-pinning.md) | Per-Project Plugin Version Pinning | forge:init reads `marketplace.json` (written by forge-pin) to populate `forge_min_version`; primary implementation is in the [forge-pin capability](../../forge-pin/) |
| [ADR-027](../../../spec/arch-decisions/ADR-027-cross-repo-effort-artifacts-in-shared-effort-repositories.md) | Cross-Repo Effort Artifacts | Motivates `repo_type=project`; explains `Parent` column in `.forge/efforts/README.md` |
| [ADR-028](../../../spec/arch-decisions/ADR-028-capabilities-as-bounded-units-within-deployables.md) | Capabilities as Bounded Units | Why `capabilities/` directories are NOT created by `forge:init` |
| [ADR-029](../../../spec/arch-decisions/ADR-029-deployable-project-product-repository-roles.md) | Deployable/Project/Product Repository Roles | Defines the three `repo_type` values; motivates the repository type prompt in `forge:init` |
