# Runbook — forge-verify

## forge:verify

### When to Run

Run `forge:verify` after all tasks in `plan/tasks.md` are marked complete and before
running `forge:promote` to advance to the verification phase. It is also triggered
automatically when `forge:promote` is invoked and `verification/report.md` is absent.

The conversational trigger is any statement of PR readiness: "let's verify before
opening the PR", "all tasks are done", "forge:verify".

### Interpreting a FAIL Report

A FAIL report contains a Gaps section with numbered gap entries. Each entry includes:
- The requirement it affects (BR-N or TR-N)
- The code location (file path + function or line)
- A description of what is missing

**For stub gaps:** Open the identified file and implement the real behavior. The stub
was detected because the function body is a placeholder. Replace it with the actual
implementation, then re-run the task through the quality loop.

**For missing wiring gaps:** The identified component exists but is not connected to
the rest of the system. Common causes: middleware not added to the chain, route handler
not registered, event subscriber not wired at startup. Find the configuration or
registration point and connect the component.

**For "No task found" gaps:** A requirement has no corresponding task. Add a task to
`plan/tasks.md` for this requirement, implement it through the quality loop, then
re-run `forge:verify`.

After addressing all gaps, re-run `forge:verify`. The report is overwritten on each
run. A new PASS report is required before `forge:promote` will advance the phase.

### Re-Running forge:verify

`forge:verify` is idempotent. Running it multiple times produces a fresh report each
time. The previous `verification/report.md` is overwritten.

---

## Implementation Quality Loop Contract

### When a Task Is Escalated

If a task reaches the iteration limit, the implementation skill writes escalation state
to `.state.json` and surfaces it to the engineer. The task is not marked complete.

**To resolve an escalation:**

1. Read the escalation state: open `.state.json` and find the `pause` field
2. Review `remainingFailures` — what is still failing?
3. Review `iterationSummary` — what was attempted?
4. Review `suggestedNextAction` — what does the skill recommend?

**Common resolution paths:**

- **Lint error that persists across iterations:** The fix attempted was incorrect.
  Read the lint rule documentation for the specific rule ID. Fix the root cause, not
  just the symptom.

- **Test failure that cannot be resolved:** The test may be testing the wrong thing,
  or there may be a missing dependency (a mock, a test fixture, a database seed). If
  the spec is ambiguous, clarify the acceptance criterion before resuming.

- **Spec validation gap:** The acceptance criterion may be ambiguous or may conflict
  with another requirement. Review the spec artifact the criterion references. If
  clarification is needed, update `plan/tasks.md` or the relevant spec file before
  resuming.

**After resolving the root cause:**

Resume the task. The implementation skill reads the escalation state, presents the
prior summary, and resets the iteration counter to 0 for the new attempt. The
`suggestedNextAction` is presented as starting context — the engineer is not required
to follow it if they have determined a different approach.

### Adjusting the Iteration Limit

If 3 iterations is consistently insufficient for the project's complexity (e.g., long
integration test suites that require multiple dependency fixes), increase the limit in
`.forge/config`:

```
quality_loop_max_iterations=5
```

The new limit takes effect immediately for subsequent tasks. Tasks already in progress
(escalated) use the limit that was in effect when they were escalated.

There is no maximum — the limit is a project decision. However, limits above 5 should
be examined: if tasks routinely require more than 5 iterations, the likely cause is
overly large tasks (break them into smaller tasks) or spec ambiguity (clarify before
implementing).
