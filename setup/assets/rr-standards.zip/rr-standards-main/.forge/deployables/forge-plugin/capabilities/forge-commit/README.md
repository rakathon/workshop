# forge-commit

Structured commit creation for the Forge AI-accelerated development framework.
Delivers the `forge:commit` skill that replaces raw `git commit` during implementation
work, enforcing branch conventions, scope discipline, conventional commit format, and
machine-readable traceability via structured git notes (ADR-008).

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:commit` | Skill | Interactive | Manual invocation or "commit this task" |

**`forge:commit`** guides an engineer through a six-step commit ceremony: branch
convention check, staged-changes scope validation, conventional commit message
proposal, commit creation, structured git note attachment, and a prompt to run
`forge:update-plan`. The git note attaches a JSON metadata payload to the commit
that `forge:verify`, `forge:diagnose`, and `forge:revert` consume for programmatic
traceability.

## Why This Capability Exists

Raw `git commit` produces inconsistent messages, allows mixed-concern commits that
blur task boundaries, and produces no machine-readable metadata. Without structured
notes, downstream skills (`forge:verify`, `forge:diagnose`, `forge:revert`) must
parse commit messages — which is fragile and error-prone. This capability enforces
the discipline required for reliable AI-assisted verification and rollback.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-plan](../forge-plan/) | Generates `plan/tasks.md` that forge:commit reads for task IDs. |
| [forge-verify](../forge-verify/) | Consumes git notes written by forge:commit to verify implementation. |
| [forge-effort](../forge-effort/) | Provides the effort directory and `.state.json` that forge:commit references. |

See also: [ADR-008 — Structured git notes as the Task Metadata Layer](../../../../spec/arch-decisions/ADR-008-structured-git-notes.md)

## Implementation Location

`plugins/forge/skills/commit/` — `forge:commit` SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| `requirements/business.md` | Business drivers for structured commit enforcement |
| `requirements/technical.md` | Technical requirements for each commit ceremony step |
| `requirements/success-criteria.md` | Measurable acceptance criteria |
| `spec/README.md` | Skill design overview |
| `spec/skills.md` | Detailed skill specification |
