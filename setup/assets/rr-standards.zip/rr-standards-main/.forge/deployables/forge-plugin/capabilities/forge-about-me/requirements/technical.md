# Technical Requirements — forge-about-me

Parent deployable: [forge-plugin](../../requirements/technical.md)

---

## TR-1: forge:about-me Skill

### TR-1.1: Command Surface

`forge:about-me` takes no arguments. It is always safe to run and requires
no active Forge effort, no git repository, and no prior state.

### TR-1.2: Conversational Flow

The skill must execute five phases in order:

1. **Role extraction** — request LinkedIn profile, CV, or job description;
   extract role fields; note gaps for the next phase
2. **Role deep-dive** — fill gaps with targeted questions; never re-ask
   anything already answered
3. **Writing samples** — collect one or more samples; analyze tone across
   defined dimensions; present a 3–4 sentence voice description for
   confirmation; wait for confirmation before proceeding
4. **Communication audience** — one focused question about day-to-day
   communication channels and audience adaptation
5. **Assembly and output** — detect surface, assemble the context block,
   deliver to the correct destination

### TR-1.3: Output Format

The assembled context block must be wrapped in HTML comment markers and
contain exactly four sections in this order:

```
<!-- forge:about-me:start -->
## My Context Profile

### Company Context
[Fixed Rakuten Rewards description — must not be altered or summarised]

### My Role
[3–5 sentences, first person, prose only — no bullets]

### Communication Audience
[1–3 sentences, first person, prose only]

### Tone & Voice
[3–4 sentence voice description, first person]
[Anti-pattern instruction line]
[Closing "Write as..." line]
<!-- forge:about-me:end -->
```

The markers `<!-- forge:about-me:start -->` and `<!-- forge:about-me:end -->`
must appear verbatim as the first and last lines of the block in every output
destination — `CLAUDE.md` and `about-me.md` alike.

Descriptive content (My Role + Communication Audience + Tone & Voice opening
sentences) must target under 250 words. The anti-pattern instruction is fixed
prose and sits outside that target.

### TR-1.4: Surface-Specific Output

The skill uses named surface sections (Claude Code, Claude.ai/Desktop,
Cowork) rather than runtime detection. Claude knows which surface it is
running on from its own context and applies the appropriate section.

- **Claude Code** — Write the block to `~/.claude/CLAUDE.md` (the
  user-level personal context file). Never write to a project `CLAUDE.md`.
- **Claude.ai / Claude Desktop** — Save the block as `about-me.md` in the
  current working directory and provide "paste into Custom Instructions"
  guidance.
- **Cowork** — Save the block as `about-me.md` and share the full path so
  the user can retrieve it.

### TR-1.5: ~/.claude/CLAUDE.md Write Behaviour

When writing to `~/.claude/CLAUDE.md` the skill must use marker-based
replacement:

1. Read the existing `~/.claude/CLAUDE.md` (create it if absent)
2. Search for `<!-- forge:about-me:start -->` and `<!-- forge:about-me:end -->`
3. If both markers are present: replace the entire span from the opening
   marker to the closing marker (inclusive) with the new block
4. If no markers are present: append the new block at the end of the file
   with a preceding blank line
5. Never modify any content outside the marker boundaries

### TR-1.6: Tone Analysis

The skill must analyze writing samples across these dimensions: formality,
directness, technical depth, length/brevity, warmth, and structure. It must
also scan for eight defined AI anti-patterns and remove from the output list
any pattern that genuinely appears in the user's own writing.

### TR-1.7: No Effort Context Required

The skill must not read, write, or reference `.forge/` in any way. It has
no dependency on Forge effort state.
