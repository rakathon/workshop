# forge-validate-messaging

Validates event and message contracts (`spec/messaging/*.md`) against the organizational
messaging standards. An inline editing aid used during contract authoring — provides
immediate standards feedback without writing gate artifacts or updating workflow state.

**Skill:** `forge:validate-messaging`
**Classification:** Worker
**Part of:** spec-driven-development initiative
