# Success Criteria — forge-spec-storage

- [ ] PII fields in a proposed schema trigger an inline GDPR comment immediately after entity confirmation
- [ ] Index check fires only when requirements mention query patterns; advisory question when no patterns found
- [ ] Storage type is announced and confirmed before any entity is designed
- [ ] When spec/api/ exists and has resource names not matched to entities, the unmapped resources are flagged
- [ ] `.state.json` is updated to "present" after the schema is written
