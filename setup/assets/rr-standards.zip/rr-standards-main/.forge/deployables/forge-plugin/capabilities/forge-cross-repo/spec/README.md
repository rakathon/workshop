# forge-cross-repo Specification

## Overview

`forge-cross-repo` delivers three skills that manage the lifecycle of cross-repository
efforts in the Forge framework. When a feature spans multiple repositories, work is
organized at two levels: a coordination repository that holds the cross-cutting
requirements and plan, and local sub-efforts in each deployable repository that hold the
implementation detail.

The three skills handle the three directions of information flow this creates:

| Skill | Direction | What it does |
|-------|-----------|-------------|
| `forge:project` | Coordination → Local | Creates a local sub-effort from a coordination effort by materializing relevant artifacts as local files |
| `forge:sync` | Coordination → Local (check) | Detects when local projections are behind the coordination repository |
| `forge:upstream` | Local → Coordination | Creates change proposals and optionally PRs when local work reveals coordination-level gaps |

## Design Rationale

The central design decision is **materialized projections** rather than live references,
symlinks, or submodules. See
[ADR-003](arch-decisions/ADR-003-materialized-projections-for-cross-repo-artifacts.md)
for the full rationale.

The short version: local engineers must be able to work offline and independently. A
reference that requires a network fetch to resolve is not a local artifact — it is a
network dependency. Projections are real files, committed to git, readable without
any additional fetch. Staleness is a known state managed by `forge:sync`, not a silent
failure mode.

## Information Flow

```
Coordination repository
  .forge/efforts/favorite-stores/
    requirements/business.md
    requirements/technical.md
    plan/plan.md
          |
          | forge:project (fetch via GitHub API, scope, materialize)
          v
Local deployable repository
  .forge/efforts/favorite-stores-backend/
    requirements/projected-business.md   ← provenance header + scoped content
    requirements/projected-technical.md  ← provenance header + scoped content
    plan/projected-plan.md               ← provenance header + scoped content
    .state.json                          ← coordinationRef records all projections
          |
          | Local discovery reveals gap
          v
  upstream-proposals/001-add-store-id-field.md
          |
          | forge:upstream --pr
          v
Coordination repository (PR opened)
```

## Key Data Structures

### coordinationRef (in .state.json)

Records the origin and current status of all projections for a local sub-effort.
See [technical.md](../requirements/technical.md#tr-15-coordinationref-structure) for
the exact schema and field definitions. The `sourceSha` on each projection entry is
what enables `forge:sync` to detect staleness without a full diff.

### Provenance header

Written at the top of every projected file. Contains all five fields required for
staleness detection and traceability. See
[technical.md](../requirements/technical.md#tr-14-provenance-header-format) for the
exact format.

### upstreamProposals (in .state.json)

Array of pending and resolved change proposals. Each entry records the proposal file,
its status (`proposed`, `merged`, `rejected`), the target coordination file, and the
PR URL if one was created.

## Skill Designs

Detailed step-by-step skill designs are in [skills.md](skills.md).

## Architecture Decisions

- [ADR-003: Cross-Repo Artifacts Are Materialized Projections, Not Live References](arch-decisions/ADR-003-materialized-projections-for-cross-repo-artifacts.md)
