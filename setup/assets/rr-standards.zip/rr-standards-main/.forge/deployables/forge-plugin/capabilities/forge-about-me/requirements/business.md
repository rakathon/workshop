# Business Requirements — forge-about-me

Parent deployable: [forge-plugin](../../requirements/business.md)

---

## BR-1: Generate a Personal Claude Context Profile

Rakuten Rewards employees use Claude across multiple surfaces — Claude Desktop,
Claude.ai, and Claude Code. Without a personal context block in the system
prompt, every conversation starts cold: Claude has no knowledge of who the
person is, what they do, or how they communicate.

`forge:about-me` must guide any employee through producing an accurate,
specific, first-person context block they can paste into Claude's Custom
Instructions or CLAUDE.md — so that Claude behaves like a well-briefed
colleague from the first message of every conversation.

## BR-2: Workshop-Ready Efficiency

The primary delivery context is an internal workshop. The skill must feel
efficient and warm — not slow or bureaucratic. It must avoid asking questions
that can be answered from materials the user already provided, and must keep
each conversational turn focused on one or two things at most.

## BR-3: Tone Accuracy via Writing Samples

Generic adjectives ("clear", "professional") produce useless context blocks.
The skill must collect actual writing samples from the user — Slack messages,
emails — and derive a specific, sample-grounded voice description. It must
present that description for confirmation before including it in the output.

## BR-4: Surface-Aware Output

Employees use the skill from different contexts. In a Claude Code project
session, the natural home for personal context is `CLAUDE.md`. In a
Desktop or Chat session, the natural output is a standalone file the user
can copy from. The skill must detect the context and offer the right
output path without asking the user to understand the technical distinction.
