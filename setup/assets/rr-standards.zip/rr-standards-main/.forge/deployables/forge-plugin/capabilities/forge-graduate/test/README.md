# Test Strategy — forge-graduate

## Scope

| Area | What is tested |
|------|---------------|
| `forge:graduate` skill | Merge algorithm correctness, provenance insertion, post-approval reconciliation, state updates, registry removal, coordination effort targeting, missing-target error handling, worker isolation |

---

## Approach

### Skill Behavioral Tests

`forge:graduate` is an LLM-executed skill. It is tested using the with/without-context
eval methodology from rr-standards. The `.evals.json` companion file alongside `SKILL.md`
provides the eval set.

The eval set must have at minimum 5 compliant and 5 non-compliant examples covering the
main behavioral rules. `rr-standards:validate --active` provides the harness.

### Integration Tests

End-to-end tests covering the full graduation lifecycle on a fixture repository with
known effort and deployable structures.

**Test cases:**

| Test | Fixture state | Expected result |
|------|--------------|----------------|
| First-time graduation | Effort with artifacts; no existing canonical docs | Canonical docs created with correct content; provenance comment present |
| Incremental graduation | Prior canonical docs exist; effort updates one section | Existing section replaced; unchanged sections preserved; no duplicate sections |
| Post-approval modifications present | `.state.json` has `postApprovalModifications` entries | Graduation report lists each modification; canonical docs reflect final state |
| No post-approval modifications | `.state.json` `postApprovalModifications` is empty | Graduation report states "None." |
| Capability-scoped effort | `.state.json` `capabilities` is populated | Updates target `capabilities/<cap>/`; deployable-level docs untouched |
| Coordination effort | `.state.json` `businessProducts` populated | Updates `.forge/products/<name>/`; not `.forge/deployables/<name>/` |
| Missing target | `.state.json` has no `deployables` or `businessProducts` | Skill halts; returns clear error; no files written |
| Already graduated | `.state.json` `graduation.graduated` is true | Skill halts; returns error noting effort was already graduated |
| ADR missing effort reference | ADR exists but lacks `**Created by:**` field | Provenance field added; graduation report notes the fix |
| ADR absent from canonical directory | ADR listed in `.state.json` but not present in `.forge/spec/arch-decisions/` | Graduation report flags missing ADR; graduation otherwise proceeds |
| Registry row removal | `.forge/efforts/README.md` contains effort row | Row removed; surrounding rows and table formatting unchanged |
| Graduation commit | After graduation | Single commit with only canonical docs, `.state.json`, and `README.md` changes |

### Merge Algorithm Unit Verification

The merge algorithm is the highest-complexity behavior in this skill. Tests must
cover it explicitly:

| Case | Input | Expected |
|------|-------|----------|
| Section exists in canonical, effort updates it | Canonical has `## BR-1`; effort has `## BR-1` with new content | Canonical `## BR-1` contains effort content |
| Section absent in canonical, effort adds it | Canonical has `## BR-1`; effort has `## BR-2` | Canonical gains `## BR-2`; `## BR-1` unchanged |
| Effort has no content for a section | Canonical has `## BR-3`; effort has no `## BR-3` | Canonical `## BR-3` preserved unchanged |
| Empty canonical document | Target file does not exist | File created from effort artifact with provenance comment |
| Append pattern detected | N/A — skill must never produce this | No test case needed; verify absence in all output |

---

## Test Plans

_None yet — to be added during implementation phase._

## Coverage Notes

The merge algorithm and post-approval modification reporting are the highest-priority
items for behavioral testing. The merge algorithm determines whether canonical
documentation remains coherent after graduation, and failures are difficult to detect
without explicit verification. Post-approval modification reporting is the primary
safeguard against silently promoting unapproved changes.
