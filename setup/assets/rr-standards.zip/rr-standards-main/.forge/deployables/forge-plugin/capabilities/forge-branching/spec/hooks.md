# forge-branching Hooks Design

Design for the two enforcement hooks delivered by this capability. Both hooks are pure
POSIX shell with no external tool dependencies beyond git.

Implementation:
- `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh`
- `plugins/forge/hooks/pre-push/pre-push.sh`

---

## Hook 1: enforce-branch-policy.sh (PreToolUse)

**File:** `hooks/pre-tool-use/enforce-branch-policy.sh`
(in plugin cache at `~/.claude/plugins/cache/<marketplace-dir>/forge/<sha>/`)

**Trigger:** `PreToolUse` — matcher `Bash`

**Scope:** Project — registered in `.claude/settings.json` at project scope, pointing
to the hook script in the plugin cache.

**Purpose:** Before any Bash tool call, check whether the command is a `git commit`
or `git push` and whether the current branch is the default branch. If both are true
and no admin override is active, block the tool call with exit 2 and emit a structured
JSON diagnostic on stderr.

---

### Behavior (Numbered Steps)

1. **Check tool name.** Read the tool name from `CLAUDE_TOOL_NAME`. If the value is
   not `Bash`, exit 0 immediately. This ensures the hook adds no latency to non-shell
   tool calls (Write, Edit, Read, etc.).

2. **Check command.** Read the command from `CLAUDE_TOOL_INPUT`. If the command does
   not contain the substring `git commit` and does not contain the substring `git push`,
   exit 0 immediately. This allows all non-commit/push shell commands on any branch.

3. **Check admin override.** If `FORGE_ALLOW_MAIN_COMMIT` equals `1` or if
   `FORGE_ADMIN_OP` is set and non-empty, jump to the admin override path (step 8).

4. **Get current branch.** Run `git branch --show-current` and capture the output.
   If the output is empty (detached HEAD state), exit 0 — no branch to protect.

5. **Determine default branch.** Run `git config init.defaultBranch` and capture the
   output. If the output is empty, use `main` as the fallback.

6. **Compare.** If the current branch (step 4) does not equal the default branch
   (step 5), exit 0 — the engineer is already on a feature branch.

7. **Block.** Emit the structured diagnostic JSON to stderr and exit 2.

8. **Admin override path.** Write an audit log entry to `.forge/audit/<timestamp>.json`
   (creating the directory if needed). Exit 0 to allow the operation.

---

### Exit Code Table

| Condition | Exit | Notes |
|-----------|------|-------|
| Tool is not `Bash` | 0 | No git calls made |
| Command lacks `git commit` / `git push` | 0 | No git calls made |
| `FORGE_ALLOW_MAIN_COMMIT=1` | 0 | Audit log written |
| `FORGE_ADMIN_OP` is set | 0 | Audit log written |
| Current branch is not the default branch | 0 | Normal feature branch work |
| Detached HEAD (empty branch name) | 0 | Cannot determine branch; allow |
| git not installed or not a git repo | 0 | Allow; don't block non-git contexts |
| Current branch equals default branch | 2 | Blocked — branch policy violation |

---

### Structured Diagnostic

Emitted to stderr on exit 2:

```json
{
  "type": "branch_policy_violation",
  "blocked": true,
  "reason": "Direct commits to 'main' are not permitted. All work must happen on a feature branch and be merged via pull request.",
  "currentBranch": "main",
  "activeEffort": "forge-branching",
  "nextAction": "Switch to your effort branch: git checkout effort/forge-branching"
}
```

When no active effort is detected:

```json
{
  "type": "branch_policy_violation",
  "blocked": true,
  "reason": "Direct commits to 'main' are not permitted. All work must happen on a feature branch and be merged via pull request.",
  "currentBranch": "main",
  "activeEffort": null,
  "nextAction": "Create an effort branch first: use forge:effort to start a new effort"
}
```

The `reason` field always uses the actual default branch name in the message, not the
literal string `'main'`. If the default branch is `master`, the message reads
`"Direct commits to 'master' are not permitted."`.

---

### Admin Override and Audit Log

**Override signals:**
- `FORGE_ALLOW_MAIN_COMMIT=1` — set by the engineer explicitly for a single operation
- `FORGE_ADMIN_OP=<reason>` — set by Forge skills (`forge:init`, `forge:update`)

When either signal is present, the hook:
1. Creates `.forge/audit/` if it does not exist
2. Writes `.forge/audit/<YYYY-MM-DDTHH-MM-SSZ>.json`:

```json
{
  "operation": "direct_commit_override",
  "reason": "<FORGE_ADMIN_OP value, or 'FORGE_ALLOW_MAIN_COMMIT=1 set by engineer'>",
  "branch": "<current branch>",
  "timestamp": "<ISO-8601 UTC>"
}
```

3. Exits 0 to allow the operation

The timestamp in the filename uses hyphens instead of colons to produce a valid path:
`2026-03-27T14-30-00Z.json`.

---

### Performance

The hook is designed to add negligible latency to Bash tool calls:

- Steps 1–2 (tool and command checks) involve only string matching with no subprocess
  calls. Feature branch work and non-commit commands return at step 2 in microseconds.
- Steps 4–5 (branch detection) make at most two subprocess calls: `git branch --show-current`
  and `git config init.defaultBranch`. Both are fast local reads with no network I/O.
- The overall hook completes in under 100ms including subprocess overhead.

---

### Edge Cases

| Condition | Behavior |
|-----------|----------|
| Detached HEAD state | `git branch --show-current` returns empty string; exit 0 |
| Empty branch name for any other reason | exit 0 |
| git not installed | `git branch --show-current` fails; treat as empty; exit 0 |
| Not inside a git repository | `git branch --show-current` returns empty; exit 0 |
| `.forge/` directory absent (no audit dir needed) | Admin override creates it on demand |
| `FORGE_ADMIN_OP` set but `FORGE_ALLOW_MAIN_COMMIT` not set | Override still applies; `FORGE_ADMIN_OP` is sufficient |
| Both `FORGE_ALLOW_MAIN_COMMIT` and `FORGE_ADMIN_OP` set | Override applies; `FORGE_ADMIN_OP` value used as reason in audit log |

---

### Branch Name Format Validation (TR-7)

After the default-branch block check passes (i.e., the current branch is NOT the
default branch), `enforce-branch-policy.sh` performs an additional validation step
for `git commit` commands.

**Validation sequence (for git commit only):**

1. Extract the current branch name (already captured in step 4)
2. Validate the branch name against the allowed pattern:
   `^(effort/[a-z0-9-]+|feature/[a-z0-9-]+|fix/[a-z0-9-]+|hotfix/[a-z0-9-]+|chore/[a-z0-9-]+|docs/[a-z0-9-]+|refactor/[a-z0-9-]+|release/[a-z0-9.]+)$`
3. If the branch name does not match: exit 2 with the following structured diagnostic
   emitted to stderr:

```json
{
  "type": "branch_name_violation",
  "blocked": true,
  "reason": "Branch name 'wip-stuff' does not follow naming conventions.",
  "currentBranch": "wip-stuff",
  "allowedFormats": ["effort/<id>", "feature/<slug>", "fix/<slug>", "hotfix/<slug>", "chore/<slug>", "docs/<slug>", "refactor/<slug>", "release/<version>"],
  "suggestedName": "<type>/<slug>",
  "nextAction": "Rename: git branch -m <type>/<slug>"
}
```

4. If the branch name matches: exit 0, allow the commit

**Allowed branch types:**

| Type | When to use |
|------|-------------|
| `effort` | Forge effort branches — created automatically by `forge:effort` |
| `feature` | New functionality that did not exist before |
| `fix` | Bug fix for non-production code |
| `hotfix` | Urgent fix for a production issue |
| `chore` | Maintenance: dependency updates, config changes, cleanup |
| `docs` | Documentation only — no source code changes |
| `refactor` | Structural code changes with no behavior change |
| `release` | Release preparation — version bumps, changelogs |

The `reason` field in the diagnostic always uses the actual branch name (not the literal
string `'wip-stuff'`). The `suggestedName` field is a template placeholder instructing
the engineer to supply the correct type and a descriptive slug.

---

### Push-Time Branch Alignment Warning (TR-9)

After the default-branch block check passes AND after format validation passes, for
`git push` commands (not `git commit`), `enforce-branch-policy.sh` performs a secondary
alignment check: does the work being pushed match the branch type?

**Bypass:** If `FORGE_SKIP_BRANCH_VALIDATION=1` is set, skip both this alignment check
and any other push-time checks (note: format validation on `git commit` still applies —
the bypass only affects push-time behavior).

**Alignment check sequence:**

1. Extract the branch type prefix (the first path segment before `/`)
2. If the branch type is `effort`: skip — effort branches are always aligned by definition
3. Read the commits being pushed (capped at 20):
   `git log origin/<default-branch>..HEAD --oneline 2>/dev/null`
4. Read the changed files (capped at 30):
   `git diff origin/<default-branch>...HEAD --name-only 2>/dev/null | head -30`
5. If both commands return nothing (no divergence from the default branch): skip the check
6. Invoke the alignment check subprocess with a 10-second timeout:
   ```
   claude -p "Branch name: <branch>. Commits: <commits>. Changed files: <files>. Does the branch type match the work? Reply with YES or NO and if NO suggest a better branch name." --max-tokens 60
   ```
7. Parse the response: if the response contains `NO`, emit a warning to stdout
8. If the subprocess fails or times out: skip silently and exit 0
9. Exit 0 always — this check is advisory only; the push proceeds regardless

**Warning format (emitted to stdout when misaligned):**

```
⚠️  Branch alignment check: branch name may not match the work being pushed.
    Current branch: fix/auth-flow-crash
    Suggestion: feature/auth-token-refresh

    To rename before opening PR: git branch -m feature/auth-token-refresh
    Push continues.
```

The `Suggestion:` line is populated from the branch name returned by the `claude -p`
subprocess. If the subprocess response contains `NO` but no alternative branch name can
be parsed, the suggestion line is omitted.

---

## Hook 2: pre-push.sh (Git Hook Template)

**File:** `hooks/pre-push/pre-push.sh`
(in plugin cache; installed to `.git/hooks/pre-push` by `forge:init`)

**Trigger:** git `pre-push` hook — invoked by git before each push

**Scope:** Repository — installed into `.git/hooks/pre-push` by `forge:init`. Not
committed to version control; re-installed on each `forge:init` run.

**Purpose:** Enforce branch policy for engineers using the git CLI directly. Reads the
pushed refs from stdin and blocks any push targeting `refs/heads/main` or
`refs/heads/master`.

---

### Standard Git Hook Interface

Git invokes `pre-push.sh` with two arguments:
- `$1` — the remote name (e.g., `origin`)
- `$2` — the remote URL

For each ref being pushed, git writes one line to stdin:
```
<local-ref> <local-sha1> <remote-ref> <remote-sha1>
```

The hook reads all lines from stdin before making any blocking decision.

---

### Detection Logic

For each line read from stdin, the hook extracts the remote ref (field 3 in the
whitespace-delimited line). If the remote ref equals `refs/heads/main` or
`refs/heads/master`, the hook records a violation. After reading all lines, if any
violation was recorded, the hook emits the block message and exits 1.

---

### Block Message Format

When blocking, the hook reads the actual target branch name from the pushed ref and
inserts it dynamically. The first line format is:
`forge: direct push to '<branch>' is not permitted. Open a pull request instead.`

Full message printed to stderr:

```
forge: direct push to '<branch>' is not permitted. Open a pull request instead.
All work must be merged via pull request.

To open a pull request: gh pr create
To bypass this check (emergency only): git push --no-verify
```

For example, if the target branch is `main`:

```
forge: direct push to 'main' is not permitted. Open a pull request instead.
All work must be merged via pull request.

To open a pull request: gh pr create
To bypass this check (emergency only): git push --no-verify
```

---

### --no-verify Bypass

When `git push --no-verify` is used, git skips all hooks before executing the push.
The `pre-push.sh` hook is simply not invoked. No additional bypass logic is needed
in the hook script — the standard git mechanism provides the emergency bypass.

This is documented in the block message so engineers know the bypass path exists.

---

### Exit Code Table

| Condition | Exit | Notes |
|-----------|------|-------|
| No refs pushed to `refs/heads/main` or `refs/heads/master` | 0 | Allowed |
| Push targets `refs/heads/main` | 1 | Blocked |
| Push targets `refs/heads/master` | 1 | Blocked |
| `git push --no-verify` used | — | Hook not invoked by git |

---

### Edge Cases

| Condition | Behavior |
|-----------|----------|
| Push to `refs/heads/main-backup` or similar | exit 0 — exact match only |
| Push of tag refs (e.g., `refs/tags/v1.0.0`) | exit 0 — tag refs not matched |
| Push to remote branch with different name (e.g., `refs/heads/feature/x`) | exit 0 |
| Empty stdin (force push with no refs?) | exit 0 |
| Hook not executable | git reports hook permission error; engineer must run `chmod +x .git/hooks/pre-push` |

---

## Testing Requirements

The PreToolUse hook requires tests covering:

| Test case | Input | Expected behavior |
|-----------|-------|-----------------|
| Non-Bash tool call | `CLAUDE_TOOL_NAME=Write` | Exit 0, no output |
| Bash tool, non-commit command | `git status` | Exit 0, no output |
| Bash tool, `git commit` on feature branch | Current branch = `effort/foo` | Exit 0, no output |
| Bash tool, `git commit` on main | Current branch = `main` | Exit 2, JSON diagnostic on stderr |
| Bash tool, `git push origin main` on main | Current branch = `main` | Exit 2, JSON diagnostic on stderr |
| Admin override, `FORGE_ALLOW_MAIN_COMMIT=1` | Current branch = `main` | Exit 0, audit log written |
| Admin override, `FORGE_ADMIN_OP=forge:init` | Current branch = `main` | Exit 0, audit log with reason |
| Active effort present | `.forge/efforts/README.md` has active row | `activeEffort` in JSON matches effort ID |
| No active effort | No `.forge/efforts/README.md` | `activeEffort` is null, nextAction says `forge:effort` |
| Detached HEAD | `git branch --show-current` returns empty | Exit 0, no output |

The git hook requires tests covering:

| Test case | Input | Expected behavior |
|-----------|-------|-----------------|
| Push to feature branch | `refs/heads/effort/foo` | Exit 0 |
| Push to `refs/heads/main` | Remote ref = `refs/heads/main` | Exit 1, block message on stderr |
| Push to `refs/heads/master` | Remote ref = `refs/heads/master` | Exit 1, block message on stderr |
| Push of tag | `refs/tags/v1.0.0` | Exit 0 |
| Push to `refs/heads/main-2` | Remote ref = `refs/heads/main-2` | Exit 0 — not an exact match |
| Multiple refs, one is main | Mix of feature + main refs | Exit 1 — any match blocks |
| `git push --no-verify` | Hook not invoked | Not applicable (git skips hook) |
