# Runbook — forge-arch-review

Operational procedures for the `forge:arch-review` worker skill.

---

## Procedures

### forge:arch-review Fails — Requirements File Not Found

**Symptom:** The skill reports it cannot read `requirements/business.md` or
`requirements/technical.md`.

**Cause:** The effort directory does not have the expected requirements files.
`forge:arch-review` requires both requirements files to be present before analysis
can proceed.

**Resolution:**
1. Verify the effort directory path passed to the worker is correct
2. Check that the effort has completed requirements authoring:
   - `<effort-dir>/requirements/business.md` must exist
   - `<effort-dir>/requirements/technical.md` must exist
3. If requirements are incomplete, complete them before running `forge:arch-review`

---

### forge:arch-review Produces FAIL — Cannot Advance to Planning

**Symptom:** `forge:promote` blocks with "validation/report.md has result: FAIL."

**Cause:** One or more MUST-rule violations were found in the discovery artifacts.

**Resolution:**
1. Read `validation/report.md` and locate the rows marked `✗ FAIL`
2. Each FAIL finding includes the rule and a description of the violation
3. Update the affected spec artifact to address the violation
4. Re-run `forge:arch-review` to regenerate the report
5. If the overall result is now PASS or PASS WITH CONCERNS, `forge:promote` will permit
   advancement

Common FAIL causes:
- API error response bodies missing the `code` field (required by REST standard)
- Required BRs with no design coverage in any spec artifact
- Authentication not specified for write endpoints

---

### forge:arch-review Produces PASS WITH CONCERNS — Reviewing Concerns

**Symptom:** `forge:promote` permits advancement but surfaces concerns.

**Cause:** SHOULD violations or high-risk patterns were found. These do not block
advancement but should be reviewed before proceeding.

**Resolution:**
1. Read `validation/report.md` and locate the rows marked `⚠ CONCERN`
2. For each concern, assess whether it should be:
   - **Resolved before implementation:** Update the spec and re-run `forge:arch-review`
   - **Accepted as a known tradeoff:** Document the rationale in a new or updated ADR;
     the concern will remain in the report but is now traceable to a decision
   - **Deferred:** Add the concern to the Open Decisions & Risks section for tracking
3. `forge:promote` will permit advancement even with concerns; the decision to resolve
   or accept is an engineering judgment call

---

### validation/arch-review.html Does Not Open Correctly

**Symptom:** The HTML file shows broken layout, missing content, or browser errors
when opened locally.

**Cause options:**
- Browser security policy blocking `file://` URL access (some browsers restrict this)
- Generated HTML syntax error
- Character encoding issue in the HTML file

**Diagnosis:**
- Try opening the file in a different browser
- Inspect the browser console for errors
- Check that the `<meta charset="UTF-8">` tag is present in the HTML `<head>`
- Verify no `<script>` tags are present (the file should have none)

**Resolution:**
- If a browser security policy is the issue: open using a simple local server
  (`python3 -m http.server`) or use a different browser
- If a syntax error is suspected: re-run `forge:arch-review` to regenerate the file

---

### Standards File Not Found During Analysis

**Symptom:** `validation/report.md` contains a NOTE finding: "Standard file not
found — REST API checks skipped."

**Cause:** The rr-standards plugin cache does not contain the expected standards
file at the path the worker is using.

**Diagnosis:**
1. Verify the `standards_lib` path passed to the worker is correct
2. Check that the plugin cache contains the expected standards files:
   - `<standards_lib>/api/rest.md` for REST checks
   - `<standards_lib>/storage/` for storage checks
   - `<standards_lib>/messaging/` for messaging checks

**Resolution:**
- If the plugin cache is missing files: re-install or update the Forge plugin
- If the standards file does not exist in rr-standards: file a standards gap report
  — the standard must be authored before this check can run
- A NOTE finding for a missing standard does not affect the overall result; it is
  informational only

---

### forge:promote Blocks With "validation/report.md Not Found"

**Symptom:** `forge:promote` refuses to advance with "This effort requires an
architecture review. Run forge:arch-review before advancing to planning."

**Cause:** `validation/report.md` is absent for a full-tier effort.

**Resolution:**
1. Run `forge:arch-review` to generate the validation artifacts
2. Verify `validation/report.md` was written to `<effort-dir>/validation/report.md`
3. Re-run `forge:promote`

If the effort is lightweight-tier (patch, refactor, extension, poc) and is
incorrectly being blocked, verify that the effort's `.state.json` has the correct
`subtype` value. Lightweight-tier efforts do not require `validation/report.md`.
