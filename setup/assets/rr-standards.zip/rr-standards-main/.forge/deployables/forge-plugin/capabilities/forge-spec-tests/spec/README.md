# Spec — forge-spec-tests

| Artifact | Description |
|----------|-------------|
| [skills.md](skills.md) | Skill interface spec |

**ADR-028:** Test strategy is a capability canonical artifact.
**Output consumed by:** `forge:verify`, `forge:qa`
