# forge-arch-review
<!-- graduated-from: arch-review at 2026-05-04T20:02:05Z -->

Architecture review package generation for the Forge AI-accelerated development framework.
Delivers the `forge:arch-review` orchestrator skill, which conducts a pre-generation
interview, validates discovery artifacts, and produces a self-contained HTML document
for the architecture review meeting.

## What It Delivers

| Artifact | Type | Classification | Trigger |
|---------|------|----------------|---------|
| `forge:arch-review` | Skill | Orchestrator | Manual invocation or conversational |

**`forge:arch-review`** conducts a focused interview with the author (rollout, cost,
risks, afterword), runs `forge:validate` if the report is absent or stale, then generates
two outputs:

- **`validation/report.md`** — machine-readable validation record consumed by
  `forge:promote` to gate advancement from discovery to planning
- **`validation/arch-review.html`** — self-contained HTML document for the architecture
  review meeting; 9 sections with sticky nav, PR #246 design system, interactive
  cost sliders, C4 diagrams via Mermaid, and API contracts as an interactive accordion

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-init](../forge-init/) | Produces the `.forge/` structure that arch-review reads |
| forge-promote _(separate capability)_ | Reads `validation/report.md`; blocks discovery→planning if result is FAIL |
| forge-graduate _(separate capability)_ | Runs after the full workflow completes; depends on passing arch review |

## Implementation Location

`plugins/forge/skills/arch-review/` — `forge:arch-review` SKILL.md and README.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Why this capability exists |
| [requirements/technical.md](requirements/technical.md) | How it must behave |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview |
| [spec/skills.md](spec/skills.md) | `forge:arch-review` detailed design |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations and trust model |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
Primary program BRs addressed: BR-11 (design validation before implementation),
TR-11a (design validation report + HTML presentation).
