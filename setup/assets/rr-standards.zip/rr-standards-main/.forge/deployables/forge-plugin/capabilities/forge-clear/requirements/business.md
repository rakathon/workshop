# Business Requirements — forge-clear

Parent deployable: [forge-plugin](../../requirements/business.md)

---

## BR-1: Unset the Active Effort Without Disturbing State

Engineers sometimes need to work on tasks unrelated to the current active
effort — answering a quick question, reviewing another file, or running a
one-off command — without wanting to pause and checkpoint their work.

`forge:clear` must let the engineer dismiss the active effort context
instantly, without triggering the full `forge:pause` handoff (context summary,
state commit, branch check). The effort must remain fully intact for
reactivation later.
