# forge-plan Specification

## Overview

`forge:plan` is an orchestrator skill. It reads all discovery artifacts for a given
effort and produces an annotated, wave-ordered implementation plan in `plan/tasks.md`.
For coordination efforts, it also produces `plan/plan.md` — a deployable-scoped view
of the plan that can be materialized into local sub-efforts by `forge:project`.

The plan is the contract between design and implementation. It must be grounded in the
artifacts produced during discovery, cover all stated requirements, and annotate every
task with enough information for an executing agent to proceed without inferring intent
from description text.

## Key Design Decisions

### ADR-005: Task Annotations Use Markdown Prefix Convention

Tasks carry type and wave as inline bracket annotations. This format is human-readable
in plain text, diff-friendly, machine-parseable by skills, and co-locates metadata with
the task it describes. See
[ADR-005](../../../../efforts/forge-workflow/spec/arch-decisions/ADR-005-task-annotations-as-markdown-prefix-convention.md)
for the full rationale and alternatives considered.

### Orchestrator Classification

`forge:plan` is an orchestrator, not a worker. It runs in the main session context
because it must read effort state, present the plan for engineer review, and
update the master registry. It does not spawn a sub-agent — the planning operation
is interactive and relies on session continuity.

### Two-Output Design for Coordination Efforts

Coordination efforts produce two plan artifacts with distinct audiences:
- `plan/tasks.md` — implementation tasks for the coordination repo's own work
- `plan/plan.md` — deployable-scoped acceptance criteria for downstream sub-efforts

The two-output design reflects the fact that coordination efforts have two kinds of
work: cross-cutting coordination tasks (belonging to `plan/tasks.md`) and deliverable
responsibilities assigned to specific deployable repositories (belonging to
`plan/plan.md`).

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](../requirements/business.md) | Why this capability exists |
| [requirements/technical.md](../requirements/technical.md) | How it must behave |
| [requirements/success-criteria.md](../requirements/success-criteria.md) | Measurable success criteria |
| [spec/skills.md](skills.md) | `forge:plan` detailed design |
| [test/README.md](../test/README.md) | Test strategy |
| [security/README.md](../security/README.md) | Security considerations |
| [runbook/README.md](../runbook/README.md) | Operational procedures |
