# Technical Requirements

*Elaborated from: [requirements/business.md](business.md)*
*Elaborated: 2026-04-21*

---

## TR-1: Slack Channel Reference Storage in .state.json

*Traces to: BR-1*

The effort's `.state.json` must support an optional `slackChannels` field (array of objects) where each object has `id` (string, Slack channel ID) and `name` (string, Slack channel display name used as the directory slug). Absence of the field or an empty array must be treated equivalently — no Forge skill may fail when the field is missing or empty. The object structure replaces the previously designed string array.

---

## TR-2: Slack Integration via Slack MCP

*Traces to: BR-2, BR-6*

All Slack access (message history, channel info, user resolution) must use the Slack MCP server bundled with the Forge plugin. Skills must not call the Slack REST API directly. The MCP server handles OAuth token configuration; skills reference MCP tools only. Credentials must be configured in the user's MCP environment, never committed to the repository.

---

## TR-3: Configurable Periodic Message Import

*Traces to: BR-2*

The import must be triggerable as a manually-invoked operation or on a configurable schedule. The schedule cadence must be configurable (e.g. via `.forge/config` or effort metadata) rather than hardcoded. Each successful run must write a checkpoint (ISO 8601 timestamp) to a persistent location within the effort directory — including runs that find zero messages, so that already-confirmed-empty ranges are not re-scanned on the next run. Subsequent runs with no explicit `--from`/`--to` range automatically use the checkpoint as the start and `now - lag-buffer` as the end (see TR-17). A bounded range run (both `--from` and `--to` provided) must not overwrite the checkpoint.

---

## TR-16: Checkpoint Storage and Bootstrap

*Traces to: BR-2*

The import checkpoint must be stored at `efforts/<effort_id>/messages/slack/<channel-name>/.checkpoint` as a plain ISO 8601 timestamp — one checkpoint file per channel. If no checkpoint file exists and no `--from` argument is provided, the import must stop and prompt the user to supply a start date — it must not attempt to fetch unbounded history. If a checkpoint file exists but is malformed, the import must stop with a clear error rather than silently defaulting to a full re-fetch.

---

## TR-4: Message File Layout — YYYY-MM/YYYY-MM-DD.md

*Traces to: BR-2*

Imported messages must be written to `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD.md`. Each file contains all messages for that calendar day, sorted ascending by timestamp. If a file already exists for the day, the import must merge new messages in rather than overwriting — preserving previously imported content. The `<channel-name>` is the display name slug from the `slackChannels` mapping; the channel ID is used only for Slack API calls.

---

## TR-5: Message File Content Format

*Traces to: BR-2, BR-10*

Each top-level message entry in a daily file must include: author display name, timestamp (ISO 8601), and message text. Thread replies must be indented beneath their parent message (e.g. via Markdown blockquote or heading hierarchy), preserving reply order. The parent message's position in the file is determined by its own timestamp in the top-level channel flow — replies do not affect that position. Reactions and file attachments are out of scope unless a future BR covers them.

---

## TR-15: Cross-Day Thread Handling

*Traces to: BR-10*

When a thread reply is sent on a different calendar day than its parent message, the reply must be appended under the parent entry in the parent's daily file. The reply must also appear in the daily file for the day it was sent, as a cross-reference of the form: `↩ Reply in thread from <YYYY-MM-DD> — [<parent message excerpt>](../YYYY-MM/YYYY-MM-DD.md#<anchor>)`. This ensures each day's file is a complete record of activity on that day while thread context remains intact in the parent's file.

---

## TR-6: Confluence and Jira Link Enrichment

*Traces to: BR-5*

During import, any URL in a message body matching `https://rakutenrewards.atlassian.net/wiki/` (Confluence) or `https://rakutenrewards.atlassian.net/jira` / `https://rakutenrewards.atlassian.net/browse` (Jira) must be resolved via the Atlassian MCP. Enrichment appends a short summary (title + ≤2 sentence description) inline after the link. If a resource is inaccessible, the original link is preserved with a `[summary unavailable: <reason>]` note and the import continues.

---

## TR-7: Daily Summary as Separate Invokable Step

*Traces to: BR-3*

Daily summary generation must be a separate operation from message import, independently invokable. It reads the daily message file at `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD.md` and writes a summary to `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/YYYY-MM-DD-summary.md`. Re-running regenerates the summary from the current file contents.

The summary must use labeled sections to prominently surface the following high-priority topics when present in the day's messages: architectural decisions, planning decisions, raised risks, raised bugs, raised problems with specifications, time-off notices, and status updates. Additional notable discussion may appear under a general notes section. High-priority sections must appear before general notes regardless of the order topics appeared in the conversation.

---

## TR-8: Weekly Summary as Separate Invokable Step

*Traces to: BR-4*

Weekly summary generation must be a separate operation from both message import and daily summarization, independently invokable. It reads all daily files in the target ISO week and writes a summary to `efforts/<effort_id>/messages/slack/<channel-name>/YYYY-MM/week-<ISO-week-number>-summary.md`. Re-running regenerates from current file contents.

The summary must use the same labeled high-priority sections as daily summaries (architectural decisions, planning decisions, raised risks, raised bugs, raised problems with specifications, time-off notices, status updates), aggregated across all days in the week. Each item must be attributed to its source day. Additional notable themes appear under a general notes section after the high-priority sections.

---

## TR-9: Import Idempotency

*Traces to: BR-2, BR-3, BR-4*

All import and summary operations must be idempotent. Running the import twice for the same time range must produce the same file contents as running it once. This applies to daily message files, daily summaries, and weekly summaries.

---

## TR-10: Import Run Logging

*Traces to: BR-8*

Each import run must emit a structured log entry recording: effort ID, channel ID, date range fetched, message count imported, enrichment results (successes and failures), and any errors encountered. On failure, the log must identify which step failed and preserve any already-written files in their last-good state.

---

## TR-11: Message Data Access Control

*Traces to: BR-7*

Imported message files must reside only within the effort's own directory (`efforts/<effort_id>/messages/`). No cross-effort reads of message files are permitted by any Forge skill. Access is controlled by repository-level permissions — no additional per-effort ACL mechanism is required.

---

## TR-12: No Third-Party Transmission of Message Content

*Traces to: BR-7*

Message content must not be transmitted to any external service other than (a) the Slack MCP to fetch messages, and (b) the Atlassian APIs to resolve linked resources per BR-5. Summary generation using Claude must occur within the user's own Claude session — not via a shared or external endpoint.

---

## TR-14: Import Date/Time Range Parameters

*Traces to: BR-9*

The import skill must accept optional `--from` and `--to` parameters accepting ISO 8601 date/time values (e.g. `2026-04-01` or `2026-04-01T09:00:00Z`). When `--from` is provided without `--to`, the range end is `now - lag-buffer`. When neither is provided, the import uses the stored watermark as start and `now - lag-buffer` as end. When `--to` is provided explicitly, the lag buffer is not applied to that value. A fully bounded run (both `--from` and `--to` provided) must not update the watermark; watermark-based and start-only runs always advance the checkpoint to the resolved `end`.

---

## TR-17: Import End Timestamp Lag Buffer

*Traces to: BR-2, BR-9*

When computing the default `end` bound (i.e. when `--to` is not provided), the import must subtract a configurable lag buffer from the current timestamp. The default buffer is 5 minutes. The buffer is exposed as `--lag-buffer <minutes>` and can be set to `0` to disable it. The purpose of the buffer is to avoid permanently missing messages that were in-flight or not yet indexed by the Slack API at query time — the next run's window overlaps the tail of the previous run by the buffer duration, and the idempotency/dedup logic handles any re-fetched messages. The checkpoint is written at `now - lag-buffer`, not at `now`.

---

## TR-18: Late-Reply Thread Lookback

*Traces to: BR-10*

The import must fetch replies that were sent within the import window but belong to thread parents that were posted before the window start. The lookback window (how far before `start` to scan for pre-window parents) is configurable via `--thread-lookback <days>` (default: 30 days). Pass `0` to disable. For each pre-window parent whose `latest_reply` timestamp falls within `[start, end]`, only replies within that window are collected. These late replies are written using the cross-day dual-write rule (TR-15): the reply appears in full under the parent in the parent's daily file, and as a cross-reference in the reply's own daily file. If the parent's daily file does not yet exist (parent predates the entire import history), it is created with the parent message as context before the reply is appended.

---

## TR-13: Slack MCP Bundled in Forge Plugin

*Traces to: BR-2, BR-6*

The Forge plugin's `.mcp.json` must declare the Slack MCP server as a bundled dependency, following the same pattern as the existing Atlassian MCP declaration. Skills that require Slack access must verify the MCP is available at invocation time and stop with a clear configuration error if it is not (mirroring the Atlassian MCP precondition pattern used in `forge:elaborate`).
