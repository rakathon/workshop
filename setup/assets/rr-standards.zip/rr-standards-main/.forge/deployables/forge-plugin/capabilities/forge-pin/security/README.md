# Security — forge-pin

## Trust Boundary

`forge:pin` runs within the engineer's interactive Claude Code session. It writes
two committed files (`.claude-plugin/marketplace.json`, `.claude/settings.json`) and
optionally updates `.forge/version`. It makes outbound GitHub API calls via the `gh`
CLI to resolve version tags.

## Primary Security Surfaces

- **`.claude-plugin/marketplace.json`** — committed to the repository; defines which
  plugin version Claude Code loads for all contributors. A tampered file could cause
  the wrong plugin version to load silently. The SHA field mitigates this: if a tag is
  moved, the SHA mismatch produces an explicit error rather than a silent version change.
- **GitHub API calls** — `forge:pin` calls `gh api` to resolve release tags and commit
  SHAs. Credentials are managed by the `gh` CLI and must not be logged or stored. The
  call is read-only and scoped to the public rr-standards repository.
- **`enabledPlugins` in `.claude/settings.json`** — `forge:pin` removes all `forge@*`
  entries and adds `forge@forge-local`. A malicious modification here could activate a
  different plugin source.

## Cryptographic Pin Integrity

`forge:pin` stores both a human-readable tag (`ref`) and a commit SHA (`sha`) in
`.claude-plugin/marketplace.json`. Claude Code uses the SHA to load the exact plugin
version from the cache. If the tag is ever moved or repointed, the SHA mismatch
surfaces as an explicit error — no silent loading of a different version.

The SHA is resolved at pin time via:
```bash
gh api repos/rewards-guilds/rr-standards/git/ref/tags/v<version> \
  --template '{{.object.sha}}'
```

## Review Requirements

All PRs that modify `forge:pin`'s `SKILL.md` trigger the `security-reviewer` agent
in `rr-standards:review`.
