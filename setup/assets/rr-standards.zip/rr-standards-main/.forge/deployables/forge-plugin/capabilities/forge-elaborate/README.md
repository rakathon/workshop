# forge-elaborate

Builds deep, shared understanding of the problem being solved through a conversational
interview. Reads all existing discovery artifacts, then interviews the engineer with
relentless, dependency-ordered questions until no productive questions remain. Each
question comes with a recommended answer. Each agreed answer is written immediately
to the appropriate artifact: BRs to `requirements/business.md`, TRs to
`requirements/technical.md`, architectural decisions via `forge:adr`. Concludes by
writing `requirements/user-stories.md` in Connextra format.

**Skill:** `forge:elaborate`
**Classification:** Orchestrator
**Works with or without an active effort**
**Supersedes:** `forge:extract` (deprecated)

Part of the spec-driven-development initiative (Initiative 3).
