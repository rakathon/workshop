# Business Requirements — forge:statusline Skill
<!-- graduated-from: forge-statusline at 2026-04-26T01:20:08Z -->

## Problem Statement

Engineers using Forge lose awareness of their current effort context during long sessions.
The Claude Code statusline is a persistent, low-overhead surface for at-a-glance information,
but there is no Forge-aware implementation. The existing `/statusline` command generates
generic scripts; Forge users need one that surfaces effort phase, git branch, and session
health without manual setup.

## Goals

- Give every Forge engineer a consistent, effort-aware statusline they can install in one command.
- Surface the most useful signals (effort, phase, context health) without requiring configuration.
- Never override a user's existing custom statusline without explicit consent.

## Business Requirements

### BR-1: Opt-in installation via dedicated skill

The statusline must be installed by a dedicated `forge:statusline` skill invoked
explicitly by each engineer. It must not be installed automatically by `forge:init`
or any hook. Installation is per-machine (user-scoped settings), not per-repository.

**Rationale:** Statusline config lives in `~/.claude/settings.json`. Modifying it from
`forge:init` (which writes repo-scoped artifacts) is the wrong layer, and silently
overwriting a user's existing config would be disruptive.

### BR-2: Safe install — never silently overwrite user customization

If `~/.claude/settings.json` already contains a `statusLine.command` entry that does
not point to the Forge-managed script, the skill must stop and inform the engineer.
It must require an explicit `--replace` flag to proceed.

### BR-3: Forge-aware display segments

The installed script must display:

1. **Session identity** — model name, working directory basename, session cost, elapsed time.
2. **Git + Forge context** — branch name; when a matching Forge effort is active, its ID,
   truncated title, and current phase.
3. **Context health** — color-coded progress bar (green < 70%, yellow 70–89%, red ≥ 90%)
   and percentage. Rendered on a second line.

### BR-4: Worktree awareness

When running inside a `--worktree` session (`worktree.*` fields present in JSON input),
the statusline must display the worktree name and branch instead of the main session's
branch.

### BR-5: Staleness detection on forge:update

When `forge:update` runs, it must check whether the installed `~/.claude/forge-statusline.py`
matches the version shipping in the current plugin. If stale, it must notify the engineer
and prompt them to re-run `forge:statusline` to update. It must not update the file itself.

### BR-6: Subagent panel customization

The `forge:statusline` skill must write a `subagentStatusLine` entry into
`~/.claude/settings.json` alongside `statusLine`, so the agent panel shows
Forge-relevant row formatting (agent type, status, token count). Both entries are
installed and removed together. The plugin must not ship a `settings.json` — doing
so would activate the subagent panel for all plugin users regardless of whether they
ran `forge:statusline`.

## Out of Scope

- Automatic installation during `forge:init`.
- Windows PowerShell support (Bash/Python 3 only; Windows users can use WSL).
- Rate-limit display (Pro/Max subscriber only; not relevant to the internal team context).
- Clickable OSC 8 links (terminal-dependent; not worth the complexity for v1).
