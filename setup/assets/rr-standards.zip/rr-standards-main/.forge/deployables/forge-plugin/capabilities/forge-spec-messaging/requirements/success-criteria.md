# Success Criteria — forge-spec-messaging

- [ ] When `--event` is not provided, event scope is confirmed before any individual contract is designed
- [ ] Each event contract contains all five decisions: schema, producer, consumers, ordering, idempotency
- [ ] Unknown consumers are explicitly flagged as "unknown — must be resolved before implementation" rather than omitted
- [ ] Inline checks fire for every event immediately after confirmation, before the next event begins
- [ ] Non-standard choices are recorded as inline comments with rationale and trigger a forge:adr prompt
- [ ] Contracts are written to `spec/messaging/<event-name>.md` using lowercase-with-hyphens filenames
- [ ] `.state.json` is updated to `"present"` after the first contract is written
- [ ] If `standards/messaging/contracts.md` is absent, the skill warns and continues rather than stopping
