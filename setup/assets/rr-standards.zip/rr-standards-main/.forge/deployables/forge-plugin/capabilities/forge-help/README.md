# forge-help

Dynamic documentation and Q&A for the Forge AI-accelerated development framework.
Delivers the `forge:help` skill that answers questions about Forge by reading the
plugin's own documentation — skills, hooks, standards, and language guides — at
runtime.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:help` | Skill | Interactive | `forge:help` (catalog) or `forge:help <question>` (Q&A) |

**`forge:help`** operates in two modes:

- **Catalog mode** (`forge:help` with no argument): Produces a complete, structured
  catalog of all implemented skills grouped by workflow phase, all active hooks with
  one-liner descriptions, and the available standards and language guides. The catalog
  is derived dynamically from the plugin's own AGENTS.md files — it cannot go stale.

- **Q&A mode** (`forge:help <question>`): Parses the question, identifies which
  component areas it spans, navigates AGENTS.md files to locate relevant artifacts,
  reads them, and synthesizes a single complete plain-English answer. Questions that
  span hooks and standards produce one unified answer — the engineer never needs to
  assemble the picture themselves.

## Why This Capability Exists

The Forge plugin ships with dozens of skills, hooks, standards, and language guides
across a layered directory structure. An engineer cannot be expected to navigate that
structure themselves to answer a basic question like "what does `inject-generation-standards`
do?" or "what phases does the Forge workflow have?". Without a live documentation layer,
engineers either read plugin internals (violating the abstraction boundary) or ask
questions that Claude answers from training data (which may be wrong or stale). This
capability makes the plugin self-documenting.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| All capabilities | `forge:help` reads every capability's SKILL.md and AGENTS.md to answer questions and populate the catalog |
| [forge-effort](../forge-effort/) | Provides `.state.json` context that `forge:status` handles; `forge:help` directs effort-state questions to `forge:status` |

## Implementation Location

`plugins/forge/skills/help/` — `forge:help` SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| `requirements/business.md` | Business drivers for a live Forge documentation layer |
| `requirements/technical.md` | Technical requirements for catalog mode, Q&A mode, stub filtering, and scope boundaries |
| `requirements/success-criteria.md` | Measurable acceptance criteria |
| `spec/README.md` | Skill design overview |
| `spec/skills.md` | Detailed skill specification |
