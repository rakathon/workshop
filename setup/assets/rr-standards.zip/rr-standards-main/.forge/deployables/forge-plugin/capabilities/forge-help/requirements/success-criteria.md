# Success Criteria — forge-help

These criteria are the measurable acceptance bar for the forge-help capability.
Each criterion specifies the observable behavior, the mechanism that delivers it,
and how to verify it.

---

## SC-1: Catalog Mode Produces a Current, Structured Overview With No Stubs

**Criterion:** When invoked with no argument, `forge:help` produces a catalog of
implemented skills grouped by workflow phase, active hooks with one-liner descriptions,
and available standards and language guides — all derived dynamically from AGENTS.md
files. Stub skills are excluded.

**Verification:**
1. Invoke `forge:help` with no argument.
2. Confirm all implemented skills appear grouped by phase.
3. Confirm at least one hook appears with a plain-English description.
4. Confirm standards categories and language guides appear.
5. Confirm no skill directory that contains only `.gitkeep` appears in the catalog.

**Pass condition:** Catalog output is present, grouped, and contains no stubs.

---

## SC-2: Q&A Mode Answers a Skill Question From SKILL.md Content

**Criterion:** When asked about a specific skill, `forge:help` reads that skill's
SKILL.md and answers from its content. No internal file paths appear in the output.

**Verification:**
1. Invoke `forge:help` with a question about `forge:commit` (e.g., "what does
   forge:commit do?").
2. Confirm the answer describes the six-step ceremony accurately.
3. Confirm no file paths like `plugins/forge/skills/commit/SKILL.md` appear.

**Pass condition:** Answer is accurate, complete, and path-free.

---

## SC-3: Q&A Mode Synthesizes an Answer That Spans Hooks and Standards

**Criterion:** When asked a question that spans both a hook and a standard (e.g.,
"how does Forge enforce standards during code generation?"), `forge:help` produces
one unified answer covering both areas.

**Verification:**
1. Ask `forge:help` "how does Forge enforce standards during code generation?"
2. Confirm the answer references the relevant hook behavior.
3. Confirm the answer references the relevant standard's content.
4. Confirm a single response is produced — not two separate answers.

**Pass condition:** Single response; covers both hook and standard; no follow-up
needed to complete the picture.

---

## SC-4: Stub Skills Are Excluded From Catalog and Q&A

**Criterion:** Skills that have no SKILL.md do not appear in catalog output.
When asked about a stub skill by name, the skill acknowledges it is not implemented.

**Verification:**
1. Identify a stub skill directory (contains only `.gitkeep`).
2. Invoke `forge:help` with no argument; confirm the stub name is absent.
3. Ask `forge:help` about the stub skill by name.
4. Confirm the response says "forge:`<name>` is not yet implemented."

**Pass condition:** Stub absent from catalog; explicit stub query returns "not yet
implemented" message.

---

## SC-5: Effort-State Questions Are Deflected to forge:status

**Criterion:** When asked an effort-state question ("am I ready to run forge:plan?"),
`forge:help` answers the conceptual/precondition part and directs the engineer to
`forge:status` for their specific state. It does not read any `.state.json` or effort
directory.

**Verification:**
1. Ask `forge:help` "am I ready to run forge:plan?"
2. Confirm the answer explains forge:plan's preconditions.
3. Confirm the answer recommends running `forge:status`.
4. Confirm no effort-specific data (e.g., phase, effort ID) appears in the answer.

**Pass condition:** Preconditions explained. `forge:status` recommended. No
effort-specific data leaked.

---

## SC-6: Hook Answers Are Derived From Script Behavior, Not Script Source

**Criterion:** When asked about a hook, `forge:help` reads the hook script and
describes its behavior in plain English without showing the script source or path.

**Verification:**
1. Ask `forge:help` about a specific hook (e.g., "what does inject-generation-standards
   do?").
2. Confirm the answer describes the hook's behavior accurately.
3. Confirm no shell script code appears verbatim in the answer.
4. Confirm no file path to the hook script appears in the answer.

**Pass condition:** Behavior accurately described; no raw script content or paths.
