# Technical Requirements — forge-adr

Parent deployable: [forge-plugin](../../requirements/technical.md)

---

## TR-1: ADR Numbering Algorithm

### TR-1.1: Sequential Numbering Within a Scope

ADR numbers are scoped to the `spec/arch-decisions/` directory they are written to.
Each scope (effort, deployable, or repository) maintains its own independent series
starting at ADR-001. Numbers are not global to the repository.

To determine the next ADR number, `forge:adr` must:

1. Read all files in the target `spec/arch-decisions/` directory
2. Extract the numeric component from each filename matching the pattern
   `ADR-NNN-*.md` (three-digit zero-padded number)
3. Identify the lowest positive integer not already present in the series (gap-filling)
4. Use that integer as the next ADR number, zero-padded to three digits

**Gap-filling rule:** If the series contains ADR-001 and ADR-003 but not ADR-002, the
next ADR is ADR-002. If the series is contiguous (ADR-001, ADR-002, ADR-003), the next
ADR is ADR-004. Gap-filling ensures that accidental deletions or renames of ADR files
do not silently corrupt the numbering sequence.

### TR-1.2: Handling an Empty Directory

If `spec/arch-decisions/` exists but contains no ADR files (only the index README.md),
the next ADR number is 001.

If `spec/arch-decisions/` does not exist, `forge:adr` must create it before writing
the first ADR.

### TR-1.3: Filename Format

ADR files must follow the naming convention:

```
ADR-NNN-<kebab-case-slug>.md
```

Where:
- `NNN` is the three-digit zero-padded ADR number (e.g., 001, 012, 100)
- `<kebab-case-slug>` is derived from the decision title: lowercase, words separated
  by hyphens, punctuation removed, no leading or trailing hyphens
- Maximum slug length: 60 characters (truncate if necessary, at a word boundary)

Examples:
- `ADR-001-three-tier-claude-md-context-design.md`
- `ADR-007-quality-loop-at-task-execution-not-verification.md`
- `ADR-012-use-postgresql-for-session-storage.md`

---

## TR-2: ADR File Location

`forge:adr` writes to one of three locations depending on the resolved scope:

| Scope | Path |
|-------|------|
| Effort | `.forge/efforts/<effort-id>/spec/arch-decisions/ADR-NNN-<slug>.md` |
| Deployable | `.forge/deployables/<deployable-id>/spec/arch-decisions/ADR-NNN-<slug>.md` |
| Repository | `.forge/spec/arch-decisions/ADR-NNN-<slug>.md` |

The effort scope is the default when an active effort can be identified. The deployable
scope is used when an engineer records a decision directly against a deployable — for
example, adding an ADR retroactively after an effort has been graduated. The repository
scope is used for cross-cutting decisions not specific to any one deployable.

---

## TR-3: ADR Template

Every ADR produced by `forge:adr` must use the following template exactly:

```markdown
# ADR-NNN: <Title>

**Status:** <status>
**Effort ID:** <effort-id>      ← effort scope only
**Deployable:** <deployable-id> ← deployable scope only; omit both lines for repository scope
**Date:** <ISO-8601-date>

## Context

<Why this decision was needed. What problem was being solved, what constraints
existed, what was learned during the conversation that made this decision
necessary. Written in past or present tense from the perspective of the moment
the decision was made.>

## Decision

<The decision itself, stated clearly and directly. "We will use X." "The system
will Y." Not hedged, not tentative — this is the committed choice.>

## Alternatives Considered

<Each alternative that was meaningfully considered before this decision was made.
For each alternative: what it was, why it was not chosen. If no alternatives were
considered, write "No alternatives were explicitly considered.">

## Consequences

<What this decision means going forward. What is now easier, what is now harder,
what constraints it imposes, what follow-on decisions it enables or forecloses.>
```

### TR-3.1: Status Field Values

The `Status` field must be one of the following values exactly:

| Value | When to use |
|-------|-------------|
| `Accepted` | The decision is current and in force |
| `Proposed` | The decision is under consideration but not yet committed |
| `Deprecated` | The decision was once accepted but no longer applies |
| `Superseded` | The decision was replaced by a later ADR (reference the superseding ADR) |

All ADRs created by `forge:adr` start with status `Accepted`. The `Proposed` status
is available for decisions that the engineer explicitly marks as tentative.

### TR-3.2: Template Population from Conversation Context

When `forge:adr` is triggered conversationally (without explicit title or decision
text arguments), it must populate the ADR sections from the surrounding conversation:

- **Context:** Derive from the problem discussion that preceded the decision statement
- **Decision:** Derive from the explicit decision statement in the conversation
- **Alternatives Considered:** Include any alternatives discussed before the decision;
  if none were explicitly discussed, write "No alternatives were explicitly considered."
- **Consequences:** Derive from any follow-on discussion; if not discussed, infer from
  the nature of the decision

The populated sections must be accurate to the conversation. `forge:adr` must not
fabricate reasoning that was not present in the discussion.

---

## TR-4: State Update

After writing the ADR file, `forge:adr` must update the effort's `.state.json` when
the scope is `effort`. This step is skipped for deployable-scoped and repository-scoped
ADRs, which have no associated `.state.json`.

The `adrsCreated` array at `phases.discovery.artifacts.adrsCreated` must be appended
to (not overwritten). Entries are the ADR filename without the `.md` extension.
ADRs are not phase-specific — always write to the discovery phase array regardless of
the effort's current phase.

```json
{
  "phases": {
    "discovery": {
      "artifacts": {
        "adrsCreated": [
          "ADR-001-<slug>",
          "ADR-002-<slug>"
        ]
      }
    }
  }
}
```

---

## TR-5: ADR Index Update

After writing the ADR file, `forge:adr` must update the index file at
`spec/arch-decisions/README.md` within the active effort directory. The index must
be a table with one row per ADR:

```markdown
# Architecture Decisions — <effort-id>

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-001](ADR-001-<slug>.md) | <Title> | Accepted | <Date> |
| [ADR-002](ADR-002-<slug>.md) | <Title> | Accepted | <Date> |
```

If the index file does not exist, `forge:adr` must create it. If it exists, the new
ADR row is appended to the table in numeric order.

---

## TR-6: Suggested Commit Format

`forge:adr` must not run `git commit` automatically. After writing all files, it must
print the files it wrote and a suggested commit command for the engineer to run when
ready.

The suggested commit message format is:

```
docs(<scope-label>): ADR-NNN <decision-subject>
```

Where:
- `<scope-label>` is the effort ID, deployable ID, or `repo` for repository-wide ADRs
- `<decision-subject>` is a concise (≤ 60 characters) restatement of the decision title

Examples:
```
docs(forge-workflow): ADR-009 use PostgreSQL for session storage
docs(payments-service): ADR-003 event sourcing for transaction log
docs(repo): ADR-001 monorepo structure for rr-standards
```

---

## TR-7: Write Target Resolution

`forge:adr` must determine the write target (scope and directory) before writing any
file. The target is resolved using the following priority order:

1. **`--effort <id>` argument:** Write to `.forge/efforts/<id>/spec/arch-decisions/`.
   Read the effort's `.state.json`; stop if it does not exist.
2. **`--deployable <id>` argument:** Write to `.forge/deployables/<id>/spec/arch-decisions/`.
   Stop if the deployable directory does not exist.
3. **Active effort from context:** Check branch name, then single open `.state.json`,
   then conversation context. If a single active effort is identified, use the effort scope.
4. **Ask the engineer:** If the scope cannot be determined (no active effort, no explicit
   flags, or multiple open efforts), present the available options — open efforts,
   deployables, and repository level — and ask the engineer to choose.

An active effort is not required. The skill must not stop solely because no effort is
active; it must offer the deployable and repository scopes as alternatives.

---

## TR-8: Conversational Trigger Patterns

The CLAUDE.md tier-1 content and the UserPromptSubmit hook must recognize the
following patterns as decision events that trigger `forge:adr` automatically:

| Pattern type | Examples |
|-------------|---------|
| Direct decision statement | "we'll use X", "we're going with X", "let's use X" |
| Rationale-bearing decision | "we'll use X because Y", "let's go with X — it gives us Y" |
| Explicit decision announcement | "we've decided to X", "the decision is X", "I've decided to X" |
| Commitment after discussion | "okay, let's go with option B", "I think X is the right call" |

These patterns are intent signals to Claude, not NLP rules. The agent uses judgment
to distinguish casual mentions of technology from genuine architectural commitments.
A statement like "I'm reading about DynamoDB" is not a decision. A statement like
"let's use DynamoDB for the session table" is.

---

## TR-9: Semantic Duplicate Detection

Before writing a new ADR, `forge:adr` must scan existing ADRs in scope for semantic
overlap with the proposed title and decision. This check runs after the title is
determined (TR-3) and before the filename is derived.

### TR-9.1: Scan Scope

Read the title line (`# ADR-NNN: <Title>`) from every existing ADR file matching
`ADR-NNN-*.md` in `<adr_dir>`. Assess whether any existing title covers the same
subject as the proposed title, even if worded differently.

Semantic overlap means the same architectural choice — not just shared keywords.
"Use Redis for session caching" and "Use Redis as the session store" are the same
decision. "Use Redis for rate limiting" and "Use Redis for session caching" are not.

### TR-9.2: Cross-Scope Check for Effort-Scoped ADRs

When the write target is an effort, `forge:adr` must also check the associated
deployable's `spec/arch-decisions/` directory. The associated deployable is resolved
in this order:

1. Read `deployableId` from `<effort_dir>/.state.json` if the field exists
2. Otherwise, check whether `.forge/deployables/<effort_id>/` exists (same name as effort)
3. If neither resolves a deployable, skip the cross-scope check

When a deployable is found, apply TR-9.1 to `.forge/deployables/<deployable_id>/spec/arch-decisions/`
in addition to `<adr_dir>`. Tag each candidate with its source scope when presenting
to the engineer.

### TR-9.3: Classification — Duplicate vs Conflict

For each candidate identified by TR-9.1, `forge:adr` must classify the overlap as
one of two types:

- **Duplicate** — same concern, same choice. Both the existing and proposed ADR make
  the same architectural decision, just worded differently. The new ADR is redundant.
  Example: existing "Use Redis for session caching" vs proposed "Use Redis as the session store".

- **Conflict** — same concern, different choice. The existing and proposed ADR address
  the same architectural problem but reach opposite conclusions. The new ADR would
  contradict the existing one.
  Example: existing "Use Memcached for caching" vs proposed "Use Redis for caching".

To classify accurately, `forge:adr` must read the `## Decision` section from any
candidate where the title alone is ambiguous. The Decision section — "We will use X" —
makes the choice explicit and removes ambiguity.

### TR-9.4: Conflict Handling — Supersession

When a conflict is detected, `forge:adr` must present the conflicting ADR and ask
the engineer whether the new decision supersedes it:

```
This decision conflicts with an existing ADR:
  - ADR-002: Use Memcached for Caching  [effort: user-auth-service]
    Decision: We will use Memcached for session caching.

Does the new ADR supersede ADR-002?

  1. Yes — write new ADR and mark ADR-002 as Superseded by ADR-NNN
  2. No — these address different aspects, proceed without changing ADR-002
  3. Cancel — do not write the new ADR
```

If the engineer selects option 1, `forge:adr` must:
- Write the new ADR as normal
- Update the superseded ADR's `**Status:**` line from `Accepted` to `Superseded by ADR-<adr_num>`
- Update the superseded ADR's row in its index from `Accepted` to `Superseded`
- Include the modified files in the suggested commit

If the engineer selects option 2, proceed normally without modifying the existing ADR.
If the engineer selects option 3, stop without writing any files.

### TR-9.5: Duplicate Handling — Confirmation

When only duplicates are found (no conflicts), `forge:adr` must present them and ask
the engineer to confirm the new decision is genuinely distinct:

```
The following existing ADR(s) may cover the same decision:
  - ADR-003: Use Redis for Session Cache  [effort: user-auth-service]

Is "<proposed title>" a distinct architectural decision?

  1. Yes, it's distinct — proceed with new ADR
  2. No, it's a duplicate — cancel
```

`forge:adr` must not write the new ADR until the engineer selects option 1. If the
engineer selects option 2, stop without writing any files.

If no overlap of any kind is found, proceed without prompting — the check must be
silent when there is nothing to flag.

---

## Constraints

- `forge:adr` must not overwrite an existing ADR file. If a file at the computed path
  already exists (e.g., due to a manual creation), `forge:adr` must prompt the engineer
  before proceeding
- ADR filenames are permanent once committed. `forge:adr` must not rename existing
  ADR files
- The ADR template sections — Context, Decision, Alternatives Considered, Consequences
  — are all required. An ADR with an empty section must not be committed; `forge:adr`
  must populate every section before writing
- `forge:adr` writes only to the resolved `spec/arch-decisions/` directory and,
  for effort-scoped ADRs, the effort's `.state.json`. It does not modify any other files.
