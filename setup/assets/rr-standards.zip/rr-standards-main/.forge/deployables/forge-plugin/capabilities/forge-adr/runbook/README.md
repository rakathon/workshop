# Runbook — forge-adr

Operational procedures for the forge-adr capability.

---

## Procedures

### forge:adr Creates ADR in the Wrong Effort

**Symptom:** An ADR was created in an effort that was not the intended target.

**Cause:** Multiple efforts are open simultaneously and `forge:adr` resolved to the
wrong one. Most common when working across multiple efforts in the same session.

**Resolution:**
1. Delete the incorrectly placed ADR file
2. Revert the `.state.json` update for the wrong effort (remove the entry from
   `adrsCreated`)
3. Re-run `forge:adr` with an explicit effort ID argument, or ensure the correct
   effort is the only open one

**Prevention:** When multiple efforts are open, always provide the effort ID
explicitly: `forge:adr --effort <effort-id> "Title of the decision"`

---

### forge:adr Assigns the Wrong ADR Number

**Symptom:** A newly created ADR has a number that conflicts with an existing ADR,
or skips a number that should have been filled.

**Cause:** The `spec/arch-decisions/` directory contains ADR files that do not match
the `ADR-NNN-*.md` naming pattern (e.g., manual files with inconsistent names), or
a file was created between the scan step and the write step.

**Resolution:**
1. Rename the conflicting or incorrectly numbered ADR to the correct filename
2. Update the ADR index (`spec/arch-decisions/README.md`) to reflect the corrected
   filename
3. Update the `.state.json` `adrsCreated` entry to match the corrected filename
4. Commit the corrected files with a message explaining the correction

**Prevention:** Ensure all ADR files in `spec/arch-decisions/` follow the
`ADR-NNN-*.md` naming convention. Do not create manual ADR files outside of
`forge:adr` unless you maintain the naming convention exactly.

---

### forge:adr Produces an Incomplete ADR

**Symptom:** An ADR was written but one or more sections are empty, minimal, or
contain only a placeholder.

**Cause:** The conversation did not contain enough material to populate all sections
from context, and the skill did not prompt the engineer to provide the missing content.

**Resolution:**
1. Open the ADR file directly and fill in the missing sections
2. Commit the update with a message like:
   `docs(<effort-id>): complete ADR-NNN <subject>`

**Prevention:** When invoking `forge:adr` conversationally, ensure the decision
discussion covers not just the decision itself but also why alternatives were not
chosen and what the decision means going forward. The more context in the conversation,
the richer the ADR.

---

### `.state.json` `adrsCreated` Out of Sync with ADR Files

**Symptom:** The `adrsCreated` array in `.state.json` does not match the ADR files
present in `spec/arch-decisions/`. Either files exist that are not in the array, or
the array contains entries for files that do not exist.

**Cause:** Manual ADR creation (file added without updating state), manual deletion,
or a `forge:adr` run that partially failed after writing the file but before updating
state.

**Resolution:**
1. List all ADR files: `ls .forge/efforts/<id>/spec/arch-decisions/ADR-*.md`
2. Compare against the `adrsCreated` array in `.state.json`
3. Edit `.state.json` to make the array match the actual files (add missing entries,
   remove stale entries)
4. Commit the state correction with a message like:
   `chore(<effort-id>): reconcile adrsCreated with ADR files`

---

### forge:adr Does Not Trigger on a Decision Statement

**Symptom:** The engineer made a clear decision statement ("we'll use X because Y")
but no ADR was created.

**Cause:** The statement did not match the intent recognition patterns, or the
UserPromptSubmit hook did not fire, or the hook fired but did not detect the pattern
as a workflow event.

**Resolution:**
Invoke `forge:adr` explicitly to capture the decision retroactively:
```
forge:adr "Title of the decision"
```
Or in conversation: "Let's record an ADR for the decision to use X."

If conversational triggering is consistently failing, check that the forge-managed
section of CLAUDE.md contains the current intent recognition list (re-run `forge:init`
in merge mode if the section is stale).
