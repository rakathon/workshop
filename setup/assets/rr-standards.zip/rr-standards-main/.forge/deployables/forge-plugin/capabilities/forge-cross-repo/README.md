# forge-cross-repo

Cross-repository effort management for the Forge AI-accelerated development framework.
Delivers the `forge:project`, `forge:sync`, and `forge:upstream` skills for creating
and maintaining efforts that span multiple repositories.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:project` | Skill | Interactive | Manual invocation |
| `forge:sync` | Skill | Interactive | Manual invocation |
| `forge:upstream` | Skill | Interactive | Manual invocation |

**`forge:project`** creates a cross-repo effort with a root manifest at
`.forge/efforts/<name>/project.json` that lists all participating repositories,
their roles, and dependency ordering. Creates per-repo effort stubs in each
participating repository.

**`forge:sync`** reconciles the state of a cross-repo effort across all
participating repositories, surfacing divergences between the root manifest and
per-repo `.state.json` files.

**`forge:upstream`** propagates a change (ADR, plan amendment, phase transition)
from one repository's effort to all downstream participants, maintaining
consistency without manual per-repo updates.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-effort](../forge-effort/) | Each participating repo uses `forge:effort` to create its local effort stub. |
| [forge-promote](../forge-promote/) | Cross-repo promotion requires all repo efforts to pass their local gates first. |
| [forge-graduate](../forge-graduate/) | Graduation aggregates artifacts across all participating repos. |

## Implementation Location

`plugins/forge/skills/project/` — `forge:project` SKILL.md and README.md
`plugins/forge/skills/sync/` — `forge:sync` SKILL.md and README.md
`plugins/forge/skills/upstream/` — `forge:upstream` SKILL.md and README.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview and key design decisions |
| [spec/skills.md](spec/skills.md) | `forge:project`, `forge:sync`, `forge:upstream` detailed design |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | Relevant ADRs |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
