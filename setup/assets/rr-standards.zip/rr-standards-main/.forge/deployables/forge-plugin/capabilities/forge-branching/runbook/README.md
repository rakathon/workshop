# Runbook — forge-branching

Operational procedures for the forge-branching deliverables: the PreToolUse hook and
git pre-push hook.

---

## Procedures

### Agent Blocked from Committing — Legitimate Work

**Symptom:** Claude Code is blocked from `git commit` with a JSON diagnostic:
`"type": "branch_policy_violation"`.

**Cause:** The agent is on the default branch. All development work must happen on a
feature branch.

**Resolution:**
1. Check the `activeEffort` field in the diagnostic. If non-null, switch to the effort
   branch: `git checkout effort/<effort-id>`
2. If `activeEffort` is null, start a new effort with `forge:effort` before committing
3. Re-attempt the commit on the effort branch

---

### Admin Needs to Commit Directly to Main

**Symptom:** An administrator needs to commit to the default branch for a legitimate
maintenance operation (e.g., manual hotfix).

**Resolution:**
1. Set the override for the current shell session only:
   ```bash
   export FORGE_ALLOW_MAIN_COMMIT=1
   ```
2. Perform the commit
3. Unset the variable immediately after:
   ```bash
   unset FORGE_ALLOW_MAIN_COMMIT
   ```
4. Verify the audit log was written: `ls .forge/audit/`

The override must not be added to any shell profile or `.env` file. It is valid only
for the current shell session.

---

### pre-push Hook Blocking a Push

**Symptom:** `git push origin main` is blocked with the forge message:
`"forge: direct push to main is not permitted."`

**Cause:** The git `pre-push.sh` hook is installed and the target ref is
`refs/heads/main` or `refs/heads/master`.

**Normal resolution:**
- Do not push to main directly. Open a pull request instead: `gh pr create`

**Emergency resolution (exceptional only):**
```bash
git push --no-verify origin main
```

Use `--no-verify` only for genuine emergency operations. This bypasses all git hooks.

---

### pre-push Hook Not Installed (Engineer Cloned Repo)

**Symptom:** `git push origin main` is not blocked on a freshly cloned repository.

**Cause:** `.git/hooks/pre-push` is not tracked by git. Engineers who clone the
repository must reinstall the hook.

**Resolution:**
1. Run `forge:init` in the cloned repository. The `forge:init` skill installs
   `pre-push.sh` into `.git/hooks/pre-push` and makes it executable.

---

### Audit Log Not Being Written

**Symptom:** Admin override with `FORGE_ALLOW_MAIN_COMMIT=1` allows the commit but
no entry appears in `.forge/audit/`.

**Possible causes:**
- The hook cannot write to the repository directory (permissions issue)
- The `.forge/` directory does not exist and the hook cannot create it

**Diagnosis:**
```bash
# Check if .forge/ directory exists and is writable
ls -la .forge/
# Check hook exit code manually
FORGE_ALLOW_MAIN_COMMIT=1 CLAUDE_TOOL_NAME=Bash CLAUDE_TOOL_INPUT="git commit -m test" \
  plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh; echo "exit: $?"
```

**Resolution:**
- Ensure `.forge/` exists and is writable by the current user
- If the repository is new and `.forge/` does not exist, run `forge:init` first

---

### Hook Running Slowly

**Symptom:** Bash tool calls are perceptibly slower than expected.

**Diagnosis:**
```bash
time CLAUDE_TOOL_NAME=Bash CLAUDE_TOOL_INPUT="git status" \
  plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh
```

Expected: under 100ms. If significantly above 100ms:
- Check whether `git branch --show-current` is slow (large repository or network mount)
- Check whether the hook is being invoked in a context where git operations are
  unexpectedly slow (e.g., NFS-mounted `.git/`)

The hook should exit before making any git calls for non-Bash tools and non-commit
commands. Only `git commit` and `git push` commands trigger the git branch lookup.
