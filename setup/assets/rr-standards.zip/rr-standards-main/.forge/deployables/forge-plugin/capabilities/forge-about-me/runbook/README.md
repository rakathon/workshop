# Runbook — forge-about-me

## Skill Does Not Complete

If the skill stalls mid-interview, re-invoke `/forge:about-me`. The skill
has no saved state — it starts fresh. The user will need to re-provide their
materials, but the interview is short enough that this is not a significant
burden.

## Output File Not Found

If `about-me.md` was not created, check whether the Write tool was permitted
during the session. In some Claude Code permission configurations, file writes
require explicit user approval. Re-run the skill and approve the Write call
when prompted.

## CLAUDE.md Append Produced Unexpected Results

If appending to `CLAUDE.md` produced malformed output:
1. Open `CLAUDE.md` and locate the `## My Context Profile` section
2. Delete the section and the preceding blank line
3. Re-run `forge:about-me` and choose `about-me.md` instead
4. Manually copy the desired section into `CLAUDE.md`

## Surface Detected Incorrectly

If the skill behaves as Desktop mode in a Claude Code session (or vice versa),
the detection command may have failed silently. Check that:
- A `.git` directory or `CLAUDE.md` file exists in the current working directory
- The Bash tool is permitted in your Claude Code settings

If neither condition is met, the skill correctly falls back to Desktop mode.
