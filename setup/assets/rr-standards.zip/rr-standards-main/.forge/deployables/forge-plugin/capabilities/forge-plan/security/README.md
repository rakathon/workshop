# Security — forge-plan

## Security Considerations

`forge:plan` reads effort artifacts from `.forge/efforts/` and writes plan artifacts
to the same directory. It does not handle user credentials, secrets, or external
network access. Its security surface is limited.

### File System Access

`forge:plan` reads only files within `.forge/efforts/<id>/`. It must not follow
symlinks to paths outside the effort directory or the repository root. All file reads
are scoped to the effort directory passed as the argument.

### No External Calls

`forge:plan` does not make network calls. It does not fetch artifacts from external
repositories, access CI systems, or invoke external APIs. All inputs are local files.

### Commit Authorship

The commit produced by `forge:plan` uses the git author configuration of the current
session. No special credentials or signing are required beyond the repository's
standard commit signing configuration.

### Plan Content

The plan file reflects the content of the requirements and spec artifacts. If those
artifacts contain sensitive design details (API keys, internal infrastructure names,
PII data models), those details will appear in the plan. Security review of plan
content is the same as security review of the underlying requirements and spec
artifacts.
