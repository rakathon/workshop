# Technical Requirements — forge-graduate

Parent deployable: [forge-plugin](../../requirements/technical.md)
Primary program TRs addressed: TR-12

---

## TR-1: Inputs — Effort ID Passed by the Orchestrator

`forge:graduate` receives a single input: the effort ID. The orchestrator (running in the
main session) passes this ID when it launches the worker sub-agent. The worker does not
read session state, does not navigate the active work registry, and does not interact with
the engineer. It receives the effort ID and proceeds.

The effort directory path is derived from the effort ID: `.forge/efforts/<effort-id>/`.

## TR-2: Identify Associated Deployables and Products from `.state.json`

Before reading any effort artifacts, the skill must read the effort's `.state.json` to
determine what canonical documentation will be updated. Two fields are relevant:

- `deployables` — list of deployable names this effort targets; each maps to
  `.forge/deployables/<name>/`
- `businessProducts` — list of product names (coordination efforts only); each maps to
  `.forge/products/<name>/`

For local (single-deployable) efforts, the `deployables` field identifies the target. For
coordination efforts, the `businessProducts` field identifies the target. A coordination
effort may update both product and deployable documentation.

If neither field is populated, the skill must halt and return an error to the main session:
graduation without a known target is not permitted.

## TR-3: Merge Algorithm — Update Sections, Not Append

Graduation is not a copy operation. Canonical documentation must remain a coherent,
current description of the deployable — not an append-only log of effort outputs.

The merge algorithm must:

1. Read the existing canonical document (if it exists)
2. Identify which sections the effort artifact updates or adds
3. Replace the content of existing sections with the updated content from the effort
4. Add new sections that do not yet exist in the canonical document
5. Preserve sections that the effort does not address

**What "append" means (prohibited):** Adding a new "Requirements added by effort-XYZ"
section alongside the existing requirements section. After graduation, a reader should see
a single, coherent requirements section — not a layered record of successive efforts.

**What "update" means (required):** Finding the relevant section in the existing document
and replacing its content with the effort's version. If the section does not exist, it is
added in the appropriate location in the document structure.

The effort's artifact is the authoritative source for any section it covers. Sections
not covered by the effort are preserved unchanged.

## TR-4: Target Paths by Artifact Type

| Effort artifact | Target path for deployable efforts | Target path for coordination efforts |
|----------------|-------------------------------------|--------------------------------------|
| `requirements/` | `deployables/<name>/requirements/` | `products/<name>/requirements/` |
| `spec/` | `deployables/<name>/spec/` | `products/<name>/spec/` |
| `capabilities/<cap>/` | `deployables/<name>/capabilities/<cap>/` | N/A |
| ADRs | Already in `.forge/spec/arch-decisions/` — verify only | N/A |

ADRs are written to the canonical ADR directory (`.forge/spec/arch-decisions/`) during
the discovery phase, not at graduation. Graduation must verify that each ADR produced
by this effort references the effort ID in its metadata. Graduation does not move or
copy ADRs.

## TR-5: Capability-Level Artifacts

When the effort targets a specific capability within a deployable (the effort's
`capabilities` field in `.state.json` is populated), artifact graduation must be scoped
to the capability directory:

```
deployables/<name>/capabilities/<cap>/requirements/
deployables/<name>/capabilities/<cap>/spec/
```

The skill must not update deployable-level requirements or spec when the effort targets
a capability. The capability directory is the correct scope.

## TR-6: Provenance Metadata

Every canonical document updated by graduation must record the effort ID that last updated
it. This provenance metadata takes the form of a comment or front-matter field:

```markdown
<!-- graduated-from: effort-<id> at <ISO-8601-timestamp> -->
```

This comment is placed at the top of the file, below the H1 heading. It is not visible
in rendered Markdown but is present in the source. Subsequent graduations update the
comment to reflect the most recent graduating effort.

Provenance serves two purposes:
- **Traceability:** An engineer can find the effort that produced the current version of a
  canonical document and read its history.
- **Audit:** The graduation report records which files were updated and from which effort,
  creating an auditable record of promotions.

## TR-7: Post-Approval Modifications Must Appear in the Graduation Report

Before writing any updated canonical documentation, the skill must read
`phases.*.postApprovalModifications` from `.state.json`. If any post-approval
modifications are present, the graduation report must:

1. List each modified artifact with its file path
2. Identify which phase the modification occurred in
3. State that the graduated document reflects the modified (not the originally approved)
   content

The graduation must not proceed silently past post-approval modifications. The report is
returned to the main session so the engineer is aware of what was reconciled.

If no post-approval modifications exist, the graduation report notes this explicitly.

## TR-8: State Updates — Graduation Fields in `.state.json`

After all canonical documentation is written, the skill must update the effort's
`.state.json` with:

```json
{
  "graduation": {
    "graduated": true,
    "graduatedAt": "<ISO-8601 timestamp>",
    "graduatedTo": [
      "deployables/<name>/requirements/business.md",
      "deployables/<name>/spec/api/...",
      "..."
    ]
  }
}
```

`graduatedTo` must list every file path that was created or updated during graduation.
This list is the complete record of what the effort contributed to canonical documentation.

## TR-9: Registry — Remove Effort Row from `.forge/efforts/README.md`

After state is updated, the skill must remove the effort's row from the active registry
at `.forge/efforts/README.md`. Graduated efforts are not active work — they are closed.

The effort directory remains at `.forge/efforts/<id>/` as a permanent historical record.
Only the registry row is removed.

## TR-10: Graduation Commit

Graduation changes must be committed in a distinct commit from any effort close commit.
The commit must contain:

- All updated canonical documentation files
- The updated effort `.state.json` (graduation fields)
- The updated `.forge/efforts/README.md` (registry row removed)

Commit message format:
```
docs(graduation): graduate effort-<id> to <deployable-name>
```

The commit must not contain source code changes, test changes, or other non-graduation
content. The graduation commit is the auditable record of the promotion.

## TR-11: Coordination Efforts Target Products, Not Deployables

For coordination efforts (efforts in a coordination repository that span multiple
deployables), graduation targets `.forge/products/<name>/` instead of
`.forge/deployables/<name>/`. The merge algorithm and provenance requirements are
identical; only the target path differs.

A coordination effort may produce both product-level documentation (user flows, cross-
cutting requirements) and deployable-level artifacts. Each artifact type is graduated to
its appropriate target.

## TR-12: Isolated Execution — Worker Sub-Agent Behavior

`forge:graduate` runs as an isolated worker sub-agent. This means:

- The skill does not read the main session's conversation history or context
- The skill does not emit status updates to the engineer during execution
- The skill does not invoke other skills
- The skill receives only the effort ID as input
- The skill returns only the graduation report as output

The orchestrator (main session) is responsible for:
- Confirming QA sign-off before invoking graduation
- Passing the correct effort ID
- Presenting the graduation report to the engineer

Sections of the SKILL.md marked `[orchestrator-only]` must be skipped when the skill
runs as a worker. These sections include: reading `.state.json` to check workflow phase,
emitting status to the engineer, and invoking other skills.
