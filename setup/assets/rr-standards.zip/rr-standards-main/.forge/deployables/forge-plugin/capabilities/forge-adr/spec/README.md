# forge-adr — Architecture

This capability delivers the `forge:adr` skill, which captures architectural decisions
during conversation and writes them as structured ADR files in the active effort's
`spec/arch-decisions/` directory.

---

## Artifact Inventory

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:adr` | Skill | Orchestrator | Manual invocation or conversational intent |

---

## Architecture

`forge:adr` is a pure skill — no hooks, no background processes. It runs entirely
within Claude's conversational context and uses Claude Code tools (Read, Write, Bash)
for all file operations.

The skill operates in two modes:

**Explicit invocation:** The engineer calls `forge:adr` (or `/forge:adr`) directly,
optionally providing a title and decision text. The skill writes a fully structured ADR
from the provided arguments and conversation context.

**Conversational trigger:** The CLAUDE.md tier-1 content and the UserPromptSubmit hook
instruct Claude to recognize decision statements ("we'll use X", "let's go with Y
because Z") and respond by invoking `forge:adr` automatically. From the engineer's
perspective, making a design decision in conversation results in an ADR appearing in the
effort directory — no explicit command required.

Both modes produce identical output: the same ADR file, the same `.state.json` update,
the same commit.

---

## Data Flow

```
Engineer conversation
        │
        ▼
Decision statement detected
(CLAUDE.md intent recognition
 or explicit forge:adr invocation)
        │
        ▼
Determine active effort ID
(.state.json or branch context)
        │
        ▼
Scan spec/arch-decisions/ for
existing ADR numbers
        │
        ▼
Compute next ADR number
(gap-filling algorithm)
        │
        ▼
Write ADR-NNN-<slug>.md
(all four sections populated)
        │
        ▼
Update spec/arch-decisions/README.md
(append row to index table)
        │
        ▼
Append to .state.json adrsCreated[]
        │
        ▼
Commit: docs(<effort-id>): ADR-NNN <subject>
```

---

## Key Invariants

- **ADR numbers are effort-scoped.** Each effort has its own ADR-001 through ADR-NNN.
  Two efforts in the same repository can both have an ADR-001 without conflict.

- **ADRs are effort artifacts until graduation.** They live in
  `.forge/efforts/<id>/spec/arch-decisions/`, not in `.forge/deployables/` or the
  repository root. Promotion to canonical documentation is handled by `forge:graduate`.

- **All four sections are always present.** An ADR without a Consequences section or
  an empty Alternatives section is not committed. The template is not optional.

- **Numbering is deterministic.** Given the same set of existing ADR files, `forge:adr`
  always assigns the same next number. There is no randomness or timestamp-based
  assignment.

---

## Design Documents

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:adr` detailed design |
| [arch-decisions/README.md](arch-decisions/README.md) | ADRs relevant to this capability |
