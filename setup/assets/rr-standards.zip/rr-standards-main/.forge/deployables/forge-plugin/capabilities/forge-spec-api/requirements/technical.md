# Technical Requirements — forge-spec-api

## TR-1: REST Standard Loaded from Standards Directory
Loads all four REST sub-standards from [`standards/api/rest/`](../../../../../plugins/forge/standards/api/rest/) per ADR-003:
- [`contracts.md`](../../../../../plugins/forge/standards/api/rest/contracts.md) — URI structure, versioning, naming, HTTP verbs
- [`protocol.md`](../../../../../plugins/forge/standards/api/rest/protocol.md) — response envelope, headers, status codes, errors
- [`security.md`](../../../../../plugins/forge/standards/api/rest/security.md) — authentication and authorization
- [`data.md`](../../../../../plugins/forge/standards/api/rest/data.md) — pagination, timestamps, decimal/currency types

Warns per absent file; continues with general REST conventions.

## TR-2: Resource Scope Confirmed Before Endpoint Design
When `--resource` is not provided, proposes a resource breakdown from requirements and
waits for engineer confirmation before designing any individual endpoint.

## TR-3: One-Resource-at-a-Time Interactive Design
In interactive mode, all operations for a single resource are presented together as a
complete YAML block — path established first, then each verb with request schema,
response schema, status codes, and auth declaration. The engineer confirms or revises
the full resource before the skill moves to the next resource.

## TR-4: Inline Checks Fire Per Endpoint Within the Design Loop
After each endpoint is confirmed, four checks apply immediately (Step 5, inside Step 4
loop): resource is a noun, correct status codes, error schema present with code+message
fields, auth declared on write operations.

## TR-5: Non-Standard Overrides Recorded Inline and Flagged for ADR
Engineer overrides are accepted with rationale. The rationale is recorded as an inline
OpenAPI comment `# NON-STANDARD: <rationale>` on the violating element, and the engineer
is prompted to run `forge:adr`.

## TR-6: Contract Written to Canonical Path
Written to `<spec_dir>/<contract>.yaml` (one file per contract; a contract may cover multiple resources). `.state.json` updated:
`phases.discovery.artifacts.spec.api = "present"`.

## TR-8: Existing Spec Detected and Review Offered Before Authoring
Before proposing a resource scope or drafting a contract, the skill resolves `<spec_dir>`
(effort → deployable → capability → explicit `--file` path) and checks whether it already
contains files. If found, it surfaces the filenames and asks the
engineer whether to review or proceed to re-author. Review mode evaluates the existing
contract for: (a) requirements coverage — each BR/TR with an implied API operation has
a corresponding endpoint; (b) REST standard compliance — resource naming, HTTP methods,
status codes, error schema, auth. Findings are presented as gaps and violations; the
engineer chooses to fix inline or review only.

## TR-7: `<effort_dir>` Defined and Used Consistently
`<effort_dir>` = `.forge/efforts/<effort-id>/`. Defined at the top of the skill. All
path references use this variable.
