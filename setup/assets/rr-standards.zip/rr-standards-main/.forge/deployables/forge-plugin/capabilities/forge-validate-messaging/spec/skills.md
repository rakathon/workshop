# forge:validate-messaging — Skill Specification

**Agent type:** Worker
**Skill file:** `plugins/forge/skills/validate-messaging/SKILL.md`

## Purpose

Targeted validation of message/event contracts (`spec/messaging/*.md`) against the
organizational messaging standards. An inline editing aid used during
`forge:spec-messaging` — not a phase gate.

## Inputs

- `spec/messaging/*.md` — all message contract files in the effort
- `standards/messaging/contracts.md` — loaded from plugin standards directory
- `standards/messaging/event-design.md` — loaded from plugin standards directory
- `standards/messaging/versioning.md` — loaded from plugin standards directory

## Worker Steps

1. **Locate plugin root.** Run:
   ```bash
   find ~/.claude/plugins/cache -maxdepth 5 -name "plugin.json" -path "*/forge/*" 2>/dev/null \
     | head -1 | sed 's|/.claude-plugin/plugin.json||'
   ```
   Load `standards/messaging/contracts.md`, `standards/messaging/event-design.md`,
   and `standards/messaging/versioning.md` from the plugin root.

2. **Locate effort directory.** Resolve `<effort_dir>` from the active branch name or
   from the argument passed to the skill.

3. **Load spec/messaging/*.md.** If none, report:
   > "No messaging spec found. Run forge:spec-messaging first."
   and stop.

4. **Per contract, apply checks:**

   **Naming and structure (REQUIRED):**
   - Contract name follows reversed-domain pattern: `<reversed-domain>.<domain>.<subdomain>[.<qualifier>]`
   - Event name uses past tense (events) or imperative mood (commands) per event-design.md R-2
   - Schema defined with all fields named and typed
   - All field names use snake_case (no camelCase, PascalCase, or kebab-case)
   - Standard envelope fields present: `message_id`, `event_name`, `event_version`, `produced_at_ms`, `trace_id`

   **Ownership and consumers (REQUIRED):**
   - Producer identity documented (owner field)
   - At least one consumer identified (or explicitly marked "unknown")

   **Delivery semantics (REQUIRED):**
   - Ordering guarantee documented (FIFO / unordered / at-least-once / at-most-once)
   - Idempotency approach documented

   **Versioning (REQUIRED — highest risk):**
   - Schema version present (positive integer)
   - Compatibility mode declared (FORWARD_TRANSITIVE preferred per contracts.md R-5)
   - Topic name includes version suffix (e.g., `.v1`) per contracts.md R-3
   - Subject name follows `<contract-name>-v<N>` format per contracts.md R-4
   - Breaking change policy stated

   **Suggestions (SUGGESTION):**
   - Consider retry semantics for consumer failure handling if not documented
   - Consider dead-letter queue strategy if not documented

5. **Cross-contract check:** Verify no two contracts declare the same event name.
   If duplicates found, report as a single REQUIRED finding listing conflicting files.

6. **Print inline report** grouped by contract:

   ```
   ## Messaging Validation Report
   **Standard:** standards/messaging/contracts.md

   ### com.example.loyalty.points.awarded
   - [REQUIRED] Idempotency approach not documented
   - [REQUIRED] Compatibility mode not declared
   - [SUGGESTION] Consider adding retry semantics for consumer failure handling

   ### Cross-Contract
   - [REQUIRED] Duplicate event name "com.example.loyalty.points.awarded" in: points-awarded.md, points-awarded-v2.md

   **Summary:** 3 REQUIRED, 1 SUGGESTION
   ```

7. **Do NOT write any file. Do NOT update `.state.json`.** This is an inline editing
   aid only.

## Output

Inline session report only. No files written. No state updated.
