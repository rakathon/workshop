# Business Requirements — forge-classify

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-5 (continuous risk management), BR-20 (no overhead beyond validations)

---

## BR-1: Ceremony Must Be Proportional to Risk — and Risk Must Be Determined Explicitly

The Forge workflow applies different levels of rigor at different risk levels: full
arch review and mandatory human approval for R1/R2, lightweight process for R3/R4.
For this calibration to work, the risk tier must be established before design work
begins — not inferred implicitly from the work item type or left as an unspoken
assumption.

An effort with no explicit risk classification will either receive too much ceremony
(slowing low-risk work unnecessarily) or too little (allowing high-risk work to
bypass required scrutiny). `forge:classify` makes the classification explicit and
confirmed — a deliberate decision, not a derivation.

## BR-2: Classification Must Be a Decision, Not a Derivation

Risk classification determines significant downstream consequences: whether an arch
review meeting is required, whether implementation verification runs, whether human
approval is mandatory on every PR. These are not decisions that should happen
silently. An engineer who has not consciously confirmed the risk tier may not realize
that their R1 work requires a formal architecture review, or may be surprised by the
PR approval policy.

Classification must require explicit engineer confirmation. A `suggestedRisk` advisory
in `.state.json` may inform the decision, but the classification is always the
engineer's call — the advisory cannot substitute for confirmation.

## BR-3: Classification Must Be Revisable as Discovery Reveals New Information

Risk is assessed at the start of discovery based on initial requirements. As design
work proceeds, new implications surface: a requirement that seemed benign turns out
to involve PII; an API contract reveals a dependency on a core platform service; a
storage schema reveals a migration risk not apparent from the requirements alone.

The classification set at the start of discovery may become incorrect before
discovery is complete. Engineers must be able to revise the classification at any
point — not just at initialization — without disrupting work already in progress.
A classification that cannot be revised locks teams into the wrong ceremony level
for the duration of the effort.

## BR-4: Engineers Must Understand Why a Tier Was Recommended

An engineer who is told "this is R2" without explanation cannot evaluate whether
the classification is correct. They may have information that changes the
assessment — a data handling requirement that implies PII, or a dependency that is
less critical than the rubric suggests. A classification recommendation that shows
its reasoning allows the engineer to engage with it: confirm, override with
rationale, or revisit the requirements.

---

Success criteria: [success-criteria.md](success-criteria.md)
