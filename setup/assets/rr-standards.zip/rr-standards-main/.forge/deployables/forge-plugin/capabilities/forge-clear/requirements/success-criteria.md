# Success Criteria — forge-clear

- [ ] `forge:clear` deletes `.forge/EFFORT` and prints "Active effort cleared: <id>"
      when an active effort pointer exists
- [ ] `forge:clear` prints "No active effort is set." and exits cleanly when
      `.forge/EFFORT` is absent or empty
- [ ] `forge:clear` leaves `.state.json` and all effort artifacts completely unmodified
- [ ] `forge:clear` makes no git commits and stages no files
- [ ] Running `forge:clear` twice in a row prints "No active effort is set." on the
      second invocation (identical behavior to SC-2)
