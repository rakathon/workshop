# Architecture — forge-slack

<!-- graduated-from: slack-support at 2026-04-23T21:50:06Z -->

Slack integration for Forge. Associates channels with efforts, imports messages
incrementally, and generates structured summaries. All Slack access is mediated by
the Slack MCP server; skills never call the Slack REST API directly.

## Skills

| Skill | Purpose |
|---|---|
| [`forge:slack-channel`](skills/forge-slack-channel.md) | Associate or remove a Slack channel from an effort |
| [`forge:slack-import`](skills/forge-slack-import.md) | Import messages incrementally; supports CI batch mode |
| [`forge:slack-summarize`](skills/forge-slack-summarize.md) | Generate daily or weekly summaries from imported messages |

## Storage

| Document | Description |
|---|---|
| [`storage/messages.md`](storage/messages.md) | Directory layout, file formats, checkpoint, PII handling |

## Design Documents

| Document | Description |
|---|---|
| [`skills/forge-slack-channel.md`](skills/forge-slack-channel.md) | Skill contract for `forge:slack-channel` |
| [`skills/forge-slack-import.md`](skills/forge-slack-import.md) | Skill contract for `forge:slack-import` |
| [`skills/forge-slack-summarize.md`](skills/forge-slack-summarize.md) | Skill contract for `forge:slack-summarize` |

## Architecture Notes

- Messages stored at `efforts/<id>/messages/slack/<channel>/YYYY-MM/YYYY-MM-DD.md`
- Checkpoint at `efforts/<id>/messages/slack/<channel>/.checkpoint` (ISO 8601 timestamp)
- Scheduled import runs via GitHub Actions (ADR-001); manual invocation always supported
- Summaries are decoupled from import — regeneratable independently at any time
- Bounded `--from`/`--to` runs never advance the checkpoint

## ADRs

| ADR | Decision |
|---|---|
| [ADR-001](arch-decisions/ADR-001-github-actions-scheduling.md) | GitHub Actions for scheduled import over Claude Code crons |
| [ADR-002](arch-decisions/ADR-002-slack-mcp-over-direct-api.md) | Slack MCP over direct REST API |
