# Runbook — forge-pin

## Procedures

### forge:pin Fails — Unknown Version Tag

**Symptom:** `forge:pin --version X.Y.Z` fails with "Tag not found."

**Cause:** The specified version tag does not exist in the rr-standards repository.

**Resolution:**
1. Check available release tags: `gh release list -R rewards-guilds/rr-standards`
2. Re-run with a valid tag: `forge:pin --version <valid-version>`

---

### forge:pin Fails — gh CLI Not Authenticated

**Symptom:** `forge:pin` fails with a `gh` authentication error.

**Cause:** The `gh` CLI is not installed or not authenticated.

**Resolution:**
1. Verify `gh` is installed: `gh --version`
2. Authenticate: `gh auth login`
3. Re-run `forge:pin`

---

### forge:pin Ran But forge_min_version Not Updated

**Symptom:** `.forge/version` still shows the old `forge_min_version` after running
`forge:pin`.

**Cause:** `.forge/version` did not exist when `forge:pin` ran — the file is only
updated if it already exists (TR-10.3). `forge:init` had not been run yet.

**Resolution:**
- Run `forge:init` (order-independent with `forge:pin`). It will read the pin from
  `.claude-plugin/marketplace.json` and write the correct `forge_min_version`.

---

### SHA Mismatch on Plugin Load After forge:pin

**Symptom:** Claude Code reports a SHA mismatch when loading the forge plugin after
running `forge:pin`.

**Cause:** The release tag in the rr-standards repository was moved after `forge:pin`
resolved it. The committed SHA no longer matches the tag's current target.

**Resolution:**
1. Re-run `forge:pin --version <same-version>` to resolve and commit the current SHA
2. Run `/plugin install forge@forge-local` to fetch the corrected version
3. Commit the updated `.claude-plugin/marketplace.json`
