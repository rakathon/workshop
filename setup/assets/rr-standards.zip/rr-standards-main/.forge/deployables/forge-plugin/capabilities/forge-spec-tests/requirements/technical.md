# Technical Requirements — forge-spec-tests

## TR-1: `--type` Argument; Defaults to `full`

The skill accepts `--type <e2e|contract|integration|full>`. If absent,
the default is `full`. An unrecognized value stops with the list of valid types.

## TR-2: Output Directory Determined by Test Type and Repository Type

All output files are written inside a `test/` subdirectory. Output directory rules:

**E2E plans:**
- Coordination repo (`.forge/products/` has directories) →
  `.forge/products/<product-name>/test/` — prompt for `--product` if absent
- Deployable repo (no product directories) → `<effort_dir>/spec/test/`

**Contract and integration plans:**
- `--capability` provided → `<capability_dir>/test/`
- `--capability` absent → prompt for which capability; set `<capability_dir>/test/`
- Epic spanning multiple capabilities → `<effort_dir>/spec/test/`

**Full:** applies E2E routing for the e2e component, capability routing for
contract/integration components.

## TR-3: Ensures Output Directory Exists

When output target is a capability directory and `<capability_dir>` does not exist,
create standard structure (`requirements/`, `spec/`, `spec/arch-decisions/`,
`runbook/`, `security/`, `test/`) and inform the engineer. In all cases, create
`<output_dir>` if it does not already exist.

## TR-4: Reads All Available Effort Artifacts

Reads `requirements/business.md` (required), `requirements/technical.md` (optional),
`spec/api/*.yaml`, `spec/storage/*.md`, and `spec/messaging/*.md`. Records which
spec categories are present as `has_api_spec`, `has_storage_spec`, `has_messaging_spec`.

## TR-5: Feasibility Check Per Requested Type

Before proposing scenarios, verify that required spec is present for each component
of the requested type:

| Component | Required |
|-----------|---------|
| E2E | BRs present (always true at this point) |
| Contract (API) | `has_api_spec = true` |
| Contract (messaging) | `has_messaging_spec = true` |
| Integration | `has_storage_spec = true` OR TRs describe service-layer interactions |

Build separate lists of achievable and blocked components.

## TR-6: Gap Report Format

If some or all requested types are blocked, the skill prints a structured gap
report naming the missing artifact and the Forge skill to create it. If all are
blocked, stop. If some are achievable, prompt the engineer to continue with
achievable types or stop to fill the gap.

## TR-7: One Output File Per Type; Contract Files Named After Spec

Each achievable type produces one output file in `<output_dir>`:

| Type | Filename |
|------|----------|
| `e2e` | `e2e-test-suite.md` |
| `contract` | `<spec-name>-contract-test-suite.md` per spec file |
| `integration` | `integration-test-suite.md` |
| `full` | all achievable type files (e2e + per-contract + integration) |

Contract filenames are derived from the spec basename without extension:
`spec/api/favorites.yaml` → `favorites-contract-test-suite.md`

## TR-8: Scenarios Derived Per Type

- **E2E**: derived from BRs; describe observable system behavior without reference
  to service internals
- **Contract**: one scenario per endpoint (happy path + each documented error
  response) from API spec; one scenario per event schema from messaging spec
- **Integration**: derived from storage spec entities and service-layer TRs;
  describe in-process interactions against real components

When a TR is ambiguous between integration and contract (e.g. "all endpoints require
a valid bearer token"), produce both: an integration scenario for the in-process
middleware behavior and a contract scenario for the observable response shape.

## TR-9: No Unit Tests in Output

Unit test scenarios must not appear in output. If the engineer requests one,
explain that unit tests are out of scope for this test suite.

## TR-10: Load Test Placeholder Section

Every output file must include a `## Load Test Scenarios (v2)` section with a
placeholder directing the engineer to `forge:spec-tests --load-tests` when ready.

## TR-11: Re-invocation Extends, Does Not Replace

If an output file already exists, read it, identify covered scenarios, and add only
new scenarios. Do not renumber or remove existing content. Update the Coverage Map.
The confirmation step still applies on re-invocation — present only new scenarios.

## TR-12: Does Not Update `.state.json`

Test plans are planning artifacts tracked in `test/` inside the capability or effort
spec directory. The skill must not modify `.state.json`.
