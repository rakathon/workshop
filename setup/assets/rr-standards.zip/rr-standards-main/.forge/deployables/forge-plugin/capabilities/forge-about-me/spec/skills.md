# forge:about-me Skill Design

Design for the `forge:about-me` skill. The skill is interactive, runs in the
user's Claude session (any surface), and uses the Read, Write, and Bash tools
where available.

Implementation: `plugins/forge/skills/about-me/`

---

## forge:about-me

### Arguments

None.

### Preconditions

None. The skill is always safe to run.

### Flow

```
Step 1: Role Extraction
        Open with a warm invitation to paste LinkedIn, CV, or JD.
        If provided: extract role fields, note gaps.
        If not provided: ask title + company, then seniority (two questions max per turn).

Step 2: Role Deep-Dive
        Fill gaps from Step 1 with targeted questions.
        Dimensions: responsibilities, team size, direct reports (managers only),
        reporting line, stakeholders served.
        Ask one or two at a time. Skip anything already answered.

Step 3: Writing Samples
        Request one or more Slack messages or emails.
        After each sample, ask if there are more. Wait for "that's all".
        Analyze: formality, directness, technical depth, brevity, warmth, structure.
        Scan for eight AI anti-pattern tells; remove any that appear in the user's samples.
        Generate 3–4 sentence voice description in second person.
        Present for confirmation. Wait. Incorporate corrections.
        If no samples: ask three targeted questions instead; build from answers.

Step 4: Communication Audience
        One question about day-to-day communication channels and audience adaptation.
        Do not probe further.

Step 5: Assemble Context Block
        Wrap the four-section block in marker comments:
          <!-- forge:about-me:start -->
          ## My Context Profile
          ### Company Context   [verbatim fixed text]
          ### My Role           [3–5 sentences, prose, first person]
          ### Communication Audience  [1–3 sentences, prose, first person]
          ### Tone & Voice      [confirmed voice description + anti-patterns + closing line]
          <!-- forge:about-me:end -->
        Target: descriptive content under 250 words (anti-pattern line excluded).
        Markers must appear verbatim in all output destinations.

Step 6: Deliver Output
        Print the assembled block inline, then apply surface-specific behaviour.
        Claude knows which surface it is running on — no runtime detection needed.

        Claude Code:
          Write to ~/.claude/CLAUDE.md (create if absent).
          If <!-- forge:about-me:start --> … <!-- forge:about-me:end --> found:
            replace the entire span (markers inclusive) with the new block.
          Else: append at end with preceding blank line.
          Never touch content outside the markers.
          Confirm: "Added to ~/.claude/CLAUDE.md — this context will apply to
                    all your Claude Code sessions automatically."
          Never write to a project CLAUDE.md.

        Claude.ai / Claude Desktop:
          Write about-me.md in the current working directory (markers included).
          Tell user to copy block into Custom Instructions or System Prompt.

        Cowork:
          Write about-me.md in the current working directory (markers included).
          Share the full path so the user can retrieve the file.
          Tell user to copy block into Custom Instructions or System Prompt.
```

### Key Design Decisions

- Surface detection runs at Step 5 (assembly), not at invocation. The
  conversational flow is identical in both modes; detecting early would
  surface a technical distinction before the user has seen any value.
- No runtime surface detection is used. Claude knows which surface it is
  running on from its own context. The skill uses named surface sections
  (Claude Code, Claude.ai/Desktop, Cowork) — the same pattern as the
  Anthropic skill-creator. This is more reliable than any programmatic
  probe: Bash availability cannot distinguish Claude Code from a Desktop
  session with an MCP server, and `claude --version` cannot distinguish
  them either if both are installed.
- In Claude Code the skill writes directly to `~/.claude/CLAUDE.md` without
  offering a choice. There is only one correct destination for personal
  context in a Claude Code session; presenting `about-me.md` as an
  alternative would imply it is equally valid, which it is not.
- The skill never writes to a project CLAUDE.md under any circumstance.
  Personal context in a checked-in project file would expose private role
  information to teammates and is architecturally wrong.
- HTML comment markers (`<!-- forge:about-me:start -->` / `<!-- forge:about-me:end -->`)
  wrap the output block in every destination. This makes replacement deterministic
  on subsequent runs — no heuristic heading search, no risk of clobbering adjacent
  content. The markers are invisible when rendered.
- The Company Context section is fixed prose. It must be reproduced verbatim
  — not summarised, paraphrased, or abbreviated.
- Anti-patterns are filtered per-user: any pattern present in the user's own
  writing samples is removed from the output instruction. This preserves
  authentic voice rather than over-correcting.
- Direct reports are only asked if the user's title indicates a managerial role.
  Asking an individual contributor about direct reports wastes a turn.
