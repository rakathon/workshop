# Technical Requirements — forge:statusline Skill
<!-- graduated-from: forge-statusline at 2026-04-26T01:20:08Z -->

## TR-1: Python 3 stdlib only

The statusline script (`forge-statusline.py`) must use only Python 3 standard library
modules: `json`, `sys`, `os`, `subprocess`, `time`, `pathlib`, `re`. No third-party
packages. No `jq` dependency.

**Rationale:** Forge hooks already use `python3` directly (e.g. `capture-session-end.sh`,
`enforce-branch-policy.sh`). Python 3 is an established dependency. `jq` is not.

## TR-2: Graceful degradation

The script must never exit with a non-zero code or produce no output. Every code path
must fall back to a minimal `[model] dir` display if any field is absent, null, or an
error occurs (JSON parse failure, subprocess error, file read error).

## TR-3: Absent and null field handling

All JSON fields that may be absent or null per the statusline schema must be handled:
- `worktree.*` — absent outside `--worktree` sessions
- `effort.*` — not a native statusline field; sourced from filesystem
- `context_window.used_percentage` — null before first API call
- `cost.*` — may be zero/null early in session

Use `data.get('field', {}).get('subfield')` or equivalent; never assume presence.

## TR-4: Effort context via filesystem cache

The script must derive the active Forge effort from the filesystem, not from the JSON
input (which has no effort fields). Algorithm:

1. Walk up from `cwd` toward the filesystem root to find the nearest directory
   containing a `.forge/` subdirectory. Use this as `forge_root`. Stop at the
   filesystem root if not found — no effort context available.
2. Read the git branch from `git branch --show-current` (run with `cwd=forge_root`).
3. Check for `<forge_root>/.forge/EFFORT`. Read the effort ID from that file if present.
4. Fall back to deriving the effort ID from the branch name suffix
   (e.g. branch `effort/forge-statusline` → effort ID `forge-statusline`).
5. If an effort ID is found, read `currentPhase` and `title` from
   `<forge_root>/.forge/efforts/<effort_id>/.state.json`.
6. Cache the result to `/tmp/forge-statusline-<session_id>` with a 5-second TTL.
   Use `session_id` (not PID) as the cache key so concurrent sessions in different
   repos do not share state.

## TR-5: Title truncation

Effort titles must be truncated to 30 characters with a trailing `…` if longer,
to avoid overflowing narrow terminals.

## TR-6: Script location and settings path

- Script installed to: `~/.claude/forge-statusline.py`
- Settings written to: `~/.claude/settings.json`
- `statusLine` config: `{ "type": "command", "command": "~/.claude/forge-statusline.py", "padding": 2 }`
- Script must be made executable (`chmod +x`) after install.

## TR-7: Content hash for staleness detection

The plugin ships a `forge-statusline.py.sha256` file alongside the script sources.
`forge:update` compares this hash against both installed scripts (`forge-statusline.py`
and `forge-subagent-statusline.py`) and emits a single advisory if either is stale.
The skill must not use version strings for this comparison — only content hashes.

The hash file covers both scripts (concatenated SHA-256 of both files in alphabetical
order by filename) so a single comparison detects staleness in either.

## TR-8: Settings merge — not overwrite

When writing `~/.claude/settings.json`, the skill must read the existing file (if any),
merge the `statusLine` key, and write back. It must preserve all other keys. If the file
does not exist, create it with only the `statusLine` key.

## TR-9: subagentStatusLine — dedicated script

The `subagentStatusLine` entry in the plugin's `.claude-plugin/settings.json` must
point to a dedicated script `~/.claude/forge-subagent-statusline.py`, installed
alongside `forge-statusline.py` by the `forge:statusline` skill. No inline command;
no `jq`. Format each visible agent row as: `[type] name · status · Xtk`

## TR-10: No refreshInterval required

The script sources effort state from the filesystem (fast, cached). Git branch is read
via subprocess (fast). No time-based data is displayed. `refreshInterval` is not needed
and must not be set.
