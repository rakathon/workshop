# Business Requirements — forge-elaborate

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-1 (accelerate discovery), BR-2 (requirements fidelity), BR-3 (designs validated before implementation)

---

## BR-1: Engineers Frequently Begin Implementation Without a Shared Understanding of the Problem

When an engineer starts building from a product brief or a set of business requirements, they are working from their own interpretation of what needs to be built. That interpretation is rarely complete — it contains gaps, assumptions, and ambiguities the engineer does not know are there. The gaps surface during implementation (expensive), in code review (still expensive), or in production (very expensive).

The solution is not better documentation alone. It is an active, conversational process that surfaces the gaps by asking questions — and does not stop until there are no more productive questions to ask. `forge:elaborate` is that process.

## BR-2: Understanding Must Be Built in a Natural Dependency Order

Some questions cannot be answered well until others are answered first. You cannot design a sensible data model before you understand the business requirements. You cannot design integration contracts before you understand the data model. You cannot reason about internal implementation before you understand the contracts that constrain it.

A tool that asks questions in an arbitrary or mechanically fixed order produces shallow answers — the engineer has not had the opportunity to think through earlier layers before being asked about later ones. The interview must respect natural dependency order while remaining responsive to what has already been established and adaptive enough to cycle back when deeper questions reveal earlier gaps.

## BR-3: Each Agreed Understanding Must Be Written to the Right Artifact Immediately

A shared understanding that exists only in conversation is lost when the conversation ends. Each answer that is agreed upon must be written to the appropriate artifact — business requirement, technical constraint, or architectural decision record — immediately when agreed, not accumulated and written at the end.

This is required because sessions are interrupted. A partially completed interview that has written its agreed answers is recoverable. One that has accumulated everything for a final write is not.

## BR-4: The Skill Must Work Regardless of What Artifacts Exist at Invocation Time

Engineers invoke this skill at different points in discovery. Some have no prior artifacts at all. Others have a full set of business requirements but no technical requirements. Others have BRs, TRs, and partial specs. The skill must read whatever exists, orient itself, and begin asking what is missing — not require a specific prior step to have been completed first.

This means `forge:elaborate` subsumes the function previously served by `forge:extract`: it can be invoked cold with no prior artifacts and will interview the engineer to produce business requirements, technical requirements, and architectural decisions in a single session.

## BR-5: The Skill Must Be Usable Outside of a Formal Effort

Not every design conversation results in a formal Forge effort. Engineers sometimes need to think through a problem, develop a deep understanding of it, and then decide how to proceed. When there is no active effort, the skill conducts the same interview — building the same depth of understanding — but holds the results in context and asks the engineer at the end whether they want to write the understanding anywhere.

## BR-6: The Shared Understanding Must Culminate in User Stories

Business requirements and technical requirements describe what the system must do and what constraints it must satisfy. User stories describe who wants what and why — the human frame that connects the technical work to real user value. After the interview concludes, the skill writes `requirements/user-stories.md` in Connextra format, giving the team a user-centred view of what they are building.

---

Success criteria: [success-criteria.md](success-criteria.md)
