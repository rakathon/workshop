# Security — forge-about-me

## Data Handling

`forge:about-me` processes personally identifiable information: job title,
seniority, team size, reporting relationships, and writing samples. This data
is handled entirely within the user's Claude session — it is not transmitted
to any external service by the skill itself.

Writing samples may contain sensitive internal communications. The skill
must not persist these samples beyond what is needed to generate the voice
description. They are used in-session only and are not written to any file.

## Output Files

The assembled context block (`about-me.md` or appended to `CLAUDE.md`)
contains role and communication information. Users should treat these files
as they would any personal or role-specific document — do not commit them
to shared repositories without review.

## No Elevated Permissions

The skill uses only Read, Write, and Bash tools. Bash access is limited to:
- A single detection command checking for `.git`, `CLAUDE.md`
- Reading and writing `CLAUDE.md` if the user chooses that path
- Writing `about-me.md`

No network calls, no subprocess execution, no elevated permissions required.
