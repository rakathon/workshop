# Technical Requirements — forge:validate-messaging

Parent: [business requirements](business.md)

---

## TR-1: Load All Messaging Spec Files from the Effort Directory (← BR-1)

The skill must load all files matching `spec/messaging/*.md` from the resolved effort
directory. If no files match, the skill reports:

> "No messaging spec found. Run forge:spec-messaging first."

and halts without error.

**Acceptance criteria:**
- All `.md` files under `spec/messaging/` are loaded and validated.
- Missing directory or empty directory produces the expected advisory message.
- No crash or silent failure on empty spec directory.

---

## TR-2: Load the Organizational Messaging Contracts Standard (← BR-1)

The skill must load `standards/messaging/contracts.md` from the Forge plugin standards
directory. The plugin root is located by running:

```bash
find ~/.claude/plugins/cache -maxdepth 5 -name "plugin.json" -path "*/forge/*" 2>/dev/null \
  | head -1 | sed 's|/.claude-plugin/plugin.json||'
```

The standard file is at `<plugin-root>/standards/messaging/contracts.md`.

Also load `standards/messaging/event-design.md` and `standards/messaging/versioning.md`
to provide complete coverage of naming conventions, envelope field requirements, and
versioning rules.

**Acceptance criteria:**
- Standards are loaded before any checks are applied.
- If the standards directory cannot be found, the skill warns and proceeds using
  built-in check rules derived from these requirements.

---

## TR-3: Apply Per-Contract Field Checks (← BR-1)

For each contract file, the following checks apply:

| Check | Severity | Rule Source |
|-------|----------|-------------|
| Contract name follows reversed-domain pattern (`<reversed-domain>.<domain>.<subdomain>[.<qualifier>]`) | REQUIRED | contracts.md R-2 |
| Event name uses past tense (for events) or imperative mood (for commands) | REQUIRED | event-design.md R-2 |
| Schema defined with all fields named and typed | REQUIRED | contracts.md R-1 |
| All field names use snake_case | REQUIRED | event-design.md R-1 |
| Standard envelope fields present: `message_id`, `event_name`, `event_version`, `produced_at_ms`, `trace_id` | REQUIRED | event-design.md R-5 |
| Producer identity documented (owner field) | REQUIRED | contracts.md R-1, R-7 |
| At least one consumer identified (or explicitly marked "unknown") | REQUIRED | spec-messaging TR-3 |
| Ordering guarantee documented | REQUIRED | spec-messaging BR-1 |
| Idempotency approach documented | REQUIRED | spec-messaging BR-1 |
| Compatibility mode declared | REQUIRED | contracts.md R-5 |
| Topic name includes contract version suffix (`.<vN>`) | REQUIRED | contracts.md R-3 |

**Acceptance criteria:**
- Each check fires independently — a failure on one does not suppress other checks.
- Checks use content scanning (look for keywords/fields in the markdown), not
  structural parsing that would fail on minor formatting variation.

---

## TR-4: Apply Versioning Checks (← BR-3)

For each contract file:

| Check | Severity | Rule Source |
|-------|----------|-------------|
| Schema version present (integer ≥ 1) | REQUIRED | contracts.md R-1, versioning.md R-1 |
| Breaking change policy stated (or compatibility mode = FORWARD_TRANSITIVE documented) | REQUIRED | contracts.md R-5, versioning.md R-3 |
| Subject name follows `<contract-name>-v<N>` format | REQUIRED | contracts.md R-4 |

**Acceptance criteria:**
- Missing version produces a REQUIRED finding (not a warning or suggestion).
- Missing compatibility mode produces a REQUIRED finding.
- Subject format mismatch produces a REQUIRED finding.

---

## TR-5: Cross-Contract Uniqueness Check (← BR-1)

After all per-contract checks, perform a cross-contract check: verify that no two
contract files declare the same event name (the `name:` field or equivalent heading).

If duplicates are found, report them together as a single REQUIRED finding listing
the conflicting files.

**Acceptance criteria:**
- Two contracts with identical event names produce one cross-contract REQUIRED finding.
- Unique event names produce no cross-contract finding.

---

## TR-6: Must Not Write Files or Update State (← BR-2)

The skill must not:
- Write or modify any file in the effort directory.
- Write or modify `validation/report.md`.
- Update `.state.json`.
- Create any file anywhere.

Output is inline session text only.

**Acceptance criteria:**
- After running the skill, `git status` shows no new or modified files.
- `.state.json` `mtime` is unchanged.

---

## TR-7: Run as a Worker Agent (← BR-1)

The skill must be implemented with `agent-type: worker`. This prevents the messaging
standards (potentially large) from being loaded into the engineer's main session
context window, preserving capacity for implementation work.

**Acceptance criteria:**
- Frontmatter declares `agent-type: worker`.
- Skill does not instruct Claude to load the standards into the current session.
