# Security — forge-effort

This document describes the security considerations for the forge-effort capability.

---

## What forge-effort Stores and Where

The forge-effort capability writes three categories of files:

1. **`.state.json`** — Machine-readable effort state. Contains: effort identity, type,
   tier, risk, phase status, artifact inventory, open decisions, pause state, and cross-repo
   references. No credentials, tokens, API keys, or PII.

2. **`.forge/efforts/README.md`** — The active-work registry. Contains: effort IDs, titles, types,
   phases, and statuses. Organizational metadata only.

3. **Effort directory scaffolding** — Empty directories created at effort initialization.
   No content.

**None of these files contain secrets.** The capability does not write source code, service
configurations, or any file that would contain credentials, tokens, or sensitive system
information.

---

## Cross-Repository References

The `coordinationRef` field in `.state.json` records:
- `repo` — the coordination repository in `org/repo` form (public repository path).
- `effortId` — an effort ID string (not a credential).
- `branch` — a git ref (branch name or commit SHA).
- `commitSha` — a commit SHA from the coordination repository.
- `projectedAt` — an ISO-8601 timestamp.

None of these fields are secret. They are the same information visible in a public GitHub
repository URL. Engineers and agents should avoid putting sensitive information in effort
IDs or effort titles, as these appear in the registry and commit messages.

---

## The productionBound Flag and Its Security Role

The `productionBound: false` flag on PoC efforts is a structural control, not a security
enforcement mechanism. It signals that:
- `forge:review` is not registered as a required PR status check for this effort.
- Security and privacy validation failures are non-blocking.

This flag does not prevent a determined engineer from merging PoC code to a production
branch. That enforcement is the responsibility of branch protection rules and CI/CD
pipeline configuration at the repository level. The `productionBound` flag makes the intent
explicit and prevents the path of least resistance from leading to incorrect behavior —
it is not a security boundary.

**Consequence:** Repository administrators must configure branch protection for
production-tracked branches independently of Forge. Forge communicates intent; branch
protection enforces it.

---

## Hook Script Security

The four hooks in this capability are shell scripts that:
- Read local files (`.state.json`, `.forge/efforts/README.md`).
- Write local files (`.state.json`, `.forge/efforts/README.md`).
- Make optional GitHub API calls via `gh api` (SessionStart hook only).

**Input validation:** Hooks receive file paths as arguments. Paths are used to read and
write files in the local working tree. No path should be passed to shell commands in an
unsanitized way. Implementations must use proper quoting and avoid constructing commands
by string concatenation with untrusted path inputs.

**GitHub API calls:** The SessionStart hook calls `gh api` with repository and file paths
derived from `coordinationRef`. These values are written at effort creation time by trusted
agents. If `.state.json` is manually edited with a malicious `repo` value, the hook would
make an API call to that repository path. This is a low-severity risk (the call is read-only
and requires the `gh` CLI to be authenticated to the target repository) but implementers
should be aware of it.

**No arbitrary code execution:** Hooks do not execute content from effort artifacts. They
parse JSON (`.state.json`) and Markdown (`.forge/efforts/README.md`). JSON parsing must use a
proper parser, not ad-hoc shell substitution, to avoid injection risks.

---

## Pause State Security

The `pauseState.contextSummary` field contains a natural-language summary of the session's
context, written by the AI agent. This field may contain references to design decisions,
technical constraints, or architectural choices.

Engineers should be aware that:
- Pause state is stored in plaintext in `.state.json`, which is committed to git history.
- The contextSummary should not contain credentials, access tokens, or specific PII data.
- If an engineer accidentally includes sensitive information in a conversation that is then
  captured in a pause summary, that information will be in git history after the next commit.

This is a documentation hygiene concern, not a system design vulnerability — the same care
that applies to commit messages and code comments applies to pause state summaries.

---

## Recommendations for Repository Administrators

1. Configure branch protection on production-tracked branches independently of Forge. The
   `productionBound` flag communicates intent but does not enforce it.

2. Review `.state.json` files in code review for any unexpected content. They should contain
   only effort metadata, not secrets or PII.

3. Ensure engineers understand that effort IDs and titles appear in commit messages and the
   registry. Titles like "security-exploit-poc" or "bypass-auth-investigation" are
   inadvisable as they will appear in git history.

4. If your organization has strict data classification requirements, consider whether effort
   titles and open decision descriptions may contain information that should not be in a
   shared git repository.
