# Technical Requirements — forge:validate-storage

*Effort: forge-validate-storage*  *Authored: 2026-04-13*

---

## TR-1: Load All Storage Spec Files (← BR-1)

**Description:**
Load all files matching `spec/storage/*.md` from the active effort directory. This
includes physical schema files for all storage technologies present in the design.

**Acceptance Criteria:**
- AC-TR-1.1: All `*.md` files under `spec/storage/` are read. No file is silently skipped.
- AC-TR-1.2: If no files are found, output: "No storage spec found. Run forge:spec-storage first." and stop.
- AC-TR-1.3: Files `spec/storage/logical-schema.md` and `spec/storage/query-patterns.md` are
  loaded for context (cross-referencing query patterns against indexes) but are not
  themselves validated as physical schemas.

---

## TR-2: Detect Storage Technology from Filename (← BR-1)

**Description:**
Detect the storage technology from the physical schema file name and load the applicable
standard from the plugin standards directory (`standards/storage/<type>.md`). If the
technology cannot be determined from the filename, ask the engineer before proceeding.

**Acceptance Criteria:**
- AC-TR-2.1: Filename-to-technology mapping:
  - `postgres.sql`, `postgres.md`, `postgresql.md` → PostgreSQL → `standards/storage/postgresql.md`
  - `dynamo.md`, `dynamodb.md` → DynamoDB → `standards/storage/dynamodb.md`
  - `redis.md` → Redis → `standards/storage/redis.md`
  - `opensearch.md`, `elasticsearch.md` → OpenSearch → `standards/storage/opensearch.md`
  - `extension-storage.md` → Browser Extension Storage → `standards/storage/extension-storage.md`
- AC-TR-2.2: If the filename matches none of the above patterns, list the unmatched files
  and ask the engineer to identify the technology before continuing.
- AC-TR-2.3: If the applicable standard file does not exist in the plugin root, warn
  but apply general checks and continue.
- AC-TR-2.4: Each physical schema file is validated independently with its own applicable standard.

---

## TR-3: Apply Common Schema Checks Per Entity (← BR-1)

**Description:**
For each entity/table/collection defined in the physical schema, apply common checks
regardless of storage technology.

**Acceptance Criteria:**
- AC-TR-3.1: Verify a primary key is defined for each entity. Flag as REQUIRED if absent.
- AC-TR-3.2: Verify all fields have explicit types. Flag fields without types as REQUIRED.
- AC-TR-3.3: Verify a soft-delete policy is documented (either a `deleted_at` field or an
  explicit policy statement that records are hard-deleted). Flag omission as REQUIRED.
- AC-TR-3.4: Cross-reference indexes against `spec/storage/query-patterns.md` if that file
  is present. Flag indexes that serve no documented query pattern as SUGGESTION.
  Flag query patterns with no supporting index as REQUIRED.

---

## TR-4: Check PII Annotations (← BR-3)

**Description:**
Identify fields containing personal data and verify that retention period and deletion
obligation are documented inline or in a nearby comment.

**Acceptance Criteria:**
- AC-TR-4.1: Fields to be considered PII by default (unless context indicates otherwise):
  `email`, `name`, `first_name`, `last_name`, `phone`, `phone_number`, `dob`,
  `date_of_birth`, `address`, `postal_code`, `zip_code`, `ip_address`, `device_id`,
  `ssn`, `tax_id`, `credit_card`, `card_number`, `account_number`, `gender`,
  `nationality`, any field with `_pii` suffix, any field annotated as PII.
- AC-TR-4.2: For each PII field, verify a retention period is documented (e.g.,
  "Retention: 7 years" in a comment). Flag as REQUIRED if absent.
- AC-TR-4.3: For each PII field, verify a deletion obligation is documented (e.g.,
  "Deletion: anonymise on request" in a comment). Flag as REQUIRED if absent.
- AC-TR-4.4: GDPR comment format for PostgreSQL (standard pattern):
  `-- GDPR: Contains PII (<field list>). Retention: <period>. Deletion: <obligation>.`

---

## TR-5: Apply Technology-Specific Checks (← BR-1)

**Description:**
In addition to common checks, apply storage-technology-specific checks derived from
the applicable organizational standard.

**Acceptance Criteria:**
- AC-TR-5.1 (PostgreSQL):
  - All timestamp fields must use `TIMESTAMPTZ` (not `TIMESTAMP`, `DATETIME`). Flag as REQUIRED.
  - Composite primary keys must have documented justification. Flag absence of justification as SUGGESTION.
  - Indexes should be named with the pattern `idx_<table>_<column(s)>`. Flag non-conforming names as SUGGESTION.
  - UUID primary keys preferred over serial/integer. Flag serial PKs as SUGGESTION.
- AC-TR-5.2 (DynamoDB):
  - Every item type must have `entity_type` and `schema_version` fields. Flag absence as REQUIRED.
  - Partition key must be defined with access-pattern justification. Flag if undefined or unjustified as REQUIRED.
  - Sort key must be defined if hierarchical relationships exist. Flag missing SK on entities with relationships as SUGGESTION.
  - GSI count should be reasonable (flag if > 10 as SUGGESTION, > 20 as REQUIRED — DynamoDB hard limit).
  - All attribute names must be snake_case. Flag violations as REQUIRED.
  - Timestamp fields must use ISO-8601 format. Flag non-conforming timestamp fields as REQUIRED.
- AC-TR-5.3 (Redis):
  - Key schema must be documented with a naming pattern (e.g., `user:<id>:session`). Flag absence as REQUIRED.
  - TTL must be documented for all keys used for session data, tokens, or caches. Flag missing TTL as REQUIRED.
  - Data structure type (String, Hash, List, Set, Sorted Set) must be specified per key. Flag omission as REQUIRED.
- AC-TR-5.4 (OpenSearch):
  - Index mapping must define field types. Flag unmapped fields as REQUIRED.
  - Analyzer configuration should be documented for text fields used in full-text search. Flag absence as SUGGESTION.
  - Index name pattern should follow `<service>-<entity>-<env>`. Flag non-conforming names as SUGGESTION.
- AC-TR-5.5 (Browser Extension Storage):
  - All storage keys must be namespaced (prefixed by feature/module). Flag non-namespaced keys as REQUIRED.
  - Schema version field (`_version`) must be documented. Flag absence as SUGGESTION.
  - Sensitive data (tokens, credentials) must have encryption noted. Flag unencrypted sensitive fields as REQUIRED.

---

## TR-6: No Gate Artifacts or State Updates (← BR-2)

**Description:**
The skill must be a pure read-and-report tool. It must not write any file or update
any workflow state.

**Acceptance Criteria:**
- AC-TR-6.1: The SKILL.md explicitly prohibits writing to `validation/report.md`.
- AC-TR-6.2: The SKILL.md explicitly prohibits modifying `.state.json`.
- AC-TR-6.3: The SKILL.md explicitly prohibits writing any other file.
- AC-TR-6.4: The prohibition is stated both in the step instructions and in a Constraints
  section of the SKILL.md.

---

## TR-7: Worker Agent Type (← BR-1)

**Description:**
The skill must run as a worker to avoid loading standards content into the engineer's
main session. This keeps the validation focused and prevents context pollution.

**Acceptance Criteria:**
- AC-TR-7.1: `agent-type: worker` is set in the SKILL.md frontmatter.
- AC-TR-7.2: The SKILL.md states that the skill does not share context with the main
  engineer session.
- AC-TR-7.3: All file reads and checks are performed by the worker sub-agent.
