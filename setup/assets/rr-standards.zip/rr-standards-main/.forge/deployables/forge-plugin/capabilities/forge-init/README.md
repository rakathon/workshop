# forge-init

Repository initialization for the Forge AI-accelerated development framework.
Delivers the `forge:init` skill and two hooks that bring any repository into Forge
compliance from first use.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:init` | Skill | Interactive | Manual invocation |
| `inject-generation-standards.sh` | Hook | Project (plugin cache) | PreToolUse: Write, Edit |
| `forge-version-check.sh` | Hook | User (global) | SessionStart |

**`forge:init`** creates the `.forge/` directory structure appropriate to the
repository's role, registers the generation standards injection hook in
`.claude/settings.json`, and writes the CLAUDE.md forge-managed section. No flags
— version pinning is handled by the separate [forge-pin](../forge-pin/) capability.

**`inject-generation-standards.sh`** fires before every Write or Edit tool call
and injects the appropriate language guide into the model's context — coding
standards enforced at generation time without engineer invocation.

**`forge-version-check.sh`** runs at session start in every repository. Checks
whether the installed plugin meets the project minimum, emits upgrade notices,
and blocks sessions when the Productivity Engineering-defined mandatory deadline
has passed.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-pin](../forge-pin/) | Optional companion — pins the repository to a specific Forge version. Order-independent with `forge:init`. |
| forge-update _(separate branch)_ | Migrates committed configuration after a plugin update. Depends on `forge:init` having been run. |

## Implementation Location

`plugins/forge/skills/init/` — `forge:init` SKILL.md and README.md
`plugins/forge/hooks/pre-tool-use/inject-generation-standards.sh`
`plugins/forge/hooks/session-start/forge-version-check.sh`

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements (BR-1 through BR-12) |
| [requirements/technical.md](requirements/technical.md) | Technical requirements (TR-1 through TR-9) |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview and key design decisions |
| [spec/skills.md](spec/skills.md) | `forge:init` detailed design |
| [spec/hooks.md](spec/hooks.md) | Injection hook and enforcement hook detailed design |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | Relevant ADRs |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations and trust model |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
Primary program BRs addressed: BR-10, BR-15, BR-16, BR-20.
