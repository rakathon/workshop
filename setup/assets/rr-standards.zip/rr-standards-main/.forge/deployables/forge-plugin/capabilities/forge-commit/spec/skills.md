# forge:commit — Skill Specification

**Agent type:** Orchestrator
**Skill file:** `plugins/forge/skills/commit/SKILL.md`

---

## Purpose

`forge:commit` replaces raw `git commit` for implementation work. It enforces branch
convention, scope discipline, and conventional commit format, then attaches a
structured JSON git note (ADR-008) that downstream skills use for machine-readable
traceability.

---

## Trigger

Use instead of raw `git commit` whenever committing implementation work. Natural
triggers include: "commit this task", "create a commit for this implementation",
"make a forge commit", or any time the engineer is about to commit during
implementation.

---

## Step 1: Branch Convention Check (Non-Blocking)

Inspect the current git branch name:

```bash
git branch --show-current
```

**Accepted conventions:**
- `effort/<work-id>`
- `<work-id>/<short-description>`

If the branch name does not match either convention:
1. Surface the current branch name and the two accepted conventions.
2. Offer to rename: suggest `effort/<work-id>` derived from the effort ID in
   `.state.json` or `plan/tasks.md`.
3. If the engineer declines, proceed — this is a guardrail, not a gate.

If the branch name conforms, note it silently and continue.

---

## Step 2: Staged-Changes Scope Check

Inspect staged changes:

```bash
git diff --cached --name-only
git diff --cached --stat
```

**No staged changes:** Stop with:
> "No staged changes found. Stage your changes with `git add` before running
> `forge:commit`."

**Staged changes present:** Read `<effort_dir>/plan/tasks.md` (where
`<effort_dir>` = `.forge/efforts/<effort-id>/`). Compare the staged file paths
against the task descriptions to evaluate scope.

**Single-task scope:** Confirm the task context:
> "Staged changes appear to be scoped to: [task ID] — [task title]. Proceeding."

**Mixed-concern detection:** If staged files span multiple unrelated tasks:
1. List the files and identify which task each likely belongs to.
2. Explain the concern: mixed commits make `forge:verify` unreliable.
3. Suggest how to split: `git add -p` for partial staging, or stage by file.
4. Ask: "Do you want to split the staged changes, or proceed with a mixed commit?"
5. Do not proceed until the engineer responds.

---

## Step 3: Conventional Commit Message Proposal

Derive a conventional commit message:

```
type(scope): description
```

- **type**: Infer from the nature of the change — `feat` for new behavior, `fix`
  for a bug correction, `chore` for housekeeping, `docs` for documentation,
  `test` for test-only changes, `refactor` for restructuring without behavior change.
- **scope**: Use the effort ID (without the `effort/` prefix) or the primary
  directory/package name changed.
- **description**: Imperative mood, ≤72 characters total line length. Summarize
  what the commit delivers, not what it changes.

Present the proposal:
> "Proposed commit message: `feat(forge-commit): add SKILL.md and capability artifacts`
> Confirm, or provide your own message:"

Accept the engineer's alternative verbatim. Do not modify or re-format it.
Do not proceed to commit until a message is confirmed.

---

## Step 4: Create the Commit

Create the commit with the confirmed message:

```bash
git commit -m "<confirmed-message>"
```

Capture the resulting SHA:

```bash
git log -1 --format="%H"
```

Do not use `--no-verify` unless the engineer explicitly requests it.

---

## Step 5: Attach Structured Git Note

Derive the note fields:

| Field | Source |
|-------|--------|
| `workId` | `id` field in `.forge/efforts/<id>/.state.json`, or extracted from branch name |
| `taskId` | `(TASK-NNN)` at end of the matching task line in `plan/tasks.md` |
| `wave` | `[wave:N]` annotation on the task line |
| `taskType` | Type annotation (`[auto]`, `[tdd]`, `[checkpoint]`, `[manual]`) — defaults to `auto` |
| `standardsChecked` | Always `true` when attached via `forge:commit` |

**If `plan/tasks.md` does not exist or no matching task is found:** Ask the engineer
to provide the task ID manually before attaching the note.

Write the JSON to a temp file and attach:

```bash
cat > /tmp/forge-commit-note.json << 'EOF'
{
  "workId": "<effort-id>",
  "taskId": "<TASK-NNN>",
  "wave": <n>,
  "taskType": "<type>",
  "standardsChecked": true
}
EOF
git notes add -F /tmp/forge-commit-note.json HEAD
```

**Why a temp file:** Inline shell quoting of JSON (`-m '{"key": "val"}'`) is
fragile across platforms and terminals. Writing to a file sidesteps all quoting
issues and produces a reliable result.

**Why git notes matter:** The note is the machine-readable traceability link that
`forge:verify` reads to confirm implementation. Without it, verification falls back
to parsing commit messages — which is fragile and error-prone. `forge:diagnose` and
`forge:revert` also use notes to locate commits associated with specific tasks.

After attaching, confirm:
> "Git note attached. SHA: <short-sha>"

---

## Step 6: Prompt for forge:update-plan

Print unconditionally:

```
Run `forge:update-plan` to record this SHA and mark the task complete.
```

This prompt must appear after every successful commit+note sequence, regardless of
whether the engineer appears to know the next step.

---

## Output Summary

A successful `forge:commit` invocation produces:
1. A git commit with a confirmed conventional commit message.
2. A `git notes` entry on that commit containing the structured JSON payload.
3. A printed prompt to run `forge:update-plan`.

**Failure modes and their behavior:**

| Condition | Behavior |
|-----------|----------|
| No staged changes | Hard stop with instructions to `git add` |
| Non-conforming branch | Warn, offer rename, allow proceed |
| Mixed-concern staged changes | Warn, pause for input, allow proceed |
| No `plan/tasks.md` | Ask for task ID manually before attaching note |
| `git commit` fails | Surface the error; do not attempt to attach a note |
| `git notes add` fails | Surface the error; remind engineer to attach manually |
