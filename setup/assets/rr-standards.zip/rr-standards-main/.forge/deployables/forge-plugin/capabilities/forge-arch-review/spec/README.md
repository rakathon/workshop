# forge-arch-review — Architecture

This capability delivers the `forge:arch-review` skill. The skill runs as an isolated
worker sub-agent to validate discovery artifacts against organizational standards and
produce the two outputs required for the architecture review gate.

---

## Artifact Inventory

| Artifact | Type | Classification | Trigger |
|---------|------|----------------|---------|
| `forge:arch-review` | Skill | Worker (isolated sub-agent) | Manual or conversational |

---

## Worker Sub-Agent Design

`forge:arch-review` is classified as a worker — it runs as an isolated sub-agent
spawned by the orchestrating session. This design choice reflects two constraints:

**Context size:** Reading the full set of discovery artifacts (requirements, spec,
ADRs) plus every applicable standard from the standards library in the same context
window as the ongoing engineer conversation would consume the budget needed for
subsequent planning and implementation work.

**Analysis consistency:** An isolated sub-agent starts from a clean context. The
quality of standards checking does not vary based on what the engineer has discussed
in the main session before invoking the skill.

The orchestrating session is responsible for determining whether the effort is
full-tier (arch review required), assembling the correct paths to pass to the worker,
and presenting the worker's result summary to the engineer. The worker is responsible
only for reading, analyzing, and writing its two output artifacts.

---

## Output Artifacts

| File | Purpose | Consumer |
|------|---------|----------|
| `validation/report.md` | Machine-readable per-rule findings and overall result | `forge:promote` (gate check); human reviewers |
| `validation/arch-review.html` | Self-contained projection-ready meeting document | Architecture review meeting participants |

Both artifacts are written in a single commit by the worker at the end of its run.

---

## Standards Coverage

The standards the worker checks depend on what artifact directories exist in the
effort. Security and privacy checks run on every effort without exception.

```
Every effort:
  - Requirements traceability (all BRs/TRs → design coverage)
  - ADR quality (decision + rationale + alternatives)
  - Security implications (OWASP, auth model, secrets, input validation)
  - Privacy implications (PII exposure, retention, consent)

If spec/api/ exists:
  - REST API standards (standards/api/rest.md)

If spec/storage/ exists:
  - Storage standards per store type (standards/storage/)

If spec/messaging/ exists:
  - Messaging contract standards (standards/messaging/)
```

---

## Key File Locations

| File | Purpose |
|------|---------|
| `<effort-dir>/validation/report.md` | Per-rule findings; overall result header |
| `<effort-dir>/validation/arch-review.html` | Self-contained HTML for review meeting |
| `<effort-dir>/requirements/` | Business and technical requirements read by the worker |
| `<effort-dir>/spec/` | Design artifacts (api/, storage/, messaging/, ADRs) |
| `<standards-lib>/api/rest.md` | REST API standard; checked when spec/api/ exists |
| `<standards-lib>/storage/` | Storage standards; checked when spec/storage/ exists |
| `<standards-lib>/messaging/` | Messaging standards; checked when spec/messaging/ exists |

---

## Design Documents

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:arch-review` detailed skill design |
