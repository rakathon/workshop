# forge-update-plan Spec

Design artifacts for the `forge:update-plan` capability.

## Contents

| File | Description |
|------|-------------|
| [skills.md](skills.md) | Detailed skill specification — step-by-step orchestration logic |

## Design Summary

`forge:update-plan` is an orchestrator skill with eight steps: resolve effort
context, resolve the target task ID, guard against double-completion, read the
commit SHA, update `plan/tasks.md`, update `.state.json`, create a follow-up
commit, and report success.

Two design principles guide the skill:

1. **Auto-detection reduces friction** — The most common invocation is `forge:update-plan`
   with no arguments, immediately after `forge:commit`. The skill extracts the TASK-NNN
   from the recent commit subject or git notes, so the engineer does not need to retype it.

2. **SHA inline in plan/tasks.md is the traceability anchor** — Appending the SHA to the
   task line in `plan/tasks.md` creates a human-readable and machine-readable link from
   each task to its implementation evidence, enabling `forge:verify` to do reliable
   semantic matching rather than heuristic commit scanning.

## Key Design Decisions

### SHA recorded in both plan/tasks.md and .state.json

`plan/tasks.md` is the human-readable record (engineers read it). `.state.json` is the
machine-readable record (skills read it). Both are updated atomically so that the two
canonical sources of truth stay in sync.

### jira.syncStatus as a side-channel trigger

Rather than directly calling a Jira API, the skill sets a flag that a separate sync
process polls. This decouples the task-completion step from Jira connectivity — the
update succeeds even if Jira is unreachable. The sync process picks up the flag on
its next run.

### Guard check prevents idempotency issues

Checking `completedTasks` before writing prevents accidental double-completion if
the engineer runs `forge:update-plan` twice. The guard is a hard stop, not a warning,
because the follow-up commit would otherwise create a meaningless duplicate.

## Related Documentation

- [forge:commit](../../../capabilities/forge-commit/) — commits implementation work and triggers forge:update-plan
- [forge:verify](../../../capabilities/forge-verify/) — consumes completedTasks and SHA links written here
- [forge:plan](../../../capabilities/forge-plan/) — generates plan/tasks.md that forge:update-plan updates
