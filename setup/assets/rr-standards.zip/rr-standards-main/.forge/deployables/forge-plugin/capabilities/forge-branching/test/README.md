# Test Strategy — forge-branching

## Scope

| Area | What is tested |
|------|---------------|
| `enforce-branch-policy.sh` | Tool name filtering, command detection, branch detection, admin override, audit log creation, JSON diagnostic format, performance |
| `pre-push.sh` | Ref detection, block message format, exit codes, edge cases (tags, partial name matches) |

---

## Approach

### Hook Unit Tests

Both hooks are pure shell scripts with deterministic behavior given controlled inputs.
They are tested directly using shell-based test scripts with fixture files and
environment variable injection.

**enforce-branch-policy.sh test cases:**

| Test case | Setup | Expected outcome |
|-----------|-------|-----------------|
| Non-Bash tool | `CLAUDE_TOOL_NAME=Write` | Exit 0, no output, no git calls |
| Bash, non-commit command | `CLAUDE_TOOL_INPUT="git status"` | Exit 0, no output |
| Bash, `git commit`, feature branch | Current branch = `effort/foo` | Exit 0, no output |
| Bash, `git commit`, main | Current branch = `main` | Exit 2, JSON on stderr |
| Bash, `git push origin main`, main | Current branch = `main` | Exit 2, JSON on stderr |
| `FORGE_ALLOW_MAIN_COMMIT=1` | Main branch, commit command | Exit 0, audit log written |
| `FORGE_ADMIN_OP=forge:init` | Main branch, commit command | Exit 0, audit log with reason |
| Active effort in `.forge/efforts/README.md` | effort ID = `my-feature` | JSON has `activeEffort: "my-feature"` |
| No `.forge/efforts/README.md` | File absent | JSON has `activeEffort: null` |
| Detached HEAD | `git branch --show-current` returns empty | Exit 0, no output |
| Performance | `time` the hook on main | Completes in < 100ms |

**pre-push.sh test cases:**

| Test case | Stdin input | Expected outcome |
|-----------|-------------|-----------------|
| Feature branch push | `refs/heads/effort/foo` as remote ref | Exit 0 |
| Main branch push | `refs/heads/main` as remote ref | Exit 1, message on stderr |
| Master branch push | `refs/heads/master` as remote ref | Exit 1, message on stderr |
| Tag push | `refs/tags/v1.0.0` as remote ref | Exit 0 |
| Partial name match | `refs/heads/main-backup` as remote ref | Exit 0 |
| Multiple refs, one is main | Feature ref + main ref | Exit 1 |
| Empty stdin | No input | Exit 0 |

### Integration Tests

End-to-end scenarios are documented in `plugins/forge/test/integration/branch-enforcement/`.

---

## Test Plans

_None yet — to be added during implementation phase._

## Coverage Notes

`enforce-branch-policy.sh` is the higher-priority item for automated testing: it is
critical infrastructure that runs on every Bash tool call. A silently failing hook
means branch policy is unenforced and no tool will detect the gap.
