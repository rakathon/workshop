← [Decisions Index](README.md)

# ADR-002: Use Slack MCP Instead of Direct Slack REST API

**Status:** Accepted
**Date:** 2026-04-21
**Created by:** slack-support

---

## Context

`forge:slack-import` needs to fetch channel message history, thread replies, and user
display names from Slack. Two approaches were available:

1. **Direct Slack REST API** — skills call the Slack API endpoints directly using a
   bot token managed in the user's environment.
2. **Slack MCP server** — skills call Slack via the MCP server bundled with the Forge
   plugin, which mediates all API access and handles authentication.

## Decision

Use the Slack MCP server for all Slack access. Skills must not call the Slack REST
API directly.

## Rationale

| Criterion | Direct REST API | Slack MCP |
|---|---|---|
| Credential management | Skill must handle token injection, rotation, and error handling | Handled entirely by the MCP server configuration |
| Consistency with existing pattern | N/A | Matches the existing Atlassian MCP pattern already in the plugin |
| Skill complexity | Each skill must implement HTTP calls, pagination, and error handling | Skills call typed MCP tools; transport and pagination are abstracted |
| Token scope enforcement | Skills must document and validate required scopes | MCP server declares and enforces scopes at configuration time |
| Future Slack API changes | Each skill must be updated | MCP server is updated independently of skill logic |

The Forge plugin already uses this pattern for Atlassian access via the Atlassian MCP.
Using the same pattern for Slack keeps the plugin architecture consistent and avoids
introducing a second credential management model.

## Consequences

**Positive:**
- Skills are decoupled from Slack API versioning — API changes are absorbed by the MCP server
- Credential management is consistent with the existing Atlassian MCP pattern
- Skills are simpler — no HTTP client code, pagination logic, or error handling for transport failures

**Negative:**
- The Slack MCP server must be declared in the Forge plugin's `.mcp.json` as a dependency
- All three `forge:slack-*` skills must verify MCP availability as a precondition
- Users must complete MCP authorization before Slack skills can operate

## Alternatives Considered

**Direct Slack REST API:** Rejected. Introducing direct API calls would require each
skill to manage token injection, handle HTTP errors, implement pagination, and stay
current with Slack API changes — all complexity the MCP abstraction eliminates.
