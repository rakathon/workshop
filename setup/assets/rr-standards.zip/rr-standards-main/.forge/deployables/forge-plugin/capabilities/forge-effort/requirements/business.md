# Business Requirements — forge-effort

Parent deployable: [forge-plugin](../../requirements/business.md)
Parent effort BRs addressed: BR-1, BR-2, BR-4, BR-5, BR-8, BR-9, BR-11

---

## BR-1: Engineers Must Be Able to Create a Work Effort Without Knowing the Directory Taxonomy

An engineer who decides to start a new unit of work must not need to know where directories
go, what `.state.json` contains, or how the registry format works. A conversational request
("let's start working on the favorites feature") or a direct skill invocation (`forge:effort`)
must produce a correctly scaffolded effort directory, a populated `.state.json`, and a
registered entry in `.forge/efforts/README.md` — without the engineer supplying any of those details.

The taxonomy is a consequence of the effort's declared type, tier, and scope, not a decision
the engineer makes at creation time.

## BR-2: All Four Effort Subtypes Must Be Supported with Appropriate Ceremony

A bug fix and a multi-repo initiative are both work efforts, but they require fundamentally
different levels of ceremony. The system must support four production-bound subtypes (patch,
refactor, extension — with increasing discovery and planning requirements) and one
non-production-bound subtype (PoC). The ceremony for each must be proportional to its risk:

- A `patch` effort proceeds directly to implementation with no discovery required.
- A `refactor` effort has optional planning and no discovery required.
- An `extension` effort has optional discovery and optional planning.
- A `poc` effort is non-production-bound: no CI review gates, no security blocking, no
  path to direct production merge. A PoC that proves viable requires a new production effort.

Applying full-tier ceremony to a patch is not acceptable. Allowing a PoC to slide into
production without restarting as a production effort is also not acceptable. The subtype
determines which ceremony applies, and that classification is immutable after the first commit.

## BR-3: Effort State Must Survive Session Boundaries Without Information Loss

Development work spans days or weeks. A session boundary must not cause loss of:
- Which phase the effort is in
- Which artifacts have been produced
- Which decisions are open and which tasks are blocked
- What the agent was doing when the session ended

The state of a work item must be fully recoverable in a subsequent session — by the same
engineer, a different engineer, or an automated pipeline — without requiring the engineer
to reconstruct context from the directory tree or from conversation history.

An effort that can only be continued in the same session is not a work item. It is a
conversation.

Addressing parent BRs: BR-5 (state survives session boundaries).

## BR-4: Workflow State Must Be Immediately Readable at Session Start

When a session begins — whether continuing existing work or picking up a handoff — the
current state of all active efforts must be immediately available without any engineer
action. The agent must know, before the engineer says anything:

- What effort is most likely active (based on branch name or single-active-effort heuristic)
- What phase that effort is in
- Which artifacts exist and which are absent
- What the next required action is
- Whether any decisions are open that require engineer input
- Whether any pause state exists from a prior session

The overhead of reconstructing "where we are" must be zero.

Addressing parent BRs: BR-4 (immediately readable state at session start).

## BR-5: Work Item Hierarchy Must Be Visible Without Traversing Directories

Development work is hierarchical. An engineer working on a story must be able to identify
the epic and effort it serves. A team lead reviewing progress must be able to see all
in-flight work at every level.

The registry at `.forge/efforts/README.md` must present the complete active hierarchy in a single
view. Effort creation must update this registry automatically. The hierarchy is a
first-class concern at creation time — it must not require reconstruction from directory
structure after the fact.

Addressing parent BRs: BR-8 (work item hierarchy readable without traversing directories).

## BR-6: Workflow Artifacts Must Serve Both Human Readers and AI Agents

Every artifact the effort system produces serves two audiences. Engineers use requirements,
specifications, and state files for documentation, design review, and onboarding. AI agents
use them for navigation, constraint loading, and phase-gate decisions.

The `.state.json` must be machine-readable without transformation. The registry must be
human-readable without tooling. Artifacts produced during an effort must be structured so
that both an engineer and a subsequent agent can consume them independently, without requiring
translation or supplemental context.

Addressing parent BRs: BR-9 (artifacts serve both human readers and AI agents).

## BR-7: The Workflow Must Work Conversationally — No Explicit Commands Required

The `forge:effort`, `forge:status`, `forge:pause`, and `forge:resume` skills must be
optional acceleration paths, not required ceremonies. An engineer who never invokes any
Forge command must:

- Get a new effort scaffolded when they describe scope to Claude
- Get status reported when they ask "where are we?"
- Get pause state persisted when they say "let's pick this up tomorrow"
- Get state restored when they start a new session
- Get state updated automatically as they produce artifacts in conversation

An engineer who uses explicit skill invocations must get identical outcomes. The skills
exist for precision and automation, not as the only path to correct behavior.

Addressing parent BRs: BR-11 (Forge must not depend on engineers using specific commands).

---

Success criteria: [success-criteria.md](success-criteria.md)
