# forge-verify

Two capabilities delivered under this heading:

1. **`forge:verify` skill** — final implementation verification before PR. A one-pass
   semantic check that the complete implementation delivers the effort's stated goals.
   Runs after all tasks are complete, before `forge:promote` to verification phase.

2. **Implementation quality loop contract** — a shared behavioral contract executed by
   all `forge:build-*` implementation skills. Defines the per-task loop: implement →
   lint → validate against spec → test → commit or escalate.

These are distinct in scope and timing. See [spec/README.md](spec/README.md) for the
design rationale.

## What Each Delivers

### forge:verify

| Artifact | Type | Trigger |
|---------|------|---------|
| `forge:verify` skill | Worker (isolated sub-agent) | Manual or on `forge:promote` |
| `verification/report.md` | Output artifact | Written by each `forge:verify` run |

`forge:verify` reads all discovery artifacts (requirements, spec, ADRs) and the
implementation code for every completed task. It checks that each BR and TR has real
implementation evidence — not stubs or missing wiring — and that the implementation
does not contradict any ADR. It produces a structured PASS/FAIL report with specific
code locations for any gaps.

`forge:promote` advancing to the verification phase requires `Result: PASS` in
`verification/report.md`.

### Quality Loop Contract

| Artifact | Type | Consumed by |
|---------|------|-------------|
| `build-contract` | Shared skill contract | All `forge:build-*` skills |

The quality loop runs inside each `forge:build-*` skill, once per task. It ensures
that a task is not committed and not marked complete until lint, spec validation, and
tests all pass — or until the iteration limit is reached and the state is escalated
to the engineer. The contract is defined once and referenced by all implementation
skills for consistency.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-plan](../forge-plan/) | Provides `plan/tasks.md` — the acceptance criteria and task list that both the quality loop and `forge:verify` read |
| [forge-promote](../forge-promote/) | `forge:promote` requires a PASS `verification/report.md` to advance from implementation to verification phase |
| [forge-graduate](../forge-graduate/) | `verification/report.md` is included in the graduation bundle as evidence of implementation quality |

## Implementation Location

`plugins/forge/skills/verify/` — `forge:verify` SKILL.md and README.md
`plugins/forge/skills/build-contract/` — quality loop contract SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements (BR-13, BR-14) |
| [requirements/technical.md](requirements/technical.md) | Technical requirements — forge:verify skill and quality loop contract |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Design overview and key decisions |
| [spec/skills.md](spec/skills.md) | forge:verify design + quality loop contract |
| [spec/arch-decisions/](spec/arch-decisions/) | ADRs scoped to this capability |
| [test/README.md](test/README.md) | Test strategy and acceptance tests |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
