# Business Requirements — forge:validate-messaging

Parent effort: [spec-driven-development](../../spec-driven-development/)
Deployable: [forge-plugin](../../../deployables/forge-plugin/)

---

## BR-1: Engineers Need Immediate Feedback on Messaging Contract Compliance During Authoring

When engineers author event and message contracts during `forge:spec-messaging`, they
need immediate inline feedback on whether the contracts comply with the organization's
messaging standards — without waiting for a full `forge:validate` gate run.

Missing producer/consumer identification, undefined ordering guarantees, and absent
idempotency approaches are common defects that are expensive to fix after implementation
has begun. Each defect caught at contract authoring time takes seconds to correct; the
same defect caught after implementation requires coordinated rework across producer and
consumer implementations.

**Acceptance criteria:**
- Running `forge:validate-messaging` on an effort directory reports all non-compliant
  fields for each contract in `spec/messaging/` within a single session turn.
- The report appears inline in the conversation — no file is written, no state is updated.
- All checks from the organizational messaging standards are applied, not a subset.

---

## BR-2: The Validator Must Not Write Gate Artifacts or Update Workflow State

`forge:validate-messaging` is an inline editing aid, not a phase gate. Phase gates
are the responsibility of `forge:validate`. Writing to `validation/report.md` or
updating `.state.json` would incorrectly signal that a gate check has passed,
misleading the workflow state machine and potentially allowing gate bypass.

**Acceptance criteria:**
- After running `forge:validate-messaging`, no files are created or modified in the
  effort directory.
- `.state.json` is not updated.
- `validation/report.md` is not created or overwritten.
- The skill output is confined entirely to the conversation session.

---

## BR-3: Versioning Strategy and Schema Completeness Defects Must Be Surfaced Explicitly

Versioning and schema completeness are the highest-risk messaging contract defects.
A contract without a declared version allows consumers to be silently broken when
the schema evolves. A contract with incomplete schema (untyped fields, missing
envelope fields) cannot be used as an implementation contract by the consumer team.

These defects are not optional warnings — they must appear as REQUIRED findings that
the engineer must address before the contract is usable for implementation.

**Acceptance criteria:**
- Contracts missing a schema version are flagged as REQUIRED, not as suggestions.
- Contracts missing a breaking change policy are flagged as REQUIRED.
- Contracts with untyped or incomplete schema fields are flagged as REQUIRED.
- The summary line distinguishes REQUIRED findings from SUGGESTION findings.

---

Success criteria: See validation/report.md after discovery approval.
