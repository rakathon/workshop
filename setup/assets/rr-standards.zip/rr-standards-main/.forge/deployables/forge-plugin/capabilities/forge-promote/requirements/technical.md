# Technical Requirements — forge-promote

## TR-1: Active Effort Detected from Context
Identifies the active effort from branch name or .forge/efforts/README.md. Falls back to
asking only when ambiguous.

## TR-2: Advisory Readiness Checks (Non-Blocking)
Reports present/absent artifacts for the current phase transition. Never blocks
promotion on missing artifacts — the engineer decides to proceed.

## TR-3: Single Yes/No Confirmation
One confirmation step. No typed string required. Engineer says yes or no.

## TR-4: .state.json Updated with Approval Record
Sets `phases.<phase>.status = "approved"`, `approvedAt`, and `approvedBy`. Advances
`currentPhase` to `targetPhase`. For multi-step gaps, applies one approval per phase
in sequence. Creates one checkpoint commit per phase approved.

## TR-5: Artifacts Not Locked
Promotion does not restrict writes to any directory. Per ADR-031, phase gate
enforcement does not exist in Forge v1.

## TR-6: Only for Formal Efforts
Gracefully no-ops when there is no active Forge effort in context.

## TR-7: --target Argument for Multi-Step Advancement
`forge:promote` accepts an optional `--target <phase>` argument. When provided:
- If `targetPhase` is not in the phase sequence: stop with an error listing valid phases.
- If `targetPhase` is at or before `currentPhase`: exit silently (no-op). This is
  the expected outcome when calling skills invoke `--target` and the effort has
  already advanced past the target.
- Otherwise: compute the gap (all phases from `currentPhase` up to but not including
  `targetPhase`) and advance through each in sequence.

When called without `--target`, advances exactly one phase (original behavior).

## TR-8: Advisory Readiness Checks (Non-Blocking Per ADR-031)
All readiness checks are informational. No artifact absence blocks promotion.
The engineer sees what is present and what is missing, then decides whether to proceed.

**Discovery exit advisory:**
- `requirements/business.md` — present or absent
- `requirements/technical.md` — present or absent
- `spec/` artifact types present
- **Validation gate:** if `validation/report.md` is absent, offer a yes/no/skip prompt
  to run `forge:validate` inline before advancing. If the engineer skips, note the
  absence and continue.

**Planning exit advisory:**
- `plan/tasks.md` — present or absent; task count if present

**Implementation exit advisory:**
- Completed vs. remaining task count from `plan/tasks.md`

## TR-9: Phase Sentinel Integration
Other skills (`forge:plan`, `forge:commit`, `forge:verify`) call
`forge:promote --target <phase>` at natural workflow transition points. `forge:promote`
must handle these calls correctly:
- Silent no-op when target ≤ current (effort already advanced past the expected phase)
- Normal advisory + confirmation flow when target > current
The calling skill behavior is documented in each respective capability.
