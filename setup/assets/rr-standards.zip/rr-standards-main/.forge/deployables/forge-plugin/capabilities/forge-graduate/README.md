# forge-graduate

Effort graduation for the Forge AI-accelerated development framework.
Delivers the `forge:graduate` skill, which promotes a completed effort's artifacts
to the canonical documentation for the associated deployable or product.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:graduate` | Skill | Worker (isolated sub-agent) | Invoked by orchestrator after QA sign-off |

**`forge:graduate`** reads the completed effort's requirements, specifications, and
ADR references, then merges them into the associated deployable's canonical
documentation (updating existing sections, not appending new sections alongside old
ones). It records the effort ID as provenance metadata in each updated document,
surfaces any post-approval modifications for reconciliation, updates `.state.json`
with the graduation record, and removes the effort from the active registry.

Graduation is the formal handoff from ephemeral work-in-progress to authoritative
documentation. After graduation, the effort directory is a permanent historical record;
the canonical documentation in the deployable directory becomes the authoritative
reference for what the deployable is.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-effort](../forge-effort/) | Provides the effort being graduated |
| [forge-verify](../forge-verify/) | Verification must complete before graduation |
| [forge-promote](../forge-promote/) | Effort must advance through all required phases before graduation |

## Implementation Location

`plugins/forge/skills/graduate/` — `forge:graduate` SKILL.md and README.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements (BR-1 through BR-5) |
| [requirements/technical.md](requirements/technical.md) | Technical requirements (TR-1 through TR-12) |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview and key design decisions |
| [spec/skills.md](spec/skills.md) | `forge:graduate` detailed design |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | Relevant ADRs |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
Primary program BRs addressed: BR-7, BR-12.
