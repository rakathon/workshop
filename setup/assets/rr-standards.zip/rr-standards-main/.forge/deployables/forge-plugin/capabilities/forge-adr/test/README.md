# Test Strategy — forge-adr

## Scope

| Area | What is tested |
|------|---------------|
| `forge:adr` skill | ADR numbering algorithm (sequential, gap-filling, empty directory), filename slug derivation, template population from explicit arguments, template population from conversation context, `.state.json` update, index file creation and update, commit message format, active effort identification |

---

## Approach

### Skill Behavioral Tests

`forge:adr` is tested using the with/without-context eval methodology from rr-standards.
An `.evals.json` companion file alongside `SKILL.md` defines the evaluation cases.

The eval set must cover the main behavioral rules with ≥ 5 compliant and 5 non-compliant
examples. `rr-standards:validate --active` provides the harness.

### Unit Tests — ADR Numbering Algorithm

The numbering algorithm is deterministic and must be tested independently of the full
skill flow:

| Test case | Existing ADRs | Expected next number |
|-----------|--------------|---------------------|
| Empty directory | None | 001 |
| Contiguous from 001 | ADR-001, ADR-002, ADR-003 | 004 |
| Gap at start | ADR-002, ADR-003 | 001 |
| Gap in middle | ADR-001, ADR-003 | 002 |
| Gap at end (non-contiguous) | ADR-001, ADR-002, ADR-005 | 003 |
| Single ADR | ADR-001 | 002 |
| Non-ADR files present | README.md, ADR-001 | 002 |
| Mixed-format filenames | ADR-001, not-an-adr.md | 002 |

### Integration Tests

End-to-end tests covering the full ADR creation lifecycle on a temporary git repository:

1. Empty effort directory → `forge:adr` → verify ADR-001 created with all four
   sections; `.state.json` `adrsCreated` contains `["ADR-001-<slug>"]`; index created
2. Effort with ADR-001 and ADR-003 → `forge:adr` → verify ADR-002 created (gap-filling)
3. Explicit invocation with `title` and `decision` → verify those values appear in the
   correct sections; verify Context and Consequences are derived and non-empty
4. Explicit invocation with `title` only → verify Decision derived from context; all
   four sections present
5. Conversational trigger "let's use Redis for the cache layer" → verify ADR created
   with a title derived from the decision statement; no explicit skill invocation
6. Multiple decisions in one exchange → verify one ADR per decision; sequential numbers
7. `forge:adr` run twice in the same session → verify correct sequential numbering;
   no collision; both ADRs present in index and `.state.json`

---

## Test Plans

_None yet — to be added during implementation phase._

## Coverage Notes

The numbering algorithm is the highest-priority unit test target — incorrect numbering
creates ADR filename collisions or gaps that corrupt the series. Skill behavioral tests
cover the full template-population flow. Integration tests cover the commit and state
update consistency requirement.
