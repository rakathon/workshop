# .state.json Schema Reference

## Overview

Every effort directory contains a `.state.json` file at its root:

```
.forge/efforts/<effort-id>/.state.json
```

This file is the machine-readable state for a single work item. Hooks read it to provide
phase context. Skills write it when phases advance, artifacts are created, or decisions
are recorded. The file must be committed atomically with the artifact or operation that
triggers any change.

All keys must be sorted alphabetically at every nesting level. Arrays must use
one-item-per-line formatting. Consistent 2-space indentation and no trailing commas
are required. This formatting discipline makes concurrent updates from multiple
engineers merge cleanly (see TR-13).

---

## Base Fields

These fields are defined by the forge-plugin parent spec and are present in every
`.state.json` regardless of effort subtype.

### id
- **Type:** string
- **Example:** `"forge-workflow"`
- **Set by:** forge:effort at creation
- **Immutable:** yes
- **Description:** Unique identifier for the effort within the repository. Used as the
  directory name under `.forge/efforts/` and as the scope identifier in commit messages
  (e.g., `chore(forge-workflow): advance to planning`).

### title
- **Type:** string
- **Example:** `"Forge Workflow"`
- **Set by:** forge:effort at creation
- **Mutable:** yes — can be updated if the effort scope is renamed
- **Description:** Human-readable name for the effort. Appears in `.forge/efforts/README.md`
  and in session-start context output.

### type
- **Type:** string
- **Values:** `"program"` | `"initiative"` | `"epic"` | `"story"` | `"task"` | `"spike"`
- **Set by:** forge:effort at creation
- **Immutable:** yes
- **Description:** Work item type. Together with `tier`, determines which phases are
  required. Programs, initiatives, and epics are always full-tier. Stories, tasks, and
  spikes may be lightweight or full-tier depending on scope.

### tier
- **Type:** string
- **Values:** `"full"` | `"lightweight"`
- **Set by:** forge:effort at creation
- **Immutable:** yes
- **Description:** Determines the required phase set. Full-tier requires discovery,
  validation, planning, implementation, verification, review, and QA. Lightweight-tier
  is a reduced set determined by `subtype`.

### risk
- **Type:** string
- **Values:** `"R1"` | `"R2"` | `"R3"` | `"R4"`
- **Set by:** forge:effort at creation
- **Mutable:** yes — may be updated if scope changes meaningfully
- **Description:** Risk classification. R1 (critical) through R4 (low). Drives which
  phases within the full-tier set are mandatory vs. optional (e.g., QA is required for
  R1/R2, risk-dependent for R3, optional for R4).

### parentId
- **Type:** string | null
- **Example:** `"forge-plugin"` or `"repo:org/efforts-repo/auth-platform-initiative"`
- **Set by:** forge:effort at creation
- **Mutable:** no — hierarchy is set at creation
- **Description:** ID of the parent effort. Bare IDs reference a parent in the same
  repository. The `repo:`-prefixed form references a parent in a different repository
  (cross-repo hierarchy). `null` for top-level efforts.

### childIds
- **Type:** array of strings
- **Example:** `["payments-backend", "payments-ios"]`
- **Set by:** forge:effort when a child effort is created
- **Description:** IDs of direct child efforts. Same `repo:` prefix convention as
  `parentId` for cross-repo children. Updated when a new child effort is scaffolded.

### deployables
- **Type:** array of strings
- **Example:** `["forge-plugin"]`
- **Set by:** forge:effort at creation; may be updated during discovery
- **Description:** Technical deployables this effort contributes to. These identifiers
  correspond to directories under `.forge/deployables/`. Empty at creation is valid;
  updated as contributing deployables are identified during discovery.

### timebox
- **Type:** string (ISO-8601 date) | null
- **Example:** `"2026-04-15"`
- **Set by:** forge:effort at creation or during planning
- **Description:** Target completion date. Informational — not enforced by hooks.
  `null` for open-ended efforts.

### currentPhase
- **Type:** string
- **Values:** `"discovery"` | `"validation"` | `"planning"` | `"implementation"` |
  `"verification"` | `"review"` | `"qa"` | `"deployment"` | `"operations"` |
  `"investigation"` | `"findings"`
- **Set by:** forge:promote or forge:graduate when a phase transition occurs
- **Description:** The effort's current active phase. Phase transitions are committed
  atomically with the operation that triggers them.

### Phase Structure

Which phases are present in `phases` depends on the effort's tier and type.

**Full-tier efforts** (programs, initiatives, epics, and any story/task/spike marked
`tier: "full"`) progress through these phases in order:

| Phase | `currentPhase` value | Purpose |
|-------|----------------------|---------|
| Discovery | `"discovery"` | Requirements, spec artifacts, ADRs |
| Validation | `"validation"` | Standards compliance review and arch sign-off |
| Planning | `"planning"` | Implementation task breakdown |
| Implementation | `"implementation"` | Code, tests, and automation |
| Verification | `"verification"` | Automated and manual verification against acceptance criteria |
| Review | `"review"` | Engineering / tech-lead review of completed work |
| QA | `"qa"` | QA sign-off (required for R1/R2; risk-dependent for R3; optional for R4) |
| Deployment | `"deployment"` | Release and rollout |
| Operations | `"operations"` | Post-release steady-state monitoring |

Valid `currentPhase` values for full-tier efforts:
`"discovery"`, `"validation"`, `"planning"`, `"implementation"`, `"verification"`,
`"review"`, `"qa"`, `"deployment"`, `"operations"`

**Spike efforts** use a simplified two-phase structure:

| Phase | `currentPhase` value | Purpose |
|-------|----------------------|---------|
| Investigation | `"investigation"` | Time-boxed research and experimentation |
| Findings | `"findings"` | Documenting conclusions and recommendations |

Valid `currentPhase` values for spikes: `"investigation"`, `"findings"`

**Lightweight-tier efforts** (`tier: "lightweight"`) use a reduced phase set determined
by their `subtype` (see subtype field documentation). Not all phases are required;
which phases appear in `phases` depends on the subtype.

---

### phases
- **Type:** object
- **Description:** Per-phase state tracking. Each phase that has been started has a
  nested object. Phases that have not been started are present with
  `"status": "not_started"`. See per-phase structure below.

#### phases.discovery
```json
{
  "status": "not_started | in_progress | approved",
  "approvedBy": null,
  "approvedAt": null,
  "artifacts": {
    "requirements": {
      "business": "absent | draft | present",
      "technical": "absent | draft | present"
    },
    "spec": {
      "api": "absent | draft | present",
      "messaging": "absent | draft | present",
      "storage": "absent | draft | present"
    },
    "adrsCreated": []
  }
}
```

#### phases.validation
```json
{
  "status": "not_started | in_progress | passed | passed_with_concerns | failed",
  "artifacts": ["validation/report.md"]
}
```

#### phases.planning
```json
{
  "status": "not_started | in_progress | complete",
  "artifacts": ["plan/tasks.md"]
}
```

#### phases.implementation
```json
{
  "status": "not_started | in_progress | complete",
  "checkpoint": {
    "activeSkill": null,
    "lastCompletedStep": null,
    "updatedAt": null
  },
  "completedTasks": [],
  "remainingTasks": []
}
```

#### phases.verification
```json
{
  "status": "not_started | in_progress | passed | passed_with_gaps",
  "artifacts": ["verification/report.md"]
}
```

---

## forge-workflow Extensions

The forge-workflow effort adds the following fields to the base schema. Every effort
managed by the forge-workflow capability will carry these fields; unset fields use
their documented defaults.

### subtype
- **Type:** string | null
- **Values:** `"patch"` | `"refactor"` | `"extension"` | `"poc"` | `null`
- **Default:** `null`
- **Set by:** forge:effort at creation (prompted during initialization)
- **Immutable:** yes — cannot change after the effort's first commit
- **Description:** Lightweight effort classification (TR-0). Determines which phases are
  required for lightweight-tier efforts:
  - `patch` — no discovery, no arch review, no planning, no QA required
  - `refactor` — no discovery, no arch review, planning optional, no QA required
  - `extension` — discovery optional, no arch review, planning optional, QA risk-dependent
  - `poc` — no discovery, no arch review, no planning, CI review optional/non-blocking,
    no QA required; sets `productionBound: false`
  - `null` — full-tier work item (program, initiative, or epic); not a lightweight subtype

### productionBound
- **Type:** boolean
- **Default:** `true`
- **Set by:** forge:effort at creation
- **Immutable:** yes — must never be changed from `false` to `true` on an existing effort
- **Description:** Whether this effort's output is subject to production compliance
  requirements (TR-0). `false` only for `poc` subtype. When `false`:
  - `forge:review` is not registered as a required PR status check for this effort
  - Security and privacy validation failures are non-blocking
  If a PoC proves viable and the team wants to ship, a new production-tier effort must
  be created; PoC code is never directly promoted. The PoC records the new effort's ID
  in `spawnedWorkItems`.

### spawnedWorkItems
- **Type:** array of strings
- **Default:** `[]`
- **Set by:** forge:effort when a production follow-on is created from a PoC
- **Description:** IDs of production efforts spawned from this PoC after it proved
  its concept (TR-0). Only meaningful when `subtype` is `"poc"`. Each entry is the
  `id` of the spawned effort, using the `repo:` prefix convention if the spawned effort
  lives in a different repository.

### coordinationRef
- **Type:** object | null
- **Default:** `null`
- **Set by:** forge:project when a coordination effort projects down to this local
  sub-effort
- **Immutable:** yes — set once at projection time
- **Description:** Cross-repository reference back to the coordination effort that
  spawned this local sub-effort (TR-4). Contains sufficient information to locate and
  retrieve coordination artifacts without human interpretation. `null` for standalone
  efforts not part of a multi-repo coordination.

#### coordinationRef fields

| Field | Type | Description |
|-------|------|-------------|
| `repo` | string | Coordination repository identifier in `org/repo` form |
| `effortId` | string | ID of the coordination effort in the remote repository |
| `branch` | string | Git ref used to resolve the coordination effort (branch name or commit SHA) |
| `commitSha` | string \| null | Commit SHA at which the projection was taken; `null` until the first `forge:project` run |
| `projectedAt` | string \| null | ISO-8601 timestamp of the last projection; `null` until first projection |
| `projections` | array | One entry per materialized file projected from the coordination repo |

#### coordinationRef.projections array entries

Each entry records provenance for one materialized projection file:

| Field | Type | Description |
|-------|------|-------------|
| `source` | string | Path to the source artifact in the coordination repository |
| `local` | string | Path to the materialized file in this local repository |
| `sourceSha` | string \| null | Commit SHA of the source artifact at projection time; used for staleness detection (TR-14) |

The `sourceSha` enables the SessionStart hook to compare against the coordination
repository's current HEAD and warn when a local projection is stale (TR-11, TR-14).

### upstreamProposals
- **Type:** array of objects
- **Default:** `[]`
- **Set by:** forge:upstream when a local discovery reveals a needed change to a
  coordination-level artifact (TR-6)
- **Description:** Pending proposed changes to coordination-level artifacts. A local
  effort must not silently diverge from the coordination truth — proposed changes must
  be surfaced as explicit proposals and tracked until resolved.

#### upstreamProposals array entries

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Sequential identifier, e.g., `"001"` |
| `file` | string | Path to the proposal document in this local effort (e.g., `"upstream-proposals/001-add-store-id-field.md"`) |
| `prUrl` | string \| null | URL of the PR opened against the coordination repository; `null` until PR is created |
| `status` | string | `"proposed"` \| `"merged"` \| `"rejected"` |
| `targetFile` | string | Path to the artifact in the coordination repository that this proposal modifies |
| `targetRepo` | string | Coordination repository identifier in `org/repo` form |

Local work may proceed optimistically with the proposed change reflected in the local
projection, but the effort's state must show that an unresolved upstream change exists
until the coordination-level PR is merged.

### openDecisions
- **Type:** array of objects
- **Default:** `[]`
- **Set by:** forge:effort or any skill when a decision point is reached that requires
  external input or explicit resolution before a task can proceed (TR-1)
- **Description:** Unresolved decisions that are blocking or may block implementation
  tasks. Surfaced in session-start context output (TR-11) so the agent always knows
  what is waiting for a human decision.

#### openDecisions array entries

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Sequential identifier in `OD-NNN` format, e.g., `"OD-001"` |
| `description` | string | What needs to be decided and why it matters |
| `blockedTask` | string \| null | Task ID that cannot proceed until this decision is resolved; `null` if no specific task is blocked |
| `raisedAt` | string | ISO-8601 timestamp when the decision was recorded |

When a decision is resolved, the entry is removed from `openDecisions` and the
reasoning is recorded in the relevant ADR or task note.

### phases.\*.postApprovalModifications
- **Type:** array of objects (per phase)
- **Default:** `[]` on each phase object
- **Set by:** PostToolUse hook `update-workflow-state.sh` when an artifact that was
  produced during an approved phase is subsequently modified (TR-9)
- **Description:** Tracks modifications to previously-approved artifacts. Each phase
  object may carry this array. For example, if a requirements file produced during
  discovery is modified during implementation, the `discovery` phase object records the
  modification.

This record serves two purposes:
1. **Review visibility** — Reviewers can see which approved artifacts changed during
   implementation and assess whether the changes are consistent with the overall design.
2. **Graduation reconciliation** — Before promoting artifacts to deployable canonical
   docs, all post-approval modifications must be reviewed (TR-12). The graduated
   artifact must represent the final coherent state, not the originally-approved state
   with unreviewed patches.

No formal reopen process is required; the modification is permitted, recorded, and
reconciled at graduation.

#### postApprovalModifications array entries

| Field | Type | Description |
|-------|------|-------------|
| `file` | string | Relative path to the modified artifact within the effort directory |
| `modifiedAt` | string | ISO-8601 timestamp of the modification |
| `modifiedDuringPhase` | string | The `currentPhase` value at the time the modification occurred |

### graduation
- **Type:** object
- **Default:** `{ "graduated": false, "graduatedAt": null, "graduatedTo": [] }`
- **Set by:** forge:graduate when an effort is closed and its artifacts are promoted
  to canonical documentation (TR-12)
- **Description:** Graduation tracking. Graduation is a distinct, auditable operation
  that occurs after QA sign-off — not automatically at effort close. The graduated
  artifacts become part of the deployable's canonical documentation and the effort is
  removed from the active registry.

#### graduation fields

| Field | Type | Description |
|-------|------|-------------|
| `graduated` | boolean | `false` until the graduation operation completes |
| `graduatedAt` | string \| null | ISO-8601 timestamp of the graduation commit; `null` until graduated |
| `graduatedTo` | array of strings | Canonical directories the effort's artifacts were merged into (e.g., `["deployables/forge-plugin", "products/forge"]`); empty until graduated |

---

## Full Example

A full-tier initiative mid-implementation with a coordination reference, some
post-approval modifications, and an open decision:

```json
{
  "childIds": [
    "payments-backend",
    "payments-ios"
  ],
  "coordinationRef": {
    "branch": "main",
    "commitSha": "a3f9b12c4d5e6f7a8b9c0d1e2f3a4b5c",
    "effortId": "payments-initiative",
    "projectedAt": "2026-03-15T09:00:00Z",
    "projections": [
      {
        "local": ".forge/efforts/payments-backend/spec/api/payments-api-projection.md",
        "source": ".forge/efforts/payments-initiative/spec/api/payments-api.md",
        "sourceSha": "b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6"
      },
      {
        "local": ".forge/efforts/payments-backend/spec/requirements-projection.md",
        "source": ".forge/efforts/payments-initiative/requirements/technical.md",
        "sourceSha": "c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7"
      }
    ],
    "repo": "org/platform-repo"
  },
  "currentPhase": "implementation",
  "deployables": [
    "payments-backend"
  ],
  "graduation": {
    "graduated": false,
    "graduatedAt": null,
    "graduatedTo": []
  },
  "id": "payments-backend-epic",
  "openDecisions": [
    {
      "blockedTask": "TASK-009",
      "description": "JWT claim name for member ID — confirm with auth team before implementing token validation",
      "id": "OD-001",
      "raisedAt": "2026-03-20T11:30:00Z"
    }
  ],
  "parentId": "repo:org/platform-repo/payments-initiative",
  "phases": {
    "discovery": {
      "approvedAt": "2026-03-10T16:00:00Z",
      "approvedBy": "eng-lead@example.com",
      "artifacts": {
        "adrsCreated": [
          "ADR-001-jwt-token-validation.md",
          "ADR-002-payment-idempotency-key.md"
        ],
        "requirements": {
          "business": "present",
          "technical": "present"
        },
        "spec": {
          "api": "present",
          "messaging": "absent",
          "storage": "present"
        }
      },
      "postApprovalModifications": [
        {
          "file": "requirements/technical.md",
          "modifiedAt": "2026-03-22T14:30:00Z",
          "modifiedDuringPhase": "implementation"
        }
      ],
      "status": "approved"
    },
    "implementation": {
      "checkpoint": {
        "activeSkill": null,
        "lastCompletedStep": null,
        "updatedAt": null
      },
      "completedTasks": [
        {
          "commitSha": "a3f9b12",
          "id": "TASK-001",
          "type": "auto",
          "wave": 1
        },
        {
          "commitSha": "d4e5f67",
          "id": "TASK-002",
          "type": "tdd",
          "wave": 1
        }
      ],
      "postApprovalModifications": [],
      "remainingTasks": [
        "TASK-003",
        "TASK-004",
        "TASK-009"
      ],
      "status": "in_progress"
    },
    "planning": {
      "artifacts": [
        "plan/tasks.md"
      ],
      "postApprovalModifications": [],
      "status": "complete"
    },
    "validation": {
      "artifacts": [
        "validation/report.md",
        "validation/arch-review.html"
      ],
      "status": "passed"
    }
  },
  "productionBound": true,
  "risk": "R2",
  "spawnedWorkItems": [],
  "subtype": null,
  "timebox": "2026-04-30",
  "tier": "full",
  "title": "Payments Backend Epic",
  "type": "epic",
  "upstreamProposals": [
    {
      "file": "upstream-proposals/001-add-payment-method-field.md",
      "id": "001",
      "prUrl": "https://github.com/org/platform-repo/pull/42",
      "status": "proposed",
      "targetFile": ".forge/efforts/payments-initiative/spec/api/payments-api.md",
      "targetRepo": "org/platform-repo"
    }
  ]
}
```
