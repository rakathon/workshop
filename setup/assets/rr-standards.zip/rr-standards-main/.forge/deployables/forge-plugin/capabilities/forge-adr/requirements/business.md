# Business Requirements — forge-adr

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-9, BR-11

---

## BR-1: Architectural Decisions Made During Conversation Must Not Be Lost

When an engineer and an AI agent work through a design problem, decisions emerge
naturally in conversation: "we'll use PostgreSQL because of better transactional
guarantees," "let's go with the event-sourcing approach to support audit requirements."
These decisions carry context — the reasoning, the alternatives considered — that is
often richer at the moment of decision than it will be when the engineer later tries
to reconstruct it from code or a vague memory of the discussion.

Without a mechanism to capture decisions at the moment they are made, that reasoning
disappears when the session ends. A future engineer, or a future AI agent resuming
the work, has no record of why a design choice was made — only that it was made.

`forge:adr` must capture architectural decisions at the moment they arise, before
context is lost, without interrupting the engineer's flow.

## BR-2: ADR Capture Must Work Through Natural Conversation Without Explicit Commands

Engineers must not need to know that `forge:adr` exists to benefit from it. When an
engineer makes a statement of decision — "we've decided to use DynamoDB for session
storage," "let's go with the read-through caching pattern" — the agent must recognize
the decision and capture it automatically.

Engineers who want to explicitly invoke `forge:adr` must be able to do so. Direct
invocation is appropriate for power users and for decisions that the engineer wants to
ensure are captured precisely. But explicit invocation must not be required for the
workflow to function correctly.

## BR-3: ADRs Must Serve Both Human Readers and AI Agents

Every ADR created by `forge:adr` serves two audiences. Human readers — engineers,
architects, leads — use ADRs to understand why design choices were made, to onboard
onto in-progress work, and to evaluate whether past decisions are still valid. AI
agents use ADRs as navigation context when loading effort state, as constraints on
future design choices, and as decision history during architecture review.

An ADR that is readable by humans but structurally ambiguous to agents fails half its
purpose. An ADR that is machine-parseable but opaque to humans fails the other half.
The structure of every ADR must make it useful to both audiences independently.

## BR-4: ADR Numbering Must Be Consistent and Sequential

ADRs within an effort are referenced by number in other documents, in architecture
reviews, and in conversation. ADR-003 must always refer to the same decision. If
numbering is inconsistent — numbers skipped, numbers reused, sequences that differ
across effort subdirectories — the references break and the ADR series loses
navigability.

`forge:adr` must maintain a consistent sequential numbering scheme within each ADR
series (per effort, deployable, or repository). Gap-filling (assigning the lowest
available number rather than always incrementing the highest) must be deterministic
and correct. The engineer must never need to determine the next ADR number manually.

## BR-6: Duplicate Decisions Must Not Silently Accumulate in the ADR Record

An ADR record is only as useful as it is non-redundant. If the same architectural
decision is recorded twice — in slightly different words, across separate sessions, or
in different scopes — the record becomes contradictory and confusing. A future engineer
or AI agent reading the ADR index cannot tell which record is authoritative, whether one
supersedes the other, or whether both apply simultaneously.

The problem is especially acute across scope boundaries. A decision captured during an
active effort may already exist in the associated deployable's canonical documentation.
Recording it again creates two authoritative sources for the same choice, with no clear
relationship between them.

`forge:adr` must check for semantically similar existing ADRs before writing a new one.
It must distinguish between two distinct problems:

- **Duplicate**: the same decision recorded twice in different words — the new ADR is
  redundant and should be cancelled.
- **Conflict**: a new decision that contradicts an existing one — the existing ADR should
  be marked `Superseded` and the ADR index updated to reflect the change.

The engineer must actively confirm each case before `forge:adr` writes or modifies
any file.

## BR-5: ADR Capture Must Not Interrupt the Engineer's Flow

The primary value of capturing a decision is doing it at the moment of clarity, before
the conversation moves on. A capture mechanism that requires the engineer to interrupt
their work, switch modes, or provide detailed structured input defeats its purpose —
the engineer will skip it and the decision will be lost.

`forge:adr` must operate without requiring the engineer to provide more than the
subject of the decision. If invoked conversationally, the agent must derive the subject,
context, and rationale from the surrounding conversation. If invoked explicitly, the
engineer may provide a title and decision text, but neither should be required for
a useful ADR to be produced.
