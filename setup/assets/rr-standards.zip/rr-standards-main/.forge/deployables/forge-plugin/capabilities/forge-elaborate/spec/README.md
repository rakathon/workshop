# Spec — forge-elaborate

| Artifact | Description |
|----------|-------------|
| [skills.md](skills.md) | Full skill interface spec: steps, interaction model, artifact writes, no-effort mode |
| [arch-decisions/ADR-001](arch-decisions/ADR-001-interview-model-replaces-automated-derivation.md) | Why the interview model replaces automated TR derivation |
| [arch-decisions/ADR-002](arch-decisions/ADR-002-forge-elaborate-subsumes-forge-extract.md) | Why forge:elaborate subsumes forge:extract and forge:extract is deprecated |

**Cross-references:**
- ADR-006 (co-evolutionary discovery): `.forge/deployables/forge-plugin/spec/arch-decisions/ADR-006-discovery-is-a-single-phase.md`
- Deprecates: `forge:extract` (`requirements/business.md` production via document parsing)
- Output consumed by: `forge:validate`, `forge:verify`, `forge:plan`
- Delegates to: `forge:adr` for architectural decision recording
