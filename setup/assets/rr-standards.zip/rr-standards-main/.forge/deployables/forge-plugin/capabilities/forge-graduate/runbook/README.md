# Runbook — forge-graduate

Operational procedures for `forge:graduate`.

---

## Procedures

### forge:graduate Halts — No Associated Deployables

**Symptom:** `forge:graduate` returns: "forge:graduate cannot proceed — effort
`<id>` has no associated deployables or products in `.state.json`."

**Cause:** The effort's `.state.json` has no `deployables` or `businessProducts`
field, or both fields are empty arrays.

**Resolution:**

1. Open `.forge/efforts/<id>/.state.json`
2. Add the `deployables` field with the correct deployable name:
   ```json
   "deployables": ["<deployable-name>"]
   ```
   Or, for a coordination effort:
   ```json
   "businessProducts": ["<product-name>"]
   ```
3. Commit the state update
4. Re-invoke graduation

If unsure which deployable the effort targets, check the effort's `requirements/` and
`spec/` directories — they will reference the deployable by name.

---

### forge:graduate Halts — Already Graduated

**Symptom:** `forge:graduate` returns: "Effort `<id>` has already been graduated.
`graduation.graduated` is true in `.state.json`."

**Cause:** The effort was previously graduated. The skill refuses to graduate an effort
twice to prevent accidental overwrites of canonical documentation.

**Resolution:**

If the prior graduation was incorrect or incomplete and a re-graduation is genuinely
needed:

1. Verify that the prior graduation produced the correct canonical documentation
2. If re-graduation is required, manually set `graduation.graduated` to `false` in
   `.state.json`, remove the prior provenance comments from the canonical docs, and
   re-invoke graduation
3. Document the reason for re-graduation in the commit message

Re-graduation is exceptional. Most cases that appear to require it are actually a new
effort modifying the same deployable, which is the normal path.

---

### Graduation Report Flags Missing ADRs

**Symptom:** The graduation report includes one or more entries under "Missing ADRs":
"ADR-XXX listed in `.state.json` but not found in `.forge/spec/arch-decisions/`."

**Cause:** An ADR was recorded in the effort's `.state.json` (in the `adrs` field)
but was never written to the canonical ADR directory, or it was written during a
prior session and not committed.

**Resolution:**

1. Check if the ADR exists as an uncommitted file: `git status .forge/spec/arch-decisions/`
2. If uncommitted: commit the ADR file and re-run graduation
3. If genuinely absent: write the ADR now in `.forge/spec/arch-decisions/` following
   the standard ADR format, commit it, then re-run graduation

ADRs must be present before the canonical documentation can be considered complete.

---

### Graduation Produced Duplicate Sections

**Symptom:** After graduation, a canonical document contains two sections with the
same heading (e.g., two `## BR-1` sections — one from before graduation, one from the
effort).

**Cause:** This is a graduation algorithm failure. The merge algorithm must replace
existing sections, not append alongside them.

**Resolution:**

1. Identify the affected document
2. Manually merge the duplicate sections, keeping the content from the graduating effort
   (the most recent content)
3. Commit the fix with message: `fix: resolve duplicate sections after graduation of effort-<id>`
4. File a bug against `forge:graduate` with a reproduction case

---

### Canonical Documentation Updated with Incorrect Content

**Symptom:** After graduation, canonical documentation appears to contain content from
a different effort, or sections that should have been updated were not.

**Cause:** The effort ID passed to the worker was incorrect, or the effort's artifacts
were in an unexpected state.

**Resolution:**

1. Identify the graduation commit: `git log --oneline .forge/deployables/<name>/`
2. Review the commit diff to confirm what was written
3. If incorrect content was promoted:
   - Revert the graduation commit: `git revert <sha>`
   - Investigate why the effort artifacts contained unexpected content
   - Correct the effort artifacts
   - Re-run graduation

---

### forge:graduate Fails Mid-Run — Partial Write

**Symptom:** Graduation did not complete. Some canonical documents were updated but
`.state.json` graduation fields were not written, or the registry row was not removed.

**Cause:** The skill was interrupted mid-execution (session closed, timeout, or error).

**Resolution:**

1. Check which files were modified: `git status .forge/`
2. If canonical documentation was written but `.state.json` and `README.md` were not:
   - The canonical docs may be correct; do not revert them without reviewing
   - Re-run `forge:graduate` — the skill will re-merge artifacts (idempotent for docs)
     and complete the state update and registry removal
3. If canonical documentation appears partially written:
   - Revert all changes from the partial run: `git checkout -- .forge/`
   - Re-run `forge:graduate` from scratch
