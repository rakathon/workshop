# forge-init — Architecture

This capability delivers the `forge:init` skill and two shell hooks (generation
standards injection, version enforcement). Together they ensure every repository is
initialized correctly and receives the appropriate coding standards at code generation
time. Version pinning is handled by the [forge-pin](../forge-pin/) capability;
configuration migration is handled by the forge-update capability.

---

## Artifact Inventory

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:init` | Skill | Interactive | Manual invocation |
| `inject-generation-standards.sh` | Hook | Project (plugin cache) | PreToolUse: Write, Edit |
| `forge-version-check.sh` | Hook | User (global) | SessionStart |

---

## Architecture

```
Developer machine
├── ~/.claude/
│   ├── settings.json              ← user-scope: version enforcement hook
│   └── plugins/cache/
│       └── <marketplace>/forge/
│           ├── <sha-v1>/          ← pinned version for Repo B
│           │   ├── plugin.json
│           │   ├── standards/
│           │   ├── languages/
│           │   └── hooks/
│           │       ├── pre-tool-use/
│           │       │   └── inject-generation-standards.sh
│           │       └── session-start/
│           │           └── forge-version-check.sh  ← registered globally
│           └── <sha-v2>/          ← pinned version for Repo A
│               └── ...
│
├── Repo A/
│   ├── .claude/
│   │   └── settings.json         ← enabledPlugins: forge@forge-local, hook ref
│   ├── .claude-plugin/
│   │   └── marketplace.json      ← ref: v2.0.0, sha: sha-v2
│   ├── .forge/
│   │   ├── version               ← key=value, forge_min_version=2.0.0
│   │   └── ...
│   └── CLAUDE.md                 ← forge:managed section
│
└── Repo B/
    ├── .claude/
    │   └── settings.json         ← enabledPlugins: forge@forge-local, hook ref
    ├── .claude-plugin/
    │   └── marketplace.json      ← ref: v1.0.0, sha: sha-v1
    ├── .forge/
    │   ├── version               ← key=value, forge_min_version=1.0.0
    │   └── ...
    └── CLAUDE.md
```

---

## Skill Responsibilities

`forge:init` sets up hooks, the `.forge/` directory structure, and CLAUDE.md. It has
no version awareness — it only reads what is already installed.

These capabilities compose cleanly across the initialization workflow:

| Goal | Capabilities |
|------|-------------|
| Unpinned setup | `forge:init` only |
| Pinned setup | `forge:pin` → `/plugin install forge@forge-local` → `forge:init` |
| Version upgrade | `forge:pin --version X` → `/plugin install forge@forge-local` → `forge:update` |

See [forge-pin](../forge-pin/) and forge-update for the other steps.

---

## Key File Locations

| File | Owner | Purpose |
|------|-------|---------|
| `.forge/compliance` | Engineers / PE | Optional key=value exemption record; absent = full compliance |
| `.claude-plugin/marketplace.json` | `forge:pin` | Pins forge plugin to a specific version tag + SHA; optional |
| `.claude/settings.json` (marketplace) | `forge:pin` | Registers `extraKnownMarketplaces` and `enabledPlugins` entries |
| `.claude/settings.json` (hook) | `forge:init` / `forge:update` | Registers `PreToolUse` hook path pointing to plugin cache |
| `.forge/version` | `forge:init` / `forge:pin` / `forge:update` | key=value version record; read by enforcement hook |
| `CLAUDE.md` | `forge:init` / `forge:update` | Navigation instructions for AI agents; forge:managed section |
| `~/.claude/plugins/cache/<mp>/forge/<sha>/` | Claude Code | Plugin content at a specific version |
| `plugin.json` (in cache) | rr-standards release | Plugin version declaration |
| `VERSIONS.json` (in rr-standards) | Productivity Engineering | Mandatory deadline per major version |

---

## Cross-Cutting Concerns

### GitHub API

All GitHub API calls use `gh api` — the GitHub CLI, which is a prerequisite for
Forge. `gh` handles authentication transparently and works with private repositories.

Skills use `gh api --template` (Go templates) to extract fields without `jq`:

```bash
# Latest release tag
gh api repos/rewards-guilds/rr-standards/releases/latest \
  --template '{{.tag_name}}'

# Commit SHA for a tag
gh api repos/rewards-guilds/rr-standards/git/ref/tags/v1.2.3 \
  --template '{{.object.sha}}'
```

The enforcement hook uses `gh api` with `--template` and `base64 -d` to fetch
`VERSIONS.json` without `jq`. If `gh` is not authenticated or the network is
unavailable, the hook degrades gracefully.

### Shell-Only Constraint

Both hooks are pure shell with no dependencies beyond `gh` CLI and POSIX utilities.
This is achieved by:
- `.forge/version` using `key=value` format (not JSON) — read with `grep`/`cut`
- `plugin.json` version extraction using `sed` on a known stable JSON field
- `VERSIONS.json` fetched via `gh api --template` + `base64 -d`; extracted with `sed`
- Semver comparison using shell arithmetic on split version components
- Date comparison using lexicographic string comparison of ISO 8601 dates

### Hook Location

Hook scripts live **in the plugin cache** and are referenced by absolute path from
`.claude/settings.json`. They are not copied into the project.

The injection hook path in settings.json:
```
~/.claude/plugins/cache/<marketplace>/forge/<sha>/hooks/pre-tool-use/inject-generation-standards.sh
```

The enforcement hook is registered **globally** in `~/.claude/settings.json` at global
plugin install time.

---

## Pending Enhancements

### Confluence credential check (from spec-driven-development initiative)

`forge:init` should detect whether the Atlassian MCP credentials are configured
and surface a setup message when they are not. As of ADR-030, the Forge plugin
bundles `sooperset/mcp-atlassian` via `.mcp.json`. The MCP server starts
automatically when the plugin loads, but if `CONFLUENCE_URL`, `CONFLUENCE_USERNAME`,
or `CONFLUENCE_API_TOKEN` are unset, it will fail silently at the point a skill
tries to use it.

**Required addition to `forge:init` Step 8 (summary output):**

After all other setup steps, check:

```bash
missing_vars=""
[ -z "$CONFLUENCE_URL" ]       && missing_vars="$missing_vars CONFLUENCE_URL"
[ -z "$CONFLUENCE_USERNAME" ]  && missing_vars="$missing_vars CONFLUENCE_USERNAME"
[ -z "$CONFLUENCE_API_TOKEN" ] && missing_vars="$missing_vars CONFLUENCE_API_TOKEN"
```

If any are missing, print:

```
⚠ Atlassian MCP: credentials not configured
  The Forge plugin includes the Atlassian MCP (sooperset/mcp-atlassian), which
  enables Forge discovery skills to read Confluence pages directly.

  To activate it, add the following to your shell profile (~/.zshrc or ~/.bashrc):

    export CONFLUENCE_URL=https://your-org.atlassian.net/wiki
    export CONFLUENCE_USERNAME=your-email@example.com
    export CONFLUENCE_API_TOKEN=<token from https://id.atlassian.com/manage-profile/security/api-tokens>

  You can skip this if your team does not use Confluence for PM documents.
```

If all three are set, print: `✓ Atlassian MCP credentials configured`.

This check is advisory — missing credentials do not block `forge:init` from
completing. Engineers who do not use Confluence can ignore the message.

---

## Design Documents

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:init` detailed design |
| [hooks.md](hooks.md) | Injection hook and enforcement hook detailed design |
| [arch-decisions/README.md](arch-decisions/README.md) | Relevant architectural decisions |
