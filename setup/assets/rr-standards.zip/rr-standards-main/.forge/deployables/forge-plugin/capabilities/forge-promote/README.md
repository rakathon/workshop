# forge-promote

Phase advancement for work efforts in the Forge AI-accelerated development framework.
Delivers the `forge:promote` skill, which executes the promotion ritual that moves
an effort from one phase to the next with structured validation and handoff.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:promote` | Skill | Interactive | Manual invocation or via phase sentinel |

**`forge:promote`** checks that the current phase's exit criteria are met, updates
`.state.json` to the target phase, and emits a structured handoff summary. Phases
advance in order: `discovery` → `planning` → `implementation` → `verification` →
`review` → `qa` → `deployment`.

Promotion is a deliberate ritual — it requires the engineer to confirm readiness.
All readiness checks are advisory (per ADR-031); the engineer decides to proceed.

### `--target <phase>` Extension

`forge:promote` accepts an optional `--target <phase>` argument for multi-step
advancement. When provided, it computes the gap between `currentPhase` and
`targetPhase`, advances through all intermediate phases in sequence (one checkpoint
commit per phase), and exits silently when the effort is already at or past the
target.

This argument is used by the **phase sentinel** pattern: three skills call
`forge:promote --target <phase>` automatically at natural workflow transition points
when effort state lags behind the work being done:

| Calling skill | Sentinel trigger | Target phase |
|--------------|-----------------|--------------|
| `forge:plan` | Entry — before reading artifacts | `planning` |
| `forge:plan` | Completion — after `plan/tasks.md` committed | `implementation` |
| `forge:commit` | After staging — when source files outside `.forge/` are staged | `implementation` |
| `forge:verify` | Entry — before spawning worker | `verification` |
| `forge:verify` | Completion — after a PASS result | `review` |

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-effort](../forge-effort/) | Creates the effort being promoted; must exist before `forge:promote` runs. |
| [forge-plan](../forge-plan/) | Phase sentinel caller — invokes `forge:promote --target planning` on entry and `--target implementation` on completion. |
| [forge-commit](../forge-commit/) | Phase sentinel caller — invokes `forge:promote --target implementation` when source files outside `.forge/` are staged. |
| [forge-verify](../forge-verify/) | Phase sentinel caller — invokes `forge:promote --target verification` on entry and `--target review` on completion. |
| [forge-graduate](../forge-graduate/) | Executes after promotion reaches the final phase. |

## Implementation Location

`plugins/forge/skills/promote/` — `forge:promote` SKILL.md and README.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview and key design decisions |
| [spec/skills.md](spec/skills.md) | `forge:promote` detailed design |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | Relevant ADRs |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
