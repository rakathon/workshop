# Skills — forge-spec-tests

## forge:spec-tests

**Classification:** Orchestrator

**Invocation:**
```
forge:spec-tests <effort-id> [--type <e2e|contract|integration|full>] [--capability <deployable>/<capability>]
```

**Defaults:** `--type full` when omitted.

**Mode:** Intent-first, spec-validating. The engineer declares what kind of test plan
they need. The skill checks whether available spec artifacts are sufficient, surfaces
gaps with actionable next steps, and generates scenarios only for achievable types.

**Inputs:**
- `requirements/business.md` (required)
- `requirements/technical.md` (optional)
- `spec/api/*.yaml` — enables contract scenarios
- `spec/storage/*.md` — enables integration scenarios
- `spec/messaging/*.md` — enables messaging contract scenarios
- `standards/testing/strategy.md` from plugin root — type selection rules
- `standards/testing/contract.md` from plugin root — contract scenario rules
- `standards/testing/integration.md` from plugin root — integration scenario rules
- `standards/testing/e2e.md` from plugin root — E2E scenario rules
- (all standards optional — falls back to built-in classification rules if absent)

**Output directory:**
- `e2e` in coordination repo → `.forge/products/<product-name>/test/`
- `e2e` in deployable repo → `<effort_dir>/spec/test/`
- `e2e` with `--capability` → `<capability_dir>/test/`
- `contract`/`integration` → `<capability_dir>/test/`
- Does NOT touch `.state.json`

**Output files per type:**

| Type | File(s) written |
|------|----------------|
| `e2e` | `e2e-test-suite.md` |
| `contract` | `<spec-name>-contract-test-suite.md` per API/messaging spec |
| `integration` | `integration-test-suite.md` |
| `full` | all achievable type files (e2e + per-contract + integration) |

**Test types produced:**
- `e2e` — user-visible observable behaviors from BRs
- `contract` — endpoint/schema agreement scenarios from API or messaging spec
- `integration` — in-process component interactions from storage spec or TRs
- Unit tests: always excluded

**Gap behavior:** Blocked types are surfaced with the Forge skill needed to produce
the missing spec. The engineer decides whether to stop and fill the gap or continue
with achievable types.

**Steps:**
1. Determine test plan type (`--type`, default: `full`)
2. Determine output directory (`--capability` or infer from effort type in `.state.json`)
3. Ensure output directory exists; create capability dir if absent
4. Load testing standards from plugin (strategy, contract, integration, e2e)
5. Read effort artifacts; record spec presence flags
6. Feasibility check: achievable vs blocked; print gap report; prompt if partially blocked
7. Check for existing test plan files (re-invocation path)
8. Propose scenarios for achievable types only
9. Present draft and confirm
10. Write one file per achievable type to `<output_dir>`
11. Commit all new/updated files in `<output_dir>`
12. Print summary with files written and remaining gaps
