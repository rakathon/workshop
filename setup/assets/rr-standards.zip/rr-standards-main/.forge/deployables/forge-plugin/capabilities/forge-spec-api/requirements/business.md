# Business Requirements — forge-spec-api

Parent deployable: [forge-plugin](../../requirements/business.md)

## BR-1: Standard Violations Must Surface During Design, Not After

When an API contract violates the REST standard, the cost of correction depends entirely
on when the violation is discovered. Found at authoring time: one field change. Found at
code review: discussion, PR iteration, possible re-implementation. Found in production:
coordination, versioning, and client migration.

An interactive design tool that checks conformance inline — after each endpoint is
confirmed, before the next is drafted — catches violations at the cheapest possible
moment. Deferred validation (a separate `forge:validate-api` pass after the whole
contract is written) is strictly worse: the engineer has already mentally moved on.

## BR-2: One-Resource-at-a-Time Produces Better Contracts Than One-Endpoint-at-a-Time

A resource groups all the operations that share a path — GET, POST, PUT, DELETE, and
their query parameters. Designing at the resource level allows the engineer to establish
the canonical path first, then review all verbs and query parameters together. Patterns
emerge: consistent naming across operations, query parameters that apply to multiple
verbs, response shapes that should match across methods.

Designing endpoint by endpoint breaks this context. The engineer confirms a GET before
the POST is drafted, making cross-operation consistency harder to evaluate. Operating
at the resource level keeps the full surface of a resource visible during review.

## BR-3: Non-Standard Choices Must Be Explicitly Recorded, Not Silently Accepted

An API that deviates from the REST standard for a legitimate reason is fine. An API
that deviates because the engineer chose a path without realizing it was non-standard is
a problem. The skill must distinguish between these two cases: explicit override with
rationale is accepted and recorded; silent violation is corrected.

## BR-5: An Existing Contract Should Be Reviewable Without Re-Authoring From Scratch

When an API contract has already been written, the engineer should be able to invoke
the skill to check whether it is still correct — without discarding and re-authoring
the whole contract. Requirements evolve, standards get updated, and gaps accumulate
incrementally. The skill should detect an existing contract and offer to evaluate it
against current requirements and the REST standard, surfacing only what has changed
or is missing.

## BR-4: The Contract Must Be Traceable to the Requirements That Drove It

Every endpoint in the contract should map to at least one business or technical
requirement. The contract is the design answer to the requirements; without traceability
the connection is implicit and easily lost as requirements evolve.

---
Success criteria: [success-criteria.md](success-criteria.md)
