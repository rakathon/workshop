# Business Requirements — forge-spec-storage

## BR-1: PII Compliance Requirements Must Surface During Schema Design, Not at Review

When a storage schema introduces PII fields (email, name, date of birth, financial
data), GDPR retention and deletion obligations apply. Discovering this during code
review — after schema migrations are written and data access layer is implemented —
means revisiting multiple artifacts under time pressure. Discovering it during schema
design costs one inline comment.

## BR-2: Storage Type Selection Requires Understanding Access Patterns

Choosing between relational, document, cache, and search storage depends on the
access patterns the feature requires. Engineers who default to a storage type without
confirming it against the requirements may build the correct feature against the wrong
store. The skill should make the selection explicit and grounded.

## BR-3: Index Strategy Must Be Decided Against Requirements, Not Intuition

Under-indexed schemas cause performance problems in production. Over-indexed schemas
slow writes. The right index set follows from the query patterns stated in requirements
— the skill should check whether required query patterns have corresponding indexes, not
just ask "do you want indexes?"

## BR-4: API and Storage Contracts Must Align

When an API contract already exists for an effort, storage schemas should map
consistently to the API's resource model. Divergence between API resources and storage
entities surfaces integration complexity at implementation time; catching it during
design is cheaper.

---
Success criteria: [success-criteria.md](success-criteria.md)
