# forge-pin — Design Overview

`forge:pin` is a single-responsibility skill: it creates or updates the project-local
marketplace pin that locks Claude Code to a specific Forge plugin version. It has no
knowledge of hooks, directory structure, or CLAUDE.md — those belong to `forge:init`.

## Responsibility Boundary

| Skill | Owns |
|-------|------|
| `forge:pin` | `.claude-plugin/marketplace.json`, `extraKnownMarketplaces` + `enabledPlugins` in `.claude/settings.json`, `forge_min_version` in `.forge/version` |
| `forge:init` | Hook registration, `.forge/` directory structure, CLAUDE.md |
| forge-update | `active_version`, `last_migrated_*` in `.forge/version`; configuration migrations |

## Order Independence

`forge:pin` and `forge:init` can be run in either order:

```
Option A (pin first):  forge:pin → /plugin install → forge:init
Option B (init first): forge:init → forge:pin → /plugin install
```

In Option B, `forge:pin` updates `forge_min_version` in the already-written
`.forge/version` directly (TR-10.3), so no re-run of `forge:init` is needed.

## Key Files

| File | Action |
|------|--------|
| `.claude-plugin/marketplace.json` | Created or updated with `ref` + `sha` pin |
| `.claude/settings.json` | `extraKnownMarketplaces["forge-local"]` and `enabledPlugins["forge@forge-local"]` written |
| `.forge/version` | `forge_min_version` updated (if file exists) |

## Design Documents

| Document | Contents |
|----------|----------|
| [skills.md](skills.md) | `forge:pin` detailed flow and design decisions |
