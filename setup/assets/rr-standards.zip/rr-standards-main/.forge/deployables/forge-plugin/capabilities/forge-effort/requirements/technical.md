# Technical Requirements — forge-effort

Parent technical requirements: [forge-workflow/requirements/technical.md](../../../../../efforts/forge-workflow/requirements/technical.md)

---

## TR-0: Effort Subtype and Production-Bound Status Are Declared at Creation and Are Immutable

Every effort must be classified at creation with a `subtype` field and a `productionBound`
boolean. These fields are set by `forge:effort` (or by the conversational path) and must
never change after the effort's first commit. Subsequent hooks and skills read these fields
to determine which phases are required and whether CI review is mandatory.

**Subtype values and their phase requirements:**

| Subtype | Discovery | Arch review | Planning | CI review | QA |
|---------|-----------|-------------|----------|-----------|----|
| `patch` | No | No | No | Yes — blocking | No |
| `refactor` | No | No | Optional | Yes — blocking | No |
| `extension` | Optional | No | Optional | Yes — blocking | Risk-dependent |
| `poc` | No | No | No | Optional, non-blocking | No |

`productionBound` must be `false` for all `poc` subtype efforts and `true` for all others.
The `productionBound: false` flag drives two behaviors at the CI level:
1. `forge:review` is not registered as a required PR status check for this effort.
2. Security and privacy validation failures are non-blocking.

Changing `productionBound` from `false` to `true` on an existing effort is prohibited.
If a PoC proves viable, a new production-tier effort must be created. The PoC records the
spawned effort's ID in `spawnedWorkItems`.

## TR-1: Effort State Must Be Stored in .state.json in the Effort Directory

Each effort must have a `.state.json` file at `.forge/efforts/<effort-id>/.state.json`.
This file is the canonical machine-readable state for the effort.

**Required fields at creation:**

| Field | Type | Constraint |
|-------|------|------------|
| `id` | string | Matches directory name; immutable after first commit |
| `title` | string | Human-readable name |
| `type` | string | `program` \| `initiative` \| `epic` \| `story` \| `task` \| `spike` |
| `tier` | string | `full` \| `lightweight`; immutable after first commit |
| `risk` | string | `R1` \| `R2` \| `R3` \| `R4` |
| `subtype` | string \| null | See TR-0; immutable after first commit |
| `productionBound` | boolean | `false` for `poc`; `true` otherwise; immutable after first commit |
| `parentId` | string \| null | Bare ID for same-repo parent; `repo:org/repo/id` for cross-repo |
| `childIds` | array | Empty at creation; updated when child efforts are scaffolded |
| `deployables` | array | Technical deployables this effort contributes to |
| `currentPhase` | string | Starting phase per effort type |
| `phases` | object | Per-phase state objects; see schema reference |
| `openDecisions` | array | Empty at creation |
| `spawnedWorkItems` | array | Empty at creation; relevant only for `poc` subtype |
| `coordinationRef` | object \| null | `null` for standalone efforts; set by `forge:project` |
| `upstreamProposals` | array | Empty at creation |
| `graduation` | object | `{ graduated: false, graduatedAt: null, graduatedTo: [] }` |
| `timebox` | string \| null | ISO-8601 date or `null` |

The complete field schema and a fully-populated example are in [spec/state-schema.md](../spec/state-schema.md).

State transitions must be committed atomically with the artifact that triggered them. An
artifact on disk that is not reflected in `.state.json` is a consistency violation. An
agent that writes a requirements file must also update `.state.json` in the same commit —
either directly or by letting the PostToolUse hook update it and including both files in
the commit.

## TR-2: The Registry Must Reflect All Active Efforts in a Single File

`.forge/efforts/README.md` is the active-work registry. Every effort creation, phase advance, and
closure must produce an update to this file. Each effort occupies exactly one line in a
Markdown table. Closed efforts are removed; they are permanently preserved in
`.forge/efforts/` but no longer appear in the registry.

**Required table columns:**

| Column | Description |
|--------|-------------|
| ID | Effort identifier, links to the effort directory |
| Title | Human-readable name |
| Type | Work item type |
| Tier | `full` \| `lightweight` |
| Risk | R1–R4 |
| Phase | Current phase |
| Status | `in_progress` \| `blocked` \| `review` \| etc. |

Child efforts must appear indented beneath their parent in the table (achieved via
`&nbsp;&nbsp;` prefix in Markdown cells or equivalent visual indentation).

The file must use one-row-per-effort formatting so concurrent additions by multiple
engineers merge cleanly without conflict. See TR-13.

## TR-7a: The Local Implementation Plan Uses Typed, Wave-Annotated Task Format

When a planning phase is required (full-tier and some extension efforts), `forge:plan`
generates `plan/tasks.md` with the following mandatory task format:

```
- [ ] [auto][wave:1] Description of task (TASK-NNN)
- [ ] [tdd][wave:2] Description of task (TASK-NNN)
- [ ] [checkpoint][wave:2] Description — why human input is needed (TASK-NNN)
- [x] [auto][wave:1] Completed task description (TASK-NNN) (a3f9b12)
```

**Task type annotations:**

| Annotation | Meaning |
|------------|---------|
| `[auto]` | Agent proceeds autonomously; no pause required |
| `[checkpoint]` | Agent pauses before or after for human decision or confirmation |
| `[tdd]` | RED → GREEN → REFACTOR discipline; tests must be written and failing before implementation |
| `[manual]` | Human action required; agent cannot execute this task |

**Wave annotations:**

| Annotation | Meaning |
|------------|---------|
| `[wave:N]` | Dependency group; all tasks in wave N must complete before wave N+1 begins |

Completed tasks must record the commit SHA inline: `(TASK-NNN) (a3f9b12)`.
The `update-workflow-state.sh` PostToolUse hook reads the task completion state from
`plan/tasks.md` to update `phases.implementation.completedTasks` and
`phases.implementation.remainingTasks` in `.state.json`.

## TR-8: The Phase-Context Hook Informs and Never Blocks

The `phase-context.sh` PreToolUse hook fires before any Write or Edit operation targeting
a file under `.forge/efforts/`. Its behavior is strictly informational:

- **Typical write for current phase:** exit 0, no output (silent pass-through).
- **Atypical write for current phase (post-approval modification):** exit 0 with
  informational message naming the artifact, the phase it was produced in, the current
  phase, and the note that this modification will be tracked for reconciliation at graduation.
- **Write outside `.forge/efforts/`:** exit 0, no output, immediate return.

The hook must never exit 2 for any write to a `.forge/efforts/` path. The only case where
exit 2 is permitted by ADR-002 is writing source code files before discovery is approved
for full-tier efforts — and that enforcement belongs to a separate hook scope, not to
`phase-context.sh`.

**Performance:** Must complete in under 200ms. The hook reads exactly two inputs: the
target file path (from hook arguments) and `.state.json` (one file read). No network calls.

## TR-9: Post-Approval Modifications Must Be Tracked in .state.json

When an artifact produced during an approved phase is subsequently modified, the
`update-workflow-state.sh` PostToolUse hook must record the modification in
`phases.<phase>.postApprovalModifications`:

```json
{
  "file": "requirements/business.md",
  "modifiedAt": "2026-03-27T14:30:00Z",
  "modifiedDuringPhase": "implementation"
}
```

This tracking serves two purposes:
1. **Review visibility:** Reviewers see which approved artifacts changed during
   implementation.
2. **Graduation reconciliation:** `forge:graduate` must present all post-approval
   modifications for review before promoting artifacts to canonical documentation.

No reopen process is required to modify an approved artifact. The modification is
permitted, recorded, and reconciled at graduation.

## TR-11: Session Start Must Inject Current Workflow State

The `inject-workflow-context.sh` SessionStart hook must fire at every session start and
emit the following to Claude's context:

1. Active efforts from `.forge/efforts/README.md` with ID, title, phase, and status.
2. Current effort identification: single in-progress effort, or branch-name match, or
   prompt to clarify if multiple are active.
3. For the current effort: full phase state, artifact inventory (present / absent),
   open decisions, pause state (if resuming), post-approval modifications (if any).
4. For cross-repo sub-efforts: staleness check against the coordination repo's current
   HEAD via `gh api` (non-blocking; skipped if offline or if the check exceeds the
   time budget).

**Performance:** Must complete in under 2 seconds including any GitHub API calls.
Staleness checks run in a background subprocess with a hard timeout. If the timeout
is exceeded, the session starts without staleness info — it is never blocking.

**Output format:** Emitted as a structured Markdown block with a `## Forge — Active
Workflow Context` heading. See the hook specification in [spec/hooks.md](../spec/hooks.md)
for the full output format.

## TR-13: Concurrent State Updates Must Be Merge-Friendly

`.state.json` and `.forge/efforts/README.md` are updated by multiple operations and potentially
by multiple engineers working concurrently. They must be structured to minimize merge
conflicts.

**`.state.json` formatting rules:**
- All keys sorted alphabetically at every nesting level.
- All arrays formatted with one item per line.
- Consistent 2-space indentation throughout.
- No trailing commas (standard JSON).

**Why this matters:** Two engineers adding different ADR filenames to `adrsCreated`
will each add one line in a different position. One-item-per-line formatting allows
git to auto-merge these additions cleanly. Two engineers updating different phase
statuses modify different key paths — these also merge cleanly because each key is
on its own line.

**`.forge/efforts/README.md` formatting rules:**
- One effort per table row, one row per line (no line wrapping within rows).
- Additions are new lines; removals are line deletions; updates are in-place edits to
  one line.
- Rows sorted consistently (by effort ID or hierarchy position) so adjacent rows are
  stable between operations.

## TR-15: Forge Must Function Through Conversational Intent

The four skills in this capability — `forge:effort`, `forge:status`, `forge:pause`,
`forge:resume` — must be triggerable conversationally without explicit skill invocation.
The CLAUDE.md Tier 1 content, the SessionStart hook output, and the UserPromptSubmit
routing hook together must give Claude enough context to:

- Recognize "let's start working on X" as an effort creation event and scaffold correctly.
- Recognize "where are we?" as a status request and read `.state.json` to respond.
- Recognize "let's pick this up tomorrow" as a pause event and persist pause state.
- Recognize a session start with pause state as a resume event and restore context.

The explicit skill invocation path must remain available and must produce identical
outcomes. An engineer who never uses an explicit Forge skill must get the same artifacts,
state transitions, and registry entries as one who does.

**Intent recognition is via CLAUDE.md instructions, not NLP rules.** The CLAUDE.md Tier 1
section describes the pattern classes (statements of scope, statements of status, session
conclusion signals) and the corresponding actions. Claude applies these descriptions
naturally in conversation.

**Automatic state management is via PostToolUse hooks.** When Claude writes or modifies
an artifact, `update-workflow-state.sh` fires and updates `.state.json` automatically.
No explicit state management step is required from the agent or engineer.
