# Success Criteria — forge-commit

These criteria are the measurable acceptance bar for the forge-commit capability.
Each criterion specifies the observable behavior, the mechanism that delivers it,
and how to verify it.

---

## SC-1: Branch Convention Warning Is Surfaced but Does Not Block the Commit

**Criterion:** When invoked on a branch that does not follow `effort/<work-id>` or
`<work-id>/<short-description>`, `forge:commit` warns the engineer, offers a rename,
and allows them to proceed anyway.

**Verification:**
1. Check out a branch named `my-feature-branch`.
2. Stage a change. Invoke `forge:commit`.
3. Confirm the output includes the current branch name and the expected conventions.
4. Confirm a rename suggestion is offered.
5. Decline the rename and proceed. Confirm the commit is created.

**Pass condition:** Warning is surfaced. Engineer can decline rename. Commit succeeds.

---

## SC-2: Mixed-Concern Staged Changes Are Flagged and the Skill Halts Until Resolved

**Criterion:** When staged changes span multiple unrelated logical tasks, `forge:commit`
identifies the affected tasks, explains the concern, and does not proceed to commit
creation until the engineer confirms they want to continue or splits the changes.

**Verification:**
1. Stage changes from two unrelated tasks (e.g., a new handler file and an unrelated
   config tweak in a different package).
2. Invoke `forge:commit`.
3. Confirm the output identifies the mixed-concern files.
4. Confirm the skill pauses for engineer input.
5. Confirm that proceeding after acknowledgment creates the commit.

**Pass condition:** Mixed concern is detected and surfaced. Skill waits for input.
No commit is created until the engineer responds.

---

## SC-3: Conventional Commit Message Is Proposed and Engineer Confirmation Is Required

**Criterion:** `forge:commit` proposes a `type(scope): description` message and does
not create the commit until the engineer confirms or provides an alternative.

**Verification:**
1. Stage a single-task change and invoke `forge:commit`.
2. Confirm the proposed message follows the `type(scope): description` format.
3. Provide an alternative message.
4. Confirm the commit is created with the engineer-provided message, not the proposal.

**Pass condition:** Message is proposed. Engineer alternative is accepted verbatim.
Commit message matches engineer-provided text exactly.

---

## SC-4: Structured Git Note Is Attached to Every Commit with Correct JSON Structure

**Criterion:** After every commit, a `git notes` entry is attached to the commit
containing a valid JSON payload with all five required fields: `workId`, `taskId`,
`wave`, `taskType`, and `standardsChecked`.

**Verification:**
1. Invoke `forge:commit` on a repository with a valid `plan/tasks.md` and `.state.json`.
2. After commit, run `git notes show HEAD`.
3. Parse the output as JSON.
4. Confirm all five fields are present.
5. Confirm `workId` matches the effort ID.
6. Confirm `taskId` matches a `TASK-NNN` from `plan/tasks.md`.
7. Confirm `standardsChecked` is `true`.

**Pass condition:** `git notes show HEAD` returns valid JSON with all five fields
populated correctly.

---

## SC-5: forge:update-plan Prompt Is Printed After Every Successful Commit

**Criterion:** The post-commit prompt "Run `forge:update-plan` to record this SHA
and mark the task complete." appears unconditionally after every successful
commit-and-note sequence.

**Verification:**
1. Invoke `forge:commit` and complete the full flow.
2. Inspect the output for the exact prompt text.
3. Repeat with different task types and wave numbers.

**Pass condition:** Prompt appears in output for every successful invocation.
Prompt text matches exactly: `Run \`forge:update-plan\` to record this SHA and
mark the task complete.`

---

## SC-6: No-Staged-Changes Case Is Detected and Reported Cleanly

**Criterion:** When `forge:commit` is invoked with no staged changes, the skill
reports a clear message and does not attempt to create a commit.

**Verification:**
1. Ensure no files are staged (`git status` shows clean staging area).
2. Invoke `forge:commit`.
3. Confirm the output includes a message about no staged changes and instructions
   to stage with `git add`.
4. Confirm no commit is created.

**Pass condition:** Clear error message printed. No commit created.
