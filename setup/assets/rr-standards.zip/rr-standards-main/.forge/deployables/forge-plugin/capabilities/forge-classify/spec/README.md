# Spec — forge-classify

| Artifact | Description |
|----------|-------------|
| [skills.md](skills.md) | Full skill interface spec: steps, state.json interactions, re-invocation behavior, error handling |
| [arch-decisions/](arch-decisions/) | Capability-scoped ADRs (none currently) |

**Standards reference:**
- Risk rubric: `plugins/forge/standards/risk/classification.md`

**Cross-references:**
- Initiative design: `.forge/efforts/spec-driven-development/spec/skills.md § forge:classify`
- Reads `suggestedRisk` advisory from `.state.json` if present; clears it after classification
- Classification drives: `forge:arch-review` (R1/R2 only), `forge:verify` (R1/R2 required), `forge:promote` (PR approval policy)
