# Technical Requirements — forge-commit

Parent business requirements: [requirements/business.md](business.md)
Related ADR: [ADR-008 — Structured git notes as the Task Metadata Layer](../../../../../spec/arch-decisions/ADR-008-structured-git-notes.md)

---

## TR-1: Branch Convention Check (Non-Blocking Guardrail)

`forge:commit` must inspect the current git branch name before proceeding to the
staged-changes check.

**Accepted conventions:**
- `effort/<work-id>` — the standard effort branch format
- `<work-id>/<short-description>` — an alternate permitted format

If the branch name does not match either convention, the skill must:
1. Display the current branch name and the expected conventions.
2. Offer to rename the branch to a conforming name (suggest a specific name).
3. Allow the engineer to decline and proceed anyway — this check is a guardrail,
   not a hard gate. The commit must not be blocked solely by a branch name.

If the branch conforms, note it silently and continue.

## TR-2: Staged-Changes Scope Check

`forge:commit` must inspect the currently staged changes to evaluate whether they
are scoped to a single logical task.

**Scope evaluation criteria:**
- Changes that belong to a single task in `plan/tasks.md` are in scope.
- Changes that span multiple unrelated tasks (e.g., a new feature and an unrelated
  refactor) are mixed-concern and must be flagged.
- Changes that have no staged files must be detected and reported with a clear message:
  "No staged changes found. Stage your changes with `git add` before running
  `forge:commit`."

**On mixed-concern detection:**
1. Describe which changes appear to belong to which task.
2. Suggest how to split the commit (e.g., `git add -p` or stage by file).
3. Ask the engineer to confirm they want to proceed or split. The skill must not
   auto-proceed past a mixed-concern warning.

**On clean scope:** Confirm the task context (task ID and title from `plan/tasks.md`).

## TR-3: Conventional Commit Message Proposal

`forge:commit` must propose a conventional commit message of the form:

```
type(scope): description
```

Where:
- `type` is one of: `feat`, `fix`, `chore`, `docs`, `test`, `refactor`
- `scope` is derived from the effort ID or the primary file/package changed
- `description` is a concise imperative-mood summary (≤72 characters total)

The skill must:
1. Present the proposed message to the engineer.
2. Ask for confirmation or an alternative.
3. Accept the engineer's alternative verbatim if provided.
4. Not proceed to commit until a message is confirmed.

## TR-4: Commit Creation

`forge:commit` must create the git commit using the confirmed message:

```bash
git commit -m "<confirmed-message>"
```

The commit must not include `--no-verify` or any flag that bypasses hooks unless
the engineer explicitly requests it and acknowledges the implications.

After the commit succeeds, capture the resulting commit SHA for use in Step TR-5.

## TR-5: Structured Git Note Attachment (ADR-008)

`forge:commit` must attach a structured JSON git note to the commit created in TR-4.
The note must contain the following fields:

```json
{
  "workId": "<effort-id>",
  "taskId": "<TASK-NNN>",
  "wave": <n>,
  "taskType": "auto|tdd|checkpoint|manual",
  "standardsChecked": true
}
```

**Field derivation:**
- `workId`: The effort ID extracted from `.state.json` (`id` field) or from the
  branch name (`effort/<work-id>` → `<work-id>`).
- `taskId`: The task ID (`TASK-NNN`) from the matching task line in `plan/tasks.md`.
  Task IDs appear at the end of task lines as `(TASK-NNN)`.
- `wave`: The wave number from the task annotation (`[wave:N]`) in `plan/tasks.md`.
- `taskType`: The type annotation from the task line: `auto`, `tdd`, `checkpoint`,
  or `manual`. Defaults to `auto` if the annotation is absent.
- `standardsChecked`: Always `true` when attached via `forge:commit`.

**Attachment method:** Write the JSON to a temporary file, then attach via:
```bash
git notes add -F <tmpfile> HEAD
```
Do not use shell inline JSON (`-m '{"key": "val"}'`) — quoting is fragile and
produces malformed notes on some platforms.

**Why this matters:** The git note is the machine-readable traceability link that
`forge:verify` reads to confirm implementation. `forge:diagnose` and `forge:revert`
also consume notes to locate the commit associated with a specific task. Without the
note, verification falls back to parsing commit messages, which is fragile and
unreliable.

## TR-6: Post-Commit Task Completion Check

After attaching the git note, `forge:commit` must ask whether the commit completes the
associated task before invoking `forge:update-plan`. If the task is complete, invoke
`forge:update-plan` to mark it `[x]` with the commit SHA. If partial/WIP, leave the
task open.

## TR-7: Phase Entry Check Before Staging

When an effort is active, `forge:commit` must check `currentPhase` in `.state.json`
before proceeding to the staged-changes check:

- If `currentPhase` is `"implementation"` or any later phase: proceed silently —
  no phase check needed.
- If `currentPhase` is before `"implementation"` (e.g., `"planning"`, `"discovery"`):
  invoke `forge:promote <effort-id> --target implementation` and wait for it to
  complete before proceeding.

This is the fallback for engineers who begin committing implementation work without
having explicitly run `forge:promote`. It also handles multi-step gaps (e.g., committing
from discovery phase advances through both discovery and planning in one operation).
