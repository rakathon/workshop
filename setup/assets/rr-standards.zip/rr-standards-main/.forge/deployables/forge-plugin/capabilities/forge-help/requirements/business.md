# Business Requirements — forge-help

Parent deployable: [forge-plugin](../../requirements/business.md)

---

## BR-1: Engineers Must Be Able to Get Accurate Answers About How Forge Works Without Reading Plugin Internals

An engineer using Forge must be able to ask natural-language questions about any part
of the framework — how a skill works, what a hook does, what standards are embedded,
what language guides are available, what phases the workflow has — and receive a
grounded, accurate answer without navigating the plugin directory structure themselves.
The plugin's internal file layout is an implementation detail that engineers should
never need to understand in order to use Forge effectively.

**Acceptance criteria:**
- An engineer can ask "how does `inject-generation-standards` work?" and receive an
  accurate explanation of the hook's behavior in plain terms
- An engineer can ask "what does Forge's REST API standard say about error responses?"
  and receive a specific, grounded answer drawn from the standard's actual content
- An engineer can ask "what phases does the Forge workflow have?" and receive an
  accurate description of the full workflow lifecycle
- No answer ever exposes internal plugin file paths to the engineer

---

## BR-2: Engineers Must Be Able to Get an Orientation to Everything Forge Provides

An engineer who is new to Forge, or returning after time away, must be able to invoke
`forge:help` with no argument and immediately see a complete, structured catalog of
everything the framework provides: skills (grouped by phase), hooks (with a one-liner
on what each does), and pointers to the standards and language guides that are
available. The catalog must reflect what actually exists — not a static list that can
go stale.

**Acceptance criteria:**
- Invoking `forge:help` with no argument produces a catalog of all implemented skills
  grouped by workflow phase, all active hooks with a brief description of each, and
  the set of available standards and language guides
- Stub skills (directories with no SKILL.md) do not appear in the catalog
- The catalog is always current — it is derived dynamically from the plugin's own
  AGENTS.md files, not hardcoded in the skill

---

## BR-3: Answers Must Span Multiple Areas When a Question Requires It

A question about Forge often spans more than one component — for example, "how does
Forge enforce standards during code generation?" involves both a hook and the standards
library. The skill must synthesize a complete answer from all relevant parts of the
plugin rather than scoping its answer to a single directory or component and leaving
the engineer to piece together the rest.

**Acceptance criteria:**
- A question that involves both a hook and a standard produces one complete answer
  covering both
- A question about a workflow phase produces an answer that includes the relevant
  skills, any hooks active during that phase, and the artifacts involved
- The engineer never needs to ask a follow-up question to get the complete picture
  for a single conceptual question

---

## BR-4: The Skill Must Explain Workflow Concepts, Not Just Enumerate Components

An engineer must be able to ask workflow-level questions — "what phases does Forge
have?", "what needs to be true before I can run `forge:promote`?", "what is the
difference between discovery and validation?" — and receive accurate, substantive
answers grounded in how the framework actually works. The skill serves as the primary
explanation layer for the framework's workflow model.

**Acceptance criteria:**
- An engineer can ask about any phase and receive an explanation of its purpose,
  required inputs, expected outputs, and how to advance past it
- An engineer can ask about a skill's preconditions and receive an accurate answer
  drawn from the skill's own documentation
- When an engineer asks an effort-state question ("am I ready to run forge:plan?"),
  the skill explains the preconditions for that skill and recommends `forge:status`
  for their specific effort state — it does not read live effort state itself

---

## BR-5: The Catalog and Q&A Must Reflect Only What Is Implemented

Forge has many planned but unimplemented skills (stubs). Surfacing stubs as if they
were usable creates confusion and erodes trust in the framework. The skill must show
only what actually works today.

**Acceptance criteria:**
- Stub skills (directories containing only `.gitkeep`, with no `SKILL.md`) are
  excluded from the catalog and from Q&A answers
- If an engineer explicitly asks about a stub skill by name, the skill acknowledges
  it is not yet implemented rather than fabricating a description
