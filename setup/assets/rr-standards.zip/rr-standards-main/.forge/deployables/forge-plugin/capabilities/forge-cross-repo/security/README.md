# Security — forge-cross-repo

## GitHub API Token Scope

`forge-cross-repo` skills use the `gh` CLI for all GitHub API calls. The `gh` CLI
uses the authentication token configured by `gh auth login`.

**Minimum required scopes:**

| Skill | Required scope |
|-------|---------------|
| `forge:project` | `repo:read` (or `public_repo` for public repositories) on the coordination repository |
| `forge:sync` | `repo:read` (or `public_repo` for public repositories) on the coordination repository |
| `forge:upstream` (without `--pr`) | No GitHub API calls; no token required |
| `forge:upstream --pr` | `repo:write` on the coordination repository, or the ability to fork and create a PR |

No admin scopes are required. The skills use only the contents API and commits API
for reads, and the pull requests API for PR creation.

**Token storage:** The GitHub token is managed by the `gh` CLI and stored in the
engineer's `gh` credential store. Forge does not store, log, or transmit the token.
Engineers who are concerned about token scope should use a fine-grained personal access
token scoped to the specific coordination repository.

## coordinationRef.repo Contains No Secrets

The `coordinationRef.repo` field in `.state.json` is a GitHub repository identifier
in `<org>/<repo>` format (e.g., `acme/platform-coordination`). This is a public
identifier — it names the repository, not any credentials or tokens for accessing it.
Committing `coordinationRef` to version control does not expose secrets.

## Provenance Headers Contain No Secrets

The provenance header written into projected files contains:
- `source_repo` — the GitHub repository identifier (public identifier, see above)
- `source_effort` — the effort ID (a workflow artifact name, not a secret)
- `source_file` — a file path in the coordination repository (a workflow artifact path)
- `source_commit` — a git blob SHA (a content hash, not a credential)
- `projected_at` — a timestamp

None of these fields contain authentication tokens, passwords, API keys, or personal
information. Provenance headers are safe to commit and review.

## Coordination Repository Access

`forge:project` and `forge:sync` require read access to the coordination repository.
If the coordination repository is private, the engineer must have explicit read access
granted by the repository owner. Forge does not attempt to bypass access controls or
retry with different credentials on failure.

If an engineer lacks access to the coordination repository, `forge:project` will fail
with a clear error (HTTP 403 or 404). The error message will direct the engineer to
request access — Forge will not attempt any workaround.

## Upstream Pull Request Creation

`forge:upstream --pr` creates a pull request to the coordination repository using
`gh pr create --repo <org/repo>`. The PR is created under the engineer's GitHub
identity. If the engineer does not have write access to the coordination repository,
they must fork it first. Forge does not create forks automatically.

The pull request body contains the change proposal document, which is authored by
the engineer. Engineers should review the proposal content before passing `--pr`,
as the PR body will be visible to all contributors to the coordination repository.

## No Secrets in Effort Artifacts

Effort artifacts — requirements, plans, projections, proposals — must not contain
secrets, credentials, or tokens. The forge-workflow system is designed around the
principle that all artifacts are committed to git and are therefore permanent,
visible to all repository contributors, and potentially visible to future contributors
if the repository history is ever made public.

Engineers should apply the same judgment to forge artifacts that they apply to source
code: never put a secret in a file that will be committed to version control.
