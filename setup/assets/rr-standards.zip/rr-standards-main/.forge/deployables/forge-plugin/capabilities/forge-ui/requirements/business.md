# Business Requirements — forge-ui

Parent deployable: [forge-plugin](../../requirements/business.md)

<!-- graduated-from: design-system-integration at 2026-04-25T23:10:46Z -->

---

## BR-2: The Prototyping Workflow Must Be a Forge-Aligned Skill

The existing `rakuten-styleguide` skill works but is not Forge-aligned: it has no
SKILL.md structure, no precondition checks, no standards references, and no integration
with rr-standards tooling. A redesigned prototyping skill must fit the Forge skill
architecture (SKILL.md-based, with preconditions, steps, and references to
organizational standards). The skill must support both the Figma-to-prototype and
prompt-to-prototype workflows that the design team already uses. Engineers must be able
to invoke it as a slash command (`/forge:ui` or equivalent) without needing to know the
underlying project's structure.

## BR-3: The Prototyping Skill Must Remain Low-Friction for the Design Team

The design team's primary concern is speed — they need to move from idea to running
prototype in minutes, not hours. Any redesigned skill must preserve or improve on the
current workflow's speed. Requiring the design team to learn Forge concepts or fill in
effort artifacts before prototyping would contradict this requirement. The skill's entry
point must be as simple as: describe what you want (or share a Figma node) → get running
code. Forge alignment is a structural concern for engineers building the skill; it must be
invisible to the design team using it.

## BR-4: There Must Be a Defined Path From Prototype to Production

Currently, prototypes produced by the design skill are disconnected from production
implementation. There is no standard for when a prototype is "good enough" to become
a production reference, no handoff format, and no skill that helps an engineer
implement from a design spec. A skill must exist that takes a design spec (whether that
is a Figma link, a prototype URL, or a written specification) and guides an engineer
through a production-quality implementation that passes organizational frontend standards.

The core requirement is met by `forge:ui` production mode driven by `forge:ui-design`
and `ui-spec-template.md`. The discrete "promote this prototype" trigger and associated
handoff record format are deferred to a follow-on effort.

## BR-6: Skills Must Encode Standards References, Not Standards Content

None of the skills produced for UI code generation should reproduce the content of
organizational standards inline. If the spacing token table appears in a skill's module
file, it will drift from the canonical standard the next time tokens are updated. Skills
must reference standards by path; standards are the single source of truth. This
separation is both a quality requirement and a maintenance requirement.

## BR-7: The Design Team Must Be Able to Use Skills Without Knowing the Standards Framework

The design team uses Claude Code today to prototype but has no knowledge of SKILL.md
files, rr-standards taxonomy, or Forge. Skills built for UI generation must be usable
by someone who types a natural-language prompt. The standards framework backing the
skills is for engineers authoring and maintaining skills — not for the end users of
those skills.
