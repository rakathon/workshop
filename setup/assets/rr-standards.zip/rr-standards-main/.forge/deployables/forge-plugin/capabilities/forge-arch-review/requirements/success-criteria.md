# Success Criteria — forge-arch-review

- [ ] An effort whose 409 response body is missing the `code` field (required by the
      REST API standard) produces a FAIL finding for that specific rule and an overall
      result of FAIL in `validation/report.md`
- [ ] An effort with no standards violations and no concerns produces an overall result
      of PASS in `validation/report.md`
- [ ] An effort with SHOULD violations but no MUST violations produces an overall result
      of PASS WITH CONCERNS in `validation/report.md`
- [ ] `validation/arch-review.html` opens in a browser directly from the filesystem
      (`file://` URL) without requiring a server; all 12 sections are present and
      reachable via the navigation sidebar
- [ ] `validation/arch-review.html` makes no external network requests (no CDN, no
      external fonts, no remote images); verified by opening with network disabled
- [ ] The navigation sidebar in `validation/arch-review.html` has anchor links to all
      12 required sections; clicking each link scrolls to the correct section
- [ ] The Requirements Traceability section in `validation/arch-review.html` flags a
      BR that has no corresponding design artifact (uncovered requirement highlighted)
- [ ] The Requirements Traceability section in `validation/report.md` shows an uncovered
      requirement with ✗ UNCOVERED status
- [ ] `forge:promote` blocks a full-tier effort with a FAIL result in
      `validation/report.md` from advancing to planning
- [ ] `forge:promote` permits a full-tier effort with a PASS WITH CONCERNS result to
      advance to planning
- [ ] `forge:promote` blocks a full-tier effort that has no `validation/report.md`
      from advancing to planning, with a message instructing the engineer to run
      `forge:arch-review`
- [ ] Lightweight-tier efforts (patch, refactor, extension, poc) are not blocked by
      the absence of `validation/report.md` at `forge:promote`
- [ ] `validation/arch-review.html` body text is at minimum 14px; each section breaks
      to a new page when printed
- [ ] The skill completes successfully when `spec/messaging/` is absent; the Messaging
      & Events section in the HTML states no messaging artifacts were found
- [ ] The skill produces a NOTE finding (not a FAIL or CONCERN) when a standards file
      referenced for a domain cannot be located in the plugin cache
