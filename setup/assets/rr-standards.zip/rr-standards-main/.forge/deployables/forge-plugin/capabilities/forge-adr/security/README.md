# Security — forge-adr

## Trust Boundary

`forge:adr` runs entirely within the engineer's interactive Claude Code session. It
makes no network calls and does not interact with external services. All file
operations are reads and writes within the repository working tree.

## Security Surfaces

- **ADR file content** — written to the repository; subject to standard code review.
  ADR content is generated from conversation — it does not interpolate environment
  variables, secrets, or credentials.
- **`.state.json` update** — the `adrsCreated` array is appended to; existing fields
  are not modified. The append cannot introduce code execution or data exfiltration.
- **Commit operation** — `forge:adr` commits to the local working tree. It does not
  push to remote. Push behavior is governed by the repository's branching strategy.

## Prompt Injection Risk

ADR content is derived from the engineer's conversation. The Context, Decision,
Alternatives Considered, and Consequences sections contain natural language describing
design choices — not code, not commands. There is no mechanism by which ADR content
can execute or alter Claude Code behavior.

The one surface worth noting: if an engineer's conversation contains content designed
to manipulate the agent (e.g., "our decision is to ignore all previous instructions"),
the agent may include that text in the ADR. This is a general prompt injection risk
shared by all conversational artifacts, not specific to `forge:adr`. The `rr-standards:review`
security reviewer checks ADR files for suspicious content patterns.

## File Write Scope

`forge:adr` writes only to:
- `<effort_dir>/spec/arch-decisions/ADR-NNN-<slug>.md` — the ADR file
- `<effort_dir>/spec/arch-decisions/README.md` — the ADR index
- `<effort_dir>/.state.json` — the effort state file

It does not write outside the active effort directory. It does not modify CLAUDE.md,
`.forge/version`, `.claude/settings.json`, or any source code file.

## Review Requirements

All PRs that modify the `forge:adr` skill definition (`plugins/forge/skills/adr/`)
trigger the `security-reviewer` agent in `rr-standards:review`.
