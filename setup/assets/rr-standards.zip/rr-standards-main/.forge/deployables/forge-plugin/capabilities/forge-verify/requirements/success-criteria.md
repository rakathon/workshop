# Success Criteria — forge-verify

---

## forge:verify Skill

### SC-V-1: Missing Requirement Coverage Produces a FAIL Report with Code Location

**Setup:** An effort where one business requirement (e.g., BR-2) has no corresponding
implementation — the task that was supposed to implement it was marked complete with a
stub.

**Action:** Run `forge:verify`.

**Expected result:**
- `verification/report.md` is written with `Result: FAIL`
- The Requirement Coverage table shows BR-2 as `FAIL`
- The Gaps section contains an entry for BR-2 identifying the specific file and
  function where the stub was detected (e.g., `src/auth/session.ts:42 — validateSession()`)
- The gap description explains that the function body is a stub (returns null / TODO)

### SC-V-2: Fully Implemented Effort Produces a PASS Report with No Gaps

**Setup:** An effort where all requirements have real implementation evidence, no stubs
in load-bearing paths, all components are wired together, and no ADRs are contradicted.

**Action:** Run `forge:verify`.

**Expected result:**
- `verification/report.md` is written with `Result: PASS`
- All rows in the Requirement Coverage tables show `PASS`
- The Gaps section is empty (or absent)
- The Summary paragraph confirms the implementation delivers the effort's stated goals

### SC-V-3: forge:verify Runs Correctly as an Isolated Sub-Agent

**Setup:** A session where the engineer has partial implementation context in their
active conversation — e.g., they have been discussing a specific task's implementation
details.

**Action:** Run `forge:verify`.

**Expected result:**
- The sub-agent reads discovery artifacts and implementation code directly from the
  file system
- The sub-agent's analysis is not influenced by the main session's conversation context
- The verification report reflects only what is in the files — not what was discussed
  in the session

### SC-V-4: forge:promote Blocks on Missing or FAIL Verification Report

**Setup:** An effort with all tasks marked complete but either:
(a) `verification/report.md` does not exist, or
(b) `verification/report.md` exists with `Result: FAIL`

**Action:** Run `forge:promote` to advance from implementation to verification phase.

**Expected result:**
- `forge:promote` does not advance the phase
- For case (a): engineer is prompted to run `forge:verify` first
- For case (b): engineer is informed the verification report shows FAIL with the gap
  count; advancement requires resolving gaps and re-running `forge:verify`

---

## Implementation Quality Loop Contract

### SC-V-5: Lint Errors Are Detected and Fixed Within the Loop

**Setup:** A task implementation that introduces a lint error (e.g., an unused import
in TypeScript with eslint configured).

**Action:** The implementation skill runs the quality loop on this task.

**Expected result:**
- Step 2 (Lint) detects the error
- The skill addresses the error in the current iteration (removes the unused import)
- Lint passes in the same or a subsequent iteration
- The task is committed only after lint passes

### SC-V-6: TDD Task Writes Failing Test Before Implementation

**Setup:** A task annotated `[tdd]` in `plan/tasks.md`.

**Action:** The implementation skill executes the task.

**Expected result:**
- Step 1 begins by writing the test, not the implementation
- The skill runs the test and confirms it fails before writing any implementation code
- If the test passes before implementation is written, the skill flags this as an
  incorrect test and does not proceed to implementation
- Only after the test is confirmed failing does the skill write implementation code
- The loop continues until the test passes

### SC-V-7: Iteration Limit Reached — Escalation State Written to .state.json

**Setup:** A task where all three iterations fail (lint errors in iteration 1, test
failure in iterations 2 and 3 that cannot be resolved autonomously).

**Action:** The implementation skill runs the quality loop.

**Expected result:**
- After the third iteration, the skill does not attempt a fourth iteration
- `.state.json` `pause` field contains:
  - `reason: "quality_loop_limit_reached"`
  - `taskId` and `taskDescription` for the blocked task
  - `iterationsAttempted: 3`
  - `remainingFailures` with the specific errors still present
  - `iterationSummary` with a one-line summary of each iteration
  - `suggestedNextAction` with a specific, actionable recommendation
- The task is NOT marked complete in `plan/tasks.md`
- The engineer is presented with the escalation state

### SC-V-8: Resumed Task Presents Prior Escalation Context

**Setup:** A task that was escalated (SC-V-7) in a prior session. The engineer is now
resuming work.

**Action:** The implementation skill is invoked on the blocked task.

**Expected result:**
- The skill detects existing escalation state in `.state.json`
- The prior iteration summary and remaining failures are presented to the engineer
  before any new implementation begins
- The engineer is asked how to proceed (modify approach, update spec, override)
- The iteration counter resets to 0 for the resumed attempt
