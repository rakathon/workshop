# Test Plan — forge-plan

## Test Strategy

`forge:plan` is a skill executed by an AI agent. Its outputs are markdown files
containing annotated task lists. Testing focuses on output correctness — does the
generated plan have the right annotations, the right wave groupings, and coverage
of all requirements?

## Test Scenarios

### Annotation Correctness

**Scenario:** A requirements set containing a repository layer, a service layer, an
API handler, and a scaffolding task.

Expected annotations:
- Scaffolding task → `[auto]`
- Repository layer task → `[tdd]`
- Service layer task → `[tdd]`
- API handler task → `[tdd]`

**Scenario:** A requirements set that includes a task requiring confirmation of a
contract with an external team.

Expected: task receives `[checkpoint]` annotation with a note explaining what needs
confirming.

**Scenario:** A requirements set that includes a production data migration step
requiring DBA approval.

Expected: migration task receives `[manual]` annotation.

### Wave Assignment Correctness

**Scenario:** Requirements set where service layer depends on repository layer;
API handler depends on service layer; scaffolding has no dependencies.

Expected wave assignments:
- Scaffolding → `wave:1`
- Repository layer → `wave:2`
- Service layer → `wave:3`
- API handler → `wave:4`

**Scenario:** Two independent feature areas (e.g., favorites and recommendations)
with no dependency between them.

Expected: both feature areas receive tasks in the same wave grouping rather than
being sequenced unnecessarily.

### Vertical Slice / Just-In-Time Infrastructure

**Scenario:** An effort with three user story clusters — Browsing (wave 1–3),
Location (wave 4–5), and Search (wave 6) — where four API proxy routes exist:
feedapi and detail-api required by Browsing; geocode and city-autocomplete required
only by Search.

Expected:
- `feedapi` proxy and `detail-api` proxy → assigned to the same wave as the first
  Browsing task that calls them (wave 1)
- `geocode` proxy and `city-autocomplete` proxy → assigned to the same wave as the
  first Search task that calls them (wave 5 or 6), **not wave 1**
- No standalone "infrastructure wave" precedes the first user-story wave

**Scenario:** A shared utility (e.g., a distance calculation function) consumed by
both Browsing (cluster 1) and Location (cluster 2).

Expected: the utility is assigned to the earliest wave in cluster 1, not extracted
into a separate foundational wave.

### Delivery Diagram Presence

**Scenario:** Any completed epic-path plan.

Expected:
- `plan/tasks.md` contains a Mermaid `gantt` block immediately after the intro
  paragraph and before the first `## Wave` section
- The diagram has one `section` per story/feature cluster
- Each cluster has a `milestone` entry at the wave where it first becomes observable
- Any `[checkpoint]` task appears as `crit` in the diagram
- Any wave where two clusters overlap contains a `%%` comment naming both clusters

### Requirements Coverage

**Scenario:** Requirements document containing 5 business requirements and 8 technical
requirements.

Expected: every requirement has at least one corresponding task in the plan; no
requirement is unaddressed.

### Format Compliance

**Scenario:** Any completed plan.

Expected: every task matches the ADR-005 format exactly:
`- [ ] [type][wave:N] Description (TASK-NNN)`

### Coordination Plan Output

**Scenario:** Coordination effort with two deployable repositories.

Expected: `plan/plan.md` is written alongside `plan/tasks.md`, with one section per
deployable, each containing acceptance criteria and cross-deployable dependencies.

**Scenario:** Non-coordination effort.

Expected: only `plan/tasks.md` is written; no `plan/plan.md`.

## Reference Test Case: favorite-stores

The canonical reference test for `forge:plan` uses the `favorite-stores` effort.
The plan it generates must include:
- TASK-003 as `[tdd][wave:2]` — the FavoritesRepository implementation
- TASK-009 as `[checkpoint][wave:4]` — the feature flag wiring requiring platform team
  confirmation

These are acceptance criteria for the capability (see
[success-criteria.md](../requirements/success-criteria.md)).
