← [Decisions Index](README.md)

# ADR-001: Use GitHub Actions for Scheduled Slack Import

**Status:** Accepted
**Date:** 2026-04-21
**Created by:** slack-support

---

## Context

`forge:slack-import` needs to run on a recurring schedule to keep effort message
files up to date without requiring manual intervention. Two mechanisms were considered:

1. **Claude Code crons** (`CronCreate`) — registered within the Claude Code session,
   run locally on the developer's machine.
2. **GitHub Actions scheduled workflow** — registered in `.github/workflows/`, run
   on GitHub's infrastructure using the `schedule` (cron) event.

## Decision

Use GitHub Actions as the scheduling mechanism.

## Rationale

| Criterion | Claude Code cron | GitHub Actions |
|---|---|---|
| Runs without IDE open | No — requires active Claude Code session | Yes — runs on GitHub's runners |
| Auditable / version-controlled | No — stored in local session state | Yes — workflow file in repo |
| Credentials management | Local environment variables | GitHub Actions secrets |
| Team visibility | Per-developer | Shared; visible in Actions tab |
| Reliability | Dependent on developer uptime | GitHub SLA |

The import is fundamentally a background data-collection job. Tying it to a
developer's local session undermines the goal of continuous, unattended import.
GitHub Actions is the right tool for headless, scheduled repository operations.

## Consequences

**Positive:**
- Import runs reliably without any developer session active
- Schedule is version-controlled and visible to the whole team in the Actions tab
- Credentials are managed via GitHub Actions secrets, not per-developer environment variables

**Negative:**
- A `.github/workflows/slack-import.yml` file must be added and maintained
- Slack authentication must be available to the GitHub Actions runner (bot token via secrets)
- The Claude Code CLI must be installed as a workflow step

## Alternatives Considered

**Claude Code crons:** Rejected because import reliability depends on a developer
having the IDE running on a machine with valid credentials — not acceptable for
a background data collection workflow.
