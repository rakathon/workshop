# Skills — forge-classify

## forge:classify

**Classification:** Orchestrator

**Conversational equivalent:** "classify the risk", "what risk level is this?",
"set the risk tier", "is this R1 or R2?"

**Arguments:** `<effort-id>` (required — the effort slug from `.forge/efforts/<id>/`)

**Inputs:**
- `<effort_dir>/.state.json` — reads `suggestedRisk`, `suggestedRiskRationale`, `risk`
- `<effort_dir>/requirements/business.md` — if present, informs rubric application
- `<plugin_root>/standards/risk/classification.md` — the risk rubric

**Outputs:**
- `<effort_dir>/.state.json` — writes `risk` and `riskRationale`; clears `suggestedRisk` and `suggestedRiskRationale`
- No artifact files written

---

## Steps

**Step 1 — Read current state**

Read `.state.json`. Surface `suggestedRisk` if present.
Surface current `risk` if already set.

**Step 2 — Read business requirements**

Read `requirements/business.md` if present. Note absence without blocking.

**Step 3 — Load risk rubric**

Load `standards/risk/classification.md`. Fall back to built-in rubric if absent.

**Step 4 — Apply rubric, derive recommendation**

Evaluate requirements against each rubric tier. Show indicators that fired,
higher-tier indicators that did not, and lower-tier indicators that were
overridden. Format:
```
Recommended: <R?>

Why <R?>:
  ✓ <fired indicator>

Why not higher:
  ✗ <R1 indicator> — not present

Why not lower:
  ✗ <R? indicator> — <condition> not met
```

**Step 5 — Confirm with engineer**

Three valid responses:
- **Confirm** — accept recommendation
- **Override** — specify tier + brief rationale
- **Revise** — reconsider; skill stops without writing

**Step 6 — Write to .state.json**

Write `risk` (R-notation only) and `riskRationale`. Clear `suggestedRisk` and
`suggestedRiskRationale` if present.

**Step 7 — Print summary**

```
Risk classification set: <R?> — <riskRationale>

What this means:
  <tier consequence line>

Next steps:
  forge:elaborate <effort-id>
  forge:spec-api <effort-id>
```

---

## Re-invocation

Re-invoke at any phase to revise the classification. Shows current tier and
rationale, asks what prompted the revision, runs full recommendation flow.

---

## Error Handling

| Condition | Behavior |
|-----------|---------|
| `.state.json` not found | Stop: "No active effort found. Run forge:effort to initialize one." |
| `currentPhase` not `discovery` | Warn + confirm before proceeding |
| Engineer does not decide after two exchanges | Stop; suggest re-invoking when ready |
