# Test Strategy — forge-about-me

## Approach

Behavioral tests via `test.yaml` evaluated with `/rr-standards:test-skill`.
The skill is conversational so test cases simulate multi-turn input by
embedding the user's responses directly in the prompt.

## Test Cases (planned)

| ID | Name | What it validates |
|----|------|------------------|
| `cv-provided-happy-path` | Full flow with CV | Extraction skips inferable fields; deep-dive fills only gaps; output is correctly assembled |
| `no-materials-happy-path` | Full flow without materials | Falls back to question sequence; all required fields collected before assembly |
| `writing-sample-anti-pattern-filter` | Anti-pattern filtering | Patterns present in user samples are omitted from the output instruction |
| `surface-cli-claudemd` | CLI surface → CLAUDE.md append | Detection fires correctly; user chooses CLAUDE.md; existing content preserved |
| `surface-cli-file` | CLI surface → about-me.md | Detection fires correctly; user declines CLAUDE.md; file saved as about-me.md |
| `surface-desktop` | Desktop/Chat surface | No CLI detection; block saved as about-me.md; Custom Instructions guidance printed |
| `no-writing-samples` | No samples provided | Three fallback questions asked; all eight anti-patterns included in output |

## Notes

- Surface detection tests use fixture files (`.git/` stub or `CLAUDE.md`) to
  simulate CLI vs. Desktop environments
- The Company Context section should be verified verbatim in at least one test
- The 250-word descriptive content limit should be validated in the happy-path tests
