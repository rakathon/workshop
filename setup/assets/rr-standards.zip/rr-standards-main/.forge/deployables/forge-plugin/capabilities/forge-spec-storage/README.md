# forge-spec-storage

Designs storage schemas during discovery. Infers storage type, loads the applicable
standard, and guides the engineer through each entity with inline checks (PK, FK, index
strategy, soft-delete policy, GDPR retention for PII fields) firing immediately after
each entity is confirmed.

**Skill:** `forge:spec-storage`  **Classification:** Orchestrator
Part of the spec-driven-development initiative (Initiative 3).
