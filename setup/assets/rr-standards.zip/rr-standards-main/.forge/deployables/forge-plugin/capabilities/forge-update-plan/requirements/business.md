# Business Requirements: forge:update-plan

## Context

The Forge framework tracks implementation progress in two canonical artifacts:
`plan/tasks.md` (the human-readable task checklist) and `.state.json` (the
machine-readable workflow state). Both must remain accurate for downstream skills
(`forge:verify`, `forge:status`, Jira sync) to produce correct results.

## Business Requirements

### BR-1: Prevent plan drift after task completion

After completing an implementation task and committing, engineers frequently forget
to update `plan/tasks.md` and `.state.json`. This creates plan drift: tasks appear
incomplete in the plan when they are done in the code. `forge:verify`, `forge:status`,
and Jira sync all depend on plan accuracy — if the plan drifts, these downstream
skills produce incorrect results.

**Outcome:** The plan and state reflect the true implementation status of each task
immediately after a commit completes that task.

### BR-2: Establish a machine-readable link between tasks and commit evidence

Recording the commit SHA inline in `plan/tasks.md` creates a permanent machine-readable
link between each task and its implementation evidence. Without this link, `forge:verify`
must heuristically match commits to tasks (fragile and error-prone).

**Outcome:** Each completed task entry in `plan/tasks.md` contains the SHA of the commit
that completed it, enabling reliable traceability from task to code.

### BR-3: Automatically queue Jira sync on task completion

Jira sync must be triggered automatically when a task is marked complete — engineers
should not need to remember to trigger it separately. A `jira.syncStatus = "pending"`
flag is the trigger signal consumed by the Jira sync process.

**Outcome:** Jira tickets are updated to reflect task completion without requiring a
separate manual action from the engineer.

### BR-4: Detect the target task from the commit when no argument is given

The task to mark complete should be detectable from the most recent commit (if the
commit message or git note contains a TASK-NNN reference) — the engineer should not
need to type the task ID if it can be inferred.

**Outcome:** Engineers can run `forge:update-plan` immediately after `forge:commit`
with no arguments and the correct task is identified automatically.
