# Technical Requirements — forge-clear

Parent deployable: [forge-plugin](../../requirements/technical.md)

---

## TR-1: forge:clear Skill

### TR-1.1: Command Surface

`forge:clear` takes no arguments. It is idempotent: running it when no active
effort is set must print an informational message and exit cleanly without error.

### TR-1.2: File Operation

`forge:clear` must delete `.forge/EFFORT` using `rm -f` (no error if absent).
It must not read, write, or touch any other file — specifically:

- `.forge/efforts/<id>/.state.json` — must not be modified
- `plan/tasks.md` or any other effort artifact — must not be modified
- No git staging or committing

### TR-1.3: Output

On success, `forge:clear` must print:

```
Active effort cleared: <effort-id>

To reactivate this effort, run forge:effort and select <effort-id>,
or run forge:resume if you left off mid-task.
```

When no active effort is set:

```
No active effort is set.
```

### TR-1.4: No State Side Effects

`forge:clear` must not write `.forge/EFFORT` under any circumstance. It may
only delete it.
