# Skills — forge-effort

Design for the four skills delivered by the forge-effort capability. All four are
orchestrator-type skills that run in the engineer's Claude Code session and use
Claude Code tools (Read, Write, Edit, Bash) for all file operations.

Related: [state-schema.md](state-schema.md) | [hooks.md](hooks.md)

Implementation location: `plugins/forge/skills/`

---

## forge:effort

### Purpose

Create and scaffold a new work effort: create the effort directory under `.forge/efforts/`,
write `.state.json` with all required fields, and register the effort in `.forge/efforts/README.md`.
The conversational equivalent is Claude recognizing a scope statement ("we need to build X")
and taking these actions automatically.

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `<title>` | Optional | Human-readable effort title. Prompted if absent. |
| `--type` | Optional | Work item type: `program \| initiative \| epic \| story \| task \| spike`. Prompted if absent. |
| `--subtype` | Optional | For lightweight efforts: `patch \| refactor \| extension \| poc`. Prompted if absent. |
| `--parent` | Optional | ID of the parent effort (same repo) or `repo:org/repo/id` for cross-repo parent. |
| `--risk` | Optional | Risk classification: `R1 \| R2 \| R3 \| R4`. Prompted if absent. |
| `--timebox` | Optional | Target completion date in ISO-8601 format (e.g., `2026-04-30`). |

### Preconditions

- **PC-1:** Repository has been initialized (`forge:init`) — `.forge/efforts/README.md` exists.
- **PC-2:** If `--parent` is provided, the parent effort exists (same-repo) or is reachable
  (cross-repo). A missing parent is a warning, not a blocker — the effort is created with a
  dangling parent reference that can be resolved later.
- **PC-3:** No existing effort with the same ID exists in `.forge/efforts/`.

### Flow

```
Step 1: Gather effort identity
        If title not provided: prompt "What is the effort title?"
        Derive effort ID from title: lowercase, hyphens for spaces, strip special chars
        (e.g., "Favorites Feature — Backend" → "favorites-feature-backend")
        Check .forge/efforts/<id>/ does not already exist

Step 2: Determine effort classification
        If type not provided: prompt "What type of work item is this?"
          (program / initiative / epic / story / task / spike)
        Determine tier:
          program, initiative, epic → always "full"
          story, task, spike → prompt "Is this a full-tier effort or lightweight?"
        If lightweight: prompt for subtype (patch / refactor / extension / poc)
        Set productionBound:
          poc → false
          all others → true

Step 3: Determine risk classification
        If risk not provided:
          For full-tier: prompt "What is the risk level? R1 (auth/payments/PII),
          R2 (core features), R3 (new features), R4 (logging/minor changes)"
          For lightweight patch/refactor: default R4 unless engineer specifies
          For lightweight extension: prompt for R1-R4
          For poc: default R4 (non-blocking; poc is never production-bound)

Step 4: Determine phase starting point
        Full-tier (program/initiative/epic/story/task): currentPhase = "discovery"
        Full-tier spike: currentPhase = "investigation"
        Lightweight patch: currentPhase = "implementation"
        Lightweight refactor: currentPhase = "implementation"
        Lightweight extension: currentPhase = "discovery" if scope is non-trivial; else "implementation"
        Lightweight poc: currentPhase = "implementation"

Step 5: Scaffold effort directory
        Create: .forge/efforts/<id>/
        Create: .forge/efforts/<id>/requirements/   (full-tier and extension only)
        Create: .forge/efforts/<id>/spec/           (full-tier and extension only)
        Create: .forge/efforts/<id>/spec/arch-decisions/
        Create: .forge/efforts/<id>/plan/           (full-tier; optional for refactor/extension)
        Create: .forge/efforts/<id>/validation/     (full-tier only)
        Create: .forge/efforts/<id>/meetings/       (full-tier and extension only; empty at creation)
        Create: .forge/efforts/<id>/upstream-proposals/  (if coordinationRef will be set)

Step 6: Write .state.json
        Write all required fields (see TR-1 in requirements/technical.md)
        Key ordering: alphabetical at every nesting level
        Array formatting: one item per line
        Set phases object with appropriate phase set per tier and type:
          Full-tier: discovery, validation, planning, implementation, verification
          Spike: investigation, findings
          Lightweight patch/poc: implementation only
          Lightweight refactor: planning (not_started), implementation
          Lightweight extension: discovery (not_started if optional), planning (not_started if optional), implementation

Step 7: Update .forge/efforts/README.md
        Add one row to the efforts table for the new effort
        If parent is provided, indent the row beneath the parent's row
        Use the column order: ID | Title | Type | Tier | Risk | Phase | Status

Step 8: Commit atomically
        Stage: .forge/efforts/<id>/ (all scaffolded files)
        Stage: .forge/efforts/<id>/.state.json
        Stage: .forge/efforts/README.md
        Commit message: "chore(<id>): scaffold <title> effort"

Step 8.5: Create and checkout the working branch [orchestrator-only]
        Run: git checkout -b effort/<id>
        If the branch already exists: git checkout effort/<id> (idempotent — no error)
        Confirm to engineer: "Working branch: effort/<id> (created)"
        or if the branch already existed: "Working branch: effort/<id> (resumed)"

Step 9: Print summary
        Effort created: <id>
        Type: <type> | Tier: <tier> | Risk: <risk>
        Subtype: <subtype | "full-tier">
        Production-bound: <yes | no>
        Phase: <currentPhase>
        Directory: .forge/efforts/<id>/
        Next: <first action appropriate for the effort type and phase>
```

### Output

A printed summary confirming the effort ID, classification, and next action. The effort
directory is scaffolded and `.state.json` is written and committed.

### Deviation Rules

**Autonomous:**
- Deriving the effort ID from the title (always the same transformation).
- Defaulting risk to R4 for patch and poc subtypes.
- Creating all required subdirectories for the effort type without prompting.

**Escalate to engineer:**
- Ambiguous scope that could be either a story or an epic — prompt to clarify.
- Parent effort not found — warn and confirm whether to proceed with dangling reference.
- Effort ID collision — present the existing effort and ask whether to use a different name.

### [orchestrator-only]

- Reading `.state.json` from the current effort context to determine active effort.
- Reading `.forge/efforts/README.md` to check for existing efforts before scaffolding.
- Updating the registry row after scaffolding.
- Printing the summary to the engineer.

---

## forge:status

### Purpose

Read the current effort's `.state.json` and present a human-readable summary of phase,
artifact inventory, open decisions, wave-level task completion, and next suggested action.
The conversational equivalent is Claude reading state and responding to "where are we?"

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `[effort-id]` | Optional | Specific effort to report on. Defaults to the current active effort. |
| `--verbose` | Optional | Include the full artifact routing table and post-approval modification list. |

### Preconditions

- **PC-1:** `.forge/efforts/README.md` exists.
- **PC-2:** The target effort has a `.state.json` file.

### Flow

```
Step 1: Identify target effort
        If effort-id provided: use it
        If single active effort: use it
        If branch matches an effort ID: use that effort
        If multiple active and no branch match: list all and prompt to clarify

Step 2: Read .state.json

Step 3: Build status summary
        Header: <id> (<type>, <tier>, <risk>)
        Current phase: <currentPhase> (<status>)
        Subtype and production-bound status (lightweight efforts)

Step 4: Report artifact inventory
        For each artifact type expected for this effort's tier and subtype:
          Present: ✓ <path>
          Absent:  ✗ <path> (required | optional)
        For implementation phase: show wave completion
          Wave 1: 3/3 tasks complete ✓
          Wave 2: 1/4 tasks complete (in progress)
          Wave 3: 0/2 tasks (not started)

Step 5: Report open decisions
        If none: "No open decisions."
        If any: list each with ID, description, and blocked task (if any)

Step 6: Report post-approval modifications
        If none: "No post-approval modifications."
        If any: list each file and the phase during which it was modified
        (--verbose only)

Step 7: Report pause state
        If pauseState is populated: show active task and next action
        If not: skip

Step 8: Suggest next action
        Derive from currentPhase, artifact inventory, and openDecisions:
          Discovery with missing artifacts → "Create <missing artifact>"
          Discovery complete, not approved → "Ready for arch review; run forge:arch-review or proceed conversationally"
          Planning → "Generate implementation plan from discovery artifacts"
          Implementation with tasks remaining → "Continue with <next task in current wave>"
          Blocked open decision → "Resolve OD-NNN: <description> before continuing"
          All tasks complete → "Run forge:verify or proceed to verification"
```

### Output

A Markdown-formatted status block printed to the engineer. No files are written.

### Deviation Rules

**Autonomous:**
- Deriving the next suggested action from the current state.
- Identifying wave completion from `plan/tasks.md` (parsed at read time, not from stale state).

**Escalate to engineer:**
- Inconsistency between `plan/tasks.md` and `phases.implementation` in `.state.json` —
  surface the discrepancy rather than silently resolving it.

### [orchestrator-only]

All behavior in this skill is orchestrator-only. `forge:status` does not run as a worker
sub-agent — it always runs in the main session to report to the engineer.

---

## forge:pause

### Purpose

Persist the current session's mid-task state to `.state.json` so that a subsequent session
can resume without information loss. The conversational equivalent is Claude recognizing a
"let's pick this up tomorrow" or "I need to stop here" signal and persisting pause state
automatically.

### Arguments

None. `forge:pause` derives all context from the current session and `.state.json`.

### Preconditions

- **PC-1:** An active effort exists (`.state.json` is present).
- **PC-2:** The effort is in a phase where mid-task state exists to persist (typically
  implementation, but also applicable in discovery or planning if work is incomplete).

### Flow

```
Step 1: Identify the active effort (same heuristic as forge:status Step 1)

Step 2: Read .state.json

Step 3: Identify current task state
        If in implementation phase: read plan/tasks.md to identify which task is in
        progress (last task marked in-progress or last attempted task)
        If in discovery phase: identify which artifact was most recently worked on
        If in planning phase: identify current planning state

Step 4: Compose the pause state object
        pauseState: {
          "activeTask": "<TASK-ID or null>",
          "activePhase": "<currentPhase>",
          "lastCompletedStep": "<description of last completed step>",
          "contextSummary": "<2-3 sentence summary of where we are and what decisions were made this session>",
          "nextAction": "<specific description of the next step the resuming agent should take>",
          "pausedAt": "<ISO-8601 timestamp>"
        }
        The contextSummary must include enough detail that a new session can resume without
        reading the full conversation history. It should capture:
          - The problem being solved or the artifact being produced
          - Any decisions made this session that are not yet in an ADR
          - Any constraints or concerns that are in-context but not in state files

Step 5: Write pauseState to .state.json
        Merge the pauseState object into the existing .state.json
        Preserve all other fields unchanged

Step 6: Commit the updated .state.json
        Commit message: "chore(<effort-id>): pause session — <brief description>"

Step 7: Print confirmation
        "Paused. Next session: <nextAction>"
        Remind the engineer of any open decisions that should be resolved before resuming.
```

### Output

A confirmation message with the next action and any open decisions. `.state.json` is
updated and committed with the pause state.

### Deviation Rules

**Autonomous:**
- Composing the contextSummary from the current session.
- Deriving the nextAction from the current task state.

**Escalate to engineer:**
- If the current task is in a failed or blocked state (e.g., a quality loop exceeded its
  iteration limit) — describe the exact failure before pausing, so the engineer can decide
  whether to note it in the pauseState or take action before stopping.

### [orchestrator-only]

- Reading session conversation history to compose the contextSummary.
- Printing the pause confirmation to the engineer.

---

## forge:resume

### Purpose

Restore pause state from `.state.json` and re-inject the context the resuming agent needs to
continue without reconstruction. Typically triggered automatically by the SessionStart hook
when it detects a populated `pauseState` field — this skill provides the explicit invocation
path for the same behavior.

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `[effort-id]` | Optional | Specific effort to resume. Defaults to the current active effort. |

### Preconditions

- **PC-1:** An active effort with a populated `pauseState` field in `.state.json`.
- **PC-2:** The effort directory is intact (scaffolded directories and artifacts are present).

### Flow

```
Step 1: Identify the active effort (same heuristic as forge:status Step 1)

Step 2: Read .state.json

Step 3: Check for pauseState
        If pauseState is null or absent: emit "No pause state found for <id>. Nothing to resume."
        and suggest running forge:status to see current state.

Step 4: Re-inject context
        Present the pause state clearly:
          "Resuming <effort-id>."
          "Last session summary: <pauseState.contextSummary>"
          "Active task: <pauseState.activeTask>"
          "Next action: <pauseState.nextAction>"

Step 5: Surface open decisions
        List any openDecisions that were present at pause time.
        Note which decisions are blocking tasks.

Step 6: Check artifact currency
        Read the current artifact inventory from .state.json.
        If any artifacts were expected but are absent (e.g., a file was started but not saved),
        surface this gap. Do not assume the pause state is consistent with the file system.

Step 7: Clear the pauseState
        After re-injecting context, clear the pauseState field from .state.json:
          pauseState: null
        This signals that the effort is actively in progress, not paused.
        The clearing is committed immediately.

Step 8: Commit
        Commit message: "chore(<effort-id>): resume session"

Step 9: Ready to proceed
        Confirm to the engineer that context is restored and the effort is ready to continue.
        Do not begin the resumed task automatically — wait for the engineer to confirm or redirect.
```

### Output

A printed context summary with the last session's state, next action, and any open decisions.
`pauseState` is cleared from `.state.json` and committed.

### Deviation Rules

**Autonomous:**
- Clearing the pauseState after re-injection.
- Surfacing the next action from the preserved state.

**Escalate to engineer:**
- If the `nextAction` in pauseState references a task that no longer exists in `plan/tasks.md`
  (e.g., the plan was revised between sessions) — surface the discrepancy and ask the engineer
  to clarify the intended next step.
- If open decisions were not resolved between sessions — list them and ask whether to proceed
  with the blocked tasks anyway or resolve the decisions first.

### [orchestrator-only]

- Printing the resume summary to the engineer.
- Deciding whether to wait for confirmation before proceeding with the resumed task.
