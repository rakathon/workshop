# Business Requirements — forge-graduate

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program BRs addressed: BR-7, BR-12

---

## BR-1: Effort Directories Are Working Space, Not Permanent Documentation

An effort directory is a scratchpad for the journey from intent to working software. While
work is in progress, the effort directory is the right place for requirements drafts,
evolving specifications, and open decisions. Once work is done, the effort directory
becomes a historical record — useful for understanding how a decision was reached, but not
the right place to look for what the deployable does now.

Engineers should not need to read a closed effort directory to understand a deployable's
current behavior, API surface, or storage model. The authoritative reference for what a
deployable is must live in the deployable's canonical documentation, not scattered across
closed effort directories.

## BR-2: Engineers Need a Permanent, Maintained Reference for What a Deployable Does

The question "what does this deployable do and why?" must have a single authoritative
answer. That answer cannot live in an effort directory that was closed six months ago,
cannot be reconstructed by reading a sequence of closed efforts in order, and cannot
require understanding the full history of the work to get the current state.

The deployable's canonical documentation — requirements, specifications, architecture
decisions — must represent the current, coherent state of the deployable. When a new
engineer joins a team, or when an existing engineer starts a new effort that touches an
existing deployable, the canonical documentation must be the starting point. Graduation
is the operation that keeps this documentation current.

## BR-3: Post-Approval Modifications Made During Implementation Must Be Reconciled Before Promotion

Software development is not waterfall. Approved requirements get refined during
implementation. Agreed specifications get adjusted when code exposes unforeseen
constraints. This is expected and permitted — the workflow records these modifications
rather than blocking them.

At graduation, all post-approval modifications must be visible and deliberately addressed.
The graduated artifact must represent a final, coherent state — not the originally approved
design with patches silently applied on top. An engineer performing graduation must see
which artifacts were modified after approval and confirm that the graduated result is
intentional, not an accidental accumulation of implementation-time changes.

Silently promoting a modified artifact without flagging the modification is a graduation
failure. The reconciliation is not a veto — the modification may well be correct — but
it must be acknowledged, not bypassed.

## BR-4: The Effort Record and the Deployable Docs Serve Different Questions

The effort directory answers: "How did we get here? What was considered and rejected?
What was the approved baseline before implementation began? What was discovered during
implementation that changed the design?"

The deployable documentation answers: "What is this deployable now? What does it do,
how is it structured, and why were its key decisions made?"

Both questions are legitimate, but they must be answered in different places. Graduation
is the operation that ensures the deployable documentation answers its question correctly
after each effort completes. The effort directory remains as a permanent historical record;
the deployable documentation becomes authoritative for the current state.

## BR-5: Graduation Must Be Explicit, Not Automatic

Completing all tasks, merging the PR, and passing QA are necessary conditions for
graduation — they are not sufficient. Graduation is a deliberate operation that the
engineer or their agent invokes after confirming that QA has approved the feature in a
pre-production environment.

This deliberateness matters because graduation modifies the canonical documentation.
Automatically promoting effort artifacts at PR merge would promote artifacts before the
feature has been validated end-to-end. Graduation after QA sign-off ensures that only
validated work reaches the canonical record.
