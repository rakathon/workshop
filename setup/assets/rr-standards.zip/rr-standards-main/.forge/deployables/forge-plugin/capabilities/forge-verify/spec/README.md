# forge-verify Specification

## What This Capability Delivers

Two distinct things that serve different purposes in the workflow:

1. **`forge:verify` skill** — a one-pass semantic check that the complete
   implementation delivers the effort's stated goals. Runs after all tasks are marked
   complete, before `forge:promote` advances to the verification phase.

2. **Implementation quality loop contract** — a shared behavioral specification that
   all `forge:build-*` implementation skills execute. Defines the per-task loop:
   implement → lint → validate against spec → test → commit (or escalate).

These are distinct in scope and timing. The quality loop runs inside each task, in each
implementation skill, before the task is committed. `forge:verify` runs once, after all
tasks are committed, and checks whether the aggregate implementation delivers what the
effort promised. The quality loop catches per-task correctness; `forge:verify` catches
integration gaps and semantic delivery failures that no individual task loop can see.

See [ADR-007](arch-decisions/) for the reasoning behind this separation.

## Key Design Decisions

### forge:verify Is a Single-Pass Analytical Skill

`forge:verify` does not loop. It reads artifacts and code, produces a report, and exits.
It does not run linters or test suites — those are the quality loop's responsibility
and have already run for every task before any task was committed.

`forge:verify`'s scope is goal delivery: does the whole thing work? Does the
implementation cover every BR and TR? Are stubs present where real behavior is expected?
Is integration wiring in place? These are questions that can only be answered by looking
at the full implementation at once.

### The Quality Loop Is Infrastructure, Not Skill Logic

The loop is not implemented independently in each `forge:build-*` skill. It is defined
once as a contract (`spec/skills.md`, build-contract section) and referenced by every
implementation skill. This ensures consistent iteration limits, escalation formats,
TDD discipline, and linter detection across all implementation skills.

### Isolation Enables Consistent Analysis

`forge:verify` runs as an isolated sub-agent for the same reason `forge:arch-review`
does: the full discovery artifact set plus the implementation codebase would consume
the context the engineer needs for subsequent work. Running isolated also prevents the
main session's partial implementation discussion from influencing the verification
analysis.

## Contents

| File | Purpose |
|------|---------|
| [skills.md](skills.md) | forge:verify skill design + quality loop contract |
| [arch-decisions/](arch-decisions/) | ADRs scoped to this capability |
