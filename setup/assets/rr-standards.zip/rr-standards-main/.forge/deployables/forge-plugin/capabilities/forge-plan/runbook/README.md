# Runbook — forge-plan

## Invoking forge:plan

**Direct invocation:**
```
forge:plan <effort-id>
```

Example: `forge:plan favorite-stores`

**Conversational invocation:**
- "Let's break this into tasks"
- "Let's plan the implementation for favorite-stores"
- "What do we need to build for this effort?"

## Prerequisites

Before invoking `forge:plan`, the effort must be in the planning phase. This means:
- Discovery artifacts are present (requirements, at least one spec artifact)
- For full-tier efforts: `validation/report.md` is present with a PASS or PASS WITH
  CONCERNS result
- The effort has been promoted to planning via `forge:promote`

If discovery artifacts are missing, `forge:plan` will produce an incomplete plan.
Run `forge:promote` to verify readiness before invoking `forge:plan`.

## Output Location

After `forge:plan` completes:
- `plan/tasks.md` — the annotated task list, committed to the effort directory
- `plan/plan.md` — coordination plan (coordination efforts only), committed alongside
  `plan/tasks.md`

## Reviewing the Generated Plan

After `forge:plan` writes the plan, review it before advancing to implementation:

1. Verify every task has both a type and wave annotation
2. Verify wave ordering matches the actual dependency structure
3. Verify TDD-appropriate tasks (repository, service, domain logic) are annotated
   `[tdd]`
4. Verify checkpoint tasks have clear notes explaining what needs confirming
5. Verify all requirements are addressed by at least one task

If corrections are needed, edit `plan/tasks.md` directly. The annotation format is
plain markdown — edits are straightforward.

## Advancing to Implementation

After the plan is reviewed and correct, use `forge:promote` to advance the effort
from planning to implementation:

```
forge:promote <effort-id>
```

`forge:promote` checks that `plan/tasks.md` is present and contains at least one
wave of tasks before allowing the transition.

## Troubleshooting

**Problem:** Generated plan is missing tasks for a requirement.

**Resolution:** The requirement may not be explicit in the artifacts, or the spec
artifact may be absent. Add the missing spec artifact and re-run `forge:plan`, or
add the missing tasks manually to `plan/tasks.md`.

**Problem:** Wave grouping looks wrong — tasks that should be parallel are sequential.

**Resolution:** `forge:plan` infers dependencies from the artifacts. If the spec
does not make the independence explicit, the skill may be conservative and sequence
tasks that could be parallel. Edit `plan/tasks.md` to correct the wave assignments.

**Problem:** A task is annotated `[auto]` but should be `[checkpoint]`.

**Resolution:** The checkpoint condition may not be described in the requirements
or spec. Add the checkpoint context to the spec (an open decision, an interface
confirmation needed) and re-run, or edit the annotation manually.
