# Security — forge-clear

## Trust Boundary

`forge:clear` runs within the engineer's interactive Claude Code session. It
performs a single file deletion (`rm -f .forge/EFFORT`) and prints output.

## Security Surfaces

- **`.forge/EFFORT`** — gitignored; contains only an effort ID string. Deleting
  it has no security implications: it is a session-local pointer, not a
  credential or secret.
- No network calls, no external API access, no credential handling.

## Review Requirements

No special review requirements. This skill has no security-sensitive surfaces.
