# forge-spec-api

Co-authors REST API contracts during discovery. Loads the REST standard, proposes a
resource breakdown, designs one resource at a time with inline standard checks, and
writes the completed contract to `<spec_dir>/<contract>.yaml` (one file per contract,
covering all resources).

**Skill:** `forge:spec-api`  **Classification:** Orchestrator
Part of the spec-driven-development initiative (Initiative 3).
