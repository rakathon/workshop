# forge:clear Skill Design

Design for the `forge:clear` skill. The skill is interactive, runs in the
engineer's Claude Code session, and uses only the Bash tool.

Related: [effort-resolution.md](../../../../plugins/forge/skills/common/effort-resolution.md)

Implementation: `plugins/forge/skills/clear/`

---

## forge:clear

### Arguments

None.

### Preconditions

None. The skill is always safe to run.

### Flow

```
Step 1: Check for active effort pointer
        Read .forge/EFFORT (tr -d whitespace)
        If absent or empty → print "No active effort is set." → stop

Step 2: Delete the pointer
        rm -f .forge/EFFORT
        Print "Active effort cleared: <effort-id>"
        Do not touch .state.json or any other file
        Do not stage or commit anything

Step 3: Print recovery hint
        "To reactivate this effort, run forge:effort and select <effort-id>,
         or run forge:resume if you left off mid-task."
```

### Key Design Decisions

- `forge:clear` reads `.forge/EFFORT` directly rather than using the full
  effort-resolution chain. The resolution chain may fall back to in-session
  context (Step 3) and write `.forge/EFFORT` at Step 4 — neither is appropriate
  for a skill whose only job is to remove the pointer.
- No git operations. `.forge/EFFORT` is gitignored; clearing it leaves no trace
  in history and requires no commit.
- Idempotent by design: `rm -f` produces no error when the file is absent, and
  the absent-file branch exits cleanly.
