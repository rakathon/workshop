# Test Plan — forge-cross-repo

## Test Approach

`forge-cross-repo` skills make GitHub API calls and write files and state. Testing
requires both an online path (with a real or mock coordination repository) and an
offline path (simulating API unavailability). All tests verify that files written have
the correct structure and that `.state.json` is updated correctly.

The test harness uses a mock coordination repository — a real GitHub repository
containing known fixture artifacts — so that API call behavior is tested end-to-end
without depending on production data.

---

## forge:project Tests

### Online Tests (Mock Coordination Repository Available)

**TC-P-01: Full projection with all artifacts**
- Setup: mock coordination repo with `favorite-stores` effort containing
  `requirements/business.md`, `requirements/technical.md`, and `plan/plan.md`
- Run: `forge:project --coordination-repo test-org/mock-coordination --effort-id favorite-stores`
- Verify: three projected files created with correct `projected-*` naming
- Verify: each file begins with a well-formed provenance header with all five fields
- Verify: `.state.json` contains `coordinationRef` with `repo`, `effortId`, `branch`,
  `commitSha`, `projectedAt`, and a `projections` array with one entry per file
- Verify: each `projections` entry has `source`, `local`, and `sourceSha`
- Verify: new row added to `.forge/efforts/README.md`

**TC-P-02: Provenance header contains correct blob SHAs**
- Run projection; then modify the source file in the mock repo and run a new projection
- Verify: the second projection has a different `source_commit` value in the header
- Verify: the second projection's `.state.json` `sourceSha` differs from the first

**TC-P-03: Idempotency — running forge:project again on same effort**
- Run `forge:project` twice with the same arguments
- Verify: the skill detects an existing sub-effort and prompts for confirmation before
  overwriting, or refuses and guides the engineer to use `forge:sync --rematerialise`
  for updates

### Offline Tests (API Unavailable)

**TC-P-04: GitHub API unreachable — no partial state**
- Simulate network failure by pointing `--coordination-repo` to a nonexistent repo
- Verify: skill exits with a clear error message
- Verify: no files were created under `.forge/efforts/`
- Verify: `.forge/efforts/README.md` was not modified
- Verify: error message includes the API call that failed and actionable guidance

**TC-P-05: Authentication failure**
- Simulate by revoking `gh` authentication or using an invalid token
- Verify: error message identifies authentication as the failure reason
- Verify: no partial state is written

---

## forge:sync Tests

### Staleness Detection

**TC-S-01: Current projection is reported as current**
- Setup: local sub-effort with `coordinationRef` whose `sourceSha` matches the current
  blob SHA in the mock coordination repository
- Run: `forge:sync`
- Verify: projection reported as `current`

**TC-S-02: Stale projection is reported with SHA delta**
- Setup: local sub-effort with `coordinationRef` whose `sourceSha` is an older SHA
  (achieved by modifying the source file in the mock repo after projection)
- Run: `forge:sync`
- Verify: projection reported as `stale`
- Verify: output includes both the locally recorded SHA and the current SHA

**TC-S-03: Re-materialisation updates file and state**
- Setup: stale projection (TC-S-02 precondition)
- Run: `forge:sync --rematerialise`
- Verify: projected file is rewritten with updated content
- Verify: provenance header `source_commit` and `projected_at` are updated
- Verify: `.state.json` `sourceSha` for the projection entry is updated
- Verify: `.state.json` `coordinationRef.commitSha` is updated

### Offline Tests

**TC-S-04: API unavailable reports unreachable, not error**
- Simulate network failure
- Run: `forge:sync`
- Verify: each projection reported as `unreachable` with the reason
- Verify: skill exits cleanly (exit code 0)
- Verify: no files were modified
- Verify: `.state.json` was not modified

**TC-S-05: Mixed state — some unreachable, some checkable**
- Setup: two projections; one from a reachable repo, one from an unreachable repo
- Verify: reachable projection is classified correctly (current or stale)
- Verify: unreachable projection is classified as `unreachable`
- Verify: report lists all projections

---

## forge:upstream Tests

**TC-U-01: Proposal document written with all required sections**
- Run: `forge:upstream` with a change description
- Verify: proposal file exists at `upstream-proposals/001-<slug>.md`
- Verify: file contains all five required sections: title block, change description,
  rationale, proposed content, and status/target metadata

**TC-U-02: .state.json upstreamProposals array updated**
- Run: `forge:upstream`
- Verify: `.state.json` `upstreamProposals` array contains a new entry with `id`,
  `file`, `status: "proposed"`, `targetRepo`, `targetFile`, and `prUrl: null`

**TC-U-03: Proposal IDs increment correctly**
- Run `forge:upstream` three times
- Verify: proposal files are named `001-*.md`, `002-*.md`, `003-*.md`
- Verify: IDs in `.state.json` are `"001"`, `"002"`, `"003"`

**TC-U-04: --pr flag records PR URL in state**
- Run: `forge:upstream --pr` against the mock coordination repository
- Verify: `gh pr create` is called with `--repo <org/coordination-repo>`
- Verify: `.state.json` `prUrl` field is set to the PR URL (not null)

**TC-U-05: --pr failure leaves local state intact**
- Simulate PR creation failure (no write access)
- Run: `forge:upstream --pr`
- Verify: proposal document exists and is complete
- Verify: `.state.json` entry exists with `prUrl: null`
- Verify: error message explains the failure and offers the manual path

**TC-U-06: Missing coordinationRef fails clearly**
- Run `forge:upstream` in an effort directory with no `coordinationRef` in `.state.json`
- Verify: skill fails with a message directing the engineer to run `forge:project` first
