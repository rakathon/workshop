# Technical Requirements — forge-spec-storage

## TR-1: Storage Type Determined Before Schema Design
Type determined from `--type` flag, or by reading the tech stack table in
`.forge/deployables/<deployable-name>/spec/README.md` (written by `forge:init`).
In a formal effort, `deployables` from `.state.json` identifies which deployable
spec(s) to check. If no deployable spec is found, the engineer is prompted.
Announced and confirmed before designing any entity.

## TR-2: Storage Standard Loaded Per Type
Loads `standards/storage/<type>.md` per ADR-003. Warns if absent; proceeds with general conventions.

## TR-3: API and Messaging Specs Cross-Referenced When Present
If `spec/api/` exists, resource names are cross-referenced against the entity list.
Unmapped API resources are flagged as a design question. API and messaging specs are
optional — storage may be designed before these contracts exist.

## TR-4: Three-Phase Sequential Design with Restart Support
Design proceeds through three phases: logical schema (Phase 1), query patterns
(Phase 2), physical schema (Phase 3). Phase 0 reads existing artifact contents and
evaluates completeness against requirements before resuming. A phase is only
considered complete if its artifact covers the full domain.

## TR-5: Query Patterns Derived from All Available Sources
Query patterns are derived from requirements verbs, UI artifacts in `spec/ui/`,
flows in `spec/flows/`, API contracts (if present), and messaging consumers (if
present). Each pattern records its source artifact.

## TR-6: Physical Schema Driven by Query Patterns
Each entity's index strategy is derived from Phase 2 query patterns. Every query
pattern must be served by a primary key, index, or key design in the physical schema.

## TR-7: Inline Checks Applied Per Entity in Phase 3
For each entity in Phase 3: PK declared, FK or key design declared (where applicable),
index strategy covers all query patterns for that entity, soft-delete policy stated,
PII inline annotation for any field containing personal data.

## TR-8: Written to Effort Spec Path and .state.json Updated
Phase artifacts written to `<effort_dir>/spec/storage/`. `.state.json` updated to
`phases.discovery.artifacts.spec.storage = "present"` after Phase 3 completes.
Without a formal effort, artifacts written to `spec/storage/` in the working directory.
