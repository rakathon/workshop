# forge-validate-storage

Targeted validation of storage schemas (`spec/storage/*.md`) against the applicable
organizational storage standard. An inline editing aid for use during
`forge:spec-storage` — provides immediate standards feedback without writing gate
artifacts or modifying workflow state.

**Skill:** `forge:validate-storage`  **Classification:** Worker
Part of the spec-driven-development initiative (TASK-013).

## What It Does

- Loads all physical schema files from `spec/storage/`
- Detects storage technology (PostgreSQL, DynamoDB, Redis, OpenSearch, Browser Extension)
- Loads and applies the applicable organizational standard
- Applies common checks: primary key, field types, soft-delete policy, index-to-query-pattern alignment
- Applies explicit PII checks: retention period and deletion obligation for personal data fields
- Applies technology-specific checks derived from the organizational standard
- Prints an inline session report grouped by entity with REQUIRED and SUGGESTION findings

## What It Does Not Do

- Does not write `validation/report.md`
- Does not modify `.state.json`
- Does not write any file
- Does not replace `forge:validate` as the discovery phase gate
