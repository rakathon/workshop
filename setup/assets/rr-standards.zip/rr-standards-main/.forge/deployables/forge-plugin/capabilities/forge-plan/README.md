# forge-plan

Implementation planning for work efforts in the Forge AI-accelerated development framework.
Delivers the `forge:plan` skill, which generates an annotated, wave-ordered
implementation plan inside the current effort's directory.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:plan` | Skill | Interactive | Manual invocation |

**`forge:plan`** reads the effort's requirements and architecture artifacts, then
writes `.forge/efforts/<name>/PLAN.md` — a structured task list ordered by
delivery waves. Each task is annotated with: risk rating (R1–R4), estimated
complexity, dependencies, and acceptance criteria. Tasks within a wave are
parallelizable; waves are sequentially ordered by dependency and risk.

The plan is the contract between design and implementation. `forge:verify` checks
each task against the acceptance criteria written here.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-effort](../forge-effort/) | Provides the effort directory; creates the initial PLAN.md stub. |
| [forge-arch-review](../forge-arch-review/) | Architecture review findings inform risk annotations in the plan. |
| [forge-verify](../forge-verify/) | Validates implementation against task acceptance criteria from the plan. |
| [forge-promote](../forge-promote/) | Completed plan is a prerequisite for the `design → build` promotion. |

## Implementation Location

`plugins/forge/skills/plan/` — `forge:plan` SKILL.md and README.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview and key design decisions |
| [spec/skills.md](spec/skills.md) | `forge:plan` detailed design |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | Relevant ADRs |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
