# Business Requirements — forge-plan

Parent deployable: [forge-plugin](../../requirements/business.md)
Primary program TRs addressed: TR-7, TR-7a

---

## BR-1: Engineers Must Not Jump to Implementation Without Thinking Through Dependencies

When a team finishes discovery and design, the path of least resistance is to begin
coding immediately — picking whatever task feels most tractable and starting. This
produces work that must be thrown away when a foundational dependency turns out to be
incomplete, or when a team member picks the same task on a parallel branch. An explicit
implementation plan, generated from the discovery artifacts before coding begins, forces
the dependency analysis to happen once — deliberately — rather than being rediscovered
repeatedly and expensively during implementation.

## BR-2: Parallel Execution Must Be Possible Without Coordination Overhead

Teams accelerated by AI agents can run multiple implementation tasks simultaneously on
separate git worktrees. The bottleneck is not execution speed — it is knowing which
tasks are safe to run in parallel and which must wait. Without an explicit dependency
grouping, every task runs sequentially by convention. Wave groupings enable genuine
parallelism: tasks in the same wave have no dependency on each other and can be executed
simultaneously. The plan must surface this information explicitly so teams and agents
can exploit it without per-task negotiation.

## BR-3: Agents Must Know When to Pause for Human Input Without Inferring from Description Text

An agent executing a task should not need to infer from the task description whether it
should proceed autonomously or pause for a decision. Description-based inference is
unreliable: "implement the auth middleware" could be a straightforward coding task or a
task that requires confirming a token claim name with another team before writing a line
of code. Task type annotations resolve this unambiguously at planning time, not at
execution time. The plan must communicate intent — not just what to build, but how much
autonomy the executing agent has on each task.

## BR-4: TDD Discipline Must Be Established at Planning Time, Not Discovered During Implementation

A task annotated as test-first establishes a contract: the test exists and is failing
before implementation code is written. If TDD discipline is not declared in the plan,
an agent may write implementation code first and add tests afterward — producing passing
tests that validate the implementation rather than the requirement. The window for
enforcing TDD is before implementation begins. `forge:plan` closes that window.

## BR-5: Coordination Efforts Must Produce a Deployable-Scoped View of the Plan

A coordination effort spans multiple deployable repositories. The engineers and agents
working in each deployable repository need to know: what is this deployable responsible
for, what are the acceptance criteria for this deployable's scope, and what dependencies
exist on other deployables. A monolithic plan with no deployable scoping requires each
team to read the whole plan and extract their slice. The coordination plan must produce
a structure that makes each deployable's responsibilities self-evident.

## BR-6: Initiative Epic Breakdowns Are Also Coordination Plans

An initiative or program cannot be directly implemented — it must first be broken into
child epics, each of which will go through its own discovery, specification, and
implementation cycle in its owning deployable repository. Initiatives almost always
span multiple repositories, so the epic breakdown and the coordination plan are the
same artifact. Each epic must declare which deployable owns it so that `forge:project`
can materialize it as a local effort in the correct repo without any additional mapping
step. A plan that assigns epics to deployables at authoring time eliminates the
coordination overhead of figuring out "which team does what" at implementation time.

## BR-7: Tasks Must Carry Enough Context to Be Executed Without Re-Reading the Full Spec

An agent or engineer picking up a task from `plan/tasks.md` should not need to re-read
the full requirements and spec to understand what standards apply, which requirements
are being addressed, or what tests must pass before the task is done. When a task lacks
this context, agents make inconsistent choices about which standards to follow, skip
tests that are implied but not explicitly stated, and complete tasks that satisfy the
code but not the requirement. Each task must embed the applicable standards references,
the requirement IDs it satisfies, and the specific named tests that must exist and pass
at completion.

---

Success criteria: [success-criteria.md](success-criteria.md)
