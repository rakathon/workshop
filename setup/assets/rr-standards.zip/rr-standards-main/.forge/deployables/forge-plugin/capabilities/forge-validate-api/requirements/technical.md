# Technical Requirements — forge:validate-api

## Traceability

| TR | Satisfies |
|----|-----------|
| TR-1 | BR-1 |
| TR-2 | BR-1 |
| TR-3 | BR-1 |
| TR-4 | BR-1 |
| TR-5 | BR-2 |
| TR-6 | BR-1 |
| TR-7 | BR-3 |

---

## TR-1 — Load all API contract files from the effort

The skill must load all files matching `spec/api/*.yaml` from the target effort
directory (`.forge/efforts/<effort_id>/spec/api/`).

**Acceptance Criteria:**
- All `.yaml` files under `spec/api/` are discovered and processed.
- If no files are found, the skill emits: "No API spec found. Run forge:spec-api first."
  and exits cleanly without error.

---

## TR-2 — Load the REST standard from the plugin standards directory

The skill must load `standards/api/rest/` from the Forge plugin standards directory.
The plugin root must be located using the standard find command documented in CLAUDE.md:

```bash
find ~/.claude/plugins/cache/forge-local -maxdepth 4 -name "plugin.json" -path "*/forge/*" 2>/dev/null \
  | head -1 | sed 's|/.claude-plugin/plugin.json||' \
  | grep . \
  || find ~/.claude/plugins/cache -maxdepth 5 -name "plugin.json" -path "*/forge/*" 2>/dev/null \
     | head -1 | sed 's|/.claude-plugin/plugin.json||'
```

**Acceptance Criteria:**
- The skill reads standards from the resolved plugin root, not from a hardcoded path.
- If the plugin root cannot be resolved, the skill reports an error and exits.

---

## TR-3 — Per-endpoint checks

For each endpoint defined in the OpenAPI spec, the skill must apply:

1. **Resource naming:** The path segment(s) represent nouns, not verbs. Flag paths
   containing action words (e.g., `/getUser`, `/createOrder`, `/doSomething`).
2. **HTTP status codes:** Verify correct status codes are declared:
   - GET: 200, 400, 401, 404, 500
   - POST: 201, 400, 401, 422, 500
   - PUT/PATCH: 200, 400, 401, 404, 422, 500
   - DELETE: 204, 400, 401, 404, 500
3. **Error schema:** Every error response (4xx, 5xx) must reference a schema with at
   least `code` and `message` fields.
4. **Auth on write operations:** POST, PUT, PATCH, DELETE endpoints must declare an
   auth/security requirement (security scheme specified in the operation or globally).

**Acceptance Criteria:**
- Each check produces a REQUIRED or SUGGESTION finding with a clear description.
- Checks are applied to every endpoint path and method combination.

---

## TR-4 — Contract-level checks

The skill must apply these checks at the contract (document) level:

1. **Error component present:** `components/schemas/Error` block exists at the top level.
2. **Version format:** `info.version` is present and follows semantic versioning
   (e.g., `1.0.0`, `2.3.1`).
3. **$ref resolution:** All `$ref` values within the document resolve to a defined
   component within the same document.

**Acceptance Criteria:**
- Missing `components/schemas/Error` is flagged as REQUIRED.
- Invalid or missing `info.version` is flagged as REQUIRED.
- Unresolvable `$ref` entries are flagged as REQUIRED, identifying the broken reference.

---

## TR-5 — No file writes, no state updates

The skill must NOT write to `validation/report.md` or update `.state.json`. Output is
inline session output only.

**Acceptance Criteria:**
- The skill produces no file system side effects on any invocation.
- No calls to Write tool, no shell redirects, no artifact creation.
- This constraint is explicitly documented in the SKILL.md.

---

## TR-6 — Run as a worker agent

The skill must run as a worker to avoid loading standards content into the engineer's
main session context (where it would persist across all subsequent steps and pollute
the session with large standard documents).

**Acceptance Criteria:**
- `agent-type: worker` is declared in the SKILL.md frontmatter.
- The skill runs as an isolated sub-agent invoked by the engineer or an orchestrator.

---

## TR-7 — Severity labels and grouped report format

The inline report must use severity labels REQUIRED (must fix before promoting) and
SUGGESTION (informational), grouped by endpoint.

**Acceptance Criteria:**
- Every finding has a severity label: either `[REQUIRED]` or `[SUGGESTION]`.
- Findings are grouped by endpoint path + method.
- Contract-level findings appear in a dedicated section (e.g., `### Contract`).
- The report ends with a summary: `**Summary:** N REQUIRED, M SUGGESTION`.
