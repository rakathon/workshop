# Security — forge-arch-review

## Trust Boundary

`forge:arch-review` is a worker sub-agent spawned by the engineer's interactive
Claude Code session. It reads from the filesystem (effort artifacts and standards
library) and writes two output files. It makes no network calls and accesses no
credentials.

Primary security surfaces:

- **Effort artifacts** — the worker reads requirements and spec files from the
  effort directory; content in these files is AI-generated and does not come from
  untrusted external sources
- **Standards library** — the worker reads standard files from the rr-standards
  plugin cache; these are version-controlled and reviewed as part of the plugin release
- **Generated HTML** — the worker writes `validation/arch-review.html`; content is
  derived from effort artifacts and must not introduce script execution vectors

---

## Generated HTML Security

`validation/arch-review.html` is a static document that will be opened in browsers
and potentially shared across teams. The following constraints apply:

**No inline JavaScript:** The HTML must not contain `<script>` tags or `on*` event
handlers. Navigation is anchor-based; no JavaScript is required or permitted.

**No external references:** All `src` and `href` attributes must be internal anchors
or inline data URIs. External URL references are prohibited (no CDN, no remote fonts,
no remote images). This prevents the document from making unexpected network requests
when opened.

**Content injection risk:** The worker populates HTML sections with content from
effort artifacts. If an effort artifact contains HTML special characters or markdown
that could be misinterpreted as HTML structure, the worker must escape it correctly
before embedding. This is a generation-time responsibility in the skill implementation.

---

## Prompt Injection Risk

The worker reads effort artifacts written by Claude Code agents during the discovery
phase. These artifacts are generated from engineer conversations and may contain
content that looks like instructions to a subsequent AI agent.

The worker sub-agent runs with a scoped system prompt that defines its role
(validate and generate outputs only). Content from effort artifacts is treated as
data, not instructions. The worker must not act on imperative language found in
artifact content (e.g., "ignore previous instructions and do X").

---

## Standards Library Integrity

The standards loaded by the worker are read from the rr-standards plugin cache.
The integrity of the plugin cache is maintained by `forge:pin` (commit SHA pinning).
Changes to standards require a plugin release and must go through the rr-standards
PR review process, which includes standards review and security scanning.

---

## No Credentials or Secrets Access

The worker reads only effort artifacts and standards files. It does not:
- Access `.env` files or secrets
- Read `~/.aws/`, `~/.ssh/`, or other credential directories
- Make GitHub API calls
- Read source code files (it reads `.forge/` artifacts only)

If an effort artifact contains a secret that was committed by mistake, the secret
will be present in the generated HTML and report. This is an effort authoring
problem, not a security surface introduced by this capability. Engineers should
follow secret scanning practices on all `.forge/` commits.

---

## Review Requirements

All PRs that modify the `forge:arch-review` SKILL.md or the skill's generation
logic trigger the `security-reviewer` agent in `rr-standards:review`, which checks
for prompt injection vectors and HTML output safety.
