# Success Criteria — forge-pin

- [ ] `forge:pin` creates `.claude-plugin/marketplace.json` pinning the team to a
      specific Forge version using both a semver tag and a commit SHA; re-running to
      the same version produces "Already pinned. Nothing to do."
- [ ] Files written by `forge:pin` (`.claude-plugin/marketplace.json`,
      `.claude/settings.json`, `.forge/version`) include an explicit commit reminder
      so engineers know to share the pin with the team
- [ ] `forge:pin --version X` with an unknown tag fails with a diagnostic listing
      available release tags
- [ ] When `.forge/version` exists at pin time, `forge_min_version` is updated to
      match the new pin without requiring `forge:init` to be re-run
- [ ] `forge:pin` and `forge:init` produce a correctly configured repository regardless
      of which is run first
