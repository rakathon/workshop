# Security — forge-promote

## Trust Boundary

`forge:promote` runs within the engineer's interactive Claude Code session. It does
not introduce network-accessible services and makes no external network calls. All
operations are local file reads, `.state.json` writes, and git commits.

Primary security surfaces:

- **`.state.json` writes** — `forge:promote` writes approver identity and timestamp
  into `.state.json`. The approver field is read from git config (`user.name` /
  `user.email`). An engineer can configure arbitrary git identity before running
  `forge:promote`. The approver field is a record of intent, not a cryptographic
  proof of identity.

- **git commit** — The checkpoint commit is made using the engineer's configured git
  identity. The same git identity caveat applies.

- **Phase summary content** — The phase summary displays content from artifact files
  (first headings, ADR decisions, open decisions). If any of these files contain
  adversarial content designed to inject instructions into the Claude Code session,
  that content is presented to the session. This is the same risk as any file read
  operation in Claude Code.

## Identity Model

The `approvedBy` field in `.state.json` is populated from `git config user.name` and
`git config user.email`. This represents the engineer's declared git identity, not a
verified organizational identity. For environments where stronger identity assurance
is required:

- Use commit signing (GPG or SSH) to cryptographically bind the checkpoint commit to
  a verified key
- The checkpoint commit SHA provides a permanent reference that can be verified against
  the commit signature independently of `forge:promote`

`forge:promote` does not manage commit signing. If the repository requires signed
commits, the git signing configuration must be in place before `forge:promote` runs.

## No Hook Scripts

`forge:promote` delivers no hook scripts. The security model is simpler than
capabilities that deliver hooks — there are no scripts executing on every file write
or session start.

## File Access Scope

`forge:promote` reads and writes only:
- `.forge/efforts/<effort-id>/.state.json`
- `.forge/efforts/<effort-id>/requirements/` (read only — existence check)
- `.forge/efforts/<effort-id>/spec/` (read only — existence and content check)
- `.forge/efforts/<effort-id>/validation/report.md` (read only — result parsing)
- `.forge/efforts/<effort-id>/validation/verify-report.md` (read only — result parsing)
- `.forge/efforts/<effort-id>/plan/tasks.md` (read only — task format check)
- `.forge/efforts/README.md` (read and write — registry update)

It must not read or write source code, test files, or any file outside `.forge/`.

## Review Requirements

All PRs that modify the `forge:promote` skill definition (`plugins/forge/skills/promote/`)
trigger the `security-reviewer` agent in `rr-standards:review`. The security reviewer
checks that the skill does not introduce file access outside the defined scope and does
not add network calls.
