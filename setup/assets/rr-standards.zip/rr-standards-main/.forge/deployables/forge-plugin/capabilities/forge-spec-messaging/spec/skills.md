# Skills — forge-spec-messaging

## forge:spec-messaging

**Classification:** Orchestrator

**Invocation:** `forge:spec-messaging <effort-id> [--event <name>]`

**Inputs:**
- `<effort_dir>/requirements/business.md` (required)
- `<effort_dir>/requirements/technical.md` (optional)
- `standards/messaging/contracts.md` (plugin standards)

**Outputs:**
- `<effort_dir>/spec/messaging/<event-name>.md` — contract per event
- `.state.json` update: `phases.discovery.artifacts.spec.messaging = "present"`

**Steps:**
1. Load messaging standard
2. Read requirements; enumerate events
3. Confirm event scope with engineer (unless `--event` specified)
4. For each event: propose all five decisions at once → confirm → inline checks → write
5. Update `.state.json`; commit

**Five decisions per event:** schema fields, producer, consumers (or "unknown"), ordering guarantee, idempotency approach.

**Inline checks per event:** schema defined, producer named, consumers identified, ordering stated, idempotency documented.
