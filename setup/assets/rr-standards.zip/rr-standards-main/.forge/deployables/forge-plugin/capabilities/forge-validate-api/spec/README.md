# forge-validate-api Spec

Design artifacts for the `forge:validate-api` capability.

## Contents

| File | Description |
|------|-------------|
| [skills.md](skills.md) | Detailed skill specification — step-by-step worker logic, checks reference, and output format |

## Design Summary

`forge:validate-api` is a worker skill that applies the REST standard checks to
`spec/api/*.yaml` and prints an inline session report. It is explicitly not a phase
gate — it writes no files and updates no state.

### Key Design Decisions

**Worker agent type (not orchestrator)**

Standards content loaded into a worker runs in an isolated sub-agent context and does
not persist in the main session. Loading `standards/api/rest/*.md` into the main
session would accumulate large content across subsequent steps, degrading quality of
later responses. The worker isolation eliminates this concern.

**No file output by design**

`forge:validate` owns `validation/report.md`. `forge:validate-api` is an editing aid,
not a gate. Making it write files would create ambiguity about which artifact is
authoritative for promotion decisions, and would break the single-responsibility
principle of the gate chain.

**Severity labels instead of pass/fail**

A binary pass/fail at the editing-aid stage would block engineers mid-authoring on
findings that may be intentional deviations (e.g., a non-standard status code for a
specific client requirement). REQUIRED / SUGGESTION labels give engineers the
information they need without interrupting flow.

**Grouped by endpoint**

Engineers work on one endpoint at a time during `forge:spec-api`. Grouping findings
by endpoint matches their mental model and lets them act on one endpoint at a time
without scanning a flat list.

## Related Documentation

- [forge:spec-api skill](../../../forge-spec-api/) — produces the contracts that forge:validate-api checks
- [forge:validate skill](../../../forge-verify/) — the phase gate that owns validation/report.md
- [REST Standard](../../../../../standards/api/rest/) — the standard applied by this skill
