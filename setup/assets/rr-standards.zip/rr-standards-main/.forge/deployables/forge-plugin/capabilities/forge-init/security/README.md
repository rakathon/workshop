# Security — forge-init

## Trust Boundary

`forge:init` and the two hooks run within the engineer's interactive Claude Code
session and hook execution environment respectively. They do not introduce
network-accessible services.

Primary security surfaces:

- **Hook scripts** — executed on every Write/Edit (injection hook) or session start
  (enforcement hook); must not introduce code execution vectors, credential access,
  or exfiltration paths
- **CLAUDE.md managed section** — written into the repository; subject to prompt
  injection screening (see `rr-standards:review` security-reviewer agent)
- **`.forge/version`** — key=value file written to the repository; must not be
  writable by untrusted processes
- **GitHub API calls** — `forge-version-check.sh` calls `gh api` to fetch
  `VERSIONS.json`; credentials are managed by the `gh` CLI and must not be logged
  or stored by Forge

## Hook Script Security

Both hook scripts are reviewed by the `hook-reviewer` agent in `rr-standards:review`
on every PR that modifies them. The four check IDs are:

| Check ID | What it detects |
|----------|----------------|
| `network-exfiltration` | `curl`, `wget`, or outbound connections to non-marketplace endpoints |
| `credential-access` | Reads of `~/.ssh/`, `~/.aws/`, `~/.config/gcloud/`, or `$HOME` credential paths |
| `file-exfiltration` | Reads outside `.forge/`, `.claude/`, and the plugin cache path |
| `obfuscated-execution` | Eval of dynamic strings, pipes into shell, encoded payloads |

The `inject-generation-standards.sh` hook reads only from the plugin cache (standards
content) and writes only to stdout. It makes no network calls and reads no credentials.

The `forge-version-check.sh` hook makes one outbound `gh api` call to fetch
`VERSIONS.json` from the rr-standards marketplace. This is the only permitted outbound
call. The call is read-only, uses the engineer's existing `gh` authentication, and
degrades gracefully when the network is unavailable.

## Prompt Injection Risk

The CLAUDE.md forge:managed section is injected into every Claude Code session in the
repository. Content written to this section has the same privilege as CLAUDE.md
instructions. The template is static and version-controlled in the plugin; it does not
interpolate user-supplied content. The only substitutions are:
- `{{forge_version}}` — semver string from `plugin.json`
- `{{marketplace_dir}}` — directory name from the plugin cache path
- `{{sha}}` — commit SHA from the plugin cache path

None of these substitutions can introduce arbitrary instruction content.

## Plugin Version Pin Integrity

The [forge-pin capability](../../forge-pin/) stores both a human-readable tag (`ref`)
and a commit SHA (`sha`) in `.claude-plugin/marketplace.json`. `forge:init` reads this
file at initialization time but does not write it. See the forge-pin security
documentation for the pin integrity model.

## Review Requirements

All PRs that modify hook scripts (`plugins/forge/hooks/**/*.sh`) trigger the
`hook-reviewer` agent in `rr-standards:review`. All PRs that modify CLAUDE.md
templates or skill definitions trigger the `security-reviewer` agent.
