# Success Criteria — forge-adr

- [ ] An effort with ADR-001 in `spec/arch-decisions/` → `forge:adr` creates ADR-002
      with the correct sequential number, without engineer specifying the number
- [ ] An effort with ADR-001 and ADR-003 (gap at 002) → `forge:adr` creates ADR-002,
      filling the gap rather than assigning ADR-004
- [ ] An effort with no existing ADR files → `forge:adr` creates ADR-001
- [ ] After `forge:adr` runs with effort scope, the effort's `.state.json`
      `phases.discovery.artifacts.adrsCreated` array contains the new ADR entry
- [ ] After `forge:adr` runs with deployable scope, no `.state.json` is modified
- [ ] Conversational trigger "let's use PostgreSQL because of better transactions" →
      `forge:adr` creates an ADR capturing the decision with no additional engineer input
- [ ] Conversational trigger "we've decided to go with option B for the auth flow" →
      `forge:adr` creates an ADR; no explicit `forge:adr` invocation required
- [ ] Every ADR contains all four required sections: Context, Decision, Alternatives
      Considered, Consequences; no section is empty or missing
- [ ] ADR filename follows `ADR-NNN-<slug>.md` pattern; slug is kebab-case derived
      from the decision title
- [ ] `forge:adr` invoked explicitly with a title and decision text → ADR created with
      those values; engineer does not need to provide Context or Consequences manually
- [ ] `forge:adr` invoked explicitly with only a title → ADR created; agent populates
      remaining sections from conversation context
- [ ] The `spec/arch-decisions/README.md` index is updated to include the new ADR row
- [ ] `forge:adr` does not run `git commit`; it prints the files written and a
      suggested commit command
- [ ] Suggested commit message follows `docs(<scope-label>): ADR-NNN <decision-subject>`
      format, where scope-label is the effort ID, deployable ID, or `repo`
- [ ] If no active effort exists and no `--deployable` flag is provided, `forge:adr`
      asks the engineer where to write the ADR rather than stopping with an error
- [ ] `forge:adr --deployable <id>` writes the ADR to
      `.forge/deployables/<id>/spec/arch-decisions/` without requiring an active effort
- [ ] A casual mention of a technology ("I've been reading about DynamoDB") does not
      trigger ADR creation; only genuine architectural commitments trigger creation
- [ ] An effort with an existing ADR-003 "Use Redis for Session Cache" → proposing a new
      ADR titled "Use Redis as the session store" surfaces ADR-003 as a potential duplicate
      and asks the engineer to confirm before proceeding
- [ ] An effort whose associated deployable already has ADR-001 "Use Redis for Session
      Cache" → proposing the same decision in the effort prompts the cross-scope duplicate
      warning, identifying the deployable ADR as the likely duplicate
- [ ] When no semantically similar ADRs exist, `forge:adr` proceeds without any duplicate
      warning — the check is silent when there is nothing to flag
- [ ] Engineer responds "it's a duplicate" → `forge:adr` stops without writing any files
- [ ] An effort with ADR-002 "Use Memcached for Caching" → proposing "Use Redis for
      Caching" is classified as a conflict (not a duplicate) and the engineer is asked
      whether the new ADR supersedes ADR-002
- [ ] Engineer confirms supersession → new ADR written; ADR-002 status updated to
      "Superseded by ADR-NNN"; ADR-002 row in the index updated to "Superseded";
      both files included in the suggested commit
- [ ] Engineer responds "different aspects" to a conflict → new ADR written without
      any modification to the existing ADR
- [ ] Engineer cancels on a conflict → no files written or modified
