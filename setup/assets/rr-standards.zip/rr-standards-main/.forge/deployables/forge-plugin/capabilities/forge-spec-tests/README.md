# forge-spec-tests

Authors high-level test strategies for capabilities during discovery. Maps each
acceptance criterion from requirements to a test scenario (unit/integration/E2E/contract),
then writes to the capability's canonical directory per ADR-028.

**Skill:** `forge:spec-tests`  **Classification:** Orchestrator
Part of the spec-driven-development initiative (Initiative 3).
