# forge-adr

Architecture decision capture for the Forge AI-accelerated development framework.
Delivers the `forge:adr` skill, which records significant design choices as
Architecture Decision Records (ADRs) inside the current effort's context.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:adr` | Skill | Interactive | Manual invocation |

**`forge:adr`** captures a design decision that emerged during a conversation and
writes it to `.forge/efforts/<name>/spec/arch-decisions/<slug>.md` using the
standard ADR format: context, decision, consequences. Indexes the new ADR in the
effort's `spec/arch-decisions/README.md`.

ADRs are lightweight records — the goal is to capture the reasoning at the moment
of decision, before context is lost. `forge:adr` accepts a title and optional
body; Claude populates the context and consequences sections from the surrounding
conversation.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-effort](../forge-effort/) | Provides the effort directory where ADRs are stored. |
| [forge-arch-review](../forge-arch-review/) | Consumes ADRs when validating design consistency. |
| [forge-graduate](../forge-graduate/) | Includes ADRs in the canonical documentation bundle. |

## Implementation Location

`plugins/forge/skills/adr/` — `forge:adr` SKILL.md and README.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Business requirements |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable success criteria |
| [spec/README.md](spec/README.md) | Architecture overview and key design decisions |
| [spec/skills.md](spec/skills.md) | `forge:adr` detailed design |
| [spec/arch-decisions/README.md](spec/arch-decisions/README.md) | Relevant ADRs |
| [test/README.md](test/README.md) | Test strategy and test plans |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
Primary program BRs addressed: BR-9, BR-11.
