# Implementation Spec — forge:statusline Skill
<!-- graduated-from: forge-statusline at 2026-04-26T01:20:08Z -->

## Overview

This capability delivers three artifacts:

1. **`forge-statusline.py`** — the statusline script shipped in the plugin, installed
   to `~/.claude/` by the skill.
2. **`forge:statusline` skill** (`skills/statusline/SKILL.md`) — installs and manages
   the script.
3. **`subagentStatusLine` config** — written to `~/.claude/settings.json` by the skill alongside `statusLine`. The plugin ships no `settings.json`.

---

## Artifact 1: forge-statusline.py

### Location in plugin

```
plugins/forge/statusline/forge-statusline.py
plugins/forge/statusline/forge-statusline.py.sha256
```

The `statusline/` directory is not a skill — it's a resource directory holding the
script and its content hash.

### Script structure

```python
#!/usr/bin/env python3
import json, sys, os, subprocess, time, hashlib
from pathlib import Path

def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        print("[Claude] —")
        return

    # --- Extract fields with safe defaults ---
    model     = (data.get('model') or {}).get('display_name', 'Claude')
    workspace = data.get('workspace') or {}
    cwd       = workspace.get('current_dir') or data.get('cwd', '')
    dirname   = Path(cwd).name if cwd else '—'
    session_id = data.get('session_id', 'default')

    cost_data = data.get('cost') or {}
    cost_usd  = cost_data.get('total_cost_usd') or 0
    dur_ms    = cost_data.get('total_duration_ms') or 0

    ctx       = data.get('context_window') or {}
    pct       = int(ctx.get('used_percentage') or 0)

    worktree  = data.get('worktree')  # present only in --worktree sessions

    # --- Line 1: session identity + git/forge context ---
    line1 = build_line1(model, dirname, cost_usd, dur_ms, worktree, cwd, session_id)

    # --- Line 2: context health bar ---
    line2 = build_line2(pct)

    print(line1)
    print(line2)

if __name__ == '__main__':
    main()
```

### Line 1 composition

```
[Model] 📁 dirname | cost duration | 🌿 branch [effort-id · phase]
```

- `branch` — from `git branch --show-current` run in `cwd`; suppressed if not a git repo
- `effort-id · phase` — from effort cache (see below); suppressed if no active effort
- In worktree mode: branch = `worktree.branch`, dirname still from `workspace.current_dir`

### Line 2 composition

```
[████████░░] 80% context
```

- Bar is 10 characters: `█` filled, `░` empty
- Colors: green (`\033[32m`) < 70%, yellow (`\033[33m`) 70–89%, red (`\033[31m`) ≥ 90%
- Reset with `\033[0m`

### Effort cache

```python
CACHE_TTL = 5  # seconds
CACHE_PATH = Path(f'/tmp/forge-statusline-{session_id}')

def get_effort_context(cwd, session_id):
    if CACHE_PATH.exists():
        age = time.time() - CACHE_PATH.stat().st_mtime
        if age < CACHE_TTL:
            return json.loads(CACHE_PATH.read_text())

    result = _resolve_effort(cwd)
    CACHE_PATH.write_text(json.dumps(result))
    return result

def _find_forge_root(cwd):
    """Walk up from cwd to find the nearest directory containing .forge/."""
    path = Path(cwd).resolve()
    while True:
        if (path / '.forge').is_dir():
            return path
        parent = path.parent
        if parent == path:
            return None
        path = parent

def _resolve_effort(cwd):
    # 1. Walk up to find forge_root
    forge_root = _find_forge_root(cwd)
    if not forge_root:
        return {}

    # 2. Read .forge/EFFORT if present
    effort_file = forge_root / '.forge' / 'EFFORT'
    effort_id = effort_file.read_text().strip() if effort_file.exists() else None

    # 3. Fall back to branch name suffix (effort/<id> convention)
    if not effort_id:
        try:
            branch = subprocess.check_output(
                ['git', 'branch', '--show-current'],
                cwd=str(forge_root), text=True, stderr=subprocess.DEVNULL
            ).strip()
            if branch.startswith('effort/'):
                effort_id = branch.split('/', 1)[1]
        except Exception:
            pass

    if not effort_id:
        return {}

    # 4. Read .state.json
    state_path = forge_root / '.forge' / 'efforts' / effort_id / '.state.json'
    if not state_path.exists():
        return {}

    try:
        state = json.loads(state_path.read_text())
        title = state.get('title', effort_id)
        if len(title) > 30:
            title = title[:29] + '…'
        return {
            'id': effort_id,
            'title': title,
            'phase': state.get('currentPhase', '?')
        }
    except Exception:
        return {}
```

---

## Artifact 2: forge:statusline skill

### Location

```
plugins/forge/skills/statusline/SKILL.md
```

### Skill arguments

| Flag | Description | Default |
|------|-------------|---------|
| `--replace` | Override an existing non-Forge statusline | false |
| `--uninstall` | Remove the Forge statusline and clear settings entry | false |

### Install flow

**Step 1 — Resolve plugin root**

Resolve the plugin root using:
  `plugins/forge/skills/common/plugin-root.md`

The script source is at `<plugin_root>/statusline/forge-statusline.py`.

**Step 2 — Check existing settings**

Read `~/.claude/settings.json`. Check both `statusLine.command` and
`subagentStatusLine.command` as a pair:

| State | Action |
|-------|--------|
| Both absent | Proceed to install |
| Both point to Forge scripts | Check combined content hash; update if stale, skip if current |
| Either points to something else | Stop unless `--replace` was passed |

If `--replace` is required, the message must name which setting conflicts:
> "`subagentStatusLine` is already configured with a custom command. Use `--replace` to override both settings."

**Step 3 — Copy script**

```python
import shutil, os, stat, hashlib, json
from pathlib import Path

src  = Path('<plugin_root>/statusline/forge-statusline.py')
dest = Path.home() / '.claude' / 'forge-statusline.py'

shutil.copy2(src, dest)
dest.chmod(dest.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
```

**Step 4 — Merge settings**

```python
settings_path = Path.home() / '.claude' / 'settings.json'
cfg = {}
if settings_path.exists():
    cfg = json.loads(settings_path.read_text())

cfg['statusLine'] = {
    'type': 'command',
    'command': str(Path.home() / '.claude' / 'forge-statusline.py'),
    'padding': 2
}

settings_path.write_text(json.dumps(cfg, indent=2) + '\n')
```

**Step 5 — Print summary**

```
forge:statusline installed

  Script:   ~/.claude/forge-statusline.py
  Settings: ~/.claude/settings.json (statusLine configured)

The statusline will appear after your next interaction with Claude Code.
Re-run /forge:statusline to update the script when you upgrade Forge.
```

### Uninstall flow (`--uninstall`)

1. Delete `~/.claude/forge-statusline.py` if it exists.
2. Delete `~/.claude/forge-subagent-statusline.py` if it exists.
3. Read `~/.claude/settings.json`, remove both `statusLine` and `subagentStatusLine`
   keys, write back.
4. Print: `forge:statusline removed. Restart Claude Code to clear the display.`

---

## Artifact 3: subagentStatusLine written by forge:statusline

The plugin ships **no** `.claude-plugin/settings.json`. Shipping one would activate
`subagentStatusLine` for all plugin users unconditionally, violating the opt-in contract.

Instead, `forge:statusline` writes both `statusLine` and `subagentStatusLine` into
`~/.claude/settings.json` as part of the install step (Step 4):

```python
cfg['statusLine'] = {
    'type': 'command',
    'command': str(Path.home() / '.claude' / 'forge-statusline.py'),
    'padding': 2
}
cfg['subagentStatusLine'] = {
    'type': 'command',
    'command': str(Path.home() / '.claude' / 'forge-subagent-statusline.py')
}
```

The uninstall flow (`--uninstall`) removes both keys.

The script source ships at:

```
plugins/forge/statusline/forge-subagent-statusline.py
```

### forge-subagent-statusline.py structure

```python
#!/usr/bin/env python3
import json, sys

def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        return

    tasks = data.get('tasks') or []
    for task in tasks:
        task_id   = task.get('id', '')
        name      = task.get('name', '?')
        kind      = task.get('type', '?')
        status    = task.get('status', '?')
        tokens    = task.get('tokenCount', 0)
        content   = f"[{kind}] {name} · {status} · {tokens}tk"
        print(json.dumps({"id": task_id, "content": content}))

if __name__ == '__main__':
    main()
```

---

## File Manifest

| File | Action | Description |
|------|--------|-------------|
| `plugins/forge/statusline/forge-statusline.py` | Create | Main statusline script source |
| `plugins/forge/statusline/forge-subagent-statusline.py` | Create | Subagent panel script source |
| `plugins/forge/statusline/forge-statusline.py.sha256` | Create | Combined content hash for staleness detection |
| `plugins/forge/skills/statusline/SKILL.md` | Create | forge:statusline skill definition |
| `plugins/forge/skills/common/plugin-root.md` | Create | Shared plugin root resolution fragment |
| `.forge/deployables/forge-plugin/spec/arch-decisions/ADR-034-*.md` | Create | Plugin root resolution decision |

---

## forge:update integration

`forge:update` must add a check step:

1. Resolve the installed scripts: `~/.claude/forge-statusline.py` and
   `~/.claude/forge-subagent-statusline.py`.
2. If either file exists, compute a combined hash using the same algorithm as the
   plugin's `forge-statusline.py.sha256` (SHA-256 of both files concatenated in
   alphabetical filename order). Compare against the plugin's stored hash.
3. If either script is absent or the combined hash differs, print a single advisory
   at the end of the update summary:

```
⚠️  forge:statusline scripts are out of date.
    Run /forge:statusline to update ~/.claude/forge-statusline.py
                                  and ~/.claude/forge-subagent-statusline.py
```

This check is advisory only — `forge:update` never modifies files outside the repo.

---

## Open Decisions

None. All design questions from the initial exploration have been resolved:

- **Script sourcing:** Copy to `~/.claude/` (inspectable, self-contained).
- **Effort resolution:** `.forge/EFFORT` file first, branch name suffix as fallback.
- **JSON parsing:** Python 3 stdlib only; no `jq`.
