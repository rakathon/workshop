# Test Strategy — forge-promote

## Scope

| Area | What is tested |
|------|---------------|
| Readiness check — full tier, discovery → planning | Artifact presence, validation report parsing, FAIL blocking, PASS WITH CONCERNS handling |
| Readiness check — lightweight tier | Gate bypass behavior |
| Readiness check — planning → implementation | Task file presence, task format detection |
| Readiness check — implementation → verification | All-complete check, SHA presence |
| Readiness check — verification → closed | Verify report presence and result |
| Confirmation protocol | Accepted inputs, rejected inputs, cancellation, no response |
| Checkpoint commit | Commit contents, commit message format, approver and timestamp in state |
| Registry update | Phase column updated, other rows preserved |
| State updates | All fields, post-approval modification reconciliation |

---

## Approach

### Skill Behavioral Tests

`forge:promote` is tested using the with/without-context eval methodology from
rr-standards. `.evals.json` companion file alongside `SKILL.md`.

The eval set must have ≥ 5 compliant and 5 non-compliant examples covering the main
behavioral rules. `rr-standards:validate --active` provides the harness.

---

### Readiness Check Test Cases

| Test case | Input state | Expected behavior |
|-----------|-------------|-------------------|
| Full tier, all artifacts present, PASS result | Complete `.state.json`, all files exist, `validation/report.md` has PASS | Proceeds to summary |
| Full tier, missing business.md | No `requirements/business.md` | Stops with gap report listing missing artifact; no summary presented |
| Full tier, missing technical.md | No `requirements/technical.md` | Stops with gap report |
| Full tier, missing spec artifacts | `spec/` contains only README | Stops with gap report |
| Full tier, missing validation report | No `validation/report.md` | Stops with message directing engineer to run `forge:arch-review` |
| Full tier, FAIL validation result | `validation/report.md` has FAIL | Stops with block message; no summary, no confirmation prompt |
| Full tier, PASS WITH CONCERNS | `validation/report.md` has PASS WITH CONCERNS | Proceeds; concerns shown in summary |
| Lightweight tier, no artifacts | `tier` = `patch`, no discovery files | Proceeds to summary without artifact checks |
| Planning, no tasks file | No `plan/tasks.md` | Stops with gap report |
| Planning, empty tasks file | `plan/tasks.md` exists but no task lines | Stops with gap report |
| Implementation, all tasks complete with SHAs | All `[x]` with 7-char SHAs | Proceeds to summary |
| Implementation, incomplete tasks remain | One `[ ]` task present | Stops listing incomplete tasks |
| Implementation, task complete but no SHA | `[x]` line missing SHA | Stops with gap report |
| Verification, verify-report absent | No `validation/verify-report.md` | Stops directing engineer to run `forge:verify` |
| Verification, verify-report FAIL | `validation/verify-report.md` has FAIL | Stops with block message |
| Verification, verify-report PASS | `validation/verify-report.md` has PASS | Proceeds to summary |

---

### Confirmation Protocol Test Cases

| Test case | Input | Expected behavior |
|-----------|-------|-------------------|
| Affirmative — yes | `yes` | Advances |
| Affirmative — confirm | `confirm` | Advances |
| Affirmative — approved | `approved` | Advances |
| Affirmative — case insensitive | `YES`, `Confirm`, `APPROVED` | Advances |
| Affirmative — with whitespace | `  yes  ` | Advances |
| Ambiguous — maybe | `maybe` | Rejects; requests explicit confirmation |
| Ambiguous — sure | `sure` | Rejects; requests explicit confirmation |
| Ambiguous — ok | `ok` | Rejects; requests explicit confirmation |
| Ambiguous — empty string | `` | Rejects; requests explicit confirmation |
| Cancellation — no | `no` | Cancels; no state changes |
| Cancellation — cancel | `cancel` | Cancels; no state changes |

---

### Checkpoint Commit Test Cases

| Test case | Fixture state | Expected outcome |
|-----------|--------------|-----------------|
| Discovery → planning | Confirmed advancement | Commit message `chore(PROJ-1234): promote discovery to planning`; commit contains only `.state.json` |
| Planning → implementation | Confirmed advancement | Correct commit message and contents |
| approvedBy populated | git user.name configured | `approvedBy` = git name |
| approvedBy fallback | git user.name absent, user.email present | `approvedBy` = git email |
| approvedBy unknown | Neither name nor email configured | `approvedBy` = `"unknown"` |
| approvedAt format | Any promotion | UTC ISO-8601 timestamp in `approvedAt` |

---

### Post-Approval Modification Reconciliation Test Cases

| Test case | Input state | Expected outcome |
|-----------|-------------|-----------------|
| Modifications present | `postApprovalModifications` has 2 entries | Both shown in summary; after promotion, moved to `phases.<phase>.reconciledModifications`; `postApprovalModifications` = `[]` |
| No modifications | `postApprovalModifications` = `[]` | Section omitted from summary; `reconciledModifications` not written |

---

### Integration Tests

End-to-end tests on a temporary git repository:

1. Full-tier effort with all artifacts and PASS validation → promote discovery → planning
   → verify `.state.json` fields, checkpoint commit, registry update
2. Full-tier effort with FAIL validation → attempt promote → verify blocked before summary
3. Lightweight-tier effort → promote discovery → planning with no discovery artifacts
   → verify promotion succeeds
4. Confirmation with `maybe` → verify no state changes; second attempt with `yes`
   → verify promotion completes
5. Promotion with post-approval modifications present → verify modifications in summary
   → verify reconciliation in `.state.json` after promotion

---

## Test Plans

_None yet — to be added during implementation phase._

## Coverage Notes

The readiness check for the discovery → planning full-tier transition is the highest
priority test area — a bug here could allow advancement past a FAIL validation result.
The confirmation protocol is the second priority — ambiguous input must never advance
the effort.
