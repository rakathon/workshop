# forge-branching — Architecture

This capability enforces branch policy across a Forge-managed repository. It delivers
four layers of enforcement:

1. **Default-branch blocking** — direct commits and pushes to main are structurally
   prevented via a PreToolUse hook and a git pre-push hook
2. **Branch name format validation** — commits on non-conforming branch names are
   blocked with a rename suggestion
3. **Push-time alignment warning** — commits that don't match the declared branch type
   are flagged before the PR is opened
4. **Conversational branch creation** — engineers describe their work and the agent
   creates a correctly-named branch automatically

---

## Artifact Inventory

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `enforce-branch-policy.sh` | PreToolUse hook | Project (plugin cache) | Bash tool calls |
| `pre-push.sh` | Git hook template | Repository `.git/hooks/` | `git push` |
| `forge-claude-md-section.md` | CLAUDE.md template section | Session context | Session start |

---

## Enforcement Layers

### Layer 1: Default Branch Block

Prevents any commit or push reaching the default branch without going through a PR.

```
Agent → Bash tool → enforce-branch-policy.sh
    Detects: tool=Bash, command=git commit/push, branch=main
    Exit 2 → Claude Code blocks the call; JSON diagnostic to stderr

Engineer → git push → .git/hooks/pre-push
    Reads pushed refs from stdin
    Detects: remote ref = refs/heads/main or refs/heads/master
    Exit 1 → git aborts; block message to stderr
```

### Layer 2: Branch Name Format Validation

On every `git commit`, after confirming the branch is not the default branch, validates
that the branch name follows one of the allowed formats:

```
effort/<id>       — Forge effort branches (always valid)
feature/<slug>    — New functionality
fix/<slug>        — Bug fixes
hotfix/<slug>     — Urgent production fixes
chore/<slug>      — Maintenance operations
docs/<slug>       — Documentation only
refactor/<slug>   — Structural changes, no behavior change
release/<version> — Release preparation
```

Slug rules: lowercase, hyphens only, max 40 characters. Release slugs may contain dots.

Invalid branch → exit 2 with `branch_name_violation` JSON diagnostic listing all valid
formats and a `git branch -m` rename instruction.

### Layer 3: Push-Time Alignment Warning

On every `git push` (except effort branches), invokes `claude -p` with the branch name,
recent commits, and changed file paths. If the AI assessment indicates the work does not
match the branch type, emits an advisory warning to stdout with a suggested branch name.
Always exits 0 — the push proceeds regardless.

10-second timeout on the `claude -p` call; silently skipped if it fails or times out.
`FORGE_SKIP_BRANCH_VALIDATION=1` bypasses both format validation and alignment checks.

### Layer 4: Conversational Branch Creation (CLAUDE.md)

The forge-managed CLAUDE.md section includes type inference rules that guide the agent
to create a correctly-named branch when the engineer describes work conversationally.
Eight inference rules cover the full taxonomy; a clarifying question is asked only when
the type is genuinely ambiguous.

---

## Admin Override

| Signal | Scope | Audit |
|--------|-------|-------|
| `FORGE_ALLOW_MAIN_COMMIT=1` | Current shell session only | Written to `.forge/audit/` |
| `FORGE_ADMIN_OP=<reason>` | Set by Forge skills only | Written to `.forge/audit/` |
| `git push --no-verify` | CLI path only | None (git built-in mechanism) |
| `FORGE_SKIP_BRANCH_VALIDATION=1` | Format + alignment checks only | None |

---

## Key File Locations

| File | Owner | Purpose |
|------|-------|---------|
| `plugins/forge/hooks/pre-tool-use/enforce-branch-policy.sh` | forge-branching | PreToolUse hook — all three agent-path enforcement layers |
| `plugins/forge/hooks/pre-push/pre-push.sh` | forge-branching | Git hook template — CLI push enforcement |
| `plugins/forge/templates/forge-claude-md-section.md` | forge-init / forge-branching | CLAUDE.md template — branch type inference section |
| `.git/hooks/pre-push` | `forge:init` (installer) | Active git hook; installed from template |
| `.forge/audit/<timestamp>.json` | enforce-branch-policy.sh | Audit record for each admin override |

---

## Design Documents

| Document | Contents |
|----------|----------|
| [hooks.md](hooks.md) | Detailed design for all enforcement logic: default-branch blocking, format validation, alignment warning, pre-push hook, admin override protocol, audit log format, performance constraints, edge cases |
