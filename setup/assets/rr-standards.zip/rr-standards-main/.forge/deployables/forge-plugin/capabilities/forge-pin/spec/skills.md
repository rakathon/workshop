# forge:pin Skill Design

Design for the `forge:pin` skill. The skill is interactive, runs in the engineer's
Claude Code session, and uses `gh api` for all GitHub API calls.

Related: [forge-init skill design](../../forge-init/spec/skills.md) |
forge-update skill design _(separate capability)_

Implementation: `plugins/forge/skills/pin/`

---

## forge:pin

### Arguments

| Flag | Description | Default |
|------|-------------|---------|
| `--version <semver>` | Version to pin to (e.g. `1.2.3` or `v1.2.3`) | latest release |

### Preconditions

- **PC-1:** `gh` CLI installed and authenticated
- **PC-2:** Not inside a `.forge/` subdirectory

### Flow

```
Step 1: Resolve target version via GitHub API
        If --version provided: strip leading "v"; look up tag SHA
          gh api repos/rewards-guilds/rr-standards/git/ref/tags/v<version>
          → error with available tags if tag not found
        If omitted: fetch latest release tag
          gh api repos/rewards-guilds/rr-standards/releases/latest
        Check if already pinned to this version + SHA → "Already pinned. Nothing to do."

Step 2: Create/update .claude-plugin/marketplace.json
        Write git-subdir source with ref (semver tag) and sha (commit SHA)

Step 3: Update .claude/settings.json
        extraKnownMarketplaces["forge-local"] → ./.claude-plugin
        enabledPlugins: remove all forge@* entries; add forge@forge-local = true

Step 4: Update .forge/version forge_min_version (only if .forge/version exists)
        sed -i "s/^forge_min_version=.*/forge_min_version=<version>/" .forge/version

Step 5: Instruct user to run /plugin install forge@forge-local; pause for confirmation

Step 6: Print summary
        Created / Updated / Unchanged per file
        Commit reminder with exact git commands
        Next steps: forge:init (first time) or forge:update (pin change on existing repo)
```

### Key Design Decisions

- `forge:pin` has no knowledge of hooks or `.forge/` directory structure — that's
  `forge:init`'s responsibility. Keeping them separate allows either to be run
  independently or in any order.
- Both `ref` (semver tag) and `sha` (commit SHA) are stored. The SHA provides a
  cryptographic pin — Claude Code uses it to load the exact plugin version rather than
  whatever the tag currently points to, preventing tag mutation attacks.
- `forge:pin` only updates `forge_min_version`, not `active_version`. `active_version`
  reflects what is actually loaded, which is set by `forge:init` at init time and by
  `forge:update` after migrations.
- Re-pinning to the same version exits cleanly with "Already pinned." — this makes
  `forge:pin` safe to run in scripts or CI without side effects.
- The plugin install step requires explicit confirmation because `forge:update` (if
  run next) depends on the plugin being in the cache. Failing to install before
  running `forge:update` causes a confusing error.
