# Success Criteria — forge-spec-api

- [ ] Inline checks fire after EACH endpoint is confirmed — not once after all endpoints are designed
- [ ] A non-standard status code triggers a correction proposal, not silent acceptance
- [ ] When the engineer overrides a standard rule, the rationale appears as an inline comment in the YAML and a forge:adr prompt is shown
- [ ] When `--resource` is not provided, a resource breakdown is proposed and confirmed before any endpoint is designed
- [ ] The contract file includes the standard Error schema component at the top level
- [ ] `.state.json` is updated to `"present"` after the contract is written
- [ ] If `requirements/business.md` is absent, the skill stops with a message pointing to `forge:elaborate`
