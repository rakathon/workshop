# Runbook — forge-cross-repo

## Starting a Local Sub-Effort from a Coordination Effort

**When to use:** A new feature spans multiple repositories. A coordination effort
exists (or has just been created) in the coordination repository. You are starting
work in one of the deployable repositories.

**Prerequisites:**
- `gh` CLI installed and authenticated (`gh auth login`)
- Read access to the coordination repository
- The coordination effort ID (visible in the coordination repo's `.forge/efforts/README.md`)

**Steps:**

1. Run `forge:project` in the local deployable repository:
   ```
   forge:project --coordination-repo <org/repo> --effort-id <effort-id>
   ```

2. Confirm the local effort ID when prompted (default: `<effort-id>-<deployable-name>`)

3. Review the projected files created under `.forge/efforts/<local-effort-id>/`

4. Commit the result:
   ```
   git add .forge/efforts/<local-effort-id>/
   git add .forge/efforts/README.md
   git commit -m "docs(<local-effort-id>): project from <coordination-effort-id>"
   ```

5. Proceed with local discovery: write technical requirements and spec artifacts that
   elaborate the projected coordination requirements.

---

## Checking Whether Projections Are Current

**When to use:** You are resuming work on a local sub-effort and want to verify that
your projections are still aligned with the coordination repository. Also run before
advancing from discovery to planning.

**Steps:**

1. Run `forge:sync` from the repository root:
   ```
   forge:sync
   ```

2. Review the output:
   - `current` — no action needed
   - `stale` — see "Updating a Stale Projection" below
   - `unreachable` — check network/authentication; proceed with local work if blocked

---

## Updating a Stale Projection

**When to use:** `forge:sync` reports one or more projections as `stale`. You have
reviewed the coordination repository changes and decided to incorporate them.

**Steps:**

1. Review what changed in the coordination repository. The `stale` output includes both
   SHAs; use them to inspect the diff:
   ```
   gh api repos/<org/repo>/commits/<current-sha>
   ```

2. If the changes are relevant to your local work, re-materialise:
   ```
   forge:sync --rematerialise
   ```

3. Review the rewritten projected files. Verify that the updated coordination content
   is coherent with your local elaboration artifacts (local technical requirements,
   spec, etc.).

4. Update your local artifacts if the coordination changes affect them.

5. Commit the updated projections:
   ```
   git add .forge/efforts/<local-effort-id>/
   git commit -m "docs(<local-effort-id>): update projections from <coordination-effort-id>"
   ```

**If you decide not to update:** A stale projection may be intentional. If the
coordination change does not affect your local work, leave the projection as-is.
`forge:sync` will continue to report it as stale until you re-materialise or the
coordination artifact reverts. This is expected and not an error.

---

## Proposing a Change to a Coordination Artifact

**When to use:** Local discovery reveals that a coordination-level artifact — a
requirement, a contract, a plan entry — is incomplete, incorrect, or needs to change.

**Steps:**

1. Run `forge:upstream` and describe the change:
   ```
   forge:upstream
   ```
   Or, if you want to create a PR immediately:
   ```
   forge:upstream --pr
   ```

2. Follow the prompts to identify the target coordination file, describe the change,
   and provide the rationale and proposed content.

3. If you used `--pr`, share the PR URL with the coordination effort owner.

4. If you did not use `--pr`, the proposal is recorded locally. Create the PR manually
   when ready:
   ```
   gh pr create \
     --repo <org/coordination-repo> \
     --title "forge:upstream: <title>" \
     --body-file .forge/efforts/<local-effort-id>/upstream-proposals/<id>-<slug>.md
   ```

5. After the PR is merged, update the proposal status in `.state.json`:
   - Change `status` from `proposed` to `merged`

---

## Diagnosing Authentication Failures

**Symptoms:** `forge:project` or `forge:sync` fails with HTTP 401 or 403.

**Steps:**

1. Check `gh` authentication status:
   ```
   gh auth status
   ```

2. If not authenticated, re-authenticate:
   ```
   gh auth login
   ```

3. If authenticated but getting 403: verify that your GitHub account has read access
   to the coordination repository. Contact the coordination repository owner to request
   access.

4. If using a fine-grained token: verify the token has `repo:read` scope for the
   coordination repository and has not expired.

---

## Diagnosing Missing coordinationRef

**Symptoms:** `forge:upstream` fails with "No coordinationRef found in .state.json."

**Cause:** The local effort was created manually (not via `forge:project`), or the
`.state.json` was created from the template without populating `coordinationRef`.

**Resolution:** Run `forge:project` to establish the coordination link and materialize
projections. If the sub-effort already has local artifacts that should be preserved,
`forge:project` will prompt before overwriting; answer accordingly to merge or skip
individual files.
