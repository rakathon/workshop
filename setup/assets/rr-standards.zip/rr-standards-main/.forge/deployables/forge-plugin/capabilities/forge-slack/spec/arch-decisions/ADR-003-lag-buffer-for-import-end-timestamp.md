# ADR-003: Use Lag Buffer When Computing Import End Timestamp

**Status:** Accepted
**Deployable:** forge-plugin / forge-slack
**Date:** 2026-04-28

## Context

When `forge:slack-import` runs without an explicit `--to` bound, it needs to determine
how far forward to fetch messages. The natural choice is the current timestamp (`now`),
but this introduces a subtle correctness risk: Slack's API may not have indexed all
messages sent in the seconds immediately before the query executes. A message sent at
`14:32:05` may be invisible to a query with `latest=14:32:07` due to delivery lag or
eventual consistency. When the import checkpoints at `now`, the next run starts from
that timestamp and those in-flight messages are permanently missed.

This came to light when considering the move from end-of-previous-day to current
timestamp as the default `end` bound.

## Decision

We will subtract a configurable lag buffer (default: 5 minutes) from `now` when
computing the default `end` timestamp. The checkpoint is written at `now - lag-buffer`
rather than `now`. The next run therefore starts from a point 5 minutes before the
previous run ended, overlapping the tail window. Any messages re-fetched in that
overlap are silently deduplicated by the existing `ts`-based idempotency logic.
The buffer is exposed as `--lag-buffer <minutes>` and can be set to `0` to disable.

## Alternatives Considered

**Checkpoint at `now` with no buffer** — simple but creates a permanent blind spot for
messages in-flight at query time. Once the checkpoint advances past those messages they
can never be recovered without a manual `--from` backfill.

**End-of-previous-day boundary (original design)** — sidesteps the lag problem by
always importing complete days, but means the import is up to 24 hours behind and
users do not see today's messages until the next day's run.

**Fetching the same window twice and comparing** — would detect gaps but doubles API
calls on every run with no benefit in the common case where lag is sub-second.

## Consequences

- Import results are guaranteed complete for any message sent more than `lag-buffer`
  minutes before the run, with no manual intervention required.
- Each watermark-based run re-fetches a small overlap window (default: 5 minutes of
  messages). The dedup logic must remain correct; any regression there would cause
  duplicate entries in daily files.
- CI jobs with infrequent schedules (e.g. hourly) may want a larger `--lag-buffer`
  to account for longer potential delivery windows.
- Users importing manually get near-real-time results (at most 5 minutes behind)
  rather than waiting until the next calendar day.
