# Success Criteria — forge-effort

These criteria are the measurable acceptance bar for the forge-effort capability. Each
criterion specifies the behavior, the mechanism that delivers it, and how to verify it.

---

## SC-1: forge:effort Creates a Valid .state.json in Under 5 Seconds

**Criterion:** Invoking `forge:effort` (or the conversational equivalent) produces a
`.state.json` that passes schema validation and registers the effort in `.forge/efforts/README.md`,
all within 5 seconds of invocation.

**Verification:**
1. Invoke `forge:effort` in a repository with an initialized `.forge/` directory.
2. Confirm `.forge/efforts/<id>/.state.json` exists and contains all required base fields.
3. Confirm `subtype` and `productionBound` are set correctly per the declared subtype.
4. Confirm `.forge/efforts/README.md` contains exactly one new row for the effort.
5. Measure wall-clock time from invocation to completion.

**Pass condition:** All fields present and valid; registry updated; elapsed time under 5s.

---

## SC-2: SessionStart Hook Completes in Under 2 Seconds

**Criterion:** The `inject-workflow-context.sh` hook completes its state injection within
2 seconds at session start, even when GitHub API staleness checks are in flight.

**Verification:**
1. Start a Claude Code session in a repository with one or more active efforts.
2. Measure the time from session start to the first Forge context block appearing in output.
3. Repeat with and without network access (offline should complete faster or equal).

**Pass condition:** Context block appears within 2 seconds. In offline mode, the hook
emits context without staleness info rather than waiting or erroring.

---

## SC-3: PostToolUse Hook Detects All 8 Artifact Types and Updates State

**Criterion:** The `update-workflow-state.sh` PostToolUse hook correctly identifies and
records state updates for all 8 recognized artifact write patterns.

**The 8 artifact types:**
1. `requirements/business.md` → sets `phases.discovery.artifacts.requirements.business: "present"`
2. `requirements/technical.md` → sets `phases.discovery.artifacts.requirements.technical: "present"`
3. `spec/api/*.yaml` → sets `phases.discovery.artifacts.spec.api: "present"`
4. `spec/storage/*.md` → sets `phases.discovery.artifacts.spec.storage: "present"`
5. `spec/messaging/*.md` → sets `phases.discovery.artifacts.spec.messaging: "present"`
6. `spec/arch-decisions/ADR-*.md` → appends filename to `phases.discovery.artifacts.adrsCreated`
7. `plan/tasks.md` → sets `phases.planning.status: "in_progress"` if previously `"not_started"`
8. `validation/report.md` → sets `phases.validation.status: "in_progress"` and parses
   the overall result (PASS / PASS WITH CONCERNS / FAIL) into `phases.validation.result`

**Verification:** Write a test file for each artifact type, then verify the corresponding
`.state.json` field was updated. Use a mock `.state.json` with all phases in `not_started`.

**Pass condition:** All 8 artifact types produce the correct state update. No artifact
write leaves `.state.json` in an inconsistent state.

---

## SC-4: Phase-Context Hook Never Exits 2 for Any .forge/efforts/ Write

**Criterion:** The `phase-context.sh` PreToolUse hook exits 0 for every write to a
`.forge/efforts/` path, regardless of current phase or artifact type.

**Verification:**
1. Set up an effort in `implementation` phase with discovery marked `approved`.
2. Attempt to write `requirements/business.md` (a post-approval modification scenario).
3. Confirm the hook exits 0 (write is allowed).
4. Confirm the hook emits an informational message (not a block).
5. Attempt writes for 10 different effort artifact paths across 3 different current phases.

**Pass condition:** Every test case produces exit 0. No write to a `.forge/efforts/` path
is blocked by this hook under any conditions.

---

## SC-5: forge:status Accurately Reports Wave-Level Task Completion

**Criterion:** `forge:status` (or the conversational "where are we?") correctly reports
the number of completed and remaining tasks per wave, matching the actual state of
`plan/tasks.md` and `phases.implementation` in `.state.json`.

**Verification:**
1. Create an effort with a `plan/tasks.md` containing 3 waves and 10 tasks.
2. Mark 4 tasks complete (including all of wave 1 and partial wave 2).
3. Invoke `forge:status`.
4. Confirm output shows: wave 1 complete, wave 2 partially complete (N of M), wave 3 not started.

**Pass condition:** Reported wave completion matches task file state exactly.

---

## SC-6: forge:pause / forge:resume Round-Trips State Without Information Loss

**Criterion:** Invoking `forge:pause` followed by `forge:resume` in a subsequent session
restores the engineer to exactly the state they left, with no information loss.

**Pause state that must survive the round-trip:**
- The active task at the time of pause
- The last completed step in that task
- Open decisions and their descriptions
- Post-approval modifications recorded so far
- The agent's understanding of next action (natural-language summary)

**Verification:**
1. Begin an effort in implementation phase, mid-task.
2. Record an open decision.
3. Invoke `forge:pause`. Verify `.state.json` contains a populated `pauseState` object.
4. Start a new session. Invoke `forge:resume` (or observe automatic resume via SessionStart).
5. Verify the agent correctly reports: which task was active, what the open decision was,
   and what the next action is.

**Pass condition:** All pause state fields are present in `.state.json` after pause.
After resume, the agent's reported state matches the paused state exactly.

---

## SC-7: A Conversational Engineer Gets Identical Outcomes to an Explicit-Command Engineer

**Criterion:** An engineer who never invokes a Forge skill — working entirely through
natural conversation — produces the same artifacts and state updates as an engineer who
uses explicit skill invocations at every step.

**Verification (conversational path):**
1. Start a session with no existing efforts.
2. Say: "We need to build a caching layer for user sessions."
3. Verify: effort scaffolded, `.state.json` created, registry updated.
4. Say: "The caching layer must support 10k ops/sec and have a 1-hour TTL."
5. Verify: requirements artifact created or updated.
6. Say: "We've decided to use Redis."
7. Verify: ADR created in `spec/arch-decisions/`.
8. Say: "Let's pick this up tomorrow."
9. Verify: `pauseState` populated in `.state.json`.

**Compare against explicit path:** Run `forge:effort`, produce the same artifacts via
skills, invoke `forge:pause`. Verify `.state.json` structure is identical.

**Pass condition:** Both paths produce identical `.state.json` structure and equivalent
artifact content. The conversational path requires no Forge skill knowledge from the engineer.

---

## SC-8: poc Subtype Sets productionBound: false and Cannot Be Changed

**Criterion:** When `forge:effort` is invoked with subtype `poc`, `.state.json` is written
with `productionBound: false`, and no subsequent operation can change this field to `true`.

**Verification:**
1. Create an effort with `subtype: "poc"`.
2. Confirm `productionBound: false` in `.state.json`.
3. Attempt to manually set `productionBound: true` and re-run any hook or skill.
4. Confirm the system does not apply production-bound CI checks for this effort.
5. Create a production follow-on effort. Confirm the PoC's `spawnedWorkItems` array
   records the new effort's ID.

**Pass condition:** `productionBound: false` is set at creation for poc. Production
follow-on is tracked in `spawnedWorkItems`, not via mutation of the original field.
