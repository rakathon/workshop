# forge:help — Skill Specification

**Agent type:** Orchestrator
**Skill file:** `plugins/forge/skills/help/SKILL.md`

---

## Purpose

`forge:help` is the live documentation layer for the Forge plugin. It answers questions
about the framework by reading the plugin's own documentation at execution time —
skills, hooks, standards, and language guides — rather than relying on hardcoded lists
or training-data knowledge that may be stale.

---

## Trigger

- `forge:help` (no argument) — catalog mode
- `forge:help <question>` (any argument) — Q&A mode

Natural triggers: "what skills does Forge have?", "how does forge:commit work?",
"what does the inject-generation-standards hook do?", "what phases does Forge have?",
"what does Forge's REST API standard say about X?", "/forge:help".

---

## Step 1: Resolve the Plugin Root

Before any file reads, resolve the plugin root path using the standard fragment at
`plugins/forge/skills/common/plugin-root.md`:

```bash
find ~/.claude/plugins/cache/forge-local -maxdepth 4 -name "plugin.json" \
  -path "*/forge/*" 2>/dev/null | head -1 | sed 's|/.claude-plugin/plugin.json||' \
  | grep . \
  || find ~/.claude/plugins/cache -maxdepth 5 -name "plugin.json" \
     -path "*/forge/*" 2>/dev/null | head -1 | sed 's|/.claude-plugin/plugin.json||'
```

All subsequent paths reference `<plugin_root>/` as the base. Never hardcode the
plugin root path.

---

## Step 2: Route to Catalog or Q&A Mode

- **No argument:** proceed to Catalog Mode (Step 3)
- **Any argument:** proceed to Q&A Mode (Step 4)

---

## Step 3: Catalog Mode

Execute this discovery sequence and produce a structured catalog:

### 3a. Skills

1. Read `<plugin_root>/skills/AGENTS.md` — enumerates skill directories and phases
2. For each skill directory listed, check: `[ -f "<plugin_root>/skills/<dir>/SKILL.md" ]`
   - Present: read the `description` from the SKILL.md frontmatter (or first paragraph)
   - Absent: skip entirely — do not include stubs in any output
3. Group implemented skills by workflow phase as annotated in AGENTS.md

### 3b. Hooks

1. Read `<plugin_root>/hooks/hooks.json` — enumerates hook scripts by event type
2. For each hook script path in the JSON, read the script
3. Derive a one-liner in plain English: describe *what the hook does* and *when it fires*
   — do not quote script code or show the file path

### 3c. Standards

1. Read `<plugin_root>/standards/AGENTS.md`
2. List the available standards categories with a brief description of each domain

### 3d. Language Guides

1. Read `<plugin_root>/languages/AGENTS.md`
2. List the available language guides

### 3e. Output Format

Present the catalog as structured Markdown:

```
## Forge Skills

### Discovery
- forge:elaborate — ...
- forge:adr — ...
...

### Planning
...

### Implementation
...

### Validation
...

## Hooks

### PreToolUse
- <hook-name> — <one-liner>

### PostToolUse
- <hook-name> — <one-liner>

## Standards

- API — ...
- Security — ...
...

## Language Guides

- Go — ...
- Kotlin — ...
...
```

---

## Step 4: Q&A Mode

### 4a. Parse the Question

Identify which component areas the question spans:
- Skills (named skill or workflow concept)
- Hooks (named hook or "how does Forge enforce/inject/check...")
- Standards (REST, security, storage, messaging, testing, observability)
- Language guides (Go, Kotlin, Swift, TypeScript, Java)
- Workflow phases (discovery, planning, implementation, validation, graduation)

A question may span multiple areas. Identify all of them.

### 4b. Navigate to Relevant Artifacts

For each identified area:

| Area | Navigation path |
|------|----------------|
| Skill | Read `<plugin_root>/skills/AGENTS.md` → locate skill directory → read `SKILL.md` |
| Hook | Read `<plugin_root>/hooks/hooks.json` → locate hook script → read script |
| Standard | Read `<plugin_root>/standards/AGENTS.md` → locate category → read standard file |
| Language guide | Read `<plugin_root>/languages/AGENTS.md` → locate language dir → read guide |
| Workflow phase | Read `<plugin_root>/skills/AGENTS.md` → read SKILL.md files for skills in that phase |

Before reading any skill's SKILL.md, verify it exists (stub check). If asked about a
stub by name, respond: "forge:`<name>` is planned but not yet implemented." — do not
fabricate behavior.

### 4c. Synthesize and Answer

Read the located artifacts in full. Produce one complete plain-English response that:
- Addresses every aspect of the question
- Covers all identified areas in a single unified answer
- Does not require a follow-up question to complete the picture
- Does not expose internal plugin file paths

### 4d. Effort-State Boundary

If the question requires knowing the engineer's specific effort state (e.g., "am I
ready to run forge:plan?", "what phase am I in?"):

1. Answer the conceptual part: explain the skill's preconditions and what it requires
   from plugin documentation
2. Append: "To see your current effort state and recommended next action, run
   `forge:status`."

Do not read `.forge/EFFORT`, `.forge/efforts/`, `.state.json`, or any effort directory.

---

## Output Constraints

- No internal plugin file paths in any response
- No raw script code quoted back to the engineer
- No artifact content dumped verbatim — synthesize and present in plain terms
- No sub-agents spawned
- No files written; no effort state modified
