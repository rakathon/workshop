# Technical Requirements — forge-classify

Parent: [business requirements](business.md)
Upstream program requirements: forge-plugin TR § Discovery Phase Capabilities

---

## TR-1: Risk Rubric Loaded from Standards File

The skill must load the risk classification rubric from
`<plugin_root>/standards/risk/classification.md` (per ADR-003 — skills reference
standards, never embed rules). If the file is absent, a built-in fallback rubric
is used and the absence is noted to the engineer. The fallback rubric must be
identical in content to the standards file to ensure consistent classification
behavior regardless of the file's presence.

## TR-2: suggestedRisk Advisory Integration

If a prior step has written `suggestedRisk` and `suggestedRiskRationale` to
`.state.json`, `forge:classify` must surface them as the starting point before
applying its own analysis. The advisory informs but does not constrain — the
engineer may confirm, override, or disagree regardless of the suggested value.

## TR-3: Explicit Rationale for the Recommendation

The recommendation presented to the engineer must show:
- Which rubric indicators fired (triggering the recommended tier)
- Which higher-tier indicators were evaluated and did not fire
- Which lower-tier indicators would have applied and why the recommended tier is
  higher

This level of transparency allows engineers to catch errors in both directions:
a missed indicator that should escalate the tier, or an indicator that was applied
but does not actually fit this capability.

## TR-4: Engineer Confirmation Required

The classification is not written to `.state.json` until the engineer explicitly
confirms or provides an override. Three responses are valid:
- **Confirm** — accept the recommendation as-is
- **Override** — specify a different tier with a brief rationale
- **Revise** — reconsider before deciding; skill stops without writing

If the engineer overrides, the override rationale must be captured and stored
alongside the classification in `.state.json` (`riskRationale` field).

## TR-5: State.json Fields Written and Cleared

On confirmation or override, `forge:classify` writes:
- `"risk"`: the committed tier (`R1`, `R2`, `R3`, or `R4`) — always `R`-notation
- `"riskRationale"`: one sentence capturing the primary reason for the tier

And clears (sets to `null`):
- `"suggestedRisk"` — if present
- `"suggestedRiskRationale"` — if present

Fields are read before writing to avoid clobbering unrelated `.state.json` content.

## TR-6: Re-invocation Support

`forge:classify` may be re-invoked after a classification has already been set.
On re-invocation, it must show the current classification and rationale, ask what
prompted the revision, and run the full recommendation flow again. There is no
restriction on tier direction — escalation and de-escalation are both valid.

## TR-7: Phase Guard (Advisory)

Classification is intended for the discovery phase, but it is not strictly
gated. If the effort's `currentPhase` is not `discovery`, the skill warns the
engineer and asks for confirmation before proceeding. It does not block — risk
revision at any phase is a valid use case.

## TR-8: Output Format

The summary output after writing must include:
- The committed tier in `R`-notation (never natural language synonyms)
- A one-line rationale
- A single tier-consequence line showing what this classification requires
- Next-step suggestions pointing to `forge:elaborate` and `forge:spec-api`
