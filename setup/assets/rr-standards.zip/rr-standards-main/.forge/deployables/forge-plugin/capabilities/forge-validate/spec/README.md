# forge-validate Spec

Design artifacts for the `forge:validate` capability.

## Contents

| File | Description |
|------|-------------|
| [skills.md](skills.md) | Detailed skill specification — orchestrator pre-invocation steps and worker logic |

## Design Summary

`forge:validate` is a two-part skill: an orchestrator pre-invocation check (runs in
the engineer's session) and a worker sub-agent (performs the actual validation checks).
This separation keeps large spec file content out of the engineer's primary session
context, consistent with ADR-015 (worker pattern for context-heavy operations).

### Key design decisions

**Grep-extractable result line:** The `**Result:**` header must be the first non-blank
line of `validation/report.md`. This enables `forge:promote` and other skills to
extract the outcome with a single `grep '^\*\*Result:\*\*'` call, with no prose parsing.

**Worker does not update .state.json:** State updates are the orchestrator's
responsibility. The worker only writes the report file and commits it. This keeps the
worker stateless and re-runnable.

**Parallelization threshold at 1,000 lines:** For typical R3/R4 efforts, artifacts
are well under this threshold and single-pass validation is fast. For R1/R2 efforts
with many spec artifacts, four domain-specialized agents run in parallel to keep
validation time acceptable.

**Standards loaded only for present domains:** Loading all standards unconditionally
would pollute context for efforts that don't use all domains. Only standards for spec
domains actually present in the effort are loaded.

## Related Documentation

- [forge-promote capability](../forge-promote/) — reads the `**Result:**` line as its gate
- [forge-arch-review capability](../forge-arch-review/) — also writes `validation/report.md` for R1/R2 formal review meetings
- [spec-driven-development initiative skills spec](../../../../efforts/spec-driven-development/spec/skills.md) — section on forge:validate
