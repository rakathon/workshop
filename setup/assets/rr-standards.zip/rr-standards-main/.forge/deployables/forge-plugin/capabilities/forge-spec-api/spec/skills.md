# Skills — forge-spec-api

## forge:spec-api

**Classification:** Orchestrator

**Invocation:** `forge:spec-api [<effort-id>] [--resource <name>] [--file <path>] [--deployable <name>] [--capability <name>] [--interactive]`

**Inputs:** `requirements/business.md` (required), `requirements/technical.md` (optional), REST sub-standards

**Outputs:** `<spec_dir>/<contract>.yaml` (one file per contract, covering all resources) · `.state.json` update

**Steps:** Load standard → read reqs → check existing spec → confirm scope → per-resource loop (propose all operations → confirm → inline checks) → write contract → update state → commit

**Inline checks per endpoint (within resource review):** noun resource, correct status codes, error schema with code+message, auth on writes.
