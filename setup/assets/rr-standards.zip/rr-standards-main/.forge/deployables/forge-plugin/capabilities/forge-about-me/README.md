# forge-about-me

Guides the user through a conversational interview to produce a structured
personal context block — a short Markdown file they can paste into Claude's
system prompt so every conversation starts with accurate context about who
they are.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|----------|------|-------|---------|
| `forge:about-me` | Skill | Interactive | Manual invocation |

**`forge:about-me`** walks the user through four phases — role extraction from
LinkedIn/CV, role deep-dive, writing samples for tone analysis, and audience
framing — then assembles a four-section context block and writes it to the
user's personal Claude context. Output destination adapts to the surface:
in a Claude Code session, the block is written to `~/.claude/CLAUDE.md` (the
user-level personal context that applies to all Claude Code sessions);
in a Desktop/Chat session, the block is saved as `about-me.md` for the user
to paste into Custom Instructions. The context is never written to a project
`CLAUDE.md`.

## Output Format

The assembled context block has exactly four sections:

- **Company Context** — a fixed description of Rakuten Rewards (same for all employees)
- **My Role** — title, seniority, responsibilities, team size, reporting line, stakeholders served
- **Communication Audience** — day-to-day channels and how they adapt across audiences
- **Tone & Voice** — confirmed voice description plus a personalized anti-pattern list

## Surface-Aware Output

No runtime detection is used — Claude knows which surface it is running on
from its own context and applies the appropriate behaviour.

| Surface | Output behaviour |
|---------|-----------------|
| Claude Code | Write to `~/.claude/CLAUDE.md` (user-level personal context, all sessions) |
| Claude.ai / Claude Desktop | Save `about-me.md` + "paste into Custom Instructions" guidance |
| Cowork | Save `about-me.md` + share full path for retrieval |

Personal context is **never** written to a project `CLAUDE.md`.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| None | Standalone skill — no Forge effort context required |

## Implementation Location

`plugins/forge/skills/about-me/` — `forge:about-me` SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| [requirements/business.md](requirements/business.md) | Why this capability exists |
| [requirements/technical.md](requirements/technical.md) | Technical requirements |
| [requirements/success-criteria.md](requirements/success-criteria.md) | Measurable acceptance criteria |
| [spec/README.md](spec/README.md) | Design overview |
| [spec/skills.md](spec/skills.md) | `forge:about-me` detailed design |
| [test/README.md](test/README.md) | Test strategy |
| [security/README.md](security/README.md) | Security considerations |
| [runbook/README.md](runbook/README.md) | Operational procedures |

## Parent Deployable

This capability belongs to the [forge-plugin](../../README.md) deployable.
