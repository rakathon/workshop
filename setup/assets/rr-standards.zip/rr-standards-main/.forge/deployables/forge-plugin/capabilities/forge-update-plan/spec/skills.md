# forge:update-plan — Skill Specification

**Agent type:** Orchestrator
**Skill file:** `plugins/forge/skills/update-plan/SKILL.md`
**Command:** `forge:update-plan [TASK-NNN]`

## Purpose

Marks an implementation task complete in `plan/tasks.md`, records the commit SHA
inline, moves the task from remainingTasks to completedTasks in `.state.json`,
and sets jira.syncStatus = "pending" to trigger Jira sync.

Run immediately after `forge:commit` completes an implementation task.

## Steps

1. Resolve effort context: read `.state.json` from the effort directory. Derive effort_id from current branch or present effort list.
2. Resolve target task:
   - If TASK-NNN argument provided: use it.
   - Otherwise: read `git log -1 --format="%s %N"` (subject + notes). Extract TASK-NNN from the text.
   - If still not found: display remainingTasks list and ask engineer to select.
3. Guard: check that TASK-NNN is in remainingTasks. If in completedTasks: stop with "Task TASK-NNN is already complete."
4. Read commit SHA: `git log -1 --format="%H"`.
5. Update plan/tasks.md: find the task line, change `- [ ]` to `- [x]`, append ` — <sha>` before the closing paren or at end of line.
6. Update .state.json:
   - Remove TASK-NNN from remainingTasks
   - Add `{"taskId": "TASK-NNN", "sha": "<sha>"}` to completedTasks
   - Ensure `jira` key exists; set `jira.syncStatus = "pending"`
7. Stage and commit: `chore(<effort-id>): mark <TASK-NNN> complete (<sha-short>)`
8. Print: "Task TASK-NNN marked complete. SHA: <sha>. Jira sync queued."

## Output

Updated `plan/tasks.md` and `.state.json`. Follow-up commit created.
