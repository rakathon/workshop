# Spec — forge-spec-messaging

| Artifact | Description |
|----------|-------------|
| [skills.md](skills.md) | Skill interface spec: invocation, steps, inline checks, error handling |

**Cross-references:**
- Initiative design: `.forge/efforts/spec-driven-development/spec/skills.md § forge:spec-messaging`
- Output consumed by: `forge:validate-messaging`, `forge:validate`, `forge:verify`
