# Technical Requirements — forge-init

Parent deployable: [forge-plugin](../../requirements/technical.md)

---

## TR-1: forge:init Skill

### TR-1.1: Command Surface

`forge:init` accepts no flags. It is a setup-only command responsible for hook
registration, `.forge/` directory structure, and CLAUDE.md — it has no version
pinning responsibilities.

Version pinning is handled by the separate `forge:pin` skill (TR-10). Engineers who
want to lock their team to a specific Forge version run `forge:pin` before or after
`forge:init` — the two skills are order-independent.

`forge:init` always writes to `.claude/settings.json` at **project scope**, ensuring
all contributors who clone the repository get the hook registered automatically. User
scope is not supported.

### TR-1.2: Idempotency

Running `forge:init` on an already-initialized repository must be safe and must
produce the same end state as the first run. It must not create duplicate content,
reset state written after initialization, or destroy any artifacts in `.forge/efforts/`.
The skill must detect existing initialization and operate in merge mode (TR-2.2) rather
than create mode when the `.forge/` directory already exists.

### TR-1.3: Output

`forge:init` must print a structured summary of every action taken: files created,
files updated (with the change made), files left unchanged, and the version recorded.
Engineers must be able to verify initialization from the output alone without inspecting
the resulting files.

### TR-1.4: Repository Type Selection

On first initialization (create mode), `forge:init` must prompt the engineer to
select the repository type before creating any files. The prompt must present three
options with plain-language descriptions — not framework jargon — that allow an
engineer unfamiliar with Forge to make the correct choice:

1. **Source code repository** — a service, application, or library that engineers
   build and ship. Maps to `repo_type=deployable`. Creates `deployables/` and
   `efforts/`.

2. **Product repository** — owned by a product manager. Tracks product strategy,
   roadmap, and cross-team requirements. Contains no source code. Maps to
   `repo_type=product`. Creates `products/` and `efforts/`.

3. **Coordination repository** — houses planning artifacts for a project spanning
   multiple repositories. Contains no source code. Maps to `repo_type=project`.
   Creates `efforts/` only.

In merge mode (repository already initialized), `forge:init` reads `repo_type` from
the existing `.forge/version` and skips the prompt. The existing type is shown in
the summary output.

The `repo_type` value recorded by this prompt is written to `.forge/version` (TR-4.1)
and controls which artifact directories are created (TR-3.1).

---

## TR-2: CLAUDE.md Generation and Merge

### TR-2.1: Create Mode (No Existing CLAUDE.md)

When no CLAUDE.md exists, create it from the Forge CLAUDE.md template. The generated
file must include at minimum:

- A Forge-managed section marker (see TR-2.3) wrapping the Forge content
- An explicit instruction to read the appropriate AGENTS.md files when navigating
  standards or language guides, with the path to the rr-standards installation
  (Claude Code does not load AGENTS.md automatically; without this instruction, agents
  working outside a forge: skill will not receive standards navigation context)
- An explicit instruction to read `.forge/deployables/<name>/` for canonical
  deployable artifacts (requirements, design, test strategy, security, deployment,
  runbook, and `capabilities/<name>/` for capability-level requirements and design per
  ADR-028) when working on a specific deployable; without this instruction, AI agents
  will not know where to find the authoritative deployable-level documentation
- An explicit instruction to read `.forge/products/<name>/` for PM product artifacts
  (requirements, strategy, roadmap, deployables cross-reference) when working on a PM
  product in a product-role repository (ADR-029)
- References to the rr-standards installation path, resolved using the detected
  installation mode (TR-5.1)
- The Forge hooks reference, pointing to `.claude/hooks/` in the repository

### TR-2.2: Merge Mode (Existing CLAUDE.md)

When a CLAUDE.md already exists, merge Forge content into it without modifying any
content outside the Forge-managed section:

- If a Forge-managed section (TR-2.3) already exists: replace its content with the
  current Forge template content, preserving all content outside the section markers
- If no Forge-managed section exists: append the Forge-managed section to the end
  of the file, preserving all existing content unchanged

Under no circumstances may merge mode overwrite, truncate, or reorder content that
exists outside the Forge-managed section markers.

### TR-2.3: Forge-Managed Section Markers

The Forge content within CLAUDE.md must be delimited by stable, machine-readable
markers:

```
<!-- forge:managed:start -->
... Forge-generated content ...
<!-- forge:managed:end -->
```

These markers enable `forge:init` (idempotent merge), `forge:update` (incremental
update), and diagnostic tooling to locate Forge content precisely. They must never
appear more than once in a file; `forge:init` must validate this and fail with a
diagnostic error if duplicate markers are detected.

---

## TR-3: Forge Directory Structure

### TR-3.1: Required Directories and Files

`forge:init` must create the following structure if not already present. Existing
files must not be overwritten. Which artifact directories are created depends on the
repository type selected during initialization (TR-1.4).

**Always created (all repository types):**

```
.forge/
├── README.md           # master work item registry (empty table at init)
├── version             # installation version record (TR-4) — key=value format
├── spec/
│   ├── README.md       # repo-level cross-deployable design artifacts index
│   └── arch-decisions/
│       └── README.md   # repo-level ADR index
└── efforts/
    └── README.md       # work item registry index (empty table at init)
```

**Created only for `repo_type=deployable` (source code repositories):**

```
.forge/
└── deployables/
    └── README.md       # deployable registry (empty table at init)
```

**Created only for `repo_type=product` (product repositories):**

```
.forge/
└── products/
    └── README.md       # product registry (empty table at init)
```

Individual deployable directories (`.forge/deployables/<name>/`) are created later by
`forge:deployable` during discovery — the deployable list is not known at
initialization time. PM product directories (`.forge/products/<name>/`) are created by
`forge:product-init`.

Capability directories (`.forge/deployables/<name>/capabilities/<capability-name>/`)
are not created by `forge:init`. Per ADR-028, capabilities are identified and created
during the discovery phase of the work items that deliver them, not at repository
initialization time.

The `.forge/efforts/README.md` master registry table must include a `Parent` column to
accommodate work items whose parent lives in a different repository (BR-12). Cross-repo
parent references use the provisional `repo:org/repo/id` format.

### TR-3.2: Settings and Hooks

`forge:init` must write the required hook registrations into `.claude/settings.json`
(see TR-5.2 and TR-6). Hook scripts are bundled within the plugin cache and are
referenced by path from `settings.json` — they are not copied into the project. The
plugin cache entry is the authoritative source for hook script content.

---

## TR-4: Version Record

### TR-4.1: Format and Location

`forge:init` must write `.forge/version` as a flat `key=value` file. JSON is not used
because this file is read primarily by shell hooks, and `key=value` eliminates any JSON
parsing dependency — `grep` and `cut` are sufficient, both POSIX standard with no
installation required.

```
forge_min_version=1.2.3
active_version=1.2.3
initialized_with=1.2.3
initialized_at=2026-03-15T10:00:00Z
last_migrated_with=
last_migrated_at=
repo_type=deployable
```

Fields:
- `forge_min_version` — the minimum Forge plugin version the project configuration
  is valid for. The version enforcement hook (TR-8) reads this with:
  `grep "^forge_min_version=" .forge/version | cut -d= -f2`
- `active_version` — the version currently pinned in `.claude-plugin/marketplace.json`.
  Maintained by `forge:init` and `forge:update`. Allows the enforcement hook to compare
  the active version against `forge_min_version` using only shell key=value reads,
  without JSON parsing of the plugin cache. Normally equals `forge_min_version`; a
  divergence indicates manual editing of `.forge/version`.
- `initialized_with` — the plugin version that ran `forge:init`; never changed after
  init.
- `initialized_at` — UTC ISO-8601 timestamp of the `forge:init` run; never changed
  after init.
- `last_migrated_with` / `last_migrated_at` — set by `forge:update` (TR-7); empty
  until the first migration is run.
- `repo_type` — the role of this repository in the Forge framework. `deployable`
  (default) for repositories that contain source code. `product` for PM-owned product
  repos. `project` for coordination-only repos per ADR-027.

### TR-4.2: Format Rules

- One field per line, `key=value` with no spaces around `=`
- Values are unquoted plain strings
- Empty fields are represented as `key=` (key present, value empty) — not omitted
- No comments, no sections, no nesting
- Shell hooks read fields with: `grep "^<key>=" .forge/version | cut -d= -f2`
- Skills update fields with: `sed -i "s/^<key>=.*/<key>=<value>/" .forge/version`

### TR-4.3: Version Source

The active Forge plugin version is read from `plugin.json` in the cache entry
corresponding to the ref/SHA pinned in `.claude-plugin/marketplace.json`. `forge:init`
reads this version to populate `forge_min_version` and `initialized_with`. If the
plugin cache entry for the pinned version is absent or its manifest cannot be read,
`forge:init` must fail with a diagnostic error; initialization must not proceed with
an unknown version value.

### TR-4.4: Migration Tracking

Each `forge:update` run must update `last_migrated_with`, `last_migrated_at`, and
`forge_min_version` in `.forge/version` before completing. This records the highest
plugin version the project configuration has been explicitly validated against.

---

## TR-5: Plugin Installation

### TR-5.1: Project Scope Only

`forge:init` always activates the Forge plugin at **project scope** by writing to
`.claude/settings.json` in the current repository. This file is committed to version
control, ensuring every contributor who clones the repository gets Forge activated
automatically without any manual install step.

User scope (`~/.claude/settings.json`) is not supported by `forge:init`. The plugin
must already be installed (via `/plugin install forge@rr-standards --scope project`
or equivalent) before `forge:init` is run.

### TR-5.2: Plugin Discovery

`forge:init` does not create or modify `.claude-plugin/marketplace.json`. That file
is managed exclusively by `forge:pin` (TR-10).

`forge:init` discovers the currently installed Forge plugin by searching the Claude
Code plugin cache. It prefers a `forge-local` installation (set up by `forge:pin`) if
present, falling back to the global `rr-standards` installation. The discovered plugin
path provides the hook script path, template files, and version for Steps 3–7.

If no Forge plugin is found in the cache, `forge:init` fails with a diagnostic
directing the engineer to run `/plugin install forge@rr-standards`.

### TR-5.3: forge_min_version Determination

`forge:init` reads `forge_min_version` from the existing `.claude-plugin/marketplace.json`
if the file is present (written by a prior `forge:pin` run). If the file is absent
(unpinned repository), `forge_min_version` is written as empty in `.forge/version`,
meaning no minimum version is enforced by the version hook.

This design allows `forge:pin` and `forge:init` to be run in any order. See the
[forge-pin capability](../../forge-pin/requirements/technical.md) for how it keeps
`forge_min_version` in sync when run after `forge:init`.

### TR-5.4: Plugin Path for CLAUDE.md

Standards content is bundled within the cached plugin directory. CLAUDE.md must
reference the plugin cache path for standards navigation. The exact path is resolved
from the cached SHA directory at init time and written into the CLAUDE.md
forge-managed section.

### TR-5.5: Hook Registration

`forge:init` writes exactly one entry to `.claude/settings.json` at project scope:
the `PreToolUse` hook registration pointing to the injection hook script in the plugin
cache (TR-6.3). It does not write `extraKnownMarketplaces` or `enabledPlugins` entries
— those are managed by `forge:pin` (TR-10). Existing settings content outside the
forge hook entry is preserved unchanged.

---

## TR-6: Generation Standards Injection Hook

### TR-6.1: Hook Purpose

The generation standards injection hook is a Claude Code `PreToolUse` hook that fires
before any Write or Edit operation and loads the applicable organizational coding
standard for the file being written. This is the mechanism by which standards
enforcement happens at generation time (BR-3) without requiring engineer invocation.

### TR-6.2: Hook Behavior

For each Write or Edit tool call, the hook must:

1. Inspect the target file path and determine its language from the file extension
2. Resolve the corresponding language guide path from the rr-standards installation
3. If a language guide exists: inject it as a system context message before the
   tool call proceeds
4. If no language guide exists for the detected language: proceed without injection
   and log a warning (do not block)
5. If the rr-standards path cannot be resolved: log a warning and proceed (degraded
   mode — do not block file writes)

### TR-6.3: Hook Installation

The hook script lives in the plugin cache at:
`~/.claude/plugins/cache/<marketplace>/forge/<sha>/hooks/pre-tool-use/inject-generation-standards.sh`

It is not copied into the project. `forge:init` registers it in `.claude/settings.json`
by absolute path (TR-3.2). The registered path must be updated when the plugin is
upgraded — see the forge-update capability.

### TR-6.4: Hook Testing

The hook is critical infrastructure — a hook that fails silently means standards are
not enforced at generation time and no engineer or tool will detect the gap. The hook
must have automated tests covering: correct language detection, correct standard path
resolution for each supported language, graceful degradation when rr-standards is
unreachable, and correct behavior when the file extension has no associated standard.

_TR-7 (forge:update) is documented in the forge-update capability._

---

## TR-8: Version Enforcement Hook

### TR-8.1: Hook Purpose and Installation

A Claude Code `SessionStart` hook that runs at the start of every session and checks
whether the developer's currently installed Forge plugin version satisfies the minimum
required by the current repository.

Unlike the generation standards injection hook (TR-6), the version enforcement hook is
installed at **user scope** as part of the global Forge plugin installation — not by
`forge:init`. It must run even in repositories where `forge:init` has not yet been run,
so it can detect uninitialized repositories. It is registered once when the developer
installs the Forge plugin and applies to all their Claude Code sessions.

### TR-8.2: Enforcement Behavior

At session start, the hook must:

1. Check whether `.forge/version` exists in the current repository
2. If absent: emit a non-blocking notice that this repository is not initialized;
   suggest running `forge:init` (do not block)
3. If present: read `forge_min_version` and `active_version`; compare them

Version comparison outcomes:

- **Active version ≥ `forge_min_version`**: proceed. If a newer version is available,
  emit a non-blocking notice suggesting `forge:update`.

- **Active version < `forge_min_version`**: block with a diagnostic error and instruct
  the engineer to run `forge:update`. If an active implementation task is in progress,
  emit a warning instead of a block and allow the session to proceed.

- **No `.forge/version`**: emit a non-blocking notice that this repository is not
  initialized and suggest running `forge:init`. Do not block.

### TR-8.3: Mandatory Update Deadline Enforcement

In addition to per-repository minimum version enforcement, the hook must enforce
organization-wide mandatory update deadlines defined in `VERSIONS.json` in the
marketplace repository. After `mandatoryAfter`, a developer still on an older major
version is blocked regardless of the repository's `forge_min_version`.

```json
{
  "v2": {
    "latestRelease": "2.1.0",
    "mandatoryAfter": "2026-05-01"
  }
}
```

If `VERSIONS.json` is unreachable, the hook must degrade gracefully: skip the deadline
check, emit a warning, and allow the session to proceed. The per-repository minimum
version check (TR-8.2) still runs using locally available data.

---

## TR-9: Compliance Exemption

### TR-9.1: Exemption Record

A repository may exempt itself from coding standards enforcement by creating
`.forge/compliance` as a key=value file:

```
coding_standards=exempt
reason=Repository deprecated — scheduled for decommission Q3 2026
```

Fields:
- `coding_standards` — `enforced` (default) or `exempt`. Controls coding standards
  enforcement only.
- `reason` — free text; required when `coding_standards=exempt`

When `.forge/compliance` is absent or `coding_standards` is absent, `enforced` is
assumed. `forge:init` does not create `.forge/compliance`.

### TR-9.2: Effect on Generation Standards Injection Hook

When `coding_standards=exempt`, the injection hook must skip standard injection and
exit 0 silently:

```bash
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  [ "$cs" = "exempt" ] && exit 0
fi
```

### TR-9.3: Effect on Version Enforcement Hook

When `coding_standards=exempt`, the version enforcement hook must not block the session
for version mismatch or mandatory deadline. It must emit a non-blocking notice
identifying the repository as coding-standards-exempt and allow the session to proceed.

### TR-9.4: Effect on forge:review

When `coding_standards=exempt`, `forge:review` must skip the coding standards check
(`rr-standards-plugin` category) and run all other checks normally.

### TR-9.5: What Exemption Does Not Affect

The following are unaffected by `coding_standards=exempt`:
- All non-coding-standards review checks (security, privacy, error handling, etc.)
- `forge:init` and `forge:update` — operate normally
- Work item tracking (`.forge/efforts/`) — unaffected
- Deployable artifact management (`.forge/deployables/`) — unaffected
- CLAUDE.md generation and maintenance — unaffected

_TR-10 (forge:pin) is documented in the [forge-pin capability](../../forge-pin/requirements/technical.md)._

---

## Constraints

### Technical Constraints

- All skills and hooks must run within Claude Code without requiring additional
  runtime dependencies beyond a standard development environment (shell, git, gh CLI)
- The version enforcement hook must not add perceptible latency to normal session
  starts when the repository is current; the check must complete in under 500ms
- CLAUDE.md merge operations must be implemented without sed or awk; file reads and
  writes are handled by Claude Code tools directly
- Hook scripts are pure POSIX shell with no external tool dependencies beyond `gh` CLI
- `.forge/version` uses `key=value` format (not JSON) specifically to make shell
  parsing trivial

### Process Constraints

- `forge:init` must never modify files outside of CLAUDE.md, `.forge/`, and
  `.claude/settings.json`; it must not touch source code, test files, or existing
  configuration files. `.claude-plugin/` is owned by `forge:pin`, not `forge:init`.
- `forge:init` must not install the Forge plugin or the `gh` CLI — both must already
  be present before `forge:init` is run
- The `gh` CLI must be installed and authenticated before using any Forge skill or
  hook that makes GitHub API calls; Forge does not configure `gh` authentication
- Every Forge release must be tagged in the rr-standards repository using semantic
  versioning (`v<major>.<minor>.<patch>`); untagged commits cannot be referenced by
  `--version` and are not valid pin targets
- Mandatory update deadlines are set by Productivity Engineering in `VERSIONS.json`
  in the marketplace and must be changeable without modifying the hook itself
- Active work protection in `forge:update` applies only to MAJOR version migrations;
  MINOR and PATCH migrations may be applied without active work checks

---

## TR-11: Brownfield Repository Analysis (Step 3c / Step 5c)

### TR-11.1: Trigger Conditions

Brownfield analysis is offered only when all of the following hold:
- create mode (`.forge/` absent before this run)
- `repo_type=deployable`
- `is_legacy=false`
- at least one source indicator file exists within 4 directory levels of the
  repository root (build manifests: `go.mod`, `pom.xml`, `build.gradle`,
  `build.gradle.kts`, `package.json`, `setup.py`, `pyproject.toml`, `Cargo.toml`;
  or a `Dockerfile`; or source files with extensions `.go`, `.java`, `.kt`, `.py`,
  `.ts`, `.swift`)

If no source indicator is found, `forge:init` treats the repository as greenfield
and skips Steps 3c and 5c entirely — no prompt is shown.

### TR-11.2: Engineer Consent

`forge:init` must obtain explicit opt-in before performing any codebase analysis or
creating any files in `.forge/deployables/`. The default response is `n` (skip). An
engineer who presses Enter without typing must not trigger the analysis.

### TR-11.3: Deployable Identification

The analysis must identify deployable units using build manifest files as primary
signals. Each distinct build manifest at depth ≤ 3 from the repository root is treated
as a deployable root candidate. Deployable names are derived from:

1. The module/artifact name declared in the build file (e.g., `module` field in
   `go.mod`, `<artifactId>` in Maven `pom.xml`, `name` field in `package.json`)
2. The containing directory name when no explicit name is declared

All derived names must be normalized to `kebab-case` (lowercase, spaces and underscores
replaced with hyphens).

### TR-11.4: Engineer Confirmation of Deployables

Before creating any scaffolding files, `forge:init` must present the identified
deployable list to the engineer and wait for one of three responses: accept, edit, or
skip. This gives engineers the opportunity to correct misidentifications before
scaffolding is written. If the engineer chooses skip at this point, no scaffolding is
written and the step exits cleanly.

### TR-11.5: Orchestrator/Worker Split (per ADR-015)

`forge:init` is classified as `agent-type: orchestrator`. Capability identification
and scaffold file creation run as **worker sub-agents** spawned via the Task tool —
one worker per confirmed deployable. Workers run concurrently; the orchestrator does
not wait for one to finish before spawning the next.

This split is required because large monorepos may have 50 or more deployables, each
with many source packages and route groups. Reading and analyzing that volume of source
code in the orchestrator's context window would cause context pollution, quality
degradation, and excessive session length. Each worker receives a narrow context packet
(deployable root path, deployable name, output path) and discards its context window
when it completes.

The orchestrator's Phase 1 (deployable discovery and engineer confirmation) must use
only Bash and Glob — it must not read source file contents. Name extraction from build
manifests (e.g., `go.mod`, `pom.xml`, `package.json`) is the only file read permitted
in the orchestrator during this step.

### TR-11.6: Worker Context Packet

Each worker must receive a context packet containing:
- `repo_root` — absolute path of the repository root
- `deployable_name` — kebab-case deployable name
- `deployable_root` — absolute path of the deployable's root directory
- `build_file` — absolute path of the detected build manifest (may be empty)
- `output_base` — absolute path of the target `.forge/deployables/<name>/` directory

Workers must not read files outside `deployable_root` and must not write files outside
`output_base`.

### TR-11.7: Worker Analysis Scope

Each worker reads source files within the deployable root to extract:

- **Dependencies and stack** — from the build manifest: language, framework, all
  declared dependencies, infrastructure dependencies (databases, message brokers,
  cloud SDKs, gRPC)
- **Entry points** — `main.*`, `app.*`, `server.*`, `cmd/*/main.*` at depth ≤ 3:
  what port/protocol is served, what top-level components are wired up
- **Contracts** — all contract surfaces within 3 levels of the deployable root:
  - *REST* — route/handler/controller files and OpenAPI/Swagger specs: HTTP verb,
    path, handler name, request/response type names from handler signatures
  - *gRPC* — proto files: service name, RPC method names, request/response message types
  - *GraphQL* — schema files and gql-tagged TypeScript: Query/Mutation/Subscription
    operation names and return types
  - *Messages* — Kafka/RabbitMQ/SQS/SNS/EventBridge consumer and producer registrations:
    topic/queue name, direction (publishes/subscribes), event type name
  - *In-memory interfaces* — interface/abstract type definitions in service or port
    layers: interface name and method signatures
- **Data models** — entity/model/schema files: entity names and key fields
- **Configuration** — config files at depth ≤ 2: configurable parameters and defaults
- **Test posture** — test directory structure and file count only (no content reads)
- **Capabilities** — derived from package directories, route group prefixes, and
  framework annotations; limited to 10 candidates per deployable

Workers read only what is necessary for extraction. They do not read every source file.

### TR-11.8: Scaffolding Content (Worker)

Each worker must produce populated content derived from what was read — not blank stubs.
All AI-inferred content must be wrapped in a visible warning marker
(`> **⚠ AI-inferred — review before use**`) so engineers know what was generated
vs. what they wrote. Sections that cannot be inferred from code must use a stub marker
(`> **✏ Needs input**`) describing what the engineer must supply. Sections with no
inferred content and no actionable prompt are omitted entirely rather than left blank.

**Deployable `spec/README.md`** must contain:
- *Tech Stack* — language, framework, build tool, databases/storage, message broker,
  external service dependencies, and the protocol/port the deployable serves; all
  inferred from the build manifest, config files, and entry points
- *Components* — table of significant packages/modules with their paths and inferred
  responsibilities
- *High-Level Flows* — 1–3 representative flows through the system, tracing from
  entry point through component layers to persistence or outbound calls, derived from
  the entry point wiring and route/handler structure

**Capability `spec/README.md`** must contain:
- *Contracts* — one subsection per contract surface present in this capability:
  REST (endpoint table with request/response types), gRPC (RPC table), GraphQL
  (operation table), Messages (topic/direction/event-type table), In-memory interfaces
  (interface and method signature table). Omit subsections with no detected content.
- *Data Model* — entities read or written by this capability with key fields
- *Component Structure* — packages and files that implement this capability
- *Flows* — traced flows from contract surface through component layers to output
- *Algorithms* — `✏ Needs input` stub only; omitted unless a non-trivial algorithm
  is evident from file/function names

Files written per deployable: `README.md`, `requirements/business.md`,
`requirements/technical.md`, `spec/README.md`, `spec/arch-decisions/README.md`,
`runbook/README.md`, `security/README.md`, `test/README.md`.

Files written per capability: `README.md`, `requirements/business.md`,
`requirements/technical.md`, `spec/README.md`.

Workers must return a structured JSON result:
`{deployable, capabilities: [...], files_created, files_skipped}`.

### TR-11.9: Worker Failure Isolation

If a worker fails (error exit or non-JSON result), the orchestrator must record that
deployable as failed and continue collecting results from other workers — a single
failing worker must not abort the scaffolding run. Failed deployables are listed in
the Step 9 summary so the engineer knows which ones need manual scaffolding.

### TR-11.10: Idempotency

Brownfield analysis is only offered in create mode. Merge mode never triggers Steps
3c or 5c. Any scaffold file that already exists must be left unchanged (same skip
behaviour as other Step 5 files).

### TR-11.11: Scope Constraint

Workers must not read files outside their assigned `deployable_root` and must not
write files outside their assigned `output_base`. Workers must not make network calls.
The orchestrator must not read source file contents during deployable discovery
(Phase 1) — source reading is exclusively a worker responsibility.

---

## TR-12: Atlassian MCP Credential Check

### TR-12.1: Purpose

The Forge plugin bundles `sooperset/mcp-atlassian` as a declared MCP server (per
ADR-030, `plugins/forge/.mcp.json`). The server requires three environment variables
to authenticate with Confluence. `forge:init` must check whether these are set and
surface a setup message when they are not, so engineers encounter the requirement
at setup time rather than mid-task.

### TR-12.2: Check Behavior

At the end of the `forge:init` summary step (Step 8 / the final output), after all
file writes and hook registrations are complete:

1. Check whether each of the following environment variables is set and non-empty:
   - `CONFLUENCE_URL`
   - `CONFLUENCE_USERNAME`
   - `CONFLUENCE_API_TOKEN`

2. If **all three are set**: print one line in the summary:
   ```
   ✓ Atlassian MCP (Confluence): credentials configured
   ```

3. If **any are missing**: print a setup block:
   ```
   ⚠ Atlassian MCP (Confluence): credentials not configured
     The Forge plugin includes the Atlassian MCP (sooperset/mcp-atlassian), which
     enables Forge discovery skills to read Confluence pages directly.

     Add the following to your shell profile (~/.zshrc or ~/.bashrc):

       export CONFLUENCE_URL=https://your-org.atlassian.net/wiki
       export CONFLUENCE_USERNAME=your-email@example.com
       export CONFLUENCE_API_TOKEN=<token from https://id.atlassian.com/manage-profile/security/api-tokens>

     You can skip this if your team does not use Confluence for PM documents.
   ```

### TR-12.3: Constraints

- This check is **advisory only** — missing credentials must not prevent `forge:init`
  from completing or block any other setup step.
- The check runs in the orchestrating session using shell environment reads; no
  subprocess or external call is required.
- The check must not attempt to validate or test the credentials — only check presence.
- The message must not appear more than once even if `forge:init` is run in merge mode
  on an already-initialized repository.

---

### Open Questions

3. **Lag period default values** — what are the Productivity Engineering-defined
   maximum lag periods for breaking and non-breaking Forge updates?
   - **Impact:** TR-8.2 enforcement behavior; determines how aggressively version
     enforcement blocks sessions
   - **Decision needed by:** design phase; requires Productivity Engineering input

6. **Cross-repo `parentId` reference format stability** — the provisional
   `repo:org/repo/work-item-id` format for cross-repo work item references in
   `.state.json` has unresolved identity stability and resolution concerns.
   - **Impact:** `.state.json` schema migrations (forge-update); any skill that reads
     or writes `parentId` or `effortRef` for cross-repo work items
   - **Decision needed by:** design phase for the Multi-Repository Project Support epic

7. **Project repository discovery** — no specified mechanism for an engineer in a
   product repository to navigate upstream to a effort repository.
   - **Impact:** `forge:init` behavior in product repositories participating in
     cross-repo projects; CLAUDE.md template content for product repositories
   - **Decision needed by:** design phase for the Multi-Repository Project Support epic
