# Technical Requirements — forge-help

Parent business requirements: [requirements/business.md](business.md)

---

## TR-1: Discovery Must Use AGENTS.md Files as the Navigation Layer

*Traces to: BR-1, BR-2, BR-3*

The skill must navigate the plugin's directory structure using AGENTS.md files as its
discovery mechanism. It must not hardcode file paths, skill lists, hook lists, or
standards lists into the skill itself. Every catalog and answer must be derived from
reading AGENTS.md files at the appropriate directory level, then reading the referenced
artifacts.

---

## TR-2: Catalog Mode Is Triggered by No-Argument Invocation

*Traces to: BR-2*

When invoked with no argument, the skill enters catalog mode. In catalog mode it must:

1. Read `plugins/forge/skills/AGENTS.md` to discover implemented skills (those with a
   SKILL.md) — skip stubs
2. Read `plugins/forge/hooks/hooks.json` and the corresponding hook scripts to derive a
   one-liner description of each active hook
3. Read `plugins/forge/standards/AGENTS.md` to enumerate available standards categories
4. Read `plugins/forge/languages/AGENTS.md` to enumerate available language guides
5. Present the result as a structured catalog grouped by: workflow phase (for skills),
   hook event type (for hooks), and domain (for standards and language guides)

---

## TR-3: Q&A Mode Is Triggered by Any Argument

*Traces to: BR-1, BR-3, BR-4*

When invoked with any argument (a question or topic), the skill enters Q&A mode. It must:

1. Parse the question to identify which component areas it spans (skills, hooks,
   standards, language guides, workflow phases)
2. Navigate AGENTS.md files in each relevant area to locate the specific artifacts
   that contain the answer
3. Read those artifacts in full
4. Synthesize a complete answer in plain terms that fully addresses the question
5. Never expose internal plugin file paths in the answer

---

## TR-4: Hook Answers Must Be Derived From Script Content

*Traces to: BR-1*

When a question involves a hook, the skill must read the hook's shell script and explain
its behavior in plain terms. The answer must describe what the hook does and when it
fires — not show the script itself or its path to the engineer.

---

## TR-5: Stub Filtering Is Required in Both Modes

*Traces to: BR-5*

The skill must actively distinguish implemented skills (directories containing a SKILL.md)
from stubs (directories containing only `.gitkeep`) by checking for the presence of
SKILL.md before including a skill in any output. This check must be performed at
execution time, not assumed from a static list.

If an engineer explicitly asks about a skill by name that is a stub, the skill must
respond: "forge:`<name>` is not yet implemented." and optionally describe its intended
purpose if that can be derived from the AGENTS.md description.

---

## TR-6: Effort State Is Out of Scope

*Traces to: BR-4*

The skill must not read `.forge/EFFORT`, `.forge/efforts/`, or any `.state.json` file.
It operates solely on the plugin's static documentation. When an engineer asks a question
that requires knowing their specific effort state, the skill must:

1. Answer the general/conceptual part of the question from plugin documentation
2. Recommend `forge:status` for the effort-specific state

---

## TR-7: The Skill Runs as an Orchestrator in the Main Session

*Traces to: BR-1, BR-2, BR-3*

`forge:help` runs in the main engineer session (agent-type: orchestrator). It does not
spawn sub-agents. All file reads and synthesis happen inline. The skill must not pollute
the engineer's context with excessive raw file content — it reads, synthesizes, and
presents a clean answer.
