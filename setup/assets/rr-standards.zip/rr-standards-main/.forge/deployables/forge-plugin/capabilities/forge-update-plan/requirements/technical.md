# Technical Requirements: forge:update-plan

## Traceability

| TR | BRs |
|----|-----|
| TR-1 | BR-1, BR-2 |
| TR-2 | BR-2 |
| TR-3 | BR-1, BR-2 |
| TR-4 | BR-1 |
| TR-5 | BR-3 |
| TR-6 | BR-4 |
| TR-7 | BR-1 |
| TR-8 | BR-1 |

## Technical Requirements

### TR-1: Resolve effort context and target task

Read `plan/tasks.md` from the resolved effort directory. Identify the target task using
the following priority order:

1. Use the TASK-NNN argument if provided by the engineer.
2. Otherwise, extract a TASK-NNN reference from the most recent commit message or git
   notes (`git log -1 --format="%s %N"`).
3. If no TASK-NNN can be determined, display the list of remaining tasks and prompt the
   engineer to select.

### TR-2: Read the commit SHA

Read the full SHA of the most recent commit using:
```
git log -1 --format="%H"
```

This SHA is the implementation evidence to be recorded inline.

### TR-3: Update plan/tasks.md

Find the line in `plan/tasks.md` corresponding to the target task. Change the checkbox
from `- [ ]` to `- [x]` and append ` — <sha>` to the end of the line (after the closing
parenthesis if one exists, or at the end of the line).

Example result:
```
- [x] [auto][wave:1] Author `forge:update-plan` SKILL.md (TASK-001) — a3f9b12c...
```

### TR-4: Update .state.json remainingTasks and completedTasks

In the `phases.implementation` object of `.state.json`:
- Remove TASK-NNN from `remainingTasks`.
- Append `{"taskId": "TASK-NNN", "sha": "<full-sha>"}` to `completedTasks`.

### TR-5: Set jira.syncStatus = "pending"

Ensure the `jira` key exists at the top level of `.state.json`. Set
`jira.syncStatus = "pending"`. If the `jira` key is absent, create it:
```json
"jira": { "syncStatus": "pending" }
```

### TR-6: Fallback to interactive task selection

If the TASK-NNN cannot be determined from the argument or from the recent commit (Steps
1–2 of TR-1), display the task list from `remainingTasks` and prompt the engineer to
select the correct task ID before proceeding.

### TR-7: Create a follow-up commit

After updating both files (`plan/tasks.md` and `.state.json`), stage and commit them:
```
chore(<effort-id>): mark <TASK-NNN> complete (<sha-short>)
```
where `<sha-short>` is the first 7 characters of the SHA recorded in TR-2.

### TR-8: Guard against marking already-completed tasks

Before making any changes, verify that TASK-NNN appears in `remainingTasks` in
`.state.json`. If it is already in `completedTasks`, stop immediately with:
```
Task TASK-NNN is already complete.
```
Do not modify either file.
