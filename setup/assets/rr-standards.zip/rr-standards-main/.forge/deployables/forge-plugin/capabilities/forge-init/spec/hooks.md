# forge-init Hooks Design

Design for the two shell hooks delivered by the forge-init epic. Both hooks are pure
POSIX shell with no external tool dependencies beyond the `gh` CLI prerequisite.

Implementation:
- `plugins/forge/hooks/pre-tool-use/inject-generation-standards.sh`
- `plugins/forge/hooks/session-start/forge-version-check.sh`

---

## Hook 1: Generation Standards Injection

**File:** `hooks/pre-tool-use/inject-generation-standards.sh`
(in plugin cache at `~/.claude/plugins/cache/<marketplace-dir>/forge/<sha>/`)

**Trigger:** `PreToolUse` — matcher `Write|Edit`

**Scope:** Project — registered in `.claude/settings.json` by absolute path to the
hook within the pinned plugin cache entry. Each project's hook path points to its
pinned version's hook script, ensuring the correct version's standards are always
injected.

**Purpose:** Before any Write or Edit tool call, detect the target file's language,
find the corresponding language guide in the plugin cache, and output it to stdout so
Claude Code injects it into the model's context. Standards are enforced at generation
time without engineer invocation (BR-3).

### Compliance Exemption Check

Before any other logic, the hook checks whether the repository is in compliance-exempt
mode. If exempt, exit 0 immediately — no injection, no warning, no output:

```bash
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  [ "$cs" = "exempt" ] && exit 0
fi
```

### Language Detection

The hook determines language from the file extension:

| Extension(s) | Language |
|-------------|---------|
| `.go` | go |
| `.java` | java |
| `.kt`, `.kts` | kotlin |
| `.swift` | swift |
| `.ts`, `.tsx` | typescript |
| `.js`, `.jsx`, `.mjs`, `.cjs` | javascript |
| `.py` | python |
| `.rb` | ruby |
| `.rs` | rust |
| _(other)_ | no injection, silent exit 0 |

### Standard Path Resolution

The hook resolves its own plugin root via `BASH_SOURCE[0]`:

```bash
# Hook lives at: <plugin_root>/hooks/pre-tool-use/inject-generation-standards.sh
# Language guides: <plugin_root>/languages/<lang>/guide.md
PLUGIN_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
LANG_GUIDE="$PLUGIN_ROOT/languages/$language/guide.md"
```

### Injection

If a language guide is found, output its content to stdout. Claude Code reads the
hook's stdout and injects it as additional context before the tool call proceeds.
The hook exits 0 in all cases — it never blocks a Write or Edit.

### Degraded Mode

| Condition | Behavior |
|-----------|----------|
| No file path in environment | Exit 0 silently |
| File extension not in language table | Exit 0 silently |
| Language detected, guide file absent | Warning to stderr; exit 0 |
| Plugin root cannot be resolved | Warning to stderr; exit 0 |
| `.forge/compliance` is exempt | Exit 0 silently (no warning) |

### Complete Script

```bash
#!/usr/bin/env sh
set -e

PLUGIN_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"

# Check for compliance exemption
if [ -f ".forge/compliance" ]; then
  cs=$(grep "^coding_standards=" .forge/compliance | cut -d= -f2)
  [ "$cs" = "exempt" ] && exit 0
fi

# Get target file path from Claude Code hook input
FILE_PATH="${CLAUDE_TOOL_INPUT_FILE_PATH:-${CLAUDE_TOOL_INPUT_PATH:-}}"
if [ -z "$FILE_PATH" ]; then
  exit 0
fi

# Detect language from extension
ext="${FILE_PATH##*.}"
language=""
case "$ext" in
  go)             language="go" ;;
  java)           language="java" ;;
  kt|kts)         language="kotlin" ;;
  swift)          language="swift" ;;
  ts|tsx)         language="typescript" ;;
  js|jsx|mjs|cjs) language="javascript" ;;
  py)             language="python" ;;
  rb)             language="ruby" ;;
  rs)             language="rust" ;;
esac

if [ -z "$language" ]; then
  exit 0
fi

LANG_GUIDE="$PLUGIN_ROOT/languages/$language/guide.md"

if [ ! -f "$LANG_GUIDE" ]; then
  printf "forge: no language guide for .%s files\n" "$ext" >&2
  exit 0
fi

cat "$LANG_GUIDE"
exit 0
```

---

## Hook 2: Version Enforcement

**File:** `hooks/session-start/forge-version-check.sh`
(in plugin cache — but registered at **user scope**)

**Trigger:** `SessionStart`

**Scope:** User (global) — registered in `~/.claude/settings.json` when the developer
installs the Forge plugin. Runs at the start of every Claude Code session regardless
of which repository is open.

**Purpose:** Enforce that the repository is initialized, that the pinned plugin version
meets the project minimum, and that the mandatory organizational upgrade deadline has
not passed. Must complete in under 500ms.

### Algorithm

```
1. .forge/version absent → print notice, exit 0 (non-blocking)

2. .forge/compliance present with coding_standards=exempt
   → print notice, exit 0 (non-blocking)

3. Read forge_min_version and active_version from .forge/version
   Malformed (either empty) → warning, exit 0

4. Compare active_version vs forge_min_version
   active < min, no active impl task → error, exit 1 (blocking)
   active < min, active impl task    → warning, exit 0 (non-blocking)

5. Extract major version from forge_min_version

6. Fetch VERSIONS.json via gh api (1-second timeout)
   Unreachable → warning about skipped deadline check, exit 0

7. Extract mandatoryAfter for this major version
   Major not listed in VERSIONS.json → exit 0 (no deadline)

8. Compare today vs mandatoryAfter
   today >= mandatoryAfter         → error, exit 1 (blocking)
   today within 30-day window      → warning, exit 0
   today before warning window     → exit 0 silently
```

### Semver Comparison

```bash
version_gte() {
  local a b IFS=.
  local v1=($1) v2=($2)
  for i in 0 1 2; do
    a="${v1[$i]:-0}"; b="${v2[$i]:-0}"
    [ "$a" -gt "$b" ] && return 0
    [ "$a" -lt "$b" ] && return 1
  done
  return 0  # equal
}
```

### Date Comparison

ISO 8601 dates (YYYY-MM-DD) compare correctly as strings due to their zero-padded
format. Warning window uses GNU/BSD date compatibility:

```bash
today=$(date -u +%Y-%m-%d)
warning_date=$(date -u -d "$mandatory_after -30 days" +%Y-%m-%d 2>/dev/null \
  || date -u -v-30d -j -f "%Y-%m-%d" "$mandatory_after" +%Y-%m-%d 2>/dev/null || echo "")
```

### VERSIONS.json Fetch

GitHub Contents API returns base64-encoded file content. Fetched via `gh api`
(authenticated, private repo safe); parsed with `base64 -d` and `sed`:

```bash
encoded=$(gh api \
  "repos/rewards-guilds/rr-standards/contents/VERSIONS.json" \
  --template '{{.content}}' 2>/dev/null)
versions_json=$(printf '%s' "$encoded" | tr -d '\n' | base64 -d 2>/dev/null)
mandatory_after=$(printf '%s' "$versions_json" | \
  sed -n "/\"v${major}\"/,/}/{s/.*\"mandatoryAfter\": *\"\([^\"]*\)\".*/\1/p;}" | \
  head -1)
```

### Active Work Item Check

Before blocking for `active < min`, the hook checks for active implementation tasks:

```bash
has_active_impl() {
  for state_file in .forge/efforts/*/.state.json; do
    [ -f "$state_file" ] || continue
    phase=$(sed -n 's/.*"currentPhase": *"\([^"]*\)".*/\1/p' "$state_file" | head -1)
    impl_status=$(sed -n '/"implementation"/,/}/{s/.*"status": *"\([^"]*\)".*/\1/p}' \
      "$state_file" | head -1)
    if [ "$phase" = "implementation" ] && [ "$impl_status" = "in_progress" ]; then
      return 0
    fi
  done
  return 1
}
```

### Output Messages

All user-facing messages go to stderr. Exit code determines blocking:

| Condition | Message | Exit |
|-----------|---------|------|
| Not initialized | `forge: this repository is not initialized. Run forge:init.` | 0 |
| Compliance exempt | `forge: this repository is coding-standards-exempt.` | 0 |
| Version malformed | `forge: WARNING — .forge/version is malformed. Run forge:init.` | 0 |
| active < min, active task | `forge: WARNING — active version X < forge_min_version Y. Run forge:update after this task.` | 0 |
| active < min, no active task | `forge: ERROR — active version X < forge_min_version Y. Run forge:update.` | 1 |
| Deadline passed | `forge: ERROR — forge vN support ended on DATE. Run forge:update.` | 1 |
| Approaching deadline | `forge: WARNING — forge vN migration required by DATE. Run forge:update soon.` | 0 |
| Network unavailable | `forge: WARNING — cannot verify upgrade deadline (gh unavailable or not authenticated).` | 0 |

---

## Testing Requirements

The injection hook requires automated tests covering:

| Test case | Expected behaviour |
|-----------|-------------------|
| `.go` file | Injects Go language guide to stdout |
| `.java` file | Injects Java language guide to stdout |
| `.ts` file | Injects TypeScript language guide to stdout |
| `.py` file | Injects Python language guide to stdout |
| `.md` file | No injection; exits 0 silently |
| File with no extension | No injection; exits 0 silently |
| Language guide file absent | Warning to stderr; exits 0 |
| Plugin root unresolvable | Warning to stderr; exits 0 |
| No file path in environment | No injection; exits 0 silently |
| `.forge/compliance` with `coding_standards=exempt` | No injection; exits 0 silently |

The enforcement hook requires tests covering:

| Test case | Expected behaviour |
|-----------|-------------------|
| No `.forge/version` | Notice to stderr; exits 0 |
| `active_version < forge_min_version`, no active task | Error to stderr; exits 1 |
| `active_version < forge_min_version`, active impl task | Warning to stderr; exits 0 |
| `forge_min_version` malformed | Warning to stderr; exits 0 |
| `mandatoryAfter` passed | Error to stderr; exits 1 |
| Within 30-day warning window | Warning to stderr; exits 0 |
| Before warning window | Exits 0 silently |
| `VERSIONS.json` unreachable | Warning to stderr; exits 0 |
| Major version not in `VERSIONS.json` | Exits 0 silently |
| `.forge/compliance` with `coding_standards=exempt` | Notice to stderr; exits 0 |
