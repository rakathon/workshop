# Design Spec — forge-ui-design

Parent deployable: [forge-plugin](../../requirements/business.md)

<!-- graduated-from: design-system-integration at 2026-04-25T23:10:46Z -->

---

## Purpose

`forge:ui-design` conversationally authors a UI spec (`ui-spec.md`) by walking the
engineer through goal, mode, scope, data, and mode-specific details — then writes the
completed spec to disk ready for `forge:ui` to consume.

**Agent type:** Orchestrator

**Skill location:** `plugins/forge/skills/ui-design/SKILL.md`

---

## Trigger Conditions

Use this skill whenever someone wants to plan or specify a UI before building it:
"let's design the UI", "help me spec out this page", "I want to think through what to
build", "write a UI spec for X", "plan the UI for this feature", "what should this page
look like?", or any time someone is at the beginning of UI work and hasn't described
what to build yet. Also trigger when someone says "I want to explore a few approaches"
or "I need to show some data from the API" or "I have a Figma design to implement" —
these are the three modes this skill supports.

Run `forge:ui-design` before `forge:ui` when the scope is ambiguous or the work is
non-trivial.

---

## Three Modes

| Mode | Description | Trigger signal |
|------|-------------|----------------|
| Explore | Rapid iteration on ideas before any production commitment | "I want to explore", "prototype this" |
| API-driven | Build UI from API data shape | "I need to show data from the API" |
| Figma handoff | Implement a finalized Figma design | "I have a Figma design", "here is the Figma link" |

---

## Skill Flow

1. Ask about goal — what the user wants to accomplish with this UI
2. Identify mode — explore, API-driven, or Figma handoff
3. Walk through scope — which pages or sections are in scope
4. Gather data — what data the UI depends on (for API-driven mode)
5. Mode-specific details — for Figma mode: link and annotations; for explore mode: constraints and variants
6. Write `ui-spec.md` to disk using `ui-spec-template.md` as the structural contract

---

## Output Artifact

`ui-spec.md` — a structured Markdown file written to the working directory or effort
spec directory. This file is the machine-readable input to `forge:ui` production mode
and serves as the handoff record from design to implementation.

---

## Deferred Scope

### Prototype Promotion Trigger

The explicit "promote this prototype" step — triggered when the engineer signals they
want to move an exploration prototype into production — is deferred to a follow-on
effort. The `ui-spec.md` template covers the structural handoff requirement for this
effort; the promotion workflow itself is not yet implemented in the skill.
