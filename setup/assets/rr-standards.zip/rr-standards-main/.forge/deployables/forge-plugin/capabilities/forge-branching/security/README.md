# Security — forge-branching

## Trust Boundary

`enforce-branch-policy.sh` runs within the Claude Code hook execution environment on
every Bash tool call. `pre-push.sh` runs within the git hook environment on every push.
Neither hook introduces network-accessible services or stores credentials.

Primary security surfaces:

- **Hook scripts** — executed frequently on developer machines; must not introduce code
  execution vectors, credential access, or exfiltration paths
- **Audit log** — `.forge/audit/<timestamp>.json` written to the repository working
  tree; must not capture sensitive data from the environment
- **Admin override signals** — `FORGE_ALLOW_MAIN_COMMIT` and `FORGE_ADMIN_OP`
  environment variables; must not be persisted or logged beyond the audit record

## Hook Script Security

Both hook scripts are reviewed by the `hook-reviewer` agent in `rr-standards:review`
on every PR that modifies them. The four check IDs are:

| Check ID | What it detects |
|----------|----------------|
| `network-exfiltration` | `curl`, `wget`, or outbound connections to non-approved endpoints |
| `credential-access` | Reads of `~/.ssh/`, `~/.aws/`, `~/.config/gcloud/`, or `$HOME` credential paths |
| `file-exfiltration` | Reads outside `.forge/`, the repository working tree, and the plugin cache |
| `obfuscated-execution` | Eval of dynamic strings, pipes into shell, encoded payloads |

`enforce-branch-policy.sh` reads:
- `CLAUDE_TOOL_NAME` and `CLAUDE_TOOL_INPUT` (environment variables set by Claude Code)
- `FORGE_ALLOW_MAIN_COMMIT` and `FORGE_ADMIN_OP` (environment variables)
- Output of `git branch --show-current` and `git config init.defaultBranch`
- `.forge/efforts/README.md` (local repository file, effort ID detection only)

It writes only to `.forge/audit/` (audit log on override). It makes no network calls.

`pre-push.sh` reads stdin (git-provided ref data). It makes no network calls and reads
no files outside the hook's own execution context.

## Audit Log Security

The audit log captures only: operation name (`"direct_commit_override"`), the
`FORGE_ADMIN_OP` value or a static string, the branch name, and the timestamp. It
does not capture command content, file paths, or environment variables beyond the
named override signals.

`FORGE_ADMIN_OP` is set by Forge skills to a short reason string (e.g.,
`"forge:init"`, `"forge:update"`). It is not an arbitrary user-supplied string injected
into the audit log — Forge skills set it to known static values. If an engineer sets
it manually to an unexpected value, that value is written to the audit log as-is, which
is appropriate for an audit record.

## Override Signal Persistence

The `FORGE_ALLOW_MAIN_COMMIT` and `FORGE_ADMIN_OP` environment variables must never
be written to any file tracked by git. The hook reads them and exits — it does not
write them anywhere. The responsibility for not persisting these variables lies with
the engineer (for `FORGE_ALLOW_MAIN_COMMIT`) and with Forge skills (for
`FORGE_ADMIN_OP`, which they `unset` after the operation completes).

## Review Requirements

All PRs that modify hook scripts (`plugins/forge/hooks/**/*.sh`) trigger the
`hook-reviewer` agent in `rr-standards:review`. All PRs that modify the audit log
format trigger the `security-reviewer` agent.
