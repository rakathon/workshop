# Technical Requirements — forge-cross-repo

Parent deployable: [forge-plugin](../../requirements/technical.md)
Program TRs addressed: TR-4, TR-5, TR-6, TR-14

---

## TR-1: forge:project Skill

### TR-1.1: Command Surface

`forge:project` accepts two required arguments:

- `--coordination-repo <org/repo>` — GitHub repository identifier for the coordination
  repository (e.g., `acme/platform-coordination`)
- `--effort-id <id>` — The effort ID in the coordination repository whose artifacts
  should be projected to this local sub-effort

No positional arguments are accepted. Both flags are required; the skill must fail with
a clear usage message if either is absent.

### TR-1.2: Artifact Fetching via GitHub API

Coordination artifacts are fetched using the GitHub API, not via `git clone`. For each
artifact to be projected, the skill calls:

```
gh api repos/<org/repo>/contents/<path>
```

The response includes a `content` field (base64-encoded) and a `sha` field (the blob
SHA for the file at the latest commit on the default branch). The skill decodes the
base64 content and records the blob SHA for each projection.

The skill must not require the engineer to have `git clone` access to the coordination
repository. Read access via the GitHub API (authenticated via `gh` CLI) is sufficient.

### TR-1.3: Projection Scoping

Before materializing artifacts, the skill reads the coordination effort's plan to
identify which sections are relevant to this deployable. Scoping determines:

- For requirements: the subset of business and technical requirements that apply to
  this deployable, not the full coordination-level requirements document
- For the plan: the entries from the coordination plan that are assigned to this
  deployable, not the full cross-repo plan

Scoping is performed by reading the coordination plan's deployable-assignment
annotations (TR-7 of the forge-workflow spec) and extracting the entries where this
deployable is listed as responsible. If the coordination plan does not have per-deployable
sections, the full plan is projected with a note that manual scoping may be needed.

### TR-1.4: Provenance Header Format

Each projected file must begin with a provenance metadata header in exactly this format:

```
<!-- forge:projection
  source_repo: <org/repo>
  source_effort: <effort-id>
  source_file: <path-in-coordination-repo>
  source_commit: <blob-sha>
  projected_at: <ISO-8601 timestamp>
-->
```

All five fields are required. A projected file missing any of the five fields is
considered malformed. The header must appear as the first content in the file, before
any markdown heading or body text.

### TR-1.5: Local Sub-Effort Scaffolding

After materializing projections, the skill creates the local sub-effort directory
under `.forge/efforts/<local-effort-id>/` with a `.state.json` file containing the
`coordinationRef` structure:

```json
{
  "coordinationRef": {
    "branch": "main",
    "commitSha": "<sha-of-coordination-repo-head-at-projection-time>",
    "effortId": "<coordination-effort-id>",
    "projectedAt": "<ISO-8601>",
    "projections": [
      {
        "local": ".forge/efforts/<local-effort-id>/requirements/projected-business.md",
        "source": ".forge/efforts/<coordination-effort-id>/requirements/business.md",
        "sourceSha": "<blob-sha>"
      }
    ],
    "repo": "<org/coordination-repo>"
  }
}
```

The `coordinationRef` fields must be populated exactly as specified:
- `repo` — the GitHub identifier of the coordination repository
- `effortId` — the effort ID in the coordination repository
- `branch` — the branch from which artifacts were projected (default: `main`)
- `commitSha` — the SHA of the coordination repository's HEAD at projection time
- `projectedAt` — ISO-8601 UTC timestamp of when the projection was taken
- `projections` — array of projection entries, one per projected file

Each projection entry must include:
- `source` — the path of the source file in the coordination repository
- `local` — the path of the materialized file in the local repository
- `sourceSha` — the blob SHA of the source file at projection time (used for staleness detection)

### TR-1.6: Registry Update

The skill must add the new local sub-effort to `.forge/efforts/README.md` as a new table row.
The entry must include the `coordinationRef.repo` as the parent reference, using the
provisional format `repo:<org/repo>/<effort-id>`.

### TR-1.7: Offline Behavior

If the GitHub API call fails for any reason — network unavailable, authentication
failure, repository not found — the skill must fail immediately with a clear error
message. The error must:

- State that the GitHub API is unreachable or the request failed
- Identify which API call failed and what the error was
- Provide actionable guidance (check network, run `gh auth login`, verify repo access)
- Not create any partial files or state

The skill must not silently proceed with partial projections. An engineer who runs
`forge:project` must either get a complete, correct result or a clear failure — never
a partially scaffolded sub-effort.

---

## TR-2: forge:sync Skill

### TR-2.1: Command Surface

`forge:sync` requires no arguments when run from within a repository containing a
sub-effort with `coordinationRef` in its `.state.json`. An optional `--rematerialise`
flag triggers re-fetching and rewriting of stale projections.

If multiple sub-efforts with `coordinationRef` exist, the skill reports on all of them.

### TR-2.2: Staleness Detection Logic

For each projection entry in `coordinationRef.projections`, the skill:

1. Reads the `sourceSha` from the local projection entry
2. Calls the GitHub API to retrieve the current blob SHA for the source file:
   ```
   gh api repos/<org/repo>/commits?path=<source_file>&per_page=1
   ```
   And reads the blob SHA from the response for the source file.
3. Compares the current blob SHA against `sourceSha`

### TR-2.3: Projection States

Each projection is reported in one of three states:

- **current** — the `sourceSha` matches the current blob SHA in the coordination
  repository. The local projection reflects the latest coordination artifact.
- **stale** — the `sourceSha` does not match the current blob SHA. The local
  projection was taken against an earlier version. The skill must report the known
  `sourceSha` and the current SHA so the engineer can identify what changed.
- **unreachable** — the GitHub API call failed (network error, authentication failure,
  permission denied). The skill must report this state with the reason, not raise an
  error. The local projection remains usable; staleness cannot be determined.

### TR-2.4: Re-materialisation (--rematerialise)

When `--rematerialise` is passed, the skill re-fetches the content of all stale
projections, rewrites the projected files with updated content, and updates the
provenance header with the new `source_commit` and `projected_at` values. The
`sourceSha` and `commitSha` in `.state.json`'s `coordinationRef` are updated to
reflect the new projection.

Re-materialisation applies only to projections in `stale` state. Projections in
`current` or `unreachable` state are not modified.

### TR-2.5: Offline Behavior

If the GitHub API is unreachable when `forge:sync` runs, the skill must report each
projection as `unreachable` with the reason. It must not fail with an error. The local
projections remain valid and usable. The engineer is informed that staleness could not
be determined.

---

## TR-3: forge:upstream Skill

### TR-3.1: Command Surface

`forge:upstream` accepts a description of the change as its primary argument and an
optional `--pr` flag:

- Primary argument: a description of the change needed in the coordination repository
  (may be a phrase or a short paragraph provided interactively)
- `--pr` flag: if present, the skill creates a GitHub pull request to the coordination
  repository after writing the proposal document

### TR-3.2: Proposal Document

The skill writes a change proposal document to:
```
.forge/efforts/<local-effort-id>/upstream-proposals/<id>-<slug>.md
```

Where `<id>` is a zero-padded three-digit integer (e.g., `001`, `002`) incremented from
the highest existing proposal ID, and `<slug>` is a short kebab-case summary derived
from the change description.

The proposal document must have the following structure:

```markdown
# Upstream Proposal <id>: <title>

**Status:** proposed
**Target repository:** <org/coordination-repo>
**Target file:** <path-in-coordination-repo>
**Created:** <ISO-8601>

## Change Description

[What needs to change in the coordination artifact and why]

## Rationale

[The local discovery or implementation finding that necessitates this change]

## Proposed Content

[The specific content to add, modify, or remove in the target file]
```

All sections are required. If the engineer has not provided enough information to fill
a section, the skill must prompt for the missing information before writing the
document.

### TR-3.3: State Update

After writing the proposal document, the skill updates `.state.json`'s
`upstreamProposals` array with a new entry:

```json
{
  "file": "upstream-proposals/<id>-<slug>.md",
  "id": "<id>",
  "prUrl": null,
  "status": "proposed",
  "targetFile": "<path-in-coordination-repo>",
  "targetRepo": "<org/coordination-repo>"
}
```

`prUrl` is `null` until a PR is created. `status` starts as `proposed`.

### TR-3.4: Pull Request Creation (--pr)

When `--pr` is passed, the skill creates a pull request to the coordination repository:

```
gh pr create \
  --repo <org/coordination-repo> \
  --title "forge:upstream: <title>" \
  --body "<proposal document content>"
```

The PR URL returned by `gh pr create` is recorded in the `prUrl` field of the
proposal's entry in `.state.json`.

If `gh pr create` fails (no write access, authentication failure, or the engineer must
fork first), the skill must report the failure clearly, leave the proposal document
intact, and note that the PR was not created. The proposal document may still be used
to create the PR manually.

### TR-3.5: coordinationRef Dependency

`forge:upstream` requires a `coordinationRef` in the local effort's `.state.json` to
identify the coordination repository and the target effort. If no `coordinationRef` is
present, the skill must fail with a clear error directing the engineer to run
`forge:project` first.

---

## Constraints

### GitHub API Constraints

- All cross-repo API calls must use the `gh` CLI. The `gh` CLI must be installed and
  authenticated before any `forge-cross-repo` skill is invoked; Forge does not configure
  `gh` authentication.
- API calls must use the repos contents API and commits API only. Forge must not require
  admin-level API scopes.
- The minimum required scope for `forge:project` and `forge:sync` is read-only access
  to the coordination repository's contents.
- The minimum required scope for `forge:upstream --pr` is the ability to create a pull
  request (either write access to the coordination repository or the ability to fork it).

### Offline Constraints

- `forge:project` requires network access and must fail clearly when unavailable.
- `forge:sync` must degrade gracefully offline, reporting `unreachable` state.
- `forge:upstream` (without `--pr`) requires no network access.
- `forge:upstream --pr` requires network access for PR creation only; the proposal
  document is written locally regardless of connectivity.

### File Constraints

- Projected files are committed to the local repository and are treated as first-class
  artifacts. They appear in git log, can be blamed, and can be diffed.
- The provenance header must not be removed or modified by engineers or tools other than
  `forge:sync --rematerialise`.
- Projected file paths use the `projected-` prefix convention:
  `projected-business.md`, `projected-plan.md`.
