# Technical Requirements — forge-plan

Parent: [business requirements](business.md)
Upstream program requirements: TR-7 (coordination plan structure), TR-7a (task annotations), ADR-005

---

## TR-1: Every Task Must Carry Both a Type Annotation and a Wave Annotation

`forge:plan` must assign two annotations to every task it generates. Neither may be
omitted. A task with only a type annotation or only a wave annotation is incomplete.

**Type annotation** — governs how an executing agent approaches the task:

| Annotation | Meaning |
|------------|---------|
| `[auto]` | Agent proceeds autonomously; no pause required |
| `[checkpoint]` | Agent pauses before or after for human decision or confirmation |
| `[tdd]` | Agent follows RED → GREEN → REFACTOR; tests must exist and be failing before implementation code is written |
| `[manual]` | Human action required; agent cannot execute this task |

**Wave annotation** — governs execution ordering and parallelism:

| Annotation | Meaning |
|------------|---------|
| `[wave:N]` | Dependency group. All wave N tasks complete before wave N+1 begins. Tasks within the same wave have no dependency on each other and may run in parallel. |

## TR-2: The plan/tasks.md Format Must Match ADR-005 Exactly

The required format (per ADR-005) is:

```
- [ ] [auto][wave:1] Description of task (TASK-NNN)
- [ ] [tdd][wave:2] Description of task (TASK-NNN)
- [ ] [checkpoint][wave:2] Description — note why human input is needed (TASK-NNN)
- [x] [auto][wave:1] Completed task description (TASK-NNN) (a3f9b12)
```

Rules:
- Type annotation precedes wave annotation
- Task ID appears at end of description in parentheses
- Completed tasks record the first 7 characters of the satisfying commit SHA inline,
  after the task ID
- The checkbox `[ ]` or `[x]` precedes annotations; it is not part of them

`forge:plan` writes uncompleted tasks. It does not write completion SHAs — those are
recorded by the implementation skill when the task passes its quality loop.

## TR-3: Wave Assignment Must Reflect Actual Task Dependencies

Wave assignment is a dependency analysis, not an arbitrary grouping.

**Algorithm:**

1. Identify the complete set of tasks for the effort
2. For each task, identify which other tasks it depends on (tasks that produce artifacts,
   structures, or interfaces that this task requires as inputs)
3. Assign wave 1 to all tasks with no dependencies on any other pending task
4. Assign wave N+1 to any task whose dependencies include at least one wave N task
5. If a task depends on tasks from multiple waves, assign it to the wave after the
   highest-wave dependency
6. **Tie-breaking:** When a task has no dependencies and would otherwise land in
   wave 1, but it is only required by a later user story cluster, assign it to the
   same wave as the earliest task in that cluster that consumes it. A task must
   appear in the earliest wave where it is **needed**, not the earliest wave where
   it is **permitted**. A task may be promoted to an earlier wave only if two or
   more clusters require it before either can start.

Tasks within the same wave have no dependency on each other and may be executed in
parallel on separate git worktrees.

## TR-13: Infrastructure Tasks Must Be Assigned to the Cluster That First Requires Them

After enumerating implementation tasks, `forge:plan` must group them by user story
or feature cluster before assigning waves. For each cluster, the infrastructure tasks
(API proxy routes, schema migrations, utility libraries, scaffolding) that are first
required by that cluster must be assigned to that cluster — not extracted into a
standalone foundational wave.

An infrastructure task belongs in a shared early wave only if two or more clusters
genuinely require it before either can start. Shared utilities (e.g., shared types,
distance calculation helpers) belong in the earliest cluster that depends on them.

The intent is "as early as needed", not "as early as permitted." Building
infrastructure before the cluster that uses it produces unused artifacts that are
never exercised during the waves that follow.

## TR-14: plan/tasks.md Must Include a Delivery Diagram

After the intro paragraph in `plan/tasks.md` (before the first wave section),
`forge:plan` must insert a Mermaid Gantt diagram showing when each user story or
feature cluster becomes observable.

The diagram must include:
- One `section` per story/feature cluster
- Each task as a bar spanning its assigned wave
- A `milestone` marker per cluster at the wave where the cluster first becomes
  observable (user can exercise end-to-end for UI; endpoint callable for API;
  integration tests pass for backend; schema applied for migrations)
- `[checkpoint]` tasks marked as `crit`
- A comment (`%% Wave N: ...`) at any wave where two clusters overlap — one
  completing, one bootstrapping

Wave numbers (not dates) are used on the X-axis.

## TR-4: Type Annotation Must Be Derived from Task Characteristics, Not Description Text

`forge:plan` must apply a consistent set of heuristics to determine task type.
Annotation must not be based on description text alone.

**Type assignment heuristics:**

`[tdd]` — assign when the task is any of:
- Implementing a repository layer (data access object, query interface, persistence)
- Implementing a service layer (business logic, use case, application service)
- Implementing a domain model (entity, aggregate, value object)
- Implementing an API handler or controller where request/response contracts exist
- Any task where a spec artifact (API contract, storage schema) defines the expected
  behavior exactly — the spec is the test specification

`[checkpoint]` — assign when the task involves any of:
- Confirming an interface or contract with another team before implementation begins
- Making an architectural choice that affects downstream tasks
- Introducing an external dependency that must be provisioned or approved (service
  account, third-party API key, infrastructure resource)
- Wiring integration points where the correct behavior depends on a decision not
  fully resolved in the spec
- Any task where proceeding incorrectly would require significant rework of downstream
  wave tasks

A checkpoint task must include a note in its description explaining what needs to be
confirmed — not just that it is a checkpoint.

`[manual]` — assign when the task requires a human action that an agent cannot perform:
- Provisioning infrastructure resources in a console or ticket system
- Deploying to a restricted environment
- Performing a production data migration that requires DBA approval
- Any action gated by an organizational process outside the codebase

`[auto]` — assign to all other tasks: scaffolding, configuration, writing tests,
implementing logic that is fully specified, updating documentation.

## TR-5: The Coordination Plan (plan/plan.md) Must Be Written for Coordination Efforts

When the effort is a coordination effort (spanning multiple deployable repositories),
`forge:plan` must also write `plan/plan.md` in addition to `plan/tasks.md`.

`plan/plan.md` is deployable-scoped, not task-level. It contains:
- One section per deployable involved in the effort
- Per section: the acceptance criteria items assigned to that deployable, expressed as
  verifiable statements of what must be true when the work is done
- Cross-deployable dependencies made explicit: if deployable B depends on an interface
  from deployable A, that dependency must appear in both sections

`plan/plan.md` is the artifact that `forge:project` materializes into local sub-efforts.
It must be structured so that the deployable-scoped slice is extractable without
reading the full document.

## TR-6: The Plan Must Be Committed as Part of the Planning Phase

After writing `plan/tasks.md` (and `plan/plan.md` if applicable), `forge:plan` must
commit all written artifacts with a conventional commit message that includes the
effort ID in the scope:

```
chore(<effort-id>): generate implementation plan
```

The PostToolUse hook will detect the `plan/tasks.md` write and update `.state.json` to
reflect planning phase in progress. The explicit commit ensures the plan is in git
history and visible to the PostToolUse hook.

## TR-7: The Plan Must Be Generated from Effort Artifacts, Not from Engineer Memory

`forge:plan` reads all discovery artifacts before generating the plan:
- `requirements/business.md` and `requirements/technical.md`
- All spec artifacts: `spec/api/`, `spec/storage/`, `spec/messaging/`, `spec/test-strategy.md`
- All ADRs: `spec/arch-decisions/ADR-*.md`

The plan must be grounded in what these artifacts say. Tasks that have no basis in the
requirements or spec are not valid plan tasks. Tasks that address stated requirements
but are not represented in the plan are a gap that must be closed before the plan is
committed.

## TR-8: Phase Entry Check Before Plan Generation

Before reading discovery artifacts, `forge:plan` must check `currentPhase` in
`.state.json`:

- If `currentPhase` is `"planning"` or any later phase: proceed silently to plan
  generation — no phase check needed.
- If `currentPhase` is before `"planning"` (e.g., `"discovery"`): invoke
  `forge:promote <effort-id> --target planning` and wait for it to complete.
  `forge:promote` will show advisory readiness checks, offer to run `forge:validate`
  if no validation report exists, and ask the engineer to confirm advancement.

This ensures effort state is aligned with the work being done, without blocking the
engineer if they choose not to advance.

## TR-9: Phase Completion Check After Plan Committed

After `plan/tasks.md` is written and committed, `forge:plan` must check `currentPhase`:

- If `currentPhase` is `"implementation"` or later: proceed silently to the output summary.
- If `currentPhase` is `"planning"`: invoke `forge:promote <effort-id> --target implementation`
  to offer immediate advancement to the implementation phase. Wait for the engineer's
  response before printing the output summary.

This allows an engineer who invokes `forge:plan` to advance through both the discovery
and planning phases in a single command invocation.

## TR-10: Initiative and Program Efforts Must Produce plan/epics.md Instead of plan/tasks.md

When the effort type (from `.state.json`) is `"initiative"` or `"program"`, `forge:plan`
must write `plan/epics.md` and must not write `plan/tasks.md`.

`plan/epics.md` serves as both the epic breakdown and the coordination plan for the
initiative. It must contain one section per child epic. Each section must include:
- **Epic ID** — sequential identifier: EPIC-001, EPIC-002, etc., assigned in recommended
  delivery order (foundational epics first)
- **Name** — a short descriptive title (3–8 words)
- **Deployable** — the deployable slug (e.g. `rewards-api`) that owns this epic. This
  is the name used under `.forge/deployables/` in the owning repository — not the repo
  name itself. Every epic must have a deployable assigned; use `tbd` only if it cannot
  be determined. `forge:project` reads this field to materialize the epic in the
  correct deployable. When the deployable lives in a different repository from the
  coordination repo, a separate **Repo** field must also be set; omit Repo otherwise.
- **High-Level Output** — one paragraph describing the concrete deliverable when this
  epic is complete: what exists, what works, what a user or system can do
- **Relevant Requirements** — the BR-*/TR-* IDs from the initiative's requirements that
  this epic is responsible for satisfying, with a brief quote of the requirement text
- **Success Criteria** — 3–6 measurable, unambiguous conditions confirmable by automated
  check, stakeholder demo, or defined process; no subjective criteria allowed
- **Dependencies** — other epics in this initiative that must be fully or partially
  complete before this epic can start (omit section if none)

Target epic count: 3–8. Fewer than 3 suggests the effort may not be initiative-scale.
More than 8 suggests epics should be merged.

The initiative path does not invoke `forge:promote` to advance to an implementation
phase — initiatives do not implement directly; each child epic has its own lifecycle.

## TR-11: Epic-Path Tasks Must Carry Requirement Traceability, Applicable Standards, and Required Tests

When the effort type is `"epic"`, `"story"`, `"task"`, or `"spike"`, each task in
`plan/tasks.md` must include three additional fields beyond the type/wave/description:

**Satisfies** — a comma-separated list of BR-*/TR-* requirement IDs this task fulfills.
Tasks with no direct requirement mapping (pure scaffolding) must state `n/a`. This
ensures every requirement has an owning task and every task has a stated purpose.

**Standards** — a comma-separated list of applicable Forge standard and language guide
file paths (relative to the plugin root) that govern how this task should be implemented.
`forge:plan` must locate the plugin root and read `standards/AGENTS.md` to identify
which standards are relevant before writing any tasks. If no standards apply to a
specific task, state `none`.

**Required tests** — a bulleted list of named unit and integration tests that must exist
and be passing before this task is considered complete. Each entry must name the test
function and describe in one line what it verifies. For scaffolding, configuration, or
migration tasks with no testable behavior, state `none (<reason>)`.

The task format changes from a single-line checkbox to a multi-line block:

```
### TASK-NNN [<type>][wave:N]

<One-sentence description.>

**Satisfies:** BR-001, TR-002
**Standards:** `standards/api/contracts.md`, `languages/go/http-handlers.md`
**Required tests:**
- Unit: `TestFoo_Bar` — verifies <what>
- Integration: `TestFoo_Integration` — verifies <what>
```

## TR-12: forge:plan Must Identify Applicable Standards Before Writing Tasks

Before enumerating tasks for an epic-path effort, `forge:plan` must:

1. Locate the Forge plugin root using the canonical shell command from CLAUDE.md
2. Read `<plugin-root>/standards/AGENTS.md` to understand available standards domains
3. Based on the effort's spec artifacts and requirement content, identify which standards
   and language guides apply (e.g., efforts with API specs → `standards/api/`; storage
   specs → `standards/storage/`; any effort with TDD tasks → `standards/testing/`)
4. Record the applicable standards list internally and use it to annotate every task

Standards references in task blocks must be file paths relative to the plugin root,
not display names or prose descriptions.
