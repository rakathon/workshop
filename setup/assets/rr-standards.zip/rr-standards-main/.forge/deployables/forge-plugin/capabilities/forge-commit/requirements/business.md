# Business Requirements — forge-commit

Parent deployable: [forge-plugin](../../requirements/business.md)

---

## BR-1: Raw git commit Produces Inconsistent Commit Messages Across Engineers and Sessions

When engineers commit implementation work using raw `git commit`, message quality
varies widely: some messages describe the diff, some describe the intent, some omit
scope entirely, and some mix multiple tasks into a single commit. This inconsistency
makes the commit history unreliable as a record of what was done and why. Code
review, incident investigation, and rollback all depend on commit messages being
consistently formatted and scoped. A skill that proposes and enforces conventional
commit format — `type(scope): description` — eliminates the inconsistency without
requiring the engineer to remember the convention on every commit.

## BR-2: Mixed-Concern Commits Make forge:verify Unreliable

The `forge:verify` skill confirms that each task in `plan/tasks.md` has a
corresponding commit with sufficient implementation evidence. When multiple logical
tasks are bundled into a single commit, verification cannot isolate which parts of
the commit satisfy which task. False positives (a task marked complete when the
commit also contains unrelated changes) and false negatives (a task with implementation
evidence that is obscured by noise from other tasks) both occur. Requiring engineers
to confirm single-task scope before committing eliminates this verification failure
mode.

## BR-3: Traceability from Requirements to Code Requires Machine-Readable Metadata

Business requirements must be traceable to the commits that implement them. That
traceability chain — business requirement → task → commit — must be machine-readable
so that `forge:verify`, `forge:diagnose`, and `forge:revert` can follow it
programmatically. Commit messages are human-readable but not reliably parseable at
scale. Structured JSON metadata attached to every task-completion commit (via git
notes, per ADR-008) provides the machine-readable layer. Without it, traceability
depends on text parsing heuristics, which are fragile and fail on non-standard
message formats.

## BR-4: Engineers Must Be Prompted to Update the Plan After Each Commit

A commit that completes a task does not automatically update `plan/tasks.md` or
`.state.json`. If an engineer forgets to run `forge:update-plan`, the plan drifts
from reality: tasks appear incomplete that are done, wave ordering is broken, and
Jira sync is never triggered. An explicit post-commit prompt — "Run
`forge:update-plan` to record this SHA and mark the task complete" — ensures the
plan stays current without requiring the engineer to remember the follow-up step.
