# ADR-002: forge:elaborate Subsumes forge:extract; forge:extract Deprecated

**Status:** Accepted
**Date:** 2026-04-25
**Capability:** forge-elaborate

---

## Context

`forge:extract` read a PM document (Confluence page, Jira epic, product brief) and produced
structured `BR-*` entries in `requirements/business.md`. It was designed as a first step in
the discovery chain: extract BRs from a PM artifact, then elaborate TRs from those BRs.

This two-step model assumed that discovery begins with a PM document. In practice, engineers
frequently invoke discovery without a PM document — from a verbal brief, from a Slack thread,
from their own understanding of what needs to be built. `forge:extract` had no value in these
cases. More importantly, both steps were forms of artifact production that did not require the
engineer to actually think through the problem — they produced documents from inputs, not
understanding from conversation.

The new `forge:elaborate` interview model makes `forge:extract` redundant. If a PM document
exists, the engineer can describe it or paste relevant sections into the conversation and the
interview will incorporate that context. If no PM document exists, the interview begins from
first principles. Either way, the mechanism for capturing business requirements is the interview,
not document parsing.

---

## Decision

`forge:elaborate` is redesigned to be invokable with no prior artifacts. It does not require
`requirements/business.md` to exist — it will produce business requirements during the interview
if they are missing. This means `forge:elaborate` can be the first skill invoked in discovery,
making `forge:extract` unnecessary as a prior step.

`forge:extract` is deprecated. The deprecation is deferred — `forge:extract` remains callable
but its SKILL.md will be updated to note that `forge:elaborate` is the preferred entry point
for discovery and that `forge:extract` will be removed in a future version.

---

## Consequences

**Positive:**
- Engineers have a single entry point for discovery: `forge:elaborate`
- No prerequisite step is required; the skill adapts to whatever exists
- Business requirements produced by the interview have the benefit of the conversational context that produced them — they are more likely to be complete and correctly framed

**Negative:**
- `forge:extract`'s automated parsing of structured PM documents (e.g., extracting requirements from a long Confluence page) is not directly replicated. Engineers with large PM documents will need to either summarize them conversationally or paste relevant sections.

**Mitigations:**
- The interview model can incorporate PM document context provided conversationally
- If structured document parsing proves to be a high-value gap, it can be reintroduced as a pre-processing step that feeds context into the interview, rather than producing BRs directly

**Deprecation note:**
`forge:extract` SKILL.md should be updated to include:
> "Deprecated: `forge:elaborate` is now the preferred entry point for discovery and can be
> invoked with no prior artifacts. `forge:extract` will be removed in a future version."
