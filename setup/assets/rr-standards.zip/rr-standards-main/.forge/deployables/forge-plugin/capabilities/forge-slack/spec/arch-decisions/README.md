# Architecture Decisions — forge-slack

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [ADR-001](ADR-001-github-actions-scheduling.md) | Use GitHub Actions for Scheduled Slack Import | Accepted | 2026-04-21 |
| [ADR-002](ADR-002-slack-mcp-over-direct-api.md) | Use Slack MCP Instead of Direct Slack REST API | Accepted | 2026-04-21 |
| [ADR-003](ADR-003-lag-buffer-for-import-end-timestamp.md) | Use Lag Buffer When Computing Import End Timestamp | Accepted | 2026-04-28 |
