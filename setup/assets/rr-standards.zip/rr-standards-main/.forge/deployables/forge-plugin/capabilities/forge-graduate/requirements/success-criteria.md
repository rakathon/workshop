# Success Criteria — forge-graduate

- [ ] A completed single-deployable effort (e.g., "favorite-stores") graduates
      successfully: the target deployable's requirements files are updated (not appended),
      the API specification is present in the deployable's `spec/` directory, and all ADRs
      produced by the effort reference the effort ID in their metadata

- [ ] When a graduated effort's target deployable already had requirements documentation,
      the post-graduation requirements document is a single coherent section — not the old
      section plus a new "additions from effort-XYZ" section alongside it

- [ ] Each canonical document updated during graduation contains a provenance comment
      recording the effort ID and graduation timestamp, placed at the top of the file below
      the H1 heading

- [ ] When the graduating effort has one or more post-approval modifications recorded in
      `.state.json`, the graduation report explicitly lists each modified artifact, the
      phase in which it was modified, and confirms that the graduated document reflects the
      final (modified) state

- [ ] After graduation, the effort's `.state.json` contains `graduation.graduated: true`,
      `graduation.graduatedAt` set to a valid ISO-8601 timestamp, and `graduation.graduatedTo`
      listing every file path that was created or updated

- [ ] After graduation, the effort's row is absent from `.forge/efforts/README.md`; the effort
      directory itself remains intact at `.forge/efforts/<id>/`

- [ ] The graduation changes are committed in a single, distinct commit whose message
      follows the `docs(graduation): graduate effort-<id> to <deployable-name>` format and
      contains no source code or test file changes

- [ ] A coordination effort graduates correctly: cross-cutting artifacts are promoted to
      `.forge/products/<name>/` and the product documentation reflects the current state
      of the feature, not an append of the effort's output

- [ ] `forge:graduate` runs as an isolated worker sub-agent: it does not read the main
      session's conversation history, does not emit status during execution, and returns
      only the graduation report

- [ ] If the effort's `.state.json` has no `deployables` or `businessProducts` fields
      populated, `forge:graduate` halts immediately and returns a clear error to the main
      session rather than graduating to an unknown target
