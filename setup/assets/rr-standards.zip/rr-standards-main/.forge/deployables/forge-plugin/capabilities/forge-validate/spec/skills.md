# forge:validate — Skill Specification

**Agent type:** Worker (spawned by orchestrator pre-invocation)
**Skill file:** `plugins/forge/skills/validate/SKILL.md`

## Purpose

Full cross-reference validation of all discovery artifacts against each other and
against organizational standards. Produces `validation/report.md` — the gate artifact
read by `forge:promote`. Runs before `forge:promote` is invoked.

## Orchestrator Pre-invocation (runs in the engineer's session)

1. Read `.state.json`. Confirm `currentPhase = "discovery"` and `phases.discovery.status != "approved"`.
2. Confirm at minimum `requirements/business.md` exists.
3. Check for an active checkpoint in `.state.json`. If found, offer resume.
4. Spawn the worker.
5. After worker completes, read `**Result:**` from `validation/report.md` and present to engineer.
6. Update `.state.json`: `phases.validation.status = "passed" | "passed_with_concerns" | "failed"`.

## Worker Steps

1. Load all discovery artifacts (business.md, technical.md, spec/api/*.yaml, spec/storage/*.md, spec/messaging/*.md, spec/arch-decisions/*.md).
2. If total file size > 1,000 lines: spawn the four internal agents in parallel. Otherwise: single-pass.
3. Requirements traceability check.
4. Standards compliance check (only for domains present in spec/).
5. Cross-spec consistency check.
6. ADR quality check.
7. Compute result: FAIL / PASS WITH CONCERNS / PASS.
8. Write `validation/report.md`.
9. Commit: `docs(<id>): design validation report`

## Internal Agents (spawned when artifacts > 1,000 lines)

| Agent | Check | Receives | Returns |
|-------|-------|----------|---------|
| requirements-traceability-agent | BR/TR → spec coverage | All BRs/TRs, spec summaries | Coverage map |
| api-standards-agent | API vs REST standard | spec/api/*.yaml | findings[] |
| storage-standards-agent | Schema vs storage standard | spec/storage/*.md | findings[] |
| cross-spec-consistency-agent | Cross-spec conflicts | All spec artifacts | conflicts[] |

## Output Format

`validation/report.md` must start with:
```
**Result:** PASS | PASS WITH CONCERNS | FAIL
```
Followed by per-check sections with severity labels (REQUIRED / SUGGESTION).
