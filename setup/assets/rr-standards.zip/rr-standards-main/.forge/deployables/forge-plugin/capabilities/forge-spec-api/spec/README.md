# Spec — forge-spec-api

| Artifact | Description |
|----------|-------------|
| [skills.md](skills.md) | Full skill interface spec |

**Cross-references:**
- Initiative design: `.forge/efforts/spec-driven-development/spec/skills.md § forge:spec-api`
- Standard loaded: `plugins/forge/standards/api/rest.md`
- Output consumed by: `forge:validate-api`, `forge:validate`, `forge:verify`
