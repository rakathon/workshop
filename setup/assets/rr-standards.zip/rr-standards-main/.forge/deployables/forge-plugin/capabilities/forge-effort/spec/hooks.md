# Hooks — forge-effort

This file specifies the four hooks delivered by the forge-effort capability. Hooks are
shell scripts that fire at Claude Code lifecycle events. They never contain business logic
— they read state, emit context, and update state files. All writes to `.state.json` are
performed in the working tree; Claude commits the state change atomically with the artifact
that triggered it (guided by the CLAUDE.md before-write rule).

Implementation location: `plugins/forge/hooks/`

---

## Hook 1: inject-workflow-context.sh

**Purpose:** Inject the current workflow state into Claude's context at the start of every
session, so the agent knows what is happening before the engineer says anything.

**Trigger:** SessionStart lifecycle event.

**Applies to:** Every session start in a repository that has `.forge/efforts/README.md`.

### Behavior

1. Check for `.forge/efforts/README.md`. If absent, exit 0 with no output (repository not initialized).
2. Read `.forge/efforts/README.md` to get the list of all active efforts.
3. For each active effort, read `.forge/efforts/<id>/.state.json`.
4. Identify the most likely current effort:
   - If only one effort is `in_progress`, that is the current effort.
   - If the current git branch name matches an effort ID (e.g., branch `effort/forge-workflow`
     matches effort `forge-workflow`), use that effort.
   - If multiple efforts are active and none matches the branch, list all with a prompt
     to clarify before proceeding with workflow operations.
4.5. Branch drift check (runs after effort identification, before any other output):
   - If no active effort was identified in step 4: skip this check entirely.
   - Read current branch: `git branch --show-current`
   - Compute expected branch: `effort/<active-effort-id>`
   - If current branch ≠ expected branch:
     - Emit the following as the FIRST item in the output (before everything else):

       ```
       ⚠️ **Branch mismatch:**
       Active effort: <id>  Expected branch: effort/<id>
       Current branch: <actual-branch>
       Run: git checkout effort/<id>
       ```

     - Then continue with normal output below.
   - If current branch = expected branch: proceed normally, no output for this check.
   - This check is informational only. The hook still exits 0 regardless of branch state.
5. Emit the artifact routing table (artifact type → canonical path for every artifact type
   in every phase). This is the Tier 2 content from ADR-001.
6. For the current effort, emit:
   - ID, title, type, tier, risk classification
   - Current phase and status
   - Artifact inventory: which artifacts are present, which are absent
   - Open decisions (if any) with their blocking task (if any)
   - Pause state and next action (if `pauseState` is populated in `.state.json`)
   - Post-approval modifications (if any — flags these for reconciliation awareness)
7. For cross-repo sub-efforts (efforts with a non-null `coordinationRef`), check staleness:
   - Read `coordinationRef.projections` from `.state.json`.
   - For each projection, compare `sourceSha` against the coordination repo's current HEAD
     via `gh api repos/<org>/<repo>/commits?path=<source_file>&per_page=1`.
   - Run all API calls in background subprocesses with a 1.5-second timeout.
   - If a projection is stale (local `sourceSha` differs from current HEAD), emit a
     staleness warning identifying the stale file and the coordination repo.
   - If the API call fails or times out: skip silently. Do not emit an error.
8. Exit 0. This hook never blocks session start.

### Exit Codes

| Condition | Exit Code | Output |
|-----------|-----------|--------|
| Normal operation | 0 | Forge context block |
| No `.forge/efforts/README.md` | 0 | None (silent) |
| No active efforts | 0 | Brief "no active efforts" note |
| Multiple active efforts, ambiguous current | 0 | List all; note to clarify |
| API call failure or timeout | 0 | Context without staleness info |

**This hook never exits 2. Session start is never blocked.**

### Performance

Must complete in under 2 seconds. GitHub API staleness checks run in background subprocesses
with a 1.5-second hard timeout. The main hook body (reading local state files) must complete
in under 500ms independently of network operations.

### Output Format

```
## Forge — Active Workflow Context

**Current effort:** <id> (<type>)
**Phase:** <phase> (<status>)
**Tier:** <tier> | **Risk:** <risk>

**Artifacts:**
- requirements/business.md ✓
- requirements/technical.md ✓
- spec/api/ (absent)
- spec/storage/ (absent)

**Next suggested action:** <derived from phase and artifact inventory>

**Open decisions:** <none | list of OD-NNN: description>

**Post-approval modifications:** <none | list of modified files>

**Artifact routing table:**
- Business requirements → .forge/efforts/<id>/requirements/business.md
- Technical requirements → .forge/efforts/<id>/requirements/technical.md
- API specification → .forge/efforts/<id>/spec/api/
- Storage schema → .forge/efforts/<id>/spec/storage/
- Messaging contracts → .forge/efforts/<id>/spec/messaging/
- Architecture decisions → .forge/efforts/<id>/spec/arch-decisions/ADR-NNN-*.md
- Implementation plan → .forge/efforts/<id>/plan/tasks.md
- Validation report → .forge/efforts/<id>/validation/report.md
```

### Edge Cases

| Scenario | Behavior |
|----------|----------|
| No active effort in registry | Emit "no active efforts" note; skip routing table |
| Single effort but branch doesn't match | Use the single active effort; no ambiguity prompt |
| Multiple efforts, branch matches one | Use the branch-matched effort as current |
| `.state.json` missing or corrupt | Skip that effort; emit warning naming the affected effort |
| Offline (no network) | Skip all API calls; proceed with local state only |
| `coordinationRef` is null | Skip staleness check entirely for that effort |

---

## Hook 2: route-to-skills.sh

**Purpose:** Detect high-confidence workflow intent in the engineer's prompt and inject
targeted routing context before Claude responds. This hook is a safety net — the CLAUDE.md
Tier 1 intent patterns are the primary recognition mechanism. This hook handles cases where
additional context would materially improve Claude's action selection.

**Trigger:** UserPromptSubmit lifecycle event (fires after user submits a prompt, before
Claude responds).

**Applies to:** Every prompt in a repository with `.forge/efforts/README.md`.

### Behavior

1. Read the prompt text from the hook's input.
2. Scan for high-confidence intent signals:
   - **Explicit skill invocation** (e.g., `/forge:status`, `forge:pause`) → inject the full
     skill routing instructions for that skill.
   - **Effort-scoped action** (e.g., "start working on PROJ-1234", "create an effort for X")
     → inject effort creation routing context if the target effort is not currently active.
   - **Completion / graduation signal** (e.g., "QA passed, let's close this out", "effort is
     done") → inject the graduation checklist context and confirm all pre-graduation conditions.
3. For low-confidence or ambiguous signals: exit 0, no output. Let CLAUDE.md handle it.
4. This hook must not duplicate what CLAUDE.md already provides for common conversational
   patterns. Its role is supplementary — catching edge cases and high-stakes operations.
5. Exit 0. This hook never blocks.

### Exit Codes

| Condition | Exit Code | Output |
|-----------|-----------|--------|
| High-confidence signal detected | 0 | Targeted routing context (~20-30 lines) |
| Low-confidence or ambiguous | 0 | None (silent) |
| No `.forge/efforts/README.md` | 0 | None (silent) |

**This hook never exits 2.**

### Performance

Must complete in under 300ms. Text scanning only — no file reads beyond a quick check for
`.forge/efforts/README.md` existence. No network calls.

### Edge Cases

| Scenario | Behavior |
|----------|----------|
| Prompt matches multiple signal types | Inject context for the highest-confidence signal only |
| No active effort | Skip all routing injection; CLAUDE.md handles it |
| Explicit skill invocation for a skill not in forge-effort | Inject generic "skill not recognized" note pointing to available skills |

---

## Hook 3: phase-context.sh

**Purpose:** Before any Write or Edit operation targeting a `.forge/efforts/` path, inform
Claude about the current phase and whether the target artifact was produced in an earlier
(possibly approved) phase. This gives the agent awareness that it is making a post-approval
modification.

**Trigger:** PreToolUse lifecycle event for Write and Edit operations.

**Applies to:** Files under `.forge/efforts/` only. Any path outside `.forge/efforts/`
(including `.forge/deployables/`, `.forge/products/`, source code, or configuration) passes
through immediately without any check.

### Behavior

1. Extract the file path from the hook's input arguments.
2. If the path is not under `.forge/efforts/`, exit 0 immediately with no output.
3. Extract the effort ID from the path:
   `.forge/efforts/<effort-id>/...` → `<effort-id>`.
4. Read `.forge/efforts/<effort-id>/.state.json`.
5. Determine the artifact category from the file path:
   - `requirements/` → requirements artifact (belongs to discovery phase)
   - `spec/` → design artifact (belongs to discovery phase)
   - `validation/` → validation artifact (belongs to validation phase)
   - `plan/` → planning artifact (belongs to planning phase)
   - `phases.implementation` artifacts → implementation phase
6. Compare the artifact's phase against the effort's `currentPhase`:
   - **Typical write:** the artifact's phase matches the current phase, or is a later phase.
     Exit 0, no output.
   - **Atypical write (post-approval modification):** the artifact's phase is earlier than
     the current phase, AND the earlier phase's status is `"approved"`. Exit 0, emit
     informational context.
7. If `.state.json` is absent or unreadable, exit 0 immediately — do not block the write.

### Informational Output (Atypical Write)

```
Note: You are modifying <artifact-path>, which was produced during the <prior-phase> phase
(approved on <approvedAt>). The effort is currently in the <currentPhase> phase.
This modification will be tracked as a post-approval change in .state.json and must be
reconciled before graduation. The write will proceed.
```

### Exit Codes

| Condition | Exit Code | Output |
|-----------|-----------|--------|
| Path outside `.forge/efforts/` | 0 | None |
| Typical write for current phase | 0 | None |
| Atypical write (post-approval modification) | 0 | Informational note (above) |
| `.state.json` absent or unreadable | 0 | None |

**This hook never exits 2. No write to `.forge/efforts/` is ever blocked.**

This is a hard constraint from ADR-002. The only scenario where source code writes are
blocked (full-tier efforts before discovery approval) belongs to a separate hook that applies
to source code paths — not to this hook.

### Performance

Must complete in under 200ms. The hook reads exactly two inputs:
1. The target file path (from hook arguments — no disk read).
2. `.state.json` (one file read, typically under 10KB).

No network calls. No recursive directory searches.

### Edge Cases

| Scenario | Behavior |
|----------|----------|
| Effort ID cannot be extracted from path | Exit 0, no output |
| `.state.json` missing | Exit 0, no output (treat as no-op) |
| Phase status is `not_started` (no approval yet) | Typical write — exit 0, no output |
| Write to `.state.json` itself | Path is under `.forge/efforts/` but has no artifact category — exit 0, no output |
| Multiple efforts, ambiguous path | Parse the second path segment as the effort ID (`.forge/efforts/<id>/...`) |

---

## Hook 4: update-workflow-state.sh

**Purpose:** After any successful Write or Edit operation targeting a `.forge/efforts/` path,
detect the artifact type and update `.state.json` and `.forge/efforts/README.md` automatically. This
is the mechanism that makes state management invisible — engineers and agents produce artifacts,
and state is a side effect.

**Trigger:** PostToolUse lifecycle event for Write and Edit operations that completed successfully.

**Applies to:** Files under `.forge/efforts/` only. Writes to other paths pass through with
no action.

### Behavior

1. Extract the written file path from the hook's input.
2. If the path is not under `.forge/efforts/`, exit 0 immediately.
3. Extract the effort ID from the path.
4. Read `.forge/efforts/<effort-id>/.state.json`.
5. Determine the artifact category and apply the corresponding state update:

| Written path pattern | State update |
|---------------------|-------------|
| `requirements/business.md` | `phases.discovery.artifacts.requirements.business = "present"` |
| `requirements/technical.md` | `phases.discovery.artifacts.requirements.technical = "present"` |
| `spec/api/*.yaml` or `spec/api/*.md` | `phases.discovery.artifacts.spec.api = "present"` |
| `spec/storage/*.md` | `phases.discovery.artifacts.spec.storage = "present"` |
| `spec/messaging/*.md` | `phases.discovery.artifacts.spec.messaging = "present"` |
| `spec/arch-decisions/ADR-*.md` | Append filename to `phases.discovery.artifacts.adrsCreated` (if not already present) |
| `plan/tasks.md` | Set `phases.planning.status = "in_progress"` if currently `"not_started"`; parse task completion and update `completedTasks` / `remainingTasks` |
| `validation/report.md` | Set `phases.validation.status = "in_progress"` if currently `"not_started"`; parse overall result (PASS / PASS WITH CONCERNS / FAIL) into `phases.validation.result` |
| `validation/arch-review.html` | Append `"validation/arch-review.html"` to `phases.validation.artifacts` if not already present |

6. Check for post-approval modifications:
   - Determine the phase the artifact belongs to (see step 5 mapping).
   - If that phase's `status` is `"approved"`, append a post-approval modification record:
     ```json
     {
       "file": "<relative path within effort directory>",
       "modifiedAt": "<ISO-8601 timestamp>",
       "modifiedDuringPhase": "<currentPhase value>"
     }
     ```
   - Append to `phases.<artifact-phase>.postApprovalModifications`.
7. Write updated `.state.json` to disk.
8. If the effort's `currentPhase` or status changed, update the corresponding row in
   `.forge/efforts/README.md` in-place.
9. Exit 0.

### Exit Codes

| Condition | Exit Code | Output |
|-----------|-----------|--------|
| Normal operation | 0 | None (silent) |
| Path outside `.forge/efforts/` | 0 | None |
| `.state.json` absent | 0 | None (cannot update what does not exist) |
| Unrecognized artifact path | 0 | None (not all writes are artifact writes) |

**PostToolUse hooks cannot exit 2 to block operations — they are informational by definition.**

### Atomicity Note

This hook updates `.state.json` in the working tree only. It does not create commits.
The CLAUDE.md before-write rule instructs Claude to commit the artifact and the state change
together. The typical commit flow is:

1. Claude writes the artifact (e.g., `requirements/business.md`).
2. This hook fires and updates `.state.json`.
3. Claude commits both files: `docs(<effort-id>): add business requirements`.

If Claude commits only the artifact without the updated `.state.json`, state becomes
inconsistent. The CLAUDE.md instructions explicitly require atomic commits of artifact
and state together.

### Performance

Must complete in under 500ms. Reads one file (`.state.json`), performs in-memory updates,
writes one file (`.state.json`), and optionally updates one line in `.forge/efforts/README.md`.
No network calls. No recursive searches.

### Edge Cases

| Scenario | Behavior |
|----------|----------|
| ADR file already in `adrsCreated` | Skip append; do not duplicate |
| `plan/tasks.md` re-written with same completion state | Idempotent — no spurious updates |
| `validation/report.md` re-written with different result | Update `phases.validation.result` to the new value |
| Effort has no `phases.discovery` (lightweight effort with no discovery) | Skip discovery artifact updates; proceed for other phase types |
| `.state.json` is being written itself | No-op — writing `.state.json` does not trigger self-referential updates |
