# Test Plan — forge-verify

## Scope

This document covers test strategy for two components:
1. The `forge:verify` skill
2. The implementation quality loop contract (exercised through `forge:build-*` skills)

---

## forge:verify Skill

### Test Categories

**Stub detection accuracy**
- Effort with stubs in load-bearing paths → FAIL report with accurate code locations
- Effort with real implementations → PASS report
- Edge case: stub in a non-load-bearing utility function → must not FAIL (out of scope)

**Missing wiring detection**
- Component registered in config but never called → FAIL with wiring gap description
- Event emitter with no subscriber → FAIL
- Fully wired effort → PASS

**Requirement coverage**
- BR with no corresponding task in plan → FAIL with "No task found" note
- TR with incomplete implementation → FAIL with specific gap location
- All BRs and TRs covered → PASS

**ADR compliance**
- Implementation contradicts an ADR decision → FAIL
- Implementation follows all ADRs → PASS (ADR compliance table shows PASS for all)

**Isolation**
- Verify sub-agent reads from file system, not from main session context
- Verify report content matches file state, not conversation state

**Phase gate**
- `forge:promote` with no `verification/report.md` → prompt to run `forge:verify`
- `forge:promote` with `Result: FAIL` → block with gap count
- `forge:promote` with `Result: PASS` → advance phase

### Fixtures

Test fixtures should include:
- A minimal effort with 2 BRs and 2 TRs, where one BR is covered by a stub
- A fully implemented effort with all checks passing
- An effort with a missing wiring scenario (route handler defined, middleware not
  applied)

---

## Implementation Quality Loop Contract

### Test Categories

**Lint integration**
- Task with lint error → error detected in Step 2, addressed, task completes
- Task with no lint config → lint step skipped, task proceeds to Step 3
- Task with lint binary absent → warning emitted, task proceeds to Step 3

**TDD protocol**
- `[tdd]` task: test written and confirmed failing before implementation begins
- `[tdd]` task: test that passes before implementation → flagged as incorrect test
- `[tdd]` task: RED → GREEN → REFACTOR sequence confirmed

**Spec validation**
- Task with acceptance criterion not met → gap detected in Step 3, addressed in
  current iteration

**Iteration limit**
- Task that cannot pass in 3 iterations → escalation state written to `.state.json`
- Escalation state contains all required fields (TR-V-2.6)
- Task NOT marked complete after escalation
- Next task NOT started after escalation

**Resumption**
- Resumed task: prior escalation state presented before new attempt begins
- Iteration counter resets to 0 for resumed task

**Multi-language tasks**
- Task modifying TypeScript and Go files → both linters run independently
- All must pass before Step 3

### Acceptance Tests (Mapped to Success Criteria)

| Success Criterion | Test |
|-------------------|------|
| SC-V-5: Lint detected and fixed | Run loop on task with eslint error; confirm error fixed before commit |
| SC-V-6: TDD writes failing test first | Run `[tdd]` task; confirm test failure recorded before implementation |
| SC-V-7: Escalation state written | Run task with 3 forced failures; confirm `.state.json` pause field |
| SC-V-8: Resumed task shows prior context | Read escalation state; resume; confirm prior summary presented |
