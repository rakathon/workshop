# Skills — forge-plan

## forge:plan

**Classification:** Orchestrator

**Conversational equivalent:** "Let's break this into tasks" / "Let's plan the
implementation" / "What do we need to build?"

**Arguments:** effort ID (required — the effort slug used in `.forge/efforts/<id>/`)

**Inputs:**
- `.forge/efforts/<id>/.state.json` (to determine effort type and coordination status)
- `.forge/efforts/<id>/requirements/business.md`
- `.forge/efforts/<id>/requirements/technical.md`
- `.forge/efforts/<id>/spec/api/` (if present; epic path only)
- `.forge/efforts/<id>/spec/storage/` (if present; epic path only)
- `.forge/efforts/<id>/spec/messaging/` (if present; epic path only)
- `.forge/efforts/<id>/spec/test-strategy.md` (if present; epic path only)
- `.forge/efforts/<id>/spec/arch-decisions/ADR-*.md` (epic path only)
- `<plugin-root>/standards/AGENTS.md` (epic path only — to identify applicable standards)

**Outputs:**
- **Initiative/program:** `.forge/efforts/<id>/plan/epics.md`
- **Epic/story/task/spike:** `.forge/efforts/<id>/plan/tasks.md`
- `.forge/efforts/<id>/plan/plan.md` (coordination epics only — multi-repo epics that are not initiatives)

---

## Dispatch

Read `type` from `.state.json`. Route to the appropriate path:

| Type | Path | Output |
|------|------|--------|
| `initiative`, `program` | Initiative Path | `plan/epics.md` |
| `epic`, `story`, `task`, `spike` | Epic Path | `plan/tasks.md` |

---

## Initiative Path

**Step 1I — Read requirements**

Read `requirements/business.md` and `requirements/technical.md`. Extract strategic
goals, key constraints, and any explicit sub-problem groupings.

**Step 2I — Identify child epics**

Break the initiative into 3–8 named epics. Each epic must be a coherent,
independently releasable slice of work with its own discovery/spec/plan cycle and a
clear boundary with other epics. For each epic, derive:

1. Name (3–8 words)
2. Deployable — the deployable slug (e.g. `rewards-api`) that owns this epic, matching
   the name used under `.forge/deployables/` in the owning repo. Not the repo name.
   `forge:project` reads this field to materialize the epic in the correct deployable.
   Use `tbd` if unknown. Add a separate Repo field only when the deployable lives in a
   different repository from the coordination repo.
3. High-Level Output — one paragraph: what exists, what works, what users/systems can do
4. Relevant Requirements — BR-*/TR-* IDs this epic owns, with brief quoted text
5. Success Criteria — 3–6 measurable, unambiguous conditions (no subjective criteria)
6. Dependencies — other epics that must be complete (or partially complete) first

**Step 3I — Write plan/epics.md**

```markdown
# Initiative Plan: <Effort Title>

This plan breaks the initiative into child epics. Each epic will have its own
discovery, specification, and implementation cycle.

---

## EPIC-001: <Epic Name>

### High-Level Output

<One paragraph describing the concrete deliverable when this epic is complete.>

### Relevant Requirements

- **BR-001** — <brief quote>
- **TR-003** — <brief quote>

### Success Criteria

- [ ] <Measurable condition>
- [ ] <Measurable condition>

### Dependencies

- Depends on: EPIC-NNN (<reason — what specifically must exist first>)
```

Assign EPIC IDs sequentially in recommended delivery order (foundational first).
Omit the Dependencies subsection for epics with no intra-initiative dependencies.

**Step 4I — Commit**

```bash
git add .forge/efforts/<id>/plan/epics.md
git commit -m "chore(<id>): generate initiative epic breakdown"
```

Do not invoke `forge:promote` for initiative efforts — each child epic has its own
lifecycle.

---

## Epic Path

**Step 1E — Read requirements**

Read `requirements/business.md` and `requirements/technical.md`. Build an internal
map of all BR-*/TR-* IDs and what each requires, including any explicit task hints.

**Step 2E — Read spec artifacts**

Read all spec artifacts under `spec/`. Extract implementation obligations:
- `spec/api/*.yaml` → endpoint handlers, request/response contracts
- `spec/storage/*.md` → data access, migration tasks, schema changes
- `spec/messaging/*.md` → producers, consumers, event schemas
- `spec/test-strategy.md` → test types required, coverage expectations
- `spec/arch-decisions/ADR-*.md` → constraints that shape task design

**Step 3E — Identify applicable standards**

Locate the Forge plugin root using the canonical command from CLAUDE.md. Read
`<plugin-root>/standards/AGENTS.md`. Based on the effort's spec artifacts and
requirements, identify which standards and language guides apply. Record the list
as file paths relative to the plugin root — this is used to annotate every task.

Examples:
- Effort with API spec → `standards/api/contracts.md`, `standards/api/protocol.md`
- Effort with storage spec → `standards/storage/` guides
- Any TDD tasks → `standards/testing/` guides
- Language-specific work → `languages/<lang>/` guides

**Step 4E — Identify implementation tasks**

Enumerate all tasks. For each task, also identify:
- Which BR-*/TR-* requirement IDs it satisfies
- Which named unit/integration tests must pass before it is done (derive from
  `spec/test-strategy.md` and the spec contracts)

A task must be grounded in the artifacts. Do not invent tasks without basis; do not
omit tasks implied but not stated.

After enumerating tasks, group them by user story/feature cluster. For each cluster,
identify which infrastructure tasks (API routes, migrations, utilities) it first
requires and assign those tasks to that cluster. An infrastructure task goes in a
shared early wave only if two or more clusters need it before either can start.
Shared utilities belong in the earliest cluster that requires them.

**Step 5E — Analyze dependencies**

Build a dependency graph. A dependency exists when task B requires an artifact,
decision, or testable output produced by task A.

**Step 6E — Assign waves**

1. Wave 1: tasks with no dependencies
2. Wave N+1: tasks whose highest-wave dependency is wave N
3. Verify: no task in wave N depends on a task in wave N or higher
4. Tie-breaking: a dependency-free task that is only required by a later cluster is
   assigned to the wave of the earliest consuming task in that cluster, not wave 1.

**Step 7E — Assign type annotations**

First matching rule wins:

- `[manual]` — human action required (infra provisioning, restricted deployment, DBA approval)
- `[checkpoint]` — requires external confirmation or unresolved decision before/after
  (must include a note in description: `confirm <X> before proceeding`)
- `[tdd]` — repository layer, service layer, domain model, API handler with spec contract
- `[auto]` — everything else (scaffolding, config, migrations, docs)

**Step 7.5E — Write delivery diagram**

After writing the intro paragraph in `plan/tasks.md` (before the first wave section),
insert a Mermaid Gantt diagram. The diagram shows each story/feature cluster as a
section, tasks as bars at their assigned wave, a milestone marker per cluster at the
wave where it first becomes observable (user-exercisable for UI; endpoint callable for
API; integration tests passing for backend; schema applied for migrations), and a
comment at any wave where two clusters overlap (one completing, one bootstrapping).
Mark `[checkpoint]` tasks as `crit`. Use wave numbers on the X-axis.

**Step 8E — Write plan/tasks.md**

Each task is a multi-line block, sorted by wave then task ID:

```markdown
# Implementation Plan: <Effort Title>

Tasks within the same wave are independent and can run in parallel on separate
git worktrees. Tasks in wave N+1 require all wave N tasks complete before starting.

---

## Wave 1 — Foundation

### TASK-001 [auto][wave:1]

<One-sentence description of what this task produces or changes.>

**Satisfies:** n/a
**Standards:** none
**Required tests:** none (scaffolding task)

---

### TASK-002 [tdd][wave:1]

<One-sentence description.>

**Satisfies:** BR-002, TR-004
**Standards:** `standards/storage/schema-design.md`, `languages/go/repository-pattern.md`
**Required tests:**
- Unit: `TestFavoritesRepository_Add` — verifies row insertion and ID return
- Unit: `TestFavoritesRepository_List` — verifies pagination and user scoping
- Integration: `TestFavoritesRepository_Integration` — real DB, constraint enforcement

---

## Wave 2 — Core Implementation

### TASK-003 [tdd][wave:2]
...
```

Fields required on every task:
- `**Satisfies:**` — BR-*/TR-* IDs, or `n/a` for pure scaffolding
- `**Standards:**` — plugin-root-relative paths, or `none`
- `**Required tests:**` — named tests with one-line descriptions, or `none (<reason>)`

**Step 9E — Write plan/plan.md (coordination efforts only)**

Check `.state.json` for `type: "coordination"` or non-empty `deployables` array.
If coordination, write `plan/plan.md` with one section per deployable:

```markdown
# Coordination Plan: <Effort Title>

---

## <Deployable Name> (<repo-name>)

### Acceptance Criteria

- <criterion> — <how assessed>

### Cross-Deployable Dependencies

- Depends on: <other-deployable> delivering <interface> before <wave:N>
```

Omit the Dependencies subsection for deployables with no cross-deployable dependencies.

**Step 10E — Commit**

```bash
git add .forge/efforts/<id>/plan/tasks.md
# if plan/plan.md was written:
git add .forge/efforts/<id>/plan/plan.md
git commit -m "chore(<id>): generate implementation plan"
```

Commit both files in the same commit if both were written.

---

## Output Format Reference

Plan output formats are defined by the bundled templates in
`templates/forge/efforts/plan/`. Teams may override any template by placing a
project-local copy under `.forge/templates/plan/` in their repository.

| File | Template | Used when |
|------|----------|-----------|
| `plan/epics.md` | `templates/forge/efforts/plan/epics.md` | initiative / program efforts |
| `plan/tasks.md` | `templates/forge/efforts/plan/tasks.md` | epic / story / task / spike efforts |
| `plan/plan.md` | `templates/forge/efforts/plan/plan.md` | coordination efforts (epic path only) |

See the template files for the canonical structure and all required fields.
