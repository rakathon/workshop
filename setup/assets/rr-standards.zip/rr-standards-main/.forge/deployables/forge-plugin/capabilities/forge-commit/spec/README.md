# forge-commit Spec

Design artifacts for the `forge:commit` capability.

## Contents

| File | Description |
|------|-------------|
| [skills.md](skills.md) | Detailed skill specification — step-by-step orchestration logic |
| `arch-decisions/` | ADRs scoped to this capability (currently empty; see deployable-level ADR-008) |

## Design Summary

`forge:commit` is a six-step orchestrator skill that replaces raw `git commit` for
implementation work. Its design follows two key principles from ADR-008:

1. **Commit messages stay human-readable** — conventional commit format
   (`type(scope): description`) is enforced but not extended with structured data.
2. **Rich metadata goes in git notes** — the JSON note payload (workId, taskId, wave,
   taskType, standardsChecked) is the machine-readable traceability layer, not the
   message.

The skill is a guardrail, not a gate. Branch convention warnings are non-blocking.
Mixed-concern warnings pause the flow but accept engineer override. Only the
no-staged-changes case is a hard stop (there is nothing to commit).

## Key Design Decisions

### Use temp file for git notes attachment

The note JSON must be written to a temp file before calling `git notes add -F`.
Inline shell quoting (`git notes add -m '{"key": "val"}'`) is fragile across
platforms and terminals. A temp file sidesteps all quoting issues.

### taskId sourced from plan/tasks.md, not .state.json

`.state.json` tracks task IDs at the array level but does not expose the current
in-progress task reliably mid-session. `plan/tasks.md` is the canonical source for
task IDs — the skill reads the task list and asks the engineer to confirm which task
is being completed if ambiguous.

### standardsChecked is always true when attached by forge:commit

Any commit flowing through `forge:commit` is assumed to have been made in a context
where the engineer had access to Forge standards. Manual raw commits bypass this
assumption — they produce no note at all, which is detectable by `forge:verify`.

## Related Documentation

- [ADR-008 — Structured git notes](../../../../../spec/arch-decisions/ADR-008-structured-git-notes.md)
- [forge:update-plan](../../../capabilities/forge-update-plan/) (planned; reads notes written here)
- [forge:verify](../../../capabilities/forge-verify/) (consumes notes written here)
