# Test Strategy — forge-arch-review

## Scope

| Area | What is tested |
|------|---------------|
| `forge:arch-review` skill | Correct standard selection per artifact type, per-rule severity assignment, overall result computation, report structure, HTML section completeness, isolated worker behavior |
| `validation/report.md` | Header format, per-rule table structure, traceability matrix, overall result extractability |
| `validation/arch-review.html` | Self-containment (no external refs), all 12 sections present, navigation links, print CSS, minimum font size |
| `forge:promote` gate | FAIL blocks advancement, PASS WITH CONCERNS permits advancement, missing report blocks advancement |

---

## Approach

### Skill Behavioral Tests

`forge:arch-review` is tested using the with/without-context eval methodology from
rr-standards. A `.evals.json` companion file alongside `SKILL.md` specifies test cases.

The eval set must include at minimum:

**Standards violation detection:**

| Test case | Fixture | Expected behavior |
|-----------|---------|-------------------|
| Missing `code` field in 409 response | Effort with REST spec missing `code` field | FAIL finding for that rule; overall FAIL |
| SHOULD violation (non-standard status code) | Effort returning 200 for duplicate add | CONCERN finding; overall PASS WITH CONCERNS |
| Clean effort | Effort with no violations | PASS; no FAIL or CONCERN findings |
| Uncovered BR | Effort with BR-7 not addressed in any spec | FAIL finding in Requirements Coverage |
| Uncovered TR | Effort with TR not addressed in any spec | CONCERN finding in Requirements Coverage |

**Standards selection:**

| Test case | Fixture | Expected behavior |
|-----------|---------|-------------------|
| No spec/api/ | Effort with storage and messaging only | No REST API section in report |
| spec/api/ present | Effort with API spec | REST API section present in report |
| No spec/messaging/ | Effort without messaging | Section 7 in HTML states not applicable |
| Missing standard file | Standards lib with api/rest.md removed | NOTE finding for REST domain; skill continues |

**ADR quality:**

| Test case | Fixture | Expected behavior |
|-----------|---------|-------------------|
| ADR missing rationale | ADR with decision but no rationale | CONCERN finding |
| Complete ADR | ADR with decision, rationale, alternatives | PASS |

**Overall result computation:**

| Test case | Findings mix | Expected overall result |
|-----------|-------------|------------------------|
| One FAIL, multiple CONCERNs | Mixed | FAIL |
| No FAILs, one CONCERN | CONCERN only | PASS WITH CONCERNS |
| Only NOTEs | NOTEs only | PASS |
| No findings | Empty | PASS |

### HTML Output Tests

End-to-end tests that generate `validation/arch-review.html` from a fixture effort
and verify structural properties:

1. All 12 section `id` attributes present in generated HTML
2. Navigation sidebar contains 12 anchor links matching section IDs
3. No `src` or `href` attributes containing `http://` or `https://` URLs
4. Body font-size CSS property is at minimum 14px
5. Print media query contains `page-break-before: always` (or `break-before: page`)
6. File opens correctly in a browser from a `file://` URL (manual verification step)

### Promote Gate Tests

Integration tests for the `forge:promote` gate behavior:

| Test case | State | Expected behavior |
|-----------|-------|-------------------|
| Full-tier effort, FAIL result | `validation/report.md` present with FAIL | Promote blocked; FAIL findings surfaced |
| Full-tier effort, PASS WITH CONCERNS | `validation/report.md` present with PASS WITH CONCERNS | Promote permitted |
| Full-tier effort, PASS | `validation/report.md` present with PASS | Promote permitted |
| Full-tier effort, no report | No `validation/report.md` | Promote blocked; arch-review instruction shown |
| Lightweight effort (patch), no report | No `validation/report.md` | Promote permitted |
| Lightweight effort (poc), no report | No `validation/report.md` | Promote permitted |

---

## Test Plans

_None yet — to be added during implementation phase._

## Coverage Notes

The highest-priority test areas are:
1. Standards violation detection (the core purpose of the skill)
2. Overall result computation (consumed by `forge:promote` as a gate)
3. HTML self-containment (the most common failure mode for generated HTML)

The promote gate tests are critical — an incorrect gate allows design-level
violations through to implementation, defeating the purpose of the capability.
