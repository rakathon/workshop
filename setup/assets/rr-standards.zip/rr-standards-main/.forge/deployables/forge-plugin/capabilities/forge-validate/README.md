# forge-validate

Discovery artifact validation for the Forge AI-accelerated development framework.
Delivers the `forge:validate` skill that performs full cross-reference validation of
all discovery artifacts — requirements traceability, standards compliance, cross-spec
consistency, and ADR quality — and produces `validation/report.md`, the gate artifact
read by `forge:promote`.

## What It Delivers

| Artifact | Type | Scope | Trigger |
|---------|------|-------|---------|
| `forge:validate` | Skill | Worker (spawned by orchestrator) | Before `forge:promote`, or "validate my discovery artifacts" |

**`forge:validate`** checks that:
1. Every business requirement (BR-*) and technical requirement (TR-*) is covered by
   at least one spec artifact.
2. Every spec artifact (API contracts, storage schemas, messaging contracts) complies
   with the applicable organizational standard.
3. No conflicts exist between spec artifacts (e.g., an API endpoint writing a field
   not in the storage schema).
4. Every ADR has the required sections (Context, Decision, Alternatives, Consequences).

The skill produces `validation/report.md` with a grep-extractable
`**Result:** PASS | PASS WITH CONCERNS | FAIL` line on the first non-blank line.
`forge:promote` reads this line as its gate artifact — if no report exists or the
result is `FAIL`, promotion is blocked.

## Why This Capability Exists

Without an automated pre-promotion check, inconsistencies in discovery artifacts
surface during implementation — at the highest cost. Engineers start coding against
a spec that conflicts with the storage schema, or implement TRs that have no design
coverage. `forge:validate` moves this detection to the earliest possible point:
before planning begins. The grep-extractable `**Result:**` line makes the gate
machine-readable, so `forge:promote` can enforce it programmatically.

## Related Capabilities

| Capability | Relationship |
|-----------|-------------|
| [forge-promote](../forge-promote/) | Reads `validation/report.md` written by forge:validate. Blocks promotion on FAIL. |
| [forge-elaborate](../forge-elaborate/) | Produces `requirements/business.md` and `requirements/technical.md` — loaded by forge:validate for BR/TR coverage checks. |
| [forge-spec-api](../forge-spec-api/) | Produces `spec/api/*.yaml` — checked by forge:validate against the REST standard. |
| [forge-spec-storage](../forge-spec-storage/) | Produces `spec/storage/*.md` — checked against the applicable storage standard. |
| [forge-arch-review](../forge-arch-review/) | Also writes `validation/report.md` using the same format; forge:promote reads either. |

## Implementation Location

`plugins/forge/skills/validate/` — `forge:validate` SKILL.md

## Artifacts

| Artifact | Description |
|----------|-------------|
| `requirements/business.md` | Business drivers for automated discovery validation |
| `requirements/technical.md` | Technical requirements for each validation check |
| `spec/README.md` | Skill design overview |
| `spec/skills.md` | Detailed skill specification |
