# forge-verify Skills Design

Two designs are documented here:

1. **`forge:verify`** — the final implementation verification skill
2. **Quality loop contract (build-contract)** — the shared per-task loop executed by
   all `forge:build-*` implementation skills

---

## forge:verify

### Classification

Worker (isolated sub-agent)

### Why Isolated

`forge:verify` reads the full set of discovery artifacts (requirements, spec, ADRs) and
traverses the implementation code for every task in the plan. Loading this material in
the main engineer session would consume context needed for the implementation work that
follows a FAIL report, or for the PR preparation that follows a PASS report.

Running isolated also ensures consistent analysis quality regardless of what has
accumulated in the engineer's active conversation. The verification result must reflect
what is in the files — not partial context from the current session's discussion.

### Preconditions

- **PC-1:** All tasks in `plan/tasks.md` are marked complete with commit SHAs
- **PC-2:** The effort's discovery artifacts exist:
  `requirements/business.md`, `requirements/technical.md`, at minimum one ADR or
  `spec/README.md`
- **PC-3:** Not currently in escalation state (a `pause.reason = quality_loop_limit_reached`
  in `.state.json` indicates unresolved task work — that must be resolved first)

### Steps

```
Step 1 — Load discovery artifacts
  Read requirements/business.md — extract all BR-* entries
  Read requirements/technical.md — extract all TR-* entries
  Read all files in spec/arch-decisions/ — extract all ADR decisions
  Read spec/README.md and any other files in spec/ — extract design constraints

Step 2 — Load the implementation plan
  Read plan/tasks.md
  For each completed task, extract:
    - Task ID (TASK-NNN)
    - Task description
    - Commit SHA (the 7-char SHA recorded inline after the task)
    - Which BRs/TRs the task addresses (from task description and acceptance criteria)

Step 3 — Map requirements to tasks
  Build a coverage map: for each BR and TR, which task(s) are responsible?
  Flag any BRs or TRs with no corresponding task — these are planning gaps that
  forge:verify must report as FAIL with the note "No task found for this requirement."

Step 4 — Load implementation code
  For each completed task's commit SHA:
    Read the source files changed in that commit
    Focus on the files most directly relevant to the task's stated purpose

Step 5 — Verify each requirement
  For each BR in the coverage map:
    Locate the implementation code in the responsible task's commit
    Apply stub detection (see TR-V-1.3): is the implementation real or a placeholder?
    Apply wiring check (see TR-V-1.3): are all components connected end-to-end?
    Record: PASS (with code location) or FAIL (with gap description)

  For each TR in the coverage map:
    Apply the same checks as BRs
    Additionally: does the implementation match the spec artifact it is supposed to
    fulfill? (e.g., if TR specifies a REST endpoint shape, does the code implement
    that shape?)
    Record: PASS or FAIL

  For each ADR:
    Does the implementation follow the prescribed approach?
    Does the implementation contradict the decision?
    Record: PASS or FAIL

Step 6 — Write verification/report.md
  Format: see TR-V-1.4
  Overall result: PASS if all requirements PASS; FAIL if any requirement FAILs

Step 7 — [orchestrator-only] Present report to engineer
  Summarize: total requirements checked, PASS count, FAIL count
  If PASS: confirm the implementation is ready for PR; proceed to forge:promote
  If FAIL: present the gap list; inform engineer that implementation must resume
    before forge:promote can advance to verification phase
```

### Report Format

See [TR-V-1.4](../requirements/technical.md) for the complete report structure.

Key format rules:
- `Result:` is the second line of the document, after the title — scannable without
  reading the full report
- Every FAIL row in the Requirement Coverage table must reference a Gap entry by number
- Every Gap entry must include a specific code location — file path and function name
  or line number
- The Summary paragraph is required for both PASS and FAIL results

### PASS / FAIL Semantics

**PASS:** The implementation delivers the effort's stated goals. All requirements have
real implementation evidence. No stubs in load-bearing paths. No missing integration
wiring. All ADRs complied with. The engineer may proceed to open a PR.

**FAIL:** One or more requirements are not delivered. The verification report identifies
exactly what is missing and where. Implementation must resume. The engineer should
address the gaps identified in the report, re-run affected tasks through the quality
loop, and then re-run `forge:verify`.

There is no intermediate result. A concern that does not constitute a gap — a style
preference, a potential future risk, a non-binding observation — is out of scope and
must not appear in the report as a FAIL. If it is worth noting, include it in the
Summary paragraph as context only.

### [Orchestrator-Only] Triggering forge:verify

The main session (orchestrator role) triggers `forge:verify` when:
- The engineer explicitly requests verification ("let's verify", "forge:verify")
- The engineer signals readiness to open a PR and all tasks are marked complete
- `forge:promote` is invoked and `verification/report.md` is absent

The orchestrator launches the sub-agent, waits for `verification/report.md` to be
written, then reads and presents it. The orchestrator does not attempt to interpret
the report independently — it presents the sub-agent's findings.

---

## Quality Loop Contract (build-contract)

This contract is referenced by all `forge:build-*` implementation skills. Every
implementation skill executes this loop identically for each task. The contract is
defined here once; individual skill designs reference this document rather than
duplicating it.

Implementation: `plugins/forge/skills/build-contract/`

### Loop Steps (Numbered)

```
For each task in the current wave:

  iteration = 0
  while iteration < MAX_ITERATIONS:

    STEP 1 — IMPLEMENT
      Read the task description and acceptance criteria from plan/tasks.md.
      Read the applicable spec artifacts:
        - API contract if implementing an endpoint
        - Storage schema if modifying data access
        - Event schema if publishing or consuming events
      Write or update source files to fulfill the task.
      For [tdd] tasks: write the test FIRST (see TDD Protocol below).
      For [auto] tasks: proceed autonomously.
      For [checkpoint] tasks: pause for engineer confirmation before committing.

    STEP 2 — LINT
      Identify all source files modified in Step 1.
      Detect the language(s) of those files by extension.
      Run the configured linter for each language (see Linter Detection Table).
      Read the full linter output — do not assume pass.
      If errors or warnings: address each one before proceeding to Step 3.
      If no linter configured for a language: skip lint for that language silently.
      If linter binary absent: emit a warning; proceed to Step 3.

    STEP 3 — VALIDATE AGAINST SPEC
      Read the task's acceptance criteria from plan/tasks.md.
      Read the applicable spec artifacts again (same as Step 1).
      For each acceptance criterion:
        Confirm the implementation satisfies it.
        If not: address the gap in the current iteration.
      This is a focused check on this task's scope only.
      Do not attempt full-effort goal delivery checks — that is forge:verify's scope.

    STEP 4 — RUN TESTS
      Run the test suite or the subset affected by the changed files.
      For [tdd] tasks: confirm the test written in Step 1 now passes.
      Confirm no existing tests regress.
      If failures: address each one before proceeding.

    IF ALL CHECKS PASS (Steps 2, 3, 4 all clean):
      Commit with message:
        chore(<effort-id>): implement <task-title> (TASK-NNN)
      Record commit SHA in plan/tasks.md:
        - [x] [auto][wave:N] Task description (TASK-NNN) (a3f9b12)
      Mark task complete — EXIT LOOP

    iteration += 1

  IF MAX_ITERATIONS REACHED WITHOUT PASSING:
    → Write escalation state to .state.json (see Escalation Format)
    → Surface to engineer — do NOT mark the task complete
    → Do NOT continue to next task
```

### TDD Protocol

Tasks annotated `[tdd]` require RED → GREEN → REFACTOR:

**RED:**
1. Write the test that describes the expected behavior
2. Run the test — confirm it FAILS
3. If the test passes without any implementation: the test is wrong — fix it
4. Do not write any implementation code until the test is confirmed failing

**GREEN:**
5. Write the minimum implementation to make the test pass
6. Run the test — confirm it now passes

**REFACTOR:**
7. Improve the implementation for clarity and maintainability
8. Run the test again — confirm it still passes

The RED confirmation in step 2-3 is not optional. An implementation skill that writes
implementation and test together, producing a passing test, has not followed TDD.

### Linter Detection Table

The implementation skill detects which linter to run from project-level configuration
files. Check for config files in the project root (or language-standard locations).

| Language | Config file(s) to check | CLI command |
|----------|--------------------------|-------------|
| TypeScript | `eslint.config.js`, `eslint.config.mjs`, `.eslintrc.*` | `npx eslint <files>` |
| JavaScript | Same as TypeScript | `npx eslint <files>` |
| Go | `.golangci.yml`, `.golangci.yaml` or `golangci-lint` in PATH | `golangci-lint run <files>` |
| Java | `checkstyle.xml` in root or `src/`, checkstyle plugin in `pom.xml` | `mvn checkstyle:check` |
| Java (Gradle) | checkstyle plugin in `build.gradle` or `build.gradle.kts` | `./gradlew checkstyle` |
| Kotlin | `.editorconfig` + `detekt.yml` or detekt plugin in `build.gradle.kts` | `./gradlew detekt` |
| Swift | `.swiftlint.yml` in project root | `swiftlint <files>` |
| Python | `.flake8`, `setup.cfg` with `[flake8]` section, `pyproject.toml` with `[tool.flake8]` | `flake8 <files>` |

**Config absent:** Skip lint for that language silently. Absence of a linter config
is a valid project state — not an error.

**Binary absent:** Emit a warning (one line: "Warning: <linter> config found but
binary not installed — skipping lint for <language>"). Continue to Step 3. Do not fail
the loop iteration on a missing binary.

**Multiple languages in one task:** Run linter for each language independently. All
must pass before proceeding.

### Escalation Format

When MAX_ITERATIONS is reached, write the following to the `pause` field in
`.state.json`. All fields are required.

```json
{
  "pause": {
    "reason": "quality_loop_limit_reached",
    "taskId": "TASK-NNN",
    "taskDescription": "Human-readable description of the blocked task",
    "iterationsAttempted": 3,
    "remainingFailures": {
      "lint": [
        "<file>:<line> — <error message> (<rule-id>)"
      ],
      "specValidation": [
        "Acceptance criterion N not satisfied: <description of the gap>"
      ],
      "tests": [
        "<TestSuite/TestName> — <failure message>"
      ]
    },
    "iterationSummary": [
      "Iteration 1: <one-sentence summary of what was attempted and what failed>",
      "Iteration 2: <one-sentence summary>",
      "Iteration 3: <one-sentence summary>"
    ],
    "suggestedNextAction": "<Specific, actionable recommendation for the engineer. Name the file, function, or concept to review. Not a generic instruction.>"
  }
}
```

**Notes on field values:**
- `iterationsAttempted` is always equal to MAX_ITERATIONS when escalation occurs
- `remainingFailures` must contain only the failures still present after the final
  iteration — not the full history of failures across iterations
- An empty array `[]` is valid if a category (lint, specValidation, tests) has no
  remaining failures but other categories do
- `suggestedNextAction` must be specific: name the file, function, or concept. "Review
  the implementation" is not acceptable.

### Iteration Limit — Default and Configuration

**Default:** 3 iterations.

**Why 3:** Three iterations covers the typical correction cycle: implement → fix lint →
fix test. After three iterations without passing, the remaining failures almost always
require human judgment — a spec ambiguity, a design conflict, a missing dependency.
Additional automated attempts without new information do not improve outcomes.

**Configuration:** Override per project via `.forge/config`:
```
quality_loop_max_iterations=5
```

The configured value applies to all `forge:build-*` skills in the repository. If the
file is absent or the key is not present, use 3.

The configured value must be read at the start of each task execution, not cached
across tasks. An engineer changing the limit mid-effort should have the new limit
applied to subsequent tasks.

### Iteration Counter Reset

The iteration counter resets to 0 for each task. A task that required 3 iterations does
not affect the iteration budget for the next task.

When a task is resumed after escalation (the engineer has reviewed and directed a new
approach), the iteration counter resets to 0 for the resumed attempt. The prior
escalation summary is presented to the engineer as context but does not count against
the new iteration budget.
