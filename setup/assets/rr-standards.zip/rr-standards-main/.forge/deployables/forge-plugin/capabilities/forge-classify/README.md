# forge-classify

Assigns an R1–R4 risk classification to a Forge effort. Reads the business
requirements and risk rubric, derives a recommendation with explicit rationale,
and writes the confirmed classification to `.state.json` after engineer sign-off.

**Skill:** `forge:classify`
**Classification:** Orchestrator
**Invoked by:** `forge:elaborate` (automatically, after user stories are written) or manually
**Drives:** discovery depth, arch review, implementation verification, PR approval policy

Part of the spec-driven-development initiative (Initiative 3).
