# Runbook — forge-clear

## Procedures

### forge:clear Reports "No active effort is set." Unexpectedly

**Symptom:** Running `forge:clear` prints "No active effort is set." even though
you were working in an effort context.

**Cause:** `.forge/EFFORT` was already deleted — either by a prior `forge:clear`,
`forge:pause`, or manually.

**Resolution:**
1. Run `forge:effort` to select and reactivate the effort.
2. Or run `forge:resume` if you have a pause state to restore.

---

### Active Effort Not Cleared After Running forge:clear

**Symptom:** Subsequent commands still pick up the effort context after
`forge:clear`.

**Cause:** The effort was resolved via in-session context (Step 3 of the
effort-resolution chain), not via `.forge/EFFORT`. Claude accessed effort files
earlier in this conversation, so the effort ID remains in-session context even
without the pointer file.

**Resolution:** Start a new Claude Code session. In-session context does not
persist across sessions.
