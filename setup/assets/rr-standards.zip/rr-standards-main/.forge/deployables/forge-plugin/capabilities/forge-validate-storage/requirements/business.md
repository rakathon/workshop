# Business Requirements — forge:validate-storage

*Effort: forge-validate-storage*  *Authored: 2026-04-13*

---

## BR-1: Targeted Inline Storage Schema Feedback

**Description:**
When engineers author storage schemas during `forge:spec-storage`, they need immediate
inline feedback on whether the schema complies with the applicable storage standard
(PostgreSQL, DynamoDB, Redis, OpenSearch) — without waiting for the full `forge:validate`
run at the end of discovery. Without targeted storage validation, violations (missing PII
annotations, non-idiomatic index design, missing soft-delete policy) accumulate and are
expensive to fix in batch.

**Acceptance Criteria:**
- AC-1.1: Running `forge:validate-storage` during or after `forge:spec-storage` produces
  an inline session report covering all entities in `spec/storage/*.md`.
- AC-1.2: The report identifies at least: missing primary key definitions, fields without
  types, missing soft-delete policy, and indexes not tied to query patterns.
- AC-1.3: The report loads and applies the standard for the detected storage technology
  (PostgreSQL, DynamoDB, Redis, or OpenSearch); technology-specific checks are applied.
- AC-1.4: The validator runs as a self-contained worker and does not require reading prior
  session state.

---

## BR-2: Non-Gating Editing Aid

**Description:**
The targeted storage validator must not write a gate artifact or update state — it is an
editing aid. Only `forge:validate` owns `validation/report.md`. Writing to that file or
updating `.state.json` from `forge:validate-storage` would corrupt the workflow gate and
create conflicting authority over the validation phase.

**Acceptance Criteria:**
- AC-2.1: `forge:validate-storage` never writes to `validation/report.md`.
- AC-2.2: `forge:validate-storage` never modifies `.state.json`.
- AC-2.3: All output from `forge:validate-storage` is confined to the current session
  (inline report only).
- AC-2.4: Engineers can run `forge:validate-storage` multiple times during discovery
  without side effects.

---

## BR-3: Explicit GDPR and PII Compliance Surfacing

**Description:**
The inline report must surface GDPR/PII annotation gaps and soft-delete policy omissions
explicitly, since these are the highest-risk storage schema defects. PII violations
found late in the development cycle require schema migrations and policy updates that
are costly and may block production readiness.

**Acceptance Criteria:**
- AC-3.1: Any field identified as containing personal data (email, name, DOB, phone,
  financial data, IP address, device ID) that lacks a retention period annotation
  is flagged as a REQUIRED finding.
- AC-3.2: Any field identified as containing personal data that lacks a deletion
  obligation annotation is flagged as a REQUIRED finding.
- AC-3.3: Soft-delete policy omissions are flagged as REQUIRED findings (entities
  without a `deleted_at` field or equivalent policy statement).
- AC-3.4: REQUIRED findings are visually distinguished from SUGGESTION findings
  in the report.
