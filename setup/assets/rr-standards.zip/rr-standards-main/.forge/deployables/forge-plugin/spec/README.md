# Forge Framework — Architecture

<!-- graduated-from: forge-update at 2026-04-13T15:44:47Z -->

> **Visual reference:** [Forge Workflow Diagram](../../../../docs/workflows/forge-workflow-diagram.md) —
> phase sequence, human gates, and per-phase Activities / Artifacts / Skills.

Full technical spec detail is documented in the forge-plugin work item:
[`.forge/efforts/forge-plugin/spec/`](../../../efforts/forge-plugin/spec/README.md)

## Guiding Principles

1. **The repository is the source of truth.** All workflow state, artifacts, and
   decisions live in version-controlled files.
2. **Standards are separate from skills.** Skills reference standards documents; they
   do not embed them. When a standard changes, every skill that references it benefits.
3. **Skills do one thing.** Each skill has a single, focused purpose. Composition is
   handled by the `using-skills` orchestration layer.
4. **Discovery is co-evolutionary, not sequential.** Requirements and design co-evolve
   freely during discovery. The gate that matters is before implementation.
5. **Validation is always active; ceremony scales with risk.** Standards compliance,
   security, and privacy checks apply regardless of workflow tier.
6. **Humans remain in the loop at gates, not on mechanics.** Phase transitions require
   explicit human approval. Mechanical work is delegated to agents.
7. **GitHub Actions is the CI/CD runtime.** Automation outside interactive sessions
   runs in non-interactive Claude within GitHub Actions.
8. **Standards govern generation and evaluation — not just evaluation.** The same
   standards document used to evaluate a PR is injected at code generation time.
9. **Analytical skills run in isolated sub-agents.** Worker sub-agents get fresh,
   isolated context windows. Orchestrator skills run in the main session.
10. **Context quality is actively monitored.** A PostToolUse hook warns at defined
    thresholds before quality silently degrades.
11. **Agent autonomy has explicit, documented boundaries.** Every skill defines what
    it can do without asking and what it must escalate.

## Key Locations

| Purpose | Path |
|---------|------|
| Work item registry | `.forge/efforts/README.md` |
| Work item artifacts | `.forge/efforts/<work-id>/` |
| Deployable canonical artifacts | `.forge/deployables/<deployable-name>/` |
| PM product artifacts (product-role repos) | `.forge/products/<product-name>/` |
| Architectural decisions | `.forge/deployables/forge-plugin/spec/arch-decisions/` |
| Repo-level cross-deployable decisions | `.forge/spec/arch-decisions/` |
| Operational runbook | `docs/runbook/` |
| Codebase profile | `docs/codebase/` |
| Plugin installation | `plugins/` |

## Design Documents

| Area | Document |
|------|----------|
| Workflow infrastructure — directory structure, state model, tiering, phase gates | [project: workflow.md](../../../projects/forge-plugin/spec/workflow.md) |
| Skills — full catalog, design rules, orchestrator/worker classification | [project: skills.md](../../../projects/forge-plugin/spec/skills.md) |
| Hooks — hook inventory and communication protocol | [project: hooks.md](../../../projects/forge-plugin/spec/hooks.md) |
| Standards — catalog of required standards and document structure | [project: standards.md](../../../projects/forge-plugin/spec/standards.md) |
| Templates — workflow templates and CLAUDE.md template design | [project: templates.md](../../../projects/forge-plugin/spec/templates.md) |
| Integrations — git metadata, Jira, DataDog, GitHub Actions | [project: integrations.md](../../../projects/forge-plugin/spec/integrations.md) |
| Distribution — plugin marketplace model, package architecture | [project: distribution.md](../../../projects/forge-plugin/spec/distribution.md) |
| Repository layout — marketplace.json, plugin structure | [project: repository-layout.md](../../../projects/forge-plugin/spec/repository-layout.md) |
| Architectural decisions — ADR-001 through ADR-029 | [arch-decisions/README.md](arch-decisions/README.md) |
| forge:update skill design — flow, manifest format, multi-version algorithm, idempotency, rollback | [skills.md](skills.md) |

---

## forge:update Design

### Overview

This epic delivers one skill and one static artifact type: the `forge:update` skill
and the migration manifest format that makes it extensible.

`forge:update` is the configuration migration skill that brings a repository's
committed Forge configuration — directory structure, CLAUDE.md, and `.state.json`
schemas — up to date with the currently active Forge plugin version.

It is always the third step in the version upgrade sequence:

```
1. forge:pin --version <new-version>   ← change the version pin (forge:pin)
2. /plugin install forge@forge-local   ← fetch the new plugin version into cache
3. forge:update                        ← migrate committed repo files to match
```

For unpinned repositories, steps 1–2 are replaced by updating the globally installed
plugin, and `forge:update` is run afterward.

### Deliverables

| Artifact | Type | Scope |
|----------|------|-------|
| `forge:update` | Skill (SKILL.md) | Interactive, invoked in engineer session |
| `plugins/forge/migrations/<from>-to-<to>.json` | Migration manifest | Static; bundled in plugin cache; read by forge:update |

The migration manifest format is the mechanism by which future Forge releases declare
what structural changes `forge:update` must apply. Without a specified format, the
skill would require changes every time a new version introduced new migrations.

### Architecture

```
Engineer session
│
├── .forge/version               ← source of truth: what version last configured this repo
├── .claude-plugin/marketplace.json  ← source of truth: what version to migrate to (pinned)
│
└── forge:update
    │
    ├── Step 1: Read current_version from .forge/version active_version
    ├── Step 2: Resolve target_version from pin or installed cache
    ├── Step 3: Discover plugin_root from cache
    ├── Step 4: Classify MAJOR vs MINOR/PATCH
    ├── Step 5: Check active work items (MAJOR only)
    ├── Step 6: Discover and sequence migration manifests
    │           plugin_root/migrations/<from>-to-<to>.json (for each version step)
    ├── Step 7: Pre-migration report and confirmation
    ├── Step 8: Snapshot for rollback
    ├── Step 9: Apply migrations (manifests in sequence, then version record last)
    │   ├── 9.N.1  create-dir
    │   ├── 9.N.2  rename
    │   ├── 9.N.3  state-field
    │   ├── 9.N.4  claude-md refresh
    │   └── (repeat for each manifest N)
    └── Step 10: Update .forge/version (terminal — signals migration complete)
```

### Key Design Decisions

**Version record updated last.** The `.forge/version` update is the final operation.
An updated version record is the commit of record that migration completed. If the
skill fails mid-migration, the version record still reflects the prior version, and
re-running will re-apply from the start. Individual operations are idempotent, so
already-applied steps are skipped on re-run.

**Sequential manifest application.** When migrating across multiple versions (e.g.,
v1 → v3), each manifest is applied in order (v1→v2, then v2→v3) rather than
constructing a combined plan. Each manifest executes against a known intermediate
state. A synthesized combined plan risks producing an incorrect end state that cannot
be mechanically verified.

**Manifests are declarative.** Migration manifests enumerate operations using a small,
fixed set of operation types. The skill applies them mechanically — no reasoning about
what each operation means, only whether the idempotency pre-check passes. This keeps
migration application deterministic regardless of the migration content.
