← [Decisions Index](README.md)

# ADR-016: Plugin-Based Distribution — Forge Plugin Bundles Skills and Standards

**Status:** Accepted
**Date:** 2026-03-05
**Revised:** 2026-03-08

## Context

ADR-011 established git submodule as the distribution mechanism. The submodule model
provides correct technical properties: co-versioning by construction (skills and standards
always ship from one commit), per-project version pinning, and no external infrastructure.

Two problems emerged during requirements analysis (BR-15, BR-16):

**The bootstrapping problem.** In the submodule model, `forge:update` is installed by
`setup.sh`, which runs inside the submodule. On a fresh clone, the submodule must be
initialized before `forge:update` exists. This requires `git clone --recurse-submodules`
— an extra step developers routinely forget — or a manual `git submodule update --init`
after the fact. There is no way to guide developers through this step using Forge tooling
because Forge tooling doesn't exist yet.

**Submodule DX.** Git submodules are notoriously difficult to work with: detached HEAD
state inside the submodule, pin-advance commits polluting project history, CI pipelines
requiring explicit submodule init steps. These are not hypothetical — they are documented,
recurring friction in every organization that uses submodules. The submodule operations
can be wrapped in forge commands, but the underlying complexity leaks whenever something
goes wrong.

A GitHub Releases download model (gitignored `plugins/rr-standards/`, version spec file
committed) was considered as an intermediate step. It eliminates submodule DX but
recreates the bootstrapping problem: `forge:update` must be available to download
rr-standards, but `forge:update` lives inside rr-standards. The circular dependency
is the same; the surface has moved.

The resolution reached through implementation: use Claude Code's native plugin model
as the single delivery mechanism and bundle standards content inside the plugin.

## Decision

Distribution uses the Claude Code plugin system as a single delivery mechanism:

**Plugin installation (per-developer, once):**
The forge plugin is installed at the user level (`~/.claude/settings.json`) as part
of developer onboarding. Installing the plugin makes all skills in the plugin available
immediately — no per-skill installation step. Skills are namespaced automatically
(`forge:<skill>`, `rr-standards:<skill>`). The plugin bundles:

- All forge workflow skills (`forge:init`, `forge:review`, etc.)
- All rr-standards authoring and quality skills (`rr-standards:author`,
  `rr-standards:validate`, `rr-standards:coverage`, `rr-standards:review`)
- Standards documents and language guides under `plugins/forge/standards/` and
  `plugins/forge/languages/` within the plugin directory tree
- Hook scripts

The plugin is installed and updated through Claude Code's standard plugin management.
There is no separate GitHub Releases tarball, no `plugins/rr-standards/` download directory,
and no `rr-standards-version` tracking file.

**`forge:init` — project structure setup (per-project, run once):**
`forge:init` initializes a project for Forge use. Its role is project configuration,
not content delivery. It:
- Creates the `.forge/` directory structure in the project
- Writes a `CLAUDE.md` template committing the project to Forge standards
- Registers hook scripts in `.claude/settings.json` (pointing to the plugin-installed
  hook paths)
- Does NOT download or install rr-standards content — content is already available
  via the installed plugin

Because the plugin is installed at the user level before `forge:init` is ever run,
the bootstrapping problem does not arise. `forge:init` is always available when a
developer has set up their environment.

**Standards authorship:**
The root-level `standards/` and `languages/` directories in this repository are legacy
artifacts. New conformant standards and language guides are authored using the
`rr-standards:author` skill and placed under `plugins/forge/standards/` and `plugins/forge/languages/`
respectively. The rr-standards skills are the authoring tools; the plugin bundle is
the delivery vehicle.

**Semantic versioning on the forge plugin:**
The plugin uses semantic version tags. Breaking changes (hook exit code changes, skill
output format changes, schema changes) increment the major version. Additive changes
(new skills, new standards, documentation) increment minor or patch. Plugin updates
are managed through Claude Code's plugin update mechanism.

## Consequences

**Positive:**
- Bootstrapping problem solved: skills are always available once the plugin is installed;
  `forge:init` has nothing to bootstrap because the plugin is already present
- No git submodule DX: no `--recurse-submodules`, no detached HEAD, no manual init steps
- No download step on clone: a fresh project clone works immediately once the developer
  has the plugin installed; there is nothing to run after `git clone`
- Co-versioning by construction: skills, standards documents, hooks, and templates all
  ship from one plugin version; cross-deployable consistency is guaranteed
- Single installation unit: one `claude install-plugin forge` during developer onboarding;
  no per-project content management
- Works for all language ecosystems — no Node.js or language-specific package manager
  required; the plugin is pure text (markdown skill files and shell hooks)
- Separation of concerns: project structure (committed) is set up by `forge:init`;
  skill and standards content (user-level, not committed) comes from the plugin

**Negative:**
- Plugin updates are managed by developers individually; there is no per-project
  `rr-standards-version` pin that can enforce a specific version across the team
- Teams must coordinate plugin version expectations informally (e.g., via onboarding
  docs) rather than through a committed version spec
- The plugin bundle grows as more standards and language guides are added; this is a
  natural consequence of bundling content, and is bounded by the number of standards

## Alternatives Considered

**Git submodule (ADR-011, superseded):** Correct co-versioning properties but poor DX
and the circular bootstrapping dependency — `forge:update` requires the submodule, but
the submodule requires initialization that Forge cannot assist with.

**GitHub Releases download with global plugin:** The model described in the initial
ADR-016 draft. Eliminated submodule DX but required a separate download step on every
fresh clone, `rr-standards-version` tracking, and `plugins/rr-standards/` gitignore management.
Superseded by bundling content directly in the plugin.

**npm package:** Good DX for JS projects; wrong tool for a multi-language organization
(Go, Swift, Java, Python). Would require Node.js in all consuming projects regardless
of technology stack.

**Commit `plugins/rr-standards/` directly (no submodule, no gitignore):** Eliminates all
bootstrapping and DX problems. Rejected because every plugin update creates large diffs
in project history, and the committed directory grows with every new standard and skill.
