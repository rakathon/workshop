# ADR-030: Atlassian MCP Bundled with the Forge Plugin

**Status:** Accepted
**Date:** 2026-04-02

## Context

`forge:extract --confluence <url>` requires authenticated access to Confluence to
read PM documents. Confluence rejects unauthenticated requests, so plain HTTP
fetching (WebFetch) does not work for private pages. The skill needs a way to
authenticate with Confluence without requiring per-engineer credential plumbing
at the point of invocation.

Claude Code supports MCP (Model Context Protocol) servers. Plugins can bundle
MCP server declarations via a `.mcp.json` file at the plugin root. When the plugin
is installed, declared MCP servers are automatically available in every session
where the plugin is active — no separate installation step required by the engineer.

Two Atlassian MCP server options exist:

- **atlassian/atlassian-mcp-server** (official) — Cloud-only, OAuth 2.1, requires
  an Atlassian Rovo subscription
- **sooperset/mcp-atlassian** (community) — Cloud + Data Center/Server, API token
  authentication, no subscription required, 4.8k stars, actively maintained

## Decision

The Forge plugin bundles `sooperset/mcp-atlassian` as a declared MCP server via
`plugins/forge/.mcp.json`. The server is named `atlassian` in the declaration.
It runs as a stdio process via `uvx mcp-atlassian` — no separate install step
required beyond having `uv` / Python available.

Engineers configure the server once by setting three environment variables in their
shell profile:

```
CONFLUENCE_URL=https://your-org.atlassian.net/wiki
CONFLUENCE_USERNAME=your-email@example.com
CONFLUENCE_API_TOKEN=your-api-token
```

If these variables are unset, the MCP server fails to start at session open. Skills
that depend on Confluence access (`forge:extract --confluence`) check for the MCP
tool at invocation time and surface a setup message if it is unavailable.

`forge:init` is responsible for detecting missing credentials at setup time and
guiding engineers through the configuration. See the forge-init capability spec for
the pending enhancement.

## Alternatives Considered

**Official Atlassian Rovo MCP:** Rejected as the primary option because it requires
an Atlassian Rovo subscription that not all teams have, and it is Cloud-only —
teams on Atlassian Data Center or Server are excluded. It remains a viable option
for teams that have Rovo; the `.mcp.json` declaration could be extended to support
both servers in future.

**curl with environment variables:** Viable but requires per-engineer credential
setup without the MCP's tool abstraction. Skills would need to call Bash directly
with auth headers rather than using a named MCP tool. More fragile; harder to
extend to Jira or other Atlassian products in future.

**Require engineers to install mcp-atlassian separately:** More explicit but adds
friction. The plugin bundling model exists precisely to eliminate this class of
per-project setup step.

**No Confluence support:** Rejected. Confluence is the organization's standard
PM documentation platform. Requiring engineers to export pages before running
`forge:extract` adds a manual step that reduces adoption.

## Consequences

- Engineers install the Forge plugin once and get Confluence MCP support without a
  separate install step, provided `uv` is available (already required for other
  Python-based tooling).
- One-time credential setup (`CONFLUENCE_URL`, `CONFLUENCE_USERNAME`,
  `CONFLUENCE_API_TOKEN`) is required per engineer. `forge:init` surfaces this
  during repository setup.
- Tools exposed by the server are namespaced as `mcp__atlassian__<tool-name>` in
  Claude Code sessions (e.g., `mcp__atlassian__confluence_get_page`).
- The community dependency (`sooperset/mcp-atlassian`) is not maintained by
  Atlassian. If it becomes unmaintained, migration to the official Rovo MCP or
  a direct API approach is the fallback path.
- This `.mcp.json` pattern can be extended for other Forge MCP dependencies
  (e.g., DataDog MCP for `forge:diagnose`) without changing the plugin installation
  model.
