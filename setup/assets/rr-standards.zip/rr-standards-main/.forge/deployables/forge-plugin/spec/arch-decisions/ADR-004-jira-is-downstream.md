← [Decisions Index](README.md)

# ADR-004: Jira Is Downstream, Not Co-Equal

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Most engineering teams use Jira as a shared source of work status visible to PMs, scrum masters, and managers. Jira tickets are frequently edited by non-engineers. If Jira were treated as the authoritative state store for workflow, external edits — status changes, field updates, description rewrites — could corrupt the workflow state that skills depend on. At the same time, ignoring Jira entirely creates a split view of reality that erodes trust in both systems.

## Decision

The repository is authoritative. Jira receives updates from the repository. When they conflict, the repository wins unless the engineer explicitly overrides this.

## Consequences

**Positive:**
- Repository state is only edited by engineers working on the capability, making it a controlled and verifiable source of truth
- External Jira edits by non-engineers cannot corrupt workflow state
- The unidirectional data flow (repository → Jira) is simple to reason about and implement
- Repository state is auditable via git history; Jira edits are not

**Negative:**
- Engineers who rely on Jira as their primary view of work status must understand that the Jira view may lag repository state and may be overwritten
- Teams that use Jira as a communication layer (comments, status changes by non-engineers as decisions) must establish a different communication channel for those purposes
