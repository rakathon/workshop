← [Decisions Index](README.md)

# ADR-015: Analytical Skills Run as Isolated Sub-Agents to Prevent Context Pollution

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Several skills must read large volumes of external data before producing their output: PR review reads full file diffs that may span hundreds of files; log analysis reads multi-thousand-line DataDog exports; document ingestion reads large PM documents. If these skills run in the engineer's main Claude Code session, their input data remains in the session's context window after the skill completes. This residual context can bias subsequent code generation, inflate the context window to the point of quality degradation, and surface irrelevant information in unrelated operations. The skills also represent a natural parallelism opportunity — when a diff is large, multiple independent analyses can run concurrently.

## Decision

Forge skills are classified as either orchestrators (running in the main Claude Code session) or workers (running as isolated sub-agents via the Task tool with fresh context windows). The classification is declared in each skill's SKILL.md frontmatter (`agent-type: orchestrator | worker`). Orchestrating skills construct a context packet (input paths, standards paths, output schema, work-id), spawn the worker via the Task tool, receive the structured result, write it to the appropriate artifact path, and update `.state.json`. When `forge:review` encounters a diff exceeding a configurable line threshold (default: 300 lines), the orchestrating skill partitions the changed files into groups and spawns one worker per group concurrently.

## Consequences

**Positive:**
- Worker context windows are scoped to exactly the inputs they need and are discarded when the worker completes, preventing context pollution in the engineer's session
- Large inputs can be processed in parallel by multiple workers, reducing total elapsed time
- The classification is declared once per skill in SKILL.md frontmatter, not decided per-invocation
- Orchestrator skills stay concise — they coordinate, they do not analyze

**Negative:**
- Spawning a sub-agent has non-zero latency overhead compared to running inline — for short, targeted operations this overhead is not justified (which is why they remain as orchestrators)
- The context packet assembly adds implementation overhead to each orchestrating skill
- Debugging a failed worker requires inspecting the context packet it received, which is not as straightforward as debugging an inline operation
