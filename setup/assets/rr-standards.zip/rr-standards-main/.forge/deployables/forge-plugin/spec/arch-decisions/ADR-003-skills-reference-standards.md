← [Decisions Index](README.md)

# ADR-003: Skills Reference Standards, Never Embed Rules

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Skills need to apply standards when generating or reviewing code. The rules those standards encode — naming conventions, error handling patterns, API design requirements — could either be embedded directly in the skill's SKILL.md or referenced from a separate standards file. If rules are embedded, updating a standard means updating every skill that applies it, and the same rule may drift across copies. Engineers who want to apply a standard without invoking a skill have no canonical source to consult.

## Decision

A skill's SKILL.md instructs Claude to load and apply a specific standards file. The rules themselves live in the standards file.

## Consequences

**Positive:**
- Single source of truth — a standard is updated once and every referencing skill benefits immediately
- Standards are usable without skills; engineers can read and apply them directly
- Skill files stay concise — they describe process, not rules
- Reduces risk of rule drift across multiple skill files

**Negative:**
- Skills require the standards files to be present at the expected path — a missing or moved standards file breaks the skill
- The skill must handle the case where the standards file is not found and surface a clear error rather than silently proceeding without the rules
