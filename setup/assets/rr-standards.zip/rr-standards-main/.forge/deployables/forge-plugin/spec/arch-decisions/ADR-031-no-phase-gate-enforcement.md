# ADR-031: No Phase Gate Enforcement in Forge v1

**Status:** Accepted — Supersedes ADR-007
**Date:** 2026-04-03

## Context

ADR-007 established a single pre-implementation gate: discovery must be approved
before implementation can begin, enforced by a PreToolUse hook that blocks writes
to source code until `.state.json` shows `phases.discovery.status = "approved"`.

In practice, engineering work is not linear. New requirements surface mid-sprint.
A design flaw found during implementation requires updating the spec. A plan needs
a new task added after approval. A framework that forces engineers to "reopen" a
phase via a special skill, satisfy a gate check, and re-approve before they can
edit a Markdown file creates friction disproportionate to the benefit — especially
for a framework that is not yet in production and has no established user base to
protect from breaking changes.

Additionally, the `forge:reopen` skill (designed as the gate-bypass mechanism)
adds workflow complexity that engineers are unlikely to reach for intuitively.

## Decision

Forge v1 does not enforce phase gates. Artifacts in `requirements/`, `spec/`, and
`plan/` are always writable regardless of `.state.json` phase status. The PreToolUse
hook that blocked writes based on phase state is removed.

Phases and their statuses are retained as **tracking and communication tools**, not
enforcement mechanisms:

- `forge:promote` still records that a phase is approved and advances `currentPhase`.
  This gives the team a shared, machine-readable record of where the effort stands.
- Phase status is visible in `forge:status` and `.forge/efforts/README.md`.
- `currentPhase` advances on promotion but does not go backwards — an effort in
  `implementation` can still have its `requirements/` or `spec/` edited freely.

`forge:reopen` is removed from the framework entirely. There is nothing to unlock.

## Alternatives Considered

**Keep phase gates with a lighter-weight bypass:** Reduce the "reopen" ritual to a
single command with no confirmation. Rejected because the underlying problem is not
the ritual — it is that blocking writes at all is the wrong model for a framework
used by teams actively discovering requirements through implementation.

**Keep enforcement but make it opt-in per effort:** Allow teams to enable strict
phase gates if they want them. Rejected for v1 — premature configurability adds
complexity without demonstrated demand. If enforcement proves valuable, it can be
added as an opt-in in a future major version.

## Consequences

- `forge:reopen` is removed. No replacement is needed.
- The PreToolUse phase gate enforcement hook is removed from `forge:init`.
- `forge:promote` changes from a gate enforcer to a tracking/checkpoint tool.
  Its readiness checks become advisory: they surface what is missing or incomplete,
  but the engineer decides whether to proceed regardless.
- Engineers can edit requirements, specs, and plans at any point in the effort
  lifecycle without ceremony. The phase record in `.state.json` reflects intent
  and progress, not a locked state.
- If gate enforcement becomes necessary in a future version (e.g., for compliance
  or multi-team coordination), the phase model is already in place and enforcement
  can be layered on top without a data model change.
