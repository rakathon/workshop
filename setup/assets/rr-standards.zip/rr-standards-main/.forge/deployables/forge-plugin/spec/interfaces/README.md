# Forge Framework — Published Interfaces

Interfaces published by the Forge framework that other products and consumers
depend on. These are the stable contracts that downstream consumers reference.

## Skills (Claude Code Skill Interface)

Skills are the primary interface of the Forge framework. Each skill is defined by
a `SKILL.md` file and invoked via Claude Code's `/skill-name` syntax.

| Skill | Location | Status |
|-------|----------|--------|
| `forge:review` | `plugins/forge/skills/review/` | Planned |
| `forge:init` | `plugins/forge/skills/init/` | Implemented |
| `forge:pin` | `plugins/forge/skills/pin/` | Planned |
| `forge:update` | `plugins/forge/skills/update/` | Planned |
| `forge:pause` | `plugins/forge/skills/pause/` | Planned |
| `forge:resume` | `plugins/forge/skills/resume/` | Planned |
| `forge:product` | `plugins/forge/skills/product/` | Planned |
| `forge:product-update` | `plugins/forge/skills/product-update/` | Planned |

## Hooks (Claude Code Hook Interface)

Hooks are shell scripts bundled in the plugin cache and registered by path in
`.claude/settings.json`. They are not copied into the project.

| Hook | Trigger | Scope | Status |
|------|---------|-------|--------|
| `inject-generation-standards.sh` | PreToolUse (Write/Edit) | Project | Implemented |
| `forge-version-check.sh` | SessionStart | User (global) | Implemented |

## State Schema

The `.forge/` directory structure and `.state.json` schema are a published interface
consumed by all skills, hooks, and CI integrations. Schema changes that alter or
remove existing fields are breaking changes.

Schema documentation: [`.forge/efforts/forge-plugin/spec/workflow.md`](../../../../projects/forge-plugin/spec/workflow.md)

## Review Output Schema

The structured JSON output format produced by `forge:review` and consumed by GitHub
Actions, audit tooling, and the metrics database.

Schema documentation: [`.forge/efforts/forge-plugin/spec/review-output-schema.md`](../../../../projects/forge-plugin/spec/review-output-schema.md)
