← [Decisions Index](README.md)

# ADR-028: Capabilities Are Bounded Capabilities Within Deployables

**Status:** Accepted
**Date:** 2026-03-18

## Context

ADR-025 (superseded by ADR-029) established the deployable as the unit of canonical
documentation in the Forge framework. Each deployable has a directory at
`.forge/deployables/<deployable-name>/` containing its requirements, design, interfaces,
security policy, deployment configuration, and runbook.

As a deployable grows — particularly a platform deployable like `forge-plugin` that delivers
many distinct skills and agents — the deployable directory absorbs the requirements and
design for all of those capabilities simultaneously. A deployable with twenty skills has
requirements documents that cover all twenty, design documents covering all twenty, and
test strategies covering all twenty. These documents become large, harder to navigate,
and harder to reason about in isolation.

The root cause is that ADR-025 defines only one canonical entity — the deployable — and
does not distinguish between deployable-level concerns (deployment, security posture,
operational runbooks, overall architecture) and capability-level concerns (the
requirements, design, and tests for a specific skill or agent within the deployable).

A cleaner definition: a **deployable** is something that is independently deployable and
has operational concerns — a version, a runbook, a security posture, a deployment
configuration. A **capability** is a bounded, independently implementable and testable
capability within a deployable — it has its own requirements, design, and tests, but it
is not independently deployable; it ships as part of its deployable.

## Decision

### 1. Capabilities are a named entity type within a deployable

A capability is a capability within a deployable that meets all of the following criteria:
- It has its own requirements (what it must do)
- It has its own design (how it is structured)
- It has its own tests (how it is verified in isolation)
- It can be implemented and tested independently of other capabilities in the deployable

Not every capability within a deployable needs to be a named capability. A capability directory
is warranted when a capability is complex enough to have meaningful standalone
requirements and design, and when it is useful to reason about its correctness
independently. Simple, tightly-coupled capabilities that have no standalone testability
are documented at the deployable level.

### 2. Capabilities live under their deployable's canonical directory

Each capability has a directory at `.forge/deployables/<deployable-name>/capabilities/<capability-name>/`
with the following structure:

```
.forge/deployables/<deployable-name>/
├── requirements/              # deployable-level requirements
├── spec/                    # deployable architecture, ADRs, interfaces
├── test-strategy.md           # deployable-level test strategy
├── security.md                # deployable security posture
├── deployment.md              # how the deployable ships
├── runbook/                   # operational procedures
└── capabilities/
    ├── README.md              # capability registry: one row per capability
    └── <capability-name>/
        ├── requirements/
        │   ├── business.md    # what this capability must do and why
        │   └── technical.md   # NFRs, constraints, integration points
        ├── spec/
        │   ├── README.md      # capability design overview
        │   └── arch-decisions/ # ADRs scoped to this capability
        └── test-strategy.md   # how to verify this capability in isolation
```

Capabilities do not have runbooks, security policies, or deployment configurations —
those are deployable-level concerns. A capability that introduces a meaningful security
implication contributes to the deployable's `security.md`; it does not own one.

### 3. Deployable-level documents cover cross-capability concerns

The deployable's `requirements/`, `spec/`, and `test-strategy.md` cover:
- Requirements that span multiple capabilities or cannot be attributed to a single capability
- The overall architecture and how capabilities compose
- Integration test strategy across capabilities
- Security, privacy, and operational concerns

They do not replicate the detail already captured in capability directories.

### 4. Work items reference both deployable and capability

The `deployables` field in `.state.json` identifies which deployables a work item
contributes to. A companion `capabilities` field identifies the specific capabilities within
those deployables:

```json
"deployables": ["forge-plugin"],
"capabilities": ["forge-plugin/forge-review"]
```

The capability reference uses `<deployable-name>/<capability-name>` to be unambiguous when a
work item touches capabilities across multiple deployables. A work item that touches only
deployable-level concerns (no specific capability) leaves `capabilities: []`.

### 5. Test plans belong to capabilities, not to work items

Test strategies and test plans are canonical capability artifacts, not work item artifacts.
Work items are delivery vehicles; they deliver code that implements requirements. You do
not test a project — you test a capability.

Test strategy is authored directly in the capability's canonical directory
(`.forge/deployables/<name>/capabilities/<capability>/test-strategy.md`) during the discovery
phase of the work item that creates or modifies the capability. It is a living document
maintained in the deployable/capability space for as long as the capability exists.

`spec/test-strategy.md` is not a valid work item artifact. Design validation reads
the test strategy from the capability canonical path, derived from the work item's
`capabilities[]` field.

For work items that contribute to deployable-level concerns spanning multiple capabilities
(or no specific capability), the deployable-level `test-strategy.md` at
`.forge/deployables/<name>/test-strategy.md` serves the same role.

### 6. Capabilities are defined during discovery, not at deployable creation

`forge:init` does not pre-populate capability directories. Capabilities are identified and
created during the discovery phase of the work items that deliver them, following the
same principle as deployable directories (ADR-029 §2): "Deployables are added explicitly by
developers, not inferred from the codebase."

## Alternatives Considered

**Sub-deployables** — treating each capability as a nested deployable with its own runbook,
security policy, and deployment configuration. Rejected because most capabilities
within a platform deployable do not have independent operational concerns. Calling
`forge:init` a sub-deployable would require it to have a runbook and a security policy,
which is not meaningful — those concerns belong to `forge-plugin` as a whole.

**Flat additional deployable directories** — creating `.forge/deployables/forge-init/`,
`.forge/deployables/forge-review/` etc. as peer deployables rather than capabilities of
`forge-plugin`. Rejected because it misrepresents the deployment and operational
model: these capabilities are not independently deployable, and they share a version
lifecycle with `forge-plugin`. Treating them as peer deployables would require defining
interfaces between them that are better understood as internal composition.

**No structural separation** — keeping all capability detail in the deployable directory,
relying on the file→directory expansion rule (500-line limit) to manage size. Rejected
because expansion handles document size, not separation of concerns. A deployable
directory containing the requirements and design for twenty skills is hard to navigate
regardless of how the files are split.

## Consequences

**Positive:**
- Deployable-level documents remain focused on deployable-wide concerns; capabilities absorb
  the complexity of individual capabilities without polluting the deployable-level view
- Large platform deployables scale naturally: each new skill or agent that meets the
  capability criteria gets its own directory without restructuring anything else
- Traceability improves: a work item can reference both the deployable it contributes to
  and the specific capability it delivers, making it navigable from either direction
- The capability is independently reviewable: a PR delivering `forge:review` can be
  validated against `capabilities/forge-review/requirements/` without reading the full
  deployable requirements

**Negative / Watch:**
- Adds a new entity type — engineers must understand the deployable/capability distinction
  and the criteria for when a capability warrants a capability directory
- The boundary is a judgment call: a guiding principle (the three criteria in §1) is
  provided, but edge cases will arise and need to be resolved consistently
- Existing deployables need their capability structure defined retrospectively as work items
  are delivered; partially-populated capability directories are expected during the
  transition period
