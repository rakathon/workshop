← [Decisions Index](README.md)

# ADR-023: Work Item Hierarchy Is Modeled in State, Not Directory Structure

**Status:** Accepted
**Date:** 2026-03-05

## Context

The projects directory is flat: `.forge/efforts/<work-id>/`. The original type enum (`initiative | epic | story | task`) had no concept of a level above initiative. When planning Forge itself — a large, multi-quarter endeavor containing seven initiatives and twenty-plus epics — the flat model produced a registry of siblings with no discernible structure. There was no way for engineers, agents, or the registry to understand that `epic-ai-pr-review` belonged to `initiative-code-review`, which belonged to `forge-plugin`.

Two structural options were available: nest directories (creating `.forge/efforts/<program>/<initiative>/<epic>/`) or model the hierarchy in state and surface it in the registry while keeping the directory flat.

## Decision

Add `program` to the type enum, making the full hierarchy: `program | initiative | epic | story | task`. Programs undergo the same full-tier workflow as initiatives.

Add `parentId` and `childIds` to `.state.json`. The parent-child relationship lives in the data model. The projects directory remains flat — all work items are siblings in `.forge/efforts/`. No nested directories are introduced.

Extend the `.forge/efforts/README.md` registry format to display items grouped under their parent, using indentation to show depth. The registry is the structural view; the filesystem is not.

## Consequences

**Positive:**
- Supports arbitrarily large programs without restructuring the directory layout or breaking the uniform `.forge/efforts/<id>/` contract
- Parent-child relationships are machine-readable — skills and hooks can navigate the hierarchy without parsing directory paths
- The registry remains the single entry point for both humans and agents; no directory traversal is needed to understand structure
- Flat directories stay easy to navigate directly

**Negative:**
- `childIds` must be kept in sync — adding a new child work item requires updating the parent's `.state.json`. This is a `forge:effort` responsibility, not a manual one, but the coupling exists
- A stale or hand-edited registry can misrepresent hierarchy; tooling (`forge:effort`, `forge:promote`, `plan/update`) must maintain it accurately

## Alternatives Considered

**Nested directories** (`.forge/efforts/<program>/<initiative>/<epic>/`): Expressive but breaks the uniform `.forge/efforts/<id>/` contract. Skills and hooks that reference `.forge/efforts/<id>/` would need path-depth awareness. Navigation becomes harder as nesting grows. Rejected.

**Module-level grouping** (as used in the monolithic app pattern): Groups items in subdirectories but does not express parent-child relationships — it is a namespace, not a hierarchy. `.forge/efforts/payments/PROJ-1234/` does not imply PROJ-1234 is a *child* of payments, only that it belongs to that module. Insufficient for this use case.
