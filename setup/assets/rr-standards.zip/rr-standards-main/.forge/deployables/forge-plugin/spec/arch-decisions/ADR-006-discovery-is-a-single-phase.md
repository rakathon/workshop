← [Decisions Index](README.md)

# ADR-006: Discovery Is a Single Phase, Not Two Sequential Phases

**Status:** Accepted  
**Date:** 2026-03-03

## Context

High-level development work involves both requirements gathering (what must the system do?) and design (how will it do it?). A natural instinct is to model these as sequential phases with a gate between them: requirements must be approved before design begins. In practice, this formalism breaks down because the two activities are co-evolutionary — writing an API contract reveals missing requirements, and designing a storage schema reveals conflicting constraints. Sequential phases with a gate between them produce one of two failure modes: engineers mark requirements "approved" prematurely to unblock design, or they abandon the framework entirely on complex work where discovery is most valuable.

## Decision

Requirements and design are treated as a single co-evolutionary Discovery phase rather than two sequential phases with a gate between them. The phase produces two artifact sets (`requirements/` and `spec/`) that are approved together. There is no gate between them.

## Consequences

**Positive:**
- Models how discovery actually works, reducing the incentive to game the process with premature approvals
- Keeps the gate count minimal — one approval for the full discovery artifact set
- Requirements and design are reviewed in context of each other, which is the only meaningful way to assess their correctness
- Engineers can iterate between requirements and design artifacts freely within the phase

**Negative:**
- Approving discovery requires the reviewer to assess both artifact sets together, which is a larger review surface than approving them sequentially
- The combined artifact set may be harder to review incrementally on large initiatives
