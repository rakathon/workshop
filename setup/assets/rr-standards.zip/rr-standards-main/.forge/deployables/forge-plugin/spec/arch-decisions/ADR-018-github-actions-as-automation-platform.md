← [Decisions Index](README.md)

# ADR-018: GitHub Actions Is the Deployment Orchestration and Automation Platform

**Status:** Accepted
**Date:** 2026-03-05

## Context

Several Forge capabilities must run outside interactive engineer sessions: PR review
must run on every pull request without engineer invocation; rollout monitoring must run
continuously during a staged deployment; incident diagnosis must run in response to
production alerts. These capabilities need a platform that can trigger on repository
events (PR opened, deployment completed), run Claude in non-interactive mode, and
interact with GitHub APIs (PR status checks, branch protection, CODEOWNERS). The
organization already uses GitHub as its version control platform.

## Decision

GitHub Actions is the automation platform for all Forge capabilities that run outside
interactive sessions. `forge:review` runs as a GitHub Actions workflow triggered on pull
request events. Rollout monitoring and incident diagnosis run as GitHub Actions workflows
triggered by deployment events. Claude runs in non-interactive (`--print`) mode within
these workflows. The resulting signals (AI approval, rollback recommendation, incident
diagnosis) are written back to GitHub as PR status checks, deployment logs, or issue
comments.

## Consequences

**Positive:**
- No additional CI/CD infrastructure to operate; the organization already uses GitHub Actions
- GitHub Actions has native integration with pull request events, branch protection, and
  CODEOWNERS — which are the enforcement mechanisms for the approval policy
- Non-interactive Claude in GitHub Actions is the same model as ADR-005; no new execution
  model is required
- Secrets management (Anthropic API key, Jira credentials, DataDog credentials) is handled
  by GitHub Actions secrets, which the organization already manages

**Negative:**
- GitHub Actions has per-workflow and per-organization concurrency limits; high PR volume
  could cause queuing delays in `forge:review` runs
- GitHub Actions billing is consumption-based; per-invocation cost ceilings for sub-agents
  must be enforced at the skill level, not at the platform level
- Teams not using GitHub as their repository host cannot use these workflows; this is an
  accepted constraint given the organization's GitHub standardization
