← [Decisions Index](README.md)

# ADR-019: Brownfield Codebase Context Is Produced Once and Stored in docs/codebase/

**Status:** Accepted
**Date:** 2026-03-05

## Context

AI agents implementing capabilities in an existing codebase need structured knowledge of
that codebase's technology stack, architectural patterns, naming conventions, existing
integrations, and areas of known concern. Without this context, agents apply
organizational standards without regard for existing patterns, producing code that is
standards-compliant but inconsistent with the codebase. This context could be produced
on demand by each skill (re-reading the codebase each invocation), stored per-work-item
under `.forge/efforts/<id>/`, or produced once and stored at the project level for reuse
across all work items.

## Decision

`forge:map` produces a structured codebase profile and stores it in `docs/codebase/`
as five documents: `STACK.md`, `ARCHITECTURE.md`, `CONVENTIONS.md`, `INTEGRATIONS.md`,
and `CONCERNS.md`. The profile is referenced from the project CLAUDE.md, making it
available to all subsequent skills without explicit invocation. The mapping is run once
at brownfield onboarding and updated when significant architectural changes occur.

## Consequences

**Positive:**
- Context is produced once and reused across all work items; no per-invocation codebase
  re-reading is required
- Storage in `docs/` makes the profile project-scoped and version-controlled alongside
  the code it describes
- Referencing the profile from CLAUDE.md makes it available in every session without
  requiring the engineer to explicitly load it
- The profile accumulates across the project lifetime and can be updated incrementally

**Negative:**
- The profile can become stale if significant architectural changes occur without triggering
  a `forge:map` update; staleness must be managed by team discipline and ADR cross-referencing
- Producing the initial profile for a large brownfield codebase is a significant upfront
  operation with non-trivial context window and cost requirements

## Alternatives Considered

**Per-work-item codebase context:** Would be fresh for each piece of work but would repeat
the cost of codebase analysis on every work item and produce inconsistent profiles across
concurrent work items.

**On-demand codebase reading per skill invocation:** No upfront cost, but each skill
invocation would need to decide what to read, producing inconsistent coverage and
significant per-invocation overhead for large codebases.
