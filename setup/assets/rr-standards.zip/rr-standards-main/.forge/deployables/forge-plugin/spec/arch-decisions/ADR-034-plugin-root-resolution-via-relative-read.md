# ADR-034: Plugin Root Resolution via Relative Read

**Status:** Accepted
**Date:** 2026-04-26
**Updated:** 2026-04-28
**Effort:** forge-statusline (initial), forge-plugin-root-resolution (updated)
**Created by:** forge-statusline

---

## Context

Several skills need to locate plugin resources at runtime — templates, scripts, migration
manifests, and other files that ship inside the plugin cache. Two patterns existed:

1. **Relative Read** (`forge:init`): read `../../.claude-plugin/plugin.json` using the
   Read tool; note the absolute path the tool resolves to; strip the suffix to derive
   `plugin_root`. Self-anchoring — the relative path is always resolved relative to the
   loaded skill file, so it always points to the correct cached version.

2. **`find`-based search** (`forge:update`): scan `~/.claude/plugins/cache` for
   `plugin.json` files matching `*/forge/*`, then sort by semver to pick the highest.
   Fragile when multiple plugin versions are cached simultaneously, and has caused
   incorrect version selection in practice.

When adding a new skill (`forge:statusline`) that must locate a resource file in the
plugin cache at runtime, the question of which pattern to standardise became important.
Given that multiple skills will need this capability, it should be extracted into a
shared common fragment rather than re-implemented per skill.

---

## Decision

**Canonical plugin root resolution uses the relative Read pattern**, extracted into
`plugins/forge/skills/common/plugin-root.md` for reuse across all skills.

The algorithm:

1. Read `../../.claude-plugin/plugin.json` (relative to the skill's own directory) using
   the Read tool.
2. Note the absolute path the Read tool resolved to.
3. Derive `plugin_root` by stripping `/.claude-plugin/plugin.json` from the end of
   that path.

Skills reference this fragment with:
> Resolve the plugin root using:
> `plugins/forge/skills/common/plugin-root.md`

There are no exceptions. All skills — including `forge:update` and `forge:init` —
use the relative-read pattern. `forge:update` does not need to locate a *target*
version from the cache; it operates on the host repository's `.forge/` artifacts and
reads the currently running plugin version from the already-resolved `plugin_root`.

---

## Consequences

- Skills that need plugin resources read one file (relative) and get `plugin_root` for
  free — no shell commands, no version ambiguity.
- New skills that need the plugin root include the common fragment rather than
  implementing their own resolution.
- No skill may use `find ~/.claude/plugins/cache`, relative-path counting (`../../../../`),
  or any other ad-hoc mechanism to locate the plugin root.
- Skills operating as Worker sub-agents that receive `plugin_root` as an argument from
  their orchestrator do not need this fragment — they should use the passed value directly.
- All skills that reference `<plugin_root>` in a resource path must include an explicit
  resolution step that invokes `plugin-root.md` before any such reference appears.
- If the plugin manifest cannot be read, skills stop immediately with:
  > "The Forge plugin does not appear to be installed or the manifest is missing.
  > Try reinstalling the plugin."
  No fallback to `find` or any other discovery mechanism is permitted.
