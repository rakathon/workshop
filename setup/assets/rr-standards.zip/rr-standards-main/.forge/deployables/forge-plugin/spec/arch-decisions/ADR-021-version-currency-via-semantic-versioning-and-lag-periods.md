← [Decisions Index](README.md)

# ADR-021: Version Currency Is Enforced via Semantic Versioning with Lag Periods and Active-Work Protection

**Status:** Accepted
**Date:** 2026-03-05

## Context

BR-16 requires that all developers stay on a current version of the framework while
protecting engineers with active in-progress work from forced mid-task upgrades.
Updates cannot be pushed simultaneously to all teams, but stale versions undermine
the consistency guarantees the framework exists to provide. The rollout mechanism
must distinguish breaking from non-breaking changes, enforce a maximum lag period
after which updates become mandatory, and protect active work from disruption while
preventing indefinite deferral.

## Decision

The framework uses semantic versioning. Non-breaking changes (minor and patch versions)
are adopted silently at session start — the global plugin's session-start hook fetches
the latest compatible version and updates `plugins/rr-standards/` without requiring engineer
action. Breaking changes (major versions) require explicit engineer-initiated adoption:
the session-start hook emits a visible notice, and after a Productivity Engineering-defined
lag period (default: two full sprint cycles), the hook escalates to a blocking error that
prevents the session from proceeding until the upgrade is applied. An engineer with an
active work item in `in_progress` state is protected from forced major-version upgrades
until the current phase reaches a natural stopping point (phase completion or `forge:pause`
invocation). New projects always initialize on the latest major version. Productivity
Engineering publishes a changelog and enforcement deadline for every major release via
`VERSIONS.json` in the rr-standards repository.

## Consequences

**Positive:**
- Non-breaking improvements (new standards, new skills, documentation) are automatically
  distributed without requiring any engineer action
- Breaking changes are visible and time-bounded; engineers always know the enforcement
  deadline before they are blocked
- Active-work protection prevents mid-task disruption for breaking changes
- Productivity Engineering controls enforcement deadlines without requiring engineer
  involvement for non-breaking changes

**Negative:**
- Silent minor-version adoption means engineers may pick up new standards or skill
  behavior between sessions without an explicit notification; changelog review is
  recommended but not enforced for non-breaking changes
- Active-work protection can be gamed by keeping a work item perpetually `in_progress`;
  the lag period cap prevents indefinite deferral but does not prevent gaming within the lag window
- The session-start hook must fetch `VERSIONS.json` from the rr-standards source to
  check enforcement deadlines, which adds a network call at session start

## Alternatives Considered

**Uniform mandatory upgrades:** All developers must upgrade immediately when a new version
is released. Rejected because it disrupts active work and does not distinguish breaking
from non-breaking changes.

**Fully voluntary upgrades:** Engineers upgrade when they choose. Rejected because it
allows indefinitely stale versions, undermining the consistency guarantee the framework
provides.
