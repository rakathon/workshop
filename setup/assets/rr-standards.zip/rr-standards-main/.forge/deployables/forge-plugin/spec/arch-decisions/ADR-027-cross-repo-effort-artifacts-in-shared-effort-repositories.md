← [Decisions Index](README.md)

# ADR-027: Cross-Repository Effort Artifacts Are Hosted in Shared Effort Repositories

**Status:** Accepted
**Date:** 2026-03-18

## Context

BR-23 requires the framework to model projects that span multiple product repositories.
The technical requirements derived from BR-23 establish that project-level artifacts
(requirements, design) must exist at a scope independent of any single participating
product repository — a project spanning three repositories cannot have its top-level
documentation canonically inside any one of them.

This raises the question of where project-level artifacts live. The existing `.forge/`
structure (ADR-025) roots all canonical artifacts in the repository where the product
resides. For single-repository work, that is sufficient. For cross-repository projects,
a new hosting model is required.

A secondary constraint is that some projects must start private. A project may be
embargoed, commercially sensitive, or otherwise not ready for broad visibility at
inception. The hosting model must accommodate this without requiring a re-architecture
when the project becomes shareable.

## Decision

### 1. Cross-repository projects are hosted in shared effort repositories

A **effort repository** is a repository whose primary purpose is hosting project-level
artifacts: the business requirements, technical requirements, design, and plan for a
cross-repository initiative. Product repositories remain the authoritative home for
their own canonical product artifacts (per ADR-025); effort repositories hold only the
project-scoped artifacts that span those products.

Within a effort repository, each project lives under `.forge/efforts/<project-id>/`
following the existing work item artifact structure.

### 2. The framework supports any number of effort repositories

There is no assumption of a single global effort repository. The organization may
operate multiple effort repositories — divided by domain, team, security boundary, or
any other organizing principle. The framework treats any repository initialized as a
effort repository as a valid host.

### 3. Not every cross-repository project requires a dedicated repository

A project that spans repositories does not automatically require its own isolated
repository. The default is the shared effort repository. A dedicated repository is
warranted only when isolation is required (see point 4 below).

### 4. Projects that must start private may use a dedicated repository

A project that cannot be shared at inception — due to confidentiality, commercial
sensitivity, or staged disclosure — may be initialized in a project-specific private
repository. When the project is ready for broader visibility, its artifacts migrate to
the shared effort repository. The framework must not break traceability during this
migration; project IDs and cross-repository references established before migration
must remain valid after it.

## Alternatives Considered

**Each cross-repository project gets its own dedicated repository** — rejected because
it produces unbounded repository proliferation. Most projects do not require isolation,
and creating a repository per project imposes operational overhead (permissions,
discovery, archival) that outweighs any organizational benefit.

**Project artifacts live in one of the participating product repositories** — rejected
per the technical requirements derived from BR-23. Assigning canonical authority to one
participating repository creates an implicit ownership asymmetry and means that engineers
working in other participating repositories must go off-repo to read the project context
they depend on. The product repository is authoritative for what that product is; it is
not authoritative for a project that spans products it does not own.

**A single mandatory global effort repository** — rejected because it assumes a uniform
organizational structure that does not hold in practice. Teams may have legitimate reasons
to separate projects by domain, business unit, or security boundary. Mandating a single
repository would require policy exceptions to be modeled as framework deviations rather
than as configuration.

## Consequences

**Positive:**
- Project-level artifacts are co-located with other projects, making cross-project
  discovery and navigation natural within a shared repository
- Multiple effort repositories allow domain or security separation without requiring
  framework changes — the organizing boundary is a repository boundary, not a framework
  concept
- The dark-project pathway provides a governed, low-friction route from private inception
  to shared visibility; the framework does not treat embargoed work as a special case
  requiring workarounds
- Single-repository projects are unaffected; they continue using `.forge/efforts/`
  within their own repository with no change

**Negative / Watch:**
- Engineers working in a product repository cannot assume project context is co-located —
  they must know which effort repository hosts the project their work item belongs to;
  the framework must make this navigable (cross-repository reference resolution is a
  design responsibility, deferred to the multi-repo design phase)
- Migrating a project from a private repository to a shared effort repository is an
  operational step that must preserve all cross-repository references; the migration
  path is a design-phase concern and is not specified here
- Discovery of which effort repository hosts a given project is not self-evident; a
  convention or registration mechanism will be needed (deferred to design)
