# ADR-032: Phase Sentinel — Automatic Phase Advancement via forge:promote

**Status:** Accepted  
**Date:** 2026-04-13  
**Deciders:** rr-benjamin.vogan

---

## Context

ADR-031 established that phase state is a tracking tool, not an enforcement mechanism.
Phases advance only via `forge:promote`, which must be invoked manually. In practice,
engineers routinely forget to run `forge:promote` between phases, leaving `.state.json`
misaligned with the work that has actually been done.

The pain: state says "discovery" while the engineer is already committing implementation
code, or state says "implementation" while the engineer is running verification.

## Decision

Introduce the **Phase Sentinel** pattern: the three skills that serve as natural phase
entry points (`forge:plan`, `forge:commit`, `forge:verify`) each check `currentPhase`
at their entry and/or exit and call `forge:promote --target <phase>` automatically when
the effort's state lags behind the work being done.

`forge:promote` is extended to serve as the single source of truth for all promotion
logic, including a new `--target <phase>` argument for multi-step advancement.

### Phase Sentinel Touchpoints

| Skill | Check | Transition Offered |
|-------|-------|-------------------|
| `forge:plan` | Entry (before reading artifacts) | discovery → planning |
| `forge:plan` | Completion (after tasks.md committed) | planning → implementation |
| `forge:commit` | After staging (Step 0) | planning/discovery → implementation (only when staged content signals implementation) |
| `forge:verify` | Entry (before spawning worker) | implementation → verification |
| `forge:verify` | Completion (after PASS result) | verification → review |

### forge:promote --target Extension

`forge:promote` gains an optional `--target <phase>` argument:

- **Multi-step gap:** if `currentPhase` is two or more phases behind `targetPhase`,
  advance through all intermediate phases, creating one checkpoint commit per phase
  approved.
- **No-op when target ≤ current:** if the effort is already at or past the target
  phase, exit silently. This is the expected path when calling skills fire after the
  effort has already been advanced.
- **Unknown phase name:** stop with an error listing valid phases.

### Validation Gate

When advancing out of the discovery phase, if `validation/report.md` is absent,
`forge:promote` prompts the engineer to run `forge:validate` before advancing
(yes/no/skip). This is a soft prompt, not a hard block — consistent with ADR-031.

## Consequences

**Good:**
- Phase state stays aligned with work without requiring the engineer to remember
  separate `forge:promote` invocations.
- All promotion logic is centralized in one skill (`forge:promote`). Calling skills
  delegate via `--target`; no promotion mechanics live in the callers.
- The explicit conditional check in each Phase Entry Check ("if currentPhase is before
  X, then invoke forge:promote; otherwise proceed silently") ensures zero friction when
  state is already aligned.
- Multi-step gap detection handles the case where an engineer jumps phases (e.g.,
  committing implementation code while still in discovery).
- `forge:commit`'s sentinel inspects staged file paths before deciding whether to fire.
  Discovery artifacts (`requirements/`, `spec/`) suppress the sentinel; only source
  files outside `.forge/` or plan-only commits trigger it. This prevents false
  promotions when engineers use `forge:commit` to record discovery work.

**Neutral:**
- `forge:promote` called without `--target` behaves identically to before — no
  behavior regression.
- The Phase Sentinel is advisory, not enforcing. Engineers can decline the offered
  advancement and work in a phase-misaligned state if they choose.

**Trade-offs:**
- The calling skills now have an implicit dependency on `forge:promote` being
  available. If `forge:promote` is ever renamed or removed, the Phase Entry Checks
  in three skills break silently (they will just not fire).
- The validation gate adds an extra prompt when leaving discovery without a report,
  which may feel interruptive in lightweight workflows. Engineers can skip it.

## Alternatives Considered

### Alternative A: PostToolUse hook for phase advisory

Add a PostToolUse hook that detects when all artifacts for a phase are present and
emits a "Phase complete — run forge:promote" advisory. Rejected: hooks cannot interact
with the engineer (no prompt), so this would only produce a banner that engineers could
ignore, which is the existing problem in a different form.

### Alternative B: Separate forge:advance-phase skill

Create a new `forge:advance-phase` worker skill and have calling skills delegate to it
instead of `forge:promote`. Rejected: introduces a second skill with overlapping
responsibility when `forge:promote` already exists and can be extended. Creates
maintenance burden and confuses the "which skill advances phases?" question.

### Alternative C: Auto-advance without confirmation

Detect phase transitions and advance `.state.json` automatically without prompting.
Rejected: phase advancement requires the engineer's awareness (it represents a
deliberate workflow gate). Silent state mutations would surprise engineers and
potentially create incorrect audit trails.
