# Forge Plugin Lifecycle — Installation, Versioning, and Updates

This document traces the exact state of every relevant file through the complete
lifecycle of Forge plugin installation and upgrade across two repositories. Steps
follow the actual developer workflow: marketplace and plugin management via the
Claude Code `/plugin` command, and project configuration via `forge:init` and
`forge:update` skills.

---

## Repository and File Reference

**rr-standards repo** (GitHub: `rewards-guilds/rr-standards`) — the plugin marketplace.
Contains the plugin code and a `marketplace.json` catalog at the repository root.

```
rr-standards/
├── marketplace.json                 ← catalog listing available plugins
└── plugins/
    └── forge/
        ├── plugin.json              ← version declaration
        ├── skills/                  ← skill SKILL.md files
        └── hooks/                   ← hook scripts
```

**Developer machine plugin cache** — keyed by marketplace source and commit SHA:

```
~/.claude/plugins/cache/
└── <marketplace-source>/
    └── forge/
        └── <commit-sha>/
            ├── plugin.json
            ├── skills/
            └── hooks/
```

**Each initialized project:**

```
<project-root>/
├── .claude/
│   └── settings.json                ← enabledPlugins + extraKnownMarketplaces
├── .claude-plugin/
│   └── marketplace.json             ← local marketplace pinning forge to a specific version tag + SHA
│                                       (created by forge:init, not by /plugin)
└── .forge/
    └── version.json                 ← forge_min_version and migration tracking
                                        (created by forge:init)
```

---

## Initial State (before any action)

**rr-standards repo** at commit `v1.0.0`:
```json
// marketplace.json
{
  "name": "rr-standards",
  "plugins": [
    { "name": "forge", "source": "./plugins/forge" }
  ]
}

// plugins/forge/plugin.json
{ "name": "forge", "version": "1.0.0" }
```

**Developer machine:**
```
~/.claude/plugins/cache/   (empty)
```

**Repo A, Repo B:** no `.claude/` directory, no `.forge/` directory.

---

## Step 1 — Developer adds rr-standards marketplace to Repo A

```
/plugin marketplace add github:rewards-guilds/rr-standards --scope project
```

Claude Code fetches `marketplace.json` from the default branch of rr-standards
and records the marketplace in the project settings. No plugin code is downloaded yet.

**Repo A `.claude/settings.json`** (NEW):
```json
{
  "extraKnownMarketplaces": {
    "rr-standards": {
      "source": {
        "source": "github",
        "repo": "rewards-guilds/rr-standards"
      }
    }
  }
}
```

**Cache:** still empty — adding a marketplace does not fetch plugin code.

**rr-standards repo, Repo B:** unchanged.

---

## Step 2 — Developer installs the forge plugin in Repo A

```
/plugin install forge@rr-standards --scope project
```

Claude Code reads the rr-standards `marketplace.json` at the current HEAD (`v1.0.0`),
follows the `./plugins/forge` relative path, fetches the plugin content, and caches
it. The plugin is added to `enabledPlugins` in the project settings.

**Repo A `.claude/settings.json`** (UPDATED):
```json
{
  "extraKnownMarketplaces": {
    "rr-standards": {
      "source": { "source": "github", "repo": "rewards-guilds/rr-standards" }
    }
  },
  "enabledPlugins": {
    "forge@rr-standards": true
  }
}
```

**Cache** (NEW):
```
~/.claude/plugins/cache/
└── rewards-guilds_rr-standards/
    └── forge/
        └── sha-for-v1.0.0/
            ├── plugin.json   → { "name": "forge", "version": "1.0.0" }
            ├── skills/
            └── hooks/
```

The forge plugin is now active in Repo A. When the developer opens Repo A, Claude
Code loads forge v1.0.0 from the `v1.0.0` cache entry.

**rr-standards repo, Repo B:** unchanged.

---

## Steps 3 & 4 — Developer adds marketplace and installs forge plugin in Repo B

Same commands, executed in Repo B. The marketplace.json from rr-standards is still
at `v1.0.0` (nothing has changed in rr-standards). The plugin at `v1.0.0` is already
in the cache — no new download occurs.

**Repo B `.claude/settings.json`** (NEW — same structure as Repo A):
```json
{
  "extraKnownMarketplaces": {
    "rr-standards": {
      "source": { "source": "github", "repo": "rewards-guilds/rr-standards" }
    }
  },
  "enabledPlugins": {
    "forge@rr-standards": true
  }
}
```

**Cache:** unchanged — `v1.0.0` entry already present, reused for Repo B.

---

## Step 5 — Developer runs `forge:init` in Repo A and Repo B

`forge:init` is a forge skill (not a `/plugin` command). After the plugin is active,
the developer runs `forge:init` to initialize the Forge workflow structure. By default
it pins to the latest release tag. To pin to a specific version:

```
forge:init --version 1.0.0
```

`forge:init` resolves the specified tag to its commit SHA via the GitHub API —
engineers specify human-readable version numbers, not raw commit hashes. It then
creates a project-local marketplace pinning both the tag and its SHA.

**`forge:init` creates in each repo:**

```json
// .claude-plugin/marketplace.json  (NEW — committed to the repo)
{
  "name": "local",
  "plugins": [{
    "name": "forge",
    "source": {
      "source": "github",
      "repo": "rewards-guilds/rr-standards",
      "ref": "v1.0.0",
      "sha": "sha-for-v1.0.0"
    }
  }]
}
```

```json
// .forge/version.json  (NEW)
{
  "forge_min_version": "1.0.0",
  "initialized_with": "1.0.0",
  "initialized_at": "2026-03-15T...",
  "last_migrated_with": null,
  "last_migrated_at": null
}
```

`forge:init` also updates `.claude/settings.json` to reference the local marketplace
alongside the remote one, and switches `enabledPlugins` to use the pinned local entry:

```json
// .claude/settings.json  (UPDATED)
{
  "extraKnownMarketplaces": {
    "rr-standards": {
      "source": { "source": "github", "repo": "rewards-guilds/rr-standards" }
    },
    "local": {
      "source": { "source": "directory", "path": "./.claude-plugin" }
    }
  },
  "enabledPlugins": {
    "forge@local": true
  }
}
```

From this point, Claude Code loads forge via the local marketplace pin (`v1.0.0`)
rather than from whatever HEAD of rr-standards currently is. Both repos are now
pinned to `v1.0.0`.

**Cache:** unchanged.

---

## Step 6 — New version of forge is published to rr-standards

Updated plugin code is committed and pushed to rr-standards. The commit SHA becomes
`v2.0.0`. `plugins/forge/plugin.json` is bumped to `2.0.0`.

**rr-standards repo** (new HEAD = `v2.0.0`):
```json
// plugins/forge/plugin.json  (CHANGED)
{ "name": "forge", "version": "2.0.0" }

// marketplace.json  (unchanged — still references ./plugins/forge)
```

**Developer machine cache:** unchanged — nothing is fetched automatically.

**Repo A, Repo B:** unchanged — both pinned to `v1.0.0`, both running forge v1.0.0.
The new version exists in rr-standards but neither repo is aware of it yet.

---

## Step 7 — Developer runs `forge:update` in Repo A

`forge:update` detects that the rr-standards marketplace has a newer release
(`v2.0.0`, v2.0.0) than Repo A's current local pin (`v1.0.0`, v1.0.0).

**Pre-update report:**
```
Current:  forge v1.0.0  (v1.0.0 — sha-for-v1.0.0)
Available: forge v2.0.0  (v2.0.0 — sha-for-v2.0.0)

Change type: MAJOR VERSION — breaking migration required.

Configuration changes that will be applied to Repo A:
  .claude-plugin/marketplace.json: ref v1.0.0 → v2.0.0 (sha updated accordingly)
  .forge/version.json: forge_min_version 1.0.0 → 2.0.0
  [any structural .forge/ migrations for v2]

Repo B is not affected — it remains on v1.0.0 until forge:update is run there.

Confirm? [y/N]
```

After confirmation:

1. `v2.0.0` plugin content fetched and cached
2. `.claude-plugin/marketplace.json` updated in Repo A
3. `.forge/` structure migrated for v2
4. `.forge/version.json` updated

---

## Final State

**rr-standards repo:**
```json
// plugins/forge/plugin.json
{ "name": "forge", "version": "2.0.0" }   ← tagged v2.0.0
```

**Developer machine cache:**
```
~/.claude/plugins/cache/
└── rewards-guilds_rr-standards/
    └── forge/
        ├── sha-for-v1.0.0/      ← v1.0.0  (retained — still used by Repo B)
        └── sha-for-v2.0.0/      ← v2.0.0  (NEW — used by Repo A)
```

**Repo A:**
```json
// .claude-plugin/marketplace.json
{ ..., "ref": "v2.0.0",
      "sha": "sha-for-v2.0.0" }        ← Claude loads forge v2.0.0

// .forge/version.json
{
  "forge_min_version": "2.0.0",
  "last_migrated_with": "2.0.0",
  "last_migrated_at": "2026-03-15T14:00:00Z"
}
```

**Repo B:**
```json
// .claude-plugin/marketplace.json
{ ..., "ref": "v1.0.0",
      "sha": "sha-for-v1.0.0" }        ← Claude loads forge v1.0.0 (unchanged)

// .forge/version.json
{ "forge_min_version": "1.0.0", "last_migrated_with": null }
```

The developer can switch between Repo A (v2.0.0) and Repo B (v1.0.0) freely.
Each project loads its pinned version from a separate cache entry.

---

## Version Enforcement at Session Start

**Developer opens Repo A:**
- Active version: 2.0.0 (v2.0.0, via local marketplace pin)
- `forge_min_version`: 2.0.0 → proceed

**Developer opens Repo B:**
- Active version: 1.0.0 (v1.0.0, via local marketplace pin)
- `forge_min_version`: 1.0.0 → proceed
- Optional notice: forge v2.0.0 is available, run `forge:update` when ready

**After the v2 mandatory deadline (`mandatoryAfter` in VERSIONS.json) passes:**
- Developer opens Repo B → enforcement hook blocks
- "forge v1 support ended on [date]. Run `forge:update` to migrate this repository."
