← [Decisions Index](README.md)

# ADR-007: The Only Pre-Implementation Gate Is Discovery, Not Validation

**Status:** Accepted  
**Date:** 2026-03-03

## Context

For full-tier workflows, implementation should not begin until the design has been validated. Validation (the design validation report) confirms that the design is internally consistent and meets the requirements. A naive model would add a separate validation gate after discovery approval, creating a three-gate sequence: requirements approval, design approval, validation approval, then implementation. Two of these gates protect against the same failure — implementing against an unapproved or unvalidated design — creating redundancy that inflates the ceremony without adding a meaningful quality check.

## Decision

For full-tier workflows, implementation is blocked until discovery is approved. Validation is a required artifact that must be completed before implementation, but it does not add a separate gate. It is part of what `workflow/promote` checks when approving discovery. If validation has not been run, promote will not approve discovery.

## Consequences

**Positive:**
- Gate count is kept minimal — one gate for all pre-implementation checks (discovery + validation together)
- Engineers cannot skip validation by accident; promote surfaces it as a prerequisite
- The validation report is reviewed in context of the discovery artifacts, not in isolation

**Negative:**
- The discovery approval via `workflow/promote` must explicitly verify that `validation/report.md` exists and has a passing status before marking discovery approved — this logic must be implemented and maintained in promote
- If an engineer runs validation, finds issues, updates the design, and needs to re-run validation, all of this happens within the discovery phase with no explicit checkpoint between validation passes
