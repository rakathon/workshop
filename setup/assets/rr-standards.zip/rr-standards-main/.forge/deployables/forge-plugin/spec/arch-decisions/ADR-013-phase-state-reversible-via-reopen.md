← [Decisions Index](README.md)

# ADR-013: Phase State Is Reversible via workflow/reopen, Not via Overwriting

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Once a phase is approved, its artifacts are protected from direct editing by the `02-protect-approved-artifacts.sh` pre-commit hook. Occasionally a reviewer or engineer identifies an issue after approval — a missing requirement, a design flaw, an incorrect assumption — and needs to reopen the phase to make corrections. Without an explicit reopen mechanism, the only escape paths are silently editing protected artifacts (blocked by the hook) or manually editing `.state.json` directly (bypasses all auditability). Neither is acceptable.

## Decision

A phase that has been approved can be moved back to `in_progress` via `workflow/reopen` without reverting any code. This is a state-only operation. If code also needs to be reverted, `workflow/revert` is used separately and explicitly.

## Consequences

**Positive:**
- Provides a documented, auditable path for correcting a prematurely or incorrectly approved phase
- Requires explicit engineer confirmation before changing state — no silent modifications
- The separation from `workflow/revert` keeps each operation focused: reopening is lightweight, reverting code is destructive and deliberate
- Re-approving the phase via `workflow/promote` re-runs validation checks, catching any divergence between updated specs and the implementation

**Negative:**
- An engineer could invoke `workflow/reopen`, update spec artifacts, and proceed without also running `workflow/revert` to align the code — creating a divergence between specs and implementation
- This divergence is partially mitigated by the promote re-validation step, but the tool cannot prevent an engineer from ignoring a mismatch if they choose to
