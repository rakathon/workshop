← [Decisions Index](README.md)

# ADR-011: git submodule as the Distribution Mechanism

**Status:** Superseded by [ADR-016](ADR-016-two-tier-plugin-distribution.md)
**Date:** 2026-03-03

## Context

rr-standards must be distributed to consuming projects in a way that handles three concerns simultaneously: versioning (projects must be able to pin to a specific version and advance deliberately), standards sharing across skills (a skill referencing a standard must always get the version of that standard it was developed against), and cross-deployable consistency (a new version of one deployable cannot be silently combined with an old version of another). Several distribution models were considered, ranging from a simple git submodule to a plugin-per-package model with independent versioning.

## Decision

rr-standards is distributed to consuming projects as a git submodule, installed at `plugins/rr-standards/` by convention. `setup.sh` copies skills, hooks, and templates from the submodule into the project's `.claude/` directory. Standards are referenced in CLAUDE.md using paths relative to `plugins/rr-standards/`. Each project pins to a specific commit and advances the pin deliberately.

## Consequences

**Positive:**
- The submodule commit SHA is the version — no additional versioning mechanism is needed
- All standards and skills ship from the same commit, making cross-deployable consistency guaranteed by construction
- Pinning, advancing, and rolling back the version are standard git operations that engineers already know
- Consuming projects can inspect the full rr-standards source at the pinned version without any additional tooling

**Negative:**
- All consuming projects receive the entire rr-standards repository even if they only use a subset of it — selective sparse checkout is a future option if this becomes costly
- Submodule management (init, update, deinit) is a known friction point for engineers unfamiliar with submodules

## Alternatives Considered

Plugin-per-package distribution — each package (rr-core, workflow-full, implementation, etc.) would be an independently versioned artifact. Rejected because it requires semantic versioning per package, a dependency declaration mechanism, and a lock file or compatibility matrix, amounting to building a package manager for Claude skills. Future path: GitHub Releases of rr-standards with `setup.sh --packages=<list> --version=<tag>` flags if selective installation becomes valuable.
