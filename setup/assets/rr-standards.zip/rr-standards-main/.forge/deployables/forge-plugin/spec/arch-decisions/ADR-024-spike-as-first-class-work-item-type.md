← [Decisions Index](README.md)

# ADR-024: Spike Is a First-Class Work Item Type with Investigation-Specific Phases and Artifacts

**Status:** Accepted
**Date:** 2026-03-05

## Context

Investigative work — time-boxed research to reduce uncertainty before committing to an approach — is a recognized and common work pattern. Spikes produce knowledge (findings, recommendations), not production code. They are not stories, which produce working software via the implementation pipeline, nor tasks, which are atomic units of known work.

Forcing spikes into the story type creates two problems: first, phases that don't apply (PR review, implementation verification, QA) would be present in the workflow state, either blocking progress or requiring manual suppression; second, the output artifact (a findings document with recommendation) has no natural home in the requirements/spec/plan structure that stories use.

## Decision

Add `spike` as a first-class type in the work item type enum alongside `program | initiative | epic | story | task`.

Spikes use a dedicated lightweight workflow with two phases: `investigation` (active work) and `findings` (findings document produced, awaiting approval). The standard phases — discovery, validation, planning, implementation, verification, PR review, QA, runbook — do not apply to spikes and are not tracked in their state.

The primary artifact is `findings/findings.md`, which replaces the requirements/spec/plan directory tree used by other work item types.

A `timebox` field is added to `.state.json`. For spikes, this is a required ISO date string representing the deadline by which findings must be produced. An investigation that has exceeded its timebox without approved findings is a blocked state. For all other work item types, `timebox` is null.

Spike code is exploratory and not production-bound — a spike may produce prototype code as part of the investigation (comparing approaches, building far enough to produce a confident estimate). PR review is optional for spike code, not required. The primary artifact and gate remains `findings/findings.md`. A spike may spawn child work items (epics, stories) from its findings; those are recorded in the `findings` phase state under `spawnedWorkItems`.

## Consequences

**Positive:**
- Spike state is clean — no inapplicable phases to skip or suppress
- The timebox is machine-readable and enforceable by hooks (warn or block on overdue spikes)
- Findings as a named artifact give the output a clear, findable location
- Spawned work items are traceable to the spike that motivated them via `spawnedWorkItems` and the child's `parentId`

**Negative:**
- The type enum grows; tooling must handle one additional type
- `timebox` is type-specific — it is meaningful for spikes and ignored for everything else; this is a mild schema inconsistency

## Alternatives Considered

**Spike as a story subtype (e.g., a `subtype` flag on story):** Avoids growing the type enum but still requires all phase-applicable logic to check the subtype before enforcing phases. The savings are superficial; the complexity is the same. Rejected.

**Spike as a task with a findings template:** Loses the timebox, the distinct phase model, and the ability for tooling to distinguish spikes from implementation tasks. Rejected.
