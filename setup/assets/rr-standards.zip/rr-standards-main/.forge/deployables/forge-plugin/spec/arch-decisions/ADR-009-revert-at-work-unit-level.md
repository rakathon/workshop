← [Decisions Index](README.md)

# ADR-009: Revert Operates at the Work-Unit Level, Not the Commit Level

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Engineers need to undo work, but the unit they think in — a task, a phase, a full work item — rarely maps to a single commit. A task may span multiple commits (implementation, tests, documentation updates). A phase may span dozens. Asking engineers to identify individual commit SHAs and sequence `git revert` calls correctly is error-prone, especially with non-linear histories. Additionally, reverting code without updating the corresponding workflow state files (`plan/tasks.md`, `.state.json`) leaves the repository in an inconsistent state where the spec claims work is done but the code disagrees.

## Decision

The `workflow/revert` skill accepts a scope (task, phase, or work-id) and reverses the logical unit of work, not raw git commits. It parses commit SHAs from `plan/tasks.md`, identifies all commits belonging to the scope, reconciles non-linear history, presents an execution plan for engineer confirmation, and then executes.

## Consequences

**Positive:**
- Revert operates at the level engineers think in, not at the level git operates at
- Workflow state files are updated atomically with the code revert, preserving consistency
- The engineer sees an execution plan before anything is changed — no silent destructive operations
- Works for any scope width: single task up to entire work item

**Negative:**
- Correctly identifying all commits belonging to a logical scope is harder with non-linear histories (rebases, squash merges)
- The skill must handle history ambiguity and surface it to the engineer rather than silently reverting the wrong commits
- The implementation is substantially more complex than a simple `git revert <sha>`
