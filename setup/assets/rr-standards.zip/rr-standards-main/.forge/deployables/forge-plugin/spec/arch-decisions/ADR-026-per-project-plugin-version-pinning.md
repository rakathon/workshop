← [Decisions Index](README.md)

# ADR-026: Per-Project Plugin Version Pinning via Committed Local Marketplace

**Status:** Accepted
**Date:** 2026-03-15

## Context

The Forge plugin is distributed via the rr-standards GitHub repository acting as a
Claude Code plugin marketplace. Multiple repositories within the organization use the
Forge plugin, and each may be at a different stage in its adoption of new Forge
versions. A developer works on multiple repositories concurrently and must be able to
open any repository and have the correct plugin version load automatically.

Claude Code's plugin cache stores fetched plugin versions keyed by commit SHA
(`~/.claude/plugins/cache/<source>/<plugin>/<sha>/`), meaning multiple versions of
the same plugin can coexist on the developer's machine simultaneously.

The question is: how does each repository declare which version of the Forge plugin
it requires, such that the correct version is loaded automatically and is identifiable
by humans without looking up commit hashes?

## Decision

Each initialized repository commits a project-local marketplace definition at
`.claude-plugin/marketplace.json`. This file pins the Forge plugin to a specific
release using both a semantic version tag (`ref`) and its corresponding commit SHA.
The tag provides human-readable version identification; the SHA provides
cryptographic immutability — if a tag is ever moved, the SHA mismatch produces an
explicit error rather than a silent version change.

```json
// .claude-plugin/marketplace.json
{
  "name": "local",
  "plugins": [{
    "name": "forge",
    "source": {
      "source": "github",
      "repo": "rewards-guilds/rr-standards",
      "ref": "v1.2.3",
      "sha": "<commit-sha-for-v1.2.3>"
    }
  }]
}

// .claude/settings.json
{
  "extraKnownMarketplaces": {
    "local": { "source": { "source": "directory", "path": "./.claude-plugin" } }
  },
  "enabledPlugins": { "forge@local": true }
}
```

Every release of the Forge plugin must be tagged in the rr-standards repository using
semantic versioning (`v1.2.3`). This is what makes `--version 1.2.3` a valid parameter
for `forge:init` and `forge:update` — the skills resolve the tag to its SHA via the
GitHub API rather than requiring engineers to look up or copy raw commit hashes.

When a developer opens the project, Claude Code reads `enabledPlugins`, resolves
`forge@local` through the local marketplace, fetches the pinned version into the cache
if not already present, and loads that exact plugin version. No manual installation
step is required after the initial `forge:init`.

`forge:init` creates both files using the latest release tag by default, or a
specific version when `--version <semver>` is provided. `forge:update` updates
the `ref` and `sha` in `.claude-plugin/marketplace.json` when the developer
upgrades their project. Both files are committed to version control, making the
pinned version visible in PR diffs, auditable in git history, and consistent across
all contributors.

## Consequences

**Positive:**
- Per-project version isolation is automatic: each repository loads its pinned
  version regardless of what other repositories on the same machine are pinned to
- No manual install step after cloning: `enabledPlugins` activates the plugin
  immediately when the developer trusts the project folder
- Version pins are human-readable (`v1.2.3`) — engineers can identify and specify
  versions without looking up commit hashes; `forge:init --version 1.2.3` is the
  full workflow
- The SHA provides cryptographic verification: a moved tag produces an explicit error
  rather than silently loading a different version
- A developer can concurrently work on repositories at different major versions
  without conflict — each loads from its own cache entry
- Mandatory upgrade enforcement (via `VERSIONS.json` in the marketplace) bounds how
  long a repository can remain on an old version

**Negative / Watch:**
- Each project carries two additional committed files (`.claude-plugin/marketplace.json`
  and entries in `.claude/settings.json`); `forge:init` and `forge:update` must
  maintain these correctly
- rr-standards must tag every release with a semantic version tag; untagged commits
  are not directly usable as a `--version` argument — this is an operational
  requirement on the rr-standards release process
- The cache accumulates plugin versions over time; Claude Code's cache eviction policy
  determines when old versions are removed
