← [Decisions Index](README.md)

# ADR-020: Mandatory Adoption Is Enforced via forge:init and forge:review as a Required Status Check

**Status:** Accepted
**Date:** 2026-03-05

## Context

BR-15 requires that Forge adoption be mandatory for all development work in all
repositories, with no opt-out. The mandate must be enforced mechanically, not through
self-reporting or periodic audits. Two enforcement points are needed: one that ensures
a repository is correctly configured before any Forge-mediated work can begin, and one
that ensures every pull request is reviewed before it can merge. The enforcement mechanism
must work for both greenfield and brownfield repositories without requiring teams to
rebuild existing CLAUDE.md files or project structures.

## Decision

Enforcement operates at two points. First, `forge:init` creates the repository
structure, `plugins/rr-standards/` content, and CLAUDE.md configuration that allow a repository
to produce AI approval signals. A repository without this initialization cannot produce
a `forge:review` approval signal, because the skill depends on `plugins/rr-standards/` being
present and the CLAUDE.md being configured. Second, `forge:review` runs in GitHub Actions
on every pull request as a required status check enforced via branch protection rules.
A PR cannot merge without a passing `forge:review` signal. For brownfield repositories,
`forge:init` detects the existing CLAUDE.md and merges into it without overwriting
existing content. There is no exemption path — teams with constraints that prevent normal
initialization work with Productivity Engineering to define an appropriate tier or
exception, not to bypass enforcement.

## Consequences

**Positive:**
- Enforcement is mechanical, not self-reported; a repository either has the required
  configuration or it cannot produce AI approval signals
- Branch protection rules are managed by Productivity Engineering, not by individual teams;
  teams cannot disable the required status check
- Brownfield detection prevents accidental destruction of existing project configuration
- The two enforcement points are independently verifiable: repository initialization state
  is visible in the repo, and PR status check results are visible in GitHub

**Negative:**
- Teams cannot merge PRs during a `forge:review` outage without a manual Productivity
  Engineering override (this is intentional and addressed by ADR-022)
- Brownfield onboarding requires running `forge:init` on every existing repository
  within the enforcement window, which is a non-trivial rollout effort
- Repositories with unusual structures (monorepos, non-standard layouts) require additional
  `forge:init` configuration to place `.forge/` at the correct scope level
