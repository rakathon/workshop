← [Decisions Index](README.md)

# ADR-017: Standards Are Discoverable via CLAUDE.md, Not via a Service

**Status:** Accepted
**Date:** 2026-03-05

## Context

Organizational standards must be accessible to engineers and AI agents without requiring
a skill invocation. Two mechanisms were considered: embedding standards references in
each project's CLAUDE.md (which Claude Code loads automatically at session start), or
exposing standards through an MCP server that agents query on demand. The CLAUDE.md
approach makes standards visible at the start of every session without any action from
the engineer. The MCP approach requires network access at generation time and introduces
an infrastructure dependency that must be operated and kept available.

## Decision

Standards are referenced from the project CLAUDE.md using file paths into `plugins/rr-standards/`.
CLAUDE.md is loaded automatically by Claude Code at every session start, making standards
discoverable without skill invocation. An MCP-based standards query interface is not in
scope for v1.

## Consequences

**Positive:**
- Standards are visible to the agent from the first moment of every session, before any
  skill is invoked
- No network dependency at generation time; standards are local files already present via
  `plugins/rr-standards/`
- Engineers can read standards directly as files without any tooling
- Consistent with the principle that standards are usable without invoking a skill

**Negative:**
- CLAUDE.md must be kept up to date when new standards are added; this is handled by
  `forge:init` and the brownfield merge process, but requires that process to be run
- Standards references in CLAUDE.md are paths, not content — if `plugins/rr-standards/` is absent,
  the references resolve to nothing; this is caught by the session-start enforcement hook

## Alternatives Considered

**MCP server for standards delivery:** Would allow dynamic querying of standards by topic,
version, or language. Rejected because it introduces a network dependency that fires on
every pre-tool-use hook (i.e., on every file write), breaks co-versioning between skills
and standards, and requires infrastructure to operate.
