← [Decisions Index](README.md)

# ADR-005: Non-Interactive Claude for Automation

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Several workflow integrations — PR review on open, rollout monitoring post-deploy — must run without a human present. Claude Code's default mode is interactive: it prompts, waits, and maintains session state across turns. This model is incompatible with GitHub Actions triggers that fire asynchronously and must complete without human input. A mechanism is needed that allows Claude to execute a skill, produce machine-readable output, and exit.

## Decision

GitHub Actions integrations use Claude in non-interactive (`--print`) mode. Skills are invoked by name in the prompt; output is machine-parseable.

## Consequences

**Positive:**
- PR review and rollout monitoring run without a human in the loop, satisfying the automation requirement
- `--print` mode produces deterministic, capturable output that GitHub Actions can parse and act on
- Skills remain unchanged — the same skill works in interactive and non-interactive contexts

**Negative:**
- Non-interactive Claude does not have session history or persistent context across invocations
- Each invocation must supply full context via the context file format, placing the burden on the GitHub Actions workflow to assemble the right context
- Debugging failures requires inspecting the assembled context packet, not an interactive session
