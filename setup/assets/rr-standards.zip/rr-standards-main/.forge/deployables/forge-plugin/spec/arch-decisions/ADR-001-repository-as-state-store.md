← [Decisions Index](README.md)

# ADR-001: Repository as State Store, Not a Service

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Workflow state must be persisted somewhere so that multi-phase development work survives context resets, session restarts, and handoffs between engineers. The options are an external service (database, SaaS workflow tool, hosted API) or the effort repository itself. External services require provisioning, credentials, network access, and ongoing maintenance. They also introduce a dependency that is not under the engineer's control and is not co-located with the code it describes.

## Decision

All workflow state lives in `.forge/` as JSON files in the effort repository. No external database, workflow service, or SaaS tool is the authority.

## Consequences

**Positive:**
- Version control provides history, auditability, branching, and review for free
- State is portable — anyone who clones the repository has full context without additional setup
- No infrastructure to provision, secure, rotate credentials for, or maintain
- State changes are reviewable in PRs alongside the code they describe
- Rollback of state is a standard git operation

**Negative:**
- State is not queryable across projects — a dashboard showing all in-flight work across all repositories is not achievable with this model alone
- JSON files in a repository are less ergonomic to inspect than a purpose-built UI
- Concurrent edits to state files can produce merge conflicts
