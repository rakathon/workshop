# ADR-033: Project-Local Template Overrides for Forge Plugin Templates

**Status:** Accepted  
**Date:** 2026-04-14  
**Effort:** forge-pr

---

## Context

The Forge plugin ships built-in templates (in `plugins/forge/templates/`) used by
skills as fallback content — for example, a default PR description template used
by `forge:pr` when no project-level template exists. As teams adopt Forge, they will
need to customize these templates to match their organization's PR review process,
coding standards, or compliance requirements without modifying the plugin itself
(which would be overwritten on `forge:update`).

Without a formal override mechanism, teams either: (a) modify the plugin templates
directly and lose changes on update, or (b) maintain a separate PR template in
`.github/` that skills must be explicitly taught to find. Neither is sustainable.

## Decision

Any Forge plugin template can be overridden by placing a file with the same name in
the project's `.forge/templates/` directory. Skills that load a plugin template must
check `.forge/templates/<filename>` before falling back to the plugin's own
`plugins/forge/templates/<filename>`.

The template resolution order for any skill that loads a Forge plugin template is:

1. `.forge/templates/<template-name>` — project-local override (highest priority)
2. `../../templates/<template-name>` relative to the skill file — plugin default

This applies to all templates loaded by Forge skills, not only PR templates.

## Alternatives Considered

**Environment variable pointing to a template directory:** Requires engineers to
configure their environment and is invisible to the codebase. Rejected — convention
over configuration is preferable for discoverability.

**Separate `.forge/config` key per template:** More explicit but requires skills
to know each template's config key. The filename-as-identity convention is simpler
and self-documenting.

**Only use `.github/pull_request_template.md` for PR templates:** Works for PR
templates specifically but doesn't generalize to other template types (ADR templates,
requirements templates, etc.) that Forge may ship in the future.

## Consequences

- Skills must implement a two-step template load: check `.forge/templates/` first,
  then fall back to the plugin default.
- `.forge/templates/` must be created by `forge:init` as an empty directory (with
  `.gitkeep`) so the override location is visible and documented in the repository.
- Plugin template updates via `forge:update` do not affect project-local overrides.
- Projects that copy a plugin template to `.forge/templates/` to customize it accept
  responsibility for keeping it current when the plugin template changes.
