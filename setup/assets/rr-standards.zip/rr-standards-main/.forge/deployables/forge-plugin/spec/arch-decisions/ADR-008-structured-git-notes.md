← [Decisions Index](README.md)

# ADR-008: Structured git notes as the Task Metadata Layer

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Task completion produces richer context than a commit message can carry: which task ID was completed, which work-id it belongs to, which tests were written, what coverage was achieved, which standards were checked, and any deviations from those standards. Commit messages are human-readable but not reliably machine-parseable at scale, and stuffing structured data into commit message trailers is non-standard and fragile. An alternative metadata layer is needed that attaches to commits without altering them and can be queried programmatically by skills like `diagnose` and `revert`.

## Decision

The `implement/commit` skill attaches a structured JSON note to every task-completion commit via `git notes`. Commit messages remain conventional (feat/fix/chore). All rich context — task ID, work-id, tests written, coverage, standards checked, deviations — lives in the note. The `plan/update` skill reads the resulting SHA and records it in `plan/tasks.md` but does not write git notes.

## Consequences

**Positive:**
- Commit messages remain human-readable and follow conventional commit format
- Structured JSON in notes enables programmatic querying by `diagnose` and `revert` skills
- git notes are a native git mechanism — no external storage required
- Notes attach to commits without altering the commit SHA, preserving commit integrity

**Negative:**
- git notes are not replicated by default — `git push` does not push notes unless the notes refspec (`refs/notes/*`) is explicitly configured
- Teams must configure their remote to push notes; this is a one-time setup step but is non-obvious and easy to miss
- Engineers unfamiliar with git notes may be surprised to find metadata that is not visible in standard `git log` output without `--notes`
