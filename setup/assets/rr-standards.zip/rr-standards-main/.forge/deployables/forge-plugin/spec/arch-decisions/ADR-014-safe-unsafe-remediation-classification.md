← [Decisions Index](README.md)

# ADR-014: Autonomous Remediation Is Bounded by a Safe/Unsafe Action Classification

**Status:** Accepted  
**Date:** 2026-03-03

## Context

The operate package enables agents to execute runbook steps during incidents. The goal is autonomous remediation — resolving common incidents without requiring an engineer to be paged. The risk is that fully autonomous execution of runbook steps could make a bad situation worse: some steps (service restart, cache eviction) are low-risk and easily reversible; others (database writes, data deletion, queue purge) are irreversible and have a high blast radius if applied incorrectly. A mechanism is needed that allows common, safe steps to run autonomously while preserving human judgment for high-consequence actions.

## Decision

The `operate/remediate` skill executes runbook steps autonomously only when each step is classified as SAFE (restart, cache clear, capability flag adjustment, scaling within bounds). Steps classified as UNSAFE (database writes, data deletion, any action without a defined rollback) require engineer confirmation before proceeding. If any UNSAFE step is encountered or any step fails, remediation halts and pages on-call with the completed steps and the blocking action. The classification is defined in the runbook itself — each step carries an explicit `safe: true/false` and `rollback:` field.

## Consequences

**Positive:**
- The most frequent incident responses (service restarts, cache eviction, flag changes) run autonomously, satisfying the automation requirement
- High-blast-radius actions require human confirmation, preserving oversight where it matters
- The safety boundary is transparent and auditable — it is declared in the runbook, not hidden in the skill's logic
- Unclassified steps default to UNSAFE, ensuring new or incomplete runbooks always escalate rather than proceeding blindly

**Negative:**
- Runbook authors must classify each step at authoring time, adding authoring overhead
- A step that is mistakenly classified as SAFE will execute autonomously even if it should require confirmation — the classification is only as reliable as the runbook author's judgment
- Incomplete runbooks will always escalate to engineers until fully classified, which may initially reduce the autonomy benefit
