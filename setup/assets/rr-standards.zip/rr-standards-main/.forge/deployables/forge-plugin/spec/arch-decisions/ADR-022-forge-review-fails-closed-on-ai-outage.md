← [Decisions Index](README.md)

# ADR-022: forge:review Fails Closed on AI Service Outage

**Status:** Accepted
**Date:** 2026-03-05

## Context

`forge:review` is a required status check on every pull request. When the AI service
is unreachable, the check must produce some result. Two behaviors are possible: fail
closed (the PR is blocked; engineers cannot merge without a Productivity Engineering
override) or fail open (the PR auto-passes with a logged warning, allowing merge to
proceed). BR-17 requires that degraded behavior be explicitly defined. BR-18 requires
that AI review decisions be auditable. BR-15 requires that no PR bypasses review
without a record. An outage that silently auto-passes reviews would create an
uninvestigable gap in the audit trail for the duration of the outage.

## Decision

When the AI service is unreachable during a `forge:review` run, the check fails with
a structured diagnostic error that distinguishes a service outage from a review
rejection. The PR is blocked — it does not auto-pass. A documented manual override
process exists for Productivity Engineering to unblock an individual PR during a
prolonged outage; this override produces a logged audit record. Engineers must be able
to distinguish "the AI service is down" from "the AI rejected this PR" by reading the
check output.

## Consequences

**Positive:**
- No PR merges during an outage without an explicit audit record; the integrity of the
  mandatory review requirement (BR-15) is maintained even when the AI service is unavailable
- The structured diagnostic error gives engineers and Productivity Engineering actionable
  information: the service is down, not the PR is rejected
- The manual override process is documented and auditable, satisfying BR-18 for the
  override decision itself

**Negative:**
- An AI service outage blocks all PRs across all teams simultaneously; this is a
  significant operational impact that Productivity Engineering must be prepared to respond to
- The manual override process requires Productivity Engineering availability during
  prolonged outages, including outside business hours if PRs are time-sensitive
- Teams may apply pressure to auto-pass reviews during outages; the fail-closed decision
  must be organizationally supported to be sustainable

## Alternatives Considered

**Fail open (auto-pass with logged warning):** Allows PR merges to continue during outages.
Rejected because it silently creates uninvestigable gaps in the mandatory review audit trail,
violating BR-15 and BR-18. An outage that auto-passes reviews is operationally indistinguishable
from a period when review was simply not enforced.
