← [Decisions Index](README.md)

# ADR-025: Product-Scoped Directory Structure for Canonical Artifacts

**Status:** Superseded by [ADR-029](ADR-029-deployable-project-product-repository-roles.md)
**Date:** 2026-03-14

## Context

The initial `.forge/` structure is work-item-centric: requirements, design decisions, and
test strategies live under `.forge/efforts/<work-item-id>/`. This is appropriate for
coordinating delivery — a work item has a clear scope, a clear start, and a clear end.
It is not appropriate as a long-term home for the artifacts that describe what a product
*is* and how it *works*.

After a work item closes, its artifacts become archaeological record: to answer "what are
the current requirements for this product?" an engineer must identify every work item that
contributed to it and synthesize across them. There is no single authoritative view.

Forge is deployed across diverse repository types within the organization: mobile apps
(one deployed app per repo, multiple capability deployables), microservices (typically one
service per repo), DDD aggregate repositories (multiple bounded contexts per repo), and
legacy monoliths (many subsystems per repo). In all of these cases, the unit of
long-term maintenance is not the repository — it is a named product or deployable within
the repository. A repository may contain one product or many.

Additionally, product-scoped concerns (security policy, deployment configuration, test
strategy, operational runbooks) are not uniform across all products in a repository. A
public-facing REST API has a different security policy than an internal event consumer in
the same repo. A Kubernetes service and an AWS Lambda in the same repo have different
deployment configurations. These artifacts must be owned at the product level, not
asserted at the repository level.

## Decision

### 1. Products are explicit named entities

Products are added explicitly by developers, not inferred from the codebase. `forge:init`
creates an empty product registry. Products are added during discovery using `forge:product`
as the team identifies what is being built. A work item may not know its contributing
products at creation time — `products: []` is a valid initial state, updated during
discovery.

### 2. Each product owns a canonical artifact directory

Every product in a repository has a directory at `.forge/products/<product-name>/`
containing its canonical, living artifacts:

```
.forge/products/<product-name>/
├── README.md                    # product overview; links to all below
├── requirements/
│   ├── business.md              # what this product must do and why
│   └── technical.md             # NFRs, integration contracts, constraints
├── spec/
│   ├── README.md                # current architecture overview
│   ├── arch-decisions/          # ADRs scoped to this product
│   └── interfaces/              # interfaces published by this product
│       ├── api/                 # REST/GraphQL contracts (OpenAPI etc.)
│       ├── events/              # message and event contracts
│       └── library/             # client library API surface (if applicable)
├── dependencies/                # upstream interfaces this product consumes
│   └── <publisher-name>.md      # dependency version, migration plans, adaptations
├── test-strategy.md             # how to verify this product works
├── security.md                  # security policy for this product
├── deployment.md                # how this product is deployed and rolled back
└── runbook/
    ├── README.md                # index of operational procedures
    └── <area>.md                # per-area operational runbooks
```

These documents are updated incrementally as PRs merge. They are never closed or
archived — they reflect the current state of the product for as long as the product
exists.

### 3. Repo-level `.forge/spec/` is reserved for genuinely cross-product decisions

`.forge/spec/arch-decisions/` holds only decisions that apply equally to every product
in the repository — distribution mechanism, shared tooling choices, CI platform, policies
that govern all plugins or services uniformly. Decisions scoped to a single product belong
in that product's `spec/arch-decisions/`, not at the repo level. When in doubt: if a
decision would not change behavior for products other than the one being designed, it
belongs at the product level.

### 4. Work item requirements are goal statements; design artifacts are the approach

Work item requirements (`projects/<id>/requirements/`) are a **goal statement** — what
the team needs to accomplish with this work item. Engineers write these during discovery
to give the team a single, focused place to see the work item's intent. They are not a
copy or subset of the product requirements; they answer a different question: "what are
we trying to achieve?" rather than "what does the product currently do?"

Discovery includes a **gap analysis**: comparing the work item's goal statement against
the current product/capability canonical requirements to understand what needs to change.
The gap drives the design. After implementation ships, `forge:product-update` updates
the product/capability canonical requirements to reflect the delivered state. The actual
change to the product specification is captured by the git diff on the product
requirements files — not stored separately.

Work item design artifacts (`projects/<id>/spec/`) — API contracts, storage schemas,
message contracts — are the technical approach produced to close the gap.

When a work item closes, the product's canonical documents reflect the delivered state,
and the work item's artifacts remain in `projects/` as a permanent record of what the
team set out to accomplish and how they approached it.

Work items reference their contributing products via `products: [...]` in `.state.json`,
updated during discovery as products are identified.

### 5. Interface ownership follows the publisher

The product that publishes an interface owns it. Published contracts (API specs, message
contracts, event schemas, library API surfaces) live in the publisher's
`spec/interfaces/` directory and are not duplicated in consuming products.

When a published interface changes, the consequences for consuming products (migration
plans, local data model changes, compatibility notes) are documented in each consuming
product's `dependencies/<publisher-name>.md`. The interface itself is not re-documented
there — only the consuming product's response to the change.

### 6. Product documents are updated at PR merge, not at work item close

Product canonical artifacts are updated incrementally: each merged PR that delivers a
change to a product is accompanied by updates to the relevant product documents.
`forge:product-update` assists by reading the work item's delta artifacts and the current
product documents and proposing specific edits. These updates are included in the same PR
as the code changes they describe.

## Alternatives Considered

**Repo-level canonical documents** — a single `requirements/`, `spec/`, and
`test-strategy/` at the repository root. Rejected because it does not accommodate
multi-product repositories (mobile apps, DDD repos, monoliths), and because it cannot
express the per-product variation in security policy, deployment configuration, and
operational runbooks that exists in practice.

**Assembled view from work item history** — no canonical product documents; the product
view is synthesized on demand by reading all work items that contributed to a product.
Rejected because it requires traversal and synthesis to answer basic questions ("what
are the current requirements for this product?"), and because it does not support
iterative refinement of requirements and design outside of explicit work item boundaries.

**Single flat requirements file per product** — all requirements in one document, no
`requirements/` subdirectory. Deferred to product creation time; the directory form is
the default to accommodate growth beyond 500 lines (per the artifact expansion rule),
but a single-file form is valid for small products.

## Consequences

**Positive:**
- A product's current state is always readable from a single directory regardless of
  how many work items contributed to it
- Security, deployment, test strategy, and operational runbooks are product-scoped,
  correctly reflecting that these differ across products in the same repository
- Interface ownership is unambiguous: the publisher's `spec/interfaces/` is the
  authoritative source; consumers document their own adaptations
- Works uniformly across all repository types — the product granularity adapts to the
  repo (one product for a microservice; many for a monolith or mobile app)

**Negative / Watch:**
- Requires `forge:product` and `forge:product-update` skills to exist before the
  structure provides full value; partially initialized product directories are a risk
  during the transition period
- ADRs 001–024 in this repository are Forge framework product decisions and belong in
  `.forge/products/forge-plugin/spec/arch-decisions/` under this model. They currently
  live at the repo level. Migration is deferred to a dedicated forge-init implementation
  task; until then, they remain in `.forge/spec/arch-decisions/` as acknowledged
  technical debt

**Open question:**
- Cross-repo downstream consumer identification: when a published interface changes,
  Forge can identify consuming products within the same repository by scanning
  `dependencies/` directories. It cannot automatically identify consumers in other
  repositories. The mechanism for notifying cross-repo consumers is unresolved and
  deferred to the forge-init design phase (see forge-init TR open questions).
