← [Decisions Index](README.md)

# ADR-029: Deployable, Effort, and Product as Distinct Repository Roles

**Status:** Accepted
**Date:** 2026-03-24
**Supersedes:** [ADR-025](ADR-025-product-scoped-canonical-artifact-directory.md)

## Context

ADR-025 established `.forge/products/<name>/` as the canonical artifact directory for a
"product" — a technical deployable unit such as a mobile app, backend service, or browser
extension. This was the right instinct: a long-lived directory per deployable unit, updated
incrementally as work ships.

The term "product" created a collision. Product Managers use "product" to mean something
fundamentally different: a user-facing business capability like Favorites, Sign Up, or
Referral Program. A PM product is not a deployable unit — it is a *cross-cutting concern*
that spans multiple deployable units across multiple repositories. The full requirements for
"Favorites" live distributed across the mobile app repo, the backend API repo, the extension
repo, and the web application repo. There is no single place that captures the PM's view of
the product.

This collision made it impossible to represent the PM's notion of product within the Forge
directory structure, and it caused vocabulary confusion at the boundary between engineering
and product management.

A secondary issue: the current `repo_type` scalar in `.forge/version` allows a repository
to be either a `product` (engineering) repo or a `project` (work-item coordination) repo,
but not both. In practice, a mono-repo may legitimately serve multiple roles simultaneously:
it may contain multiple deployables, host cross-repo work items, and host PM product
documentation all at once.

## Decision

### 1. Three distinct concepts replace the single "product" concept

**Deployable** — a technical deployable unit. A deployable is independently deployable, has
its own version lifecycle, runbook, security posture, and deployment configuration. Examples:
the iOS mobile app, the rewards backend API, the browser extension, the web frontend, a
data pipeline.

**Product** — a user-facing business capability managed by a Product Manager. A product
spans multiple deployables across one or more repositories. It has requirements, strategy,
goals, success metrics, and a roadmap, but it does not have its own runbook or deployment
configuration — those belong to the deployables that implement it.

**Project** — a work item or initiative that coordinates delivery across one or more
deployables (unchanged from existing design). Projects are time-bounded and produce
artifacts in `.forge/efforts/<work-id>/`.

These concepts are not mutually exclusive within a repository. A mono-repo may host
deployables, products, and projects simultaneously.

### 2. Directory structure follows the concept

```
.forge/
├── deployables/        # Present when the repo has the "deployable" role
│   └── <name>/        # One directory per deployable unit
├── efforts/          # Present when the repo has the "effort" role
│   └── <work-id>/     # One directory per work item
└── products/          # Present when the repo has the "product" role
    └── <name>/        # One directory per PM product (e.g., favorites, sign-up)
```

### 3. Deployable canonical artifacts replace product canonical artifacts

`.forge/deployables/<name>/` holds the canonical, living artifacts for a technical deployable
unit. This is the same structure previously described for `.forge/products/<name>/` in
ADR-025, renamed to eliminate the vocabulary collision:

```
.forge/deployables/<deployable-name>/
├── README.md
├── requirements/
│   ├── business.md
│   └── technical.md
├── spec/
│   ├── README.md
│   ├── arch-decisions/
│   └── interfaces/
│       ├── api/
│       ├── events/
│       └── library/
├── dependencies/
│   └── <publisher-name>.md
├── capabilities/
│   ├── README.md
│   └── <capability-name>/
│       ├── requirements/
│       ├── spec/
│       └── test-strategy.md
├── test-strategy.md
├── security.md
├── deployment.md
└── runbook/
    ├── README.md
    └── <area>.md
```

All rules from ADR-025 (explicit registration, incremental updates at PR merge, interface
ownership following the publisher, etc.) continue to apply — this is a rename, not a
redesign of deployable-level governance.

### 4. PM product canonical artifacts live in `.forge/products/<name>/`

Each PM product has a directory at `.forge/products/<product-name>/` capturing the
cross-deployable view that the PM manages:

```
.forge/products/<product-name>/
├── README.md               # overview: PM owner, target users, current status
├── strategy.md             # vision, goals, OKRs, success metrics
├── requirements/
│   └── business.md         # cross-deployable PM requirements
├── roadmap.md              # PM roadmap
├── deployables.md           # which deployables implement this, with repo cross-refs
└── artifacts/
    └── README.md           # generated artifacts (analysis, prototypes, outputs)
```

PM product artifacts describe *what* the product should do from a user and business
perspective. They do not own runbooks, security policies, or deployment configurations —
those belong to the deployables that implement the product.

PM products are registered explicitly, just as deployables are. `forge:product-init` creates
the directory stub. The PM or team registers the product when they begin formalizing its
requirements.

### 5. Repository roles replace the single `repo_type` field

`forge:init` writes a `repo_types` array to `.forge/version`. A repository may have one or
more roles:

```
repo_types = ["deployable"]                      # default for service/app repositories
repo_types = ["effort"]                        # work item coordination repo
repo_types = ["product"]                        # PM product documentation repo
repo_types = ["product", "effort"]             # PM docs + work item coordination (mono-repo)
repo_types = ["deployable", "effort"]           # deployable repo with cross-repo coordination
repo_types = ["deployable", "product", "effort"]  # all three roles
```

Migration: existing repos with `repo_type = product` (the old scalar, meaning an engineering
deployable) are treated as `repo_types = ["deployable"]`. Existing `repo_type = effort` maps
to `repo_types = ["effort"]`. Both the old scalar and the new array are valid until the
forge-init epic implements the migration tooling.

### 6. Work item state references deployables, not products

The `products` field in `.state.json` — which identified the technical deployables a work
item contributes to — is renamed to `deployables`. The `capabilities` field (which uses
`<product>/<capability>` form) is updated to `<deployable>/<capability>` form:

```json
"deployables": ["mobile-app", "rewards-api"],
"capabilities": ["rewards-api/favorites"]
```

A companion `businessProducts` field (optional) allows a work item to be attributed to a
PM product for traceability:

```json
"businessProducts": ["favorites"]
```

This field is informational — it does not drive phase gate logic. It supports navigation
from a work item to the PM product it contributes to.

## Alternatives Considered

**Keep "product" for engineering, find a different term for the PM concept** — considered
terms such as "capability", "domain", "program area". Rejected because Product Managers
already own the term "product" in the organization's vocabulary, and engineering using it
for a different concept creates ongoing confusion at the PM-engineering boundary. Giving
engineering a clearer term ("deployable") and letting PM keep "product" is more durable.

**Nested products — PM product contains sub-products (the deployables)** — rejected because
it misrepresents the relationship. A deployable (the mobile app) is not a sub-product of
"Favorites" — it implements *many* PM products simultaneously. The many-to-many relationship
between deployables and PM products cannot be cleanly expressed as a hierarchy.

**Single flat directory with a `kind` field** — a single `.forge/deliverables/<name>/kind`
distinguishing deployables from PM products. Rejected because the artifact structures are
different enough (deployables have runbooks, security policies, deployment configs; PM products
have strategy and cross-deployable references) that sharing a directory root with a
discriminator field adds conceptual overhead without simplifying the structure.

## Consequences

**Positive:**
- Engineering and PM vocabulary are fully aligned: each group uses "product" and "deployable"
  consistently with their own mental model, with no ambiguity at the boundary
- The full requirements for a PM product (Favorites, Sign Up, Referral Program) have a
  single authoritative home, regardless of how many deployables implement it
- Repository roles are explicit and composable — a mono-repo with multiple roles is a
  first-class citizen, not an edge case
- All ADR-025 governance rules for canonical artifacts are preserved; this is a rename with
  a new concept added, not a redesign

**Negative / Watch:**
- Renames `.forge/products/<name>/` to `.forge/deployables/<name>/` across all existing
  repositories — existing installations require a migration step. The forge-init epic must
  provide a migration skill that renames the directory and updates all cross-references
- The `products` field in `.state.json` is renamed to `deployables`, requiring a JSON
  migration in all existing work items. The old field name should be accepted as a fallback
  until migration is confirmed complete
- Two directories that both start with a different sense of "p" (`products/` = PM, was
  engineering; `projects/` = work items) remain adjacent in `.forge/`. The rename
  `.forge/products/` → `.forge/deployables/` removes the previous ambiguity but teams must
  learn the new mapping

**Open question (deferred to forge-init epic):**
Migration tooling: how does `forge:migrate` identify and update all repositories using the
old `products/` directory and `products` state field? This includes cross-repo references
in `effortRef` and `parentId` fields that may embed product names.
