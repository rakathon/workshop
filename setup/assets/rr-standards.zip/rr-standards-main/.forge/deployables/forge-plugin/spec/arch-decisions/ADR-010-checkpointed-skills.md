← [Decisions Index](README.md)

# ADR-010: Multi-Artifact Skills Are Checkpointed and Resumable

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Some skills write multiple artifacts in sequence — `workflow/init` creates the directory structure and several state files; `spec/api` produces a contract, an examples file, and an error catalog. If a skill is interrupted mid-way (network error, context limit, engineer Ctrl-C), the partial state is inconsistent: some artifacts exist, others do not. Without a recovery mechanism, the engineer must either manually identify and remove partial artifacts before re-running, or accept an inconsistent state that may cause downstream skills to fail with confusing errors.

## Decision

Skills that write more than one artifact record their progress in the `checkpoint` field of `.state.json` after each step. On invocation, a skill checks for an active checkpoint: if one exists for the same skill, it resumes from the last completed step rather than starting over.

## Consequences

**Positive:**
- Re-invoking an interrupted skill continues from where it stopped rather than duplicating already-completed work
- Partial state is never silently accepted — the checkpoint makes it explicit that a skill is in-progress
- `workflow/status` surfaces active checkpoints so engineers are aware of in-progress operations

**Negative:**
- The checkpoint field must be explicitly cleared when a skill completes successfully or is abandoned — stale checkpoints from skills that will not be resumed must be detectable and clearable
- Every multi-artifact skill must implement checkpoint read/write logic, adding implementation overhead to each skill
- A checkpoint from a partially-completed skill of version N may not be compatible with the skill's logic if the skill is updated to version N+1 before the checkpoint is cleared
