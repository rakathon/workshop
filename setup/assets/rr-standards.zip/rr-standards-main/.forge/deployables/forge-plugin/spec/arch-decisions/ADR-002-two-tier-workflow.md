← [Decisions Index](README.md)

# ADR-002: Two-Tier Workflow, Not One Configurable Workflow

**Status:** Accepted  
**Date:** 2026-03-03

## Context

Different work types carry different risk profiles. Initiative/epic work involves architectural decisions, cross-team coordination, and high blast-radius changes — it benefits from enforced upstream phases (requirements, design, validation). Story/task work is often well-understood, low-risk, and fast-moving — mandatory upstream phases create overhead that causes engineers to bypass the system entirely on small items, defeating the purpose of having a workflow at all. A single configurable workflow that applies the same rules to all work types either over-engineers low-risk work or under-engineers high-risk work.

## Decision

The system has two tiers with different defaults, not different permissions. For initiative/epic work, all upstream phases (requirements, design, validation) are required. For story/task work, those phases are skipped by default but are available on demand — the engineer invokes the relevant skill and the phase is added to the workflow state, activating the corresponding gate.

## Consequences

**Positive:**
- High-stakes work receives enforced rigor without requiring configuration
- Low-risk work follows a fast default path, reducing friction and improving adoption
- The full toolset is available to engineers at all tiers — opting in is always possible
- Phase gate mechanism ensures that once an engineer opts into a phase, they cannot skip its approval gate

**Negative:**
- The story/task path relies on engineer judgment to decide when to invoke optional phases — this cannot be enforced by the tool
- Two tiers means two sets of documentation, two sets of state transitions, and two sets of tests to maintain
- Engineers unfamiliar with the system may not know when to opt into optional phases
