# Architectural Decisions

| ADR | Title | Status |
|-----|-------|--------|
| [ADR-033](ADR-033-project-local-template-overrides.md) | Project-Local Template Overrides for Forge Plugin Templates | Accepted |
| [ADR-032](ADR-032-phase-sentinel-automatic-phase-advancement.md) | Phase Sentinel — Automatic Phase Advancement via forge:promote | Accepted |
| [ADR-031](ADR-031-no-phase-gate-enforcement.md) | No Phase Gate Enforcement in Forge v1 | Accepted |
| [ADR-030](ADR-030-atlassian-mcp-bundled-with-forge-plugin.md) | Atlassian MCP Bundled with the Forge Plugin | Accepted |
| [ADR-001](ADR-001-repository-as-state-store.md) | Repository as State Store, Not a Service | Accepted |
| [ADR-002](ADR-002-two-tier-workflow.md) | Two-Tier Workflow, Not One Configurable Workflow | Accepted |
| [ADR-003](ADR-003-skills-reference-standards.md) | Skills Reference Standards, Never Embed Rules | Accepted |
| [ADR-004](ADR-004-jira-is-downstream.md) | Jira Is Downstream, Not Co-Equal | Accepted |
| [ADR-005](ADR-005-non-interactive-claude-for-automation.md) | Non-Interactive Claude for Automation | Accepted |
| [ADR-006](ADR-006-discovery-is-a-single-phase.md) | Discovery Is a Single Phase, Not Two Sequential Phases | Accepted |
| [ADR-007](ADR-007-single-pre-implementation-gate.md) | The Only Pre-Implementation Gate Is Discovery, Not Validation | Accepted |
| [ADR-008](ADR-008-structured-git-notes.md) | Structured git notes as the Task Metadata Layer | Accepted |
| [ADR-009](ADR-009-revert-at-work-unit-level.md) | Revert Operates at the Work-Unit Level, Not the Commit Level | Accepted |
| [ADR-010](ADR-010-checkpointed-skills.md) | Multi-Artifact Skills Are Checkpointed and Resumable | Accepted |
| [ADR-011](ADR-011-git-submodule-distribution.md) | git submodule as the Distribution Mechanism | Superseded by ADR-016 |
| [ADR-012](ADR-012-declared-package-dependencies.md) | Package Dependencies Are Declared and Resolved, Not Assumed | Superseded by ADR-016 |
| [ADR-013](ADR-013-phase-state-reversible-via-reopen.md) | Phase State Is Reversible via workflow/reopen, Not via Overwriting | Accepted |
| [ADR-014](ADR-014-safe-unsafe-remediation-classification.md) | Autonomous Remediation Is Bounded by a Safe/Unsafe Action Classification | Accepted |
| [ADR-015](ADR-015-isolated-sub-agents.md) | Analytical Skills Run as Isolated Sub-Agents to Prevent Context Pollution | Accepted |
| [ADR-016](ADR-016-two-tier-plugin-distribution.md) | Plugin-Based Distribution — Forge Plugin Bundles Skills and Standards | Accepted |
| [ADR-017](ADR-017-standards-discoverability-via-claude-md.md) | Standards Are Discoverable via CLAUDE.md, Not via a Service | Accepted |
| [ADR-018](ADR-018-github-actions-as-automation-platform.md) | GitHub Actions Is the Deployment Orchestration and Automation Platform | Accepted |
| [ADR-019](ADR-019-brownfield-codebase-context-in-docs.md) | Brownfield Codebase Context Is Produced Once and Stored in docs/codebase/ | Accepted |
| [ADR-020](ADR-020-mandatory-adoption-enforced-via-init-and-review.md) | Mandatory Adoption Is Enforced via forge:init and forge:review as a Required Status Check | Accepted |
| [ADR-021](ADR-021-version-currency-via-semantic-versioning-and-lag-periods.md) | Version Currency Is Enforced via Semantic Versioning with Lag Periods and Active-Work Protection | Accepted |
| [ADR-022](ADR-022-forge-review-fails-closed-on-ai-outage.md) | forge:review Fails Closed on AI Service Outage | Accepted |
| [ADR-023](ADR-023-work-item-hierarchy-modeled-in-state.md) | Work Item Hierarchy Is Modeled in State, Not Directory Structure | Accepted |
| [ADR-024](ADR-024-spike-as-first-class-work-item-type.md) | Spike Is a First-Class Work Item Type with Investigation-Specific Phases and Artifacts | Accepted |
| [ADR-025](ADR-025-product-scoped-canonical-artifact-directory.md) | Product-Scoped Directory Structure for Canonical Artifacts | Superseded by ADR-029 |
| [ADR-026](ADR-026-per-project-plugin-version-pinning.md) | Per-Project Plugin Version Pinning via Committed Local Marketplace | Accepted |
| [ADR-027](ADR-027-cross-repo-effort-artifacts-in-shared-effort-repositories.md) | Cross-Repository Effort Artifacts Are Hosted in Shared Effort Repositories | Accepted |
| [ADR-028](ADR-028-capabilities-as-bounded-capabilities-within-products.md) | Capabilities Are Bounded Capabilities Within Deployables | Accepted |
| [ADR-029](ADR-029-deployable-project-product-repository-roles.md) | Deployable, Effort, and Product as Distinct Repository Roles | Accepted |

## Adding a New ADR

1. Copy the template below into a new file: `ADR-NNN-short-title.md`
2. Fill in all sections
3. Add a row to the table above

```markdown
← [Decisions Index](README.md)

# ADR-NNN: Title

**Status:** Proposed | Accepted | Deprecated | Superseded by [ADR-NNN](ADR-NNN-filename.md)
**Date:** YYYY-MM-DD

## Context

[The situation, forces, and problem that motivated this decision]

## Decision

[What was decided]

## Consequences

**Positive:**
- ...

**Negative:**
- ...

## Alternatives Considered

[Optional — include when alternatives were explicitly weighed]
```
