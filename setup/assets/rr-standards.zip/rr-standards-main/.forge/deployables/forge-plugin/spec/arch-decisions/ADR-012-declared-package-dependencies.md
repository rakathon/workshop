← [Decisions Index](README.md)

# ADR-012: Package Dependencies Are Declared and Resolved, Not Assumed

**Status:** Superseded by [ADR-016](ADR-016-two-tier-plugin-distribution.md)
**Date:** 2026-03-03
**Superseded:** 2026-03-08

## Supersession Note

This ADR described a `setup.sh`-based package resolver with explicitly declared
`Requires:` dependencies across packages (`rr-core`, `workflow-light`, `workflow-full`).
That model was superseded when ADR-016 adopted the Claude Code plugin model as the
single delivery mechanism. The plugin is now the unit of distribution: all skills are
co-installed when the plugin is installed, so there is no partial-install state that
could produce runtime "skill not found" errors. The concern this ADR addressed is
resolved structurally rather than by a resolver.

The original decision is preserved below for historical reference.

---

## Context

The rr-standards package system has multiple packages with inter-dependencies. Skills in one package may call skills from another at runtime — for example, `implement/commit` (in the `implementation` package) calls `plan/update` (in the `workflow-light` package). If a team installs `implementation` without `workflow-light`, the call fails at runtime with a confusing "skill not found" error whose root cause — a missing package — is not obvious. The alternative is to assume engineers install the correct combination, which is the failure mode the gap analysis identified as a real problem.

## Decision

Each package explicitly declares its dependencies (`Requires:`). `setup.sh` resolves the full dependency closure before installing — a team installing `workflow-full` automatically gets `workflow-light` and `rr-core` without having to know that. Packages that require another package's skills at runtime are not installable in isolation.

## Consequences

**Positive:**
- Missing package dependencies are caught at installation time, not at runtime
- Engineers do not need to understand the internal dependency graph to install a package correctly
- The dependency graph is shallow (max 2 hops), so resolution is trivial with no diamond dependency problems

**Negative:**
- `setup.sh` must implement dependency resolution logic — for the current graph depth a simple topological sort over a hardcoded adjacency list is sufficient, but this must be maintained as new packages are added
- If the graph grows significantly in depth or gains conditional dependencies, the resolution logic becomes a candidate for a more formal solver
