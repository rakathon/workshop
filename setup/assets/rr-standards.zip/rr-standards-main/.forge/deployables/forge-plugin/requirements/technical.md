# Technical Requirements — Forge Framework

<!-- graduated-from: forge-update at 2026-04-13T15:44:47Z -->

Founding document: [`.forge/efforts/forge-plugin/requirements/technical.md`](../../../projects/forge-plugin/requirements/technical.md)

Requirements were established during the forge-plugin program discovery phase. The
founding document is the authoritative source. Amendments below record changes made
after discovery approval; refer to the founding document for the complete development
lifecycle phase specifications (Phases 1–8) and implementation requirements.

---

## Amendments

### Amendment to Section 2: Discovery Phase Capabilities (ADR-028)

- Test strategy is not a work item discovery artifact. It is authored directly in the
  deployable or capability canonical directory during discovery and maintained there as a
  living document. Discovery capabilities must write test strategy to
  `.forge/deployables/<name>/capabilities/<capability>/test-strategy.md` (or the deployable-level
  `test-strategy.md` for cross-capability concerns), not to the work item's `spec/`
  directory. Design validation reads the test strategy from the canonical path derived
  from the work item's `capabilities[]` field.

### Amendment to Section 1: Workflow Infrastructure (ADR-028)

- The workflow state model (`.state.json`) must carry two deployable-relationship fields
  for every work item: `deployables` (the deployables the work item contributes to) and
  `capabilities` (the specific capabilities within those deployables, in `<deployable>/<capability>`
  form). Both are set during discovery and may be empty at work item creation.
- The framework must support a `capabilities/` subdirectory within each deployable's canonical
  directory (`.forge/deployables/<name>/capabilities/<capability-name>/`), containing
  capability-level requirements, design, and test strategy. Capability directories are
  created during discovery, not at repository initialization.

### Amendment to Section 1: Workflow Infrastructure (BR-23)

- The work item hierarchy must support parent-child relationships across repository
  boundaries. An epic in one repository must be able to declare a parent work item
  that exists in a different repository, and the framework must be able to resolve
  that reference.
- Project-level artifacts (requirements, design) must be able to exist at a scope
  independent of any single product repository. The current model roots all artifacts
  in a repository; a project spanning multiple repositories cannot have its top-level
  documentation canonically inside any one of them.
- The master work registry must be able to represent work items whose full context
  lives in a different repository.

### Amendment to Section 2: Discovery Phase Capabilities (BR-23)

- When discovery artifacts are created in a product repository as part of a project,
  those artifacts must carry structured metadata identifying the originating project.
  Traceability cannot depend on naming conventions or commit message discipline alone.

### Amendment to Constraints (BR-23)

- Product repositories must remain independently functional. The framework must not
  require simultaneous access to all participating repositories for routine
  single-repository work.

---

## forge:update Technical Requirements

### TR-1: Uninitialized Repository Handling

#### TR-1.1: Detection

`forge:update` must check for the existence of `.forge/version` as its first action.
If the file is absent, the repository has not been initialized with `forge:init` and
there is no version baseline to migrate from.

#### TR-1.2: Output and Exit Behavior

When `.forge/version` is absent, `forge:update` must:

- Print a message identifying that the repository is not initialized for Forge
- Direct the engineer to run `forge:init` to initialize it
- Exit without making any changes to the repository

The exit must be clean (exit 0) — an uninitialized repository is an expected condition,
not an error. No warning or error prefix is appropriate.

---

### TR-2: Migration Manifest Format

#### TR-2.1: Manifest Location

Each Forge plugin version that requires configuration migration must include a manifest
file at:

```
plugins/forge/migrations/<from-version>-to-<to-version>.json
```

For example, a migration from `v1.2.0` to `v2.0.0` would be declared in
`migrations/v1.2.0-to-v2.0.0.json`. Manifests are only present when a migration is
required; their absence means no structural changes are needed for that version jump.

#### TR-2.2: Manifest Schema

Each manifest is a JSON file with the following structure:

```json
{
  "from": "1.2.0",
  "to": "2.0.0",
  "breaking": true,
  "steps": [
    { "op": "create-dir",  "path": ".forge/capabilities" },
    { "op": "rename",      "from": ".forge/spec/interfaces", "to": ".forge/interfaces" },
    { "op": "state-field", "field": "currentPhase", "rename": "phase" },
    { "op": "claude-md",   "action": "refresh" }
  ]
}
```

Fields:

| Field | Type | Description |
|-------|------|-------------|
| `from` | semver string | The version this manifest migrates from |
| `to` | semver string | The version this manifest migrates to |
| `breaking` | boolean | `true` if this is a MAJOR version migration |
| `steps` | array | Ordered list of migration operations (see TR-2.3) |

#### TR-2.3: Supported Operation Types

The following operation types must be supported. Each is an entry in the `steps` array.

| `op` | Required fields | Description |
|------|----------------|-------------|
| `create-dir` | `path` | Create a directory at `path` if it does not exist. No-op if already present. |
| `rename` | `from`, `to` | Move a file or directory from `from` to `to`. No-op if `from` is absent (already applied). Error if `to` already exists and is not the result of a prior rename. |
| `state-field` | `field`, `rename` | In every `.state.json` under `.forge/efforts/`, rename JSON field `field` to `rename`. No-op on files that already use the new field name. |
| `claude-md` | `action: "refresh"` | Replace the forge-managed section of `CLAUDE.md` with the current template from the new plugin version, preserving all content outside the managed section. |

No operation types other than those listed may appear in a manifest. An unrecognised
`op` value must cause `forge:update` to abort with a diagnostic before applying any
steps.

---

### TR-3: Sequential Multi-Version Migration

#### TR-3.1: Step-by-Step Application

When the repository version and the target version span multiple manifest steps (e.g.,
the repository is at `v1.0.0` and the target is `v3.0.0`), `forge:update` must apply
each manifest in sequence — `v1.0.0→v2.0.0` then `v2.0.0→v3.0.0` — rather than
synthesizing a combined migration plan.

Each manifest is applied in full before the next begins. This ensures each migration
runs against a known intermediate state derived from the prior migration's output, not
against a synthesized projection of the final state.

#### TR-3.2: Manifest Discovery

`forge:update` discovers applicable manifests by:

1. Reading `active_version` from `.forge/version` as the starting point
2. Scanning `plugins/forge/migrations/` in the installed plugin cache for manifest
   files whose `from` field is ≥ `active_version` and ≤ target version
3. Sorting discovered manifests by `from` version (ascending)
4. Applying them in that order

If no manifests are found for the version range, `forge:update` proceeds with only the
always-required steps (CLAUDE.md refresh, version record update) and treats the
migration as non-breaking.

#### TR-3.3: Intermediate State Consistency

Between manifests, no version record update is written. The version record is updated
only once, after all manifests have been applied successfully (TR-5). If a manifest
fails mid-sequence, the repository may be in an intermediate state — some manifests
applied, others not — but the version record will still reflect the last successfully
completed full migration, allowing re-run to recover (TR-4).

---

### TR-4: Re-Run Idempotency

#### TR-4.1: Requirement

Every migration step must be safe to re-apply. If `forge:update` is interrupted or
fails mid-migration, re-running it must produce the same result as if the migration
had completed without interruption. Steps that already completed must not fail or
produce duplicate changes on re-run.

#### TR-4.2: Per-Operation Idempotency Rules

Each operation type must implement the following check-before-apply behavior:

| Operation | Idempotency behavior |
|-----------|---------------------|
| `create-dir` | Skip if directory already exists |
| `rename` | Skip if `from` path is absent (move already completed). Error if both `from` and `to` exist (ambiguous state — requires engineer resolution). |
| `state-field` | Skip files where the field is already using the new name |
| `claude-md` refresh | Always re-apply — the managed section is replaced in full, making re-application safe |

#### TR-4.3: Re-Run Entry Point

Because the version record is not updated until all steps complete (TR-5), a re-run
after partial failure will re-enter the migration from the beginning of the first
unapplied manifest. Steps from prior manifests that have already been applied will
be skipped per TR-4.2, and the migration will continue from where it failed.

---

### TR-5: Version Record as Terminal Operation

#### TR-5.1: Update Order

Updating `.forge/version` must be the final operation in every migration. All manifest
steps — across all applicable manifests — must be applied before the version record
is written. The version record update is not part of any manifest; it is always
performed by `forge:update` itself after all manifest steps complete.

#### TR-5.2: Fields Updated

On successful completion, `forge:update` must update the following fields in
`.forge/version`:

| Field | New value |
|-------|-----------|
| `active_version` | Target version |
| `forge_min_version` | Target version |
| `last_migrated_with` | Target version |
| `last_migrated_at` | UTC timestamp of this migration |

`initialized_with` and `initialized_at` are never modified by `forge:update`.

#### TR-5.3: Completion Signal

An updated version record is the definitive signal that migration is complete. A
repository whose `active_version` does not match the installed plugin version has
either not been migrated or experienced a failed migration. The version record must
not be updated speculatively or partially — it reflects a successfully completed end
state, not progress toward one.
