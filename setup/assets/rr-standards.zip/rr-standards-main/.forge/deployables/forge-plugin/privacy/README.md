# Privacy — Forge Framework

_To be populated during the forge-plugin discovery and implementation phases._

## Data Handled

| Data | Classification | Source | Purpose |
|------|---------------|--------|---------|
| PR diff content | Internal | GitHub | Code review analysis |
| Repository file contents | Internal | Local filesystem / GitHub | Standards injection, review |
| Engineer session context | Internal | Claude Code session | Workflow state |

The Forge framework does not collect, store, or transmit personal data as part of
its normal operation. It operates on code and workflow artifacts. Privacy review
applies primarily to the `forge:review` CI integration (which processes PR content
in GitHub Actions) and any future Jira or DataDog integrations.

## Retention

Forge does not own a datastore. Review output records written to the CI metrics
database (per forge-plugin TR-7.3) are subject to the retention policy of that
database, owned by the Productivity Engineering team.

## Applicable Standards

- `forge:review --checks privacy` applies the organizational privacy standard to
  PRs touching member data — this is a review capability, not a data handling concern
  of the framework itself

## Amendments

_None._
