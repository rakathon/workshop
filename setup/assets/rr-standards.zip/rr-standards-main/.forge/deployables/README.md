# Product Registry

Products in this repository. Each product has canonical living artifacts under its
directory. Work items that contribute to a product are listed in the work item registry
(`.forge/efforts/README.md`) and reference this product in their `.state.json`.

| Product | Type | Status | Description |
|---------|------|--------|-------------|
| [forge-plugin](forge-plugin/README.md) | Framework | Active | AI-accelerated software development process — workflow, skills, hooks, and integrations |
| [rr-standards-plugin](rr-standards-plugin/README.md) | Plugin | Active | Coding guidelines, standards taxonomy, and authoring/review skills |
