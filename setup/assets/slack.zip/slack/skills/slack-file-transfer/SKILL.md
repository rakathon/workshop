---
name: slack-file-transfer
description: Upload a local file to a Slack channel, or download all file attachments from a Slack channel to a local directory. Uses the /slack-auth token (xoxp-) and calls the Slack Web API directly — no Slack MCP server required. Use when you need to share a file into Slack or retrieve files someone posted.
invocable: true
tools: Read, Write, Bash, AskUserQuestion
---

# Slack File Transfer

Upload a file from your local machine to a Slack channel, or download all file attachments from a Slack channel to a local directory.

**Usage:**
- `/slack-file-transfer` — interactive: find a channel, then choose upload or download

**Requirements:**
- A stored user token from `/slack-auth`. Run that skill first if you have never authenticated, or if the token was revoked.
- Scopes needed: `files:read` (download), `files:write` + `chat:write` (upload), `search:read` (channel search)

---

## Phase 0: Load and Validate the User Token

Load the token from `~/.slack_user_tokens.json`. Handle token rotation automatically.

```python
import json, os, time, urllib.request, urllib.parse

CLIENT_ID = '3414236285.11054762287428'

def refresh_token_if_needed(entry):
    expires_at = entry.get('expires_at', 0)
    rt = entry.get('refresh_token')
    if not rt or time.time() < expires_at - 300:
        return entry
    post = urllib.parse.urlencode({
        'client_id': CLIENT_ID, 'grant_type': 'refresh_token', 'refresh_token': rt,
    }).encode('ascii')
    req = urllib.request.Request(
        'https://slack.com/api/tooling.tokens.rotate', data=post, method='POST',
        headers={'Content-Type': 'application/x-www-form-urlencoded'})
    with urllib.request.urlopen(req) as r:
        resp = json.loads(r.read())
    if not resp.get('ok'):
        raise RuntimeError(f"Token refresh failed: {resp.get('error')}")
    entry['token']         = resp['token']
    entry['refresh_token'] = resp['refresh_token']
    entry['expires_at']    = resp.get('exp', int(time.time()) + 43200)
    return entry

def load_user_token(team_id=None):
    token_file = os.path.expanduser('~/.slack_user_tokens.json')
    if not os.path.exists(token_file):
        return None, None, None
    with open(token_file) as f:
        stored = json.load(f)
    if not stored:
        return None, None, None
    if team_id and team_id in stored:
        entry = stored[team_id]
    elif len(stored) == 1:
        team_id, entry = list(stored.items())[0]
    else:
        return None, None, None
    entry = refresh_token_if_needed(entry)
    stored[team_id] = entry
    tmp = token_file + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(stored, f, indent=2)
    os.replace(tmp, token_file)
    return entry['token'], entry, stored

token, token_entry, stored_tokens = load_user_token()
```

**If `token` is None**, stop and display:

> **No Slack user token found.**
> Run `/slack-auth` to authenticate, then try again.

**If multiple workspaces are stored**, display them and ask which to use:

```
AskUserQuestion:
  question: "Which Slack workspace do you want to work with?"
  header: "Workspace"
  options: one per team_name in stored_tokens
```

Call `load_user_token(team_id=<selected>)` to get the final token.

**Verify the token is live:**

```python
def slack_api_get(token, method, **params):
    url = 'https://slack.com/api/' + method
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={'Authorization': f'Bearer {token}'})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

auth = slack_api_get(token, 'auth.test')
if not auth.get('ok'):
    # Stop — show error and suggest re-running /slack-auth
```

---

## Phase 1: Find and Select a Channel

Use `search.messages` with an `in:#<query>` filter to find channels. This is the correct approach — it searches only channels the user is a member of, proves membership, and returns the channel ID in a single call.

### Step 1a — Ask for a search term

```
AskUserQuestion:
  question: "Search for a Slack channel (type part of the name, e.g. 'canada' or 'bastion'):"
  header: "Channel search"
  options:
    - label: "canada"
    - label: "bookkeeper"
    - label: "bastion"
  multiSelect: false
# User may also type any term via "Other"
```

### Step 1b — Search for the channel

```python
def search_channels(token, query):
    """
    Search for channels matching query using search.messages.
    Returns list of {channel_id, channel_name, workspace} dicts, deduplicated.
    """
    results = []
    seen_ids = set()
    page = 1
    while True:
        resp = slack_api_get(token, 'search.messages',
            query=f'in:#{query}',
            count=20,
            page=page,
            highlight='false')
        if not resp.get('ok'):
            break
        messages = resp.get('messages', {}).get('matches', [])
        for msg in messages:
            channel = msg.get('channel', {})
            cid = channel.get('id')
            cname = channel.get('name', cid)
            if cid and cid not in seen_ids:
                seen_ids.add(cid)
                results.append({
                    'channel_id': cid,
                    'channel_name': cname,
                })
        paging = resp.get('messages', {}).get('paging', {})
        if page >= paging.get('pages', 1):
            break
        page += 1
    return results
```

Display results as plain text before the AskUserQuestion:

```
Found N channel(s) matching "canada":

  1. #wg-canada-bookkeeper (C0A8GQXG196)
  2. #canada-ops (C1234567890)
```

If no results: say so and loop back to Step 1a.

### Step 1c — Ask the user to pick a channel

```
AskUserQuestion:
  question: "Which channel would you like to use?"
  header: "Select channel"
  options:
    - label: "1. #wg-canada-bookkeeper (C0A8GQXG196)"   ← one per result
    - label: "Search again"
  multiSelect: false
```

- Channel selected → store `{channel_id, channel_name}`, proceed to Phase 2.
- "Search again" → loop back to Step 1a.

---

## Phase 2: Choose Operation

```
AskUserQuestion:
  question: "What would you like to do with #<channel_name>?"
  header: "Operation"
  options:
    - label: "Upload a file to this channel"
      description: "Post a file from your local machine as a Slack attachment"
    - label: "Download all files from this channel"
      description: "Save every file attachment posted in the channel to a local directory"
  multiSelect: false
```

---

## Phase 3A: Upload a File

### Step 3A-1 — Select a local file

Start in the current working directory. Present a directory browser loop so the user can navigate without typing a full path.

**Step A: Ask which starting directory:**

```
AskUserQuestion:
  question: "Where would you like to browse for the file?"
  header: "Starting directory"
  options:
    - label: "Current directory (<show absolute path of cwd>)"
    - label: "~/Downloads"
    - label: "~/Desktop"
  multiSelect: false
# User may type a custom absolute path via "Other"
```

Resolve `~` paths to absolute with:
```bash
echo "$HOME"
```

**Step B: List files in the chosen directory:**

```bash
ls -lh --time-style="+%b %d %Y" "<chosen_dir>" 2>/dev/null | grep -v '^total' | head -40
```

Display the listing as plain text, then ask:

```
AskUserQuestion:
  question: "Select a file to upload, navigate to a subdirectory, or type a custom path:"
  header: "Browse files"
  options: <one per entry from ls — directories suffixed with "/", files show size>
    - label: "reports/"           ← subdirectory
    - label: "export.csv (24 KB)" ← file with size
    - label: "Go up one level (..)"
    - label: "Enter path manually"
  multiSelect: false
```

- If user picks a directory → set it as the new current dir, repeat Step B.
- If user picks "Go up one level" → `os.path.dirname(current_dir)`, repeat Step B.
- If user picks "Enter path manually" → ask for path via AskUserQuestion "Other" option, then validate it exists and is a file.
- If user picks a file → resolve to absolute path, confirm and proceed.

**Step C: Confirm the selection:**

```
AskUserQuestion:
  question: "Upload '<filename>' (<size>) to #<channel_name>?"
  header: "Confirm upload"
  options:
    - label: "Yes — upload this file"
    - label: "Choose a different file"
  multiSelect: false
```

"Choose a different file" → return to Step A.

### Step 3A-2 — Optionally add a message

```
AskUserQuestion:
  question: "Add a caption or message with the file? (optional)"
  header: "Caption"
  options:
    - label: "No message — just the file"
    - label: "Add a message (type in 'Other')"
  multiSelect: false
```

If "Add a message": the user types via "Other". Store as `initial_comment`.

### Step 3A-3 — Upload the file using the v2 API

Slack's current upload API is a three-step process:

**Step 1: Get an upload URL**

```python
import os

file_path = '<resolved absolute path>'
file_name = os.path.basename(file_path)
file_size = os.path.getsize(file_path)

resp = slack_api_get(token, 'files.getUploadURLExternal',
    filename=file_name,
    length=str(file_size))

if not resp.get('ok'):
    # Show error and abort
    raise RuntimeError(f"Could not get upload URL: {resp.get('error')}")

upload_url = resp['upload_url']
file_id    = resp['file_id']
```

**Step 2: POST the file content to the upload URL**

Use `curl` with POST and `--data-binary` for this step. Despite what some Slack documentation says, the upload URL requires a **POST**, not a PUT. The correct response body is `OK - <N>` where N is the byte count; if you get HTML back, the bytes did not land.

Do NOT use `-L` (follow redirects) and do NOT use `-X PUT`. No `Authorization` header is needed for this step — the URL is pre-signed.

```python
import subprocess

result = subprocess.run([
    'curl', '-s', '-w', '\nHTTP_STATUS:%{http_code}',
    '-X', 'POST',
    '-H', 'Content-Type: application/octet-stream',
    '--data-binary', '@' + file_path,
    upload_url              # no -L, no Authorization header
], capture_output=True, text=True)

output = result.stdout
post_status = output.split('HTTP_STATUS:')[-1].strip() if 'HTTP_STATUS:' in output else '?'
post_body   = output.split('HTTP_STATUS:')[0].strip()
# Expect: status=200, body="OK - <N>" where N is the file size in bytes
# If body is HTML, the upload did not land — check that you used POST, not PUT
if post_status != '200' or not post_body.startswith('OK'):
    raise RuntimeError(f"Upload step 2 failed: HTTP {post_status} body={post_body[:100]!r}")
```

**Step 3: Complete the upload — share to channel**

```python
complete_params = {
    'files': json.dumps([{'id': file_id}]),
    'channel_id': channel_id,
}
if initial_comment:
    complete_params['initial_comment'] = initial_comment

post_data = urllib.parse.urlencode(complete_params).encode('ascii')
req = urllib.request.Request(
    'https://slack.com/api/files.completeUploadExternal',
    data=post_data,
    method='POST',
    headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/x-www-form-urlencoded',
    })
with urllib.request.urlopen(req) as r:
    result = json.loads(r.read())

if not result.get('ok'):
    raise RuntimeError(f"Upload failed: {result.get('error')}")
```

**Report success:**

```
✅ File uploaded successfully!
   File:    <file_name>
   Size:    <human-readable size>
   Channel: #<channel_name>
   Slack file ID: <file_id>
```

---

## Phase 3B: Download All Files

### Step 3B-1 — Select download destination

Propose a smart default based on the channel name:

```python
default_dir = os.path.join(os.getcwd(), 'downloads', 'slack', channel_name)
```

```
AskUserQuestion:
  question: "Where should files be saved? Default: <default_dir>"
  header: "Download directory"
  options:
    - label: "Use default: downloads/slack/<channel_name>/ (Recommended)"
    - label: "Enter a custom path"
  multiSelect: false
```

If "Enter a custom path": ask via AskUserQuestion "Other" option. Expand `~` to absolute path.

Create the destination directory if it does not exist:
```bash
mkdir -p "<dest_dir>"
```

### Step 3B-2 — List all files in the channel

```python
def list_channel_files(token, channel_id):
    """
    Fetch all files shared in a channel using files.list.
    Returns list of file dicts with id, name, url_private_download, size, created, user.
    """
    files = []
    page = 1
    while True:
        resp = slack_api_get(token, 'files.list',
            channel=channel_id,
            count=200,
            page=page)
        if not resp.get('ok'):
            break
        batch = resp.get('files', [])
        files.extend(batch)
        paging = resp.get('paging', {})
        if page >= paging.get('pages', 1):
            break
        page += 1
    return files
```

Report what was found:
```
Found N file(s) in #<channel_name>.
```

If no files are found, report that and exit gracefully.

### Step 3B-3 — Delta check (skip already-downloaded files)

For each file, the local filename is `<file_id>_<file_name>` (prefixing with ID avoids collisions when the same name was posted multiple times).

```python
def local_filename(file_entry):
    return f"{file_entry['id']}_{file_entry['name']}"

def already_downloaded(dest_dir, file_entry):
    path = os.path.join(dest_dir, local_filename(file_entry))
    return os.path.exists(path)

to_download = [f for f in all_files if not already_downloaded(dest_dir, f)]
already_present = len(all_files) - len(to_download)
```

Report:
```
  Already downloaded: N (will be skipped)
  To download:        N
```

If all files are already present:
```
Nothing new to download. All N files already exist in <dest_dir>.
```
Exit gracefully.

### Step 3B-4 — Confirm before downloading

```
AskUserQuestion:
  question: "Download N file(s) to <dest_dir>?"
  header: "Confirm download"
  options:
    - label: "Yes — download N file(s)"
    - label: "Cancel"
  multiSelect: false
```

### Step 3B-5 — Download each file

Use `url_private_download` with the Bearer token. The `url_private` URL requires auth; without the token Slack returns a redirect to the login page.

```python
import shutil

downloaded = []
failed = []

for file_entry in to_download:
    url = file_entry.get('url_private_download') or file_entry.get('url_private')
    if not url:
        failed.append((file_entry['name'], 'no download URL'))
        continue

    dest_path = os.path.join(dest_dir, local_filename(file_entry))

    try:
        dl_req = urllib.request.Request(url, headers={'Authorization': f'Bearer {token}'})
        with urllib.request.urlopen(dl_req) as resp, open(dest_path, 'wb') as out:
            shutil.copyfileobj(resp, out)
        downloaded.append(file_entry['name'])
    except Exception as e:
        failed.append((file_entry['name'], str(e)))
```

Print a one-line progress update after each file:
```
  ✅ report_q1.pdf (1.2 MB)
  ✅ screenshot.png (84 KB)
  ⚠️  private_image.jpg — download failed: HTTP 403
```

### Step 3B-6 — Final summary

```
Download complete.
  Directory:   <dest_dir>
  Downloaded:  N file(s)
  Skipped:     N (already present)
  Failed:      N
```

List any failures with their error messages so the user knows what to address.

---

## Helper: Human-Readable File Size

```python
def human_size(n_bytes):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n_bytes < 1024:
            return f"{n_bytes:.0f} {unit}"
        n_bytes /= 1024
    return f"{n_bytes:.1f} TB"
```

---

## Error Handling

| Error | Action |
|---|---|
| Token missing | Stop; prompt user to run `/slack-auth` |
| Token expired / rotation fails | Stop; prompt user to run `/slack-auth` |
| `search.messages` returns `not_authed` | Stop; prompt user to run `/slack-auth` |
| No channels found in search | Tell user; loop back to channel search |
| `files.getUploadURLExternal` fails | Show `error` field from Slack; abort upload |
| PUT to upload URL fails | Show HTTP status; abort upload |
| `files.completeUploadExternal` fails | Show `error` field; abort upload |
| `files.list` returns `channel_not_found` | Tell user the channel cannot be accessed and verify membership |
| Individual file download fails (403) | Log and continue; report in final summary |
| Destination directory not writable | Tell user; abort download |

---

## Validation

After completing the skill, verify:
- ✅ Token loaded and validated before any Slack API calls
- ✅ Channel selected via search (never hardcoded)
- ✅ Upload uses v2 API (getUploadURLExternal + completeUploadExternal)
- ✅ Upload file content is PUT as bytes — not base64, not form-encoded
- ✅ Download uses `url_private_download` with Bearer token
- ✅ Delta check skips already-downloaded files
- ✅ Local filenames prefixed with Slack file ID to prevent collisions
- ✅ All errors reported clearly with next-step guidance

---

## Important Notes

- **Never use the Slack MCP server** in this skill. All API calls go directly to `https://slack.com/api/` with the `xoxp-` token from `~/.slack_user_tokens.json`.
- **Token rotation:** The token may expire mid-session (12h TTL). The load helper at Phase 0 handles pre-emptive refresh (5-minute buffer). If an API call returns `token_expired`, reload and retry once.
- **files.list scope:** `files.list` with a `channel` filter lists all files the authenticated user can see that were shared in that channel — including files from DMs that were also shared into the channel. This is the correct API for "all files in channel."
- **Large files:** The v2 upload API (getUploadURLExternal) supports files up to Slack's plan limit (~1 GB for paid). For the common case of documents and images this is never an issue.
- **Private channels:** The token needs `groups:history` (already in scope from `/slack-auth`) to access private channels. The channel search will surface only channels the user is a member of.
