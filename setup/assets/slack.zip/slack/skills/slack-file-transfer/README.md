# Slack File Transfer Skill

Upload a local file to a Slack channel, or download all file attachments from a Slack channel to a local directory. Works entirely via the Slack Web API — no Slack MCP server needed.

## Purpose

- **Upload**: Post a document, screenshot, or any file directly into a Slack channel as a proper Slack file attachment.
- **Download**: Bulk-save every file ever posted in a channel to a local directory, with delta logic to skip files already downloaded.

## Requirements

A stored Slack user token from `/slack-auth`. Run that skill once per workspace before using this one. The token is stored at `~/.slack_user_tokens.json` and auto-refreshes as needed.

## Usage

```
/slack-file-transfer
```

The skill is fully interactive — it will guide you through channel selection, then the upload or download flow.

## Upload Flow

1. Search for a channel by name (e.g. "canada" or "bookkeeper")
2. Select the channel from search results
3. Browse your local filesystem directory-by-directory, or enter a path manually
4. Optionally add a caption message
5. File is uploaded via Slack's v2 upload API (`files.getUploadURLExternal` + `files.completeUploadExternal`)

## Download Flow

1. Search for and select a channel
2. Confirm or change the destination directory (defaults to `downloads/slack/<channel_name>/`)
3. Skill fetches the full file list, skips files already present (delta download)
4. Downloads all remaining files with one-line progress per file
5. Local files are named `<file_id>_<original_name>` to prevent collisions

## Examples

### Example 1: Upload a report

```
/slack-file-transfer

Searching... select #wg-canada-bookkeeper
Choose "Upload a file"
Browse to ~/Documents/ → select "runbook-v2.pdf" (310 KB)
Add caption: "Updated runbook for review"

✅ File uploaded successfully!
   File:    runbook-v2.pdf
   Channel: #wg-canada-bookkeeper
```

### Example 2: Download channel files

```
/slack-file-transfer

Searching... select #wg-canada-bookkeeper
Choose "Download all files"
Confirm destination: downloads/slack/wg-canada-bookkeeper/

Found 14 file(s). Already downloaded: 9. To download: 5.

  ✅ 3_architecture-diagram.png (84 KB)
  ✅ 7_db-schema-v2.pdf (1.2 MB)
  ...

Download complete. Downloaded: 5, Skipped: 9.
```

## See Also

- [slack-auth skill](../slack-auth/SKILL.md) — authenticate first
- [slack-archive skill](../slack-archive/SKILL.md) — archive channel messages (not files)
