#!/usr/bin/env python3
"""
Slack Auth — Python entry point for all Python-requiring operations.
Called by slack_auth.sh whenever Python 3 is available.

Modes:
  --prepare              Non-blocking. Checks for an existing valid token, or
                         generates PKCE state, opens the browser, and exits.
                         Writes /tmp/slack_auth_state.json.

  --listen               Blocking (up to 5 min). Reads state file, starts the
                         HTTP callback server, waits for the OAuth redirect,
                         exchanges the code for a token, and stores it.

  --check                Show all stored tokens and verify each is still valid.

  --revoke               Interactively remove a stored token.

  --store <response_json> Parse an oauth.v2.access JSON response (from the
                         curl fallback path), verify the token, and store it.
"""
import json, os, sys, hashlib, base64, secrets as secrets_mod, time
import urllib.request, urllib.parse, http.server, threading, queue, subprocess, ssl

CLIENT_ID     = '3414236285.11054762287428'
REDIRECT_URI  = 'http://localhost:3013/callback'
CALLBACK_PORT = 3013
STATE_FILE    = '/tmp/slack_auth_state.json'
TOKEN_FILE    = os.path.expanduser('~/.slack_user_tokens.json')

USER_SCOPES = [
    'identify',
    'channels:history', 'groups:history', 'im:history', 'mpim:history',
    'channels:read', 'groups:read', 'mpim:read', 'emoji:read',
    'files:write', 'files:read',
    'users:read', 'users:read.email',
    'chat:write', 'reactions:read', 'reactions:write',
    'canvases:read', 'canvases:write', 'groups:write', 'im:write', 'mpim:write',
    'search:read',
]


# ── SSL / HTTP opener ─────────────────────────────────────────────────────────

def _make_ssl_ctx():
    """
    Return an SSL context that verifies certificates on any platform.

    The tricky cases:
    - python.org macOS Python ships without a CA bundle and does not wire up
      the system keychain. We export certs using the 'security' CLI instead.
    - Corporate/enterprise environments (WSL2, managed Linux) inject root CAs
      via OpenSSL's dynamic trust store. Passing an explicit cafile= to
      ssl.create_default_context() bypasses that dynamic loading and breaks
      cert verification. For these environments the only correct approach is
      ssl.create_default_context() with NO cafile argument.

    Priority order:
      1. macOS: system keychain export via 'security' CLI
      2. macOS fallback: certifi (if keychain export fails)
      3. Linux/WSL2: ssl.create_default_context() with no cafile — lets
         OpenSSL use its own trust store, including injected corporate CAs
      4. Last resort: ssl._create_unverified_context() (still encrypted)
    """
    import platform, tempfile

    # macOS: export certs from both system keychains via the 'security' CLI.
    # This is the most reliable approach for python.org macOS Python which
    # ships without a CA bundle and does not wire up the system keychain.
    if platform.system() == 'Darwin':
        try:
            certs = ''
            for kc in ('/System/Library/Keychains/SystemRootCertificates.keychain',
                       '/Library/Keychains/System.keychain'):
                r = subprocess.run(['security', 'find-certificate', '-a', '-p', kc],
                                   capture_output=True, text=True)
                if r.returncode == 0:
                    certs += r.stdout
            if certs.count('BEGIN CERTIFICATE') > 10:
                with tempfile.NamedTemporaryFile(mode='w', suffix='.pem', delete=False) as f:
                    f.write(certs)
                    ca_path = f.name
                try:
                    ctx = ssl.create_default_context(cafile=ca_path)
                finally:
                    os.unlink(ca_path)
                return ctx
        except Exception:
            pass
        # macOS fallback: certifi (ships its own CA bundle, present when pip is used)
        try:
            import certifi
            return ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            pass
        # macOS last resort: no cert verification. Reaches here only on python.org
        # macOS without certifi and with a broken 'security' CLI — very unusual.
        return ssl._create_unverified_context()

    # Linux / WSL2 / Windows: use the default context with NO explicit cafile.
    # This allows OpenSSL to load its own trust store dynamically, which is
    # essential in corporate environments where root CAs are injected via the
    # OpenSSL engine rather than written to the standard bundle file.
    # Note: ssl.create_default_context() succeeds even on misconfigured systems;
    # the context may fail at connection time. That's acceptable — if it does,
    # the caller will get a meaningful SSL error message.
    return ssl.create_default_context()


# Build the opener once at module load — avoids reconstructing the SSL context
# on every API call.
_OPENER = urllib.request.build_opener(
    urllib.request.HTTPSHandler(context=_make_ssl_ctx())
)


def _urlopen(req):
    return _OPENER.open(req)


# ── Utilities ─────────────────────────────────────────────────────────────────

def detect_platform():
    if sys.platform == 'darwin': return 'macos'
    if sys.platform == 'win32':  return 'windows'
    try:
        v = open('/proc/version').read().lower()
        if 'microsoft' in v or 'wsl' in v: return 'wsl2'
    except Exception: pass
    return 'linux'


def open_browser(url):
    p = detect_platform()
    try:
        if p == 'wsl2':
            r = subprocess.run(
                ['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe',
                 '-NoProfile', '-NonInteractive', '-Command', f'Start-Process "{url}"'],
                timeout=10, capture_output=True)
            return r.returncode == 0
        elif p == 'macos':   subprocess.Popen(['open', url]);                     return True
        elif p == 'windows': subprocess.Popen(['cmd.exe', '/c', 'start', '', url]); return True
        else:                subprocess.Popen(['xdg-open', url]);                  return True
    except Exception:
        return False


def is_user_token(t):
    return bool(t and (t.startswith('xoxp-') or t.startswith('xoxe.xoxp-')))


def slack_api_get(token, method, **params):
    url = 'https://slack.com/api/' + method
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={'Authorization': f'Bearer {token}'})
    with _urlopen(req) as r:
        return json.loads(r.read())


def refresh_token_if_needed(entry):
    expires_at = entry.get('expires_at', 0)
    rt = entry.get('refresh_token')
    if not rt or time.time() < expires_at - 300:
        return entry
    post = urllib.parse.urlencode({
        'client_id': CLIENT_ID, 'grant_type': 'refresh_token', 'refresh_token': rt,
    }).encode('ascii')
    req = urllib.request.Request(
        'https://slack.com/api/tooling.tokens.rotate', data=post, method='POST',
        headers={'Content-Type': 'application/x-www-form-urlencoded'})
    with _urlopen(req) as r:
        resp = json.loads(r.read())
    if not resp.get('ok'):
        raise RuntimeError(f"Token refresh failed: {resp.get('error')}")
    entry['token']         = resp['token']
    entry['refresh_token'] = resp['refresh_token']
    # 'exp' from tooling.tokens.rotate is an absolute Unix timestamp
    entry['expires_at']    = resp.get('exp', int(time.time()) + 43200)
    return entry


def save_stored(stored):
    tmp = TOKEN_FILE + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(stored, f, indent=2)
    os.replace(tmp, TOKEN_FILE)
    os.chmod(TOKEN_FILE, 0o600)


def load_stored():
    if not os.path.exists(TOKEN_FILE):
        return {}
    with open(TOKEN_FILE) as f:
        return json.load(f)


def write_state(data):
    with open(STATE_FILE, 'w') as f:
        json.dump(data, f, indent=2)
    os.chmod(STATE_FILE, 0o600)


def read_state():
    if not os.path.exists(STATE_FILE):
        print(f'❌ State file not found: {STATE_FILE}')
        print('   Run /slack-auth without --listen to start a fresh flow.')
        sys.exit(1)
    with open(STATE_FILE) as f:
        return json.load(f)


# ═════════════════════════════════════════════════════════════════════════════
# MODE: --prepare  (non-blocking)
# ═════════════════════════════════════════════════════════════════════════════

def mode_prepare():
    platform = detect_platform()

    # ── Check for existing valid token ────────────────────────────────────────
    stored = load_stored()
    for tid, entry in list(stored.items()):
        try:
            entry = refresh_token_if_needed(entry)
            v = slack_api_get(entry['token'], 'auth.test')
            if v.get('ok'):
                scopes = entry.get('scopes', [])
                fw = '✅' if 'files:write' in scopes else '❌'
                ea = entry.get('expires_at')
                note = ''
                if ea:
                    rem = int(ea - time.time())
                    h, m = divmod(max(rem, 0) // 60, 60)
                    note = f'valid for {h}h {m}m, then auto-refreshes'
                stored[tid] = entry
                save_stored(stored)
                write_state({
                    'status':    'existing',
                    'team_name': entry['team_name'],
                    'team_id':   tid,
                    'user_name': entry['user_name'],
                    'files_write': 'files:write' in scopes,
                    'expiry_note': note,
                    'scopes':    scopes,
                })
                print(f'Valid token found for {entry["team_name"]} ({tid}). {note}')
                print(f'User: {entry["user_name"]}  |  files:write: {fw}')
                sys.exit(0)
        except Exception as e:
            print(f'Token for {tid} is invalid ({e}), will re-authenticate.')

    # ── Generate PKCE + build auth URL ────────────────────────────────────────
    code_verifier  = secrets_mod.token_urlsafe(64)
    code_challenge = base64.urlsafe_b64encode(
        hashlib.sha256(code_verifier.encode('ascii')).digest()
    ).rstrip(b'=').decode('ascii')
    state = secrets_mod.token_urlsafe(16)

    auth_params = urllib.parse.urlencode({
        'client_id':             CLIENT_ID,
        'user_scope':            ','.join(USER_SCOPES),
        'redirect_uri':          REDIRECT_URI,
        'state':                 state,
        'code_challenge':        code_challenge,
        'code_challenge_method': 'S256',
    })
    auth_url = f'https://slack.com/oauth/v2/authorize?{auth_params}'

    # ── Write state file (read by --listen) ───────────────────────────────────
    write_state({
        'status':        'new',
        'auth_url':      auth_url,
        'code_verifier': code_verifier,
        'state':         state,
        'platform':      platform,
    })

    # ── Open browser ──────────────────────────────────────────────────────────
    launched = open_browser(auth_url)

    # ── Print URL and status ──────────────────────────────────────────────────
    print(f'Platform: {platform}')
    print(f'Browser: {"opened" if launched else "could not open automatically"}')
    print(f'AUTH_URL={auth_url}')
    sys.exit(0)


# ═════════════════════════════════════════════════════════════════════════════
# MODE: --listen  (blocking — up to 5 minutes)
# ═════════════════════════════════════════════════════════════════════════════

def mode_listen():
    s = read_state()

    if s.get('status') == 'existing':
        print('Token already stored — nothing to do.')
        sys.exit(0)

    code_verifier  = s['code_verifier']
    expected_state = s['state']

    # ── Start HTTP callback server ────────────────────────────────────────────
    received = queue.Queue()

    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            prs = urllib.parse.urlparse(self.path)
            if prs.path == '/callback':
                qs   = urllib.parse.parse_qs(prs.query)
                code = qs.get('code',  [None])[0]
                err  = qs.get('error', [None])[0]
                rs   = qs.get('state', [None])[0]
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                if code:
                    self.wfile.write(
                        b'<!DOCTYPE html><html><body style="font-family:sans-serif;'
                        b'text-align:center;padding:60px">'
                        b'<h2>&#x2705; Authentication successful!</h2>'
                        b'<p>You can close this tab and return to the terminal.</p>'
                        b'</body></html>')
                    received.put(('code', code, rs))
                else:
                    self.wfile.write(
                        b'<!DOCTYPE html><html><body style="font-family:sans-serif;'
                        b'text-align:center;padding:60px">'
                        b'<h2>&#x274C; Authentication failed</h2><p>'
                        + (err or 'unknown error').encode('utf-8')
                        + b'</p></body></html>')
                    received.put(('error', err, rs))
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, *args): pass

    try:
        server = http.server.HTTPServer(('localhost', CALLBACK_PORT), CallbackHandler)
    except OSError as e:
        print(f'❌ Cannot start callback server on port {CALLBACK_PORT}: {e}')
        print(f'   Check: lsof -i :{CALLBACK_PORT}')
        sys.exit(1)

    threading.Thread(target=server.serve_forever, daemon=True).start()
    print('Listening for OAuth callback on localhost:3013...')
    sys.stdout.flush()

    # ── Wait for callback ─────────────────────────────────────────────────────
    try:
        event_type, value, ret_state = received.get(timeout=300)
    except queue.Empty:
        print('\n❌ Timed out after 5 minutes. Re-run /slack-auth to try again.')
        sys.exit(1)
    finally:
        server.shutdown()
        try:
            os.unlink(STATE_FILE)
        except Exception:
            pass

    if ret_state != expected_state:
        print('❌ State mismatch — stale redirect. Re-run /slack-auth.')
        sys.exit(1)
    if event_type == 'error':
        print(f'❌ Slack returned an error: {value}')
        sys.exit(1)

    # ── Exchange code for token ───────────────────────────────────────────────
    print('Authorization received. Exchanging code for token...')
    sys.stdout.flush()

    post = urllib.parse.urlencode({
        'code':          value,
        'redirect_uri':  REDIRECT_URI,
        'client_id':     CLIENT_ID,
        'code_verifier': code_verifier,
    }).encode('ascii')
    req = urllib.request.Request(
        'https://slack.com/api/oauth.v2.access', data=post, method='POST',
        headers={'Content-Type': 'application/x-www-form-urlencoded'})
    with _urlopen(req) as r:
        response = json.loads(r.read())

    if not response.get('ok'):
        print(f'❌ Token exchange failed: {response.get("error")}')
        print(json.dumps(response, indent=2))
        sys.exit(1)

    au             = response.get('authed_user', {})
    user_token     = au.get('access_token')
    granted_scopes = [s for s in au.get('scope', '').split(',') if s]
    refresh_tok    = au.get('refresh_token')
    expires_in     = au.get('expires_in')
    expires_at     = int(time.time()) + expires_in if expires_in else None

    if not is_user_token(user_token):
        print('❌ No user token in response. Check User Token Scopes at api.slack.com.')
        print(json.dumps(response, indent=2))
        sys.exit(1)

    # ── Verify + store ────────────────────────────────────────────────────────
    v2 = slack_api_get(user_token, 'auth.test')
    if not v2.get('ok'):
        print(f'❌ Token verification failed: {v2.get("error")}')
        sys.exit(1)

    team_id   = v2['team_id']
    team_name = v2['team']
    user_name = v2.get('user', 'unknown')
    user_id   = v2.get('user_id', 'unknown')

    entry = {
        'team_name': team_name, 'team_id': team_id,
        'user_name': user_name, 'user_id': user_id,
        'token': user_token, 'scopes': granted_scopes,
    }
    if refresh_tok: entry['refresh_token'] = refresh_tok
    if expires_at:  entry['expires_at']    = expires_at

    stored = load_stored()
    stored[team_id] = entry
    save_stored(stored)

    fw  = '✅' if 'files:write' in granted_scopes else '❌'
    rot = f'\n   Token rotation: enabled (auto-refreshes every {expires_in // 3600}h)' if expires_in else ''

    print(f'\n✅ Slack authentication successful!\n')
    print(f'   Workspace:   {team_name} ({team_id})')
    print(f'   User:        {user_name} ({user_id})')
    print(f'   files:write: {fw}')
    print(f'   All scopes:  {", ".join(granted_scopes)}')
    print(rot)
    print(f'\nToken stored in ~/.slack_user_tokens.json')
    print('Other team members: run /slack-auth to authenticate as themselves.')

    if 'files:write' not in granted_scopes:
        print('\n⚠️  files:write was NOT granted. Add it under User Token Scopes at api.slack.com.')


# ═════════════════════════════════════════════════════════════════════════════
# MODE: --check  (show stored tokens)
# ═════════════════════════════════════════════════════════════════════════════

def mode_check():
    stored = load_stored()
    if not stored:
        print('No tokens stored. Run /slack-auth to authenticate.')
        sys.exit(0)

    print('\nStored Slack user tokens:\n')
    needs_save = False
    for tid, entry in list(stored.items()):
        try:
            refreshed = refresh_token_if_needed(entry)
            if refreshed.get('token') != entry.get('token'):
                stored[tid] = refreshed
                needs_save = True
            entry = refreshed
            v = slack_api_get(entry['token'], 'auth.test')
            status = '✅ valid' if v.get('ok') else f'❌ invalid ({v.get("error")})'
        except Exception as e:
            status = f'❌ error ({e})'
        scopes = entry.get('scopes', [])
        fw = '✅' if 'files:write' in scopes else '❌'
        ea = entry.get('expires_at')
        rot = ''
        if ea:
            rem = int(ea - time.time())
            h, m = divmod(max(rem, 0) // 60, 60)
            rot = f'\n    Rotation:    enabled — valid for {h}h {m}m'
        print(f'  {entry.get("team_name", "?")} ({tid})')
        print(f'    Status:      {status}')
        print(f'    User:        {entry.get("user_name", "?")}')
        print(f'    files:write: {fw}{rot}')
        print(f'    All scopes:  {", ".join(scopes)}')
        print()
    if needs_save:
        save_stored(stored)


# ═════════════════════════════════════════════════════════════════════════════
# MODE: --revoke  (remove a stored token)
# ═════════════════════════════════════════════════════════════════════════════

def mode_revoke():
    stored = load_stored()
    if not stored:
        print('No tokens stored.')
        sys.exit(0)

    if len(stored) == 1:
        tid, entry = list(stored.items())[0]
        print(f'Removing token for {entry["team_name"]} ({tid})...')
    else:
        print('Stored workspaces:')
        items = list(stored.items())
        for i, (tid, entry) in enumerate(items):
            print(f'  {i+1}. {entry["team_name"]} ({tid})')
        choice = input('Enter number to revoke: ').strip()
        try:
            idx = int(choice) - 1
            tid, entry = items[idx]
        except (ValueError, IndexError):
            print('Invalid selection.')
            sys.exit(1)

    del stored[tid]
    tmp = TOKEN_FILE + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(stored, f, indent=2)
    os.replace(tmp, TOKEN_FILE)
    os.chmod(TOKEN_FILE, 0o600)
    print(f'Token for {entry["team_name"]} removed from {TOKEN_FILE}')
    print('Run /slack-auth to re-authenticate.')


# ═════════════════════════════════════════════════════════════════════════════
# MODE: --store <response_json>  (curl fallback path: parse + store token)
# ═════════════════════════════════════════════════════════════════════════════

def mode_store(response_str):
    resp = json.loads(response_str)
    if not resp.get('ok'):
        print(f'❌ Token exchange failed: {resp.get("error")}')
        print(json.dumps(resp, indent=2))
        sys.exit(1)

    au  = resp.get('authed_user', {})
    tok = au.get('access_token', '')
    if not is_user_token(tok):
        print('❌ No user token. Check User Token Scopes at api.slack.com.')
        print(json.dumps(resp, indent=2))
        sys.exit(1)

    scopes = [s for s in au.get('scope', '').split(',') if s]

    v = slack_api_get(tok, 'auth.test')
    if not v.get('ok'):
        print(f'❌ Verification failed: {v.get("error")}')
        sys.exit(1)

    entry = {
        'team_name': v['team'],  'team_id':  v['team_id'],
        'user_name': v.get('user', '?'), 'user_id': v.get('user_id', '?'),
        'token':  tok, 'scopes': scopes,
    }
    if au.get('refresh_token'): entry['refresh_token'] = au['refresh_token']
    if au.get('expires_in'):    entry['expires_at']    = int(time.time()) + au['expires_in']

    stored = load_stored()
    stored[v['team_id']] = entry
    save_stored(stored)

    fw = '✅' if 'files:write' in scopes else '❌'
    print(f'\n✅ Slack authentication successful!\n')
    print(f'   Workspace:   {v["team"]} ({v["team_id"]})')
    print(f'   User:        {v.get("user","?")} ({v.get("user_id","?")})')
    print(f'   files:write: {fw}')
    print(f'   All scopes:  {", ".join(scopes)}')
    print(f'\nToken stored in {TOKEN_FILE}')
    print('Other team members: run /slack-auth to authenticate as themselves.')


# ═════════════════════════════════════════════════════════════════════════════
# Dispatch
# ═════════════════════════════════════════════════════════════════════════════

mode = sys.argv[1] if len(sys.argv) > 1 else '--prepare'

if mode == '--prepare':
    mode_prepare()
elif mode == '--listen':
    mode_listen()
elif mode == '--check':
    mode_check()
elif mode == '--revoke':
    mode_revoke()
elif mode == '--store':
    if len(sys.argv) < 3:
        print('Usage: slack_auth_listener.py --store <oauth_response_json>')
        sys.exit(1)
    mode_store(sys.argv[2])
else:
    print(f'Unknown mode: {mode}. Use --prepare, --listen, --check, --revoke, or --store.')
    sys.exit(1)
