#!/usr/bin/env bash
# Slack Auth — entry point for the /slack-auth skill.
#
# Detects the best available runtime and dispatches:
#   python3      → slack_auth_listener.py (seamless HTTP listener)
#   curl+openssl → URL-paste fallback     (works everywhere, one extra step)
#
# For native Windows without WSL2, use slack_auth.ps1 instead.
#
# The OAuth flow is split into two phases so Claude can surface the auth URL
# to the user via AskUserQuestion before the blocking listener starts:
#
#   Phase 1 (--prepare): non-blocking. Checks existing token, or generates
#     PKCE state, opens browser, writes /tmp/slack_auth_state.json, exits.
#     Claude reads the URL from output and shows it via AskUserQuestion.
#
#   Phase 2 (--listen): blocking. Reads state file, starts HTTP server,
#     waits for OAuth callback, exchanges code for token, stores result.
#
# Usage (direct):
#   bash slack_auth.sh [--prepare|--listen|--check|--revoke]

set -euo pipefail

# Resolve the directory containing this script so we can find sibling files.
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

CLIENT_ID="3414236285.11054762287428"
REDIRECT_URI="http://localhost:3013/callback"
CALLBACK_PORT=3013
TOKEN_FILE="$HOME/.slack_user_tokens.json"
USER_SCOPES="identify,channels:history,groups:history,im:history,mpim:history,channels:read,groups:read,mpim:read,emoji:read,files:write,files:read,users:read,users:read.email,chat:write,reactions:read,reactions:write,canvases:read,canvases:write,groups:write,im:write,mpim:write,search:read"


# ── Arguments ─────────────────────────────────────────────────────────────────
CHECK_MODE=0; REVOKE_MODE=0; PREPARE_MODE=0; LISTEN_MODE=0
for arg in "$@"; do
    case "$arg" in
        --check)   CHECK_MODE=1   ;;
        --revoke)  REVOKE_MODE=1  ;;
        --prepare) PREPARE_MODE=1 ;;
        --listen)  LISTEN_MODE=1  ;;
    esac
done
# Default with no flags: run --prepare
if [[ "$CHECK_MODE" -eq 0 && "$REVOKE_MODE" -eq 0 && "$PREPARE_MODE" -eq 0 && "$LISTEN_MODE" -eq 0 ]]; then
    PREPARE_MODE=1
fi


# ── Platform detection ────────────────────────────────────────────────────────
detect_platform() {
    case "${OSTYPE:-}" in
        darwin*)          echo "macos"   ;;
        msys*|cygwin*|win32*) echo "windows" ;;
        *)
            if grep -qi 'microsoft\|wsl' /proc/version 2>/dev/null; then
                echo "wsl2"
            else
                echo "linux"
            fi ;;
    esac
}
PLATFORM=$(detect_platform)


# ── Runtime detection ─────────────────────────────────────────────────────────
# On macOS 12.3+, /usr/bin/python3 is a stub that triggers an Xcode install
# dialog. Verify the interpreter actually runs before committing to it.
has_real_python3() {
    command -v python3 >/dev/null 2>&1 || return 1
    python3 -c "import sys; sys.exit(0)" 2>/dev/null || return 1
}

pick_runtime() {
    if has_real_python3; then echo "python3"
    else                      echo "curl"
    fi
}
RUNTIME=$(pick_runtime)


# ── Browser open (platform-aware) ────────────────────────────────────────────
open_browser() {
    local url="$1"
    case "$PLATFORM" in
        macos)   open "$url" 2>/dev/null & ;;
        wsl2)    powershell.exe -NoProfile -NonInteractive \
                     -Command "Start-Process \"$url\"" 2>/dev/null & ;;
        windows) cmd.exe /c start "" "$url" 2>/dev/null & ;;
        *)       xdg-open "$url" 2>/dev/null & ;;
    esac
}


# ── PKCE generation (bash + openssl) ─────────────────────────────────────────
generate_pkce() {
    CODE_VERIFIER=$(openssl rand -base64 64 | tr '+/' '-_' | tr -d '=\n' | head -c 86)
    CODE_CHALLENGE=$(printf '%s' "$CODE_VERIFIER" | \
        openssl dgst -sha256 -binary | openssl base64 -A | tr '+/' '-_' | tr -d '=')
    STATE=$(openssl rand -base64 16 | tr '+/' '-_' | tr -d '=\n')
}


# ── Auth URL builder (pure bash, no python required) ─────────────────────────
build_auth_url() {
    local enc_scopes enc_redirect enc_state enc_challenge
    enc_scopes=$(printf '%s' "$USER_SCOPES" | sed 's/,/%2C/g; s/:/%3A/g')
    enc_redirect=$(printf '%s' "$REDIRECT_URI" | sed 's|:|%3A|g; s|/|%2F|g')
    enc_state=$(printf '%s' "$STATE" | sed 's/+/%2B/g; s/=/%3D/g; s|/|%2F|g')
    enc_challenge=$(printf '%s' "$CODE_CHALLENGE" | sed 's/+/%2B/g; s/=/%3D/g')
    echo "https://slack.com/oauth/v2/authorize?client_id=${CLIENT_ID}&user_scope=${enc_scopes}&redirect_uri=${enc_redirect}&state=${enc_state}&code_challenge=${enc_challenge}&code_challenge_method=S256"
}


# ═════════════════════════════════════════════════════════════════════════════
# --check mode: show stored tokens, verify each, report status
# ═════════════════════════════════════════════════════════════════════════════
if [[ "$CHECK_MODE" -eq 1 ]]; then
    if has_real_python3; then
        python3 "${SKILL_DIR}/slack_auth_listener.py" --check
    else
        if [[ -f "$TOKEN_FILE" ]]; then
            echo "Stored token file: $TOKEN_FILE"
        else
            echo "No tokens stored. Run /slack-auth to authenticate."
        fi
        echo "(Install Python 3 for detailed token status)"
    fi
    exit 0
fi


# ═════════════════════════════════════════════════════════════════════════════
# --revoke mode: remove a stored token
# ═════════════════════════════════════════════════════════════════════════════
if [[ "$REVOKE_MODE" -eq 1 ]]; then
    if has_real_python3; then
        python3 "${SKILL_DIR}/slack_auth_listener.py" --revoke
    else
        echo "Install Python 3 to use --revoke."
        exit 1
    fi
    exit 0
fi


# ═════════════════════════════════════════════════════════════════════════════
echo ""
echo "Platform: $PLATFORM  |  Runtime: $RUNTIME"


# ═════════════════════════════════════════════════════════════════════════════
# PATH 1: Python 3 — two-phase flow via slack_auth_listener.py
# ═════════════════════════════════════════════════════════════════════════════
if [[ "$RUNTIME" == "python3" ]]; then
    if [[ "$PREPARE_MODE" -eq 1 ]]; then
        python3 "${SKILL_DIR}/slack_auth_listener.py" --prepare
    else
        python3 "${SKILL_DIR}/slack_auth_listener.py" --listen
    fi
    exit $?
fi


# ═════════════════════════════════════════════════════════════════════════════
# PATH 2: curl + openssl — URL-paste fallback (works everywhere)
# For --prepare: generates state, opens browser, prints URL, exits.
# For --listen: reads pasted callback URL as $2 argument (provided by Claude
#               after user pastes it via AskUserQuestion).
# ═════════════════════════════════════════════════════════════════════════════
if ! command -v curl >/dev/null 2>&1 || ! command -v openssl >/dev/null 2>&1; then
    echo "❌ No supported runtime found (Python 3 or curl+openssl)."
    echo "   Install Python 3 to use /slack-auth."
    exit 1
fi

STATE_FILE="/tmp/slack_auth_state.json"

if [[ "$PREPARE_MODE" -eq 1 ]]; then
    generate_pkce
    AUTH_URL=$(build_auth_url)
    # Persist state for --listen phase
    printf '{"status":"new","code_verifier":"%s","state":"%s"}' \
        "$CODE_VERIFIER" "$STATE" > "$STATE_FILE"
    chmod 600 "$STATE_FILE"
    open_browser "$AUTH_URL" 2>/dev/null || true
    echo ""
    echo "Using URL-paste flow (no HTTP listener available on this system)."
    echo "AUTH_URL=$AUTH_URL"
    exit 0
fi

# --listen phase for curl path: Claude passes the callback URL as second argument
# (first argument is "--listen", second is the pasted redirect URL)
CALLBACK_URL="${2:-}"
if [[ -z "$CALLBACK_URL" ]]; then
    echo "❌ No callback URL provided. Usage: slack_auth.sh --listen <redirect_url>"
    exit 1
fi

# Read state
if [[ ! -f "$STATE_FILE" ]]; then
    echo "❌ State file not found. Re-run /slack-auth."; exit 1
fi
CODE_VERIFIER=$(grep -o '"code_verifier":"[^"]*"' "$STATE_FILE" | cut -d'"' -f4)
EXPECTED_STATE=$(grep -o '"state":"[^"]*"'       "$STATE_FILE" | cut -d'"' -f4)
rm -f "$STATE_FILE"

CODE=$(printf '%s' "$CALLBACK_URL" | grep -oP '(?<=code=)[^&]+' 2>/dev/null \
    || printf '%s' "$CALLBACK_URL" | sed 's/.*[?&]code=\([^&]*\).*/\1/')
RETURNED_STATE=$(printf '%s' "$CALLBACK_URL" | grep -oP '(?<=state=)[^&]+' 2>/dev/null \
    || printf '%s' "$CALLBACK_URL" | sed 's/.*[?&]state=\([^&]*\).*/\1/')

if [[ -z "$CODE" ]]; then
    echo "❌ Could not extract authorization code from the URL."
    exit 1
fi
if [[ "$RETURNED_STATE" != "$EXPECTED_STATE" ]]; then
    echo "❌ State mismatch — stale or tampered URL. Re-run /slack-auth."
    exit 1
fi

echo ""
echo "Exchanging code for token..."

RESPONSE=$(curl -s -X POST https://slack.com/api/oauth.v2.access \
    -d "code=${CODE}" \
    -d "redirect_uri=${REDIRECT_URI}" \
    -d "client_id=${CLIENT_ID}" \
    -d "code_verifier=${CODE_VERIFIER}")

if [[ -z "$RESPONSE" ]]; then
    echo "❌ No response from Slack API. Check your network connection."
    exit 1
fi

if has_real_python3; then
    python3 "${SKILL_DIR}/slack_auth_listener.py" --store "$RESPONSE"
else
    # Last resort: save raw JSON, user must process manually
    printf '%s' "$RESPONSE" > "${TOKEN_FILE}.raw"
    chmod 600 "${TOKEN_FILE}.raw"
    echo ""
    echo "⚠️  Python 3 unavailable for JSON parsing."
    echo "   Raw token response saved to ${TOKEN_FILE}.raw"
    echo "   Install Python 3 and re-run /slack-auth for full token storage."
fi
